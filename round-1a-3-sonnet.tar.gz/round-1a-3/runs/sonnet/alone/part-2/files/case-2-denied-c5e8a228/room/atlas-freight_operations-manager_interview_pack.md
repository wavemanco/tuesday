# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Round type and relationship to the interviewer: not known. Built as a generic loop (screen, hiring manager, panel) with flat persona weights, which is a noticeably weaker pack than one built with the relationship in hand. The upgrade menu says what would fix that.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values: does past behavior show how you work with others |
| EXP | Work-experience deep-dive: does the claim survive scrutiny, and what was actually you |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth |
| CASE | Live problem from the role: structure and reasoning |

An answer slot is an instruction for the interview, not a question for you. Where one appears, answer whichever branch is true. The honest second branch is a limit, not a confession.

## Prep triage

You have a week. In order:

1. A1: the step-up objection. This is the highest-ROI prep in the pack; rehearse it aloud until it is boring.
2. C1 and C2: the 40% mis-pick figure, how it was counted and how much was yours.
3. A3 and D2: the Power BI gap, said plainly with a learning plan.
4. E1: the 90-second journey arc.
5. B1 and B2: one live diagnosis each, out loud, structure first.

Everything else is insurance.

## Fit snapshot

The JD, as you gave it: "Own daily terminal operations across 4 sites; drive on-time performance and cost-per-shipment down; lead a team of 12 supervisors; build reporting in Excel/Power BI; 5+ years operations leadership required; Lean/Six Sigma a plus." Your background, as you gave it, is the evidence pool. Nothing here has been inspected, so confidence tops out at medium.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material carries shift-level management and a peak-season plan, and says nothing about terminals or about more than one site. Words stay at the quotes' scope: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's four-sites line makes a probe on scope likely. If your responsibility covered anything beyond your own shift, say what; if not, say so plainly and stay with the shift and the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your quote is about mis-pick rate, not on-time performance or cost-per-shipment, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if any on-time or cost measure moved in your work, say which and how it was counted; if you did not track one, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The material says three supervisors and the JD says twelve; the pack states that as its own observation. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: say what your current role covers in your own words; if it covers anything beyond what the quote says, say what, and if not, say so plainly and stay with the three |
| F4 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | medium | [grounded] | discovery | Your material says solid Excel and does not show whether you built reporting in it. Answer slot: the JD's build-reporting line makes a probe likely. If you built reports in Excel, say what they showed and who read them, in your own words; if you used it otherwise, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The first quote counts years in operations and does not say how many were leadership. Answer slot: the JD's required line makes a probe on the leadership years likely. If some of the seven were in a leadership role, say how many and in what role, in your own words; if fewer than five were, say so plainly and stay with the seven years and the current role |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | discovery | Your quote says green belt certified and does not say which program or whether it was applied to work. Words: "I'm green belt certified." Answer slot: the JD names Lean and Six Sigma, so a probe on which program and where you applied it is likely. If you applied it, say where and what you did; if the certification was not applied to work, say so plainly and stay with the certification |

Gate check: none of the JD's lines is a term such as a licence, location or schedule. "5+ years operations leadership required" is an experience requirement, so it is graded as F6 rather than as a gate.

## Persona table

No loop source establishes this loop, so the weights rest on the Generic archetype (screen, hiring manager, panel) with flat weights, not on Atlas Freight's documented process. If you learn who is interviewing you, the weights change.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| Skeptic | Quiet probing of the step up in scope and of the Power BI gap | Flat. Round type and interviewer are unknown. Gets four questions because the pack's highest-ROI objection sits here: F3 and F1 are where the JD's scale presses hardest on the material | Rehearse A1 until it is boring; bridge only from the quotes in F1 and F3; concede the step up plainly and give a plan said as a plan |
| Case / Strategist | Live problems on on-time performance, cost per shipment and the first thirty days | Flat. Gets four questions because the JD is an operating role whose first requirements are metrics to move, so a live problem is a likely format in any manager-level round | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Data-Driven Prober | Reads the background line by line; probes the 40% figure and the surge plan | Flat. Three questions. Your 40% mis-pick figure is the one number in your material, and a figure is the usual target | Know what you can and cannot say about how the figure was counted; say plainly when you do not know; name the weakest assumption before they do |
| Pressure | Time-boxes, devil's advocate on scale, Power BI and cost | Flat. Three questions. Unknown relationship, so no basis to weight it up or down | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Conversational | The journey question, Lean as a casual aside, "what do you know about us" | Flat. Three questions. Casual-register questions are still scored | A pre-scripted 90-second arc built only from the quotes; treat the Lean aside as scored |
| Peer Evaluator | Seam between sites, credit across teams, supervisor pushback | Flat. Three questions. A peer terminal or operations lead is plausible in a multi-site role, but nothing in your material says so | Propose seam principles rather than pretending to know the seam; disagreement stories that show spine and tact |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're over three supervisors today, and this role has twelve across four sites. What makes you think you can step up to that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Open with the quote at its own scope: "I'm currently a senior shift manager over 3 supervisors." Concede the step in the quote's own terms: "A team of twelve is bigger than the three I lead now." Answer slot: say what your current role covers in your own words; if it covers anything beyond what the quote says, say what, and if not, say so plainly and stay with the three. Then give a plan, said as a plan, for getting to know the supervisors and the sites in your first weeks, in your own words. Hold through two follow-ups by returning to the three, never by adding to them | F3 and F1 are where the JD's scale presses hardest on the material, so this objection arrives in some form. JD because it scores a stated requirement; it gets the deepest rehearsal because it is the likeliest question and the thinnest evidence |
| A2 | "The posting asks for five-plus years of operations leadership. Which of your years count toward that?" | JD | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" | Say the quotes as they stand: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: if some of the seven were in a leadership role, say how many years and in what role, in your own words; if fewer than five were, say so plainly and stay with the seven years and the current role. Keep the count to what each role actually was | F6 is a required line on the JD and the quote counts operations years, not leadership years. JD because it scores a stated requirement |
| A3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "solid Excel, never used Power BI" | Choose the weakness that is true for you and say it before they do. Your material states one: "I haven't used Power BI." Pair it with "solid Excel" at its own scope and a learning plan said as a plan, in your own words. Answer slot: if a different part of the JD is your weakest, name that one instead and say what you would do about it. Calibrated candor beats bluffing a tool | F5 is the one gap you have stated yourself, so it is the likeliest answer to this stem. JD because it asks you to score yourself against the posting |
| A4 | "What's behind the move, and why now?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | The pack does not supply a reason and will not guess one. Start from where you are, in the quote's words, then say what draws you to this role in your own words, then why now. Answer slot: give your actual reason; if it is mixed, say both parts plainly. Do not criticize your current employer | A motivation probe is standard for a candidate stepping up in scope, and F1 is the step. EXP because it tests whether your story is consistent under follow-up |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one terminal has slipped over three weeks. What do you need to know first, and how do you structure the diagnosis?" | CASE | [generic] | Clarify before structuring: what on-time means here and where it is measured, where the slip sits, and what changed. Then objective, segmentation, approach, metrics, risks, thinking aloud, and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's on-time performance line (F2's requirement) asked as a live decision. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Cost per shipment has to come down without hurting service. Where do you look first, and what would you refuse to cut?" | CASE | [generic] | Structure it: define the cost base and the service floor, find where cost per shipment moves most, rank options by service risk, and name the anti-pick, the saving you would turn down, with the reason. No claim about your past is needed | The JD's cost-per-shipment line, with an anti-pick because the job includes saying no. CASE because it scores structure |
| B3 | "Sketch your first thirty days across four sites and twelve supervisors you've never met." | CASE | [generic] | Clarify what is already measured, then what you would learn, whom you would meet and in what order, what you would leave alone, and what you would commit to by day thirty. Say it as a plan; it is a method, not a past | F1 and F3 together, asked as a plan, which is the safest form for a scope you have not held. CASE because it scores structure |
| B4 | "What would you want on a daily terminal dashboard, and how would you build the first version?" | JD | [grounded] "solid Excel, never used Power BI" | Start from the two measures the JD names: on-time performance and cost-per-shipment. Say the first version would be in Excel, in your own words, and that you would learn Power BI as a plan. Answer slot: if you have built any report in Excel for your site, say what it showed and who read it; if not, say so plainly. JD content, CASE delivery | The JD's build-reporting line (F4 and F5) in the live form it usually takes. JD first because it scores a stated requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what you did in the quote's words: "I cut mis-pick rate 40% by redesigning the pick path." Then the four slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer slot: if you know how it was counted, say how; if you do not, say plainly that you do not know how the figure was counted. The pack supplies no baseline, period or method | The 40% is the one figure in your material, so it is a magnet target; F2 is its row. EXP because it tests whether the claim survives scrutiny |
| C2 | "How much of the pick-path redesign was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if others worked on it, say who and what each did; if it was yours alone, say so plainly. Hold your account through the second follow-up, concede specifically any part that was not yours, and never fold on the part that was | Attribution probes follow every headline figure (F2). EXP because it tests precision about what was yours |
| C3 | "Tell me about the peak-season surge plan. What was in it?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Start with the quote: "I ran the site's peak-season surge plan two years running." Answer slot: say what the plan covered, in your own words, and whether you wrote it or ran one that was set for you, which the word ran does not settle; if you do not remember details, say what you do. Answer slot: if anything changed between the two years, say what; if nothing did, say so plainly | F1 holds this quote, and it is the closest your material comes to owning operations. The question exists because "ran" can mean wrote or executed, and a prober will ask which. EXP |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who already runs multiple terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause, restate the question, then use only the quoted beats in order, in your own words. Concede only what is true for you: if their experience is wider than yours in a particular area, name the area. Hold what you have through the follow-ups; do not argue you have equivalent scale | The Pressure stem applied to F1, which is the row a multi-terminal rival would beat. JD because it scores fit for the listed role |
| D2 | "You've never used Power BI and we need reporting built. Why isn't that a dealbreaker?" | JD | [grounded] "solid Excel, never used Power BI" | Hold, then concede. Hold: "solid Excel" at its own scope. Concede plainly: "I haven't used Power BI." Then a plan said as a plan, in your own words: how you would learn it and by when. Answer slot: if you have built any reports in Excel, say what they showed and who read them; if not, say so plainly. Never claim Power BI exposure the quote does not carry | F5 is the stated gap, and a pressure interviewer goes straight at a stated gap. JD because it scores a stated requirement |
| D3 | "The posting says drive cost-per-shipment down. What have you done about cost?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if any of your work moved a cost measure, say which and how it was measured; if none did, or it was not yours, say so plainly and stay with the mis-pick result: "I cut mis-pick rate 40% by redesigning the pick path." Hold that through two follow-ups without adding to it | F2 is the only row near this requirement and it speaks to mis-pick rate. JD because it scores a stated requirement |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc with beats only as the quotes state them, in your own words, in this order: the seven years, the current role, the pick-path result, the two peak seasons. End on why this role. Answer slot: give your reason for this role in your own words; if it is mixed, say so. Add no beat the quotes do not carry: no titles, team sizes or dates | The biography question is asked in some form in nearly every loop and is scored even when it feels casual. EXP; F1 and F2 supply the beats |
| E2 | "Lean and Six Sigma are listed as a plus. What's your history with them?" | JD | [grounded] "green belt certified" | Say it as it stands: "I'm green belt certified." Answer slot: say which program it was and where you applied it, in your own words; if it was not applied to work, say so plainly and stay with the certification | F7's requirement, asked casually, which is how a plus gets scored. JD |
| E3 | "What do you know about us, and what drew you to a regional carrier?" | CO | [generic] | This pack could not retrieve anything about Atlas Freight, so it supplies no company fact. Read the company's own site and careers page before the interview and bring two facts you found yourself, then connect them to the role in your own words | The homework check. `[generic]` because the research searches were refused; the upgrade menu says what pasting the company's pages would change. CO |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our terminals depend on each other. Where's the seam between your site and mine, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam rather than a pretended map: who owns a shared decision, how a disagreement escalates, what is measured the same way at every site. Then spine and tact: say what you would hold your ground on and why, and what you would give. No claim about your past is needed | F1's four-site requirement, in a peer's collegial packaging. JD because it scores how you would do the listed job |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams and had several owners. It needs a named contribution of yours, a named contribution of someone else's, and credit given in how you described it afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No fit row carries a cross-team story, so this is a scaffold case. VAL because it scores behavior with peers |
| F3 | "Tell me about a time one of your supervisors pushed back on a plan of yours." | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: choose a time a supervisor of yours disagreed with you and the disagreement changed or confirmed the plan. It needs a named plan, their objection and what you did next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's team-of-twelve line (F3) raises the question of how you lead supervisors. EXP because it tests a real instance |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own daily terminal operations across 4 sites | A1, B3, F1, C3 |
| Drive on-time performance and cost-per-shipment down | B1, B2, D3, C1 |
| Lead a team of 12 supervisors | A1, B3, F3 |
| Build reporting in Excel/Power BI | B4, D2, A3 |
| 5+ years operations leadership | A2 |
| Lean/Six Sigma a plus | E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How are on-time performance and cost-per-shipment reported today, and who reads them?" | The JD makes you owner of both, so it shows you read the role as a metrics job; the answer also tells you how much reporting exists before you build any |
| 2 | "Is Power BI already in use here, or is building it part of this role?" | It gets the reporting expectation on the table early, and lets your learning plan meet the real one |
| 3 | "How are the twelve supervisors spread across the four sites, and what is the experience mix?" | It shows you are already thinking about the span, and the answer tells you where your first weeks should go |
| 4 | "Which of the four sites would you want me to understand first, and why?" | It signals a plan for the first thirty days and hands the interviewer a chance to teach |
| 5 | "What would success look like at ninety days?" | It converts the interview into an agreement about what good looks like, which is also the best defense against the scope objection in A1 |
| 6 | "What happens after this round?" | Process logistics; it also tells you who you meet next, which reweights the persona table |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says shift management and a surge plan, not terminals or several sites |
| Led a team of twelve supervisors, or a comparable span | Inflated form of F3 | "I'm currently a senior shift manager over 3 supervisors." The limit is the pack's observation: the material says three |
| Brought on-time performance or cost-per-shipment down | Inflated form of F2 | F2's quote at its own scope: the material says mis-pick rate, not on-time performance or cost |
| Built reporting in Power BI, or has worked with it | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't used Power BI." No slot |
| Five or more years of operations leadership | Inflated form of F6 | F6's quotes at their own scope: the material counts seven years in operations, and does not say how many were leadership |
| Led Lean or Six Sigma improvement projects | Inflated form of F7 | "I'm green belt certified." The limit is the pack's observation: the material says certified, not applied |

## Sources

Provided documents: the JD text and the background summary in your message. No values page, loop source or strategy brief was provided, so no loop source establishes this loop and no values-style round is detected; the values cheat sheet is dropped.

Searches sent, all refused:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics terminals news strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Every call was refused. It would have fed a values cheat sheet; no published value is in hand, so none is named |
| 2. Interview process, operations manager | unavailable | Every call was refused. It would have set the loop and persona weights; the Generic archetype with flat weights stands in |
| 3. Company strategy and recent news | unavailable | Every call was refused. It would have grounded the CO bank; E3 is generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative JD for the title | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you meet (hiring manager, peer, skip-level, recruiter, panel) → persona weights move off flat, and banks are added or dropped to match
- The recruiter's prep email (focus areas, any pre-declared deliverable, process) → coverage of anything graded; usually one email
- The interviewer's name → an interviewer read and a reverse question tied to their own path
- Atlas Freight's own careers or values page, pasted → CO and VAL questions become grounded instead of generic, and a values cheat sheet if the loop documents a values round
- Your answers to the answer slots in F1, F2, F3, F4, F6 and F7, and how the 40% in C1 was counted → those rows' bridges become your own words instead of slots; the artifacts that would raise confidence are the belt certificate and the site's before-and-after pick-accuracy report
- Deep research: a deeper research pass would add a strategy brief and role-family loop reports, up to 6 more searches and 2 more fetches, several more minutes, and needs search permission granted
- A tuesday-dossier.md from an earlier session → verified evidence and a strategy for each weak area, never a prerequisite
