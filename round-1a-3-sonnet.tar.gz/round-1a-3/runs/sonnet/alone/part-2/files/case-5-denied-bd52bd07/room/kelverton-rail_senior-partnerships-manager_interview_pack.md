# Senior Partnerships Manager, Kelverton Rail: second-round panel prep pack

**Round:** 60-minute panel. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your spoken POV on operator partnerships over the next 18 months, no slides, landing on what it means for the operators themselves. Remaining time: Q&A, with Ross pushing on commercials. Tuesday.

**Built on:** your message and the recruiter's email as you quoted it. No JD, no company research (web searches were refused in this session), and the market report was not available to me, so none of it is read. Sections that depend on those are dropped or flagged, and the upgrade menu says what each would add.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge, and thinking at the company's altitude |
| CASE | A live problem from the role, structured aloud |

Answer slots (instructions that end without a question mark) are for the interview, not for me: answer whichever branch is true for you, and if the practice was not yours or never existed, say so plainly. That is a limit, not a confession.

**Highest-ROI prep in this pack: B1** (the "never carried a direct quota" challenge from Ross). It will arrive in some form, because the recruiter said Ross will push on commercials and you have stated the quota gap yourself.

## Prep triage (about four hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 75 min | Build the POV: choose a spine, a departure, an anti-pick and the operators close. Speak it aloud twice against a 15-minute timer | Section Graded deliverable, A1, A3 |
| 2 | 45 min | Rehearse B1 aloud three times, including all three follow-ups, until the plain acknowledgment sounds boring | B1, Prohibited claims |
| 3 | 40 min | Re-read the market report for two things: one point to agree with, one to depart from, and what it cannot tell you | A4 |
| 4 | 30 min | Write down, in your own words, what you do and do not know about how the £4M and the 6-to-40 were counted | D1, D2, D3 |
| 5 | 30 min | Rehearse the rail and consulting gaps | B2, C1, C2, C3 |
| 6 | 20 min | Pick your reverse questions and rehearse the journey arc | Reverse questions, E1, E2 |

Everything else (A2, A5, B3, B4, F1, F2) is insurance: read once, rehearse if time remains.

## Fit snapshot

The JD was not supplied, so requirements are the recruiter's own words (quoted from your message) and your description of the company.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Senior Partnerships Manager" — recruiter's email, as you quoted it | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | none | A CV-style line with nothing inspected behind it, so expect a probe on what the channel covered. Lead with it in its own terms: nine years in partnerships, the last four running the ISV channel at a payments company |
| F2 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material counts partners in an ISV channel at a payments company; it does not show an operator-facing plan, and the POV needs none of your past to be forward-looking. Words at the quote's scope: "I took the ISV channel from 6 partners to 40." The figure raises the defend-the-number slots, covered in D2. Answer slot: how a partner was counted in the 40, what the count is sensitive to, the assumption you would defend least, and which part was yours; if you do not know how something was counted, say so plainly |
| F3 | "Please land on what it means for the operators themselves" — recruiter's email | "bus and light rail network planning", "so I know the operator world from the other side" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning. It does not say which operators, or which side "the other side" is, so the pack leaves that phrase for you to define. Words at the quote's scope: "My transport consulting years were bus and light rail network planning." Answer slot: if any of that planning work showed you what the operators using it needed, say what you saw, in your own words; if it did not, say so plainly and stay with the planning work |
| F4 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue", "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | You stated the negative, so the plain acknowledgment is yours to say: "I've never carried a direct quota. What I have is influenced revenue, roughly £4M." The figure raises the defend-the-number slots, covered in D1 and D3. The pack does not say what the influence consisted of |
| F5 | "they sell scheduling software to train operating companies" — your message | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then a plan, never a past: how you would learn how operators buy |

No gate (location, right to work, office pattern, start date) appears in the material, so no gate row exists. A JD would show whether there is one.

## Graded deliverable: the 15-minute POV

Declared by the recruiter: "present a short POV on where you'd take our operator partnerships over the next 18 months", "no slides needed, just talk us through it", and "land on what it means for the operators themselves".

**Facts you may build on** (quoted from the rows they draw on):

| Row | Exact words | Use |
|---|---|---|
| F2 | "took it from 6 partners to 40" | Your channel-building experience, at its own scope |
| F3 | "bus and light rail network planning" | Your operator-side exposure, at its own scope |
| F4 | "never carried a direct quota, only influenced revenue" | The plain acknowledgment that lets Ross's push on commercials land on a stated position |

**Theses.** All three are patterns for you to test, not facts about Kelverton or its operators. Pick one as the spine.

| Thesis | Provenance | Mandatory concession | What it means for operators |
|---|---|---|---|
| T1 Depth before breadth: fewer operator partnerships over 18 months, each tied to a result an operator can state in its own terms | [generic] | It gives up partner count as the headline, and you cannot size which relationships to keep without Kelverton's own data. Say that | An operator should be able to say what changed for it, in its own words. If it cannot, the partnership is not done |
| T2 Adoption is where a partnership earns its place: judge each one by how much change effort it removes for the operator | [generic] | It is a hypothesis. The nearest thing from your own work is F3's "bus and light rail network planning", which is not train operating companies. Say it is a hypothesis to test with Deepa | Operators carry less change load to get the value |
| T3 Commercial shape first: for each partnership, set out what it earns Kelverton and what it costs the operator before anything is built | [generic] | You do not have Kelverton's current terms or margins and would ask for them first, and per F4 you have "never carried a direct quota". Say both plainly | Operators see what they are paying for and what they get |

**Recommended shape (my reasoning, yours to overrule):** T1 or T2 as the spine, with T3 stated proactively as your answer on commercials, because the recruiter said Ross will push there and a thesis that meets the push before it arrives is stronger than one defended afterwards.

**Differentiating from the report.** The report came from Kelverton's own strategy team, per your message, so the panel can be assumed to know it. Reciting its shortlist scores as homework.

| Move | What to do | Provenance |
|---|---|---|
| One consensus item | Pick one point from the report and credit it briefly, to show you read it | [generic] |
| One departure | Pick one point you would handle differently, with your reason and what evidence would change your mind | [generic] |
| One anti-pick | Name something you would deliberately not do in 18 months. A suggestion to test: not making partner count the 18-month headline. Expect "but you took the ISV channel from 6 to 40": your words stand ("took it from 6 partners to 40"); what count did or did not tell you there, or what you would measure here instead, is yours to say | [generic] |

I have not read the report, so I cannot say which items are the consensus ones. Paste the key pages and I will map them.

**The requested close, what it means for operators:** end on one sentence per thesis you chose, in the form "an operator would be able to ___", written by you from your own view of operators. Do not close on Kelverton's benefit.

**Run of show (15 minutes):**

| Minutes | Beat |
|---|---|
| 0–1 | Frame it: what you are going to say, and that it is a view to test, not a finished plan |
| 1–4 | What you would want to confirm first about Kelverton's partner results and operators' feedback |
| 4–10 | Spine thesis, then the consensus item and the departure from the report |
| 10–12 | Anti-pick |
| 12–15 | What it means for the operators, then stop and invite the panel in |

## Persona table

The loop is one session with a panel, established by the recruiter's email, so no archetype fallback is used. Weights blend the top two personas of each member's relationship, per the panel rule.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live follow-ups on the POV: what would you need to know, what would you drop, how would you measure it | Highest: the POV itself is a live strategic problem, and Deepa is your future manager (hiring-manager prior) | Clarify, structure, think aloud, challenge one premise respectfully (A1–A5) |
| Pressure / Stress | Ross cutting in on commercials, time-boxing, "how much was actually you" | High: the recruiter said Ross will push on commercials, and Commercial Director sits in the executive prior | Pause, restate, hold the position F4's quote carries through two follow-ups, concede specifically (B1–B4) |
| Skeptic | Quiet persistent probing of the rail and consulting gaps | High: you stated both gaps (F5, F3), and a hiring manager is buying capability and derisking gaps | Rehearse the most predictable objection until it is boring; bridges from your stated evidence only (C1–C3) |
| Data-Driven Prober | Ross or Deepa on how the £4M and the 6-to-40 were counted | Medium: figures on a CV are magnet targets, and the commercial seat makes a denominator question likely | Know what you can and cannot say about how each figure was counted; say plainly when you do not know (D1–D3) |
| Conversational | "Walk us through the journey", "why rail-tech, why now" | Medium: panels open and close in this register, and it is still scored | A 90-second arc built only from your own sentences (E1, E2) |
| Peer Evaluator | Where partnerships ends and Ross's commercial team begins | Lower: Ross is not a peer, but the seam question is natural with a commercial director in the room | Offer seam principles and say what you would bring his team (F1, F2) |
| Values / Behavioral | Not included | The recruiter's description names no values round, and no values were read | None needed. A values page would reverse this |

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through your view: where would you take our operator partnerships over the next 18 months, and what does that mean for the operators themselves?" | CASE | [generic] | This is the deliverable itself, so follow the build section and the run of show. Open by saying what you would want to confirm with Kelverton first, then spine, departure, anti-pick, operators close. The guidance makes no claim about your past | F2 and F3 are the rows nearest this ask. CASE because it is a live plan, and it is the part the recruiter pre-announced |
| A2 | "What would you need to know about our operators before committing to that plan, and who would you ask first?" | CASE | [generic] | Name two or three things you would want to confirm (how operators currently experience the partnerships, which ones they use, what they would drop) and who inside Kelverton and at an operator could tell you. Say it as a plan to test, not as knowledge you have | A clarify-first test is how case interviewers score structure. The question is likely because the POV has to be built from outside the building |
| A3 | "Name one partnership you would deliberately not pursue in the next 18 months, and why." | CASE | [generic] | Use the anti-pick from the build section. Give the reason in operator terms, and name the evidence that would change your mind | The role's job includes saying no, so a candidate who only adds is exposed. CASE because it tests judgment on a live choice |
| A4 | "You've read our strategy team's report. Which part would you depart from?" | CO | [grounded] "which I've read" | The pack has not read the report, so it cannot choose for you. Answer slot: name the point you would handle differently, with your reason, in your own words; if you do not disagree with any, say so plainly and name where you would want more evidence. Credit one consensus item first | F2 is the row the POV draws on. CO because it tests homework depth, and the report is a shared source the panel can recite |
| A5 | "How would you know, twelve months in, that this is working for the operators rather than just for us?" | CASE | [generic] | Structure it: ask which of an operator's own measures the partnership should move, agree that with the operator before building, and name what you would stop if it did not move. Say you would want Kelverton's existing measures first. It makes no claim about your past | F3 is the row where operator-side evidence is thinnest. CASE because the recruiter asked you to land on the operators |

### B. Pressure / commercial

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've told us you've never carried a direct quota. Why should we trust you with commercial outcomes for these partnerships?" | JD | [grounded] "never carried a direct quota, only influenced revenue", "roughly £4M of influenced revenue" | The deepest rehearsal in the pack. **Hold:** "I've never carried a direct quota. What I have is influenced revenue, roughly £4M." **Concede specifically:** that is a real difference from carrying one, and you will not pretend otherwise. Then stop; do not fill the pause with a stronger claim. **Follow-up 1:** "What were you accountable for, then?" Answer slot: say what you were measured on, if anything, in your own words; if you were not measured on a figure, say so plainly and return to the quote. **Follow-up 2:** "How much of that was actually you?" Answer slot: say which part was yours; if you cannot separate it, say so. **Follow-up 3:** "And if we gave you a number in month three?" Say, as a plan, what you would ask to agree first: how it is counted and what is in your control. Rehearse aloud three times | F4 is where Ross's push on commercials lands hardest. JD because it scores the commercial requirement the recruiter raised, delivered as pressure |
| B2 | "Sixty seconds: you haven't sold into rail. Why you?" | JD | [grounded] "Never sold into rail specifically", "bus and light rail network planning" | **Hold:** "I haven't sold into rail specifically." Then the nearest thing your material carries, at its own scope: "My transport consulting years were bus and light rail network planning." **Concede:** that is not selling to train operating companies and you would not claim it is. Close with a plan for the first weeks, not a claim about the past. Time-box to a minute and stop | F5 is the stated gap and F3 the nearest evidence. JD because it tests fit to the job, with Pressure as the delivery |
| B3 | "Walk me through the commercial terms you'd want in an operator partnership: who pays whom, and for what?" | CASE | [generic] | Ask what Kelverton's current terms are before proposing anything. Then set out the question as options to test (what the partnership earns Kelverton, what it costs the operator, who bears the risk) and say which you would test first and why. State plainly that you have not carried a number, per F4, so you would involve Ross's team early. No claim about your past beyond that | The recruiter flagged commercials, so a structure for terms is likely wanted. CASE because it is a live commercial design problem |
| B4 | "What would your 18-month plan cost us, and what would we have to stop doing?" | CASE | [generic] | Name the cost categories you would ask about (people, partner support, integration effort) and say you would size them with Kelverton's own numbers. Then name what the plan displaces. Do not give figures; you do not have Kelverton's | Commercial pressure on the POV is the likeliest way Ross tests it. CASE because it forces trade-offs, not enthusiasm |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | Pick the weakest part honestly, and if it is the rail gap, say it plainly: "I haven't sold into rail specifically." Then a ramp plan as a plan: who you would talk to first, what you would read, what you would ask operators. Do not pick a fake weakness | F5 is the largest stated gap, and Deepa will want to see you name it first. JD because it scores honest self-assessment against the role |
| C2 | "Your consulting years were bus and light rail. How does that carry over to train operators?" | EXP | [grounded] "bus and light rail network planning" | Start from the quote at its scope: your transport consulting years were bus and light rail network planning. Answer slot: if any of that work showed you what the operators using it needed, say what, in your own words; if it did not, say so plainly and stay with the planning work. Do not describe it as train operating company experience | F3 is the only operator-side evidence and the question tests its limit. EXP because it asks what the quoted work actually covered |
| C3 | "You took the ISV channel from 6 partners to 40 at a payments company. What from that would transfer here, and what wouldn't?" | JD | [grounded] "took it from 6 partners to 40", "last 4 at a payments company running the ISV channel" | Open with the quote at its scope: you took the ISV channel from 6 partners to 40. Then say, in your own words, what you think carries over and what clearly does not. Both halves are yours to choose, and a candid "does not" scores higher than a stretched "does". Do not describe how the growth was achieved beyond what you can stand behind | F2 is the row this probes. JD because it scores transfer to the listed job |

### D. Data-driven prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: say how it was counted, what it is sensitive to, and which part was yours, in your own words; if you do not know how something was counted, say so plainly. The pack supplies no method and no baseline | F4's figure is the likeliest target for a commercial seat. EXP because it tests attribution honesty |
| D2 | "What counted as a partner when it went from 6 to 40?" | EXP | [grounded] "took it from 6 partners to 40" | Answer slot: say what the count included and what it left out, in your own words; if you do not know or never fixed a definition, say so plainly and return to the quote | F2's figure is a count, and counts hide definitions. EXP because it tests how you know your own number |
| D3 | "Which assumption behind the £4M would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Name it before they do, in your own words, then say what would change if it were wrong. The pack names no assumption for you; if you do not know one, say so plainly | Naming the weakest assumption converts a gotcha into credibility. EXP, per the metric rule |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through the journey from transport consulting into partnerships." | EXP | [grounded] "5 years in transport consulting", "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc with only the beats your sentences state: five years in transport consulting, then nine years in partnerships, the last four running the ISV channel at a payments company. Your material does not say what the first five partnerships years were. Answer slot: if asked, say what that role was, in your own words | F1 carries the arc. EXP because it tests whether the story hangs together |
| E2 | "Why rail-tech, and why now?" | EXP | [generic] | Give your actual reason in your own words. If the reason is not rail-specific, say so plainly and name what about this company is. The guidance supplies no reason | Skeptics and managers both ask it, and an inconsistent answer here undermines everything above. EXP because it tests motivation consistency |

### F. Peer / seam

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where's the seam between partnerships and commercial, and what happens when we disagree?" | CASE | [generic] | Offer seam principles rather than pretending to know the seam: who owns the operator relationship, who owns the terms, how a disagreement gets decided. Say what you would bring Ross's team, not only what you would need from it | A Commercial Director in the room makes the seam natural. CASE because it is a live organisational problem |
| F2 | "How do you handle credit when a partner-sourced deal closes in someone else's team?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: if there was a rule for how influenced revenue was credited, say how it was counted, in your own words; if there was no rule, or it was not yours, say so plainly and return to the quote. Then say how you would want to agree it here | F4's figure is the seam between partnerships and commercial. EXP because it asks how you actually handled attribution |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Senior Partnerships Manager" | C3, E1 |
| "where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, A4, B4 |
| "what it means for the operators themselves" | A1, A5, C2 |
| "Ross will push on commercials" | B1, B3, B4, D1, D2, D3, F2 |
| "they sell scheduling software to train operating companies" | B2, C1 |
| Mid-list JD requirements | None, and why: no JD was supplied, so none are known |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which operator partnerships are working best today, and what do the operators themselves say changed for them?" | Points the conversation at operator outcomes, which is where the recruiter asked you to land |
| R2 | "What would you need to see commercially at month 18 to call this a good hire?" | Gives Ross a chance to state his bar, and gives you the number you did not carry before |
| R3 | "Where did the strategy team's report differ from what operators tell you directly?" | Shows you treated the report as one input, not as the answer |
| R4 | "What do you most want the first 90 days to prove, given I haven't sold into rail specifically?" | Names the gap yourself and converts it into scope, which is the hold-then-concede move in a different register |
| R5 | "What is the hardest part of getting an operator to adopt something new?" | Invites the panel's own view and tests T2 without asserting it |
| R6 | "What are the next steps and timeline?" | Closes the logistics and shows you are ready to proceed |

## Prohibited claims

Built from the fit snapshot before the banks were written. These are not coached anywhere in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota or owned a revenue number | Negative you stated, F4 | The plain acknowledgment: "I've never carried a direct quota." No slot |
| Sold into rail, or has train operator buying experience | Negative you stated, F5 | The plain acknowledgment: "I haven't sold into rail specifically." No slot |
| Closed or generated £4M | Inflated form of F4 | F4's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: your material says influenced, not closed. D1 and D3 stay inside the figure |
| Experience of train operating companies' operations or scheduling | Inflated form of F3 | F3's quote at its own scope: "bus and light rail network planning". The limit is the pack's observation: your material says bus and light rail. C2's slot stays inside the planning work |

## Sources

**Provided:** your message, including the recruiter's email as you quoted it and your background description. The market report you mention was attached to the recruiter's email, not to this conversation, so I did not read it.

**Searches sent, all refused (permission not granted in this session):**
- "Kelverton Rail company values": refused
- "Kelverton Rail interview process partnerships manager": refused
- "Kelverton Rail strategy news scheduling software train operating companies": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused
- "Senior Partnerships Manager job description rail technology train operating companies": refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values cheat sheet; none is built, and the recruiter's description names no values round |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Would have checked loop structure; your own words from the recruiter establish this session, so persona weights are unaffected |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Would have fed a grounding brief and CO questions; A4 and the departure move are written as structures instead |
| 4. `Deepa` and `Ross` at Kelverton Rail | unavailable | Would have fed an interviewer read and a tailored reverse question; both are absent |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Would have grounded more fit rows and JD questions; the snapshot rests on the recruiter's words and yours |

## Upgrade menu

- The JD text → the fit snapshot's requirement rows become quotes from the posting, mid-list requirements get questions, and any gate (location, right to work, office pattern) shows up as a row
- The market report, pasted or its key pages → a grounding brief, a map of the consensus items to bring and depart from in the POV, and a sharper A4
- Deepa's and Ross's public profile text, pasted → an interviewer read, persona weights adjusted by their own history, and a reverse question tied to their paths
- Your answers to the slots in F2, F3, F4 (how the 6 and 40 and the £4M were counted, what the planning work showed you about operators) → those rows upgrade, and D1 to D3 and C2 become story-mapped. The artifact that would raise F4 from medium is a partner-attributed revenue report from your CRM or finance reporting
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, and it needs search permission, which was refused here) → a strategy brief and operator context for A1 to A5; say so if you want it
- The recruiter's view of what Deepa and Ross each care about → persona weights reset from stated focus areas instead of relationship priors
- A tuesday-dossier.md, if you have one → verified evidence and per-gap strategy constraints in place of the locally built prohibited list
