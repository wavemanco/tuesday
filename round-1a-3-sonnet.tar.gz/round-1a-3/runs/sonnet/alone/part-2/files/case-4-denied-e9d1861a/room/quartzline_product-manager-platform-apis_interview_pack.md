# Interview prep pack: Product Manager, Platform APIs at Quartzline

Hiring-manager round, 45 minutes, Thursday. The manager's name was not given. Built on your dossier (job underwriting, dated 2026-08-14), which supplies the requirements and your confirmed evidence.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: the only sentences about your past are ones you gave, quoted in each row.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the actual role |

Labels: `[grounded]` rests on a provided document or your confirmed claims; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about you or Quartzline. An answer slot is an instruction for the interview: it names what an interviewer is likely to probe and gives two honest branches, and it never asks you to say something you did not do. Question letters skip F, which belongs to the fit rows.

## Fit snapshot

Gradings for F2 (roadmap and prioritization authority), F6 and the confidence and gap type of F1 come from your dossier. F3, F4, F5, F7, F8 and F9 are graded here from your quotes, because the dossier names no weak area for them. The dossier lists no hard gates, and "3+ years" is a length-of-experience requirement, not a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's frame is a bridge positioned as adjacent, never as product-management experience. Say the two quotes at their own scope and call them adjacent work. The limit, as the pack's observation: your material carries integration delivery and sessions feeding product, and does not show a product-manager title or years in the role. The plain acknowledgment is sourced from prohibited_claims: "Having held a product manager title or role": you haven't held a product manager title or role. The second quote is confirmed with limited inspectable proof, so expect a probe on it |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an acknowledge_gap area and lists prohibited_claims: "Having owned a product roadmap" and "Having set prioritization for an engineering squad". The words are the plain acknowledgment only: you haven't owned a roadmap, and you haven't set prioritization for an engineering squad. Then a ramp plan said as a plan, never a past: what you would learn first, starting with which decisions belong to the PM and which to the two squad leads. No bridge and no slot |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | high | [inferred] | transferability | The quotes say client integrations of the vendor's REST APIs and a playbook, and the words stay there. The limit, as the pack's observation: your material does not show a product release of your own. Answer slot: the JD's line makes a probe on what you took to go-live likely. Say which of scoping, requirements, architecture, UAT and go-live were yours to decide and how you decided, in your own words; if any were not, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes touch technical work without showing what the playbook contains. Answer slot: the JD's technical-fluency line makes a probe on what the playbook holds likely. Say what it covers, in your own words; if it covers less than the probe expects, say so plainly and stay with the playbook as quoted |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quotes reach clients and product, at their own scope. They do not name the other groups the requirement lists. Answer slot: the requirement's three groups make a probe on who else you worked with likely. Say who else was involved and what you did with them, in your own words; if the work was with clients and product only, say so plainly |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | low | [grounded] | discovery | The dossier grades this low with strategy clarify, and no verified entry speaks to it, so nothing about your past goes in the answer. Answer slot: the requirement's own wording, "Agile delivery experience", is the probe. If you worked in an agile delivery process, say how, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline defines it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quote is sessions that fed client evidence to product, and the words stay there. It is confirmed with limited inspectable proof, so volunteer the limit before it is extracted. Answer slot: the JD's line makes a probe on how the sessions were run likely. Say how they ran and who was in them, in your own words; if you cannot say, or they ran differently from what the probe assumes, say so plainly and stay with the sessions as quoted |
| F8 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | The material is silent, so the words are a slot. Answer slot: the JD's line makes a probe on what you have measured likely. If you defined or tracked any measure of how the integrations were taken up, say what was counted and how, in your own words; if you did not, say so plainly, and say what you would ask first: how adoption is measured today and what the baseline is |
| F9 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quote carries requirements and go-live on integrations, at its own scope. Answer slot: the JD's line makes a probe on what the requirements step produced likely. Say what that step consisted of and who it was for, in your own words; if it was not written for engineers, say so plainly and stay with the quoted requirements step |

## Persona table

Starting weights are the hiring-manager prior in this pack's persona model: Case/Strategist and Skeptic lead. Your note says one 45-minute conversation with the hiring manager, and nothing documents a loop beyond that, so there is no further round-type adjustment. No values-style round is detected (no loop source names one), so there is no Values bank. No interviewer profile exists, so there are no interviewer-signal adjustments.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet, persistent probing of the title and roadmap gap, then R2, R3 and R5 | High. Hiring-manager prior, raised because the dossier names the objection and the fit rows F1 and F2 are where it presses | Rehearse A1 until it is boring: limit named first, bridge at its own scope, ramp plan |
| Case/Strategist (bank B, 5 questions) | Live problems from the role: a breaking change, flat adoption, two squads, discovery, a spec | High. Hiring-manager prior; the JD's responsibilities are the case material. Banks are `[generic]` because research was refused | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Conversational (bank C, 3 questions) | The opener, then casual questions on a hot JD topic | Medium. A 45-minute conversation usually opens loosely; casual questions are still scored | A 90-second arc built from your three quotes; treat the casual technical question as scored |
| Data-Driven Prober (bank D, 3 questions) | The 30+ figure, the playbook, adoption | Medium. One headline figure in your evidence and a named adoption responsibility | Know what you can say about how the figure was counted, and say plainly where you do not know |
| Pressure (bank E, 2 questions) | Time-boxed version of A1; attribution probe on the sessions | Low to medium. Hiring managers can compress the objection into a challenge | Pause, restate, anchor in your quote, hold through two follow-ups, then concede one specific thing |
| Peer Evaluator (bank G, 2 questions) | The seam with the two squad leads; credit | Low. The manager is not a peer, but decision authority against the squad leads is the dossier's open question | Propose seam principles instead of pretending to know the seam |

## Question banks

Highest-ROI prep in this pack: **A1**. The dossier's underwriter named it as the likeliest objection to you, and it has the deepest rehearsal below.

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | Level 0, name the limit before it is extracted: you haven't held a product manager title or role, and you haven't owned a roadmap. Then the bridge, at its own scope and called adjacent: the integrations you led end to end, scoping through go-live, and the quarterly sessions that fed client evidence to product. Say what you did, then stop; let the interviewer draw the inference. Level 1, "who decided what went on the roadmap those sessions fed?": hold on the quote's words, sessions feeding client evidence to product, and add nothing about what product did with it. The sessions are confirmed with limited inspectable proof, so if asked what you can show, say plainly how much there is. Level 2, "so a PM with three years has done what you haven't": concede the true, specific part (the title and the roadmap were not yours, so someone with three years of the job has done what you haven't) and hold the core, which is the integration work as quoted. Level 3, "so how would you get up to speed?": a plan, never a past. Ask which decisions belong to the PM alone and which to the two squad leads, and how adoption is measured today, before proposing priorities. Never present any of this as product-management experience | Named by the dossier as the likeliest objection, and F1 and F2 are where it presses. JD because it scores the stated requirement; the deepest rehearsal because it will arrive in some form |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | Pick the part your material does not carry: roadmap ownership and prioritization authority. Say it plainly: you haven't owned a roadmap, and you haven't set prioritization for an engineering squad. Then the ramp plan, as a plan: in the first weeks you would learn which decisions belong to the PM alone and which to the two squad leads, and how adoption is measured today, before proposing priorities. No story about having done it, and no slot, because the dossier records this as a gap | F2 is the acknowledge_gap area, so the honest answer is the acknowledgment plus the ramp. JD because it scores the role's own list; Skeptic because it asks you to name the gap |
| A3 | "Why a move into product management now, and why this platform?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Give your actual reason, in your own words: one you can defend under a follow-up. Link it only to what your quotes carry, the client integration work and the sessions that fed product. Claim no motive you do not hold. If you have no settled reason yet, say so plainly, then give the nearest true thing | F1 is the gap a motivation probe tests. EXP because it tests whether your account of your own path stays consistent under questions |
| A4 | "Have you worked in an agile delivery process inside a product organization?" | JD | [grounded] | The requirement's own wording, "Agile delivery experience", is the probe. If you worked in an agile delivery process, say how, in your own words. If you never worked that way, say so plainly, and add what you would want to confirm about how Quartzline defines it. Nothing about your past goes in beyond what you say here | F6 is a discovery gap: the evidence may exist and the material does not show it. JD because the requirement is listed as preferred |
| A5 | "The role asks for shipped API or platform products. What have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Lead with the quotes at their own scope: the 30+ client integrations of the vendor's REST APIs, scoping through go-live, and the integration playbook your team uses. Answer slot: the JD's line makes a probe on what you took to go-live likely. Say which of scoping, requirements, architecture, UAT and go-live were yours to decide and how you decided, in your own words; if any were not, say so plainly and stay with the integrations | F3 is the must-have the evidence reaches only adjacently. JD because it scores a stated must-have |

### Bank B: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner tells you a breaking change to the API they depend on lands in two sprints, and their go-live is next month. What do you need to know first, and what do you do?" | CASE | [generic] | Clarify first: what changes, which endpoints, which other partners are affected, what the partner's date depends on, what was promised in the docs. Objective: protect the partner's launch without freezing the platform. Options: a longer deprecation window, a versioned endpoint, a compatibility layer, sequencing the change. Say who decides each option and what you do not yet know about decision rights. Metric: partners migrated and partners blocked. Risk: partners who have not heard yet. Challenge one premise, whether the two sprints are fixed. The question needs no claim about your past, so the guidance makes none | A live problem from the partner-facing API responsibility (F2's JD line). `[generic]` because it is a pattern for the problem, not a fact about Quartzline |
| B2 | "Adoption of a recently released endpoint is flat after two months. Diagnose it." | CASE | [generic] | Clarify first: how adoption is counted here, what the baseline is, over what window, and which partners were expected to adopt. Then segment: never started integrating, started and stalled, integrated with low volume. Hypotheses per segment (documentation, authentication, sandbox access, partner priorities, whether the endpoint fits the need) and how you would test each with partners. Close with what you would report and when. Asking how adoption is measured today is honest, not stalling: the dossier lists it as unresolved | F8's responsibility, asked as a diagnosis instead of a record. `[generic]` because it is a pattern |
| B3 | "Each of the two squads wants the next quarter for its own priority. How do you decide?" | CASE | [generic] | Answer as an approach, not a history. Ask what each priority is tied to, what evidence from partners exists for each, and what the cost of waiting is. Propose a decision principle before an answer, say who you would bring in, and say what you do not know about who has the final call here. Do not phrase any of it as something you have done | The dossier's open question on decision authority, turned into a live problem; F2. CASE because it tests reasoning under a seam you do not control |
| B4 | "How would you run discovery with integration partners in your first 60 days?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer as a plan: who you would talk to first and what you would ask; how what you hear reaches the squads as something they can build from; what you would have in hand by day 60. If you mention your past, the only sentence is the one you gave, at its scope: sessions that fed client evidence to product. It is confirmed with limited inspectable proof, so expect a probe on what you can show, and say plainly if little can be shown. Answer slot: the JD's line makes a probe on how those sessions ran likely. Say how they ran and who was in them, in your own words; if they ran differently from what the probe assumes, say so plainly and stay with the sessions as quoted | F7's responsibility, asked as a plan so that the guidance stays inside the quote. JD content, forward-looking delivery |
| B5 | "Write me the first paragraph of a spec for a webhook retry feature. What goes in it?" | CASE | [generic] | Say what the opening has to settle: the problem and which partners feel it, what is out of scope, how you will know it worked, and what is still open. Name who you would review it with before the squads see it. Keep it to the shape of the paragraph; the question needs no claim about your past, so the guidance makes none | F9's "write specs" line, asked as a live exercise so that no past is presupposed. `[generic]` because it is a pattern |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Three beats, each one clause the quote states, in your own words: the client integrations you led end to end, the playbook your team uses, the sessions that fed client evidence to product. Then one sentence on why this role, your own reason. Add no dates, employers, titles or outcomes the quotes do not carry. About 90 seconds | The open slot every loose conversation has, and the one place to land the adjacent frame yourself. F1, F3 and F7 are the rows it draws on; EXP because it tests a consistent account |
| C2 | "Anything you've been digging into lately around API docs or schemas?" | JD | [grounded] "Wrote the internal integration playbook her team uses" | Pick something you have really read or used lately and say what it taught you, in your own words; name no tool or practice you did not use. If nothing comes to mind, say so plainly, then give the nearest thing your material carries: the playbook your team uses, at that scope. Answer slot: if asked what the playbook covers, say what it covers; if it covers less than the question assumes, say so plainly | A casual question on a hot JD topic, and still scored. F4 is where it presses |
| C3 | "Tell me about a time a customer, a sales colleague or an engineer wanted something you couldn't give them." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pick a time with a named stake, what you actually said or did, and a relationship intact at the end. The nearest material your quotes carry is the client integrations you led, at that scope. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The open prompt for the stakeholder requirement (F5). EXP because it asks for an instance you must choose |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Thirty-plus client integrations. Walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Four slots a figure raises, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Keep the figure attached to client integrations of the vendor's REST APIs, and do not convert it into a count of anything else | The headline figure in the evidence is a magnet for a prober. F1 and F3 both rest on it |
| D2 | "Who uses the integration playbook, and what does it cover?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The quote carries two facts: you wrote it, and your team uses it. The dossier grades this high with an inspectable playbook, so you can offer to walk the interviewer through it. Answer slot: the JD's technical-fluency line makes a probe on what it contains likely. Say what it covers, in your own words; if it covers less than the probe expects, say so plainly and stay with the playbook as quoted | F3 and F4 both lean on this sentence, so it is the one most likely to be tested for scope |
| D3 | "Adoption is a named responsibility here. What have you tracked on adoption?" | JD | [grounded] | Answer slot: the JD's "Define and track adoption metrics" makes a probe on what you have measured likely. If you defined or tracked any measure of how the integrations were taken up, say what was counted and how, in your own words. If you did not, say so plainly, then say what you would ask first: how adoption is measured today and what the current baseline is. No quote carries a measure, so none is supplied | F8 is silence, which is a discovery gap and never a capability claim. JD because it scores a stated responsibility |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | One sentence of limit: you haven't held a product manager title or role. One sentence of bridge: the 30+ client integrations you led, scoping through go-live, as adjacent work. One sentence of ramp: what you would learn first. Then stop, and do not fill the silence. If interrupted with "so you can't do the job," hold on the integration work as quoted and concede only the specific part, the title | The time-boxed form of A1 (F1). JD because the content is the requirement; the Pressure delivery tests composure |
| E2 | "Those roadmap-input sessions — how much of that was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having owned a product roadmap" | Pause and restate the question, then anchor in the quote: you ran the sessions, and they fed client evidence to product. Hold that through two follow-ups. Concede one specific thing: you haven't owned a roadmap. Say plainly if little can be shown for the sessions, since the dossier confirms them with limited inspectable proof. Answer slot: if someone else ran any part of them, say which part and who | The attribution probe aimed at the pack's one medium-confidence quote (F1, F7) |

### Bank G: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where is the seam between this role and the two squad leads, and what happens when you disagree with one of them?" | CASE | [generic] | Propose seam principles, not a claimed seam: you do not yet know where this role's decision rights end, and the dossier lists that as unresolved. Say what you would want agreed early: who decides what, how partner evidence is brought to a disagreement, and who breaks a tie. Offer something in return, as a plan: specs the squads can build from and a regular readout of what partners are saying. Make no claim about past disagreements | The dossier's open question on authority, asked collegially (F2, F9) |
| G2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | "We" for context, "I" for contribution, and use the quotes' own verbs: led, wrote. Answer slot: if other people did parts of any of those integrations or of the playbook, say who and what was theirs; if no one else shared in them, say that plainly | Credit probes test whether your first-person claims are scoped (F1, F3) |

### Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1 "3+ years product management experience" | A1, A2, A3, E1, E2 |
| R2 "Shipped API or platform products" | A5, D1 |
| R3 "Technical fluency: API docs, schemas" | C2, D2 |
| R4 "Stakeholder management across engineering, sales, customers" | C3, G1, G2 |
| R5 "Agile delivery experience" | A4 |
| "Own the roadmap for the partner-facing API platform" | A1, A2, B3 |
| "Run discovery with integration partners" | B4 |
| "Write specs and drive delivery with two engineering squads" | B5, G1 |
| "Define and track adoption metrics" | B2, D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's open risk: authority is asserted in the JD and not evidenced. It reads as diligence, and you need the answer before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second open risk: adoption metrics are a named responsibility with no baseline stated. It shows you start from what is measured |
| 3 | "What does discovery with integration partners look like today, and who holds those relationships?" | The JD names discovery as a responsibility; the answer tells you what you inherit and who you work with |
| 4 | "How do the two squads plan and deliver their work today, and where does a PM's spec come in?" | It lets you confirm how Quartzline defines agile delivery (F6) instead of guessing |
| 5 | "What would you want this role to have changed, learned or delivered by day 60?" | It asks for the manager's own bar, and it gives you the ramp plan's target |

## Prohibited claims

Built from the dossier's prohibited_claims and, for the later entries, from the fit snapshot. The first three are sourced; the rest are inflated forms of sentences you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | prohibited_claims: "Having held a product manager title or role" | The plain acknowledgment: you haven't held a product manager title or role. Then the F1 quotes at their own scope, called adjacent |
| Owned a product roadmap | prohibited_claims: "Having owned a product roadmap", and the dossier's acknowledge_gap area | The plain acknowledgment: you haven't owned a roadmap. Then a ramp plan. The sessions quote appears only as F1's adjacent bridge, never as roadmap ownership. No slot |
| Set prioritization for an engineering squad | prohibited_claims: "Having set prioritization for an engineering squad" | The plain acknowledgment: you haven't set prioritization for an engineering squad. Then a ramp plan. No slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quotes at their own scope. The limit is the pack's observation: your material says client integrations and a playbook, not a product release of your own. A5's slot stays inside scoping through go-live |
| Wrote API documentation or schemas | Inflated form of F4 | F4's playbook quote at its own scope. C2's and D2's slots ask only what the playbook covers |
| Managed engineering, sales and customer stakeholders | Inflated form of F5 | F5's quotes at their own scope: clients and product. C3's slot asks only who else was involved |
| Ran discovery with integration partners | Inflated form of F7 | F7's quote at its own scope: sessions feeding client evidence to product. B4's slot asks only how the sessions ran |
| Wrote specs for engineering squads | Inflated form of F9 | F9's quote at its own scope: requirements and go-live on integrations. B5 is a live exercise and makes no claim about your past |

## Sources

Provided documents: tuesday-dossier.md, envelope version 1.1, dated 2026-08-14. It supplied role_profile (requirements and responsibilities as the JD's lines; its unknowns are used as analysis only), handoff_to_mock_interview (verified evidence, weak areas and their strategies, the objection, risks, employer questions, prohibited claims), and decision (context only). It carries no evidence_map, evidence_state or risk_register. Your message supplied the round: a 45-minute conversation with the hiring manager.

Searches sent, all refused by the host, and no result came back from any:

- `Quartzline company values`: refused
- `Quartzline interview process product manager`: refused
- `Quartzline API platform strategy news`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have fed VAL themes and a values-style check. No values page was read, so no company value is named in this pack |
| 2. `{company} interview process {role family}` | unavailable | Would have documented the round's format. Your own words fix one hiring-manager conversation, and the persona weights rest on the hiring-manager prior |
| 3. `{company} strategy` / recent news | unavailable | Would have grounded the CASE and CO banks in Quartzline's current priorities. Bank B is `[generic]` instead |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there is no query to form; the interviewer read is absent |
| 5. representative `{role title}` JD | skipped | The dossier's role_profile fixes the requirements and the JD-tagged questions |

## Upgrade menu

- Search access, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; offered once) → Quartzline's published values, the round's documented format and current strategy; bank B becomes company-specific, and the three unavailable rows in Sources are re-run
- The full JD text → the dossier's summarized requirements become verbatim JD quotes in F1 to F9 and in the question lines
- The hiring manager's name → an interviewer read, persona weights tuned to their public footprint, and a reverse question tied to their own path
- The recruiter's prep note (focus areas, any pre-declared deliverable) → coverage tuned to what is announced, and a build section for any deliverable
- Your answers to the slots in F3, F4, F5, F7, F8 and F9, in your own words → those rows become story-mapped and the matching questions lose their slots
- The session notes or written readouts from the roadmap-input sessions → F7's evidence moves from limited inspectable proof toward inspectable
