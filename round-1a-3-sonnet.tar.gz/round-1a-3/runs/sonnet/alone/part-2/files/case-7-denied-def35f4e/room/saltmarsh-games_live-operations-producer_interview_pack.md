# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Format: 60 minutes, Friday. Built as a hiring-manager round, which is an assumption: your note did not say how Tobias relates to the role.

## How to use this pack

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. Not used in this pack: no published values were in hand |
| EXP | Whether your background claims survive follow-up; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for you now. Either branch is a good answer if it is true: say what you did, or say plainly that you did not and return to what you did do.

The highest-ROI prep in this pack is B2, the in-app-purchase question. It is the gap you named yourself, and the JD does not answer it for you.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a content-drop calendar for the main title, not an events calendar and not two titles, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely. If you ran a calendar for any other title, say which and what you did, in your own words; if you did not, say so plainly and stay with the main title |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe on it. Lead in the quote's own terms: you ran the weekly content-drop calendar, for the main title, for two years, because a named cadence beats an adjective |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team" — your message | low | [inferred] | discovery | Your material shows the calendar and a stated absence of leading a team; it does not show which of the four disciplines the calendar involved. Answer slot: the JD names design, art, engineering and community, so expect a probe on which of them you worked with on a drop. If you coordinated with any, say which and how, in your own words; if some were not part of your calendar, or the coordination was not yours, say so plainly and stay with the calendar. When leading comes up, the words are yours: "I haven't led a team." |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers to the studio head, not that you ran post-event reviews or owned the KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event-review line makes a probe on reviewing single events likely, and a defend-the-number probe on the figures. If you produced or reviewed those numbers, say what part was yours and how they were counted; if the figures came from elsewhere and you presented them, say so plainly and stay with the presenting |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe on what is on it and how QA works with it. Lead with the quote: you wrote the release checklist, and QA still uses it. It says written and still used, nothing more, so add detail only in your own words |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | discovery | Your material shows four years as an associate producer and two of them on the calendar; it does not show whether the main title was a live-service game or what the other two years covered. Answer slot: the JD's years line makes a probe on which years were live-service likely. If the main title was live-service, say what made it so in your own words and for how long; if only part of the four years was, name that part; if none was, say so plainly and stay with the calendar you ran |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe on the numbers. Lead in the quote's own terms: you presented the monthly retention numbers to the studio head. The defend-the-number slots in C1 apply |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | The checklist is a written piece in use; your material does not show other writing. Answer slot: the JD's written-communication line makes a probe on what else you have written likely. If you wrote other documents that people relied on, say what they were and who used them, in your own words; if the checklist is the main one, say so plainly and stay with it: "I wrote the release checklist our QA team still uses." |
| F9 | In-app purchases (not in the JD; raised by your message) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past: what you would ask for, and from whom, in your first weeks. Nothing added to make the gap feel smaller |

## Persona table

Weights start from the hiring-manager relationship prior. No interviewer profile was available, so there are no interviewer-signal adjustments. No source establishes the loop, so the generic archetype applies and adds no tilt: these weights rest on a pattern, not on Saltmarsh's documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A, 5 questions) | Live problems from the role: two calendars, a release-day blocker, a post-event review | High. The hiring-manager prior puts it first, and the JD's duties (calendar, coordination, post-event review, release checklist) each convert into a live problem | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully per case |
| Skeptic (bank B, 4 questions) | Quiet probing of the gaps in F1, F3, F6 and F9 | High. The hiring-manager prior puts it first, and you named two gaps yourself (F3 leading a team, F9 in-app purchases) | Rehearse B2 until it is boring: the plain acknowledgment first, then only what the quotes carry, then a plan |
| Data-Driven Prober (bank C, 3 questions) | Defend-the-number questions on the retention numbers | Medium. The JD asks for comfort with retention metrics and your message says you presented them monthly (F7, F4) | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Conversational / Rapport Builder (bank D, 3 questions) | The opener, "walk me through the journey", and casual questions about the games and your writing | Medium. Most interviews open this way; the first minutes are still scored | A 90-second arc built only from your own sentences (D1) |
| Pressure (bank E, 2 questions) | Time-boxed "why you" and "how much of that was you" | Low to medium. It follows the gaps in F3 and F9 if the Skeptic round turns hard | Hold the core through two follow-ups; concede specific limits plainly |
| Peer Evaluator (bank F, 2 questions) | Seam-splitting and credit questions between teams | Low. It rises if Tobias turns out to be a peer, which your note does not say | Propose seam principles rather than pretending to know this team's seam |
| Values / Behavioral | Not weighted | No bank: no published values were in hand and no source names a values round | Upgrade menu says what would change this |

## Question banks

Requirement coverage:

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, A2, A5, B1 |
| Experience running a content calendar | B1, C2, D1 |
| Coordinate design, art, engineering and community on each update | A2, B3, F1 |
| Own the post-event review and the KPIs it reports | A3, C1, C2, C3, E2 |
| Manage the release checklist with QA | A4 |
| 3+ years producing live-service games or apps | B4, D1 |
| Comfortable with player-retention metrics | B2, C1, C3, E2 |
| Clear written communication | D3 |
| In-app purchases (raised by you, not the JD) | B2, E1 |

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Say you're handed the live-events calendar for two mobile titles you've never worked on. What do you need to know before you plan the next few weeks?" | CASE | [generic] | Structure it aloud: clarify, objective, approach, metrics, risks. Clarifiers to ask: what is already locked, who owns each team's dates, what each title's events are meant to achieve, and how the studio judges an event afterwards. State your hypothesis early, then say what would change it. The question needs no claim about your past, so the guidance makes none | The JD's two-titles line (F1) asked as a live problem. CASE because it scores structure; JD content, CASE delivery. Generic because it is a pattern for the problem, not a fact about Saltmarsh |
| A2 | "Two events are due in the same week, one per title, and engineering tells you only one can ship. How do you decide, and who do you talk to?" | CASE | [generic] | Ask what is at stake for each event and what can move. Ask who owns the final call. Lay out the options: move one, cut scope on one, or stagger them. Say who you would tell and when, community included, and what you would record about the decision and why. No claim about your past | The JD's four-team coordination line (F3) with its two-title scope (F1), as a decision rather than a record. Generic: a pattern for the problem |
| A3 | "Retention on one title dips the week after an event. How would you run the post-event review?" | CASE | [generic] | Clarify how the metric is defined and what you would compare it against. Separate the event from anything else that changed that week. Say what the report would state, who reads it and what would change before the next event. Name the assumption you would defend least before the interviewer does. No claim about your past | The JD's post-event-review line (F4) as a live problem. The weakest-assumption move belongs here because it is a metric question |
| A4 | "Four hours before an event goes live, QA raises a blocker. Walk me through the next hour." | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Structure it: what the blocker is and how severe; the options (delay, ship without the affected piece, or a fix); who needs to know now and what community can tell players; what gets recorded afterwards. If your checklist comes up, say only "I wrote the release checklist our QA team still uses". Answer slot: the JD's release-checklist line makes a probe on what the checklist covers likely. If asked, say what it covers in your own words; if a detail is not yours to give, say so plainly | The JD's QA line (F5) as a live problem, with the one quote you can bring in if it fits. CASE because the live problem is the test |
| A5 | "Suppose one title's players return daily and the other's return weekly. How would that change the events you plan?" | CASE | [generic] | Clarify what each event is for. Segment: cadence of events, length of an event, what the post-event review would look at for each. Say what would make you wrong. No claim about your past | The JD's two-title scope (F1) pushed on a differentiator. Generic: the daily and weekly split is invented for the problem and is not a fact about Saltmarsh's titles |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've run the calendar for your main title. This role runs two titles' calendars. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold only what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: if you ever ran a calendar for more than one title, say which and what you did, in your own words; if not, say so plainly and stay with the main title. Then say what you would settle first about the second title, as a plan: its cadence, who owns its dates, what each event is for. Hold through two follow-ups by returning to the calendar, never by adding to it | F1 is the evidence for the JD's headline duty and where scope is probed first. JD because it scores a stated requirement |
| B2 | "You haven't worked on a game with in-app purchases. How would you plan and judge live events without that?" | JD | [grounded] "never worked on a game with in-app purchases"; [grounded] "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. First sentence, before they press: "I haven't worked on a game with in-app purchases." Then only what the quotes carry: "I presented the monthly retention numbers to the studio head." Stop there on the past and let them draw the inference. Then the plan, said as a plan: in the first weeks, ask who in the studio owns that side and what they track, read how past events were judged, and ask what is off limits for events. Follow-up 1, "So you can't tell whether an event is worth running": hold, and say you cannot yet tell how events pay back here and how you would find out. Follow-up 2, "What would you get wrong in month one?": concede one specific limit, that you would not yet know how this title's players respond to its offers, and say what would shrink it. Follow-up 3, "Why take that risk over someone who has?": list what you did, the calendar, the checklist and the retention numbers, in the quotes' own terms, and stop | F9 is the gap you stated, the JD does not answer it, and the interviewer need only ask; F7 is the adjacent evidence and the limit on it. JD because it scores the job's gap. Deepest rehearsal: most follow-ups, the exact concession worded in advance, the limit named first |
| B3 | "You haven't led a team. This role coordinates design, art, engineering and community on every update. How do you get four disciplines moving on one date?" | JD | [grounded] "Never led a team"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Plain acknowledgment first: "I haven't led a team." Then the calendar at the quote's scope: "I ran the weekly content-drop calendar for our main title." Answer slot: the JD names the four teams, so expect a probe on which you worked with. If you coordinated with any on a drop, say which and how, in your own words; if the calendar did not involve some of them, or the coordination was not yours, say so plainly and stay with the calendar. Then, as a plan: with each discipline, agree up front who decides the date and what each needs from the others | F3 holds the stated negative and the open question beside it. JD because the JD's coordination line is what is scored; the negative is yours, so the acknowledgment is sourced |
| B4 | "The JD asks for 3+ years producing live-service games or apps. Which of your four years were live-service?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say the four years and the calendar at their own scope: four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for the main title. Answer slot: if the main title was live-service, say what made it so in your own words and for how long; if only part of the four years was, name that part; if none was, say so plainly and stay with the calendar. Do not round the four up to live-service | F6 is where the JD's years line meets your dates. EXP because it tests whether the dates survive a follow-up |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start with the quote: "I presented the monthly retention numbers to the studio head." Then the four slots, each in your own words: how a figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how a figure was counted, say so plainly. The pack supplies no method, baseline or figure | F4 and F7 share this quote. EXP because it is a defend-the-number probe on a headline claim; the weakest-assumption move is the rehearsal |
| C2 | "Tell me about a drop that didn't land the way the team expected." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a drop where what happened differed from what the team expected, so you can say what was expected, what you saw and what, if anything, changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title", or say how you would review one | An open prompt whose theme the JD's post-event-review line (F4) raises. No quote carries a story here, so it is a scaffold with its honest branch |
| C3 | "Which retention measures would you put on a post-event report, and which would you be careful with?" | JD | [generic] | Pick two or three. For each, say what it can tell you and what it cannot. Name the assumption you would defend least before they ask. Do not cite figures of your own; the question does not ask for them | The JD's KPI line (F4) with the weakest-assumption move built in. Generic: a pattern for the problem |

### D. Conversational / Rapport Builder (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you end up here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; [grounded] "Wrote the release checklist our QA team still uses"; [grounded] "Presented the monthly retention numbers to the studio head" | A 90-second arc, four beats in order, each in your own words at its scope: four years as an associate producer at a puzzle-game studio; the last two running the weekly content-drop calendar for the main title; writing the release checklist QA still uses; presenting the monthly retention numbers to the studio head. Answer slot for the why: say in your own words what draws you to live operations and to Saltmarsh; if you have no Saltmarsh-specific reason yet, say what draws you to the role as the JD describes it | F2, F5, F6 and F7 are the arc's four beats. EXP because it is your story in sequence; casual in register, still scored |
| D2 | "What do you know about our games, and what would you want to find out in your first month?" | CO | [generic] | Say only what you have actually played or read, and say plainly if that is little. Then the first-month list as a plan: which events ran, how they were judged, who owns each team's dates. The pack holds nothing on Saltmarsh's titles, so spend prep time on the games themselves and the studio's own pages | A CO question. The research that would have grounded it was refused, so it is generic and the table in Sources says what it would have moved |
| D3 | "Tell me about something you wrote that a team relied on." | JD | [grounded] "Wrote the release checklist our QA team still uses" | Story map on one sentence: "I wrote the release checklist our QA team still uses." Answer slot: if you know what it covers and how QA took it up, say so in your own words; if a detail is not yours to give, say so plainly. Add nothing the sentence does not say | An open prompt whose theme the JD's written-communication line raises (F8). JD because it scores a stated requirement, asked in a casual register |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run live events for two titles?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; [grounded] "Wrote the release checklist our QA team still uses"; [grounded] "Presented the monthly retention numbers to the studio head"; [grounded] "Never led a team"; [grounded] "never worked on a game with in-app purchases" | Pause and restate the question. Hold: the calendar, the checklist and the retention numbers, each at its quoted scope. Concede two limits before they ask, plainly: "I haven't led a team." and "I haven't worked on a game with in-app purchases." Do not fold on the three things you did; do not add a claim to win the minute | F1, F3, F5, F7 and F9 are what a time-boxed challenge lands on. EXP because it tests what was actually yours |
| E2 | "That retention work. How much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The quote's verb is presenting: "I presented the monthly retention numbers to the studio head." Answer slot: if you also produced or analysed the numbers, say which part; if others produced them or the figures came from elsewhere, say so plainly and stay with the presenting. Hold through two follow-ups; concede what you do not know about how they were counted, plainly | F4 and F7's attribution probe. EXP because it is the standard how-much-was-you question |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where's the seam between a producer and engineering on a release, and what happens when you disagree about the date?" | CASE | [generic] | Propose principles and do not pretend to know this team's seam: who decides when an estimate is challenged, what each side hears first, and what gets written down. Say you would ask how this team already draws the line. Say what you bring them: a clear calendar and early notice. No claim about your past | The JD's engineering coordination line (F3) in a collegial register. Generic: a pattern for the problem |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a drop or release where several teams contributed, so you can say what each did, how credit was named and where there was friction. If no such time comes to mind, say so plainly, then say how you would handle it | The peer stem: credit across teams. No quote carries a story, so it is a scaffold. EXP because it asks for past behavior |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which two titles would I be planning for, and what does a good first event cycle look like for each?" | Ties to the JD's two-title scope (F1) and shows you are already thinking in the job's terms |
| R2 | "How do design, art, engineering and community agree an update's date today, and where does that usually get stuck?" | Names all four teams from the JD (F3) and asks about the seam you would own |
| R3 | "How are post-event reviews used today: who reads them, and what has changed because of one?" | The JD gives the post-event review and its KPIs to this role (F4); the answer tells you what you would be accountable for |
| R4 | "I haven't worked on a game with in-app purchases. In my first month, what would you most want me to understand about how the team judges an event?" | Names your gap first, in your own words (F9), and turns it into a ramp question. Use it only if B2 has not already come up |
| R5 | "How does the release checklist work with QA today, and what would you want to change in my first quarter?" | Connects to the one line of yours with a named artifact (F5) and asks what success looks like there |
| R6 | "What would a strong first ninety days look like in this role?" | Generic by design: it hands you the interviewer's own scoring sheet for the role |

## Prohibited claims

Built from the fit snapshot before the banks were written. This pack found things it will not coach, which is why the list is not empty.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation: the material says the main title and content drops. B1's slot stays inside the main title |
| Led a team, or managed the teams on each update | Negative you stated, F3 | The plain acknowledgment: "I haven't led a team." B3's slot asks only which disciplines the calendar involved |
| Has worked on a game with in-app purchases | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Owned the post-event reviews or the KPIs | Inflated form of F4 | F4's quote at its own scope: "I presented the monthly retention numbers to the studio head." C1 and E2's slots ask only what part was yours |
| Four years producing live-service games | Inflated form of F6 | F6's quotes at their own scope: four years as an associate producer; two on the calendar. The limit is the pack's observation: the material does not show which years were live-service |

## Sources

Provided documents: the JD text and your background, both from your message. No dossier was consumed. No search returned results: all four calls were refused.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games mobile game studio values` | unavailable | Refused. It would have shown whether published values exist to theme VAL questions and a values cheat sheet. Nothing moved: no VAL questions, no cheat sheet |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Refused. It would have shown the loop's rounds and could have changed the persona weights. Weights rest on the hiring-manager prior and a generic pattern, said plainly above |
| 3. `Saltmarsh Games strategy news mobile titles` | unavailable | Refused. It would have grounded D2 and a strategy-based CASE question. D2 is generic |
| 4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` | unavailable | Refused. It would have given the interviewer read and a reverse question tied to Tobias's path. Both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

Search queries sent, in order: `Saltmarsh Games mobile game studio values` (refused); `Saltmarsh Games interview process live operations producer` (refused); `Saltmarsh Games strategy news mobile titles` (refused); `Tobias Wrenfield Saltmarsh Games Head of Live Operations` (refused).

## Upgrade menu

- How Tobias relates to the role (future manager, peer, or senior to it) and anything the recruiter said about format or focus → persona weights recomputed; a peer round adds a reciprocity reverse question
- Permission to run web search, or pasted pages from Saltmarsh's own site → the four refused targets run: values, loop structure, strategy and Tobias's public professional footprint, and with them an interviewer read, CO questions grounded in the company, and a reverse question tied to Tobias's path. A deeper pass of up to 6 more searches and 2 more fetches is optional after that
- Your own words on the answer slots: whether the main title was live-service (F6), which disciplines the calendar involved (F3), whether you produced or only presented the retention numbers (F4), and what else you have written (F8) → those rows move from discovery toward grounded, with stories in place of slots
- Any recruiter-announced deliverable, such as a presentation or take-home → a build section for it
- Prep time available → a prioritized schedule sized to it
- A `tuesday-dossier.md` from an earlier job-underwriter run, if you have one → the top objection derived from evidence rather than my inference, and per-gap strategy limits; not needed for anything above
