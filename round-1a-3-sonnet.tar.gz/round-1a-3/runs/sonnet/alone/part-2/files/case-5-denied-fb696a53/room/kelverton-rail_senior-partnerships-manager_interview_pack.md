# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday. A 60-minute panel with Deepa (VP Partnerships, your future manager) and Ross (Commercial Director), as the recruiter's email describes it. The first 15 minutes are your POV on "where you'd take our operator partnerships over the next 18 months", no slides, landing on what it means for the operators themselves. The rest is Q&A, and "Ross will push on commercials."

**Built on:** your message and the recruiter's email as you quoted it. No posting text was supplied, no web research ran, and the market report's text was not available to me, so it is used only as something you have read.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its strategy and can think at its altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

## Prep triage (about four hours, over the weekend)

1. **90 minutes: build and say aloud the POV** (section 5). Pick one thesis, its concession and your anti-pick. Say it aloud three times against a timer.
2. **60 minutes: B1, then C1 and C2, aloud.** B1 is the highest-ROI prep in this pack: the most predictable objection to you, and the one where the material is thinnest. C1 and C2 are where Ross will press.
3. **30 minutes: A1, A2 and A4.** These are the follow-ups to your POV. For A4, re-read the market report first.
4. **30 minutes: D1 and D2 with someone interrupting you.** Then choose three reverse questions from section 11.
5. **30 minutes: one full run-through.** 12 minutes of POV, then B1 and C1 cold.

Everything else is insurance.

## Fit snapshot

No posting text was supplied, so requirements come from the recruiter's own words, quoted, and from role-family expectations written as plain prose and marked generic. Nothing in your inputs identifies a gate, a term such as location, travel or vetting, so no row is a hard gate; the posting text would settle that.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Senior Partnerships Manager" — role title, your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | none | No gap on the title, but a self-reported line with nothing inspected behind it, so expect the figure probed (C1, C2). Lead with the channel in the quote's own terms: you ran the ISV channel for the last four of your nine years in partnerships |
| F2 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email, as you quoted it | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" — your message | medium | [grounded] | transferability | The quote carries an ISV channel at a payments company, not operator partnerships, and the words stay at that scope: "For the last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Answer slot: the POV is about operators, so expect a probe on what carries over from a channel of ISVs. Say which parts carry over, in your own words; if you think few do, say so plainly and stay with the channel you ran |
| F3 | "Please land on what it means for the operators themselves." — recruiter's email, as you quoted it | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The quote carries bus and light rail network planning, which sits next to train operating companies and does not reach them. The words stay at that scope: "Before that I spent five years in transport consulting, in bus and light rail network planning." Answer slot: the recruiter asks you to land on the operators, so expect a probe on how close that work was to operators. If any of it was done with an operator's own people, say what it was and which part was yours; if none was, or you are not sure, say so plainly and stay with the network planning |
| F4 | "Ross will push on commercials" — recruiter's email, as you quoted it | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | The figure is stated; how it was counted is not shown. Words at its scope: "I took it from 6 partners to 40, roughly £4M of influenced revenue." Answer slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Where you do not know how it was counted, say so plainly |
| F5 | Carrying a revenue number for partner-sourced business — generic role-family expectation, not from your inputs | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota, only influenced revenue." Then how you would handle a number in this role, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Experience selling into rail operators — generic role-family expectation, from "they sell scheduling software to train operating companies" in your message | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then how you would learn the sector, said as a plan and never as a past |

## Graded deliverable: the 15-minute POV

The recruiter announced this, so it is graded. Build it as a spoken argument, not a tour of the market. Nothing below is a fact about Kelverton or the rail market: the theses are hypotheses to test against the report you have read, and you should say so aloud.

**Facts you can stand on** (each is a fit-snapshot row's own evidence, at its own scope):
- F2: "last 4 at a payments company running the ISV channel — took it from 6 partners to 40"
- F3: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F4: "took it from 6 partners to 40, roughly £4M of influenced revenue"

**Shape (aim for 10 to 12 minutes, leaving room before the 15 are up)**
1. One sentence on your stance: partnerships here exist to change something for operators, so you will end there.
2. One item from the market report, in its own terms, to show you read it.
3. Your thesis, where it departs from the report's consensus, and why.
4. Your concession and your anti-pick.
5. What it means for the operators themselves, in a sentence you could say to an operator.
6. What you would check in the first 90 days to find out whether you are wrong.

**Differentiation.** The report was circulated inside Kelverton and sent to every candidate, so reciting its shortlist scores as homework. Bring one consensus item to prove grounding, then one thesis-driven divergence, then the anti-pick.

**Three theses to choose from (all generic until tested against the report). Pick the one you can defend for ten minutes of questions.**

| Thesis | Concession you must make | Closest to what your material carries |
|---|---|---|
| T1. Fewer, deeper operator partnerships, each tied to a result the operator itself can state | Slower headline growth. Expect the contrast with "took it from 6 partners to 40"; say in your own words why this job differs, or concede that it may not | F2, as the contrast |
| T2. Build partners around the operators, so that what operators get from Kelverton's software is worth more to them | It needs the product to be ready for it and adds support load; you cannot verify either from outside, so name it as the first thing you would check | F2, the channel you ran |
| T3. Joint operator proof first: evidence of an operator outcome, used to open the next conversation | It depends on operators sharing data and on time, and 18 months is short for evidence | F4, if you can say how the figure was counted |

**Anti-pick (choose your own, with a reason).** An option: no broad partner programme until two or three operator partnerships show a result. The point of the anti-pick is to show you will say no.

**The close.** The recruiter asked you to land on the operators themselves. Answer slot: say what changes for an operator, in the report's words or in words operators have used to you, if you have heard any; if you have not, say what you would ask them first. Claim nothing about what operators want that you have not heard.

## Persona table

The recruiter's email establishes one 60-minute session with a 15-minute POV, then Q&A, and names no values round. Which panelist asks what in the Q&A is not stated, so the split below is a judgment.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (Deepa, assumed) | Follow-ups on your POV: what would make it wrong, what you would do first, what you would say no to | High. A future manager buys capability and derisks gaps, and the first 15 minutes hand them a thesis to probe | Clarify, state objective, structure, approach, risks; name the weakest premise of your own thesis before they do (A1 to A5) |
| Skeptic (Deepa, assumed) | Quiet, persistent probing of the gaps in F5 and F6 and of the distance from payments and bus and light rail to operators | High. You stated both gaps yourself, so they are the first thing a careful panel will test | Rehearse B1 until it is boring: plain acknowledgment, then only what your quotes carry, then a plan (B1 to B5) |
| Data-Driven Prober (Ross) | Asks for the denominator behind the £4M and for the difference between influenced and closed | High. "Ross will push on commercials" and the only figure on your CV is a revenue figure | Say how the figure was counted, or say plainly that you do not know; name the assumption you would defend least (C1 to C4) |
| Pressure (Ross) | Interrupts the POV, asks what it costs, asks why you and not someone who has sold into rail | Medium. A commercial director pushing is plausible, but the email says "push", not "interrupt" | Pause, restate, hold the core claim through two follow-ups, concede specifically (D1 to D3) |
| Conversational / Rapport | The "walk me through the journey" opener | Low to medium. It is likely to open the Q&A, and it is still scored | A 90-second arc built from your quotes (E1, E2) |

## Question banks

Total: 19 questions. Quotes in the Provenance column are exactly as they appear in the fit snapshot.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've told us where you'd take operator partnerships. What would you need to learn in your first 90 days to know whether you're right?" | CASE | [grounded] | Structure it aloud: the claim you are least sure of, who you would ask, what evidence would change your mind, and what you would do differently if it did. This asks for a plan, so the guidance makes no claim about your past | The recruiter's POV brief makes this follow-up likely. CASE because it scores reasoning on the role's own problem |
| A2 | "What would have to be true about operators for your thesis to be wrong?" | CASE | [generic] | Name the premise you would defend least, in your own words, before they do, and say what you could observe that would tell you. Hold the thesis; concede the premise | The weakest-assumption move applied to your own POV. CASE because it tests reasoning, not recall |
| A3 | "Suppose you inherit an operator partnership that has gone quiet. How do you decide what to do first?" | CASE | [generic] | Clarify first: what the partnership was for, what each side expected, what quiet means here. Then objective, options, one metric, and what it means for the operator. Think aloud; challenge one premise respectfully | A live problem from the role, which asks nothing about your past and presupposes nothing about it |
| A4 | "You've read our strategy team's market report. What did you take from it, and where do you disagree?" | CO | [grounded] | Bring one point from the report in its own terms, then one place your view departs and why. If you do not disagree with any of it, say so plainly and name the part you would test first. Do not recite its shortlist | The report is in every candidate's hands, so the score is in the divergence. CO because it tests homework depth. This pack has not read the report |
| A5 | "Where would you say no in your first 18 months?" | JD | [generic] | Name your anti-pick from section 5 and give the reason in one sentence. Concede what saying no costs. A partnerships role that never declines anything has no strategy | Section 5 builds the anti-pick; this is where it is asked. JD because it scores judgment in the role |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail, and you haven't carried a direct quota. Why should we trust you with operator partnerships here?" | JD | [grounded] "Never sold into rail specifically" "never carried a direct quota, only influenced revenue" | **Highest-ROI prep in this pack.** Level 1, the plain acknowledgment: "I haven't sold into rail specifically, and I've never carried a direct quota, only influenced revenue." Level 2, only what your material carries, at its own scope: the channel you ran and the consulting you did, in the words of F2 and F3. Level 3, a plan, never a past: how you would learn the sector and how you would handle a number here. Follow-up 1 ("influenced isn't closed"): concede it in those words, then answer the C2 slot. Follow-up 2 ("what happens if Ross asks you to carry a number in month three?"): give your actual view, in your own words. Hold the core, concede the gaps, never add to what you did | F5 and F6 are gaps you stated yourself, so this objection arrives in some form. The deepest rehearsal is aimed at where the material is thinnest. JD because it scores the stated fit |
| B2 | "How much of the move from 6 partners to 40 was actually you?" | EXP | [grounded] "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | Say it in the quote's own terms: you ran the channel and took it from 6 partners to 40. Answer slot: the question asks about attribution, so expect follow-ups on who else did what. If others did part of it, say which part was theirs; if all of it was yours, say so plainly; if you do not know how it split, say that | F2's headline figure is a magnet for attribution probes. EXP because it tests what was actually yours |
| B3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | Name the rail gap in your own words as you stated it, then say how you would learn it, as a plan. Do not claim to be weak at nothing, and do not offer a gap you did not name yourself | F6 is the gap you named. JD because it scores honest self-assessment against the role |
| B4 | "Your planning background is bus and light rail. What from that carries over to train operating companies?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Keep the quote at its scope: five years in transport consulting, in bus and light rail network planning. Answer slot: say which parts carry over to train operating companies, in your own words; if you think few do, say so plainly and stay with the network planning. Do not claim knowledge of how train operators schedule or plan | F3 is adjacent and does not reach operators; this is the likeliest probe on it. EXP because it tests what the background supports |
| B5 | "Why partnerships at a scheduling-software company, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | Give your actual reason, in your own words; your material does not state one, so none is supplied here. Pick a reason that points toward this role and what it does, not away from your current one. If the reason is mixed, say so plainly | The reason for the move is a standard motivation-consistency check, and F1 is the continuity it sits against. EXP because it tests your own account of your path |

### C. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the £4M. How was it counted?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | State the figure at its own scope, "roughly £4M of influenced revenue". Answer slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Say whether it is a total or a yearly figure. If you do not know how it was counted, say so plainly | F4 is the commercial probe Ross is described as making. EXP because it tests the defensibility of a headline number |
| C2 | "What's the difference between influenced and closed revenue in your numbers?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" "took it from 6 partners to 40, roughly £4M of influenced revenue" | Level 1, the plain acknowledgment: "I've never carried a direct quota, only influenced revenue." Answer slot: what "influenced" meant in your reporting, in your own words; if the term was applied loosely, or you do not know the formal definition, say so plainly | F5 and F4 meet here. EXP because it tests whether you know your own number |
| C3 | "How would you put a number on what an operator partnership is worth to Kelverton in year one?" | CASE | [generic] | Structure it: what the partnership changes for the operator, what Kelverton gets, which of those you would count and which you would not, and the assumption you would defend least. Ask what the commercial team already tracks before proposing a measure. Name no figure | A live commercial problem for a commercial director. CASE because it scores structure, with no past claimed |
| C4 | "You haven't carried a direct quota. How would you expect to be measured here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Plain acknowledgment first: "I've never carried a direct quota, only influenced revenue." Then either give your actual view of how you would want to be measured, or ask first how the role is measured here. No figure, range or flexibility is supplied | F5 is the stated gap. JD because it scores the role's terms |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has sold into rail?" | JD | [grounded] "Never sold into rail specifically" "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause and restate the question. Hold only what the quotes carry, at their scope: the channel you ran, taken from 6 partners to 40, and the five years in transport consulting. Concede the rail point plainly. Hold through two follow-ups; do not claim you would out-learn them | F6, F2 and F3 together. JD with Pressure delivery: it scores composure |
| D2 | "I'll stop you there. What does that cost us, and when does it pay back?" | CASE | [generic] | Say what you would need to know to put a number on it, name the payback logic, and concede that you cannot give a figure from outside. Do not invent one. Then return to the thesis | A POV interruption tests whether you collapse or hold. CASE because it is a live reasoning problem |
| D3 | "That sounds like more work for less commercial return. Convince me otherwise." | JD | [generic] | Restate, hold the mechanism of your thesis, and concede specifically what you cannot yet show. Do not fold on the core claim to restore harmony | A devil's-advocate challenge to a thesis, scored on holding then conceding |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey from transport consulting to partnerships." | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue" | A 90-second arc in this order: five years in transport consulting, in bus and light rail network planning; then nine years in partnerships, the last four running the ISV channel at a payments company. Answer slot: why the moves happened, in your own words; if there was no single reason, say so plainly | F3 and F1 form the arc. EXP because it tests whether the path is coherent. A casual opener is still scored |
| E2 | "What drew you to Kelverton in particular?" | CO | [grounded] "they sell scheduling software to train operating companies" | Give your own reason, in your own words, tied to what Kelverton sells: scheduling software to train operating companies. Claim nothing about Kelverton beyond that unless it comes from the report you have read | The sector fact comes from your message. CO because it tests genuine interest |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| F1 Senior Partnerships Manager | B2, B5, E1 |
| F2 Where you'd take operator partnerships in 18 months | A1, A2, A3, A4, A5, D3 |
| F3 Land on what it means for the operators | B4, E1, A3 (POV close, section 5) |
| F4 Commercials | C1, C2, C3, D2 |
| F5 Carrying a revenue number | B1, C2, C4 |
| F6 Selling into rail operators | B1, B3, D1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which operator partnership today would you point to as the one working best, and what makes it work?" | It gives you something concrete to test your POV against, and it shows your thesis rests on evidence |
| 2 | "How is partnership performance measured here today, and which of those measures would sit against this role?" | It settles the F5 question from their side, without you having to volunteer a position first |
| 3 | "What has changed since the market report was circulated, or what would you now say differently?" | It shows you read it, and it goes beyond reciting it |
| 4 | "When an operator relationship is in a live commercial conversation, how do partnerships and the commercial side split ownership?" | It speaks to both panelists and to the seam Ross is likely to care about |
| 5 | "What are operators asking Kelverton for that it cannot yet give them?" | It ties back to the recruiter's request to land on what it means for the operators |
| 6 | "What would you want to be true about this role after the first 90 days?" | It gives you a measure you can plan against, whatever the answer |
| 7 | "What happens after this round?" | A process question that lets you plan the next week |

## Prohibited claims

Built locally from the fit snapshot. These are claims this pack will not coach, because the material either contradicts them or says less than they do.

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota or owned a revenue number | Negative you stated, F5 | The plain acknowledgment: "I've never carried a direct quota, only influenced revenue." No slot |
| Has rail sales experience | Negative you stated, F6 | The plain acknowledgment: "I haven't sold into rail specifically." No slot |
| Closed, sourced or generated £4M | Inflated form of F4 | F4's quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation: your material says influenced revenue, not closed or sourced revenue |
| Built or launched the ISV channel from scratch | Inflated form of F2 | F2's quote at its own scope: you ran it and took it from 6 partners to 40. The limit is the pack's observation: the material says you ran it, not that you started it |
| Understands how train operators plan or schedule | Inflated form of F3 | F3's quote at its own scope: bus and light rail network planning. The limit is the pack's observation: the material says bus and light rail, not train operating companies |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report was attached to that email, but its text was not available to me in this conversation, so it was not read and nothing in this pack is drawn from it.

Searches sent (all refused, none returned anything):
- "Kelverton Rail company values" — refused
- "Kelverton Rail interview process partnerships manager" — refused
- "Kelverton Rail strategy news train operating companies scheduling software" — refused
- "Deepa VP Partnerships Kelverton Rail" — refused
- "Senior Partnerships Manager rail technology train operating companies job description" — refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | A values cheat sheet, section 10, if a values round were documented. Nothing in your inputs names one, so no values bank was written |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Loop structure. The recruiter's email already fixes this session's shape, so persona weights rest on that email and not on a documented loop |
| 3. `Kelverton Rail strategy` / recent news | unavailable | The CO bank and a grounding brief. The market report would answer this target, but its text is not in hand, so it could not be skipped |
| 4. `Deepa Kelverton Rail` | unavailable | An interviewer read and a reverse question tied to a career path. Absent from this pack |
| 5. representative `Senior Partnerships Manager` JD | unavailable | The requirement rows, which would have been quoted from a posting; they rest on the recruiter's words and generic expectations instead |

## Upgrade menu

- The posting text for this role → F5 and F6 stop being generic expectations and become quoted requirements; the coverage table becomes complete; it also shows whether any term, such as location, travel or vetting, is a gate
- The market report's text, or its key sections → A4 and the POV's consensus item become grounded, and the differentiation in section 5 becomes specific
- Search access, or a deeper pass of up to 6 more searches and 2 more fetches, several more minutes → values, interview-process and strategy research, a grounding brief, and a representative posting
- Deepa's and Ross's full names or profile links → an interviewer read, persona weights tuned to them, and a reverse question tied to each of their paths
- Your own answers to the answer slots in F2 to F4, in your own words (what carried over from the ISV channel, how close your consulting was to operators, how the £4M was counted) → those rows are regenerated and move toward high where something inspectable stands behind them
- A partner revenue report or programme scorecard behind the £4M → F1 and F4 can move from medium toward high
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and a named objection to rehearse; not needed to use this pack
