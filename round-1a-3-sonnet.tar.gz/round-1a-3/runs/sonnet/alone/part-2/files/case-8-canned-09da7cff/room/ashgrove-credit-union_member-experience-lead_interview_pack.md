# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds on 29 November 2026 (the recruiter's email names all three). **Built:** 20 November 2026.

| Round | Who (relationship) | Length | What the recruiter's email says it holds |
|---|---|---|---|
| 1 | The recruiter | 30 min | The process email gives no focus for it |
| 2 | Head of Member Services (your future manager) | 45 min | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | A 20-minute case on a complaint escalation; the panel is also the values round, scored against the four values |

Interviewer names are not assigned yet, so there are no interviewer reads in this pack.

## How to use this pack

- **Personas describe how a question is asked; types describe what is scored.** Every question carries one of five type tags:
  - **VAL** — does your past behaviour show Ashgrove's published values.
  - **EXP** — do the claims in your background survive follow-up questions, and what was actually yours.
  - **JD** — can you do the listed job, gaps included.
  - **CO** — do you understand Ashgrove's strategy well enough to think at its level.
  - **CASE** — structure and reasoning on a live problem.
- Question IDs run by persona (A1, A2, B1 and so on) so a drill can name them.
- **Guidance is scaffolding, not a script.** Where a cell says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly it was not yours. Both are good answers.
- Quoted sentences in the evidence and Provenance cells are your own words from your message. Rehearse those, at that scope, and nothing larger.

## Prep triage (nine days, 20 to 29 November)

| Order | Do this | Sections |
|---|---|---|
| 1 | Say D1 aloud until it is boring: the contact-centre question, the highest-ROI prep in this pack | D1, B1 |
| 2 | Rehearse the presenting answer the same way: plain acknowledgment, then the plan | D2, B2 |
| 3 | Time the escalation case at 20 minutes, out loud, twice | G1, G2 |
| 4 | Decide which story you will tell for each of the four values, or whether the honest answer is "no such time" | F1 to F4 |
| 5 | Write your own one-line answers to pay, notice, location and reason for leaving, in your own words | A3 to A6 |

Everything else is insurance.

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, and nothing inspected sits behind it. The words stay there: "I handled the branch's formal complaints log." Answer slot: "end to end" makes a probe on what happened to a complaint beyond the log likely. If any step beyond the log was yours, say which and what you did, in your own words; if the log was the part you held, or the later steps were not yours, say so plainly and stay with the log |
| F2 | "the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your sentence says you built it, that it is monthly, and that your regional manager uses it. It does not show what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet counted. If it counted either, say which and how it was counted; if it counted something else, or you do not know how a figure was counted, say so plainly and stay with your sentence |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and training, not supervisors and coaching. Words at that scope: "I trained new tellers on our escalation script." Answer slot: if any of that training reached supervisors, or you have coached anyone through an escalation, say who and what; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not establish this either way. Answer slot: if you have worked with a digital team, say what and which part was yours; if not, say so plainly, then say how you would start, as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Say it in your sentence's own terms: six years in retail banking, the last three as a branch supervisor. The JD says customer operations and your sentence says retail banking; use your own term and let the interviewer connect them |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your sentence says formal complaints; it does not show which rules applied to them. Words at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's "regulated" makes a probe on the rules or timescales likely. If you knew which applied, say so in your own words; if you did not, or none were set out for you, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have stated this one. Words: "I haven't presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says spreadsheet and does not name the tool. Answer slot: if it was Excel, say so and what it did; if it was another tool, say so plainly and stay with your sentence |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches | A1, C1, F4, G1 |
| The contact centre | B1, D1 |
| Report monthly on volumes and resolution times | C3, E1 |
| Coach branch supervisors on escalations | C2, G2, H1, H2 |
| Work with digital teams on self-service journeys | C4, H3 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | E2 |
| Confident presenting to senior leaders | B2, D2, C3 |
| Comfortable with Excel reporting | E1 |
| Ashgrove's strategy (not a JD line) | A2, G3, H3 |

## Grounding brief: Ashgrove's July 2026 strategy

You gave me four points from the brief. This table holds those four and nothing else.

| Fact from the brief | Provenance | Reading for this loop | Reading provenance |
|---|---|---|---|
| "move 40% of member service to digital channels by 2028" | [grounded] | Ties to the JD's self-service line; expect it in H3 and in the manager's round | [inferred] |
| "consolidate eight branches into five hubs over 2027" | [grounded] | Sits against "Neighbours, Not Numbers"; a branch-manager panel may raise it | [inferred] |
| "launch a small-business lending product in Q1 2027" | [grounded] | A new product line may bring a new kind of member complaint; a talking point, not a question I expect | [inferred] |
| "the main competitive pressure is app-only banks" | [grounded] | Frames why resolution speed and clarity matter to retention | [inferred] |

The panel and the manager will have read this brief. Bring one point to show you have read it, then one thought of your own about what it does to complaints. Do not recite all four.

---

# ROUND 1: Recruiter, 30 minutes

## Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly walk-through, logistics, why us | High. A recruiter screen's prior is conversational plus logistics (pay, notice, location, reason for leaving), and the recruiter's own email gives no other focus | Pre-script the 90-second arc; treat casual questions as scored |
| B. Skeptic (light) | Knock-out checks in a friendly register | Medium-low. Your two stated gaps (F2, F8) are the likeliest knock-out checks, but a screen usually checks and moves on | Say each gap plainly once, with its plan, and move on |

## Question bank

### A. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc using only the beats those sentences state: the six years, the last three as a supervisor, the log, the tellers' script, the monthly sheet. Answer slot: why you are moving toward owning complaints is not in your material; say in your own words what draws you, and if no one moment comes to mind, say what you want the next job to hold | The opener every recruiter asks and the one most likely to ramble. F1, F4 and F6 supply the beats; EXP because it tests what is actually yours |
| A2 | "What do you know about Ashgrove, and why us?" | CO | [grounded] | Bring one point from the brief, then your own thought on what it does to complaints; do not recite the list. Answer slot: why Ashgrove, in your own words; nothing is written for you here | The recruiter sent you the brief, so recital scores as homework. CO because it tests whether you can think at their level |
| A3 | "What's prompting you to look at a move?" | EXP | [generic] | Logistics slot: give your actual reason in your own words, in a sentence or two. No reason appears in your material, so none is written here | The reason-for-leaving check every screen makes; EXP because it tests consistency with the story in A1 |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | A logistics check; JD because it concerns the listed job's terms |
| A5 | "What are you looking for, salary-wise?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first. If asked for your current pay, prepare a polite redirect to the role's band. No figure is written here | Pay is asked at the screen to rule people in or out; JD because it concerns the job's terms |
| A6 | "Where are you based, and how would you feel about moving between sites?" | JD | [grounded] | Logistics slot: give where you are based and any limit on travel, in your own words. The JD says "across branches and the contact centre", so expect the question to be about moving between them | Location is a screening item, and the JD's "across branches" raises travel. F1 carries the requirement |

### B. Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as the branches. Have you worked in one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Short version of D1: the plain acknowledgment, "I haven't worked in a contact centre", then stop; if the recruiter wants more, give the plan from D1. Do not offer a bridge you have not been asked for | F2 is the stated gap and the likeliest knock-out; JD because the contact centre is in the first line of the JD |
| B2 | "The role presents to senior leaders. How comfortable are you at that level?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then your plan for it, said as a plan (full version in D2) | F8 is the other stated gap; JD because it is a stated requirement |

## Reverse questions for Round 1

| Question | Why it lands |
|---|---|
| "Is the case in the panel round shared in advance, and is there anything I can read first?" | It is an un-researchable fact that decides how you prepare G1 |
| "How do the panel score against the four values: each separately, or as a whole?" | It shows you take the values round as a scored round |
| "How much of the week does the role spend across branches and the contact centre, and where would I be based?" | It ties to the JD's own wording and settles A6 |
| "What happens after the panel: who decides, and when do I hear?" | A plain process question that closes the loop |

---

# ROUND 2: Head of Member Services (your future manager), 45 minutes

## Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| C. Behavioural / Values | "Tell me about a time" scenarios | High. The recruiter's email says "mostly behavioural" | Story from a quoted sentence where one carries it; otherwise say so plainly |
| D. Skeptic | Probing the gap between your background and the JD | High. A hiring manager's prior is to derisk gaps, and your two stated gaps (F2, F8) are the obvious ones | Rehearse D1 until it is boring |
| E. Data-driven prober | The spreadsheet, the log, what counted | Medium. Reporting is a headline duty and you built the sheet | Know what you can and cannot say about how it was counted |
| Case | A live problem | Low here. A manager's prior includes cases, but the only case the recruiter documents is in Round 3 | Covered in Round 3 |

## Question bank

### C. Behavioural / Values

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time a complaint needed escalating." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on the log and the escalation script at the scope the sentence states. Answer slot: the JD asks about escalations, so expect a probe on one specific case; choose one from your own work and say which part was yours. If no escalation went through you, or you only held the log, say so plainly and stay with the log and the tellers you trained | F1 and F4 are the nearest evidence for the escalation duty; EXP because it tests what was actually yours |
| C2 | "Tell me about a time you trained or coached someone through something difficult." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The sentence states new tellers and the escalation script; those are the beats. Answer slot: expect a probe on what you did when someone struggled. If there was such a time, say what you did; if not, or it was not yours, say so plainly and stay with the training you gave | JD's coaching duty makes this likely; F4 is the evidence and the limit is its scope. VAL because the manager scores how you treat others |
| C3 | "Tell me about a time you had to give senior people news they did not want." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The sentence carries a monthly report your regional manager uses; it does not say what the figures told them. Answer slot: if any month's figures carried news the regional manager did not want, say what you did; if you only compiled the sheet, or no such month comes to mind, say so plainly and name the nearest thing your material does carry | A persona stem aimed at the reporting duty. F3 is the evidence; VAL because it scores the hard truth landing |
| C4 | "Tell me about a time you worked with a team outside your own branch." | JD | [grounded] | Selection scaffold: pick a time with a named stake, a moment you had to agree something with people outside your branch, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would start with a digital team | F5 has no evidence either way; JD because it tests the digital-teams duty |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see contact-centre experience in your background. How would you handle the contact-centre half of this role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **Highest-ROI prep in this pack.** Hold, then concede. Open with the plain acknowledgment: "I haven't worked in a contact centre." Then your own words at their scope: "I handled the branch's formal complaints log." That is the branch side; say so. Follow-up 1 (does branch experience transfer?): do not claim it does; say what you would need to see first. Follow-up 2 (what do you do first?): a plan, said as future: ask to sit in on how complaints are handled there and read their records before changing anything. Follow-up 3 (will you be credible with contact-centre staff?): concede specifically that you would not be on day one on their side of the work, and hold that you will not bluff it. Name the limit before they ask: your material is the branch side | F2 is the stated gap and half of the JD's first line, so this question arrives in some form. JD because it scores the stated requirement; the guidance stays inside F2 and F1's scope |
| D2 | "I don't see presenting above regional level in your background. This role reports to senior leaders. Why should I be confident?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Hold, then concede. Plain acknowledgment: "I haven't presented to anyone above regional level." Then the sentence at its scope: you built the monthly sheet your regional manager uses. Do not say you presented it. Plan, said as future: ask what the senior forum looks like and what they want to see, then rehearse the monthly read-out before the first one. Concede specifically that the room is new; hold that you will prepare for it | F8 is the second stated gap; JD because it is a stated requirement. F3 gives the one adjacent sentence and the guidance stays inside it |
| D3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose from your own material, and say it plainly with its plan. F2 and F8 are the two you have stated; picking a made-up weakness is the weaker answer | A standard Skeptic stem. It tests honest self-assessment, and F2 and F8 are the candid answer |

### E. Data-driven prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built. What did it show?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | The sentence carries the sheet, the monthly cycle and the regional manager. Answer slot: the JD names volumes and resolution times and Excel, so expect those. If the sheet counted either, or was Excel, say so in your own words; if it counted something else, or you do not know how a figure was counted, say so plainly. Name the figure you would defend least, in your own words, before they do | F3 and F9 hold the open points; EXP because it tests whether the claim survives follow-up |
| E2 | "What rules did the formal complaints in your branch's log have to follow?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: the JD says "regulated", so this probe is likely. If you knew which rules or timescales applied, say so in your own words; if you did not, or none were set out for you, say so plainly and stay with "I handled the branch's formal complaints log." | F7 is the open point; JD because regulated complaints is a stated requirement |

## Reverse questions for Round 2

| Question | Why it lands |
|---|---|
| "What would the first ninety days look like, and which part of the complaints process worries you most today?" | It asks the future manager for their real priority |
| "How do complaint volumes and resolution times reach senior leaders today, and what would you want changed in the first cycle?" | It ties to the reporting duty and tells you the forum D2 is about |
| "How much of the role sits in the contact centre, and who there would I work with first?" | It turns D1 into a plan with a name on it |
| "Where do digital teams sit relative to member services, and which self-service journey comes first?" | It ties to the 40% digital target and the JD's self-service line |
| "What does a good escalation look like from a supervisor, in your words?" | It shows you think in terms of the coaching duty |

---

# ROUND 3: Panel of two branch managers, 60 minutes (includes the 20-minute case; the values round)

## Persona weights

| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| F. Values / Behavioural | One scored question or more per published value | High. The recruiter's email says "The panel is also the values round" and that they "score against the four values" | One story per value from a quoted sentence where one carries it, otherwise the honest branch |
| G. Case / Strategist | The 20-minute escalation case and strategy follow-ups | High. The case is documented and takes a third of the hour | Clarify, then objective, then approach, then risks; think aloud |
| H. Peer evaluator | Seam between your role and the branches | Medium. The role coaches branch supervisors, and the panel are branch managers, so I read them as stakeholders in that work (inferred, not documented) | Offer seam principles; do not pretend to know the seam |

## Values cheat sheet (the four published values)

| Value (as published) | Working meaning | Your mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a decision. Selection scaffold: pick a time you chose for the member over what suited the branch; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Plain Words | If a member needs it explained twice, the writing was wrong | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: if you ever simplified a script, letter or report, say what and why; if not, say so plainly and stay with the training |
| Neighbours, Not Numbers | Every branch is part of its town | F6: "6 years in retail banking, the last 3 as a branch supervisor." Answer slot: if your branch's town shaped a decision of yours, say which; if not, say so plainly and stay with the three years |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: if you stayed with one complaint from finding to fix, say what and your part; if it passed on, say so plainly |

## Question bank

### F. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold: a named stake, a moment where the member's interest and the branch's convenience pulled apart, a decision of yours, and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always is the first published value; VAL because it scores behaviour against it. No quote carries a decision, so this is a scaffold |
| F2 | "Tell me about a time you made something clearer for a member or a colleague." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Nearest thing in your sentence: the escalation script you trained tellers on, at that scope. Answer slot: if you rewrote or simplified anything, a script, a letter or a report, say what and why; if not, say so plainly, then say how you would test a letter on a member before sending it | Plain Words is published and testable; F4 is the nearest evidence. VAL because it scores the value |
| F3 | "Tell me about a time your branch's town shaped a decision you made." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | The sentence carries the last three years as a branch supervisor. Answer slot: if the town shaped a decision of yours, say which and what you chose; if not, or it was not yours, say so plainly and stay with the branch | Neighbours, Not Numbers; F6 is the only sentence that places you in a branch. VAL because it scores the value |
| F4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Beats the sentence states: you handled the log. Answer slot: expect a probe on one complaint. If you stayed with one from finding to fix, say what and which part was yours; if it passed to someone else part-way, or no case comes to mind, say so plainly and say what you would do the same way again | Own the Fix; F1 is the evidence and the limit is its scope. Choose a story where the hard truth landed, or say none comes to mind |

### G. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member has complained at their branch twice and phoned the contact centre, and each told them something different. They now say they will take it outside the credit union. You have the file. What do you do?" (practice case; the panel's real case is not known) | CASE | [generic] | Structure, aloud: what you ask first (what exactly was said, when, what the member wants, which rules and timescales apply: ask the panel); the objective (a fix for the member, with one named owner); what you do today (contact the member in plain words); who needs to know; what you record; why two answers were given and how that gets fixed. Make no claim about your past; the question needs none | The recruiter says the case is a complaint escalation, so a live problem on that shape is certain. CASE because it scores structure; [generic] because the real scenario is not known |
| G2 | "In the case, afterwards the branch supervisor says they feel blamed. What do you say?" (follow-up to G1) | CASE | [generic] | Separate the member's fix from the supervisor's learning: acknowledge the feeling, ask what they saw, agree what to change in the process rather than the person, and keep hold of the follow-up yourself. A plan and a method, with no past claimed | JD's coaching duty is where this lands; a branch-manager panel is likely to ask how a supervisor would hear it |
| G3 | "We are moving from eight branches to five hubs over 2027. What does that do to complaints, and how do you keep every branch part of its town?" | CO | [grounded] | Take a position and say it as a reading: name two or three things you would watch during the consolidation, in your own words (complaint volumes by branch, resolution times and repeat contacts are candidates). Ask what the panel would watch. Do not criticise the strategy, and say plainly what you do not know about Ashgrove's plans | The brief's hub plan meets the published value Neighbours, Not Numbers. CO because it scores strategic altitude; no claim about your past is needed |

### H. Peer evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our supervisors are stretched. How would you make coaching useful and not one more job?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Principles, said as a plan: ask supervisors what they find hardest, agree a rhythm with the branch manager, bring patterns from the complaints records back to them. Your own words at their scope: you trained new tellers on the escalation script. Answer slot: if any of that reached supervisors, say so; if not, say so plainly | JD's coaching duty; F4 is the evidence and the limit. The reciprocity framing is what a peer scores |
| H2 | "Where does your job end and a branch manager's begin when an escalation goes wrong?" | JD | [grounded] | Offer seam principles and do not pretend to know the seam: one named owner, whoever finds the problem keeps hold of it, and you would rather agree the line with them than assume it. Ask what they would expect | A seam probe from the peer persona; the published value Own the Fix gives the principle |
| H3 | "40% of member service is meant to go digital by 2028. What is your worry about what is left for branches?" | CO | [grounded] | Say it as a view, not as experience: F5 shows nothing either way, so if you have not worked with a digital team, say so plainly. Take a position on what a complaint needs that self-service cannot give, and ask what the panel has seen | The brief's digital target meets the JD's self-service line; CO because it scores strategic thinking |

## Reverse questions for Round 3

| Question | Why it lands |
|---|---|
| "What does a good escalation from your branch look like today, and what makes a bad one?" | It asks the people who send escalations what they need |
| "How are branch teams hearing about the hub plans, and what are members asking you about it?" | It speaks to Neighbours, Not Numbers without taking a side |
| "What could a new complaints lead do in their first month that would genuinely help your branch?" | Reciprocity: it asks what you can give, not only what you need |
| "Which of the four values is hardest to keep hold of on a busy day in your branch?" | It treats the values as practised, not as a poster |
| "How do your supervisors currently learn from a complaint that closed badly?" | It ties to Own the Fix and to the coaching duty |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says the log, not the process end to end. C1's slot stays with the log and the tellers |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." Your material says new tellers and training, not supervisors and coaching |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." Your material says formal, not which rules applied |
| Reported complaint volumes and resolution times each month | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." Your material does not show what the sheet counted |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD text; the four values, copied from ashgrovecu.org/about/values on 20 November 2026; the recruiter's email on the process; the four points of Ashgrove's July 2026 strategy brief as you wrote them (I have not seen the brief itself); your background message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values are in hand and fix the cheat sheet and F1 to F4 |
| 2. Ashgrove interview process | skipped | The recruiter's email fixes three sessions, who runs each, and the values round, which fix the persona weights |
| 3. Ashgrove strategy and recent news | skipped | The pasted brief points, dated July 2026, fix the grounding brief and A2, G3 and H3 |
| 4. Interviewer names | n/a | No names exist yet, so there was no query to form; the interviewer reads are absent |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Your answers to the slots in F1, F3, F4, F5, F7 and F9** (what the sheet counted, whether formal complaints followed set timescales, any work with digital teams, any training that reached supervisors) → those rows can move from slots to grounded story maps in C1, C2, E1, E2 and H1.
- **Inspectable artifacts** (a redacted copy of the monthly complaints sheet, the escalation script, the log's format) → F1, F3, F4, F7 and F9 can move from `medium` or `low` toward `high`.
- **Interviewer names** → an interviewer read per person, adjusted persona weights, and one reverse question tied to each person's own path.
- **The recruiter's answer on the case** (whether it is shared in advance, what format, any pre-read) → a build section for it if a deliverable is announced, and a sharper G bank.
- **The full strategy brief text** → the grounding brief grows from the four points you gave to the brief's own wording, and A2, G3 and H3 get sharper.
- **Hours per day you can spend on prep** → the triage resizes to your actual time.
- **A deeper research pass (L2)** → up to 6 more searches and 2 more fetches, several more minutes: recent org context and role-family reports for a credit-union complaints lead.
- **A `tuesday-dossier.md` from an earlier evidence check** would add verified evidence and a prohibited-claims list; this pack was built from your message alone.
