# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager, because the role sits in his function. Your note did not say, so the weights below rest on that assumption.
**Round:** 60 minutes, Friday. No loop source describes the round, so persona weights rest on the hiring-manager prior and not on Saltmarsh's documented process.
**Research status:** every web search was refused in this session, so nothing here is drawn from Saltmarsh's own pages. Company-specific rows are labeled `[generic]` or left out. The Sources section has the details.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims in your background survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

The highest-ROI rehearsal in this pack is **B1**, the in-app-purchase gap, followed by **B2**, the team-leading gap. Both are objections your own message states, so both are likely to come up in some form. Do those two first.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one main title and weekly content drops, with nothing inspected behind it. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on a second calendar likely. If you ever worked on a second title's drops, say what you did, in your own words; if not, say so plainly and stay with the main title |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | The calendar quote touches this requirement without showing who you worked with. Answer slot: the JD names four teams, so expect a probe on which of them you worked with on the drops. If any, say which and how, in your own words; if none, or it was not yours, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented retention numbers, which is adjacent to this requirement and does not reach it. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if any meeting or write-up followed a drop, say what part was yours, in your own words; if there was none, or it was not yours, say so plainly and stay with the numbers you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your material says you wrote the checklist, and the JD says manage it. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you used the checklist on releases, say how, in your own words; if not, say so plainly and stay with the sentence above |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material gives the four years and the weekly drops, and does not say whether you would call the title live-service. Answer slot: if you would call it live-service, say so and say why, in your own words; if you would not, say so plainly and stay with the weekly drops. Years of experience is a risk to name, not a gate |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a statement with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you ran it, weekly, for two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in the requirement as worded. Expect a probe on how the numbers were counted. If you do not know how, say so plainly. Lead with the sentence above, in its own terms |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | transferability | Your material has one written artifact, and it is adjacent to this requirement. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you wrote anything else others relied on, say what, in your own words; if the checklist is the main example, say so plainly |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the role: scheduling two titles, diagnosing a retention dip, planning an event | Highest. Hiring-manager prior, assumed because Tobias heads the function. No loop source describes how his round runs, so this is a prior and not a finding | Clarify first, then structure, then answer. Say your framework aloud. Claim nothing about past work you have not quoted |
| B. Skeptic | Probes the gaps: purchases, team-leading, one title versus two | High. Same prior, and two gaps are stated in your own message | Rehearse B1 until it is boring. Hold the quoted ground and concede the gaps plainly with a ramp plan |
| C. Data-Driven Prober | Retention numbers, how they were counted, what they are sensitive to | Medium. The JD's retention line and your presented-numbers quote draw it | Say what you know about how the numbers were counted and plainly what you do not |
| D. Conversational | Opening "walk me through your journey", why Saltmarsh, what you play | Medium. An opener like this is likely in any round, and casual questions are still scored | Prepare a 90-second arc from your own sentences. Treat casual questions as scored |
| E. Peer Evaluator | Seams between producer, design, art, engineering and community | Low to medium. The JD's four-team coordination line draws it, though the interviewer is assumed to be your manager | Offer seam principles instead of claiming to know their seams |
| F. Pressure | Time-boxed challenges on gaps and attribution | Low to medium. The prior for a hiring manager puts it below Case and Skeptic, and an attribution probe on the checklist is still plausible | Pause, restate, hold through two follow-ups, concede specifically |

No values-style round is detected. No loop source names one, and the generic fallback does not assume one, so there is no values bank and no values cheat sheet. If Saltmarsh publishes values, a recruiter email would add them.

## Question banks

### A. Case / Strategist (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We have two titles and one week where both want a big event. How do you decide what runs and when?" | CASE | [generic] | Clarify first: what each event is meant to move, what is already locked, which teams have capacity, how much the two player bases overlap. Then structure: criteria, recommendation, the risk you are accepting, what you would check afterward. Think aloud. The question needs no claim about your past, so the guidance makes none | Tests the two-titles requirement (F1) as a live decision. CASE because it scores structure, and `[generic]` because it is a pattern for the problem and not a fact about Saltmarsh |
| A2 | "An event goes live Thursday and Monday's build is missing an art asset. What do you do?" | CASE | [generic] | Structure: what is actually blocked, the options (cut scope, ship reduced, delay), who needs telling and in what order, what QA needs to re-check, what you would record afterward. Name the trade-off aloud. No claim about your past | Tests four-team coordination (F2) and the release checklist (F4) together. CASE because it is a live problem |
| A3 | "Day-7 retention dipped after last weekend's event. Diagnose it." | CASE | [generic] | Clarify: which cohort, which platforms, what else shipped, what the baseline is. Then hypotheses, the data each needs, and what you would say to the team in the meantime. Say plainly where you do not know how the studio defines the metric | Tests retention comfort (F7) live. CASE delivery for what is also JD content |
| A4 | "You're planning an event for a mix of paying and non-paying players. What do you need to know first?" | CASE | [generic] | Clarify the objective the event serves, what players can buy, what the studio counts as success, and what must not be disrupted. Say what you would ask, then how you would structure the plan. This is the safe ground for the purchases gap: a plan, not a past | Asks about purchases without the interviewer needing to name your gap. See B1 for the direct version |
| A5 | "What should a post-event review contain, and who should see it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Structure: the goal and how the event did against it, what was measured and how, what happened, what to repeat or change, who owns each follow-up. Written so each reader can find their part. The nearest thing in your material is the sentence in Provenance, at its own scope; say it as it is. Answer slot: if any write-up followed a drop, say what part was yours, in your own words; if none did, say so plainly | The JD's review-and-KPI line (F3) as a spoken question. JD because it scores the stated responsibility |

### B. Skeptic (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I see you haven't worked on a game with in-app purchases. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | **The highest-ROI rehearsal in this pack.** Say it plainly: "I haven't worked on a game with in-app purchases." Then give a plan as a plan, in the future tense: what you would learn first, who you would ask, what you would read in the first events' numbers. Hold the ground your quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "Presented the monthly retention numbers to the studio head". Follow-up 1 is likely "what would you need in the first 30 days". Follow-up 2 is likely "how do you avoid a wrong call on a paid event before you know the model". Concede there that you do not yet know the model, and say how you would find out. Never describe a purchase event as something you have done | The one objection with a stated source behind it (Prohibited claims, entries 1 and 2). The JD does not mention purchases, so how much weight the interviewer gives it is unknown, and the rehearsal covers both outcomes |
| B2 | "The role coordinates design, art, engineering and community. You've never led a team. How do you get four disciplines moving together?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say: "I haven't led a team." The pack's own observation is that the JD says coordinate, not lead, so you can say you are applying for the coordinating job, in those words, if it is true. Then your calendar sentence at its own scope. Answer slot: the JD names four teams, so expect a probe on which you worked with on the drops. If any, say which and how, in your own words; if none, or it was not yours, say so plainly and stay with the calendar | Second most stated gap. F2 is the row it presses on. JD because it scores the stated coordination requirement |
| B3 | "You've run the calendar for one title. This role has two. What changes?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | The sentence at its own scope: one main title, weekly drops, two years. Answer slot: if you ever worked on a second title's drops, say what you did, in your own words; if not, say so plainly. Then say what you would do differently as a plan, with no claim about the past | F1 is where the JD outruns the evidence. EXP because it checks the claim, and it is premised only on the quote |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Selection scaffold: choose the JD line your quoted material carries least, which the pack reads as F2, F3 or the purchases gap. State it in one sentence, then give your ramp plan. A named, honest weakness with a plan is stronger than a polished non-answer. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The standard Skeptic stem. JD because it scores honest self-assessment against the listed requirements |

### C. Data-Driven Prober (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the retention numbers you presented. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start from the sentence at its own scope. Answer slot: if you know how the numbers were counted, say so in your own words, and name the assumption you would defend least before they ask; if you do not know, or it was not yours, say so plainly and return to the sentence | F7 is the row a prober tests first. EXP because it checks whether the claim survives |
| C2 | "Which retention measures would you look at first after an event, and why?" | JD | [generic] | Say what the event was for first, then the baseline you would compare against, then the cohorts, then short-term versus longer-term effect, then the limits of what the numbers can show. Say plainly where you do not know how Saltmarsh defines them. No claim about your past | Tests the retention requirement (F7) as a forward-looking judgment. `[generic]` because it is a pattern |
| C3 | "Tell me about a time a retention number changed what the team did." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Open prompt, so selection scaffold: pick an instance with a named number, a named decision and a clear link between them. The nearest sentence your material carries is the one in Provenance, at its own scope. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's retention line (F7) as a behavioral prompt. EXP because it checks use of the numbers and not only presentation |

### D. Conversational / Rapport Builder (weight: mid, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc of those four sentences, in your own words, each at its own scope. Answer slot: give your own reason for moving to Saltmarsh, in your own words; if the reason is mostly that the role is a step up, say that plainly | F5 and F6 supply the beats. EXP because it is the CV walk-through |
| D2 | "What draws you to Saltmarsh Games?" | CO | [generic] | Selection scaffold: say only what you can back from having looked at their games or public material yourself. This pack could not research Saltmarsh, so it supplies nothing about them. If you have not looked yet, do that before Friday. If nothing specific comes to mind, say so plainly, then say what you want from live operations work | CO because it tests homework. `[generic]` because research was unavailable, which is the honest cost |
| D3 | "What are you actually playing or watching in live operations these days?" | JD | [generic] | Name titles and events you actually follow, and one thing each does that you would borrow or avoid. Real and specific beats broad. If you follow none, say so plainly and name the nearest thing you do follow | A casual question about a JD topic, still scored. JD because it is aimed at the role's domain |
| D4 | "What makes a release note or an event brief clear to someone outside your team?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Say what you look for in clear writing, in your own words. The one written artifact your material carries is the sentence in Provenance, at its own scope. Answer slot: if you wrote anything else others relied on, say what; if not, say so plainly | The JD's written-communication line (F8). JD because it scores that listed requirement |

### E. Peer Evaluator (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where is the seam between live ops and community, and what happens when we disagree?" | CASE | [generic] | Offer seam principles and not a claim about their seam: who owns the calendar, who owns player-facing wording, what gets agreed before an update locks. Say you would confirm their actual arrangement first | Tests four-team coordination (F2) collegially. `[generic]` because it is a pattern |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an occasion where the credit question was real and say who did what, with "we" for context and "I" for your own contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The standard peer stem. VAL because it scores collaborative behavior, with no published values to tie it to |

### F. Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has run a live-ops team with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head"; "Never led a team, and never worked on a game with in-app purchases" | Pause and restate. Hold on what your quotes carry: the calendar and the retention numbers, each at its own scope. Concede in one sentence: "I haven't led a team, and I haven't worked on a game with in-app purchases." Do not claim to be better than the other candidate. Say what you would do in the first weeks. Hold through two follow-ups and concede only what is true | Tests composure on the two stated gaps (Prohibited claims, entries 1 and 2). JD because it scores fit against the role |
| F2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: "I wrote the release checklist our QA team still uses." Answer slot: if anyone else shaped it, or it has changed since you wrote it, say plainly what was yours; if neither is true, say so. Never widen the sentence | F4 is the row an attribution probe targets. EXP because it checks what was personally yours |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, B3 |
| "coordinate design, art, engineering and community teams on each update" | A2, B2, E1 |
| "own the post-event review and the KPIs it reports" | A5, A3 |
| "manage the release checklist with QA" | A2, F2 |
| "3+ years producing live-service games or apps" | D1, B4 |
| "experience running a content calendar" | A1, B3, D1 |
| "comfortable with player-retention metrics" | A3, C1, C2, C3 |
| "clear written communication" | D4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like for this producer across the two titles?" | Makes the interviewer describe success in concrete terms, and tells you what to rehearse next |
| R2 | "When design, art and engineering priorities collide on an update, who makes the call?" | Shows you think about decision rights, which is the seam in the four-team requirement |
| R3 | "Which KPIs does a post-event review report today, and who reads it?" | Shows you care about the review as a working document, and gives you the vocabulary to use |
| R4 | "How does the producer work with QA on release readiness at the moment?" | Connects to the checklist you wrote without claiming more than the sentence says |
| R5 | "What would you want a new producer to learn first about how events relate to the paid side of the game?" | Turns the purchases gap into a ramp conversation instead of leaving it as an objection |
| R6 | "What is the part of this role people usually find hardest?" | Invites candor and signals you plan to do the hard parts |

No reverse question is tied to Tobias's own path. Only his name and title were given, and no research could be run on his public footprint.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| P1 — Led a team | A negative you stated: "Never led a team, and never worked on a game with in-app purchases" — your message | Your plain acknowledgment: "I haven't led a team." No slot. If the interviewer asks, give the acknowledgment and move to coordination |
| P2 — Worked on a game with in-app purchases, or on paid events | A negative you stated, same sentence | Your plain acknowledgment: "I haven't worked on a game with in-app purchases." A plan for learning it is said as a plan and never as a past |
| P3 — Ran the calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one main title and weekly drops. B3's slot stays inside that |
| P4 — Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The pack's observation is that your material says you presented retention numbers. A5's slot asks only what followed a drop |
| P5 — Managed the release process with QA | Inflated form of F4 | F4's quote at its own scope. The pack's observation is that your material says you wrote the checklist |

## Sources

**Provided documents:** the job description text you pasted, and the background in your message. Everything quoted in the fit snapshot is from those two, named there.

**Searches sent, all refused (permission not granted in this session):**

- "Saltmarsh Games values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games mobile studio news strategy" — refused
- "Tobias Wrenfield Saltmarsh Games" — refused

Nothing about Saltmarsh or Tobias in this pack comes from outside what you gave me.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet and VAL questions by name. Without it, no values section and E2 is `[generic]` |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have fixed the loop and persona weights. Without it, weights rest on the hiring-manager prior and the generic archetype |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have grounded CO and CASE questions in current priorities. Without it, they are `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have given an interviewer read and a reverse question tied to his path. Both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The relationship to Tobias (manager, peer or skip-level) → persona weights recomputed, and banks added or dropped to match
- The recruiter's prep email, if there is one → coverage of any focus areas or pre-declared deliverable, and the loop structure
- Saltmarsh's published values, pasted → a values cheat sheet and values-tagged questions
- Search permission, or pasted company news or a strategy note → CO and CASE questions grounded in Saltmarsh's actual priorities. A deeper research pass would use up to 6 more searches and 2 more fetches and take several more minutes, and it needs search permission to run
- Tobias's public talks or writing, pasted → an interviewer read and a reverse question tied to his path
- Your answers to the slots in F1, F2, F3, F4, F5 and F8 → those rows move from discovery or transferability toward `[grounded]`, and the matching bank rows become story-mapped
- A sample of what you wrote, such as the checklist itself or a monthly retention deck → confidence on F3, F4, F7 and F8 can rise from medium or low, because an inspectable artifact would exist
- A `tuesday-dossier.md` from an earlier evaluation pass → verified evidence and a named top objection, instead of the inferred one
