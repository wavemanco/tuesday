# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy. He is Priya's peer, and both would report to the same VP
- **Round:** one 60-minute conversation with Dan
- **Built on:** the JD highlights, the candidate summary, the interviewer profile summary and the research note you gave me. Web research was not available (see Sources), so nothing here comes from a search

## How to use this pack

- **Personas are how a question arrives. Types are what it scores.** Each question carries both a persona letter (its bank) and one type tag.
- **Type key:**
  - **VAL**: behavioral. Does past behavior show the trait the question names? No values-style round was detected for this loop, so VAL questions are themed by persona stems only.
  - **EXP**: work-experience deep-dive. Does a CV claim survive scrutiny, and what was actually the candidate's own?
  - **JD**: role-driven. Can she do the listed job, gaps included?
  - **CO**: company and strategy knowledge. Can she think at Northwind's altitude?
  - **CASE**: a live problem from the role, scored on structure and reasoning.
- **Guidance is scaffolding, not a script.** Say it in Priya's own words. Where a cell says "answer slot", it is an instruction for the interview and not a question for this conversation. Either honest branch is a good answer.
- **Highest-ROI prep in this pack: D1**, the sales-ops and quota gap. Rehearse it until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | transferability | Your material says product strategy and ops at a consumer-tech company, with no go-to-market work in it, and the words stay at that scope: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's ownership line makes a probe on go-to-market likely. If any of that work took a product to customers, say which and what part was yours, in your own words; if none did, or none was yours, say so plainly and stay with the strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material says a proposal and a credited uplift, and nothing about where the opportunity came from. The words stay there: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's whitespace line makes a probe on how the opportunity was found likely. If you identified it yourself, say how, in your own words; if it was brought to you, or no analysis sat behind it, say so plainly and stay with the proposal. The figure itself raises its own slots, handled at A1, A2 and G2 |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The quote already names both tools. Lead with it in its own terms: "I'm skilled in SQL and Tableau." It is a CV-level line with nothing inspected behind it, and the JD's word is "independent", which the quote does not carry, so expect Dan to probe it. A4 rehearses that probe |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a model that was built and used in negotiations, not a motion that was designed. The words stay at the model: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD's requirement makes a probe on what you designed, as opposed to what you modelled, likely. If any part of how partners were engaged was yours to set, say which and how you decided; if the model was the extent of it, or none was yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Reword only the quote: "I set annual volume targets, with consensus across orgs." It shows agreement was reached and not how, so expect a probe on the how (B3) |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | The quote is about use, and the JD says experience. The words stay at use: "I use AI tools daily." Answer slot: expect a casual probe on what you are doing with AI. Say which tools and for what, in your own words; if the use stops short of building or shipping anything with AI, say so plainly and stay with what you use |
| F7 | Fluency in sales-operations mechanics, since the interviewer leads Sales Strategy. Role-family prose with no source, so it is not quoted and raises no answer slot | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it is stated. Words: "I have no classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to quota or sales-ops work, and nothing added to make the gap feel smaller |

## Reading the interviewer

Public professional footprint only, and here only what your profile summary gave me: it was not independently researched.

- **Career pattern:** pricing and monetization roles, with one early-stage-startup chapter. His profile self-describes as "relentlessly data-driven".
- **Implications:**
  1. Every number Priya cites will be taken to its assumptions. Rehearse A1, A2 and G2 before anything else.
  2. A pricing and monetization spine is his native language, so cases tilt to packaging, price and unit economics (C3).
  3. A startup chapter means builder stories land well, and a nine-year large-company career invites a probe on pace (D3).
  4. He is a peer under the same VP, so he is also pricing what a hire costs his own work: seam principles (B1) and reciprocity (B4).
- **Mirror opportunity, shared vocabulary only:** his pricing and monetization language against the revenue language in F4: "built a partner-level revenue model used in carrier negotiations". Say it in the quote's own words and do not describe it as pricing work.
- **No shared-path mirror is offered.** Nothing in F1 to F7 carries a startup chapter.

## Persona table

Weights are shown in three passes so you can recalibrate if you know something I don't. The loop rests on your own words: one 60-minute conversation with a peer. No loop source names a values round.

| Persona | Bank | How it shows up with Dan | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | A, 5 questions | Takes each number to its inputs and its weakest assumption | Highest. Peer prior, plus "relentlessly data-driven" pushes it up, plus F2 holds a headline figure and F3 a tool claim | Know what you can and cannot say about how the figure in F2 was counted, and say plainly when you do not know. Name the weakest assumption you know of before he does |
| Peer Evaluator | B, 4 questions | Seam-splitting between Sales Strategy and Emerging Products, collaboration, credit | High. Peer prior, and he would share a VP with the hire | Reciprocity: what Priya brings his team, not only what she needs. Propose seam principles rather than pretending to know the seam |
| Case / Strategist | C, 3 questions | Live GTM, whitespace and pricing problems | Medium. The role is strategy, and his pricing spine tilts cases to price and packaging | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and say the framework before using it |
| Skeptic | D, 3 questions | Quiet probing of the sales-ops gap, the partner-motion requirement and why B2B | Medium. F7 is a stated gap in his own function, and F4 is a required item with adjacent evidence only | Rehearse D1 until boring. Bridge only from the quotes, with the limit named |
| Conversational | E, 2 questions | The opening biography and a casual AI question | Medium-low as a style, but certain as an opener. Casual questions are still scored | A 90-second arc, built from the quotes. Treat the AI question as scored |
| Pressure | G, 2 questions | Time-boxed "why you" and "how much was you" | Low. Peer prior does not call for it, though a data-driven peer may stress a number | Pause, restate, hold through two follow-ups, then concede one specific thing |
| Values / Behavioral | H, 2 questions | Behavioral prompts | Low. No values-style round is detected, and values pages were not available | Where a quoted sentence carries a story, use it. Where none does, select one and keep the honest branch ready |

## Question banks

### Bank A: Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The beats are only the ones the quote states: you proposed the change, it was a store-surface change, and the uplift was credited to it. Say it at that scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: say how the uplift was counted if you know, in your own words; if you do not know, or someone else owned the counting, say so plainly and return to the proposal. Never state a method you could not repeat under a second question | F2 holds the CV's one headline figure, so this is the Prober's first target. EXP because it tests what the claim rests on |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name the assumption before he does, in your own words. The pack does not name one. Answer slot: if you know the assumptions behind the credit, say which you would defend least and what the figure is sensitive to; if you do not know them, say so plainly and return to the proposal. A plain "I don't know how that was counted" is a credibility gain, not a loss | The second level of the Prober's usual pair. EXP because it scores whether she knows her own assumptions |
| A3 | "How was the revenue model you built used in the carrier negotiations?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: you built a partner-level revenue model, and it was used in carrier negotiations. Say it at that scope. Answer slot: if you took part in the negotiations themselves, say how; if others used the model while you were not in the room, say so plainly and stay with the model you built. The JD's partner-motion line makes the follow-up on what you designed likely, so hold at the model and never widen it | F4 is where the partner-motion requirement presses hardest. EXP because it scores attribution on a quoted claim |
| A4 | "Tell me about an analysis you ran yourself in SQL or Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | Open prompt with no quoted story behind it, so this is a selection scaffold. Pick one analysis you ran yourself: it needs a question you asked, the data you pulled, what you found, and what changed because of it. If one exists, offer to walk him through it end to end. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach one. Open with the quote's own terms: "I'm skilled in SQL and Tableau." | F3 is the one row with no gap, and the JD's "independent" is the word he will test. JD because it scores the stated requirement |
| A5 | "Net revenue retention in the enterprise segment fell two points quarter on quarter. How would you take that apart in SQL?" | CASE | [generic] | Make no claim about your past. Clarify first: how the metric is defined, over what window, whether the fall is broad or concentrated. Then split it into the four moves the JD names: land, adopt, expand and renew. Name the cuts you would run, the query shape for each, and what data quality could fake the fall. End by naming the assumption you would trust least | Pairs a live problem with F3's tool claim. CASE because it is a decision under data, and the enterprise framing comes from your research note |

### Bank B: Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | JD | [generic] | Propose seam principles and do not pretend to know the seam: decision rights agreed before launch, one shared definition for any number both teams report, and an escalation path to the shared VP. Then give the disagreement style in a sentence: say what you would bring him first, then ask for his data. Make no claim about a past dispute | The peer relationship and the shared VP come from your intake. JD because the role's cross-functional line is the stated requirement |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | The beats the quote states: annual volume targets, and consensus across orgs. Say it at that scope. Answer slot: if credit was ever contested in that work, say what you did; if it never was, or the process was not yours to run, say so plainly and stay with the targets and the consensus | Stem from the Peer persona. F5 is the only quoted cross-org sentence, so it carries the story. VAL because it scores behavior toward an equal |
| B3 | "How did you get to consensus on those targets?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote states: you set annual volume targets and consensus was reached across orgs. Answer slot: the JD's influence line makes a probe on how likely. If you had to move a team, say how, in your own words; if agreement came without that, or someone else drove the process, say so plainly and stay with the targets | F5 shows consensus was reached and not how. EXP because it scores what was actually hers |
| B4 | "What would you need from me in your first month, and what could you do for my team?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity first. Offer what the quote carries: "I'm skilled in SQL and Tableau." Then ask him for what he knows best: how sales operations works here and how he would define the stages the JD names. Asking him to teach you quota mechanics is the honest move on F7 and makes him your guide. Say nothing about a past you cannot quote | The reciprocity question a peer expects. JD because it scores partnership fit in the role |

### Bank C: Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the GTM plan for a new product line launching into an existing enterprise base. What do you need to know first?" | CASE | [generic] | Say the framework aloud first. Clarify: who buys, what success is, what the launch window is, what exists to build on. Then objective, segmentation, approach, metrics, risks. Use the JD's stage words: land, adopt, expand and renew. Challenge one premise respectfully. Make no claim about your past | Covers F1's ownership line. CASE because it scores structure on a role problem, and "enterprise expansion" is a priority in your research note |
| C2 | "Where is the whitespace across land, adopt, expand and renew for a product like this, and how would you find it in the data?" | CASE | [generic] | Define whitespace per stage as a gap between where customers are and where they could be. Offer two or three hypotheses, say which data would test each in SQL, and name where you could be wrong. No claim about your past. Do not borrow F2's figure to prove you can do this | Covers F2's JD line. CASE because the role will ask it live |
| C3 | "Compass is launching as an AI copilot. Price it standalone, bundle it into the platform, or go usage-based, given a much larger vendor is bundling against us?" | CASE | [grounded] | Clarify first: what Compass is for, who buys it, what its margin looks like. The profitability priority matters here. Then test each option against unit economics and the bundling threat. Bring one consensus item to prove grounding (defend the base against a bundle), then one thesis-driven divergence with a concession, and name the option you would say no to. Do not claim to know Northwind's actual pricing | The three priorities and the bundling threat come from your research note, which was not checked for currency. CASE content with CO grounding. His pricing spine makes this his native ground |

### Bank D: Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales ops or quota setting in your background. How would you handle that in this role?" | EXP | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | **The highest-ROI prep in this pack.** Name the limit before he asks: "I have no classic sales-ops or quota-setting experience." Then the quote at its own scope: "I set annual volume targets, with consensus across orgs." Do not say these are the same thing. Then a ramp plan, said as a plan: spend the first weeks learning how sales operations sets and tracks quota here, and ask him to walk you through it. Hold through three levels. If he asks how a volume target differs from a quota, say what you understand the difference to be and claim no equivalence. If he asks whether you would learn on his team's time, concede that part of it is true and say what you would do to shrink it. If he asks what you would not touch until you had learned it, name something specific in your own words. Do not fold on the core claim to restore harmony | F7 is stated, the interviewer leads Sales Strategy, and the evidence only goes as far as F5. Named the deepest rehearsal because it will be asked in some form. EXP because it tests honest self-assessment |
| D2 | "The role asks for partner-motion design experience. What partner motions have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the quote carries: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of how partners were engaged was yours to set, say which and how you decided, in your own words; if the model was the extent of it, or none was yours, say so plainly and stay with the model. Hold at the model through two follow-ups by returning to it, never by adding to it | F4 is a required item with adjacent evidence only, so the probe is certain. Runner-up for deepest rehearsal after D1. JD because it scores a stated requirement |
| D3 | "Why B2B data infrastructure, and why now, after nine years at a large consumer-tech company?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Answer slot: give your actual reasons for the move, in your own words, and the one thing about two new product lines that draws you. Claim no B2B experience, because your material does not carry any. If he probes pace, say what you would do in the first month rather than describing a past pace | Motivation consistency, and his startup chapter makes a pace probe likely. F1 carries the career shape. EXP because it scores the story's consistency |

### Bank E: Conversational / Rapport Builder (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with three beats: two years of strategy consulting at a top firm, then nine years at a large consumer-tech company in product strategy and ops, then why this role. Answer slot: give the last beat in your own words. If a quoted result belongs in the arc, say it at its own scope and expect it to be probed. Stop at 90 seconds | Almost certainly the opener, and a rapport opener is still scored. F1 carries the arc. EXP because it is the CV told aloud |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it at the quote's scope: "I use AI tools daily." Answer slot: name the tools and what you use them for, in your own words; if the use stops short of building or shipping anything with AI, say so plainly and stay with what you use. Then turn it around and ask him how he sees Compass reaching customers | F6 is the AI-plus line, asked casually, and casual questions on hot JD topics are scored. JD because it scores a stated plus |

### Bank G: Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has carried a quota?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" and "skilled in SQL/Tableau" and "No classic sales-ops or quota-setting experience." | Pause and restate the question. Hold: "I built a partner-level revenue model that was used in carrier negotiations, and I'm skilled in SQL and Tableau." Concede one specific thing: "I have no classic sales-ops or quota-setting experience." Hold through two follow-ups by returning to those two sentences. Do not compare yourself with the other candidate's record | Stem from the Pressure persona, aimed at F7. JD because it scores comparative role fit. Hold-then-concede structure |
| G2 | "That ~$400M ARR. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold at the quote's verb: you proposed the change. Concede specifically and only what is true. Answer slot: if you know how the credit was assigned, say so; if you do not, say so plainly. Do not upgrade "proposed" to "drove", "led" or "delivered", and do not widen "credited with" into something you counted | The attribution probe F2 invites. EXP because it scores what was actually hers |

### Bank H: Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | No quoted sentence carries this story, so this is a selection scaffold. Pick a time that has a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stem from the Values persona. No values-style round is detected and no published values were in hand, so this is a generic rehearsal. VAL because it scores behavior |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | No quoted sentence carries this story, so this is a selection scaffold. Pick an occasion with a named customer, a metric that pointed the other way, and the choice you made. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stem from the Values persona. A data-driven pricing interviewer may test whether she can put a customer before a number. VAL because it scores a trade-off |

### Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| own GTM strategy for two new product lines | C1, C3, D3, E1 |
| identify whitespace across land/adopt/expand/renew | C2, A5 |
| run independent analysis in SQL and Tableau | A4, A5, B4 |
| partner-motion design experience required | D2, A3 |
| strong cross-functional influence | B1, B2, B3 |
| AI experience a plus | E2, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You have come through pricing and monetization roles. How has that shaped how you think about packaging the two new lines?" | Ties to his own path, and it turns the hardest probe into a peer conversation. It signals she researched him |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer. It shows she is thinking about his load |
| R3 | "Where do Sales Strategy and Emerging Products overlap today, and where is that still being worked out?" | Surfaces the seam from B1 and shows she thinks in decision rights |
| R4 | "How is the team thinking about positioning against bundling from a larger platform vendor?" | Rests on the competitive threat in your research note. Reads as diligence |
| R5 | "How does Compass relate to the two new product lines, and who owns each number at six and twelve months?" | Answers something she needs to know before accepting: what she would own and how it would be measured |
| R6 | "How does the profitability priority show up in the targets the new lines carry?" | Connects to a stated priority, and a data-driven peer will value the question |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has quota-setting or sales-ops experience, including that her volume targets were quotas | Negative the candidate stated, F7 | "I have no classic sales-ops or quota-setting experience." F5's quote at its own scope: "I set annual volume targets, with consensus across orgs." The pack's observation is that the material does not show whether those targets were quotas. No slot |
| Designed partner motions | Inflated form of F4 | F4's quote at its own scope: a revenue model that was built and used in negotiations. The limit is the pack's observation: model, not motion. D2's slot stays inside the model |
| Drove, led or delivered the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: "proposed", and "credited with". The material does not show who counted or delivered it |
| Owned go-to-market strategy or launched products to market | Inflated form of F1 | F1's quote at its own scope: product strategy and ops. The material does not show go-to-market work |
| Built or shipped AI products or models | Inflated form of F6 | F6's quote at its own scope: "I use AI tools daily" |

## Sources

- **Provided documents:** your message (the JD highlights, the candidate summary, the interviewer profile summary and the research note). No dossier was provided. The research note is undated and its currency was not checked.
- **Searches sent, all refused:**
  - "Northwind Data company values principles": refused
  - "Northwind Data interview process strategy GTM sales strategy": refused
  - "Dan Kovac Director Sales Strategy Northwind Data": refused
- **Fetches:** none sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Every call was refused. It would have fed a values cheat sheet and mapped VAL questions. Neither is in this pack, and no values-style round is detected without it |
| 2. `Northwind Data interview process` | unavailable | Every call was refused. It would have confirmed the loop. The loop here rests on your own words: one 60-minute conversation with a peer |
| 3. `Northwind Data strategy` | unavailable | No call was sent because search was declined. It would have checked that the research note is current and added recent moves to the CO bank |
| 4. `Dan Kovac Northwind Data` | unavailable | Every call was refused. It would have added public talks and writing to the interviewer read. Only your profile summary is used |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot rows. Only highlights were supplied, so mid-list requirements may be missing |

## Upgrade menu

- **Full JD text** → the six rows sourced from highlights become full-JD quotes, and any mid-list requirement gets a question
- **Priya's resume bullets, or her own answers to the answer slots** → F1, F2, F4, F5 and F6 can upgrade, and the slots in A1 to A3, B2, B3 and D2 get filled with her real answers
- **The written proposal or the dashboard behind the ~$400M ARR credit, and the deck behind the carrier model** → F2 and F4 can rise from `medium` to `high`
- **The recruiter's note on what Dan's conversation covers, or any piece to prepare** → coverage assumed from round-type priors becomes stated, and a build section is added for any declared deliverable
- **Search access** → values, loop and strategy research, plus Dan's public footprint. A deeper pass adds up to 6 more searches and 2 more fetches and takes several more minutes
- **A dated Northwind strategy brief** → a grounding brief section, and a check that the research note's priorities are current
- **A prior `tuesday-dossier.md`** → verified evidence and a named highest-ROI objection in place of the inferred ones, and prohibited claims from a source other than this pack
