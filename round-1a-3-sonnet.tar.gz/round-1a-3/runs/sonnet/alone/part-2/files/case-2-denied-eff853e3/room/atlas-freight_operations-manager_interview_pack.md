# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager. Company: Atlas Freight (regional logistics, 800 employees, per the JD you pasted). Interviewer: not known. Round type and relationship: not known, so persona weights are flat (section 8).

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Question IDs run by persona (A1, A2, B1 and so on) so you can drill any of them by ID.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. Not used in this pack: no published values were read |
| EXP | Whether your background claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether your homework on the company runs deep |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding for a spoken answer, not a script. An answer slot is an instruction for the interview, not a question for you now: where it says to say something in your own words, it means words only you can supply, and where it offers a second branch, that branch is as good an answer as the first.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows a senior shift role and the site's surge plan, and the words stay at that scope: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's 4-sites line makes a probe on the reach of your remit likely. If it reached beyond what these sentences say, say how far, in your own words; if it did not, say so plainly and stay with them |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material measures mis-pick rate, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's on-time and cost-per-shipment line makes a probe on other measures likely. If you tracked another measure, say which and how it was counted; if you tracked none beyond mis-pick rate, say so plainly and stay with it |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows 3 supervisors, and the words stay there: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's 12 makes a probe on scale likely. If more people reported to you at any point, say how many and when, in your own words; if not, say so plainly and stay with the 3 |
| F4 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a self-rating, not a record of what was built, so it is a discovery lead and not a claim to assert. Answer slot: the JD's reporting line makes a probe on what you used Excel for likely. Say what you used it for and who, if anyone, used the output, in your own words; if it was not used for anything others relied on, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI use, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The first quote counts years in operations, and nothing in your material says how many of them included leading people. Words at the quote's scope: "I have 7 years in warehouse and distribution ops." Answer slot: say how many of the seven years included leading people, with the role in each, in your own words, and give the number as it is, whatever it is |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap in the quote, but a certificate line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: "I'm green belt certified." Your material does not name the program the belt is from, so say which in your own words |

## Persona table

Weights rest on the Generic archetype (screen, hiring manager, panel), not on this company's documented process: no loop source establishes the loop, and your note did not say who you are meeting. That is why the weights are flat, and flat is noticeably weaker than a tuned pack.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of scale, tools and the years requirement | Flat. Not tuned to a relationship; F1, F3, F5 and F6 are where the material is thinnest, so the questions are written there | Rehearse A1 until it is boring; hold what the quotes carry and say the limit plainly |
| B. Data-Driven Prober | Goes line by line through the 40% | Flat. The only headline figure in your material is the one in F2 | Know what you can and cannot say about how the figure was counted (B1); say plainly when you do not know |
| C. Case / Strategist | Live problems from the role | Flat. The JD's on-time and cost lines generate cases whatever the round | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| D. Pressure | Time-boxed challenges to your claims | Flat. Probable if a senior or time-boxed round is on the calendar; unknown | Pause, restate, hold two follow-ups, concede specifically and never on the core claim |
| E. Conversational | Friendly opener, biography, casual JD questions | Flat. Most loops open this way, and these questions are still scored | Pre-script the 90-second arc (E1) from your own quotes |
| F. Values / Behavioral | Past-behavior prompts | Flat. No loop source names a values round and no published values were read, so these are open prompts on JD themes | Choose stories with a named stake; the scaffold ends in an honest branch |
| G. Peer | Seams between sites, credit, collaboration | Flat. Likely only if a site lead is in the loop | Reciprocity: what you bring to their site, and seam principles, not a pretended seam |

## Question banks

Three questions per persona under flat weights. A1 is the highest-ROI rehearsal in this pack.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have three supervisors reporting to you today. This role has twelve across four sites. What changes at that scale?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Open with what the quote carries, at its own scope: "I'm currently a senior shift manager over 3 supervisors." Name the scale difference yourself before the interviewer does. Answer slot: if your remit reached beyond the supervisors you have described, say how far, in your own words; if it did not, say so plainly and stay with the 3. Then give your own first-weeks plan for a larger team, stated as a plan and never as something done. Expect two follow-ups, the largest team you have led and how you would run supervisors you did not choose: answer the first from your own experience or say plainly it was the 3, and answer the second as a plan. Return to the quote each time and add nothing to it | F3 and F1 are where the posting's scale presses hardest on the material, so this objection arrives in some form; JD because it scores a stated requirement |
| A2 | "The role builds reporting in Excel and Power BI. Where are you with Power BI?" | JD | [grounded] "never used Power BI" | Say it plainly: "I've never used Power BI." Then a plan, in your words: how you would learn it and how fast, and which operational measure you would put first. A plan is future tense; do not describe any Power BI work as done. Stop after the plan rather than filling the silence | F5 is a stated gap, and the interviewer will find it on the first question about tools; JD because it scores the reporting requirement |
| A3 | "The posting asks for five years of operations leadership. How much of your seven years was leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say the quote at its scope: "I have 7 years in warehouse and distribution ops." Answer slot: say how many of those years included leading people, with the role in each, in your own words, and give the number as it is. If part of the time was individual work, say so plainly. Do not round up | F6: the years line counts operations, not leadership, so the probe is predictable; JD because it scores a stated requirement |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% on mis-pick rate was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Start from the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say how the figure was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours, all in your own words. If you do not know how part of it was counted, say that plainly. Name the weakest assumption before they do. Never describe a counting method you cannot repeat under a second question | F2's only figure; EXP because it tests whether the number survives attribution scrutiny |
| B2 | "Beyond mis-pick rate, what did you track: on-time, cost per shipment, anything else?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: name any other measure you tracked and how it was counted; if you tracked none beyond mis-pick rate, say so plainly and stay with the quote. Then give, as a plan, the two measures you would put first for four sites and why | F2: the JD's on-time and cost line against a quality metric; JD because it scores the stated requirement |
| B3 | "Tell me about the reporting you have built: what was in it, and who used it?" | JD | [inferred] "solid Excel" | Answer slot: say what you used Excel for and who, if anyone, used the output, in your own words. If it was not used for anything others relied on, say so plainly and stay with "solid Excel". Do not describe a report, a layout or an audience you cannot name | F4 is thin: a self-rating, so this is a discovery rehearsal; JD because it scores the Excel half of the reporting line |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance at one of the four sites has slipped over three weeks. What do you need to know first, and where do you look?" | CASE | [generic] | Structure aloud: how on-time is defined and measured; whether it is one site or a pattern; what changed three weeks ago; then segment by lane, shift and day, then the metrics you would watch and the risk of fixing the wrong thing. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's on-time line as a live problem; CASE because it scores structure |
| C2 | "Cost per shipment is rising while volume is flat. Where do you look?" | CASE | [generic] | Clarify what is in the cost figure and how it is calculated; segment by site, lane and shift; separate a real cost change from an allocation or counting change; propose what you would check in the first week and what you would not touch yet. No claim about your past | The JD's cost-per-shipment line as a live problem |
| C3 | "Peak season is coming and volume will run well above normal at all four sites. Sketch the surge plan. What do you need to know first?" | CASE | [generic] | Clarify the forecast and its confidence, then the constraints (labor, space, equipment); structure by site and shift; name the trigger points for escalation and what you would measure daily. Think aloud. The question needs no claim about your past; E2 is where your own surge plan comes in | A strategy-flavored case from the role's own cycle |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already run multiple sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, then hold with the three quotes at their own scope. Answer slot: if your remit reached past what these quotes carry, say how far; if it did not, say so plainly and return to them. Hold through two follow-ups; concede the limit in specific words, not on the core of what you have done | F1 and F3 are the likeliest points for a time-boxed challenge; JD because it scores fit to the stated role |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Stay with the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which part was yours and who else contributed, in your own words; if it was shared, say so plainly and return to what you did. Hold through two follow-ups; concede only what is true | F2's figure under attribution pressure; EXP because it tests what was yours |
| D3 | "Green belt: that is a classroom credential. What have you actually done with it?" | JD | [grounded] "green belt certified" | Start with the quote: "I'm green belt certified." Answer slot: name the program the belt is from, and if you used it on a project, say which project and what part was yours; if the certification was not tied to a project of yours, say so plainly and stay with the quote. Do not link it to any other result unless you did so in fact | F7: the plus-skill is the easy place for a pressure probe; JD because it scores the Lean/Six Sigma line |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc built only from these sentences, in your own words: the seven years, where you are now, the two results as you would say them, the certification. Close with your own reason for this role. The pack has none of your reasons, so it supplies none | The biography question opens most loops and is scored; EXP because it checks the story against the CV |
| E2 | "Tell me about the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The beats the quote states: a surge plan, the site's, two years running. Answer slot: if the second year differed from the first, say how and why; if it did not, say so plainly and stay with the plan. Then extend it as a plan to four sites, stated as a plan and never as a past | Your own surge plan is the clearest match for a freight operator's peak; EXP because it tests what you ran |
| E3 | "What do you know about Atlas Freight, and why us?" | CO | [generic] | No research ran for this pack, so nothing here describes the company. Before the interview, read the company's own site and careers page and bring one specific observation, and say why it matters to the role. Give your own reason for moving here. If you cannot find an answer to something, say what you would ask | Homework depth is scored; CO because it tests company knowledge; generic because research was refused |

### F. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to deliver an unpopular truth to a supervisor or to leadership." | JD | [generic] | A selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's lead-supervisors line as a behavioral prompt; JD because no published values were read |
| F2 | "When did you put a customer ahead of an internal metric?" | JD | [generic] | A selection scaffold: pick a time where the metric and the customer pulled apart, you chose, and you can say what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | On-time and cost can pull apart; JD because it scores that line |
| F3 | "What does a good supervisor look like on your team, and what do you do when one is not there yet?" | JD | [generic] | Describe the standard in your own terms. Answer slot: if you have developed a supervisor who was not there yet, say how, in your own words; if you have not, say so plainly and say how you would. Never describe a development practice you have not run | Leading twelve supervisors is the JD's own requirement; JD |

### G. Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our sites sit side by side. Where is the seam between them, and what happens when we disagree about priorities?" | CASE | [generic] | Offer seam principles, not a pretended seam: who owns the call, what data decides it, when it escalates. Ask what the current practice is. No claim about your past | A peer's collaboration probe; CASE because it is a live scenario |
| G2 | "How do you handle credit when a result spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if others contributed to the result in the quote, say who and how you say so; if it was yours alone, say so plainly. Never claim a share beyond what you did | A credit probe lands on your one headline result; EXP because it tests attribution |
| G3 | "What would you need from me in your first month?" | CASE | [generic] | Lead with what you would bring to their site, then what you need, as a short list. No claim about your past | A peer prices the hire against their own load |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, C3, D1, E2, G1 |
| "drive on-time performance and cost-per-shipment down" | B2, C1, C2, F2 |
| "lead a team of 12 supervisors" | A1, F1, F3 |
| "build reporting in Excel/Power BI" | A2, B3 |
| "5+ years operations leadership required" | A3 |
| "Lean/Six Sigma a plus" | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which of the four sites is the hardest to run today, and what makes it so?" | Shows you think about where your days would go, and tells you what the scale really is |
| R2 | "Which measures are reviewed for each site in a normal week, and where do they live today?" | Ties to the on-time, cost and reporting lines, and shows where Excel or Power BI sit in the current process |
| R3 | "What does the current group of twelve supervisors look like, and what would you want changed in the first six months?" | Puts the scale gap on the table as a ramp conversation instead of an objection |
| R4 | "What does success look like at 90 days and at 12 months?" | Gives you a target to hold your plan against |
| R5 | "When on-time and cost point in different directions, how are decisions split between the sites and the central team?" | Shows you see the trade-off and tells you how much authority the role carries |
| R6 | "What is the next step in the process, and who else will I meet?" | Costs nothing and tells you the round structure, which retunes this pack |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran or owned operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material shows a senior shift role and the site's surge plan |
| Improved on-time performance or lowered cost per shipment | Inflated form of F2 | F2's quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." B2's slot asks only what else was tracked |
| Led a team of twelve supervisors, or a large supervisor team | Inflated form of F3 | F3's quote at its own scope: "I'm currently a senior shift manager over 3 supervisors." |
| Built the operation's reporting in Excel | Inflated form of F4 | "Solid Excel" at its own scope. B3's slot asks only what Excel was used for |
| Has used, or is familiar with, Power BI | Negative you stated, F5 | "I've never used Power BI." No slot |
| Led Lean or Six Sigma projects, or that the pick-path redesign was a Lean or Six Sigma project | Inflated form of F7 and F2 | "I'm green belt certified." The pack's observation: nothing in your material ties the belt to the redesign or names its program |
| Holds five or more years of operations leadership | Inflated form of F6 | "I have 7 years in warehouse and distribution ops." The limit is the pack's observation: the material does not show how many of those years included leading people |

## Sources

Provided documents: the JD text and your background, both pasted in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused, so no published values were read. It would have fed a values cheat sheet and VAL questions, and it would also have shown whether the company name resolves to this firm |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. It would have fed the loop structure and persona weights; they fall back to the Generic archetype, flat |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. It would have fed company-grounded CO and CASE questions; C1 to C3 and E3 are generic instead |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent: "Atlas Freight regional logistics company values" (refused); "Atlas Freight interview process operations manager" (refused); "Atlas Freight regional logistics strategy news" (refused).

## Upgrade menu

- Who you are meeting (name, title, manager, peer or senior) → persona weights retuned from flat, an interviewer read, and a reverse question tied to their path
- The recruiter's prep note → round format, focus areas and any declared deliverable, which retunes the banks
- Search permission, or a pasted values page, careers page or strategy brief → E3, C1 to C3 and the reverse questions become company-grounded instead of generic, and the company name is confirmed as the firm you are meeting
- A deeper research pass once search is allowed (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief for the CO and CASE banks
- Your answers to the slots in F1, F2, F3, F4 and F6 → those rows and the questions that draw on them become story-mapped answers instead of slots
- The green belt certificate (issuing body and program) → F7 rises from medium to high, and D3 gets its program named
- The site's mis-pick report covering the redesign period → F2 and B1 rise from medium to high
- How many hours you have before the interview → a prep triage ordered to that time
- A prior `tuesday-dossier.md` for this role → verified evidence and prohibited claims in place of the list built here
