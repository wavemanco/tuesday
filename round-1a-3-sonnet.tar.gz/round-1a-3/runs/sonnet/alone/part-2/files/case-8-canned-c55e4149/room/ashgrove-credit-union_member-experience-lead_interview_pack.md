# Member Experience Lead — Ashgrove Credit Union: interview pack for Dara

Loop mode: three rounds on 29 November 2026. Round 1 is a 30-minute recruiter conversation. Round 2 is 45 minutes with the Head of Member Services, who would be Dara's manager, mostly behavioural. Round 3 is 60 minutes with a panel of two branch managers, including a 20-minute complaint-escalation case, and it is also the values round. The interviewers beyond their roles have not been assigned, so there is no interviewer read.

## How to use this pack

- Personas describe how a question arrives. Types describe what it scores.
- Type key: VAL = behavioural or values alignment against Ashgrove's four published values. EXP = work-experience deep-dive, whether your own account survives scrutiny. JD = a stated requirement of the role. CO = company and strategy knowledge. CASE = a live problem set in the role.
- Guidance is scaffolding, not a script. Every sentence about your past comes from something you wrote, and the quotes sit in the Provenance column so you can see where each one stops.
- An answer slot is an instruction for the interview, not a question for now. Answer it from your real experience, or say plainly that the practice was not yours or did not exist.
- The one to rehearse hardest is B1, with B9 as its pressure form. Round 2 is where it lands, and it is the biggest stated gap against the role's scope.

## Fit snapshot (shared across the three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on years, but a line from your message with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: six years in retail banking, the last three as a branch supervisor. The JD says customer operations and your line says retail banking, so say retail banking and let the interviewer draw the match |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says a formal complaints log, and does not show which rules or deadlines governed its entries. Answer slot: the JD's word regulated makes a probe on that likely. If you know which rules or deadlines governed the entries in the log, say which and what part of the handling was yours, in your own words; if you do not know, or none applied, say so plainly and stay with "I handled the branch's formal complaints log" |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [grounded] | transferability | The quote is one branch's log, and the words stay there: "I handled the branch's formal complaints log." The JD's end-to-end, across-branches scope is wider than the quote, which is the pack's observation and not words for you. Answer slot: if any entries on the log involved other branches or other teams, say how and what part was yours; if none did, say so plainly and stay with your branch |
| F4 | "the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past: what you would sit in on, who you would ask to walk you through how complaints move between the centre and the branches. Never a claim to contact-centre exposure |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [grounded] | discovery | The quote says a monthly spreadsheet, and the material does not show what it held. Answer slot: expect a probe on its contents. Say what the spreadsheet held and how it was filled, in your own words; if you cannot say, say so plainly and stay with "I built the monthly complaints spreadsheet our regional manager uses." |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [grounded] | discovery | The quote says spreadsheet and the JD says Excel, so the material does not show which tool. Answer slot: say which tool you built it in, in your own words; if it was not Excel, say so plainly and say what it was |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | low | [grounded] | transferability | The quote says new tellers and your own role was branch supervisor, so the material shows training at the teller level. The words stay at that scope: "I trained new tellers on our escalation script." Answer slot: say who the people you trained were and how the training ran, in your own words; if you cannot say, say so plainly and stay with the tellers |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then a plan, never a past: how you would prepare to present to someone more senior. Never a claim to having presented to senior leaders |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing here. Answer slot: if any of your branch work touched digital channels or self-service, say what and which part was yours; if none did, say so plainly and say what you would ask a digital team first |

No requirement in the JD is a term you meet or do not, such as a licence or a legal bar. All eight stated requirements are graded as experience, so no row is a hard gate and none needs a gate question.

## Grounding brief: what Ashgrove has said it is doing

This rests only on the four points you supplied from the July 2026 strategy brief the recruiter sent, plus the JD's own description of the employer. It is vocabulary to sound current, not a script, and a brief every candidate received is something to depart from with a reason, not recite.

| Item | As provided | Why it matters in this loop | Provenance |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | Complaint self-service journeys sit inside this target, and the JD names working with digital teams on them. Feeds B7, B3, C8 | [grounded] |
| Branch consolidation | Eight branches into five hubs over 2027 | Two of the three panel members are branch managers, so the hub change touches their own branches. Feeds C7 and the Neighbours, Not Numbers value | [grounded] |
| New product | Small-business lending product in Q1 2027 | A new product line brings a new kind of member and, by extension, possible new complaint themes; the extension is this pack's derivation from the product launch, not something the brief says | [inferred] |
| Competition | The main competitive pressure is app-only banks | Frames C8: what a member's complaint experience has to be so that a faster app does not win them | [grounded] |
| Character | Member-owned, about 900 staff (JD) | Frames A8 and the values answers | [grounded] |

---

# Round 1 — Recruiter, 30 minutes

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly biography question, motivation, logistics | High. The recruiter-screen prior is Conversational plus a light Skeptic, and a 30-minute slot leaves room for little else | Know your 90-second arc and treat the casual questions as scored |
| Skeptic (light) | Knockout checks against the JD in a friendly register | Medium. F4 and F8 are stated in your own message, so a recruiter reading the JD against your background will touch them | Name both plainly before asked, in the words F4 and F8 give |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." — your message; "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "I built the monthly complaints spreadsheet our regional manager uses." — your message | A 90-second arc in three beats the quotes state: six years in retail banking, the last three as a branch supervisor; handled the branch's formal complaints log and trained new tellers on the escalation script; built the monthly complaints spreadsheet your regional manager uses. Tell each in your own words. Close with your own reason for wanting this role, which the pack does not supply | F1 is the evidence the biography has to carry, and the recruiter's first read of fit is built from it. EXP because it tests what the CV line survives |
| A2 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot for the reason for leaving: give your actual reason in your own words, framed around what you are moving toward, and keep it identical across all three rounds. The pack supplies none | Every recruiter screen asks it and it must stay consistent into rounds 2 and 3. EXP because it tests the story behind the move |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot for pay: either give your own figure, or ask for the role's band first. The choice is yours and the pack names no number. If asked about your current pay, you can decline and redirect to the role's band | Pay is the recruiter's standard knockout. JD because it concerns the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot for notice: give your actual notice period, in your own words | Start-date planning is a standard recruiter item. JD because it concerns the listed job's terms |
| A5 | "The role covers branches and the contact centre — any constraints on where or how you can work?" | JD | [generic] | Logistics slot for location: give your own constraints in your own words, or say plainly you have none. The JD's mention of branches and the contact centre is the reason to expect it | The role spans sites, and the recruiter must know the candidate can cover them. JD because it concerns the listed job's terms |
| A6 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | Hold what your message says and no more. Say the two plainly: "I haven't worked in a contact centre" and "I haven't presented to anyone above regional level." Then one plan per gap, said as a plan: sitting in on how the contact centre handles complaints, and preparing before you present to anyone more senior. Do not soften either into a strength | F4 and F8 are the stated gaps, and a recruiter reading the JD will find them. JD with a Skeptic delivery; candour rehearsed here makes B1 easier |
| A7 | "Walk me through how you handled the branch's formal complaints log." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | The beats the quote states: the branch's log, formal complaints, handled by you. Answer slot: the JD asks for regulated complaint handling, so expect a probe on what governed the entries. If you know which rules or deadlines governed them, say which and what part was yours; if you do not know, or none applied, say so plainly and describe how you handled the log | F2 is the requirement the recruiter will test first, and the JD's word regulated presses on it. EXP because it tests what was actually yours |
| A8 | "Why Ashgrove, rather than an app-only bank?" | CO | [grounded] | Use only what you have read: the credit union is member-owned, its first value is "Members First, Always", and its brief names app-only banks as the main competitive pressure. Say what draws you in your own words and tie it to one value by name. Do not recite the strategy brief back | The recruiter sent the brief, so the question tests whether it was read. CO because it tests homework |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does the Head of Member Services most need from this hire in the first months?" | Shapes your round 2 answers around their stated need, and shows you are already thinking about the manager |
| "Is there anything about the format or materials for the 20-minute case I should know?" | A candidate who asks about the case in advance signals preparation, and the answer fixes C5's shape |
| "Who is on the panel, and which branches do they manage?" | Interviewers are unassigned, so this is the one question that can replace several assumptions in the Round 3 pack |
| "Does this role manage the contact centre team directly, or work alongside it?" | The JD says the role owns the process across branches and the contact centre; the answer sets how B1 should be pitched |
| "What is the timeline after the 29th, and what is the pay band?" | Practical, and asking for the band lets you answer A3 from their number if you choose that option |

---

# Round 2 — Head of Member Services (your prospective manager), 45 minutes, mostly behavioural

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the contact-centre and seniority gaps | Highest. The hiring-manager prior is Case/Strategist plus Skeptic, they are buying capability and de-risking gaps, and F4 and F8 are stated | Rehearse B1 until it is boring: plain acknowledgment, the adjacent work at its real scope, a concrete ramp plan |
| Values / Behavioral | Scenario probes, STAR-shaped | High. The recruiter described the round as mostly behavioural, which lifts this above the hiring-manager prior | Use "we" for context and "I" for contribution; where no story comes to mind, say so plainly |
| Data-Driven Prober | Digs into the spreadsheet and the escalation training | Medium. The role reports monthly and the candidate built a monthly spreadsheet | Say plainly what you can and cannot say about how the spreadsheet was filled |
| Case / Strategist | Live problems on the digital shift and a first-90-days plan | Medium. The recruiter said mostly behavioural, which pulls this down from the hiring-manager prior | Clarify first, then objective, segmentation, approach, metrics, risks |
| Pressure | Time-boxed challenge on why you | Lower. Expected only as a follow-up inside the Skeptic questions | Pause, restate, hold the position through two follow-ups, concede specifically |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see contact centre experience in your background — how would you handle that in a role that owns the complaints process across branches and the contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message; "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | The highest-ROI rehearsal in this pack. Hold what the quotes carry: "I haven't worked in a contact centre." Then the adjacent work, at its own scope only: "I handled the branch's formal complaints log." Then a plan, said as a plan: sit in on how the centre handles complaints, have its team walk you through how complaints reach branches, and ask what they find hardest to hand over. Through two follow-ups, return to the acknowledgment and the plan and never add to the log. Concede specifically that the learning curve is real. Name the limit before it is asked for | F4 is the largest gap against the role's scope and a manager will ask it. JD because the requirement is stated, Skeptic delivery because it probes the gap |
| B2 | "Tell me about a time you presented to senior leaders." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message; "I built the monthly complaints spreadsheet our regional manager uses." — your message | The JD asks for confidence presenting to senior leaders. Selection scaffold: pick the most senior audience you have spoken to; it needs the room, what you said and what came of it. If no such time comes to mind, say so plainly: "I haven't presented to anyone above regional level." Then give the nearest thing your material does carry, which is the monthly spreadsheet your regional manager uses, at its own scope, or how you would prepare for it | F8 is stated, so the question will be asked in some form. JD with a Skeptic delivery |
| B3 | "Tell me about any work you've done with digital teams or on self-service." | JD | [grounded] none given | The JD names working with digital teams on self-service journeys and your material says nothing about it. Answer slot: if any of your branch work touched digital channels or self-service, say what and which part was yours; if none did, say so plainly and say what you would ask a digital team first. Do not stretch another answer to cover it | F9 is silence, so this is discovery rehearsal. JD because it scores a stated requirement |
| B4 | "Tell me about a time you delivered an unwelcome message to someone senior." | VAL | [generic] | Selection scaffold: pick a moment with a named stake, a point where you did not fold, and a relationship still working at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack names no event for you | A stock behavioural stem in a mostly behavioural round. VAL because it tests demonstrated behaviour, and generic because no quoted sentence of yours carries it |
| B5 | "Tell me about the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." — your message | The beats the quote states: built by you, monthly, used by your regional manager. Answer slot: the JD describes reporting monthly and names Excel, so expect a probe on contents and tool. Say what the spreadsheet held, how it was filled and which tool you built it in, in your own words; if you cannot say, say so plainly and stay with the quote. Name the assumption in it you would defend least, in your own words, before they do | F5 and F6 are both thin on contents and tool, and this is the reporting probe. EXP with a Prober delivery |
| B6 | "Walk me through how you trained new tellers on the escalation script." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | The beats the quote states: new tellers, our escalation script, trained by you, and your own role as branch supervisor. Answer slot: the JD asks about coaching branch supervisors on escalations. Say who you trained and how the training ran, in your own words; if you cannot say, say so plainly and stay with the tellers. Do not claim you wrote the script | F7 is adjacent: the material says tellers and the role says supervisors. EXP because it tests what was actually yours |
| B7 | "By 2028 Ashgrove wants 40% of member service on digital channels. What would you need to know before designing a self-service route for raising a complaint?" | CASE | [grounded] | Clarify first: what complaints come in now and by which channel, which kinds need a person, and what the digital team can already do. Then the objective, and say it in plain words, one of Ashgrove's own values. Then segment by complexity and by who needs a human, approach with the digital team, metrics, risks. Name the risk of a complaint lost between channels, and challenge one premise respectfully. This asks about no past, so the guidance makes no claim about yours | A case on the strategy brief's headline target and the JD's digital line. CASE because it is a live problem, CO because it uses the brief |
| B8 | "What would you do in your first 90 days?" | CASE | [generic] | A plan, never a past. Structure: listen first, across branches and the contact centre; map how a complaint travels between them; baseline the monthly report; then pick the first fix. Say what you would not change yet. Ask what is already in motion before proposing anything | A standard hiring-manager case that tests whether the plan matches the role's scope. CASE because it is a live problem |
| B9 | "Sixty seconds: why you over someone who has run a contact centre complaints team?" | EXP | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | B1 in its pressure form. Pause, restate the question, then hold: three years as a branch supervisor at its own scope. Concede specifically: "I haven't worked in a contact centre." Do not claim a depth of complaints work the quotes do not carry. Hold through two follow-ups, concede only what is true | B1's objection often arrives time-boxed, and F4 is the target. EXP with a Pressure delivery |

## Reverse questions

| Question | Why it lands |
|---|---|
| "Where is complaint handling strongest and weakest today between branches and the contact centre?" | Shows you think about the hand-off, which the role owns, and the answer tells you what B8 should lead with |
| "What would you want the monthly complaints report to change in the first six months?" | Ties to the reporting duty and reveals what the manager actually reads |
| "Where do you expect self-service to do most for complaints by 2028, and where not?" | Brings the 40% target into the conversation in the manager's terms |
| "How does this role fit with the digital teams and with the timing of the hub consolidation?" | Tests your read of the 2027 plan and surfaces dependencies early |
| "What would make you say, a year in, that this hire had been the right one?" | Asks the manager to define success in their words, which you can then rehearse against |

---

# Round 3 — Panel of two branch managers, 60 minutes, includes a 20-minute case, scored on the four values

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored against Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Highest. The recruiter said the panel is the values round and they score against the four values | One story per value where a quote carries one; a selection scaffold where none does; "we" for context, "I" for contribution |
| Case / Strategist | The 20-minute complaint escalation case, plus strategy questions | High. The recruiter named a 20-minute case, and the panel prior blends top personas | Say the framework aloud, state a hypothesis early, challenge one premise |
| Peer Evaluator | Branch managers pricing what you cost them and give them | Medium. The role coaches branch supervisors, so these two are likely the people the role works alongside; that is this pack's reading of the loop, not something the recruiter said | Reciprocity framing; propose seam principles rather than a seam |
| Skeptic | Gaps in the background | Lower. Rounds 1 and 2 carry most of it, but a panel can still probe | Reuse B1's acknowledgment and plan |

## Question bank — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | Members First, Always. Selection scaffold: pick a decision where a member's interest and a rule or a number pulled apart; it needs the member's stake, the pull the other way and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is "I handled the branch's formal complaints log," at its own scope, or how you would decide | No quoted sentence carries a member-side decision, so this is a scaffold. VAL because it scores the value by name |
| C2 | "Tell me about a time you made something clearer for a member or a colleague." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | Plain Words, meaning that if a member needs it explained twice, the wording is at fault. Selection scaffold: pick something you explained or reworded, what was unclear and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is training new tellers on the escalation script, at that scope. Answer slot: if any of the script's wording was yours to change, say what and why; if it was not, say so plainly | The quote touches a script but shows nothing about wording, so it is a scaffold with a slot. VAL because it scores the value by name |
| C3 | "Tell me about a time you weighed what a branch's town needed against what the numbers said." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." — your message | Neighbours, Not Numbers, meaning every branch is part of its town. Selection scaffold: pick a decision with a named local stake, the figure pulling the other way and what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is your three years as a branch supervisor, at its own scope, or how you would weigh it. Two branch managers will hear this one with the hub consolidation in mind | No quoted sentence carries a decision between a town's needs and a figure, so this is a scaffold. VAL because it scores the value by name |
| C4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | Own the Fix, meaning whoever finds the problem keeps hold of it until it is solved. The beats the quote states: the branch's formal complaints log, handled by you. Answer slot: if any complaint stayed with you until it was solved, say which, what you did and where it ended; if the log did not work that way, or none did, say so plainly and describe how you handled the log | The quote carries the log but not a case that stayed with you, so the further beat is a slot. VAL because it scores the value by name |

## Question bank — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | The 20-minute case: "A member comes into a branch upset about a charge they dispute. The supervisor handles it on Monday. The member then phones the contact centre twice and is told different things, and now puts the complaint in writing. What do you do?" | CASE | [generic] | Say the structure aloud first. Clarify: what the member wants, what each channel told them, what is on record, which deadlines the complaint process sets, and whether anything marks this member as needing extra care. Objective in plain words: one owner, one record, one clear answer the member does not need explained twice. Approach: the owner keeps hold until it is solved, the story is checked across both channels, the reply is in plain words and says what happens next. Then root cause: why two answers, what changes. Metrics: time to resolve, repeat contacts. Risks: the hand-off between channels. Challenge one premise respectfully. This asks about no past, so the guidance makes no claim about yours | The recruiter named a 20-minute escalation case. Generic because the scenario is a pattern for the problem, not Ashgrove's own case |
| C6 | "A supervisor at one branch escalates almost everything to you at once, and another almost never escalates. How do you coach each?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | Clarify before coaching: what the cases actually show for each, and what each supervisor says makes escalation hard. Then a principle for both, one rule for when to escalate and when to keep hold, with a conversation each. Metric: repeat contacts and time to resolve by branch. Concede that you would want the data first. The nearest your material carries is training new tellers on the escalation script, at that scope, and it is not coaching supervisors | A live problem from the JD's coaching line, and a case the branch managers will recognise. CASE because it asks about no past |
| C7 | "Eight branches are due to become five hubs over 2027. What happens to complaints, and what would you watch?" | CO | [grounded] | Bring the one fact, then diverge with a reason. Thesis: complaints are an early signal of what the change does to members, ahead of footfall. Watch volumes and resolution times by branch before and after, repeat contacts and which complaints move to digital. Neighbours, Not Numbers is the value at stake, so name what local knowledge a hub could lose. Concede that you have no Ashgrove data and would start with theirs. Do not recite the brief | The hub change touches the panel's own branches. CO because it tests altitude on the strategy |
| C8 | "An app-only bank is quicker than we are. What does a member's complaint experience have to be for them to stay?" | CO | [grounded] | The brief names app-only banks as the main competitive pressure. Answer from the member's side of the counter: a complaint heard once, owned by one person, answered in plain words. Speed matters, but a fast wrong answer is a second complaint. Say what you would measure, such as time to resolve and repeat contacts. Concede what you do not know about their members | Ties the competitive frame to complaints, where this role sits. CO with a values lens |

## Question bank — Peer Evaluator and Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C9 | "Where is the seam between a branch manager and you when a complaint goes wrong, and what happens when we disagree?" | CASE | [generic] | Offer seam principles, not a pretended seam: who keeps hold of the member, who decides the fix, who tells the member, and how disagreement gets settled. Reciprocity: what you would give the branch manager, such as visible complaint trends for their branch. For the disagreement, a selection scaffold: pick a time you disagreed with an equal, what each side wanted and how it ended. If no such time comes to mind, say so plainly, then say how you would handle it | The panel are the people the role works alongside, so the seam is the likeliest peer probe. CASE with a Peer delivery |
| C10 | "You'd be coaching supervisors across branches and a contact centre you haven't worked in. Why would they listen?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." — your message; "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | Hold what the quotes carry: three years as a branch supervisor, at its own scope. Concede: "I haven't worked in a contact centre." Then a plan: ask supervisors what makes an escalation hard before coaching anyone, and learn the centre's side. Do not claim authority you have not been given. Hold through two follow-ups | The panel's version of B1, from people who supervise supervisors. JD with a Skeptic delivery |

## Values / principles cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold at C1. Nearest material, F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Nothing in it shows a member-side decision, so if no time comes to mind, say so plainly |
| Plain Words | If a member needs it explained twice, the wording is at fault | Scaffold at C2. Nearest material, F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script." It shows training on a script, not wording, so the wording question is a slot |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold at C3. Nearest material, F1: "6 years in retail banking, the last 3 as a branch supervisor." It shows the branch role and nothing about a local decision, so if no time comes to mind, say so plainly |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Mapped at C4 to F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The log is the beat the quote states; a case that stayed with you is a slot |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What could a new complaints lead do in their first month that would genuinely help your branch?" | The reciprocity question for a peer panel: it asks what you can give, not only what you need |
| "Which escalations cost your supervisors the most time today?" | Shows you start from the supervisors' side, and the answer is your first coaching target |
| "As eight branches become five hubs, what do you most want complaint handling to protect?" | Brings Neighbours, Not Numbers into the conversation on the panel's own ground |
| "When a complaint goes wrong in your branch, what do you wish had happened sooner?" | Gets a real example you can reflect in the case and in later conversations |
| "How would you like to hear about complaint trends from this role, and how often?" | Ties the monthly reporting duty to the panel's needs and shows you design for the reader |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | A7, C5 |
| Own the member complaints process end to end across branches and the contact centre | A6, B1, B8, B9, C5, C10 |
| Report monthly on complaint volumes and resolution times | B5, B8 |
| Coach branch supervisors on escalations | B6, C6, C10 |
| Confident presenting to senior leaders | A6, B2 |
| Comfortable with Excel reporting | B5 |
| Work with digital teams on self-service journeys | B3, B7, C8 |
| Published values, all four | C1, C2, C3, C4 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log, not an across-branch process. A7's and C4's slots stay inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The material says a formal complaints log and does not show what governed it. A7's slot asks only what governed the entries, if you know |
| Reported on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: you built the monthly spreadsheet your regional manager uses. The material does not show its contents. B5's slot asks only what it held |
| Built Excel reporting | Inflated form of F6 | F6's quote at its own scope: a spreadsheet. B5's slot asks only which tool |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: you trained new tellers on the escalation script. B6's slot asks only who you trained and how |
| Wrote the escalation script | Inflated form of F7 | F7's quote says "our escalation script" and that you trained tellers on it. C2's slot asks only whether any wording was yours to change |
| Worked in a contact centre | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description you pasted; the four values copied on 20 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; the four strategy points from the July 2026 brief the recruiter sent; your background message. No dossier was present.

Searches and fetches sent: none.

Loop: the recruiter's email establishes it, naming three sessions and for each who runs it and what it holds. It also says the panel is the values round, so a values-style round is detected. The interviewers beyond their roles are unassigned.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values page names all four values, which fix the values cheat sheet and C1 to C4 |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The July 2026 brief points you supplied fix the grounding brief and B7, C7 and C8 |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names are assigned, so there is no query to form, and the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewers' names, once assigned → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each one's own path
- The full text of the July 2026 strategy brief → the grounding brief rests on four points you supplied, and the full text could sharpen B7, C7 and C8
- An answer to the F2 slot, on what governed the entries in the log → F2 can move from discovery to a grounded bridge, and A7 can be rewritten around it
- An answer to the F5 and F6 slots, on what the spreadsheet held and which tool built it → F5 and F6 can move from low confidence, and B5 can be rewritten around it
- An answer to the F9 slot, on any digital or self-service work → B3 can become a story-mapped answer
- A copy of the spreadsheet itself with figures removed → the artifact that would raise F5 and F6 from low confidence, and the thing a prober would ask to see
- The recruiter's guidance on the 20-minute case, such as its format and materials → C5 can be rebuilt around the real shape
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, covering strategy context, any named interviewer's public talks, role-family loop reports and recent organisation news → a fuller grounding brief and sharper CO questions. Say the word and I will run it
- A `tuesday-dossier.md` from a prior job-underwriter run, if you have one → verified evidence and a named lead objection, so this pack's weak areas carry an agreed strategy rather than an inferred one
