# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager, running Saltmarsh's single 60-minute interview (see the loop table under Persona weights).
**Built from:** your JD and background as you gave them, plus research at the default tier (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Every question carries one of each.

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth |
| CASE | Hypothetical or live problem: structure and reasoning |

Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours. Either branch is a good answer.

## Fit snapshot

Your sentences are quoted exactly, from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your words stay at the sentence's scope: "For the last two years I ran the weekly content-drop calendar for our main title." The pack's observation is that your material shows one title's weekly drops, not event calendars across two titles. Answer slot: the JD's "two of our mobile titles" makes a probe likely. If you ever ran more than one calendar, say how it worked, in your own words; if you did not, or it was not yours, say so plainly and stay with the main title's calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team" — your message | low | [inferred] | discovery | The calendar sentence touches this requirement without showing who you worked with. "Never led a team" is yours and stays at its scope: it is a statement about leading, and the material is silent on coordinating. Plain acknowledgment, if led comes up: "I've never led a team." Answer slot: if you worked with design, art, engineering or community people on those drops, say who and what that looked like, without calling it leading; if some of those disciplines were not involved, or it was not yours to coordinate, say so plainly and return to the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your words: "I presented the monthly retention numbers to the studio head." The pack's observation is that your material shows presenting, monthly, not a post-event review and not ownership of the KPIs. Answer slot: if any numbers you presented came from looking back at a content drop, say which and what the look-back found; if none did, or you did not build the figures, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your words: "I wrote the release checklist our QA team still uses." The pack's observation is that your material says wrote, not managed at each release. Answer slot: if you also ran the checklist at release time, say how, in your own words; if you did not, or that was QA's or someone else's, say so plainly and stay with writing it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | discovery | Your words: "For four years I was an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Your material does not say whether the main title was a live-service game, and a years-of-experience requirement is likely to be read literally against the title "associate producer" (a reading, not a gate). Answer slot: if the main title was a live-service game, say so and what made it live; if not, say so plainly |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap in the sentence. Lead with it in its own terms: you ran it, weekly, for two years, on the main title. Expect a probe, because nothing inspectable stands behind it yet |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in the sentence. Lead with it in its own terms: monthly retention numbers, presented to the studio head. Expect a probe on how the numbers were counted (D1) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A written document that another team still uses touches this requirement; it does not show its length or readers beyond QA. Answer slot: if asked for an example of your writing, name one document you wrote and who read it; if the checklist is the only one, say so plainly |
| F9 | Not in the JD, which is silent on in-app purchases. Saltmarsh's September 2026 announcement moves Tidepool Tactics and Lantern Row to a season-pass model (see Sources) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work, and nothing added to make the gap feel smaller |

## Reading the interviewer

Public professional footprint only. Nothing else was found, so no style or personality inference is made.

| Observation | Source | Provenance | What it means for you |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games; previously a QA lead at a console studio | Search result for the GDC 2026 talk page (snippet only) | [grounded] | QA and release vocabulary is his native language. Expect release-decision probes (A2, E2) |
| GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | Same search result (snippet only) | [grounded] | Expect questions that test announced versus built: B3, A5. The company's second value says the same thing in different words |
| Mirror opportunity, shared vocabulary: his QA background and your sentence "Wrote the release checklist our QA team still uses" (F4) | His path from the row above; your sentence from F4's evidence cell | [grounded] | Use the checklist sentence at its own scope when a release-discipline question arrives. No shared jump is claimed, since your material shows no move out of QA |
| No self-described interview style, other talks or writing turned up | Searches listed in Sources | [grounded] | Persona weights below rest on the loop and the relationship, not on his style |

## Persona weights

First, what the loop looks like. A loop source (Saltmarsh's careers page, fetched) establishes it.

| Loop fact | Source | Provenance |
|---|---|---|
| Every loop is a recruiter call, then the Outage Hour | saltmarshgames.com/careers/interviewing | [grounded] |
| The Outage Hour is a single 60-minute interview with the hiring manager | same page | [grounded] |
| It has two parts, in this order: a live-incident tabletop on a simulated outage during a live event, then a values conversation | same page | [grounded] |
| There is no take-home | same page | [grounded] |
| Three published values: Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener | saltmarshgames.com/values | [grounded] |

A values-style round is therefore detected, so the pack includes the values cheat sheet. There is no declared deliverable, so there is no build section. This pack prepares the Outage Hour only; the recruiter call is not covered.

| Persona | How it shows up here | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | The tabletop: a simulated outage during a live event, then follow-ups | Highest, 5 questions. The hiring-manager prior is Case plus Skeptic, and the page makes the tabletop the first half of the hour | Clarify, then objective, who you pull in, message, metrics, risks. Think aloud. Challenge one premise politely |
| Values / Behavioral (B) | The second half: a values conversation against three named values | Highest, 5 questions. The page says it is guaranteed, and it is a scored conversation | One story or one honest scaffold per value. "We" for context, "I" for what you did |
| Skeptic (C) | Quiet probing of the gaps, from the hiring-manager prior | Mid, 3 questions. Your two stated gaps (F9 and "Never led a team") are the likeliest material | Rehearse the single likeliest objection (C1) until it is boring. Hold, then concede, specifically |
| Data-Driven Prober (D) | Retention numbers probed to their assumptions | Mid, 3 questions. Retention is a JD requirement and you present those numbers | Say how each figure was counted, or say plainly that you do not know |
| Pressure (E) | Time-boxed challenges, "how much was actually you" | Low-mid, 2 questions. A tabletop on an outage invites time pressure, but no source says the interviewer is a stress style | Pause, restate, hold through two follow-ups, concede only what is true |
| Conversational (F) | Opening biography and casual company questions | Low, 2 questions. Casual questions are still scored | A 90-second arc from your own sentences |

Peer Evaluator is left out: the page names a hiring-manager interview, and no peer round is documented. If your relationship to the interviewer differs, tell me and the weights change.

## Question banks

### A. Case / Strategist (tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The event is live and players can't claim their rewards. Community is already seeing complaints. What do you do in the first fifteen minutes, and what is the first message players see?" | CASE | [generic] | Clarify first: what is broken, who is affected, since when, whether it is getting worse. State the objective: stop harm to players, then restore. Name who you pull in using the JD's own list: engineering to diagnose, community for player voice, design and art only if content must change. Say the first player message aloud: what is known, what is not, when the next update comes, nothing promised that is not built. Close with what you would record for the post-event review. The question needs no claim about your past, so the guidance makes none | The page puts a live-incident tabletop first. CASE because it scores structure; it also scores F2's team list and F8's written communication |
| A2 | "Engineering says a fix could ship in two hours. QA wants a full regression pass first. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Clarify what the fix touches and what the failure costs players against what a skipped check could cost. Lay out options (ship now, wait for the full pass, a staged rollout), name who decides and who you consult, pick one, and say what would change your mind. You may mention the checklist at the sentence's scope: "I wrote the release checklist our QA team still uses." Answer slot: if a checklist step was ever shortened or waived for a release you worked on, say which and who decided; if that never happened, or was not yours to decide, say so plainly and reason from principle about which steps you would hold | F4 is your one piece of evidence on the JD's release-checklist line, and the interviewer's background makes this the likeliest place it is tested. CASE because it is a live decision |
| A3 | "The event has ended and players are engaging less than after the last one. Build the post-event review: what goes in it, and which KPIs do you report?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head" | Clarify what "less" is measured against. Structure: the event's goal, what was planned against what shipped, the KPI set with definitions, what counts as a finding rather than noise, actions with owners. Use your sentence at its scope: "I presented the monthly retention numbers to the studio head." Name the weakest assumption in the comparison before the interviewer does. Answer slot: if any numbers you presented came from looking back at a content drop, say which and what the look-back found; if none did, or you did not build the figures, say so plainly and stay with presenting them | The JD has you own the post-event review (F3), and F7 is your retention evidence. CASE for delivery, JD for content |
| A4 | "From February 2027 our two titles share one events calendar and one live-ops group. What do you need to know first to sequence events across them?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify: what the two player bases share, who owns each slot, what the rules are when events collide. When they collide, the company's first value says the players win, so say how you would decide in that spirit. Anchor on your sentence at its scope. Answer slot: the JD says two titles, so expect a probe. If you ever ran more than one calendar, say how it worked, in your own words; if you did not, say so plainly and say how you would learn it. Use the news to show you read it; do not recite it | F1 meets the September 2026 announcement here. CO because it uses current strategy, CASE in delivery |
| A5 | "Art for tomorrow's event is two days late, and community has already teased it. What now?" | CASE | [generic] | Clarify what exactly was teased. Lay out the options: move the date, cut scope, ship in stages. Choose one and say what you would tell players: what is built, what is not, when you will say more. Then say what you would change about how teasers get cleared. No claim about your past | Tests the second value, "we announce what is built, not what is hoped", inside a case. F2 is the JD line it exercises |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you left a process or a checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4, with only the beats the sentence states: you wrote the checklist, and QA still uses it; tell them in your own words. Answer slot: if there was an earlier version or a problem it solved, say what, in your own words; if there was none, or the checklist grew from others' work, say so plainly and stay with writing it and QA still using it | The third value is "Leave the Build Greener", and its published meaning names the checklist. F4 is the only row that maps |
| B2 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a time a scheduled drop, or its content, ran against what players were experiencing. It needs a named stake, what you decided and who else was in the room, and what players saw. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I ran the weekly content-drop calendar for our main title for the last two years", or how you would decide | The first value, "Players Before Plans", is stated as exactly this tension. No sentence of yours carries a disagreement, so it is a scaffold, not a story (F6) |
| B3 | "Tell me about a time you had to choose between saying what you hoped to ship and saying only what was built." | VAL | [generic] | Selection scaffold: pick a status update, announcement or note where the two diverged. It needs the audience, the pull to say more, the line you chose, and what happened next. If no such time comes to mind, say so plainly, then say how you would handle it | The second value, "Ship the Patch Not the Promise", and the interviewer's public talk make this the likeliest values question. No row of yours carries it |
| B4 | "Tell me about a time you had to tell leadership something they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Beats the sentence states: monthly, retention numbers, the studio head. Answer slot: if any month's numbers were unwelcome, say what you said and what happened next; if none were, say so plainly and describe how you presented them. The pack does not supply an ending | F7 is the only row near leadership communication. VAL because it scores whether the hard truth landed |
| B5 | "Tell me about a time you disagreed with engineering or design about what would go into a drop." | VAL | [generic] | Selection scaffold: pick a time the stake was named, each side's position is clear, you can say what you proposed and whose call it was, and the relationship was intact after. If no such time comes to mind, say so plainly, then say how you would handle it | The JD's team-coordination line (F2) raises this. Scaffold because no sentence of yours carries a disagreement |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases"; "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | **Highest-ROI prep in this pack.** Hold-then-concede. Concede first and plainly, in your own sentence: "I haven't worked on a game with in-app purchases." If leading comes up: "I've never led a team." Then say what you bring, at its scope: "I ran the weekly content-drop calendar for our main title for the last two years" and "I wrote the release checklist our QA team still uses." Then a ramp plan, said as a plan: what you would ask to see and who you would ask in your first weeks. Hold through two follow-ups: do not call the gap small, and do not claim a past you do not have | F9 is the likeliest objection: both titles are moving to a season pass, and you have said you have not worked on purchases. This is a prediction (the JD itself does not mention purchases), so ask the recruiter whether it will come up. JD because it scores the listed job, gaps included |
| C2 | "This role coordinates design, art, engineering and community on every update. Who did you work with on your weekly drops?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Never led a team" | Start with the sentence at its scope. Answer slot: if you worked with design, art, engineering or community people on those drops, say who and what that looked like, without calling it leading; if some of those disciplines were not involved, or it was not yours, say so plainly and return to the calendar. If led comes up: "I've never led a team." | F2 is the thinnest row against a JD line that names four teams. EXP in delivery, JD in content |
| C3 | "Why leave puzzle games for us, and why now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | Answer slot: the pack does not know your reason, so give your real one in your own words. Add one thing about Saltmarsh's titles or published values that you can speak to truthfully. Do not use a reason you would not repeat under a second question | Motivation consistency is a core Skeptic score. F5 is the row it presses on |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how those monthly retention numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Start at the sentence's scope: "I presented the monthly retention numbers to the studio head." Then four slots, in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | F7 is your headline metric evidence, and every such claim gets a defend-the-number question. EXP because it tests attribution |
| D2 | "After a limited-time event, which retention measure would you report, and what would you compare it against?" | JD | [generic] | Pick one measure and define it aloud. Choose the baseline and say its weakness. Say what you would not conclude from it. No claim about your past | The JD's retention requirement (F7), as a live problem |
| D3 | "The retention number says the event worked, but the community says it felt bad. Which do you believe?" | CASE | [generic] | Do not pick a side first. Ask what each measures and over what period, say how you would reconcile them, and say what you would report. The company's first value says players win when they disagree with the plan, so do not dismiss the community signal | Joins F3's KPI ownership to the first value. CASE because it has no single right answer |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has already run live events with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | Pause, restate the question. Concede first: "I haven't worked on a game with in-app purchases." Then hold on what your sentences carry: "I ran the weekly content-drop calendar for our main title for the last two years", "I wrote the release checklist our QA team still uses", "I presented the monthly retention numbers to the studio head." Add the ramp plan from C1 as a plan. Claim no edge over the other producer. Hold through two follow-ups by returning to those sentences | F9 and F1 under time pressure. JD because it scores the listed job |
| E2 | "That checklist — how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold on the sentence: "I wrote the release checklist our QA team still uses." Answer slot: if others shaped it, say who and how; if you wrote it alone, say so plainly. Do not add detail to make it larger | F4 is a CV-style line with nothing inspected behind it, so the attribution probe is the likeliest pressure. EXP because it tests precision |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc using only these beats: four years as an associate producer at a puzzle-game studio; for the last two, the weekly content-drop calendar for the main title; the release checklist QA still uses; the monthly retention numbers to the studio head. Finish on why live operations, in your own words (answer slot: your real reason). Add nothing to the sentences | A casual opener that is still scored. F5, F6, F4 and F7 supply the beats |
| F2 | "Have you played Tidepool Tactics or Lantern Row? What would you change about their events?" | CO | [generic] | Play at least one before the interview if you can. Say honestly which you have played. If neither, say so plainly and say what you would look at first. Name one real observation from your own play; do not invent one | The two titles are named in the September 2026 announcement (see Sources). CO because it is homework depth |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, B2, F1 |
| Coordinate design, art, engineering and community teams on each update | A1, A5, B5, C2 |
| Own the post-event review and the KPIs it reports | A3, D2, D3 |
| Manage the release checklist with QA | A2, B1, E2 |
| 3+ years producing live-service games or apps | C3, E1, F1 |
| Experience running a content calendar | A4, B2, F1 |
| Comfortable with player-retention metrics | A3, B4, D1, D2, D3 |
| Clear written communication | A1, A5. No dedicated question: the interview is spoken and there is no take-home, so this is tested through the player message in A1 |

## Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | No row carries a story (B2). Scaffold: pick a time a scheduled drop ran against what players were experiencing, with a named stake and a decision. If none comes to mind, say so plainly, then give the nearest thing your material carries or how you would decide |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No row carries a story (B3). Scaffold: pick a time you chose between saying more and saying only what was built. If none comes to mind, say so plainly, then say how you would handle it |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses". Tell only what the sentence states (B1) |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You came into live ops from QA lead at a console studio. What from that do you still reach for when you plan an event?" | Ties to his public path, and invites a story instead of a rehearsed answer |
| 2 | "Your GDC talk argued that a live team is judged by whether its patch notes describe what shipped. How does your team check that today?" | Shows you read him. Ask it only if you have read the talk yourself; this pack saw only its summary |
| 3 | "From February the two titles share a calendar and one live-ops group. Where would this role sit, and what changes first?" | Shows you read the September 2026 news, and clarifies a JD that still says two titles |
| 4 | "What has a post-event review changed in the next event? Can you give me an example?" | Tests whether the KPIs the JD gives this role actually steer anything |
| 5 | "What does the Outage Hour reward most, and what do candidates most often get wrong in it?" | Asks for the scoring directly, and is an honest question for a format they run every time |
| 6 | "What would you want someone in this role to have learned by day ninety?" | Turns C1's gap into a plan on their terms, without volunteering a claim |

## Prohibited claims

Not coached in this pack, because your material does not carry them. Built from your fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team | Negative you stated, F2: "Never led a team" | The plain acknowledgment: "I've never led a team." No slot. The question of coordination is separate and stays an answer slot in C2 |
| Worked on a game with in-app purchases, or monetization experience | Negative you stated, F9: "never worked on a game with in-app purchases" | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a ramp plan, as a plan |
| Planned and ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material shows the main title's weekly drops, not two titles' event calendars. A4's slot stays inside the calendar you ran |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material shows presenting, not owning. A3's slot asks only about what you presented |
| Managed the release checklist with QA at each release | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says wrote, not managed. A2's slot stays with the checklist you wrote |

## Sources

Provided documents: the JD and your background, as you gave them in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches sent:
- "Saltmarsh Games values" returned https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games mobile studio news strategy" returned https://saltmarshgames.com/news/project-larkspur (snippet only: September 2026, Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and retires per-title event teams in favour of a single live-ops group)
- "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise (snippet only; the page is on a host I could not confirm as the conference's own, so read the talk yourself before leaning on it)

Fetches sent:
- https://saltmarshgames.com/careers/interviewing
- https://saltmarshgames.com/values

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet, B bank: three values by name |
| 2. Saltmarsh Games interview process, live ops | yes | Loop table and persona weights: one Outage Hour, tabletop then values, no take-home |
| 3. Saltmarsh Games strategy and recent news | yes | A4, F2, reverse question 3 and F9. Snippet only, not fetched, because both fetches went to targets 1 and 2 |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Interviewer read and reverse questions 1 and 2. Snippet only, not fetched |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias Wrenfield is the hiring manager running the Outage Hour → persona weights and the interviewer read confirmed or reweighted
- The recruiter's guidance on the Outage Hour, such as the event type or title the tabletop will use → A1 to A5 tuned to it, and any focus areas covered
- How many hours you have before Friday → a prioritized prep schedule sized to it
- Your answers to the answer slots in F1, F2, F3, F4, F5 and F8 → those rows move from discovery or transferability toward story-mapped answers, and the matching bank cells follow
- A redacted copy of the release checklist or a retention report you presented → F4 and F7 move from medium toward high confidence
- Which of Tidepool Tactics or Lantern Row you have played → F2 in the F bank becomes a story-mapped answer
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a company strategy brief, the interviewer's talk read in full, and role-family loop reports; say the word if you want it
- A tuesday-dossier.md from job-underwriter → the highest-ROI objection becomes evidence-derived rather than inferred, weak areas gain strategy constraints, and prohibited claims arrive pre-checked
