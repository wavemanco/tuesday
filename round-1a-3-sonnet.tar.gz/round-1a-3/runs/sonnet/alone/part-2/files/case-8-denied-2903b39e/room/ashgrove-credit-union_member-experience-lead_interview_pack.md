# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Three rounds on 29 November 2026 (loop mode): R1 recruiter, 30 min; R2 Head of Member Services (your future manager), 45 min, mostly behavioural; R3 panel of two branch managers, 60 min, including a 20-minute complaint-escalation case, and scored against the four published values. No interviewer names yet, so there is no interviewer read; persona weights come from the relationship priors and the recruiter's own description of each round.

## How to use this pack

- Personas are how a question arrives; types are what it scores. Types: VAL (values or behavioural alignment), EXP (does your background survive scrutiny), JD (the stated role and its gaps), CO (company and strategy knowledge), CASE (a live problem from the role).
- Guidance is scaffolding, not a script. Wherever it says "answer slot", it is an instruction for the interview, not a question for me: it names what an interviewer is likely to probe and gives two honest branches. Answer from what you actually did; the second branch is always allowed to be "that wasn't mine, or it didn't exist".
- Every guidance cell rests on a sentence you wrote, quoted in its Provenance cell. If a cell has no quote, it makes no claim about your past.
- Question IDs run by persona across the whole pack (A, B for R1; C, D, E, G for R2; H, J, K, L for R3). Fit-snapshot rows are F1 to F9.

## Prep triage (9 days to 29 November)

1. D1 first: the contact-centre objection is the highest-ROI prep in this pack. It is the one most likely to be asked in some form in all three rounds. Say it aloud with all three follow-ups until it is boring. B1 is its first outing.
2. Write your own plain-words answers to the answer slots on F1, F3, F5, F6 and F7. Send them to me and I will regenerate the rows that draw on them.
3. D3 and L1: the senior-leaders objection. Settle your plan wording, in the future tense.
4. J1 (the 20-minute case): practise it timed, twice, using the structure in the cell. Then J3 and G1.
5. H1 to H4: choose your four values stories, or decide honestly that one has none.
6. A3 to A6 and A2: your own logistics answers and your own reason for Ashgrove.
7. One drill with me in the last two days.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process across branches, and nothing is inspected behind it. The words stay at the quote's scope: "I handled the branch's formal complaints log." Answer slot: expect a probe on what happened to a complaint once it was logged. If any stage after logging was yours, say which and how you handled it, in your own words; if the log was where your part ended, say so plainly and stay with the log |
| F2 | "and the contact centre" (from "across branches and the contact centre") — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap that wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan in the future tense and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The sentence says what you built and who uses it, not what it held. Answer slot: expect a probe on what the spreadsheet counted. Say what it counted and how each figure was counted, and the assumption behind it you would defend least; if it held something other than counts, say so plainly and say what it held |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other words: you built a monthly spreadsheet that a manager uses. Keep your word, "spreadsheet", and say Excel only if that is what it was. Nothing is inspected behind the line, so expect a probe on it |
| F5 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says "formal"; the JD says "regulated", and the sentence does not show whether those meet. Answer slot: expect a probe on what governed how the log was kept. If rules, deadlines or reporting duties applied to it, say which and what you did under them, in your own words; if you do not know, or none did, say so plainly and stay with the log |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The quote carries training new tellers on "our" script, not coaching supervisors, and not whose script it was. Answer slot: expect a probe on whom your training reached. If it reached anyone beyond new tellers, say whom and how; if it did not, say so plainly and stay with the tellers |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you have worked with a digital or product team on anything members used, say what and what part was yours; if you have not, say so plainly and say what you would ask them first |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then a plan, in the future tense, for how you would get ready. Never a claim to confidence you have not described, and nothing added to soften the sentence |
| F9 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | The length is met in your own terms. Your quote says retail banking and the JD says financial-services customer operations; use your term and let them connect it. A line with nothing inspected behind it, so expect a probe on the three supervisor years |

### Requirement coverage

| JD requirement | Fit row | Questions that cover it |
|---|---|---|
| Own the complaints process end to end across branches | F1 | A1, C1, D2, H4, J1, K1 |
| ...and the contact centre | F2 | B1, D1, J1 |
| Report monthly on complaint volumes and resolution times | F3 | E1, K2, J1 |
| Coach branch supervisors on escalations | F6 | C2, J3 |
| Work with digital teams on self-service journeys | F7 | C3, G1 |
| 4+ years in financial-services customer operations | F9 | A1 |
| Experience handling regulated complaints | F5 | B2 |
| Confident presenting to senior leaders | F8 | B3, D3, L1 |
| Comfortable with Excel reporting | F4 | E1, E2 |

## Grounding brief: Ashgrove's July 2026 strategy

From the brief the recruiter sent you, as you relayed it (I have not seen the brief itself):

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- Main competitive pressure: app-only banks.

What it means for this role, as the pack's inference and not Ashgrove's words: `[inferred]` complaints will increasingly start in digital channels, so the digital-teams line in the JD is likely the future of the job; `[inferred]` the hub consolidation will be on the minds of two branch managers in R3, whatever the case is about, so say nothing about which branches and no opinion on the decision; `[inferred]` a lending product for small businesses will bring a new kind of member and new kinds of complaint.

Differentiate, do not recite. The brief went to every candidate the recruiter spoke to, so quoting "40% digital by 2028" proves homework and nothing more. Bring that one consensus item, then one reasoned divergence: complaints are where self-service is most likely to fail a member first, so a visible human route should stay open for anything contested, even while simple status updates move to digital. The anti-pick: do not push every complaint into self-service to hit a channel number. Concede that for simple updates digital is faster for members. This is a thesis to hold with reasons, not a claim about your past. It is used in G1.

## Round 1: Recruiter screen (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport (A) | Friendly walk-through, motivation, logistics | High: a recruiter screen's prior; the risk is treating a friendly register as unscored | A 90-second arc; own logistics answers ready |
| Skeptic, light (B) | Quiet knockout checks on the biggest gaps | Medium: the JD names the contact centre and regulated complaints, and your own words state a contact-centre gap | Plain acknowledgment, then the plan; see D1 |
| All others | None expected in this round | Low: the recruiter says the case and the values scoring come in R3, behavioural depth in R2 | No bank |

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your journey. How did you get to where you are now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc on the beats those sentences state: six years in retail banking, the last three as a branch supervisor; within that, the complaints log you handled and the monthly complaints spreadsheet you built, which your regional manager uses. Tell it in your own words and end on why this role. What the first three years held is not in your material; if asked, answer from what you actually did | F9 is the evidence for the length requirement, and F1 and F3 are the rows a screen tests first; EXP because it tests whether the CV story holds together, in a conversational register |
| A2 | "What draws you to Ashgrove?" | CO | [grounded] | Use Ashgrove's own words, not slogans: two of its four published values, "Members First, Always" and "Own the Fix", and the direction in the brief, more member service on digital channels by 2028 and eight branches into five hubs over 2027. Give your real reason in your own words; your material does not mention credit unions, so say only what is true for you | A screen checks motivation consistency, and the values and brief are the grounding; CO because it scores whether the homework is current |
| A3 | "What is prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason in your own words, framed around what you are moving toward and not against anyone. Do not offer a reason that is not yours | A recruiter screen asks the reason for leaving; EXP because it tests a consistent personal story |
| A4 | "What is your notice period, and when could you start?" | JD | [generic] | Logistics slot: give your actual notice period and any real flexibility on it; do not offer a date you have not checked against your contract | A recruiter screen always covers notice; JD because it scores the role's terms |
| A5 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first; both are normal. The JD gives no band, so do not guess one for them. If asked for current or past pay, you can decline politely and return to what you are looking for; no figure is needed | A recruiter screen always covers pay; JD because it scores the role's terms |
| A6 | "Where are you based, and is getting to different branches workable?" | JD | [generic] | Logistics slot: say where you are based and what is workable, in your own words. The JD says the role spans branches and the contact centre and does not say where either is, so ask the recruiter where the role sits and how often visits are expected | A recruiter screen always covers location; JD because the role spans sites |

### Bank B: Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see contact-centre work in your background. How would you handle that part of the role?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Plain acknowledgment first: "I've never worked in a contact centre." Then what your material carries at its own scope: "I handled the branch's formal complaints log." Then a plan in the future tense and your own words: what you would do first to learn how the contact centre handles complaints and whom you would learn it from. The full hold-then-concede rehearsal is D1 | F2 is the stated gap and the likeliest probe even in a screen; JD because it scores a stated requirement |
| B2 | "The role asks for experience handling regulated complaints. What is yours?" | JD | [grounded] "I handled the branch's formal complaints log" | Say what you handled, in those words: "I handled the branch's formal complaints log." Answer slot: expect a probe on what governed how the log was kept. If rules, deadlines or reporting duties applied to it, say which and what you did under them, in your own words; if you do not know, or none did, say so plainly and stay with the log | F5 is where the JD's wording runs ahead of the quote; JD because it scores a stated requirement |
| B3 | "Which part of the JD would you be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level"; "Never worked in a contact centre" | Your material names two gaps. Pick the one you honestly rank higher, say it in one sentence with the plain acknowledgment ("I've never presented to anyone above regional level", or "I've never worked in a contact centre"), then give your plan to close it, in the future tense. Do not answer "nothing" and do not recite both | F8 and F2 are the stated gaps; JD because it scores honest self-assessment against the listed role |

### Reverse questions: R1

| Question | Why it lands |
|---|---|
| "Which of the JD's four responsibilities (the process, the monthly reporting, coaching, digital) would the first quarter focus on?" | Shows you read the JD as a priority list and gets you the first thing to prepare |
| "How is the complaints process split between the branches and the contact centre today?" | Takes the JD's own sentence seriously and begins closing your contact-centre gap |
| "What does the 20-minute case look like: a role-play, a written scenario, anything to prepare?" | Only the recruiter can say, and it changes how you rehearse J1 |
| "Who is on the panel, and which branches do they manage?" | A practical ask that unlocks names for the interviewer read |
| "What does the Head of Member Services most want the new person to fix first?" | Prepares R2, and signals you think in outcomes |

## Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (C) | Past-behaviour prompts | High: the recruiter says the round is mostly behavioural | Map a story only where a quoted sentence carries one |
| Skeptic (D) | Probes on the gaps | High: a hiring manager is buying capability and de-risking gaps, and your own words state two | Hold-then-concede; D1 is the deepest rehearsal |
| Data-Driven Prober (E) | Walks the one artifact you built | Medium: a manager who will rely on monthly reporting will test the spreadsheet | Say what it counted and how; own what you do not know |
| Case / Strategist (G) | One strategy-flavoured case | Low: the manager prior says case, but the recruiter says mostly behavioural | Clarify, then structure; see G1 |

### Bank C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you improved how something was done at work." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3's sentence: you built the monthly complaints spreadsheet, and your regional manager uses it; those are the beats it states. Answer slot: the question asks what prompted the change. If something was not working before you built it, say what, in your own words; if it was asked of you or simply something you set up, say so plainly and stay with the building | F3 is the nearest evidence of changing how something is done, and the JD's process-ownership line (F1) is the reason for the theme; VAL because the round is behavioural |
| C2 | "Tell me about a time you helped a colleague get better at handling something difficult." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F6's sentence: you trained new tellers, on "our" escalation script. Answer slot: if training followed a particular mistake or complaint, say what happened and what part was yours; if it was routine onboarding, say so plainly and stay with the training. Say whom it reached, and no one beyond them unless it did | The JD's coaching line makes this likely; F6 is the evidence and its limit is whom the training reached; VAL because it is behavioural |
| C3 | "Tell me about a time you worked with a team outside your branch to change something members used." | VAL | [generic] | Selection scaffold: pick a time you worked with a team beyond your branch (head office, regional, IT, product). It needs a named change, what you asked of them, and what happened for members. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would start with a digital team | The JD's digital-teams line raises the theme (F7); no quoted sentence carries it, so it is a scaffold; VAL because it scores behaviour |

### Bank D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't worked in a contact centre, and this role owns the process across the contact centre too. Why you?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | **Highest-ROI prep in this pack.** Limit first: claim no contact-centre knowledge, tools or numbers, and never say it is basically the same. Open plain: "I've never worked in a contact centre." Hold at the quotes' scope: "I handled the branch's formal complaints log" and "trained new tellers on our escalation script". Then a plan in the future tense: what you would do in your first weeks to learn how that side handles complaints, and from whom. Follow-up 1, "A branch log isn't a contact-centre queue": concede exactly, "That's fair. I don't know how your contact centre runs, and I would learn it before changing anything." Follow-up 2, "Why would that team follow you?": hold on the plan, learning first and listening to the people who do the work. Follow-up 3, "Branch people never understand us": concede specifically, "Some of that may be true of me, so I would ask your team to show me", and do not fold on wanting the role | F2 is the biggest stated gap and the JD's headline sentence includes it, so this question will arrive in some form; JD because it scores a stated requirement |
| D2 | "How much of that complaints work was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses"; "trained new tellers on our escalation script" | Say it at the sentences' own scope: you handled the log, you built the spreadsheet, you trained new tellers. The script is "our" script; say who set it and what part, if any, was yours. Hold through two follow-ups by returning to those three sentences; when asked what was not yours, concede it plainly and specifically | An attribution probe is the standard test of a CV; F1, F3 and F6 are the rows it tests; EXP because it tests what was actually yours |
| D3 | "The role has to be confident presenting to senior leaders, and you haven't presented above regional level. What is your plan?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Plain acknowledgment: "I've never presented to anyone above regional level." Do not claim a confidence you have not described. Then the plan, in the future tense and your own words: what you would ask this manager about the audience, and how you would rehearse your first presentation. The one adjacent fact you can state at its scope is that you built a monthly spreadsheet your regional manager uses | F8 is a stated gap that the manager owns; JD because it scores a stated requirement |

### Bank E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the monthly complaints spreadsheet you built. What did it track?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Open on the sentence: you built a monthly complaints spreadsheet that your regional manager uses. Answer slot: say what it counted, how each figure was counted, and the assumption behind it you would defend least; if it held something other than counts, say so plainly and say what it held. If you can show a version with no member data, offer to walk through it end to end | F3 and F4 both rest on this one sentence, and the JD's monthly-reporting line makes it the likeliest artifact to be probed; EXP because it tests the claim itself |
| E2 | "How comfortable are you with Excel? What is the most you have done in it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what is true: "I built the monthly complaints spreadsheet our regional manager uses", and say Excel only if that is what it was. Answer slot: if you used particular features, name them and what each was for; if it was simple, say so plainly and stay with what you built | F4 is a presentation gap on a single sentence; JD because the requirement is stated |

### Bank G: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "We want 40% of member service on digital channels by 2028. Where should complaints sit in that, and what should happen when a complaint starts in the app?" | CO | [grounded] | Clarify first: what counts in the 40%, whether complaints are inside it, how a member reaches a person today. Objective: the member's complaint resolved, without being asked to explain it twice. Approach: digital for status updates and simple matters; a visible human route for anything contested. Metrics: complaint volumes and resolution times, which the JD names. Risks: members who cannot or will not use the app, and the app-only banks the brief names. Use the grounding brief's thesis: the consensus is moving service to digital; your divergence is that complaints are where self-service fails first; your anti-pick is pushing every complaint into self-service to hit a number; concede that simple updates are faster digitally. Answer slot: if you have worked with a digital or product team, say what and what part was yours; if not, say so plainly | The strategy brief and the JD's digital-teams line (F7) both raise it; CO because it scores current strategy, with CASE delivery |

### Reverse questions: R2

| Question | Why it lands |
|---|---|
| "What does a good month of complaints reporting look like to you, and what would you want to see change in the numbers?" | The JD makes monthly reporting a core job; you learn how the manager reads it |
| "How are complaints handed between the branches and the contact centre today, and where do they get stuck?" | Own the Fix in practice: you start where the process breaks, and you show you know it spans both |
| "Which self-service journeys is the digital team working on first, and where do complaints sit among them?" | Ties to the 40% digital target and to the JD's digital-teams line |
| "How will the move to five hubs change the supervisors I would coach?" | Shows you read the brief and think about the people the role touches; ask it neutrally and take no position on the decision |
| "What support would a new lead get in learning the contact-centre side, and who should I spend time with first?" | Turns your stated gap into a plan and shows you intend to own it |

## Round 3: Panel of two branch managers (60 minutes, with a 20-minute case; the values round)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (H) | One probe per value | High: the recruiter says the panel is the values round and scores against the four | A mapped story where a quote carries one; a scaffold with its honest branch where none does |
| Case / Strategist (J) | The 20-minute escalation case, plus variants | High: the recruiter names the case and its length | Say the structure aloud before using it; clarify before answering |
| Peer Evaluator (K) | Seam and credit questions from managers whose supervisors you would coach | Medium: the role's coaching line touches their teams | Reciprocity framing; propose seam principles, not a pretended seam |
| Skeptic (L) | The presenting gap returns | Low: the panel is scored on values and the case, but gaps from R2 can come back | Plain acknowledgment, then the plan |

Pressure is not signalled here; if the case turns time-boxed, use D1's hold-then-concede.

### Bank H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] | Selection scaffold on Members First, Always: pick a time the easiest answer for the branch and the member's interest pointed different ways. It needs a named stake, the decision you made, and what you said to the member. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", at its own scope, or how you would handle it | The published value is the raising source; no quoted sentence carries a decision story, so it is a scaffold (F1 is the nearest row); VAL because it scores a published value |
| H2 | "Tell me about a time something had to be explained to someone twice." | VAL | [grounded] "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Plain Words: the sentences you can stand on are that you trained new tellers on "our" escalation script and that you built a spreadsheet your regional manager uses. Answer slot: if tellers needed the script explained twice and you changed how you explained it, or what the script said, say what and why, in your own words; if not, say so plainly and stay with the training | The published value is the raising source; F6 and F3 carry the nearest sentences, but neither says anything was explained twice; VAL because it scores a published value |
| H3 | "Tell me about a time a number and a neighbour pulled in different directions." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Neighbours, Not Numbers: the sentence carries that you spent three years as a branch supervisor. Answer slot: if there was a time the figures and what the town needed pulled apart, say what the number was, what the town needed and what you did, in your own words; if there was no such time, say so plainly and stay with the three years. Expect this one to carry weight, since the brief consolidates eight branches into five hubs; take no position on which branches | The published value is the raising source; F9 carries the only branch sentence; VAL because it scores a published value |
| H4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix: the sentence carries that you handled the branch's formal complaints log. Answer slot: if you followed a complaint to its end yourself, say what the problem was, what you did and how it closed; if the log was recording and someone else resolved, say so plainly and stay with the log | The published value is the raising source, and the JD's process-ownership line (F1) is the same idea; VAL because it scores a published value |

### Bank J: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member has raised the same complaint in branch twice. They have now phoned the contact centre. The branch says it is resolved; the member says it is not. Walk us through what you do." | CASE | [generic] | Say the structure aloud first. Clarify: what the member was told, what is recorded, what time limits or rules apply to this complaint (say you would check them before promising a date), whether the member needs extra care. Objective: the member's outcome, and an accurate record. Who keeps hold: one person holds it until it is closed. What the member hears: plain words, in two sentences, nothing needing explaining twice. Challenge one premise: who decides it is "resolved". Then the supervisor, with the aim of a better next escalation and not blame; the root cause; how it is counted in the monthly figures; and when you would raise it with the Head of Member Services. This question needs no claim about your past, so the guidance makes none | The recruiter names a 20-minute escalation case; the shape is from the JD (F1, F2, F3); CASE because it is a live problem, `[generic]` because it is a pattern and not Ashgrove's actual case |
| J2 | "Eight branches are becoming five hubs over 2027. How should complaints be handled so members do not feel forgotten?" | CO | [grounded] | The brief is the source for the eight-to-five plan; it does not say which branches. Talk about the complaints process, not the decision: a complaint should not depend on which building a member used; a member who has known one branch for years should not have to start again; keep one named owner per complaint through any change. Take no position on which branches, and do not speculate | The brief raises it, and two branch managers will hear it personally; CO because it scores current strategy, with CASE delivery |
| J3 | "A supervisor keeps escalating late, and by then the member is furious. How would you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | Structure: find out what is getting in the way before judging it; agree what late means; agree what earlier looks like in practice; follow up on the next real case. Answer slot: if any of your training or coaching reached supervisors, say whom and how; if not, say so plainly and stay with the tellers: "trained new tellers on our escalation script" | The JD's coaching line (F6); CASE because it is a live problem, and the quote is only for the one sentence of past it can carry |

### Bank K: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "A branch manager disagrees with how you handled a member's complaint in their branch. Where is the seam between you, and what happens next?" | CASE | [generic] | Propose seam principles: one person holds the complaint until it is closed; the branch manager knows the town and the member's history; you agree the facts first (what the member said, what is recorded) before you argue about the answer. If you still disagree, it goes to the Head of Member Services. This needs no claim about your past | A peer round is about seams; the JD's ownership line (F1) is the source; CASE because it is a live problem |
| K2 | "How would you report complaint numbers to branch managers without making it feel like a league table?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Neighbours, Not Numbers in practice: numbers to find the fix and not to rank, with the context of each branch's town beside each figure. The one sentence of past you can use is that you built a monthly spreadsheet your regional manager uses. Whether it ever compared branches is not in your material; if you know, say it; if not, say so plainly | The JD's reporting line (F3) and the published value meet here; VAL because it scores a published value |

### Bank L: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "How comfortable are you presenting complaint results to senior leaders when the news is not good?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then what you would do, in the future tense and your own words: say the number plainly, say what it means for members, and say what you are doing about it. Do not claim a past of delivering bad news you have not described | F8 returns in collegial packaging; JD because it scores a stated requirement |

### Values cheat sheet

Detected because the recruiter says the panel scores against the four values. The names are Ashgrove's, as you copied them this morning from ashgrovecu.org/about/values.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold at H1: a time the easy branch answer and the member's interest differed, with a named stake, a decision and what the member was told. If none comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F6: "trained new tellers on our escalation script". The sentence states the training and the script; whether anything was explained twice or reworded is H2's answer slot |
| Neighbours, Not Numbers | Every branch is part of its town | F9: "6 years in retail banking, the last 3 as a branch supervisor". The sentence states the branch and the three years; what the town needed against what the numbers said is H3's answer slot |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log". The sentence states the log; whether you followed a complaint to its end is H4's answer slot |

### Reverse questions: R3

| Question | Why it lands |
|---|---|
| "Which of the four values is hardest to live up to on a busy branch day, and why?" | Invites candour from people who live it, and shows you take the values as practice |
| "When a complaint is about your branch, what do you want the lead to do, and what not to do?" | Makes them the expert and shows you will work with branches, not around them |
| "What could a new lead do in their first month that would genuinely help your supervisors?" | The reciprocity question for a peer-style round |
| "As eight branches become five hubs, what should the complaints process protect for members who have known their branch for years?" | Ties to Neighbours, Not Numbers; it asks their view and takes no position |
| "How do you want complaint figures shared with your branch, and what would feel unfair?" | Surfaces the league-table worry before it becomes one |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation: the material says the branch's log, not the process across branches. The slots stay inside the log |
| Has experience handling regulated complaints | Inflated form of F5 | F5's quote at its own scope. The material says "formal", not "regulated"; B2's slot asks only what governed how the log was kept |
| Reported on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. E1's slot asks only what the spreadsheet counted |
| Coached branch supervisors | Inflated form of F6 | F6's quote at its own scope: new tellers. The slots ask only whom the training reached |
| Wrote or set the escalation script | Inflated form of F6 | The quote says "our escalation script". D2's slot asks only who set it and what part was yours |
| Has worked in a contact centre, or knows how one runs | Negative you stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Is confident or experienced presenting to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |

## Sources

Provided documents: the JD; the four values as you copied them this morning (20 November 2026) from ashgrovecu.org/about/values; the recruiter's email about the three rounds; the four points of the July 2026 strategy brief as you relayed them (I have not seen the brief itself); your background as you gave it in your message. No dossier. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the four names and their wording; the values cheat sheet and H bank use it |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email establishes the three sessions and who runs each; persona weights follow it |
| 3. Ashgrove strategy and recent news | skipped | The four brief points, from July 2026, already supply current priorities for the grounding brief, G1 and J2 |
| 4. Interviewer name and Ashgrove | n/a | No interviewer has a name yet, so there was no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your own answers to the answer slots on F1, F3, F5, F6 and F7 → those rows move from discovery or transferability to quoted stories, and C1, C2, D2, E1, B2 and J3 regenerate with your words
- A copy of the monthly complaints spreadsheet's column headings, with no member data → F3 and F4 can rise from medium to high, and E1 and E2 become story-mapped
- Your notice period, salary expectation, location and reason for moving → A3 to A6 are filled in your own quoted words
- The names of the Head of Member Services and the two branch managers → an interviewer read, persona weights tuned to each, and a reverse question tied to each person's path
- One email to the recruiter: the format of the 20-minute case (role-play, written scenario, anything in advance) and how the panel scores the four values → J1 and the values bank rebuilt around the real format
- The full strategy brief text → the grounding brief and G1 and J2 move from your relayed four points to the brief's own wording
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): Ashgrove's strategy and recent context, plus candidate reports on this kind of loop → a richer grounding brief, and any loop details confirmed or corrected. Offered once
- A tuesday-dossier.md from job-underwriter, if you have one → verified evidence and prohibited claims arrive from the underwriter, and the strongest objection is evidence-derived instead of inferred
