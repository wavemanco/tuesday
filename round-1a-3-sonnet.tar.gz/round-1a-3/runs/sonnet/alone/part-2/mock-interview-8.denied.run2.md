Quick status: the pack is written and I'm running a last check on it for a mislabelled cross-reference and stray brackets before I hand it over.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-8-denied-270455d2/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop from the recruiter's email, with persona weights taken from how each round is described, since no interviewers are named. No searches were run, because your pasted JD, values text and strategy summary already covered what they would have.

The highest-ROI prep is D1, in the Head of Member Services round: "You handled a branch's formal complaints log. This role covers the whole process across branches and the contact centre. What makes you think you're ready?" The pack has you hold what your own words carry and concede the contact centre by name. The same pressure returns at the panel in I1, on how much was actually you.

Say the word and I'll play the Skeptic on D1.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop mode, three rounds on 29 November 2026:** a 30-minute recruiter conversation; a 45-minute round with the Head of Member Services (your prospective manager, mostly behavioural); a 60-minute panel of two branch managers that includes a 20-minute complaint-escalation case and scores against the four published values. No interviewer has been named, so there is no interviewer read and the reverse questions are role-based. Persona weights rest on the recruiter's own description of each round.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words. All proposed wording in this pack is pending your approval, and nothing in it should be said unless it is true for you.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether what you have told us survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Ashgrove's altitude, from its published strategy |
| CASE | Structure and reasoning on a live problem from the role |

Question IDs run by round and persona: A and B are round 1, C to E round 2, F to I round 3. **The highest-ROI rehearsal in the pack is D1**, the question that tests whether a branch complaints log reaches the whole process across branches and the contact centre. It will be asked in some form. Rehearse it until it is boring.

Rows marked answer slot are instructions for the interview, not questions for you now. Where you answer one in this chat, I will fold it into the pack.

## Fit snapshot (shared across all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." The JD's end-to-end line makes a probe on who set the steps, and where complaints went after the log, likely. Answer slot: if any step in how a complaint moved on from the log was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says monthly, complaints, you built it, your regional manager uses it. It does not say what the spreadsheet counted. Answer slot: if it counted volumes or time taken to resolve, say which, in your own words; if it counted something else, or you are not sure how a figure in it was counted, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message; "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | transferability | Your sentence says you trained new tellers on the escalation script, and that you were a branch supervisor for three years. The JD's coaching is of supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you have also coached a supervisor or a peer through an escalation, say who and what; if not, say so plainly and stay with the tellers |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Say it in your own terms and let the interviewer draw the link: "I've spent six years in retail banking, the last three as a branch supervisor." A CV-style line with nothing inspected behind it, so expect a probe on what the six years held |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says formal complaints log. It does not say what governed that log. Answer slot: if the log was governed by external rules or timelines, say what, in your own words; if it was only the branch's or the bank's internal procedure, or you are not sure, say so plainly and stay with the log you handled |
| F7 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Never a claim to senior presenting |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, not which tool, and not what it did. Answer slot: if it was built in Excel, say so and what it did, in your own words; if it was another tool, or you are not sure which parts were yours, say so plainly and stay with the spreadsheet you built |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital work. Answer slot: if you have worked with an online or app team on any member journey, say what and which part was yours; if you have not, say so plainly and say how you would start |

No row is a gate: every requirement in the JD is experience or capability, none a licence, location, pay or schedule term.

## Grounding brief: Ashgrove's July 2026 strategy

The wording below comes from your message's summary of the strategy brief; the brief itself was not read.

| Strategy element | Where it appears in this pack | Provenance |
|---|---|---|
| "move 40% of member service to digital channels by 2028" | A2, E2, R2.5 | [grounded] your message |
| "consolidate eight branches into five hubs over 2027" | F4, H1, panel reverse questions | [grounded] your message |
| "launch a small-business lending product in Q1 2027" | No question depends on it; know it exists in case it comes up | [grounded] your message |
| "the main competitive pressure is app-only banks" | E2, as the reason the digital target exists | [grounded] your message |

## Persona tables (weights with reasoning)

### Round 1: recruiter, 30 minutes

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, motivation, logistics | High: the recruiter-screen prior is conversational with logistics, and the recruiter's email describes a plain 30-minute conversation | Rehearse a 90-second arc; treat the pay, notice, location and leaving questions as scored |
| Skeptic (light) | Knockout checks on the two visible gaps against the JD | Medium: the recruiter-screen prior includes light knockout checks, and F2 and F7 are the gaps a screener can see in the JD | Say the stated gap plainly, once, then move to a plan |

### Round 2: Head of Member Services, 45 minutes

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario stories, "tell me about a time" | High: the recruiter calls this round mostly behavioural | Where a quoted sentence carries a story, map it; where none does, choose from your own material, and say plainly if nothing fits |
| Skeptic | Probing whether branch experience reaches the whole role | High: the hiring-manager prior derisks gaps, and this is your prospective manager, so F1, F2 and F7 are where they would press | Rehearse D1 until it is boring: hold the log at its scope, concede the contact centre by name |
| Case/Strategist | Digital self-service and strategy | Medium-low: the hiring-manager prior favours cases, but the recruiter says mostly behavioural | Clarify first, then structure; bring one point from the brief, then one reasoned divergence |

### Round 3: panel of two branch managers, 60 minutes

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The 20-minute complaint-escalation case | High: the recruiter says 20 of the 60 minutes are a case | Clarify, name one owner, reach the member, record, then the pattern |
| Values/Behavioral | Stories scored against the four values | High: the recruiter says the panel scores against the values | One story or honest scaffold per value |
| Peer Evaluator | Seam between the complaints role and branches | Medium: branch managers sit beside the role, and the JD has the role coaching branch supervisors | Reciprocity: what you bring them, not only what you need |
| Pressure | Attribution probes | Low-medium: a panel can press on how much was yours | Hold through two follow-ups, then concede the specific limit |

## Round 1 question bank: recruiter

Proposed wording, pending your approval.

### A. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your career so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Story-mapped on F5: the beats the sentence states are six years in retail banking, the last three as a branch supervisor; tell them in your own words. Answer slot: one sentence on what draws you to this role; if it is not sharp yet, say what you want to find out | The recruiter's biography question is the most certain opener; F5 is what it rests on. EXP because it tests what you say about your own path |
| A2 | "Why Ashgrove?" | CO | [grounded] | Pick one published value or one line of the strategy summary that is true for you, and say why in plain words. Candidates: "Own the Fix", where whoever finds the problem keeps hold of it until it is solved; or "move 40% of member service to digital channels by 2028". Answer slot: the reason is yours; if neither fits, say what does | A motivation question in a friendly register is still scored. Makes no claim about your past, so it carries its label alone |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure or range, or ask for the role's band first. The pack supplies no number. If asked about your current pay, you may decline politely and bring the conversation back to the role's band | A recruiter screen carries a pay question; the only safe answer is your own |
| A4 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | Same reason as A3 |
| A5 | "Is the location and working pattern workable for you?" | JD | [generic] | Logistics slot: state your own constraints plainly, or ask where the role is based and how the week works before answering. The JD does not state location, so ask rather than assume | Same reason as A3; F-rows hold no location requirement because the JD states none |
| A6 | "What is prompting you to look at a move?" | EXP | [generic] | Logistics slot: give your actual reason, in one or two sentences, pointed at what you want next rather than away from your current employer. The pack supplies no reason | The reason for leaving is asked of every screen candidate |

### B. Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about the formal complaints you handled. What rules or timelines did you work to?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Start with what you stated: "I handled the branch's formal complaints log." Answer slot: if the log was governed by external rules or timelines, say what, in your own words; if it was only internal procedure, or you are not sure, say so plainly and stay with the log. Do not add rules you cannot name | F6 is the requirement the JD states and your material does not close; a screener will check it early. JD because it scores a stated requirement |
| B2 | "This role covers the contact centre too. You have not worked in one, have you?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Say it plainly: "I haven't worked in a contact centre." Then a plan, said as a plan: what you would want to learn first about how complaints arrive there. Stop after the plan; do not offer a substitute | F2 is a stated negative, so the plain acknowledgment is yours to give; rehearsed once, it stays short. JD because it scores the stated requirement |

## Round 2 question bank: Head of Member Services

Proposed wording, pending your approval.

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you made a call from the member's side of the counter." | VAL | [grounded] | Selection scaffold: pick a time that has a named member situation, the decision you made, and what it cost or risked; F1's complaints log is one place to look. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | Ashgrove's first published value, in its own words; this round is mostly behavioural. VAL because it scores behaviour against that value |
| C2 | "Tell me about a time you delivered an unpopular truth to someone senior to you." | VAL | [grounded] | Selection scaffold: pick a time with a named message, the person it was for, and how it landed; the monthly spreadsheet your regional manager uses (F3) is one place to look. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem, and F7 makes upward communication a theme of this loop. VAL because it scores a behaviour, not a requirement |
| C3 | "Tell me about the spreadsheet you built. What did it show, and who used it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3, with only the beats the sentence states: it is monthly, it is about complaints, you built it, your regional manager uses it. Answer slot: what it counted, and which tool it was in; if it counted volumes or time to resolve, say which; if you are not sure how a figure was counted, say so plainly. Name the assumption you would defend least before they do, if you know one | F3 and F8 rest on this sentence and nothing is inspected behind it, so it is probed. EXP because it tests what was yours |
| C4 | "Tell me how you trained the new tellers on the escalation script." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: you trained new tellers on your escalation script, which is all the sentence states. Answer slot: the JD asks about coaching supervisors; if you have also coached a supervisor or peer through an escalation, say who and what; if not, say so plainly and stay with the tellers | F4 is the closest evidence for the coaching requirement. EXP because it tests what you actually did |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You handled a branch's formal complaints log. This role covers the whole process across branches and the contact centre. What makes you think you are ready for that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Hold what the quote carries: "I handled the branch's formal complaints log." Follow-up one, on the contact centre: concede by name, "I haven't worked in a contact centre," then a plan said as a plan. Follow-up two, on what you would do first: listen to how complaints arrive before changing anything. Answer slot: if any part of the process beyond the log was yours to set, say which; if none was, say so plainly and stay with the log. Hold through two follow-ups by returning to the log, never by adding to it. Let the interviewer draw the inference | This is where the JD's lead requirement presses against F1 and F2, and the person asking would be your manager. JD because it scores the headline requirement |
| D2 | "This role presents to senior leaders. What is your experience of that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level."; "I built the monthly complaints spreadsheet our regional manager uses." | Say it plainly: "I've never presented to anyone above regional level." Then one quoted thing at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." Then a plan, said as a plan: how you would prepare for your first senior presentation. Do not describe a presentation you did not give | F7 is a stated negative; the JD's seniority line makes the question certain. JD because it scores a stated requirement |
| D3 | "Why you, over someone who has run a contact-centre complaints team? You have sixty seconds." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses."; "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold-then-concede. Hold: what is stated, at its scope, "I handled the branch's formal complaints log," "I trained new tellers on our escalation script," "I built the monthly complaints spreadsheet our regional manager uses." Concede: "I haven't worked in a contact centre." Do not claim to be better; say what you would bring and what you would learn, and stop | A time-boxed challenge on F1 and F2; the prospective manager is weighing the gap. JD, delivered under pressure |

### E. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "What have you done with digital teams on member self-service?" | JD | [grounded] | Answer slot: if you have worked with an online or app team on any member journey, say what and which part was yours, in your own words; if you have not, say so plainly and say how you would start | F9 is a silent row; the JD names the requirement and the manager owns it |
| E2 | "We want 40% of member service on digital channels by 2028. What does that mean for how we handle complaints?" | CO | [grounded] | Bring one point everyone prepared will bring: digital service is the answer to app-only banks. Then a reasoned divergence with its concession. Option one: simple, early-stage issues can be resolved digitally so staff time goes to hard cases; concession: you have not seen Ashgrove's complaint mix. Option two: anything a member calls a complaint keeps a clear route to a person, in plain words; concession: it may slow the digital target. Anti-pick: do not promise that all complaints go digital | A strategy question from the brief's lead target, and the JD names digital teams. CO because it scores fluency with Ashgrove's current direction |

## Round 3 question bank: branch-manager panel

Proposed wording, pending your approval.

### F. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "A member has complained three times about the same charge. The branch says it is resolved, the contact centre's note says it is not, and the member now wants to speak to someone senior. You own this from today. What do you do in the next hour, and what do you do about the pattern?" | CASE | [generic] | Structure it: what you would ask first (what the member wants, what they have been told and by whom, which note is current, which deadline or clock applies; ask which one, do not assume); name one owner, you; reach the member first, in plain words, with what happens next and by when; reconcile the notes; decide and record. Then the pattern: why three contacts without closure, and where in the route between branch and contact centre it broke. Challenge one premise respectfully: "resolved" by whose test? The question needs no claim about your past, so the guidance makes none | The recruiter says 20 minutes of this round is a complaint-escalation case. `[generic]` because it is a pattern for the problem, not a fact about Ashgrove |
| F2 | "The branch supervisor disagrees with your decision and says the member has banked with them for twenty years. What do you say?" | CASE | [generic] | Listen first. Separate the member's history from the facts of the complaint, and say both are real. Agree who owns what from here, and what the member will be told, in plain words. If the supervisor shows you something that changes the facts, change the decision, and say so. Offer a short debrief afterwards, as a coach and not a judge | The JD's coaching line (F4) set as a live disagreement, and the panel are branch managers. CASE because it asks for reasoning, not a past |
| F3 | "Complaint volumes from one town's branch have doubled in a month. Diagnose it." | CASE | [generic] | Clarify first: doubled against what, which complaint types, what changed that month (staff, product, an outage, a notice to members), one cause or several. Look at resolution times beside volumes. Talk to the branch before concluding; the town is not a row in a table. Say what you would decide, and what would change your mind | The JD's reporting line (F3) set as a diagnosis. CASE because it scores structure and a live decision |
| F4 | "We are going from eight branches to five hubs over 2027. How should complaints handling protect member trust through that?" | CO | [grounded] | Thesis: complaints from affected towns are an early signal, so give them a named owner and a plain-words explanation. Concession: you have not seen Ashgrove's own data. Anti-pick: do not offer to run all of it centrally. Use the brief's wording, not a guess at what is planned | The brief's hub move, put to branch managers it may touch. CO because it scores fluency with Ashgrove's current plan |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When have you chosen the member's side of the counter?" | VAL | [grounded] | Selection scaffold: a named member situation, the choice you made, what it cost or risked. F1's complaints log is one place to look. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | Value 1, "Members First, Always", in its own words. The panel scores against it. VAL |
| G2 | "When have you had to rewrite or re-explain something because a member needed it explained twice?" | VAL | [grounded] | Selection scaffold: a named piece of wording, what failed to land, what you changed. The escalation script you trained tellers on (F4) is one place to look; if its wording or your explanation of it ever changed because something did not land, say what. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would write it | Value 2, "Plain Words". The value's own test is whether it was explained twice. VAL |
| G3 | "Tell me about a time the numbers and the people in a branch told you different things." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold, with F3 as the place to look, since you built a monthly set of numbers. Pick a time where a count and a local reality pointed different ways, what you did, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh the two | Value 3, "Neighbours, Not Numbers", against a role that reports numbers. VAL |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1, with only the beat the sentence states: you handled the log. Answer slot: if a complaint in the log that began elsewhere stayed with you until it was resolved, say which and what you did; if the log's cases moved on to others, or there was none, say so plainly and stay with the log | Value 4, "Own the Fix", and F1 is the nearest evidence. VAL |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our branches and this role sit side by side. Where is the seam, and what do you need from us?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Reciprocity first: what you bring them, as a role that keeps complaints moving and reports them. Say "I spent the last three years as a branch supervisor," at its scope, and let them draw the rest. Offer seam principles, not a map: who tells the member, when a case goes up, how you disagree. Concession: you do not know today's seam | The panel are branch managers and the JD has the role coaching their supervisors; F4 and F5 are the evidence. JD |

### I. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "How much of that complaints process was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | Hold-then-concede. Hold: "I handled the branch's formal complaints log," "I trained new tellers on our escalation script," "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: which steps you set, which the bank or your region set; if someone else set them, or you are not sure, say so plainly. Hold through two follow-ups, then concede the specific limit | A panel may press on attribution after F1; the question exists to test whether a claim survives. EXP |

## Values cheat sheet (round 3, panel)

The recruiter says the panel scores against the four values; names are Ashgrove's own, from the page you pasted.

| Value | Working meaning, paraphrased | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, row F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Pick a named member situation where you took their side and it cost something. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide |
| Plain Words | If a member has to be told twice, the writing failed | Scaffold, row F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Look for wording that changed because it did not land. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would write it |
| Neighbours, Not Numbers | Each branch is part of its own town | Scaffold, row F3: "I built the monthly complaints spreadsheet our regional manager uses." Look for a count and a local reality that disagreed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh them |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Story-mapped, row F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The beat the sentence states is that you handled the log. Answer slot: if a complaint that began elsewhere stayed with you until solved, say which; if not, say so plainly and stay with the log |

## Reverse questions

Role-based, since no interviewer is named.

**Round 1, recruiter**

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "For the case in the panel, is it a written scenario, a role-play or a discussion, and is there anything to read first?" | Removes the one format you do not know |
| R1.2 | "What happens after the panel, and on what timeline?" | Shows you are planning, and gives you dates |
| R1.3 | "Is there anything in my background you would want the Head of Member Services to hear about directly from me?" | Surfaces the objection early, so D1 is rehearsed against the real one |
| R1.4 | "Where does complaint ownership sit today across the branches and the contact centre?" | Tests the JD's end-to-end line against the actual structure |
| R1.5 | "What would you want me to ask the panel that candidates usually forget?" | Invites the recruiter's own view of the loop |

**Round 2, Head of Member Services**

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What does success look like at 90 days and at a year?" | Turns the interview into a plan you can be measured on |
| R2.2 | "Which part of the complaints process do you most want improved first?" | Shows you think about the job, not the title |
| R2.3 | "Who in the contact centre would I learn from in my first month?" | Turns F2 into a plan, in front of your prospective manager |
| R2.4 | "How do monthly complaints reports get used by senior leaders, and what decisions follow?" | Makes the F7 gap a question about the audience, not about you |
| R2.5 | "As the 40% digital target approaches, how do you see this role working with digital teams?" | Ties your question to the strategy summary |

**Round 3, panel**

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could a new person in this role do in their first month that would genuinely help your branch?" | Reciprocity with branch managers who sit beside the role |
| R3.2 | "What does a good escalation look like from the branch side, and where does it most often go wrong?" | Lets them teach you, and tells you what the case may press on |
| R3.3 | "As eight branches become five hubs, what do you most want complaints handling to protect?" | Ties your question to the brief and to their towns |
| R3.4 | "How do branch managers find out how a complaint from their branch ended?" | Tests the seam you are asked about in H1 |
| R3.5 | "Which of the four values do you see tested hardest in your branch, and what does it look like?" | Invites an example from them, which you can answer back |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B2, D1, D3, F1, I1 |
| "report monthly on complaint volumes and resolution times" | C3, F3 |
| "coach branch supervisors on escalations" | C4, F2, H1 |
| "work with digital teams on self-service journeys" | E1, E2 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | B1 |
| "confident presenting to senior leaders" | C2, D2 |
| "comfortable with Excel reporting" | C3 |

## Prohibited claims

Built from the fit snapshot before the banks were written. These are not coached.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the whole complaints process | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one branch's formal complaints log, not the process across branches and the contact centre. D1's slot stays inside the log |
| Worked in or ran a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Presented to senior leaders | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never presented to anyone above regional level." No slot |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. C3's slot asks only what the spreadsheet counted |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: you trained new tellers. C4's slot stays with the tellers |
| Handled complaints under external rules | Inflated form of F6 | F6's quote at its own scope: the formal log. B1's slot asks only what governed it |

## Sources

Provided documents: the JD; the recruiter's email; the values text copied from the Ashgrove values page on 20 November 2026; your message's summary of Ashgrove's July 2026 strategy brief; your background.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the four value names and meanings used in the cheat sheet and the G bank |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email already fixes the three sessions, who runs each, and the panel's values scoring |
| 3. `Ashgrove Credit Union strategy` | skipped | The pasted strategy summary, from July 2026, fixes the CO questions E2 and F4 and the grounding brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer is named, so there is no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names, once assigned → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each one's path
- The recruiter's answer on the case's format and any pre-read → case rows F1 to F3 re-weighted to the real format
- Your answers to the answer slots on F1, F3, F4, F6, F8 and F9 → those rows become stories in your own words, with confidence raised where your answer supports it
- An anonymised view of the monthly complaints spreadsheet's layout, if you are allowed to share one, with no member data → F3 and F8 move from medium toward high, since a report layout is the inspectable artifact for this domain
- Your pay expectation, notice period and location constraints, if you want them rehearsed → A3 to A5 quote your own words
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, on Ashgrove's recent strategy and organisation → a fuller grounding brief and sharper CO questions (offered once)
- A `tuesday-dossier.md` → verified evidence, the objection worth deepest rehearsal, and prohibited claims, in place of the ones this pack inferred
