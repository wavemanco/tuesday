I'll read the skill's reference files before building the pack.
Your prep pack is saved as `atlas-freight_operations-manager_interview_pack.md`, in the working directory. It has 21 questions across seven interviewer styles, a requirement-by-requirement map of your background against the JD, and reverse questions.

- **Flat weights:** I don't know who is interviewing you, so every interviewer style carries equal weight.
- **No company research:** The three web searches I tried were refused. Nothing in the pack comes from outside the JD and your message, and the company-knowledge questions stay generic.
- **Most likely objection:** The pack names A1 as the highest-value prep: you currently oversee 3 supervisors and the role leads 12. This is inferred from your material, not confirmed.
- **Power BI:** The pack coaches you to say "I have never used Power BI" and give a learning plan. It does not coach any claim of experience.
- **Slots to fill:** Where your material is silent, such as how many of your 7 years were in a leadership role, the pack leaves a slot for you to answer in your own words. It doesn't fill them in for you.

Say the word and I'll play the Skeptic on A1 so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who will you be meeting first (future manager, peer, skip-level or recruiter), and did the recruiter mention a presentation or case to prepare? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

- Role: Operations Manager, Atlas Freight (JD: "regional logistics, 800 employees")
- Interviewer: not known
- Relationship and round type: not known, so persona weights are flat (section 4)

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your CV claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the company |
| CASE | A live problem from the role, structured aloud |

An answer slot is an instruction for the interview, not a question for you here: answer it from your own experience, or say plainly the practice was not yours.

## 1. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message, "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows warehouse and distribution work and a surge plan for "the site"; it does not mention terminals or a second site, and the words stay at that scope: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-sites line makes a probe on scale likely. Say plainly what the surge plan covered and which parts were yours to set, in your own words; if the site was the whole of it, say so and stay with the site |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote reaches mis-pick rate, not on-time performance or cost-per-shipment. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost per shipment, say what you tracked and how it was counted; if you did not, say so plainly and say what you would measure first |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote shows 3 supervisors; the JD says 12. Words: "I'm currently a senior shift manager over 3 supervisors." Answer slot: expect a probe on the step from 3 to 12. Say how you would approach a larger team, as a plan and never as a past; if 3 is the most you have led, say so plainly |
| F4 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [inferred] | discovery | The quote says "solid Excel" and does not say what it was used for. Answer slot: the JD says build reporting. If you built recurring reports, say what they showed and who read them; if you did not, say so plainly and describe your Excel use as it was |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives seven years in operations and a current supervisory role, and does not say how the seven divide by role. Answer slot: the requirement is stated as a hard line, so expect a probe. Say your role in each stretch of the seven years, in your own words; if the leadership stretch is shorter than the posting asks, say so plainly |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | discovery | The quote does not name the program or discipline. Words: "I'm green belt certified." Answer slot: if the certification was in Lean or Six Sigma, name the program in your own words; if it was another discipline, say so plainly |

No row is a gate: the 5+ years line is experience, graded like any other requirement.

## 2. Persona table

Round type and interviewer are unknown, and no loop source establishes the loop, so the fallback archetype is Generic: flat weights. Each bank has three questions.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of scale and gaps | Flat. The JD's 12 supervisors and 4 sites sit against F3 and F1, and Power BI is F5, so this persona has the most material in this pack | Rehearse A1 until it is boring; hold what the quotes carry, concede the step up |
| B. Case / Strategist | Live problems from the role | Flat. The JD's on-time and cost-per-shipment lines (F2) are the natural cases | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| C. Data-Driven Prober | Digs into the 40% line by line | Flat. A quantified claim (F2) is a magnet for this persona | Say how the figure was counted, or say plainly you do not know |
| D. Pressure | Interrupts, time-boxes, challenges credit | Flat. Applies whichever round it is | Pause, restate, hold through two follow-ups, concede specifically |
| E. Values / Behavioral | Scenario probes, story-shaped answers | Flat. No published values were read, so these are open prompts | Pick a real story; if none comes to mind, say so |
| F. Conversational | Friendly, unstructured, still scored | Flat. Common in a first conversation | A 90-second arc built from your own sentences |
| G. Peer Evaluator | Seam-splitting, credit, collaboration | Flat. Matters if a peer sits in the loop | Propose seam principles, offer what you bring their team |

Tell me who you are meeting and these weights move.

## 3. Question banks

Highest-ROI prep in this pack: A1. It rests on the biggest numeric step in the JD against F3, and this is inferred from the material, not from a dossier.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're currently a senior shift manager over 3 supervisors, and this role leads 12. What makes that step realistic?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Follow-up 1, how it scales: answer as a plan in your own words. Follow-up 2, what breaks first: name what you would watch first, as your judgment, not as something that happened. Follow-up 3, have you led that many: answer slot, say plainly the largest number of supervisors you have led; if 3 is the most, say so and stay with the 3. Concession wording: "Twelve is a bigger span than three." Never fold on the 3 | F3 against the JD's 12 is the likeliest objection, and F1's scale sits behind it. JD because it scores a stated requirement; deepest rehearsal for that reason |
| A2 | "The role builds reporting in Excel and Power BI. Where are you on each?" | JD | [grounded] "solid Excel, never used Power BI" | Say each half at its own scope: "solid Excel" and "I have never used Power BI." For Excel, answer slot: if you built recurring reports, say what they showed and who read them; if you did not, say so plainly and describe your Excel use as it was. For Power BI, give a plan in your own words: how you would learn it and what first report you would build. No past claim about the tool | F4 and F5 are the two halves of one JD line, and the candidate stated the second half's gap. JD because it scores a listed tool |
| A3 | "Why this role, and why now?" | EXP | [generic] | Give your actual reason in your own words, then tie it to the posting's own lines: own daily operations, drive on-time performance and cost-per-shipment down, lead supervisors. No claim about your past is needed, so none is coached | Motivation consistency is the Skeptic's standard probe; EXP because the answer is checked against the CV. `[generic]` because it is a pattern, not a fact about this employer |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of the four terminals has dropped for three weeks running. Diagnose it." | CASE | [generic] | Clarify first: which lanes, which shifts, since when, how on-time is defined. Then objective, segmentation of the drop, hypotheses ranked by how cheaply you can test them, the data you would pull, risks. Challenge one premise respectfully. Think aloud | F2's on-time requirement as a live problem; it presupposes nothing about your past |
| B2 | "Leadership wants cost-per-shipment down without hurting on-time performance. Where do you start?" | CASE | [generic] | Clarify what is in the cost figure and who owns each part. Name the trade-off explicitly, propose where you would look first and why, and say how you would know it worked. Hold the trade-off between the two metrics rather than picking one | F2's second metric, set against the first the way the JD sets them. CASE because structure is scored |
| B3 | "Peak season is eight weeks out and volume is forecast above last year at all four sites. Plan the surge." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: forecast, labor, space, equipment, carrier and customer communication, daily checkpoints, triggers to escalate. You may say "I ran the site's peak-season surge plan two years running" and stop there; the beats are the plan, the site and the two years, in your own words | F1's surge plan is the nearest thing your material has to this problem, at the site's scale. CASE because it is a live plan |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut the mis-pick rate by 40%. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot, four parts in your own words: how it was counted, what the figure is most sensitive to, the assumption you would defend least, and which part was yours. Name the weakest assumption before they do. If you do not know how part of it was counted, say that plainly | F2's only figure; defend-the-number applies. EXP because it tests attribution |
| C2 | "Walk me through the redesign of the pick path." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats the quote states: the pick path, its redesign, the mis-pick rate, the 40%. Tell them in your own words. Answer slot: say which parts of the redesign were yours; if others contributed, say so plainly | F2 is the one specific piece of work in your material, so expect a walk-through. EXP because it tests what was actually yours |
| C3 | "Which numbers would you want on a daily terminal report, and how would you build it?" | JD | [grounded] "solid Excel, never used Power BI" | A design answer: who reads it, what decision each number drives, how often it refreshes. Say plainly which tool you would use now and that you would learn Power BI as a plan. Answer slot: if you have built a report like this before, say what it was; if not, say so | F4 and F5 again as a live design question; JD because it scores the reporting line |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Hold: "I cut mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups. Answer slot: say which part was yours and which was others', in your own words; if it was shared, say so plainly and concede that specifically, without folding the core | F2's figure under pressure. EXP because attribution is the target |
| D2 | "Sixty seconds: why you over a candidate who has run a bigger operation?" | JD | [grounded] "7 years in warehouse and distribution ops", "ran the site's peak-season surge plan two years running", "green belt certified" | Build sixty seconds from the three quotes, each at its scope, and stop. Hold through two follow-ups. Concession slot: if the other candidate's scale is not yours, say so plainly in your own words, then say what you would do in your first weeks | F1 and F7 are what you can say; the scale gap is the pack's observation. JD because the question scores fit against the role |
| D3 | "The posting asks for 5+ years of operations leadership. Walk me through your seven years." | JD | [grounded] "7 years in warehouse and distribution ops" | Say your role in each stretch of the seven years, in your own words, without rounding up. Answer slot: if the leadership stretch is shorter than the posting asks, say so plainly and say what the rest of the seven years carried | F6 is the requirement the posting calls required, so expect it checked literally. JD because it scores a stated requirement |

### E. Values / Behavioral

No company values were read, so these are open prompts on themes from the persona's stems and the JD's own lines.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to a manager or leader." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values probe for a manager hire; `[generic]` because no company values were read |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time where the customer cost and the metric cost were both real, and say which you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Freight is customer-facing; the stem is a persona stem. `[generic]` for the same reason |
| E3 | "Tell me about a time you brought a team of supervisors with you on a change." | VAL | [generic] | Selection scaffold: pick a change you introduced where supervisors had to carry it, and say what you did, in your own words, and how you knew it held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's "lead a team of 12 supervisors" raises the theme; F3 is the row it draws on |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path" | A 90-second arc made only of those sentences, told in whatever order is true, ending on why this role. Do not add titles, dates or scope the quotes do not carry | Casual openers are scored; F1, F2, F3 and F6 are the material the arc can use |
| F2 | "You mentioned a green belt. Which program, and what did it cover?" | JD | [grounded] "green belt certified" | "I'm green belt certified." Answer slot: name the program in your own words; if a project came with it, describe it as it was; if none did, say so plainly | F7 is the posting's plus, asked casually. JD because it scores a listed preference |
| F3 | "What do you know about Atlas Freight so far?" | CO | [grounded] | Say the JD's own facts: regional logistics, 800 employees, four sites, twelve supervisors. Then add what you have read yourself before the interview, naming where you read it. No company research was available when this pack was built | CO is thin here because research did not run; the JD is the only company source |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our terminals sit side by side. Where is the seam between yours and mine, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who owns the customer commitment, how handoffs are measured, how disagreement is escalated. Say you would want to learn the actual seam first | The JD's four sites make site-to-site seams likely. `[generic]` because the org is unknown |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | A principle in your own words: name contributors specifically, take credit only for your part. No story is coached, as no quote carries one | A standard peer probe |
| G3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Lead with what you bring their team, then what you need. Keep both as intentions, not past claims | Reciprocity framing for a peer interviewer |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, B1, B3, D2, G1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C1, C2 |
| "lead a team of 12 supervisors" | A1, E3 |
| "build reporting in Excel/Power BI" | A2, C3 |
| "5+ years operations leadership required" | D3, F1 |
| "Lean/Six Sigma a plus" | F2, D2 |
| Headline figure: 40% mis-pick rate | C1, C2, D1 |

## 4. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance look like across the four sites today, and which site is furthest from where you want it?" | Shows you think site by site, which is the JD's own frame |
| R2 | "How are the 12 supervisors spread across the sites, and what does that team need most from its next manager?" | Lets you hear what the scale step really involves before you promise anything |
| R3 | "Which reports does the team run on today, and where do you want Excel and Power BI to go?" | Opens the reporting line on your terms, and shows you plan to learn the tools |
| R4 | "How is cost-per-shipment measured here, and who owns each part of it?" | Defines the metric before you are held to moving it |
| R5 | "What would a strong first 90 days look like, and how is the role measured at six and twelve months?" | Converts the interview into a shared definition of success |

## 5. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations across several sites | Inflated form of F1 | F1's quotes at their scope. The limit is the pack's observation: the material shows warehouse and distribution work and a surge plan for "the site", not terminals or a second site |
| Led twelve supervisors | Inflated form of F3 | "I'm currently a senior shift manager over 3 supervisors." The material shows 3 |
| Moved on-time performance or cost-per-shipment | Inflated form of F2 | "I cut mis-pick rate 40% by redesigning the pick path." The quote is about mis-pick rate |
| Built reporting in Excel | Inflated form of F4 | "solid Excel" at its own scope. The material does not say what it was used for |
| Has Power BI experience | Negative you stated, F5 | The plain acknowledgment: "I have never used Power BI." No slot |
| Has 5+ years of operations leadership | Inflated form of F6 | "7 years in warehouse and distribution ops" at its own scope. The material does not say how the seven divide by role |
| Led Lean or Six Sigma programs, or the pick-path redesign was a Lean or Six Sigma project | Inflated form of F7 and F2 | "green belt certified" and the pick-path quote, kept separate at their own scope. The material does not link them |

## 6. Sources

Provided documents: your message, carrying the JD text and your background summary. No CV document was provided.

Searches sent, all refused (web search permission was not granted):

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Would have fed a values cheat sheet; none exists, and bank E is open prompts |
| 2. `Atlas Freight interview process operations manager` | unavailable | Would have fixed the loop and persona weights; they fall back to the Generic archetype, flat |
| 3. `Atlas Freight strategy` / recent news | unavailable | Would have grounded CO and CASE questions in current priorities; F3 in bank F is JD-only and B1 to B3 are generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there is no query; the interviewer read is absent |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## 7. Upgrade menu

- Who you are meeting and the round type (manager, peer, skip-level, recruiter, panel) → persona weights recomputed, banks re-ordered, no longer flat
- The recruiter's note on format or any deliverable (presentation, case, take-home) → a build section for it
- Web search permitted in this session → company values, loop and strategy fetched, so the CO and CASE questions and persona weights stop being `[generic]`
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), offered once → a grounding brief on the company's recent moves and competitors
- The interviewer's name → an interviewer read and a reverse question tied to their path
- Your CV text → F1 to F7 quotes beyond the one-line summaries; inspectable artifacts that would raise confidence: the before-and-after mis-pick report for F2, your green belt certificate for F7, a sample report you built in Excel for F4, an org chart or roster showing the supervisors you oversee for F3
- Your answers to the slots in F1, F2, F3, F4, F6 and F7, stated in your own words → those rows regenerate on your actual facts
- A tuesday-dossier.md from job-underwriter, if you have one → verified evidence and the objection worth deepest rehearsal, instead of the inferred one here
