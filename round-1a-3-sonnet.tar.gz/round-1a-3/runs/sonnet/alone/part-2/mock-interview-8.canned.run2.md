I'll read the reference files the skill requires before writing anything.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-8-canned-a400a235/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop pack from the recruiter's schedule, with 32 questions in all. Persona weights come from the roles only, since no interviewers are named yet. I ran no web searches, because your JD, values text, strategy summary and recruiter email already covered what research would have. I haven't verified your copies of the values page or the strategy summary against the live sources.

- **Biggest risk:** the contact centre. The JD puts it inside the role's scope and you've never worked in one, so every round can reach it. B2 is the deepest rehearsal: the plain sentence, a learning plan, and three escalating follow-ups. A7 and C10 are the lighter versions.
- **Second gap:** presenting above regional level (A9, B3, B7). Rehearse the plain sentence and a short plan for your first leadership presentation.
- **Round 3:** the pack covers the 20-minute escalation case (C5, C6) and one values question for each of the four values (C1 to C4). Where none of your sentences carries a story, I gave you a selection scaffold instead of inventing one.
- **Branch consolidation:** the plan to merge eight branches into five hubs directly affects the panel of branch managers (C9). The guidance is to ask rather than pronounce.
- **The date:** 29 November 2026 is a Sunday. It's worth confirming the day and times with the recruiter.

I didn't need to ask you anything to build this. The upgrade menu at the end of the file lists what would sharpen it, including your answers to the "answer slot" prompts and a deeper research pass.

Say the word and I'll play the Skeptic on B2 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Prepared:** 20 November 2026. **Mode:** loop, three rounds, all on 29 November 2026 (a Sunday, so worth confirming the day and times with the recruiter).

| Round | Length | Who | What the recruiter said it is |
|---|---|---|---|
| 1 | 30 min | The recruiter | Process and screen |
| 2 | 45 min | Head of Member Services, your would-be manager | "mostly behavioural" |
| 3 | 60 min | Panel of two branch managers | A 20-minute case on a complaint escalation, plus "the values round": they score against the four values |

Interviewers beyond their roles have not been assigned, so persona weights come from the roles and the round descriptions, not from anyone's public footprint. No CV was supplied: the evidence in this pack is the sentences in your message.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is scored. Every question carries both a persona bank and a type tag.
- Type key: **VAL** = behaviour against Ashgrove's published values. **EXP** = whether your background survives scrutiny. **JD** = a stated requirement of the role. **CO** = company and strategy knowledge. **CASE** = a live problem.
- Guidance is scaffolding, not a script. Where it quotes you, say it in your own words at the same size. Where it says "answer slot", only you can fill it, and the honest answer may be "that was not mine to do" or "there was no such step".
- Spoken answers should fit 90 to 120 seconds.

## Prep triage (nine days: 20 to 28 November)

1. **20 to 21 Nov: the contact-centre question, aloud, until it is boring.** B2 first, then A7 and C10. This is the highest-ROI prep in the pack, because every round can reach it.
2. **22 Nov: write down your four logistics answers** (A3 to A6) and decide them before anyone asks. One written line each.
3. **23 to 24 Nov: presenting above regional level.** A9, B3, B7. Say the plain sentence and the plan aloud.
4. **25 to 26 Nov: pick four values stories** (C1 to C4), one per value, and test each against the honest branch.
5. **27 Nov: the 20-minute case.** C5 timed, then C6, B9 and B10.
6. **28 Nov: one run of all three rounds back to back, then stop.**

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process across branches and the contact centre, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened after a complaint was logged likely. If you saw any complaint through later steps, say which steps were yours; if the log was where your part ended, or there was no such step, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre exposure, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | The sentence says a monthly complaints spreadsheet; it does not show whether it tracked volumes or resolution times. Answer slot: if it tracked either, say which and how each was counted; if it tracked something else, or neither, say so plainly and say what it did track |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and the branch's script, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you ever coached people at supervisor level, say who and on what; if the training was only new tellers, say so plainly and stay there |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show any work with digital teams. Answer slot: if you have worked with a digital or app team, say on what and what part was yours; if not, say so plainly and say how you would begin |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on years, but a self-reported line with nothing inspected behind it, so expect a probe on what the branch work covered. Lead with the six years and the three as supervisor in the quote's own terms |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [inferred] | discovery | A formal complaints log touches the requirement without showing whether rules, timeframes or reporting duties governed it. Answer slot: if particular rules applied to the log, say which and what part of meeting them was yours; if none did, or they sat with someone else, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for a first leadership presentation, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | presentation | The sentence reaches the requirement in other terms: a spreadsheet, built by you, used monthly. It does not say which tool. Words: the quote as it stands. Answer slot: if the spreadsheet was in Excel, say so; if it was another tool, say which |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches and the contact centre | A7, B2, B9, B10, C5, C10 |
| Report monthly on complaint volumes and resolution times | A8, B8, B10 |
| Coach branch supervisors on escalations | B6, C6, C7 |
| Work with digital teams on self-service journeys | B11 |
| 4+ years in financial-services customer operations | A1, B1 |
| Regulated complaints experience | B4 |
| Confident presenting to senior leaders | A9, B3, B7 |
| Comfortable with Excel reporting | A8, B8 |

## Grounding brief (from the 2026 strategy brief, as you summarised it)

The recruiter sent the brief; I have your four points, not the document. It was published in July 2026, about four months ago. Use their words: "member service", "digital channels", "hubs".

| Item | What it says | How it reaches the interview | Provenance |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | Complaints will arrive through more channels; the JD's self-service line sits here. B11 | [grounded] |
| Branch consolidation | Consolidate eight branches into five hubs over 2027 | The round-3 panel are branch managers, and this affects their own world. C9. Never comment on whether it is right | [grounded] |
| Small-business lending | Launch a small-business lending product in Q1 2027 | A new product is a new place for a member to have a problem. A question you could ask, not a fact about their plans | [inferred] |
| Competitive pressure | The main competitive pressure is app-only banks | Members will compare Ashgrove with app-only experiences; ties to Plain Words and self-service | [inferred] |

---

# Round 1: the recruiter (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly screen: your journey, why here, the practical details | High. A recruiter screen is the relationship prior for this persona, and the recruiter's own words call it a process and screen round | A 90-second arc; treat the chat as scored; ask real questions at the end |
| Skeptic (light) | Knockout checks in a friendly register: contact centre, presenting, Excel | Medium. The JD's contact-centre and senior-leader lines are the two likeliest knockouts, and you have said you lack both | Say the plain sentence first, then the plan; do not defend |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey in banking and what's brought you here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in four beats, each a sentence you already said, told in your own words and no larger: the six years and the three as supervisor, the complaints log, the training, the monthly spreadsheet. Answer slot: the last beat, why Ashgrove, is yours alone; give your actual reason. Stop at what you would stand behind in round two | The opener of every screen, and the version told here is the one rounds two and three test against; F6, F1, F4 and F9 are its four beats. EXP because it sets what the CV claims |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Pick one published value, or one item in the 2026 strategy brief, that genuinely matters to you; say what it is in their words and why in yours. The pack will not choose it for you. If you can name two, make the second different in kind: one about members, one about where Ashgrove is heading. If nothing in either moves you, say what does | Motivation consistency is the recruiter's real score. CO because it needs the company's own words, and both the values and the brief are in hand | 
| A3 | "What's making you look to move on from your current role?" | EXP | [generic] | Logistics slot, reason for leaving: give your actual reason in your own words, framed around what you are moving toward, and keep it to what you would say in front of your current employer. Use the same wording in all three rounds, because they will compare | Every screen asks it and a changing answer is the thing that gets noticed; EXP because it tests consistency of your own story |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words, and anything you already know that could change it. Do not estimate | A knockout-and-planning question; JD because it concerns the job's start terms |
| A5 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first; your choice. If asked for current or past pay, you may decline politely and bring the conversation back to the role's band. The pack supplies no figure | The one logistics question with real money attached; JD because it concerns the job's terms |
| A6 | "Which of our sites could you work from?" | JD | [grounded] | Logistics slot: give your own location and any real limits on travelling between sites, in your own words. The JD's "across branches and the contact centre" makes travel between sites a likely follow-up; answer it with what is true | The role spans branches and the contact centre, so location and travel are practical filters; JD for the same reason |
| A7 | "The role covers the contact centre as well as the branches. What's your experience of contact centres?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | Say it first, plainly: "I've never worked in a contact centre." Then stay at the scope of what you said: "I handled the branch's formal complaints log." Close with one sentence of plan, what you would do first to learn the contact centre's side, in your own words. Claim no shadowing, partnership or exposure you have not told me about. The full rehearsal is B2 | F2 is the likeliest knockout in a screen. JD because it scores a stated requirement; the light version, with B2 as the deep one |
| A8 | "The role reports monthly on complaint volumes and resolution times. What have you reported on?" | JD | [inferred] "I built the monthly complaints spreadsheet our regional manager uses" | Start from the sentence as it stands. Answer slot: the JD names volumes and resolution times, so expect "what did it show". If it tracked either, say which and how you counted it; if it tracked something else, or neither, say so plainly and say what it did track. If it was in Excel, say so; if another tool, say which | F3 and F9 together: the reporting and Excel requirements both rest on one sentence. JD because it scores two stated requirements |
| A9 | "You'd be presenting to senior leaders. How do you feel about that?" | JD | [grounded] "I've never presented to anyone above regional level" | Say it plainly: "I've never presented to anyone above regional level." Then a plan: how you would prepare for a first leadership presentation and what support you would ask for, in your own words. Answer slot: if you have presented at regional level, say to whom and about what; if not, say so and leave it there. Describe no confidence you have not had occasion to test | F8 is a stated gap the recruiter can see in the JD. JD because the line is an explicit requirement |

### Reverse questions: round 1

| Question | Why it lands |
|---|---|
| "Who will be on the panel in round three, and will anything about the case be shared beforehand?" | It extracts the one structural fact the pack is missing and shows you are preparing |
| "What would you like me to be ready to cover with the Head of Member Services?" | Recruiters know what the manager is worried about; the answer sharpens round two |
| "Does the complaints lead sit above the contact centre's complaint handling, or alongside it?" | It clarifies the shape of F1 and F2 without asking for a favour |
| "The brief has 40% of member service moving to digital channels by 2028. Is the self-service work already staffed, or does this role start it?" | Ties your homework to the JD's digital line and tells you how much F5 will matter |
| "What happens after the three rounds, and when would I hear?" | Process clarity, and it ends the screen on logistics rather than hope |

---

# Round 2: the Head of Member Services (45 minutes, your would-be manager)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gaps: contact centre, presenting, regulated complaints | High. A hiring manager is buying capability and derisking gaps, and you have stated two gaps outright | Rehearse B2 until the plain sentence and the plan come out unforced |
| Values / Behavioral | "Tell me about a time" questions about escalations and hard conversations | High. The recruiter described this round as "mostly behavioural" | A story only where a sentence of yours carries one; otherwise the scaffold and its honest branch |
| Case / Strategist | Live problems from the role, and the 2026 strategy | Medium. Hiring-manager prior; the digital shift gives them a natural CO question | Clarify, structure, then answer; use their vocabulary |
| Data-Driven Prober | "What did that spreadsheet count?" | Medium-low. One line on the monthly spreadsheet is your only reporting evidence | Say what it counted, and say plainly when you do not know how a figure was counted |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Name the two you have already stated, no more: the contact-centre side of the process, then presenting above regional level. For each, the plain sentence, then one sentence of plan in your own words. Close on what your quotes carry at their own scope: "I handled the branch's formal complaints log" and "I built the monthly complaints spreadsheet our regional manager uses". Do not add a third, invented weakness | F2 and F8 are the two stated gaps. JD because it asks you to score yourself against the posting |
| B2 | "The role owns complaints in the contact centre as well as the branches. You've never worked in one. How would you handle that?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" "I built the monthly complaints spreadsheet our regional manager uses" | **The highest-ROI rehearsal in this pack.** Hold: "I've never worked in a contact centre. I handled the branch's formal complaints log and I built the monthly complaints spreadsheet our regional manager uses." Then a plan, said as a plan: who you would learn from, what you would read, what you would ask first, in your own words. Follow-up 1, "How would you earn credibility with people who've done this for years?": answer with the learning plan, not with a claim. Follow-up 2, "What if the contact-centre team doesn't want a branch person telling them how to handle complaints?": stay with the member's side and ask what they would want from the role. Follow-up 3, "So we'd be hiring you to learn the job?": concede specifically, "the contact centre is new to me", and return to the two quotes. Limit: you do not know how a contact centre handles complaints, and the quotes do not say you do | The role's own wording puts the contact centre in F1's scope and F2 says you have not worked in one, so this arrives in some form in every round. JD because it scores a stated requirement |
| B3 | "You've never presented above regional level. Why should I be comfortable with that?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses" | Concede it plainly: "I've never presented to anyone above regional level." What you do carry, at its own scope: "I built the monthly complaints spreadsheet our regional manager uses"; the spreadsheet is yours and the audience is new. Then the plan: how you would prepare the first leadership pack and what you would ask your manager for, in your own words. Do not claim presentation skills the material does not show | F8 against a role that reports to senior leaders every month. JD because the requirement is stated |
| B4 | "The role asks for experience of regulated complaints. What governed the complaints in your log?" | JD | [inferred] "I handled the branch's formal complaints log" | Answer slot: the JD says regulated, so expect a probe on what governed the log. If particular rules, timeframes or reporting duties applied, say which and what part of meeting them was yours, in your own words. If you did not work to such rules, or they sat with someone else, say so plainly and stay with the log: "I handled the branch's formal complaints log." Name no regulator, rule or deadline you cannot explain | F7 is a requirement the JD states and your material neither confirms nor denies. JD because it scores the requirement directly |
| B5 | "Tell me about an escalation that was going badly. What did you do?" | EXP | [generic] | Selection scaffold: pick a time with a named stake, a point where it could have gone either way, what you did yourself, and how it ended, including what did not go well. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use "we" for context and "I" for what was yours | Escalation is the JD's own coaching topic; EXP because it asks for a real instance. A scaffold because none of your sentences carries an escalation story |
| B6 | "Tell me about training new tellers on the escalation script." | EXP | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: you trained new tellers; the script was the branch's ("our"); tell those in your own words. Answer slot: the JD asks about coaching branch supervisors, so expect "did you ever coach at supervisor level". If you did, say who and on what; if the training was only new tellers, say so plainly and stay there. If you wrote or changed the script, say what; if it was handed to you, say so | F4 is the only evidence for the coaching requirement and it stops short of supervisors. EXP because it tests exactly what was yours |
| B7 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time where the truth was unwelcome, you chose to say it, and the relationship was intact afterwards; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Show the result landing, only if it did | A standard behavioural stem, and the hardest test of the senior-audience gap in F8. VAL because it measures how you behave when the member's side is inconvenient |
| B8 | "On the monthly complaints spreadsheet: walk me through how it worked." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Prober question: start from the sentence. Answer slot: say what the sheet counted and how each count was made, in your own words. Name the assumption behind it you would defend least, or say plainly you do not know how a figure was counted. If any part was not yours, say which | F3 and F9 rest on this one line, and a prober will go two levels deep. EXP because it tests the claim |
| B9 | "A branch supervisor has escalated the same complaint three times and the member is still unhappy. Where do you start?" | CASE | [generic] | Clarify first: what the member has been told, what is logged where, whether any deadline is running. Then objective (the member's side), one named owner today, a plain reply to the member, and what you change afterwards. Challenge one premise: is this one complaint or a pattern. Think aloud | A live problem from the role's core. CASE because it scores structure, not a past |
| B10 | "Complaints are taking longer to resolve through the contact centre than in the branches. How would you find out why?" | CASE | [generic] | Clarify definitions first: when the clock starts and stops, whether categories match across channels. Then segment by complaint type, channel and handoff, form a hypothesis, test it with the people who do the work. Say aloud that the contact centre is new to you and what you would ask them | It puts F2 inside a problem, and the JD's resolution-times line behind it. CASE because it scores diagnosis |
| B11 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that mean for complaints?" | CO | [grounded] | Reason aloud from their strategy: more contact on digital channels means complaints arrive in new places and the route to complain has to be in plain words. Do not claim knowledge of Ashgrove's systems. Answer slot: the JD asks about digital teams and self-service journeys; if you have worked with a digital or app team, say on what and what part was yours; if not, say so plainly and say how you would start | The 40% figure is the brief's headline and the JD's digital line follows it. CO because it asks for strategy altitude |

### Reverse questions: round 2

| Question | Why it lands |
|---|---|
| "Given that the contact centre is new to me, what would you want me to learn first?" | It turns the stated gap into a joint plan |
| "Where do complaints currently get stuck between the branches and the contact centre?" | It shows you are thinking about the process as a whole, and tells you what B9 and B10 are really about |
| "How are volumes and resolution times reported to leadership today, and what would you change?" | Ties directly to the reporting line in the JD |
| "Who reads the monthly report, and what decisions does it drive?" | Addresses the senior-audience gap from the receiving end |
| "How will the move from eight branches to five hubs change how complaints reach this role?" | Shows you read the 2026 brief and are thinking about the job it creates |

---

# Round 3: the panel of two branch managers (60 minutes, includes a 20-minute case)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scored against the four published values; STAR-shaped stories | Guaranteed. The recruiter said the panel is "also the values round" | One story per value where a sentence of yours carries it; otherwise the scaffold and its honest branch |
| Case / Strategist | The 20-minute complaint-escalation case | High. The recruiter named it and gave it a third of the round | Clarify, structure, think aloud; use their values in your actions, not as slogans |
| Peer Evaluator | Seam-splitting between branches and your role; "what do we get" | Medium-high. This is my judgement from the roles: branch managers' supervisors are the people you would coach and escalate with, so they price what you cost their branches | Reciprocity: what you bring them, not only what you need; propose seam principles |
| Conversational | Friendly questions about motivation and first month | Medium. A panel often opens or closes in a conversational register | Treat it as scored |
| Skeptic | Contact-centre gap, from branch people who may prefer a branch background | Low-medium. Branch managers may care less about the contact-centre gap than your manager, but one of them may still raise it | The plain sentence, never a dig at contact-centre candidates |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Value: Members First, Always. Selection scaffold: pick a time when the member's interest and a rule or target pulled apart, you chose the member's side, and say what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value's own phrase is the question's theme. VAL because it is scored against the named value; none of your sentences carries this story, so a scaffold |
| C2 | "Tell me about a time something you explained had to be explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Value: Plain Words. The one anchor is the training: "I trained new tellers on our escalation script." Answer slot: if you changed any wording of the script, or of how you taught it, because it was confusing, say what and why; if you did not, say so plainly and describe how you taught it. If another time fits better, take it | The value is "if a member needs it explained twice, we wrote it wrong". F4 is the only line that touches teaching words. VAL |
| C3 | "Tell me about a time you put a branch's own members or town ahead of what the numbers said." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Value: Neighbours, Not Numbers. The one anchor is that you were a branch supervisor for three years. The story itself comes from you: a named member, branch or local circumstance, the decision, and what the numbers said. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The panel are branch managers; this is the value they will feel most. F6 carries the role, not the story. VAL |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Value: Own the Fix. Anchor: "I handled the branch's formal complaints log." Answer slot: if you followed any complaint from the log through to its end, say which and what part was yours; if the log was where your part ended, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value says whoever finds the problem keeps hold of it, and the JD's end-to-end line points the same way. F1 and F7 mark the limit of what the log shows. VAL |
| C5 | "A member has complained at their branch twice and phoned the contact centre once. Nothing is resolved. The branch says it belongs to the contact centre, the contact centre says it belongs to the branch, and the member has said they will leave. You own the process. Walk us through the next day, and what you change afterwards." | CASE | [generic] | The 20-minute case. First two minutes: clarifying questions aloud (what the member has been told, what is logged where, any deadline running; ask rather than assume which rules apply). Then objective in the member's terms, one named owner today, a plain-words message to the member, then the process fix across branch and contact centre, the measures you would watch (volumes and resolution times by channel), and the risks. Challenge one premise respectfully, such as whether it is two owners or none. Let the panel see the values in what you do; do not recite them | The recruiter named the escalation case; this version puts the JD's cross-channel scope and all four values into one problem. CASE with VAL scoring |
| C6 | "A supervisor in one branch tends to settle complaints at the counter and not log them. You've been asked to coach them. How do you approach it?" | CASE | [generic] | Ask first why: workload, doubt about what counts as a complaint, worry about how the branch looks. Start from the member's side, give them a plain-words way to log, agree the approach with their branch manager, and say what you would check afterwards. A plan only; claim no past coaching beyond what F4 carries | The JD's coaching line, set among the people who would be coached. CASE |
| C7 | "Our supervisors are already stretched. What would you need from the branches, and what would they get from you?" | CASE | [generic] | Reciprocity first: what the branches get (a clear route, quicker answers, feedback on patterns), then what you would need (timely logging, a flag when stuck). Said as a plan, in your own words | The Peer Evaluator's core probe: whether the hire reduces or adds to their load. CASE |
| C8 | "When a complaint is sitting in a branch, where's the line between what the branch owns and what you own?" | JD | [grounded] | Propose seam principles and ask, rather than claim to know theirs: one named owner for each complaint, the lead owns the process and the data, the branch keeps the member relationship unless you agree otherwise. Tie to Own the Fix: whoever finds the problem keeps hold of it, so the seam question is where the finder needs help | The seam is the first question a peer asks. JD because the role owns the process across branches; the value gives you their own principle to build on |
| C9 | "The strategy brief has eight branches becoming five hubs over 2027. How does a complaints lead keep to 'Neighbours, Not Numbers' while that happens?" | CO | [grounded] | Handle it as a live subject for the people in the room. Do not claim knowledge of which branches or when, and do not say whether it is right. Reason from the value: keep complaints visible by town and branch during the change so members of a changing branch are not lost in aggregate numbers, and keep what members are told in plain words. Ask what they would want from the role during it | The brief's second item and the panel's own world. CO because it tests strategy altitude; VAL because it is scored against a named value |
| C10 | "Why you, over someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre" "6 years in retail banking, the last 3 as a branch supervisor" | Concede first: "I've never worked in a contact centre", and a candidate who has would know it better. Hold what you carry at its own scope: "6 years in retail banking, the last 3 as a branch supervisor." Do not say that you know what branch managers need, and do not run down contact-centre backgrounds. Close with how you would close the gap | The Pressure-style stem against F2, asked by people who may not mind the gap. JD because it scores fit to the stated requirement |
| C11 | "What draws you to a member-owned credit union?" | CO | [grounded] | Answer slot: give your actual reason in your own words. Do not borrow wording from the values page unless it is true for you; an honest, plainer answer reads better than a polished one | The JD says "member-owned", and the first value is about members. CO because it asks why this company |
| C12 | "What would your first month look like?" | JD | [generic] | A plan only: listen before you change anything, spend time with the contact centre and a few branches, read how complaints are logged across both, and decide what to measure first. Adjust each step to what you would really do | A conversational close that is still scored. JD because it tests the role's scope |

### Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | C1: a selection scaffold; no sentence of yours carries this story, so it ends in the honest branch |
| Plain Words | If a member needs it explained twice, the writing was wrong | F4: "trained new tellers on our escalation script", with the answer slot in C2 |
| Neighbours, Not Numbers | Every branch is part of its town | F6: "6 years in retail banking, the last 3 as a branch supervisor"; the story is a scaffold, C3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log", with the answer slot in C4 |

### Reverse questions: round 3

| Question | Why it lands |
|---|---|
| "What could a new complaints lead do in their first month that would genuinely help your branch?" | Reciprocity: it asks what you can give, not only what you get |
| "When a complaint is sitting in your branch, what do you most want from the person who owns the process?" | It lets them describe the seam in their own words |
| "Which of the four values is hardest to live up to day to day in your branch, and what gets in the way?" | It takes the values round seriously and invites an honest answer |
| "How are branch managers involved as the hubs take shape in 2027?" | Shows you read the brief; ask it respectfully and drop it if they would rather not say |
| "What would tell you, a year from now, that the complaints process had changed for the better?" | Turns their answer into the measure you would aim at |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log. C4's slot stays inside the log |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Reported complaint volumes and resolution times each month | Inflated form of F3 | F3's quote at its own scope. A8's slot asks only what the spreadsheet tracked |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers and the branch's script. B6's slot stays with the training |
| Handled complaints under regulatory rules | Inflated form of F7 | F7's quote at its own scope. B4's slot asks only what governed the log |

## Sources

Provided documents: the JD; the values text you copied this morning (20 November 2026) from ashgrovecu.org/about/values; the recruiter's email on the three rounds; your summary of four points from the July 2026 strategy brief; your background as described in your message. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the values cheat sheet and C1 to C4 |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email already states the three sessions, who runs each and what each holds, which fixes the loop and persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The July 2026 brief, about four months old, already supplies priorities, recent moves and the competitive frame; it fixes the grounding brief, B11 and C9 |
| 4. Interviewer name and company | n/a | No names were given, only roles, so there was no query to form |
| 5. Representative `Member Experience Lead` JD | skipped | The supplied JD fixes the fit snapshot and the JD-tagged questions |

I did not fetch the live values page or the full brief, so anything on them newer than your copies is not in this pack.

## Upgrade menu

- Exact times for each of the three rounds, and a check on the day, since 29 November 2026 is a Sunday → the triage can plan the final run-through around the real order and gaps
- A CV, or the bullets you would put on one → F1, F3, F4 and F6 sit at `medium` on your sentences alone; a copy of the monthly complaints spreadsheet or a log extract with member details removed would be the inspectable artifact that could move F3 and F9 toward `high`
- Your answers to the answer slots in F1, F3, F4, F5 and F7, and the notice, pay, location and reason-for-leaving answers → those rows regenerate with your own words in them, and A3 to A6 become quoted logistics
- Interviewer names, once assigned → persona weights read from public footprint, and a reverse question tied to each person's path
- The recruiter's guidance on the 20-minute case (shared in advance or live, what is scored) → C5 and C6 tuned to the real format
- The full strategy brief → the grounding brief rests on the document, not on a four-point summary
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): the full strategy brief if it can be found, interviewer talks and writing once names exist, role-family loop reports, and recent organisation context
- Hours available per day → the triage resizes to hours, not days
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and any claims already ruled out arrive in the pack ready to use
