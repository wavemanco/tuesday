I'll read the reference files before building the pack.
The pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-1-denied-32c7644f/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. I built it for a peer round with Dan, as a single 60-minute conversation.

All three of my web searches were refused (Northwind's values, its interview process, and Dan's public footprint). Everything about Northwind therefore comes from your research note, which is undated. There is no values cheat sheet, and the interviewer read uses only the profile summary you gave me. The Sources section accounts for each search.

The pack has 25 questions in seven persona banks, weighted for a peer: Peer Evaluator 5, Data-Driven Prober 5, Skeptic 4, Case/Strategist 4, Conversational 3, Pressure 2, Values 2. It also has a fit snapshot, an interviewer read, a requirement-coverage table, six reverse questions and a prohibited-claims list.

The highest-ROI rehearsal is C1: "You haven't done classic sales-ops or quota-setting work. How do you own GTM strategy for products the sales org has to carry?" Priya's own notes state that gap. Her "annual volume targets" are held at their own scope, not renamed as quotas. C4, on partner-motion design, is the second priority.

Some guidance cells are answer slots, where the pack asks Priya to say what she did in her own words. Her notes don't carry that detail, so the pack leaves it for her to supply. Sending her answers or her CV would turn those slots into quoted evidence.

Say the word and I'll play Dan as the Skeptic on C1, with live follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Did the recruiter name any focus areas or ask Priya to prepare something for the conversation with Dan, such as a POV or a presentation? If so, it would add a build section and retune the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy — a **peer** (both report to the same VP)
- **Format:** one 60-minute conversation
- **Built on:** the JD highlights, candidate notes, interviewer profile summary and research note you supplied. The JD is the highlights, not the full posting, so JD rows quote those highlights.

## How to use this pack

Personas are **how a question is asked**. Types are **what it scores**. Every question carries both, so you can rehearse the delivery and the content. Guidance is scaffolding, not a script: say it in your own words, and only say what you actually did.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether claims about your work survive scrutiny, including attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, competition, priorities |
| CASE | Structure and reasoning on a live problem from the role |

**Highest-ROI prep in this pack: C1**, the sales-ops and quota-setting objection. It will be asked in some form, and it is aimed at the one stated gap. Rehearse it until it is boring. C4 (partner motion) is second.

## Fit snapshot

Evidence cells hold only the candidate's own words as they appear in the coach's notes. Confidence grades the evidence, and nothing here has an inspected artifact behind it yet.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm" — the coach's notes; "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | The words stay at the quotes' scope: two years of strategy consulting, then nine years in product strategy & ops. The material says product strategy and ops, not go-to-market. Answer slot: the JD's GTM line makes a probe on go-to-market work likely. If any of that work covered how a product reached customers, say what it was and which part was yours, in your own words; if it was product-side only, or none of it was yours, say so plainly and stay with the product strategy & ops you did |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | At its own scope: a change was proposed, and it was credited with a ~$400M ARR uplift. The quote does not say which part of a customer's journey it touched or how the credit was assigned. Answer slot: the JD's land/adopt/expand/renew line makes a probe on how the opportunity was found likely. If you know how, say so in your own words; if it was not found that way, or you do not know, say so plainly and stay with what you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | discovery | The quote names the tools, not an analysis run independently. Answer slot: pick one analysis and say what question it answered and what you did; if it was a team's analysis, say which part was yours; if no such analysis comes to mind, say so plainly and say how you use the tools |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model at partner level, used in negotiations, not the design of a partner motion. Words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the word "required" makes a probe on how partners were engaged likely. If your part went beyond the model and its use, say what; if it did not, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap in wording, but it is one line from the coach's notes with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: annual volume targets, with consensus across orgs |
| F6 | Fluency in how sales sets quotas and plans capacity — role-family expectation for a GTM lead beside Sales Strategy; no JD highlight quotes it [generic] | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it is stated. Words: "I haven't done classic sales-ops or quota-setting work." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | Say it in the quote's terms: "I use AI tools daily." Nothing beyond that quote is claimed; what "daily" covers is rehearsed in E2 |

No row is a hard gate: none of the highlights states an eligibility, location, pay or credential term.

## Reading the interviewer

Public professional footprint only, and only what your profile summary gave. Nothing here is inferred about personality.

| Signal | Source | What it means for the conversation | Provenance |
|---|---|---|---|
| Describes himself as "relentlessly data-driven" | Your message, Dan's profile | Every number you say is a candidate for "how was that counted". Know what you can and cannot say about each figure, and say plainly when you do not know (B1 to B4) | [grounded] |
| Career spine is pricing and monetization roles | Your message, Dan's profile | Cases tilt to pricing, packaging and unit economics (D3, D4). Revenue-model vocabulary is common ground: your F4 quote, "built a partner-level revenue model used in carrier negotiations", is the natural bridge, held at its own scope | [grounded] |
| One early-stage-startup chapter | Your message, Dan's profile | Expect a probe on moving without large-company resources (C3). Founder-style or build-from-nothing stories land well with this kind of path, but only tell one your material carries | [grounded] |
| Peer, same VP | Your message | He is weighing what you cost and add to his work. Reciprocity and seam principles matter more than selling yourself (A1, A4, R2, R3) | [grounded] |

## Persona table

Weights come from three passes: the relationship prior (peer: Peer Evaluator plus Prober), the interviewer signals above, and the loop. Your own description fixes the loop as one 60-minute session with Dan, and names no values round, so none is detected and values stays low.

| Persona | Bank | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | A (5) | Seam-splitting, "what do you need from my team", credit and disagreement scenarios | Highest. The peer relationship is the prior, and Dan will share a VP with you | Reciprocity framing; offer seam principles instead of pretending to know the seam |
| Data-Driven Prober | B (5) | Line-by-line probing of the figure, the model, the targets, the analysis | Highest. His self-description is "relentlessly data-driven" and every one of your headline lines is a numbers line | Know what you can and cannot say about each figure; name the weakest assumption before he does; say plainly when you do not know |
| Skeptic | C (4) | Quiet probing of F6 and F4, the consumer-to-B2B move, why now | High. The one stated gap (F6) and the thin partner-motion evidence (F4) are exactly what a skeptical peer tests | Rehearse C1 until boring; bridge only from quoted evidence; state limits plainly, with a plan |
| Case / Strategist | D (4) | Live problems from the role: Compass launch, the bundling threat, pricing, profitability | Medium-high. The role owns GTM for new lines, and his pricing and monetization spine tilts cases that way. Peer rounds are less case-led than manager rounds | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Conversational | E (3) | Biography opener, "what are you playing with in AI", motivation | Medium. A 60-minute peer conversation almost always opens here, and the casual register is still scored | A 90-second arc built from your quotes; treat casual AI questions as scored |
| Pressure | F (2) | Time-boxed challenge, "how much was actually you" | Low. No signal in his profile points to a stress style, but a data-driven peer can sound like one | Pause, restate, hold the quoted position through two follow-ups, then concede specifically |
| Values / Behavioral | G (2) | Scenario probes on unpopular truths and customer-over-metric choices | Low. Your description names no values round, and I could not retrieve Northwind's published values this run, so these are persona-stem questions only | Choose a story your material carries, or say plainly that none comes to mind and give the nearest thing it does carry |

## Question banks

Each Provenance cell holds one label and then the candidate's own sentences the guidance rests on. A row with the label alone makes no claim about your past.

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where is the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | JD | [generic] | Say you do not yet know where the seam sits, and ask where it is drawn today. Then offer principles rather than a map: agree decision rights up front; settle disputes on shared definitions of the numbers; bring a disagreement to the VP only as a written tradeoff both of you have signed. These are how you would work, not claims about a past | The peer prior puts the seam question first, and F5's requirement is the JD line it scores. JD because it tests the cross-functional requirement; the delivery is peer |
| A2 | "Tell me about a time you got several orgs to agree on a number they all had a stake in." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5, at the quote's scope: the targets were annual, they were volume targets, and the consensus was across orgs. Tell it in those terms. Answer slot: expect a probe on where the orgs disagreed. If they did, say what the disagreement was and which part of the resolution was yours; if there was no real disagreement, or the resolution was not yours, say so plainly and stay with the targets | The JD's cross-functional line (F5) makes this an open prompt Dan can ask without having read anything. EXP because it tests what was actually yours |
| A3 | "Your store-surface change was credited with a large ARR uplift. How do you think about who gets credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Keep the quote's verbs: you proposed it, and it was credited with the uplift. Answer slot: if others built, shipped or measured it, name them by role and what they did; if no one else was involved, or you do not know who else was, say so plainly and stay with what you proposed. Never move "proposed" to "drove" | Credit is the peer probe on shared work, and F2 is the highest-profile claim. EXP because it tests attribution; peer because Dan will be sharing credit with you |
| A4 | "What would you need from my team in your first 90 days, and what could you do for it?" | JD | [grounded] "skilled in SQL/Tableau" | Needs: say what you would ask for, as a plan (shared definitions, access to the data your team already trusts). Offer: "I'm skilled in SQL and Tableau" is the quote you hold; any specific joint analysis is an offer about the future, not a past claim | The reciprocity question. F3 is the one quote that translates into something a peer's team can use. JD because it tests how the role plugs into Sales Strategy |
| A5 | "Two new product lines will compete for the same sales capacity. How do you decide whose pipeline gets prioritised, and how do you bring that to me?" | CASE | [grounded] enterprise expansion, the Compass copilot launch and profitability as Northwind's stated priorities, from your research note | Clarify first: how capacity is allocated today and who decides. Then criteria tied to the three stated priorities, a recommendation you would take to the VP with Dan, and the data you would want before committing. Concede what you cannot know yet. No claim about your past is needed | A live problem sitting exactly on the seam and the role's first real conflict. CASE because it asks for structure, with peer delivery |

### B. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that ~$400M figure was arrived at." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Defend-the-number, in your own words, with four slots. How it was counted: say so if you know, or say plainly you do not. What it is sensitive to: name it if you know it. The assumption you would defend least: name it before Dan does. Which part was yours: the quote says you proposed the change. Do not reconstruct a method you cannot repeat under a second question | A headline metric on a data-driven peer's desk is the first thing probed. F2 is that metric. EXP because it tests whether the number survives |
| B2 | "How did you check that revenue model against what actually happened?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold the quote: you built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: if you checked it against actuals, say how, in your own words; if it was not checked that way, or the checking was not yours, say so plainly and stay with the model and how it was used | Validation is the standard prober follow-up. F4 is the model. EXP because it separates "built" from "validated" |
| B3 | "How were those annual volume targets arrived at?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Say what the quote says: annual volume targets, with consensus across orgs. Answer slot: if you know how they were arrived at, say so in your own words; if you do not, or the method was someone else's, say so plainly and stay with the consensus. Name the assumption you would defend least | The targets line (F5) is the one with a method behind it, so it draws the denominator probe. EXP because it tests method ownership |
| B4 | "Tell me about an analysis you ran yourself in SQL or Tableau, from the question to the decision." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick one analysis where you can say the question, the data, what you did, and what decision it informed. Answer slot: if it was a team's analysis, say which part was yours. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry. Offer to walk through it end to end | The JD names independent analysis in SQL and Tableau (F3), and a data-driven peer will test it directly. JD because it scores the stated requirement |
| B5 | "Expansion revenue in one segment is flat while new-logo is growing. What do you pull first, and what would tell you it is whitespace and not churn?" | CASE | [generic] | Structure: define the metric, cut cohorts by land, adopt, expand and renew, check denominators, state a hypothesis, and name the assumption you would defend least. Think aloud; ask what data exists. No claim about your past is needed | Covers the JD's whitespace line (F2) in the prober's own register. CASE with a data-prober delivery |

### C. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't done classic sales-ops or quota-setting work. How do you own GTM strategy for products the sales org has to carry?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | **The highest-ROI rehearsal in this pack.** Open with the plain acknowledgment: "I haven't done classic sales-ops or quota-setting work." Then hold the quote at its scope: annual volume targets, with consensus across orgs. The pack's observation is that the material says volume targets, not quotas, so do not call them quotas. Answer slot: if a sales or field team carried those targets, say how you worked with them; if not, or you do not know, say so plainly and stay with the targets. Close with a plan, said as a plan: learn how Sales Strategy sets quotas and capacity before proposing anything for the new lines. Hold-then-concede: if Dan says "volume targets are not quotas", concede the difference specifically and return to the quote and the plan; on a second push, do not add experience to close the gap | F6 is the single stated gap and the likeliest objection to this candidate from a Sales Strategy peer. JD because it scores the requirement; the delivery is skeptical |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | Name your weakest area honestly. F6 is the stated one: "I haven't done classic sales-ops or quota-setting work." Pair it with the plan, not with a claim. If you would rank another area weaker, say that area and why, in your own words | The standard Skeptic stem, and a calibrated answer here pre-empts C1. JD because it asks you to rank the listed job |
| C3 | "You've spent nine years at one large consumer company. What makes you think you'll move at the pace of a 3,000-person B2B company?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Hold what the quote says: nine years at a large consumer-tech company, in product strategy & ops. Answer slot: if any of that work faced business customers or partners instead of consumers, say which; if none did, say so plainly. Then answer about pace with something you have actually done, in your own words; if nothing comes to mind, say so and describe how you would ramp | The single early-stage chapter in Dan's history makes pace a natural probe, and F1's evidence is entirely consumer-side. EXP because it tests the transfer of your experience |
| C4 | "Your model was used in carrier negotiations. This role requires partner-motion design experience. Where does the first end and the second begin?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The second-deepest rehearsal. Hold the quote: "I built a partner-level revenue model that was used in carrier negotiations." The pack's observation is that the material says a model, not a motion. Answer slot: say what the model was used for in those negotiations and what your part was; if you were not in the negotiations, say so plainly and stay with the model. Let Dan draw the line; do not draw it for him upward | "Required" in the JD makes F4 a probe a peer will not skip. JD because it scores a stated requirement; Skeptic because it is aimed at the gap |

### D. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Northwind is launching Compass. Sketch the GTM motion for the first two quarters. What do you need to know first?" | CASE | [grounded] "2 years strategy consulting at a top firm"; the Compass launch from your research note | Say your framework aloud and state a hypothesis early. Clarify who the buyer is and which existing customers are in scope; then objective, segmentation by land, adopt, expand and renew, motion, metrics, risks. Challenge one premise, for example whether Compass is sold standalone or through the existing platform, given the bundling threat. The consulting line is your quote for why the structure comes naturally; claim nothing more | Compass is one of the three stated priorities, and the role owns GTM for new lines. CASE and CO: the problem is live, and the vocabulary is the company's |
| D2 | "A much larger platform vendor starts bundling a competing capability into its suite. How should GTM respond?" | CASE | [grounded] bundling by a much larger platform vendor as the main competitive threat, from your research note | Do not recite the consensus answer; give one consensus item to show grounding, then one divergence with reasons, and an anti-pick (what you would not do, such as chasing a price war). Structure: what the bundle covers, which segments are exposed, what outcome you can prove that a bundle cannot, how pricing and packaging respond. Concede what you would need to see in deal data | The note names bundling as the main threat, so this is the likeliest strategy question. CASE with CO content; the anti-pick is the role's job of saying no |
| D3 | "A product line is priced per seat today, but customers consume data volume. How would you decide whether to move to usage-based pricing, and how would you test it?" | CASE | [generic] | Clarify first: who holds the pricing data, how customers' usage varies, how renewals are structured. Criteria: customer value alignment, revenue predictability, discount depth, effect on expansion. Test: a limited cohort with a pre-agreed readout. Invite Dan's view because pricing is his native ground. Name your weakest assumption | Dan's pricing and monetization spine makes this the likeliest case in his own language. CASE because it is a live decision; generic because it is a pattern, not a claim about Northwind |
| D4 | "Northwind is prioritising profitability alongside growth. A new line is growing but discounting is eroding margin. How do you decide whether to keep investing GTM effort?" | CASE | [grounded] profitability as one of Northwind's three stated priorities, from your research note | Structure: define the margin and payback measures, cut by segment and cohort, separate discounting that buys durable expansion from discounting that does not, set a decision rule and a review point. Say which numbers you would want first and which assumption you would defend least | The profitability priority and a data-driven pricing peer meet here. CASE with CO content |

### E. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | A 90-second arc in your own words: two years of strategy consulting at a top firm, then nine years at a large consumer-tech company in product strategy & ops. Pick the two lines the role touches most, the revenue model and the annual volume targets, at their own scope. Why you are moving now is yours to say; see E3 | The opener of a peer conversation is scored even when it feels safe. EXP because it is the CV walk; F1, F4 and F5 are the rows it must carry |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say it in the quote's terms: you use AI tools daily. Answer slot: say which tools and for what, in your own words; if the use is general productivity, say so plainly. Connect it to Compass only as curiosity about how it will be sold, never as building or launching AI products | The JD's AI-experience plus (F7), asked casually, with Compass making it live. JD because it scores the plus |
| E3 | "Why leave a role you've held for nine years, and why Northwind, why now?" | EXP | [grounded] the three stated priorities from your research note | Give your actual reason for leaving, in your own words; the pack does not supply one. Then say which of the three stated priorities (enterprise expansion, the Compass launch, profitability) genuinely pulls you, and why. Choose the one that is true for you | A motivation-consistency probe from a skeptical or friendly peer. EXP for the reason for leaving; the pull toward Northwind draws on the research note |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has run quota for a living?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Pause and restate the question. Concede the stated gap in one sentence: "I haven't done classic sales-ops or quota-setting work." Then hold only what the quotes carry: a partner-level revenue model used in carrier negotiations, and annual volume targets set with cross-org consensus. Through two follow-ups, return to those and the learning plan from C1; do not add anything | The time-boxed version of C1. JD because it scores fit; Pressure because the test is composure. F6 is the gap |
| F2 | "That ~$400M number. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold-then-concede: "I proposed the change; it was credited with the uplift." Hold that through two follow-ups. Concede specifically what you do not know about how the credit was assigned. Answer slot: if you know who else was involved and what they did, say so; if you do not, say so plainly | Attribution of F2 under pressure. EXP because it tests exactly how much was yours |

### G. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. No quoted sentence carries this story, so the pack supplies none | Standard behavioral stem. Tagged VAL because it is values-style, though Northwind's published values were not retrieved this run, so it is not mapped to a named value |
| G2 | "When have you put a customer or partner ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick an occasion with a real internal cost, a decision that was yours or one you argued for, and an outcome you can state. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Customer-first framing mirrors a pricing-and-monetization career. VAL with a selection scaffold for the same reason as G1 |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| "own GTM strategy for two new product lines" | C1, C2, D1, D2, D3, D4, E1 |
| "identify whitespace across land/adopt/expand/renew" | B5, D1 |
| "run independent analysis in SQL and Tableau" | B4, B5 |
| "partner-motion design experience required" | C4, B2, F1 |
| "strong cross-functional influence" | A1, A2, A3, A4, A5 |
| "AI experience a plus" | E2, D1 |
| Sales-ops and quota fluency (role-family, not quoted) | C1, C2, F1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has been pricing and monetization, with a stretch at an early-stage startup. What did that stretch change about how you think about pricing?" | It ties to his own path and turns the conversation from interrogation to peer talk. It shows you read his background and not only the company |
| R2 | "What could a new person on my side do in their first month that would genuinely help your team?" | The reciprocity question for a peer: you are asking how to reduce his load, not only what you need |
| R3 | "Where is the line between Sales Strategy and Emerging Products GTM today, and where is it still unsettled?" | It proposes you will respect the seam, and it surfaces the turf question A1 and A5 test |
| R4 | "Which two or three numbers would tell you in six months that GTM for the new lines is working?" | A data-driven peer will answer in metrics, which tells you how you will be judged and gives you something to repeat back |
| R5 | "How is the bundling threat showing up in deals today, and what has sales already tried?" | It shows you have the company's main competitive frame and asks for the deal-level reality the research note cannot give you |
| R6 | "How does the profitability priority change how the new lines are measured compared with growth?" | It connects the three stated priorities to the measurement that will govern your work, and invites the pricing-lens answer he is best placed to give |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says product strategy & ops, not go-to-market |
| Designed or ran a partner motion or partner program | Inflated form of F4 | F4's quote at its own scope. The material says a revenue model used in negotiations, not a motion. C4's slot stays inside the model |
| Set quotas, or did sales-ops or capacity planning | Negative the candidate stated, F6; F5's quote says volume targets | The plain acknowledgment F6 gives: "I haven't done classic sales-ops or quota-setting work." No slot. The volume-target quote is not renamed |
| Drove, generated or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: a change was proposed, and it was credited with the uplift |
| Built or shipped AI products, or has experience launching a copilot | Inflated form of F7 | F7's quote at its own scope: "I use AI tools daily." |

## Sources

- **Provided documents:** your message, covering the JD highlights, Priya's background notes, the interviewer profile summary and your research note on Northwind's priorities and competitive threat. No `tuesday-dossier.md` was present.
- **Searches sent (all refused, none returned results):**
  - "Northwind Data B2B data infrastructure company values" — refused
  - "Northwind Data interview process strategy GTM" — refused
  - "Dan Kovac Director Sales Strategy Northwind Data" — refused
- No pages were fetched. Everything about Northwind in this pack comes from your messages and your research note, which is undated.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | The search was refused. It would have fed a values cheat sheet; none is built, and G1 and G2 are not mapped to named values |
| 2. `Northwind Data interview process GTM` | unavailable | The search was refused. It would have documented the loop; your own description (one 60-minute conversation with a peer) fixes the session, so persona weights rest on that |
| 3. `Northwind Data strategy` / recent news | skipped | Could not have moved A5, D1, D2 or D4: your research note already supplies the three priorities and the competitive threat. The note is undated |
| 4. `Dan Kovac Northwind Data` | unavailable | The search was refused. It would have fed the interviewer read with talks and writing; the read uses only the profile summary you gave |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Full JD text** → the six JD-quoted rows are now built from highlights; the full text would add any mid-list requirement (a named tool or method) that currently has no question.
- **Priya's CV, or her answers to the answer slots in F1 to F4 and F7** → thin rows become quoted evidence; the pack regenerates the rows that draw on them. For this field the artifact that would raise a medium row to high is the model file or readout behind the revenue model and the ARR credit.
- **Recruiter or HR guidance** (stated focus areas, or a pre-declared deliverable such as a POV or presentation) → graded-deliverable build sections and coverage tuned to what Dan has been told to score.
- **Search permission, for a deeper research pass** (up to 6 more searches and 2 more fetches, several more minutes) → Northwind's published values, a documented loop, Dan's public talks and writing, and a dated strategy brief, which would also replace the undated research note. Search was refused this run.
- **A date or source for the research note** → confirms that D1, D2 and D4 are current rather than stale.
- **Prep time available** → a prioritized rehearsal schedule sized to it.
- **A `tuesday-dossier.md`** → would carry verified evidence and the likeliest objection from evidence rather than inference, and give each weak area a stated strategy and a binding prohibited-claims list.
