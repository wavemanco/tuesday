I'll read the skill's reference files before building the pack.
The pack is written and saved. Next I'm sending you the summary.

Your prep pack is saved as `larkfield-systems_engineering-manager_interview_pack.md`. I built it as a loop: one shared fit snapshot, then a mini-pack for each of Tuesday, the Thursday panel and Monday's VP round. Each mini-pack has its own persona weights, 8–9 questions and 5 reverse questions.

- **Research didn't run.** Web search was refused in this session. I couldn't check Larkfield's values, interview process or strategy. The pack has no values cheat sheet, and the company-knowledge questions are generic. The Sources section lists each refused search.
- **Evidence is thin.** The fit snapshot rests on the four sentences you gave me. Where they don't cover a requirement (growing engineers, the device-management domain), the guidance is a slot you answer from your own experience, not a story I wrote for you.
- **Highest-ROI prep is T-S2.** Expect the Tuesday question "You haven't owned a hardware-adjacent roadmap. How would you partner with our hardware team on ours?" The pack rehearses saying the limit first, then holding through three follow-ups.
- **The reliability quarter carries a lot.** It is your only roadmap-conflict story, and it appears in seven questions across the three rounds. Two more stories from your own experience would help most before Thursday and Monday.

Say the word and I'll play the Skeptic on T-S2, or any other persona and question.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full job description and your CV? Say skip and I'll leave the pack as it is. A CV would add evidence for growing engineers and for the device-management domain.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack — Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Role: Engineering Manager, two squads building device-management services, 11 engineers. Rounds: Tuesday, hiring manager (a Director of Engineering, your would-be boss), 45 min. The Thursday after, panel of two staff engineers and a product manager, 60 min. The following Monday, VP Engineering, 30 min, described by the recruiter as "values and leadership philosophy". No interviewer names were given, so there is no interviewer read.

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Each round has its own persona weights, bank and reverse questions; the fit snapshot, prohibited list, sources and upgrade menu are shared.

Question IDs read round, persona, number: T is Tuesday, P is the panel, M is Monday; S is Skeptic, C is Case/Strategist, N is Conversational, R is Peer Evaluator, D is Data-Driven Prober, V is Values/Behavioral, X is Pressure.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Whether your stated experience survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

Your material carries one story about roadmap conflict, the reliability quarter, and it appears in the guidance of T-S3, P-D1, P-C1, P-R3, P-V1, M-V3 and M-X1. The panel and Monday ask for more than one story, so two further stories from your own experience are worth more than polishing this one.

1. Before Tuesday: T-S2, the highest-ROI prep in this pack, until the limit and the concession come out plain. Then T-S1, T-S3 and T-N1.
2. Between Tuesday and Thursday: P-D1 (counting the 60%), P-R3 (the product seam) and P-C1.
3. Between Thursday and Monday: M-X1, M-V1 and M-V3, plus the two further stories.

Everything else is insurance.

## Fit snapshot

The requirements are lines from the role description you gave me. Your evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description, your message (the two-squads part) | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Say it at its own scope: "3 as a team lead of 6". Your material says one team of that size and does not show a second group. Answer slot: the role says two squads, so expect a probe on how you would divide attention between them. If you have led more than one group at once, say how, in your own words; if you have not, say so plainly and stay with the team of 6 |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description, your message (the delivery part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote is one prioritisation call on one team's quarter, with a 60% drop after it; it is not shown as owning delivery across two squads. Answer slots on the figure, in your own words: how the 60% was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say that plainly |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description, your message (the hiring part) | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | The quote already reaches hiring in the role's terms, but nothing is inspected behind it, so expect a probe. Lead with it as written: you run the loop, for backend roles. Your material says backend roles, so keep to that scope |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description, your message (the growth part) | none given | none | [grounded] | discovery | Your material is silent on growing engineers. Answer slot: expect a probe on how you develop people. If you have helped an engineer develop, say what you did, in your own words; if that was not part of your lead role, or did not happen, say so plainly and say how you would approach it |
| F5 | "partner with hardware and product on roadmap" — role description, your message (the product part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote carries a roadmap conflict and does not say who applied the pressure or whom you worked with. Answer slot: if you negotiated that quarter with a product counterpart, say how, in your own words; if product was not involved, or the call was made another way, say so plainly and stay with the quarter |
| F6 | "partner with hardware and product on roadmap" — role description, your message (the hardware part) | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | low | [grounded] | discovery | Your stated limit is owning, and the plain acknowledgment is yours: "I've never owned a hardware-adjacent roadmap." Your material does not say whether you have worked alongside a hardware team. Answer slot: if you have, say what the work was; if you have not, say so plainly. Then a plan stated as a plan, never as a past |
| F7 | "building device-management services" — role description, your message | none given | none | [grounded] | discovery | Your message places you at a payments company, and your material does not mention device management. Answer slot: if anything you have built touched devices or connectivity, say what, in your own words; if nothing did, say so plainly and say what you would ask the squads first |

The role description states no term such as location, schedule, travel or pay, so the snapshot has no gate row. The full JD may; see the upgrade menu.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 lead two squads | T-S1, T-C1, P-R1, M-X1 |
| F2 delivery | T-S3, P-D1, P-C1 |
| F3 hiring | T-N2, T-C2, P-D2, M-V4 |
| F4 growth | T-S4, M-V1 |
| F5 product roadmap | P-R3, P-C1, M-N1 |
| F6 hardware roadmap | T-S2, P-C2, M-X1 |
| F7 device-management domain | T-C3, P-D3, M-N2 |

## Round 1 — Tuesday, Director of Engineering (hiring manager), 45 min

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Derisking the step up: two squads, the hardware seam, and the limits you stated | High. The hiring-manager prior is Case/Strategist plus Skeptic, and a would-be boss is buying capability and pricing gaps. F1 and F6 are where your material is thinnest against the role | Rehearse T-S2 until it is boring. Say limits plainly, state plans as plans, hold the core through two follow-ups |
| Case/Strategist | Live problems from the squads' actual work | Medium-high. The same prior; 45 minutes fits one or two cases | Clarify before structuring, structure before answering, challenge one premise respectfully |
| Conversational | "Walk me through your journey", then casual probes on hiring | Low-medium. The opener is near-certain in a 45-minute round, and casual questions are still scored | A 90-second arc built only from your own sentences |

Depth follows weight: Skeptic 4, Case 3, Conversational 2.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-S2 | "You haven't owned a hardware-adjacent roadmap. How would you partner with our hardware team on ours?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The highest-ROI prep in this pack. Name the limit before it is asked for: "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked alongside a hardware team in any capacity, say what the work was, in your own words; if you have not, say so plainly. Then the plan, as a plan: what you would ask hardware and product in your first weeks about what is fixed and what can move. Follow-up 1, expect a collision between hardware's date and your squads' plan: hold with the one roadmap-conflict line your material carries, "I pushed a reliability quarter through against roadmap pressure". Answer slot: if you can say how that decision was made, say so in your own words; if it was not a negotiation with another team, say so plainly and stay with the quarter. Follow-up 2, expect "so you would be learning this on our time": concede exactly what is true, that owning a roadmap like this is something you have not done, and do not fold on what you do carry. Offer no timeline and no claim that you would pick it up quickly. Follow-up 3, expect your week-one steps: the plan again, in your own words | F6 is the role's headline partnership and the place your stated limit sits, so this objection arrives in some form; JD because it scores the stated hardware-and-product requirement, with Skeptic delivery |
| T-S1 | "This role leads two squads and eleven engineers. What is the biggest step up from what you have done so far?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers and never owned a hardware-adjacent roadmap" | Name the step in your own words, starting from what your quote carries: "3 as a team lead of 6". Say your limits as you stated them: you have not managed managers and have not owned a hardware-adjacent roadmap. Answer slot: expect a probe on how you would divide attention between two squads. If you have led more than one group at once, say how, in your own words; if you have not, say so plainly and stay with the team of 6. Close with a plan stated as a plan: what you would ask each squad in your first weeks | F1 is where a Director first tests scale, and F6 supplies the limit you volunteered; JD because it scores the stated lead-two-squads line |
| T-S3 | "The 60% drop in on-call burden you describe. How much of that was you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the position the quote carries: "I pushed a reliability quarter through against roadmap pressure", and the on-call burden was 60% lower after. Hold it through two follow-ups by returning to that sentence, never by adding to it. Answer slot, in your own words: which part of the quarter's work was yours and which was the team's; if you cannot separate them, say so plainly. Concede specifically where you cannot attribute, and say what the figure does not tell you | Quantified claims are the first thing probed, and F2 is yours; EXP because it tests attribution |
| T-S4 | "Tell me about a time you helped an engineer grow." | JD | [generic] | A selection scaffold: pick a time with a named stake, something you did, and a visible change in the person. No sentence in your material carries this, so no story is mapped. If no such time comes to mind, say so plainly, then say how you would approach it | The role names growth for 11 engineers and F4 is silent, so this is a likely free miss; JD because it scores a stated responsibility |
| T-C1 | "You take over two squads. One is behind on a committed date, the other is stable, and hardware and product each ask for something that conflicts with the other. How do you spend your first two weeks?" | CASE | [generic] | Clarify first: what is committed to whom, what is movable, who else is affected. Then structure: objective, what you need to see in each squad, how you sequence the conflicting asks, who you speak to and in what order, what you measure, what could go wrong. Say the framework aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem built from F1, F5 and F6 together, which is how a hiring manager tests the role's real shape; CASE because it scores reasoning rather than history |
| T-C2 | "You have one hiring slot and both squads want it. How do you decide?" | CASE | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Structure the decision: what each squad loses without the hire, the role profile, who weighs in, how you tell the squad that does not get it. You can anchor in the quote as written, "I run our hiring loop for backend roles", and keep to that scope. Answer slot: if you have had to allocate scarce headcount between groups, say how, in your own words; if you have not, say so plainly and describe how you would do it | F3 is your strongest row, so this is where it earns credit; CASE because it is a decision made live |
| T-C3 | "What would you want to learn in your first month about what the two squads run?" | CASE | [generic] | List your questions in the order you would ask them: who depends on these services and what happens when they fail; what the on-call load is and who carries it; what is committed and to whom; what hardware and product each expect of the squads. The list is a method, not a claim about your past. State your own starting point on the domain in your own words | F7 is silent, so a clarifying-questions exercise lets you show method without a domain claim; CASE |
| T-N1 | "Walk me through your journey, and why this role, why now." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A 90-second arc from those two sentences only: the quote on your years and your lead role, then the reliability quarter in its own terms. Answer slot: why you are leaving and why this role now. Give your own reason, and if it is partly unsettled, say so plainly rather than polishing one. The pack supplies no motive | The biography opener is near-certain and scored; F1 and F2 supply the beats |
| T-N2 | "Tell me how your hiring loop works." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Describe it in the quote's terms: you run it, for backend roles, with about 40 interviews last year. Answer slot: if you set any stage of the loop, say which and why, in your own words; if you inherited it, or no stage was yours to set, say so plainly and describe how you run it. On the 40, say how it was counted and what it covers, in your own words, or say you do not know how it was counted | F3 is the strongest match to the role's hiring line, and a casual question about it is still scored; EXP because it tests what was actually yours |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| T-1 | "How are the two squads set up today, and where would I fit in that structure?" | Settles the structure behind F1 so you are not guessing at what leading two squads involves |
| T-2 | "When hardware's dates and the squads' plan conflict, who decides, and how has that gone?" | Goes straight at F6 and turns a gap into a working conversation about the real seam |
| T-3 | "Where do you expect I would need the most help in my first quarter?" | Invites the Director's own view of the gaps, so the Skeptic conversation becomes joint |
| T-4 | "What would success look like at 90 days and at a year?" | Gives you the scoring sheet the rest of the loop is measured against |
| T-5 | "Which of the squads' commitments is the most at risk right now?" | Shows you think about delivery from the first day, and tells you what T-C1 resembles |

## Round 2 — the Thursday after, panel: two staff engineers and a product manager, 60 min

### Persona table

No names are known, so weights blend the top two personas of each seat's relationship, not per person.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between engineering and product, credit, how you lead people who know the systems | High. The peer prior fits all three seats, since each is pricing what you add to their work; the product seat adds the roadmap seam | Reciprocity framing, seam principles rather than a claimed seam, disagreement with spine and tact |
| Data-Driven Prober | Counting the 60%, checking the hiring loop | Medium-high. The technical-specialist prior is Prober plus Pressure; staff engineers who read your material will go to its figures | Say what you can and cannot say about how each number was counted, and name your weakest assumption first |
| Case/Strategist | Reliability against roadmap; hardware slipping | Medium. A 60-minute panel with a product seat tends to carry one or two live problems, and the role's roadmap partnership supplies them | Clarify, structure, think aloud |
| Values/Behavioral | One scored behavioral conversation from the product seat | Low-medium. The cross-functional prior is Values plus Conversational, but the loop puts the values round on Monday | Choose a story where the hard truth landed, or say none comes to mind |

Depth follows weight: Peer 3, Prober 3, Case 2, Values 1.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-R3 | "Product and engineering sit side by side. Where is the seam on the roadmap, and what happens when we disagree?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Offer seam principles, not a claimed seam: who owns the what, who owns the why, and how a disagreement is escalated and decided. Say you do not yet know theirs. The one roadmap conflict your material carries is "I pushed a reliability quarter through against roadmap pressure". Answer slot: if you can say who was pressing and how the decision was reached, say so in your own words; if it was not a disagreement with product, say so plainly and stay with the quarter | F5 is the requirement the product seat scores, and the stated stem for peers is exactly this seam; JD because it scores the roadmap-partnership line |
| P-R1 | "Staff engineers on these squads will know the systems better than you do. How would you lead them?" | JD | [generic] | Structure around decision rights: what you decide, what you defer, how you learn the systems from them, how you disagree and what happens when you do. Offer principles and make no claim about a seam you have not seen. Say what you would take off their plate | F1 includes leading people with more system depth, and two seats are staff engineers; JD because it scores the lead-the-squads line |
| P-R2 | "Tell me about a time you disagreed with a technical lead and how it resolved." | VAL | [generic] | A selection scaffold: a named disagreement, a position you held, and a working relationship intact at the end. Your quoted material does not carry a disagreement with an engineer, so no story is mapped here. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Disagreement style with equals is what the peer persona scores; VAL because it asks for past behavior |
| P-D1 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The prober's question. Answer slots, in your own words: how the figure was counted, what it is sensitive to, and the assumption you would defend least. Name that assumption before they do. If you do not know how it was counted, say so plainly. Say only what the quote says: the burden dropped 60% after you pushed the quarter through | F2's figure is the one metric in your material, and F2's slots are exactly these; EXP because it tests whether the number survives |
| P-D2 | "You run the hiring loop for backend roles. What, if anything, do you check to see whether it is working?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start from the quote at its scope: you run it, for backend roles, with about 40 interviews last year. Answer slot: if you check anything after hires start, say what and how, in your own words; if you check nothing, say so plainly and say what you would look at first | F3 is a message line with nothing inspected behind it; EXP because it probes what was actually yours |
| P-D3 | "What parts of what you have built would transfer to device-management services?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start from the quote and say plainly that it places you at a payments company. Answer slot: if any service you built touched devices or connectivity, say what, in your own words; if none did, say so plainly and say what you would ask the squads first | F7 is silent in your material; a staff engineer will go to it first; JD because it scores the stated domain |
| P-C1 | "A staff engineer says a reliability fix should displace a committed feature, and product says no. You are the manager. What do you do?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure: what the fix prevents and what the feature earns, who has to be in the decision, what you would ask each side, how you communicate the outcome, what you would measure. You may point to "I pushed a reliability quarter through against roadmap pressure" as the nearest line your material carries. Answer slot: if a staff engineer was part of that decision, say what part, in your own words; if not, say so plainly and stay with the quarter | This case sits where F2 and F5 meet and is the panel's most direct use of your story; CASE |
| P-C2 | "Hardware slips their ship date by six weeks. What happens to your squads' plan?" | CASE | [generic] | Clarify first: what depends on that date, what is already committed, and what is movable. Then re-sequence, tell the people affected in a stated order, and say what you would watch. State the limit: you do not know hardware's constraints, and say how you would learn them. The question needs no claim about your past | F6 is where you are thinnest, and a hypothetical lets you show method; CASE |
| P-V1 | "Tell me about a time you said no to a stakeholder and kept the relationship." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The only line your material carries is "I pushed a reliability quarter through against roadmap pressure". Answer slot: if there was a conversation where you said no, say who it was with and where the relationship stood after, in your own words; if that was not how it went, say so plainly. If no such time comes to mind, say so, then give the nearest thing your material does carry, or how you would handle it | The product seat scores partnership under disagreement; VAL because it asks for past behavior; F5 is the row it draws on |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| P-1 | "What could a new manager do in their first month that would genuinely help your work?" | Reciprocity for the staff-engineer seats: it asks what you can add before what you need |
| P-2 | "Where does the product and engineering seam go wrong most often today?" | Aimed at the product seat and at F5; the answer tells you what P-R3 was really probing |
| P-3 | "How does on-call load show up for the two squads?" | Ties to the reliability quarter in your own material, in a way that opens a peer conversation |
| P-4 | "When engineers disagree with a roadmap call, how does that get resolved now?" | Shows you care about the decision path, and tells you what leading these engineers involves |
| P-5 | "What does the squads' working relationship with hardware look like from where you sit?" | A direct reading of F6 from the people closest to it |

## Round 3 — the following Monday, VP Engineering, 30 min

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Leadership philosophy and scored behavioral stories | High. The recruiter's own words for this round are "values and leadership philosophy", and the dedicated-values prior is Values plus Conversational | Map a story to each question where a quoted sentence carries one, and a selection scaffold ending in its honest branch where none does; "we" for context, "I" for contribution |
| Conversational | Short, open "what draws you" questions | Medium. Thirty minutes leaves room for rapport, and casual questions are still scored | Pre-script a short arc; treat casual questions as scored |
| Pressure | "Why you, over someone who has done this" | Medium. The skip-level prior adds Pressure, and your stated limits give it material | Pause, restate, hold the core through two follow-ups, concede exactly |

Depth follows weight: Values 4, Conversational 2, Pressure 2.

No published company values were in hand (see Sources), so there is no values cheat sheet. The values questions use persona stems and the recruiter's phrase, and where no sentence of yours carries a story they are selection scaffolds.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-X1 | "Sixty seconds: why you, over a manager who has already led managers or owned a hardware roadmap." | EXP | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause and restate the question. Concede first, in your own words: you have not managed managers and have not owned a hardware-adjacent roadmap. Then lay out what your sentences carry, at their scope: 3 as a team lead of 6, you run the hiring loop for backend roles, and the reliability quarter. Hold through two follow-ups by returning to those sentences, never by adding to them. Answer slot: what you offer beyond those lines, in your own words; if nothing comes to mind, say so plainly. Do not call yourself ready for it | F1 and F6 are where a Pressure interviewer goes; EXP because it tests whether your story survives cross-examination |
| M-V1 | "What is your philosophy on leading engineers?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Describe what you did, using those three lines at their scope, and let the VP draw the inference. Answer slot: the principle behind them, in your own words; the pack states none, and an inference you assert about yourself is the one that gets tested. If nothing comes to mind, say so plainly and say how you would lead | The recruiter's own words for this round are "leadership philosophy"; F1 and F3 carry the beats |
| M-V2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold: a named stake, a moment you did not give way, a relationship intact after. Your quoted material does not mention a customer, so no story is mapped here. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The stem is the Values persona's own; VAL because it asks for past behavior |
| M-V3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Your material carries "I pushed a reliability quarter through against roadmap pressure" and no more. Answer slot: if leadership was part of that pressure and you said something they did not want to hear, say what and how it landed, in your own words; if it was not leadership, or no such conversation happened, say so plainly. If no such time comes to mind, say so, then give the nearest thing your material does carry, or how you would handle it | Another stem the Values persona uses, and F2 and F5 are the only rows near it |
| M-V4 | "Tell me about a time the hiring loop surprised you." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start from the quote at its scope. Answer slot: if the loop surprised you, say what and what you did about it, in your own words; if it did not, say so plainly and describe how you run it. If no such time comes to mind, say so, then say how you would handle it | The role names hiring and F3 is your strongest row; VAL because it probes judgment and values through a real event, not a stated one |
| M-N1 | "So, what draws you to leading two squads here?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: give your own reason in your own words; the pack supplies none. Tie it to lines the role states, "partner with hardware and product on roadmap" and "building device-management services", only where they are genuinely part of your reason. Say your starting point plainly from the quote | A rapport question is still a motivation probe; F1, F5 and F7 give the role's side |
| M-N2 | "What do you know about what industrial IoT customers need from device management?" | CO | [generic] | Answer slot: say what you have learned in preparation, in your own words, and if it is little, say so plainly and ask the VP what matters most. No research ran for this pack, so the pack supplies no facts about the company or its customers; read the company's own pages before Monday | A CO question the pack cannot ground without research; F7 is why it matters |
| M-X2 | "Tell me what you would get wrong in your first 90 days." | JD | [generic] | Name your own answer, in your own words, before it is extracted from you, and tie it to the limits you stated: managing managers and the hardware-adjacent roadmap. Pair it with a plan stated as a plan. The pack names no mistake for you | The Pressure persona probes self-assessment; JD because it scores fit against the role's gaps |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| M-1 | "What does leadership look like here when it is working well?" | Matches the round's own subject and lets the VP define the standard you are scored on |
| M-2 | "Which of the company's values is hardest to live by in practice?" | Invites candor about values, and shows you listen for the gap between stated and lived |
| M-3 | "How do you see an engineering manager's path here, including to managing managers?" | Names your stated limit as a direction you want, without claiming it |
| M-4 | "What is the company betting on for device management over the next two years?" | Substitutes for the strategy research that did not run, and lets the VP supply the current picture |
| M-5 | "What do you most want to see from a new manager in the first quarter?" | Gives you the VP's own bar, which the Director and the panel can then be measured against |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | A negative you stated | "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | A negative you stated | "I've never owned a hardware-adjacent roadmap." No slot |
| Led two squads, or a team of 11 | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation: your material says a team of 6, and the role says two squads |
| Owned delivery across a roadmap | Inflated form of F2 | F2's quote at its own scope. The slots stay inside the quarter |
| The reliability quarter caused the 60% drop | Inflated form of F2; the quote says the drop came after | F2's quote at its own scope. The slots ask only how the figure was counted and which part was yours |
| Made hiring decisions or owned headcount | Inflated form of F3 | F3's quote at its own scope: you run the loop, for backend roles |

## Sources

Provided documents: your message, which holds the role description, the three round descriptions, the recruiter's phrase for Monday, and the candidate sentences quoted in F1 to F7. The loop rests on those words, so no archetype fallback was used; the values-style round is detected from the recruiter's description of Monday.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused (web search was not permitted in this session):

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have produced the values cheat sheet and names for the VAL questions; no section 10 in this pack |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have added case formats; persona weights are unaffected because your own words fix the three rounds |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have grounded CO and CASE questions; they stay generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so no query could be formed; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | The role description you gave fixes the requirement column of the fit snapshot |

## Upgrade menu

- The full JD text → the seven rows quoting the role description would be checked against the posting's own list, and any stated term such as location, schedule, travel or pay would become a gate row
- Your CV → every evidence cell currently rests on four sentences from your message; a CV would add rows for F4 and F7 and may supply stories for P-R2, M-V2 and M-V3
- Two or three further stories from your own experience on disagreement, saying no, and developing an engineer → the selection scaffolds in T-S4, P-R2 and M-V2 become mapped stories
- Any artifact that backs the 60%, such as the on-call dashboard or the incident counts before and after → F2 moves from medium toward high and the defend-the-number slots can be answered precisely
- Web search permission → the three refused searches could be rerun at L1 for values, loop structure and strategy; a deeper pass would add up to 6 further searches and 2 further fetches, several more minutes, and would let CO and CASE questions rest on the company's current strategy
- Interviewer names → an interviewer read, persona weights per person, and a reverse question tied to each person's own path
- The recruiter's prep email → any focus areas or pre-declared deliverables for the panel and for Monday
- A tuesday-dossier.md from an earlier session, if you have one → it would carry verified evidence and constraints into this pack
