I'll read the reference files the skill points to before building the pack.
The pack is done, and I'm wrapping up the message to you. It's saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-2-denied-33672a1c/atlas-freight_operations-manager_interview_pack.md`.

I built it for a hiring-manager round, since you didn't say who you're meeting. The web search was refused in this session, so nothing in it comes from Atlas Freight itself. It rests on your JD and your background, and it has no company-values or strategy questions.

It has 20 questions across six interviewer styles, a fit table of the JD against your own sentences, a list of claims it won't coach, and reverse questions for you to ask.

Say the word and I'll play the Skeptic on A2 ("You currently lead three supervisors; this role has twelve across four sites. What changes at that scale?"). That's the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting (your future manager, a peer, a recruiter, someone more senior), and did the recruiter mention any focus areas or a take-home? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Round type: not stated, so this pack is built on a hiring-manager prior. That makes the persona weights weaker than they would be with the real relationship.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for your own words, not a script, and each guidance cell is meant to be speakable in 90 to 120 seconds.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment. Not used in the banks: no published Atlas Freight values were read and no values round is documented |
| EXP | Work-experience deep-dive: whether your claims survive scrutiny |
| JD | Role and JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge. Not used in the banks: no company research landed, so none would be grounded |
| CASE | A live problem from the actual role |

Question IDs run by persona: A, B, C, D, E and G. Fit-snapshot rows are F1 to F7.

## Prep triage

Interview next week, so these come first, in this order:

1. A2, the highest-ROI prep in this pack. Rehearse it until it is boring.
2. C1 and E2: how the 40% was counted and which part was yours.
3. A1, A3 and D3: the plain acknowledgments.
4. B1 and B2: say the case structures out loud once each.
5. D1: your 90-second arc.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "ran the site's peak-season surge plan two years running" — your message; "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution operations and a surge plan for the site, not terminal operations or four sites, and the words stay at that scope: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-sites line makes a probe on multi-site responsibility likely. If any of your work reached beyond the site's plan, say what and how, in your own words; if it did not, say so plainly and stay with the plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says mis-pick rate, not the two measures the JD names, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: expect a probe on what else you tracked. If you tracked other measures besides mis-picks, say which and how each was counted, in your own words; if you did not, say so plainly and stay with the mis-pick figure |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors and the JD says 12, and the words stay at your scope: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's twelve makes a probe on span likely. If you have led a larger group at any point, say who and when, in your own words; if not, say so plainly and stay with the three |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | medium | [grounded] | discovery | Your message says Excel skill, not what you built with it: "I have solid Excel." Answer slot: the JD's build-reporting line makes a probe on what you built likely. If you built reports other people used, say which and for whom, in your own words; if you used Excel but built no reports for others, say so plainly and stay with the skill |
| F5 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan in your own words and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | A years requirement is graded like any other row, not a gate. Your material gives seven years in operations and a current role over supervisors, and does not show how many of the seven were in leadership. Answer slot: expect the count. Give your own count in your own words; if the leadership part is shorter than five years, say so plainly and stay with the seven years and your current role |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap on the JD's terms, but a message line with no certificate shown, so expect a probe. Lead with the quote's own terms: "I'm green belt certified." |

## Persona table

No loop source was read, so the loop rests on the generic archetype (screen, hiring manager, panel) rather than on Atlas Freight's documented process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet probing of scale and background: 3 supervisors against 12, warehouse against terminals | High. Hiring-manager prior, and F3, F1 and F6 are the rows where the JD outruns your quotes | Rehearse the span-of-control objection (A2) until it is boring; concede scope in your quote's terms; give a ramp plan as a future |
| Case / Strategist (bank B) | Live operations problems: a service dip, a cost spike, a surge, daily visibility across sites | High. Hiring-manager prior, and the JD is operations-owner language | Clarify, then segment, then approach, then metrics, then risks, thinking aloud |
| Data-Driven Prober (bank C) | Walks the CV line by line and probes the 40% | Medium. Hiring-manager prior lifts the Skeptic, not the Prober, but the JD's on-time-performance and cost-per-shipment lines and your headline figure make the probe likely | Know what you can and cannot say about how the 40% was counted; say plainly where you do not know |
| Conversational (bank D) | Opening biography, casual questions about the JD's Lean and Power BI lines | Medium. Almost every loop opens here, and casual questions are still scored | A 90-second arc; treat the casual tool questions as scored |
| Pressure (bank E) | Time-boxed challenge on why you and how much was you | Medium-low. No signal either way about the interviewer's style; a manager hiring for an operations owner may test composure | Pause, restate, anchor in what you said, hold through two follow-ups |
| Peer Evaluator (bank G) | Seam and credit questions with the other site leads | Low. The JD names a team to lead, not a peer group, but you will work alongside other functions | Seam principles, not pretend knowledge of the seam; reciprocity framing |
| Values / Behavioral | Not banked | Low. No published values were read and no loop source documents a values round | Supply the company's published values or the round type and this bank gets built |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "currently a senior shift manager over 3 supervisors" | Pick the one gap you will name first, and say it in the quote's own terms: "I've never used Power BI" or "I'm currently a senior shift manager over 3 supervisors." Then give a ramp plan in your own words, stated as future and never as a past. Hold-then-concede: name it once, specifically, and do not retreat from what your quotes do carry | F5 and F3 are the two rows where the JD outruns what you wrote, and a rehearsed candid answer is the cheapest credibility gain available. JD because it scores the listed requirements, gaps included |
| A2 | "You currently lead three supervisors; this role has twelve across four sites. What changes at that scale?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Concede the scope in those terms and stop; the concession is the scope, not an apology. Likely follow-ups, each answered from your own material: "Who else has reported to you?"; "How would you split your week across four sites?"; "What would you do in the first thirty days?" Answer slot: if you have led a larger group at any point, say who and when, in your own words; if not, say so plainly and answer the other two as a plan, in the future tense | F3 is where the JD's mandate presses hardest, so this objection arrives in some form. JD because it scores the stated requirement |
| A3 | "The JD asks for five-plus years of operations leadership. How many of your seven years were spent leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer with the count, in your own words and no larger than the truth. Start from the quote: "I have 7 years in warehouse and distribution ops," then give your own leadership count. Answer slot: if the leadership part is shorter than five years, say so plainly and stay with the seven years and your current role | F6 is the row the probe lands on, and it is a count, so the answer is either ready or it is not. JD because it scores a stated requirement |
| A4 | "You've worked in warehouse and distribution. This role runs terminals. What do you know about running a terminal?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start with the quote's own terms: "I have 7 years in warehouse and distribution ops." Then answer as a plan, not a past: what you would ask first about how a terminal runs and what you would want to see on your first walk of one. Questions you would ask are safe; claims about terminals are not | F1 is the nearest evidence and it does not name terminals. JD because the question scores the listed responsibility; the guidance stays a plan because the quotes carry no terminal work |
| A5 | "Why leave a senior shift manager role for this one, and why Atlas Freight?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Give your own reason for leaving, in your own words, one or two sentences. Begin from "I'm currently a senior shift manager over 3 supervisors," then say what draws you to the role as the JD describes it. Cite no company facts: none were researched | The Skeptic's why-leave-why-here probe tests motivation consistency, and F3 frames the move. EXP because it tests your own account of your path |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four sites has slipped over three weeks. Walk me through how you'd diagnose it." | CASE | [generic] | Structure it aloud: clarify how on-time is defined and measured at that site; split the slip by shift, lane, customer and inbound against outbound; name the data you would pull; separate the quick containment from the root cause; say how you would brief the supervisors; name the measure that tells you it is fixed. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's on-time line (F2's requirement), asked as a decision. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "Cost per shipment is rising at one site and flat at the others. What do you look at first?" | CASE | [generic] | Clarify what is inside the cost figure and over what period; break it into labor, transport and everything else; check volume and mix before blaming efficiency; compare the site against the flat ones; propose one test before any change. Think aloud and challenge one premise respectfully | The JD's cost-per-shipment line (F2's requirement) as a diagnosis. CASE because it scores structure over a right answer |
| B3 | "Volume jumps for two weeks across all four sites and the supervisors are the same people. Plan it." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure first: forecast the surge, staff and shifts, dock and yard capacity, communication cadence with supervisors, a daily check, an end condition. Where the story is yours, tell only what the quote states: you ran the site's peak-season surge plan, two years running, in your own words | F1 carries the surge plan. CASE because it is a live problem; the one candidate sentence it draws on is quoted |
| B4 | "You have twelve supervisors across four sites and can't be everywhere. How do you know what's happening each day?" | CASE | [generic] | Name a daily rhythm, the few numbers every supervisor reports against, what triggers an escalation, how you pick which site to walk, and how you check the numbers are true. State a trade-off: more visibility costs supervisor time | The JD's four sites and twelve supervisors (F1 and F3's requirements) as one live problem. `[generic]` because it is a pattern, not a claim about Atlas Freight |
| B5 | "Describe the reporting you'd put in front of site supervisors each morning, and how you'd build it." | JD | [grounded] "solid Excel"; "never used Power BI" | Few measures, a named owner for each, one cadence, and what each would make a supervisor do differently. On tools, say what the quotes carry: "I have solid Excel" and "I've never used Power BI," then a plan to learn it in the future tense. Answer slot: if you built reports other people used, say which and for whom, in your own words; if not, say so plainly and stay with the skill | F4 and F5 are the row pair this probes. JD because the build-reporting line is a stated requirement |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-pick rate 40% by redesigning the pick path. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what the quote states: the mis-pick rate, the 40%, the pick-path redesign. Four slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly. Never supply a baseline or method you cannot repeat under a second question | F2's headline figure is where a Prober starts. EXP because it tests whether the claim survives scrutiny |
| C2 | "Mis-picks aren't what this job is scored on. What else moved when you redesigned the pick path?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Stay with the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked other measures besides mis-picks, say which and how each was counted, in your own words; if you did not, say so plainly and stay with the mis-pick figure | F2's gap, asked as a probe. The question assumes only the quote and the JD's scoring; the slot lets the premise be false |
| C3 | "For the peak-season surge plan you ran two years running, what were the numbers that mattered?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Start from the quote: "I ran the site's peak-season surge plan two years running." Answer slot: if specific numbers were tracked, name them and how each was counted, in your own words; if none were, or they were not yours, say so plainly and describe the plan as the quote states it | F1's second quote, probed for measurement. The question presupposes only that a plan was run, which the quote says |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey in a couple of minutes." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Build a 90-second arc from those five sentences and nothing else, in the order that sounds natural to you. End on why this role, in your own words. Practise it out loud; the casual register is still scored | Every loop opens here, and F1, F2, F3, F6 and F7 are the material. EXP because it tests the account of your path |
| D2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Start from "I'm green belt certified." Answer slot: if you are applying it somewhere now, say where and how, in your own words; if not, say so plainly and stay with the certification | F7 is the JD's plus-skill, asked casually. The question premises only the JD's line |
| D3 | "Any experience with Power BI?" | JD | [grounded] "never used Power BI" | One line: "I've never used Power BI." Then your plan for learning it, in the future tense and in your own words, and stop. No bluff and no hedge | F5 is a stated gap, and a casual question is the likeliest place it surfaces. JD because it scores a named tool |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you for this role over someone who already runs several sites?" | JD | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "currently a senior shift manager over 3 supervisors" | Pause, restate the question, then hold on what the quotes carry: you ran the site's peak-season surge plan two years running, and you cut mis-pick rate 40% by redesigning the pick path. Concede scope in the quote's terms: "I'm currently a senior shift manager over 3 supervisors." Do not claim to out-scale a multi-site manager | F1, F2 and F3 together. JD because it scores fit against the listed role, under a time box |
| E2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause, then hold through two follow-ups. Answer slot: say which part was yours and which was others', in your own words; if others did most of it, say so plainly. Keep the quote's own verb, "redesigning," and do not upgrade it | F2's attribution probe, the standard Pressure stem. EXP because it tests what was actually yours |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles rather than pretending to know the seam: one owner per measure, shared definitions, a named escalation route. Say what you would bring the other team, not only what you would need | A collaboration probe from the stem; F1's multi-site requirement is where it would sit. `[generic]` because it makes no claim about Atlas Freight |
| G2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Use "we" for context and "I" for contribution, and keep "I" to what the quote states: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if others contributed, say who and how, in your own words; if you did it alone, say so plainly | F2 is the one result in your material where credit could be questioned. EXP because it tests attribution honesty |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A4, B1, B3, B4 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C2, C3 |
| "lead a team of 12 supervisors" | A2, B4 |
| "build reporting in Excel/Power BI" | B5, D3, A1 |
| "5+ years operations leadership required" | A3 |
| "Lean/Six Sigma a plus" | D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which of the four sites would you most want the new person to look at first, and why?" | It shows you are already thinking in terms of four sites, and the answer tells you where A2's ramp plan should start |
| 2 | "How are on-time performance and cost per shipment defined and reported today, and who owns each number?" | It is the first thing B1 and B2 say you would clarify, so it shows the same instinct |
| 3 | "What does reporting look like now, and who builds it?" | It surfaces the Power BI question on your terms, after D3's plain answer, and tells you how much ramp time to plan |
| 4 | "Of the twelve supervisors, how long have they been in role, and what support do they get today?" | It turns A2 from an objection into a planning conversation |
| 5 | "What would success look like at ninety days and at a year?" | It lets you check your prep priorities against what they will actually measure |
| 6 | "What has been hardest for the people who have run these sites?" | It invites the interviewer to name the real problem, which you can then rehearse |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material says warehouse and distribution operations and the site's surge plan, not terminal operations or four sites. |
| Drove down on-time performance or cost per shipment | Inflated form of F2 | F2's quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." The limit is the pack's observation: your material says mis-pick rate. C2's slot asks only what else you tracked |
| Led or managed twelve supervisors | Inflated form of F3 | F3's quote at its own scope: "I'm currently a senior shift manager over 3 supervisors." A2's slot asks only whether you led a larger group at any point |
| Used Power BI | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." Then a plan, in the future tense. No slot |

## Sources

Provided documents: the job description text and your background as you wrote them in your message.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

All three searches were refused by the host, so nothing was read from the web. Queries sent, each refused:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news 2026" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions; neither is in the pack |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have named the real rounds; persona weights rest on the generic archetype and a hiring-manager prior instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have grounded CO questions and a grounding brief; the pack has no CO bank |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The round type and who you are meeting (future manager, peer, recruiter, someone senior) → persona weights recomputed and banks added or dropped, plus a reverse question tied to their path if you share a profile
- The recruiter's prep email, or anything they said about focus areas or a take-home → coverage of any pre-declared deliverable
- Web search permitted → Atlas Freight's published values, loop structure and current strategy, which would add a values cheat sheet if a values round is documented, CO questions, and a grounding brief
- Your own answers to the answer slots in F1, F2, F3, F4 and F6 (multi-site reach, other measures tracked, any larger group led, reports built, your leadership-years count) → those rows get quoted evidence and A2, A3, B5, C2 and C3 can be tightened
- Your CV text, if you have one beyond the summary you gave me → more quotable sentences for the fit snapshot, and sharper story maps for D1 and B3
- A `tuesday-dossier.md` from an earlier evidence review, if you have one → verified-claim grading and a ready prohibited-claims list; without one, this pack graded your evidence and built its prohibited list from your message
