I'm building the full prep pack now. Your message already covers the values, the three-round loop and the strategy points, so I'm not running any web searches. I'm saving it to the working directory.
Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop from the recruiter's email: recruiter screen, Head of Member Services, then the branch-manager panel with the case and values round. It has 30 questions across the three rounds, a fit snapshot, a values sheet for the panel, reverse questions for each round, and a prohibited-claims list. I ran no web searches because your message already covered the JD, the values, the loop and the four strategy points.

**What stands out for you, Dara:**
- **The contact-centre gap is the big one.** You've never worked in a contact centre and the role owns the process across branches and the contact centre. B3, "weakest on day one", is the highest-ROI rehearsal, and F2 is the same objection coming back from the panel. The pack coaches you to name the gap first, hold only what your own sentences carry, then give a plan.
- **Two published lines pull against each other.** "Own the Fix" says whoever finds the problem keeps hold, but the role coaches escalation. F3 prepares you for the panel asking who keeps hold when a supervisor escalates.
- **The hub consolidation sits under the panel's values.** Eight branches becoming five hubs meets "Neighbours, Not Numbers" in front of branch managers. D6 prepares for it.

I noticed 29 November 2026 falls on a Sunday, so it's worth confirming the date with the recruiter.

Several rows end in answer slots, such as what your complaints log was subject to, what your spreadsheet counted and in which tool, and whether you've worked with digital teams. Tell me those in your own words and I'll rewrite the rows that depend on them.

Say the word and I'll play the Skeptic on B3, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview pack for Dara

Loop: three rounds on 29 November 2026, built from the recruiter's email.

| Round | Who | Length | Shape |
|---|---|---|---|
| 1 | The recruiter | 30 min | Recruiter screen |
| 2 | Head of Member Services, who would be your manager | 45 min | Mostly behavioural |
| 3 | Panel of two branch managers | 60 min | 20-minute case on a complaint escalation, plus the values round, scored against the four values |

Interviewer names are not yet assigned beyond these roles, so there is no interviewer read in this pack.

The highest-ROI prep in the pack is B3, "Which part of this role would you be weakest at on day one?", in round 2. The second is F2, the same objection coming back from the panel in collegial packaging. Rehearse these two until they are boring.

## How to use this pack

- **Personas** are how a question is asked. **Types** are what it is scoring. Every question carries both, so you can see coverage at a glance.
- Type key: **VAL** is values and behaviour against Ashgrove's published values. **EXP** tests whether your background survives scrutiny. **JD** tests a stated requirement of the role. **CO** tests knowledge of Ashgrove's strategy and context. **CASE** is a live problem from the real job.
- Provenance key: `[grounded]` traces to something you gave me. `[inferred]` is derived from it, with the derivation named. `[generic]` is a pattern with no claim about Ashgrove or about you.
- An **answer slot** is an instruction for the interview. It marks a place where only you know the true answer, and it always has an honest second branch: "say so plainly". It is never a question for this conversation.
- Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- Rounds 1 and 2 are weighted differently from round 3. Questions are numbered pack-wide, with a letter per persona: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Pressure, F Peer, G Data-Driven Prober.
- Dropped as not applicable: prep triage (no prep time stated), graded deliverables (the case is live, not a pre-declared take-home), interviewer read, delivery coaching (no assessment provided).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your sentence reaches the JD line in other terms: it says retail banking, not customer operations. Say it as written: "I've spent six years in retail banking, the last three as a branch supervisor." Then stop and let them judge the fit. It is a CV-style line with nothing inspected behind it, so expect a probe on it |
| F2 | "own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not the process end to end and not across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any stage beyond logging was yours, say which and how you decided, in your own words; if the log was where your part ended, or those stages were not yours, say so plainly and stay with the log you handled |
| F3 | "the contact centre" (from the same JD line as F2) — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | low | [inferred] | discovery | "Formal complaints log" touches the requirement, and your material does not show whether the log was subject to external rules. Answer slot: if the log was subject to external rules or reporting deadlines, say which, in your own words; if it was an internal log only, or you are not sure which rules applied, say so plainly and stay with the log you handled |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence shows a monthly complaints spreadsheet that someone above you uses, and does not show what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours tracked. If it counted volumes or times, say which and how, in your own words; if it counted something else, say what; if you do not know how a figure was counted, say so plainly and stay with the spreadsheet you built |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, not which tool. Answer slot: say which tool you built it in, in your own words; if it was not Excel, say so plainly and stay with the spreadsheet you built |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says you trained new tellers on the escalation script, not that you coached supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: if you have coached any supervisor or peer on escalations, say who and how, in your own words; if you have not, say so plainly and stay with training the tellers |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for a first senior presentation, said as a plan and never as a past. Your material does not say whether Ashgrove's senior leaders sit above that level |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: if you have worked on any digital or self-service channel, say what it was and which part was yours, in your own words; if you have not, say so plainly and say how you would approach it |

No row is a hard gate. None of the JD's four requirement lines is a term you either meet or do not, such as a licence or a location. They are experience and skill lines, so each is graded on evidence.

## Grounding brief: Ashgrove's strategy as you gave it

| Item | What the brief says, as you reported it | Provenance |
|---|---|---|
| Digital | Move 40% of member service to digital channels by 2028 | [grounded] |
| Branches | Consolidate eight branches into five hubs over 2027 | [grounded] |
| Lending | Launch a small-business lending product in Q1 2027 | [grounded] |
| Competition | The main competitive pressure is app-only banks | [grounded] |

Use these as vocabulary: "member service" rather than "customer service", and "hubs" rather than "closures". The pack holds only these four points, because you did not paste the brief itself. If the brief says more, send it and the CO rows sharpen (see the upgrade menu).

---

# Round 1: Recruiter screen (30 minutes)

## Persona table, round 1

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Conversational | Friendly chat on your background and why this role; logistics asked in a casual register | High. A recruiter screen's prior is conversational plus a light skeptic, and the recruiter's email says this is 30 minutes "with me" | A pre-scripted 90-second arc; treat every casual question as scored; give logistics answers in your own words |
| B Skeptic, light | Quick knockout checks on the JD's headline lines: years, scope, tools | Medium. A recruiter screen checks the lines a hiring team will otherwise reject on, and F1, F3 and F6 are where your material is thinnest or silent | Short, plain answers that return to the quotes; concede the contact-centre gap in one sentence rather than defending it |

## Question bank, round 1

### A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about your background and what brought you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | A 90-second arc built only from the beats the sentence states: six years in retail banking, the last three as a branch supervisor, in your own words. Answer slot: then give your own reason for moving toward complaints and member experience; if you do not have a settled reason yet, say so plainly and say what draws you in the JD's first line | The opener every screen runs, and F1 is its spine. EXP because it tests what your background claims |
| A2 | "Why are you looking to leave your current role?" | EXP | [generic] | Reason-for-leaving logistics slot: give your own reason in one forward-looking sentence, in your own words. This pack supplies none, because your material states none. Say the same reason in all three rounds | The logistics question a recruiter screen carries. EXP because it tests consistency of your own account, not the listed job |
| A3 | "What salary are you looking for?" | JD | [generic] | Pay logistics slot: give your own number, or ask for the role's band first. If asked what you earn now, you may decline or redirect to the role's band without giving a figure. The pack supplies no figure | Pay is a standard recruiter-screen item. JD because it concerns the listed job's terms |
| A4 | "What is your notice period?" | JD | [generic] | Notice logistics slot: give your actual notice period, in your own words | A standard recruiter-screen item, and the date it fixes feeds their scheduling. JD because it concerns the listed job's terms |
| A5 | "Is there anything about location or travel between branches we should know about?" | JD | [generic] | Location logistics slot: state your own constraints, in your own words; if there are none, say so plainly. Ask the recruiter where the role sits and how much of it spans branches and the contact centre, since the JD says "across branches and the contact centre" | Location is a standard item, and the JD's own wording makes travel plausible. JD because it concerns the listed job's terms |
| A6 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | Pick one or two points from the strategy brief and say them in your own words: 40% of member service to digital channels by 2028, eight branches into five hubs over 2027, the small-business lending product in Q1 2027, app-only banks as the main pressure. Then one sentence of your own view on why it matters to a complaints lead. The question needs no claim about your past, so the guidance makes none | The cheapest differentiator in a screen, and the brief is something the recruiter sent you. CO because it tests homework depth |

### B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for 4+ years in financial-services customer operations and comfort with Excel reporting. How does your experience line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I built the monthly complaints spreadsheet our regional manager uses" | Two clauses. Years: "I've spent six years in retail banking, the last three as a branch supervisor." Stop there and let the recruiter decide whether it counts. Excel: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD says Excel and your sentence says spreadsheet, so say which tool it was in, in your own words; if it was not Excel, say so plainly and stay with the spreadsheet you built | F1 and F6 are the two JD lines a screen can reject on. JD because it scores the stated requirements directly |
| B2 | "This role covers both branches and the contact centre. Does your experience cover both?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "Never worked in a contact centre" | A short version of the day-one objection: the branch side first, "I handled the branch's formal complaints log and trained new tellers on our escalation script"; then the other side in plain words, "I haven't worked in a contact centre"; then a plan for learning it, said as a plan. Do not stretch the branch log to cover both channels. Rehearse the full version at B3 | F2 and F3 together are the biggest gap, and this is its first airing. JD because it scores the headline requirement |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

## Persona table, round 2

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | "Tell me about a time..." questions on coaching, escalation, senior stakeholders | High. The recruiter's email calls this round "mostly behavioural", which lifts this persona above the hiring-manager prior | Story-map where a quoted sentence carries a story; use the selection scaffold where none does; "we" for context, "I" for your contribution |
| B Skeptic | Quiet probing of the gaps: contact centre, end to end, regulated, senior audiences | High. A manager is buying capability and weighing the gaps, and F2, F3, F4 and F8 are the thinnest rows | Rehearse the contact-centre objection until it is boring; bridge only from what you actually said; give the limit plainly, then a plan |
| D Case/Strategist | Short live problems from the role: digital self-service, coaching supervisors | Medium. The hiring-manager prior favours cases, but the email says "mostly behavioural", so cases appear briefly | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| A Conversational | Motivation and "why Ashgrove" | Medium. A manager round opens with fit and motivation | A reason that is genuinely yours, tied to one published fact |
| G Data-Driven Prober | Walk-through of the monthly spreadsheet | Low-weight but likely once. The spreadsheet is the one artifact you built that a manager can ask about in detail | Know what it counted and how, and say plainly when you do not |
| E Pressure | A time-boxed "why you" challenge | Low. Mostly behavioural suggests little stress-testing, but the manager will own the call | Pause, restate, hold the position the quotes carry, concede the contact-centre gap |

## Question bank, round 2

### B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | **The highest-ROI rehearsal in this pack.** Name it before they do: "I haven't worked in a contact centre." Hold what the quotes carry, at their scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script", which is the branch side only, and say that scope aloud. Concede specifically that the contact-centre half of "across branches and the contact centre" is new to you. Then give a plan, said as a plan, for learning it: your own steps in your own words, each one something you can stand behind. Rehearse three follow-ups. First, "How do you own something you have never done?": return to the plan and to what you would keep hold of. Second, "Someone from a contact centre would be faster": concede speed on that half, hold what the quotes carry on the branch half. Third, "Would you accept correction from contact-centre team leads?": answer in your own words, with no past instance added. Never claim contact-centre exposure, and never describe branch work as contact-centre work | F3 is where this role's two-channel mandate presses hardest, so this objection arrives in some form from this manager. JD because it scores the stated requirement; the limit is named before it is asked for |
| B4 | "The role owns the complaints process end to end. What part of that process have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Hold only what the quote carries: "I handled the branch's formal complaints log." Answer slot: if any stage after logging was yours, say which and how you decided, in your own words; if the log was where your part ended, or those stages were not yours, say so plainly and describe how you ran the log. Hold through two follow-ups by returning to the log, never by adding to it | F2 is the second-likeliest probe after B3, and the JD's end-to-end line is the raising source. JD because it scores the stated requirement |
| B5 | "Tell me about a time you handled a regulated complaint." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | An open prompt on the JD's regulated-complaints line. Story-map only what the quote carries: the formal complaints log, at its scope. Answer slot: if any complaint on the log was subject to external rules or deadlines, say which rules and what you did with that complaint, in your own words; if the log was internal only, or you are not sure which rules applied, say so plainly and stay with the log you handled. The pack names no regulator and no time limit, because your material gives none | F4 is a discovery row, so the honest answer is not yet known to the pack. JD because it scores the stated requirement |
| B6 | "What is the most senior group you have presented to?" | JD | [grounded] "I've never presented to anyone above regional level" | Hold-then-concede. Say it as you stated it: "I've never presented to anyone above regional level." Then give a plan, said as a plan, for preparing a first senior presentation, in your own words. Answer slot: if you have presented at regional level, say to whom and about what; if what you gave was a written report or spreadsheet rather than a presentation, say so plainly | F8 is a stated negative against a JD line, so the question comes in some form. JD because it scores the stated requirement |

### C: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you trained or coached someone through a difficult escalation." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | An open prompt on the JD's coaching line. Story-map at the quote's scope: new tellers, the escalation script, in your own words. Answer slot: if a particular teller or case stands out, say what the situation was and what you did; if the training was a walk-through of the script rather than coaching through a live case, say so plainly. Keep the scope at tellers; the JD says supervisors | F7 is the nearest evidence for the coaching requirement. EXP because it tests what was actually yours |
| C2 | "Tell me about a time you delivered an unpopular truth to someone more senior." | VAL | [generic] | A selection scaffold: pick a time with a named stake, the message you carried, the person, and what happened afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack supplies no incident | A standard behavioural stem, and the role reports results upward (F8). VAL because it scores past behaviour, not a published value by name |

### D: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You would work with digital teams on self-service journeys. Which complaints would you keep with a person, and which could a member resolve alone?" | JD | [grounded] | Structure it: clarify first (what counts as a complaint rather than a query, what is already digital, what the 40% by 2028 covers); objective; segmentation on criteria you can defend in your own words; approach; how you would know it worked; risks. Use Ashgrove's own words: if a member needs it explained twice, "we wrote it wrong". Answer slot: if you are asked what digital or self-service work you have done, say what it was and which part was yours, in your own words; if you have none, say so plainly and return to how you would approach it | F9 is a silent row and the 40% target makes digital a live topic. JD because it scores the stated requirement, with CASE delivery |
| D2 | "You would coach branch supervisors on escalations, some as experienced as you. How would you run the first session?" | JD | [grounded] | Structure it: ask what is going wrong with escalations today and what data shows it; agree the objective with them; use their real cases rather than yours; settle what "escalate" means and who keeps hold of the member; say how you would know it worked. The question asks about no past, so the guidance makes none | F7 is a transferability row and the JD names coaching supervisors. JD because it scores the stated requirement, with CASE delivery |

### A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A7 | "Why Ashgrove, rather than an app-only bank?" | CO | [grounded] | Answer slot: give your own reason, in your own words. One anchor from Ashgrove's published words, if it is true for you: "Members First, Always — we decide from the member's side of the counter." One fact: the strategy brief names app-only banks as the main competitive pressure. Do not claim to know how Ashgrove is responding beyond what the brief says | A manager wants to hear that the motivation is specific. CO because it tests homework depth |

### G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The beats the sentence states: monthly, complaints, used by your regional manager, built by you. Answer slot: the JD names volumes and resolution times, so say what yours tracked and how each figure was counted, in your own words; if it tracked something else, say what; if you do not know how a figure was counted, say so plainly. Name the assumption behind its figures that you would defend least, in your own words, or say you do not know. No figure is supplied here | F5 and F6 both rest on this spreadsheet, so it is the likeliest artifact to be opened up. EXP because it tests attribution and how a figure was counted |

### E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, rather than someone who has run a contact-centre complaints team?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Pause and restate the question. Hold what the quotes carry, at their scope: the branch side, "I handled the branch's formal complaints log and trained new tellers on our escalation script". Concede plainly: "I haven't worked in a contact centre." Then your plan, said as a plan. Do not argue that branch experience beats contact-centre experience. Hold through two follow-ups, and fold on nothing the quotes carry | B3 under a stopwatch. JD because it scores the stated requirement, with Pressure delivery |

---

# Round 3: Panel of two branch managers (60 minutes: 20-minute case, plus the values round)

## Persona table, round 3

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | Scenario probes scored against the four published values | High. The recruiter's email says "The panel is also the values round — they score against the four values" | A story or honest scaffold for each of the four values; see the values sheet below |
| D Case/Strategist | The 20-minute case on a complaint escalation, plus questions on strategy | High. The recruiter's email names the case, and it takes a third of the hour | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| F Peer | Branch managers asking what you would need from them and where the seam sits | Medium. They manage the branches whose supervisors you would coach, so the work lands on them | Reciprocity framing: what you bring their branches, not only what you need; propose principles for the seam rather than pretending to know it |
| B Skeptic | The contact-centre objection returning in collegial packaging | Medium. F3 is a stated negative and travels to every round | The same hold-then-concede as B3, in a quieter register |
| E Pressure | A twist inside the case: a supervisor pushes back | Low. Mostly shown inside the case rather than as a style | Pause, restate, hold the member's position without overriding anyone |

The panel members are not yet named, so weights are for the panel as a pair, not per person. The recruiter's email does not say whether the case uses a real Ashgrove scenario; see the upgrade menu.

## Question bank, round 3

### D: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D3 | "A member has complained about the same fee at their branch and again by phone to the contact centre. Neither record mentions the other, and they have now written asking for a formal escalation. What do you do in the first 24 hours?" | CASE | [generic] | Think aloud in this order. Clarify: what each record says, what the member asked for, and which time limits apply, which you ask the panel rather than assume. Objective: the member stops having to repeat themselves. Approach: one named owner who keeps hold, the two records joined, the member told plainly what happens next and when. Metrics: resolved, how long it took, whether the member had to chase. Risks: branch and contact centre each assuming the other has it. Challenge one premise respectfully, for example whether the two records are one complaint or two. The scenario is invented here, not Ashgrove's, and the guidance makes no claim about your past | The case is 20 of the 60 minutes. CASE because it scores structure on a live problem from the role; the scenario is `[generic]` until the recruiter says what the real one is |
| D4 | "The branch supervisor tells you they have already handled it and do not want the contact centre involved. What now?" | CASE | [generic] | A twist inside D3. Pause and restate. Hold the member's position without overriding anyone: ask what "handled" means and what the member was told. Concede what the supervisor may know that you do not. Agree who keeps hold, and say where you would take a disagreement that stays open. Use Ashgrove's own lines: "whoever finds the problem keeps hold of it", and "every branch is part of its town". No claim about your past | A pressure test inside the case, and the panel is two branch managers. CASE because it scores reasoning under pushback |
| D5 | "Complaint volumes at one branch doubled month on month. What do you look at before you report it?" | JD | [generic] | Clarify definitions first: what counts as a complaint, whether logging changed, the channel mix, a one-off event. Segment by type, channel and time. Check data quality before building a story. Then say what you would report plainly and what decision it supports, with resolution times alongside volumes. The question asks about no past | The JD's monthly-reporting line (F5) turned into a live problem. JD because it scores the stated requirement, with CASE delivery |
| D6 | "Eight branches are becoming five hubs over 2027. What does that mean for how complaints are handled?" | CO | [grounded] | Ask what has been decided before saying what you would do. Then the continuity of a complaint across the change: who keeps hold when a branch closes. Then local knowledge: how hubs stay part of their towns, in the words of "Neighbours, Not Numbers". Say plainly where you do not know; the brief as you reported it gives the numbers and the year, not the plan for complaints. Do not correct the panel | The strategy brief's consolidation sits directly under this panel's values line. CO because it tests altitude and homework |

### C: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C3 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | A selection scaffold for Members First, Always: pick a time when what the member needed and what was easiest for the branch pointed different ways, with a named stake, the decision, and what the member saw. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack supplies no incident | The value is published and scored by name, and no quoted sentence carries a decision of this kind. VAL because it scores past behaviour against a named value |
| C4 | "Tell me about a time something you wrote or said had to be explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-map the one place your sentence touches words: you trained new tellers on the escalation script, at that scope. Answer slot: the value says "we wrote it wrong", so expect a probe on the script's wording; if any part of its wording was yours to write or change, say what and why; if the script was handed to you, say so plainly and say how you taught it. Answer in short plain sentences, since the delivery is part of the score | Plain Words is the value a candidate's own phrasing is judged against. VAL because it scores past behaviour against a named value |
| C5 | "Tell me about a time local knowledge changed how you handled a member or a case." | VAL | [grounded] | A selection scaffold for Neighbours, Not Numbers: pick a time with a named member or situation, what you knew locally, what you did differently, and what resulted. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not claim a connection to a town you do not have | Branch managers will weigh this value against the hub plan. VAL because it scores past behaviour against a named value |
| C6 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-map at the quote's scope: the formal complaints log you handled. Answer slot: the value says whoever finds the problem keeps hold of it until it is solved, so expect a probe on whether you followed a complaint after it was logged; if you did, say which complaint and how you kept hold, in your own words; if the log was where your part ended, or someone else took it on, say so plainly and describe how you handled what was yours | Own the Fix is the value closest to the job's mandate. VAL because it scores past behaviour against a named value |

### F: Peer

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "You would coach supervisors in our branches on escalations. What would you need from us, and what could you offer?" | JD | [generic] | Reciprocity first: what a branch gets from the way you work, in principle, such as one place to see escalations, consistent wording and a feedback loop back to the branch. Then what you would need: honest access, their view of where escalations go wrong, and time. Propose principles for the seam; do not pretend to know the seam. The question asks about no past | The panel's branches are where the coaching lands. JD because it scores the coaching requirement; Peer delivery |
| F2 | "You have not worked in our contact centre. How would you earn credibility with the branches and the contact centre?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Concede in your own words, as you did at B3: "I haven't worked in a contact centre." Name what you do carry, at its scope: the branch's formal complaints log and training new tellers on the escalation script. Then credibility by plan: listen before changing anything, and say what you would ask each side. A hold-then-concede in a quieter register; add no past instance | The same objection as B3 in a collegial form, which is why it is the second-highest-ROI item. JD because it scores the headline requirement |
| F3 | "Our values say whoever finds the problem keeps hold of it. Your role coaches supervisors on escalations. When a supervisor escalates, who keeps hold?" | VAL | [grounded] | A position, framed as your reading of two published lines: escalation moves the work, not the ownership, so the finder stays the member's named contact while whoever can fix it fixes it. Ask whether that is how Ashgrove sees it. No past claim | Two of the published lines meet in this role, and a panel of branch managers lives that seam. VAL because it scores a named value applied to the job |

## Values sheet (round 3)

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decisions start from what the member sees at the counter | No quoted sentence carries a decision of this kind, so C3's selection scaffold applies, ending in its honest branch |
| Plain Words | If a member has to be told twice, the wording failed, not the member | F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script", at tellers-and-script scope; C4 holds the answer slot |
| Neighbours, Not Numbers | Each branch is judged as part of its own town, not as a figure | No quoted sentence carries a local-knowledge story, so C5's selection scaffold applies, ending in its honest branch |
| Own the Fix | Whoever spots a problem stays responsible until it is solved | F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script", at the log's scope; C6 holds the answer slot |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches and the contact centre | A5, B2, B3, B4, E1, D3, D4, F2, F3 |
| Report monthly on complaint volumes and resolution times | G1, D5 |
| Coach branch supervisors on escalations | C1, D2, F1, F3 |
| Work with digital teams on self-service journeys | D1 |
| 4+ years in financial-services customer operations | A1, B1 |
| Experience handling regulated complaints | B5 |
| Confident presenting to senior leaders | B6, C2 |
| Comfortable with Excel reporting | B1, G1 |
| Four published values | C3, C4, C5, C6 |
| Strategy (digital, hubs, app-only banks) | A6, A7, D1, D6 |

## Reverse questions

### Round 1, recruiter

| # | Question | Why it lands |
|---|---|---|
| 1 | "Do you know yet who will be on the round-three panel, so I can prepare for the right audience?" | Shows you are preparing to the audience, and the answer feeds the interviewer read when names exist |
| 2 | "Will the 20-minute case use a real Ashgrove scenario or a constructed one, and can I use paper to work it through?" | Tells you whether D3 and D4 should stay generic, and shows you are planning the case format |
| 3 | "How is the contact centre organised alongside the branches today, and who does it report to?" | Gives you the contact-centre picture that B3 and F2 both depend on |
| 4 | "What would you like me to be ready to cover in round two beyond what is in the JD?" | Gives you the recruiter's own focus areas, which the pack otherwise assumes |
| 5 | "What is the timeline after round three?" | Practical, and it closes the logistics you raised at A2 to A5 |

### Round 2, Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| 1 | "Where does the complaints process work well today, and where does it break between the branches and the contact centre?" | Turns the objection at B3 into joint problem-solving |
| 2 | "What would you want to see from me in the first 90 days?" | Ties your plan at B3 to what your manager will measure |
| 3 | "How will the hub consolidation change what this role owns during 2027?" | Connects to the brief and shows altitude |
| 4 | "Which senior forums would the monthly report go to, and what do they decide from it?" | Handles the presenting gap by asking about the audience rather than avoiding it |
| 5 | "How do the digital teams and this role split ownership of self-service journeys?" | Probes the seam that F9 leaves open |

### Round 3, branch-manager panel

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new complaints lead do in their first month that would genuinely help your branch?" | The reciprocity question for a panel that works beside the role |
| 2 | "When a complaint leaves your branch, what would you most want to hear back, and how fast?" | Shows Own the Fix from the branch side |
| 3 | "During the move to hubs, what would you want the complaints report to tell you that it does not today?" | Ties reporting to what they need, not what you assume |
| 4 | "What does Own the Fix look like for you on a day when a complaint crosses to the contact centre?" | Invites the panel's own view of the F3 tension at C-and-F level |
| 5 | "What is the thing a new Member Experience Lead most often gets wrong with branch teams?" | Signals humility and gives you their warning in their words |

No reverse question is tied to an interviewer's own path, because no interviewer profile exists yet.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end, or across branches | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's complaints log, not the process. B4's slot stays inside the log |
| Coached supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: you trained new tellers on the escalation script. The limit is the pack's observation. C1's slot stays at tellers |
| Reported on complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: a monthly complaints spreadsheet your regional manager uses. G1's slot asks only what it counted |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope: a formal complaints log. B5's slot asks only what rules applied, and allows that it was an internal log |
| Has contact-centre experience | Negative you stated, F3 | The plain acknowledgment F3 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." The slot at B6 covers only regional-level presenting, if you did any |

## Sources

Provided documents: the job description; Ashgrove's four published values, which you copied on 20 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; the four points you gave from Ashgrove's July 2026 strategy brief; your background summary. No `tuesday-dossier.md` was present. No search or fetch was sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The four values you pasted fix the values sheet and the VAL banks |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email names all three rounds, who runs each and what each holds, which fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` and recent news | skipped | The four brief points you gave fix the CO rows; a fuller brief would sharpen them (see the upgrade menu) |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer names were given, so there is no query to form; the interviewer read is absent |
| 5. Representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The strategy brief's full text, when you can paste it → the CO rows (A6, A7, D1, D6) move from the four points you gave to the brief's own wording and numbers
- The interviewers' names, once assigned → an interviewer read, persona weights per person, and a reverse question tied to each one's own path
- Your answers to the answer slots, said in your own words in your next message → the rows they draw on (F2, F4, F5, F6, F7, F9) are rewritten from your quotes, and the slots in B4, B5, C1, C4, C6, D1 and G1 become story-mapped
- The recruiter's word on whether the round-three case uses a real Ashgrove scenario → D3 and D4 stay `[generic]` until then, and one email to the recruiter settles it
- Your available prep hours before 29 November → a prioritised schedule tied to these question IDs
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → recent organisational context and loop reports for this role, which would feed the CO bank; say the word and I will run it
- A `tuesday-dossier.md` from an earlier evaluation of this role, if you have one → verified evidence and prohibited claims would replace the ones this pack built locally, and the objection that gets the deepest rehearsal would be named from evidence rather than inferred; the pack does not need it
- The date: 29 November 2026 falls on a Sunday on the calendar → confirm the day with the recruiter, since any prep schedule keys on it
