I've read the skill's rules and your inputs. I'm now writing the prep pack as a three-round loop, one section per interview on 29 November, and saving it as a markdown file.
Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop for 29 November. Round 1 is the recruiter, round 2 is the Head of Member Services, and round 3 is the branch-manager panel, which also carries the values cheat sheet. Each round has its own persona weights, 10 questions and reverse questions. I had no interviewer names and no CV beyond your paragraph, so there is no interviewer read. The pack uses your pasted values, the recruiter's email and the strategy brief points you gave me, and I ran no web searches.

The two gaps you stated, contact centre and presenting above regional level, are rows F4 and F9 in the pack. The deepest rehearsal is D1, the contact-centre objection, and the pack also covers the other gaps it found (F2, F3, F5–F8).

Say the word and I'll play the Skeptic on D1 with live follow-ups, or run the 20-minute escalation case (G1) as the panel.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

- Candidate: Dara
- Role: Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
- Date: 29 November 2026, three rounds (loop mode)
- Round 1: 30 minutes with the recruiter
- Round 2: 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural
- Round 3: 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation; the panel is also the values round, scored against the four values
- Interviewer names: none given, so there is no interviewer read; roles only

## How to use this pack

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether what you say about your own work survives follow-up questions |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know where Ashgrove is heading and can think at that altitude |
| CASE | Structure and reasoning on a live problem from the role |

Labels: `[grounded]` traces to something you or the employer supplied; `[inferred]` is derived from it, with the derivation named; `[generic]` is a role-family pattern with no claim about you or Ashgrove.

An answer slot is an instruction for the interview, not a question for me. It tells you what to say if the interviewer probes a point your material does not settle, and it always allows that the honest answer is that the thing did not happen or was not yours.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length: the quote already says six years in retail banking, and a length requirement is not a gate. Say it as you wrote it. Expect the probe to move to what the last three years held, which F3, F5 and F7 carry |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal complaints log, and does not show what rules or deadlines governed the entries. Answer slot: the JD's word for these complaints is regulated, so a probe on what governed your log is likely. If rules or deadlines governed how entries in your log were handled, say which and what was yours to do, in your own words; if none did, or that part was not yours, say so plainly and stay with the formal complaints log you handled |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | low | [grounded] | transferability | Your material says one branch's log; it does not say what happened to a complaint before or after the log. The words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on anything beyond the log likely. If any step beyond the log was yours to run, say which and how, in your own words; if none was, or it was not yours, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says a monthly complaints spreadsheet that your regional manager uses; it does not say what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what your spreadsheet counted. If it showed either, say how each was counted, in your own words; if it showed neither, or counted something else, say so plainly and stay with the spreadsheet you built |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet, not which tool. Answer slot: say which tool it was built in, in your own words; if it was not Excel, say so plainly and say what you used |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The quote is training new tellers on a script, which is not coaching supervisors, and the words stay there. Your message also says you were a branch supervisor for the last three years, so you were on the supervisors' side of the desk; let the panel draw anything from that. Answer slot: if you ever coached anyone at supervisor level on escalations, say who and how, in your own words; if not, say so plainly and stay with training new tellers on the script |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material touches this either way. Answer slot: if any of your work touched a digital or self-service channel, say what it was and which part was yours; if none did, say so plainly and say what you would want to learn first |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past |

No requirement in the JD is a gate (a term such as a licence, location or pay): the length requirement is graded on evidence like the others, and the JD states no location, pay or credential.

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | B1, C1, D1, D3, G1, G2 |
| Report monthly on complaint volumes and resolution times | C5, E1 |
| Coach branch supervisors on escalations | B2, H2 |
| Work with digital teams on self-service journeys | A3, C3, E2 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B3 |
| Confident presenting to senior leaders | C2, D2 |
| Comfortable with Excel reporting | C5 |

## Grounding brief: Ashgrove's July 2026 strategy

Use their vocabulary. Bring one item to show you have read it, then your own view. Every candidate the recruiter sent the brief to has the same list, so reciting it scores as homework and departing from it with reasons scores as judgement.

| Item | Source | Provenance | Where it may surface (derivation named) |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief, July 2026, sent by the recruiter | [grounded] | Inferred from this item and the JD's self-service line: A3, C3 and E2 |
| Consolidate eight branches into five hubs over 2027 | 2026 strategy brief | [grounded] | Inferred from this item plus the fact that round 3 is two branch managers: G3, F2 and the round 3 reverse questions |
| Launch a small-business lending product in Q1 2027 | 2026 strategy brief | [grounded] | Inferred: a new product may bring a new kind of complaint; use as a one-line aside only, with no claim to know |
| Main competitive pressure is app-only banks | 2026 strategy brief | [grounded] | Inferred: ties to self-service journeys and Plain Words in A3 and E2 |
| Member-owned, about 900 staff | The JD | [grounded] | Context for A2 |

I have your four-point summary of the brief, not its text. If the brief says more about complaints or contact-centre plans, send it and the CO rows sharpen.

---

# ROUND 1: Recruiter screen (30 minutes)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; logistics and "walk me through" | High. A recruiter screen's prior is Conversational plus a light Skeptic, and the recruiter's email says 30 minutes with them. Depth 7 | Pre-script a 90-second arc; treat casual questions about the JD's hot topics as scored; have your own answers on notice, pay, location and reason for looking ready |
| Skeptic (light) | A knockout-style check on the gaps | Medium. The JD lists regulated complaints and contact-centre scope, and your material has gaps on the latter. Depth 3 | Say the gap plainly in your own stated words, then the plan; no bluffing |

## Question bank: Round 1

### A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" "I handled the branch's formal complaints log" "trained new tellers on our escalation script" "I built the monthly complaints spreadsheet our regional manager uses" | Build a 90-second arc from those four sentences only: six years in retail banking, the last three as a branch supervisor; the complaints log you handled; training new tellers on the escalation script; the monthly spreadsheet you built. Add anything else in your own words, and end on why this role, in your reason | F1 is the opener's evidence; F3, F5 and F7 are the beats a recruiter will pull on. EXP because it tests whether the CV story holds together; the register is Conversational |
| A2 | "What draws you to a member-owned credit union?" | CO | [grounded] | Give your actual reason in your own words. If one of Ashgrove's published values is part of it, use its exact words, such as "we decide from the member's side of the counter", only if that is true for you. The guidance makes no claim about your past | Motive is the recruiter's first consistency check and the JD calls Ashgrove member-owned. CO because it tests whether the candidate understands the organisation they are joining |
| A3 | "What do you know about where Ashgrove is heading?" | CO | [inferred] | Bring one item from the brief to show you have read it: the move of 40% of member service to digital channels by 2028. Then say, as your own view and held as a view, what that means for how complaints are taken and tracked. The guidance makes no claim about your past | The brief is the same one every candidate received, so grounding plus one divergence is the stronger shape. The view is derived from the brief's digital goal and the JD's self-service line; F8 is the related gap |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | Every recruiter screen asks it, and the only safe answer is yours. JD because it concerns the listed job's terms |
| A5 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own number, or ask for the role's band first; either choice is yours. Do not offer a figure you have not decided, and if asked about current pay you can decline and redirect to the role's band | Pay is the other near-certain recruiter question, and the posting gives no band. JD because it concerns the listed job's terms |
| A6 | "Where can you work from, and how often?" | JD | [generic] | Logistics slot: state where you can work and how often, in your own terms. The JD you gave me states no location, so confirm the pattern with the recruiter | The JD states no location, so the recruiter's question is the first place it is settled. JD because it concerns the listed job's terms |
| A7 | "Why are you looking to leave your current role?" | EXP | [generic] | Logistics slot: give your own reason in your own words, in one or two sentences | Recruiters check motivation consistency against the rest of the loop. EXP because it tests the story behind the CV |

### B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Pick one gap from your own two statements and say it plainly in those words: "I haven't worked in a contact centre." Then say, as a plan, what you would do first to close it. Do not add an adjacent claim you cannot back | F4 and F9 are the two gaps you stated; this is where either one surfaces first. JD because it scores honest self-assessment against the listed requirements |
| B2 | "The role coaches branch supervisors on escalations. What have you done in that space?" | JD | [grounded] "trained new tellers on our escalation script" | Start at the quote's scope: you trained new tellers on your escalation script. Answer slot: the JD says coach branch supervisors, so expect a probe on supervisors. If you coached anyone at supervisor level on escalations, say who and how; if not, say so plainly and stay with training new tellers on the script | F7 is the evidence and shows a different audience from the JD's. JD because the question is the listed responsibility |
| B3 | "Do you have experience handling regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log" | Say what you handled in those words. Answer slot: the JD's word is regulated, so expect a probe on what governed your log. If rules or deadlines governed how entries were handled, say which and what was yours to do; if none did, or that part was not yours, say so plainly and stay with the formal complaints log you handled | F2 is a knockout-style check in a recruiter screen. JD because it scores a stated requirement |

## Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What does the 20-minute complaint-escalation case in round 3 involve, and is there anything to read first?" | The answer tells you whether to prepare material or just a structure, and it shows you are preparing |
| R1.2 | "Who will I meet in each round, once the interviewers are assigned?" | Names and roles let the pack gain an interviewer read |
| R1.3 | "What is the main problem the Head of Member Services wants this hire to solve?" | Aims your round 2 examples at the stated problem |
| R1.4 | "How is complaints work split today between branches and the contact centre, and who leads each?" | It speaks directly to F4 and shows where you will need to learn fastest |
| R1.5 | "What is the timeline after the 29 November rounds?" | A practical close, and it tells you how long to wait before following up |

---

# ROUND 2: Head of Member Services, your manager (45 minutes, mostly behavioural)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" prompts tied to Ashgrove's values | High. The hiring-manager prior is Case plus Skeptic, but the recruiter's email says mostly behavioural, so this moves to the top. Depth 5 | Where a quoted sentence carries a story, tell it; where none does, use the scaffold and its honest branch; "we" for context, "I" for what you did |
| Skeptic | Quiet probing of the gaps, with a manager's eye on what he would have to fund and coach | Medium. This is the person who would manage you, so the gaps in F4 and F9 are his risk. Depth 3 | Rehearse the contact-centre objection until it is boring: plain words, no bluff, a plan |
| Case / Strategist | A live problem from his actual roadmap | Low to medium. It is a hiring-manager prior, pulled down by "mostly behavioural". Depth 2 | Clarify, then structure, then answer; challenge one premise respectfully |

## Question bank: Round 2

### C: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you found a problem that wasn't strictly yours to fix, and what you did about it." | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix, in their words: "whoever finds the problem keeps hold of it until it is solved." Selection scaffold: a named problem, the moment you decided to keep hold of it, what you did to keep hold, and how it ended including what stayed unfixed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the formal complaints log you handled, at that scope, or how you would keep hold of one | F3 is the nearest evidence to the value and carries no story about fixing anything. VAL because it scores a published value; the theme comes from the value's own wording |
| C2 | "Tell me about a time you delivered an unwelcome truth to someone more senior than you." | VAL | [generic] | Selection scaffold: a named stake, a moment you did not fold, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would do it. The pack supplies no event | F9 shows the senior-audience gap, so this is where it can resurface in a behavioural wrapper. VAL because it scores behaviour under pressure; the question is a standard persona stem |
| C3 | "Tell me about a time you worked with a team outside your own to change how something was done." | JD | [grounded] | Selection scaffold for the JD's digital-teams line: name the other team, what you needed from them, what changed, and your part in it. Answer slot: F8 shows nothing either way. If any of your work touched a digital or self-service channel, say what and which part was yours; if none did, say so plainly and say what you would want to learn first | F8 is a none-given row, and this is the likely vehicle for it. JD because the JD raises it; the form is behavioural |
| C4 | "Tell me about a time you put a member ahead of an internal target or convenience." | VAL | [grounded] "I handled the branch's formal complaints log" | Members First, Always. Selection scaffold: the member's situation, the internal pull, what you decided, what it cost, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the formal complaints log, at that scope, or how you would decide | F3 is the only related evidence and does not show a decision. VAL because the value is the first of four published |
| C5 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Tell it in the quote's words: you built it, it is monthly, your regional manager uses it. Answer slots: the JD names volumes and resolution times and Excel, so expect probes on each. Say which tool it was built in; say what it counted and how each was counted; name the assumption behind a count you would defend least, or say plainly you do not know how it was counted. If it showed neither volumes nor resolution times, say so and stay with what it did show | F5 and F6 are the two requirements this evidence reaches and does not settle. EXP because it checks whether your account holds under follow-up |

### D: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A big part of this role sits in the contact centre, and you haven't worked in one. How do you handle that?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | **Highest-ROI prep in this pack.** Limit first: your material says one branch's formal complaints log and says you have not worked in a contact centre, so nothing you say may suggest contact-centre experience. Open with the words from your message: "I haven't worked in a contact centre." Then stay at the quote's scope: you handled the branch's formal complaints log. Then a plan, said as a plan: what you would do first to learn how complaints reach and are recorded there, in your own words. Follow-up 1, how you will earn credibility with people who have done the job for years: say what you would ask and listen to before proposing anything, and make no parallel claim. Follow-up 2, what if their process differs from the branches: hold the plan and concede specifically, "I don't know yet how it differs, and this is how I would find out." Follow-up 3, why you then: return to the log, the script training, and the plan, and add nothing | F4 is the largest stated gap against the JD's central line, so this objection will arrive in some form. JD because it scores a stated requirement; the Skeptic's delivery is quiet and persistent |
| D2 | "You'd be presenting to senior leaders, and you haven't presented above regional level. What makes you ready?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses" | Plain words first: "I haven't presented to anyone above regional level." Then what you would bring: the spreadsheet you built is the material for a monthly report, at its own scope. Then a plan for the first presentation, in your own words, such as who you would ask what the audience needs. Hold the plan through two follow-ups; concede that you have not done it. Do not claim confidence you have not shown | F9 is a stated gap and this is its natural question; F5 is the content you would present. JD because it scores a stated requirement |
| D3 | "The role owns complaints end to end. What part of that have you actually owned?" | JD | [grounded] "I handled the branch's formal complaints log" | The hold is only what the quote carries: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on anything beyond the log likely. If any step beyond the log was yours to run, say which and how you decided; if none was, or it was not yours, say so plainly. Hold that line through two follow-ups by returning to the log, never by adding to it | F3 is where the JD's scope presses hardest on your evidence. JD because it scores the headline responsibility |

### E: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How would you report monthly on complaint volumes and resolution times to senior leaders? What do you need to know first?" | CASE | [generic] | Clarify first: who reads it and what decision it serves; what counts as a complaint and when the clock starts and stops; whether branches and the contact centre are counted the same way. Then objective, split by channel and branch, what you would show and what you would flag, risks to the numbers. Think aloud and challenge one premise. The question needs no claim about your past, so the guidance makes none | The JD's reporting line, asked as a decision. CASE because it is a live problem; JD content, CASE delivery. F5 is the related evidence |
| E2 | "We aim to move 40% of member service to digital channels by 2028. What does that do to complaints, and what would you want from the digital team?" | CO | [grounded] | Structure it: how complaints enter through digital channels and get into the same process; what you would ask the digital team for, such as where members drop out of a self-service journey; where a human must take over; Plain Words, so a journey a member has to read twice is a journey to fix. Answer slot, because F8 shows nothing: if any of your work touched a digital channel, say what; if none did, say so plainly and stay with how you would approach it | The brief supplies the premise, so the question can be asked as a plain strategy question. CO and CASE: grounded in the brief, delivered as a live problem |

## Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would a good first 90 days look like, and what do you want me to have changed by then?" | Gives you the manager's own yardstick to aim examples at |
| R2.2 | "How are complaints recorded across branches and the contact centre today, and where does the process break down most?" | Shows you want to own the process, and the answer tells you how big F3 and F4 are in practice |
| R2.3 | "How much of the contact centre's complaint handling would I own, and how much stays with its leaders?" | A seam question that makes the contact-centre gap concrete and shows you respect existing ownership |
| R2.4 | "Which digital teams would I work with first, and what are they building on self-service?" | Follows the 40% by 2028 goal and F8 |
| R2.5 | "As eight branches become five hubs over 2027, how do you expect complaint routes to change?" | Grounded in the brief and shows you are thinking at the organisation's altitude |
| R2.6 | "Who would I present the monthly numbers to, and what decisions do they make from them?" | Prepares you for F9 and signals you treat reporting as decision support |

---

# ROUND 3: Panel of two branch managers (60 minutes, includes a 20-minute case; the values round)

## Persona weights

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes scored against the four published values | High. The recruiter's email says the panel is also the values round and scores against the four values. Depth 5 | One story per value where a quoted sentence carries one; otherwise the scaffold with its honest branch |
| Case / Strategist | The 20-minute complaint-escalation case | High to medium. The recruiter's email names the case and its length; its content is not given. Depth 3 | Clarify, structure, think aloud, name what you do not know |
| Peer Evaluator | Seam questions: where this role meets the branches, and what happens when they disagree | Low to medium. This is a panel blend: the interviewers are branch managers, whose supervisors you would coach, and names are not assigned. Depth 2 | Propose seam principles and ask where the seam currently is, rather than pretending to know |

## Question bank: Round 3

### F: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time what a member needed and what the process allowed pulled in different directions." | VAL | [grounded] "I handled the branch's formal complaints log" | Members First, Always: "we decide from the member's side of the counter." Selection scaffold: the member's need, the process limit, your decision, what it cost, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the formal complaints log you handled, or how you would decide | F3 is the nearest evidence and does not show a decision. VAL because it scores the first published value |
| F2 | "Tell me about a time you adjusted what you were doing because of the town or community a branch served." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Neighbours, Not Numbers: "every branch is part of its town." Selection scaffold: a named local circumstance, what you changed, who it affected. If nothing comes to mind, say so plainly, then give the nearest thing your material carries, that you were a branch supervisor for the last three of six years in retail banking, or how you would approach a hub that serves several towns. Let the panel draw any conclusion from your tenure | F1 is the only related evidence. VAL because it scores a published value; the 2027 consolidation makes the theme live for branch managers |
| F3 | "Tell me about a time a member or colleague needed something explained twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Plain Words: "if a member needs it explained twice, we wrote it wrong." Selection scaffold: what was unclear, what you changed, how you knew it worked. Answer slot: if any part of the escalation script was explained again or reworded because it did not land, say what and who changed it; if not, say so plainly and stay with training new tellers on the script | F7 is the nearest evidence and says only that you trained. VAL because it scores a published value; the theme comes from its wording |
| F4 | "Tell me about a time a problem you found needed other people to fix it. How did you keep hold of it until it was solved?" | VAL | [grounded] "I handled the branch's formal complaints log" | Own the Fix: "whoever finds the problem keeps hold of it until it is solved." Selection scaffold: the problem, who else had to act, how you stayed with it, how it ended including anything left unfixed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the formal complaints log you handled, or how you would keep hold | F3 is again the nearest row and carries no resolution story. VAL because it scores the fourth published value |
| F5 | "Which of our four values would you find hardest to live in this role?" | VAL | [grounded] | Pick one you can speak to honestly and say why, in your own words. Then say what you would do about it, as a plan. Do not say all four come easily. If you choose Own the Fix, the contact-centre scope is where it will be tested; if Plain Words, the written side of complaint responses. The guidance makes no claim about your past | An honest-self-assessment question inside the values round. VAL because it is scored against the published values; F4 and F9 are what an honest answer may touch |

### G: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member has complained three times about the same fee and has been given different answers in the branch. They have now written to the chief executive. Walk us through how you handle the escalation." | CASE | [generic] | This is an illustrative case; the real one is not known. Structure, thinking aloud: clarify what has been said to the member and by whom, what the complaint is, who holds it now, what deadlines apply and what you do not yet know about them; name one owner and stay with the member until it is solved (Own the Fix); respond in plain words (Plain Words); find out why the answers differed and fix that upstream, including how supervisors are coached; record it and show how it enters the monthly numbers. Name what you would escalate and to whom. The guidance makes no claim about your past | The recruiter said the panel case is a complaint escalation. CASE because it is a live problem; the scenario is generic rehearsal, not a prediction. F3 and F7 are the related evidence |
| G2 | "Same case: it turns out the first complaint came in through the contact centre and the branch never saw it. What changes?" | CASE | [generic] | Say plainly what you do not know about how the contact centre records complaints, then structure: one record that both channels write to, a named owner across both, a check on how long the complaint sat unseen, and what you would ask the contact-centre leads before proposing changes. The guidance makes no claim about contact-centre experience | The JD's scope runs across both channels, so a panel with a case can pivot here. CASE because it extends the live problem; F4 is the gap it touches |
| G3 | "Branches are consolidating into five hubs over 2027. How would you keep complaint handling consistent through that?" | CO | [grounded] | Clarify what changes first: escalation routes, who the supervisors are, which members change branch. Then structure: one process and one record through the change, coaching for supervisors whose role shifts, a view of the numbers by hub and town (Neighbours, Not Numbers), risks. The guidance makes no claim about your past | The brief supplies the consolidation and the panel are branch managers. CO because it tests thinking at the organisation's altitude |

### H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our branches sit alongside your team. Where is the seam on escalations, and what happens when we disagree about a complaint?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Ask where the seam is today before declaring one, then offer principles: the person who finds a problem keeps hold of it until it is solved, and the member's need decides ties. Say that you were a branch supervisor for the last three of your six years in retail banking, and let them draw the inference. Do not say you know their view | The seam is a branch manager's own concern. JD because it concerns the listed role; the Peer delivery is collegial |
| H2 | "How would you coach a supervisor who disagrees with how you would handle an escalation?" | JD | [grounded] "trained new tellers on our escalation script" | Describe your approach in your own words: listen first, find out what the supervisor saw in the case. Answer slot: if you have coached anyone at supervisor level, say who and how; if not, say so plainly and stay with training new tellers on the script | F7 is the evidence and shows a different audience from the JD's. JD because it scores the listed coaching responsibility |

## Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "When a complaint escalates from your branch today, where does it get stuck?" | Panel members live with the process, and the answer feeds your plan |
| R3.2 | "How would you want a Member Experience Lead to coach your supervisors: in the branch, remotely, or in groups?" | Shows you treat coaching as theirs to shape |
| R3.3 | "Which kinds of complaint take most of your supervisors' time?" | Gives you real content for E1 and G1 |
| R3.4 | "As branches become hubs, what do you most want to stay the same for your members?" | Direct on Neighbours, Not Numbers and the 2027 change |
| R3.5 | "What could a new person in this role do in their first month that would genuinely help your branches?" | A reciprocity question: it asks what you can give them, not only what you need |
| R3.6 | "What do you wish complaint reporting told you that it does not today?" | Links to the JD's reporting line and shows interest in their use of the numbers |

## Values cheat sheet (round 3)

Names are Ashgrove's own, from the text you copied on 20 November 2026 from ashgrovecu.org/about/values.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence of yours carries a story yet. Nearest: F3, "I handled the branch's formal complaints log". Scaffold: pick a time a member's need and the process pulled apart, with a named decision and its cost; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Questions C4, F1 |
| Plain Words | If a member needs it explained twice, the writing was wrong | No quoted sentence of yours carries a story yet. Nearest: F7, "trained new tellers on our escalation script". Scaffold: pick a time something did not land and you changed it; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Question F3 |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence of yours carries a story yet. Nearest: F1, "6 years in retail banking, the last 3 as a branch supervisor". Scaffold: pick a time a local circumstance changed what you did; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Question F2 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | No quoted sentence of yours carries a story yet. Nearest: F3, "I handled the branch's formal complaints log". Scaffold: pick a time you found something and stayed with it to a result; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Questions C1, F4 |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation: your material says one branch's log, not an end-to-end process. D3's slot stays inside the log |
| Has contact-centre experience | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: "trained new tellers on our escalation script". B2's slot stays inside that scope |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope: "I handled the branch's formal complaints log". The limit is the pack's observation: your material does not show what governed the log. B3's slot asks only what governed it, and allows that nothing did |
| Reported complaint volumes and resolution times to leadership | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses". C5's slot asks only what it counted |

## Sources

Provided documents: the job description text; the four values copied from ashgrovecu.org/about/values on 20 November 2026 (pasted, not fetched); the recruiter's email on the three rounds; your account of the 2026 strategy brief published July 2026 (four points, not its full text); your background in your message. No dossier was present. No interviewer names were given. The recruiter's email establishes the loop: three sessions, with who runs each and what each holds.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the cheat sheet and the VAL questions; it was not re-checked against the live page |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the rounds, who runs each, and what each holds, so persona weights follow them |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief you were sent already supplies priorities and the competitive frame for the CO questions |
| 4. interviewer name and company | n/a | No names were given, so no query could be formed; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A line from you on what governed your complaints log (rules, deadlines, or neither) → upgrades F2 and the B3 slot; the artifact that would raise it is the log's column headings or a redacted entry, with nothing inspected so far
- The monthly spreadsheet's column headings and the tool it was built in → upgrades F5 and F6 and the C5 slots from `medium` toward `high`
- A story for each of the four values, in your own words → replaces the scaffolds in the values cheat sheet and C1, C4, F1 to F4
- Anything you have done that touched digital or self-service work, or coached other supervisors → upgrades F8 and F7
- Your own answers on notice, pay, location and reason for looking → quoted into slots A4 to A7
- The recruiter's description of the round 3 case: its format, any reading, whether you present or discuss → restructures G1 and G2, and adds a build section if a deliverable is announced
- Interviewer names once assigned → an interviewer read and tailored reverse questions, and per-person persona weights
- How many hours you have before 29 November → a prioritised prep triage
- The full text of the strategy brief → sharper CO rows and a grounding brief that rests on the text rather than a four-point summary
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → recent organisation context, loop reports for the role family, and an interviewer footprint once names exist
- A verified-evidence dossier from job-underwriter → a candidate-specific objection ranking and strategy limits per gap; never required
