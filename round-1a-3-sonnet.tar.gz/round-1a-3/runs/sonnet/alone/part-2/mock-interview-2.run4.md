I'll read the reference files the skill points to before building the pack.
The pack is written. I'm running one check for stray square brackets before I present it.
Your prep pack is saved as `atlas-freight_operations-manager_interview_pack.md`. I don't know who you're meeting or what kind of round it is, so I built it for a generic screen → hiring manager → panel loop with flat persona weights. It has 23 questions across seven interviewer styles, a fit snapshot against each JD line, a "claims this pack won't coach" list, and six reverse questions.

Web search was refused in this session, so nothing in the pack comes from Atlas Freight's own materials. The company-knowledge and strategy questions are generic, and the Sources section lists what each refused search would have fed.

The pack names A2 as the highest-ROI prep. The JD asks for twelve supervisors and you currently have three, so expect that question in some form.

Say the word and I'll play the Skeptic on A2 with live follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you know who you're meeting (hiring manager, a peer, HR or a panel), and has the recruiter mentioned anything you're expected to prepare, like a presentation or a case? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

- Role: Operations Manager, Atlas Freight
- Interviewer: not given
- Relationship and round type: not given, so the persona weights below are flat

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Each question carries one of each.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, asked as a behavioral story |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company |
| CASE | Structure and reasoning on a live problem |

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview: say what is true in your own words, and use the second branch if the first is not true. Provenance labels: `[grounded]` rests on your words or the JD, `[inferred]` is this pack's derivation, `[generic]` is a role-family pattern with no claim about you.

## Prep triage

The interview is next week. Hours available are not stated, so these are ordered, not timed.

1. Say A2 aloud until the three-to-twelve answer is boring. It is this pack's highest-ROI prep.
2. Say C1 and D1 aloud: how the 40% figure was counted, and which part was yours.
3. Fix the Power BI sentence (D3, B4) and answer the Excel slot.
4. Talk B1, B2 and B3 through once each, out loud.
5. Time the 90-second arc in E1.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material carries a shift-manager role and the site's surge plan, and does not show terminals or more than one site. The words stay at that scope: "I'm currently a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's daily-operations line makes a probe on what was yours to decide likely. If any part of running the shift or the surge plan was yours to set, say which and how you decided, in your own words; if a part was set for you, or there was no such part, say so plainly and describe how you ran them |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material reaches mis-pick rate, not the two measures this line names, so the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slots for the figure: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Say each in your own words; "I don't know how it was counted" is an honest branch |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says three supervisors where the JD says twelve; that limit is this pack's observation, not words for you. The words stay at the quote's scope: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's team-size line makes a probe on span of control likely. If you have led a different number of supervisors at an earlier point, say when and how many, in your own words; if three is the number you have led, say so plainly and describe how you lead them |
| F4 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" touches the Excel half without showing whether it reached reporting that others read. Answer slot: the JD's reporting line makes a probe on what you built likely. If you built reports that others used, say what they tracked and who read them, in your own words; if your Excel work was for your own use, or you built no such reports, say so plainly and say what you use Excel for |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would get to working level, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The quotes show seven years in operations and a current role over supervisors, and do not show how many of the seven were spent leading people. Answer slot: the JD's years line makes a probe on that split likely. If five or more of the seven were spent leading people, say which roles and for how long, in your own words; if fewer, say so plainly and stay with the seven years in warehouse and distribution ops and the current role |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | discovery | "Green belt certified" touches the line without showing what the certification was in or whether it was applied at work, so the words stay at "I'm green belt certified." Answer slot: the JD's Lean/Six Sigma line makes a probe on the certification likely. Say what it was in and who awarded it, in your own words, and if you applied it at work, say where; if you did not, say so plainly |

None of the JD's six requirement lines is a gate, so no row is `hard_gate`. The years line is graded as an experience requirement (F6).

## Persona table

No loop source was read for Atlas Freight, so the weights rest on the Generic fallback archetype, flat. Bank depth follows where the fit snapshot is thinnest (F1, F3, F5), not who is asking.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the gaps: scale, years, why now | Flat prior, relationship unknown. Depth 5: F1, F3 and F6 give it the most to press | Rehearse A2 until it is boring; build bridges only from the quotes in the fit snapshot; where there is no bridge, say the limit plainly, then give a plan said as a plan |
| B. Case/Strategist | Live problems from the job: diagnose a slip, break down a cost, plan a first month | Flat prior. Depth 4: the JD's measures (F2) and scope (F1) are natural case material | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| C. Data-Driven Prober | Goes line by line through your numbers | Flat prior. Depth 3: F2 holds your one quantified claim | Know what you can and cannot say about how the figure was counted; name the weakest assumption before they do; say plainly when you do not know |
| D. Pressure | Interrupts, time-boxes, challenges attribution and the Power BI gap | Flat prior. Depth 3: F5 is a stated gap and F2 is a figure | Pause and restate; anchor in your own stated sentences; hold through two follow-ups before conceding anything real |
| E. Conversational | Friendly arc questions that are still scored | Flat prior. Depth 4: every loop has an opener, and E1 feeds the rest | A 90-second arc from your quoted sentences; treat casual questions about the JD's hot topics as scored |
| F. Peer Evaluator | Seam-splitting, credit-sharing, how you decide between sites | Flat prior. Depth 2: lowest, because nothing says a peer is in the loop | Reciprocity framing; propose principles for a seam rather than pretending to know it |
| G. Values/Behavioral | Scenario probes on judgment and candor | Flat prior. Depth 2: no values-style round is detected, so these are insurance | Selection scaffolds with an honest branch; "we" for context, "I" for contribution |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "currently a senior shift manager over 3 supervisors" | Pick the one weakness you honestly judge largest and name it in a sentence, then say what you would do first, as a plan and not a past. Your material gives you one plain sentence: "I haven't used Power BI." If you judge a different gap larger, hold that area at the quote's own scope: "I'm currently a senior shift manager over 3 supervisors." Never pick a weakness you do not believe in to look candid | F5 is the one row where the gap is stated, and F3 is where the JD's scale presses hardest, so this arrives in some form. JD because it scores the listed job against the person |
| A2 | "The JD asks for a team of twelve supervisors, and you're a senior shift manager over three today. How do you get from three to twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." State the numbers as they are, three today and twelve in the JD, before the interviewer does. Answer slot: if you have led a different number of supervisors at an earlier point, say when and how many; if three is the number you have led, say so plainly and describe how you lead them. Then give the plan, said as a plan: what you would find out first, in your own words. Follow-up 1: "What changes when it's twelve?" Follow-up 2: "What would you not delegate?" Answer both as plans, and if pushed on experience return to the three you lead, never adding to it | F3 is where the JD's team size most outruns the material, so this objection will come in some form. JD because it scores the stated requirement; deepest rehearsal because of that |
| A3 | "Beyond your own shift, what have you been accountable for?" | JD | [grounded] "ran the site's peak-season surge plan two years running"; "currently a senior shift manager over 3 supervisors" | Story-mapped on F1: the plan, the site's, peak season, two years running. These are the beats the quote states; tell them in your own words. Answer slot: the JD's daily-operations line makes a probe on what was yours to decide likely. If any part of the plan was yours to set, say which and how you decided; if a part was set for you, or there was no such part, say so plainly and describe how you ran it | F1 is the evidence for the daily-operations requirement and the likeliest place for scope to be probed. JD because it scores that line |
| A4 | "The role asks for five-plus years of operations leadership. Of your seven years, how long were you leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Tell the beats the quotes state: seven years in warehouse and distribution ops, and a current role over three supervisors. The observation here is the pack's, not words for you: your material does not separate years leading people from the seven. Answer slot: if five or more of the seven were spent leading people, say which roles and for how long, in your own words; if fewer, say so plainly and stay with the seven years in ops and the current role | F6 is a discovery row, so the split is unknown and a titled-years line invites exactly this question. JD because it scores the stated years |
| A5 | "Why this role, and why now?" | EXP | [generic] | Give your actual reason in your own words. The pack has none to offer, and a reason you did not give is one you could not defend on a second question. Keep it to two sentences, tie it to a line of the JD you actually care about, and make sure it fits the arc you give in E1 | A motivation-consistency probe is standard Skeptic material. EXP because it tests the story behind the move, and the pack holds no fact about your reasons |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your sites has slipped over the last month and cost per shipment is climbing. What do you need to know first?" | CASE | [generic] | Clarify first: how on-time is defined and where it is measured, what it slipped against, and what changed in volume, staffing or equipment over the period. State the objective: recover on-time without buying it back with cost. Segment by site, shift, lane and customer; rank two or three hypotheses; say what data you would pull and what first action each would trigger; say how you would know it is working and what could go wrong. Challenge one premise aloud, for example whether the two measures moved for the same reason. The question presupposes nothing about your past | A live problem built from the JD's two measures (F2). CASE because it scores structure, not a right answer |
| B2 | "You've just taken over four sites and twelve supervisors. What do you do in your first thirty days?" | CASE | [generic] | Structure it: what you would observe before changing anything, which numbers you would get defined and on the table first, how you would meet each supervisor, the one or two things you would act on, and one thing you would explicitly leave alone for now. Say how you would report back. It makes no claim about your past, so the guidance makes none | Built from the JD's scope and team lines (F1, F3). CASE because it is a decision under uncertainty, not a record of what you did |
| B3 | "If cost per shipment were the number that mattered most this year, how would you break it down?" | JD | [generic] | Start by asking what goes into the numerator and the denominator here, and say that your weakest assumption is that the definition is the same at all four sites. Then break the cost down into its parts, where the controllable parts sit, and how volume and mix move the number without any change in performance. Say what you would look at first | Scores the JD's cost line (F2) with a case delivery. JD because the requirement is the target, CASE-style because it is asked as a live decomposition |
| B4 | "How would you build a weekly operations report across four sites: what goes on it, and in what tool?" | JD | [grounded] "solid Excel"; "never used Power BI" | Design aloud: who reads it, what decision each line supports, a handful of measures per site that mirror the JD's two, exceptions, and a trend. Fix definitions before building. On the tool, say what you would build it in. Where Power BI comes up, the plain sentence is "I haven't used Power BI," then a plan, said as a plan. Answer slot: if you have built reports that others read, say what they tracked, in your own words; if not, say so plainly and say what you use Excel for | F4 and F5 together are the reporting requirement. JD because it scores that line, with the Excel half left as a slot and the Power BI half as a stated gap |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend the number, at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Four answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least, named before the interviewer names one; and which part was yours. "I don't know how it was counted" is an honest branch for any of them. Never add a measure you did not take | F2 holds your one quantified claim, so it is a magnet for probes. EXP because it tests whether the figure survives a second question |
| C2 | "What did you actually change when you redesigned the pick path?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on F2: the pick path, redesigned, and the mis-pick rate cut. These are the beats the sentence states. What the change consisted of is an answer slot: describe it in your own words and say who else was involved; if parts were others' work, say so plainly. Hold through two follow-ups by returning to what you changed, and nothing beyond it | F2 again, from the process side: a Prober tests the claim by asking for its content. EXP because it tests attribution |
| C3 | "Which of the measures this role is judged on have you worked with directly?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if any measure you tracked in your own role is among them, say which, how it was counted and what part was yours, in your own words; if none is, say so plainly and return to the quote: "I cut mis-pick rate 40% by redesigning the pick path." Do not stretch that result to a measure it did not count | F2 is where the evidence is adjacent and not direct, so the gap is likely to be probed. JD because it scores the line about the role's measures |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate the question. Hold: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which parts were yours and which were others', in your own words; if you cannot separate them, say so plainly. Concede specifically, naming the part you cannot speak to, and never concede the core sentence. Hold through two follow-ups by returning to the redesign | F2's attribution is the likeliest pressure target. EXP because it tests what was actually yours |
| D2 | "Sixty seconds: why you over a candidate who already runs several sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path" | The question presupposes nothing about you. Pick the two of these three sentences you can defend deepest and say them at their own scope, in your own words, inside sixty seconds. Add one plain sentence on what you would have to learn, as a plan. Say what you bring and leave the rival's experience alone | A time-boxed comparison is Pressure's standard stem, pressing on F1 and F3. JD because it scores fit to the listed job |
| D3 | "You've never used Power BI. Why should I put you in charge of reporting?" | JD | [grounded] "never used Power BI"; "solid Excel" | Acknowledge first, in plain words: "I haven't used Power BI." Then hold what the quote carries: "solid Excel." Answer slot: if you have built reports that others read, say what they tracked, in your own words; if not, say so plainly. Then a plan, said as a plan, for getting to working level. Hold through two follow-ups; concede nothing beyond the stated negative and do not fold on the Excel sentence | F5 is a stated gap and F4 is thin, so this question is close to certain in some form. JD because it scores the reporting line |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc built only from these sentences: seven years in warehouse and distribution ops; now a senior shift manager over three supervisors; the pick-path redesign and the mis-pick figure; the surge plan two years running; the green belt. Tell it in your own words, with "we" for context and "I" for what you did. Answer slot: why this role, your actual reason, in your own words | The opener frames every later probe, so each beat has to survive its own bank question (F1, F2, F7). EXP because it is your story as you tell it |
| E2 | "Tell me about a time you used your green belt." | JD | [grounded] "green belt certified" | Selection scaffold: pick a time at work when you applied what the certification covered, with a named problem, what you did, and a result you can back. Say what the certification was in and who awarded it, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would approach it. Do not attach the pick-path redesign to the certification unless it came from it | F7 is a discovery row: the certification is stated, its use is not. JD because the JD names it as a plus; the story format is behavioral |
| E3 | "Walk me through the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Story-mapped on F1: the plan, the site's, peak season, two years running, told in your own words. Answer slots: which parts of the plan were yours to set; how you knew it worked, if you did; and if anything differed between the two years, say what. Where there was no such part, or no measured outcome, or nothing differed, say so plainly and describe how you ran the plan | The surge plan is your strongest operations-ownership evidence (F1), so a friendly walk-through is likely. EXP because it tests what you did |
| E4 | "What do you know about Atlas Freight so far?" | CO | [grounded] "regional logistics, 800 employees" | The only facts this pack holds about Atlas are the JD's own: "regional logistics, 800 employees". Everything else has to come from the company's own site, which this pack could not read. Read it before the interview and say only what you found; where you have not found something, say so plainly rather than guessing | Homework depth is scored even in a friendly register. CO because it tests company knowledge, and it stays generic because no Atlas research ran |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Two of your four sites both need extra people on the same day and you can cover only one. How do you decide?" | CASE | [generic] | State your principle before the answer: what being short costs each site and its customers, and what is reversible. Say what you would need to know, decide, say whom you would tell and when, and say what you give up by deciding. The question presupposes nothing about your past | Built from the JD's four-site scope (F1), in the peer register of deciding between teams. CASE because it is a live decision |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams, with a named other party, a split of credit you can state, and the relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. "We" for context, "I" for what you did | A persona stem for credit-sharing with peers. VAL because it scores behavior, and it is generic because no Atlas value was read |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, what you said, how it landed and where the relationship stood afterwards. Choose a story where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A standard behavioral stem; insurance, since no values-style round is detected. VAL because it scores candor in past behavior |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named customer need, the metric you set aside, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | A standard behavioral stem that fits a freight role. VAL because it scores which way a trade-off went |

### Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| "Own daily terminal operations across 4 sites" | A3, B2, E3, F1 | |
| "drive on-time performance and cost-per-shipment down" | B1, B3, C3 | |
| "lead a team of 12 supervisors" | A2, B2 | |
| "build reporting in Excel/Power BI" | B4, D3 | |
| "5+ years operations leadership required" | A4 | |
| "Lean/Six Sigma a plus" | E2 | |
| Headline figure: the mis-pick reduction | C1, C2, D1 | |

No CO question is grounded in Atlas's strategy, because no research ran; E4 is the only CO row.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance defined here, and where in the process is it measured?" | It shows you would own the definition before the number, and it ties to B1 |
| R2 | "What goes into cost per shipment here, and who owns each part of it?" | It turns the weakest-assumption move outward and ties to B3 |
| R3 | "How long have the twelve supervisors been in role, and how are they spread across the four sites?" | It shows you are thinking about span of control, and the answer tells you what you would inherit |
| R4 | "What reporting exists today, what is it built in, and what would you want built first?" | It lets you ask about tools without hiding the Power BI gap, and ties to B4 and D3 |
| R5 | "What would a strong first ninety days look like?" | It gets the interviewer's own success measure on the table, and ties to B2 |
| R6 | "What is the hardest part of this job that the JD does not say?" | It invites candor about the role and gives you something to answer in your close |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned daily terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material shows a shift-manager role and the site's surge plan, and does not show terminals or more than one site. A3's slot stays inside the shift and the plan |
| Led twelve supervisors | Inflated form of F3 | F3's quote at its own scope: "I'm currently a senior shift manager over 3 supervisors." The pack's observation is that the material says three. A2's slot stays inside the span you have led |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." The pack's observation is that the material reaches mis-pick rate. C3's slot stays inside what you tracked |
| Built Excel reporting that others used | Inflated form of F4 | "Solid Excel" at its own scope. The pack's observation is that the material does not show reports built for others. B4's slot stays inside what you build in Excel |
| Has used Power BI | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I haven't used Power BI." No slot |
| Seven years of operations leadership | Inflated form of F6 | "7 years in warehouse and distribution ops" at its own scope. The pack's observation is that the material does not separate years leading people from the seven. A4's slot stays inside your own roles |
| Six Sigma or Lean practitioner, or a belt other than the one stated | Inflated form of F7 | "Green belt certified" at its own scope. The pack's observation is that the material does not say what it was in or whether it was applied |

## Sources

Provided documents: the JD lines and your background, both in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have fed a values cheat sheet if a values-style round had been detected, and E4's content |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. It would have fed the loop structure and persona weights; they fall back to the Generic archetype, flat |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. It would have fed CO and CASE questions grounded in current strategy; they stay generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent, by query:

- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight interview process operations manager` — refused
- `Atlas Freight regional logistics strategy news` — refused

## Upgrade menu

- The interviewer's name and title, and who they are to the role → persona weights read from their public footprint, an interviewer read, and a reverse question tied to their path
- The recruiter's prep email or process notes → the loop structure, any stated focus areas, and a build section for any presentation or case you are asked to bring
- Atlas Freight's own materials (a values or careers page, any brief the recruiter sent) → a values cheat sheet if a values round is named, and CO and CASE rows that become `[grounded]` where they are `[generic]` now
- A deeper research pass, once web search is allowed in this session (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Atlas's strategy and recent context, and loop reports for this role
- Your answers to the slots in F1, F3, F4, F6 and F7 (how many supervisors you have led and when, which of the seven years were spent leading people, what Excel reports you built, what the green belt covered) → those rows move from slots to story-mapped answers
- A mis-pick report or change record behind the 40%, the surge plan document, or the green belt certificate → F2, F1 and F7 move from `medium` toward `high`
- A tuesday-dossier.md from a job-underwriter run → verified evidence, the likeliest objection derived from evidence instead of inferred, and strategy limits per gap
