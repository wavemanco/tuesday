I've read the prep-pack spec and I'm now running the budgeted company research on Kelverton Rail: values, loop, strategy, the two interviewers and a representative JD. Then I'll build the pack.
Your prep pack is saved as `kelverton-rail_senior-partnerships-manager_interview_pack.md`. I built it for a panel of Deepa (your future manager) and Ross (commercial push), with a 15-minute POV followed by Q&A, and without a JD. The host refused every web search, so nothing in it comes from outside what you wrote. Requirements come from the recruiter's quoted words or are labeled generic.

Say the word and I'll run the first 15 minutes live as Deepa and Ross, starting with B1, the question the pack names as highest-ROI.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the JD to paste? It would turn the three role-family rows into quoted requirements and re-key the coverage table, and the pack stands as built without it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

- Round: second round, one 60-minute panel, on Tuesday
- Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director), per the recruiter's email as you quoted it
- Shape: first 15 minutes, your own POV with no slides, ending on what it means for the operators; the rest is Q&A, with Ross pushing on commercials
- Built without a JD and without any web research (see Sources), so every requirement below comes from the recruiter's words or is labeled generic

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (no values-style round is detected for this loop, so no VAL questions appear) |
| EXP | Whether your CV claims survive scrutiny and you can say what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Homework: the company, its market, how you think at its altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

Labels: `[grounded]` traces to what you or the recruiter wrote; `[inferred]` is derived from an adjacent or representative source; `[generic]` is a role-family pattern with no claim about Kelverton or you.

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for me: answer whichever branch is true, in your own words.

## Prep triage (about four hours, spread over the weekend)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 90 min | Build the POV from section 5, say it aloud twice against a clock, and aim for 11 to 12 minutes so an interruption fits inside the 15 | Section 5, A1 |
| 2 | 45 min | Rehearse the highest-ROI question until it is boring: hold, concede, plan. Say it aloud, not in your head | B1, then B2, B3 |
| 3 | 45 min | Write your own one-line answers to the four slots a figure raises, for the £4M and the 6 to 40, then say each aloud | C1, C2, C3, D2 |
| 4 | 30 min | Run one commercial scenario aloud with a timer | C4, D3 |
| 5 | 30 min | Draft the 90-second journey arc and pick three reverse questions | E1, section 11 |

Everything else is insurance.

## Fit snapshot

No JD was supplied. Requirements are the recruiter's own words, quoted, or role-family expectations written as plain prose and labeled `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, and the words stay there: "For the last four years I ran the ISV channel at a payments company." Answer slot: the recruiter asks for a view on operator partnerships, so expect a probe on what carries over from an ISV channel. Say in your own words what you think carries over and what does not, which is a view you hold now and not a past claim; if you think little carries over, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The quote is the scope: "For five years I did transport consulting, in bus and light rail network planning." Your gloss, "the other side", does not say whose side or for whom. Answer slot: expect a probe on what "the other side" means. Say who you worked for and with, in your own words; if the phrase is looser than that, say so plainly and stay with "bus and light rail network planning" |
| F3 | "Ross will push on commercials." — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The words stay at the quote: "roughly £4M of influenced revenue." Answer slot: a figure raises four probes, each answered in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. A document that shows the counting would move this row from medium to high |
| F4 | Grow and run a portfolio of partners — role-family expectation, no source supplied | "took it from 6 partners to 40" — your message | medium | [generic] | none | No gap at the stated scope: lead with "I took it from 6 partners to 40", in those terms. Expect a probe on it. Answer slot: say what counted as a partner and which part of the growth was yours, in your own words; if no definition was set, or the growth was not wholly yours, say so plainly and stay with the figures as quoted |
| F5 | Sell or partner into rail operators — role-family expectation, no source supplied | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. The adjacent consulting years are F2, at their own scope. Never a claim to rail selling |
| F6 | Carry a direct revenue number — role-family expectation, no source supplied | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota; it was influenced revenue." Then what you would want to learn about how partnership numbers are set here, said as a plan. Never a claim to owning or booking a figure |

No row is a hard gate: nothing in the material states an eligibility, location or schedule term.

## Graded deliverable: the 15-minute POV

The recruiter's words, quoted: "present a short POV on where you'd take our operator partnerships over the next 18 months", "no slides needed, just talk us through it", and "Please land on what it means for the operators themselves."

**Grounded facts to build on.** F1: "9 years in partnerships, last 4 at a payments company running the ISV channel". F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". F4: "took it from 6 partners to 40". Use each at its own words; the thesis is a view about this role, not a lesson you claim to have drawn from the past unless you did.

**Theses.** Pick two, not three. Each carries a concession you say aloud before anyone asks. All three are `[generic]` shapes: the content that fills them is yours, from the report and your own reading.

| Thesis | What you argue | Mandatory concession |
|---|---|---|
| T1: Plan backwards from the operator | Choose two or three things an operator's own team should be able to say are better at month 18, and make each partnership activity answer to one of them. This lands the requested close without a bolt-on | You are choosing those outcomes without Kelverton's customer data, so say which one you would test first with Deepa and with operators before committing |
| T2: Deeper before broader | Spend the first half of the 18 months on fewer, closer operator relationships, then widen what proved repeatable | Depth concentrates risk in a few relationships, and breadth is how you learn what generalises. F4 is breadth evidence, so present this as a view on this role |
| T3: Make the partnership something Ross can price | Bring the commercial logic yourself: what the operator gets, what Kelverton gets, how each is measured, instead of waiting to be pushed | F6: you have not carried a direct quota, so this is a framework and not a track record. Say so before he does |

**Differentiation.** Your note describes the market report as one "their strategy team circulated internally last quarter", so both interviewers know it and any prepared candidate can assemble its shortlist. I have not seen it, so the content is yours: bring one item from it that you agree with, to show you read it; then one thesis-driven divergence with its reasons; then the anti-pick. Do not hand its figures back as if they were new.

**The anti-pick.** Say what you would deliberately not do. Options to test against your own judgment, each `[generic]`: refusing to make partner count the headline measure; refusing bespoke work for a single operator that cannot be reused; refusing to commit to an operator outcome you cannot measure. Choose the one you can defend in two sentences, and say what evidence would change your mind.

**The close.** The last minute is one sentence an operator's team could recognise as theirs: what is different for them at month 18. I have not drafted it, because it depends on the thesis you pick and on what you believe; draft it yourself and say it without notes.

**Timing, a rehearsal pattern.**

| Minutes | Beat |
|---|---|
| 0 to 1 | State your working definition of operator partnerships aloud and check it with Deepa in one sentence |
| 1 to 3 | Where things stand, by your reading, including the one consensus item from the report |
| 3 to 9 | Your two theses, each with its concession |
| 9 to 10 | The anti-pick |
| 10 to 12 | The close for the operators, then stop |

## Persona table

The loop is established by the recruiter's words: one 60-minute panel, a 15-minute POV, then Q&A. No archetype fallback is needed.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A, 5 questions) | Live problems on their own roadmap; follow-ups on your POV | Highest. The POV is graded, and a future manager's relationship prior is Case/Strategist plus Skeptic | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B, 5 questions) | Quiet, persistent probing of the gaps, from Deepa as the future manager | Highest. F5 and F6 are stated gaps, and a hiring manager is derisking exactly those | Rehearse B1 until it is boring; bridges only from adjacent evidence you stated (F2, F4); plan for the rest |
| Data-Driven Prober (C, 4 questions) | Inputs and assumptions behind each figure; commercial scenarios | High. "Ross will push on commercials" is the recruiter's own signal, and F3 and F4 are the figures on offer | Know what you can and cannot say about how each figure was counted; say plainly when you do not know |
| Pressure (D, 3 questions) | Time-boxed or interrupting challenges from Ross | Medium. An executive's relationship prior includes Pressure, and the recruiter's signal is about commercials, not manner | Pause, restate the question, hold through two follow-ups, concede specifically |
| Conversational (E, 2 questions) | The opening "walk me through the journey" and casual probes on rail scheduling | Low. Panels often open this way, and casual questions are still scored | A 90-second arc made only from what your message states |

Not included: Values/Behavioral, because the recruiter's words name no values-style round and the loop is established; Peer Evaluator, because neither named interviewer is a peer.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have fifteen minutes: where would you take our operator partnerships over the next 18 months, and what does it mean for the operators themselves?" | CASE | [grounded] | The live version of section 5. Say your working definition of operator partnerships and check it in one sentence; give the objective for 18 months; name the two or three situations you would treat differently; give the approach; name the one or two measures that show operators are better off; name the risks, including your concession. Close on one operator-facing sentence. It makes no claim about your past | The recruiter named this as the graded first 15 minutes; CASE because it is a live problem on their actual roadmap |
| A2 | "What would you need to know about our operators before committing to that plan, and how would you find out?" | CASE | [generic] | Clarify first. List the three or four things you cannot know from outside, who inside you would ask, and what you would do in the first weeks to find out. Say plainly which parts of your POV are hypotheses until then. It makes no claim about your past | Case scoring rewards clarifying before structuring; F5 is why this question is likely |
| A3 | "Which measure would tell you at month six that the plan is working for the operators, not for us?" | CASE | [generic] | Choose one measure an operator would recognise as theirs, say how you would know it, and name the lagging measure Kelverton would see. Name the assumption behind it you would defend least before you are asked. Do not name a figure you cannot source | Lands the requested close at metric level, and Ross's commercial lens (F3) makes a measure question likely |
| A4 | "What would you deliberately not do in the next 18 months?" | CASE | [generic] | Give one anti-pick you can defend in two sentences and say what evidence would change your mind. Section 5 offers options; pick by your own judgment | The role's real job includes saying no, so a reasoned departure from the consensus answer scores as judgment |
| A5 | "Where do you agree with our own market report, and where would you push back?" | CO | [generic] | You have the report and I do not, so the content is yours: one point you agree with that shows you read it, one divergence with its reason, stated as a view. Do not recite figures back | A document both sides hold is the consensus answer; CO because it tests homework depth |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota. Why should we trust you with a commercial conversation with an operator?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue" | **The highest-ROI prep in this pack.** The limit, said before it is asked for: your material carries influenced revenue and no direct number. Level 1, the hold: "I've never carried a direct quota; it was influenced revenue", then the figure in its own words, "roughly £4M of influenced revenue". Level 2, if pressed that influenced is soft: answer slot: say how it was counted and which part was yours, in your own words; if you do not know how it was counted, or the share was not yours to claim, say so plainly. Level 3, if pressed on what changes under a number: a plan, not a past: what you would want to learn first about how partnership numbers are set here, and who you would ask. Concession to rehearse: "That is a real difference, and I'd rather you weigh it than have me talk around it." Hold through two follow-ups by returning to the quotes, never by adding to them | F6 is the thinnest row and the recruiter announced the commercial push, so this question arrives in some form; JD because it tests the listed job including its gap |
| B2 | "You haven't sold into rail. What do you actually know about how operators make decisions?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Plain acknowledgment first: "I've never sold into rail specifically." Then the consulting years at their own words: "five years in transport consulting, in bus and light rail network planning." Answer slot: expect a probe on what "the other side" means. Say who you worked for and with, in your own words; if the phrase is looser than that, say so plainly and stay with "bus and light rail network planning". Then a plan: what you would ask operators' people in the first weeks | F5 is the stated gap and F2 is the adjacent evidence; JD because the role is operator-facing |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Choose the weakest from the two your own material states, say it plainly in the quote's terms, and pair it with a plan for the first weeks: what you would ask and whom. Do not offer a strength dressed as a weakness. If neither is the weakest, say what is and why, in your own words | The Skeptic stem; F5 and F6 are the two stated gaps, so the answer should come from them |
| B4 | "Why would you leave payments for a rail-tech company?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A selection scaffold: the reason must be specific to Kelverton and to operators, and true; say it in two sentences. If no clear reason comes to mind, say so plainly, then give the nearest thing your material does carry, the quote above at its own words, or how you would test the move | Motivation consistency is what the Skeptic scores; F2 is the only row near the sector |
| B5 | "Your last four years were an ISV channel. Why does that map to operator partnerships?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Hold the quote at its scope: "nine years in partnerships, the last four at a payments company running the ISV channel." Answer slot: say in your own words what you think carries over and what does not, a view you hold now; if the match is looser than the question assumes, say so plainly and stay with the channel you ran | F1 is the translation test; JD because it scores whether the background reaches the role |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that roughly £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Say what you know about how it was counted, in your own words, and what it is sensitive to. If you do not know how it was counted, say so plainly: "I don't know how it was counted" is a complete honest answer and better than a method you cannot repeat under the next question. Never supply a method, baseline or attribution model you did not use | F3 is the headline figure; EXP is the defend-the-number question, and Ross is announced as the commercial push |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Name it yourself, in your own words, before they do. If you know of none, say plainly that you have not stress-tested it and what you would check first | Naming the weakest assumption turns a gotcha into a credibility gain; F3 |
| C3 | "Take me through the 6 to 40: what counted as a partner?" | EXP | [grounded] "took it from 6 partners to 40" | The sentence at its own words: "I took it from 6 partners to 40." Answer slot: say what counted as a partner and which part of the growth was yours, in your own words; if there was no formal definition, or the growth was not wholly yours, say so plainly and stay with the figures as quoted | F4 is the second headline metric, and a prober asks for the denominator |
| C4 | "An operator partner asks for a discount in return for being a public reference. Walk me through how you'd think about it." | CASE | [generic] | Structure it: what the operator is really asking for, what the reference is worth to Kelverton, what precedent it sets for other operators, who decides discounts here, and what you would take to Ross instead of agreeing on the spot. It makes no claim that you have done this | A commercial scenario that tests structure without needing a quota history (F6) |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "took it from 6 partners to 40"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Pause and restate the question in one clause. Hold on what the quotes carry, each at its own words: "I took it from 6 partners to 40" and the consulting years. When pressed, concede specifically: "I've never sold into rail specifically." Hold through two follow-ups by returning to those facts. You cannot say what the other candidate has done, so do not compare | F5 is the stated gap; JD because it scores fit including the gap; the stem is the Pressure persona's |
| D2 | "That roughly £4M of influenced revenue: how much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Pause first. Answer slot: say which part was yours and which was others', in your own words; if you cannot split it, say so plainly instead of estimating. Hold through two follow-ups by returning to your own words, then concede specifically what you do not know | The attribution probe, delivered as pressure; F3 |
| D3 | "If this role carried a number from day one, what would you want to know before accepting it?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | A plan, not a past: what the number counts, who sets it, what the operators' buying cycle implies for when it can be met, and what support sits behind it. State the limit plainly: "I've never carried a direct quota; it was influenced revenue." Then stop | F6; tests whether you can discuss a number honestly under a hypothetical |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc with only these two facts, in the order your message gives them: five years in transport consulting, then nine years in partnerships, the last four running the ISV channel at a payments company. Answer slot: the reason for the move to Kelverton, in one or two sentences of your own words; if the reason is still forming, say so plainly instead of inventing one | F1 and F2; panels often open this way, and EXP because it is your own story |
| E2 | "What are you actually thinking about in rail scheduling these days?" | CO | [generic] | Answer from what you have actually read or watched. If you have read the report, name one point you took from it and one you would question. If no thought comes to mind, say so plainly and say what you would read first | A casual-register question about the company's own product area is still scored; CO |

### Requirement coverage

| Requirement | Questions |
|---|---|
| POV on operator partnerships over 18 months (F1) | A1, A2, A3, A4, B5 |
| Land on what it means for the operators (F2) | A1, A3, B2 |
| Ross pushes on commercials (F3) | B1, C1, C2, C3, C4, D2, D3 |
| Grow a partner portfolio, generic (F4) | C3, B5 |
| Rail experience, generic (F5) | B2, B3, D1 |
| Carry a direct revenue number, generic (F6) | B1, B3, D3 |

No JD was supplied, so no JD-listed requirement is missing from this table because none could be read; with one, this table is re-keyed.

## Reverse questions

Neither interviewer's career path is known, and neither is a peer, so none ties to a path and none is a reciprocity question.

| # | Ask | Why it lands |
|---|---|---|
| R1 (Deepa) | "What would you want to be true about operator partnerships 18 months from now that isn't true today?" | It gets her own success measure and shows you think in outcomes, which is where your POV ends |
| R2 (Deepa) | "How are partnership targets set today, and what does this seat own versus influence?" | It surfaces F6 honestly instead of leaving it for them to raise |
| R3 (Ross) | "Where do operator commercial conversations tend to stall for us?" | It gives you his working model of the commercial push and hands you a real problem to think about |
| R4 (Deepa) | "Who at the operators does this role spend most of its time with, and what does a good relationship look like from their side?" | It anchors the conversation in the operators themselves, the recruiter's requested close |
| R5 (either) | "Which part of last quarter's market report do you think partnerships should act on first?" | It shows you read it without reciting it, and tells you which item they treat as consensus |
| R6 (either) | "What would you want me to have learned by day 90, and what would tell you early that it was going well?" | It turns the F5 and F6 gaps into a shared plan with a stated yardstick |

## Prohibited claims

Claims this pack will not coach, with their basis and honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or has rail commercial experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never sold into rail specifically." No slot |
| Carried a quota, owned a revenue number, or booked the £4M | Negative you stated, F6 | "I've never carried a direct quota; it was influenced revenue." No slot |
| Has rail scheduling or timetabling expertise | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation, not words for you: the material says bus and light rail network planning, not rail scheduling. B2's slot stays inside the consulting years |
| Personally recruited, or personally won, the 40 partners | Inflated form of F4 | F4's quote at its own scope: "took it from 6 partners to 40". The limit is the pack's observation: the material does not say which part was yours. C3 and D2 ask only which part |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report the recruiter attached was not supplied to me, so nothing in this pack draws on it.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

Every search was refused by the host, so nothing in the pack comes from outside what you wrote.

Queries sent, all refused:

- Kelverton Rail values — refused
- Kelverton Rail interview process partnerships manager — refused
- Kelverton Rail strategy news scheduling software train operating companies — refused
- Deepa VP Partnerships Kelverton Rail — refused
- Ross Commercial Director Kelverton Rail — refused
- Senior Partnerships Manager rail technology job description — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Every call was refused. Would have moved the names for any values themes; no values-style round is detected, so no cheat sheet is owed |
| 2. Kelverton Rail interview process, partnerships | unavailable | Every call was refused. Would have moved loop detail and persona weights; the recruiter's words establish this session, so the weights stand |
| 3. Kelverton Rail strategy and recent news | unavailable | Every call was refused. Would have grounded A5, E2 and a grounding brief, which are therefore generic |
| 4. Interviewer names with the company | unavailable | Both calls were refused. Would have moved an interviewer read, persona adjustments and a reverse question tied to their paths |
| 5. Representative Senior Partnerships Manager JD | unavailable | The call was refused. Would have turned F4 to F6's role-family requirements into `[inferred]` rows and given JD-tagged questions a source |

## Upgrade menu

- The JD text → F4 to F6 become quoted requirements, the coverage table is re-keyed, and any mid-list requirement gets its own question
- The market report's key sections, pasted → a grounding brief, A5 and E2 move from `[generic]` to `[grounded]`, and the consensus item to bring is named exactly
- Search permission for this session → values, loop, strategy and interviewer rows re-run at L1; a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, would then be available
- Deepa's and Ross's surnames or professional profiles → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each path
- The attribution document behind the £4M, such as a partner-sourced revenue report or the definition of an active partner → F3 and F4 move from medium to high, and C1 to C3 can be rehearsed against it
- Your full CV text → more rows can be quoted, and any sentence near rail or commercial work becomes a story map instead of a scaffold
- A `tuesday-dossier.md`, if you have one → verified evidence and a named top objection in place of the one inferred here
