I'll start with the reference files the skill requires.
I've read most of the skill's rules and am about to read the last one (the reframing audit). Then I'll run a small research pass on Larkfield Systems before building the three-round pack.
Your prep pack for all three rounds is saved as `larkfield-systems_engineering-manager_interview_pack.md`. I built it as a three-round loop with a shared fit snapshot and a separate bank for each round (8 questions each, 24 in total). It rests on your summary and the role text, since there was no CV or full job description. Web search was declined in this session, so the pack has no Larkfield values, strategy or interview-format facts, and no values cheat sheet or company-strategy question.

The question to rehearse hardest is T-A2 in Tuesday's round: "You'd be partnering with hardware on the roadmap and you're at a payments company today. How do you get up to speed, and why should I take that risk?" It comes back as M-C1 on Monday and P-D1 on Thursday. The answer holds what your own words carry, concedes "I haven't owned a hardware-adjacent roadmap" plainly, and gives a ramp plan.

Your 60% on-call figure will be probed in the panel (P-B1) and again on Monday (M-C2). Your material doesn't say how it was counted or which part was yours, so those answers are yours to supply, including "I don't know how it was counted" if that's true.

Say the word and I'll play your would-be boss on T-A2.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did the recruiter give focus areas or a pre-declared deliverable for any round, especially Thursday's panel? The answer would reweight that round's bank.

Can you paste your CV, or a few lines on anything the pack marks silent, such as helping engineers grow? Without it the pack stays as is.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (three-round loop)

Candidate: Yusuf. Loop mode: one shared fit snapshot, then a mini-pack per round.

| Round | When | Who and relationship | Length |
|---|---|---|---|
| 1 | Tuesday | Director of Engineering, the hiring manager and your would-be boss | 45 min |
| 2 | The Thursday after | Panel: two staff engineers and a product manager | 60 min |
| 3 | The following Monday | VP Engineering, described by the recruiter as "values and leadership philosophy" | 30 min |

No interviewer names were given, so there is no interviewer read. Which panel member asks what is not known, so panel personas are blended, not assigned.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the values asked about |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually you |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

There is no CO question in this pack. Research could not run (see Sources), and a company-strategy question written from memory would be a guess. The highest-ROI prep in the whole loop is **T-A2**, the hardware-partnership objection. It is asked by your would-be boss on Tuesday, and its shape returns in P-D1, M-C1 and M-B2.

An answer slot is an instruction for the interview, not a question for this conversation.

## Fit snapshot (shared by all three rounds)

The role text is the one you gave me; its lines are the requirements. It names no location, travel, pay or other term, so there are no gate rows. Whether the 11 engineers include leads who would report to you is not stated in the role text or in your material.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | Your material says a team lead of 6 at a payments company, with no manager of managers behind it, and it does not show two squads or device-management work. The words stay at that scope: "Nine years in engineering, three as a team lead of 6." The plain acknowledgment your message gives is "I haven't managed managers." Answer slot: the role says two squads, so expect a probe on the step up. If any of your work reached beyond the one team, say what and which part was yours; if none did, say so plainly and stay with the team of 6 |
| F2 | "own delivery" — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence carries one reliability quarter and a 60% figure, not ownership of delivery generally. Say it at that scope: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60%." Answer slot: the figure raises four probes, how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours; answer each in your own words, and "I don't know how it was counted" is an honest answer. Answer slot: the role's "own delivery" line makes a probe on delivery beyond that quarter likely; if you set delivery commitments beyond it, say how, and if you did not, say so plainly and stay with the quarter |
| F3 | "hiring ... for 11 engineers" — your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms: you run it, for backend roles, and the 40 counts interviews. Your material says interviews, not hires, so the count stays with the interviews |
| F4 | "growth for 11 engineers" — your message | none given | none | [grounded] | discovery | Your material is silent on this, which is not the same as a gap. Answer slot: the role names growth, so expect a probe on how you develop engineers. If you have supported anyone's growth, say what you did and which part was yours; if you have not, say so plainly and say how you would start |
| F5 | "partner with hardware and product on roadmap" — your message | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |

## Round 1: Tuesday, the hiring manager (45 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of F5 and F1: hardware, two squads, payments to industrial IoT | High. A hiring manager is buying capability and derisking gaps, and your two largest gaps sit under the role's two main lines | Rehearse the T-A2 objection until it is boring; hold what the quotes carry, concede the rest specifically, add a ramp plan |
| Case/Strategist | A live problem from the squads' own work: prioritization, a fleet incident, a joint roadmap | High. Same relationship prior; 45 minutes leaves room for one or two | Clarify, then objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Conversational | The opener, "walk me through your background" | Medium. Almost every first conversation with a would-be boss starts there, and it is scored | A 90-second arc built only from your quoted sentences |
| Peer, Prober, Pressure, Values | Mostly later in the loop | Low for this round; the later rounds' banks cover them | None needed here |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-A1 | "You lead a team of six today and this is two squads and eleven engineers. What changes for you?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I've never managed managers" | Say it at its scope: "Nine years in engineering, three as a team lead of 6." Then the acknowledgment: "I haven't managed managers." Answer slot: if any of your work reached beyond the one team, say what and which part was yours; if none did, say so plainly and stay with the team of 6. Then give a plan, not a past: what you would learn about each squad in your first weeks, and from whom | F1 is the headline structural gap and the most natural first probe from a boss; JD because it scores the role's own scale |
| T-A2 | "You'd be partnering with hardware on the roadmap, and you're at a payments company today. How do you get up to speed, and why should I take that risk?" | JD | [grounded] "never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The highest-ROI rehearsal in the pack. Level 1: "I haven't owned a hardware-adjacent roadmap." Then a plan: the first questions you would put to hardware and to product, and what you would ask them to teach you. Level 2, "what do you know about how hardware plans?": say plainly what you do and do not know, supplying nothing. Level 3, "why you over someone who has?": hold only what the quotes carry, "I pushed a reliability quarter through against roadmap pressure," at its scope, and concede the rest without softening it. Never claim hardware experience, and never turn the reliability quarter into a hardware story | F5 is where the role's hardware mandate presses hardest, so this objection arrives in some form; JD because it scores the stated requirement, with the delivery of a Skeptic |
| T-A3 | "Why leave payments for industrial IoT, and why now?" | EXP | [generic] | A selection scaffold, not a story: give your actual reason in two sentences, naming one thing in the role text, such as the two squads or partnering with hardware and product, that you can speak to honestly. If the real reason is mostly the next step in management, say so plainly. Claim nothing about Larkfield beyond the role text, since research could not run | Motivation consistency is the standard Skeptic stem; EXP because the answer is the reason for leaving |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-B1 | "Two squads, a hardware release date you don't control, and one squad asking for a reliability quarter. How do you decide what they work on?" | CASE | [generic] | Structure it aloud: what you need to know first (what is fixed on the hardware date, what the reliability ask is protecting, who is hurt if each slips), the objective, two or three options with their costs, how you would decide and who you would tell, and what you would watch afterwards. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem from the role's own delivery and roadmap lines (F2's requirement), asked as a decision; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| T-B2 | "A configuration update goes to a fleet of devices and a fraction stop checking in. What do you need to know first, and what happens in the first hour?" | CASE | [generic] | Clarify first: how many, which cohort, what changed, can the rollout be halted. Then contain, diagnose, communicate. Say plainly which calls you would make yourself and which you would hand to an engineer, and who on the hardware and product sides hears what, and when. The question needs no claim about your past, so the guidance makes none | The "device-management services" line makes an incident problem likely; CASE because it scores structure and where a manager sits in an incident |
| T-B3 | "Hardware and software often run on different clocks. How would you open a joint roadmap conversation with the hardware team in your first ninety days?" | CASE | [grounded] "never owned a hardware-adjacent roadmap" | Propose principles, not a pretended seam: what you would ask hardware about their constraints and commitments, what you would offer them in return, and one assumption you would test before drawing any plan. Open with the acknowledgment if the follow-up goes to experience: "I haven't owned a hardware-adjacent roadmap." Never describe a process you have run | F5's requirement posed as a plan; CASE because the answer is a method, not a history |

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| T-C1 | "Walk me through your background and what brought you here." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | A 90-second arc with the beats the quotes state: nine years in engineering, three as a team lead of 6, currently at a payments company, and the reliability quarter, told at its scope. End on your own reason for this role. Do not add a beat the quotes do not carry | F1 and F2 are the spine of the biography; EXP because it checks that the story matches what the boss has read |
| T-C2 | "Tell me about a time you had to weigh delivery against something else your team needed." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The story is the quoted sentence: a reliability quarter, pushed through, against roadmap pressure, with the on-call burden down 60%. Tell those beats in your own words. Answer slots: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, in your own words; "I don't know how it was counted" is an honest branch. The sentence does not say who applied the pressure or how it ended, so say only what actually happened | The role's "own delivery" line raises this theme; this is F2's likeliest open-prompt form, and EXP because the figure will be probed |

### Reverse questions: Tuesday

| # | Question | Why it lands |
|---|---|---|
| T-R1 | "What would a good first ninety days look like to you, and what would tell you at day sixty that it is going wrong?" | It turns your gaps into a shared success definition with the person who will judge them |
| T-R2 | "Where do the two squads and the hardware team meet on the roadmap today, and where does it hurt most?" | It shows you are already planning the seam you said you would learn, and the answer is information you cannot research |
| T-R3 | "Is this role new or a backfill, and what shaped how it is scoped?" | It reveals what the role is really for, and tells you what your first decisions will inherit |
| T-R4 | "Across hiring, delivery and growth for the eleven engineers, which is furthest behind?" | It uses the role's own three verbs and tells you which of F3, F2 and F4 will matter first |
| T-R5 | "What would you want me to ask hardware and product in my first two weeks?" | It invites coaching from your would-be boss on the gap you named, and signals you plan to listen before you plan |

## Round 2: Thursday, the panel (60 min)

### Persona weights

Method: blend the top two personas of each member's relationship. The two staff engineers are peers and technical specialists, giving Peer Evaluator and Data-Driven Prober. The product manager is cross-functional, giving Values/Behavioral and Conversational. Names are unknown, so no persona is assigned to a person.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between a manager and senior engineers; what you need from them; credit | High. Two of three panelists are staff engineers pricing what you add to or take from their work | Reciprocity framing: what you bring them; propose seam principles, not a pretended seam |
| Data-Driven Prober | Line-by-line probing of the 60% figure and the hiring loop | Medium-high. Engineers probe numbers, and your message gives two | Know what you can and cannot say about how each figure was counted; say plainly where you do not know |
| Values/Behavioral | Scenario prompts about working with product on trade-offs and helping people grow | Medium. The product manager's relationship points to it, and the role names product partnership and growth | A story from a quoted sentence where one carries it; a selection scaffold ending in its honest branch where none does |
| Skeptic | The gaps, in collegial packaging | Low-medium. The Tuesday objection returns here from engineers asking whether a payments manager can be trusted on device work | The T-A2 method, reused |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-A1 | "Where is the line between what a staff engineer owns technically and what the manager owns, and what happens when we disagree on a call?" | JD | [generic] | Offer seam principles, not a claimed seam: engineers own how, you own what and when and who, and you ask for the disagreement early and in the open. Then reciprocity: what you would do to make their work easier. For the disagreement example, pick a time you disagreed with a senior engineer on a call that mattered, with a named stake and a decision that held; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role's "own delivery" line sits against staff engineers' technical ownership; JD because it scores the manager's side of that line, and `[generic]` because the guidance claims nothing about your past |
| P-A2 | "How do you handle it when engineering wants reliability work and product has a date?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The quoted sentence is the story: a reliability quarter, pushed through, against roadmap pressure, with the on-call burden down 60%. Tell it at that scope. Answer slot: the role's product-partnership line makes a probe on how you worked it with the product side likely; if product was where the pressure came from, say how you worked it and what you gave up; if the pressure came from elsewhere, or there was no such trade, say so plainly and stay with the quarter | F2 is the evidence behind this requirement and the likeliest panel story; JD because the question scores the product partnership line |
| P-A3 | "How do you handle credit when work spans squads?" | VAL | [generic] | A principle, with the example left to you: credit goes where the work was done, named specifically and publicly, and you say what you do when two squads claim the same result. Pick a time credit was contested or shared across teams, with a named stake and a relationship intact at the end; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The standard Peer Evaluator credit probe, and the role spans two squads; VAL because it scores behavior toward peers |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-B1 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer in your own words on the four slots only: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Name the weakest assumption before they do. If you do not know how it was counted, say so plainly; that is a credibility gain, and an invented method is the answer that breaks on the second follow-up. The figure is on-call burden; keep it attached to that noun | F2 holds the pack's one headline figure, so a defend-the-number question is required; EXP because it tests attribution and counting |
| P-B2 | "You say you run the hiring loop for backend roles, about forty interviews last year. Walk me through what running it covers." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say what the quote carries: you run the loop for backend roles, and the 40 counts interviews, not hires. Answer slot: the role's hiring line makes a probe on which stages were yours likely; if you shaped any stage, say which and how you decided, in your own words; if the loop's design was not yours, or there was no such step, say so plainly and stay with the interviews | F3 is the strongest on-point line for the role's hiring verb and the likeliest place a prober checks the scope; EXP because it tests what was actually yours |

### Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-C1 | "Tell me about a time you and a product partner wanted different things from the same quarter." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | If the reliability quarter fits, its beats are only those the sentence states: the quarter, the push, the roadmap pressure, the 60% drop. The sentence does not say the other side was a product partner, so say who actually wanted what. If a different time fits better, use it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role's product-partnership line raises this theme; VAL because it scores behavior with a non-engineering peer |
| P-C2 | "Tell me about a time you helped someone on your team grow." | VAL | [generic] | A selection scaffold: pick a person and a moment with a named stake, what you did yourself, and what changed for them, told without credit that was theirs. F4 shows nothing in your material on growth, so this is open ground. If no such time comes to mind, say so plainly, then say how you would start with a team of your own | The role names growth for the eleven engineers (F4), and your material is silent on it; VAL because it scores behavior, and `[generic]` because no quote carries a story here |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P-D1 | "A staff engineer here will know more about device management than you on day one. How do you earn their trust?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Do not bluff technical depth: your material shows nine years in engineering and a payments background, and nothing on device management. Say so plainly, then give a plan: what you would ask them to teach you, which decisions you would leave to them, and what you would take off their plate. Calibrated candor beats a claim they can test in one question | F1 is the gap a staff engineer will feel first; JD because it scores the role's leadership of device-management work |

### Reverse questions: Thursday

| # | Question | Why it lands |
|---|---|---|
| P-R1 | "What would a new manager do in their first month that would genuinely help you?" | The reciprocity question for peers; it shows you price what you cost them, not only what you need |
| P-R2 | "Where do technical decisions get made on these squads today, and where would you want the manager to stay out?" | It asks the engineers to draw the seam, which is better than guessing it |
| P-R3 | "How is the roadmap built with hardware today, and where do you most want engineering to be different?" | Directed at the product manager, it asks about F5's territory from their side |
| P-R4 | "What does on-call look like for these squads today?" | It connects to your reliability work without claiming it applies here |
| P-R5 | "What was the hardest trade-off the three of you worked through last quarter, and how did you resolve it?" | It surfaces how this group actually disagrees, which is what you will join |

## Round 3: Monday, the VP Engineering (30 min)

### Persona weights

The recruiter's description, "values and leadership philosophy", documents a values-style round. This is a dedicated values round with a skip-level executive. In 30 minutes expect four to six questions; rehearse in this order: M-A1, M-A2, M-C1, M-C2, M-A3, M-A4. No published company values were available (see Sources), so the VAL questions are themed on the recruiter's words, not on named values.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario prompts and a "your leadership philosophy" question | High. The recruiter named the round "values and leadership philosophy" | Beliefs you can each show with something your material carries; "we" for context, "I" for contribution |
| Pressure | Time-boxed challenge: "sixty seconds, why you", "how much was you" | Medium-high. An executive prior includes composure testing, and the T-A2 objection reaches a VP in short form | Pause, restate, hold through two follow-ups, concede specifically |
| Case/Strategist | Altitude questions: first ninety days, where you will be tested | Medium. The skip-level prior is strategy-heavy, but this round is not framed as a case | A plan stated aloud, with the open questions named |
| Conversational | A warm opener | Low-medium. Thirty minutes leaves little room | One sentence, then move on |

### Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-A1 | "What is your leadership philosophy, in a few sentences?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Choose two or three beliefs you hold and can back with something your material carries; a belief with nothing behind it is the one a VP probes. Two quotes can stand behind beliefs: the hiring loop (you run it for backend roles) and the reliability quarter (pushed through against roadmap pressure). Say each belief, then say what you actually did that shows it, at the quote's scope. Do not claim a belief about growing people unless you can back it, since F4 is silent | The recruiter's "leadership philosophy" is the raising source; VAL because it scores whether beliefs and past behavior match |
| M-A2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The reliability quarter is your nearest candidate, and only if the roadmap pressure came from leadership and you said something hard to them. The sentence does not say either, so say what actually happened: who pushed, what you said, how it ended. Choose a story where the hard truth landed, and if none of your stories fits, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for the values round; VAL because it scores candor under pressure, and the ending is yours to supply, not the pack's |
| M-A3 | "Tell me about a time you got a hiring call wrong." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start from what the quote carries: you run the loop for backend roles. Then, if a call comes to mind, say what you decided, what you saw afterwards, and what you changed, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not supply a miss you did not have | The role's hiring line raises the theme and F3 is the nearest evidence; VAL because it scores learning from a decision |
| M-A4 | "How do you think about what you owe your team when roadmap pressure and their workload collide?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The quoted sentence puts the on-call burden and roadmap pressure in the same sentence; use it at its scope and say in your own words what you owe them. Answer slot: the sentence does not say what the burden was to the people on call; if you saw it, say what, and if you did not, say so plainly and stay with the figure | F2's theme moved to a values question; VAL because it scores duty to the team |

### Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-B1 | "In your first ninety days, what would you want to learn before changing anything?" | CASE | [generic] | A plan: who you would talk to in each squad, in hardware and in product; what you would read; the two or three things you would hold off deciding until you understood them. Name what you would ask each group in your own words. The question needs no claim about your past, so the guidance makes none | The standard executive altitude question for a new manager, and the sharpest place to turn F5 and F1 into a plan; CASE because it scores structure |
| M-B2 | "Where do you expect your leadership to be tested most here?" | VAL | [grounded] "never owned a hardware-adjacent roadmap"; "I've never managed managers" | Pick one honest area and say why, as a learning plan: the hardware partnership is the one your material names ("I haven't owned a hardware-adjacent roadmap"), and the growth of eleven engineers is the one your material is silent on. If the VP's follow-up is whether this role leads to managing managers, say "I haven't managed managers" and what you would want to learn first | A leadership-philosophy question that invites an honest self-assessment; VAL because it scores self-knowledge, and F5 and F1 are the candid answers |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M-C1 | "Sixty seconds: why you, rather than someone who has already run a hardware-adjacent team?" | JD | [grounded] "never owned a hardware-adjacent roadmap"; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause, restate, then concede first and specifically: "I haven't owned a hardware-adjacent roadmap." Then hold what the quotes carry: you pushed a reliability quarter through against roadmap pressure. Hold through two follow-ups by returning to the quotes, never by adding to them, and concede uncertainty on what you do not know without folding on what you do | The T-A2 objection arrives in time-boxed form from an executive; JD because it scores the role's hardware mandate, delivered as Pressure |
| M-C2 | "That reliability result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the quote's verb: "I pushed a reliability quarter through against roadmap pressure." Answer slot: which part was yours, in your own words; if most of it was your team's, say so plainly and say what you did. Name the weakest assumption behind the 60% before they do, or say you do not know how it was counted | The standard Pressure attribution stem on F2's figure; EXP because it tests exactly what was yours |

### Reverse questions: Monday

| # | Question | Why it lands |
|---|---|---|
| M-R1 | "What does good engineering leadership look like here, and what would you want me to carry?" | It asks the VP to name the values in use, which research could not supply |
| M-R2 | "How do engineering managers here grow, including towards leading other managers?" | It names your own limit honestly and asks about the path |
| M-R3 | "Where has engineering leadership been tested most in the last year?" | It invites a real story, and a real story is what a values round is for |
| M-R4 | "What decision did leadership make recently that you would point to as reflecting the company's values?" | It shows you listen for values in decisions, not slogans |
| M-R5 | "What do you most want from a new manager in this role that you do not usually get?" | It ends the conversation on what you can offer |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Lead two squads building device-management services" | T-A1, T-B1, T-B2, P-D1, M-B1 |
| "own delivery" | T-B1, T-C2, P-A1, P-A2, P-B1, M-A4 |
| "hiring ... for 11 engineers" | P-B2, M-A3 |
| "growth for 11 engineers" | P-C2, M-A1, M-B2 |
| "partner with hardware and product on roadmap" | T-A2, T-B3, P-A2, P-C1, M-C1 |
| Context line, "industrial IoT, ~600 people" | T-A3, T-B2 — context, not a requirement; no further question |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has owned a hardware-adjacent roadmap | Negative you stated, F5 | The acknowledgment F5 gives: "I haven't owned a hardware-adjacent roadmap." No slot |
| Has managed managers | Negative you stated, F1 | The acknowledgment F1 gives: "I haven't managed managers." No slot |
| Has led two squads | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says a team lead of 6, not two squads. The slot stays inside the quote's scope |
| Has owned delivery across a roadmap | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says one reliability quarter, not delivery generally |
| Has made hiring decisions or hired 40 people | Inflated form of F3 | F3's quote at its own scope: you run the loop for backend roles, and the 40 counts interviews |

## Sources

Provided documents: your message (the role description, the three rounds and your background). No dossier, CV, full JD text, interviewer profile or recruiter guidance was supplied, and no link was read.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused (search permission was not granted in this session):
- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The call was refused. Would have fed a values cheat sheet for round 3 and named VAL questions; the cheat sheet is omitted, and round 3's VAL questions are themed on the recruiter's words |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | The call was refused. Would have checked each round's format; persona weights rest on the rounds and interviewers you described, which establish the loop |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The call was refused. Would have fed CO questions and a grounding brief; both are omitted |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access, or pasted material from Larkfield's own site (values page, careers page, a recent news item) → a values cheat sheet mapped to your stories, CO questions grounded in their current strategy, and a check of each round's format
- Your CV or a few lines on anything the pack calls silent, especially anything on helping engineers grow (F4) or work beyond your one team (F1) → rows that are `discovery` or `transferability` become quoted evidence, and the answer slots become story maps
- Anything you can show on the 60% on-call figure, such as the dashboard or report it came from → F2's confidence can rise from `medium`, and P-B1 becomes a story map
- The full job description → requirements the role summary leaves open, including whether the eleven engineers include leads who would report to you, become quoted `[grounded]` rows
- Interviewer names → persona weights read from their public footprint and a reverse question tied to each one's path
- The recruiter's guidance for each round, especially the panel's focus areas → coverage of any pre-declared deliverable and a reweighting of Thursday's personas
- A `tuesday-dossier.md` from an earlier session → verified evidence and constraints that would replace the inferences in this pack
