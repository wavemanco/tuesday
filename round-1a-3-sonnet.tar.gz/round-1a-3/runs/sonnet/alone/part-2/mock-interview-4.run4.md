I'll read the skill's reference files before building the pack.
Writing is done and I'm running a last consistency pass on the pack file, then I'll present it.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-4-denied-4909b215/Quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a single hiring-manager session, with no recruiter guidance and no take-home. It has 20 questions across six interviewer styles. The Skeptic and Case styles get the most, five each.

- **Highest-ROI rehearsal: A1.** It's the dossier's objection, worded as the dossier wrote it: no PM title, no roadmap, so why not the PM with three years. Open by conceding both plainly. Then bridge using only your three verified entries at their own scope. Name the limit on the roadmap-input sessions yourself. Close with a ramp plan. F1 is the 60-second version.
- **Roadmap ownership is conceded, not bridged.** The dossier says no credible evidence exists, so A2 and A5 coach the plain acknowledgment and a plan, not a story.
- **Agile delivery (A3) is a question, not a story.** The dossier marks it as something to clarify, and nothing verified speaks to it. The guidance is an answer slot with an honest "never worked that way" branch.
- **Answer slots are for you to fill, with real answers.** F3, F4, F5 and F6 hold the details the dossier doesn't carry. For example: which stages of the integrations were yours to run, and whether engineering or sales were in the room. Answer them in your own words, or say plainly it wasn't so.
- **Reverse questions come from the dossier's two open risks.** Decision authority against the squad leads and the adoption baseline are on the list, plus four more.
- **Company-specific facts are missing.** The three web searches (values, interview process, strategy) were refused. The pack has no Quartzline-specific content and no company-knowledge questions. The case questions are built from the JD's responsibilities and labelled generic.

You can turn on search, or paste Quartzline's values and a strategy brief, and I'll add those sections. A sample of the next steps is in the pack's upgrade menu.

I can play the hiring manager on A1 and push on the follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Quartzline — Product Manager, Platform APIs — interview pack

- **Round:** hiring-manager conversation, 45 minutes, Thursday. Interviewer not named.
- **Built from:** your pasted dossier (role profile and interview handoff). No separate CV or JD text was supplied, and web research was refused in this session, so nothing here rests on facts about Quartzline beyond the dossier.
- **Built on this assumption:** one session with the hiring manager, no recruiter guidance and no pre-declared deliverable.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did.

An answer slot is an instruction for the interview, not a question for you now. Where the pack does not know something about your past, the slot gives you two honest branches: say how it went, or say plainly that it was not that way and return to what is true.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values. None appears here: no published values are in hand and no values round is documented |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and attribution |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | None appears here: the research that would ground it was refused |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

Your three verified entries from the dossier's `verified_candidate_evidence` are quoted in full in the fit snapshot, and each question's Provenance cell quotes the ones its guidance rests on.

## Fit snapshot

The requirements are the dossier's `role_profile` lines. The evidence column holds only the dossier's verified entries, numbered 1 to 3 in the order the dossier lists them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | low | [grounded] | transferability | Allowed strategy: bridge. Your material carries integration work, not the product manager job, and the dossier's condition is that the bridge is positioned as adjacent and never as PM experience. The words stay at the quotes' scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The limit, as the pack's observation: nothing in your material shows a PM title or the years that go with it, so this requirement is met only as adjacency. The dossier classes this as a transferability gap, not a gate |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities); the dossier also lists "Owning a roadmap and prioritization authority (R1 sub-claim)" as a weak area | none given | none | [grounded] | capability | Allowed strategy: acknowledge_gap. The dossier records no credible evidence here, so no bridge is coached, and no entry above is stretched to cover it. Words, sourced from the dossier's prohibited_claims items "Having owned a product roadmap" and "Having set prioritization for an engineering squad": "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then how you would learn it, said as a plan and never as a past |
| F3 | "Shipped API or platform products" — JD (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1 | medium | [inferred] | transferability | The dossier did not grade this requirement, so the grade and gap type are this pack's derivation from that one quote. The quote carries client integrations of the vendor's APIs through go-live. It does not say an API or platform product was shipped, so the words stay at its scope. Answer slot, inside that scope: expect a probe on what you personally took through go-live. Say which of scoping, requirements, architecture, UAT and go-live were yours to run on the integrations you led, and where one was not yours, say so plainly and stay with the ones that were |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier role_profile R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence 2 | medium | [inferred] | discovery | The dossier did not grade this requirement; the grade is this pack's derivation. Neither quote mentions API docs or schemas. Answer slot: R3 names API docs and schemas, so expect a probe on what the playbook and the integrations involved. If either involved API documentation or schemas, say what and which part was yours, in your own words; if neither did, say so plainly and stay with the playbook you wrote. The playbook is the one claim with an artifact behind it, so be ready to walk through it |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence 3 | medium | [grounded] | transferability | The quotes carry clients and product; neither mentions engineering or sales. Words at that scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." That entry is confirmed with limited inspectable proof, so volunteer the limit before a prober finds it: say what the sessions were and stop. Answer slot, inside that scope: R4 names engineering and sales, so expect a probe on whether either was in the loop. If they were, say how and what part was yours; if your work was with clients and product only, say so plainly and stay there |
| F6 | "Agile delivery experience" — JD (dossier role_profile R5, preferred); the dossier's weak area reads "Agile delivery inside a product org (R5)" | none given | low | [grounded] | discovery | Allowed strategy: clarify. The dossier grades this low, and no verified entry speaks to the requirement itself, so no story is mapped and nothing nearby is stretched. Answer slot: R5 names agile delivery experience, so expect a probe on how you have worked in it. If you worked in an agile delivery process, say what your part was, in your own words; if you did not work that way, say so plainly, then say what you would want to confirm about how Quartzline defines it |

## Persona table

The relationship prior for a hiring manager is Case/Strategist plus Skeptic. The only loop information is your own: one 45-minute conversation with the hiring manager. No loop source documents other rounds or a values round, so persona weights rest on that prior and on the dossier, not on Quartzline's documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet, persistent probing of the title and roadmap gap | High: it is the hiring-manager prior, and the dossier names this objection for you, so it is the most predictable question in the conversation | Rehearse the A1 objection until it is boring: concede the roadmap first, bridge only from the quoted entries, name the limit, give a ramp plan |
| Case/Strategist (bank B, 5 questions) | Live problems from the role: adoption, specs, squad trade-offs | High: the hiring-manager prior, and the JD's responsibilities (roadmap, discovery, specs, adoption metrics) are all live-problem material | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (bank C, 3 questions) | Takes your verified claims one at a time and asks what was counted and what was yours | Medium: the 30+ figure is a headline number, and one entry is marked as having limited inspectable proof | Know what you can and cannot say about each claim and say plainly where you do not know |
| Conversational / Rapport (bank D, 3 questions) | Friendly openers, then casual questions about the JD's topics | Medium: hiring-manager conversations usually open this way, and the casual questions are still scored | A 90-second arc built only from your three verified sentences |
| Peer Evaluator (bank E, 2 questions) | Seam-splitting with the two squad leads | Low to medium: this is a hiring-manager round, but decision authority against the squad leads is an open item in the dossier, so the seam is likely to come up | Propose seam principles rather than pretending to know the seam |
| Pressure (bank F, 2 questions) | Time-boxed challenges to the same objection | Low: nothing in the dossier points to a stress style | Pause, restate, hold through two follow-ups, concede only what is specifically true |

## Question banks

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years product management experience | A1, A2, A4, A5, F1 |
| R1 sub-claim: owning a roadmap and prioritization authority | A1, A2, A5, B2 |
| R2: Shipped API or platform products | C3, C1 |
| R3: Technical fluency: API docs, schemas | C2, D2, B4 |
| R4: Stakeholder management across engineering, sales, customers | E1, B5 |
| R5: Agile delivery experience | A3 |
| Responsibility: run discovery with integration partners | B3 |
| Responsibility: write specs and drive delivery with two squads | B4, A3 |
| Responsibility: define and track adoption metrics | B1 |

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | The highest-ROI rehearsal in this pack: the dossier named this objection from what you confirmed, so it is not a guess. Hold-then-concede in four beats. One, concede first and plainly, on the strength of prohibited_claims: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Two, the bridge at the quotes' own scope, in your own words: you led 30+ end-to-end client integrations of the vendor's REST APIs from scoping through go-live; you wrote the internal integration playbook your team uses; you ran quarterly roadmap-input sessions feeding client evidence to product. Three, name the limit before they extract it: the sessions are confirmed but with limited inspectable proof, so say what they were and stop, and say this is adjacent work, not PM experience. Four, a ramp plan, said as a plan: the first thing you would learn is which roadmap decisions are the PM's and which sit with the squad leads. Follow-up 1, "what do you bring that a PM with the title does not": return to beats two and three and add nothing. Follow-up 2, "so who decided what happened to that client evidence": say what you ran and where it went, "feeding client evidence to product", and repeat that you haven't owned a roadmap; do not describe product's decisions. Follow-up 3, "then why not hire the PM": concede specifically that a PM with the title has done the job you haven't, and hold the bridge and the plan. Never argue you are better. The position you hold is adjacency plus a plan; the concession is the roadmap | F1 is the largest gap and F2 is the part conceded rather than bridged; the dossier names this as the likeliest objection. JD because it scores the title requirement, delivered in the Skeptic's quiet register |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | Pick the weakness the dossier already found rather than inventing one: roadmap ownership and prioritization authority. Say it plainly: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the plan, as a plan: on day one you would ask which roadmap decisions are the PM's alone and which belong to the squad leads, since the dossier lists that as unknown. Then stop and do not hand over a second weakness to chase. Agile delivery is a separate area (A3); your material does not show it is a weakness, so do not volunteer it as one | F2 is the one row where the dossier says no bridge exists, so the honest answer is a concession plus a ramp plan. JD because it scores self-assessment against the listed role; Skeptic stem |
| A3 | "Tell me about your experience with agile delivery." | JD | [grounded] | Clarify strategy, and no story is mapped because nothing verified speaks to this requirement itself (F6). Answer slot: the JD's "Agile delivery experience" makes a probe on how you have worked likely. If you worked in an agile delivery process, say what your part was, in your own words; if you did not work that way, say so plainly. Then offer the honest clarification: "Here is what I would want to confirm about how you define it." Do not borrow the quoted go-live or UAT work to fill this | F6 is rated low by the dossier and needs discovery before it needs a story. JD because it scores a stated requirement; the Skeptic asks it in a persistent register |
| A4 | "Why this role, and why now?" | JD | [generic] | Your reason is not in your material, so the answer is yours to state in your own words: one sentence, the reason you would repeat to a friend. If you have more than one, lead with the one that survives A1: it must not need any claim from the not-coached list. Keep it consistent with the concession in A1 | The pack has no motivation material, so the reason is an answer slot. JD because it scores the move into the listed role; the Skeptic's why-here-why-now stem |
| A5 | "Leading an integration and owning a product are different jobs. How do you see the difference?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having owned a product roadmap" | Answer from both sides at the quotes' scope. What you did: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." What you haven't: "I haven't owned a product roadmap." Then the role's ask, in the JD's words, "Own the roadmap for the partner-facing API platform", as the part you would be learning, and how you would learn it as a plan. Do not describe what product owners do as though you had watched it | F1 and F2 pressed from the other direction: it asks you to state the limit yourself. JD because it scores the role's ownership mandate |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Suppose partner adoption of an API stalls. How would you find out why, and what would you measure?" | CASE | [generic] | Clarify first: ask how adoption is measured today and what the current baseline is, since the dossier lists both as unknown. Then the objective, a segmentation of partners by where they are stuck, an approach built on talking to partners, one leading and one lagging metric, and the risks. Think aloud and challenge one premise respectfully, such as whether adoption is the right measure. The question needs no claim about your past, so the guidance makes none | The JD makes defining and tracking adoption metrics a responsibility. CASE because it is a live problem; generic because it is a pattern for the problem, not a fact about Quartzline |
| B2 | "Two squads, one quarter. One squad lead wants reliability work, and a partner is pressing for a new endpoint. How do you decide?" | CASE | [generic] | Answer as a method, not a memory. The pack's observation is that your material shows no prioritization of an engineering squad, so do not open with "when I have prioritized". Clarify who decides, what evidence you would gather from partners and from each squad, the criteria, how you would communicate the call, and the risks. Say plainly that decision rights are an open item and that you would ask which calls are yours | F2's gap makes this the case where the Skeptic's concern returns as a problem. CASE because it asks for reasoning on a live trade-off |
| B3 | "Walk me through how you would run discovery with integration partners in your first 60 days." | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure it: who you would talk to first, what you would want to learn, how the evidence is recorded and who sees it. Where you refer to your own past, use only "I ran quarterly roadmap-input sessions feeding client evidence to product", called what the quote calls them and not discovery, with the limit volunteered: confirmed, limited inspectable proof | The JD makes discovery with integration partners a responsibility, and F5's one entry is the closest evidence. CASE because it is a plan for the first weeks |
| B4 | "A partner wants a new endpoint. Sketch the spec: what do you need to know first?" | CASE | [generic] | Clarify first: who the partner is, the job they need done, expected volume and the workaround they use today. Then the objective, the shape of the spec including docs and schemas, a success measure and the risks. Say your order aloud. No claim about your past is made or needed | The JD has the PM writing specs with two squads, and R3 names docs and schemas. CASE because it is a live problem on the role |
| B5 | "Sales has promised a partner a date that engineering says is not achievable. What do you do?" | CASE | [generic] | Facts first: what exactly was promised, what is achievable and what each side is working from. Then who you would bring together, what you would tell the partner and how the decision rights work. Answer as a method; no past is claimed | R4 names engineering, sales and customers together. CASE because it asks for a decision on a live problem |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure is yours to defend, and the pack supplies no counting method. Answer slot, in your own words: how the 30+ was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours; your sentence says you led them. Where you do not know how part of it was counted, say so plainly | F3 rests on this quote and the figure is a magnet for probers. EXP because it tests attribution |
| C2 | "What was actually in the integration playbook, and what part was yours?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Hold the sentence: "I wrote the internal integration playbook my team uses." This is the one claim with an artifact behind it, so offer to walk through the playbook end to end. Answer slot: R3 names API docs and schemas, so if the playbook covered either, say what and which part was yours; if it did not, say so plainly and stay with the sentence | F4's evidence and the dossier's most inspectable claim. EXP because it tests what was actually yours |
| C3 | "Tell me about the most significant API or platform work you have taken to launch." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on the quote's own beats: scoping, requirements, architecture, UAT, go-live. Keep the sentence's scope: client integrations of the vendor's REST APIs. Answer slot: say which of those stages were yours to run on the one you choose, and where one was not yours, say so plainly and stay with the stages that were. Do not call the work shipping a product | F3 is the thinnest must-have link. JD because it scores the stated requirement; an open prompt, so you choose the instance |

### D. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc built only from those three sentences, in that order, each beat a clause the sentence states. Close with your reason for this role (A4's slot) in your own words. Call the sessions what the quote calls them, and do not label any beat product work | F1's evidence set as a story. EXP because it tests that the biography survives the later probes |
| D2 | "What are you playing with in API docs and schemas these days?" | JD | [generic] | Casual questions about a JD topic are still scored. Answer slot: if you are hands-on with API documentation or schemas right now, say what, in your own words; if you are not, say so plainly and say what you would pick up first. The pack names no tool and supplies none | R3 is a stated requirement, and a rapport-style question is the likeliest way it gets asked |
| D3 | "What would you want to know about the role before you would say yes?" | JD | [grounded] | Use the dossier's two open items as a real answer: which decisions the PM makes alone against the squad leads, and how adoption is measured today and from what baseline. Ask them as genuine questions, not as a test | The dossier's unknowns double as diligence. JD because it tests understanding of the listed role |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to get engineering, sales and a customer to the same answer." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | An open prompt, so you choose the instance. Your two quotes carry the client side and the product side: the integrations and the sessions. Answer slot: R4 names engineering and sales, so if they were in the room, say how and what part was yours; if your work was with clients and product only, say so plainly and stay there. If no such time comes to mind, say so, then give the nearest thing your material carries or how you would handle it | F5's requirement. JD because it scores the stated stakeholder requirement |
| E2 | "Where is the seam between a PM and the two squad leads, and what happens when you disagree?" | JD | [grounded] | You do not know the seam, and the dossier lists it as unknown, so say so and propose principles rather than inventing a seam: who decides what and why against how, how disagreements are surfaced early, and how a call is escalated with evidence. Make it reciprocal: what the PM gives the squad leads, not only what the PM needs. Claim no past disagreement | The dossier flags decision authority as asserted but not evidenced. JD because it scores a working relationship the role depends on; Peer register |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM who has done the job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; prohibited_claims: "Having held a product manager title or role" | A1 compressed. Pause, restate the question, then: the concession in the first ten seconds ("I haven't held a product manager title or role"), the two quoted entries at their scope, the plan, and stop. Hold through two follow-ups by returning to the quotes, never by adding to them | A1's objection in a time-boxed delivery; JD because it scores the same requirement |
| F2 | "That playbook — how much of it was actually you?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Hold the sentence: "I wrote the internal integration playbook my team uses." Answer slot: if anyone else contributed, say who and what; if you wrote it alone, say that. Add no detail the sentence does not carry, and concede only what is specifically true | C2 under pressure. EXP because it tests attribution |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier flags decision authority as asserted in the JD but not evidenced. The answer tells you whether this is the ownership you would be accepting, and it reads as diligence about the seam rather than as turf |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier notes adoption metrics are a named responsibility with no baseline stated. You cannot judge the target without one, and it picks up the thread from B1 |
| 3 | "What would you want a new person in this role to have learned by day 90?" | It surfaces the ramp the hiring manager expects, which is exactly what your plan in A1 answers, and it works whatever the hire's background |
| 4 | "How do the two squads run delivery today, and where does the PM plug in?" | The dossier marks agile delivery as something to clarify. The answer tells you what the requirement means here before you are asked about it |
| 5 | "Where does partner evidence reach the roadmap today, and who sees it?" | It shows how much of the discovery work is existing process and how much is yours to build |
| 6 | "What would make you say in six months that this was the right hire?" | It makes the success criteria explicit and shows you are already thinking about the outcome |

## Prohibited claims

Built from the dossier's `prohibited_claims`, plus two entries built locally from the fit snapshot. The dossier's `evidence_state` was not supplied, so it contributes nothing here.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims: "Having held a product manager title or role" | The plain acknowledgment: "I haven't held a product manager title or role." The adjacent work stays at F1's quote scope |
| Having owned a product roadmap | Dossier prohibited_claims: "Having owned a product roadmap" | The plain acknowledgment: "I haven't owned a product roadmap." F2 carries no bridge and no slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims: "Having set prioritization for an engineering squad" | The plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot |
| Influenced or shaped the product roadmap | Inflated form of F5's third quote | The quote at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation: your material says the sessions fed client evidence to product, not what product did with it |
| Shipped API or platform products | Inflated form of F3's quote | The quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The limit is the pack's observation: your material says client integrations of the vendor's APIs, not shipping an API or platform product. The slots in F3 and C3 stay inside the quote's stages |

## Sources

**Provided documents:** your pasted tuesday-dossier.md, envelope version 1.1. Sections consumed: `role_profile` (requirements, responsibilities, unknowns) and `handoff_to_mock_interview` (high-priority requirements, verified candidate evidence, uncertain or weak areas with allowed strategies, likely interviewer objections, opportunity risks, questions for the employer, prohibited claims). The `decision` section was read as context only. Not present in the paste, so not used: `evidence_map`, `evidence_state`, `risk_register`.

**Searches sent (all refused, nothing returned):**
- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline API platform strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have moved: published value names for VAL questions. The values cheat sheet needs a loop source documenting a values round, and none is in hand, so it would not have printed regardless |
| 2. `Quartzline interview process product manager` | unavailable | Would have moved: documented loop structure and persona weights. Your own words establish this one session, so weights rest on that and the hiring-manager prior |
| 3. `Quartzline strategy` / recent news | unavailable | Would have moved: CO questions and a CASE grounded in current strategy. The CASE bank is built from the JD's responsibilities instead and is labeled generic |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile supplies the requirements the fit snapshot and JD-tagged questions rest on |

## Upgrade menu

- Search access, or a strategy brief and Quartzline's published values pasted in → CO questions and a CASE grounded in current strategy, plus VAL questions if a values round is documented. With search allowed, a deeper research pass is available: up to 6 more searches and 2 more fetches, several more minutes
- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's note on focus areas or process → coverage adjusted to what is announced, and a build section for any pre-declared deliverable
- The written summary or agenda from one of the roadmap-input sessions → F5's third quote moves from limited inspectable proof toward inspectable, and B3 and E1 can lean on it harder
- Your answers to the slots in F3, F4, F5 and F6, said outside a drill → those four rows regenerate with your own words in the evidence column
- The raw CV behind your confirmed claims → F1, F3 and F4 can quote the CV itself, which may lift confidence on the rows now graded by derivation
- Your actual prep hours before Thursday → a prioritized schedule that does the few highest-value rehearsals first
