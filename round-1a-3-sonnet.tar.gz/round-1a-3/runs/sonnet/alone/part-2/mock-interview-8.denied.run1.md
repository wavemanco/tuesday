I'll read the reference files the skill points to before building the pack.
Finishing the pack: I've saved it and just fixed one question, so I'm now writing the closing message.

Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`, in the working directory. I built it as a loop of three mini-packs, one per round on 29 November. Each has its own persona weights, 8 or 9 questions and reverse questions. The values cheat sheet sits in round 3, since the recruiter said the panel scores against the four values.

- **Highest-ROI prep:** B1, with A7 as its short version. It covers the objection a manager asks first: you've said you've never worked in a contact centre, and the role covers both branches and the contact centre. B7, on presenting above regional level, is the second.
- **No interviewer read:** no names are assigned yet, so the pack works from the roles only.
- **No searches run:** your pasted values, the recruiter's email, the JD and your summary of the strategy brief already fixed everything a search would have fed.
- **Strategy brief:** I only saw it as your summary, so read the brief itself before the 29th.
- **Your gaps:** the pack's snapshot of your background keeps your gaps at your own words. It doesn't script claims like "owned the process end to end" or "presented to senior leaders". Section 13 of the pack lists what I wouldn't coach and why.

Say the word and I'll play the round 3 panel on C1, the 20-minute escalation case, or any other question.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

29 November 2026 is a Sunday. Is that date right, or has the recruiter's email got it wrong?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds on 29 November 2026, built on 20 November 2026.

| Round | Length | Who | Relationship | What the recruiter said it is |
|---|---|---|---|---|
| 1 | 30 min | The recruiter | Recruiter screen | The process conversation |
| 2 | 45 min | Head of Member Services | Your future manager | Mostly behavioural |
| 3 | 60 min | Panel of two branch managers | Panel | Includes a 20-minute case on a complaint escalation; also the values round, scored against the four values |

Interviewer names are not assigned yet, so there is no interviewer read. Everything below is built from the roles alone.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script, and an answer slot is an instruction for the interview: answer it from your own experience, or say plainly that the practice was not yours.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your background survives a close read |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude: strategy, competitors, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Question IDs run by round: A for round 1, B for round 2, C for round 3. F rows are the fit snapshot.

## Prep triage

Nine days from today. In order, each tied to a question or section:

1. B1 and A7, the contact-centre objection, the pack's highest-ROI prep. Say the concession aloud until it is boring.
2. B7, the presenting-to-senior-leaders objection, said the same way.
3. C1 and C2, the 20-minute escalation case. Run it aloud twice with a timer and think aloud.
4. C3 to C6, one story each for the four values. Choose them from your own experience; the scaffolds say what each needs.
5. A3 to A5, your actual notice, location and pay answers, decided before the recruiter asks.
6. B3, the monthly complaints spreadsheet, so you can say what it counted and how.

Everything else is insurance.

## Fit snapshot (shared across rounds)

Requirements are quoted from the JD you pasted. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says a branch's formal complaints log, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's wording makes a probe on what happened around the log likely. If any step around the log was yours to run, say which and what you did, in your own words; if the log was the extent of it, or the other steps were not yours, say so plainly and stay with the log |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says a monthly complaints spreadsheet your regional manager uses; it does not say what it counted. Answer slot: the JD names complaint volumes and resolution times, so expect a probe on what the spreadsheet counted. If it counted either, say which and how, in your own words; if it did not, say so plainly and say what you would count first |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The quote says new tellers and an escalation script, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD says supervisors, so expect a probe on coaching at that level. If you coached any supervisors, say how, in your own words; if the tellers were the extent of it, say so plainly and stay there |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on digital teams. Answer slot: if you worked with any team outside your branch on something members used, say what and which part was yours, in your own words; if you did not, say so plainly and say how you would start |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Derived from the word "formal": the quote does not show whether those complaints followed outside rules. Answer slot: if the formal complaints you logged had set rules or deadlines attached, say what they were, in your own words; if they did not, or you do not know, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The quote says spreadsheet, not Excel. Answer slot: say which tool it was built in, in your own words; if it was not Excel, say so plainly and say what you have used |

## Grounding brief

The July 2026 strategy brief reached me only as your summary, so these rows are as you reported them. Read the brief itself before 29 November for its exact wording.

| Fact | What it may mean for the interviews | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | Questions on which complaints suit self-service and which need a person (B5, B9) | [grounded] |
| Consolidate eight branches into five hubs over 2027 | Questions on complaints during branch change, and on the branch-side view in round 3 (C5, C7) | [grounded] |
| Launch a small-business lending product in Q1 2027 | A new product line is a new source of complaints; questions on readiness (C9) | [grounded] |
| Main competitive pressure is app-only banks | Questions on why a member stays, and on plain, fast complaint handling (C9) | [grounded] |
| Member-owned, about 900 staff — JD | Tie answers to members first; the JD gives no more than this on structure | [grounded] |

Vocabulary to use: members, not customers; hubs; self-service journeys; resolution times.

# Round 1: the recruiter (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through of your background, then logistics | High: a recruiter screen is conversational by default, and the recruiter named it a process conversation | Prepare a 90-second arc for A1; treat every casual question as scored |
| Skeptic (light) | Quick knock-out checks on the JD's hard-looking items | Medium: F2, F7 and F8 are the items a screen checks first | Say the plain acknowledgment briefly and move to a plan; do not defend what you have said you have not done |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F6: six years in retail banking, the last three as a branch supervisor. Then the log and the spreadsheet, in those words, no more. Answer slot: why you are moving is yours to say; give your actual reason in your own words | F6 is the years requirement and the natural opening; EXP because it tests the background, in Conversational delivery |
| A2 | "What's making you look at a move now, and why Ashgrove?" | EXP | [generic] | Give your own actual reason for leaving, then your own reason for Ashgrove. The JD and the values page give you the vocabulary: a member-owned organisation, and "Members First, Always". Logistics slot: your reason is yours; nothing here supplies one | The recruiter row's reason-for-leaving logistics; EXP because it tests motivation consistency |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period. If it has flexibility, say your own terms; do not offer flexibility you do not have | Recruiter logistics: notice; JD because it scores the terms of the listed job |
| A4 | "The role runs across branches and the contact centre. Where are you based, and what does travel between sites look like for you?" | JD | [grounded] | Logistics slot: give your actual location and any travel limits in your own words. If you do not yet know the sites, ask where the role would be based | Recruiter logistics: location; the JD's branches-and-contact-centre line raises it |
| A5 | "What are you looking for, salary-wise?" | JD | [generic] | Logistics slot: either give your own number, or ask for the role's band first. Do not state a past salary; if asked for it, you can decline and redirect to the role's band | Recruiter logistics: pay; JD because it scores the listed job's terms |
| A6 | "The role includes regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log" | Hold only the quote: "I handled the branch's formal complaints log." Answer slot: if those complaints had set rules or deadlines attached, say what they were, in your own words; if they did not, or you do not know, say so plainly and stay with the log | F7 is the likeliest knock-out; JD because it scores a stated requirement |
| A7 | "You've not worked in a contact centre. How does that sit with a role that covers both?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then a plan, said as a plan: what you would learn first about how contact-centre complaints reach the team, and who you would ask. No claim of contact-centre work. Keep it under a minute here; B1 is the deep version | F2 is the gap a screen checks early; the negative is yours, so the question may state it |
| A8 | "Tell me about the reporting you do on complaints." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say it in the quote's words. Answer slot: the JD names complaint volumes and resolution times, so expect a probe on what it counted. If it counted either, say which; if it did not, say so plainly. Also say which tool it was built in, or that you do not remember | F3 and F9 both rest on this quote; the screen is where the Excel line is checked lightly |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Will the panel case be on a scenario I should prepare for, or is it unseen?" | Process, and it tells you how to spend days 4 to 9 |
| R1.2 | "What does the hiring team most want this role to change in the first six months?" | Draws out what the strategy brief means for the role in the team's own words |
| R1.3 | "Is the contact-centre side of the role currently owned by someone I would work with?" | Shows you have seen the F2 limit and are planning around it |
| R1.4 | "Who will I meet in rounds 2 and 3, and are there materials I should read first?" | Practical, and covers the unassigned interviewers |
| R1.5 | "Where is the date set, and is the day firm?" | 29 November 2026 is a Sunday, so confirm the date before planning around it |

# Round 2: the Head of Member Services (45 minutes, mostly behavioural)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the contact-centre and presenting gaps | High: a manager derisks gaps first, and F2 and F8 are the two gaps you have stated | Rehearse B1 and B7 until they are boring; hold, then concede specifically |
| Values/Behavioral | "Tell me about a time" prompts | High: the recruiter said mostly behavioural | Use stories from your own experience; "we" for context, "I" for what you did |
| Case/Strategist | Live problems from the role's roadmap, including digital and the hubs | Medium: the manager owns the process the strategy changes | Clarify, then structure, then think aloud; challenge one premise respectfully |
| Data-Driven Prober | Questions on the spreadsheet | Low to medium: one artifact of yours is a reporting tool | Know what you can and cannot say about what it counted |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd own complaints across branches and the contact centre. Where would you be weakest on day one?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | **Highest-ROI prep in this pack.** Hold: "I handled the branch's formal complaints log." Concede, specifically: "I haven't worked in a contact centre." Follow-up 1, "so what do you not know?": name what you do not know about contact-centre complaints, plainly. Follow-up 2, "why take the risk?": return to the log, in the quote's words, without adding to it. Follow-up 3, "what would you do first?": give a plan, said as a plan. Answer slot: if any step around the log was yours to run, say which; if not, say so plainly and stay with the log | F1 and F2 together are the objection a manager asks first, and the aimed-at spot is where the material is thinnest, so the limit is named before it is asked for |
| B2 | "Tell me about a time you coached someone through a difficult complaint escalation." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: new tellers and the escalation script, which are the beats the quote states; tell them in your own words. Answer slot: the JD says supervisors, so expect a probe on coaching at that level. If you coached any supervisors, say how; if the tellers were the extent of it, say so plainly and stay with them | F4 is the evidence for the coaching line; the open prompt's theme comes from the JD |
| B3 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what it is in the quote's words: a monthly complaints spreadsheet your regional manager uses. Answer slot: if it counted volumes or resolution times, say how each was counted and which part was yours; if it counted something else, or you do not know how a figure was defined, say so plainly. Name the definition in it you would defend least, in your own words | F3 and F9 rest on one quote; EXP because it tests what was actually yours |
| B4 | "A member complains at a branch, is passed to the contact centre, and is told to start again. What do you do, and what do you change?" | CASE | [generic] | Structure it: what you ask first (what has the member already been told, and by whom); the fix for this member today, without making them repeat themselves; who keeps hold of it until it is solved; what you record; what you change so it does not recur. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's end-to-end line, and the "Own the Fix" value asked as a decision |
| B5 | "The strategy moves 40% of member service to digital by 2028. What does that mean for complaints?" | CO | [grounded] | Clarify first: which complaint types are suited to self-service, and which need a person. Then segment, name the risk that a member with a problem is the one who most needs a person, and say how you would measure it. Use "Plain Words" for the self-service journeys. No claim about your past | The CO question from the brief; also covers the digital-teams requirement as a live problem |
| B6 | "How would complaint handling be different in a hub than in a branch?" | CO | [grounded] | Clarify what a hub is meant to do; then what changes for the member, the supervisor and the record. Tie to "Neighbours, Not Numbers" without claiming knowledge of Ashgrove's plan beyond the brief. No claim about your past | The eight-to-five consolidation is a named move in the brief, and a complaints lead would be asked about it |
| B7 | "You'll present complaint reporting to senior leaders. You've not presented above regional level. What will be different?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Plain acknowledgment: "I haven't presented to anyone above regional level." Hold: the report itself is yours, in the quote's words. Then a plan, said as a plan: how you would prepare for a senior audience. Do not claim senior exposure | F8 is the second stated gap; JD because it scores the stated requirement |
| B8 | "Tell me about a time you saw a complaint through when it wasn't strictly yours." | VAL | [grounded] | Selection scaffold for "Own the Fix": pick a time a problem you found stayed with you until it was solved; it needs a named stake, what you personally did, and the member's outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's wording ("whoever finds the problem keeps hold of it until it is solved") raises it; a scaffold because no quote carries a story |
| B9 | "Tell me about a time you worked with a team outside your branch to change something members used." | VAL | [grounded] | Selection scaffold: pick a time you took a member-facing problem to people outside your branch; it needs the team, your part, and what changed. If no such time comes to mind, say so plainly, then say how you would start with a digital team: what complaint themes you would bring, and what you would ask them first | F5 is silence, not a stated absence; the JD raises the digital-teams line |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What would you want to be true about complaints in this team after the first year?" | Asks the manager to define success, which you can build your plan around |
| R2.2 | "How do the branches and the contact centre currently hand a complaint to each other?" | Shows you are looking at the seam B4 tests |
| R2.3 | "Who does the monthly reporting go to now, and what do they ask for?" | Ties to the senior-audience limit and surfaces what the audience wants |
| R2.4 | "How will the move to five hubs change who I coach?" | Connects the coaching line to the 2027 plan |
| R2.5 | "What would you expect from a new lead from someone with a branch background in the first ninety days?" | Invites the manager to name the gap and what closes it |

# Round 3: the panel of two branch managers (60 minutes; also the values round)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes scored against the four values | Highest: the recruiter said the panel scores against the four values | One story per value from your own experience, or the scaffold's honest branch |
| Case/Strategist | The 20-minute escalation case | High: stated in the recruiter's email | Clarify, objective, approach, who owns it, what you record; think aloud |
| Peer Evaluator | Where your coaching meets a branch manager's authority | Medium: the JD has you coaching branch supervisors, and the panel are branch managers; this is my reading, not a stated fact | Offer seam principles, not claims about how Ashgrove divides the work |
| Pressure | Time-boxed challenge on the case | Low: no source says the panel is a stress format | Pause, restate, hold the position through two follow-ups |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A member has raised the same problem with two branches and the contact centre. Each says the other has it. The member says they will take it outside the credit union. You have twenty minutes." | CASE | [generic] | Structure aloud: clarify first (what has been promised, to whom, what deadlines apply, whether anything about the member changes how you handle it); the member's side first; one owner named today; a reply in plain words; what you record; what the supervisors need; what you change. Ask what outside rules apply rather than assert them. The question needs no claim about your past, so the guidance makes none | The 20-minute case the recruiter named; "Members First, Always" and "Own the Fix" asked as one decision |
| C2 | "The supervisor involved says the member is wrong and won't escalate. How do you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | Ask what the supervisor thinks happened before telling them anything; agree what the member's side looks like; agree the next step together. Your own coaching quote is "I trained new tellers on our escalation script." Answer slot: the JD says supervisors; if you coached supervisors, say how; if not, say so plainly and stay with the tellers | F4 gives your closest evidence; CASE because it is a live problem with a coaching premise |
| C3 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold for "Members First, Always": pick a decision where the member's interest and a process or number pulled apart; it needs your decision, what it cost, and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's own wording raises it; a scaffold because no quote carries such a decision |
| C4 | "Tell me about a time you made something clearer for members or for staff." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: the escalation script, in the quote's words. Answer slot: "Plain Words" says a member who needs it explained twice means the wording is wrong; if you changed any wording in a script, letter or reply because it needed explaining again, say what and who changed it; if you did not, say so plainly and say how you would test wording | The value's wording raises it; the script is the one quoted artifact near the theme |
| C5 | "Tell me about something you did for your branch's town, not for a number." | VAL | [grounded] | Selection scaffold for "Neighbours, Not Numbers": pick a time you served something specific to your branch's community; it needs the place, what you did, and why it was not a target. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The value's wording raises it; relevant because eight branches become five hubs |
| C6 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1, to its own scope: "I handled the branch's formal complaints log." Answer slot: "Own the Fix" says whoever finds the problem keeps it until solved; if there was a complaint you saw through to its end, say what it was and which part was yours; if there was none, say so plainly, and describe how you ran the log | The value's wording raises it; the log is the closest quote and carries no more than the log |
| C7 | "Eight branches become five hubs. What does that mean for a member whose branch closes, and for a complaint?" | CO | [grounded] | Clarify what members of a closing branch lose and keep; then complaints: who holds a complaint during the change, how the record travels, what supervisors need. Name the risk of numbers outrunning neighbours. No claim about your past | Branch managers are closest to the consolidation in the brief |
| C8 | "Where does your coaching of a supervisor stop and a branch manager's authority start?" | JD | [generic] | Offer principles, not a map: the member's complaint stays with a named owner; the manager keeps the people decisions; you own the process and the coaching on it. Ask what the seam is today before proposing one. No claim about your past | Peer-style seam probe; the panel are branch managers |
| C9 | "App-only banks are the main pressure, and a small-business lending product launches in Q1 2027. What does good complaint handling look like for both?" | CO | [grounded] | Structure: what a member keeps a credit union for that an app does not give; what a new product line changes (new complaint types, new staff to coach); plain-words, fast resolution; what you would report. No claim about your past | The brief's competitive frame and the new product, asked at the panel's altitude |

## Values cheat sheet

The values are quoted from the page you copied on 20 November 2026. The panel scores against all four.

| Value | Working meaning | Mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quote carries a story: use the C3 scaffold and its honest branch | C3 |
| Plain Words | If a member needs it explained twice, the wording was wrong | F4, "trained new tellers on our escalation script", at its own scope, plus C4's slot | C4 |
| Neighbours, Not Numbers | Every branch is part of its town | No quote carries a story: use the C5 scaffold and its honest branch | C5 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1, "I handled the branch's formal complaints log", at its own scope, plus C6's slot | C6 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "Which of the four values is hardest to hold to at a branch under pressure, in your experience?" | Asks the managers for their own view, which is a peer conversation |
| R3.2 | "When a complaint reaches the contact centre from your branch, what do you want to hear back, and when?" | Gets the branch-side expectations that C8 tests |
| R3.3 | "What would you want a Member Experience Lead to do differently from the last time someone coached your supervisors?" | Asks for what they want without assuming how it was done |
| R3.4 | "How are you thinking about the move to hubs, and what worries you about complaints during it?" | Shows you have read the strategy and are listening to their side |
| R3.5 | "What would make you say I was the wrong choice a year in?" | Invites the objection while you can still answer it |

## Requirement coverage

| Requirement | Questions |
|---|---|
| Own the complaints process end to end across branches | B1, B4, C1, C6 |
| And the contact centre | A7, B1, B4 |
| Report monthly on complaint volumes and resolution times | A8, B3 |
| Coach branch supervisors on escalations | B2, C2, C8 |
| Work with digital teams on self-service journeys | B5, B9 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | A6 |
| Confident presenting to senior leaders | B7 |
| Comfortable with Excel reporting | A8, B3 |

## Prohibited claims

Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's formal complaints log, not the process around it. B1's slot stays inside the log |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: new tellers and the escalation script. B2's slot asks only whether any supervisors were coached |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. B3's slot asks what the spreadsheet counted |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: the branch's formal complaints log. A6's slot stays inside the log |
| Built the Excel reporting | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. A8's slot asks which tool |

## Sources

Provided documents: the JD you pasted; the values text you copied from ashgrovecu.org/about/values on 20 November 2026; the recruiter's email about the process; the strategy brief as you summarised it (the brief itself I have not seen); your background in your message. No dossier was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the cheat sheet and the VAL questions |
| 2. Ashgrove interview process, member-services roles | skipped | The recruiter's email establishes three sessions and who runs each; persona weights follow it |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief fixes the CO questions and the grounding brief |
| 4. Interviewer name and Ashgrove | n/a | No names are assigned, so there is no query to form; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Your answers to the slots on F1, F3, F4, F5, F7 and F9 → those rows move off discovery or transferability, and the matching guidance becomes story-mapped instead of scaffolds
- Your CV → fit rows quote its lines, so more rows can reach medium or high confidence
- The names of the Head of Member Services and the two branch managers, once assigned → an interviewer read, tuned persona weights and a reverse question tied to each person's path
- The strategy brief's text → the grounding brief quotes it exactly instead of resting on your summary
- Anything the recruiter says about the panel case, such as format or materials → a build section if a deliverable is announced
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → recent Ashgrove context for the CO questions; say so if you want it
- A tuesday-dossier.md from an earlier session → verified evidence and any prohibited claims carried in
