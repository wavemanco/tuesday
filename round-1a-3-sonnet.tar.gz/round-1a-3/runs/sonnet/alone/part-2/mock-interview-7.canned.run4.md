I'll read the reference files the skill points to before building the pack.
Research is done: I read Saltmarsh's values page and interviewing page, and the strategy and Tobias-talk results came back as search snippets. I'm writing the pack file now.
Your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for the single 60-minute "Outage Hour" that Saltmarsh's careers page describes: a live-incident tabletop on a simulated outage, then a values conversation. It assumes Tobias is the hiring manager running it. The pack's highest-ROI prep is C1, the in-app-purchase gap against Saltmarsh's announced move to a season pass.

Two things in the research rest on search-result summaries only, because I spent my fetches on the values and interviewing pages. They are the season-pass announcement and Tobias's GDC talk page. Read both pages yourself before Friday.

Say the word and I'll play the Skeptic on C1 so you can rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the hiring manager you'd report to, and did the recruiter say anything about what the outage tabletop covers? Either answer would reweight the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed: the hiring manager, in the one 60-minute session Saltmarsh's careers page describes (a live-incident tabletop, then a values conversation). Candidate: Femi.

## How to use this pack

Personas describe how a question arrives; types describe what it is scoring. Rehearse both: say the answers aloud, in your own words.

Type key:

| Tag | Meaning |
|---|---|
| VAL | Whether your past behaviour shows the company's published values |
| EXP | Whether a line of your background survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you can think at the company's altitude: strategy, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for you: it names what an interviewer is likely to probe, and it gives you two honest branches, so say whichever is true. Question IDs run by persona (A, B, C, D, E, G); the letter F is skipped because fit-snapshot rows use it.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message; nothing was inspected behind it, so no row is `high`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one main title's weekly content-drop calendar, not a live-events calendar or a second title, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's calendar line makes a probe on what you set within it likely. If dates or content were yours to set, say which and how you decided, in your own words; if others set them, or there was no such decision, say so plainly and describe what running the calendar involved |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Your material does not show which teams the drops involved. Answer slot: the JD names design, art, engineering and community, so expect a probe on who you worked with on a drop. Name the teams you did work with and what you did with them, in your own words; if some of the four were not part of your drops, or the work was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you owned a review or set the KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's ownership line makes a probe on whether you ran reviews likely. If you ran any review of an update or event, say how it worked and what part was yours, in your own words; if there was no such review, or it was not yours, say so plainly and stay with the monthly numbers you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: the JD's word is manage, so expect a probe on running it release by release. If you ran it with QA on releases, say how, in your own words; if QA ran it, or it was applied without you, say so plainly and stay with the checklist |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message, "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The four years clear the JD's number; the material does not say whether the puzzle title was run as a live service, so expect a probe on that. Answer slot: if it was, say how, in your own words; if it was not, or only in part, say so plainly and stay with what your material states |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on it. Lead with the calendar in the quote's own terms: you ran it, weekly, for two years, because a named record beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap on the words, but nothing inspected behind them, and a presented number draws a probe on how it was counted. Lead with the quote's terms: you presented the monthly retention numbers to the studio head. D1 rehearses the probe |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | Your message names one written artifact and nothing about how clearly it reads. Answer slot: the JD asks for clear written communication, so expect a request to describe or show your writing. Say what you wrote and who reads it, in your own words; if the checklist is most of it, say so plainly and stay with the checklist |
| F9 | Not a JD line, company context: the September 2026 move to a season-pass model (news page, seen as a search snippet only) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." and "I haven't led a team." Then how you would learn it, said as a plan and never as a past. Nothing added to make either gap feel smaller |

## Persona weights and table

Loop: Saltmarsh's careers page (fetched) says every loop is a recruiter call, then the Outage Hour, a single 60-minute interview with the hiring manager: a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home. That establishes your session, so no archetype fallback is used. Whether Tobias is that hiring manager is an assumption.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | The tabletop: a simulated outage during a live event, with follow-ups on trade-offs and what you tell players | High. The careers page names the tabletop as the first half of the hour, and the hiring-manager prior favours live problems on the real roadmap | Clarify, then structure, then answer; think aloud; challenge one premise respectfully. A and the JD-tagged items need no past claim |
| B. Values/Behavioral | The second half: scenario probes mapped to the three published values | High. The careers page names a values conversation, and the values page names three values, so each gets a question | Map a story to each value where your own sentences carry one; where none does, say so and choose from the scaffold. Section 10 has the map |
| C. Skeptic | Quiet probing of what the background does not show | Medium. The hiring-manager prior includes it, and you have stated two gaps (F9); the September season-pass news makes the in-app-purchase gap the likeliest probe | Rehearse C1 until it is boring: concede the plain fact, hold only what your quotes carry, then a ramp plan |
| D. Data-Driven Prober | Line-by-line questions on the retention numbers and the checklist | Medium. The JD asks for comfort with retention metrics and for owning the KPIs; no source describes Tobias as analytics-led, so this is the JD's pull, not his | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| E. Conversational | The opener ("walk me through the journey") and a casual question about the role | Low to medium. Every session opens somehow, and a casual register is still scored | A 90-second arc built from four of your sentences |
| G. Pressure | Time-boxed challenges, "why you over someone with more" | Low. The careers page describes a simulated outage, which may be time-boxed, but nothing in the material says he interrupts or plays devil's advocate | Pause, restate, concede the plain fact, hold what your quotes carry |

## Reading the interviewer

Public professional footprint only. The two Tobias rows below come from a search-result summary of a conference talk page; the page itself was not fetched, so read it before Friday.

| Observation | Provenance | What it means for you |
|---|---|---|
| Your note names him as Head of Live Operations; the talk page describes him as "Head of Live Operations at Saltmarsh Games" | [grounded] | The persona weights assume he is the hiring manager for the Outage Hour |
| The same summary says he was "previously a QA lead at a console studio" | [grounded] | Release discipline is home ground for him, so expect close questions on the checklist (D3, B3) |
| GDC 2026 talk "Patch Notes Are a Promise"; the summary says "His argument: a live team is judged by how often its patch notes describe what actually shipped." | [grounded] | The company value "we announce what is built, not what is hoped" reads like the same line, so A3 and B2 rehearse separating what shipped from what was hoped |
| Mirror opportunity, shared vocabulary rather than a shared jump: checklists and release discipline. Your side, from F4: "Wrote the release checklist our QA team still uses." | [grounded] | Use your own sentence as it stands. Nothing in your material shows a move out of QA, so no shared career jump is offered, and affinity is not a strategy |

## Question banks

Ordered by weight. Highest-ROI prep in the pack: C1.

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Forty minutes into a live event, players report the event screen will not load and the support queue is filling. What are your first ten minutes?" | CASE | [inferred] | Think aloud in order. First, one clarifying question: what is broken, for whom, since when, is it spreading. Then who owns the call and who needs to be in the room: engineering first, then community, design, art and QA as the problem requires. Then what players are told and when, and a written timeline kept as you go. Make no claim about a past outage; the question needs none | The careers page describes the first half of the hour as a tabletop on a simulated outage during a live event; this scenario is the pack's own illustration, not a reported question. CASE because it scores clarifying before structuring; F2 is the requirement behind the teams in the room |
| A2 | "The fix will take until tomorrow, and the calendar says the next event starts at midnight. Extend, pause or move on?" | CASE | [inferred] | Say the trade-off aloud with the published value: "when the calendar and the players disagree, the players win." Name what players lost and what had been promised to them, then your call, then what that call costs the next event and who must be re-planned. Concede that cost without softening it. Close with who has to agree and what goes in the review | Tests the first value live, in the tabletop's own setting; derived from the careers page and the values page. CASE; the calendar requirement is F1's |
| A3 | "Engineering ships three of the five fixes you announced. Give me the opening line of the patch notes, out loud." | JD | [inferred] | Say what shipped first, plainly. Then name what did not, without a date you cannot keep: the published line is "we announce what is built, not what is hoped," and it decides what goes in. Keep it to what a player reads in one breath, then offer to tighten it aloud. It asks for no past | Covers the JD's written-communication line (F8) in a form the room can score; the value and the interviewer's talk title point at it. JD content, CASE delivery |
| A4 | "The outage is fixed. What goes in the post-event review, and which numbers does it report?" | JD | [grounded] | Structure it: timeline, player impact, cause, what changes next time, then the numbers. Pick the few numbers you can define in one sentence each, say what each one would not tell you, and name the one you would trust least. Make no claim about reviews you have run; the question needs none. If asked who owns it, say what you would want to own and what you would ask engineering and QA for | The JD's "own the post-event review and the KPIs it reports" is a headline responsibility; F3 holds the limit and D1 is the defend-the-number version |
| A5 | "From February, Tidepool Tactics and Lantern Row share one events calendar and one live-ops group. What would you want to know before planning the first shared calendar?" | CO | [grounded] | Clarify before structuring: which two titles this role covers, what the calendar's unit is (season, event, week), who decides when two titles want the same slot, and how the season pass shapes which events matter. Then objective, approach, metrics, risks, thinking aloud. Challenge one premise respectfully, for example whether a shared calendar needs a rule for conflicts. Read the full announcement before Friday; this pack saw only a summary of it | The strategy-grounded question the coverage rules ask for; the announcement says the move retires per-title event teams, which bears on this role. CO because it scores company-level thinking |

### B. Values/Behavioral (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time when what was on the calendar and what was good for players pulled apart." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold for Players Before Plans. Pick a time a date or a drop changed, or should have changed, because of what players were experiencing. It needs a named piece of evidence about players, something you gave up, and an intact relationship with whoever wanted the date kept. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I ran the weekly content-drop calendar for our main title for the last two years," or say how you would handle it | The first published value, from the fetched values page; F1 is the nearest evidence. VAL because it scores behaviour against a named value |
| B2 | "Tell me about a time you decided what to say publicly about something that was not finished." | VAL | [grounded] | Selection scaffold for Ship the Patch Not the Promise. Pick a time you chose what to tell players or colleagues about work still in progress. It needs what you knew, what you held back or worded carefully, and what happened to the promise. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The second published value; no quoted sentence carries a story for it, so the scaffold is the honest form. VAL |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote the release checklist, and QA still uses it; tell those two beats in your own words. Answer slot: the third value speaks of the checklist being better after every release, so expect a probe on whether yours changed after releases. If you changed it, say what changed and why, in your own words; if it stayed as written, or the changes were not yours, say so plainly and stay with the checklist | The third published value names the checklist, and F4 is the evidence closest to it. VAL |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold with one vehicle your material names: you presented the monthly retention numbers to the studio head. Answer slot: if any month's numbers were unwelcome, say what they showed and what you said, in your own words; if none were, say so plainly, then give the nearest thing your material carries or how you would handle it. Choose a story where the hard truth actually landed; if none did, say so rather than supplying an ending | A standard values-round prompt for a role that reports KPIs; F3 is the only evidence near it. VAL |

### C. Skeptic (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "We move to a season pass in February, and I do not see in-app purchases anywhere in your background. What would you not be able to do on day one?" | EXP | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack. Level one: open with the plain acknowledgment, "I haven't worked on a game with in-app purchases," and stop; do not fill the silence. Level two ("so what would you not be able to do?"): say specifically what you would have to learn, and hold only what the quote carries, "I ran the weekly content-drop calendar for our main title for the last two years." The limit, named now: your material shows a content-drop calendar and presented retention numbers, and shows nothing about how a season pass or purchases work, so the pack gives you no words for that. Level three ("how would you learn it?"): a plan said as a plan, what you would ask for first and from whom, in your own words, never as a past. Concede explicitly; do not argue the gap is small | Most likely objection: F9 is a stated gap, and the season-pass announcement makes it relevant to the role's titles. EXP because it tests whether the candidate describes the background at its real scope; CO in flavour |
| C2 | "This role coordinates design, art, engineering and community on every update, and you have not led a team. How does that go?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | Acknowledge plainly: "I haven't led a team." The JD's own verb for the role is coordinate; use it and do not dispute the point. Answer slot: the JD names four teams, so expect a probe on which you worked with on a drop. Say which and what you did with them, in your own words; if some of the four were not part of your drops, or the work was not yours, say so plainly and stay with the calendar you ran. Hold through a second follow-up by returning to the quote, not adding to it | The JD's coordination line (F2) meets the stated negative in F9; the second most predictable objection. JD because it scores the listed responsibility |
| C3 | "Was your puzzle title run as a live service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Two beats, each a sentence you wrote: the four years as an associate producer at a puzzle-game studio, and the weekly content-drop calendar for your main title over the last two years. Answer slot: if the title ran as a live service, say how, in your own words; if it did not, or only in part, say so plainly and stay with the calendar you ran | The JD requires 3+ years producing live-service games or apps (F5), and the material does not say whether the title was one. JD |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented in the quote's words: "I presented the monthly retention numbers to the studio head." Four answer slots, each in your own words: how the numbers were counted, what they were sensitive to, the assumption behind them you would defend least, and which part was yours. "I don't know how it was counted" is an honest branch; say it plainly rather than guess. Name the weakest assumption before the interviewer does, if you know it. The pack gives no method, definition or baseline | The one metric-bearing line in your material, and probers go to it first (F7). EXP because it tests attribution and how well you know your own number |
| D2 | "After an event ends, which retention number do you look at first, and what would make you doubt it?" | JD | [grounded] | Choose one measure you can define in a sentence, including the window it covers. Say what other than the event could move it, and what you would check before believing a change. Concede what one number cannot tell you. It asks for no past | The JD's "comfortable with player-retention metrics" needs a rehearsed answer that does not lean on a figure (F7). JD |
| D3 | "Tell me about the release checklist you wrote and how QA uses it." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Two beats the quote states: you wrote it, and QA still uses it; tell them in your own words. Answer slot: the JD's word is manage, so expect a probe on running it release by release. If you ran it with QA on releases, say how; if QA ran it, or it was applied without you, say so plainly and stay with the checklist. Describe what is on it only if you can say why each item is there | F4 is the strongest evidence in your material, and Tobias's QA background makes this the line he is likeliest to test. JD for the requirement, EXP in delivery |

### E. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats, each a sentence you wrote: the four years as an associate producer at a puzzle-game studio; the weekly content-drop calendar for your main title over the last two years; the release checklist QA still uses; the monthly retention numbers presented to the studio head. "I" for what you did. Answer slot: why live operations and why Saltmarsh now is not in your material, so give your actual reason in your own words; if you do not have a settled one, say what draws you and stop | Nearly every session opens with it, and a casual register is still scored. EXP |
| E2 | "What does running an events calendar for two titles at once look like to you?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | A role question with no past in it: say what you would need on one page (what is live, what is next, what conflicts), who you would check with before locking a week, and how you would decide when two titles want the same slot, all as a plan. Answer slot: if you set dates or content on the calendar you ran, say which and how you decided, in your own words; if others set them, say so plainly and describe what running it involved | Covers the JD's calendar requirements (F1 and F6) in the casual register this persona uses. JD |

### G. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a producer who has run live events with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Hold, then concede. Pause and restate the question. Concede the plain fact: "I haven't worked on a game with in-app purchases." Hold only what the quote carries, "I ran the weekly content-drop calendar for our main title for the last two years," and do not claim to be better than a producer you cannot compare yourself to. Hold through two follow-ups by returning to the calendar, not by adding to it; concede specifically what you would have to learn | The pressure form of C1 (F9). JD because it scores fit for the listed job under a time box |
| G2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold at the quote's scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours to set and which were set by others; if you cannot separate them cleanly, say so rather than rounding up. Hold through two follow-ups by returning to the calendar; concede any part that was someone else's by naming the part, not the person | The attribution probe that follows any "I ran" line (F1, F6). EXP |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | E2, A2, A5, G2 |
| "coordinate design, art, engineering and community teams on each update" | C2, A1 |
| "own the post-event review and the KPIs it reports" | A4, D1, D2 |
| "manage the release checklist with QA" | D3, B3 |
| "3+ years producing live-service games or apps" | C3, E1 |
| "experience running a content calendar" | E2, G2, E1 |
| "comfortable with player-retention metrics" | D1, D2 |
| "clear written communication" | A3 |
| Published values (three) | B1, B2, B3 |

## Values cheat sheet

Detected because the careers page names a values conversation. Value names and definitions are from the fetched values page.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | The schedule gives way to what players are experiencing | Selection scaffold (B1). Nearest evidence, F1: "I ran the weekly content-drop calendar for our main title for the last two years." If no time comes to mind, say so plainly |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold (B2); no quoted sentence carries a story, so if no time comes to mind, say so plainly and say how you would handle it |
| Leave the Build Greener | Each release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Beats: wrote it, and QA still uses it; B3 holds the slot on whether it changed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "I read that you were a QA lead before this. What from that carried over into how you run live operations?" | Ties to his own path and invites the conversation about release discipline rather than an interrogation about yours |
| 2 | "With the shared events calendar from February, how will this producer role sit alongside the single live-ops group?" | Shows you read the announcement and asks what the role becomes, which you cannot learn from the JD |
| 3 | "Which two titles would this role cover, and where is each in its season?" | The JD does not name them, and your first month depends on the answer |
| 4 | "What does a good post-event review look like here, and which numbers has the team found most useful?" | Goes straight to a headline responsibility and signals you care about how the numbers are counted |
| 5 | "How does the release checklist run today with QA, and what has changed in it recently?" | Connects to the third published value and to Tobias's QA background |
| 6 | "What would a strong first event cycle look like for someone in this role?" | Asks for the standard you will be measured against, not what he is looking for |

## Prohibited claims

Not coached in any cell of this pack, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or led design, art, engineering or community | A negative you stated (F9) | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or ran purchase-linked events | A negative you stated (F9) | The plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a plan said as a plan |
| Owned the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope; your material says one main title's content-drop calendar. E2's slot stays inside what you set on that calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope; your material says you presented the monthly numbers. D1's slots ask only how those were counted |
| Managed the release checklist across releases with QA | Inflated form of F4 | F4's quote at its own scope; your material says you wrote it and that QA still uses it. D3's slot stays inside the checklist |

## Sources

Provided documents: the JD and the background you pasted in your message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Queries and fetches:

- Search "Saltmarsh Games values" returned https://saltmarshgames.com/values; fetched.
- Search "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing; fetched.
- Search "Saltmarsh Games strategy news mobile games" returned https://saltmarshgames.com/news/project-larkspur; read as a search snippet only, page not fetched.
- Search "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise; read as a search snippet only, page not fetched.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | yes | Values cheat sheet and B1 to B3, three values by name |
| 2. Interview process | yes | Established the loop: persona weights, the tabletop in A, the values detection |
| 3. Strategy and recent news | yes | A5, C1's relevance and reverse question 2, from the snippet alone |
| 4. Interviewer name | yes | The interviewer read, A3 and reverse question 1, from the snippet alone |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is the hiring manager, and anything the recruiter said about the tabletop → persona weights confirmed or reweighted, and A tuned to the scenario they name
- How many hours you have before Friday → a prep triage schedule ordered by section
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the full Project Larkspur page and Tobias's talk read instead of summarized, a grounding brief section, and recent organisation context; offered once
- The release checklist itself, the content-drop calendar, or a monthly retention deck → the inspectable artifacts that would raise F4, F1 and F6, and F7 from `medium`
- Your answers to the slots (what the calendar held, which teams you worked with, how the retention numbers were counted, whether the title ran as a live service) → F1 to F5 and F8 move from `discovery` or `transferability` to quoted evidence, and the banks regenerate on them
- A `tuesday-dossier.md` from an earlier evidence check, if you have one → verified evidence and a sourced top objection in place of the one inferred here; optional
