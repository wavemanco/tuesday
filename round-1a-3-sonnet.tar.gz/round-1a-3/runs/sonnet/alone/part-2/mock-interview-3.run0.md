I'll read the skill's reference files before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-3-denied-58b323c5/stripe_product-operations-manager_interview_pack.md`. The web searches I tried were all refused, so nothing in it comes from Stripe's own materials, and every row is generic. I had no JD, CV or interviewer, so questions about your past are scaffolds for you to fill in your own words. I weighted the interviewer styles evenly because I don't know who you're meeting.

Say the word and I'll play the Skeptic on B1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is your final round with: a future manager, a peer, a skip-level, or a panel? Has the recruiter given you any focus areas or a deliverable to prepare? The answer reweights every bank.
Can you paste the job description and your CV? I'll keep going without them, but they turn the generic rows into your own evidence.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer: not named. Relationship to you: not stated, so the weights below are blended.

What this pack is built on: your message gave the company, the role and the round, and nothing else. Web research was attempted and not permitted (see Sources), so nothing here is drawn from Stripe's own materials. Every row is `[generic]`, and every question about your past is a selection scaffold, because there is no CV or JD to map it to.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values, not generic virtue |
| EXP | Whether claims about your experience survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Where it asks about your past, it asks you to choose the instance and use your own words. Nothing in it says what you did.

## Fit snapshot

Worksheet variant: no CV and no JD were supplied, so each evidence cell is empty and each requirement is role-family prose, not a quote. Fill the evidence column yourself before the interview, from your own record.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or programs across product, engineering and go-to-market teams (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence names the program, the teams on each side, and what was yours to decide, kept at the size you can defend. Selection scaffold: pick a time you coordinated work across teams that did not report to you. It needs the teams named, the part that was yours, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Define and track operating metrics for product health (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: how it was counted, what it is sensitive to, and which part of its movement was you. Selection scaffold: pick one figure you could defend under a second question. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Build or improve processes, rhythms and tooling for how teams plan and ship (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a change you made to how a team worked, with a way you judged whether it helped. Selection scaffold: pick a process you changed, not one you merely followed. It needs what was wrong, what you changed, and how you could tell afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Bring customer and field feedback into product decisions (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a case where input from customers or the field changed what a team did. Selection scaffold: pick one decision where that input mattered, with what you heard and who acted on it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Communicate clearly in writing and to senior leaders (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a document or update you wrote that others used, and a moment you gave leaders a hard message. Selection scaffold: pick one example of each, with the audience named. If no such example comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Influence people you do not manage (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer or senior person where you kept both your position and the relationship. Selection scaffold: pick one with a named stake and a named outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Get fluent quickly in the company's product area (role-family, no JD supplied) | none given | none | [generic] | discovery | Strong evidence is a time you ramped into an unfamiliar domain, and what you did in the first weeks. Selection scaffold: pick one such ramp, and say what you learned first and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

No loop source was available, so the loop is not established. The fallback archetype is Generic: flat weights, stated plainly. Weights rest on that pattern and not on Stripe's documented process. If your final is several back-to-back sessions, the schedule would let me weight each one separately.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the role: plan this, diagnose that | Medium-high. A final round for a manager role often includes a hiring-manager conversation, and the relationship priors give that relationship Case and Skeptic. Your relationship is unknown, so this is a prior, not a finding | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| B. Skeptic | Quiet probing of gaps, motivation, why here and why now | Medium-high. Same hiring-manager prior. With no CV the pack cannot find your biggest gap, so it names the most predictable question instead (B1) | Rehearse B1 until it is boring. Bridge only from what you can truthfully say you did, plus a ramp plan |
| C. Peer Evaluator | Seam-splitting with adjacent teams, credit, disagreement | Medium. Product operations sits between teams, so a peer from product or engineering is plausible. This is the pack's reasoning from the role's shape, and it is not a documented fact | Reciprocity framing: what you bring their team. Propose seam principles and do not pretend to know the seam |
| D. Values/Behavioral | Scenario probes, STAR-shaped stories, often from outside the function | Medium. Not established: no loop source names a values round, so none is assumed. Behavioral questions can still appear in any round | Pick stories where the hard truth landed. If your material shows none, say so and do not supply an ending |
| E. Pressure | Interrupts, time-boxes, questions motives | Medium. The skip-level and executive row of the relationship priors tilts here. Unknown whether one is in your loop | Pause, restate the question, hold a challenged position through two follow-ups, concede only what is true |
| F. Data-Driven Prober | Inputs, denominators, assumptions, two levels deep | Medium. The peer row of the priors pairs it with Peer, and the role is metrics-heavy. Same caveat as C | Know what you can and cannot say about how each figure was counted. Say plainly when you do not know |
| G. Conversational | Friendly, unstructured, still scored | Medium. Any round can open this way | Have a 90-second arc ready. Treat casual questions about the company's products as scored |

## Question banks

Highest-ROI prep in this pack: B1. It will be asked in some form whatever the round, and the pack has no CV to find a sharper objection with. Give it the most follow-up rehearsal.

Provenance is `[generic]` throughout: no question rests on a quote from you, and none asserts anything about Stripe.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for rolling out a new launch-readiness process across several product teams. What do you need to know first?" | CASE | [generic] | Ask two or three clarifying questions before structuring: what problem the process solves, who owns launches today, what has failed before. Then objective, which teams to start with, approach, how you would measure it, risks. Challenge one premise respectfully. This asks about no past, so the guidance makes no claim about yours | Tests structure on a problem close to the role's work, which F1 and F3 name. CASE because it is a live problem |
| A2 | "A key product-health metric dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Say your first hypothesis aloud: check the definition and instrumentation before assuming a real change. Then segment, line up recent changes, and say what you would look at first and why. State what would change your mind | Direct stem for the Case persona, and it tests F2 without needing a figure from your history |
| A3 | "Two product teams disagree on whether a feature is ready to ship, and the launch date is fixed. How do you run the next 48 hours?" | CASE | [generic] | Clarify who decides, what readiness means to each team, and what is reversible. Then who you talk to first, how you separate facts from positions, and what you escalate and when. Make no claim to have handled this before | Pairs F1 and F6: coordination plus influence without authority. CASE because it is a decision under time pressure |
| A4 | "Why this company, why this role, and where do you think the company is headed?" | CO | [generic] | This answer needs current strategy from real sources, and this pack could not fetch any. Use only what you have read yourself, and say where it came from. If you have read nothing recent, say so plainly, then say what you would want to learn first. Do not recite what you half remember | The coverage rule wants a CO question grounded in current strategy. Research was not permitted, so this one stays generic until the upgrade menu's search line is acted on |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The deepest rehearsal here. Before the interview, pick from F1 to F7 the row where you would have least to point to, using your own honest judgment. Say it in one plain sentence of your own, with no cushioning. Then give a ramp as a plan, never as a past: what you would learn first, from whom, by when. Hold through two follow-ups. If asked how weak, say what you do and do not know. If asked why hire you anyway, return to what your material does carry, in your own words. Do not name a weakness you do not have in order to look candid | Most predictable question for any candidate, and the F-row gaps are the material for it. JD because it scores the listed job, gaps included |
| B2 | "Why leave your current role, why here, and why now?" | EXP | [generic] | Give your actual reasons in your own words, and keep them consistent with what you told the recruiter. Cover leaving, this role, and timing in that order. If one of the three has no real answer, say so plainly instead of constructing one | The Skeptic persona's motivation stem. EXP because it tests whether your story survives cross-examination |
| B3 | "What would make you fail in this role in the first six months?" | JD | [generic] | Name one real risk as you see it, then your mitigation as a plan. Do not claim to have already solved it. Keep it to a risk the role actually carries, so it does not read as a disguised strength | A softer cousin of B1 that catches candidates who prepared only one gap answer. JD because it scores fit with the job |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | CASE | [generic] | Propose seam principles, not a map of a seam you cannot see from outside: who decides, who is informed, how disagreement is escalated. Ask what the team currently owns. Say what you would bring their team, not only what you need | The peer stem, tied to F6. CASE because it is a live collaboration problem |
| C2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Use we for context and I for your own contribution. Pick one real example if you have one. If none comes to mind, say so plainly, then give how you would handle it | Credit-sharing is a standard peer probe, and attribution honesty is what EXP scores |
| C3 | "Tell me about a time you disagreed with a peer about priorities. What happened?" | EXP | [generic] | Pick one with a named stake, what you said, and how it ended, told in your own words. It should show spine and tact together. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Disagreement with equals is what the Peer persona scores, and F6 is the row it draws on |

### D. Values/Behavioral

No published values were in hand, so there is no values-to-story map in this pack, and these two questions use the persona stems.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time where the message landed, with the audience named, what you said, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not supply an ending your material does not show | Standard values stem, and F5 is the row it draws on. VAL because it asks for behavior over virtue |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick one decision with the customer's situation, the metric you set aside, and the result. Use I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values stem, tied to F4 and F2. VAL because it tests judgment between two goods |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then answer from your own record in your own words without comparing yourself to people you do not know. Hold your position through two follow-ups, then concede only what is true, such as what an insider knows that you do not yet | The Pressure persona's stem. Hold-then-concede is the scored structure |
| E2 | "Think of a result you are proud of. How much of it was actually you?" | EXP | [generic] | Be precise: what was yours, what was the team's, what was luck or timing. Concede the parts that were not yours in one clean sentence and do not fold on the part that was. If no result comes to mind that you can attribute precisely, say so plainly and give the nearest thing your material does carry | Attribution honesty under pressure, which is what EXP exists to rehearse |
| E3 | "Devil's advocate: why is product operations not just overhead on the teams that actually build?" | JD | [generic] | Hold the position that the function earns its place, and say what you would measure to show it. Concede one real way it can become overhead and how you would guard against it. Make no claim to have run such a function | Tests composure on a challenge to the role itself. F3 is the row it draws on |

### F. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Pick one figure you would put on your CV. Walk me through how it was counted." | EXP | [generic] | Four things, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Do not explain a method you cannot repeat under a second question. If no figure comes to mind that you can defend, say so and use another example | The defend-the-number rehearsal, ready before your CV exists in this conversation. F2 is the row it draws on |
| F2 | "How would you decide which metrics a product operations function should track, and which would you refuse to track?" | JD | [generic] | Start from the decisions the metrics would inform, then how you would test whether a metric is trustworthy. Name one kind of metric you would decline and why. A general approach is enough here, with no claim about past practice | F2's requirement as a reasoning question |
| F3 | "If you introduced a new launch process tomorrow, how would you know in three months whether it worked?" | CASE | [generic] | Name what you would measure before the change, what would count as success, what else could explain a change, and what you would do if the signal was ambiguous. Say which assumption you would trust least | Tests F3 and F2 together without a premise about your past, so it is a hypothetical |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc from your own CV in your own words: where you started, the through-line, why this role. Rehearse it aloud until it is steady. If no through-line comes to mind, say so plainly, then give the nearest thing your material does carry | The biography question opens most conversations, and the counter-strategy for this persona is a pre-scripted arc. Your CV is not here yet, so the arc is yours to build |
| G2 | "What are you playing with these days in how teams plan and ship work?" | JD | [generic] | Name only what you actually do or have tried, and what you noticed. If nothing, say what you have been curious about and why, without naming tools you do not use | A casual question about a topic the role touches, which still gets scored |
| G3 | "What have you tried of the company's own products, and what did you notice?" | CO | [generic] | Use only what you have tried yourself. If you have tried none, say so plainly and say what you would try this week and why | Casual homework check. Generic until research can supply anything current |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 Coordinate across teams | A1, A3, C1 |
| F2 Operating metrics | A2, F1, F2, F3 |
| F3 Processes and tooling | A1, F3, E3 |
| F4 Customer and field feedback | D2 |
| F5 Written and senior communication | D1 (spoken upward communication). Written work: none, and why: no deliverable was declared and no JD supplied |
| F6 Influence without authority | A3, C1, C2, C3 |
| F7 Fluency in the product area | A4, G3, B1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a successful first 90 days look like here, and how would you and the team know?" | Shows you think in outcomes, and the answer tells you what the role is really measured on |
| 2 | "Where does product operations sit relative to product management and engineering, and where does the boundary get contested?" | Signals you have thought about seams, and surfaces the turf issues you would inherit |
| 3 | "What is one rhythm or process in how the team ships that you would change if you could?" | Invites a candid answer and shows where you could add value |
| 4 | "What is the hardest part of working here that someone outside would not see?" | A candid-diligence question that rapport-style interviewers tend to value |
| 5 | "How do leaders judge whether this function is working?" | Ties to F2 and gives you the scoring sheet for the job itself |
| 6 | "If you are a peer on the team: what could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer interviewer. Skip it otherwise |

No interviewer profile exists, so none of these is tied to an interviewer's path.

## Prohibited claims

No entries. Your message gives no sentence about your past to stretch and states no negative about yourself, so there is nothing to list. Every question about your past in this pack is a selection scaffold ending in its honest branch, and none of them states what you did. When you add a CV, this section is rebuilt against it.

## Sources

Provided documents: your message (company, role, round). No JD, CV, dossier or links.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Queries sent, all refused (no permission to search was granted, and nothing came back):

- Stripe operating principles values: refused
- Stripe interview process product operations manager final round: refused
- Stripe strategy news 2026 annual letter stablecoins agentic commerce: refused
- Stripe "Product Operations" Manager job description responsibilities requirements: refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | unavailable | Would have supplied the values by name for a cheat sheet. Without it, section 10 is absent and the Values bank uses persona stems only |
| 2. Interview process, role family | unavailable | Would have established the loop and moved persona weights. Without it the fallback is the Generic archetype with flat weights |
| 3. Strategy and recent news | unavailable | Would have grounded A4 and G3 and allowed a grounding brief |
| 4. Interviewer name | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative JD | unavailable | Would have turned F1 to F7 into `[inferred]` quoted requirements. Without it they are `[generic]` prose |

## Upgrade menu

- Permission to search the web → values by name, the documented loop, and current strategy; A4 and G3 become `[grounded]`, and persona weights follow the documented rounds. A deeper pass is also available: up to 6 more searches and 2 more fetches, several more minutes. Say if you want it
- The job description text → F1 to F7 become quoted `[grounded]` requirements, JD-tagged questions are rebuilt against its list, and any term it states (location, schedule, right to work) is surfaced as a row
- Your CV → the evidence column is filled, selection scaffolds become story-mapped answers, and each headline figure gets a defend-the-number question
- Who you are meeting and how they relate to you → persona weights are recomputed. If your final is several sessions, send the schedule and I will build a mini-pack for each
- The interviewer's name → an interviewer read and a reverse question tied to their path
- The recruiter's prep email → coverage of any stated focus area, and a build section for any declared deliverable such as a presentation or take-home
- How much prep time you have → a prioritized prep schedule
- A tuesday-dossier.md from earlier work → graded evidence and the underwriter's named objection in place of the inferred one
