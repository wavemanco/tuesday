I'll read the skill's reference files before writing anything.
I've read the skill's rules. Next I'm writing the full three-round prep pack, then checking one date detail in your recruiter's email.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-8-canned-696fa205/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a three-round loop, since your recruiter's email gives all three rounds and who runs each. It has 30 questions (A1–A9 for the recruiter, B1–B10 for the Head of Member Services, C1–C11 for the panel), each with answer guidance drawn only from what you told me. It also has a values cheat sheet for the panel round and reverse questions for each round.

- **Biggest prep item:** B1, the contact-centre objection ("you've never worked in one"). It will come up in rounds 1 and 2, and the pack gives it a three-level rehearsal.
- **Second priority:** the four values questions (C1–C4). Your material doesn't yet carry a story for any of the four values, so those rows are scaffolds until you give me real examples.
- **Research:** I ran no searches. Your pasted values, the JD, the recruiter's email and your strategy summary already covered every target. The pack works from your summary of the July brief, not the brief itself.
- **Date check:** 29 November 2026 is a Sunday. It's worth confirming that date with the recruiter.

Say the word and I'll play the Head of Member Services on B1, with follow-ups that react to what you actually say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 29 November (recruiter 30 min; Head of Member Services, your future manager, 45 min, mostly behavioural; panel of two branch managers, 60 min, including a 20-minute complaint-escalation case, also the values round). Interviewer names and roles beyond these are not yet assigned, so there is no interviewer read.

## How to use this pack

Personas are how a question is asked; types are what it scores. Guidance is scaffolding to say in your own words, not a script. Answer slots (instructions ending without a question mark) are for the interview: you do not reply to them here.

| Type | Meaning |
|---|---|
| VAL | Past behaviour against the company's published values |
| EXP | Whether your own experience survives scrutiny; what was actually you |
| JD | A stated responsibility or requirement of the role |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role |

The highest-ROI prep in this pack is B1, the contact-centre objection. It is the one gap you stated yourself, the JD puts the contact centre in the first line of the role, and it will arrive in round 1 (A7) and round 2 (B1) in some form. Rehearse it until it is boring. The second priority is the four values stories (C1 to C4), because the panel scores against them and your material does not yet carry a story for any of them.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Say it at its own scope: "I've spent six years in retail banking, the last three as a branch supervisor." Leave the JD's phrase out of your own mouth; your sentence says retail banking and branch supervision. A years-of-experience line is not a gate. Nothing inspected sits behind it, so expect a probe |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your words: "I handled the branch's formal complaints log." The quote says a formal log; it does not show which rules governed those complaints. Answer slot: the JD's regulated-complaints line makes a probe on the rules or deadlines your complaints ran under likely. If specific ones applied, say which and what part of handling them was yours, in your own words; if you are unsure, or none applied, or it was not yours, say so plainly and stay with the log |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your words stay at their scope: "I handled the branch's formal complaints log." The material says one branch's log, not a process across branches. Answer slot: if any step in handling that log was yours to decide, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and describe how you handled the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Your words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim of contact-centre exposure |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your words: "I built the monthly complaints spreadsheet our regional manager uses." The quote does not show what the spreadsheet counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours showed. If it showed either, say how each was counted; if it showed something else, say what; if it showed neither, say so plainly |
| F6 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your words at their scope: "I trained new tellers on our escalation script." Tellers and a script, not supervisors. Answer slot: if any of that training reached supervisors, say how; if it was tellers only, say so plainly and stay with the tellers |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | The material is silent. Answer slot: if you have worked with a digital or product team on anything members used for themselves, say what it was and what part was yours; if not, say so plainly and say what you would want to learn first |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you stated. Your words: "I've never presented to anyone above regional level." Then how you would prepare to present, said as a plan and never as a past. Your message does not say what presenting at regional level involved, so no claim about it is made here |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Say "spreadsheet", your own word. If asked which tool, name the tool you actually used; say Excel only if it was Excel |

No row is a hard gate: none of the JD's requirements is a term such as a licence, location, schedule or pay.

## Grounding brief (from the strategy summary you supplied)

Facts below come from your summary of the July 2026 brief. The brief itself was not read, only your account of it.

| Item | What the brief says | Provenance | What it means for this role |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | The JD's self-service line has a number behind it; complaints raised or handled through digital channels are where F7 will be tested [inferred] |
| Branch consolidation | Consolidate eight branches into five hubs over 2027 | [grounded] | Branch managers on your round 3 panel work inside this change; Neighbours, Not Numbers will be tested against it [inferred] |
| New product | Small-business lending launches in Q1 2027 | [grounded] | A new product line brings a new kind of member and, in time, new kinds of complaint [inferred] |
| Competition | Main competitive pressure is app-only banks | [grounded] | Branch presence and human ownership of a complaint are the contrast Ashgrove can draw; a good CO answer names that contrast without disparaging anyone [inferred] |

## Prohibited claims (shared)

Built before the banks. Nothing in any bank, slot or hold below asserts these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says one branch's log, not a process across branches |
| Handled regulated complaints | The JD's wording laid over F2's quote | F2's quote at its own scope. Your material says a formal log, not which rules governed it |
| Reported complaint volumes and resolution times each month | The JD's wording laid over F5's quote | F5's quote at its own scope: the monthly complaints spreadsheet. The limit is the pack's observation: what it counted is not in your material |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: new tellers and the escalation script |
| Built Excel reports | The JD's tool name laid over F9's word "spreadsheet" | F9's quote: the monthly complaints spreadsheet |
| Has contact-centre experience | Negative you stated, F4 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | A1, B10 |
| Experience handling regulated complaints | A9, B9 |
| Own the complaints process end to end across branches and the contact centre | A7, B1, C5, C11 |
| Report monthly on complaint volumes and resolution times | B2, C7 |
| Coach branch supervisors on escalations | B3, B4, C6, C8 |
| Work with digital teams on self-service journeys | B7, C10 |
| Confident presenting to senior leaders | B6, B10 |
| Comfortable with Excel reporting | B2, C7 |
| Headline metric to defend | none: your material gives no figure, so there is no defend-the-number question |
| Recruiter logistics: pay, notice, location, reason for leaving | A3, A4, A5, A6 |
| The four published values | C1, C2, C3, C4 |

# Round 1: Recruiter, 30 minutes

## Persona table, round 1

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly biography, motivation and "what do you know about us" | High: a recruiter screen's prior, and the email gives it 30 minutes with no stated focus areas | A 90-second arc built only from your own sentences; treat casual questions as scored |
| Skeptic (light) | Knock-out checks on the JD's regulated-complaints and contact-centre lines | Medium: F2 is thin and F4 is a gap you stated, both on the JD's first lines | Say the stated negative plainly, then the plan; stay at the scope of your quotes |

## Bank A

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in your own words using only what the quotes state: six years in retail banking, the last three as a branch supervisor; the formal complaints log you handled; the monthly spreadsheet you built for your regional manager. Close on why this role. Answer slot: say why you want a complaints and member experience role in your own reason; if there is no single reason, say so plainly and give the strongest true one | F1, F2 and F5 are the best-evidenced rows and make the arc. EXP because it tests whether the story matches the CV |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] "Members First, Always — we decide from the member's side of the counter" — the values page you copied | Pick the one published value that is true for you and say why in your own reason. Then link one item from the brief you were sent (the move to digital, or eight branches into five hubs) to what a complaints lead does. Say nothing about Ashgrove you cannot trace to the pages you have | The recruiter checks motivation is specific. CO because it tests homework; the values page and brief are the raising sources |
| A3 | "What are you looking for salary-wise?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first. The JD you pasted states no pay. If asked about current pay, you may decline politely and return to what you want for this role. Give no figure here that you have not decided yourself | A recruiter logs pay early, and the only safe answer is your own. JD because it is the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words. If you do not know it, say so and say when you will find out | A knock-out logistics check. JD because it concerns the listed job's start |
| A5 | "The role spans branches and the contact centre. Is there anything about location or getting between sites that we should know?" | JD | [grounded] "across branches and the contact centre" — JD | Logistics slot: state your own location position and any constraint, or say there is none. Add nothing you have not decided | The JD's wording points to more than one site, and recruiters check this early. JD because it is the listed job's terms |
| A6 | "What's prompting you to look at a move now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Logistics slot: give your real reason in your own words, short and forward-looking. If several reasons are true, give the one you would repeat to the Head of Member Services too, so the story stays consistent across rounds | The reason for leaving is checked for consistency across all three rounds. EXP because it tests the story matches your history |
| A7 | "This role covers the contact centre as well as branches. You've told us you haven't worked in one, so how do you see that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | First airing of the B1 objection, short. Hold: what the quote carries, "I handled the branch's formal complaints log." Concede plainly: "I've never worked in a contact centre." Then one sentence of plan in your own words: what you would want to learn first. Do not add contact-centre exposure you do not have | F4 is the gap you stated, so the objection arrives in some form. JD because it scores the stated requirement; a light Skeptic delivers it |
| A8 | "What do you know about where we're heading?" | CO | [grounded] "move 40% of member service to digital channels by 2028"; "consolidate eight branches into five hubs over 2027" — the brief summary you sent | Name one or two items from the brief and say what each means for how complaints are handled. Bring one consensus item to prove you read it and one view of your own. Do not recite all four | Anyone can read the brief the recruiter sent; a view of your own is what separates you. CO because it tests homework at the company's altitude |
| A9 | "The role asks for experience handling regulated complaints. Tell me about yours." | JD | [grounded] "I handled the branch's formal complaints log" | Story at the quote's scope: "I handled the branch's formal complaints log." Answer slot: if specific rules or deadlines governed those complaints, say which and what was yours, in your own words; if you are unsure, or none applied, or it was not yours, say so plainly and stay with the log | F2 is the row where the recruiter's knock-out check lands. JD because it scores the first listed requirement |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "How does the complaints process run today across branches and the contact centre, and who holds it?" | Shows you read "end to end" as a real scope; the answer also tells you what B1 will really probe |
| R1.2 | "Is anything shared in advance for the 20-minute case, such as a format or a time budget?" | Practical prep signal; the recruiter can answer in one email |
| R1.3 | "What would make a candidate stand out to Ashgrove at this stage?" | Invites the recruiter's own words on the scoring, which you cannot research |

# Round 2: Head of Member Services, 45 minutes (your future manager, mostly behavioural)

## Persona table, round 2

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes F4 and F8, the two gaps you stated | High: a hiring-manager prior, and a manager prices the day-one risk first | Hold-then-concede on B1 and B6; calibrated candor over bluffing |
| Values and Behavioral | "Tell me about a time" scenarios | High: the recruiter's email says the round is mostly behavioural | Stories from your own sentences; where none exists, say so |
| Data-Driven Prober | Reads your monthly spreadsheet line by line | Medium: reporting is in the JD and F5 is your only artifact | Know what it counted and say plainly what you do not know |
| Case and Strategist | A live problem on complaints, coaching or digital | Medium: your manager's agenda, and the brief gives them material | Clarify, structure, think aloud |

## Bank B

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd own complaints in the contact centre, and you've never worked in one. Why should I believe you can?" | EXP | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | The deepest rehearsal in the pack, three levels. Level 1: hold what the quotes carry, "I handled the branch's formal complaints log," and "I trained new tellers on our escalation script"; concede the limit in one sentence, "I've never worked in a contact centre." Level 2, "What would you do in your first month?": say your plan as a plan, not a past: what you would learn first, whom you would listen to, how you would find out where complaints enter and leave. Level 3, "Advisers will see you as an outsider. Then what?": hold, do not argue; say what you would ask them to teach you. Never claim contact-centre exposure | F4 is the single most predictable objection and your manager owns the contact centre. EXP because it tests honesty about what you have done |
| B2 | "Walk me through the monthly complaints spreadsheet you built. What did it show?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Describe it at its own scope: a monthly spreadsheet you built for your regional manager. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours counted. If it showed either, say how each was counted and the assumption behind it you would defend least; if it showed something else, say what; if you do not know how a figure was counted, say so plainly. If asked which tool, name the tool you used | F5 and F9 meet here. EXP because a prober tests whether you can explain your own artifact |
| B3 | "Tell me about a time a complaint went beyond the branch and you were involved." | VAL | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script" | Open prompt on escalation (the JD's theme). Choose a real instance; the beats your quotes support are only the log and the escalation script. Answer slot: if you were involved in one, say what happened and what was yours, in your own words; if no such time comes to mind, say so plainly and describe how you handled the log or how the script was used | F2 and F6 are the closest evidence to escalations. VAL because it asks for a chosen past instance of behaviour |
| B4 | "A branch supervisor keeps escalating complaints they could resolve themselves. How do you coach them?" | CASE | [grounded] "trained new tellers on our escalation script" | A live problem, so it asks about no past. Structure it: what you would ask first (what is stopping them), what you would agree with them, how you would check it worked, when you would leave it to them. One link to your experience, at its scope: "I trained new tellers on our escalation script." Answer slot: if any of that training reached supervisors, say how; if not, say so plainly | F6 is thin (tellers, not supervisors); a live problem rehearses the method honestly. CASE because it tests structure |
| B5 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem, and the role reports upwards on complaints. VAL because it scores past behaviour |
| B6 | "You haven't presented above regional level. This role does, regularly. Why should I be comfortable?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Hold-then-concede. Concede plainly: "I've never presented to anyone above regional level." Hold what is quoted: the monthly spreadsheet your regional manager uses. Then a plan for how you would prepare: lead with the finding, then the evidence behind it. Answer slot: if you presented anything at regional level, say what; if not, say so plainly | F8 is a stated gap and your manager will be the senior audience. JD because it scores the stated requirement |
| B7 | "Where would self-service help with complaints, and where would you keep a person in the loop?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" — the brief summary you sent | A live problem. Clarify the complaint types first, then segment (simple and low-risk against complex or vulnerable), then say where a person stays and how you would measure it. Link one line to Plain Words from the values page. Answer slot: if you have worked with a digital or product team, say what and what was yours; if not, say so plainly and say what you would want to learn first | F7 is silent and the brief puts digital at the centre. CASE with a CO frame because it tests structure in the company's vocabulary |
| B8 | "Eight branches become five hubs over 2027. What does that do to complaints?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" — the brief summary you sent | Say what you would watch, as hypotheses, not facts: where members' routes change, which complaint types might rise, what the monthly report should flag early. Do not state any effect as established. Name one thing you would want to ask before concluding | The brief is the only strategy source you hold. CO because it asks you to think at the company's altitude |
| B9 | "How do you make sure a complaint is handled within the rules, and what if a deadline is about to be missed?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer at the log's scope. Answer slot: if there were rules or deadlines on your complaints, say which and what you did when one was close, in your own words; if there were none, or you are not sure, or it was not yours, say so plainly and stay with the log. Do not name a regulation | F2 again, at a manager's depth. JD because it scores the regulated-complaints requirement |
| B10 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick one of the two gaps you stated, say it plainly in the quote's words, then give your plan. Pick the one you can speak to with a plan you believe. Do not offer a gap you have not stated as a way of sounding modest | The standard Skeptic stem; you have two stated gaps. JD because it scores honest self-assessment against the listed role |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "As more service moves digital and branches become hubs, which complaint types do you expect to grow, and what do you want this role to own first?" | Uses the brief's content as a prompt to your manager and shows you read it |
| R2.2 | "What would you want to see from me by the end of the first three months?" | Your manager's own success measure; gives you B1's plan a target |
| R2.3 | "How do you want complaints reported to you and to senior leaders, and how often?" | Turns F8 into a working question about format; answers shape how you prepare to present |
| R2.4 | "Which part of the contact centre side is hardest today?" | Lets your manager name the real problem; supports the plan you gave in B1 |

# Round 3: Panel of two branch managers, 60 minutes (values round, with a 20-minute case)

## Persona table, round 3

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values and Behavioral | One scored story per published value | High: the recruiter says the panel scores against the four values | Map a story per value where your sentences carry one; where none does, use the scaffold and its honest branch |
| Case and Strategist | The 20-minute complaint-escalation case | High: 20 of the 60 minutes are a case, by the recruiter's email | Clarify, structure, think aloud, challenge one premise respectfully |
| Peer Evaluator | Seam between a branch and the complaints lead | Medium: branch managers work next to the role you would hold | Reciprocity framing; propose seam principles, not claims about today's seam |
| Conversational | Friendly questions about why Ashgrove | Medium: a panel of two often opens warmly, and the questions are still scored | Pre-script the arc; never answer the reverse-question slot with "I think you've covered everything" |

## Values and principles cheat sheet

Ashgrove's values, copied this morning (20 November 2026) from ashgrovecu.org/about/values. Your material carries no story for any of them, so each row is a scaffold; the nearest quoted sentence is a fallback, not a mapped story.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold, used in C1: a decision where the member's position and a process pulled apart, you named the member's side, and what happened next is true. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (F2: "I handled the branch's formal complaints log"), or how you would handle it |
| Plain Words | If a member needs it explained twice, the writing was wrong | Selection scaffold, used in C2: a time something written or explained had to be said again, and what you changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (F6: "I trained new tellers on our escalation script"), or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold, used in C3: a time local circumstances changed how you applied a standard process. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (F1: "6 years in retail banking, the last 3 as a branch supervisor"), or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold, used in C4: a time you found a problem and kept hold of it to the end, including a handover that was clean. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (F2: "I handled the branch's formal complaints log"), or how you would handle it |

## Bank C

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt on Members First. Pick a real instance with a named stake and a decision that was yours; say what you did and what happened, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the log you handled, or how you would handle it | The first published value, and your sentences carry no story for it; see F2. VAL because it scores behaviour against a named value |
| C2 | "Tell me about a time something you wrote or explained needed explaining twice." | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt on Plain Words. Choose a real instance; say what was unclear, what you changed, and how you knew it worked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, training tellers on the escalation script, or how you would handle it. Do not say you wrote the script unless you did | Plain Words is the one value built on a test the interviewer can apply to your answer itself, so keep sentences short. See F6. VAL because it scores behaviour against a named value |
| C3 | "Tell me about a time local circumstances changed how you applied a standard process." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Open prompt on Neighbours, Not Numbers. Choose a real instance; say what the standard was, what the local circumstance was, what you did and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, your branch supervision, or how you would handle it | The value meets the brief's branch-consolidation plan, so expect it to be asked with a straight face; see F1. VAL because it scores behaviour against a named value |
| C4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt on Own the Fix. Choose a real instance; the key beat is the handover, if there was one, and who held it throughout. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the log you handled, or how you would handle it | The job's own title is ownership; see F2 and F3. VAL because it scores behaviour against a named value |
| C5 | "A member has complained three times about the same thing, across a branch and the contact centre, and nobody has taken it on. You're the lead: take us through it." | CASE | [generic] | The 20-minute case, likely shaped like this. Structure aloud: clarify (what the member asked for, what was promised, what the rules require), objective (resolve it and stop the repeat), approach (name one owner, contact the member, fix the cause), metrics (time to resolution, repeat rate), risks. Challenge one premise respectfully, for example whether the three contacts are one complaint. Use Own the Fix and Members First in your own words | The recruiter says the case is a complaint escalation, so a case of this shape is likely. CASE because it tests structure and reasoning |
| C6 | "The branch supervisor says the member is being unreasonable. What do you say?" | CASE | [generic] | A live follow-up. Hold both sides: the member's side of the counter and the supervisor's constraints. Say what you would ask, what you would not accept, and how you would keep the relationship with the supervisor intact | A natural pressure in a case between a branch and a complaints lead. CASE because it tests composure inside the case |
| C7 | "Which two numbers would you put in front of us each month to know the process is working?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Name two measures and say what each can hide; the JD's own pair is volumes and resolution times. Name the assumption you would defend least. Answer slot: if your own spreadsheet showed either, say how it was counted; if it showed neither, say so plainly and say what you would count first | F5 and F9; the metric move is rehearsed here. CASE because it asks for a measure you would choose |
| C8 | "Where is the seam between a branch handling a complaint and you owning the process, and what happens when we disagree?" | CASE | [generic] | Propose principles, not a claim about today's seam: one named owner at a time; a clean handover that carries the full history; a clear point at which the branch can still say no. Reciprocity: say what you would give the branch managers, such as visibility on their complaints. Say how you would disagree: the member's position first, then the facts | The peer stem; branch managers sit next to the role. CASE because it asks you to propose a seam |
| C9 | "Say a member in a town that loses its branch rings to complain. What do you do?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" — the brief summary you sent | A live problem. Listen first and name the member's concern in plain words; say what you can fix now and what you cannot; do not argue the strategy; say who owns the follow-up. Hold Neighbours, Not Numbers without criticising the plan | The brief makes this scenario concrete. CASE with a CO frame because it ties the strategy to a member |
| C10 | "Why Ashgrove rather than an app-only bank?" | CO | [grounded] "the main competitive pressure is app-only banks" — the brief summary you sent | One grounded fact from the brief, then your own reason in your own words. Do not disparage app-only banks; say what a person who owns a complaint offers that an app alone does not. Answer slot: if you have worked on a member-facing digital journey, say what; if not, say so plainly | The brief names the competitor, and F7 is silent. CO because it tests homework |
| C11 | "What would you do in your first 30 days?" | CASE | [generic] | A plan, not a past: listen across branches and the contact centre; find out how complaints flow today; read recent complaints in full; meet the supervisors you would coach; agree the first report. Say what you would not change yet | Closes the case section and returns to F3 and F4 as a plan. CASE because it tests structure |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What could a new complaints lead do in the first month that would genuinely help your branch?" | The reciprocity question for peers; it puts their workload first |
| R3.2 | "When a complaint has gone wrong in your branch, what did you most want from the process?" | Invites their own words on the seam, and gives you C8 material |
| R3.3 | "How are you and your teams hearing about the move toward hubs, and where do complaints fit?" | Shows you read the brief; raised with care, not as criticism |
| R3.4 | "Which of Ashgrove's four values do you see hardest to live in practice?" | Invites a real example you can reuse; the panel scores values, so it signals you take them seriously |

# Sources

Provided documents: the JD pasted in your message; the four values copied this morning (20 November 2026) from ashgrovecu.org/about/values; the recruiter's email on the three rounds; your summary of the July 2026 strategy brief the recruiter sent (the brief itself was not read); your own background paragraph. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted fixes the values cheat sheet and C1 to C4 |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the three rounds, their length, who runs each and the case; persona weights follow them |
| 3. `Ashgrove Credit Union strategy` | skipped | Your summary of the July 2026 brief supplies current priorities and feeds the grounding brief and CO questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name exists yet, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

The persona weights rest on the recruiter's own account of the loop, not on an archetype.

# Upgrade menu

- Hours you have before 29 November → a prep triage ordered to B1, C1 to C4 and C5, with "everything else is insurance" stated.
- Interviewer names and roles when assigned → an interviewer read from public professional footprint, persona weights re-read, and a reverse question tied to a real career path.
- Answers to the slots, in your own words (which rules or deadlines governed your complaints, what the spreadsheet counted, whether supervisors joined the escalation training, any digital-team contact, any regional-level presenting) → F2, F3, F5, F6, F7 and F8 upgrade and the banks that use them regenerate.
- The column headings of your monthly complaints spreadsheet, with no member data, and the written escalation script's wording → F5, F6 and F9 move from `medium`, because a heading list is an artifact someone can inspect.
- Four real examples, one per Ashgrove value → the scaffolds in C1 to C4 become mapped stories.
- The full July 2026 strategy brief → the grounding brief rows come from the brief itself rather than your summary.
- The recruiter, by one email: whether the 20-minute case material or format is shared in advance, and a check of the 29 November date, which falls on a Sunday → coverage of any pre-declared deliverable and a confirmed date.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes, covering recent organisation context and role-family loop reports → sharper CO questions and a check on the loop. Offered once.
- A tuesday-dossier.md → a verified-evidence grading and a prohibited-claims list carried into the pack; not needed to use it.
