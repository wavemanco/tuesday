I'll start by reading the reference files the skill points to.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a3/runs/sonnet/alone/part-2/rooms/case-7-denied-3904467c/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 22 questions across seven personas, plus a fit snapshot, reverse questions and a prohibited-claims list.

I built it assuming Tobias is your hiring manager, since his title is Head of Live Operations. The persona weights follow from that.

- **No research ran.** All four web searches (values, interview process, strategy, Tobias) were refused in this session. The pack has nothing on Saltmarsh's values or strategy and no interviewer read, and the Sources section says so. The upgrade menu lists what a rerun would add.
- **Highest-ROI prep:** A1, the in-app-purchase question, then A2 (owning the KPIs) and A3 (never having led a team). Those are the gaps you named yourself.

Say the word and I'll play the Skeptic on A1 and run it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, or is he a peer or skip-level? The answer reweights every bank.
Did the recruiter mention any focus areas, or something to prepare (a case, a presentation, a take-home)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** one 60-minute interview. Relationship assumed to be hiring manager, because the interviewer's title is Head of Live Operations and the role sits in live operations. Your note did not say, so the persona weights below rest on that assumption and move if it is wrong.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your background survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack, see Sources) |
| CASE | A live problem from the role, scored on structure and reasoning |

Question IDs run by persona. The letter F is skipped for personas because F1 to F10 are fit-snapshot rows.

**Highest-ROI prep in this pack: A1**, the in-app-purchase question, then A2 and A3. They sit where your own note says the gaps are.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's wording makes a probe on the calendar's scope likely. If your calendar work reached beyond the main title or beyond weekly drops, say where, in your own words; if it did not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show how updates were coordinated across teams. Answer slot: the JD names four disciplines, so expect a probe on each. If you worked with any of them on an update, say which and what your part was, in your own words; if you did not, or someone else coordinated, say so plainly and say how you would start |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented retention numbers, not that you owned a review or set the KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose what was reported, or reviewed how any release performed, say what and how you decided; if the numbers or any review were someone else's, or there was none, say so plainly and return to presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it, and the words stay there: "I wrote the release checklist our QA team still uses." Answer slot: if you ran releases against it, say how, in your own words; if QA or someone else ran them, or you only wrote it, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The length is stated, and a length of experience is not a gate, so this row is graded like the others. Your material does not show whether the title ran as a live service. Answer slot: if it did, say what made it one, in your own words; if you would not call it that, say so plainly and describe the work you did |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: you ran it, weekly, for the main title, for two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but nothing inspected behind it, so expect a probe on how the numbers were counted. Lead with the quote in its own terms: you presented them, monthly, to the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | Derived from the checklist being written work that others still use; the quote does not show how clear it was. Answer slot: if asked for an example of your writing, name the document in your own words; if none comes to mind, say so plainly |
| F9 | Familiarity with in-app-purchase monetization on mobile titles. Not in the JD; included because it is the gap you named — your message | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past |
| F10 | Leading a team. Not in the JD, which says coordinate; included because it is the other gap you named — your message | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't led a team." The JD's verb is coordinate, so stay in that word, and keep how you would coordinate as a plan and never as a past |

## Persona table

The persona weights come from the hiring-manager prior, adjusted by the JD. No public information about the interviewer was available (see Sources), so there are no interviewer signals.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the in-app-purchase and team-leadership gaps and of what your calendar work does and does not cover | Highest, 5 questions. A hiring manager is deriving risk, and your note names two gaps (F9, F10) while F2 and F3 are thin | Rehearse A1 until it is boring. State each gap in the plain words F9 and F10 give, then a ramp plan, and never bluff |
| B. Case / Strategist | Live problems from the job: plan a calendar, diagnose a retention drop, handle a slipping build | High, 5 questions. The hiring-manager prior says live problems on their own roadmap, and the JD's verbs are plan, run, coordinate and manage | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and use the JD's own words (calendar, post-event review, release checklist) |
| C. Data-Driven Prober | Goes two levels deep on how the retention numbers were counted and how a weekly drop was judged | Medium, 3 questions. The JD asks for comfort with retention metrics and ownership of the KPIs, and F3 and F7 rest on one quoted line | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know |
| D. Conversational / Rapport | An open biography question and why live ops, in a friendly register | Medium, 3 questions. Most interviews open this way, and the register is easy to under-prepare | A 90-second arc that stays inside your quoted facts |
| E. Pressure | Time-boxed challenges on why you, and how much of the checklist was actually you | Low, 2 questions. Nothing in the material says this interviewer is a stress interviewer; it is included so the delivery is never new | Pause, restate, hold what the quotes carry through two follow-ups, concede the specific limit |
| G. Values / Behavioral | Scenario probes: an unpopular truth, a player ahead of a metric | Low, 2 questions. No published values were available and no values round is documented, so these use the standard persona stems | Choose stories your material carries, or say plainly when none comes to mind |
| H. Peer Evaluator | Seam-splitting between live ops and engineering, and credit when work spans teams | Low, 2 questions. The JD names cross-team coordination, but the interviewer is assumed to be your manager, not a peer | Propose principles for the seam instead of pretending to know it |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've said you haven't worked on a game with in-app purchases. How does that show up in this job?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Open with the plain words: "I haven't worked on a game with in-app purchases." Stop there for a beat. Then say how you would learn it, as a plan and not a past: the first things you would ask on joining, such as whether events carry offers, how revenue is read next to retention, and who owns those decisions. Hold through two follow-ups by returning to that plan, and concede specifically that you cannot speak to purchase design from experience. Add nothing about purchases you have not done | F9 is the gap you stated and nothing in your material bridges it, so this objection is the one to make boring. JD because it scores fit for the listed mobile role, gaps included |
| A2 | "This role owns the post-event review and the KPIs it reports. What part of that have you owned yourself?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Hold only what the quote carries: "I presented the monthly retention numbers to the studio head." Answer slot: the JD names the review and its KPIs, so expect a probe on whether you chose what was reported or reviewed how a release performed. If any of that was yours, say what and how you decided, in your own words; if the numbers or any review were someone else's, or there was none, say so plainly and return to presenting the numbers. Hold through two follow-ups by returning to the presenting, never by adding to it | F3 is where the JD's ownership wording presses hardest against a one-line quote. JD because it scores the stated responsibility |
| A3 | "You've never led a team. This role coordinates design, art, engineering and community on each update. How would you get four groups to move together?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Open with the plain words: "I haven't led a team." The JD's verb is coordinate, so stay in that word. Answer slot: if you worked with any of the four groups on an update, say which and what your part was, in your own words; if you did not, or someone else coordinated, say so plainly. Then give your plan for how you would start, as a plan: one calendar everyone reads, one named owner per item, and a written note before each update | F10 is the stated gap and F2 is the row the JD presses on. JD because the question restates the JD's coordination line |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose from the gaps you have stated, not a flattering one: say it in plain words, then name what you would do in the first weeks. Do not pick a weakness you would be glad to be probed on, because the follow-up finds that out. Answer slot: if a different part of the JD feels weakest to you, say which and why, in your own words | The stem exists to see whether a candidate can judge their own limits; F9 and F10 are the safe pool. JD because it scores the whole list |
| A5 | "You've spent four years as an associate producer at a puzzle-game studio. What makes you ready for a producer role across two titles?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." | Tell what the quotes state, in your own words: four years as an associate producer at a puzzle-game studio, and for the last two years you ran the weekly content-drop calendar for the main title. Let the interviewer draw the inference. Answer slot: the JD's two-title wording makes a probe on scope likely. If your calendar work reached beyond the main title, say where; if it did not, say so plainly and stay with the calendar you ran. Concede the title difference and the scope plainly if pressed | F1 and F5 together carry the level question: your title and your scope against the JD's. EXP because it tests what your four years amount to |

### B. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've just inherited a live title with a half-built calendar. Sketch the plan for the next four weeks. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what the period is for (retention, engagement, revenue; ask which), the team capacity and release windows, and what past post-event reviews say. Then objective, segmentation of what is on the calendar, sequencing, metrics, risks. Challenge one premise respectfully. This needs no claim about your past, so the guidance makes none | The JD's lead responsibility is the calendar, and a hiring manager can test it live. CASE because it scores structure on a problem from the actual role; [generic] because it is a pattern for the problem, not a fact about this employer |
| B2 | "Retention for players who joined during last weekend's event is 20 percent below the usual weekend cohort. Diagnose it." | CASE | [generic] | Clarify what is being measured (which retention day, cohort size, normal weekend variation). Check whether the data is sound before explaining it: a tracking change, a release, a different mix of new players. Then segment, rank the hypotheses, say what you would check first, and name the assumption in your own diagnosis you would defend least | Covers the JD's retention-metrics and KPI lines as a live problem. CASE because the scoring is the structure, not the answer |
| B3 | "The update build will slip two days and the event is announced to players for Friday. Walk me through the next hour." | CASE | [generic] | Who you ask first (engineering for the cause, QA for what is at risk), the options (ship late with a message, cut scope, move the event), who decides and what you tell community and the other teams. End with what you would change in the release checklist afterward. No claim about your past | Tests the JD's release-checklist and cross-team lines under time pressure. CASE because it is a live decision problem |
| B4 | "Design, art and community each want the same slot on the calendar. How do you decide?" | CASE | [generic] | Ask what each is trying to achieve, tie the choice to the period's objective, say the criteria before the verdict, write the decision down, and say who you take a tie to. No claim about your past | F2's coordination line as a decision. CASE because it is a trade-off, not a recall question |
| B5 | "Write me the three-line status note you would send to design, art, engineering and community the day before an update goes live." | CASE | [generic] | Say the three lines aloud: what is shipping and when, what changed since the last note, what is at risk and who decides. Short sentences, each team named where it has an action. Cut anything that is not a decision or a date | The JD asks for clear written communication, and a short live writing task is the most direct test. CASE because it is delivered live; JD content |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the retention numbers you presented each month were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The quote says you presented them. Answer slot: say how they were counted if you know, in your own words: which retention measure, what it is sensitive to, the assumption you would defend least, and which part of the numbers was yours. If you did not build the counting, or do not know, say so plainly and return to presenting them. Do not name a method you cannot repeat under a second question | F7 rests on one line with nothing inspected, which is where a prober starts. EXP because it tests attribution and whether you know your own numbers |
| C2 | "After an event ends, which retention number do you look at first, and why?" | JD | [generic] | Pick one and say why in your own words, then name what it misses and the assumption you would defend least. Do not recite a list of metrics; a choice with a stated limit scores higher | Tests comfort with the JD's retention-metrics line without presupposing your past. JD because it scores the stated requirement |
| C3 | "How did you decide whether a weekly drop had worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: the JD's post-event review line makes this a likely probe. If drops were assessed, say how and what part was yours, in your own words; if there was no formal check, or someone else did it, say so plainly and return to running the calendar | F3 and F6 meet here: the calendar is quoted, the judging of it is not. EXP because the premise is a practice your quotes do not state |

### D. Conversational / Rapport Builder (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Presented the monthly retention numbers to the studio head." | A 90-second arc in this order, in your own words: four years as an associate producer at a puzzle-game studio; for the last two years you ran the weekly content-drop calendar for the main title; you wrote the release checklist the QA team still uses; you presented the monthly retention numbers to the studio head. Add no title, scope or result that is not in those sentences. Leave the gaps for the questions rather than apologizing for them first | The biography question is scored even when it feels casual. F1, F4, F5 and F7 are the rows the arc draws on. EXP because it tests the story against the background |
| D2 | "Why live operations, and why this studio?" | JD | [generic] | Answer slot: give your own reasons for live operations, in your own words. The pack has nothing on Saltmarsh beyond the JD and your note, so any reason about the studio must be yours; if you have none yet, say what you would want to learn about it, and use the upgrade menu to get it | A motivation probe is near-certain in a manager conversation. JD because it scores fit with the listed role |
| D3 | "What are you playing in live-service mobile games these days?" | JD | [generic] | Answer slot: name the titles you actually play and what you notice about how their events are run, in your own words; if you do not play in the space, say so plainly and say how you keep up. Do not name titles to sound current | A casual question about the role's own territory, and still scored. JD because it tests engagement with the domain |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, rather than someone who has run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Never led a team, and never worked on a game with in-app purchases." | Pause and restate the question. Hold on what the quotes carry: you ran the weekly content-drop calendar for the main title for the last two years. Concede the specific limit plainly: "I haven't worked on a game with in-app purchases." Hold through two follow-ups; do not claim a skill to cover the gap, and do not claim you led anyone | F9 returns here as a pressure item. JD because it scores fit, and the delivery tests composure |
| E2 | "That release checklist: how much of the QA process was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold the quote: "I wrote the release checklist our QA team still uses." Answer slot: if others contributed to it or QA ran releases against it, say so plainly and say which part was yours; if you ran releases against it, say how, in your own words. Hold through two follow-ups by returning to the checklist you wrote, never by adding to it | F4 is one line, and an attribution probe is how an interviewer tests one line. EXP because it tests what was actually yours |

### G. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship still intact at the end. The only leadership-facing line in your material is presenting the numbers to the studio head, and it does not show whether any month was unwelcome. Answer slot: if a month's numbers were unwelcome, say what they showed and how you said it, in your own words; if none were, say so plainly and give the nearest thing your material carries, or how you would handle it | A standard stem, included so the style is never new; no published values were available. VAL because it scores behavior, not content |
| G2 | "When did you put a player's experience ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision with a named metric at stake, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. No claim about your past is written here | A standard stem, and a live-operations producer sits where those two meet. VAL because it scores a decision, not a slogan |

### H. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Where is the seam between live operations and engineering, and what happens when we disagree?" | JD | [generic] | Propose principles instead of pretending to know the seam: who decides what, what is agreed in writing before an update, and where a disagreement goes if it is not settled between the two teams. Say you would learn the actual seam in your first weeks. No claim about your past | F2's coordination line, in peer packaging. JD because it scores the stated cross-team responsibility |
| H2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Use the one cross-team item your quotes carry: say "we" for the context and "I" for the part you wrote. Answer slot: if others helped write it or QA shaped it, say so plainly and say which part was yours; if you wrote it alone, say so | Credit probes are collegial attribution checks on F4. VAL because it scores behavior with peers |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A5, B1 |
| "coordinate design, art, engineering and community teams on each update" | A3, B3, B4, H1 |
| "own the post-event review and the KPIs it reports" | A2, B2, C3 |
| "manage the release checklist with QA" | B3, E2, H2 |
| "3+ years producing live-service games or apps" | A5, D1 |
| "experience running a content calendar" | B1, C3, D1 |
| "comfortable with player-retention metrics" | B2, C1, C2 |
| "clear written communication" | B5 |
| Not in the JD: in-app purchases and leading a team (F9, F10) | A1, A3, A4, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How does the post-event review work today, and which KPIs does it report?" | The JD gives the role ownership of both, so asking for the baseline reads as planning, and it tells you what F3's gap means in practice |
| 2 | "How do the two titles' calendars differ in cadence and in what the team looks at after an event?" | Shows you read the JD's two-title wording as a real scope question, and tells you how far your one-title calendar carries |
| 3 | "Given that I haven't worked on a game with in-app purchases, what would you want me to learn first?" | Owns the stated gap in your own words and turns the Skeptic's strongest question into the interviewer's own plan for you |
| 4 | "Which of design, art, engineering and community finds an update hardest to coordinate, and what has helped?" | Shows you treat coordination as the job, and gives you the team's actual seam instead of a guessed one |
| 5 | "How is the release checklist used with QA today, and where would you want a producer to change it?" | Ties to the one artifact you wrote, without claiming more than the checklist, and asks what the role would add to it |
| 6 | "What would you want a new producer to have shipped or changed by day 90?" | Gets the interviewer's own definition of success, which you can use in your closing |
| 7 | "What are the next steps after this conversation?" | Standard process question, useful for planning your follow-up |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked on a game with in-app purchases, or on monetization | A negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Has led a team | A negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't led a team." No slot |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says you presented the numbers, not that you owned a review or set the KPIs. A2's slot stays inside the presenting |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope. The material says you wrote the checklist and QA still uses it, not that you ran releases. E2's slot stays inside the checklist you wrote |
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The material says a weekly content-drop calendar for the main title. A5's slot stays inside the calendar you ran |

## Sources

**Provided documents:** the job description pasted in your message, and your background as stated in your message. No dossier was present.

**Searches sent (all four refused; the tool was not permitted in this session, and nothing came back):**

- `Saltmarsh Games company values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games mobile studio news strategy` — refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet and the VAL questions; the search was refused. Section 10 is dropped, and G1 and G2 use standard stems |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have moved persona weights if it had documented more of the loop; the search was refused. Your own words establish one 60-minute interview with Tobias Wrenfield, so the weights use the hiring-manager prior |
| 3. `Saltmarsh Games mobile studio news strategy` | unavailable | Would have fed CO questions and D2's studio-specific reason; the search was refused. The pack has no CO question and says so |
| 4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` | unavailable | Would have fed an interviewer read and a reverse question tied to his path; the search was refused. Section 7 is dropped and the reverse questions are role-level |
| 5. representative Live Operations Producer JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is your future manager, a peer or a skip-level → persona weights reweight, and the Peer or Pressure bank grows or shrinks
- The recruiter's focus areas, or any task announced for the interview (a case, a presentation) → a build section for it, and the coverage table retargets
- Search access in this session → the four refused searches rerun, giving a values cheat sheet if a values round is documented, a CO or CASE question grounded in the studio's current strategy, and a reverse question tied to Tobias's public career path. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once search works
- Your answers to the slots in F1 to F5 and F8 → those rows gain quoted evidence and the matching guidance becomes story-mapped instead of an instruction
- The calendar export, the release checklist itself, or one of your monthly retention decks → F1, F4 and F7 can move from medium toward high, and the checklist is also your example for F8
- A tuesday-dossier.md from job-underwriter → verified evidence and prohibited claims arrive pre-graded, and this pack's highest-ROI objection can be evidence-derived instead of inferred
