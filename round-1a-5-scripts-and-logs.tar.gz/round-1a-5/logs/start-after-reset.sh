#!/bin/bash
# Round 1a-5 (owner, 25 November: "go with your recommendations, build the fix round now"; the report recommended
# building now and running after the meter's reset on 26 November at 06:00 UTC). Waits for the reset, runs the
# preflight, and starts Haiku with Sonnet chained after it only if the preflight passed. The stop rule in run_step.sh
# still reads the meter before each step.
M=/var/tmp/tuesday-measure/1a5; K=$M/frozen/kit; L=$M/logs
log() { echo "$(date -u +%FT%TZ) $*" | tee -a "$L/start-after-reset.log"; }
until [ "$(date -u +%s)" -ge "$(date -u -d '2026-11-26T06:05:00Z' +%s)" ]; do sleep 60; done
log "reset passed; running the preflight"
cd /var/tmp && bash "$K/preflight.sh" > "$L/preflight.console.txt" 2>&1
if ! grep -q "^PREFLIGHT PASSED" "$L/preflight.console.txt"; then
  log "preflight did not pass; nothing started (see preflight.console.txt)"; exit 0
fi
log "preflight passed; starting haiku, then the sonnet chain"
cd /var/tmp && setsid nohup bash "$L/chain-sonnet.sh" > "$L/chain-sonnet.console.txt" 2>&1 < /dev/null &
cd /var/tmp && bash "$K/run_step.sh" haiku quality > "$L/haiku-step.console.txt" 2>&1
log "haiku run_step rc=$?"
