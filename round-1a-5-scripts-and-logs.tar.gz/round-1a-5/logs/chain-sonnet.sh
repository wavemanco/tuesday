#!/bin/bash
# Round 1a-5's chain (owner, 25 November: "go with your recommendations, build the fix round now", and "why can't we
# run things now?"; see owner-note-25nov.txt): Sonnet starts only after Haiku's step status ends "done"; any other end
# (stopped, refused, crashed) leaves Sonnet unstarted. If the stop rule bars Sonnet at that reading, it waits for the
# meter's reset (26 November 06:00 UTC) and tries once more.
# Sonnet runs from kit-sonnet-owner/, the frozen kit with one change (owner, 25 November: "run sonnet as well once
# haiku is done even if the meter is at 80%"): its start threshold is 80% and the 90% ceiling check is waived; the
# guard still stops the step at 95%.
K=/var/tmp/tuesday-measure/1a5/logs/kit-sonnet-owner; ST=/var/tmp/tuesday-measure/1a5/logs/status; C=/var/tmp/tuesday-measure/1a5/logs
while :; do
  last=$(tail -1 "$ST/haiku-quality.status" 2>/dev/null)
  case "$last" in
    *" done") break;;
    *stopped*|*STOPPED*|*REFUSED*|*CRASHED*) echo "$(date -u +%FT%TZ) haiku ended '$last'; Sonnet not started"; exit 0;;
  esac
  sleep 60
done
echo "$(date -u +%FT%TZ) haiku done; starting sonnet"
"$K/run_step.sh" sonnet quality > "$C/sonnet-step.console.txt" 2>&1; rc=$?
echo "$(date -u +%FT%TZ) sonnet run_step rc=$rc"
if grep -q "NOT STARTED: the stop rule bars the step" "$C/sonnet-step.console.txt"; then
  mv "$C/sonnet-step.console.txt" "$C/sonnet-step.before-reset.console.txt"
  echo "$(date -u +%FT%TZ) the stop rule barred sonnet; waiting for the reset"
  until [ "$(date -u +%s)" -ge "$(date -u -d '2026-11-26T06:05:00Z' +%s)" ]; do sleep 60; done
  echo "$(date -u +%FT%TZ) reset passed; starting sonnet"
  "$K/run_step.sh" sonnet quality > "$C/sonnet-step.console.txt" 2>&1
  echo "$(date -u +%FT%TZ) sonnet run_step rc=$?"
fi
