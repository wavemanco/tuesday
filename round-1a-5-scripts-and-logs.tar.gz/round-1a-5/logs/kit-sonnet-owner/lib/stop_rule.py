"""stop_rule.py: the stop rule's arithmetic (manifest section 18; plan E21), in exact decimals.

    stop_rule.py start <step> <reading>   exit 0 when the step may start, 1 when it may not
    stop_rule.py guard <reading>          exit 0 when the guard must stop the step (reading >= 95%), 1 otherwise
    stop_rule.py table                    the start threshold of every step
    stop_rule.py chain <R0>               from the reading before preflight, each step's projected start at the
                                          high planning estimates of the steps before it (manifest section 18)
    stop_rule.py self-test                the rule against simulated readings

A reading is the meter's seven-day utilization as the meter prints it, a fraction (0.44 is 44%). A step
starts only at a reading of 80% or less, and only if the reading plus the step's high planning estimate is
90% or less; so each step's start threshold is min(80, 90 - high). No exception has advance approval.
"""
import sys
from decimal import Decimal, InvalidOperation

HIGH = {"preflight": Decimal("5.50"), "haiku": Decimal("3.44"), "sonnet": Decimal("15.46"),
        "explicit": Decimal("1.25"), "opus": Decimal("17.50")}
START_CAP, CEILING, GUARD = Decimal("80"), Decimal("90"), Decimal("95")
# The thresholds the manifest prints; table() and self_test() hold the arithmetic to them.
MANIFEST_START = {"preflight": Decimal("80.00"), "haiku": Decimal("80.00"), "sonnet": Decimal("74.54"),
                  "explicit": Decimal("80.00"), "opus": Decimal("72.50")}


def percent(reading: str) -> Decimal:
    value = Decimal(str(reading).strip())
    if not value.is_finite() or value < 0 or value > Decimal("1.5"):
        raise ValueError(f"reading {reading!r} is not a seven-day utilization fraction")
    return value * 100


def threshold(step: str) -> Decimal:
    return min(START_CAP, CEILING - HIGH[step])


def start(step: str, reading: str) -> tuple[bool, str]:
    p = percent(reading)
    high = HIGH[step]
    ok_cap, ok_ceiling = p <= START_CAP, p + high <= CEILING
    if step == "sonnet":
        # Round 1a-5 only (owner, 25 November: "run sonnet as well once haiku is done even if the meter is at 80%"):
        # Sonnet starts at a reading <= 80%; the 90% ceiling check is waived for it. The guard's 95% stop is unchanged.
        ok_ceiling = True
    ok = ok_cap and ok_ceiling
    why = (f"stop rule, {step}: reading {p.normalize():f}%; start only at <= {START_CAP}% "
           f"({'yes' if ok_cap else 'NO'}) and reading + high estimate {high} = {(p + high).normalize():f}% <= "
           f"{CEILING}% ({'waived by the owner, 25 November' if step == 'sonnet' else 'yes' if ok_ceiling else 'NO'}); threshold {threshold(step) if step != 'sonnet' else START_CAP}% -> "
           f"{'START' if ok else 'REFUSED'}")
    return ok, why


def guard(reading: str) -> tuple[bool, str]:
    p = percent(reading)
    stop = p >= GUARD
    return stop, f"guard: reading {p.normalize():f}% {'>=' if stop else '<'} {GUARD}% -> {'STOP' if stop else 'go on'}"


ORDER = ("preflight", "haiku", "sonnet", "explicit", "opus")


def chain(r0: str) -> list[tuple[str, Decimal, Decimal, bool]]:
    at, rows = percent(r0), []
    for step in ORDER:
        rows.append((step, at, threshold(step), at <= threshold(step)))
        at += HIGH[step]
    return rows


def self_test() -> int:
    cases = [("start", "haiku", "0.80", True), ("start", "haiku", "0.8001", False), ("start", "haiku", "0.44", True),
             ("start", "sonnet", "0.7454", True), ("start", "sonnet", "0.7455", False),
             ("start", "sonnet", "0.75", False), ("start", "opus", "0.725", True), ("start", "opus", "0.7251", False),
             ("start", "opus", "0.73", False), ("start", "explicit", "0.80", True),
             ("start", "explicit", "0.81", False), ("start", "preflight", "0.80", True),
             ("start", "preflight", "0.81", False), ("start", "haiku", "0", True),
             ("guard", None, "0.94", False), ("guard", None, "0.9499", False), ("guard", None, "0.95", True),
             ("guard", None, "0.97", True), ("guard", None, "1", True)]
    failures = 0
    for step in HIGH:
        same = threshold(step) == MANIFEST_START[step]
        failures += not same
        print(f"  {'ok  ' if same else 'FAIL'} threshold {step}: {threshold(step)}% (manifest {MANIFEST_START[step]}%)")
    for kind, step, reading, want in cases:
        got, why = start(step, reading) if kind == "start" else guard(reading)
        failures += got != want
        print(f"  {'ok  ' if got == want else 'FAIL'} {why}")
    # The manifest's chained table: the highest R0 at which each step can start (80, 74.5, 65.6, 55.6, 46.85).
    for r0, want in (("0.4685", [True] * 5), ("0.4686", [True, True, True, True, False]),
                     ("0.5560", [True, True, True, True, False]), ("0.5561", [True, True, True, False, False]),
                     ("0.6560", [True, True, True, False, False]), ("0.6561", [True, True, False, False, False]),
                     ("0.7450", [True, True, False, False, False]), ("0.7451", [True, False, False, False, False])):
        got = [row[3] for row in chain(r0)]
        failures += got != want
        print(f"  {'ok  ' if got == want else 'FAIL'} chain from R0 {percent(r0).normalize():f}%: "
              + ", ".join(f"{s} at {a.normalize():f}% {'starts' if ok else 'waits'}" for s, a, _, ok in chain(r0)))
    for bad in ("", "abc", "-0.1", "44", "nan"):
        try:
            percent(bad)
            failures += 1
            print(f"  FAIL reading {bad!r} accepted")
        except (ValueError, InvalidOperation):
            print(f"  ok   reading {bad!r} refused")
    print("stop rule self-test:", "pass" if not failures else f"{failures} failure(s)")
    return 1 if failures else 0


def main(argv: list[str]) -> int:
    try:
        if argv[:1] == ["start"] and len(argv) == 3 and argv[1] in HIGH:
            ok, why = start(argv[1], argv[2])
            print(why)
            return 0 if ok else 1
        if argv[:1] == ["guard"] and len(argv) == 2:
            stop, why = guard(argv[1])
            print(why)
            return 0 if stop else 1
    except (ValueError, InvalidOperation) as exc:
        print(f"stop rule: {exc}; nothing starts or stops on it")
        return 1 if argv[0] == "start" else 3
    if argv == ["table"]:
        for step in HIGH:
            print(f"{step:10} high {HIGH[step]:>6}  starts at <= {threshold(step)}%")
        return 0
    if argv[:1] == ["chain"] and len(argv) == 2:
        for step, at, th, ok in chain(argv[1]):
            print(f"{step:10} projected start {at.normalize():f}% against {th}%: "
                  f"{'can start this week' if ok else 'waits (the reading would be above its threshold)'}")
        return 0
    if argv == ["self-test"]:
        return self_test()
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
