# Interview pack: Customer Support Specialist, Lumenvale Software

Remote role. Interviewer: the support team lead, name not given, conducting a text chat on Telegram. The recruiter who wrote to you is named as Marcus Hale. Built on one assumption: the team lead is your likely future manager, so hiring-manager weights apply. If they are a peer, the weights change (see the upgrade menu).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words.

| Tag | Meaning |
|---|---|
| VAL | Past behavior against the company's published values |
| EXP | Whether your stated experience survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role |

Because this interview is a text chat, every message you type is also a sample of the written communication the ad asks for. Short, plain, correctly punctuated replies are part of the score.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as quoted in your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a line from your message with nothing inspected behind it, so expect a probe. Lead with it in its own terms: three years as a customer service advisor at an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as quoted in your message | "I use Freshdesk every day" — your message | medium | [grounded] | none | Name Freshdesk, the tool your message names. Your material does not mention Zendesk, so no Zendesk claim is coached. Answer slot: if you have used Zendesk, say where and how; if you have not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — job ad, as quoted in your message | "answering around 60 calls and emails a day" — your message | low | [grounded] | discovery | The line mixes calls and emails and does not show how much was written. Answer slot: expect a probe on how much of that work was email; if you know roughly, say so, and if the split was never tracked, say so plainly and stay with the line as written. This chat is itself a written sample the interviewer is reading |
| F4 | "confidence handling escalations" — job ad, as quoted in your message | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: expect a probe on a time a case was escalated or you handled an angry customer. If that happened, say what the case was and what part was yours, in your own words; if escalations went to someone else or did not come up in your role, say so plainly and say how you would handle one |
| F5 | Familiarity with a software company's product and customers — role-family expectation, not in the ad as you quoted it | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | Help new colleagues get up to speed — common in support teams, not in the ad as you quoted it | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | No ad line rests on it, but the figure invites a probe. Say it at its own scope: you trained four new starters on the refunds process last year. Whether you wrote the material or set the process is not in your message; D2 holds the slot |

## Persona table

Loop basis: your message names one session, a text chat with the support team lead. It does not say who that person reports to or what they will focus on, so the weights rest on the hiring-manager prior in the skill's persona model and not on a documented Lumenvale process.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live support scenarios typed into the chat: an angry customer, a queue spike, a reply to rewrite | High. A support team lead hiring a specialist buys capability on live work, and a text chat makes scenarios cheap to run | Clarify, then structure, then answer; say what you would check first. Bank A |
| Skeptic | Probes the gaps: no software-company background, tool match, written share, escalations | High. F5 is a gap you stated, and F3 and F4 are thin in the material | Rehearse the F5 objection until it is boring: plain acknowledgment, then a plan. Bank B |
| Conversational / Rapport | Friendly openers like "walk me through your journey" | Medium. Chat openings usually start here, and the questions are still scored | A short written arc built only from your own lines. Bank C |
| Data-Driven Prober | Asks how the 60 a day was counted and what the training involved | Medium. Both figures in your message are easy to probe | Know what you can and cannot say about how each number was counted. Bank D |
| Pressure | Time-boxed or challenging lines such as why you over someone from SaaS support | Low-medium. Text chat softens interruption, but a lead may still test composure | Hold, then concede specifically. Bank E |
| Peer Evaluator | Seam and collaboration questions | Low unless the lead is a peer. No bank; see the upgrade menu | Reciprocity framing if it appears |
| Values / Behavioral | Scenario probes against published values | Not detected. No loop source names a values round and no values page was read, so no bank | Not applicable |

## Question banks

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer has written in three times about the same billing error and says they will cancel today. What do you write in your next reply?" | CASE | [generic] | Structure it aloud: acknowledge the three contacts and the cancellation deadline, say what you will check first, say what you will do and by when, say who you would involve if you cannot fix it yourself, and say how you would follow up. The question needs no claim about your past, so the guidance makes none | A live problem typical of support work, and a text chat lets the lead watch your actual reply. [generic] because it is a pattern, not a fact about this employer |
| A2 | "A customer demands a manager and the fix is outside what you are allowed to do. Walk me through what you do and when you hand it on." | CASE | [generic] | Structure: stay with the customer, state what you can do now, state what you cannot and why, say what you would write in the handover so the customer does not repeat themselves, and tell the customer what happens next. Presupposes nothing about your past | Tests the escalation requirement as a decision, ahead of A3, which tests it as experience. See F4 |
| A3 | "Tell me about a time you handled an escalated case." | EXP | [grounded] | Open prompt from the ad's escalation line, and F4 holds no quote, so this is a selection scaffold. Pick a case with a named customer problem, a point where it went beyond the first line, and what you did next. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle one | The ad names escalations and your material is silent, so this is the probe most likely to land on a gap. EXP because it asks for a real instance |
| A4 | "The queue doubles after a product release and you are on shift with two colleagues. How do you decide what to answer first?" | CASE | [generic] | Structure: what you need to know first, how you would sort what is waiting, what you would tell customers who are waiting, and what you would flag to the lead. Answer slot: the ad names a ticketing tool, so expect a probe on what your own tool lets you do with a queue. If you have used features for sorting or tagging, say which, in your own words; if you have not, say so plainly and describe how you would sort | The ad's ticketing-tool line (F2) makes tool-handling likely. CASE because it is a live problem, JD in what it probes |
| A5 | "A customer is upset that a refund was refused. The draft reply says: Unfortunately that is not something we can do. Please see our policy. Rewrite it." | CASE | [generic] | Write it live: acknowledge the refusal landed badly, say plainly what the decision is and the reason in one sentence, say what you can offer instead if anything, and close with a clear next step. Keep it short, the way you would send it. Presupposes nothing about your past | Scores the ad's written-communication line (F3) directly, in the medium the interview is already in. CASE in form, JD in what it scores |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have not worked for a software company. What makes you think you will pick up our product quickly?" | JD | [grounded] "I've never worked for a software company" | Highest-ROI rehearsal in this pack. Hold-then-concede. First words: "I've never worked for a software company." Then a plan, said as a plan: what you would read and watch in your first weeks and how you would check your understanding. Hold that position through two follow-ups; concede specifically that you do not yet know their product or terms, and do not claim equivalence with someone from software support. Do not describe software or technical support work you did not do | F5 is the gap you stated, and every other bank's probes come back here in some form. JD because it scores whether you can do the listed job from this starting point |
| B2 | "The ad asks for Zendesk or a similar tool. Have you used Zendesk?" | JD | [grounded] "I use Freshdesk every day" | Answer slot: if you have used Zendesk, say where and how, in your own words; if you have not, say so plainly and say that Freshdesk is the tool you use every day. Never describe Zendesk features you have not used | F2 is the evidence for the tool requirement, and the ad names Zendesk specifically. JD because it scores a stated requirement |
| B3 | "Your experience covers calls and emails. How comfortable are you with written-only support?" | JD | [grounded] "answering around 60 calls and emails a day" | Say what the line says, at its own scope: you answered calls and emails. Answer slot: if you can say roughly how much of it was email, say so in your own words; if the split was never tracked, say so plainly and stay with the line as written. Point out nothing the line does not show, and let this chat be the sample | F3 is thin: it does not show how much was written. JD because it scores the ad's written-communication line |
| B4 | "Why are you applying to move from energy supply into software support?" | JD | [generic] | Selection scaffold: your reason must be true and specific to you, and about the work, not flattery. If one clear reason comes to mind, give it in two sentences; if you are not sure what draws you, say so plainly and say what you do know you want from the role. Your material holds no sentence for this, so none is written for you | The motivation probe a skeptic opens with once the background mismatch (F5) is on the table. JD because it scores fit with the role |
| B5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name the weakness you actually have. Your message gives one: you have not worked for a software company. Say it plainly, then what you would do in the first weeks. If you would rather name escalations, name them only if that is true for you. Calibrated candor beats a disguised strength | A standard skeptic stem, and F5 and F4 are where the honest answer sits. JD because it scores honest self-assessment against the listed requirements |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your three years so far and how they connect to this role." | JD | [grounded] "3 years as a customer service advisor at an energy supplier" "I use Freshdesk every day" "I trained four new starters on our refunds process last year" | A short written arc using only these lines, each at its own scope: three years as a customer service advisor at an energy supplier, Freshdesk every day, and training four new starters on the refunds process last year. Three or four short sentences, then one sentence on why this role, in your own words | F1 is the headline requirement, and chat interviews often open this way. JD because it scores the 2+ years line; EXP in what it exposes |
| C2 | "Tell me about a time you calmed down a frustrated customer." | EXP | [generic] | Open prompt, and your material holds no sentence for it, so this is a selection scaffold. Pick a real case with a named problem, what you said or did, and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Casual-register questions about core support work are still scored. EXP because it asks for a real instance |
| C3 | "Beyond the daily tickets, what do you like and dislike about Freshdesk?" | JD | [grounded] "I use Freshdesk every day" | Answer from daily use only. Answer slot: name one thing you like and one thing you would change, in your own words; if you have only used a narrow part of it, say so plainly and say which part. Do not name features you have not used | The persona stem asks what you are playing with in the JD's own tool. JD because it scores the ad's ticketing-tool line (F2) |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You answered around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Defend-the-number slots, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Keep the word around. Keep the number on its noun: it counts calls and emails together, not emails. If you do not know how it was counted, say so plainly | A headline figure on your message is a magnet target. EXP because it tests the claim's precision |
| D2 | "You trained four new starters on the refunds process. What did that involve, and what was yours?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell the beats the line states: four new starters, the refunds process, last year. Answer slot: expect a probe on how much of it was yours. If you wrote the material or set the process, say which; if the process was set by others or the training was shared, say so plainly and describe how you trained them. Never say you ran a training programme | The second figure on your message, and a favourite for probing attribution. EXP because it tests what was actually yours |
| D3 | "What kinds of contact made up most of your day?" | EXP | [generic] | Open prompt, and your material holds no sentence on the mix, so this is a scaffold. Name the two or three types you actually handled most. If you do not remember the split, say so plainly and name the types you do remember | A prober checks whether the headline figure matches a concrete working day. EXP because it tests the claim's texture |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Short answer: why should we pick you over someone who already works in SaaS support?" | JD | [grounded] "I've never worked for a software company" "I use Freshdesk every day" | Hold-then-concede. Concede the gap first and specifically: "I've never worked for a software company." Hold the position that remains: you use Freshdesk every day. Do not claim equivalence. Hold through two follow-ups; restate rather than add. Keep it to four short lines | A time-boxed challenge aimed at F5, where composure is scored. JD because it scores fit against the requirements |
| E2 | "That refunds training: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold what the line says: you trained four new starters on the refunds process. Answer slot: if you built or set any of it, say which part; if you did not, say so plainly. Concede what you do not know or did not do, specifically, and do not fold on the core claim to ease the moment | A standard pressure stem on F6. EXP because it tests attribution under pushback |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 2+ years in customer support | C1, B4 |
| F2 Zendesk or a similar ticketing tool | B2, C3, A4 |
| F3 clear written communication | A5, B3, D1 |
| F4 confidence handling escalations | A2, A3, B5 |
| F5 software-company background | B1, E1, B4, B5 |
| F6 training new starters | D2, E2, C1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Can you confirm this process by email from a Lumenvale address or on the careers page I applied through, and who issues the offer?" | Gives you something checkable outside the chat before you share anything |
| R2 | "What would you want me to have learned by the end of my first month?" | Turns the software-company gap (F5) into a conversation about a ramp plan |
| R3 | "What does an escalation look like on this team, and who do I hand over to?" | Shows you think about handover, and answers what F4 leaves open |
| R4 | "Which ticketing tool does the team use, and what is the mix of chat, email and phone?" | Settles the tool requirement (F2) and the written share (F3) for the real job |
| R5 | "How do you review the quality of written replies on the team?" | Signals you take written communication seriously and shows how you will be judged |
| R6 | "What are the working hours and time zone, and who supplies equipment for a remote role?" | Practical terms for a remote job that the message does not give |
| R7 | "What happens after this chat, and what would you need from me?" | Closes the loop and tells you the real next step |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". Your material says Freshdesk, not Zendesk. B2's slot allows either truth |
| Handled around 60 emails or written tickets a day | Inflated form of F3: the number sits on calls and emails together | F3's quote at its own scope. The limit is the pack's observation, not words for you: the line does not separate calls from emails |
| Led or ran the new-starter training | Inflated form of F6 | F6's quote at its own scope. D2's slot asks only what was yours |
| Worked in or supported software or SaaS | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company". No slot |

## Sources

Provided documents: your Telegram message and your description of your background and the ad's requirements, both quoted as "your message". No CV and no full job ad text. No dossier.

Searches sent, all refused, none returned results:

- "Lumenvale Software company values" — refused
- "Lumenvale Software interview process Customer Support Specialist" — refused
- "Marcus Hale Lumenvale Software talent team" — refused
- "Lumenvale Software recruiter Telegram interview scam" — refused, a call outside every declared target, sent to check the employer and the message's origin

I could not verify that Lumenvale Software or the named recruiter exists, and nothing about the company in this pack comes from outside your message.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | The search was refused. It would have fed VAL questions and a values cheat sheet if a values round were documented |
| 2. Lumenvale Software interview process, support roles | unavailable | The search was refused. It would have fed persona weights and the loop structure |
| 3. Lumenvale Software strategy, recent news | unavailable | No search was sent, because the earlier searches were refused. It would have fed a CO question |
| 4. Marcus Hale, Lumenvale Software | unavailable | The search was refused. It would have checked the recruiter's public professional footprint. The team lead is unnamed, so no interviewer read exists |
| 5. Representative Customer Support Specialist JD | skipped | The requirements you quoted fix the fit snapshot and the JD-tagged questions |
| Outside the declared targets: Telegram and scam query | unavailable | The call was refused. It would have checked the employer and the process, and moved the reverse questions and the upgrade menu |

## Upgrade menu

- Whether the team lead is your future manager or a peer → persona weights recomputed, and a peer bank with a reciprocity question added if needed
- The full ad text → the four quoted requirements plus any mid-list items become JD-tagged questions, and F-rows rest on the ad's own wording
- Your CV → the F1, F2 and F6 quotes can reach `high` confidence and more answers become story-mapped instead of scaffolds
- Your answers to the slots in F2, F3, F4 and D2 (Zendesk, share of written work, escalations, what was yours in the training) → those rows upgrade from discovery and the guidance becomes story-mapped
- Search permission → the four refused targets run, giving values, loop structure, recent news and the recruiter's footprint; a deeper pass is available once, up to 6 more searches and 2 more fetches, several more minutes
- The recruiter's follow-up email, or a link to the job on the company's own site → confirms the process and the real next step, and covers any deliverable
- A `tuesday-dossier.md` from earlier work → verified evidence and a named top objection in place of the inferred ones
