# Interview pack: Customer Support Specialist, Lumenvale Software

**Role:** Customer Support Specialist (remote), Lumenvale Software
**Interviewer:** the support team lead (name not given), by text chat on Telegram. Marcus Hale from the talent team arranged it and is not the interviewer.
**Relationship assumed:** a functional lead who would manage or work closely with the hire, so the pack is weighted as a hiring-manager round.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words.
- Type tags: **VAL** (values and behaviour), **EXP** (does your experience hold up), **JD** (the stated requirements), **CO** (company and strategy knowledge), **CASE** (a live problem).
- Your interview is a text chat, so every answer will be typed. Aim for answers of two to four short messages. Write the first line so it answers the question, and add detail after it.
- Answer slots are instructions for the interview, not questions for you now. Each one has two honest branches, and either is fine.
- There are no CO questions. Company research did not run (see Sources), and a CO question written without it would be generic.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you relayed it | "3 years as a customer service advisor at an energy supplier" — your message; "answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap. The quote is longer than the two years asked for and is in role terms. It is a message line with nothing inspected behind it, so expect a probe on what the advisor job involved. Lead with it as written |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you relayed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Freshdesk is the similar tool, and the quote says daily use. Name it plainly. The pack's observation is that your material says Freshdesk, not Zendesk, so say Freshdesk and make no claim about Zendesk (see B5) |
| F3 | "clear written communication" — job ad, as you relayed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote shows emails were part of the work and says nothing about how you wrote them. Answer slot: the ad raises written communication, and this interview is itself written, so expect it to be scored live. If you wrote your own replies, say in your own words what you aimed for in them; if the wording was set for you, say so plainly and say what you changed to suit each customer. Bring one short real example if you have one |
| F4 | "confidence handling escalations" — job ad, as you relayed it | none given | none | [grounded] | discovery | The pack's observation is that your material does not show escalations either way. Answer slot: the ad names escalations, so expect a probe. If you dealt with escalated cases, say what the situation was and what part was yours; if you did not, or they went to someone else, say so plainly and say how you would handle one |
| F5 | familiarity with a software product and its customers (role-family) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F6 | sharing process knowledge with teammates (role-family) | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | No gap. Use the quote as written: four new starters, the refunds process, last year. Expect a probe on how much of the training was yours (D2, E2) |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A made-up customer message you answer live in the chat | High. A support lead hiring a written-support role will want to see you write, and the chat format makes that easy | Clarify first, then answer. Say what happens next and when |
| Skeptic | Probes on the software gap, Zendesk and escalations | High. F5 is a gap you have stated and F4 has no evidence in your material, so the lead has two obvious things to press on | Rehearse B1 until it is boring. Say the gap plainly and move straight to the plan |
| Conversational | Friendly questions about your journey and your current job | Medium. It is a chat and probably opens warmly. Casual questions are still scored | Have a short arc ready (C1) and treat easy questions as scored |
| Data-Driven Prober | Asks how "around 60 a day" was counted | Low-medium. A support lead may check the numbers, but a CV-style deep dive is less likely | Know what the figure does and does not cover (D1) |
| Pressure | Short, challenging questions: why you over someone from software? | Low-medium. Possible, because the gap invites it | Pause, hold the position, concede the specific gap only (E1) |
| Values / Behavioral | "Tell me about a time…" questions | Low-medium. No source I read describes a values round, so these are stem-based `[generic]` questions | Pick the story in advance, or say plainly that none comes to mind |

Weights follow your own description of the round: one text interview with the support team lead. No loop source documents more than that, so the weights rest on a relationship pattern and not on this company's published process. The Peer persona is left out because the interviewer is not a peer.

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes: 'This is the third time I've asked and nobody has fixed it. Cancel my account.' Reply to me as you would in the chat." | CASE | [generic] | The question asks for no claim about your past, so the guidance makes none. Structure: acknowledge the specific frustration, say who owns the next step, ask at most one question you need answered, and give a time for the next update only if you control it. Keep it short and avoid scripted apologies | Tests F3 live and the tone that F4 depends on; CASE because it is a live problem |
| A2 | "A customer says a feature isn't working and you've never seen our product. What do you do first?" | CASE | [generic] | No claim about your past. Think aloud: find out what they expected and what happened, check whether it is a known issue, try to reproduce it where you can, and hand it on with a clear summary if you cannot fix it. Say plainly that you would not guess about a product you have not used | F5 is the biggest gap, so the lead may test it as a live problem; CASE because it is a live problem |
| A3 | "Three tickets arrive together: a refund request, a customer locked out of their account, and an angry escalation from a long-standing customer. What order, and why?" | CASE | [generic] | No claim about your past. Say your ordering criteria aloud (who is blocked, who is losing money, who is waiting longest) and name what you would need to know that you do not. The order matters less than the reasoning. Concede that a team's own priorities may override yours | F4 raises escalations, and prioritisation is how a lead sees whether you stay calm; CASE |
| A4 | "Write the note you'd send when passing an escalated ticket to a senior colleague." | JD | [grounded] | No claim about your past. A good note is short and covers what the customer reported, what has been tried, what you need from the colleague, and by when. Write it in the chat | F4 is the likeliest requirement to be tested live, and a handover note shows both F3 and F4; JD with CASE delivery |
| A5 | "Make this clearer for a customer: 'Unfortunately we are unable to process your request at this time due to system constraints.'" | JD | [grounded] | No claim about your past. Rewrite it in plain words, say what happened and what the customer can do next, and keep it to two sentences. Briefly say what you changed and why | F3's requirement tested directly; JD because it scores the written-communication line |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is at an energy supplier. How will you cope supporting a software product you've never supported?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | **The highest-ROI rehearsal in this pack.** Hold: say it first and plainly: "I haven't worked for a software company." Then stay on what you said: three years as an advisor at an energy supplier, and Freshdesk every day. Follow-up one will be a version of "so what's different here?" Return to the same facts and say the plan. Follow-up two will push on technical depth. Concede specifically that you do not yet know the product or how technical its customers are, and say what you would ask in your first week. Answer slot: how you would learn a new product, in your own words, said as a plan and never as something already done. If you have not thought about it yet, say so plainly and say how you would start | F5 is a gap you have stated, and it is the one most likely to come up, so rehearsing it until it is calm changes the interview; JD because it scores the role's context |
| B2 | "Which part of this job would be weakest for you on day one?" | JD | [grounded] "I've never worked for a software company" | Give a real answer instead of a disguised strength. The one the material supports is the product and its customers: "I haven't worked for a software company." Follow with what you would do in the first two weeks. Answer slot: if a second area is also weak for you, name it plainly. If none comes to mind, say so and say how you would find out | The Skeptic's stem; F5 is the stated gap, so this question lands on it again |
| B3 | "The ad asks for confidence handling escalations. What have you handled?" | JD | [grounded] | No quote carries an escalation, so there is no story to map. Answer slot: if you have handled escalated cases, give one in the order it happened, what you did and what you handed on, in your own words. If you have not, or someone else handled them, say so plainly and say how you would handle one: listen, take ownership of the next step, set a time and follow up. Never describe a case that did not happen | F4 has no evidence in your material, and the question's premise is the ad's, so the guidance does not adopt it; JD |
| B4 | "Why move from energy to software support, and why now?" | VAL | [generic] | Your real reason in two or three sentences, framed as what you are moving toward. If there are two reasons, give the one that is true and relevant. If you have not settled on one, say so plainly and say what interests you about the work itself | The motivation probe every career switcher meets, tied to F5; VAL because it tests honesty about motive |
| B5 | "Have you used Zendesk specifically?" | JD | [grounded] "I use Freshdesk every day" | Answer slot: if you have used Zendesk, say where and how, in your own words. If not, say so plainly and return to what you said: "I use Freshdesk every day." Say which parts of it you actually use and which you have not touched. Do not claim Zendesk | The ad names Zendesk, and F2 shows Freshdesk. The slot's second branch lets the premise be false; JD |

### C. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey to here." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A short arc built on the three sentences: three years as an advisor at an energy supplier, Freshdesk every day, training four new starters on the refunds process last year. Each beat is what the quote says. Answer slot: why you are looking to move now, in your own words. If there is no single reason, say so plainly. Finish on what attracts you to this role | F1, F2 and F6 are the evidence the lead will build the picture from; EXP because it tests how your history is told |
| C2 | "What does a typical day in your current job look like?" | EXP | [grounded] "answering around 60 calls and emails a day" | Start from the quote: around 60 calls and emails a day. Answer slot: what the mix and the rhythm of the day were, in your own words. If it varied too much to describe, say so plainly. Keep the answer to what you actually did | F1 is the evidence for the experience requirement; this opens the door to F3 and F4; EXP |
| C3 | "What do you actually use Freshdesk for?" | EXP | [grounded] "I use Freshdesk every day" | Say what you use, in your own words, and name the parts you really use. If there are parts you have not used, say so plainly. Do not name features you have not touched | F2 is the ticketing-tool requirement, and a casual question like this is where it is checked; EXP |

### D. Data-Driven Prober (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say what the figure is and that it is approximate: the quote says "around". Answer slots: how it was counted, and what it is sensitive to, such as the mix of calls and emails, in your own words; the assumption you would defend least; which part was yours and which was the team's. If you do not know how it was counted, say so plainly. Never turn it into tickets or Freshdesk volume | F1 carries the only figure on the CV-style line, and figures get checked; EXP |
| D2 | "How did you decide what to teach the new starters, and how did you know it worked?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Start from the quote: four new starters, the refunds process, last year. Answer slot: if you decided what to cover and checked it afterwards, say how, in your own words. If the content was set by someone else, or you did not check, say so plainly and say what you would do now | F6 is the training evidence, and a prober checks the decisions behind it. The slot lets the premise be false; EXP |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who already works in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | Pause, then hold: three years as an advisor at an energy supplier, Freshdesk every day, four new starters trained on the refunds process. Hold through a second challenge by returning to the same facts. Concede the specific gap and nothing more: you have not worked for a software company. Do not claim anything about the other candidate | F1, F2, F6 are the evidence; F5 is the concession. The pressure persona tests composure; JD |
| E2 | "That training you mention. How much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold on the quote: you trained four new starters on the refunds process. Answer slot: say which parts were yours, in your own words. If the process and materials were set by others and you delivered them, say so plainly. Concede the exact limit and return to the quote | F6's attribution is what this probes; the premise comes from the quote; EXP |

### F. Values / Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you put a customer ahead of an internal target." | VAL | [generic] | No quote carries this story, so this is a selection scaffold: pick a time you made a decision for the customer that cost you something internal. It needs a named stake, what you chose and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem used as an open prompt; no published values were read, so it is `[generic]` |
| F2 | "Tell me about a time you had to deliver an unpopular truth." | VAL | [generic] | A selection scaffold: choose a time you told a customer or a colleague something they did not want to hear. It needs what was said, how you said it and what happened afterwards. If none comes to mind, say so plainly and give how you would approach it | A persona stem used as an open prompt; `[generic]` |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | C1, C2, D1, E1 |
| "experience with Zendesk or a similar ticketing tool" | B5, C3 |
| "clear written communication" | A1, A4, A5 |
| "confidence handling escalations" | A3, A4, B3 |
| Software context (not a JD line you quoted) | A2, B1, B2, B4, E1 |
| Sharing process knowledge (role-family) | D2, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone new to the product?" | It shows you are planning to close the F5 gap, and it gets the real onboarding picture |
| R2 | "Which ticketing tool does the team use, and how are escalations handled between tiers?" | It checks F2 and F4 in their terms and shows you care about how handover works |
| R3 | "How do you measure good support here, and what does the team find hardest to get right?" | It signals you think about outcomes, and the answer tells you how the lead thinks |
| R4 | "Who would I work with day to day, and what hours does the team cover?" | It is practical for a remote role and shows you are thinking about fit |
| R5 | "What are the next steps, and who will the offer and contract come from?" | A normal question that tells you how real the process is. A company with a real team answers it easily |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The limit is the pack's observation: your material says Freshdesk, not Zendesk. B5's slot stays on Freshdesk |
| Handled 60 tickets a day in Freshdesk | Inflated form of F1 | F1's quote at its own scope: "answering around 60 calls and emails a day". D1's slot asks only how it was counted |
| Designed or led the refunds training | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year". E2's slot asks which parts were yours |
| Has worked at a software company | A negative you stated, F5 | The plain acknowledgment: "I haven't worked for a software company." No slot |

## Sources

- Provided documents: your message (the Telegram message you pasted, the ad's requirements as you relayed them, and your background).
- Searches sent, all refused by the host before returning anything: "Lumenvale Software company values" (refused); "Lumenvale Software interview process Customer Support Specialist" (refused); "Lumenvale Software recruiter Telegram interview scam" (refused). No pages were fetched.

Research tier: L1 attempted — searches 3 of 6 sent and all refused, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The search was refused. It would have supplied official value names for a values cheat sheet, which is dropped for now |
| 2. `Lumenvale Software interview process` | unavailable | The search was refused. It would have shown whether this text-chat format matches any documented loop |
| 3. `Lumenvale Software strategy` / recent news | unavailable | No search was sent after the first refusals. It would have fed CO questions, which the pack does not have |
| 4. interviewer name | n/a | The team lead is not named, so there was no query to form |
| 5. representative Customer Support Specialist JD | skipped | The ad's requirements you gave fix the fit snapshot and the JD-tagged questions |
| (outside targets) company legitimacy check | unavailable | The search was refused; it would have shown whether the company and this hiring route can be verified |

## Upgrade menu

- Permission to search the web → values, loop structure and recent news become `[grounded]`. The values cheat sheet and CO questions would be added. A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is available once if you want it.
- The ad's full text → the four requirement rows quote the ad itself instead of your summary, and any requirement you did not mention gets its own question.
- The support team lead's name → an interviewer read and a reverse question about their path.
- An example of an escalation you dealt with, if there is one → F4 and B3 become story-mapped instead of answer slots.
- A real reply you wrote to a customer, with details removed → F3 moves from `low` to `medium` and A1 and A5 can be calibrated against it.
- Any Zendesk use → F2 and B5 change.
- Anything recruiter Marcus Hale told you about focus areas or a take-home → coverage beyond round-type assumptions.
- A saved `tuesday-dossier.md` from this prep would carry the gaps it exposed into later sessions, and nothing here depends on one.
