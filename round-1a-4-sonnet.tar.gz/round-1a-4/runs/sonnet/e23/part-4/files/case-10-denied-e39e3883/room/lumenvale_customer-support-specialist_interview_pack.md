# Interview pack: Customer Support Specialist, Lumenvale Software

Interviewer: support team lead (name not given). Round: first interview, text chat. Built from your message only (no CV, no JD text, no web research).

## How to use this pack

Personas are how a question is asked; types are what it scores. Types: VAL (values/behavioral), EXP (experience deep-dive), JD (role requirements), CO (company knowledge), CASE (live problem). The guidance is scaffolding, not a script. This is a text chat, so practise typing answers: short paragraphs, one clear point each, and no waffle.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad as you described it | "3 years as a customer service advisor at an energy supplier" — your message | high | [grounded] | none | Met on its face. Lead with it in your own words: three years as a customer service advisor at an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad as you described it | "I use Freshdesk every day" — your message | high | [grounded] | presentation | Freshdesk is the similar tool; the words stay at "I use Freshdesk every day". Do not say you have used Zendesk. If asked, say plainly that you have not, and what you would do to get up to speed |
| F3 | "clear written communication" — the job ad as you described it | "answering around 60 calls and emails a day" — your message | medium | [grounded] | transferability | Your material says calls and emails together, so it does not show how much was written. Answer slot: if a good share of the 60 were emails, say roughly how many; if it was mostly calls, say so and name where else you write (notes, case records, refund explanations) |
| F4 | "confidence handling escalations" — the job ad as you described it | none given | none | [grounded] | discovery | Your material does not mention escalations, so there is nothing to quote. Answer slot: if you ever took a case that another advisor or a customer had escalated, or passed one up, say what it was and what you did; if not, say so and describe how you would handle one |
| F5 | Software or SaaS background (not stated in the ad; a likely probe, `[generic]`) | "I've never worked for a software company" — your message | high | [grounded] | capability | A real gap that you have stated yourself. Say it in those terms and then give a plan for learning the product, never a claim to software experience |
| F6 | Training or mentoring (not required in the ad; a possible strength) | "I trained four new starters on our refunds process last year" — your message | high | [grounded] | none | Use it exactly as you said it. Do not describe yourself as a trainer or team lead |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Hiring manager / Case | Live ticket scenarios: an angry customer, a bug report, a refund dispute | High. A support team lead usually tests handling in real time, and a text chat lends itself to it | Practise typing a reply to a sample ticket in under 3 minutes |
| Skeptic | "You've never worked for software; why will this work?" | High. F5 is the obvious gap | Rehearse the concede-then-plan answer (B1) |
| Conversational / Rapport | Why this job, why leave energy | Medium. Common in a first chat | Short, honest motivation (A1) |

## Question banks

### A. Hiring manager / Rapport

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| A1 | Why customer support, and why a software company? | VAL | [grounded] | Build on your own words: "3 years as a customer service advisor at an energy supplier". Motivation for the move to software is an answer slot: say in your own words what draws you; if it is mainly the remote setup or the product type, say that honestly | Opens most chats; checks that the move is deliberate |
| A2 | Walk me through a typical day of 60 contacts. | EXP | [grounded] "answering around 60 calls and emails a day" — your message | Describe the mix, how you prioritised, and where Freshdesk fit. Keep it to what you did. Answer slot: the call to email split | Tests whether the volume claim survives questions |
| A3 | Tell me about training the new starters. | EXP | [grounded] "I trained four new starters on our refunds process last year" — your message | Say what the process was, how you taught it, and what happened to the four. Answer slot: how you taught it and how you knew they had understood | Shows teaching and process knowledge; stay within what you did |

### B. Skeptic

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| B1 | You've never worked for a software company. Why should we expect you to pick up a technical product? **Highest-ROI prep in this pack.** | JD | [grounded] "I've never worked for a software company" — your message | Hold: you have used a ticketing tool daily. Concede: "I haven't worked for a software company." Limit: do not claim technical knowledge you lack. Plan: how you learned the energy supplier's systems and billing processes is an answer slot. Say what you actually did, then how you would learn this product in your first weeks. Follow-up levels: what do you do when you cannot reproduce a bug; have you ever explained a technical thing to a non-technical customer | This is the gap most likely to be probed, and it is real, so the concession should be calm and specific |
| B2 | Have you used Zendesk? | JD | [grounded] "I use Freshdesk every day" — your message | "I use Freshdesk every day, not Zendesk." Then name two or three things you do daily in Freshdesk. Answer slot: which features, such as macros, tags, SLAs or reports | A direct probe of F2; any overreach here is easily caught |
| B3 | Tell me about a time you handled an escalation. | EXP | none given | Your material does not mention escalations. Answer slot: if you have one, give the situation, what you did and the outcome, in your own words. If you have not, say so and describe how you would handle one: listen, take ownership, set expectations, hand over with full notes | Escalation confidence is a stated requirement and has no evidence yet, so settle on a true example before the interview |

### C. Case / Pressure

| ID | Question | Type | Provenance | Guidance | Rationale |
|---|---|---|---|---|---|
| C1 | A customer says the app has been down for two days and wants a refund and to speak to a manager. Reply now. | CASE | [generic] | Structure: acknowledge, apologise for the impact without over-promising, gather details (what, since when, device, error), set a next step with a time, and say what you will escalate and what you will not. Do not promise a refund you cannot authorise. Your refunds knowledge is relevant, but only as far as you actually handled refunds | Typical live test; a text chat makes it very likely |
| C2 | You have 30 tickets and 3 are urgent. What first? | CASE | [generic] | Say your triage rule (impact, deadline, customer waiting longest) and when you would ask for help. Tie it to how you handled 60 contacts a day only where true | Tests judgement under volume |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | What does a good first 90 days look like for this role? | Shows you plan to learn the product quickly (answers B1 from the other side) |
| 2 | Which tools does the team use, and how is training on the product handled? | Practical, and tests whether onboarding is real |
| 3 | How are escalations handled and who do they go to? | Shows interest in the part of the role you have least evidence for |
| 4 | What does the team's weekly volume and mix look like? | Shows you think in workload terms |
| 5 | How is performance measured? | Tells you what the role will be like |
| 6 | Is the role fully remote, and what hours and coverage are expected? | Confirms the terms before an offer |
| 7 | Can you tell me your company's registered address or website, and which team email I can confirm this process with? | Verification (see the message). A real employer will answer without fuss |

## Prohibited claims

| Claim | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | You said Freshdesk | "I use Freshdesk every day." |
| Software or SaaS experience | "I've never worked for a software company" | Concede it, then give a learning plan |
| Experience with escalations | Not in your material | Answer slot (B3), or say you have not and how you would |
| Being a trainer or team lead | You said you trained four new starters on one process | "I trained four new starters on our refunds process last year." |
| Specific figures beyond "around 60 calls and emails a day" | Not in your material | Use only what you can back up |

## Sources

Provided: your message and the Telegram message. No searches or fetches were run (web search was not permitted). Research tier: L0.

| Target | Run |
|---|---|
| Official values | skipped |
| Loop structure | skipped |
| Recent strategy | skipped |
| Interviewer footprint | n/a (not named) |
| Representative JD | skipped |

## Upgrade menu

- The full job ad text → the F1 to F4 requirement quotes become the ad's own words instead of your summary
- Your CV → more of the fit snapshot rows get quoted evidence, and the answer slots can be filled
- The interviewer's name and the round format (live chat or asynchronous) → reweighted personas and a tailored reverse question
- Lumenvale's published values or product description → a values cheat sheet and company-knowledge questions
