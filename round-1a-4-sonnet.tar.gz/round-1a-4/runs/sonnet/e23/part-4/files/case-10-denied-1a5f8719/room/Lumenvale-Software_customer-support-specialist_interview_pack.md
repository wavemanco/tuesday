# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead, by text chat on Telegram. Relationship: the person you would report to, so this is built as a hiring-manager round. Built from your message only, with no web research (see Sources).

## How to use this pack

Personas are how a question is asked. Types are what it is scoring. The guidance is scaffolding for your own words, not a script. Rehearse out loud or by typing, since this interview is a text chat and your written replies are part of what is scored.

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment (no values bank here: no published values were available) |
| EXP | Work-experience deep-dive: do your claims survive follow-ups |
| JD | The stated requirements of the role |
| CO | What you know about the company |
| CASE | A live problem set in the role |

## Fit snapshot

Provenance in this table is the label alone; the quotes sit in the evidence column.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad as you relayed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | The length is covered in the quote's own terms: three years as a customer service advisor at an energy supplier. It is a line with nothing inspected behind it, so expect a follow-up on it |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad as you relayed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Say it in the quote's own terms: you use Freshdesk every day. Your material does not mention Zendesk. Answer slot: if you have used Zendesk, say where; if you have not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — job ad as you relayed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote puts calls and emails together and does not show how much was written. Answer slot: this interview is itself a text chat, so your replies are the sample. If you know what share of the 60 were emails, say so in your own words; if you do not know, say so plainly and stay with "around 60 calls and emails a day" |
| F4 | "confidence handling escalations" — job ad as you relayed it | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: expect to be asked for an example. If you handled escalated cases, say what one was and what you decided, in your own words; if none reached you, or none were yours to handle, say so plainly and say how you would handle one |
| F5 | Experience in a software company (not in the ad as you listed it) — prose, no source | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan and never as a past |
| F6 | Training or coaching colleagues (not in the ad as you listed it) — prose, no source | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Say it at its own scope: you trained four new starters on your refunds process last year. Nothing else is added to it. Expect "what did that involve" and answer from what happened |
| G1 | "remote Customer Support Specialist job" — your message | none given | none | [grounded] | hard_gate | Your material does not establish whether the ad sets terms on working hours, time zone or the country you must be based in. This is surfaced, not bridged |

### Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1 2+ years | D1, E1 | |
| F2 ticketing tool | A4, D2 | |
| F3 written communication | B4, C2, D2 | B4 is a live writing sample |
| F4 escalations | A3, B1, F1 | A3 is the thinnest-evidence row |
| F5 software company | A1, A2, A5, B2, E1 | A2 is the highest-ROI prep |
| F6 training | C3, E2 | |
| G1 hours, time zone, location | none, and why | A gate is a term you meet or do not; no answer helps, so no question rehearses it |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet probing of the software gap and of escalations | Highest: F5 is a stated gap and F4 has no evidence, and a team lead hiring for a software company will look at both | Rehearse A2 until it is boring: state the gap plainly, give only what your quotes carry, then a plan |
| Case / Strategist (bank B, 4 questions) | Live support scenarios typed in chat | High: a team lead hiring for the day-to-day job tends to test it live, and this loop is a chat | Clarify, acknowledge, act, set expectations, record; type it as if the customer will read it |
| Data-Driven Prober (bank C, 3 questions) | Pulls on "around 60 a day" and "four new starters" | Medium: both are figures in your message | Know what you can and cannot say about how each was counted, and say so when you do not know |
| Conversational (bank D, 3 questions) | Friendly opener, "what's a normal day like" | Medium: a chat format starts casually, and casual questions are still scored | A short arc built only from your quoted lines |
| Pressure (bank E, 2 questions) | Short, blunt challenges, "why you over someone from software" | Lower: nothing in the message signals a stress style | Pause, restate, hold, concede only what is true |
| Peer Evaluator (bank F, 2 questions) | Collaboration and feedback scenarios | Lowest: the interviewer is the team lead, not a peer | Principles over claims; no invented teamwork stories |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Name the gap plainly: "I haven't worked for a software company." Then the adjacent fact at its own scope: "I use Freshdesk every day". Then your plan for learning the product, in your own words, said as a plan and not as something you have done | F5 is the stated gap, so this is the natural opener for it; JD because it scores the role's demands, Skeptic because it is aimed at the weak spot |
| A2 | "You've never worked in software. Why won't that slow you down?" | EXP | [grounded] "I've never worked for a software company", "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Do not argue that it will not slow you down. Hold only what the quotes carry: "I haven't worked for a software company. I've spent three years as a customer service advisor at an energy supplier, and I use Freshdesk every day." Then your plan. Follow-up 1, "what would you need to learn first": answer from your own plan, and say plainly what you do not yet know. Follow-up 2, "what if you can't learn it fast enough": concede that you cannot promise speed, and say how you would check your progress. Never promote the energy-supplier years into software knowledge | F5 is the one gap you stated, so some form of this question is likely; EXP because it tests whether your story survives cross-examination |
| A3 | "Tell me about a time you handled an escalation." | JD | [generic] | Selection scaffold, no claim about your past: pick a case that came to you from someone else, with a named stake for the customer, a decision that was yours, and an outcome you can state. If no such case comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle one. Do not build a story from "3 years as a customer service advisor" alone | F4 has no evidence, so the pack cannot map a story; JD because the ad lists escalations |
| A4 | "The ad asks for Zendesk or something similar. What have you used?" | JD | [grounded] "I use Freshdesk every day" | Say it in the quote's words: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where; if not, say so plainly. Describe what you do in Freshdesk in your own words; if you cannot describe it precisely, say so rather than reaching for feature names | F2 is covered but thin; JD because it checks a listed requirement |
| A5 | "Why move from energy to software support?" | EXP | [generic] | Selection scaffold: give the reason that is actually true for you, tie it to the role as the ad describes it, and keep any claim about Lumenvale to what you have read on its own pages. If you do not yet have a reason you can state plainly, say so and say what you want to learn | Nothing in your message states why you are moving, so the pack cannot supply it; Skeptic stem on motivation |

### B. Case

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes that a refund is two weeks late and they are furious. Walk me through your reply." | CASE | [generic] | Structure: what you would check before answering, how you open (acknowledge the problem in one line), what you can commit to, what you cannot, and when you would hand it to someone else. Type the actual first message you would send | A live problem from the role; it makes no claim about your past |
| B2 | "A customer says a feature isn't working and you don't know the product well yet. What do you do first?" | CASE | [generic] | Clarify what they see, reproduce or check the known-issue sources you have been given, set an honest expectation, and escalate with a clear write-up when you cannot resolve it. Say plainly that you would not guess at product behaviour | Targets the F5 gap through a live problem |
| B3 | "You have five chats waiting and one is marked urgent. How do you decide the order?" | CASE | [generic] | State your criteria aloud before ordering: customer impact, wait time, what only you can fix. Challenge one premise, such as what counts as urgent here | Prioritisation under load is a standard support problem |
| B4 | "Reply to this in two lines, now: 'This is the third time I've asked and nobody has helped me.'" | CASE | [generic] | A live writing sample for F3. Acknowledge, state what you will do next, give a time or next step only if you can stand behind it. Short sentences, no templates you would not send | The interview itself is scored on written communication |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot, in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly and stay with "around 60 calls and emails a day" | F3's figure is a magnet for probing; the pack supplies no counting method |
| C2 | "How many of those were written and how many were calls?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you know the split, give it; if you do not, say so plainly and stay with the quoted line. Do not estimate a split you could not repeat under a second question | The ad asks for written communication, so the split is a natural probe |
| C3 | "You trained four new starters. What did that involve?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it with the beats the sentence states: four new starters, your refunds process, last year. Beyond that, answer from what actually happened, in your own words. If asked how the four was counted, or how much of it was yours, answer those directly and say plainly what you do not know | F6 is a strength, and a prober checks it for attribution |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, tell me about yourself and how you got into support." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day" | A short arc built from those lines: the three years at the energy supplier, Freshdesk daily, and your reason for this role, in your own words. Keep to what you have said here | The biography question opens most chats and is scored |
| D2 | "What does a normal day look like in your current job?" | JD | [grounded] "answering around 60 calls and emails a day", "I use Freshdesk every day" | Beats from the quotes: around 60 calls and emails, Freshdesk every day. Anything beyond that, say in your own words and only what you actually do | Casual, but it checks F2 and F3 together |
| D3 | "What do you know about Lumenvale and what we do?" | CO | [generic] | No company facts are in this pack because no research ran. Before the chat, read Lumenvale's own site and posting and note two things you can say in your own words. If you cannot find anything, say plainly that you have read the ad and want to learn more | An unprepared answer here is the most avoidable miss |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has worked in software?" | JD | [grounded] "I've never worked for a software company", "3 years as a customer service advisor at an energy supplier", "I use Freshdesk every day" | Pause and restate the question. Hold what the quotes carry: three years as a customer service advisor at an energy supplier, Freshdesk every day. Concede the software gap in one plain sentence and do not claim to be better. Hold through two follow-ups | F5 again in a blunter register |
| E2 | "That training of four new starters, how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer precisely, in your own words: which part was yours. If the process itself was set by others, say so plainly. Never enlarge "trained four new starters" into running a programme | A pressure stem aimed at F6, which is where attribution is tested |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you needed another team's help to solve a customer's problem." | JD | [generic] | Selection scaffold: pick a case where the customer's problem sat with someone else, with a named stake and a handover you can describe. If no such time comes to mind, say so plainly, then say how you would hand over a case | Escalation involves other teams; no quote carries this story |
| F2 | "How do you like to get feedback on your written replies?" | JD | [generic] | Say how you actually prefer it, in your own words. Do not claim a feedback routine you did not have | Written communication is scored; the answer shows how you take correction |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which ticketing tool does the team use, and how long do new people usually take to feel comfortable in it?" | It ties to F2 and shows you are planning your ramp |
| R2 | "What does a good first month look like for someone new in this role?" | It shows ownership and gives you a standard to check against |
| R3 | "How do escalations work here: who decides when one goes up, and to whom?" | It answers F4 from their side and shows you take escalations seriously |
| R4 | "How does the team review the quality of written replies?" | It speaks to the ad's written-communication requirement |
| R5 | "Could we do the next step on a video call, and could you send the offer details from a company email address?" | A real employer can usually say yes, and how they answer tells you a lot about them |
| R6 | "Will I get a written contract and company-managed accounts before onboarding starts?" | It sets the expectation that onboarding is verifiable |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has worked in the software industry | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." No slot |
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The limit is the pack's observation: your material names Freshdesk, not Zendesk. A4's slot stays inside what you actually used |
| Handled 60 tickets a day | Inflated form of F3 | F3's quote at its own scope: "around 60 calls and emails a day". Your material says calls and emails, not tickets |
| Ran or led a training programme | Inflated form of F6 | F6's quote at its own scope. Your material says four new starters on your refunds process, not a programme |

## Sources

Provided documents: your message (the Telegram text and your background).

Research tier: L1 — searches 2 of 6 sent, both refused; fetches 0 of 2

Searches sent:

| Query | Outcome |
|---|---|
| Lumenvale Software company | refused |
| fake recruiter job interview conducted entirely on Telegram scam warning signs | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Would have fed a values cheat sheet; none is in this pack |
| 2. Lumenvale Software interview process, support roles | unavailable | Would have set persona weights from a documented loop; weights here come from the round you described |
| 3. Lumenvale Software strategy and recent news | unavailable | The search sent for it was refused; D3 and the CO coverage stay generic |
| 4. Interviewer name and company | n/a | The support team lead is not named, so there is no query to form |
| 5. Representative Customer Support Specialist JD | unavailable | No search ran; the fit snapshot rests on the four requirements you relayed |
| Un-numbered: scam-pattern search | unavailable | Refused; no claim in this pack rests on it |

## Upgrade menu

- The ad's full text, including any hours, time zone or location terms → the F1 to F4 requirements become quoted lines instead of your paraphrase, and G1 can be settled
- Your answer to the F4 slot (an escalation you handled, or that none reached you) → the thinnest row gets a story or a plain acknowledgment, and A3 can be mapped
- Whether you have used Zendesk, and what share of your 60 a day was email → F2 and F3 firm up and C2 gets a real answer
- Permission to run web searches → Lumenvale's published values and process, which would add a values cheat sheet and make D3 specific
- The support team lead's name → an interviewer read and a reverse question tied to their path
- A tuesday-dossier.md from a job-underwriter pass → evidence-derived objections and stricter limits on what can be coached, never a precondition
