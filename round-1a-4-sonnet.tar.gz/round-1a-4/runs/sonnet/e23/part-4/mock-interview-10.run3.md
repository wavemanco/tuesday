Web search was denied, so I'm building the pack from your message alone. I'm checking the persona definitions before I write it.
**Before you reply to Marcus: this has the pattern of a recruitment scam, so please verify it first.** I'm not saying it is one. I couldn't check whether Lumenvale Software exists, because my web searches were denied. But these features match known fake-recruiter schemes:

- **Everything happens on Telegram.** The interview, the offer and the onboarding are all in one chat. Real software companies use company email, an applicant-tracking system and a video or phone call.
- **Onboarding in a chat app is where these scams usually collect money or documents.** Typical asks are ID scans, bank details, a fee for "equipment" or "training", or paid "tasks".

Before you give a time:
1. Go to Lumenvale's own website, typed in yourself, and check that the role is listed and that your application went through that site.
2. Contact the company through the email or phone number on that site, and ask whether Marcus Hale works there and whether they interview on Telegram.
3. Ask for a video or phone call, and for written messages from a company email address.

Until you've done that, don't send ID, bank details or any payment, and don't click links. A safe reply would be: *"Thanks, Marcus. Could you confirm this from your Lumenvale email address and offer a video call for the interview? I'd like to verify the process before sharing details."* A real employer will say yes without fuss.

The prep is still worth doing, because the questions will be similar whether the interviewer is real or not. I saved the pack at `/var/tmp/tuesday-measure/1a4/runs/sonnet/e23/part-4/rooms/case-10-denied-21d99a39/Lumenvale_customer-support-specialist_interview_pack.md`. It assumes the support team lead would be your manager and uses only your message, with no research.

- **Your strengths:** the 3 years, the daily Freshdesk use and the four people you trained are covered by what you told me. The ad says "or a similar ticketing tool", so Freshdesk fits. I didn't coach any Zendesk claim.
- **Two thin spots:** escalations (F4) and written communication (F3). Your message doesn't show either, so the pack gives you honest "if you did this, say how; if not, say so plainly" answers instead of invented stories.
- **Highest-ROI prep:** question B1, "Why would you be able to support software customers?" You've said you've never worked for a software company, so rehearse that one most. The pack gives you a hold-then-concede answer that stays within what you've told me.
- **Chat format:** a text interview is also a live writing sample. Practise short, complete sentences.
- **Reverse questions:** the pack includes some that double as verification, such as asking for a contract and a call on a company platform.

I can play the Skeptic on B1 as a live drill, or save a `tuesday-dossier.md` of the gaps this prep exposed. I can also convert the pack to Word.

Can you paste the full text of the job ad? It would turn the requirement rows into exact quotes and show whether I missed anything.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Lumenvale_customer-support-specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist (remote), Lumenvale Software

Round: text-chat interview with the support team lead, via Telegram. Built on the assumption that the team lead is the person you would report to, so this is weighted as a hiring-manager round. The interviewer is not named.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for your own words, not a script. Every quote below comes from your message.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values (none detected here, so no VAL questions) |
| EXP | Whether what you have told them survives scrutiny, and what was actually yours |
| JD | Whether you can do the job as the ad lists it, including its gaps |
| CO | Company and strategy knowledge (none here: no research could run) |
| CASE | A live problem from the role, answered on the spot |

Because the interview is a text chat, your written answers are also a live writing sample for the "clear written communication" requirement. Short, complete sentences beat long blocks.

## Fit snapshot

Requirements are the job ad as you described it in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you described it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | The quote already reaches the requirement. Lead with it in its own terms: for three years you were a customer service advisor at an energy supplier. It is a message line with nothing inspected behind it, so expect a probe on it |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | none | The ad's own wording allows a similar tool, and the quote names one: "I use Freshdesk every day." Your material does not mention Zendesk, so the pack coaches no Zendesk claim |
| F3 | "clear written communication" — job ad, as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are written work, but the quote does not show whether anyone judged the writing. Answer slot: the ad names written communication, so expect a probe on it. If any of your replies were reviewed, templated or scored, say what happened, in your own words; if none were, say so plainly and say how you approach writing a reply |
| F4 | "confidence handling escalations" — job ad, as you described it | none given | none | [grounded] | discovery | Your material does not show escalation work either way. Answer slot: if you handled or passed on escalated cases, say what the situation was and which part was yours; if escalations went elsewhere, or you did not handle them, say so plainly and describe how you would handle one |
| F5 | Comfort learning a software product and supporting software customers — plain prose, no source supplied | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap you stated yourself, so the words are yours: "I haven't worked for a software company." Then how you would learn a product, said as a plan and never as a past |
| F6 | Training or supporting colleagues — plain prose, no source supplied | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | Not in the ad as you described it, so a small plus. Say it in the quote's own words. Expect a probe on which part was yours (see B3) |

## Persona table

| Persona | How it shows up in a text chat | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live ticket scenarios: "a customer writes in angry, what do you send?" | Highest. A team lead hiring for a support role buys capability with live problems, and the hiring-manager prior favors this | Structure each answer in the same order: acknowledge, ask, act, record, hand off. Claim nothing about your past in a case answer |
| B. Skeptic | "You have never worked in software", "where is your escalation experience?" | High. F5 and F4 are the visible gaps, and a derisking interviewer goes there | Hold what your quotes carry through two follow-ups, then concede the specific gap |
| C. Conversational | Motivation, a typical day, why leave | Medium. The invitation came from a talent team in a friendly register | Plain, specific, short. Do not run down your employer |
| D. Data-Driven Prober | "Around 60 a day: how counted?" | Low to medium. Your CV-style lines carry two figures: 60 a day and four trainees | Know how each figure was counted, or say plainly you do not |
| E. Pressure | "Why you over someone from software?" | Low. Text chat blunts interruption, but a blunt challenge is still plausible | Pause, restate, hold, concede only the true gap |

Highest-ROI prep in this pack: B1, the software-company question. It will be asked in some form, and it is aimed at the one gap you have named yourself.

## Question banks

### A. Case/Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same billing error and says they will cancel. Write me the reply you would send." | CASE | [generic] | Write it in the chat, as the answer. Structure: acknowledge the repeat, say what you are doing now, give a next step with a time, say what you will record, and when it goes to someone else. Make no claim about your past | A live written problem that tests F3 directly. CASE because it asks for a reply, not a story |
| A2 | "A customer demands a manager and the fix is above what you may approve. What do you do?" | CASE | [generic] | Structure: what you ask first, what you tell the customer, what you pass on so they do not repeat themselves, how you follow up. If you have passed cases on, say so in your own words; the structure does not need it | The ad's escalation line (F4) turned into a decision, so it needs no past |
| A3 | "An outage hits and fifteen tickets arrive at once. Which do you take first?" | CASE | [generic] | Say the order and why: safety or money at risk, then widest impact, then oldest, with a single holding reply for the rest. Name the one thing you would ask the team lead | Tests prioritization under load; generic because it is a pattern, not a fact about Lumenvale |
| A4 | "A customer says our export button does nothing. You have never seen that feature. What are your first three replies?" | CASE | [generic] | Ask for what they see and where, check internal notes or a colleague, set an honest expectation, never guess at how the product works. It rehearses F5 as a method | The software-product gap (F5) as a live problem, where a method answer is the strongest evidence you can give |
| A5 | "Our tool is Zendesk. You said Freshdesk. How would you get up to speed?" | JD | [grounded] "I use Freshdesk every day" | Say it plainly: "I use Freshdesk every day." Answer slot: the ad names a ticketing tool, so expect a probe on which parts you use. Name them in your own words; if you use only the basics, say so. If you have used Zendesk, say when; if not, say so and describe how you would learn it | F2 is solid on the ad's own wording, and the probe is on depth. JD because it scores the stated requirement |

### B. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have worked at an energy supplier. Why would you be able to support software customers?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" and "I've never worked for a software company" and "I use Freshdesk every day" | Hold only what the quotes carry: "I haven't worked for a software company. For three years I was a customer service advisor at an energy supplier, and I use Freshdesk every day." Hold through two follow-ups by returning to those sentences, never by adding to them. Concede the specific gap: you have not supported a software product. Then give a learning plan as a plan, in the future tense | The deepest rehearsal in the pack. F5 is the gap you stated, and the question is aimed straight at it |
| B2 | "Tell me about a time you went beyond the standard process for a customer." | EXP | [generic] | Selection scaffold: pick a time with a named customer problem, a point where the standard process did not fit, a decision you made, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Open prompt; the theme comes from the ad's escalation line (F4). EXP because it tests what was your own judgment |
| B3 | "Four new starters: walk me through what you did with them." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Open with the quote in your own words. Answer slot: the figure raises its own questions. Say how the four were counted, what the number depends on, and which part was yours rather than following existing material. If you do not know how something was counted, say so plainly | F6 is the evidence, and a probe on "which part was you" is the standard check on a training claim |
| B4 | "The ad asks for confidence with escalations. How have escalations come up in your work, if at all?" | JD | [grounded] | Answer slot: if you handled or passed on escalated cases, say what the situation was and which part was yours; if you did not, say so plainly and describe how you would handle one, using the A2 structure | F4 is silent in your material, so the honest branch has to be ready |
| B5 | "Your day was calls and emails. How would I know you write well?" | JD | [grounded] "answering around 60 calls and emails a day" | Say the quote in your own words, then use the moment: this chat is itself a writing sample. Answer slot: if any of your written replies were reviewed or scored, say what happened; if none were, say so plainly | F3 is the thinnest requirement and the interview format makes it testable live |

### C. Conversational (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What drew you to this role?" | JD | [generic] | Give your true reasons in two or three sentences. If the real reason is moving into software or working remotely, say so plainly. Do not praise Lumenvale in specifics you have not verified | Motivation is asked in some form in almost every round |
| C2 | "Walk me through a typical day." | EXP | [grounded] "answering around 60 calls and emails a day" | Use the quote's own words, including "around". Answer slot: if you know how the day split between calls and emails, say so; if it varied, say that | Warm-up that still checks F1 |
| C3 | "Tell me about a customer you were glad you helped." | VAL | [generic] | Selection scaffold: a named problem, what you did, what changed for the customer. If none comes to mind, say so plainly and describe how you try to leave a customer | Rapport question; VAL by flavor only, since no published values were available |
| C4 | "Why are you looking to leave your current job, and what are your pay and notice expectations?" | JD | [generic] | Give the true reason without criticizing your employer, a range you have checked against market pay, and your actual notice period | Logistics asked in a friendly register |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Around 60 calls and emails a day: is that an average or a peak, and how was it counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say what the quote says: around 60 a day. Answer slot: say how the number was counted, what it depended on, which part of it you would defend least, and what was yours. If you do not know how it was counted, say so plainly | The headline figure in your material, so it gets a defend-the-number question |
| D2 | "What was different about your job in year three compared with year one, if anything?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Answer slot: if your responsibilities or results changed, say what and when, in your own words; if nothing changed, say so plainly and describe what you got better at | Tests whether three years was three years of the same year |
| D3 | "How do you know whether you are doing well in a support role?" | JD | [generic] | Name what the role's team would measure, such as response time, resolution and customer satisfaction. Answer slot: if your employer measured you on any of them, say which; if not, say so | A role-family question on measurement |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Why you over a candidate who has supported software before?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day" and "I've never worked for a software company" | Hold: three years as a customer service advisor and daily Freshdesk use, in those words. Concede once, specifically: "I haven't worked for a software company." Do not claim you are better, and do not fold on the held sentences | The Skeptic's question with the clock on |
| E2 | "What would your first two weeks look like?" | CASE | [generic] | A plan, in the future tense: learn the product, learn the tool, read past tickets, shadow, ask for feedback on early replies. Make no claim about your past | Tests whether you can plan your own ramp, which is the F5 gap |

## Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in customer support (F1) | B1, C2, D2, E1 |
| Zendesk or similar ticketing tool (F2) | A5, B1, E1 |
| Clear written communication (F3) | A1, B5 |
| Confidence handling escalations (F4) | A2, B2, B4 |
| Software product comfort (F5) | A4, B1, E1, E2 |
| Training (F6) | B3 |
| Company and strategy (CO) | none, because no research could run |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like for this role?" | Shows you are thinking about results and gives you the real expectations |
| R2 | "What is the ticket mix between product questions, billing and bugs, and what is the escalation path to engineering?" | Shows you are already thinking about the software side, which is your gap |
| R3 | "Which help desk do you use, and how are written replies reviewed?" | Targets F2 and F3 and tells you what the job really is |
| R4 | "Who would I report to, and how big is the team?" | A basic fact a real hiring team can answer instantly |
| R5 | "Before an offer, could I have a call on a video platform and the contract in writing from a company email address, and what would onboarding involve?" | Any real employer will say yes without hesitation, and the answer tells you whether this process is real |
| R6 | "How does the team handle coverage across time zones for a remote role?" | Practical for a remote role and shows you have read the ad |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with a software company | Negative you stated, F5 | "I've never worked for a software company" is your own sentence. Plain acknowledgment: "I haven't worked for a software company." Nothing else is claimed |
| Zendesk experience | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material names Freshdesk, not Zendesk |
| Designing or leading a training programme | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is the pack's observation: your material says you trained four people, not that you built the programme |
| Strong written communication proven by email volume | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day." The limit is the pack's observation: the quote shows volume, not that the writing was judged |

## Sources

Provided: your message (the Telegram text and your background, quoted above). The ad is known only through your description, not its full text.

Searches sent: "Lumenvale Software company careers" — refused. "fake recruiter Telegram job interview scam onboarding in chat warning signs" — refused. The host did not grant search permission, so nothing about Lumenvale could be checked and nothing in this pack comes from research.

Research tier: L1 attempted — searches 0 of 6 returned (2 sent, both refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Search permission was not granted. Would have fed a values cheat sheet, if a values round exists |
| 2. `Lumenvale Software interview process customer support` | unavailable | Search permission was not granted. Would have confirmed the loop structure and persona weights |
| 3. `Lumenvale Software strategy` / recent news | unavailable | Search permission was not granted. Would have supplied a company-knowledge question |
| 4. `interviewer name Lumenvale Software` | n/a | The support team lead is unnamed, so there is no query to form |
| 5. representative `Customer Support Specialist` JD | unavailable | Search permission was not granted. Would have upgraded the requirement rows to quoted ad text |
| Un-numbered: `Lumenvale Software company careers` | unavailable | Refused. Would have checked whether the company and the role exist |

## Upgrade menu

- The full text of the job ad → the F1 to F4 requirements become verbatim quotes, and any mid-list item the summary dropped gets a question
- The support team lead's name → an interviewer read, tuned persona weights and a reverse question tied to their path
- Permission to search → company values, loop structure, a strategy question and confirmation that the company and role exist
- Your answers to the slots in F3, F4 and B3 → those rows move from discovery to quoted evidence and the guidance gets specific
- A tuesday-dossier.md from job-underwriter → verified evidence and prohibited-claims constraints, though the pack never depends on it
