I've read the skill's rules. Now I'm running the employer check, a pay check for the role and a check on the team lead's public professional profile, so the verdict rests on sources.
**Yes, worth applying. Status: `go`.** You meet both gates (R1, R2) and have direct or adjacent evidence on the core duties. The gaps (R4, R6b, R8, R9) are things your CV doesn't say, not things you can't do, and R11 is the only absent row.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R6a, R7 · adjacent: R5 (wound and leg-ulcer care), R10 (small caseload of your own) · unclear: R4 (clear, timely written records), R6b (continence care), R8 (care planning), R9 (end-of-life visits)
- `preferred`: absent: R11 (Doppler assessment)

R5 — pressure and surgical wounds shown, leg ulcers not; R10 — home visits shown, own caseload not; R4, R6b, R8, R9 — your CV is silent and each is recoverable; R11 — absent, and the advert marks it desirable.

**Opportunity ledger.** The role looks sound. The caseload is supported by a senior nurse (RR2), the pay brackets the market median (RR3), and the team lead has publicly spoken about training staff new to community work (RR4). Open points: I couldn't confirm the posting is live (RR1), and the working pattern is unstated (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions:** none required. Before you invest effort, confirm the post is still open (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract, founded 2015, 410 staff, four locality hubs | `[grounded]` About page (calderbrookhealth.example/about) |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` advert |
| Scope read | A small own caseload with a senior community nurse behind you reads as a supported entry post, not a solo one | `[inferred]` from "small caseload" and "supported by a senior community nurse" |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. She has spoken on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott) |
| Market calibration | Band 5 community staff nurse, England: median basic pay £34,300, interquartile range £32,400 to £36,600. The advert's £31,050–£37,800 spans that range and sits near the middle. Pool cars are uncommon in the survey, so that offer is a plus | `[generic]` Wardround 2026 pay guide (n=1,240); `[grounded]` advert for the advertised figures |
| Unknowns | Working pattern and weekend rota; starting caseload size; Doppler and induction training; whether the post is still open | `[grounded]` advert silence on each |
| Contradictions | Mileage is listed alongside pool cars without saying when each applies. I couldn't compare the advert to the careers page | `[grounded]` advert; careers fetch returned nothing |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration, Adult Nurse | hard_gate | direct | medium | none | Your CV states PIN 19F4417X, active, revalidation due March 2028. Self-reported and not yet checked on the NMC register | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Not inspected | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | CV gives five years as a staff nurse on an acute medical ward | `[grounded]` CV | none |
| R4 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | The CV never mentions records or electronic systems. Five years on a ward and a home-visiting secondment are indirect context. I won't assert a documentation practice you didn't state | `[grounded]` CV silence | G3 |
| R5 | Wound and leg-ulcer care | must_have | adjacent | medium | transferability | Pressure ulcers and surgical wounds carry over. Leg-ulcer care, such as compression therapy, is not stated, which is the limit | `[grounded]` CV | G2 |
| R6a | Catheter care | must_have | direct | medium | none | CV lists catheter care | `[grounded]` CV | none |
| R6b | Continence care | must_have | unclear | low | discovery | CV lists catheter care but not continence care as such | `[grounded]` CV silence | G2 |
| R7 | Insulin administration | must_have | direct | medium | none | CV lists insulin administration | `[grounded]` CV | none |
| R8 | Care planning | must_have | unclear | low | discovery | The CV doesn't mention care planning. The discharge-to-assess secondment is context only | `[grounded]` CV silence | G3 |
| R9 | End-of-life visits | must_have | unclear | low | discovery | The CV doesn't mention palliative or end-of-life care. An acute medical ward may involve it, but I won't assume that for you | `[grounded]` CV silence | G1 |
| R10 | Hold a small caseload of your own, supported by a senior nurse | must_have | adjacent | medium | transferability | 18 months visiting patients at home in their first week after discharge carries over. You've said you have never held your own caseload, which is the limit | `[grounded]` CV and your statement; `[generic]` that a supported small caseload is a usual entry route | G4 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You've said you have never done one. The team lead has spoken on Doppler training for staff new to community work, but whether this employer trains new starters is unknown | `[grounded]` your statement and forum page | closure path: ask about training (RR4); minor risk as the advert marks it desirable |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R9, must_have) | discovery | The CV is silent on palliative or end-of-life care | It is a named duty, so a confirmed example turns an unknown into a strength | Caring for dying patients on the ward; supporting a rapid discharge home to die; syringe-driver or anticipatory-medication work; supporting a family at the end of life | A reflective account, a training certificate, a competency sign-off | `[grounded]` CV silence; `[inferred]` that an example would move R9 |
| G2 | Leg-ulcer and continence care (R5, R6b, must_have) | discovery | Wound and catheter care are stated; leg ulcers, compression and continence are not | These are the two duties closest to the advert's headline work | Applying compression bandaging; ankle-brachial or Doppler observation by others; bladder or bowel care plans; continence assessment | A competency record, a compression training certificate | `[grounded]` CV; `[inferred]` that it would close or narrow both rows |
| G3 | Care planning and electronic records (R8, R4, must_have) | discovery | Neither appears in the CV | The advert asks for clear, timely records on an electronic patient record, and these rows are cheap to resolve | Writing care plans on discharge; the electronic system your trust uses; audits of your documentation; discharge summaries you wrote | A documentation audit, a competency sign-off, a system name | `[grounded]` CV silence |
| G4 | Own caseload (R10, must_have) | transferability | Home visits are shown but not ownership of a caseload | It is the main stretch in the role, and the advert says you'll be supported | A named group of patients you followed up across several visits during the secondment; planning your own visit day | A secondment job plan or a supervisor's note | `[grounded]` CV and your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting liveness not confirmed | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The advert may have closed or may not appear on the employer's own careers page. The employer exists, but I couldn't read its careers page | `[grounded]` About page found; careers fetch returned no page | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Supported small caseload | positive_signal | — | "You will hold a small caseload of your own, supported by a senior community nurse" | The role looks scoped as an entry post with supervision | `[grounded]` advert; `[inferred]` on the scoping | How many patients would I start with, and how is the senior nurse's support structured in the first months? | noted |
| RR3 | Pay brackets the market median; pool cars | positive_signal | — | "£31,050–£37,800 a year plus mileage"; "pool cars are provided" | Pay is consistent with the role-family band. Mileage next to pool cars is unexplained | `[grounded]` advert; `[generic]` market band (Wardround 2026) | Where would I start on the range, and when does mileage apply rather than a pool car? | unresolved |
| RR4 | Training for Doppler and community induction unstated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | Desirable skills may be trained on the job. The team lead has publicly discussed Doppler training for new staff | `[inferred]` from the advert's wording; `[grounded]` forum page | What induction and Doppler training do new community nurses get, and how soon? | unresolved |
| RR5 | Working pattern unstated | unknown | — | (not stated in the advert) | Weekend or on-call duty may apply and is not mentioned | `[grounded]` advert silence | What are the working hours, and is there a weekend or on-call rota? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the discharge-to-assess secondment up your CV, in your own words: "seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | R10, RR2. It is your clearest community-facing evidence | `[grounded]` CV | resume_edits_pending_approval |
| E2 | In your statement, say plainly that you haven't yet held your own caseload or done Doppler assessment, and that you'd welcome training. State your wound-care, catheter and insulin work as it stands | R10, R11. Your own statements, no widening | `[grounded]` your statement | pending your approval |
| A1 | Take up the advert's invitation for an informal chat with Rhiannon Mabbott, and ask the RR1–RR5 questions | Her forum talks suggest she values leg-ulcer and Doppler skills, and the register's questions are written for her | `[grounded]` advert and forum page | pending your approval |

## Evidence status

Verified: none yet. Your NI number isn't needed to assess a role, and I haven't used it. Applications don't need it until an offer.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and found "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers returned no page. The employer is established, the posting is not confirmed live (RR1), and the contradictions row couldn't compare the advert to the careers page |
| 2. Role-family sweep | yes | Searched "district nurse community staff nurse Band 5 Agenda for Change pay scale 2026" and found "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It set the market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead" and found "Rhiannon Mabbott — Community Nursing Team Lead" (communitynursingforum.example/speakers/rhiannon-mabbott). It set the hiring-contact row, RR4 and A1 |

I can write all of this up as `tuesday-dossier.md` if you'd like a saved copy.

## Upgrade menu

- A check of your PIN on the public NMC register → R1 moves from `medium` to `high`.
- Any competency record (compression, continence, end-of-life, documentation) → the relevant R5, R6b, R8 or R9 row.
- Your pay floor, preferred hours and travel limits → the hard-gates line can check you against them.
- The live posting on the employer's careers page → RR1 closes.
- A deeper research pass on Calderbrook (up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Have you cared for patients at the end of life, on the ward or during a discharge home to die? What did you personally do, and is there any record of it?
G2 — Have you applied compression bandaging or carried out continence assessments or care plans? What was your role, and what training or sign-off did you have?
G3 — Do you write or contribute to care plans, and which electronic record system do you use day to day?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.