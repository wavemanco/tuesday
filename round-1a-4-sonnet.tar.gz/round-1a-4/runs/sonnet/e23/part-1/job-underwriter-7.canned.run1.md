I'll read the skill's reference files first.
The employer, the pay band and the team lead all came back as real. Next I'll check whether the posting is live on Calderbrook's careers page.
**Yes, this is worth applying for, Aoife. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5, R7a, R8 · unclear: R4 (clear, timely written records)
- `important`: direct: R10 · adjacent: R6 (leg-ulcer care), R11 (own small caseload) · unclear: R7b (continence care beyond catheters), R9 (end-of-life visits), R12 (care planning)
- `preferred`: absent: R13 (Doppler assessment)

R6 and R11 are adjacent, with their limits named in the map. R4, R7b, R9 and R12 are unclear, and your answers close them. R13 is absent, carried at preferred priority.

**Opportunity ledger.** The duties are specific and the support is structured (RR2), and the named team lead has a public community-nursing profile (RR7). Five things are unstated or unconfirmed: whether the posting is open on the employer's own site (RR1), the training route for leg-ulcer and Doppler work (RR3), the starting point on the pay range (RR4), when pool cars versus mileage apply (RR5), and the hours and rota (RR6).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm what record systems you have documented in (R4, G1).
  2. The posting is confirmed open (RR1).
  3. Your discharge-to-assess work is framed as home visiting, not as running a caseload (R10, R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` About Calderbrook Community Health page (search result) |
| Mandate | District nursing for housebound adults at home: wounds and leg ulcers, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` advert |
| Essentials | NMC registration as an Adult Nurse; full UK licence; at least one year post-registration; clear, timely records | `[grounded]` advert |
| Support model | A small caseload held under a senior community nurse, with no community experience listed as essential | `[inferred]` from the advert's support line against its essential list |
| Market calibration | The advertised £31,050–£37,800 spans a wider range than a 2026 survey of Band 5 community staff nurses in England (median £34,300, interquartile range £32,400–£36,600). In that survey 61% were paid mileage and 24% had a pool or lease car. This is a pattern, not this employer's offer. | `[generic]` Wardround 2026 pay guide; `[grounded]` advert for its own figures |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. At the 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` community nursing forum speaker page |
| Unknowns | Whether the post is open; hours and rota; training route; where on the range a new appointee starts; pool car versus mileage | `[grounded]` advert's silence |
| Contradictions | None found. The one careers-page fetch returned no page, which says nothing either way about the posting. | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states Registered Nurse (Adult), registration active, revalidation due March 2028. This is self-reported and not yet inspected. | `[grounded]` CV | none; sharing your public register entry would raise it |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full licence, category B. The advert says pool cars are provided. | `[grounded]` CV and advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | The CV says nothing about documentation or record systems. Ward nursing involves recording, but your CV does not say which systems you used or how. | `[grounded]` CV silence; `[generic]` that ward nursing involves recording | G1 |
| R5 | Wound care | must_have | direct | medium | none | CV: wound care including pressure ulcers and surgical wounds. | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | adjacent | medium | transferability | Your pressure-ulcer and surgical-wound work is the nearest evidence. Leg-ulcer assessment and compression therapy are not on your CV. | `[grounded]` CV; `[inferred]` adjacency | G4 |
| R7a | Catheter care | must_have | direct | medium | none | CV: catheter care. | `[grounded]` CV | none |
| R7b | Continence care beyond catheters | important | unclear | low | discovery | The advert pairs continence with catheters. Your CV mentions catheters only. | `[grounded]` CV and advert | folded into G1 |
| R8 | Insulin administration | must_have | direct | medium | none | CV: insulin administration. | `[grounded]` CV | none |
| R9 | End-of-life visits | important | unclear | low | discovery | The CV is silent on end-of-life or palliative care. | `[grounded]` CV silence | G2 |
| R10 | Care delivered in patients' own homes | important | direct | medium | none | 18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: the advert's patients are housebound adults, and yours were recently discharged. | `[grounded]` CV | none |
| R11 | Hold a small caseload of your own, supported by a senior community nurse | important | adjacent | medium | transferability | You told me you have never held your own caseload. The nearest evidence is home visiting on discharge-to-assess. Limit: no caseload ownership. | `[grounded]` your statement and CV | G3 |
| R12 | Care planning | important | unclear | low | discovery | Not stated on the CV. It is unknown whether you planned care on the discharge-to-assess team. | `[grounded]` CV silence | G3 |
| R13 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You have never done one. | `[grounded]` your statement | G5; carried at preferred priority |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records and EPR (R4, R7b) | discovery | The CV names no record system and does not mention continence | R4 is the one essential row not yet evidenced | Documenting in an electronic record; completing discharge or handover paperwork; catheter and continence charts or bladder assessments | Name of the system, a documentation audit, or a reference | `[grounded]` CV silence |
| G2 | End-of-life visits (R9) | discovery | The CV is silent | A named duty of the post | Last-days-of-life care on the ward; anticipatory medication or care-plan input; supporting a patient to die at home or arranging it on discharge | A palliative care competency record or a training certificate | `[grounded]` CV silence |
| G3 | Caseload and care planning (R11, R12) | transferability | Home visiting is evidenced and ownership is not | The posting's own framing is a small caseload with support | Deciding visit frequency; setting goals; following a patient across several visits | A discharge-to-assess service description or a reference | `[grounded]` your statement; `[inferred]` bridge |
| G4 | Leg-ulcer care (R6) | transferability | Pressure-ulcer and surgical-wound care, no leg-ulcer assessment | Named in the advert's duties | Compression bandaging or leg-ulcer dressings on the ward | A competency sign-off | `[grounded]` CV |
| G5 | Doppler (R13) | capability | No evidence, as you said | Desirable only. I can't tell from the posting whether the employer trains staff to do it. | None to claim. The closure path is training, which this employer may offer (RR3). | None | `[grounded]` your statement; `[inferred]` closure path |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | unknown | — | "Calderbrook Community Health CIC, Halifax" | The posting may be current and my guessed careers address may simply be wrong | `[grounded]` fetch returned no page; `[generic]` that guessed addresses often miss | Is this post currently open, and what is the closing date? | unresolved |
| RR2 | Structured support for a new caseload | positive_signal | — | "You will hold a small caseload of your own, supported by a senior community nurse" | The post is built for supported development | `[grounded]` advert | How is the caseload built up for someone new to community nursing? | noted |
| RR3 | Training route not stated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | Training may be provided, given the lead's talk on Doppler training for new staff | `[inferred]` from the advert's silence and the speaker page | Is leg-ulcer and Doppler training provided, and how soon would I practise independently? | unresolved |
| RR4 | Starting point on the pay range | unknown | — | "£31,050–£37,800 a year plus mileage" | Appointees new to community work may start nearer the bottom | `[generic]` pattern, not a claim about this employer | Where on the range would an appointee with my experience start? | unresolved |
| RR5 | Pool cars and mileage both mentioned | unknown | — | "pool cars are provided" and "plus mileage" | Mileage may apply only when you use your own car | `[inferred]` from the two phrases | When do I use a pool car, and when is mileage paid? | unresolved |
| RR6 | Hours and rota unstated | unknown | — | "end-of-life visits" | Visiting may include weekends, evenings or on-call | `[generic]` community nursing pattern | What are the working hours, and is there a weekend or on-call rota? | unresolved |
| RR7 | A named lead with a public community-nursing profile | positive_signal | — | "contact Rhiannon Mabbott, Community Nursing Team Lead" | The team is open to informal contact | `[grounded]` advert and speaker page | What would you want from a new nurse in the first three months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the discharge-to-assess secondment first. Keep your own wording: 18 months, visiting patients at home in their first week after discharge. | see R10 | `[grounded]` CV | resume_edits_pending_approval |
| E2 | Name the wound types, catheter care and insulin administration exactly as your CV states them. Make no leg-ulcer, continence or caseload claim. | see R5, R6, R7a, R8 | `[grounded]` CV | resume_edits_pending_approval |
| E3 | Say plainly in the application that you have not held a caseload or done Doppler assessment. | see R11, R13 | `[grounded]` your statements | pending your approval |
| A1 | Use the informal chat with Rhiannon Mabbott before applying, and ask RR1, RR3, RR5 and RR6 verbatim. | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your CV claims and your two statements are self-reported. I haven't used your National Insurance number and don't need it to assess a role. I'd leave it out of anything you send until an employer asks.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). I then fetched calderbrookhealth.example/careers, an address I guessed, and it returned no page. Moved: the employer is established, and the posting's liveness is not (RR1). |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay scale community staff nurse district nurse salary", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration `[generic]`, and RR4 and RR5. |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: the scope read, RR3 and RR7, and A1. |

I can put all this into a `tuesday-dossier.md` for you to keep, if you'd like.

**Upgrade menu**

- Your public NMC register entry would take R1 to `high`.
- A discharge-to-assess service description, a reference, or a competency record would strengthen R10, R11, R12 and R9.
- The employer's careers page link would close RR1.
- Your pay floor, hours and any other non-negotiables would let me check the hard gates against you, since none were given.
- The recruiter's answers on RR3 to RR6 would close those entries.
- A deeper research pass on Calderbrook (staff reports, leadership changes, regulator inspections, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

G1 — Which electronic patient record or documentation systems have you charted in, and have you done bladder or continence assessments beyond catheter care?

G2 — Have you cared for patients in their last days of life, on the ward or when arranging a discharge to die at home? What was your part?

G3 — On the discharge-to-assess team, did you decide visit frequency or set goals for any patient across several visits? What was yours versus the team's?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.