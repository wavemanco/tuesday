I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**Yes, this is worth applying for. R1 and R2, the two hard gates, are met. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (clear, timely written records)
- `important` — direct: R5, R7a, R8 · adjacent: R6 (leg-ulcer care), R10 (small caseload of your own) · unclear: R7b (continence care), R9 (end-of-life visits), R11 (care planning)
- `preferred` — absent: R12 (Doppler assessment)

R4 — your CV is silent, which is different from a contradicted claim; R6, R10 — bridges with their limits named; R12 — absent, and the only Doppler gap you have.

**Opportunity ledger.** Clear and well-supported: the posting is specific about duties, supervision and pay (RR2, RR3). Two things are unconfirmed rather than wrong: I could not find the posting on the employer's careers page (RR1), and the hours and rota are unstated (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed open, either on Calderbrook's own careers page or by Rhiannon Mabbott (RR1); (2) the caseload and Doppler gaps are stated plainly rather than papered over (R10, R12).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` calderbrookhealth.example/about, fetched |
| Posting status | The `/careers` page I tried returned no page, so I could not confirm this post is live there (RR1) | `[grounded]` fetch result |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, recorded on an electronic patient record | `[grounded]` advert |
| Supervision | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Scope read | An ordinary Band 5 community post. The duties match the pay and the supervision is built in. | `[inferred]` from the duty list against the stated support |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At the 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` communitynursingforum.example speaker page |
| Market calibration | A UK survey of community staff nurses at Band 5 in England (n=1,240) gives median basic pay of £34,300 and an interquartile range of £32,400 to £36,600. The posted £31,050–£37,800 is wider than that range and straddles the median. In the same survey 61% were paid mileage and 24% had a pool or lease car. This is a market band, not this employer's offer. | `[generic]` Wardround 2026 UK Community Nursing Pay Guide; `[grounded]` JD for the posted range |
| Unknowns | Closing date, hours and weekend rota, starting point in the range, how the caseload is built up, what Doppler training exists, which EPR system | — |
| Contradictions | None between the advert and the About page | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state Registered Nurse (Adult), PIN given, active, revalidation due March 2028. This is a specific CV claim. It is `medium` only because I have not seen the register entry, and the NMC online register is the inspectable artifact. | `[grounded]` your CV | none; your public register entry would raise it to `high` |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | You state a full UK licence, category B. The JD asks for a full UK licence and provides pool cars. | `[grounded]` your CV and the advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. This is a length-of-experience requirement, not a gate. | `[grounded]` your CV | none |
| R4 | Clear, timely written records (on an electronic patient record) | must_have | unclear | low | discovery | The CV says nothing about documentation or EPR use. Five years of ward practice and a home-visiting secondment make record-keeping likely, but that is an inference, not a claim you have made. | `[grounded]` CV silence; `[inferred]` from the ward and secondment roles | G1 |
| R5 | Wound care | important | direct | medium | none | You state wound care including pressure ulcers and surgical wounds. | `[grounded]` your CV | none |
| R6 | Leg-ulcer care | important | adjacent | medium | transferability | Adjacent to the wound care you state. Limit: nothing in your CV says leg ulcers, compression therapy or venous assessment. | `[grounded]` CV wound-care claim; `[generic]` that leg ulcers are a distinct skill set from pressure and surgical wounds | G3 |
| R7a | Catheter care | important | direct | medium | none | You state catheter care. | `[grounded]` your CV | none |
| R7b | Continence care (beyond catheters) | important | unclear | low | discovery | The CV names catheter care only. | `[grounded]` CV silence | G6 |
| R8 | Insulin administration | important | direct | medium | none | You state insulin administration. The advert also lists insulin care planning, which is R11. | `[grounded]` your CV | none |
| R9 | End-of-life visits | important | unclear | low | discovery | The CV is silent. Acute medical wards and home-visiting work may well involve end-of-life care, but you have not said so. | `[grounded]` CV silence | G2 |
| R10 | A small caseload of your own, supported by a senior community nurse | important | adjacent | medium | transferability | You visited patients at home in their first week after discharge on an 18-month secondment, which is the bridge. Limit, in your words: you have never held your own caseload. The advert's built-in support narrows the gap. | `[grounded]` your CV and your statement; `[inferred]` that the support lowers the bar | G4 |
| R11 | Care planning | important | unclear | low | discovery | The CV is silent on care planning. | `[grounded]` CV silence | G6 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You state you have never done one. It is preferred, not essential. Rhiannon Mabbott has spoken publicly on Doppler training for staff new to community work. | `[grounded]` your statement and the speaker page | G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records and EPR (R4, must_have) | discovery | No mention of documentation or electronic records in the CV | It is the only `must_have` row that is not `direct`, and one line from you could close it | Electronic notes on the ward; discharge-to-assess visit records; handover or care-plan documentation others relied on | A sanitised note template or the name of the system you used | `[grounded]` CV silence; `[inferred]` that one confirmed line would move R4 to `direct` |
| G2 | End-of-life visits (R9, important) | discovery | No end-of-life care mentioned | It is a named duty and an interviewer is likely to ask about it | Last-days care on the ward; anticipatory medication; symptom control; supporting families; discharging a patient home to die | A reference, or a note on your own role | `[grounded]` CV silence; `[generic]` that a role built on end-of-life visits is likely to probe this |
| G3 | Leg-ulcer care (R6, important) | transferability | Pressure-ulcer and surgical wound care only | It is the named duty closest to the preferred Doppler skill | Compression bandaging; ABPI or Doppler observed or assisted; tissue viability link-nurse work | A competency record or training certificate | `[grounded]` CV; `[inferred]` bridge from the wound-care claim |
| G4 | Own caseload (R10, important) | transferability | Home visits on secondment, no caseload ever held | It is the limit you flagged, and the advert provides support for it | How you planned your visits, what you decided yourself and what went to the team | Secondment job description | `[grounded]` your statement and CV |
| G5 | Doppler assessment (R12, preferred) | capability | Never done; no adjacent evidence | It is preferred, so it is a minor risk. The closure path is on-the-job training. | None to recover. The path is asking whether the employer trains staff in it. | A training offer from the employer | `[grounded]` your statement; `[inferred]` that training is plausible from Mabbott's talk, which I have not confirmed for this employer |
| G6 | Continence care and care planning (R7b, R11) | discovery | CV names catheter care and insulin administration, not wider continence or care planning | Lower impact than G1 to G3, so I am not asking about them this turn | Bowel or bladder management; discharge or care plans you wrote | Not needed yet | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's careers page | unknown | — | "Join our district nursing team" | The post may be listed under a different address or already filled. The page I tried was a guessed URL, so this says nothing about the employer. | `[inferred]` from the fetch result | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Built-in support for a first caseload | positive_signal | — | "You will hold a small caseload of your own, supported by a senior community nurse" | The structure suits a nurse moving into community work from a ward | `[inferred]` from the advert's wording | How is the caseload built up over the first few months, and how much shadowing is there? | noted |
| RR3 | Pay stated and in line with the survey band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The posting is transparent about pay; the range straddles the survey median | `[grounded]` JD figure against `[generic]` Wardround band | Where in the range would someone with my experience start, and what is the mileage rate? | noted |
| RR4 | Hours, rota and visit volume unstated | unknown | — | "district nursing team caring for housebound adults in their own homes" | The advert may leave out weekend or out-of-hours duties that district nursing teams often carry | `[generic]` role-family pattern | What are the working hours and weekend rota, and how many visits does a new starter do in a day? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Open the CV with: "Registered Nurse (Adult). Five years as a staff nurse on an acute medical ward at a district general hospital, the last 18 months seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge." | It puts your home-visiting work first. Each clause comes from your own sentences. | `[grounded]` your CV | `resume_edits_pending_approval` |
| E2 | Move "wound care including pressure ulcers and surgical wounds; catheter care; insulin administration" up beside E1, in the advert's order. Add nothing about leg ulcers, caseload or Doppler. | The three skills already match the advert's duties | `[grounded]` your CV | `resume_edits_pending_approval` |
| E3 | In the application and interview, say plainly that you have not held your own caseload and have not done a Doppler assessment | An interviewer can check both, and the advert's built-in support makes the caseload gap an easier one to admit | `[grounded]` your statement; `[generic]` that these are usually probed | pending your approval |
| A1 | Use the informal chat with Rhiannon Mabbott to ask the RR1 to RR4 questions verbatim, and ask whether Doppler training is offered | The advert invites the chat. Her public talk on Doppler training makes the question natural. | `[grounded]` advert and speaker page | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed to assess a role, so I haven't used it. You can leave it off anything you send me.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse". Fetched "About Calderbrook Community Health" (calderbrookhealth.example/about), which confirms the employer exists as described. Fetched calderbrookhealth.example/careers, which returned no page, so posting liveness is unconfirmed (RR1) |
| 2. Role-family sweep | yes | Searched "district nurse community staff nurse Band 5 Agenda for Change pay scale 2026/27 salary". It returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide), which gave the market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead". It returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott), which gave the team-lead row, G5 and plan row A1 |

I can write this up as a `tuesday-dossier.md` if you'd like to keep it. It's optional.

## Upgrade menu

- **Your NMC online register entry.** It raises R1 to `high`.
- **The live posting link or the closing date.** It resolves RR1.
- **Answers to G1 to G3.** They move R4, R9 and R6, and R4 is the one `must_have` row not yet `direct`.
- **Rhiannon's answers on hours, rota, caseload build-up and Doppler training.** They close RR2 and RR4 and the training question behind G5.
- **A deeper research pass on Calderbrook** (leadership changes, staff and trust reports, recent news). It costs up to 5 more searches and 2 more fetches, and it runs if you say the word.

## Questions

- **G1** — Did you use electronic notes or an EPR on the ward or in the discharge-to-assess role, and did you write the visit records yourself? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- **G2** — Have you cared for patients in their last days on the ward, or helped one go home to die? What did you do yourself? Same response modes apply.
- **G3** — Have you done compression bandaging, or seen or assisted with a Doppler or ABPI reading? Same response modes apply.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.