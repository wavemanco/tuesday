Checking the employer and the posting online, then I'll write up the assessment.
# Job Underwriting Assessment: Community Staff Nurse, Band 5, Calderbrook Community Health CIC (Halifax)

## Decision snapshot

**Yes, Aoife, this one is worth applying for. Status: `go`.** R1 and R2, the two hard gates, are both met (`direct`).

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · unclear: R4 (Clear, timely written records)
- `important`: direct: R5, R7a, R8a · adjacent: R10 (Small caseload of your own) · unclear: R6 (Leg-ulcer care), R7b (Continence care), R8b (Care planning), R9 (End-of-life visits)
- `preferred`: absent: R11 (Doppler assessment)

R10 (`medium`): a credible bridge through the discharge-to-assess home visits, with its limit named; R4, R6, R7b, R8b, R9: the CV is silent, so these are questions and not gaps found; R11: absent, at the `preferred` tier.

**Opportunity ledger.** The role is sound on its face: pay is stated and sits inside the market band (RR3), and senior support is named (RR4). The open items are the live posting, not yet confirmed on the employer's own site (RR1), the unstated rota (RR2) and the undefined caseload size (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** the status would drop if the posting proves not to be live (RR1), or if the rota or terms you learn (RR2) clash with a constraint you haven't yet given me.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff across four locality hubs | `[grounded]` employer About page (calderbrookhealth.example/about), read as a search-result extract |
| Role | Band 5 community staff nurse in the district nursing team, caring for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, on an electronic patient record | `[grounded]` JD |
| Caseload and support | "A small caseload of your own, supported by a senior community nurse" | `[grounded]` JD |
| Essential versus desirable | Only the NMC registration, driving licence, one year post-registration and clear records are essential; Doppler is desirable | `[grounded]` JD |
| Scope read | Doppler is desirable rather than essential, so the post appears to expect some new starters to learn it in the job | `[inferred]` from the essential/desirable split in the JD |
| Hiring manager | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse; at the 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` speaker page (communitynursingforum.example/speakers/rhiannon-mabbott), read as a search-result extract |
| Market calibration | Stated £31,050–£37,800 against a 2026 survey of Band 5 community staff nurses in England (n=1,240): median £34,300, interquartile range £32,400–£36,600, 61% paid mileage, 24% with a pool or lease car. The posting's range spans the survey's middle half, and its pool cars are offered where few respondents had one. It is a band, never this employer's offer | `[generic]` survey extract (wardround.example/2026-uk-community-nursing-pay-guide); `[grounded]` JD for the posting's figures |
| Unknowns | Rota, weekends and on-call; caseload size; contract basis (permanent or fixed-term); closing date; start date; first-90-day expectations | `[grounded]` JD silent on each |
| Contradictions | None between the JD and the About page. The careers page I tried returned no page, so the live vacancy is unconfirmed (RR1) | `[grounded]` About page; careers fetch returned nothing |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states Adult registration, active, revalidation due March 2028. Self-reported and not checked against the register by me, hence `medium` | `[grounded]` CV | none; the employer will check the register |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | CV states a full UK licence, category B. Nothing inspected | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | CV states five years as a staff nurse on an acute medical ward. A length-of-experience requirement is not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV is silent on documentation. You have worked on a ward and in a team that visited patients at home, which is indirect context only, so I don't treat it as evidence | `[grounded]` CV silence | G1 |
| R5 | Wound care | important | direct | medium | none | CV states wound care including pressure ulcers and surgical wounds. The JD lists wound and leg-ulcer care together; the leg-ulcer half is R6 | `[grounded]` CV | none |
| R6 | Leg-ulcer care | important | unclear | low | discovery | CV states pressure ulcers and surgical wounds, not leg ulcers or compression. Nothing confirms or rules it out | `[grounded]` CV silence on leg ulcers | G2 |
| R7a | Catheter care | important | direct | medium | none | CV states catheter care | `[grounded]` CV | none |
| R7b | Continence care | important | unclear | low | discovery | The CV states catheter care but not continence care more widely | `[grounded]` CV silence | G4 |
| R8a | Insulin administration | important | direct | medium | none | CV states insulin administration | `[grounded]` CV | none |
| R8b | Care planning | important | unclear | low | discovery | The CV does not mention care planning | `[grounded]` CV silence | G4 |
| R9 | End-of-life visits | important | unclear | low | discovery | The CV does not mention end-of-life or palliative care | `[grounded]` CV silence | G3 |
| R10 | A small caseload of your own, supported by a senior nurse | important | adjacent | medium | transferability | You told me you have never held your own caseload. The adjacent evidence is 18 months on a discharge-to-assess secondment, visiting patients at home in their first week after discharge. Limit: these were post-discharge visits and not a standing list of patients you plan and prioritise yourself. For roles like this, interviewers commonly probe the difference | `[grounded]` CV and your statement; `[generic]` that the difference is commonly probed | G5 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You told me you have never done one. The closure path is training: the team lead has spoken publicly on Doppler training for staff new to community work, but whether Calderbrook provides it is unconfirmed | `[grounded]` your statement and speaker page | G6; ask RR4's question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Clear, timely written records (R4, must_have) | discovery | The CV says nothing about documentation | R4 is the only `must_have` row not `direct`, and one specific answer would settle it | Writing up home visits on an electronic record; documentation audits or feedback; handover notes after discharge visits | A documentation audit result, or a competency record covering record-keeping | `[grounded]` CV silence |
| G2 | Leg-ulcer care (R6, important) | discovery | Pressure-ulcer and surgical-wound care is stated; leg ulcers are not | Leg-ulcer care is named in the advert and the team lead has spoken on leg-ulcer clinics | Compression bandaging; leg-ulcer assessments on the ward or on visits; shadowing a tissue viability nurse | A signed wound-care competency record | `[grounded]` CV; speaker page |
| G3 | End-of-life visits (R9, important) | discovery | The CV is silent | A named duty in the advert | Caring for dying patients on the ward; anticipatory-medication or rapid-discharge-home cases in discharge-to-assess | A reflection or training record on palliative care | `[grounded]` CV silence |
| G4 | Continence care and care planning (R7b, R8b, important) | discovery | Catheter care is stated; broader continence work and care planning are not | Both are named duties | Continence assessments or bladder and bowel plans; writing or updating care plans | A care-plan example with patient details removed | `[grounded]` CV silence |
| G5 | Holding a caseload (R10, important) | transferability | Home visits after discharge, with no standing list | The most obvious difference from your current work. The bridge is stated with its limit and gets stronger with detail on how much of each visit was yours to decide | Deciding what a visit covered; escalating a concern to a medical team or GP; managing a run of visits in a day | The secondment's role description, or a signed competency record | `[grounded]` CV and your statement |
| G6 | Doppler assessment (R11, preferred) | capability | None, as you told me | A desirable item, so a closable difference rather than a barrier to applying | Training on a course, or being supervised through an assessment once in post | The employer's confirmation that training is offered (RR4) | `[grounded]` your statement; `[generic]` that employers sometimes train desirable skills in post |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | unknown | — | "Calderbrook Community Health CIC, Halifax" | The careers page I tried may simply sit elsewhere, or the vacancy may be hosted on a jobs board only | `[inferred]` from one careers URL returning no page, against an About page that says vacancies are on a careers page | Can you give me the vacancy's reference on your careers page, and the closing date? | unresolved |
| RR2 | Working pattern unstated | unknown | — | "caring for housebound adults in their own homes" | Visit hours, weekends and on-call may be part of the post | `[generic]` community nursing rotas vary by service | What is the rota: visit hours, weekends, bank holidays and any on-call? | unresolved |
| RR3 | Salary stated, within market range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay is transparent and in line with comparable posts | `[grounded]` JD figures; `[generic]` survey extract band | Where in the range would my experience start, and what is the mileage rate? | noted |
| RR4 | Senior support named; Doppler training signalled | positive_signal | — | "supported by a senior community nurse" | The team may supervise new caseload-holders and train staff in Doppler | `[grounded]` JD; `[inferred]` from the team lead's published talk on Doppler training | What support and Doppler training do new starters get, and for how long? | noted |
| RR5 | "Small caseload" undefined | unknown | — | "You will hold a small caseload of your own" | Caseload size and sign-off steps may be set after a period of supervision | `[inferred]` from the JD's silence on number and sign-off | How many patients is a small caseload, and what do you sign off before it starts? | unresolved |

## Application plan

All proposed language and actions in this section are pending your approval, and none is final until you say so, whether in the table or in the notes beneath it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with your own sentence: "Seconded for the last 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge." | see R10 | `[grounded]` your CV and message | `resume_edits_pending_approval` |
| E2 | Put "wound care including pressure ulcers and surgical wounds; catheter care; insulin administration" together in one line, in your own words | see R5, R7a, R8a | `[grounded]` your CV | `resume_edits_pending_approval` |
| A1 | Take up the informal chat with Rhiannon Mabbott before applying, and ask RR1, RR2, RR4 and RR5 | The advert invites it | `[grounded]` JD | pending your approval |
| A2 | In any interview, say the home visits were post-discharge visits and not a caseload of your own, and that you haven't done Doppler assessment | see R10, R11 | `[grounded]` your statements | pending your approval |
| A3 | Leave leg-ulcer care, continence care, care planning, end-of-life care and record-keeping off the CV until you have answered G1 to G4 | No evidence for them yet | `[grounded]` the evidence map | pending your approval |

## Evidence status

Verified: none yet. Not used: the National Insurance number you included is not needed to evaluate a role, so I haven't used it.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse Band 5 district nursing Halifax"; both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). I fetched calderbrookhealth.example/careers, which returned no page. Role reality's organization and contradictions rows; RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing role scope caseload salary Agenda for Change 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration; RR3. It gave pay only and nothing on remit |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's hiring-manager row; RR4; G6 |

If you want this saved, I can write it up as `tuesday-dossier.md`.

## Upgrade menu

- A link to the live vacancy, with its reference and closing date: RR1 closes, and the posting's terms can be read in full.
- Your answers to G1, G2 and G5: R4, R6 and R10 move, and the E1 line can be firmed up.
- Signed competency records (wound care, catheter, insulin) or the secondment's role description: R5, R7a, R8a and R10 could move to `high`.
- Your non-negotiables (pay floor, hours or rota limits, travel limits): RR2 and RR3 become hard-gate rows checked against your terms, and the hard-gates line stops reading "not given".
- A deeper research pass on Calderbrook (regulator reports, staff reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

G1 — What records did you write on your discharge-to-assess home visits, in which system, and how soon after each visit?

G2 — Have you done any leg-ulcer care, such as compression bandaging or Doppler or ABPI checks, on the ward or on those visits? What, how often, and did anyone sign you off?

G5 — On those visits, who decided which patients you saw and what each visit covered, and did you ever follow the same patients over several visits?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.