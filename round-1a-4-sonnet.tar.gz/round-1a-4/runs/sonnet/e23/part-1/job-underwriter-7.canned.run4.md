Still reading the skill's reference files so the assessment follows its required shape. Next I'm loading the research-tier rules and the confidence-band definitions.
**Yes, this one is worth applying for. Status: `go`.**

Aoife, you meet both gates on your CV. The gaps are mostly things the CV doesn't say yet. The one real gap is Doppler, and the advert lists it as desirable only.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R5a, R6a, R7 · adjacent: R5b (Leg-ulcer care), R11 (Small caseload of your own) · unclear: R4 (Clear, timely written records), R6b (Continence care beyond catheters), R8 (End-of-life visits)
- `important` — direct: R10 · unclear: R9 (Care planning)
- `preferred` — absent: R12 (Doppler assessment)

R11 — the discharge-to-assess home visits are a bridge to a caseload, with the limit named; R5b — your wound work carries over, leg-ulcer compression isn't evidenced; R12 — desirable, not a blocker.

**Opportunity ledger.** The role is transparent and supported: the team lead is named and the caseload is supervised (RR2), and the pay is stated (RR5). The unknowns are whether the post is still open (RR1), the rota (RR3) and the induction offered (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** to `hold_pending_answers` if the post has closed (RR1) or if the rota or hours (RR3) clash with limits you haven't told me about.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` Calderbrook "About" page |
| Role | Band 5 district nursing post: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record; own small caseload with a senior community nurse supporting | `[grounded]` advert |
| Pay and terms | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse; at the 2025 community nursing forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Scope read | An entry route into community nursing for a nurse new to it, not a senior or specialist post | `[inferred]` from the supported small caseload and the Doppler being desirable only |
| Market calibration | A 2026 survey of Band 5 community staff nurses in England gives median basic pay £34,300, interquartile range £32,400–£36,600. The advert's range runs from below that range to above it. Only 24% of respondents had a pool or lease car, so pool cars provided is on the favourable side. This is a pattern for the role family, not this employer's offer | `[generic]` survey (n=1,240); `[grounded]` advert for its own figures |
| Unknowns | Whether the post is open and its closing date; rota and weekend or on-call duties; starting caseload size; induction and Doppler training | — |
| Contradictions | None found between the advert and the "About" page. The careers page could not be opened, so the live posting is unconfirmed | `[grounded]` both pages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states Registered Nurse (Adult), a PIN, active registration and revalidation due March 2028. It is self-reported and I haven't checked it against the register | `[grounded]` CV | A public NMC register entry would raise it to `high` |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | CV states a full UK licence, category B. Pool cars are provided, so you don't need your own car | `[grounded]` CV and advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. The advert doesn't ask for community experience here | `[grounded]` CV and advert | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | CV is silent on documentation and on record systems. Nothing is claimed either way | `[grounded]` CV silence | Ask G2 |
| R5a | Wound care | must_have | direct | medium | none | CV states wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound assessment and dressing carry over. The limit: compression therapy and Doppler-informed leg-ulcer assessment aren't evidenced | `[inferred]` adjacency derived from your pressure-ulcer and surgical-wound work | Ask G3; any compression-bandaging training would strengthen it |
| R6a | Catheter care | must_have | direct | medium | none | CV states catheter care | `[grounded]` CV | none |
| R6b | Continence care beyond catheters | must_have | unclear | low | discovery | CV mentions catheters only; the advert pairs catheter and continence care | `[grounded]` CV and advert | Ask G3 |
| R7 | Insulin administration | must_have | direct | medium | none | CV states insulin administration. The advert adds care planning, which is R9 | `[grounded]` CV | none |
| R8 | End-of-life visits | must_have | unclear | low | discovery | CV is silent. Ward experience may include it, but that is unconfirmed | `[grounded]` CV silence | Ask G1 |
| R9 | Care planning | important | unclear | low | discovery | CV is silent on care planning | `[grounded]` CV silence | Ask G2 |
| R10 | Visiting patients in their own homes | important | direct | medium | none | Eighteen months seconded to a discharge-to-assess team, visiting patients at home in their first week after discharge | `[grounded]` CV | Plan row E1 |
| R11 | A small caseload of your own, supported by a senior nurse | must_have | adjacent | medium | transferability | You have never held your own caseload. The home visits are adjacent, and the limit is that you didn't carry a caseload. The advert says a senior community nurse supports it | `[grounded]` your statement and advert; `[inferred]` the bridge | Plan row E1 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have never done one. It is desirable, not essential. The route to closing it is training | `[grounded]` your statement and advert | Ask the team about Doppler training (RR4) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R8, must_have) | discovery | CV silent on end-of-life care | A named duty in the advert; resolving it removes one of the unclear must-haves | Caring for dying patients on the ward; symptom control or anticipatory medicines; supporting families; contributing to a care-after-death or rapid-discharge plan | A competency record or training certificate | `[grounded]` CV silence |
| G2 | Records and care planning (R4, must_have; R9, important) | discovery | CV doesn't mention documentation, electronic records or care plans | The advert asks for clear, timely records on an electronic system and lists care planning | Using an electronic patient record on the ward or on the discharge team; writing discharge or care plans; documentation audits | An audit result, or a de-identified plan or entry format | `[grounded]` CV silence |
| G3 | Leg-ulcer and continence work (R5b, must_have; R6b, must_have) | discovery | Pressure and surgical wounds are evidenced; leg ulcers and non-catheter continence aren't | Both are core duties for the advert's caseload | Compression bandaging; leg-ulcer dressings; bladder and bowel assessments; continence products; catheter changes | A training record or wound-care competency sign-off | `[grounded]` CV scope |
| G4 | Caseload (R11, must_have) | transferability | Home visits are evidenced; owning a caseload isn't | The advert says a supported small caseload | Planning your own visit list; deciding visit priorities; escalating or discharging patients | A discharge-team visit log, de-identified | `[inferred]` bridge from your account |
| G5 | Doppler (R12, preferred) | capability | None, and you have confirmed it | Desirable only | A route is training once in post | A Doppler course certificate | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The posting isn't confirmed live; the careers page couldn't be opened | unknown | — | "Current vacancies are listed on our careers page" | The post may be open and the page address wrong, or the post may have closed | `[inferred]` from the failed fetch against the employer's own pointer to its vacancies | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Named team lead, informal chat offered, supported caseload | positive_signal | — | "supported by a senior community nurse" | The role has real support and a route in for a nurse new to community | `[grounded]` advert | Who is the senior community nurse, and how often would you meet for case review? | noted |
| RR3 | Rota and hours not stated | unknown | — | "end-of-life visits" | End-of-life work may involve evening or weekend visits, which the advert doesn't set out | `[generic]` community nursing pattern, not a claim about this employer | What is the working pattern: weekends, evenings, or on-call? | unresolved |
| RR4 | Induction and Doppler training not stated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | The team lead has spoken on Doppler training for staff new to community work, so the team may offer it | `[grounded]` forum page for the talk; `[inferred]` that the team offers it | What induction and Doppler training do new community nurses get? | unresolved |
| RR5 | Pay stated and within the survey's range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The offer sits within what Band 5 community nurses are paid | `[grounded]` advert; `[generic]` survey band | Where in the range would you start, given five years' post-registration experience? | noted |

## Application plan

I have drafted nothing for your CV or for outreach. These are proposals only, and nothing is final until you approve it, including the advice in the "Why" cells.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the discharge-to-assess secondment as home-visiting experience, worded as visits to patients at home after discharge. Don't call it district nursing or a caseload | See R10, R11 | `[grounded]` CV | pending your approval |
| E2 | On Doppler, state plainly that you haven't done it and ask about training | See R12, RR4 | `[grounded]` your statement | pending your approval |
| A1 | Take up the informal chat with Rhiannon Mabbott, and use the register's questions (RR1, RR3, RR4) | The advert offers it, and her public talks cover leg-ulcer clinics and Doppler training | `[grounded]` advert and forum page | pending your approval |
| A2 | Add whatever G1–G3 turn up, only once you've confirmed it | See R4, R5b, R6b, R8, R9 | `[grounded]` gap queue | pending your approval |

## Evidence status

Verified: none yet. Stage assumed: evaluating. Your National Insurance number isn't needed to assess the role, so I haven't used it.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers: no page found. The employer is established; the posting isn't confirmed live (RR1) |
| 2. Role-family sweep | yes | Searched "NHS Agenda for Change Band 5 pay scale 2026/27 community staff nurse district nurse band 5 role", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It moved the market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned the forum speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). It moved the team-lead row and RR4 |

## Dossier offer and upgrade menu

I can save all of this as `tuesday-dossier.md` if you'd like a copy to keep.

- A public NMC register entry → R1 to `high`.
- A training record or competency sign-off for compression, continence or end-of-life care → R5b, R6b and R8 firm up.
- A de-identified discharge-team visit log or care-plan format → R10, R11, R4 and R9 firm up.
- The live posting link and closing date → RR1 closes.
- Your pay floor, hours limits and any rota limits → the hard-gates checks against your own constraints can run.
- A deeper research pass on Calderbrook (public reports, staff and leadership changes; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1 — Have you cared for dying patients, on the ward or on the discharge team? What did you personally do, such as symptom control, anticipatory medicines or supporting the family?

G2 — What electronic record systems have you used? Have you written care or discharge plans, and who relied on them?

G3 — Have you done compression bandaging for leg ulcers, or continence work beyond catheters, such as bladder and bowel assessments?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.