Searched the web for Velloway Logistics and found nothing. Here is the full assessment.

## Decision snapshot

**No, don't go ahead. Don't send your IBAN, PPS number or passport photo, and don't pay anyone. Status: `no_go`.** RR1, RR2 and RR3 are all `severity: high`, and together they match a known fake-job fraud. You'd lose money or have your identity used, and the job itself would not be real.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Income of at least €30,000 a year)
- `must_have` — direct: R2, R3, R4
- `important` — unclear: R5 (A quiet place to work)

R2, R3 and R4 — your background fits the stated tasks; R1 — unconfirmed, and the posting can't back it; R5 — only you can answer it.

**Opportunity ledger.** The fit is fine and the opportunity is the problem. The cheque with a transfer-back (RR1), the identity documents requested before any interview (RR2) and the €349 up-front payment (RR3) are each severe. The employer can't be established (RR4), and the contact route is off-platform and unverifiable (RR5, RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Income of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`).
- **What would change this:** the employer would have to be verified independently, for example through an official company registry entry and a call to a number you found yourself. Its process would also have to drop all three requests: the cheque, the identity documents before an interview, and the up-front payment. A real employer would not ask for any of them.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics" is named in the posting. I could not find a company, careers page or listing under that name | `[grounded]` two web searches returned no results |
| Mandate | Remote order processing, 15–30 hrs/week, "up to €26 an hour plus commission" | `[grounded]` posting |
| Working pattern | Self-set hours, no calls or video interviews, hiring entirely on Telegram | `[grounded]` posting |
| Pay against your floor | €26 an hour at 15 hours a week comes to about €20,300 a year, and you'd need about 22 hours a week at the ceiling rate to reach €30,000. "Up to" and the commission are unquantified | `[inferred]` arithmetic from the posting's own figures |
| Market calibration | Not run. I did not do the role-family sweep, because the employer failed first | `[generic]` none available |
| Unknowns | Legal entity, registered address, who you'd report to, contract type, actual rate | `[grounded]` none stated in the posting or chat |
| Contradictions | The posting says "no experience needed, full training provided" and "payroll set-up" comes before any interview. Hiring "passed first screening" came with no screening content. The chat then asks you to buy a laptop and headset, after it said the job had "no experience needed" and "full training provided" | `[grounded]` posting against the chat messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your constraint) | hard_gate | unclear | medium | hard_gate | The ceiling rate only reaches your floor at about 22 hours a week or more, and "up to" is not a rate. Moot while the employer is unverified | `[inferred]` arithmetic from the posting; `[grounded]` your stated floor | Don't pursue; a verified employer would state the rate in writing |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. This is your own account, with no inspectable artifact | `[grounded]` your description | none |
| R3 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day over 3 years, plus training two new starters | `[grounded]` your description | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket handling is your daily work. It is your account only | `[grounded]` your description | none |
| R5 | A quiet place to work | important | unclear | low | discovery | Nothing was said about your set-up | `[grounded]` silence | Yours to judge for any future remote role |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R1, hard_gate) | hard_gate | Only a ceiling rate and hour range, no contract | The gate can't be assessed without a stated rate and guaranteed hours | None applies; it's a term of the offer | A written offer from a verified employer | `[grounded]` the posting's wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Cheque to lodge, keep a share, send the rest on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it… keep €350… transfer the rest" | This is the overpayment pattern: the cheque is fake or later returned, and the transfer comes out of your real money | `[generic]` widely documented fake-cheque pattern; not proof about this sender | Why would an employer pay you before you've worked, and why does the surplus go to a third party rather than back to you? | confirmed |
| RR2 | IBAN, PPS number and passport photo requested before any interview | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport" | These are the documents needed for identity theft or for opening accounts in your name | `[generic]` a legitimate employer collects these after a signed offer | Why are payroll documents needed before an interview, and under what signed contract? | confirmed |
| RR3 | Candidate asked to pay €349 for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it" | An up-front fee with a promised refund is an advance-fee pattern | `[generic]` fee-before-work pattern | Will you supply the equipment directly and deduct nothing from me? | confirmed |
| RR4 | Employer not established | risk_signal | medium | "Velloway Logistics" | The company may not exist as described, or may have no public footprint. Combined with RR1–RR3, I take the first reading | `[generic]` pattern for unverified employers; `[grounded]` two searches found nothing | What is your registered company number and the link to this role on your own site? | unresolved |
| RR5 | Telegram-only process, no calls or video | risk_signal | medium | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | Avoiding any live, checkable contact is common in scams | `[generic]` pattern | Can I speak to a named manager on a company phone number? | unresolved |
| RR6 | HR contact on a non-company address | risk_signal | medium | "velloway.hr@postmail.example" | The domain is not a company domain I can tie to Velloway | `[inferred]` from the domain not matching the company name | Can you write from an address on your company's own domain? | unresolved |

## Application plan

Nothing here is a CV edit. Every row is a protective step, proposed for you to decide on.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Send no IBAN, PPS number or passport photo, and make no payment | See RR2, RR3 | `[generic]` identity-theft pattern | pending your approval |
| P2 | If the cheque arrives, don't lodge it | See RR1; banks may credit a cheque before it clears, and if it later bounces the money comes back out of your account | `[generic]` how cheque clearing works | pending your approval |
| P3 | Stop replying on Telegram, and report the account to Telegram and to the jobs site | See RR4, RR5 | `[generic]` standard reporting route | pending your approval |
| P4 | Report to An Garda Síochána, and tell your bank right away if you've already sent anything | See RR1–RR3 | `[generic]` standard fraud-reporting route | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers Remote Order Processing Coordinator". It returned no results, so the employer is not established (RR4) |
| 2. Role-family sweep | skipped | I did not run it, because the employer failed first. The market calibration line stays empty |
| 3. Hiring manager's public footprint | n/a | No name was given |
| Outside declared targets | yes | Searched "remote job Telegram cheque overpayment equipment partner scam Ireland". It returned no results and moved nothing |

## Upgrade menu

- The link to the live posting and the name of the jobs site → RR4 can be checked against the original listing.
- A number or registry entry for Velloway Logistics that you find yourself → RR4 could resolve.
- A deeper research pass (up to 5 more searches and 2 more fetches) → RR4 and the employer history. It runs on your say-so.

I can also write this up as `tuesday-dossier.md` if you want a record.

Questions:

1. (RR1–RR3) Have you sent anything, or paid or lodged anything? That means the IBAN, PPS number, passport photo, the €349, or the cheque. If so, tell me which, because it changes the steps.
2. (RR4) Which jobs site was it on, and do you still have the link to the live posting?

You can answer briefly, say "skip", or ask me to go straight to finding genuine remote roles that would meet €30,000.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.