I'll check the skill's reference files first, then give you the full assessment.
# Job Underwriting Assessment: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**Do not go ahead. Status: `no_go`, on the opportunity's own merits. Stop all contact and send nothing.** The pattern you describe is a standard fake-job scam, not an unusual hiring process. Each stage matches one of two known frauds: identity theft and the fake-cheque overpayment scam. You haven't sent anything yet, so you've lost nothing.

**Fit ledger** (about you as a candidate; it can't rescue the role):

- `hard_gate`: unclear: R1 (Pay meets your €30,000 floor)
- `must_have`: direct: R2, R3, R4 · adjacent: R5 (Order processing)
- `important`: unclear: R6 (Quiet place to work)

**Hard-gates line.** R1 is the only `hard_gate` row. Its fit is unclear. The posting's maximum doesn't reach your floor at the hours it offers (RR5).

**Opportunity ledger.** The job's terms are the least of the problem. The hiring process asks for identity documents and a payment before any real interview. It then sends you a cheque and asks you to forward most of it. Three red flags (RR1–RR3) are each enough on their own to walk away.

## Role reality

- **Role** [grounded]: remote order processing, 15–30 hours a week, "up to €26 an hour plus commission". There is no stated contract type, no company registration details, no named person and no address. Nothing says what an "order" is or whose orders they are.
- **Contradiction** [grounded]: the posting says "full training provided". The chat then says you must buy your own laptop and headset first. A real employer supplies equipment or expenses it. It doesn't ask you to pay a "partner" before you start.
- **Process** [grounded]: the whole thing runs through Telegram, with no calls or video. A "chat interview" followed by "you passed" in one sitting is not a screening process. It is a funnel.
- **Market calibration** [generic]: real order-processing or customer-ops roles usually start with an HR or company-email contact and an employment contract. They don't ask for a passport scan up front. They never pay you by sending a cheque that you forward on.

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| R1 | `hard_gate` | Pay meets your €30,000 floor | unclear | low | discovery | The posting says "up to €26/h", 15–30 h/week. [inferred] 30 h × €26 × 52 weeks is about €40,500 at the very top. At 22 h/week you'd need the full €26 all year to reach €30,000. The actual rate is never stated. |
| R2 | `must_have` | Attention to detail | direct | medium | none | About 60 Zendesk tickets a day at a parcel courier, 3 years (your account). |
| R3 | `must_have` | Confident with spreadsheets | direct | medium | none | You keep your team's weekly tracker in Excel (your account). |
| R4 | `must_have` | Good written English | direct | medium | none | Written customer service work, 3 years (your account). |
| R5 | `must_have` | Process orders | adjacent | medium | transferability | You handled parcel enquiries. That is not order entry, but it is close. |
| R6 | `important` | A quiet place to work | unclear | low | discovery | You haven't said. |

Your background is genuinely solid for a real version of this role. Scammers pick postings that fit people like you.

## Gap recovery queue

| Row | Gap | What would close it |
|---|---|---|
| R1 | The actual hourly rate and contract basis are unstated. | A written contract from a verifiable company. The chat has no company details at all, so this can't close. |
| R6 | Your workspace is unknown. | Your own answer. It is minor next to RR1–RR3. |

## Opportunity risk register

| ID | Class | Severity | Finding |
|---|---|---|---|
| RR1 | red flag | critical | **Passport photo, PPS number and IBAN requested before any real interview, "so payroll can set you up".** [grounded] A legitimate employer collects these after a signed offer, through HR. This is the standard identity-theft step. A passport plus a PPS number can be used to open accounts and take credit in your name. [generic] |
| RR2 | red flag | critical | **You're asked to pay €349 for equipment**, "refunded with your first wages". [grounded] An employer asking a new hire to pay up front, to a third party, is an advance-fee scam. The refund never comes. [generic] |
| RR3 | red flag | critical | **The €2,850 cheque.** [grounded] This is the fake-cheque overpayment scam. The cheque is forged or drawn on a compromised account. Your bank may credit it within days, because credit is not clearance. When it bounces, often weeks later, the whole amount is taken back from you, including what you forwarded. The "equipment partner" receiving your transfer is the scammer. [generic] |
| RR4 | red flag | high | **Free webmail-style contact (`postmail.example`) and a Telegram-only process, with no company domain, no named recruiter and no registered address.** [grounded] I haven't verified the company either way (see Evidence status). If it exists, scammers often impersonate real firms, so a real "Velloway" would not make this offer genuine. |
| RR5 | risk signal | medium | **Pay doesn't clearly meet your floor.** [inferred] See R1. |

## Application plan

Don't apply, and don't continue. Here is what to do now:

1. **Send nothing.** No IBAN, no PPS number, no passport photo, no €349.
2. **Never lodge or forward the cheque if it arrives.** If it arrives anyway, don't deposit it. Keep the envelope and cheque as evidence.
3. **Stop replying on Telegram.** Block and report @VellowayHiring in the app. Don't email `velloway.hr@postmail.example`.
4. **Report it.** Tell the jobs site so they remove the posting. You can also report it to the Gardaí, and your bank's fraud team can note it. These reports are most useful if you keep screenshots of the chat.
5. **If you sent anything earlier than you've told me:** call your bank's fraud line immediately. If your PPS number or passport details went out, tell the Gardaí as well. The Department of Social Protection and your passport issuer can advise on protecting your identity.
6. **Your IBAN** alone is low-risk, but there's no reason to share it with anyone who hasn't passed the checks above.

What to look for in a real job like this: a company email domain you can match to its own website, a video or phone interview with a named person, a written contract before any document requests, and no payment from you at any stage.

## Evidence status

Research tier: L0, no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page: does Velloway exist as described? | skipped | I ran no searches. The decision doesn't depend on the answer. Even a real company would be unlikely to be the one messaging you. |
| 2 | Role-family sweep: market-normal scope and pay | skipped | Not needed for the verdict. Market calibration above is `[generic]`. |
| 3 | Hiring manager's public footprint | n/a | No name was given. |

## Dossier offer

If you'd like, I can write this up as a `tuesday-dossier.md` file you can keep or share with your bank or the Gardaí.

## Upgrade menu

- **The cheque's issuing bank name and any sort code on it, if it arrives.** This lets me say more about how it's likely to fail.
- **The job site's name and the original posting link.** This lets me check whether the same text is posted under other company names.
- **A search of Velloway's footprint** (up to 5 searches and 2 fetches). This would show whether a real firm exists and is being impersonated.

## Questions

1. **R-all:** Has anything beyond your own replies in chat gone to @VellowayHiring, for example documents, any payment, or your address? If your address went out, the cheque will arrive by post.
2. **R-all:** Would you like me to run a quick check on whether a real Velloway Logistics exists? This is optional, and I'd only do it with your OK.
3. **R6:** Once you're clear of this, shall I help you search for genuine roles that fit your parcel-courier and Zendesk background and your €30,000 floor?

You can reply with a short answer to each, skip any, or say "skip all".

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.