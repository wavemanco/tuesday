## Decision snapshot

**Do not go ahead. Status: `no_go`.** This is almost certainly a fake-cheque and advance-fee scam, not a job. Don't send your IBAN, PPS number or passport photo. Don't pay anyone €349. Don't lodge the cheque or transfer anything out of your account.

**Fit ledger.** This is your fit against what the posting asks. It has no bearing on the decision.
- `hard_gate`: unclear: R1 (€30,000 a year floor)
- `must_have`: direct: R2 (spreadsheets); adjacent: R3 (attention to detail)
- `important`: direct: R4 (written English), R5 (quiet workspace)
- `preferred`: absent: none

**Hard-gates line.** R1, your €30,000 floor, is `unclear`. At 15–30 hours a week and "up to" €26 an hour, the posting allows about €20,000–€40,000 a year [inferred]. Reaching €30,000 would need about 22 hours a week at the top rate, every week. The gate is moot, because the employer fails on legitimacy.

**Opportunity ledger.** Every step of the process matches a known scam pattern (RR1–RR5). Nothing in the opportunity offsets that. Your own background is solid, so the problem is the employer, not you.

## Role reality

- The posting is a generic "order processing" role with a flexible schedule, no experience needed and a "full training" promise. This is the standard lure for these scams [generic].
- Hiring runs only on Telegram with no calls or video. Real employers don't do this for a payroll role [generic].
- The posting gives no registered company details, address or website. I haven't checked whether Velloway Logistics exists, so I can't say it's attributable to a real company [inferred].
- The HR contact is `velloway.hr@postmail.example`, a free-mail style address and not a company domain [grounded].
- Market calibration: €26 an hour for no-experience remote data entry is far above the norm [generic].

## Evidence map

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| R1 | `hard_gate` | At least €30,000 a year | `unclear` | `low` | `hard_gate` | Hours and rate are only "up to" figures [grounded] |
| R2 | `must_have` | Confident with spreadsheets | `direct` | `medium` | none | You keep your team's weekly tracker in Excel (your account) |
| R3 | `must_have` | Strong attention to detail | `adjacent` | `medium` | `presentation` | About 60 Zendesk tickets a day, plus training two new starters (your account) |
| R4 | `important` | Good written English | `direct` | `medium` | none | Customer-facing written support for 3 years (your account) |
| R5 | `important` | A quiet place to work | `direct` | `low` | `discovery` | Not stated, so I can't confirm it |

## Gap recovery queue

- **R1:** Closing it would need a real employer's actual hours and rate. Neither exists to check.
- **R5:** Closing it needs only your confirmation. It doesn't matter here.
- No other gaps. I'm not proposing CV changes, because you shouldn't apply.

## Opportunity risk register

| ID | Class | Severity | Finding |
|---|---|---|---|
| RR1 | red flag | high | Fake-cheque scheme. They send you a cheque for €2,850, tell you to keep €350 and wire the rest on. The cheque will bounce days or weeks later. By then the bank has released the funds, takes the full amount back from your account, and you've lost the money you sent [generic]. |
| RR2 | red flag | high | Advance fee. You pay €349 for a laptop and headset "refunded with your first wages". Real employers don't make you pay to start [generic]. |
| RR3 | red flag | high | Identity harvesting. They ask for your PPS number, IBAN and passport photo before any interview. That is enough for identity theft and for opening accounts in your name [generic]. |
| RR4 | red flag | high | Pace and conduct. You "passed" a chat interview within a few messages, with no call, no contract and no named person [grounded]. |
| RR5 | red flag | medium | The company can't be verified. There's no domain or registered details, and the contact uses a throwaway address [grounded]. |

## Application plan

Don't apply, and stop replying to @VellowayHiring [inferred]. Take these steps:
1. **Send nothing.** That covers the IBAN, PPS number, passport photo and any payment. If any of it has already gone, tell your bank straight away. Contact your bank before the cheque arrives, or right away if you've already lodged one. Ask them to flag your account. For your PPS number, ask the Department of Social Protection what to do.
2. **If the cheque arrives, don't lodge it.** If you have lodged it, don't send anything on. Tell your bank today.
3. **Report it.** Report it to the Gardaí, to the jobs site where you found the posting, and to Telegram (report and block the account). Keep the screenshots.
4. **Search for real work on your terms.** With your Zendesk, training and Excel experience, you'd suit customer support, logistics operations or order-processing roles at companies you can check. Real ones interview by video or phone and never ask you to pay or move money.

## Evidence status

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | `skipped` | The decision rests on the messages, which already match scam patterns. A search could only add confirmation. |
| 2 | Role-family sweep | `skipped` | The market comparison above is `[generic]`, not researched. |
| 3 | Hiring manager's public footprint | `n/a` | No hiring manager was named. |

The dossier is optional. If you'd like, I can write the findings up as `tuesday-dossier.md` for your records.

**Upgrade menu.**
- **Searches on Velloway Logistics and the Telegram handle** would show whether the company exists and whether others have reported it. I'd run up to 5 searches and 2 page fetches.
- **A screenshot of the original posting and its URL** would help your report to the jobs site.
- **Your CV** would let me suggest real roles for your background.

**Questions** (answer in a line, say "skip", or tell me to move on):
1. **R3:** Have you already sent them anything beyond answering the interview questions, such as documents, bank details or money?
2. **R1:** Do you want me to search for legitimate remote or hybrid roles that meet your €30,000 floor?
3. **RR5:** Which jobs site was the posting on? I can help you write the report to them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.