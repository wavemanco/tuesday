I'll read the skill's reference files first, then give you the full assessment.
I've searched twice and I'm checking how the skill grades your evidence. The full assessment is next.
**No, don't go ahead. Don't send your IBAN, PPS number, passport photo or the €349. Don't lodge the cheque.** Everything below is a recommendation, and the decision is yours.

## Decision snapshot

**Is this legit? No. RR1, RR2, RR3 and RR5 are `severity: high` red flags, and they match a known cheque-and-fees scam. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (€30,000 a year minimum)
- `must_have`: direct: R2 · adjacent: R3 (attention to detail), R4 (written English)
- `important`: adjacent: R5 (order processing)

R1: the posting gives no guaranteed rate or hours, so €30,000 is unproven. R2, R3, R4 and R5: plausible matches from your own account, and not what decides this.

**Opportunity ledger.** The role asks for money, funds to forward and identity documents before any contract (RR1, RR2, RR3). The employer can't be found (RR5), the process avoids any live contact (RR4), and the pay doesn't fit the market (RR6). I found no positive signal.

- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year minimum).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR5 (`severity: high`).
- **What would change this:** a contract on paper, a company I can verify independently and an email on the company's own domain. They would also have to drop the cheque, the transfer and the up-front payment. The cheque and the fee alone keep this at `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics: no web presence found, so not established. I used nothing from it | `[grounded]` search returned no results |
| Duties | "Order processing" with no tasks, systems or reporting line stated | `[grounded]` posting |
| Pay and hours | Up to €26/h plus unquantified commission, 15–30 h a week. At the top rate that is about €20,300 to €40,600 a year, and €30,000 needs about 22 h a week every week | `[grounded]` posting; `[inferred]` arithmetic |
| Process | Telegram only, no calls. A "passed interview" came from a chat, and the cheque followed straight after | `[grounded]` your messages |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200, interquartile range €28,400 to €34,100. €26/h is about 1.7 times that median once annualised. The guide excludes commission-only work | `[generic]` pay guide (snippet only); `[inferred]` comparison |
| Contradictions | The kit costs €349, yet you would send on about €2,500 of the cheque (€2,850 less the €350 "bonus"). They also asked for payroll details before any interview | `[grounded]` your messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | €30,000 a year minimum (your constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is unclear because the rate is "up to" and the hours are a range | `[grounded]` your constraint and the posting; `[inferred]` arithmetic | Would need a written guaranteed rate and hours; moot at `no_go` |
| R2 | Confident with spreadsheets | must_have | direct | low | none | You keep your team's weekly Excel tracker. Self-reported, nothing inspectable | `[grounded]` your account | None |
| R3 | Strong attention to detail | must_have | adjacent | low | discovery | About 60 tickets a day implies accuracy, but no error or QA figure was given | `[inferred]` from your account | See G1 |
| R4 | Good written English | must_have | adjacent | low | discovery | Zendesk is a written channel, but no sample or feedback was supplied | `[inferred]` from your account | See G1 |
| R5 | Order processing (implied; duties unstated) | important | adjacent | low | transferability | Parcel-ticket handling is close. The limit: no order-entry system is named | `[inferred]` from your account | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Accuracy and writing (R3, R4) | discovery | Volume and tools, but no quality measure or writing sample | Matters for genuine roles of this kind | CSAT or QA scores, a reply template you wrote, or a trainer guide for your two new starters | A sanitised QA summary or template | `[grounded]` your account; `[generic]` that such roles probe these |
| G2 | Order systems (R5) | transferability | Tickets about parcels, with no order-entry tool named | A bridge needs its limit stated | Rebooking, address corrections or refund processing | A process note | `[inferred]` from your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Cheque to lodge, keep a share, forward the rest | red_flag | high | "posting you a cheque for €2,850 … keep €350 … transfer the rest" | The cheque may be counterfeit or later returned unpaid. Your transfer would be real and hard to recover, and you could be used to move other people's money | `[generic]` known overpayment pattern; the request itself `[grounded]` | Why does an employer pay a new hire in advance and ask me to forward funds to a third party? | confirmed |
| RR2 | Up-front payment to start | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | A fee for a job that may not exist; "refund with first wages" is the bait | `[generic]` advance-fee pattern; the request `[grounded]` | Why can't the company supply or reimburse the kit directly? | confirmed |
| RR3 | IBAN, PPS number and passport before any contract | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | These are identity-fraud ingredients, and real payroll collects them after a signed offer | `[generic]` pattern; the request `[grounded]` | What contract and company details come before any ID request? | unresolved |
| RR4 | No calls, Telegram-only, instant hire | risk_signal | medium | "no calls or video interviews" | It avoids accountability and traceability | `[generic]` pattern | Can I speak with a named manager on a company line? | unresolved |
| RR5 | Employer not established; HR email off any company domain | risk_signal | high | "Velloway Logistics"; "velloway.hr@postmail.example" | No footprint, plus a generic-looking email domain and the flags above, which raises severity. Obscurity alone would be medium | `[grounded]` empty search; `[generic]` severity pattern | Where is the role on your own careers site, and who would I interview with? | unresolved |
| RR6 | Pay well above market for "no experience" | risk_signal | medium | "up to €26 an hour plus commission" | Inflated pay is the lure; the real figure may be nothing | `[generic]` band; `[inferred]` mismatch | What is the guaranteed hourly rate in the contract? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing and pay nothing: no IBAN, PPS, passport or €349 | RR1, RR2, RR3 | `[grounded]` register | proposed, your call |
| A2 | If the cheque arrives, don't lodge or forward it. If you already lodged any funds, tell your bank straight away | A lodged cheque can show as available before it clears, then be reversed | `[generic]` pattern | proposed, your call |
| A3 | Stop replying and keep the chat. Report the account to the jobs site, Telegram and the Gardaí | Protects other applicants | `[generic]` | proposed, your call |
| A4 | Look for genuine customer-operations or order-processing roles at couriers and logistics firms, which your experience fits. Bring any posting here to be vetted | The €30,000 floor sits near the market band | `[generic]` pay guide; `[inferred]` fit | proposed, your call |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and got no results, so the employer is not established. This moved role reality's organization row and added RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland cheque overpayment job scam Telegram". It returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide), snippet only. This moved the market calibration and RR6 |
| 3. Hiring manager's public footprint | n/a | Only a Telegram handle was given, which is not a name. A real name and company line would let this run |

I haven't repeated your IBAN here. Keep it out of any chat with them.

I can save this as `tuesday-dossier.md` if you want a record to keep.

**Upgrade menu**
- The jobs site and the original posting's link would let me check RR5 and help you report it.
- A cheque, if it arrives, or a real company registration number would change RR1 and RR5 only if verifiable independently.
- A deeper research pass (up to 5 more searches and 2 more fetches) is available, but it can't change this `no_go`.

**Questions**
- RR3 — Besides your chat answers, have you given them your home address, phone number or any ID document?
- RR5 — Which jobs site was the posting on, and did it link to a Velloway website?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.