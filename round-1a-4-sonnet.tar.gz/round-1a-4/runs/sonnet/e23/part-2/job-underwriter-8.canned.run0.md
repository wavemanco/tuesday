I'll read the skill's core references first so the assessment follows its format.
**No, this isn't a legitimate job, and I'd send nothing. That means no IBAN, no PPS number and no passport photo. RR1, RR2 and RR3 are each `severity: high`, and the status is `no_go`.** The cheque scenario is a well-known fraud pattern, and the other steps fit it.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (€30,000 a year minimum)
- `must_have` — direct: R2, R3, R4
- `important` — unclear: R5 (a quiet place to work)

R2, R3, R4 — your background matches the stated skills; R1 — the posting's pay can't be shown to reach your floor.

**Opportunity ledger.** The role fails on its own terms. It asks for money (RR2), a cheque to be passed on (RR1) and identity documents (RR3) before any interview, and the employer can't be found (RR5). Your fit is real, but a good fit doesn't change this.

- **Hard gates:** none failed; unconfirmed: R1 (€30,000 a year minimum).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`).
- **What would change this:** an employer you can verify independently, with no payment or cheque from you, and identity documents asked for only after a signed contract. Nothing in the posting or the chat points that way.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". I found no trace of it. | `[grounded]` search returned no results |
| Mandate | Remote order processing, 15–30 hours a week, "up to €26 an hour plus commission" | `[grounded]` posting |
| Hiring channel | Telegram only, no calls or video. Contact for problems is velloway.hr@postmail.example. | `[grounded]` posting and messages |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland have a median of €31,200 a year (interquartile range €28,400–€34,100). That is about €15 an hour at 40 hours a week, so "up to €26" is well above the market for an entry-level role. The survey excludes commission-only and freelance work, so this is a pattern and not a claim about this employer. | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide; hourly figure `[inferred]` by dividing by 2,080 hours |
| Pay at your floor | At the top rate, reaching €30,000 needs about 22 paid hours every week of the year. At 15 hours, the top rate gives €20,280. | `[inferred]` arithmetic on the posting's own figures |
| Unknowns | A real employer, contract type, who pays you, and what commission is paid on | `[grounded]` posting silent |
| Contradictions | "No experience needed" sits beside a €26 an hour ceiling. The "payroll" step asks you to pay out money. | `[inferred]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your constraint) | hard_gate | unclear | medium | hard_gate | The pay is "up to" with hours of 15–30 a week, so it could land anywhere from about €20k to €40k. Confidence grades your own stated constraint. | `[grounded]` your constraint and the posting's figures; `[inferred]` range | Moot given RR1–RR3 |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 tickets a day in Zendesk. This is self-reported, so I treat it as a lead and not proof. | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Written customer correspondence daily and training two new starters. | `[grounded]` your account | none |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said, and it's trivial next to the red flags. | `[grounded]` silence | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Real pay against your floor (R1, hard_gate) | discovery | Only an "up to" rate and a range of hours | Only matters if a real employer ever appears | A written offer stating a fixed hourly rate and contracted hours | A contract on an employer's own letterhead | `[grounded]` posting; `[inferred]` that this is moot for now |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Cheque to lodge, keep a slice, send the rest on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it… keep €350… transfer the rest" | The cheque is likely counterfeit or will be recalled. Your bank can reverse the credit after you've sent real money, and you carry the loss. | `[generic]` known overpayment-cheque pattern; `[grounded]` the quote | Why would an employer pay you before work starts, and why route money to a third party? | unresolved |
| RR2 | Pay-to-start equipment fee | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | A genuine employer has no reason to take money from you in order to hire you. | `[generic]` advance-fee pattern; `[grounded]` the quote | Why can't the company supply equipment or reimburse after purchase? | unresolved |
| RR3 | IBAN, PPS number and passport requested before any interview | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport" | These are enough to attempt identity theft or fraud in your name. Genuine payroll needs them after a signed contract. | `[generic]` hiring practice; `[grounded]` the quote | Why are these needed before an offer or contract? | unresolved |
| RR4 | Telegram-only hiring, no call or video | risk_signal | medium | "no calls or video interviews" | It avoids verifiable contact. I rated it medium on its own because some small firms do hire by chat. | `[generic]` | Can I speak to a named manager on a company phone line? | unresolved |
| RR5 | Employer not established | risk_signal | medium | "Velloway Logistics"; contact at postmail.example | The company may not exist. Its contact route is a generic mail domain and not a company one. | `[grounded]` no search results; `[generic]` small firms can have thin footprints | Can you show the role on your own careers site? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, PPS number, passport photo or €349 | see RR2, RR3 | `[grounded]` register | recommended |
| A2 | If a cheque arrives, don't lodge it or transfer anything onward | see RR1 | `[grounded]` RR1 | recommended |
| A3 | Stop replying and block the account. Report @VellowayHiring to Telegram and the posting to the jobs site. | Protects other applicants | `[generic]` | your call |
| A4 | If anything has already gone out, contact your bank at once and report it to the Gardaí | Early action limits damage | `[generic]` | your call |

There are no CV edits to propose. Nothing here is externally visible text, and nothing needs approval.

## Evidence status

Verified: none yet. Your background claims are self-reported leads.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics", which returned no results. Not established, which moved RR5 and role reality's organization row. |
| 2. Role-family sweep | yes | Searched "order processing coordinator salary Ireland per hour part-time", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It moved the market calibration and R1. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |
| Un-numbered | yes | Searched "remote order processing coordinator job Telegram cheque overpayment equipment fee scam", which returned no results. It moved nothing. |

## Upgrade menu

- Your IBAN stays with you and isn't needed for anything here.
- A real, verifiable posting (a link on the company's own careers page) would let me underwrite it properly, including pay against your €30,000 floor.
- A hiring manager's name would unlock a check of their public professional footprint.
- A deeper research pass (up to 5 more searches and 2 more fetches) isn't worth running for this posting. I'd use it on a real one.

I can write this up as a dossier file if you want one.

RR3 — Has anything already gone to them, such as a document, the IBAN or any payment? If so, tell me what, and I'll tailor the next steps. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.