**Don't pay anything or send anything yet. This email looks like a scam.** I haven't built a full prep pack for this "interview" because I don't think a real interview is behind it.

**Why it looks like a scam**
- **Fee to get an interview slot.** Real employers never charge candidates, and the €95 "equipment registration fee" is the first step of the fraud.
- **Passport photo and bank details before any interview.** Real employers collect these only after a job offer, for right-to-work checks and payroll. Fraudsters use them for identity theft and account takeover.
- **A cheque for €1,850 where you send the balance on.** This is the classic overpayment scam. The cheque bounces days or weeks after you deposit it. Your bank then takes the money back, and the money you sent on is gone.
- **A "supplier's account" and an "approved vendor".** These are probably accounts controlled by the scammer, or mule accounts.
- **Other warning signs.** The email is a generic invitation to an "office manager" video call, with a `.example` HR address. It asks for money before it will confirm the interview.

**What to do**
1. Don't pay, don't send your passport or bank details, and don't deposit any cheque.
2. Check the company. Look up Brennock Facilities Ltd in the Irish Companies Registration Office (CRO) register, then find a phone number through the registry or an independent source, not from the email. Ask whether they're hiring. Check whether the ad came from a real job board account.
3. If you've already sent anything, tell your bank straight away. If you sent your passport, contact the Gardaí, and also ask your bank about fraud monitoring. Report the email to the Gardaí, and to the job board where you found the ad.

**Your background is strong for real admin roles**
You've run a four-person appointment book and chased unpaid invoices. That maps well onto calendars, travel and invoice processing. Here is how I'd prepare for a genuine interview. It's generic prep from the ad's duties, not built from a real company's research.

- **Calendars and travel.** Expect "tell me about a time you juggled conflicting schedules." Use the four-physio appointment book. Prepare one specific clash and how you resolved it.
- **Invoices.** Expect "how did you handle late payers?" Describe your chasing routine and the outcome. Only give numbers you can stand behind.
- **Excel (your weak spot).** Expect "rate your Excel." Say "solid on the basics, building up" and name what you actually use. Then spend a few evenings on SUMIF, VLOOKUP/XLOOKUP, pivot tables and filtering. Make a small invoice tracker to show.
- **Remote working.** Be ready to explain how you manage your own time, communicate, and handle confidential data.
- **Questions to ask them.** What does a typical week look like? Which tools do they use for invoices and calendars? Who will you report to?

**Upgrade menu.** With a real JD, the employer's name, and the interviewer's role, I could build the full pack. That means persona-weighted question banks, a fit snapshot with your own words quoted, and a values sheet.

**Offers.** I can run a live drill with me as a hiring manager once you have a real interview. I can also draft a short message to the company, using contact details you've found independently, asking them to confirm the role.

**Questions**
1. Did the ad come from a job board or from the company's own website?
2. Have you sent any money, documents or bank details yet?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.