**Don't pay the €95, and don't send your passport or bank details. This email has the hallmarks of a fake-cheque scam, so I haven't built an interview pack for it. Preparing for this "interview" would only help the people running it.**

**Why it looks like a scam**
- **Fee to get an interview.** Real employers never charge candidates, whatever they call the fee ("equipment registration").
- **Passport and bank details before any interview.** That is identity theft material. A real employer asks for these only after a signed offer, through a proper HR process.
- **The cheque for €1,850, with the balance sent on to a vendor.** This is the core of the scam. The cheque bounces days or weeks after your bank shows the funds. By then you've sent real money to the "vendor", and your bank will ask you to repay it.
- **Everything is rushed and tied to a "slot".** The pressure to act before the interview is a standard tactic.
- **The only live person is an "office manager" on video.** That is an easy role to fake, and it makes the process feel legitimate.

**What to do**
1. Don't reply, pay, or send anything. Don't click any links in the email.
2. Check whether Brennock Facilities Ltd exists. Search the Companies Registration Office (cro.ie), and look up a phone number from an independent source. Don't use any number from the email. Check where the original ad appeared and whether the company has its own website listing the role.
3. If you've already sent money, your passport or your bank details, call your bank's fraud line straight away. Report it to An Garda Síochána. If you sent the passport, contact the Passport Office as well.
4. Report the ad to the job site where you found it.

**For real admin interviews**
Your background fits the duties in that ad well:
- **Calendars and bookings:** you ran the appointment book for four physios.
- **Invoices:** you chased unpaid invoices.
- **Word:** you're good with it.
- **Excel:** this is your gap. Expect a question or a practical test on it, such as a SUM, a filter, a pivot table or a VLOOKUP. A few hours practising those would help.
- **Travel booking:** you have no direct experience, so be ready to talk about how you'd approach it.

I can build the full prep pack as soon as there's a verified employer and role. It would have a question bank, answers built from your own experience, a gap-and-bridge map for Excel and travel, and questions for you to ask. If you'd rather start now, I can do one for a typical remote admin assistant role. In that case I'd need to know three things:
1. Do you have a real interview coming up anywhere, or should I do the generic version?
2. If there is a real one, can you paste the job ad, or tell me the company and role?
3. Do you want me to research the company online? I'll skip that unless you say yes.