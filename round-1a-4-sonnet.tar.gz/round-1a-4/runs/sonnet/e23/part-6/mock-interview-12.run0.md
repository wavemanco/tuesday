**Please don't pay, send your passport or send your bank details. This email has the hallmarks of a fake-cheque scam, so I haven't built an interview pack for it.**

Here is why it looks like a scam:

- **You're asked to pay before the interview.** Real employers never charge candidates a "registration fee". The €95 goes to an account the email calls a "supplier's account".
- **You're asked for your passport and bank details before any interview.** No genuine employer needs these until after a signed offer, and then only through a proper HR process. Scammers use them for identity theft and account takeover.
- **The cheque is the classic fake-cheque scam.** They send you €1,850 and ask you to forward the balance to a "vendor". The cheque eventually bounces, often days or weeks later, after your bank has already credited it. The money you sent on is real and you are liable for it. A legitimate employer would buy your equipment itself or reimburse you afterwards.
- **There is no real hiring process.** You are promised a cheque before any interview, and the only contact is a generic `hr@` address. A 30-minute call with an "office manager" is the only stage.
- **The greeting is generic.** The "Dear Aoife" opening and the lack of any detail about the role suggest a mass mailing.

**What to do now**
1. Don't reply, pay or send documents. If you've already sent anything, tell me what. If it was the passport or bank details, contact your bank straight away. Consider a fraud alert with your bank and ID-theft steps via the Garda, and report it to the Garda National Economic Crime Bureau.
2. Check the company independently. Look it up in the CRO (Companies Registration Office) register and find its real website and phone number. Don't use any links or contact details from the email. Ask about the role through the job board where you applied.
3. Report the ad to the job site and the email to your email provider.
4. Keep the email in case the Gardaí or your bank need it.

It's possible a real business's name was copied for this. If so, a call to their published number would confirm the role is fake.

**Where I can still help.** The duties in the ad (calendars, travel, Word and Excel, supplier invoices) are standard for remote admin roles. You'd bring real strengths to them: two years running a four-physio appointment book and chasing unpaid invoices. If you'd like, I can build a full mock-interview pack for a genuine remote admin role, using your clinic experience and covering the Excel gap honestly. If you share a real job description or tell me about a real interview, I'll tailor it.