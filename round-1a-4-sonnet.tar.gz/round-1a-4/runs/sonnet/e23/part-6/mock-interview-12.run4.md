**Don't pay anything, and don't send your passport or bank details. This email has the hallmarks of a fake-cheque scam, so I wouldn't prepare for this interview yet.**

## Why it looks like a scam

- **You pay before you're hired.** A real employer never charges a candidate a "registration fee", and the €95 goes to a "supplier's account", not the company's.
- **They want your passport and bank details before any interview.** That is what identity theft and mule-account setup need.
- **The cheque is the core of the scam.** You'd receive €1,850, deposit it and forward the balance to a "vendor". The cheque will eventually bounce, usually days or weeks later. The money you sent is real and gone, and the bank will claim back the bounced amount from you.
- **The interview is only a lure.** Nothing in the email asks about your skills.

## What to do now

1. **Don't pay, reply with documents or deposit anything.** If you've already sent the passport or bank details, tell your bank today. Ask them to watch the account, and consider a fraud alert on your identity. You can also report it to An Garda Síochána, since this looks like Irish IBAN and euro formatting.
2. **Check the company independently.** Look up Brennock Facilities Ltd in the Companies Registration Office (CRO) database. Find a phone number from a source other than the email, and compare the sender domain with any real company site. The `.example` address in this email isn't a real, working domain.
3. **Check where you applied.** If the ad was on a job board, report the posting there.
4. **If it turns out to be genuine**, which is unlikely, a real employer will still drop the fee, the passport-first request and the cheque. Ask them to interview first and send documents only after a written contract. Right-to-work checks happen after an offer, in person or through a proper HR portal.

## Prep for a real remote admin interview

Your background fits the role described in the ad, so this prep carries over to the next genuine invitation. Here is what to expect.

**Likely format:** 30 to 45 minutes by video, with an office manager or hiring manager. Expect practical, scenario-based questions rather than puzzles.

| Ad requirement | Your evidence | Gap and how to bridge it |
|---|---|---|
| Managing calendars | Ran the appointment book for four physios | Strong. Be ready to explain how you handled clashes, cancellations and double-bookings. |
| Processing supplier invoices | Chased unpaid invoices | Partial. You chased receivables, and the role is payables. Say you know the invoice cycle (PO, invoice, approval, payment) and the follow-up discipline, but don't claim you did accounts payable. |
| Word and Excel documents | Good with Word, okay with Excel | Real gap. Be honest about "okay" and name what you can do. Spend a few days on lookups, pivot tables, formatting and basic formulas. |
| Booking travel | None stated | Probably a gap. Don't claim experience you lack. Describe the coordination skills that transfer, and say you'd learn their booking tools. |
| Remote working | None stated | Prepare an answer on how you'd stay organised and communicate without an office. |

**Questions to rehearse (answers in your own words and based on what you actually did):**
- "Tell me about a day when the appointment book fell apart. What did you do?" Use the STAR format: situation, task, action, result.
- "How did you handle patients who ignored unpaid invoices?" This is your best story, so have the tone, the steps and the results ready.
- "How comfortable are you with Excel?" Give a short, honest answer with concrete examples, then say how you're improving.
- "How would you work remotely and stay on top of things?" Mention tools, routines and check-ins.
- "What would you do with two urgent requests from different people?" Describe how you prioritise and how you communicate it.

**Questions to ask them:** what a typical week looks like, which tools they use for calendars and invoices, how success is measured in the first 90 days, and how remote staff are supported.

**Highest-value prep:** an honest, specific answer on Excel, plus your invoice-chasing story told so it clearly connects to supplier invoices.

I didn't build the full prep pack file. It makes more sense once there is a verified employer to tailor it to.

Two questions would shape a proper pack:
1. Can you confirm a real company and interviewer for a genuine role? A job description or the interviewer's name would help.
2. Do you want me to draft a polite reply declining this offer, or a short report to the job board?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.