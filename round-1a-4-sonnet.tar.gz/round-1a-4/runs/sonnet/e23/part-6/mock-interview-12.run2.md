**Don't prepare for this interview. The email has the hallmarks of a fake-job scam, and I'd stop before you send anything.**

**Red flags in the email**
- **Upfront fee.** Real employers don't charge candidates a "registration fee". The €95 goes to a "supplier's account", not the company's.
- **Cheque-and-send-balance scheme.** They give you a €1,850 cheque and ask you to send the balance to a "vendor". The cheque will bounce days or weeks after the bank first shows the funds. By then your own money is gone, and the bank will hold you liable.
- **Passport photo and bank details before any interview.** Real employers ask for ID only after a signed offer, and in person or through a secure HR system. They never ask for it by email.
- **Interview before the fee.** They won't confirm your slot until you pay.
- **Everything runs through one address.** The `.example` domain in the email is a placeholder, so I can't verify the real sender. Check where the email actually came from.

**What to do now**
1. Don't pay, don't send the passport photo or bank details, and don't deposit any cheque.
2. If you've already sent anything, act today:
   - Contact your bank right away. Give them the IBAN and ask them to try to recall the payment.
   - If you sent your passport, watch for identity misuse and report it.
   - Report it to An Garda Síochána. If it was a bank phishing attempt, also tell your bank's fraud team.
3. Look up "Brennock Facilities Ltd" in the Companies Registration Office (CRO) register. Search for the company yourself, don't use any link from the email. Also check whether the job exists on the company's own site.
4. Report the ad to the job board where you found it. Forward the email to the board and to your email provider's phishing report.
5. If you want to double-check, email the company through contact details you find independently, not the ones in this message.

**Your background is genuinely good for real admin roles**, and I'm happy to build a proper prep pack for one. You have two years running a four-physio appointment book and chasing unpaid invoices, which matches calendar management and invoice processing. Excel is your gap, and I can help you plan how to address it. If you have a real interview coming up, send me:
1. The company, role and ad, ideally with the full job description.
2. Who you'll meet and in what kind of round.
3. A short CV or background summary.

I'd build the pack around those. I don't need your passport or any ID for interview prep.