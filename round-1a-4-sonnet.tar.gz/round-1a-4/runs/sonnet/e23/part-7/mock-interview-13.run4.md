I'll read the reference files the skill points to before building the pack.
Your prep pack for the Thursday call with Hannah is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/e23/part-7/rooms/case-13-denied-1608e79d/quillmoor-diagnostics_operations-coordinator_interview_pack.md`.

I built it for a recruiter screen on the advert and background you gave me, with Hannah's own agenda setting the weights. It has 19 questions, six reverse questions, a fit snapshot against the advert, and a list of claims the pack won't coach.

**Biggest risk:** production scheduling. The advert asks for coordination of production schedules, and your material says delivery scheduling. B1 is the question to rehearse most. Hold what you actually do, answer the slot honestly, and add a plan, not a claim.

**Where it's thin:**
- **Research:** all four web searches were refused, so there's no company values, strategy or Hannah background. A6 relies on the advert alone, and the pack says so.
- **Notice period:** your material doesn't give one, so A5 is a placeholder until you tell me.
- **SAP:** this is a stated gap in the pack, handled as "Never used SAP" plus a plan to learn.

**Your terms:** your £42,000 sits inside the £38,000–£44,000 range, and the pack keeps it as "hoping for", not a minimum. Likewise, "fine with two days, wouldn't want more than three" stays as you said it.

Say the word and I'll run a live drill as the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

What is your notice period? It decides A5 and closes the one gate row the pack couldn't settle.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Interviewer: Hannah Lowther, Talent Partner. Round: recruiter screen, a 30-minute phone call on Thursday at 2pm, which she will place to the mobile number on your application. Her stated agenda: salary expectations, notice period, how the hybrid pattern would work for you, what is prompting a move; then she describes the team and next steps.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for your own words, not a script, and every line about your past rests on a sentence you wrote, quoted next to it.

| Type | Meaning |
|---|---|
| VAL | Past behaviour against the company's published values (not used here: no values round is detected) |
| EXP | Whether your own account of your work holds up, and what was actually you |
| JD | The advert's stated duties, requirements and terms |
| CO | What you know about the company |
| CASE | A live problem set in the role |

Answer slots end without a question mark and ask nothing of this conversation. They are instructions for the call: answer from your own experience, or say plainly that the thing was not yours or did not exist, and return to what your quotes carry.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries across three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's line makes a probe on production scheduling likely. If any of your scheduling involved working with a planning, warehouse or quality function, say which and what part was yours; if none did, say so plainly and stay with the deliveries |
| F2 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you chase suppliers when orders slip. A named action beats an adjective |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The quote says chasing, not tracking, and the bridge is not stretched to cover it. Answer slot: if you follow supplier deliveries as they come in, say how you know an order has slipped; if there is no set way, or it was not yours, say so plainly and stay with the chasing |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Say it as written, and expect a defend-the-number probe: how the figure was counted, what it is sensitive to, the assumption you would defend least, and which part was yours (C1, C2) |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show any reporting. Answer slot: if you report on how deliveries perform, say what, to whom and how often; if you do not, or it was not yours, say so plainly and stay with the scheduling |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | The quote clears the stated length on its face. Say it as written; nothing needs adding |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, and says nothing about what the sheet did. Answer slot: say which tool the sheet was in and what it did, in your own words; if it was not Excel, say so plainly and describe what you built |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so: "Never used SAP." A plus, not a requirement, on the advert's own wording. Then how you would learn it, said as a plan and never as a past |
| F9 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | discovery | Whether an in-house stock system counts as similar is the interviewer's call, not a claim to make. Answer slot: say which parts of it you use day to day, in your own words; if you use it only for the stock count, say so plainly |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The gate is met on your own statement. Say both halves: two days is fine, and more than three is a limit. Keep "fine" as fine and "wouldn't want" as a limit, neither stretched |
| F11 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Inside the advertised range on your own statement. Keep "hoping for": it is a hope, not a floor |
| F12 | "your notice period" — Hannah Lowther's message | none given | none | [grounded] | hard_gate | Your material does not establish it |
| F13 | "what's prompting a move" — Hannah Lowther's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Say the three facts in the order you gave them: the office closes next year, the only offer is Reading, you don't want it. Add no reason for declining Reading and no date for the closure beyond what the quote says |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A) | Friendly, unstructured; Hannah's four stated topics asked casually, then a background walk-through | High. The recruiter-screen prior is Conversational plus a light Skeptic, and her own message lists the agenda, so A1 to A5 are near-certain topics | Treat casual questions as scored; keep each answer short; say the number and the limits once, plainly |
| Skeptic (B) | Quiet probing of the gaps and the motive: production scheduling, SAP, reporting, why not Reading | Medium to high. Screens often carry a knockout check, and the advert's three duties and ERP line meet F1, F5 and F8. The pack rests on the prior; no loop source for Quillmoor was read | Rehearse B1 until it is boring: hold the quote, answer the slot honestly, give a plan and never a past |
| Data-Driven Prober (C) | A quick "how was that counted" on the one figure you have | Low to medium. A recruiter can ask one such follow-up on the headline number, F4, so a short bank is enough | Know what you can and cannot say about how the figure was counted; say plainly where you do not know |
| Case / Strategist (D) | A short live problem from the role's own duties | Low. Recruiter screens rarely run cases, but the advert's duties make a quick "what would you do" plausible | Clarify first, then structure, then say how you would communicate; think aloud |
| Pressure / Stress (E) | A time-boxed "why you" | Low. Possible as a sixty-second challenge, not as a style for a screen | Pause, restate, hold the position the quotes carry through two follow-ups, concede the one thing they say you have not done |

Persona depth follows weight, with A over the usual count because Hannah's four stated topics each need their own row. No values-style round is detected, so Values/Behavioral and Peer banks are not built, and section 10 is absent. Her message establishes this one call and nothing beyond it.

## Question banks

Requirement coverage: each advert requirement against the questions that cover it.

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1, D1, D3, E2 |
| Track supplier deliveries and chase late orders | A2, B1, D1 |
| Keep stock records accurate | C1, C2, D2 |
| Report weekly on on-time dispatch | B3 |
| 2+ years in operations or logistics coordination | A2 |
| Confident with Excel | C3 |
| ERP experience (SAP or similar) a plus | B2, E1 |
| Hybrid, two days a week at Avonmouth | A4 |
| £38,000–£44,000 | A3, B5 |
| Hannah's topics: notice period, what is prompting a move | A5, A1, B4 |

The single most predictable objection to this candidate is B1, production scheduling against deliveries scheduling. It is the highest-ROI prep in the pack: it will be asked in some form, and a calm, honest answer changes the call.

### A. Conversational / Rapport Builder (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, what's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Three beats, each the quote's own: the Bristol office is closing next year; the only offer is relocating to Reading; you don't want that. Tell them in your own words, then one sentence on what in the advert draws you, chosen from its own lines. Answer slot: if no line in the advert stands out beyond the move itself, say so plainly and ask her to tell you more about the role. Do not add a reason for declining Reading | F13 is the evidence and Hannah's own stated topic; EXP because it tests whether your account of your own situation is consistent |
| A2 | "Give me the two-minute version of your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Three beats, each from its quote: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell them in your own words and stop; let her pick what to probe | F6, F2 and F4 are the rows this walk-through carries; EXP because it is your account of your own work |
| A3 | "What are you hoping for on salary?" | JD | [grounded] "I'm hoping for £42,000." | Say the number once, as you said it: you are hoping for £42,000. The advert's range is £38,000–£44,000, so say nothing that makes it sound like a minimum. Then stop and let her respond | F11 is the evidence and a stated topic; JD because it scores a term the advert states |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Give both halves: you live in north Bristol, two days at Avonmouth is fine, and more than three is not what you want. Say the limit in the same breath as the yes, because it is the part she needs. Do not add a commute time or a reason beyond the quote | F10 is the evidence and a stated topic; JD because it scores a term of the role |
| A5 | "What's your notice period?" | JD | [generic] | State the period your contract gives, in your own words, and what it depends on if it depends on anything. If you are not sure, say so plainly and say when you will confirm it. The pack does not know your figure | F12 is the gate row and Hannah's stated topic; JD is the closest tag since it scores a term of the offer; generic because it makes no claim about your past |
| A6 | "What do you know about Quillmoor?" | CO | [grounded] | Say what the advert tells you: a diagnostic-test manufacturer with about 400 staff, and the Avonmouth site in Bristol. Answer slot: if you have read anything beyond the advert, say what; if you have not, say so plainly and say what the advert's duties tell you about the work, then ask her to say more | The advert is the one source on the company in hand, since research was refused; CO because it scores homework depth |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. Which of that have you done?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I schedule deliveries for our three depots." Answer slot: if any of your scheduling involved working with a planning, warehouse or quality function, say which and what part was yours; if none did, say so plainly and stay with the deliveries. Hold through two follow-ups by returning to the deliveries, never by adding to them. Then say, as a plan and never a past, what you would ask first to learn the production side | F1 is where the advert presses hardest and the likeliest place to be probed; JD because it scores the first stated duty |
| B2 | "Have you used SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say it as you said it: never used SAP, and you run your own in-house stock system. The advert lists ERP as a plus, so this is a gap you can name calmly. Answer slot: say which parts of the in-house system you use day to day; if you use it for little beyond the stock count, say so plainly. Then give the plan: how you would learn SAP, said as a plan | F8 is the stated gap and F9 the adjacent question of what counts as similar; JD because the advert states the ERP line |
| B3 | "How much reporting on delivery performance do you do today, if any?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The advert asks for weekly reporting on on-time dispatch. Answer slot: if you report on how deliveries perform, say what, to whom and how often, in your own words; if you do not, or it was not yours, say so plainly and return to the scheduling and chasing | F5 is the row with nothing in your material; JD because it scores a stated duty |
| B4 | "Reading is on offer. Why not take it?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Hold the quote: the only offer is Reading and you don't want it; you live in north Bristol. Answer slot: if there is a reason you don't want Reading, say it in your own words; if there is no particular reason beyond preferring to stay in Bristol, say so plainly and return to what you want here. Keep the same account you gave in A1 | F13 and F10 together; EXP because it tests whether the account stays the same under cross-examination |
| B5 | "You said £42,000. Why that figure?" | JD | [grounded] "I'm hoping for £42,000." | Hold-then-concede. Hold the figure through two follow-ups, as a hope: "I'm hoping for £42,000." Answer slot: if there is a basis for the figure, say it in your own words; if there is none beyond what you are hoping for, say so plainly. Decide before Thursday what you would say if she names a lower number; the pack does not choose that for you | F11 is the evidence; JD because it scores a stated term, and the hold follows the pressure structure |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the sentence as written, then answer in your own words: how it was counted, what it is sensitive to, and the assumption behind it you would defend least. Name that assumption before she does. If you do not know how it was counted, say so plainly | F4 carries the only figure on your side, and every figure on a CV is a probe target; EXP because it tests how well you know your own number |
| C2 | "How much of that fall was down to your rebuild?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if you can say how much of the fall the rebuild accounts for, say how you know; if you cannot, say so plainly and stay with what you rebuilt, as the quote states it. Never describe a cause the quote does not carry | F4 again, as the attribution probe; EXP because it scores what was actually you |
| C3 | "How comfortable are you in Excel? What did that spreadsheet do?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say which tool the stock-count spreadsheet was in and what it did, in your own words; if it was not Excel, say so plainly and describe what you built. Do not use the word advanced unless it fits what you can walk through | F7 is the Excel row and the quote says spreadsheet only; JD because the advert states Excel confidence |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you at noon that a delivery needed for tomorrow's production run will be two days late. What do you do?" | CASE | [generic] | Structure it: what you would ask first (what is late, what it feeds, how firm the new date is); who needs to know (planning, the warehouse and QA are the advert's three functions); what alternatives you would ask the supplier for; what you would record and when you would check again. The question needs no claim about your past, so the guidance makes none | A live problem from the late-orders duty; generic because it is a pattern for the problem |
| D2 | "The stock record says forty, the shelf has thirty-four. What do you do?" | CASE | [generic] | Structure it: recount first; check recent movements for the cause; decide whether the record or the count is wrong; correct the record with a trail; tell whoever owns the record. No claim about your past | A live problem from the stock-record duty; generic |
| D3 | "Planning wants an order out on Friday, the warehouse says Friday is full and QA has not released the batch. What do you do?" | CASE | [generic] | Structure it: get each constraint plainly; find which is movable and which is not; take options to planning rather than a verdict; say what you would tell each party and when. No claim about your past | The advert's three-way coordination duty set as a decision; generic |

### E. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over someone who has used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." "Never used SAP — we run our own in-house stock system." | Hold-then-concede in sixty seconds. Hold: four years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots and chasing suppliers when orders slip, and the stock-count rebuild with discrepancies down about a third over a year. Concede the one thing you have said: never used SAP, and you run an in-house stock system. Hold the three beats through two follow-ups without adding to them | F8 is the conceded gap and F2, F4 and F6 the held ground; JD because it scores fit against the advert, in a pressure register |
| E2 | "You're from a wholesaler. Isn't a manufacturer a big step?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Hold: four years at a building-supplies wholesaler, scheduling deliveries and chasing suppliers. Answer slot: if any of your work touched manufacturing or production, say what; if none did, say so plainly and stay with the deliveries and suppliers. Pause before answering and do not defend more than the quotes carry | F1 and F6; JD because it scores whether the background transfers to the advert's duties |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Of the four duties in the advert, which takes most of the week: scheduling, supplier chasing, stock records or the weekly reporting?" | Shows you read the advert's four duties and gives you the weighting before a later round |
| R2 | "How are the two Avonmouth days usually set: fixed days, or agreed within the team?" | Tests the hybrid you said is fine at two days, and shows whether a third day is ever expected, which matters to your limit |
| R3 | "What does the team use today to track stock and supplier deliveries, and how would a new starter be trained on it?" | Meets the SAP gap directly and asks about training, which is the plan you want to give |
| R4 | "Who would I work with day to day across planning, the warehouse and QA?" | The advert names those three functions; it tells her you are thinking about the coordination, not only the tasks |
| R5 | "What would a good first six months look like in this role?" | Moves the conversation from screening to the work, and gives you something to aim at |
| R6 | "After this call, who are the next conversations with, and how long does the process usually take?" | Hannah said she will cover next steps; this fills the gaps and gives you a timeline to plan around |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says deliveries, not production schedules. B1's slot stays inside the deliveries |
| Tracked supplier deliveries | Inflated form of F3 | F2's chasing quote at its own scope. The limit is the pack's observation: your material says chasing, not tracking |
| Advanced Excel, formulas, macros or pivot tables | Inflated form of F7 | F7's quote at its own scope: "I rebuilt our stock-count spreadsheet". C3's slot asks only what the sheet did |
| ERP or SAP experience | Negative you stated, F8 | The plain acknowledgment F8 gives: "Never used SAP." Then a plan, never a past |
| My in-house system is an ERP | Inflated form of F9 | F9's quote at its own scope: "we run our own in-house stock system". B2's slot asks only which parts you use |
| I cut discrepancies by a third | Inflated form of F4 | F4's quote at its own scope: "discrepancies fell by about a third over a year". C2's slot asks only how you know how much of the fall was the rebuild |
| £42,000 is my minimum | Inflated form of F11 | F11's quote at its own scope: "I'm hoping for £42,000." |
| I'm flexible on how many days I'm in | Contradicted by F10's quote | F10's quote only: "I wouldn't want more than three." |
| I'm being made redundant | Inflated form of F13 | F13's quote at its own scope: the Bristol office is closing and the only offer is relocating to Reading |

## Sources

Provided: the advert text, your background in your message, and Hannah Lowther's message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Every call was refused. Would have moved A6 and the framing in A1; section 10 stays absent either way, since no values round is detected |
| 2. Quillmoor Diagnostics interview process | unavailable | Every call was refused. Would have moved the loop beyond this call; Hannah's message establishes only this session, so the weights rest on the recruiter-screen prior |
| 3. Quillmoor Diagnostics strategy or news | unavailable | Every call was refused. Would have moved A6 and added a CO question grounded in current priorities |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Every call was refused. Would have moved the interviewer read, which is absent, and a reverse question tied to her path |
| 5. Representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent, all refused:

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics Avonmouth news strategy" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

## Upgrade menu

- Your notice period → A5 becomes your own figure and F12 moves from not established
- A line on how the stock-count figure was counted → F4 gets an inspectable basis, and C1 and C2 become story-mapped rather than slots
- Which tool the stock-count spreadsheet was in, and what it did → F7 moves from low, and C3 becomes story-mapped
- Whether you report on delivery performance, and how → F5 and B3 stop being slots
- Whether any of your scheduling involved planning, warehouse or quality functions → F1 and B1 get a real second branch
- Which parts of your in-house stock system you use → F9 and B2
- Permission to search the web → Sources targets 1 to 4 can run: company facts for A6, a CO question grounded in current news, and the interviewer read; a deeper pass would add up to 6 more searches and 2 more fetches, several more minutes
- Hannah's recruiter guidance, usually one message → coverage of any call topic beyond her four stated ones
- A tuesday-dossier.md from an earlier evaluation → verified evidence and prohibited claims for the banks, never required
