I'll read the skill's reference files before building the pack.
Saving the pack is done. I'm making one small fix to a rationale line, then I'll hand it over.
Sam, your prep pack for Thursday's call with Hannah is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/e23/part-7/rooms/case-13-denied-7c6830ed/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. It has 18 rehearsal questions, a table matching your experience to each line of the advert, and a list of claims not to make.

I built it for a recruiter screen around Hannah's four stated topics. Web search was refused, so I couldn't research Quillmoor or Hannah. Everything about the company comes from the advert alone, and the pack's Sources section says so.

- **Pay and hybrid:** both match your quotes. £42,000 sits inside £38,000–£44,000, and two days at Avonmouth is fine, with three as your limit.
- **Why you're moving:** this is the one to rehearse most (B1). Say the facts as you gave them: the office is closing next year, and the only offer is Reading, which you don't want. Don't say "redundant" or criticise your employer. The pack also prepares you for "would you still be looking if the office weren't closing?"
- **Gaps:** "I've never used SAP" is a plain statement. Your material doesn't show production scheduling across planning, the warehouse and QA, or weekly dispatch reporting. It also says "spreadsheet", not which tool, so I couldn't treat it as Excel experience. Where your material is silent, the pack gives slots for you to answer truthfully in your own words.
- **Notice period:** I don't have yours, so A4 is a slot. Check your contract before Thursday.
- **Your stock-count figure:** be ready to say how the "about a third" was counted, and be honest that the pack can't tell how much of the fall was your rebuild.

Say the word and I'll play Hannah on B1, the question the pack names as your highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, a 30-minute phone call; Hannah Lowther (Talent Partner) rings the mobile number on your application.
**Her stated agenda:** your salary expectations, your notice period, how the hybrid pattern would work for you, and what is prompting a move; then she tells you about the team and the next steps.
**Built on:** the advert, your background message and Hannah's LinkedIn message. No web research reached this pack (see Sources), so everything about the company comes from the advert alone.

## How to use this pack

Personas are how a question arrives; types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | The advert's stated requirements and terms |
| CO | What you know about the company |
| CASE | A live problem set in the role |

Provenance labels: `[grounded]` traces to a document you provided; `[inferred]` is a derivation, named; `[generic]` is a pattern with no claim about you or Quillmoor. An answer slot is an instruction for the call, not a question for you now: it asks you to answer from your own experience, and it always allows "that was not mine, or did not exist".

## Prep triage (two days)

1. Say B1 aloud until it is boring. It is the highest-ROI prep in this pack: Hannah has told you she will ask it, and it is the answer with the most room to go wrong unscripted.
2. Settle three facts before the call: your contractual notice period (A4), whether £42,000 is firm and whether anything lower would work for you (A2, D1), and your wording for the hybrid pattern (A3).
3. Time A1 to 90 seconds.
4. Answer the slots on F1, F2, F4, F6 and F8 to yourself, from your own experience, and rehearse B3 and B4.
5. Spend twenty minutes on Quillmoor's own website for A5.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert puts planning, the warehouse and QA in the job, so expect a probe on whether your scheduling touched other teams' plans. If it did, say which teams and what you did, in your own words; if it did not, or it was not yours, say so plainly and stay with the depots |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | discovery | The quote carries the chasing: "I chase suppliers when orders slip." It does not show whether you track deliveries. Answer slot: if you track when supplier deliveries arrive, say how, in your own words; if you do not track them as such, say so plainly and stay with the chasing |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | The quote already speaks to stock accuracy, but it is your own account with nothing inspected behind it, so expect a defend-the-number probe. Say it as it stands: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Answer slot: say how the figure was counted, what it is sensitive to, the assumption you would defend least and which part was yours, each in your own words; if you do not know how it was counted, say so plainly |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show whether you report on delivery performance. Answer slot: if you report on deliveries, say what you report and how often, in your own words; if you do not, say so plainly and say how you would set up a weekly report |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | The quote says logistics coordination in the advert's terms, and four is above the advert's two. Say it as written; it is a message line with nothing inspected behind it, so a CV or reference may be asked for |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | The quote says spreadsheet, not which tool. Answer slot: the advert asks for Excel, so expect a probe on the tool and what you did in it. If it was Excel, say so and what you did there, in your own words; if it was another tool, say so plainly and say how you would get to the same level in Excel |
| F7 | "ERP experience (SAP or similar) a plus" — advert, the SAP half | "Never used SAP — we run our own in-house stock system" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then how you would learn it, said as a plan and never as a past. The advert's own phrase is "a plus" |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" half | "Never used SAP — we run our own in-house stock system" — your message | low | [inferred] | discovery | The quote says "we run our own in-house stock system", at "we" scope, and does not say what you do in it or whether it is an ERP. Answer slot: if you work in that system yourself, say what you do in it; if you do not, or it is not an ERP, say so plainly and stay with the quote |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your figure sits inside the advertised range. Say it as you said it: "I'm hoping for £42,000." Whether anything lower would work is your decision; the pack does not supply one |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | The term is met on your own account. Say both halves as you gave them: two days at Avonmouth is fine, and you would not want more than three. "Would not want" stays a preference in your words; do not harden it into "cannot" or soften it into "flexible" |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | discovery | Your material does not give your notice period. Answer slot: state the period in your contract, as it is; if you do not know it exactly, say so plainly and say when you will confirm it |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | The quote answers the question: say it as it stands. It gives a reason for leaving, not a reason for choosing this role. Answer slot: if something about this role draws you, say what, in your own words; if the closure is the whole reason right now, say so plainly |

## Persona table

The loop for this session is established by Hannah's own message: one 30-minute phone call, with her agenda stated. Rounds after it are not established, so the pack prepares only this call.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A) | A friendly four-item agenda: pay, notice, hybrid, then your story | High. The recruiter-screen prior is Conversational plus a light Skeptic, and Hannah's message sets exactly that tone and sequence | A 90-second arc for A1 built only from the quotes it names; treat every casual question as scored |
| Skeptic (B) | Quiet probing of why you are leaving, why here, and the gaps against the advert | High. "What's prompting a move" is on her stated agenda (F12), and the advert's manufacturer setting, SAP line and dispatch report are the thinnest rows (F1, F4, F7, F8) | Rehearse B1 until it is boring; state each gap in your quotes' own terms, with an answer slot where the material is silent |
| Data-Driven Prober (C) | One or two follow-ups on the figures and the spreadsheet | Medium. Two of your own sentences carry a figure or a rebuild (F3, F6), and a recruiter may check them lightly | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Pressure (D) | A push on the salary number, a time-boxed "why you", an attribution challenge | Low to medium. Below the recruiter prior, but a pay negotiation can turn firm, and the pay figure is yours (F9) | Pause, restate, hold the figure and the quotes through two follow-ups, concede only what is true |
| Case / Strategist (E) | A quick scenario drawn from the advert's three-way coordination | Low. Below the recruiter prior, included so the style is not new on the day | Clarify, then structure, then answer; think aloud |

Not included: a Values round and a Peer persona, because nothing in the loop source (Hannah's message) names either.

## Question banks

### A. Conversational / Rapport Builder (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me about your background and what you do day to day." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler", "I schedule deliveries for our three depots and chase suppliers when orders slip", "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Three beats, each as its quote states it: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for your three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell it in your own words in about 90 seconds and stop. Keep the advert's wording out of your history; let her draw the match | The biography is the opener and is scored for economy. F5, F2 and F3 are the rows it draws on; EXP because it tests what was actually yours |
| A2 | "What are your salary expectations for this role?" | JD | [grounded] "I'm hoping for £42,000" | Give the figure you gave me, once: "I'm hoping for £42,000." Then stop and let her respond. Answer slot: if she asks whether that is firm, answer from what you have decided before the call; if you have no lower number in mind, say so plainly | Pay is the first item on her agenda, and F9 puts your figure inside the advertised range. JD because the range is the advert's term; D1 rehearses the push |
| A3 | "How would the two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Say both halves as you gave them: two days at Avonmouth is fine, and you would not want more than three. Keep "would not want" as a preference in your own words. Answer slot: if she asks which days or how you would get there, answer from your own situation, and say only what you have decided | Hybrid pattern is on her agenda and F10 is a term the advert sets. JD because the pattern is the advert's own line |
| A4 | "What's your notice period?" | JD | [grounded] | Answer slot: state the period in your contract, exactly as it is. If you do not know it exactly, say so plainly and say when you will confirm it. Say nothing about flexibility unless it is true and you have checked | On her agenda, and F11 shows your material is silent on it. JD because it is about availability for the advertised role; the guidance makes no claim about your past |
| A5 | "What do you know about Quillmoor, and what interests you in the role?" | CO | [grounded] | Use only what you have actually read. The advert gives a diagnostic-test manufacturer of about 400 staff, a site at Avonmouth, and a role linking planning, the warehouse and QA. Anything beyond that has to come from your own reading of their pages before Thursday. Answer slot: say what you have read and what stood out, in your own words; if you have read little beyond the advert, say so plainly and ask her to tell you more, which she has said she will | Hannah has said she will tell you about the team, so expect a light version of this question. This pack could not research the company, so it is grounded in the advert only; CO because it tests homework depth |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | The highest-ROI rehearsal in this pack, and the deepest: rehearse three follow-ups, B2 and then why this company, and then what would have kept you. Say the facts as you gave them, in order and briefly: the Bristol office is closing next year, the only offer is relocating to Reading, and you do not want that. Hold through two follow-ups by returning to those facts, never by adding to them. Concede plainly what the facts are: the move is driven by the closure. Do not say "redundant", do not criticise your employer, and add no dates beyond "next year". Answer slot: if something about this role draws you, say what, in your own words; if the closure is the whole reason right now, say so plainly | She has said she will ask it, and the quote gives a reason for leaving rather than for choosing this role (F12). EXP because the answer rests entirely on your own circumstances |
| B2 | "If your office weren't closing, would you still be looking?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Answer slot: if you would have stayed, say so; if you had already been thinking of leaving, say that, in your own words. Either is fine said plainly; say only the one that is true | The consistency test on F12: it checks that the reason you gave is the reason. EXP because only your own account can answer it |
| B3 | "You've worked at a wholesaler and we make diagnostic tests. Where would you be weakest on day one?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip", "Never used SAP — we run our own in-house stock system" | Name the weakness in your quotes' own terms: your scheduling is deliveries for three depots, and you have never used SAP. Then a plan, said as a plan: what you would do first to learn how Quillmoor's schedules and systems work. Answer slot: if you have worked on production schedules or with a QA team, say what you did; if not, say so plainly and stay with the depots. Never claim manufacturing experience the quotes do not carry | The strongest objection from the advert's side is F1, with F7 behind it. JD because it scores the stated requirements, including their gaps |
| B4 | "The advert mentions SAP or similar ERP experience as a plus. Where do you stand?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Say it as it is: "I've never used SAP." Then the second half of the quote at its own scope: "we run our own in-house stock system". Answer slot: if you work in that system yourself, say what you do in it; if you do not, or it is not an ERP, say so plainly. Finish with how you would learn SAP, as a plan. Do not call it ERP experience | F7 and F8: one stated absence and one half-reach. The advert's own wording is "a plus", so the honest answer costs little; JD because it scores a stated requirement |
| B5 | "The advert has a weekly on-time dispatch report. What would that look like for you?" | JD | [grounded] | Answer slot: if you report on delivery performance now, say what you report and how often, in your own words; if you do not, say so plainly and say how you would set up a weekly report. Name the measures you would start with only if you can stand behind them | F4 is the one requirement with no evidence at all, so this is the mid-list item most likely to be a free miss. JD because it scores the advert's reporting line; the guidance makes no claim about your past |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | The figure is yours to defend, so say what you can and cannot say about it. Answer slot: say how it was counted, what it is sensitive to, and the assumption you would defend least, each in your own words, before she asks; if you do not know how it was counted, say so plainly. Keep the quote's own terms: discrepancies fell by about a third over a year | Defend-the-number: a quantified claim is the likeliest target (F3). EXP because it tests how well you know your own result |
| C2 | "The advert asks for confidence with Excel. Walk me through what you rebuilt in that stock-count spreadsheet." | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | The rebuild is the one fact the quote gives: you rebuilt it. Answer slot: say what you changed, in your own words; if you do not remember the detail, say so plainly. If it was Excel, say so and what you did there; if it was another tool, say so plainly and say how you would get to the same level in Excel | F6: spreadsheet is not the same word as Excel, and the Excel line is the advert's. JD because it scores a stated requirement |
| C3 | "Walk me through what you do when a supplier's order slips." | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | The quote gives one fact: you chase suppliers when orders slip. Answer slot: if there is a usual first step, say it, in your own words; if it varies, or there is no set routine, say so plainly. Then stay with what you actually do | F2 is the best-matched row and still a message line with nothing inspected. JD because it scores the advert's chasing line |

### D. Pressure (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our range is £38,000 to £44,000. Could you do £40,000?" | JD | [grounded] "I'm hoping for £42,000" | Pause, restate the question, then hold the figure you gave: "I'm hoping for £42,000." Hold through two follow-ups without adding a reason you have not got. Concede only what is true: whether anything lower works for you is your decision, made before the call. Answer slot: if £42,000 is your number and you have no lower figure in mind, say so plainly | F9 is the one claim on this call that is entirely yours and nothing can be inspected behind it. JD because the range is the advert's term |
| D2 | "Sixty seconds: why you over someone who has already worked in manufacturing?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler", "I schedule deliveries for our three depots and chase suppliers when orders slip" | Your quotes carry four years of logistics coordination, scheduling deliveries for three depots and chasing suppliers when orders slip. Say those, in your own words, and let her draw the comparison. Answer slot: if you have worked in a manufacturer before, say where and what you did; if not, say so plainly. Do not claim the experience you are being compared against | Time-boxed pressure on F1 and F5, the wholesaler-to-manufacturer gap. JD because the comparison is made against the advert |
| D3 | "How much of that stock-count result was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold the part the quote carries: you rebuilt the spreadsheet. Concede specifically that the quote says discrepancies fell, not that the rebuild alone caused it. Answer slot: if you know what else changed over the year, say so; if you do not know how much of the fall was the rebuild, say so plainly | The attribution probe on F3; the hold is exactly what the quote carries and no more. EXP because it tests what was yours |

### E. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier says a delivery will be a week late, and QA needs it for Thursday's run. What do you do first?" | CASE | [generic] | Clarify before answering: what is affected and by when, what the supplier can really commit to, and who else needs to know. Then structure: the options, who you would tell in planning, the warehouse and QA, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem built from the advert's three-way coordination and its late-order line (F1, F2). `[generic]` because it is a pattern for the problem, not a fact about this employer |
| E2 | "Last week's on-time dispatch figure dropped. How would you find out why?" | CASE | [generic] | Clarify first: what dropped, against what, over what period. Then segment: by supplier, by product, by depot or site, by day. Say your first check and your hypothesis aloud. No claim about your past is needed | A diagnose-the-metric case from the advert's weekly report line (F4). `[generic]` for the same reason as E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work with most closely across planning, the warehouse and QA in the first month?" | It uses the advert's own three-way line, so it shows you read the role as coordination across teams, and it tells you how real that structure is |
| R2 | "Which system do the three teams record stock and orders in today, and how is someone new trained on it?" | It meets the SAP gap (F7, F8) from the forward side, without a claim about your past |
| R3 | "How are the two Avonmouth days usually arranged, fixed days or agreed with the team?" | It tests the hybrid pattern against your own limit (F10) before an offer, not after |
| R4 | "Who reads the weekly on-time dispatch report, and what does the figure look like now?" | It shows engagement with the reporting line (F4) and tells you what you would be measured on |
| R5 | "When would the team like someone to start, and how does that fit the next stages?" | It lets the notice period (F11) come up as a planning fact, not a verdict |
| R6 | "What would make a candidate stand out at the next stage?" | It turns the end of a screen into learning how the next round is weighed, and she has said she will cover next steps |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B3, D2, E1 |
| "track supplier deliveries and chase late orders" | C3, E1 |
| "keep stock records accurate" | A1, C1, C2, D3 |
| "report weekly on on-time dispatch" | B5, E2 |
| "2+ years in operations or logistics coordination" | A1, D2 |
| "confident with Excel" | C2 |
| "ERP experience (SAP or similar) a plus" | B3, B4 |
| "£38,000–£44,000" | A2, D1 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A3 |
| "your notice period" (Hannah) | A4 |
| "what's prompting a move" (Hannah) | B1, B2 |

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says deliveries for three depots, not production schedules. B3's slot stays inside the depots |
| Cut stock discrepancies by a third | Inflated form of F3 | F3's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Your material says discrepancies fell, not that the rebuild alone caused it. D3's slot asks only what else changed |
| Advanced Excel skills, or built the stock-count in Excel | Inflated form of F6 | F6's quote at its own scope: you rebuilt a stock-count spreadsheet. Your material says spreadsheet, not which tool |
| Has ERP experience | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system". Your material says an in-house stock system, not an ERP |
| Has used SAP | A negative you stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." No slot |
| I'm being made redundant | Inflated form of F12 | F12's quote at its own scope: the Bristol office is closing next year and the only offer is relocating to Reading. Your material does not say your role is redundant |
| Open to more than three days a week at Avonmouth | Contradicted by your own quote, F10 | The quote: "I wouldn't want more than three." Nothing added |
| Open to relocating to Reading | Contradicted by your own quote, F12 | The quote: the only offer is relocating to Reading, "which I don't want". Nothing added |

## Sources

Provided documents: the Quillmoor advert (pasted), your background message, and Hannah Lowther's LinkedIn message (pasted).

Searches sent, each refused (nothing returned):

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics news strategy Avonmouth" — refused
- "Hannah Lowther Quillmoor Diagnostics" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have moved A5, and could have themed a VAL question; no values cheat sheet is built either way, since no values-style round is detected |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Every call was refused. It would have moved the loop beyond this call; this session's loop is established by Hannah's own message |
| 3. `Quillmoor Diagnostics strategy` or recent news | unavailable | Every call was refused. It would have moved A5, and supplied a strategy-grounded CO question; none is in this pack |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have moved an interviewer read and a reverse question tied to her own path; both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Quillmoor's own pages (about, values, recent news), pasted or linked → A5 and the company-facing reverse questions move from the advert alone to grounded detail, and a VAL question can be themed if their values are in hand
- What Hannah has said about her own path or the process → an interviewer read and a reverse question tied to her path
- Your contractual notice period → F11 gains a quote and A4 becomes story-mapped
- Your CV → F1 to F8 now rest on your message alone; CV lines would add quotes and could raise confidence where a line stands behind them
- A stock-count report or discrepancy log from before and after the rebuild → F3 could rise from medium toward high, and C1 and D3 gain an inspectable artifact
- Your answers to the slots on F1, F2, F4, F6 and F8, said in your own words in chat → those rows regain your quotes and the guidance on them regenerates
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, and it needs search to be permitted) → a strategy brief, a recent-org-context sweep and an interviewer sweep
- A `tuesday-dossier.md` from an earlier evaluation of the role → verified evidence and prohibited claims arrive supplied instead of built locally
