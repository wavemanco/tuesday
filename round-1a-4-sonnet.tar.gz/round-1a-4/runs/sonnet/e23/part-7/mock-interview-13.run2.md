I'll read the reference files the skill requires before writing the pack.
The pack is written, and I'm giving you the summary now.

Your prep pack is saved as `quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it as a recruiter screen from Hannah's stated agenda, the advert and your summary. I had no CV text, so every line I quote about you comes from your message. My four company and Hannah searches were refused, so nothing in it rests on outside research about Quillmoor. That also means there are no company-specific questions and no read on Hannah.

- **Your own words cover three of her four topics:** the £42,000 figure sits inside the £38k–£44k range. Your two-days-fine, no-more-than-three line works as it stands. Your reason for leaving (the Bristol office closing and the Reading offer) is a solid answer.
- **Notice period is the open item:** your material doesn't give one, so I wrote nothing for it (A5).
- **Highest-ROI prep is B2:** the advert's first duty is production schedules across planning, the warehouse and QA, and what you've told me is delivery scheduling. Rehearse holding "I schedule deliveries for our three depots" and saying plainly what isn't yours.
- **SAP is a smaller gap:** the advert says "a plus", and "Never used SAP" works as a plain answer.
- **The pack also covers:** 18 questions in five styles, reverse questions, and a list of claims it won't coach. It has one sentence you may be tempted to stretch: "about a third" shouldn't become a precise or fully attributed cut.

Say the word and I'll play the Skeptic on B2.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What is your notice period? Your material doesn't establish it, and it's on Hannah's agenda.
If you have your CV text, will you paste it? Otherwise I'll stay with your summary.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Operations Coordinator, Quillmoor Diagnostics: recruiter screen prep pack

- **Role:** Operations Coordinator, Quillmoor Diagnostics
- **Interviewer:** Hannah Lowther, Talent Partner. Round: recruiter screen, a 30-minute phone call on Thursday at 2pm, to the mobile number on your application
- **Her stated agenda, in her words:** "salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps"
- **Built on:** the advert you pasted, Hannah's message, and your own summary of your background (no CV text was supplied, so every quote below is "your message")

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values (none are in hand for this company, so no VAL questions here) |
| EXP | Whether your account of your own work survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none here: company research did not run, see Sources) |
| CASE | A live problem from the role, answered with structure |

Provenance labels: `[grounded]` traces to something you or the recruiter supplied; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about you or the employer.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and it names no planning team, warehouse or QA. The words stay at "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on who you worked with likely. If any of that scheduling involved those teams, say which and how, in your own words; if none did, or it was not yours, say so plainly and stay with the deliveries |
| F2 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The sentence touches supplier deliveries without showing how you follow where one stands. Answer slot: if you keep track of supplier deliveries in a sheet, a system or by asking, say how, in your own words; if you do not track them as such, say so plainly and stay with chasing suppliers when orders slip |
| F3 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms. Lead with it as written: you chase suppliers when orders slip. It is a CV-style line with nothing inspected behind it, so expect a probe on it |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The quote reaches the requirement. Keep its wording: you rebuilt the spreadsheet, discrepancies fell by about a third, over a year. The figure raises four slots: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Your material answers none of them, so C1 and C2 leave them as slots |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show whether you report on dispatch or delivery performance. Answer slot: if you report any delivery or supplier measure regularly, say what and how often, in your own words; if you do not report on one, say so plainly and say what you would track first |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, and shows nothing of what was in it. Answer slot: if the spreadsheet was in Excel, say what you built in it, in your own words; if it was another tool, or you used little of Excel, say so plainly and say what you have used |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | You stated the SAP gap and the advert marks it as a plus. Words: "Never used SAP." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F8 | "or similar" in the ERP line — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [inferred] | transferability | The quote gives an in-house stock system at your employer, not what you do in it. Words: "we run our own in-house stock system." Answer slot: if you work in it day to day, say what you do in it; if you use it little, or it is not comparable, say so plainly |
| F9 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | The quote reaches the requirement in the advert's own field. Say it as written: four years, logistics coordinator, a building-supplies wholesaler |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | The figure sits inside the advert's range. Your material gives a hope, not a floor and not a limit on flexibility, so the words stay "I'm hoping for £42,000." |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Both halves travel together: two days is fine, and not more than three. Nothing in your material says you would do more than three |
| F12 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish this term. It is surfaced here and nothing is written for it |
| F13 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Say it in the quote's terms: the Bristol office closes next year, the only offer is relocating to Reading, and you don't want that. The quote gives no reason for not wanting it and none for choosing Quillmoor, so A1 leaves both as slots |

## Persona table

| Persona | How it shows up | Weight | Likelihood, with the reasoning | Basis | Counter-strategy |
|---|---|---|---|---|---|
| Conversational / Rapport Builder | Friendly agenda call: motivation, logistics, your background in your own words. Casual questions are still scored | 5 | High. Hannah listed her agenda in her message and it is logistics and motivation, which is how this persona asks | [grounded] her message | A short spoken arc for the background question built only from your quoted sentences (A2); the four agenda items answered in plain terms (A1, A4, A5, D2) |
| Skeptic | Quiet probing of the gaps: production scheduling against deliveries, SAP, Excel, why manufacturing | 5 | High. Three rows (F1, F6, F7) carry limits an advert-matching recruiter will notice, and a move from a wholesaler to a manufacturer invites why | [grounded] advert and your message | Rehearse B2 until it is boring: hold the quoted sentence, then say plainly what is not yours. Bridges only from what you stated |
| Data-Driven Prober | Asks how the one figure was counted and what else changed | 3 | Medium. You have one figure and a recruiter may test it lightly. A light touch is more likely than a deep one | [generic] recruiter-screen prior | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know (C1, C2) |
| Pressure / Stress | Salary push and a sixty-second pitch | 3 | Medium. Salary expectations are on her agenda, and a push on the number is a common move | [grounded] her message, [generic] the push | Say the number once, hold it through two follow-ups, concede only what you decided beforehand (D2) |
| Case / Strategist | A light live problem from the advert's supplier and stock duties | 2 | Low. A recruiter screen rarely runs cases, but the advert's chase-late-orders and stock lines make a short one possible | [generic] | Clarify first, then who needs to know, then action and record (E1, E2) |
| Values / Behavioral | Not banked | 0 | No loop source documents a values-style round, and no published values are in hand | [generic] | None |
| Peer Evaluator | Not banked | 0 | Hannah is the recruiter, not a peer on the team | [grounded] her message | None |

## Question banks

Highest-ROI prep in this pack: **B2**. The advert's first duty is production schedules across planning, the warehouse and QA, and your material says deliveries. Expect that gap to be probed in some form, and rehearse the answer until it is boring.

### Bank A: Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, what's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say the three beats the quote states: the Bristol office closes next year, the only offer is relocating to Reading, you don't want that. Answer slot: if she asks why you don't want Reading, give your own reason in one sentence; if you would rather not say, say that plainly and move on. Answer slot: add one sentence on what in this role's advert interests you, from lines you actually care about; if none stands out, say so rather than reaching for one | F13 is the evidence and is on her stated agenda. EXP because it tests whether your account of your situation holds together; there is no motivation tag in the type set |
| A2 | "Walk me through your background, and what you do now." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with only the beats the quotes state, in order: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots and chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Stop there and let her ask. Add no team size, volumes or tools you have not given | F9, F3 and F4 are the spine of the story. EXP because it is the CV walk-through, delivered casually and still scored |
| A3 | "What are you looking for in your next role?" | JD | [generic] | Selection scaffold: pick the two lines of the advert you would most want to do, and say why in your own words. If no line stands out, say so plainly, then say what matters most to you in a job. The advert's lines on supplier deliveries, stock records and weekly dispatch reporting are the candidates | Casual versions of this question score fit with the advert. JD because it checks your interest against the stated duties; `[generic]` because it is a pattern for the question, not a fact about you |
| A4 | "The role is hybrid, two days a week at Avonmouth. How would that work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say it with both halves: you live in north Bristol, two days at Avonmouth is fine, and you wouldn't want more than three. If she asks whether you could do more, repeat the second half rather than offering a number. Answer slot: if she names particular days, say plainly whether they work; your material does not say, so no line is written for it | F11 is a gate shown met. JD because it scores a term of the role rather than your history |
| A5 | "What's your notice period?" | JD | [grounded] | State the figure from your contract in your own words. If an earlier leave date is something your employer has confirmed, say that separately and say it is confirmed; if it is only hoped for, do not say it. Your material gives no figure, so none is written | F12 is a gate your material does not establish, and it is on her agenda. JD because it scores a term of the job |

### Bank B: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this advert would be your weakest on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | The weakest point your material states is SAP. Words: "Never used SAP." Then the second half of your own sentence: "we run our own in-house stock system." Then a plan, not a past: what you would do first to learn a new system, in your own words. Answer slot: if another part of the advert is weaker for you, say which, plainly | F7 is the stated gap and F8 its nearest neighbour. JD because it scores honest self-assessment against the advert |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. What have you coordinated that's closest to that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: if any of that scheduling involved planning, warehouse or QA colleagues, say who and how, in your own words; if none did, or it was not yours, say so plainly and stay with the deliveries. Follow-up one, "so that is deliveries rather than production?": answer from the quote, and if production scheduling was not yours, say that plainly. Follow-up two, "how would you get up to speed?": a plan in your own words, such as who you would ask first, not a past. Never describe production scheduling as something you have done | F1 is the widest gap between the advert and your material. JD because it scores the first stated duty; Skeptic because it is aimed at exactly where your material is thin |
| B3 | "You're at a building-supplies wholesaler. Why move into manufacturing?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Answer slot: say in your own words what draws you to this kind of work, from the advert's lines you care about; if the draw is mainly the Reading situation, say that plainly, because it is in your own words in A1. Do not claim familiarity with manufacturing or diagnostics; your material gives none | F9 is the evidence for the field you come from. JD because it scores whether the move makes sense for the role |
| B4 | "ERP experience, SAP or similar, is a plus. What systems have you used?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Say "Never used SAP." Then "we run our own in-house stock system." Answer slot: if you work in that system day to day, say what you do in it; if you use it little, or it is not comparable to an ERP, say so plainly. Call it by your own words, an in-house stock system, and not an ERP | F7 and F8 together. JD because the ERP line is in the advert; the advert's "a plus" keeps it from being decisive |
| B5 | "How confident are you in Excel, and what are you strongest at?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the stock-count spreadsheet was in Excel, say what you built in it, in your own words; if it was another tool, or you use few of Excel's features, say so plainly and say what you have used. Name no function you have not used | F6 is the evidence and is thin. JD because Excel is a stated requirement; `[inferred]` because "spreadsheet" is read as Excel |

### Bank C: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what the quote states: you rebuilt the spreadsheet, discrepancies fell by about a third, over a year. Answer slot: how it was counted, what the figure is sensitive to, the assumption behind it you would defend least, and which part was yours; say each in your own words, and where you do not know, say so plainly | F4's figure raises these four slots. EXP because it is the defend-the-number question |
| C2 | "Was anything else different over that year?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold the sentence as written and claim no more cause than it states. Answer slot: if something else changed, say what and where it leaves your share; if nothing else changed, or you do not know, say so plainly | F4 again, as attribution. EXP because it tests how much of the result was yours |
| C3 | "The role reports weekly on on-time dispatch. What do you report on now?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you report any delivery or supplier measure regularly, say what and how often, in your own words; if you do not report one, say so plainly and say what you would track first. Name no figure you have not reported | F5 has no evidence. JD because weekly reporting is a stated duty; the second branch allows that no such reporting exists |

### Bank D: Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we move you forward?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Three beats in the quotes' own terms: four years as a logistics coordinator; you schedule deliveries for three depots and chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Then stop. Do not say what they prove; let her draw it | F9, F3 and F4. JD because it scores fit with the advert under time pressure |
| D2 | "Our range is £38,000 to £44,000. What are you expecting?" | JD | [grounded] "I'm hoping for £42,000." | Say the number once: "I'm hoping for £42,000." Then stop. If pushed twice, repeat it and that it sits inside her range. Answer slot: decide before Thursday the lowest figure you would accept and whether you would say it; the pack picks no figure for you. Concede only what you have decided | F10 is a gate shown met, and it is on her agenda. JD because it scores a term; Pressure because a push on the number is the likely form |
| D3 | "Why shouldn't we pick someone who already has SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Hold, then concede. Concede in your own words: "Never used SAP." Hold on what your quotes carry: "I schedule deliveries for our three depots and chase suppliers when orders slip" and "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." Then a plan for learning the system, not a claim about how quickly you learn | F7 plus F3 and F4. JD because the ERP line is in the advert; Pressure because it invites defensiveness |

### Bank E: Case (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you on Monday that a key delivery will be four days late, and production is due to start Wednesday. What do you do?" | CASE | [generic] | Structure it aloud: what you would ask first (what is affected, how firm the new date is, whether anything can be substituted), who needs to know (the advert names planning, the warehouse and QA), what you would say to the supplier, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier and scheduling lines. `[generic]` because it is a pattern for the problem |
| E2 | "Two sites count stock differently and the records disagree. How do you get them accurate?" | CASE | [generic] | Structure it: agree one counting definition, set when each site counts, reconcile the differences, trace the largest ones to a cause, and report what you found. The question asks about no past, so the guidance claims none | A live problem from the advert's stock-records line. `[generic]` because it is a pattern for the problem |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | B2, E1 |
| "track supplier deliveries" | C3, E1 |
| "chase late orders" | A2, D1, E1 |
| "keep stock records accurate" | C1, C2, E2 |
| "report weekly on on-time dispatch" | C3 |
| "2+ years in operations or logistics coordination" | A2, D1 |
| "confident with Excel" | B5 |
| "ERP experience (SAP or similar) a plus" | B1, B4, D3 |
| "£38,000–£44,000" | D2 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A4 |
| "your notice period" (Hannah's message) | A5 |
| "what's prompting a move" (Hannah's message) | A1, B3 |

## Reverse questions

Use these in the slot after she has told you about the team and next steps. The call is a recruiter screen, so none is tied to an interviewer's path: no profile of Hannah was available.

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which teams would I work with most day to day, and how do people usually use the two Avonmouth days?" | It picks up the hybrid line you have already said is fine, and shows you are thinking about how the days would run |
| 2 | "How is on-time dispatch measured today, and who sees the weekly report?" | It ties to the advert's reporting duty and shows you have read it closely |
| 3 | "What system does the team work in day to day, SAP or something else?" | The advert marks ERP as a plus; her answer tells you how much weight it carries |
| 4 | "Is this a new role or a replacement, and what is the team's biggest pressure right now?" | It gets context an advert does not give, and invites her to tell you what the job is really for |
| 5 | "Who would I meet next, and what would they want to cover?" | It converts her next-steps summary into something you can prepare for |
| 6 | "What does a good first three months look like?" | It lets you hear what the hiring manager will measure, which sharpens later answers |
| 7 | "What is the timeline from here to a decision and a start date?" | It lets you line up her timeline against your notice period without having to bargain over it |

## Prohibited claims

What this pack will not coach, built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation: your material says deliveries, not production scheduling. B2's slot stays inside the deliveries |
| Has used SAP | Negative you stated, F7 | Your own words: "Never used SAP — we run our own in-house stock system." No slot |
| Has ERP experience | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: your material gives the system, not what you do in it |
| Cut stock discrepancies by a third as a result of the rebuild, exactly | Inflated form of F4 | F4's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: the material says "about a third" and does not say how it was counted |
| £42,000 is my minimum, or non-negotiable | Inflated form of F10 | F10's quote at its own scope: "I'm hoping for £42,000." D2's slot asks only what you decided |
| I'm flexible on how many days I would be in the office | Inflated form of F11 | F11's quote with both halves: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |
| A reason for leaving other than the office closing, such as wanting a new challenge | Contradicted by F13's quote | F13's quote and nothing more: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." |

## Sources

Provided documents: the advert text you pasted; Hannah Lowther's LinkedIn message; your own summary of your background. No dossier was supplied.

Searches sent, each refused (the host did not grant search permission):

- `Quillmoor Diagnostics values`: refused
- `Quillmoor Diagnostics interview process operations coordinator`: refused
- `Quillmoor Diagnostics Avonmouth news`: refused
- `Hannah Lowther Quillmoor Diagnostics`: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have moved a values cheat sheet and any VAL questions; none exist here |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Every call was refused. Hannah's own words establish this session, so it would have moved only the later rounds, which this pack does not cover |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Every call was refused. It would have moved a CO question and any grounding on the company's current priorities; the bank has none |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have moved an interviewer read and one reverse question tied to her path; both are absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → F12 and A5 can carry your own words once you have settled the figure; nothing can stand in for it
- Your answers to the slots in F1, F2, F5, F6 and F8 → those rows move from slot-based bridges to quoted ones, and B2, B5 and C3 get tighter
- The stock-count spreadsheet itself, or a before-and-after count record, which is the inspectable artifact in your field → F4 can move from medium toward high, and C1 and C2 can name how the figure was counted
- Your CV text → more rows with quotes, and A2 gets beats beyond your summary
- Search permission for company research → values, loop, strategy and Hannah's public footprint become `[grounded]` rows, and E1 and E2 can become company-specific CO questions
- A deeper research pass, once, if search is granted: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief and Hannah's talks and writing
- Ask Hannah after the call what the later rounds are → per-round mini-packs with their own persona weights
- A `tuesday-dossier.md` from an earlier evaluation of this role → a named highest-ROI objection and per-gap strategy limits, in place of this pack's inference
