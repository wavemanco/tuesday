# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, 30-minute phone call. Hannah Lowther, Talent Partner, will ring the mobile number on your application.
**Her agenda, from her message:** your salary expectations, your notice period, how the hybrid pattern would work for you, what's prompting a move. Then the team and next steps.
**Built on:** the advert you pasted, Hannah's message, and your notes about yourself. Web research was refused in this run (see Sources), so nothing here rests on outside facts about Quillmoor.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what is true of you.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your history survives scrutiny; what was actually you |
| JD | A stated responsibility, qualification or term of the role |
| CO | What you know about the company and its strategy |
| CASE | A live problem from the role |

Highest-ROI prep: **B2** (the SAP line), because it is the one place your own words meet a named advert line, and it carries the most follow-up levels. A3 to A5 are certain to come up because Hannah named them, so rehearse those out loud once each. This bank has 15 questions, below the usual range, because a 30-minute screen has little room for more; the coverage table below shows every advert requirement and every topic Hannah named is covered.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and the words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on how far your scheduling reached likely. If any of it involved coordinating with a planning, warehouse or QA function, say how, in your own words; if none did, say so plainly and stay with the three depots |
| F2 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap in the chasing, but a line from your message with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you chase suppliers when orders slip |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | Your sentence says scheduling deliveries for depots, which touches supplier deliveries without showing whether you followed them after booking. Answer slot: if you followed supplier deliveries once they were due, say how, in your own words; if you did not, say so plainly and stay with scheduling for the three depots |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | Lead with your own sentence. It gives the rebuild and the fall with nothing inspected behind it, and it does not say how discrepancies were counted. Answer slot: expect the four probes a figure raises, namely how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours. Answer each in your own words, and where you do not know how it was counted, say so plainly |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show any reporting. Answer slot: the advert's weekly on-time dispatch line makes a probe on reporting likely. If you produce or contribute to a regular report on deliveries or dispatch, say what it covers and how often, in your own words; if you do not, say so plainly and stay with your stock-count spreadsheet |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence names a spreadsheet, not Excel, so the link is this pack's derivation. Answer slot: if the spreadsheet was in Excel, say so and what you did in it, in your own words; if it was another tool, say so plainly and say that |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used SAP." Then, in your own terms, what the in-house stock system is, and leave it to Hannah to judge whether it counts as similar. How you would learn a new system is said as a plan, never as a past |
| F8 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap: your sentence says four years against the advert's two-plus. Say it as written |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | medium | [grounded] | none | No gap in the band: £42,000 sits inside the advertised range. Your words say hoping, not minimum, so the pack does not coach it as a floor |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | No gap. Say it at its own limits: two days is fine, and you wouldn't want more than three. Do not round it to "two days only" or to "flexible" |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. The pack makes no claim about it |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap: the reason is stated, and it can be said in your own terms. It is a reason for leaving; your material does not yet say what draws you to Quillmoor, which A2 and A6 rehearse |

### Requirement coverage

| Requirement or topic | Questions |
|---|---|
| Coordinate production schedules (F1) | B3, B6 |
| Chase late orders (F2) | C3 |
| Track supplier deliveries (F3) | C3 |
| Keep stock records accurate (F4) | C1 |
| Weekly on-time dispatch reporting (F5) | B4 |
| Excel (F6) | C2 |
| ERP, SAP or similar (F7) | B2 |
| 2+ years coordination (F8) | A1, B6 |
| Salary expectations (F9) | A3 |
| Hybrid pattern (F10) | A5, B5 |
| Notice period (F11) | A4 |
| What's prompting a move (F12) | A2, B1 |
| Quillmoor itself | A6 |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (bank A) | Friendly, unstructured; Hannah's four named topics arrive as chat | Highest. A recruiter screen starts from Conversational as its prior, and Hannah's message lists her four topics, so bank A covers them in her order | A 90-second arc built only from A1's quoted sentences; treat every casual question as scored |
| Skeptic (bank B) | Quiet probing of the advert lines your material does not reach, and of why you are leaving | Second. The recruiter-screen prior adds a light Skeptic, and your own notes give it targets: SAP, production scheduling, the Reading offer | Rehearse B2 until it is boring, using only its quote; say limits plainly rather than bridging past them |
| Data-Driven Prober (bank C) | Asks for the number behind your stock-count result | Lowest of the three. A 30-minute screen leaves little time to probe, but the figure on your notes is the item a prober would reach for | Know what you can and cannot say about how the figure was counted, and say plainly where you do not know |
| Values, Case, Peer, Pressure | Not weighted | Hannah's message names no values round, case, peer conversation or time-boxed challenge, and no interviewer profile exists to adjust the prior. Nothing about later rounds is established, so none is assumed | None built; send the later-round schedule when you have it (see the upgrade menu) |

## Question banks

### A. Conversational (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | A 90-second arc with four beats, each a clause those sentences state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year; and your Bristol office closing next year. Tell it in your own words and add no beat the sentences do not carry | The opening question of most screens; F8 is the evidence for the experience requirement. EXP because it scores what you actually did |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say what the sentence carries: the Bristol office is closing next year, and the only offer is relocating to Reading, which you don't want. Then one thing from the advert that draws you. Selection scaffold: pick a line you can speak to from your own work, such as chasing suppliers, stock records or dispatch; if nothing comes to mind, say so plainly and say what you want from the next role | Hannah named this topic, so it is certain. F12 holds the reason; EXP is the closest type, because it scores whether your account of your history is consistent. A reason for leaving and a reason for choosing Quillmoor are separate, and only the first is in your material |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Say the figure once, plainly: "I'm hoping for £42,000." It sits inside the advertised £38,000–£44,000. Then stop and let her respond, rather than adding a justification your material does not carry. Answer slot: whether £42,000 is a figure you would move from is not in your material. Decide before Thursday what you would say if she names a lower point in the band, and say only what is true of you. Do not call it a minimum | Hannah named this topic. F9 is the evidence; JD because the advert states the range and the question scores a term of the role |
| A4 | "What's your notice period?" | JD | [grounded] | Say your notice period exactly as it stands, and a start date only if it is true. Answer slot: your material does not state it. If you are unsure whether any of it can be shortened, say so plainly and say you will confirm by message. Never offer a shorter period than you can deliver | Hannah named this topic. F11 is the one row your material says nothing about; JD is the closest type, since it scores a term of the role rather than a skill |
| A5 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Say it as your sentence does: you live in north Bristol, two days at Avonmouth is fine, and you wouldn't want more than three. Answer slot: if she asks how you would get to Avonmouth, answer from what you know; if you have not worked that out, say so plainly | Hannah named this topic. F10 is the evidence, and it is a constraint you stated, so it is the strongest row in the snapshot |
| A6 | "What do you know about Quillmoor, and why us?" | CO | [grounded] | A selection scaffold, not a script. Use only what the advert says: a diagnostic-test manufacturer of about 400 staff, with the Avonmouth site in Bristol. Say which part of the role draws you, in your own terms. If nothing beyond the advert comes to mind, say so plainly, then say you would like to hear about the team. The company-strategy search was refused, so nothing more current is in this pack | It follows from A2's motivation topic. CO because it scores homework; labelled grounded in the advert only, with no strategy claim |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your office is closing, and you've been offered Reading. Why not take it?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say what the sentence carries: the only offer is relocating to Reading, which you don't want. Answer slot: if she asks why, give your actual reason in your own words; your material states none, so the pack supplies none. If you have no reason beyond not wanting it, say so plainly. Say nothing about whether you would reconsider unless it is true | A recruiter checks motivation is consistent with the story. F12 is the evidence; EXP because it scores your own account |
| B2 | "The advert mentions SAP or similar ERP experience. What have you used?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | **Highest-ROI rehearsal.** Level 1: "I've never used SAP." Then, in your own words, what the in-house stock system is. Level 2, "So no ERP experience?": hold to the sentence, and do not call the in-house system an ERP; let her judge whether it is similar. Level 3, "How would you get up to speed?": answer as a plan, in your own words, with no past training or exposure added. Answer slot: if you have used any other system of that kind, say which; if not, say so plainly. The advert lists it as "a plus", which you can say as the advert's own wording. The limit to name before she asks: your material says SAP and the in-house system, nothing wider | The advert names it, and your own words meet it. F7 is the evidence; JD because it scores a stated qualification, and this is the objection most likely to be raised in some form |
| B3 | "The role coordinates production schedules between planning, the warehouse and QA. Where have you worked with those?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Start where the quote is: scheduling deliveries for three depots and chasing suppliers when orders slip. Answer slot: if any of your scheduling involved coordinating with a planning, warehouse or QA function, say how, in your own words; if none did, say so plainly and stay with the three depots | F1 is the thinnest-bridged core duty. JD because it scores the headline responsibility |
| B4 | "The role reports weekly on on-time dispatch. Have you reported on anything like that?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if you produce or contribute to a regular report on deliveries or dispatch, say what it covers and how often, in your own words; if you do not, say so plainly, then return to your sentence about the stock-count spreadsheet | F5 has no evidence, so the honest answer is rehearsed before the probe. JD because the advert names the report |
| B5 | "What if the pattern moved to three days, or more?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Answer from the sentence: two is fine, and "I wouldn't want more than three." Answer slot: whether three is something you would be happy with is not in your material; say what is true of you | Tests whether the stated limit holds under a change. F10 is the evidence; JD because the pattern is a term of the role |
| B6 | "You're coming from building supplies, and this is diagnostic-test manufacturing. How do you see the move?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Say your sentence at its own scope: four years as a logistics coordinator at a building-supplies wholesaler. Answer slot: if any of your suppliers were manufacturers, or your work touched production, say what, in your own words; if not, say so plainly and say what you would want to learn first | The advert's manufacturer framing raises the sector question. F1 and F8 are the evidence; JD because it scores fit to the stated role |

### C. Data-Driven Prober (lowest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How was that discrepancy figure counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say your sentence as written. Answer slot: how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours, each in your own words. Where you do not know how it was counted, say so plainly. The pack names no method or baseline | The only figure in your material. F4 is the evidence; EXP because it scores whether the number survives |
| C2 | "How confident are you with Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The sentence names a spreadsheet, not Excel; the link is this pack's derivation | Answer slot: if the spreadsheet was in Excel, say so and what you did in it, in your own words; if it was another tool, say so plainly. Claim only what you did | The advert names Excel and F6 is the unconfirmed link |
| C3 | "Tell me about a time a supplier order slipped and you had to chase it." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The beats the sentence states are that orders slip and you chase suppliers. Answer slot: if a particular instance comes to mind, say what you did and what came of it, in your own words; if none stands out, say so plainly and describe how you handle it in general | F2 and F3 are the evidence. EXP because it scores whether a stated duty has an instance behind it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who does the Operations Coordinator work with most day to day: planning, the warehouse or QA?" | Uses the advert's own three functions, and shows you read it |
| R2 | "What system does the team use for stock and orders, and what does onboarding on it look like?" | Raises the SAP point on your terms, as a question about learning rather than a claim |
| R3 | "Are the two Avonmouth days set across the team, or flexible?" | Ties to your stated limit without reopening it |
| R4 | "What does the weekly on-time dispatch report look like today, and who reads it?" | Shows interest in the metric the role is judged on |
| R5 | "Is this a new role or a replacement, and what would the first three months look like?" | Lets you hear the team context Hannah promised, and what good looks like |
| R6 | "What are the next steps, and who would I meet next?" | Closes the call with a concrete next move |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | Negative you stated, F7 | The plain acknowledgment from your own sentence: "I've never used SAP." No slot |
| Has ERP experience | Inflated form of F7's in-house system | The quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: your material says an in-house stock system, not an ERP |
| Schedules production | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says deliveries, not production |
| My spreadsheet rebuild cut discrepancies by a third | Inflated form of F4 | F4's quote at its own scope: you rebuilt the spreadsheet and discrepancies fell by about a third over a year. The limit is the pack's observation: your sentence sets the two side by side and says nothing about how the fall was measured |
| Advanced Excel user | Inflated form of F6 | F6's quote at its own scope, which names a spreadsheet. The limit is the pack's observation: your material does not name the tool |
| £42,000 is my minimum | Inflated form of F9 | F9's quote at its own scope: "I'm hoping for £42,000." |
| Two days is my limit | A claim your F10 quote contradicts | F10's quote, whole: you said two days is fine and you wouldn't want more than three |

## Sources

**Provided documents:** Hannah Lowther's LinkedIn message; the Quillmoor Diagnostics advert; your notes about yourself. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Queries sent, all refused:

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused
- `Quillmoor Diagnostics strategy news Avonmouth` — refused
- `Hannah Lowther Quillmoor Diagnostics` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Would have named published values for VAL questions, though no values round is established, so the banks would not have changed |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Would have shown whether later rounds exist and reweighted personas for them; this call's own loop comes from Hannah's message |
| 3. `Quillmoor Diagnostics strategy news` | unavailable | Would have grounded A6 in current priorities; A6 uses the advert only |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Would have supplied an interviewer read and a reverse question tied to her path; both are absent |
| 5. representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → F11 and A4 become your own words instead of a slot
- Permission to run web searches, or the company's values page and any strategy material pasted in → A6 becomes grounded in current priorities, and a values bank is added if a values round turns out to exist
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Quillmoor's current context
- How the discrepancy figure was counted, and whether the spreadsheet was Excel → F4 and F6 firm up, and C1 and C2 become story-mapped; the stock-count spreadsheet or a count report would be the inspectable artifact that lifts F4 from medium
- Whether you report on deliveries or dispatch in your current job → F5 moves from discovery to a quoted row, and B4 becomes story-mapped
- Whether any of your scheduling involved planning, warehouse or QA functions → F1 and B3 firm up
- The schedule for any later rounds → per-round mini-packs with their own persona weights
- A `tuesday-dossier.md` from an earlier fit evaluation → verified evidence and sourced prohibited claims would replace the locally built list
