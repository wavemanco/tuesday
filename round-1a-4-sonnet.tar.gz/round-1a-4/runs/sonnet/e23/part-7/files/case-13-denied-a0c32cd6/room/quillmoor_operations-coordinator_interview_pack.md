# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Interviewer:** Hannah Lowther, Talent Partner. **Round:** recruiter screen, a 30-minute phone call on Thursday at 2pm. She rings the mobile number on your application.
**Her stated agenda:** your salary expectations, your notice period, how the hybrid pattern would work for you, and what is prompting a move. Then she tells you about the team and the next steps.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores. Every question carries both.
- Type key: **VAL** is values alignment. **EXP** is work-experience deep-dive. **JD** is role or advert driven. **CO** is company and strategy knowledge. **CASE** is a live problem. Logistics and motivation questions take the nearest tag: JD where the advert states the term, EXP where it is your own circumstances.
- Guidance is scaffolding, not a script. Say it in your own words. An answer slot is an instruction for the interview, not a question for you now.
- No VAL or CO questions appear. No values-style round is established, and the company research could not run (see Sources).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules and not planning or QA, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA as the parties, so a probe on who you coordinated with is likely. If your scheduling involved a planning or production function, say how; if it did not, say so plainly and stay with the deliveries |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you chase suppliers when orders slip. Answer slot: if you tracked deliveries in a particular way, say how; if there was no tracking beyond the chasing, say so plainly |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but a headline figure with nothing inspected behind it. Say it at its own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. The sentence does not say how discrepancies were counted or whether anything else changed |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show whether you have produced a regular report. Answer slot: if you have, say what it showed and how often; if you have not, say so plainly and say what you would report first |
| F5 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [inferred] | discovery | The quote says spreadsheet, not which application, and says nothing about what was done in it. Answer slot: name the application and what you did in it, in your own words; if it was not Excel, say so plainly |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. Say it as written: four years as a logistics coordinator at a building-supplies wholesaler |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | You stated the SAP absence: "I've never used SAP." The in-house stock system is adjacent work at its own scope, and the quote does not say what it covered. Answer slot: say what you use it for, in your own words; if you cannot say, stay with the sentence |
| F8 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | No gap. £42,000 sits inside the advertised band, in its upper part. The quote is a hope and does not say how firm it is, so A3 holds an answer slot on that |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | No gap. Two days is fine; three is your stated ceiling. Say the ceiling only as you stated it |
| F10 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. Nothing is drafted for it |
| F11 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | No gap on the reason itself: say it in its own terms. The quote gives why you are leaving, not why this role, so B1 holds an answer slot for the second |

## Persona table

| Persona | How it shows up | Weight, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured; her four stated topics arrive as chat, each still scored | High. The recruiter-screen prior is Conversational plus a light Skeptic, and her message lists four topics with no case or technical element. This rests on the relationship prior and her message, since no loop source establishes the later rounds | Pre-script a 90-second arc (A1); treat salary, notice and hybrid as scored |
| Skeptic | Motivation and fit gaps: "why leave, why here, why now", SAP, wholesaler to manufacturer | Medium-high. "What's prompting a move" is on her agenda and is a Skeptic stem; F7 and F1 are the thin rows | Rehearse B1 until it is boring; state the SAP absence plainly |
| Data-Driven Prober | Defends the number, the spreadsheet, the scheduling | Low-medium. Nothing in her message signals depth, but F3 is your strongest line and recurs wherever it is probed | Know what you can and cannot say about how the figure was counted |
| Case / Strategist | A live supplier or scheduling problem | Low for this call, since her agenda has none. Kept at 3 questions because the advert's duties are all coordination problems (generic pattern, not a documented loop) | Clarify, then structure, then answer |
| Pressure | Time-boxed or challenging: "why you, not someone who knows SAP", "why that salary" | Low. Nothing in her message signals it; the two most likely challenges are on pay and SAP | Hold two follow-ups, concede specifically, never fold on the core |

Highest-ROI prep: **B1**, the "why now, why Quillmoor" question. It is named on her agenda, so it will be asked, and your honest reason is about leaving rather than arriving. Rehearse the second half, where your material is silent.

## Question banks

### A. Conversational (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey: what do you do at the moment?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc with three beats, each a clause the quotes state: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots and chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Close on the move in one sentence (A2) and stop. Leave out anything those sentences do not state | The Conversational stem "walk me through the journey". F6, F2 and F3 carry it. EXP because it tests the claims you will make for the rest of the call |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | State it as you gave it, in a sentence or two: the Bristol office is closing next year, the only offer is to relocate to Reading, and you don't want that. Stop there, with no commentary on your employer. Answer slot: if something about this role also draws you, say what in your own words; if the closure is the whole reason, say so plainly | On Hannah's agenda; F11 is the evidence. EXP because it tests whether your own circumstances hold up to a second question, and no type tag fits motivation better |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Say the figure in your own words: "I'm hoping for £42,000." It sits inside the advert's £38,000–£44,000. Answer slot: expect "how firm is that?" If £42,000 is your floor, say so; if there is room, say how much; if you have not decided, decide before Thursday so the answer is yours | On Hannah's agenda; F8. JD because the band is the advert's own term |
| A4 | "How would the hybrid pattern work for you, with two days a week at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | "Two days at Avonmouth is fine; I live in north Bristol." If she asks about more days, give your limit as you stated it: you wouldn't want more than three. Do not say you are flexible on days; the quote sets a ceiling | On Hannah's agenda; F9. JD because the advert states the pattern. The ceiling is rehearsed now so it is said as a limit and not discovered later |
| A5 | "What's your notice period, and when could you start?" | JD | [grounded] | Your material does not establish your notice period, so no wording is drafted. Answer slot: state the notice your contract gives; if you do not know it, say so plainly and say you will confirm after checking | On Hannah's agenda; F10 is a surfaced gate, not a bridgeable row. JD is the nearest tag: it is a term of the hire, though not in the advert |

### B. Skeptic (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Why leave now, and why Quillmoor?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | The deepest rehearsal in the pack. Level one: the A2 answer, unchanged. Level two, "did you consider Reading?": the quote says it is the only offer and you don't want it; say that. Level three, "why us rather than any Bristol job?": Answer slot: your material says nothing about what draws you to this company; if something does, say what in your own words; if nothing yet, say so plainly and say what you want to learn from her description of the team. Keep the same answer through all three levels | Skeptic stem "why leave, why here, why now". F11 covers the first half; the second is where the material is silent. EXP because it tests whether the story survives cross-examination |
| B2 | "Have you used SAP, or a similar ERP system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | "I've never used SAP; we run our own in-house stock system." Answer slot: say what you use the in-house system for, in your own words; if you cannot say, stay with the sentence. Then, as a plan and not a past, say how you would learn whichever system they use; R3 asks which it is. The quote supports an in-house stock system and nothing wider | F7. The advert marks it "a plus", so this is a likely check rather than a gate. JD because it scores a stated requirement |
| B3 | "You're at a wholesaler now and this is a manufacturer. What do you expect to be different about coordinating production schedules?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Name what the quote carries: scheduling deliveries and chasing suppliers when orders slip. Then what you would ask first, as a plan: who sets the production schedule, what planning, the warehouse and QA each need from the coordinator, and how late supplier orders get flagged. Answer slot: if your scheduling involved a planning or production function, say how; if it did not, say so plainly and stay with deliveries | F1 is the stretch between your work and the advert's. JD because it scores the headline duty |
| B4 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Pick the one that is true for you. The thin rows are F1, F4, F5 and F7, and only F7 has a stated negative: "I've never used SAP." For any other pick, say plainly what you have not done, then the first thing you would do to learn it, as a plan. Answer slot: if your pick is the production-schedule coordination or the weekly reporting, say whether you have done any of it; if not, say so plainly | Skeptic stem. Hannah is checking self-assessment honesty; the thin rows are listed so you choose rather than improvise |

### C. Data-Driven Prober (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Discrepancies fell by about a third over a year. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say the sentence at its own scope. Answer slots, each in your own words: how a discrepancy was counted; what the figure is sensitive to; the assumption behind it you would defend least, named before she does; and which part of the rebuild was yours. If you do not know how it was counted, say so plainly | F3 is your strongest line and recurs wherever it is probed. EXP because it tests attribution and counting |
| C2 | "The advert asks for confidence with Excel. What did you build your stock-count spreadsheet in, and how would you describe your confidence with it?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: name the application and say what you did in it, in your own words; if it was not Excel, say so plainly and say what you have used in Excel, if anything. The quote says spreadsheet, so the pack names no application for you | F5. JD because it scores a stated requirement, with EXP delivery |
| C3 | "Walk me through how you schedule deliveries for your three depots." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Beats the quote states: you schedule deliveries for three depots, and you chase suppliers when orders slip. Answer slot: the advert's "track supplier deliveries and chase late orders" makes "how do you know an order is late?" a likely probe. If you tracked deliveries in a particular way, say how; if there was no tracking beyond chasing when an order slipped, say so plainly and stay with the chasing | F2 and F1. EXP because it tests what was yours; the probe comes from the advert |

### D. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you at nine this morning that a delivery a production run depends on will arrive two days late. What do you do?" | CASE | [generic] | Structure aloud. Clarify what is affected and by when. Name who needs to know: planning, the warehouse and QA, the three functions the advert names. Put options and their consequences to planning. Get a firm new date from the supplier. Record it so the weekly report reflects it. The question needs no claim about your past, so the guidance makes none | Built from the advert's supplier-chasing and scheduling duties (F1, F2). CASE because it is a live problem |
| D2 | "Planning wants a rush order moved up, the warehouse can't pick it until later in the week, and QA hasn't cleared the stock. How do you handle it?" | CASE | [generic] | Restate the three constraints. Ask which are fixed and which can move. Find the earliest date that works for all three. Say what you can promise, and to whom. Make the trade-off visible to planning rather than choosing silently. No claim about your past | The advert's coordination across planning, the warehouse and QA (F1). CASE; a pattern, not a fact about Quillmoor |
| D3 | "How would you structure the weekly report on on-time dispatch?" | CASE | [generic] | Define what counts as on time and against which date. Show on-time dispatches against total dispatches for the week, the misses with a reason each, and the trend. Say who reads it. Answer slot: if you have produced a regular report on deliveries or dispatch, say what it showed and how often; if you have not, say so plainly and answer from the structure | F4. The advert's weekly-reporting duty is otherwise uncovered. CASE because it is a design problem |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, rather than someone who already knows SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "Never used SAP — we run our own in-house stock system" | Pause, then hold on what the quotes carry: four years as a logistics coordinator, scheduling deliveries for three depots, chasing suppliers when orders slip. Hold through two follow-ups by returning to those, never by adding. Concede once and specifically: "I've never used SAP." Say how you would learn it, as a plan | Pressure stem. F6, F2 and F7. JD because it scores the advert's ERP line |
| E2 | "How much of the stock-count result was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold on what the sentence attributes to you: you rebuilt the spreadsheet. Concede what it does not say. Answer slot: if anyone else contributed, or anything else changed that year, say what; if not, say so plainly. Do not say you cut discrepancies by a third; the sentence says they fell | Pressure stem on attribution. F3. EXP because it tests what was yours |
| E3 | "Why £42,000 rather than £38,000?" | JD | [grounded] "I'm hoping for £42,000"; "4 years as a logistics coordinator at a building-supplies wholesaler" | Hold the figure. Give only the reasons the quotes carry: four years as a logistics coordinator, and the scheduling, chasing and stock-count work in A1. Concede the SAP gap in one clause if she raises it. Answer slot: if you have a reason of your own for £42,000, such as your current pay or a comparison, say it in your own words; if not, say so plainly | F8 with F6 and F7. JD because the band is the advert's own term |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B3, D1, D2 |
| Track supplier deliveries and chase late orders | C3, D1 |
| Keep stock records accurate | C1, E2 |
| Report weekly on on-time dispatch | D3 |
| 2+ years in operations or logistics coordination | A1, E1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B2, E1 |
| £38,000–£44,000 | A3, E3 |
| Hybrid, two days a week at Avonmouth | A4 |
| Notice period (Hannah's agenda) | A5 |
| What is prompting a move (Hannah's agenda) | A2, B1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Are the two Avonmouth days fixed for everyone, or set team by team?" | Tests the pattern you have said is fine at two days (F9) without volunteering your ceiling |
| R2 | "Who would I work with day to day across planning, the warehouse and QA, and who would I report to?" | The advert names those three functions, and F1 is your thinnest duty row |
| R3 | "Which stock or ERP system does the team use, and how is a new coordinator trained on it?" | The advert says SAP or similar is a plus and F7 is a stated gap; this asks about the ramp without claiming anything |
| R4 | "What does the weekly on-time dispatch report look like today, and what happens when it shows a miss?" | F4 is a row with no quote; this learns what the duty is before you are asked about it |
| R5 | "What does the process look like after this call: who would I meet next, and over what timescale?" | She will describe next steps, so ask for the detail she leaves out: who and when |
| R6 | "What would a good first month look like in this role?" | Shows interest in the work and gives you vocabulary for any later round |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Used SAP, or has ERP experience | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP." The in-house stock system stays at its own scope |
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: you schedule deliveries for three depots. The limit is the pack's observation: your material says deliveries, not production schedules |
| Managed logistics across the three depots | Inflated form of F1 | F1's quote: you schedule deliveries for three depots and chase suppliers when orders slip |
| Cut stock discrepancies by a third, or by 33% | Inflated form of F3 | F3's quote: discrepancies fell by about a third over a year, after you rebuilt the spreadsheet. The limit is the pack's observation: the material does not say how they were counted |
| Confident Excel user | Inflated form of F5 | F5's quote at its own scope: you rebuilt a stock-count spreadsheet. The limit is the pack's observation: the material does not say which application |
| Fully flexible on office days | Contradicted by F9 | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" |
| Made redundant | Contradicted by F11 | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" |

## Sources

Provided documents: Hannah Lowther's LinkedIn message; the advert for Operations Coordinator at Quillmoor Diagnostics; your message about your background and what you would tell her. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, all refused by the host before returning anything: "Quillmoor Diagnostics values"; "Quillmoor Diagnostics interview process operations coordinator"; "Quillmoor Diagnostics Avonmouth news"; "Hannah Lowther Talent Partner Quillmoor Diagnostics".

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Would have supplied published values for VAL themes and a values cheat sheet. None is in this pack |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | Would have established the loop after this call and sharpened persona weights. They rest on the relationship prior and Hannah's message |
| 3. `Quillmoor Diagnostics` strategy and recent news | unavailable | Would have fed CO questions and a grounding brief. The pack has no CO questions |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Would have fed an interviewer read and a reverse question tied to her path. Both are absent |
| 5. representative Operations Coordinator JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period: F10 becomes a quoted row and A5's slot becomes your own words
- Your answers to the answer slots, especially what the spreadsheet was built in (F5), whether you have produced a regular dispatch or delivery report (F4), and how the discrepancy figure was counted (C1): each regenerates its row from your words
- Your CV, or the stock-count spreadsheet or a summary of it: F3, F5 and C1 stay medium until something can be inspected, and a stock-count sheet or a delivery or dispatch report is the artifact that would raise them
- Why Quillmoor, in your own words: B1's second half becomes a mapped answer
- Search permission: the four refused searches can be rerun, which would add the company's published values, loop structure, recent news and Hannah's public footprint; a deeper pass (up to 6 further searches and 2 further fetches, several more minutes) would add a company grounding brief
- Hannah's answer on what follows the screen: the loop would establish persona weights for later rounds, and per-round packs become possible
- A `tuesday-dossier.md`, if you have one: it would add verified evidence and claims you have ruled out, which the pack would then follow
