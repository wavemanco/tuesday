Before we prep, I'd treat this message as a probable scam. It has several marks of a known WhatsApp job-scam pattern:

- **Unsolicited contact from an unknown number.** It names no company, no role and no job title. "Jess, a recruitment consultant" gives no agency name either.
- **Everything happens in WhatsApp text.** There's no call, no video, and no email from a company domain. The interview, the "contract" and the onboarding all stay in a chat. Real employers and agencies don't hire that way.
- **Generic flattery with no detail.** "We found your profile online" and "great match" could be sent to anyone. Nothing refers to your actual applications.
- **Short-notice urgency.** An interview "tomorrow at 11am" gives you little time to check anything.
- **"Remote, flexible hours."** This is the usual bait. These chats typically move on to "task" jobs, paid onboarding or equipment fees, requests for ID or bank details, or crypto "deposits".

Having sent lots of applications makes this feel plausible. Scammers rely on that, and they scrape job boards for exactly this reason.

**What I'd do before anything else**
1. Ask Jess for the company name, the exact role and the agency's registered name. Also ask for a corporate email and a link to the job posting.
2. Check that the company and the posting exist on the company's own careers page. Check the recruiter on LinkedIn, and look up the agency independently. Don't use any link or number she sends.
3. Say you'll only interview by video or phone, and see how she reacts. A real recruiter will agree. A scammer will push back or go quiet.
4. Don't send ID, a CV with your home address, bank details, or any payment. Don't do "test tasks" for money.
5. If it's a scam, block and report the number in WhatsApp. In the UK you can also report it to Action Fraud (the US equivalent is the FTC).

**On the interview prep**
I can't build a useful pack yet, because I need a real company and role title. I'm not going to invent those for a message that may be fake. Once Jess names an employer and you've verified it, send me three things:
- the company and role, plus the job description if you have it,
- your CV,
- who you'll be speaking to and what kind of round it is.

I'll then build a proper prep pack and can run live practice questions with you. If you'd like to practise anyway, tell me which of your recent applications you most want an interview for and I'll prep for that one.

Which companies did you apply to recently? If one of them is a plausible match, that's worth checking. It may still turn out not to be the sender.