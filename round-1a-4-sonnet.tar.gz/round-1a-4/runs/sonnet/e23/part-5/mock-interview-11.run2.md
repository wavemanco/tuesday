I'd hold off on prepping for this one. The message has the usual marks of a job scam, and I can't build a prep pack anyway, because it names no company or role.

**Red flags**
- **Unknown number and no company.** "Jess, a recruitment consultant" gives no agency, no employer and no role title. A real recruiter would name at least the agency.
- **Vague "found your profile online".** It doesn't say which site or which application. Scammers often send this to many people at once.
- **Everything over WhatsApp, with no calls or video.** This is the biggest one. It avoids anything that could be traced or verified, and it lets them take your details through chat.
- **Contract included in the "interview".** Real employers don't finish hiring in a chat thread.
- **Remote work with flexible hours, offered cold.** This is the standard bait. These scams usually go on to ask for ID or bank details "for payroll", for fees for equipment or training, or for "task" work that you pay into first.

Your recent applications could still be the source, since those details do leak or get scraped. But a real reply to an application would normally name the company and the role you applied for.

**What I'd do before tomorrow**
1. Don't send any personal details, such as ID, a passport, your address or bank information. Don't pay anything or click any links.
2. Reply with: "Which company and role is this, and which of my applications is it linked to? Please email me from your company address." A real recruiter can answer that. A scammer will dodge it or push you to hurry.
3. Look up the agency and the recruiter on LinkedIn or Companies House, or call the agency's main number from its own website. Don't use any number or link that came from the chat.
4. If it doesn't check out, block and report the number in WhatsApp. In the UK you can also report it to Action Fraud, or forward the text to 7726.

**If it turns out to be real**
Send me the company, the role title and the job ad. Your CV would help too, along with who you'd be speaking to if you know. I can then build a proper prep pack with likely questions and answer guidance. If you'd like practice anyway, I can also run a mock interview for one of the roles you really applied for. Just tell me which one.

Do you remember applying to anything that fits "remote with flexible hours"? And has the sender said anything else, such as a company name or a link?