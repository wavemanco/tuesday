I'd hold off on prepping for this one, because the message looks like a recruitment scam. It also doesn't give me what I need to build a prep pack, which is a company and a role.

**Warning signs**
- **No company or role.** "Jess" doesn't name an agency, an employer or a job title. A real recruiter would name at least one.
- **Vague "found your profile online".** Your applications could explain it, but scammers use the same line. A recruiter replying to an application usually says which role it was for.
- **Interview and contract entirely over WhatsApp, with no calls or video.** This is the classic pattern. Real employers want to hear or see you, and they don't sign contracts in a chat thread.
- **Remote and flexible hours, with no details.** This is the bait. It's often followed by a request for your ID, bank details or an upfront "equipment" or "training" fee. Some versions are task or money-handling jobs.
- **Unknown number and a next-day deadline.** The urgency is meant to stop you checking.

**What I'd do**
1. Don't send any documents, ID, bank details or addresses, and don't click any links.
2. Reply once, asking: "Which company is the role with, what's the job title, and which agency are you with? Please send the job description and email me from a company address." You could also ask for a video call.
3. Check the answers. Look up the agency's website and its listed phone number, and find the recruiter on LinkedIn. Contact the agency through those routes, not through the number that messaged you. Confirm the vacancy exists on the employer's own careers page.
4. If they dodge, push back on the call, or ask for money or ID, block and report the number on WhatsApp. In the UK you can also forward the message to Action Fraud or 7726.

If "Jess" comes back with a named company, a real job description and a verifiable contact, send me those. I'll build the full prep pack from them, with likely questions, answer guidance based on your CV and reverse questions to ask. If you'd like me to start sooner, paste the job posting and CV for one of your recent applications. I can prep you for those interviews, which are more likely to be real.

Did you apply to anything remote with flexible hours recently? If so, tell me which one, and we can check whether this message could really be connected to it.