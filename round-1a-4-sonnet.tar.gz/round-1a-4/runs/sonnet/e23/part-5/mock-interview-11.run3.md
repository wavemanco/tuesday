I haven't built a prep pack, because this message has the hallmarks of a recruitment scam. The prep skill also needs a company and a role title, and this message gives neither.

**Warning signs in the message**
- **No company or role.** "Jess" doesn't name an agency, an employer or a job. A real recruiter does that in the first message.
- **Unknown number, with no link to any application.** You've sent a lot of applications, but a genuine reply would usually come from a company email or from LinkedIn, and would mention the job you applied for.
- **"We found your profile online."** This is generic wording that fits anyone.
- **The interview and the contract both happen on WhatsApp, with no calls or video.** Real employers almost always speak to you live. Text-only hiring is the standard setup for fake-job scams.
- **"Remote with flexible hours" and an interview tomorrow at 11am.** The offer is attractive and the time pressure is built in.

**What these scams usually do next**
They "hire" you after a chat. Then they ask for ID or bank details for "payroll", or for a fee for equipment, training or a background check. Some send a cheque to deposit. Others turn it into a "task" job where you're asked to pay in first.

**What I'd do**
1. **Don't send personal details.** That includes ID, your address, bank details and your CV with contact information.
2. **Reply with questions.** Ask for the agency's full name, the employer, the job title and a company email address. A real recruiter will answer without trouble.
3. **Check the answers.** Look up the agency's registered website and phone number yourself, and contact them that way. Don't use any link or number "Jess" gives you. Then check whether the role is listed on the employer's own careers page.
4. **Never pay anything to get a job.** Real employers don't charge you.
5. **If it's fake,** block and report the number in WhatsApp. You can also report it to your local fraud agency, such as Action Fraud in the UK or the FTC in the US.

**If the role does check out**
Send me the company, the job title and ideally the job description. I can then build you a full interview pack, with likely questions, answer guidance based on your real experience, and questions to ask them. I can also run a live practice session.

If you remember which application this might be from, tell me. I can help you work out whether it matches.