I wouldn't prep for this one yet, because it looks like a scam. The mock-interview skill also needs a company name and role title to run, and this message gives neither.

**Red flags in the message**
- It comes from an unknown number, and "Jess" names no company, agency or role.
- "We found your profile online" is generic. Scammers send it to everyone.
- The interview, contract and everything else happen only over WhatsApp. Real recruiters use email from a company domain, a scheduling link, or a call or video.
- "No calls or video needed" is a deliberate avoidance of anything that could be traced or verified.
- It promises a remote job with flexible hours and gives no specifics.
- It pushes you to commit to a time tomorrow.

Plenty of people send out lots of applications, so it's easy to assume this came from one of them. Scammers rely on that. Check whether any application you sent matches a company or role you can name.

**What to do**
1. Don't click links, send ID, a CV with your full address, or bank details, and don't pay for anything. Paying for equipment, training or "registration" is a classic scam step.
2. Reply once with a verification request, for example: *"Thanks. Which company is the role with, what's the job title, and can you email me the details from a company email address? I'd also want a call or video interview."*
3. A real recruiter will answer easily. A scammer will dodge, repeat the pitch, or push you to move quickly.
4. Check any company they name yourself. Find its careers page through a search, not through a link they send, and confirm the role is listed there. Also check that the recruiter exists on LinkedIn and at the agency.
5. If it's a scam, block and report the number on WhatsApp. In the UK you can also report it to Action Fraud, or to your country's equivalent.

If they come back with a real company, a role you recognise and a verifiable contact, send me the job description and your CV. I'll build the full prep pack for that interview.