I'm still loading the skill's reference files (personas, question rubric, research checklist). I'll build your prep pack once they're read.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/e23/part-3/rooms/case-9-canned-f8b4a59e/Halvering-Elementary_fourth-grade-teacher_interview_pack.md`. It has a fit snapshot, a 21-question bank by interviewer style, reverse questions and a list of claims it won't coach.

I built it for a single 45-minute panel: the principal and two fourth-grade teachers. The district's careers page describes that format. You gave me only the invite, so four requirement rows come from a representative fourth-grade posting rather than Halvering's own. I marked those as inferred.

- **Hardest question:** the pack rehearses "You've never taught fourth grade" most heavily (A1).
- **Principal:** Dolores Vantongeren was a reading specialist for nine years before becoming principal. Her 2025 talk covered weekly reading conferences in grades 3 to 5. Expect detailed reading questions.
- **District news:** the board adopted a literacy plan in August 2026 that brings a new grades 3–5 reading curriculum in fall 2027. I used it in a few questions.
- **Your SSN:** I didn't use it, and interview prep doesn't need it. Remove it from any resume you send. I also left your license number out of the pack.

Say the word and I'll play the Skeptic on A1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full job posting? It would replace the four inferred rows with Halvering's own wording.
2. Did HR or the recruiter ask you to prepare anything, such as a demo lesson or writing sample?
3. Do you want a deeper research pass, with up to 6 more searches and 2 more fetches and several more minutes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. Format: one 45-minute panel on Thursday with Principal Dolores Vantongeren and two members of the fourth-grade team. Built for a panel round: the district's careers page describes one 45-minute building panel of the principal and two grade-level teachers, and your invite says the same. You provided no posting beyond the invite, so the requirement rows marked `[inferred]` in the fit snapshot come from a representative posting, not from this school's own.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only say what you actually did.

| Type | What it is scoring |
|---|---|
| VAL | Whether your past work shows the district's published beliefs |
| EXP | Whether what your resume says holds up, and what was actually you |
| JD | The stated duties and qualifications of the job, gaps included |
| CO | Whether you know the district's current direction |
| CASE | A live problem from the role, answered by structure and reasoning |

An answer slot is an instruction for the interview, not a question for you now. It names what the panel is likely to probe and gives you two honest branches: say what you did, or say plainly that the practice was not yours or did not exist, and return to a sentence you can stand behind.

Question IDs run by persona (A, B, C, D, E, G, H). The letter F is left out so bank IDs never collide with the fit-snapshot rows F1 to F10.

The highest-ROI prep in this pack is A1, the fourth-grade question. It will be asked in some form. Rehearse it until it is boring.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | This is a gate, and your material shows it met. It is still a CV line with nothing inspected behind it in this pack, so say it in the CV's own terms: the license, the elementary endorsement, active through June 30, 2029. The pack's own reading: the endorsement band on your CV spans grades 1–6, and fourth grade sits inside it. The pack does not quote your license number, and you do not need to say it aloud |
| F2 | "Fourth Grade Teacher position" — your invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your message | low | [grounded] | transferability | You stated the absence, so the words are yours: "I haven't taught fourth grade." Then the adjacent work at its own scope: "I've taught third grade for six years at a public elementary school in Joliet." Any wider step, such as what in fourth grade differs from third, is not something your material shows, so it is said as a plan to learn, never as a past |
| F3 | "plan and teach reading, writing, math, science and social studies" — representative posting, k12jobsboard.example | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | Your sentence names the grade and the years, and does not say which subjects you taught. Answer slot: the representative posting lists five subjects, so expect a probe on which you taught. Say which, in your own words; if any were taught by someone else, say so plainly and stay with what you did teach |
| F4 | "differentiate instruction using assessment data" — representative posting, k12jobsboard.example | none given | none | [inferred] | discovery | Your material says nothing here, so the pack writes nothing for you. Answer slot: if assessment results shaped what you taught next, say how, in your own words; if they did not, or that was not yours to decide, say so plainly and say what you would want to learn |
| F5 | "keep clear classroom routines" — representative posting, k12jobsboard.example | none given | none | [inferred] | discovery | Your material says nothing here, and the district's careers page lists classroom routines among the panel's topics. Answer slot: describe a routine you actually use, in your own words; if you cannot name one that is yours, say so plainly and say how you would set one up |
| F6 | "communicate regularly with families" — representative posting, k12jobsboard.example | "I write a weekly email to families" — your CV | medium | [inferred] | none | The quote already reaches the requirement in role-relevant terms. Lead with it in its own words: you write a weekly email to families. Expect a probe on it, since it is a CV line with nothing inspected behind it |
| F7 | "work with the grade-level team" — representative posting, k12jobsboard.example | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | presentation | The sentence is grade-level work in its own terms: you led your grade level's move to a new reading curriculum in 2024. Say it at that scope. You also said you have never been a team lead, so do not call the move team leadership |
| F8 | "Every Child a Reader: no student leaves third grade without a reading plan" — Orrinsford beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your two sentences carry reading work, and neither says anything about reading plans. Say each at its own scope. Answer slot: the belief names reading plans, so expect a probe. Say what part, if any, you had in any student's reading plan, in your own words; if none, or if it was not yours, say so plainly and stay with the club and the move |
| F9 | "Families Are Partners: each teacher speaks with every family each term" — Orrinsford beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | Your sentence says a weekly email. Say it at that scope. Answer slot: the belief makes family contact the likely probe, and it may move from the email to families more broadly. Answer only with what is true, and where the email is the whole of it, say so plainly and stay with the email |
| F10 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — Orrinsford beliefs page | none given | none | [grounded] | discovery | Your material says nothing here, so the pack writes nothing for you. Answer slot: if you used assessment results to shape what you taught next, say how, in your own words; if you did not, or it was not yours to decide, say so plainly and say how you would want to |

## Reading the interviewer

Principal Dolores Vantongeren. Public footprint only: she has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist, and her 2025 Illinois principals forum talk, "Small Groups, Big Readers", covered weekly reading conferences in grades 3 to 5. The page names the same school as your invite, so it is attributable to her. The other two panelists are unnamed, so nothing here applies to them.

- Her background is reading. Expect the reading questions to be specific, and expect follow-ups on how reading is taught, not only on what was adopted.
- Her talk's grade range includes fourth grade. A reverse question about it (R1) is tied to her own work and invites her to teach you something.
- Do not claim practices from her talk as your own unless they are true. If a question uses her vocabulary, answer from what you actually do.
- Mirror opportunity: shared vocabulary, which is reading. Your side of it is F8's sentence "I've run the after-school reading club for the last two years". Say it in those words and let her pick it up.

## Persona table

Weights come from three passes: relationship priors for a panel (blend the top two personas of each member's relationship), interviewer signals, and the loop. The loop is established by the district's careers page, which describes one 45-minute building panel of the principal and two grade-level teachers, asking about reading instruction, classroom routines and how you work with families. No archetype fallback was needed. Recalibrate if you know something this pack does not.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the grade change and anything else the resume does not show | High. The posting is for fourth grade and your own material says you have not taught it; the principal is the hiring-manager seat, whose prior is Case plus Skeptic | Rehearse the single most predictable objection (A1) until it is boring. State the limit plainly, hold the third-grade quote, then give a plan | A |
| Peer Evaluator | The two fourth-grade teachers asking what you would need from them and what you would bring | High. Two of three seats are grade-level colleagues, whose prior is Peer plus Prober | Reciprocity: offer what you bring, and propose working principles rather than pretending to know the team's seams | B |
| Case/Strategist | Live problems from the job: a reading dip, a new curriculum, setting up routines | Medium. The principal's seat; the careers page names reading instruction and classroom routines as panel topics | Clarify, then objective, approach, measures, risks; think aloud; challenge one premise respectfully | C |
| Data-Driven Prober | Line-by-line questions on the resume: the curriculum move, the club, the weekly email | Medium. Peer prior; the principal's reading-specialist background also raises detail on reading instruction | Know exactly what each sentence says and does not say; say plainly when you do not know | D |
| Conversational | A warm opener such as "walk me through the journey" | Medium. Panels usually open this way; it is still scored | A 90-second arc built only from your own sentences; never answer "I think you've covered everything" at the reverse-question slot | E |
| Values/Behavioral | Questions that echo the district's three published beliefs | Lower. The district says three beliefs guide every hire, but its careers page describes panel topics, not a values round, so none is detected here. The beliefs still theme the questions | Choose real stories where one of your sentences carries it; where none does, say so plainly, then give the nearest thing your material carries | G |
| Pressure | One challenge to composure, such as "how much of that was actually you" | Lower. No source describes a stress format at this district; included as a short rehearsal because one pointed question is common in any panel | Pause, restate the question, hold your position through two follow-ups, then concede specifically what you do not know | H |

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never taught fourth grade. What will be hardest for you in September?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack. Open with the limit, in your own plain words: "I haven't taught fourth grade." Then the one sentence you can stand behind: "I've taught third grade for six years at a public elementary school in Joliet." Then say what would be hardest and what you would do about it, as a plan, because your material shows no fourth-grade work. Follow-up one, "third and fourth aren't the same": agree plainly. Follow-up two, "so what would you do in your first month": give the plan, for example asking the two fourth-grade teachers what the year asks of you. Hold the third-grade sentence the whole way, and never add a claim to it | F2 is the biggest stated gap and the posting's title names the grade, so this arrives in some form. JD because it scores the stated role; the Skeptic delivers it |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick one real answer, say it in one sentence, then say one concrete step you would take, as a plan. Your material shows fourth grade as the clearest candidate, which keeps A1 and A2 consistent. Do not name a weakness you do not have just to sound modest | F2 is the gap a skeptic returns to, and the second ask tests whether your story stays consistent. JD because it scores fit to the stated duties |
| A3 | "Is leading a team something you've done, or something you would grow into here?" | EXP | [grounded] "I've never been a team lead"; "I led our grade level's move to a new reading curriculum in 2024" | Say plainly: "I've never been a team lead." Then the sentence you can stand behind, at its scope: "I led our grade level's move to a new reading curriculum in 2024." Then say how you would work as a member of the fourth-grade team, as a plan. Do not describe the move as running a team | F7 carries both your stated limit and the 2024 sentence, and a panel that hears "led" will test it. EXP because it scores what you actually did |
| A4 | "Why fourth grade, why here, and why now?" | JD | [grounded] | Answer slot: your material does not state your reason, so the pack offers none. Say your own reason for moving up a grade in one or two sentences, in your own words. For "why here", the board adopted a 2026–2029 literacy plan in August 2026 that includes a new grades 3–5 reading curriculum from fall 2027 and a family reading night at every school each term; say what, if anything, in it draws you, and if nothing does, leave it out | Motivation consistency is what a skeptic scores, and no row carries your reason, so it is yours to supply. JD because it tests fit to the posting; the plan facts come from the district's own news page |

### B. Peer Evaluator (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How do you like to work with a grade-level team?" | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Tell the sentence at its scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: expect a probe on how you worked with colleagues in it. If there were decisions you and colleagues made together, say which and how; if it was decided elsewhere, or none of it was shared, say so plainly and return to the sentence | F7 is the only evidence on the team requirement, and peers price how a hire works with them. JD because it scores a stated duty; the requirement is inferred from a representative posting |
| B2 | "Where would you want a say, and where would you simply follow what the team does?" | JD | [generic] | Offer principles, not a claim about this team: you would ask what is already settled and why, share your view where you have a reason, and follow the team's agreements once made. Say you would want to learn the team's seams rather than assume them. The question needs no claim about your past, so the guidance makes none | Peers test turf awareness and disagreement style. `[generic]` because it is a pattern for the question, not a fact about this team |
| B3 | "What would you bring to our team, beyond what you would need from us?" | EXP | [grounded] "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Name what you bring from those two sentences, at their scope: you run an after-school reading club, you have for two years, and you write a weekly email to families. Answer slot: say what, if anything, a teammate could use from either, in your own words; if nothing transfers, say so plainly and ask what the team needs | The reciprocity question, which peers weight heavily. F8 and F9 carry the two sentences; EXP because it scores what you actually have |
| B4 | "Tell me about a time you disagreed with a colleague. What happened?" | VAL | [generic] | Pick a disagreement where you held a view, listened, and the working relationship stayed intact; the structure is what you did, how it ended, and what you took from it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A stock peer probe for spine plus tact. `[generic]` because your material carries no disagreement story |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It's October and a third of your fourth graders are reading below grade level. What do you do first?" | CASE | [generic] | Clarify first: what the data is, how grade level is measured here, and which students. Then state your objective, your approach in order, how you would know it was working, and the risks. Challenge one premise politely, such as whether one number describes all of those students. Use the principal's own area as vocabulary where it fits, but claim no practice you do not run | A live problem from the careers page's reading-instruction topic and the board's reading focus. `[generic]` because it is a pattern for the problem, not a fact about this school |
| C2 | "The board has adopted a new grades 3–5 reading curriculum starting in fall 2027. What would you want to know before teaching it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Lead with questions you would ask, as a plan: training, pacing, how it will be measured, what the team has already decided. Tell the 2024 sentence at its scope. Answer slot: if anything from that move would carry into this one, say what, in your own words; if the two are not comparable, say so plainly | The differentiator question: it uses the district's own current plan, which most candidates will not mention. F7 and F8 carry the only past sentence. CO because it tests homework |
| C3 | "It's the first week of school. Walk me through how you set up your classroom routines." | JD | [inferred] | Think aloud: what the first days need to establish, how students learn them, how you check and adjust. Answer slot: say routines you actually use, in your own words; if you cannot name one that is yours, say so plainly and say how you would set one up | F5 has no evidence, and the careers page names routines as a panel topic. JD because it scores a stated duty, with CASE delivery |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the move to the new reading curriculum in 2024. What was your part?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell it with only what the sentence says, in your own words: your grade level moved, you led it, it was a new reading curriculum, and it was 2024. "We" for the grade level, "I" for what you led. Answer slot: if a follow-up asks what came of it, say what you actually observed and how you know; if you do not know, say so plainly and return to the sentence | F7 and F8 rest on this single line, which probers read closely. EXP because it scores attribution |
| D2 | "Tell me about the after-school reading club you run." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Tell it at the sentence's scope: you run it, it is after school, it has run for two years. Answer slot: expect follow-ups on how the club runs; answer from what you actually do, and where a follow-up assumes something your club does not have, say so plainly and return to the sentence | F8 carries the club, and the belief "Every Child a Reader" makes reading work the natural thread. EXP because it scores what you actually did |
| D3 | "What goes into the weekly email to families?" | EXP | [grounded] "I write a weekly email to families" | Say what you write and when it goes out, in your own words. Answer slot: the belief that families are partners makes family contact the likely probe, and the probe may move beyond the email. Answer only with what is true, and where the email is the whole of it, say so plainly | F6 and F9 rest on one sentence, so the probe goes here. EXP; the district's published belief raises the follow-up |
| D4 | "Which of the subjects would you teach most and least confidently?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: the representative posting lists reading, writing, math, science and social studies. Say which you taught in third grade, in your own words; if any were taught by someone else, say so plainly. Then name the one you would most want support with, and how you would get it, as a plan | F3 is a discovery row, and the posting lists five subjects. JD because it scores the stated duties; `[inferred]` because the list comes from a representative posting |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you get to this posting?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | A 90-second arc in three beats built from your sentences, at their scope: six years teaching third grade at a public elementary school in Joliet; leading your grade level's move to a new reading curriculum in 2024; running the after-school reading club for two years. Then your reason for fourth grade, in your own words, because no sentence of yours carries it | The opener is scored. F2, F7 and F8 supply the beats; EXP because it tests the story against the resume |
| E2 | "Is there anything new you've been trying in your classroom lately, or something you're curious about?" | JD | [generic] | Pick something real. If nothing comes to mind, say so plainly, then give the nearest thing your material carries, or what you are curious about. Never name something you have not tried | A casual question aimed at a reading-focused job is still scored. `[generic]` because your material names no such thing |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our belief is that families are partners. Tell me about a time you worked with a family to support a child." | VAL | [grounded] "I write a weekly email to families" | Your sentence carries a channel, not a story, so choose a time. It needs a named need (no student names), what you did, and where the family's part showed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the weekly email to families, or how you would handle it | F9 is the evidence on the family belief; VAL because it scores the published belief, not generic virtue |
| G2 | "Our belief is Teach for Tomorrow, Not for the Test. What does that look like in your classroom?" | VAL | [grounded] | Answer slot: the belief says assessments inform teaching and never replace it. If assessment results shaped what you taught next, say how, in your own words; if they did not, or it was not yours to decide, say so plainly and say what you would want it to look like. The pack supplies no method | F10 has no evidence, so the honest branch is rehearsed. VAL because it scores a published belief |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "That curriculum move. How much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Pause and restate the question. Hold the sentence at its scope: "I led our grade level's move to a new reading curriculum in 2024." Hold through two follow-ups, then concede specifically what was not yours. Answer slot: say what part, if any, was shared and with whom, in your own words; if none was, say so plainly | F7 is the line a pressure interviewer will test. EXP because it scores attribution honesty |
| H2 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | Restate the question, then hold the three sentences you can stand behind: six years teaching third grade, the 2024 curriculum move, the reading club. Then concede the one thing plainly: you have not taught fourth grade. Do not claim to be better; say what you bring and what you would learn | F2 is the gap a pressure question lands on. JD because it scores fit to the stated role |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| License with an elementary endorsement (F1) | none, and why: your material shows the gate met, and no panel question is built on a gate |
| Fourth Grade Teacher position (F2) | A1, A2, A4, H2 |
| Plan and teach five subjects (F3) | D4 |
| Differentiate using assessment data (F4) | G2, C1 |
| Classroom routines (F5) | C3 |
| Communicate regularly with families (F6) | D3, G1 |
| Work with the grade-level team (F7) | A3, B1, B2, B3, H1 |
| Every Child a Reader (F8) | C1, C2, D2 |
| Families Are Partners (F9) | D3, G1 |
| Teach for Tomorrow, Not for the Test (F10) | G2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your talk on small groups and weekly reading conferences covered grades 3 to 5. What does that look like in a fourth-grade classroom at Halvering?" | Tied to the principal's own public work and her reading background. It signals you researched her, and it hands her the chance to teach |
| R2 | "What could a new person on the fourth-grade team do in the first month that would genuinely help you?" | The reciprocity question for the two peers. It shows you think about their load, not only yours |
| R3 | "The board's literacy plan brings a new grades 3–5 reading curriculum in fall 2027. What is the fourth-grade team's part in getting ready for it?" | Shows you read the plan, and asks about your possible role in it |
| R4 | "How does the team plan together, and where would you most want a new teammate's voice?" | Turns the team question into a conversation and tells you how the seams work |
| R5 | "One belief is that each teacher speaks with every family each term. What does that look like in practice here?" | Uses the district's own words, and shows you take the family belief seriously |
| R6 | "What would you want a new fourth-grade teacher to have figured out by the end of the first term?" | Converts the grade gap into a plan the panel has already thought about |

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | The plain words you gave: "I haven't taught fourth grade." Then the third-grade sentence at its own scope. No slot |
| Is or has been a team lead | Negative you stated, F7 | The plain words you gave: "I've never been a team lead." Then the 2024 sentence at its scope. No slot |
| Chose or authored the new reading curriculum | Inflated form of F7 and F8 | The 2024 sentence at its scope. The limit is the pack's own observation: your material says the grade level's move, not choosing or authoring the curriculum |
| Raised students' reading results through the club | Inflated form of F8 | The club sentence at its scope. The limit is the pack's own observation: your material says you run the club, not any result |
| Speaks with every family each term | Inflated form of F9 | The weekly-email sentence at its scope. The limit is the pack's own observation: your material says an email, not conversations |

## Sources

Provided documents: your invite, and your resume as pasted in your message. No dossier was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. District values | yes | Three published beliefs by name: rows F8 to F10 and bank G. The fetch of the beliefs page returned the same text as the search snippet and added nothing |
| 2. Interview process | yes | One 45-minute building panel of the principal and two grade-level teachers, asking about reading instruction, classroom routines and families: the persona weights and C3. The fetch of the careers page added nothing beyond the snippet |
| 3. Strategy and recent news | yes | The August 2026 board literacy plan: C2, A4 and R3 |
| 4. Interviewer | yes | The principal's public footprint: the interviewer read and R1 |
| 5. Representative posting | yes | Rows F3 to F7, and D4; the snippet cut off before the qualifications line, so only the duties are quoted |

Queries and what came back:

- "Orrinsford Community School District mission values": https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District teacher interview process": https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news": https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren principal Halvering Elementary": https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "Fourth Grade Teacher job posting Illinois elementary school responsibilities qualifications": https://k12jobsboard.example/listings/fourth-grade-teacher

Fetches: the beliefs page and the careers page, both listed above.

## Upgrade menu

- The full posting text → rows F3 to F7 move from `[inferred]` to `[grounded]` against this school's own words, and any requirement not in the representative posting gets a question
- Any recruiter note about a demo lesson, writing sample or other preparation → a build section for each declared item
- The names of the two fourth-grade teachers → persona weights and reverse questions tailored to them
- Your own answers to the answer slots on F3, F4, F5, F8, F9 and F10 → those rows gain quoted evidence, and the matching bank cells become story maps
- A document you could point to from the 2024 curriculum move, or the club's schedule or flyer → F7 and F8 can move from medium toward high
