I'm fetching the district's values page and the principal's speaker page. Then I'll write the pack.
Your prep pack is saved as `Halvering-Elementary_fourth-grade-teacher_interview_pack.md`. I built it for a single 45-minute panel with the principal and two fourth-grade teachers. It rests on your CV and the invite only, so two requirement rows come from a representative posting and are labeled as inferred.

Your Social Security number isn't needed for interview prep. I didn't use it, and it isn't in the pack. Your educator ID number isn't in the pack either. Take both off any resume you send out.

The pack puts the most rehearsal on A1, "You've taught third grade, not fourth." You said you've never taught fourth grade, so expect that question in some form. Rehearse it, then A3 (no team-lead experience) and G1 (the same objection under a 60-second limit).

Say the word and I'll play the Skeptic panelist on A1, with follow-ups that react to what you actually say. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, I can convert it.

1. Do you have the full job posting?
2. Did HR say anything about what to bring or do at the panel, such as a sample lesson?
3. Do you want a deeper research pass, which is up to 6 more searches and 2 more fetches and takes several more minutes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** One 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Built from:** the invite and your CV text. No full job posting was supplied, so two requirement rows rest on a representative posting and are labeled `[inferred]`.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. The guidance cells are scaffolding, not a script: say the beats in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your CV claims survive scrutiny; what was actually you |
| JD | The role's stated or typical requirements, including the gaps |
| CO | Homework on the district and its current priorities |
| CASE | A live problem set in the role, answered by structure and reasoning |

Highest-ROI prep in this pack: **A1**, "You've taught third grade, not fourth." It will be asked in some form, and a calm, specific answer that stays inside what you have said changes the panel. Rehearse A1, then A3, then G1 (the same objection under time pressure). Everything else is insurance.

An answer slot is an instruction for the interview, not a question for you now. Where one appears, answer from your own experience, or say plainly that the practice was not yours or did not exist.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is shown met on your CV, with no license record inspected behind it. Say it in the quote's own terms: "I hold an Illinois Professional Educator License with the Elementary Education endorsement, grades 1–6, registered and active through June 30, 2029." Fourth grade falls inside grades 1–6 as the quote states them. Nothing to rehearse beyond saying it plainly |
| F2 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller. A1 and A2 rehearse it |
| F3 | Plan and teach the core subjects of an elementary grade (a representative fourth-grade posting found by search, not this school's posting) | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | transferability | Your material gives the grade, the years and the school type, with nothing inspected behind it. Words stay at that scope: "I've taught third grade for six years at a public elementary school in Joliet." The pack's observation is that the material does not say which subjects were yours to teach, so A5 asks in a form that lets either answer be true |
| F4 | "Every Child a Reader: no student leaves third grade without a reading plan." — the district's Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024", "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Two sentences about reading, each at its own scope: the grade level's curriculum move, and the club. The pack's observation is that the material carries a curriculum move and a club, and says nothing about reading plans for students. Answer slot: the belief's reading-plan line makes a probe on plans likely. If reading plans were part of your third-grade work, say how, in your own words; if not, or they were not yours, say so plainly and stay with the curriculum move and the club |
| F5 | Run a classroom with clear routines (a representative fourth-grade posting; the district's hiring page lists classroom routines among panel topics, seen as a search result) | none given | none | [inferred] | discovery | Nothing in your material shows or denies this. Selection scaffold: pick one routine you have run in your own room that you can describe step by step, with what it was for and what you changed in it afterwards; if none comes to mind, say so plainly, then say how you would set up the first two weeks with a new class (F2 in the Conversational bank) |
| F6 | "Families Are Partners: each teacher speaks with every family each term." — the district's Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | Words stay at the quote: "I write a weekly email to families." The pack's observation is that the material shows an email, and a conversation is a different kind of contact. Answer slot: if the email brought replies or follow-ups from families, say what happened, in your own words; if it did not, or it ran one way only, say so plainly and stay with the weekly email |
| F7 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — the district's Mission and Beliefs page | none given | none | [grounded] | discovery | Your material says nothing either way. Answer slot: a probe on how assessment shaped your teaching is likely. If results from any assessment changed what you taught, say what and how, in your own words; if none did, or it was not yours to decide, say so plainly and say how you would use assessment results, as a plan |
| F8 | Work with a grade-level team (a representative fourth-grade posting; the invite puts two fourth-grade team members on your panel) | "I led our grade level's move to a new reading curriculum in 2024" — your CV, "I've never been a team lead" — your message | medium | [inferred] | transferability | Two sentences, kept apart: the grade level's curriculum move, which is your own verb at your own scope, and a stated absence of a team-lead role. Words: "I led our grade level's move to a new reading curriculum in 2024," and, if the question comes: "I've never been a team lead." The pack's observation is that the material does not say how that move was decided or who else was in it, so A3 and G2 hold only the sentence |

## Reading the interviewer

Public professional footprint only, for Principal Dolores Vantongeren. The two team members are unnamed, so there is no read for them.

| Public fact | Provenance | What it means for your prep |
|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | [grounded] Forum speaker page, read in full | Expect reading instruction to be probed more closely than usual. Use reading vocabulary only as you actually use it in your own room |
| 2025 forum talk "Small Groups, Big Readers" covered weekly reading conferences in grades 3 to 5 | [grounded] Forum speaker page, read in full | Small groups and reading conferences are her stated topic, so expect them to come up. Do not describe a practice of your own that you do not run; if asked, an honest account of how you actually group students beats borrowed phrasing |

Mirror opportunity, kept to what is quoted: her public path is in reading, and your side of that ground is "I've run the after-school reading club for the last two years" (F4). Offer it at that scope and let her ask.

## Persona table

The loop is one panel (the invite). Weights below blend the top two personas for each seat: the principal as hiring-manager-style (Case, Skeptic) and two grade-level teachers as peers (Peer Evaluator, Prober), then adjust for the signals shown.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A, 5 questions) | Quiet, persistent probing of fourth grade and the team question | Highest. Your own material states two absences (F2, F8), and the panel's principal seat carries the hiring-manager prior | Rehearse the single objection until it is boring; say the stated negative plainly, then the plan |
| Case/Strategist (B, 3) | Live problems on reading and the literacy plan | High. The principal's reading background and the board's literacy plan both point at reading cases | Clarify first, then objective, approach, measures, risks; think aloud |
| Peer Evaluator (C, 3) | The two teachers asking how you would fit the team | High. Two of three seats are grade-level teachers | Reciprocity framing; propose working principles rather than pretending to know their seam |
| Data-Driven Prober (D, 3) | Pressing on how you knew the curriculum move or club was working | Medium. The CV carries sentences but no figures, so probing goes to practices, not numbers | Know what you can and cannot say about each sentence, and say plainly where you do not know |
| Values/Behavioral (E, 3) | Stories matched to the district's three beliefs | Medium. The district's hiring page, as a search result, lists reading instruction, routines and families as panel topics, and names no separate values round. Beliefs still theme questions | Where a quoted sentence carries a story, use it at its scope; where none does, pick a real instance, or say none comes to mind |
| Conversational (F, 2) | Opening "walk me through the journey" | Medium. Almost every panel opens this way | A 90-second arc built only from sentences you have written |
| Pressure (G, 2) | Time-boxed "why you" and "how much was actually you" | Low. Nothing in the invite or the principal's footprint signals a stress style | Pause, restate, hold the core through two follow-ups, concede specifically |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade for six years, not fourth. What will be hardest for you on day one?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet", "I've never taught fourth grade" | Highest-ROI rehearsal. Pause. Say it plainly: "I haven't taught fourth grade." Then the six years at their own scope. Then a plan, in the future tense: name what you would want to learn first about fourth grade and whom you would ask. Hold through two follow-ups by returning to what you have said; concede specifically what you do not yet know; never add experience to close the gap. Answer slot: the district's reading-plan belief makes a probe on what happens when a third grader moves on likely. If reading plans or handoffs were part of your third-grade work, say how, in your own words; if not, or they were not yours, say so plainly and stay with the six years | F2 is the largest stated gap and F4 is where the district's own words press on it. JD because it scores fit to the stated grade |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Pick the answer that is true for you. One candidate answer is already in your words: "I've never taught fourth grade." Give it, then a first step as a plan. If something else is truer, say that instead, and name it without cushioning | F2 is the likeliest honest answer, and the panel is scoring whether you know your own gap. JD because it tests the role's demands |
| A3 | "You haven't been a team lead. How do you see yourself fitting into a fourth-grade team?" | EXP | [grounded] "I've never been a team lead", "I led our grade level's move to a new reading curriculum in 2024" | Acknowledge once: "I've never been a team lead." Then the one sentence you do have, at its scope: "I led our grade level's move to a new reading curriculum in 2024." Stop there and let them ask. Answer slot: if they ask what that involved, say what you did, in your own words; if decisions were shared, or some of it was not yours, say so plainly and return to the sentence | F8 pairs a stated absence with one adjacent sentence. EXP because it tests what the CV line actually carries |
| A4 | "Why leave your current school, why here, and why now?" | CO | [grounded] Board literacy plan and district beliefs, cited in Sources | Your reason is yours to give; the pack supplies none. Say it in your own words and keep it forward-looking. For "why here", you may name what you read: the district's three published beliefs, and the board's 2026–2029 literacy plan. Say only what you actually find appealing in them. Answer slot: if something about your current school's direction is part of your reason, say it plainly and fairly; if it is not, leave it out | The Skeptic persona's standard motivation probe, and the one place the district research pays off for any candidate. CO because "why here" is scored on homework |
| A5 | "Which subjects have you taught, and where do you have the least experience?" | JD | [inferred] a representative fourth-grade posting, found by search | Selection scaffold: name the subject you have taught least, say what you have actually done in it, and give a first step as a plan. If every subject was fully yours, say so plainly; if some were handled by others or by a specialist, say that plainly too. If no gap comes to mind, say so, then give how you would find one | F3 is the one place the material gives a grade and years but no subjects. JD because it scores the role's core duties; `[inferred]` because the requirement comes from a representative posting |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A fourth grader starts the year reading well below level. Walk me through your first six weeks with that child. What do you need to know first?" | CASE | [grounded] District Mission and Beliefs page, cited in Sources | Clarify first: what the child's reading looked like before, what data exist, what the family sees at home, and what reading plan came with the child. Then objective, approach (the format is yours to choose and describe), how you would check it is working, and what could go wrong. Think aloud. This question asks nothing about your past, so the guidance claims nothing about it | The district's published belief is that no student leaves third grade without a reading plan, and the principal's public focus is reading. CASE because it is a live problem from the role |
| B2 | "The board has adopted a plan for a new grades 3 to 5 reading curriculum from fall 2027. How would you want to help a fourth-grade team get ready for it?" | CO | [grounded] Board literacy plan, cited in Sources; "I led our grade level's move to a new reading curriculum in 2024" | Show you read it: the plan adopted in August 2026 includes a new grades 3 to 5 reading curriculum from fall 2027. Then clarify before proposing: what the team already knows, who chooses the curriculum, what the timeline is. Your own sentence, at its scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if that move taught you anything about getting colleagues ready, say what, in your own words; if it did not involve preparing colleagues, or that was not yours, say so plainly and stay with the sentence | F4 and F8 meet current district strategy here, the one strategy-grounded question in the pack. CO with a CASE delivery |
| B3 | "The district plans a family reading night at every school each term. How would you plan one for fourth grade?" | CASE | [grounded] Board literacy plan, cited in Sources; "I've run the after-school reading club for the last two years", "I write a weekly email to families" | Structure it: who comes and what they want, what the night is for, how families hear about it, how you would judge afterward whether it worked, and what could go wrong. Your two sentences, at their scope: "I've run the after-school reading club for the last two years" and "I write a weekly email to families." Answer slot: if anything from the club or the email would carry over, say what and why, in your own words; if nothing would, say so plainly and design from the problem | F4 and F6 meet the district's own plan. CASE because it is a planning problem from the role |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Where do you like to lead on a team, and where do you like to follow?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024", "I've never been a team lead" | Reciprocity first: what you bring a fourth-grade team, not only what you need from it. Offer working principles rather than guessing their seam. Your one lead example, at its scope: "I led our grade level's move to a new reading curriculum in 2024." If the title comes up: "I've never been a team lead." Answer slot: where you would follow, say a specific kind of work in your own words; if you have no preference, say so plainly | F8 again, in collegial packaging. EXP because it tests what the lead sentence carries |
| C2 | "Tell me about a time you disagreed with a colleague at your grade level." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Selection scaffold: pick a real disagreement with a named stake, where you held a position and kept the relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I led our grade level's move to a new reading curriculum in 2024," or how you would handle it. Say only what happened | The Peer persona's disagreement-with-equals probe. EXP because it asks for a real instance; F8 is the only row near it |
| C3 | "How do you handle credit when work is shared across the team?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | "We" for context, "I" for contribution. The verb you have is "led," at the scope of the grade level's move, so use it at that scope. Answer slot: if some of that move was shared or was someone else's, say which parts, in your own words; if all of your part was yours alone, say that plainly | Credit-sharing probes land hardest on a sentence containing "led." EXP because it scores attribution honesty |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You led your grade level's move to a new reading curriculum. How did you decide it was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Open with the sentence at its scope. Answer slot: the district's belief that assessments inform teaching and never replace it makes a probe on evidence likely. If you tracked how the curriculum was going, say what you looked at and how, in your own words; if you did not, or someone else did, say so plainly and return to the sentence. "I don't know how that was measured" is an honest answer | F4 and F7 together; the question's premise is a practice the quote does not carry, so the slot allows that it never existed. EXP because it tests the CV claim |
| D2 | "Walk me through the reading club you run." | EXP | [grounded] "I've run the after-school reading club for the last two years" | The club and the two years, in those words. Answer slot: the principal's public topic is small-group reading, so a probe on how students were grouped or what they read is likely. If you grouped students, say how; if you did not, or choices were not yours, say so plainly and describe the club as it actually ran | F4's second sentence, and the likeliest place a reading-specialist principal asks. EXP because it defends a CV line |
| D3 | "What would you want to know about each student in your first two weeks, and what would you do with it?" | JD | [inferred] a representative fourth-grade posting; district beliefs page | A plan, in the future tense, with no claim about your past. Name the information you would ask for, who has it, and one decision it would change. Say plainly what you would not do with it: the district's published line is that assessments inform teaching and never replace it | F7 has no evidence either way, so this asks forward-looking. JD because it scores the differentiation duty the representative posting lists |

### E. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a student wasn't reading the way you hoped. What did you do?" | VAL | [grounded] "I've run the after-school reading club for the last two years" | Theme: Every Child a Reader. Selection scaffold: pick one real student or small group; it needs a named stake, what you did yourself, and what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I've run the after-school reading club for the last two years," at that scope, or how you would handle it | F4. VAL because it scores a published belief, not generic virtue |
| E2 | "Tell me about a time you worked with a family to help their child." | VAL | [grounded] "I write a weekly email to families" | Theme: Families Are Partners. Selection scaffold: one real family and child, what you did, and what changed. The nearest sentence you have is "I write a weekly email to families," at its scope. Answer slot: if a family answered or acted on the email, say what happened, in your own words; if that did not occur, say so plainly and stay with the email | F6. VAL because it scores a published belief |
| E3 | "Tell me about a time an assessment told you something that changed how you taught." | VAL | [grounded] District Mission and Beliefs page, cited in Sources | Theme: Teach for Tomorrow, Not for the Test. Selection scaffold: pick a real instance with what the assessment showed, what you changed, and what happened next. No sentence of yours carries this one. If no such time comes to mind, say so plainly, then say how you would use an assessment result, as a plan | F7. VAL because it scores a published belief; the guidance claims nothing about your past |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you get to third grade, and why fourth grade now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet", "I've run the after-school reading club for the last two years", "I write a weekly email to families" | A 90-second arc, with beats only from your sentences: the six years in third grade, the reading club, the weekly email. Answer slot: why you became a teacher and why fourth grade now are yours to say, in your own words; nothing in your material supplies them | Almost every panel opens this way, and casual questions are still scored. EXP because it tells the CV in order |
| F2 | "What would a normal morning in your fourth-grade classroom look like?" | JD | [inferred] a representative fourth-grade posting | A plan told in order, in your own words. Say how you would fit the school's existing routines and ask what the team already does. Any routine you say you already use must be one you actually use; the pack names none for you. If no routine from your own room comes to mind, say so plainly and give how you would set one up | F5 has no evidence, so this asks forward-looking. JD, in the casual register the Conversational persona uses |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a teacher who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet", "I led our grade level's move to a new reading curriculum in 2024", "I've run the after-school reading club for the last two years", "I've never taught fourth grade" | Pause, restate the question, then hold: three sentences of yours, at their scope, and nothing wider. Concede the real gap in one line: "I haven't taught fourth grade." Hold through two follow-ups; concede specifically what you do not know yet, and do not fold on the sentences you can stand behind | A1's objection under time pressure. JD because it scores fit; the pressure style is the delivery |
| G2 | "You said you led that move. How much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Pause. Hold the sentence at its scope: the grade level's move. Answer slot: say which parts were yours, in your own words; if some were shared or someone else's, say so plainly. Conceding a specific part honestly is stronger than defending the whole | F8 and F4 under the attribution probe the Pressure persona favors. EXP because it tests what the quote carries |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| License and elementary endorsement (F1) | none, and why: the gate is shown met on your CV, and F1 holds the one sentence to say |
| Fourth Grade Teacher position (F2) | A1, A2, G1 |
| Core subjects (F3) | A5 |
| Every Child a Reader (F4) | B1, D2, E1 |
| Classroom routines (F5) | F2 |
| Families Are Partners (F6) | B3, E2 |
| Assessment informs teaching (F7) | D1, D3, E3 |
| Grade-level team (F8) | A3, C1, C2, C3, G2 |
| District literacy plan (research) | A4, B2, B3 |

Your CV text carries no figures, so no defend-the-number question is included.

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. How does that shape what you look for in how fourth-grade reading is taught here?" | Ties to her own path and shows you researched her, not only the school | [grounded] Forum speaker page |
| R2 | "Your talk covered weekly reading conferences in grades 3 to 5. What does that look like in fourth grade at Halvering?" | Invites her to teach you, in her own subject, without claiming a practice of your own | [grounded] Forum speaker page |
| R3 | "The board's plan brings a new grades 3 to 5 reading curriculum from fall 2027. How is the fourth-grade team preparing, and where would a new teacher be most useful?" | Shows district homework and asks about the work, not the perks | [grounded] Board literacy plan |
| R4 | "What could a new person do in their first month that would genuinely help your team?" (to the two teachers) | The reciprocity question for peers: it asks what you can give before what you need | [generic] |
| R5 | "What does a strong first semester look like for a fourth-grade teacher who is new to the building?" | Surfaces the real bar and signals you are thinking about the ramp, which is where your stated gap sits | [generic] |
| R6 | "How do teachers and families stay in touch across a term here?" | Ties to the district's published family belief and lets you hear how it works in practice | [grounded] District Mission and Beliefs page |

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | The plain acknowledgment: "I haven't taught fourth grade." No slot. Your six years stay at "Six years teaching third grade at a public elementary school in Joliet" |
| Has been a team lead | Negative you stated, F8 | The plain acknowledgment: "I've never been a team lead." The adjacent sentence stays at its scope: "I led our grade level's move to a new reading curriculum in 2024" |
| Led the school's or the district's move to a new reading curriculum | Inflated form of F8 and F4 | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The pack's observation is that your material says the grade level's move, not the school's |
| Ran the school's reading program | Inflated form of F4 | The quote at its own scope: "I've run the after-school reading club for the last two years." The pack's observation is that your material says an after-school club, not a program |

## Sources

Provided documents: the interview invite from Human Resources, Orrinsford Community School District; your resume text and the two sentences you added about fourth grade and team leadership.
Searches sent (6) and fetches sent (2):

| # | Call | Query or URL | What came back |
|---|---|---|---|
| 1 | search | Orrinsford Community School District values mission | https://orrinsfordschools.example/about/mission-and-beliefs |
| 2 | search | Halvering Elementary School Orrinsford fourth grade teacher | no results |
| 3 | search | Dolores Vantongeren principal Halvering Elementary | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| 4 | search | Orrinsford Community School District teacher interview process panel | https://orrinsfordschools.example/careers/how-we-hire-teachers |
| 5 | search | Orrinsford Community School District strategic plan news | https://orrinsfordschools.example/news/board-adopts-literacy-plan |
| 6 | search | fourth grade teacher job posting Illinois elementary school responsibilities | https://k12jobsboard.example/listings/fourth-grade-teacher |
| 7 | fetch | https://orrinsfordschools.example/about/mission-and-beliefs | read in full |
| 8 | fetch | https://ilprincipalsforum.example/speakers/dolores-vantongeren | read in full |

Calls 4, 5 and 6 were seen as search-result excerpts only, not read in full; nothing from them is quoted in a requirement cell or treated as a source for what you did.

Research tier: L1 — searches 6 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | The three published beliefs by name: F4, F6, F7, and the VAL bank E1 to E3 |
| 2. `Orrinsford Community School District interview process` | yes | Result excerpt describes one 45-minute building panel, consistent with the invite; panel topics shaped persona weights. No separate values round was named, so no values cheat sheet is included |
| 3. `Orrinsford Community School District strategy` / recent news | yes | Board literacy plan excerpt (August 2026): B2, B3, A4, R3 |
| 4. `Dolores Vantongeren Halvering Elementary` | yes | The interviewer read, D2, R1, R2. The two team members have no names, so no read for them |
| 5. representative `fourth grade teacher` JD | yes | No JD was supplied. One search for this school's posting returned no results; a second returned a representative posting excerpt: F3, F5, F8 and A5, F2, D3, all `[inferred]` |

## Upgrade menu

- The full posting text → F3, F5 and F8 become `[grounded]`, and the routines and team rows gain real requirement wording to rehearse against
- Anything Human Resources said about what to bring or do at the panel, such as a sample lesson or a writing sample → a build section for that deliverable
- The names of the two fourth-grade team members → an interviewer read for each seat and persona weights set per person
- Your answers to the slots on F4, F6 and F7, given outside a practice session → those rows move from slot to quoted evidence and the matching guidance cells regenerate
- A look at your Illinois license record on the state's licensing lookup, which needs no number from you here → F1 moves from `medium` to `high`
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a fuller grounding brief on the literacy plan and a fuller read of the principal's public talks
- A `tuesday-dossier.md` from the job-underwriter skill, if you have one → a verified-evidence base and an underwriter-chosen top objection in place of the one inferred here
