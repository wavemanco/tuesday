# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. A 45-minute building panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given).

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for your own words, not a script, and where it says answer slot it asks you to decide which honest branch is true for you.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether your CV's claims survive scrutiny, and what was actually yours |
| JD | The stated requirements of the role, including its gaps |
| CO | Whether you know the district's current direction |
| CASE | Structure and reasoning on a live problem from the role |

Fit rows are F1 to F9. Question banks use letters A to E, G and H, skipping F so the IDs never collide with fit rows. Provenance labels: `[grounded]` traces to your documents or to cited research, `[inferred]` is derived from a typical listing or an adjacent source, `[generic]` is a role-family pattern with no claim about this district or about you.

## Prep triage

You have about two days, counting from 24 November. Do these in order. Everything else is insurance.

1. A2 and its follow-up ladder, out loud, three times. It is the highest-ROI prep in this pack.
2. G1, your 90-second opening arc, built only from your own sentences.
3. A3 and E1: decide in your own words what "led" meant, and which branch of each answer slot is true.
4. The remaining answer slots in F3, F6, F8 and F9 (E3, D2, E2, B4): decide aloud which branch is true for you.
5. Pick three reverse questions.

## Fit snapshot

The requirements come from the invite, from the district's published pages, and from a typical fourth-grade listing found by search. That listing is not this district's posting, so every row built on it is `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | No gap in your material, but a CV line with nothing inspected behind it, so expect a quick verification. State it in the quote's own terms and stop. The quote's grade range, 1–6, includes fourth grade |
| F2 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade and I've never been a team lead" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would get up to speed, said as a plan and never as a past: what you would find out first and from whom, in your own words. Nothing added to make the gap feel smaller |
| F3 | "plan and teach reading, writing, math, science and social studies" — a typical fourth-grade listing, K12 Jobs Board (search result, not this district's posting) | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | Your material gives the grade and the years and does not say which subjects you taught. Answer slot: a typical listing's subject line makes a probe on subjects likely. If you planned and taught more than one subject in those six years, say which, in your own words; if you taught only some, or others taught them, say so plainly and stay with the six years of third grade |
| F4 | "Every Child a Reader: no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material says a curriculum move and a club, not a reading plan for each student, and the words stay at that scope: "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years." Answer slot: the belief makes a probe on how far your reading work reached likely. Say in your own words who the move and the club served and which part was yours; if you cannot say, or the part was shared, say so plainly and stay with the move and the club |
| F5 | "communicate regularly with families" — a typical fourth-grade listing, K12 Jobs Board (search result) | "I write a weekly email to families" — your CV | medium | [inferred] | none | No gap in the listing's terms, but a CV line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you write a weekly email to families. A named routine beats an adjective. Add nothing about what the emails contain or achieved; your material states neither |
| F6 | "Families Are Partners: each teacher speaks with every family each term" — Orrinsford Mission and Beliefs page | "I write a weekly email to families" — your CV | low | [grounded] | transferability | The email is writing to families, and the belief is about speaking with each one, a different kind of contact, so the words stay at the quote's scope: "I write a weekly email to families." Answer slot: the belief makes a probe on your contact with families likely. Say in your own words what that contact was, starting with the weekly email; if the email was the whole of it, or any other contact was not yours to have, say so plainly and stay with the email |
| F7 | "work with the grade-level team" — a typical fourth-grade listing, K12 Jobs Board (search result) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never taught fourth grade and I've never been a team lead" — your message | medium | [inferred] | none | No gap in the listing's terms: the move was at grade-level scope, and the words stay there. The same material limits the title, in your own words: "I haven't been a team lead." Expect a probe where the two sit side by side (A3). Answer slot: if asked what leading the move involved, say in your own words what you did and which part was yours; if it was shared or directed by others, say so plainly and stay with your part |
| F8 | "differentiate instruction using assessment data" — a typical fourth-grade listing, K12 Jobs Board (search result); "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it" — Orrinsford Mission and Beliefs page | none given | none | [inferred] | discovery | Your material says nothing about assessment, which is silence, not a negative. Answer slot: the listing and the district's belief both point here, so a probe is likely. If you used assessment results to change what or how you taught, say which results and what changed, in your own words; if you did not, or that was set by others, say so plainly and say how you would approach it |
| F9 | "keep clear classroom routines" — a typical fourth-grade listing, K12 Jobs Board (search result); "classroom routines" — Orrinsford How we hire teachers page | none given | none | [inferred] | discovery | Your material says nothing about routines, which is silence, not a negative. Answer slot: the district's own page lists classroom routines among panel topics, so a probe is likely. If you run a routine you can describe, say what it is and why, in your own words; if you did not run one, or it was set by others, say so plainly and say what you would set up first |

## Requirement coverage

| Row | Requirement | Questions |
|---|---|---|
| F1 | Illinois PEL with elementary endorsement | A5 |
| F2 | Fourth Grade Teacher position | A1, A2, A4, H1 |
| F3 | Plan and teach the core subjects | E3, G2 |
| F4 | Every Child a Reader | C1, C2, D1, G2 |
| F5 | Communicate regularly with families | B2, C3 |
| F6 | Families Are Partners | C3, D2 |
| F7 | Work with the grade-level team | A3, B1, B2, B3 |
| F8 | Differentiate with assessment data; assessment informs teaching | E2, D3 |
| F9 | Clear classroom routines | B4 |

## Reading the interviewer

Public professional footprint only. Nothing was found about the two fourth-grade team members, and no self-described style was found for the principal.

| Item | What the source says | Provenance | Implication |
|---|---|---|---|
| Career pattern | "Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist." — Illinois principals forum speaker page | [grounded] | Reading questions from her will come from a specialist's ear. Be exact about which part of your reading work was yours (A3, E1) |
| Published talk | "Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5." — same page | [grounded] | Her frame spans your grade and the one you are applying to. If conferences come up, answer from what you actually do (G2 holds the slot) |
| Panel assignment | One principal plus two grade-level teachers — Orrinsford How we hire teachers page | [grounded] | Principal: Case/Strategist and Skeptic. The two team members: Peer Evaluator and Prober, by relationship, since no names or profiles were found |
| Mirror opportunity | Shared vocabulary only: reading, small groups, conferences | [inferred] | Use her words only where they are true of your practice. No row offers a shared career jump, so none is suggested |

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | The principal probing the step from third to fourth grade and the "led" next to "never been a team lead" | Highest. A hiring-manager seat starts at Case/Strategist plus Skeptic, and your own message states two limits (F2, F7) that a seat-filling panel will test | Rehearse A2 until it is boring; concede with the plain acknowledgments your message sources; bridge only from adjacent quotes; give a plan, never a past |
| Peer Evaluator (bank B, 4) | The two fourth-grade teachers asking about the seam, collaboration and routines | High. Peer seats start at Peer Evaluator plus Prober, two of the three seats are the grade team, and the district page lists routines and families as panel topics | Reciprocity framing; propose seam principles, not a pretended seam; disagreement stories only if one is real |
| Case/Strategist (bank C, 3) | The principal setting a live reading or family problem, or asking about the literacy plan | Medium-high. Hiring-manager prior, tilted to reading by her background and by the district page listing reading instruction as a panel topic | Clarify, objective, approach, how you would know, risks; think aloud; challenge one premise respectfully |
| Values/Behavioral (bank D, 3) | Scenario prompts themed on the three published beliefs | Medium. No values round is documented, so none is assumed, but the page says the beliefs guide every hire and two panel topics map to them | Map a story to a belief only where your own sentence carries one; otherwise use the selection scaffold and its honest branch |
| Data-Driven Prober (bank E, 3) | Teachers pressing on what was yours in the curriculum move and on subjects and assessment | Medium. Secondary peer persona; your CV's dates and durations are what it can press on | Know what you can and cannot say; say plainly when you do not know; stay with the part you name |
| Conversational (bank G, 2) | An opening "walk us through the journey" and a casual reading question | Low-medium. Casual-register questions are still scored; the sources document no format for the opening | A 90-second arc built from your own sentences; treat the casual reading question as scored |
| Pressure (bank H, 2) | A time-boxed "why you" or a challenge to how you teach reading | Low. No source documents a stress format, and the loop is one building panel of teachers | Pause, restate, hold through two follow-ups, concede specifically, never fold on the core |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What do you expect to be different about fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade and I've never been a team lead" | Start with the plain words: "I haven't taught fourth grade." Then the fact, in the quote's terms: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: say what you expect to differ only if you actually know, in your own words; if you do not know yet, say so plainly and say what you would ask the team in your first weeks, and why. Do not state what fourth grade requires; this pack has not researched it | F2 states the gap and F3 the adjacent grade. JD because it scores the position the invite names; the step between grades is the first thing a panel for this seat tests |
| A2 | "You haven't taught fourth grade. Why should we take that on?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead"; "Six years teaching third grade at a public elementary school in Joliet"; "Elementary Education (grades 1–6) endorsement" | The highest-ROI rehearsal in this pack. Concede first, in the words your message gives you: "I haven't taught fourth grade." Then hold only what your quotes carry: "Six years teaching third grade at a public elementary school in Joliet" and "Elementary Education (grades 1–6) endorsement." Then a plan, said as a plan: what you would find out first and from whom, in your own words. Follow-up 1, what worries you: name one thing you do not know yet, plainly. Follow-up 2, someone who has taught it: do not argue you are equal; say what you offer from the quotes and let them weigh it. Follow-up 3, what if you struggled: say how you would ask for help, as a plan. Never say third grade prepared you or that the step is small; that is the inference they test | This objection will arrive in some form from every seat at the panel, because F2 is your own statement of it and the seat is fourth grade. JD because it scores the position itself; the limit is named before it is asked for |
| A3 | "You led your grade level's move to a new reading curriculum, and you haven't been a team lead. What did leading look like?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never taught fourth grade and I've never been a team lead" | Words: "I led our grade level's move to a new reading curriculum in 2024." If the title comes up: "I haven't been a team lead." Answer slot: say in your own words what leading the move involved and which part was yours; if it was shared, directed by others, or not what the word "led" suggests, say so plainly and stay with your part. Keep the quote's scope, the grade level; do not widen it to the school or the district | F7 puts the two sentences side by side, which is where a probe lands. EXP because it tests attribution |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead" | Selection scaffold: choose one limit you can name without bluffing. The stated one is already in your words, "I haven't taught fourth grade," and it costs nothing to say. If a different limit is truer for you, take it, and say what you would do about it in the first month, as a plan. If no honest weakness comes to mind, say so plainly and name where you would most want the team's help | A Skeptic stem; F2, F8 and F9 hold the likeliest honest answers. JD because it scores readiness against the role |
| A5 | "We need an Illinois Professional Educator License with an elementary endorsement. Where does yours stand?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the quote's own terms, word for word, and stop. Have the licence record to hand before Thursday in case you are asked for it | F1 is the one gate in the invite. JD because it is a stated requirement; short and closed, so the risk is rambling |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "If two of us disagreed with you about how to pace a unit, what would you do?" | CASE | [generic] | A live problem, so no past is claimed. Structure it: what you would ask first, whose view carries what, how you would test the disagreement, who decides, and what you would concede. Offer seam principles, not a pretended seam: say you would ask how the team plans and decides before proposing how you fit in | A Peer Evaluator stem turned into a decision; F7 is the requirement it scores. CASE because it is a live problem with JD content |
| B2 | "What would you bring to our team?" | JD | [grounded] "I write a weekly email to families"; "I've run the after-school reading club for the last two years" | Reciprocity, in your own words: "I write a weekly email to families," and "I've run the after-school reading club for the last two years." Offer them as what you do, not as results; your material states none. Then turn it around: ask what the team already does with families and where a newcomer's time would help most | F5 and F4 supply the quotes; peers price what a hire adds to their own load. JD because it scores the work-with-the-team requirement, F7 |
| B3 | "Tell me about a time you worked through a disagreement with a teaching colleague." | VAL | [generic] "I led our grade level's move to a new reading curriculum in 2024" | No sentence of yours carries a disagreement, so this is the scaffold case. Pick a real instance: a named stake, what you said, what changed, a working relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I led our grade level's move to a new reading curriculum in 2024," at its own scope, or how you would handle one. Do not present that move as a disagreement story unless there was one | A Peer Evaluator theme from the disagreement stem; F7 is the requirement. VAL because it scores behavior with equals |
| B4 | "Walk us through the routines that run your classroom day." | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: the district page lists classroom routines among panel topics, so describe the routines you actually run, in your own words, as a sequence and a reason for each. If you did not run set routines, or they were set by others, say so plainly, say what you would put in place first, and return to the six years you can quote. Supply no routine you do not run | F9 is silence in your material, so this is the question that fills it honestly. JD because routines are a stated panel topic and a typical listing line |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader is reading well below the rest of the class in the first month. What do you want to know, and what do you do?" | CASE | [generic] | A live problem. Clarify first: what was seen, how it was measured, since when, what the family says. Then the objective, your approach, how you would know it is working, and the risks, thinking aloud. The district's published lines, "Every Child a Reader" and "assessments inform teaching and never replace it" (Sources), are fair vocabulary if they fit. Challenge one premise respectfully, such as what "well below" is measured against | Reading instruction is a documented panel topic and the principal's background is in reading. F4 and F8 are the rows it touches. CASE because it is a live problem from the role |
| C2 | "The board has adopted a three-year literacy plan, with a new grades 3–5 reading curriculum from fall 2027. How would you want to be part of that on this team?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you read it: the August 2026 plan names structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term (Sources). Then stay with your own words: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say what from that move you would want to use again and what you would do differently, in your own words; if you cannot say, or the move was largely set by others, say so plainly and stay with your part. Ask what the team has already decided before proposing anything. Do not claim your 2024 move resembles the district's | The plan is the one current strategy fact found. F4 and F7 are the evidence. CO because it scores knowledge of the district's direction |
| C3 | "A parent writes twice a week, worried about their child's reading. How do you respond?" | CASE | [grounded] | A live problem, so no past is claimed. Acknowledge the worry, ask what they are seeing, share what you know and do not know, agree a next step and a channel, set a cadence, and say when you would bring in the team or the principal. The district's published line is that each teacher speaks with every family each term (Sources); a good answer fits inside it | F5 and F6 are the rows this touches, and families is a documented panel topic. CASE because it is a live problem with a published standard behind it |

### D. Values/Behavioral

These are themed on the district's three published beliefs. No values round is documented, so there is no values cheat sheet; the beliefs raise the themes.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader is one of our beliefs. Tell me about a time you worked to get a student reading." | VAL | [grounded] "I've run the after-school reading club for the last two years" | No sentence of yours carries a story about one child, so this is the scaffold case. Pick a real moment: a named stake, what you did, what you could not fix, how it ended. Use "I" for what you did and "we" for context. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I've run the after-school reading club for the last two years," at its own scope, or how you would approach it | F4 is the row for this belief and it stops short of a child-level story. VAL because it scores behavior against a published belief |
| D2 | "Families Are Partners is one of our beliefs. Tell me about a time you worked with a family to help a child." | VAL | [grounded] "I write a weekly email to families" | Scaffold: pick a real instance with a named stake, what you said, what the family said, what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I write a weekly email to families," at its own scope, or how you would approach it. Do not describe replies or conversations your material does not state | F6 is the row for this belief and the email is a different kind of contact. VAL because it scores behavior against a published belief |
| D3 | "Tell me about a time assessment results and your own read of a student did not line up." | VAL | [grounded] | Scaffold: pick a real instance: what the result said, what you saw, what you did, what you would do again. If no such time comes to mind, say so plainly and say how you would weigh the two, using the district's own line that assessments inform teaching and never replace it (Sources) only if it fits what you believe | F8 is silence in your material, and this belief is its raising source. VAL because it scores judgment against a published belief |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You led your grade level's move to a new reading curriculum in 2024. Which part of that was yours?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold the quote at its scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: name which parts were yours, in your own words; if any were shared, decided elsewhere, or not yours, say so plainly. Expect two follow-ups, each one level deeper on the same part. Stay with the part you name and add nothing | F4 and F7 both rest on this one sentence, so it takes the most scrutiny. EXP because it tests attribution |
| E2 | "How do you use assessment results to decide what a student needs next?" | JD | [inferred] | Answer slot: the listing and the district's belief both raise this. If you use assessment results in your planning, say which results and what you changed, in your own words; if you do not, or that was set by others, say so plainly and say how you would approach it. Supply no tool, score or process you do not use | F8 is silence in your material. JD because it scores a typical listing line, with the district's belief behind it |
| E3 | "Which subjects did you plan and teach in third grade, and which would be new to you here?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Words: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: name the subjects you planned and taught, in your own words; if you taught only some, or others taught them, say so plainly. For "new to you", name what you honestly do not know yet, as a plan and not a past | F3 is the row; the subject line is typical of listings and not this district's own words. JD because it scores a requirement |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk us through the journey: how did you get here?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc, one sentence per beat, each in the quote's own words: the six years, the move in 2024, the club, the weekly email. Then the reason for this seat. Answer slot: your reason for fourth grade and for Halvering is yours to give; if there is no particular reason beyond wanting the change, say so plainly. Add no transition that claims a motive or a result | F3, F4, F5 and F7 carry the beats. EXP because it is the CV walk, delivered casually and still scored |
| G2 | "Anything you've been trying lately in how you teach reading?" | JD | [grounded] "I've run the after-school reading club for the last two years" | A casual question about the role's hottest topic, and still scored. Name one thing you actually do. If nothing new comes to mind, say so plainly and talk about what you do run: "I've run the after-school reading club for the last two years." Answer slot: the principal's published talk is on weekly reading conferences in grades 3 to 5 (Sources), so a probe on conferences is possible. If you hold reading conferences with students, say how and which part was yours; if you do not, say so plainly and stay with what you do | F4 is the row, and the interviewer read is the reason for the slot. JD because reading instruction is a documented panel topic |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a candidate who has taught fourth grade?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead"; "Six years teaching third grade at a public elementary school in Joliet"; "Elementary Education (grades 1–6) endorsement" | Pause and restate the question. Concede first: "I haven't taught fourth grade." Do not claim to be better than someone you have not met. Hold what the quotes carry: "Six years teaching third grade at a public elementary school in Joliet" and "Elementary Education (grades 1–6) endorsement," then stop. Hold through two follow-ups by returning to those quotes, never by adding to them | A2 is the same objection at pressure speed; F2 is the source. JD because it scores the position |
| H2 | "Suppose I told you the way you teach reading is out of date. Respond." | CASE | [generic] | A live challenge, so no past is claimed. Pause, restate, and ask what she means by out of date. Hold a position only as far as you can back it, concede one specific thing you would want to learn, and do not fold on the core just to restore harmony. Say what you would want to look at together | Low-weight Pressure persona; the principal's reading background makes reading the likeliest pressure topic. CASE because it is a live challenge |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Your forum talk was on weekly reading conferences in grades 3 to 5. How does reading-conference time fit a fourth-grade week at Halvering, if it does?" | Tied to the principal's published talk, so it shows you read her and not only the district; the "if it does" assumes nothing about the school |
| 2 | "The board adopted a plan with a new grades 3–5 reading curriculum from fall 2027. What, if anything, is the fourth-grade team doing to get ready?" | Shows you read the plan, and invites the team to tell you where a new teacher would fit |
| 3 | "What could a new fourth-grade teacher do in their first month that would genuinely help your team?" | The reciprocity question for the two peers; it asks what you can give before what you need |
| 4 | "When does the team plan together, and what gets decided there?" | Clarifies the seam your B1 and B3 answers rest on, and shows you expect to work as a team |
| 5 | "The district says each teacher speaks with every family each term. How do teams here make that work in practice?" | Uses the published belief and asks about implementation, which a prepared candidate can; it signals the family belief is one you take seriously |
| 6 | "What would a strong first year look like in this seat, and how would you want me to know early if I was off track?" | Meets the grade-level gap head on and invites feedback, which is the answer to A2's follow-up 3 in advance |

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | The plain acknowledgment: "I haven't taught fourth grade." No slot |
| Has been a team lead | A negative you stated, F2 and F7 | The plain acknowledgment: "I haven't been a team lead," with F7's quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024" |
| Led the school's or the district's reading curriculum change | Inflated form of F4 and F7 | The quote at its own scope: the grade level. The limit is the pack's observation: your material says grade level, not school or district |
| Writes a reading plan for each student | Inflated form of F4 | F4's quotes at their own scope. The limit is the pack's observation: your material says the move and the club, not individual reading plans. E1 and A3 stay inside the move |
| Speaks with every family each term | Inflated form of F6 | F6's quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says the email, not conversations with each family |
| The curriculum move or the reading club improved student reading | Inflated form of F4: an outcome no quote states | The quotes at their own scope. The limit is the pack's observation: your material states no result, and the pack supplies none |

## Sources

Provided documents: the interview invite, pasted; your CV text, pasted.

Searches sent, by query:

- "Orrinsford Community School District values mission" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District teacher interview process panel" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan (search snippet only, dated August 2026)
- "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren (search snippet only)
- "Fourth Grade Teacher Illinois elementary school job description responsibilities qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher (search snippet only; its qualifications line was cut off, so nothing is taken from it)

Pages fetched: the Mission and Beliefs page and the How we hire teachers page, both above.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford values` | yes | Three beliefs by name; they raise F4, F6, F8 and bank D. No values-style round is documented, so there is no values cheat sheet |
| 2. `Orrinsford interview process teacher` | yes | Loop established: one 45-minute building panel, the principal and two grade-level teachers, topics reading instruction, classroom routines and families. Persona weights follow it; F9 and B4 follow its topics |
| 3. `Orrinsford strategy` / recent news | yes | The August 2026 literacy plan feeds C2 and reverse question 2 |
| 4. `Dolores Vantongeren Halvering` | yes | Career pattern and published talk feed the interviewer read, G2 and reverse question 1 |
| 5. representative `Fourth Grade Teacher` JD | yes | Supplies the typical-listing requirements in F3, F5, F7, F8 and F9, all `[inferred]` |

## Upgrade menu

- The full posting text → F3, F5, F7, F8 and F9 change from `[inferred]` to `[grounded]`, and any requirement the typical listing's cut-off qualifications line held becomes visible
- Your answers to the answer slots in F3, F4, F6, F7, F8 and F9 → those rows move from discovery or transferability to quoted evidence, and the matching banks regenerate
- A sample of your weekly family email, or your active licence record as the state issues it → F5 and F1 evidence moves from a CV line to an inspectable artifact, and confidence can rise
- The two team members' names and roles, from HR → a real interviewer read for them and a tuned persona split
- The date behind "Thursday" → the invite gives only the weekday, so triage assumes two days from 24 November; 26 November is US Thanksgiving, so confirm the date with HR
- Deeper research, offered once: up to 6 more searches and 2 more fetches, several more minutes, adding a district strategy brief, deeper footprint, role-family loop reports and recent organisational context → a grounding section and sharper CO questions
- A tuesday-dossier.md from an earlier evidence review → verified claims, a prohibited-claims list from the underwriter and a named highest-ROI objection, in place of the ones this pack inferred
