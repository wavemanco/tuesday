I've read the interview-pack spec, and I'm now running the district research searches. Then I'll build your prep pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/e23/part-3/rooms/case-9-canned-a32c136c/halvering-elementary_fourth-grade-teacher_interview_pack.md`. I built it for the panel in your invite: Principal Vantongeren and two fourth-grade teachers. It has 20 questions, a fit table, notes on the principal's background, reverse questions, and the claims it won't coach. You gave me no posting from the school, so the role requirements come from a typical fourth-grade posting I found. They are labeled `[inferred]` in the file.

The pack's highest-ROI prep is A1, which is your never having taught fourth grade. Your license meets the invite's requirement, so I treated it as met and asked nothing more about it.

Your message included a Social Security number. I didn't use it, and interview prep doesn't need it, so I'd remove it from anything you send to an employer. I also left your license ID number out of the pack.

Say the word and I'll play the Skeptic on A1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you have the school's posting text, and did HR mention anything to bring or prepare, such as a sample lesson or a writing sample?
2. Do you know the names or roles of the two fourth-grade teachers, and is one of them the team lead?
3. Would you like a deeper research pass on the district (up to 6 more searches and 2 more fetches, several more minutes)?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

- **Role:** Fourth Grade Teacher, Halvering Elementary School, Orrinsford Community School District
- **Round:** one 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not known)
- **Prepared for:** Grace
- **Version:** first pass. Built from the HR invite, your CV text, and a district research pass at L1 (Sources). No posting from this school was supplied, so JD rows come from a typical fourth-grade posting and are labeled `[inferred]`.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each question has an ID by persona (A, B, C, D, E, G). The letter F is skipped so that fit rows F1 to F10 stay unambiguous.
- **Type key:** VAL = behavioral or values alignment; EXP = deep-dive on your own experience; JD = the role's stated requirements; CO = knowledge of the district and its direction; CASE = a live problem set in the role.
- **Guidance is scaffolding, not a script.** Every claim about your past rests on a sentence of yours quoted beside it. Where the pack could not honestly say more, it leaves an answer slot: say what is true, in your own words, or say plainly it was not so.
- The single highest-ROI rehearsal in this pack is **A1**.

## Prep triage (about two days, Tuesday to Thursday)

| Order | Do this | Tied to |
|---|---|---|
| 1 | Say A1 aloud three times, with a friend or a recording playing two follow-ups. Hold, then concede one specific thing | A1, A2, F2 |
| 2 | Build your 90-second arc from your own three sentences, and work out which parts of the curriculum move were yours and which were the team's | E1, B2, F10 |
| 3 | Write one honest line for each answer slot: assessment results, routines, subjects, contact with families | A3, A4, G1, D2 |
| 4 | Read the district's beliefs page and literacy-plan page yourself, not only the excerpts here | C2, D1, D2, D3 |
| 5 | Pick three reverse questions and say them aloud | R1, R2, R3 |

Everything else is insurance.

## Fit snapshot

Quotes in the evidence column are yours, exactly as given. Gap types follow the routing rule: a stated absence is `capability`, silence is `discovery`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — HR invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate, and your material shows it met. It is a CV line with nothing inspected behind it, so expect to be asked for the record. Say it in the line's own terms: the license, the endorsement and the registration date. Your material places the endorsement at grades 1 to 6, which includes fourth grade. The pack asks nothing more here |
| F2 | "Fourth Grade Teacher position" — HR invite | "I've never taught fourth grade and I've never been a team lead." — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never taught fourth grade." Then how you would learn it, said as a plan and never as a past; A1 rehearses exactly that. Nothing added to make the gap feel smaller |
| F3 | "experience in grades 3 to 5 preferred" — typical posting, K12 Jobs Board listing (fetched) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | No gap on this typical-for-the-role line: your quote already names third grade, which sits inside grades 3 to 5. Lead with the quote's own terms and stop there. The next question will be fourth grade itself (A1) |
| F4 | "plan and teach reading, writing, math, science and social studies" — typical posting, K12 Jobs Board listing (fetched) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | Your quote says third grade, not which subjects. Answer slot: say which of those subjects you taught, in your own words; if you taught a different mix, or others taught some, say so plainly and stay with the six years of third grade |
| F5 | "no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs page, Every Child a Reader (fetched) | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | Your quotes carry third grade, a reading-curriculum move and a reading club; they do not say what happened to individual students' reading. Words stay at that scope. Answer slot: the belief makes a probe on students' reading plans likely. If students in your room had reading plans, say who made them and how, in your own words; if there were none, or others made them, say so plainly and describe the club and the move as your sentences state them |
| F6 | "differentiate instruction using assessment data" — typical posting, K12 Jobs Board listing (fetched) | none given | none | [inferred] | discovery | Your material says nothing on this, and silence is not an admission. Answer slot: if you used assessment results to change what or how you taught, say which results and what changed, in your own words; if you did not, or the use was set by others, say so plainly and say what you would look at first in a fourth-grade class |
| F7 | "keep clear classroom routines" — typical posting, K12 Jobs Board listing (fetched) | none given | none | [inferred] | discovery | Your material says nothing on this. Answer slot: if you set up routines in your classroom, say which and how students learned them, in your own words; if the school set them, or you ran none you would call routines, say so plainly and name the first one you would put in place in fourth grade |
| F8 | "communicate regularly with families" — typical posting, K12 Jobs Board listing (fetched) | "I write a weekly email to families." — your CV | medium | [inferred] | none | Your quote already reaches it: weekly, written, to families. Lead with it in those terms. Do not widen it to conversations or partnership, which the sentence does not say; expect a probe on what goes in it (E3) |
| F9 | "each teacher speaks with every family each term" — Orrinsford Mission and Beliefs page, Families Are Partners (fetched) | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | The quote is written contact on a weekly rhythm; the belief is spoken contact each term. Words stay at the quote's scope. Answer slot: if there was any contact with a family beyond the weekly email, say what it was and how it went, in your own words; if there was none, or someone else handled it, say so plainly and stay with the weekly email |
| F10 | "work with the grade-level team" — typical posting, K12 Jobs Board listing (fetched) | "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." — your CV; "I've never taught fourth grade and I've never been a team lead." — your CV | medium | [inferred] | presentation | The first quote already reaches team work in other terms: you led your grade level's move. Reword nothing beyond it, and keep it apart from any team-lead claim, which your own second sentence denies: "I've never been a team lead." Expect a probe on which parts were yours and which were the team's (B2) |

## Reading the interviewer

Public professional footprint only. Nothing is known about the two fourth-grade teachers.

| Signal | What the source says | Practical implication | Provenance |
|---|---|---|---|
| Career path | Principal of Halvering Elementary since 2022, after nine years as a reading specialist (Sources row 4) | Expect reading instruction to be heard with a specialist's ear: C3, D1 and E2 are the likeliest places. Answer from what you did, in your own words | [grounded] |
| Published talk | A 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5 (Sources row 4) | Have your own view, as a plan, of where individual reading time would sit in a fourth-grade week (C3). Do not claim a practice your sentences do not state | [grounded] |
| Mirror opportunity: shared vocabulary | Reading is the shared subject of her path and your CV line: "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." (F5) | Use the sentence as it stands and let her draw any link; do not tell her it proves anything. This is a shared subject, not a shared career jump | [grounded] |

## Persona table

The loop is one 45-minute building panel of the principal and two grade-level teachers (Sources row 2), matching your invite. Weights blend the top two personas of each seat: principal as hiring manager (Case/Strategist and Skeptic), the two teachers as peers (Peer Evaluator and Data-Driven Prober), then adjust for the signals below.

| Persona (questions) | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic (5) | Quiet probing of fourth grade, team leadership, and the topics your material is silent on | Highest. You stated both limits yourself (F2), the hiring-manager seat carries this prior, and the principal's reading background makes thin spots easy to hear | Rehearse A1 until it is boring; plain acknowledgment from your own sentence plus a ramp plan; never bluff a competency |
| B. Peer Evaluator (4) | Two grade-level teachers asking what a new colleague takes from them and gives back, and how you share credit | High. Peer prior; F10 is the evidence they will test | Reciprocity framing; propose working principles rather than pretending to know their seams |
| C. Case/Strategist (3) | Live problems in reading instruction, and the district's direction | Medium. The careers page result says panels ask about reading instruction, classroom routines and families (Sources row 2); the principal's path points to reading | Clarify, then objective, approach, how you would know it is working, risks; think aloud |
| D. Values/Behavioral (3) | Stories mapped to the district's three published beliefs | Medium. The beliefs page says the beliefs guide every hire (Sources row 1). No values-style round is detected, because the loop source names none, so there is no cheat sheet; the beliefs still theme D1 to D3 | Choose a story per belief only where your sentences carry one; otherwise use the scaffold and its honest branch |
| E. Conversational (3) | The opening "walk me through your journey" and casual follow-ups | Medium. Panels open this way, and casual questions are still scored | A 90-second arc built only from your own sentences |
| G. Data-Driven Prober (2) | Line-by-line questions on your CV | Low to medium. Peer prior, but your CV states no figures beyond durations, so the probing is about subjects and how the move was judged | Know what you can and cannot say about each line; say plainly when you do not know |
| Pressure | Interruptions and devil's advocate | Low. Nothing in the sources points to a stress format, so no bank; A1's hold-then-concede covers it if it appears | Pause, restate, hold through two follow-ups |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your experience is in third grade, and you haven't taught fourth. What don't you know yet about teaching fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I've never taught fourth grade and I've never been a team lead." | The highest-ROI rehearsal in this pack. Open with the plain words of your own sentence: "I've never taught fourth grade." Then your experience at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Do not argue that it carries over; state it and let them draw the inference. Then a ramp plan, said as a plan and never as a past: choose the two things you would ask the fourth-grade team first, in your own words; if nothing comes to mind, say so plainly and say how you would find out. Follow-up one, on how you know third grade carries over: return to the six years and add nothing. Follow-up two, on what if it does not: concede one specific thing you do not yet know, without retracting the six years | F2 is the biggest gap in the snapshot and F3 is the evidence beside it, so this question will arrive in some form; JD because it scores the posted grade level |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." | Choose the one that is true for you, not the one that sounds safest. Your own sentence names two limits, and either is an honest answer: say it plainly, then say how you would close it as a plan. If something else is your real weakest area, say that instead. Hold through two follow-ups, then concede specifically | Persona stem for the Skeptic; JD because the question is scored against the posted duties (F2, F10) |
| A3 | "How have you used assessment results to plan for different learners in your class?" | JD | [inferred] | Answer slot: if you used assessment results to change what you taught or how you taught it, say which results and what changed, in your own words; if you did not, or the use was set by others, or there was no such step, say so plainly and say what you would look at first in a fourth-grade class. Then you may close on the district's published belief, "assessments inform teaching and never replace it", as the stance you would bring, which is a stance and not a claim about your past | F6 is silence in your material; the typical posting and the district's belief both raise the topic, so the probe is likely; `[inferred]` because the question's premise comes from a typical posting |
| A4 | "What routines do you put in place with a new class, and how do students learn them?" | JD | [inferred] | Answer slot: if you set up routines in your classroom, say which and how students learned them, in your own words; if the school set them, or you ran none you would call routines, say so plainly and name the first one you would put in place in fourth grade | F7 is silence in your material and the careers page result lists routines among panel topics (Sources row 2); `[inferred]` as for A3 |
| A5 | "Why this school, why fourth grade, and why now?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Your reasons are yours; the pack cannot supply them. Pick one reason about this school that you could say without notes, for example something you read in the district's three beliefs (Sources row 1), and one reason about fourth grade that is genuinely yours. If no reason about fourth grade comes to mind, say so plainly and say what you would want to find out first. Keep claims about your experience to your own sentence | The Skeptic's motivation-consistency probe; JD because it scores fit with the posted role |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you want from our team in your first month, and what could you offer us?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead."; "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Ask first, then offer. The ask can start plainly: "I've never taught fourth grade", then the two or three things you would want to learn from them, as a plan. The offer uses only your own sentence: say that you led your grade level's move to a new reading curriculum in 2024 and have run the after-school reading club for two years, then ask what from that would be useful to them. Offer it; do not assert that it will help | Reciprocity is what a peer panel is pricing (F10); JD because it scores the team requirement |
| B2 | "Tell me about how your grade level moved to the new reading curriculum. What was your part, and what was the team's?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Story-mapped on the sentence: your grade level, a move to a new reading curriculum, 2024, and you led it. Tell those beats in your own words. Answer slot: expect a probe on which parts of the move were yours and which were the team's. Say which, in your own words; if you cannot separate them, or someone else set them, say so plainly and return to "I led our grade level's move to a new reading curriculum in 2024." Hold through two follow-ups by returning to the sentence, never by adding to it | F10 is where the peer seat will test attribution; EXP because it checks what was actually yours |
| B3 | "Tell me about a time you disagreed with a colleague about how to teach something." | VAL | [generic] | Selection scaffold: pick a disagreement with a grade-level colleague that has a specific difference, a way you raised it, and a working relationship intact afterward. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer stem on disagreement; VAL as behavioral rather than tied to a published belief, and `[generic]` because it is a pattern, not a fact about this school |
| B4 | "A new fourth-grade teacher and an existing team will sometimes see things differently. How would you want us to handle that?" | JD | [generic] | Propose working principles rather than pretending to know the team's seams: ask how things are done before suggesting changes; bring ideas as questions; agree who decides what. These are plans, not a past. Add what you would want from them in return | The seam probe in a peer register; JD because it scores the team requirement (F10) |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It's October and a student arrives in your fourth-grade class reading well below the others. Walk me through your first two weeks." | CASE | [grounded] | Clarify before answering: what does the student's record say, and is there a reading plan, since the district publishes that no student leaves third grade without one (Sources row 1). Then the objective, a two-week approach, what you would look at to tell whether it is working, and the risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem in reading, the topic the careers page result and the principal's path both point to (F5); CASE because it scores structure |
| C2 | "The board adopted a literacy plan this August. What do you make of a new reading curriculum for grades 3 to 5 arriving in fall 2027?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Know the plan's three parts as the news result gives them: structured phonics from kindergarten to second grade, a new grades 3 to 5 reading curriculum from fall 2027, and a family reading night at every school each term (Sources row 3). Give a view, said as a view, on what a grades 3 to 5 change means for how fourth grade plans. If you have not read beyond this, say plainly you do not know which curriculum was chosen. If you mention your own move, use only your sentence and let the panel draw any link | The differentiator question: current strategy, from research under six months old; the pack has only the result text, so read the page itself before Thursday |
| C3 | "Sketch how you would plan reading for the first month of fourth grade. What do you need to know first?" | CASE | [generic] | Clarify first: the students' recent reading information, the curriculum in use, the time available. Then your objective, a plan for whole-group and individual reading time, how you would see progress, and risks. Think aloud. The question asks about no past, so the guidance claims none | F4's reading half, posed as a live problem the principal's reading background makes likely (Reading the interviewer) |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader is one of our three beliefs. Tell me about a time a student's reading did not move the way you expected, and what you did next." | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Your sentence carries a curriculum move and a reading club, not a student's story, so choose the story yourself: one student, what you saw, the one thing you changed, what you could say afterward. "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the reading club as your sentence states it, or say how you would handle it | The first published belief (F5); VAL because it scores past behavior against a named belief |
| D2 | "Families Are Partners is another of our beliefs. Tell me how you have worked with a family on a student's learning." | VAL | [grounded] "I write a weekly email to families." | Story-mapped on the sentence: weekly, an email, to families. Say it in those terms. Answer slot: the belief is about contact between teacher and family, so expect a probe on more than the email. If there was any contact with a family beyond the weekly email, say what it was and how it went, in your own words; if there was none, or someone else handled it, say so plainly and stay with the weekly email | F9 is where your sentence and the belief differ; VAL because the belief is the published standard |
| D3 | "Teach for Tomorrow, Not for the Test is the third belief. Tell me about a time you taught something that was not going to be on any test." | VAL | [grounded] | Selection scaffold: pick a lesson or unit where the purpose was beyond a test; say why you chose it, what students did, and what you saw. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would balance it. Link to the belief's own wording, that assessments inform teaching and never replace it, as a stance only | The third published belief; no sentence of yours carries it, so this is a scaffold |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your journey to this point." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years."; "I write a weekly email to families." | A 90-second arc of your own three sentences in order: six years teaching third grade at a public elementary school in Joliet; leading your grade level's move to a new reading curriculum in 2024 and running the after-school reading club for two years; the weekly email to families. Then your own reason for fourth grade, which only you can supply; if none comes to mind, say so plainly and say what you would want to find out first | The conversational opener is scored; the arc is built so every clause traces to your sentences |
| E2 | "Tell me about the reading club." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | The beats your sentence states: after school, a reading club, run by you, for two years. Tell it in your own words and stay with what the sentence states. If you do not remember a detail, say so plainly | Casual question, scored; the principal's reading background makes it likely (Reading the interviewer) |
| E3 | "You write a weekly email to families. What goes in it?" | JD | [grounded] "I write a weekly email to families." | The beats your sentence states: weekly, an email, to families. Say what goes in it as it actually is, in your own words, and if the contents vary, say that. Do not call it family engagement or two-way communication; your sentence does not use those words | F8's likeliest probe; JD because it scores the family-communication requirement |

### G. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Which subjects did you teach in your six years of third grade?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: the typical posting lists reading, writing, math, science and social studies. Say which of those you taught, in your own words; if you taught a different mix, or others taught some, say so plainly and return to "Six years teaching third grade at a public elementary school in Joliet." | F4 is the only row about the full subject range; `[inferred]` because the list comes from a typical posting |
| G2 | "What did your grade level look at to see how the new curriculum was going?" | EXP | [inferred] "I led our grade level's move to a new reading curriculum in 2024, and I've run the after-school reading club for the last two years." | Answer slot: the posting and the district's belief both raise assessment results, so expect this probe. If you looked at assessment results, say which and what you saw, and which part of that was yours; if nothing was looked at, or it was not yours to look at, say so plainly and return to "I led our grade level's move to a new reading curriculum in 2024." | F6 and F10 meet here; EXP because it checks what was done after the move |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 license gate | none, and why: your material shows the gate met, so the pack asks nothing; bring your license record |
| F2 fourth grade, never taught | A1, A2, A5 |
| F3 grades 3 to 5 experience preferred | A1, A2 |
| F4 plan and teach the subjects | G1, C3 |
| F5 reading plans, Every Child a Reader | C1, D1 |
| F6 differentiate using assessment data | A3, G2 |
| F7 classroom routines | A4 |
| F8 communicate regularly with families | E3, D2 |
| F9 speaking with families, Families Are Partners | D2 |
| F10 work with the grade-level team | B1, B2, B3, B4 |
| Teach for Tomorrow, Not for the Test | D3 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You were a reading specialist for nine years before becoming principal. What from that work shows up most in how Halvering teaches reading today?" | Tied to the principal's own path; it turns the panel into a conversation about her work | [grounded] |
| R2 | "The board's literacy plan brings a new grades 3 to 5 reading curriculum in fall 2027. What does fourth grade do between now and then?" | Shows you read the plan, and it asks for the present, which only they can answer | [grounded] |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the two teachers: it asks what you can give, not only what you need | [generic] |
| R4 | "What does a strong first year look like for someone new to fourth grade here?" | Hands them the chance to define success and tells you the real bar | [generic] |
| R5 | "How do third-grade reading plans reach fourth-grade teachers, and what do you do with them?" | Built on the district's published belief; it links the grade you know to the grade you want | [grounded] |
| R6 | "Families Are Partners says each teacher speaks with every family each term. What has worked best for fourth-grade teachers?" | You hear what the belief looks like in practice before you are asked about it | [grounded] |

## Prohibited claims

What this pack will not coach, and why. The honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated (F2) | "I've never taught fourth grade," with F3's quote at its own scope. No answer slot |
| Has been a team lead | A negative you stated (F2, F10) | "I've never been a team lead," with F10's first quote at its own scope: you led your grade level's move. No answer slot |
| Chose the new curriculum or ran how it was rolled out | Inflated form of F10's quote | The quote at its own scope. The limit is the pack's observation: your material says you led the move, not what it involved. B2 and G2 stay inside the move: which parts were yours |
| The reading club raised students' reading results | Inflated form of F5's club sentence | The quote at its own scope. Your material says you run the club, not what it did for students. E2 asks only for the club as the sentence states it |
| Speaks with every family each term | Inflated form of F9 | "I write a weekly email to families." Your material says an email, not conversations. D2's slot asks only about contact beyond the email |

## Sources

Provided documents: the HR invite and your CV text, both pasted into your message. No dossier was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | The three published beliefs by name; F5, F9, C1, D1 to D3, R5, R6 |
| 2. `Orrinsford Community School District interview process teacher` | yes | Loop structure: one 45-minute building panel, principal and two grade-level teachers; persona weights and panel topics |
| 3. `Orrinsford Community School District strategic plan news` | yes | The August 2026 literacy plan; C2 and R2 |
| 4. `Dolores Vantongeren Halvering Elementary School principal` | yes | The interviewer read; C3, E2 and R1 |
| 5. representative `Fourth Grade Teacher` JD | yes | F3, F4, F6, F7, F8 and F10 requirements, labeled `[inferred]` |

| # | Query or URL | What came back | Used for |
|---|---|---|---|
| 1 | Search: `Orrinsford Community School District mission values` | https://orrinsfordschools.example/about/mission-and-beliefs | Beliefs: Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test |
| 2 | Search: `Orrinsford Community School District teacher interview process` | https://orrinsfordschools.example/careers/how-we-hire-teachers (result text only, page not fetched) | Panel format and topics; consistent with your invite |
| 3 | Search: `Orrinsford Community School District strategic plan news` | https://orrinsfordschools.example/news/board-adopts-literacy-plan (result text only, page not fetched) | Literacy plan adopted August 2026 |
| 4 | Search: `Dolores Vantongeren Halvering Elementary School principal` | https://ilprincipalsforum.example/speakers/dolores-vantongeren (result text only, page not fetched; one source) | Career path and 2025 talk |
| 5 | Search: `fourth grade teacher job description Illinois elementary school` | https://k12jobsboard.example/listings/fourth-grade-teacher | A typical posting, not this school's |
| 6 | Fetch: https://orrinsfordschools.example/about/mission-and-beliefs | Page text read in full | Belief names and wording |
| 7 | Fetch: https://k12jobsboard.example/listings/fourth-grade-teacher | Page text read in full | Requirement wording for the `[inferred]` rows |

## Upgrade menu

- The posting text for this school, from HR or the district careers site: F3, F4, F6, F7, F8 and F10 move from `[inferred]` to `[grounded]` against the school's own words, and the JD-tagged questions are retuned
- The names and roles of the two fourth-grade teachers: per-member persona weights, and a reverse question tied to each one's path
- Any HR note on the panel (a sample lesson, a writing sample or something to bring): a build section for each declared deliverable
- The two district pages pasted in full (careers and literacy plan): the loop, C2 and R2 rest on the full text, not on result excerpts
- A copy of your license record showing registration status and endorsement: F1 moves from `medium` to `high`
- Your own answers to the answer slots in G1, A3, A4, D2 and B2, stated outside a drill: F4, F6, F7, F9 and F10 take your words as evidence and their bridges are rebuilt
- A `tuesday-dossier.md` from an earlier evaluation of this job would add verified evidence, a named objection and prohibited-claim constraints; this pack stands without one
