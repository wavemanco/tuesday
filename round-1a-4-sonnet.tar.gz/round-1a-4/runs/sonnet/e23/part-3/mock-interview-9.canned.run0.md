I'll read the reference files the skill points to before building the pack.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/e23/part-3/rooms/case-9-canned-2f1b443d/halvering-elementary_fourth-grade-teacher_interview_pack.md`. It has 20 questions across six interviewer styles, a fit snapshot, a reading of the principal, and reverse questions for the panel.

- **Assumption:** the district's hiring page says teacher hiring is one 45-minute panel of the principal and two grade-level teachers, so I built for that. I don't have the two teachers' names.
- **Most likely objection:** you haven't taught fourth grade. Question A1 is the one to rehearse most, and the pack gives you a short follow-up sequence to practice against it.
- **Licence:** your Illinois licence line matches the invite's requirement, so I treated it as met. I haven't looked up the licence record.
- **SSN:** I didn't use it, and it isn't in the pack or in any search. Interview prep doesn't need it, so I'd leave it out of anything you paste here. I also left your IEIN number out of the quoted evidence.
- **Research:** I found the district's three published beliefs, its panel format, the principal's background (nine years as a reading specialist) and the Board's August 2026 literacy plan. I couldn't find this school's own posting, so a few requirement rows rest on a typical fourth-grade posting and are labeled that way.

Say the word and I'll play the skeptical panelist on A1, so you can practice the fourth-grade answer out loud.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Did HR mention anything to prepare for the panel, such as a demo lesson or a writing sample? Can you paste the school's full posting for this job?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**District:** Orrinsford Community School District
**Round:** one 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Built for:** a single panel, because the district's own hiring page describes teacher hiring as one 45-minute building panel (S1)

## 2. How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for your own words, not a script: say only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether the lines in your material survive scrutiny, and what was actually you |
| JD | The stated role and its requirements, including the parts your material is thin on |
| CO | Whether you know the district's current direction, from what it has published |
| CASE | A live problem set in the role, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for you now. Where one asks what you did, either honest branch is a good answer, including "that was not mine" or "there was no such step".

## 4. Fit snapshot

Requirements come from your invite, the district's published beliefs (S2), and a representative posting for the title (S5). The representative posting is not this school's own posting, so rows built on it are `[inferred]`. The licence number on your CV is left out of the quote on purpose; it is not needed for prep.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | No gap: your line uses the requirement's own terms. It is a CV line with nothing inspected behind it, because I have not looked up the licence record. Say it in the quote's terms and have your licence record to hand if asked |
| F2 | "Fourth Grade Teacher position at Halvering Elementary School" — your invite | "I've never taught fourth grade" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would find out what fourth grade asks of you, said as a plan and never as a past. Nothing is added to make the gap feel smaller |
| F3 | "plan and teach reading, writing, math, science and social studies" — representative posting, K12 Jobs Board (S5) | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | Your material says six years of third grade, not which subjects, so the words stay at: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: a posting like this lists five subjects, so expect a probe on which you taught. Say which, in your own words; if some were taught by others, or you did not teach them, say so plainly and stay with what you did teach |
| F4 | "Every Child a Reader: no student leaves third grade without a reading plan." — Orrinsford Mission and Beliefs (S2) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material carries a curriculum move and a club, not individual students' reading plans; that is the pack's observation, not words for you. Words at their own scope: the two quotes. Answer slot: the belief makes a probe on how individual students' reading was followed likely. If following it was part of the move or the club, say how, in your own words; if it was not, or was not yours, say so plainly and stay with the move and the club |
| F5 | "Families Are Partners: each teacher speaks with every family each term." — Orrinsford Mission and Beliefs (S2) | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | Your material says the weekly email; the belief is about teachers speaking with families, which the email does not show. Words at their own scope: "I write a weekly email to families." Answer slot: if your contact with families went beyond the email, say what it was, in your own words; if the email was the whole of it, or the rest was not yours, say so plainly and stay with the email |
| F6 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — Orrinsford Mission and Beliefs (S2) | none given | none | [grounded] | discovery | Your material is silent on assessments, so there is no quote to hold and the words are an answer slot: expect a probe on how test or check results shaped what you taught next. If they did, say how, in your own words; if they did not, or that was set by others, say so plainly and say what you would want to know first |
| F7 | "work with the grade-level team" — representative posting, K12 Jobs Board (S5) | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | presentation | The quote already reaches team work in other terms, so say it as it stands: "I led our grade level's move to a new reading curriculum in 2024." The limit is the pack's observation: the line says what you led, not how the team worked, and you have said you have never been a team lead, so the word stays "led the move", never "led the team" |
| F8 | "keep clear classroom routines" — representative posting, K12 Jobs Board (S5) | none given | none | [inferred] | discovery | Your material is silent on routines, so the words are an answer slot: expect a probe on how you set up and kept routines. If you set them, say how, in your own words; if they were set school-wide or by others, or there is nothing worth naming, say so plainly and say what you would ask first about routines in a fourth-grade room |

Requirement coverage: every row maps to a question below.

| Requirement | Questions |
|---|---|
| F1 licence | none, and why: the gate is shown met by your CV line, and there is nothing to rehearse beyond having the licence record to hand |
| F2 fourth grade | A1, A3, A4, B4 |
| F3 subjects | F2 |
| F4 reading | C2, D1, D2, E1 |
| F5 families | A5, E2 |
| F6 assessments | D3, E3 |
| F7 team | A2, B1, B2, B3 |
| F8 routines | C1 |
| District direction (S4) | A3, C3 |

Your material gives no figures, so there is no defend-the-number question. If a number comes up in the room, say how it was counted or say plainly that you do not know.

## 7. Reading the interviewer

Public professional footprint only, from S3.

| Public fact | Provenance | What it means for prep | Mirror opportunity |
|---|---|---|---|
| Principal of Halvering since 2022, after nine years as a reading specialist (S3) | [grounded] | Expect the reading questions (C2, D1, D2) to go deeper than a generalist panel would; she will know the vocabulary | Reading is the shared ground: "Six years teaching third grade at a public elementary school in Joliet" (F3) is your side of it, and the shared band is third grade, since her talk covered grades 3 to 5 |
| 2025 forum talk "Small Groups, Big Readers" on weekly reading conferences in grades 3 to 5 (S3) | [grounded] | If she raises a specific method, say plainly whether you have used it; do not claim a method because her talk named it | A reverse question on her talk (R1) |

## 8. Persona table

Weights come from three passes: relationship priors, interviewer signals, then the loop. The loop source (S1) establishes one panel of three, so no archetype fallback is used. S1 names the panel's topics as reading instruction, classroom routines and how you work with families. It documents no values-style round, so there is no values cheat sheet in this pack; the district's published beliefs (S2) still theme the VAL questions.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet probing of the fourth-grade gap and the team-lead gap | Highest. The principal's relationship prior is hiring manager, which tilts to Skeptic; you have stated two gaps (F2 and the team-lead negative); both teachers will see the same gaps | Rehearse A1 until it is boring: plain acknowledgment, the quote at its own scope, a plan |
| Peer Evaluator (bank B) | Two grade-level colleagues asking what you would bring and need | High. Two of the three panelists are peers, and the peer prior is Peer Evaluator plus Prober | Reciprocity first: what you bring, then principles for what you need, never pretend knowledge of their seam |
| Case/Strategist (bank C) | Live problems on routines, a struggling reader, and the district's direction | Medium. Hiring-manager prior; S1 lists classroom routines and reading instruction as panel topics | Clarify, then objective, approach, risks; think aloud; ask what is already set |
| Data-Driven Prober (bank D) | Line-by-line questions on the curriculum move, the club and assessments | Medium. Peer prior, and the principal's reading-specialist background (S3) pushes reading probes deeper | Know what you can and cannot say about each line; say plainly when you do not know |
| Values/Behavioral (bank E) | Stories mapped to the district's three beliefs | Medium-low. No dedicated values round is documented (S1), but the district says the beliefs guide every hire (S2) | Use the scaffold; where no story comes to mind, the honest branch is a good answer |
| Conversational (bank F) | The opening journey question and an easy day-in-the-life | Near-certain to open the panel, low weight in depth. It still scores communication economy | Prepare the 90-second arc; treat casual questions as scored |
| Pressure | Interruptions and time-boxing | Not plausible: nothing in S1 or S3 points to it, so no bank | none |

## 9. Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What makes you think you can do this job from week one?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't taught fourth grade." Hold only what the quote carries: "Six years teaching third grade at a public elementary school in Joliet." Then say what you would do to find out what fourth grade asks of you, as a plan: what you would ask these three people first. Hold through two follow-ups by returning to the six years, never by adding to them. Concede specifically that someone who has taught fourth grade already knows what you would be learning. Do not tell them what fourth grade is like | F2 is the most predictable objection in this loop and sits where the material is thinnest; JD because it scores the title, Skeptic because it probes the gap |
| A2 | "You led your grade level's move to a new reading curriculum, but you haven't been a team lead. How did that work?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Say it plainly: "I've never been a team lead." Hold the quote at its scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: say in your own words how the move came to be yours to lead and what that did and did not include; if "led" was less than it sounds, say so plainly and return to the move itself | F7 and your stated negative sit side by side, so a careful panelist will ask; EXP because it tests what was actually yours |
| A3 | "Why fourth grade, why Halvering, and why now?" | CO | [grounded] | Your material says nothing about your reasons, so the reasons are yours in your own words. Build from what is public: the Board's August 2026 three-year literacy plan (S4) and the beliefs on the district's page (S2) are things you can say you read; say which matters to you and why. If no honest reason comes to mind beyond wanting a change, say so plainly and say what you want to learn | The motivation probe follows from F2; CO because the only grounding available is public research |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" | Choose from what your material states: the fourth-grade gap you have named. Say it plainly, then what you would do first, as a plan. Do not invent a weakness, and do not dress a strength as one. If the interviewer raises team leadership, use A2's words | F2 is the honest answer here; JD because it scores fit against the job, Skeptic because it asks you to name your own gap |
| A5 | "Your family communication is a weekly email. Our belief is that each teacher speaks with every family each term. How do you meet that?" | VAL | [grounded] "I write a weekly email to families" | Start from the quote: "I write a weekly email to families." Answer slot: describe the email in your own words, what goes in it and who it reaches; if asked about other contact with families, say plainly what it has and has not been, and stay with what is yours | F5 is the likeliest place for the family belief to press; VAL because it scores a published belief |

Follow-up ladder for A1 (interviewer lines, for rehearsal): "What specifically will be different for you in fourth grade?" Then: "What will you do in your first week to find out?" Then: "Would we be better off with someone who has taught fourth grade?" Hold your position through the first two; on the third, concede the specific point in A1 and return to the six years.

### Bank B: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our fourth-grade team would be your closest colleagues. What would you need from us, and what would you bring?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity first. Bring: "I led our grade level's move to a new reading curriculum in 2024," at that scope. Need: principles, not pretended knowledge of their seam, such as how the team plans and what it expects of someone new to fourth grade. Ask what would help most in the first month | Peers price what a hire adds to their work; F7 is the evidence; JD because it scores the team-work line |
| B2 | "Tell me about a time your grade level disagreed about how to do something, and how it was settled." | VAL | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Pick a specific disagreement: what it was about, what you did, and how things stood afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the move in that quote and nothing added to it, or how you would handle it | The peer persona wraps collaboration in a story prompt; `[inferred]` because the theme comes from the representative posting's team line (F7) |
| B3 | "How do you handle credit when a result belongs to the whole grade level?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | "We" for context, "I" for contribution. Answer slot: say which parts of the move were yours and which were your colleagues', in your own words; if you cannot separate them, say so plainly and return to the quote | Credit-sharing is a standard peer probe and F7's line invites it |
| B4 | "What do you expect to be different about fourth grade, and how will you find out?" | JD | [grounded] "I've never taught fourth grade" | Say plainly "I haven't taught fourth grade," then answer with what you would ask and observe, not claims about what fourth grade is like. These two teachers are the ones who know; ask them | F2 returns in collegial packaging; JD because it scores readiness for the title |

### Bank C: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It is the second week of school. How would you set up routines for a room of fourth graders?" | CASE | [inferred] | Clarify first: what is already set school-wide, and what the team uses. Then objective, approach, how you would check it is working, and one risk. Think aloud. The question asks about no past, and the guidance makes no claim about yours. Answer slot: if you have set up routines before, say how, in your own words; if not, say so plainly and rely on the structure | F8 is silent in your material; `[inferred]` because routines come from the representative posting and the panel topics in S1 |
| C2 | "A student arrives in your fourth-grade room reading well below the class. What do you want to know first, and what do you do?" | CASE | [grounded] | Clarify: what the student can already do, what has been tried, who knows the student's reading best. Then a plan with a first check and a way to adjust. Make no claim about having done this; the structure is the answer. The district's published belief is Every Child a Reader (S2) | The principal's reading background (S3) makes this likely; F4 is where your material is nearest; CASE because it is a live problem |
| C3 | "The Board has adopted a new grades 3–5 reading curriculum, starting fall 2027. How would you approach being part of that change?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say you read that the Board adopted a three-year literacy plan in August 2026 (S4). Say what your quote says and no more: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if anything from that move would shape how you approach a new one, say what, in your own words; if the new curriculum is unfamiliar to you, say so plainly and say what you would ask first | S4 is current district direction and F4's move is your only adjacent line; CO because it tests whether you read what the district published |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you moved your grade level to the new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats the quote states: you led, the grade level's move, a new reading curriculum, 2024. Answer slot: expect probes on what changed in how reading was taught and how anyone knew whether it was working. If you have a view of either, say it in your own words, including which part was yours; if there was no such step, or it was not yours, say so plainly and return to the sentence. If a number comes up, say how it was counted or that you do not know | F4's quote is the line a prober reads first; EXP because it tests attribution |
| D2 | "What happens in your after-school reading club?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | The beats the quote states: you run it, after school, for two years. Describe a session in your own words. Answer slot: if you kept any record of how students' reading went there, say what; if you did not, say so plainly | F4's second quote; EXP because the club is a concrete line to check |
| D3 | "What role do assessment results play in how you plan your next lessons?" | JD | [grounded] | Answer slot: if results shaped your planning, say how in your own words; if they did not, or planning was set by others, say so plainly and say what you would want to know first. The district's published belief is that assessments inform teaching and never replace it (S2) | F6 is silent in your material and the belief is published, so the probe is likely |

### Bank E: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader. Tell me about a time a student was not reading where they needed to be, and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Pick a time with a named stake, what you noticed, what you did and where things stood afterward; no student names. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the club as the quote says it, or how you would handle it | F4 and the published belief (S2); VAL because it scores a belief by a specific decision |
| E2 | "Families Are Partners. Tell me about a time a family helped you teach a child better." | VAL | [grounded] "I write a weekly email to families" | Pick a time with a named stake and a clear result; no family names. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the email as the quote says it, or how you would handle it | F5 and the published belief (S2) |
| E3 | "Teach for Tomorrow, Not for the Test. Tell me about a time you had to decide how much weight a test result should carry." | VAL | [grounded] | Pick a time with a named decision, the options, and what you chose. If no such time comes to mind, say so plainly, then say how you would handle it. No quote in your material speaks to this, so the pack supplies no story | F6; VAL because it scores a published belief |

### Bank F: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey to teaching third grade in Joliet." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | A 90-second arc in this order: the six years in third grade in Joliet, the 2024 move, the club, then why this job (A3). The earlier part of your path is yours to tell, in your own words; the pack adds nothing to it | Casual openers are scored; F3 and F4 supply the beats |
| F2 | "What does an ordinary day in your third-grade classroom look like, from first bell to last?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Describe a real ordinary day in your own words. Answer slot: if you taught all the subjects in the day, say so; if some were taught by others, say so plainly and stay with what you taught | F3 asks which subjects, and a casual register asks it gently |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. What do you look for first in how reading is taught in a fourth-grade room?" | Ties to her own path (S3) and shows you researched her, not just the district |
| R2 | "The Board adopted a new grades 3–5 reading curriculum starting fall 2027. What will that mean for this fourth-grade team?" | Shows you read S4 and invites her view of what is coming |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for the two peers |
| R4 | "For a teacher new to fourth grade, what does support look like in the first semester?" | Turns F2 into a conversation about support rather than a defense |
| R5 | "The district's beliefs say each teacher speaks with every family each term. How does that work in practice here?" | Shows you read S2 and asks about practice, not rhetoric |
| R6 | "What happens after the panel? The district page says references come afterward." | Practical close, grounded in S1 |

## 13. Prohibited claims

Built before the banks from the fit snapshot. None of these is coached, in any cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Has been a team lead | Negative you stated: "I've never been a team lead" | The quote, and the plain acknowledgment: "I've never been a team lead." F7's line stays "led the move" |
| Has taught fourth grade | Negative you stated: "I've never taught fourth grade" | The quote, and the plain acknowledgment: "I haven't taught fourth grade." |
| Led the school's or district's reading curriculum adoption | Inflated form of F4 and F7 | "I led our grade level's move to a new reading curriculum in 2024" at its own scope. The limit is the pack's observation: your material says the grade level's move |
| Speaks with every family each term | Inflated form of F5 | "I write a weekly email to families" at its own scope. The limit is the pack's observation: your material says the email |

## 14. Sources

Provided documents: the interview invite and the resume text you pasted. One personal identifier in your message was not used and is not in this pack.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | The three beliefs by name, used to theme E and several rows (F4, F5, F6) |
| 2. Orrinsford interview process | yes | The loop: one 45-minute panel of three, with its named topics; fixed the persona structure |
| 3. Orrinsford strategy and recent news | yes | The August 2026 literacy plan; fed A3, C3 and R2 |
| 4. Interviewer, Dolores Vantongeren | yes | The interviewer read, R1, and the reading tilt in the persona table |
| 5. Representative Fourth Grade Teacher posting | yes | The `[inferred]` requirement rows F3, F7, F8 |

Queries and results:

- "Orrinsford Community School District mission values": returned S2
- "Orrinsford Community School District teacher interview process panel": returned S1
- "Dolores Vantongeren principal Halvering Elementary School": returned S3
- "Orrinsford Community School District strategic plan news": returned S4
- "Fourth Grade Teacher job posting Illinois elementary school responsibilities qualifications": returned S5, whose snippet ends partway through its qualifications line

Fetches: S2 and S1, read in full.

- S1: https://orrinsfordschools.example/careers/how-we-hire-teachers
- S2: https://orrinsfordschools.example/about/mission-and-beliefs
- S3: https://ilprincipalsforum.example/speakers/dolores-vantongeren
- S4: https://orrinsfordschools.example/news/board-adopts-literacy-plan
- S5: https://k12jobsboard.example/listings/fourth-grade-teacher

## 15. Upgrade menu

- The full posting text for this job → the `[inferred]` rows F3, F7 and F8 become `[grounded]` and the posting's cut-off qualifications line becomes readable
- Anything HR said about preparation, such as a demo lesson or a writing sample → a build section for each declared deliverable
- The names of the two fourth-grade teachers → a peer read for each, if either has a public professional footprint
- Your answers to the slots on F3, F4, F5, F6 and F8 → those rows regenerate with your words quoted, and the matching banks tighten
- Any figures you can stand behind, such as club size or student reading results → defend-the-number questions for D1 and D2
- Your state educator licence record printout → F1 moves from `medium` to `high`
- Your prep time before Thursday → a prioritized schedule built around A1
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the district's literacy plan and recent context; offered once
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and prohibited claims in place of the ones built here; not needed to use this pack
