I'll read the reference files the skill points to before building the pack.
Checking the saved pack for stray bracket notation in prose cells, then fixing it.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-8-canned-afa344d8/ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as three round-by-round mini-packs for 3 December. No interviewer names are assigned, so persona weights come from round type, the recruiter's email and the strategy brief. It has 27 practice questions and reverse questions for each round. Round 3 also has a cheat sheet mapping your stories to the four values.

- **Highest-ROI prep (C1, round 2):** "You haven't worked in a contact centre, and your complaints work was a branch's log. What wouldn't you know on day one?" The pack coaches you to concede exactly, hold what you actually said, and give a plan. Your stated gaps are the contact centre and presenting above regional level. They are conceded in your own words, not bridged.
- **Your answers will be probed here:** what the monthly spreadsheet counted, whether the formal complaints were regulated, whether your tellers' training reached supervisors, and any digital work. The pack gives you "if yes, say how; if no, say so plainly" slots for each. It doesn't invent answers.
- **A possible angle for the panel (my inference, not something they have said):** the branch-to-hub consolidation sits next to "Neighbours, Not Numbers", and you built a spreadsheet of numbers. G3 and H3 rehearse it.
- **Research:** none run, because everything you pasted already fixed what a search would have fed. The upgrade menu lists what would sharpen the pack, mainly interviewer names and the format of the 20-minute case.

Say the word and I'll play the Skeptic on C1, or any other question, as a live drill with feedback against the pack's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Loop mode, three rounds on 3 December 2026** (built 24 November 2026).

| Round | Who | Length | What the recruiter's email says about it |
|---|---|---|---|
| 1 | The recruiter | 30 min | Not described beyond length |
| 2 | Head of Member Services, who would be your manager | 45 min | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | Includes "a 20-minute case on a complaint escalation"; "also the values round — they score against the four values" |

No interviewer names are assigned yet, so there is no interviewer read and persona weights come from round type, the recruiter's own words and the strategy brief. All three rounds fall on the same day, so build one bank of stories and spend each story once: a story told in round 1 is not available for the panel.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Rehearse both.
- **Type key:** VAL is behavioural or values alignment, scored against Ashgrove's published values. EXP is a work-experience deep-dive, where your own words get tested. JD is a question about a stated responsibility or requirement. CO is company and strategy knowledge. CASE is a live problem from the role.
- **Guidance is scaffolding, not a script.** Say it in your own words. Every claim about your past rests on a sentence you wrote, quoted in the Provenance column.
- **An answer slot is an instruction for the interview, not a question for me.** It tells you what to say if a thing is true and what to say if it is not. Both branches are fine; the second is never a confession.
- **The single highest-ROI rehearsal in the pack is C1** (round 2): owning complaints across every branch and the contact centre, from a background that says one branch's log and no contact centre. Spend your first hour there.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's log and a teller script, not a process across branches, and the words stay at that scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: the JD's "end to end" makes a probe on who set the steps of the process likely. If any step was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The sentence says the sheet is monthly and your regional manager uses it; it does not show what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what the sheet counted and how. If it counted either, say which and how, in your own words; if it counted something else, or you do not know how a figure was counted, say so plainly and stay with the sheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The sentence says tellers and the escalation script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD says supervisors, so expect a probe on whether that training reached supervisor level. If it did, say who and how, in your own words; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing on digital work. Answer slot: expect a probe, since the strategy brief puts digital at the centre. If you have worked with any digital or app team, say what and what part was yours; if you have not, say so plainly and say what you would want to find out first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap. Say it in the sentence's own terms: six years in retail banking, the last three as a branch supervisor. It is one line with nothing inspected behind it, so expect a probe on what the supervisor years covered |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | The sentence says formal complaints log; it does not show whether those complaints were regulated, so the words stay at "formal complaints log". Answer slot: expect a probe on which rules or deadlines applied to the complaints you logged. If you know, say which and what part was yours; if you do not know, or none applied, or it was not yours, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented above regional level." Then how you would prepare for a first senior presentation, said as a plan and never as a past. Nothing added about audiences, workshops or training |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Say it as the sentence says it: you built the monthly complaints spreadsheet your regional manager uses. The sentence's word is spreadsheet, and the words stay that way; the interviewer can ask which tool |

## Grounding brief: the 2026 strategy

From the July 2026 strategy brief the recruiter sent you, as you relayed it. This pack has not checked the brief against anything newer.

| Item | Source | Provenance | Where it may surface |
|---|---|---|---|
| "move 40% of member service to digital channels by 2028" | Strategy brief, relayed by you | [grounded] | A7, F1; complaints that start in a failed self-service journey (the pairing with the JD's digital line is this pack's reading) |
| "consolidate eight branches into five hubs over 2027" | Strategy brief, relayed by you | [grounded] | F2, G3, H3; the pairing with the value "Neighbours, Not Numbers" is this pack's derivation, not something any interviewer has said |
| "launch a small-business lending product in Q1 2027" | Strategy brief, relayed by you | [grounded] | Vocabulary only; a new product may bring complaints of a new kind, which is a possible case angle and not a fact |
| "the main competitive pressure is app-only banks" | Strategy brief, relayed by you | [grounded] | A2, A7, F1; the frame for why a failed digital journey matters |

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| Own the member complaints process end to end | B2, C1, E1, H1, I1 | |
| across branches and the contact centre | B1, C1, C2, I1 | |
| report monthly on complaint volumes and resolution times | D1, F3, G3 | |
| coach branch supervisors on escalations | H2, I2 | |
| work with digital teams on self-service journeys | A7, F1 | |
| 4+ years in financial-services customer operations | A1 | |
| experience handling regulated complaints | B2, E1, H1 | |
| confident presenting to senior leaders | C3, E2, F3 | |
| comfortable with Excel reporting | D1 | Covered through the spreadsheet; no question asks about the tool by name |

---

# Round 1: Recruiter screen (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly walk-through, motivation, logistics | High. Recruiter screens carry this persona by round type, and the 30 minutes is a conversation with the person who ran the process. Casual questions are still scored | A 90-second arc built from F6, F1 and F3 (A1); logistics answered from your own facts (A3 to A6) |
| Skeptic (light) | Knockout checks on the two requirements the JD names and your material leaves thin | Medium. The contact centre (F2) and regulated complaints (F7) are the two a screener checks first | Say the stated gap plainly, then stop (B1); stay at the log's scope (B2) |

## Question bank

### A: Conversational (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with three beats, each in your own words: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log and trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Close on why this role. Answer slot: give the reason that is actually yours; if there is no single reason, say what you are weighing. Add no result or scale the three sentences do not state | F6, F1 and F3 supply the beats. EXP because the recruiter is checking that the story hangs together; the delivery is conversational |
| A2 | "What draws you to Ashgrove, and to a credit union?" | CO | [grounded] | Anchor in what you read. The JD calls Ashgrove member-owned, and the site's four values are Members First, Always; Plain Words; Neighbours, Not Numbers; and Own the Fix. Pick the one or two that are genuinely yours and say why, in your own words. Answer slot: your actual reason for a credit union rather than a bank; if it is mostly the role, say that plainly | A motivation-consistency probe, asked in a friendly register. CO because it tests homework depth, and the values and the JD are the raising sources; the guidance makes no claim about your past |
| A3 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot. Give your actual reason in your own words, in a sentence or two, and turn forward to what you want next. Answer slot: if you would rather not go into the past, say you would prefer to focus on what draws you to this role. Do not supply a reason that is not yours | Reason for leaving is checked on every recruiter screen for consistency with later rounds. EXP because it tests what is actually true of your situation; generic because it is a standard screen question |
| A4 | "What salary are you looking for?" | JD | [generic] | Logistics slot. Give your own figure in your own words, or ask for the role's band first and respond to it. If asked what you earn now, you can redirect to the band for this role without giving a figure | Pay is checked early so neither side wastes the day. JD because it concerns the listed job's terms; the posting you gave me states no band |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period | A knockout-style logistics check on the listed job's terms; the answer is a fact, not a performance |
| A6 | "Are there any constraints on where or how often you could work?" | JD | [generic] | Logistics slot. Give your own constraints, or say you have none. The posting you gave me states no base, so it is also fair to ask where the role sits | The role spans branches and the contact centre, and location is a term the screener has to settle. JD because it concerns the job's terms |
| A7 | "What have you picked up about where Ashgrove is heading?" | CO | [inferred] | Bring one fact, then one view. The fact: the brief aims to move 40% of member service to digital channels by 2028 and to consolidate eight branches into five hubs over 2027. Answer slot: your view of where that touches complaints; if you hold one, say it as a view, not as something you have seen; if you have not formed one, say what you would want to find out | The grounding brief's digital and hub moves are the raising sources; the link to complaints is this pack's derivation from the brief and the JD's digital line. Lowest-cost differentiator in the round, since most candidates will not have read the brief |

### B: Skeptic, light (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role covers the contact centre as well as branches. What's your experience on that side?" | JD | [grounded] "Never worked in a contact centre" | Say it first and plainly: "I haven't worked in a contact centre." Then give the plan, as a plan: what you would want to learn first and from whom, in your own words. Do not borrow a branch story to cover it. If asked how the two differ, say what you would want to find out rather than claiming to know | F2 is a stated gap, and the screener is likely to meet it as a knockout. JD because it scores a stated requirement; the full cross-examination is C1 |
| B2 | "Tell me about the formal complaints log you handled." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7 and F1: the log, which you handled, and the escalation script, which you trained new tellers on; tell them in your own words. Answer slot: the JD asks for regulated complaints, so expect a probe on what rules or deadlines applied to the complaints in the log. If you know, say which and what part was yours; if you do not know, or none applied, or it was not yours, say so plainly and stay with the log | F7 is the evidence for the regulated-complaints requirement and is thin, so this is where the screener will test it. JD because it scores a stated requirement; EXP delivery |

## Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Does the 20-minute case in the last round have a format I should know, and is anything prepared in advance?" | The recruiter controls process detail, and a candidate who asks about format is preparing. It also tunes H1 |
| R1.2 | "How does the panel score the four values — separately, or as one view?" | Shows you are taking the values round seriously and tells you how to spend your stories |
| R1.3 | "Is the contact centre a team that would report to this role, or a partner team?" | Settles how much of day one is the area F2 leaves open, in a question that sounds like planning |
| R1.4 | "Where is the role based, and how much movement between sites would it involve?" | A logistics question you are entitled to ask, and it settles A6 from the employer's side |

---

# Round 2: Head of Member Services, your manager (45 minutes, mostly behavioural)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probing the gaps between this JD and your material | High. A hiring manager is buying capability and de-risking gaps by round-type prior, and F2 and F8 are two stated gaps. The weights come from the prior and your material, not from anything known about this person | Rehearse C1 until it is boring: concede exactly, hold the quote's scope, give a plan |
| Values / Behavioural | "Tell me about a time" questions | High. The recruiter's own words say the round is "mostly behavioural". Which values the Head of Member Services leans on is not known | A selection scaffold per question (E1, E2); one story spent once across the day |
| Case / Strategist | Live problems from the manager's own roadmap | Medium. A hiring-manager prior, plus the brief's digital and hub moves, which this manager is more likely to own | Clarify, structure, then answer, in Ashgrove's vocabulary (F1 to F3) |
| Data-Driven Prober | Pressing on the one thing you built | Low to medium. The spreadsheet (F3, F9) is the one artifact in your material | Say plainly what you know about how it counted (D1) |
| Pressure | Time-boxed challenge on presenting | Low. One question (C3), because the JD names senior leaders and your material states the gap | Concede first and exactly, hold what the quote carries |

## Question bank

### C: Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "This role owns complaints across every branch and the contact centre. You haven't worked in a contact centre, and your complaints work was a branch's log. What wouldn't you know on day one?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI rehearsal in this pack.** Hold what the quote carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Concede exactly: "I haven't worked in a contact centre." Name the limit in your own words: the log was a branch's. Follow-up 1 ("Isn't that a big gap?"): restate the concession, and do not add to the log. Follow-up 2 ("What would you do in your first month?"): a plan, said as a plan, with who you would sit with and what you would ask for first, in your own words. Never fold into "I'd pick it up quickly" with no plan, and never stretch the log into a process across branches. Answer slot: if any of your log work crossed to other branches or to a central team, say what and what part was yours; if none did, say so plainly and stay with the one branch | F2 and F1 are where the role's scope presses hardest against your material, so this objection arrives in some form from any hiring manager. JD because it scores the stated requirement; the pressure delivery is why it gets the most follow-up levels |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level." | Choose one, say it in a sentence, and then say how you would close it. The two your own material states are the contact centre and presenting above regional level; pick the one you honestly rank first. Do not name a third thing you have not assessed. Answer slot: if you have worked with a digital team, say so and do not name digital; if you have not, say so plainly, and that is the one to weigh | A standard Skeptic stem that rewards calibrated candour over a disguised strength. F2 and F8 are the two gaps you stated, and F5 is silent |
| C3 | "Sixty seconds: you haven't presented above regional level. Why should we put you in front of our senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Pause and restate the question. Concede first and exactly: "I haven't presented above regional level." Hold that you built the monthly complaints spreadsheet your regional manager uses. Answer slot: what the sheet counted, in your own words; if you do not know how a figure was counted, say so plainly. Through two follow-ups, return to the concession and to your plan for a first senior presentation, said as a plan. Do not add audiences, workshops or training you did not state | F8 is a stated gap and the JD names senior leaders. JD because it scores a stated requirement; the time-boxed delivery tests whether you hold a position without defending what you cannot back |

### D: Data-Driven Prober (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly complaints spreadsheet. What did it count, and how?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the sentence: you built it, it is monthly, and your regional manager uses it. Answer slot: what the sheet counted and how a figure got into it, in your own words; the JD's volumes and resolution times are the likely probe. Name, before you are asked, the assumption behind a figure you would defend least; if you do not know how something was counted, say so plainly. Describe no formula, chart or field you did not build | F3 and F9 are the evidence for the reporting requirements, and a built artifact is the one thing in your material an interviewer can ask to see. EXP because it tests exactly what was yours |

### E: Values / Behavioural (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a complaint escalated beyond what the counter could resolve." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold. Pick one real escalation. It needs a named member situation, the point where it went beyond the counter, what you did yourself, and what the member heard at the end; use "we" for context and "I" for what was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: you handled the branch's formal complaints log and trained new tellers on the escalation script, or how you would handle it | The JD's coaching-on-escalations line is the raising source, and the open prompt leaves the instance to you. F1 and F4 hold only the log and the script, not an incident, so the pack does not supply one |
| E2 | "Tell me about a time you had to tell someone senior something they didn't want to hear." | VAL | [generic] | Selection scaffold. Pick a time with a named stake, a message you delivered rather than softened, and an intact relationship at the end; the hard truth should have landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem. It sits close to the JD's senior-leader reporting, where your material is thin (F8), so a prepared selection matters. VAL because it scores behaviour, not a requirement |

### F: Case / Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "A member gets stuck in a self-service journey in the app, then complains. Who owns that complaint, and what do you do in the first 24 hours?" | CASE | [inferred] | Structure it aloud. Clarify first: what happened in the app, what the member has been told, which deadlines apply to this kind of complaint. State the objective: the member hears one clear answer from one person. Say who owns it: whoever finds it keeps hold, which is Own the Fix applied. Then the plain-words reply, the fix, the record, and the pattern: how many members hit the same step, who owns the journey on the digital side, and what you would report. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The brief's digital target and the JD's digital line are the raising sources, and the scenario is this pack's derivation from them. F5 is silent, so a case lets you show the reasoning without claiming digital work |
| F2 | "Over 2027 the eight branches become five hubs. What would you watch in the complaints data to know members are still being looked after?" | CO | [inferred] | Clarify what is measured today, then segment: by branch and hub, by channel, by complaint type. Watch volume and resolution time against each branch's own trend, and read cases, not only counts. Name the risk that a quieter number can mean members stopped telling you. Say what you would report and to whom, in plain words. The guidance makes no claim about your past | The hub move is the raising source and the link to complaint data is this pack's derivation. CO because it needs the company's own strategy; CASE delivery |
| F3 | "You have ten minutes with our senior team next month. What goes on the one page about complaints?" | CASE | [generic] | Say what decision the page is for, then the few numbers and the one story. The JD names volumes and resolution times, so those lead, each with what it means in a sentence. Close on what you are asking them to do. The guidance makes no claim about your past | JD content (the monthly report, F3) delivered as a case, and a rehearsal for F8 without claiming it. Generic because it is a pattern for the problem, not a fact about Ashgrove |

## Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What does a good first 90 days look like, and what would you want to be different in complaints by the end of the year?" | Moves the conversation from your gaps to the job, and gives you the manager's own measure of success |
| R2.2 | "Where does a complaint most often get stuck today between a branch and the contact centre?" | Goes straight to the seam F2 leaves open, and shows you think about the process end to end |
| R2.3 | "How are complaint volumes and resolution times reported today, and who reads the monthly report?" | Ties to F3 and F8 without claiming either: you are asking who the audience is |
| R2.4 | "The brief points to 40% of member service on digital channels by 2028. Which complaint types do you expect to move first, and who on the digital side would I work with?" | Uses the grounding brief and settles F5 from the employer's side |
| R2.5 | "What would make you say in a year that this was the right hire, and what would make you worry?" | A manager's honest answer to the worry half tells you which gap to close first |

---

# Round 3: Panel of two branch managers, including the 20-minute case and the values round (60 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Stories scored against the four published values | High. The recruiter's email says the panel scores against the four values, and a loop source documents it | One question per value (G1 to G4), each with a selection scaffold; see the values cheat sheet |
| Case / Strategist | The 20-minute escalation case | High. It is named in the email and takes a third of the hour | Clarify, objective, approach, metrics, risks; think aloud (H1 to H3) |
| Peer Evaluator | Seam-splitting, credit, "what would you need from us" | Medium. Reading, not fact: branch managers run the branches whose supervisors the JD says this role coaches. Panel rule applied: blend the top two personas of each member's relationship, and the panel's own names are unassigned | Reciprocity framing and seam principles (I1, I2) |
| Skeptic | Quiet probing of F2 and F8 | Low. Round 2 owns it, but a panel member can ask it again | Same concessions as C1 and C3 |

## Question bank

### G: Values / Behavioural (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter when it wasn't the easy option." | VAL | [grounded] | Selection scaffold, for Members First, Always. The story needs a named member, a decision that was yours, what was easier for the branch or the process, and what changed for the member; the hard truth should land, for example the member did not get everything they asked for. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value is the raising source, quoted from the page you pasted. No sentence of yours carries a story for this value, so the pack gives selection criteria and not a story |
| G2 | "Tell me about a time something you said or wrote had to be explained twice. What did you change?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, for Plain Words. The value puts the fault on the wording, not on the member, so the story that lands owns that. The nearest thing in your material is the escalation script you trained new tellers on. Answer slot: if any wording in it, or in a reply to a member, was changed because someone needed it explained twice, say what changed and who changed it; if none was, or it was not yours, say so plainly. If no such time comes to mind, say so, then give how you would handle it | The published value is the raising source. F4 holds the script only as something you trained tellers on, so whether the wording was ever changed is a slot |
| G3 | "You built the monthly complaints spreadsheet. How do you stop the numbers hiding the neighbours?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with what is yours: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if you ever looked behind a figure at one member's case and it changed what you did, say what; if you never did, say so plainly. Then give how you would keep each town visible in a report, said as a plan: by branch and by town as well as by total, with the cases read, not only counted | Neighbours, Not Numbers sits closest to the one artifact built on numbers (F3), and the hub move gives the panel a reason to ask. VAL because it scores the published value; the premise is your own sentence |
| G4 | "Tell me about a time you found a problem that wasn't yours and kept hold of it until it was fixed." | VAL | [grounded] | Selection scaffold, for Own the Fix. The story needs a named problem, a moment when handing it on would have been easy, what you did, and how you knew it was fixed from the member's side. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The published value is the raising source. F1 shows a log you handled, which is not the same as a problem you kept hold of, so the pack gives criteria and no story |

### H: Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A branch supervisor has escalated a complaint to you. The member says the branch and the contact centre told them different things, and they have been waiting. Walk us through what you do." | CASE | [generic] | The 20-minute case, so budget it: about two minutes clarifying, then structure, then answer, leaving a few minutes for questions. Clarify first: what each side told the member, what has been promised, which deadlines apply to this kind of complaint. Objective: one clear answer, from one person, in plain words. Own it: you keep hold until it is solved, and the supervisor hears the outcome. Separate the member's fix from the pattern: where the two channels disagree, and what you would report. Name what you do not know and how you would find out. Challenge one premise respectfully. The guidance makes no claim about your past | The recruiter's email names a 20-minute case on a complaint escalation but not its content, so this is a pattern for the problem and nothing about Ashgrove's actual case; once the recruiter shares the format, regenerate this row |
| H2 | "One of our supervisors keeps escalating complaints that could be settled at the counter, and another never escalates. How would you coach each?" | CASE | [generic] | Start from cases, not impressions: look at what each supervisor actually escalated, or did not. Agree what good looks like with the branch manager first, and coach alongside them, not around them. Coach through a real case, not the policy. Keep ownership with the supervisor, and follow up. Say what you would not do: take the complaint away from them. The guidance makes no claim about your past | The JD's coaching line is the raising source (F4), asked in front of the people whose supervisors are being coached. CASE because it is a live problem from the role |
| H3 | "As branches become hubs, how do you keep a town's complaints from disappearing into a hub average?" | CASE | [inferred] | Segment by town as well as by hub, and read the cases, not only the counts. Ask the branch managers what they are hearing before the numbers move. Set a point at which a town's pattern gets looked at on its own, and report it in plain words. The guidance makes no claim about your past | The hub move and the value Neighbours, Not Numbers are the raising sources; joining them is this pack's derivation, not something the panel has said |

### I: Peer Evaluator (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "You'd sit across branches and the contact centre, and we run branches. Where is the seam, and what happens when we disagree about whether a complaint is resolved?" | CASE | [generic] | Offer seam principles, not a map you cannot know: the member's outcome decides whether it is resolved; the branch manager knows the town; the complaints lead holds the process and the report. When you disagree, start from what the member has been told, then bring the case. Show spine and tact together: say what you would hold, and what you would concede | A standard peer stem. CASE because it is a live collaboration problem, and generic because the pack does not know where Ashgrove's seam actually is |
| I2 | "You've been a supervisor yourself. From that chair, what makes a head-office complaints person useful rather than a nuisance?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Speak from the chair you have: three years as a branch supervisor. Answer slot: if you remember a time head office or a complaints team helped or got in the way of your branch, say what happened in your own words; if no specific time comes to mind, say so plainly and say what you would want from them. Then turn it into what you would offer supervisors | JD content (F4, coaching) with peer delivery: the panel is checking whether the role would add to their load or reduce it. The premise is your own sentence (F6) |

## Values cheat sheet (the panel scores against these four)

| Value (official name) | Working meaning | Your story, or the scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold at G1: a named member, a decision that was yours, what was easier for the branch or the process, and what changed for the member; if none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Plain Words | If a member needs it explained twice, the organisation wrote it wrong; the fault is the wording | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot at G2: if any wording was changed because someone needed it explained twice, say what and who changed it; if none was, or it was not yours, say so plainly |
| Neighbours, Not Numbers | Every branch is part of its town; local context beats an aggregate | F3: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot at G3: if you ever looked behind a figure at one member's case, say what changed; if not, say so plainly and say how you would keep a town visible |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The log is the nearest thing in your material; the scaffold at G4 asks for a problem you kept hold of. If none comes to mind, say so plainly, then give how you would handle it |

## Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What do your supervisors most often get stuck on when a complaint escalates?" | The panel runs the branches whose supervisors the role would coach, and asking tells them you start from their problem |
| R3.2 | "What could a complaints lead do in the first month that would genuinely help your branch?" | The reciprocity question: it asks what you can bring them, not only what you need |
| R3.3 | "As branches consolidate into hubs over 2027, what would you want a complaints lead to protect for your town's members?" | Uses the brief and the value Neighbours, Not Numbers, and invites them to say what they actually worry about |
| R3.4 | "How do you hear about a complaint today: from the member, from the supervisor, or from the monthly figures?" | Surfaces where the numbers and the neighbours part company, without asserting that they do |
| R3.5 | "What is one thing about how a branch and the contact centre hand a complaint to each other that you would change?" | Goes to the seam F2 leaves open and gets a branch manager's view of it |

---

## Prohibited claims

What this pack will not coach, built before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end, or across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says one branch's log and a teller script. C1's slot stays inside the log |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented above regional level." No slot |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: a formal complaints log. B2's slot asks only which rules or deadlines applied, with "none" and "I don't know" as honest branches |
| Reported complaint volumes and resolution times monthly | Inflated form of F3 | F3's quote at its own scope: you built the monthly spreadsheet your regional manager uses. D1's slot asks only what it counted |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: you trained new tellers on the escalation script. I2 and H2 stay inside that |

## Sources

**Provided documents:** the JD as you pasted it; Ashgrove's four published values, as you copied them from ashgrovecu.org/about/values on 24 November 2026; the recruiter's email on the three rounds; the 2026 strategy brief the recruiter sent, as you summarised it in your message (four moves, listed in the grounding brief); your own background, quoted in the fit snapshot.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text fixes the values cheat sheet and the VAL questions; the page was named only as where you copied it from |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email establishes the loop: three sessions, who runs each and how long. It fixes the round structure and the persona weights, and a search could not change them |
| 3. Ashgrove strategy or recent news | skipped | The brief's four moves, relayed by you and dated July 2026, fix the CO and CASE questions. A newer move is not ruled out, and a deeper pass is offered in the menu |
| 4. Interviewer name and Ashgrove | n/a | No names are assigned, so there was no query to form; the interviewer read is absent and the menu says what a name would unlock |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **The names of the Head of Member Services and the two panel members** → an interviewer read, persona weights adjusted from their public professional footprint, and one reverse question tied to each person's own path.
- **The recruiter's detail on the 20-minute case** (whether it is live or prepared, and what material you get) → H1 rebuilt for the real format, and the case's time budget set.
- **The role's pay band and where it is based** (the recruiter can send both in one email) → A4 and A6 answered against facts, and any term the posting leaves open surfaced as a gate row.
- **Your own answers to the answer slots**, stated outside a drill: what the spreadsheet counted, whether the log's complaints were regulated, whether any training reached supervisors, any digital work → F1, F3, F4, F5 and F7 regenerate from your words, and the banks that draw on them follow.
- **Your CV** → F1, F3, F4, F6 and F9 move from your one-line summaries to your actual lines, and any row with a supporting document, such as a sample of the spreadsheet with figures removed, can move from `medium` towards `high`.
- **The complaint rules that apply to Ashgrove's members, if you know them** → sharper B2, H1 and F7, with the rules named in your words, not mine.
- **The hours you have before 3 December** → a prep triage ordered by round, with C1 first.
- **A deeper research pass, offered once:** up to 6 more searches and 2 more fetches, several more minutes, covering Ashgrove's recent news, reported interview formats for this role family, and interviewer footprints once names exist → the CO and CASE rows firmed up, and any newer move than July 2026 reflected.
- **A `tuesday-dossier.md` from an earlier evidence check, if you have one** → verified claims and unresolved risks carried into the banks. It is never a prerequisite for this pack.
