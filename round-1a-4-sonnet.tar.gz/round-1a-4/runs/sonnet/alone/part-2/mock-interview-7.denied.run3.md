I'll read the reference files the skill points to before writing anything.
The pack is written and saved. I'm now giving you the summary and the one question that would change it.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-7-denied-0b0e4c96/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it assuming Tobias is your hiring manager, since his title heads the function this role sits in.

Web search was refused in this session, so the pack has no Saltmarsh facts. The values, interview loop, strategy and Tobias's background are all missing, and the Sources section lists each refused search. Company questions are generic and the persona weights rest on a typical hiring-manager round. Spend an hour on both Saltmarsh titles before Friday, because question D2 depends on it.

Say the word and I'll play the Skeptic on B1, the in-app-purchases question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What is Tobias's relationship to the role (your future manager, a skip-level, or something else), and has the recruiter said anything about what the session will focus on or whether to bring something?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship: assumed hiring manager, not confirmed. Session: 60 minutes, Friday.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Question IDs run by persona (A1, A2, B1 and so on) so a drill can call them by name.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values a company publishes, rather than generic virtue |
| EXP | Whether your own claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Wherever a cell says answer slot, it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours or did not exist. Both are good answers.

## Prep triage

You have Tuesday to Friday. Do these in order; each is tied to a question ID.

1. Tuesday: B1, the highest-ROI rehearsal in this pack. Say it aloud until it is boring, including both follow-ups.
2. Wednesday: D1 as a 90-second arc, then C1 and C3 in your own words, then A1 and A4 aloud with the case structure.
3. Thursday: B2 and E1 against a timer, then pick your five reverse questions. Spend an hour on both Saltmarsh titles themselves, so D2 is answered from what you saw.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Words stay at the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Your material says content drops for the main title, not live events and not two titles. Answer slot: the JD's two-titles line makes a probe on a second calendar likely. If you touched another title's calendar, or any drop was a time-limited event, say so in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | Running a weekly calendar does not show whose work fed each drop, and your material is silent on it. Answer slot: if drops needed design, art, engineering or community work, say which of those you coordinated and how, in your own words; if some were not part of your drops, or the coordination was not yours, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Words stay at the quote: "I presented the monthly retention numbers to the studio head." It says presenting; your material does not show who chose or compiled the numbers, or any review of an event. Answer slot: if you chose or compiled them, say how, in your own words; if someone else supplied them, or no event review was part of it, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Lead with the quote in its own terms: "I wrote the release checklist our QA team still uses." It is a named artifact in ongoing use, with nothing inspected behind it, so expect a probe on it. Running releases is not in the quote, and the bridge adds nothing to it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | Words: "I was an associate producer for four years at a puzzle-game studio." The quote does not show whether the title kept updating after launch. Answer slot: if it did, say how, in your own words; if it did not, say so plainly and stay with the four years |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | Lead with the quote in its own terms: a recurring presentation of retention numbers to the studio head. No figure is in your material, so expect a probe on how they were counted. Answer slot: say how they were counted, what they are sensitive to, which assumption you would defend least and which part was yours; if you do not know how a figure was counted, say so plainly |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist others still use is writing others rely on, but your material does not show whether it read as clear to them, or what else you have written. Answer slot: name one document of yours that others rely on; if the checklist is the one, say so; if none comes to mind, say so plainly |
| F8 | Role-family prose, no JD line raises it: events and their KPIs at a mobile studio can involve in-app purchases — [generic] | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Carried because you named it, not because the JD asks |

## Persona table

No loop source establishes this loop, so the weights rest on a relationship prior and the Generic archetype (screen, hiring manager, panel), not on Saltmarsh's documented process. The prior assumes Tobias is your hiring manager because his title heads the function this role sits in; if he is not, the weights move.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Case/Strategist | Live problems from the role: two calendars, a post-event diagnosis, a go-live | high: the hiring-manager prior leads with it, and the JD's calendar and review duties invite live problems | Clarify, objective, segments, approach, metrics, risks; think aloud; challenge one premise politely |
| B Skeptic | Quiet probing of the gaps: in-app purchases, no team led, one calendar versus two | high: these are the gaps your own message states or the JD presses | Rehearse B1 until it is boring; bridges only from your quotes; state the limit plainly before it is asked for |
| C Data-Driven Prober | Line-by-line on the retention numbers and the KPIs the JD says the role owns | medium: the JD names retention metrics and KPI ownership | Say how a number was counted, or say plainly you do not know; name the assumption you would defend least |
| D Conversational | Friendly opener, "walk me through the journey", what you play | medium: not the prior for this relationship, but D1 is cheap to rehearse and applies whoever Tobias is | A 90-second arc built from your own sentences; treat casual questions as scored |
| E Pressure | Time-boxed challenge, "how much of that was you" | low: the prior is for skip-level rounds; kept because B1 and B2 follow-ups can turn pressure | Pause, restate, hold through two follow-ups, concede one specific limit |
| F Peer Evaluator | The seam with QA, credit across teams | low: the JD names QA and four partner teams, so the seam can come up from anyone | Reciprocity framing; seam principles rather than pretending to know the seam |
| G Values/Behavioral | Scenario prompts about unwelcome truths and trade-offs | low: no loop source names a values round and no published values were read, so these are persona-stem prompts only | A story where one of your quotes carries it, otherwise the selection scaffold and its honest branch |

## Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two titles both want a big event in the same fortnight, and engineering says only one fits. What do you need to know first, and how do you decide?" | CASE | [generic] | Clarify before you structure: what is fixed about the fortnight, what each event is meant to move, what engineering's limit really is. Then objective, options, the metric each option is judged on, and the risk of each. Challenge one premise politely, for example whether the fortnight is truly fixed. The question needs no claim about your past, so the guidance makes none | Tests the JD's two-titles calendar line (F1) as a decision. CASE because it is a live problem, `[generic]` because it is a pattern, not a fact about Saltmarsh |
| A2 | "An event ended yesterday and retention for the players who joined during it is well below the usual. Diagnose it." | CASE | [generic] | Clarify what below usual is measured against, which players, and what changed. Then split into causes you can test in order, say which assumption you would test first and why, and what you would do with each finding. Think aloud | Combines the JD's retention and post-event review duties (F3, F6) in one problem. CASE with a metrics core |
| A3 | "Design the post-event review for an event that finished last week: what goes in it, who reads it, and what does it decide?" | CASE | [generic] | Start from the decision the review feeds, then the few measures that inform it and the one you would not trust alone. Say who reads it and what changes afterwards. Answer slot: if you have written a review of this kind yourself, say what it covered; if you have not, say so plainly and stay with how you would design one | The JD gives the role ownership of the review and the KPIs it reports (F3), so the design question is likely. CASE because it is built live |
| A4 | "Walk me through what has to be true before an update goes live on a Thursday: who signs off, and what are you chasing on the Tuesday?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." "I ran the weekly content-drop calendar for our main title for the last two years." | Walk the dependencies team by team, then the checklist. Your anchor is the quote: "I wrote the release checklist our QA team still uses." Answer slot: the JD lists design, art, engineering and community; say which of those you worked with on your weekly drops and how; if some were not part of them, say so plainly and stay with the calendar you ran | Covers coordination and the checklist (F2, F4) in one scenario. JD content, CASE delivery |
| A5 | "An event is live and a reward is paying out wrongly. Players are noticing in the community channels. What is your first hour?" | CASE | [generic] | Stabilise first: decide whether to pause, who owns the fix, what players are told and when. Then log it for the review. Say your order aloud and why. No claim about your past is made | The JD joins engineering and community on each update (F2); this is where the seam shows under load. CASE |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see in-app purchases anywhere in your background. If our events touch the store, how do you get up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then a ramp as a plan, never a past: what you would ask for in week one and what you would read first. Hold through two follow-ups. If asked what you would get wrong first, name your own answer; if asked why not hire someone who has, return to what your quotes carry and add nothing. Your retention-number quote is not a revenue claim; do not stretch it | F8 is the one gap you stated outright, and a mobile live-ops interviewer has an obvious reason to press it. JD because it scores fit, and the hold-then-concede shape is the point |
| B2 | "You've never led a team, and this role coordinates design, art, engineering and community on each update. How do you get four teams to hold a date?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Acknowledge plainly: "I haven't led a team." The JD says coordinate, so keep the answer to coordination. Answer slot: if you got people from those teams to hold a drop date, say how, in your own words; if the dates were not yours to hold, or the coordination was not yours, say so plainly and describe how you would do it | F2 is thin and the stated negative sits beside it. JD because it tests the coordination line |
| B3 | "You ran the calendar for your main title. This role runs two titles. What changes when there are two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you ran, in the quote's words. Answer slot: if you touched another title's calendar, say how; if you did not, say so plainly and stay with the one you ran. Then reason aloud, as a plan: what you would share across two calendars and what must stay separate | F1: the JD says two titles and your quote says the main title. JD |
| B4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Pick the weakness your own words already name rather than inventing a safer one, say it in one sentence, then give the first-month plan. Calibrated candor beats bluffing a skill the interviewer owns | F8. A persona-stem question, so the theme is the persona's and not the JD's. JD |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot, in your own words: how they were counted, what they are sensitive to, which assumption behind them you would defend least, and which part was yours. If you do not know how a figure was counted, say so plainly and say what you would ask. Name the weakest assumption before the interviewer does | F6 is the evidence for the retention requirement and the number a prober targets first. EXP because it tests attribution |
| C2 | "Which retention measure would you put in a post-event review, and which would you refuse to rely on alone?" | JD | [generic] | Choose measures you can define aloud in one sentence each. Say which you would distrust on its own and why, then what you would pair it with. No claim about your past is made | The JD's retention and KPI lines (F3, F6) as a design choice. JD |
| C3 | "Who chose the retention numbers you presented each month?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you chose or compiled them, say how, in your own words; if someone else supplied them, say so plainly and stay with presenting them. Never say you owned the KPIs unless that is exactly what you did | F3: the JD says own the KPIs, your quote says presented. EXP |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with only these beats: four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for your main title, the checklist, the monthly retention numbers. Answer slot: the JD says live-service; if your title kept updating after launch, say how; if it did not, say so plainly. End on why this role, in your own words | F5 and F1 as one arc. The opener is scored even when it feels casual. EXP |
| D2 | "What drew you to Saltmarsh, and to live ops on mobile?" | CO | [generic] | Say your real reason in your own words. Saltmarsh facts could not be researched in this session, so none are supplied here; look at both titles before Friday and say what you noticed. If you have not played them by then, say so plainly rather than guessing | Motivation consistency; CO because it tests homework. The pack holds no company facts, so it stays `[generic]` |
| D3 | "Tell me about a piece of writing of yours that other people rely on." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | If the checklist is the one, say it in the quote's words: "I wrote the release checklist our QA team still uses." Answer slot: if others changed it over time, or you know how it read to them, say what; if you do not know, say so plainly | The JD asks for clear written communication (F7). The opener is an open prompt from that line. EXP |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run live events at a studio with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Pause, restate, then hold on what your quotes carry: the calendar you ran for two years, the checklist QA still uses. Concede one limit specifically: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to those facts, never by adding to them | B1 under time pressure. JD because it scores the fit objection |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold the quote: "I wrote the release checklist our QA team still uses." Answer slot: if QA or others wrote parts of it, say which; if it was all yours, say so plainly. Do not widen it to managing releases | F4: the attribution probe attached to a CV line with nothing inspected behind it. EXP |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Live ops and QA sit side by side: where is the seam, and what happens when we disagree about a release?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Propose seam principles instead of pretending to know the seam: who decides ship or hold, and how a disagreement is recorded. Your concrete shared artifact is the quote: "I wrote the release checklist our QA team still uses." Add what you would bring QA, not only what you need | The JD names QA directly (F4). CASE because it asks for a decision rule |
| F2 | "How do you handle credit when an update spans design, art, engineering and community?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Use we for context and I for contribution. Your contribution, in the quote's words: you ran the weekly content-drop calendar. Answer slot: say which part of a drop was yours; if you cannot separate it, say so plainly | F2: four teams per update raises credit. VAL because it scores how you share it |

### G. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Your quote shows numbers going to leadership, not whether any were unwelcome. Answer slot: if some month's numbers were unwelcome, say what you said and what happened; if none were, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6. A persona-stem prompt, so the theme is the persona's. VAL |
| G2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time with a named stake, a decision you made, and what it cost the metric. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona-stem prompt with no raising source, so no story is mapped. VAL |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A4, B3 |
| "coordinate design, art, engineering and community teams on each update" | A4, A5, B2, F2 |
| "own the post-event review and the KPIs it reports" | A2, A3, C2, C3 |
| "manage the release checklist with QA" | A4, E2, F1 |
| "3+ years producing live-service games or apps" | B4, D1, E1 |
| "comfortable with player-retention metrics" | A2, C1, C2 |
| "clear written communication" | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which recent event would you call a success, and what in the post-event review made it one?" | The JD gives this role the review and its KPIs; the answer tells you the bar and gives you vocabulary |
| R2 | "What would the first event I own look like, and who would I be coordinating on it?" | Shows the real ramp and the teams behind the JD's coordination line |
| R3 | "How do in-game purchases and event planning fit together on your two titles, and what should I read first?" | Turns your stated gap into a learning plan in front of the person who owns it |
| R4 | "What does the release checklist look like today, and where does it hurt?" | Connects to the checklist you wrote and shows you think in terms of how QA actually works |
| R5 | "How does a retention review reach the calendar: who decides to change an event?" | Tests whether the role owns the loop or only reports it |
| R6 | "What would make you say in six months that this hire worked?" | Gets the success criteria out of the room before you are measured against them |

No interviewer profile was available, so none of these is tied to Tobias's own path.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team or managed people | Negative you stated, F8 | "I haven't led a team." The JD says coordinate, so the answer stays with coordination. B2's slot asks only what you coordinated |
| Has worked on a game with in-app purchases | Negative you stated, F8 | "I haven't worked on a game with in-app purchases." Then a plan, never a past |
| Ran live events for two titles | Inflated form of F1 | F1's quote at its own scope. Your material says the main title's weekly content-drop calendar, not two titles and not events |
| Owned the KPIs or the post-event review | Inflated form of F3 | F3's quote at its own scope. Your material says presented, not owned or chose; C3's slot stays inside presenting |
| Managed releases | Inflated form of F4 | F4's quote at its own scope. Your material says you wrote the checklist QA still uses |
| Produced a live-service game | Inflated form of F5 | F5's quote at its own scope. Your material says associate producer at a puzzle-game studio; D1's slot asks only whether the title kept updating |

## Sources

Provided: the JD text and your background, both in your message. No dossier was present.

Searches sent, all refused by the host before returning anything:

- "Saltmarsh Games values": refused
- "Saltmarsh Games interview process live operations producer": refused
- "Saltmarsh Games mobile studio strategy news": refused
- "Tobias Wrenfield Saltmarsh Games": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have fed a values cheat sheet and grounded the G bank in published values; the G bank is persona-stem prompts instead |
| 2. Saltmarsh Games interview process, live ops | unavailable | Would have set the persona weights from documented rounds; the weights rest on the relationship prior and the Generic archetype |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have grounded CO and CASE questions in current priorities; D2 stays generic and A1 to A5 are role-family cases |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have given an interviewer read and a reverse question tied to his path; both are absent |
| 5. Representative live operations producer JD | skipped | The JD you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Tobias's relationship to the role, and any recruiter guidance on focus or a pre-declared exercise → persona weights recomputed, and a build section if an exercise was announced
- Web search permitted, or a pasted Saltmarsh values page, careers page or interview guide → the four unavailable targets above run, D2 moves from `[generic]` to `[grounded]`, a values cheat sheet appears if a values round is named
- Tobias's public profile, talks or writing, pasted or linked → an interviewer read, tuned persona weights and a reverse question tied to his path
- A deeper research pass, up to 6 further searches and 2 further fetches, several more minutes → a strategy brief and grounding section, offered once here
- Your answers to the slots in F1, F2, F3, F5 and F7 → those rows move off `discovery` or `transferability` and the bridges become your own stories
- The release checklist itself, a redacted page of the weekly calendar, or the monthly retention deck → F1, F3, F4 and F6 can rise from medium toward high
- A tuesday-dossier.md → verified evidence and a sourced prohibited-claims list in place of the one built locally here
