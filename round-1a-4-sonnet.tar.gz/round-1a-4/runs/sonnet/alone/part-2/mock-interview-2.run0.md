I'll read the reference files the skill points to before building the pack.
Search was refused all three times, so I'm continuing on the provided material alone and won't retry. Building the pack now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-2-denied-8db8e38d/atlas-freight_operations-manager_interview_pack.md`.

I didn't know the round type or who's interviewing, so I weighted all seven interviewer styles equally. Web search was refused three times, so there's no company research. The company-specific rows are labeled generic, and the interviewer's-style rows are generic too.

**The most important prep is A1**, the scale question. The JD says 12 supervisors across 4 sites. You've described 3 supervisors under you, and your material doesn't show terminal or multi-site work. The pack has you say your real role in your own words, then give a plan rather than a claimed past. The next priorities are A5 (how many of your 7 years were spent leading people) and C1 and G2 (the 40% mis-pick figure and how much of it was yours).

On Power BI, the pack has you say "I've never used Power BI" plainly, followed by a plan for getting to working level. It doesn't coach you to blur it.

I can play the Skeptic on A1 as a live drill whenever you want. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions, or convert the pack to Word.

Is your next round a recruiter screen, a hiring manager, a panel or someone else, and did the invite or recruiter mention any focus areas or anything to prepare? Your answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Round type and relationship: not known, so persona weights are flat (said plainly in the persona table). Built from your message only; company research did not run (see Sources).

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores: **EXP** (do your claims survive scrutiny), **JD** (can you do the listed job, gaps included), **CO** (company knowledge), **CASE** (a live problem from the role), **VAL** (published values). VAL does not appear: no published values were obtained, so nothing here can be scored against them.
- Question IDs run by persona: A, B, C, D, E, G, H. The letter F is skipped so it cannot be confused with the fit rows F1 to F7.
- Guidance is scaffolding, not a script. Each cell is built to be spoken in about 90 to 120 seconds, and only the sentences quoted in its Provenance cell are claims about your past.
- An answer slot is an instruction for the interview, not a question for now. Answer it truthfully in either direction; the second branch exists because the practice may never have been yours, or never existed.
- Labels: `[grounded]` traces to what you gave me, `[inferred]` is derived and the derivation is named, `[generic]` is a pattern for the role with no claim about Atlas Freight or you.

## Prep triage

The interview is next week. In this order:

1. A1 and A5, the scale and years-of-leadership questions. A1 is the highest-ROI prep in this pack.
2. C1 and G2, the 40% figure and how much of it was yours.
3. A3, A4 and C3, on-time and cost, then Power BI and Excel.
4. B1 and B2, one case spoken aloud start to finish.
5. E1 and E2, the 90-second arc and the "why here, why now" answer.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops, a senior shift manager role and a site's surge plan. It does not show terminal operations or more than one site. Words at that scope: "I've spent 7 years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's 4 sites make a probe on multi-site scope likely. If any of your work was in a terminal or covered more than one site, say where and what part was yours, in your own words; if none did, say so plainly and stay with the surge plan and your current role |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is a mis-pick rate, not on-time performance or cost. Words at that scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names on-time performance and cost-per-shipment, so expect a probe on whether you tracked either. If you did, say which and how it was counted, in your own words; if you did not, say so plainly and stay with the mis-pick rate. The figure itself raises the four defend-the-number slots, worked in C1 |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The material says three supervisors and the JD says twelve; that is the pack's observation, not words for you. Words at the quote's scope: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have led more than three people in any role, say where and how many; if not, say so plainly and stay with the three. Then a plan, said as a plan: what you would learn first at each site and from each supervisor |
| F4 | "build reporting in Excel/Power BI" (Excel part) — JD | "solid Excel" — your message | low | [inferred] | discovery | Derived from one phrase, which shows an Excel skill and not whether you built reports others read. Nothing is asserted from it. Answer slot: if you built reports in Excel that others used, say what they covered and who read them; if your Excel work was analysis for yourself, or there was no reporting, say so plainly and describe what you did in Excel |
| F5 | "build reporting in Excel/Power BI" (Power BI part) — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. No claim to Power BI work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The quotes give seven years of ops and a current role over supervisors; they do not show how many of those years were spent leading people, and the JD marks the requirement as required. Answer slot: say how many of the seven years were in a role leading others and what those roles were, in your own words; if fewer than five, say so plainly and stay with what those roles carried |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Say it as it stands: "I'm green belt certified." Name the methodology only as your certificate itself names it |

The JD you gave contains no term you either meet or do not (a licence, a location, a schedule, a pay level), so there is no gate row. Your material says nothing about location, schedule or travel between four sites, and the pack asks nothing about them.

## Persona table

Round type and interviewer are unknown, and no loop source (the company's careers page, a candidate guide, or your own words) establishes the loop, because company research did not run. The pack therefore falls back to the Generic archetype, Screen then hiring manager then panel, with flat weights. That is noticeably weaker than a pack built on a known round. Bank sizes below follow how hard each persona presses on F1 to F7, not how likely the persona is.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the scale, years and tooling gaps | Unknown, flat. Largest bank because F1, F3, F4, F5 and F6 are the rows the JD presses hardest | Rehearse the A1 objection until it is boring; say the limit plainly where a quote or slot allows it; follow with a plan, never a claimed past |
| Case / Strategist (B) | Live problems from the role: diagnose, plan, design | Unknown, flat. The JD's on-time and cost lines make diagnosis cases natural | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (C) | Line-by-line on figures and artifacts | Unknown, flat. One quantified claim is on the table (F2) | Know what you can and cannot say about how the figure was counted; name the weakest assumption first; say plainly when you do not know |
| Values / Behavioral (D) | Open "tell me about a time" prompts | Unknown, flat. No published values obtained, so no values-style round is detected | Choose stories that fit what the prompt asks; "we" for context, "I" for what was yours; use the selection scaffold where no quoted sentence carries a story |
| Conversational / Rapport (E) | Friendly biography and motivation questions | Unknown, flat. Common in any first conversation | Pre-script the 90-second arc; treat casual questions about the JD's plus-skill as scored |
| Pressure (G) | Time-boxed, interrupts, tests composure | Unknown, flat. Lower weight in the absence of any signal | Pause, restate, hold the position the quotes carry through two follow-ups, concede specifically |
| Peer Evaluator (H) | Seams between sites, collaboration, credit | Unknown, flat. Possible if a site lead sits on the panel | Offer what you bring them, propose seam principles rather than claiming to know the seam |

## Question banks

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, B1, B3, B4, C2, H1 |
| "drive on-time performance and cost-per-shipment down" | A3, B1, B2, C1 |
| "lead a team of 12 supervisors" | A1, D1, G1 |
| "build reporting in Excel/Power BI" | A4, B4, C3 |
| "5+ years operations leadership required" | A5, E1 |
| "Lean/Six Sigma a plus" | E3 |

No company-strategy question (CO beyond E2) is included: research did not run, so such questions would be generic, and the upgrade menu says what would change that.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role has twelve supervisors across four sites. Where does your experience sit against that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI prep in this pack. Open with the quote's own words: "I'm currently a senior shift manager over 3 supervisors." Say how you lead them in your own words; the quote carries the role and the number and nothing further. Name the scale difference yourself before they do, using only numbers you have. Answer slot: if you have led more than three people in any role, say where and how many; if not, say so plainly and stay with the three. Close with a plan, said as a plan: what you would learn first at each site and from each supervisor, and what you would measure first. Rehearse two follow-ups: "how would your approach change at twelve" (answer with the plan, not a past) and "what would worry you most" (name one real worry in your own words) | F3 is where the JD presses hardest and F1 adds the site count, so this objection will arrive in some form; JD because it scores a stated requirement. It gets the deepest rehearsal because the material is thinnest exactly here |
| A2 | "The role is terminal operations, and your background is warehouse and distribution. What would you need to learn first?" | JD | [grounded] "7 years in warehouse and distribution ops" | Start from the quote: "I've spent 7 years in warehouse and distribution ops." Answer slot: the JD names terminal operations, so expect a probe on whether any of your work was in a terminal; if some was, say where and what part was yours, in your own words; if none was, say so plainly and stay with warehouse and distribution. Then the learning plan: what you would want to see on first visits and what you would ask the people running each site, in your own words | F1 is adjacent work against a differently named environment; JD because the requirement names terminal operations |
| A3 | "The JD wants on-time performance and cost-per-shipment down. Which of those have you moved?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what the quote says: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost-per-shipment, say which and how it was counted, in your own words; if you did not, say so plainly and stay with the mis-pick rate. Do not link the figure to either measure unless you can explain how | F2 is adjacent evidence only; JD because it scores the headline requirement and the premise may be false |
| A4 | "I don't see Power BI in your background. How would you handle the reporting this role needs?" | JD | [grounded] "never used Power BI" | The plain acknowledgment has a source, so say it: "I've never used Power BI." Then a plan, said as a plan: what you would build first and in which tool, and how you would get to working level, in your own words. Answer slot for the Excel half: if you built reports in Excel that others used, say what they covered; if your Excel work was analysis for yourself, say so plainly | F5 is a stated gap, so the honest form is acknowledgment plus plan; F4 is the Excel half. JD because the tool is named in the JD |
| A5 | "The posting asks for five or more years of operations leadership. How many of your years were spent leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: say how many of the seven years were in a role leading others, what those roles were and how many people you led in each, in your own words; if fewer than five, say so plainly and stay with what those roles carried. Start from the quotes: "I've spent 7 years in warehouse and distribution ops" and "I'm currently a senior shift manager over 3 supervisors" | F6 is the row where the quotes do not show leadership years; JD because it scores a stated requirement |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of your four sites has dropped ten points in a month. Walk me through your first week." | CASE | [generic] | Structure it aloud. Clarify first: how on-time is defined and measured, when the drop began, what changed. Objective: restore the measure and find the cause. Segment: by lane, shift, day and inbound versus outbound. Approach: compare the segments, find where the drop concentrates, then test the cause with the people on the floor. Metrics: the on-time measure plus the one that moves first. Risks: a definition change masquerading as a drop. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's on-time line (F2's requirement); CASE because it scores structure; generic because it is a pattern for the problem |
| B2 | "Cost-per-shipment is above target at two of the four sites. How do you decide where to look first?" | CASE | [generic] | Clarify how the figure is built (the numerator, the denominator and what finance counts in each). Split cost into its components as that definition does. Compare the two sites with the others on each component. Decide where to look by size of gap and how controllable it is. Say what you would not cut. Metrics and risks as in B1. No claim about your past | The JD's cost line (F2's requirement), asked as a decision; CASE; generic |
| B3 | "Peak volume hits all four terminals the same week and one is short of people. What do you do?" | CASE | [generic] | Clarify the shortfall (how many, which shifts, how long). Objective: protect the service level at all four. Options: move people, move work, add temporary capacity, defer the lowest-priority work. Name the trade-off of each and who you would consult. Say what you would watch in the first two days. No claim about your past | Tests the JD's daily-operations line across sites (F1's requirement); CASE; generic |
| B4 | "Design the daily operating rhythm for four sites and twelve supervisors: what do you look at, how often, and with whom?" | CASE | [generic] | Objective first: what the daily rhythm must make visible. Then by level: what a supervisor needs, what you need, what leadership needs. Cadence: a short start-of-day check, a mid-day exception view, an end-of-day close. Name the first reports you would build, in which tool, and why. Say honestly that Excel is where you would start if that is true for you, as a plan | The JD's reporting line and the multi-site scope together (F4 and F5's requirement); CASE; generic |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you cut the mis-pick rate by 40%." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say it as the quote does: "I cut mis-pick rate 40% by redesigning the pick path." Then the four defend-the-number slots, each in your own words: how mis-picks were counted and over what period; what the 40% is most sensitive to; the assumption behind it you would defend least, named before they do; which part of the redesign was yours. If you do not know how it was counted, say so plainly. Never describe a method, baseline or cause you cannot repeat under a second question | F2 holds the only quantified claim in your material, which is where a prober starts; EXP because it tests attribution and the number |
| C2 | "Walk me through the surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Tell it at the quote's scope: "I ran the site's peak-season surge plan two years running." Answer slot: say which parts were yours to decide and which were set for you, in your own words; if the plan was set by someone else and you carried it out, say so plainly and describe how you ran it | F1 carries the surge plan as adjacent evidence for owning operations; EXP because it tests what was actually yours |
| C3 | "What's the most useful report you've built in Excel, and who used it?" | JD | [inferred] "solid Excel" | Derived from one phrase, so the pack asserts no Excel work for you. Answer slot: if you built a report that others used, say what it showed, who read it and what they did with it; if your Excel work was analysis for yourself or no report was built, say so plainly and describe what you did in Excel | F4 is thin on reporting; JD because the JD names the tool; the premise may be false |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you had to get supervisors to change how they did something." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Selection scaffold. Pick a time with a named change, someone who disagreed, what you did and what happened. If the pick-path redesign changed how others worked, you may choose it, in the quote's words; if it did not, choose another. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's supervisor-leadership line (F3's requirement) raises the theme; EXP because it tests what you actually did |
| D2 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Selection scaffold. Pick a time with a real stake, a message that was unwelcome, a moment you did not soften it, and a relationship that was intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard stem; EXP because it tests what you did. No published values were obtained, so it scores the behavior, not a named value |
| D3 | "When did you put a customer's shipment ahead of an internal metric?" | EXP | [generic] | Selection scaffold. Pick a time you chose the shipment over a number you were measured on, with the cost named and the outcome as it actually was. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard stem that fits a logistics role; EXP; generic |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey from where you started to senior shift manager." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc with three beats: where you have been ("7 years in warehouse and distribution ops"), where you are ("currently a senior shift manager over 3 supervisors"), and why you want this next. The middle steps and the reason are your own words; the pack does not know them. Keep it to the roles and moves you can answer follow-ups on | F1 and F6 draw on the same lines; EXP because it is the CV walkthrough, delivered casually |
| E2 | "Why Atlas Freight, and why this move now?" | CO | [grounded] | Use only what you can stand behind: the JD's own facts (regional logistics, 800 employees, four sites) and anything you read before the interview. Do not claim knowledge of Atlas Freight's strategy or customers: no research ran, so the pack has none to give. Answer slot: say why you want to move from running shifts to running four sites, in your own words | CO because it tests homework; the JD is the only source here; the question needs no claim about your past |
| E3 | "What are you actually working on in Lean or continuous improvement these days?" | JD | [grounded] "green belt certified" | Say it as the quote does: "I'm green belt certified." Name the methodology only as your certificate does. Answer slot: if you are running any improvement work now, say what; if the green belt methods were used on the pick-path redesign, say which and how; if they were separate, or there is no current work, say so plainly and say what your certification covered | F7; JD because "a plus" in a casual register is still scored |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who has already run multiple sites?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "currently a senior shift manager over 3 supervisors" | Pause and restate. Hold the position the quotes carry: "I cut mis-pick rate 40% by redesigning the pick path" and "I'm currently a senior shift manager over 3 supervisors." Hold through two follow-ups by returning to those. Concede specifically where the material stops. Answer slot: if you have run more than one site, say so; if not, say so plainly and concede the scale while holding on what you did | F1 and F3; JD because it scores fit against the requirement under time pressure |
| G2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the quote's own words and say plainly what part was yours: "we" for context, "I" for what you did. Answer slot: if the redesign was yours, say so as the quote does; if others did parts, say which; if you contributed to a team's redesign, say so plainly. Hold through two follow-ups, then concede only what is true | F2; EXP because it is the attribution probe |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Two of the four sites need the same resource on the same day. How do you decide, and what if two supervisors disagree?" | CASE | [generic] | Propose principles, not a claim about their seam: decide by service impact, make the trade-off visible to both, and keep one rule for ties. Ask how they handle it today. Say what you would want from the other site leads. No claim about your past | The multi-site line of F1's requirement; CASE; generic |
| H2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold. Pick a time work crossed teams, say who did what, and how you made sure credit went where it was earned. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer stem; EXP; generic |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How is on-time performance defined and measured across the four sites today?" | Gets the definition before you are held to it, and shows you think about the measure before the fix |
| 2 | "How are the twelve supervisors spread across the sites, and who do they report to?" | Shows you are thinking about span and structure, and answers what A1 will turn on |
| 3 | "What do the sites and the regional leaders use for reporting today, and in which tools?" | Tells you how large the Power BI gap is in practice, and invites them to set the bar |
| 4 | "What would a strong first quarter look like in this role?" | Gets what they will score on, which you can then aim your first answers at |
| 5 | "What is the hardest operational problem across the four sites right now?" | Moves the conversation from your gaps to a problem you would work on together |
| 6 | "What happens after this conversation, and who else would I meet?" | Practical, and tells you which personas to rehearse next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran terminal operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says warehouse and distribution ops and one site's surge plan. A1 and A2's slots stay inside that |
| Drove on-time performance or cost-per-shipment down | Inflated form of F2 | F2's quote at its own scope: a mis-pick rate. A3's slot asks only what you tracked |
| Led or managed a team of 12 supervisors | Inflated form of F3 | F3's quote at its own scope: 3 supervisors. A1's slot asks only whether you have led more than three |
| Has used, or is familiar with, Power BI | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Has five or more years of operations leadership | Inflated form of F6 | The quotes at their own scope: seven years in ops, a current role over supervisors. A5's slot asks how many were spent leading |
| Used Lean or Six Sigma to cut the mis-pick rate | Inflated form of F2 and F7 | Each quote at its own scope. E3's slot asks only whether the methods were used on that work |

## Sources

Provided documents: your message (the job description text and your background summary). No dossier, CV file, recruiter note or interviewer profile was provided.

Searches sent:

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight regional logistics terminals news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have supplied the published value names for a values cheat sheet, and the pack labels related rows generic instead |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have named the real rounds; persona weights fall back to the Generic archetype and are flat |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have fed company-strategy questions and a grounding brief, both absent here |
| 4. interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you gave fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The round type and who you meet (recruiter, hiring manager, panel, peer) → persona weights stop being flat and the banks reorder; a recruiter screen would add pay, notice, location and reason-for-leaving rows
- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their path
- The recruiter's prep note or stated focus areas → coverage of anything pre-declared, such as a presentation or take-home
- Web search access for company research (refused this session) → published values, the real loop, current strategy; CO questions and a grounding brief replace the generic rows
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, on your say-so → a strategy brief, interviewer talks and writing, loop reports and recent organisation context
- Your answers to the answer slots, stated outside a drill, for F1, F2, F3, F4 and F6 (multi-site or terminal work, on-time or cost tracking, how many were over three, Excel reports, years spent leading) → those rows upgrade from thin to quoted, and the slots in A1 to A5, C2 and C3 become story maps
- Inspectable proof for your field: the before and after mis-pick report behind F2, and your green belt certificate for F7 → the confidence on those rows can rise from medium to high
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and a prohibited-claims list that binds every cell
