I'll read the skill's reference files before building the pack.
Search permission was denied, so I'll build from your documents only and record the refused calls in Sources. Writing the pack now.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-1-denied-6e18ff2d/northwind-data_senior-gtm-strategy-lead_interview_pack.md`.

I built it for a peer conversation with Dan, using only what you gave me: the JD highlights, the summary of Priya, Dan's profile and your research note. My two web searches (Northwind's values and Dan's public footprint) were refused for lack of permission, so none of it comes from the open web. Because I had only highlights and summaries, the fit snapshot quotes your wording rather than the JD's or Priya's CV.

- **Contents:** 22 questions, built to be rehearsed in 60 minutes with Dan.
  - Peer Evaluator (5) and Data-Driven Prober (5) carry the most weight, because he is a peer and calls himself "relentlessly data-driven".
  - Case/Strategist (4) and Skeptic (4) follow, then Conversational (2) and Pressure (2).
  - There is no values bank, because no published Northwind values were in hand.
- **Highest-ROI prep:** D1, "no classic sales-ops or quota-setting", asked by the person who owns sales strategy. The ~$400M figure (B1, B2, F2) comes next.
- **Grounding:** the pack never claims the volume targets were quotas, or that she drove the ~$400M or designed partner motions. Where your notes were silent, such as how the $400M was counted or what the partner revenue model took in, the guidance is a slot Priya answers from her real experience.

Say the word and I'll play the Skeptic on D1 as Dan, with follow-ups that react to what Priya says.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy — a peer, both reporting to the same VP. **Format:** one 60-minute conversation. Built from your documents only (JD highlights, a candidate summary, Dan's profile summary, your research note); the web searches were refused, so nothing here comes from the open web.

## How to use this pack

- **Personas are how a question arrives; types are what it scores.** Rehearse both: the same gap question comes as a quiet peer aside, a data probe or a time-boxed challenge.
- **Type key.** VAL = values alignment (none appear: no published Northwind values were in hand). EXP = work-experience deep-dive. JD = a stated role requirement. CO = company and strategy knowledge. CASE = a live problem from the role. Each question carries one tag; dual-purpose calls are explained in the rationale.
- **Guidance is scaffolding, not a script.** Say it in your own words. Anything marked "Answer slot" is an instruction for the interview: answer from your real experience, or say plainly that the practice was not yours.
- **Highest-ROI prep: D1** (no classic quota-setting or sales-ops, asked by the person who owns sales strategy). Rehearse it until it is boring, then B1 and B2 (the ~$400M figure under a self-described data-driven peer).

## Fit snapshot

Candidate sentences are quoted exactly from your notes. Requirements are the JD highlights you supplied, not the full JD text.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market, and the words stay at that scope: "For nine years I was in product strategy and ops at a large consumer-tech company." Answer slot: the JD asks you to own GTM strategy for two new lines, so expect a probe on what in your product strategy and ops work comes closest. Say which piece and what part of it was yours, in your own words; if nothing comes close, say so plainly and say how you would start |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | The quote credits a proposed change with an uplift; it does not show whether analysis of lifecycle stages was involved, and the pack supplies none. Say it at its own scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the land/adopt/expand/renew line makes a probe on how the opportunity was found likely. If you found it by analysis, say what you looked at and how, in your own words; if it came another way, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The quote already names both tools. Lead with it in its own terms, because a named skill beats an adjective. Expect a probe on "independent", since Dan describes himself as data-driven. Answer slot: if you ran an analysis yourself from question to result, name it; if others pulled the data, say so plainly |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a partner-level revenue model used in carrier negotiations, with nothing inspected behind it. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD marks partner-motion experience as required, so expect a probe on the model's role. If you decided what the model took in or how it was used in the negotiations, say which and how you decided; if those were set by others, or you cannot say, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a summary line with nothing inspected behind it. Use the quote's own word, consensus, and the JD's word, influence, stays out of your mouth. Expect a probe on where the orgs disagreed (answer slot at A1) |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | The quote is daily use of AI tools, which is adjacent to AI experience if the JD means building or launching. Say what you use, for what, at that scope. Answer slot: if you built or shipped anything with AI, say what and which part was yours; if you use tools, say so plainly and stay with how you use them |
| F7 | Sales-ops and quota-setting fluency, expected of a Sales Strategy peer — the pack's inference from Dan's title, not a JD highlight | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to quota or sales-ops work |
| F8 | B2B enterprise-software context — the pack's inference from your note that Northwind is B2B data-infrastructure SaaS, not a JD highlight | "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | low | [inferred] | discovery | Your material places nine years in consumer tech and is silent on business customers. The words stay at "consumer-tech company". Selection scaffold (used at D2): pick the nearest work your material carries that involved a business counterparty, say what it was and which part was yours; if nothing comes to mind, say so plainly and say how you would learn the buying side |

## Grounding brief

The only strategy source is your research note; its date was not checked and Northwind is not covered by anything fetched. Learn this vocabulary and flag nothing as stale without checking.

| Item | What your research note says | Provenance | Where it shows up |
|---|---|---|---|
| Company | B2B data-infrastructure SaaS, about 3,000 employees | [grounded] | C1 to C3, D2 |
| Priority 1 | Enterprise expansion | [grounded] | C3, RQ4 |
| Priority 2 | An AI copilot launch called Compass | [grounded] | C1, A5, E2, RQ4 |
| Priority 3 | Reaching profitability | [grounded] | C3, RQ4 |
| Competitive threat | Bundling by a much larger platform vendor | [grounded] | C2, RQ6 |
| Not in the note | Compass's product details, pricing, financials, the two new lines' names | [generic] | The pack uses none of them; never state one in the room as fact |

## Reading the interviewer

Public footprint was not researched (search refused). Everything below is your summary of Dan's profile.

| Observation | Provenance | What it means for the conversation |
|---|---|---|
| Describes himself as "relentlessly data-driven" | [grounded] | Every number you give gets traced to its assumptions. Know what you can and cannot say about how the ~$400M was counted (B1, B2, F2) and say plainly what you do not know |
| Career spine is pricing and monetization roles | [grounded] | His native language is packaging, willingness to pay and unit economics. Expect cases to tilt that way (C2, C3) and flag pricing questions to him rather than answering as if you owned them |
| One early-stage-startup chapter | [grounded] | Builder stories land; expect a probe on working without a team to pull data (follow-up at B3) |
| Peer, same VP | [grounded] | He is pricing what you cost and contribute to his work: seam, credit and target ownership (A1 to A5) |

**Mirror opportunity.** One shared piece of vocabulary: his monetization spine and F4's quote, "built a partner-level revenue model used in carrier negotiations". Talk in revenue-model terms where it is natural. No shared career jump is offered: no row's evidence carries a startup chapter for you.

## Persona table

Weights start from the peer prior (Peer Evaluator plus Data-Driven Prober), then adjust for what Dan's profile says and the one-session loop. Your own words establish the loop (one 60-minute peer conversation), so no archetype fallback applies.

| Persona (bank) | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (A, 5 questions) | Seam, target ownership, credit, "what do you need from me" | Highest. He is a peer reporting to the same VP, so partnership fit is what he is scoring | Reciprocity framing; propose seam principles and test them with him; credit stories that name collaborators |
| Data-Driven Prober (B, 5) | Walks every number and claim to its assumptions | Highest. His own "relentlessly data-driven" line, plus a headline figure of ~$400M in your summary | Know how each figure was counted or say plainly you do not; name the weakest assumption you know of before he does |
| Case / Strategist (C, 4) | A live GTM, bundling or profitability problem | Medium-high. The role is strategy and his pricing spine tilts cases toward packaging and unit economics | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (D, 4) | The quota gap, B2B translation, why leave, weakest area | Medium-high. You stated a gap that sits squarely in his function, and a peer prices that risk first | Rehearse D1 until boring; acknowledge specifically, hold what the quotes carry, plan the ramp |
| Conversational (E, 2) | "Walk me through the journey" and an AI aside | Medium. Often the opener of a peer chat, and AI is a stated plus | A 90-second arc; treat the casual AI question as scored |
| Pressure (F, 2) | Time-boxed "why you" and "how much was you" | Low-medium. Peers rarely stress-test, but one sixty-second challenge is plausible | Pause, restate, anchor in what you stated, hold through two follow-ups |
| Values / Behavioral (no bank) | Scenario probes against published values | Low. No loop source documents a values round and none of Northwind's published values were in hand | Upgrade menu: add the values page and a bank follows |

## Question banks

Session total: 22 questions. Requirement coverage first.

| JD requirement | Covered by |
|---|---|
| own GTM strategy for two new product lines | C1, C2, C3, D3, D4, F1 |
| identify whitespace across land/adopt/expand/renew | B5, C3, B1 (headline figure) |
| run independent analysis in SQL and Tableau | B3, A2, B5 |
| partner-motion design experience required | B4, C4, D4 |
| strong cross-functional influence | A1, A3, A4, A5 |
| AI experience a plus | E2, C1 |
| Not a JD line: quota and sales-ops (F7) | D1, D4, A4, F1 |
| Not a JD line: B2B context (F8) | D2 |

### Bank A — Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between Sales Strategy and Emerging Products GTM, and what happens when we disagree?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Propose seam principles to test with him, not a map you do not have: one owner per number; the case for where the two lines can grow sits with the GTM role, how sales mechanics work sits with Sales Strategy; disagreements get settled on shared data first and go to the shared VP only if data cannot settle them. Your evidence for working across orgs is that one sentence: "I set annual volume targets with cross-org consensus." Answer slot: the JD asks for strong cross-functional influence, so expect a probe on where the orgs disagreed. If they did, say what the disagreement was and which part of resolving it was yours; if there was no real disagreement, or it was not yours to resolve, say so plainly and stay with the targets | F5 is the evidence for the influence requirement, and a peer's first worry is turf, so this is near-certain. JD because it scores the stated influence line; the peer persona supplies the delivery |
| A2 | "What would you need from my team in your first 90 days, and what could you take off my plate?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with the give: the JD asks for independent analysis in SQL and Tableau, so offer to pull your own whitespace analysis rather than queue requests with his team, in your own terms, "skilled in SQL/Tableau". Then the needs, as things to ask for, not assume: access to the data the two lines will be measured on, and time to hear how his team sees them. Do not name systems, dashboards or processes his team has; you do not know them. Answer slot: if he asks for an example, name one analysis you ran yourself; if others pulled the data, say so plainly and say what you would pull first here | The reciprocity question the peer prior predicts. F3 is the only evidence behind the offer, so the offer stays at its scope. JD because it scores whether the hire reduces his load |
| A3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Principle first: name collaborators and what each did before your own part; "we" for context, "I" for contribution. Keep the quote's verbs: "I proposed a store-surface change credited with a ~$400M ARR uplift" — proposed, credited with, not drove or delivered. Answer slot: expect "who else was in it". If others built, shipped or measured it, say what each did and which part was yours; if you cannot separate the parts, say so plainly and stay with the proposal | F2's figure and its "credited" wording invite an attribution probe in collegial dress. EXP because it scores attribution honesty, not a published value |
| A4 | "Who should own the targets for the two new lines, you or me, and how do we decide that?" | JD | [grounded] "set annual volume targets with cross-org consensus" and "No classic sales-ops or quota-setting experience" | Keep the two facts apart and in order: "I set annual volume targets with cross-org consensus" and, plainly, "I don't have classic sales-ops or quota-setting experience." Then propose a split to test with him: the GTM lead owns the case for where each line can grow; Sales Strategy owns how any target becomes quota and capacity, which is where you have no classic experience; the two get reconciled together by consensus, which is the one process your quote names. Do not equate volume targets with quotas | F5 is the nearest evidence and F7 the stated gap, and a peer who owns sales strategy will want to know where you will and will not reach into his turf. JD because the role's GTM ownership line meets his function here |
| A5 | "Compass will need Sales Strategy and your team working as one. What do you want from me before it launches, and what do I get from you?" | CASE | [grounded] your research note names Compass as an AI copilot launch | Ask-and-give, built from principles: you want his read on how sellers are measured and what would change their behavior, and his data on where the current motion converts; you give the segment and whitespace case, and early flags on pricing and packaging questions so he sees them before launch, since pricing is his spine. Agree up front how success is read, with the profitability priority in view. Claim nothing about Compass's product, pricing or timing; your note does not carry them | The cross-functional launch seam on the one named product in your research note. CASE because it is a live problem with no claim about your past; the peer persona supplies the reciprocity |

### Bank B — Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The roughly $400M ARR uplift on your CV: walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say the figure at its scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: four things to cover, each in your own words. How it was counted; what it is sensitive to; which part was yours; who credited it. If you know any of these, say so; if you do not know how it was counted, say that plainly and say what you do know. Never add a method, baseline or model you cannot repeat under a second question | The headline metric on the summary and the first thing a self-described data-driven peer opens. EXP because it scores whether the number survives scrutiny |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot: name, in your own words, the assumption you know of that you would defend least, before he finds it. If you do not know the assumptions behind the figure, say so plainly and say what you would check first. The pack does not name an assumption for you; naming one you cannot explain is worse than an honest "I don't know". The move that earns credibility is volunteering the weak point | The standard second level of the prober, and the move that turns a gotcha into a credibility gain. EXP, a continuation of B1 for drilling |
| B3 | "What is the last analysis you ran yourself from question to result in SQL or Tableau?" | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold, since the quote names a skill and no story: pick one analysis with a named question, data you pulled or built yourself, and a result someone acted on or you recommended. Say what you queried and what the view showed, in plain terms. If no such example comes to mind, say so plainly, then give the nearest thing your material carries or how you would approach it. Expect a pace follow-up, given his startup chapter: with messy data and no one to pull it for you, choose an instance where you did the pulling; if none comes to mind, say so plainly | The JD's "independent analysis" line against a data-driven interviewer. F3 is the only evidence, so the guidance is a scaffold, not a story. JD because it scores a stated requirement |
| B4 | "Walk me through the partner-level revenue model you built for carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: a partner-level revenue model; used in carrier negotiations. Say them in that order. Answer slot: expect probes on inputs, who used it in the room, and what it changed. If you decided what the model took in or how it was used, say which and how you decided; if those were set by others, or you cannot say what it changed, say so plainly and stay with the model you built. Hold two follow-ups by returning to the model, never by adding to it | F4 is the evidence for the partner requirement and the thinnest part of it, so it is probed. EXP because it tests what was actually yours; its subject makes it the JD's partner line in practice |
| B5 | "Say I hand you the land, adopt, expand and renew data for one product line. Where do you look first for whitespace, and what would make you distrust what you find?" | CASE | [grounded] the JD line "identify whitespace across land/adopt/expand/renew" | Structure out loud: state a hypothesis early; define each stage and its unit before hunting (account or contract, what counts as adoption and renewal); look at the gaps between stages first. What makes you distrust it: shifting definitions across periods, small segments, double counting across the two lines, survivors only. Offer to pull it yourself, in the quote's terms, "skilled in SQL/Tableau". This is a method, not a claim about past work: it asserts nothing you did | The JD requirement turned into a live problem, in the data-first register Dan prefers. CASE because it is live reasoning; F2 and F3 are the nearest evidence, referenced but not claimed |

### Bank C — Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the go-to-market plan for Compass. What do you need to know first?" | CASE | [grounded] your research note names Compass as an AI copilot launch | Clarify before structuring. Ask: is it sold alone, attached to the platform, or as an expansion lever for existing enterprise accounts; who buys and who uses; which lifecycle stage it is mainly for; what success means given the profitability priority. Then objective, segments, motion (direct, partner, product-led), pricing and packaging, metrics, risks. State a hypothesis early. Say what you do not know about Compass instead of guessing; your note carries only its name | Compass is a named priority in your note and the likeliest live case. CASE because the interviewer scores structure and clarification; the AI element touches the JD's AI plus |
| C2 | "A much larger platform vendor starts bundling a competing capability for free. What happens to your go-to-market for the new lines?" | CO | [grounded] your research note names bundling by a much larger platform vendor as the main competitive threat | Clarify what the bundle includes and which of the lines it hits. Segment buyers by how much the bundle satisfies them. The pricing lens: free bundling attacks willingness to pay for anything standalone, so the options are to differentiate on depth for the segment the bundle does not satisfy, to package so the line is hard to compare, or to route through partners. Name metrics: win rate, discount depth, attach, expansion. Do not describe Northwind's product strengths; you do not have them | The competitive frame from your note, in the interviewer's pricing language. CO because it tests company-altitude thinking; its delivery is a case |
| C3 | "Profitability is a stated priority. For a new line, how do you decide between spending to land new customers and spending to expand the installed base?" | CASE | [grounded] your research note lists profitability and enterprise expansion as priorities | Frame it as unit economics: payback and cost by motion, expansion cost against landing cost, what each does to the profitability target. Say what data you would want and in what order, and where the answer flips (a new line may have little installed base to expand into). Recommend a sequencing with the condition that would reverse it. This is a method, not a claim about past work | Two of the three stated priorities in tension, in the pricing and unit-economics register of Dan's spine. CASE because it is a trade-off to reason through |
| C4 | "Design the partner motion for one of the new lines. Where do you start?" | CASE | [grounded] the JD line "partner-motion design experience required"; and "built a partner-level revenue model used in carrier negotiations" | Clarify partner type (resell, referral, integration, co-sell), what the partner gets and what Northwind gets, and what a partner would have to believe. Economics before mechanics. Where your experience is closest, say it at scope: "I built a partner-level revenue model used in carrier negotiations", and say the design below is a hypothesis you would test, not something you have run | The JD marks this requirement as required, and F4 is the thin evidence for it. CASE because the live version surfaces the gap without a premise about your past |

### Bank D — Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales-ops or quota-setting work. Why should a Sales Strategy peer trust you with go-to-market for two product lines?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations" | **The highest-ROI rehearsal in the pack.** Acknowledge first, specifically: "I don't have classic sales-ops or quota-setting experience." Hold what the quotes carry, unmerged: "I set annual volume targets with cross-org consensus"; "I built a partner-level revenue model used in carrier negotiations." Let him draw the inference. Level 1, "volume targets are quotas by another name": do not agree and do not argue; restate the sentence at its scope and say where his function owns the part you do not. Level 2, "then what stops you building a plan sales can't carry": concede the risk specifically (you would not know the mechanics yet) and give the plan, never a past: learn how his team sets targets and capacity, test the lines' numbers with him before anyone sees them. Level 3, "what do you do in your first 30 days about it": say the plan again. Do not fold on the core: you are being hired to own the case for where the lines grow | The objection aims where F7 is thin, from the person whose function owns the gap. JD because it scores the hire's fit for the role; deepest rehearsal means most follow-up levels and a limit named before it is asked for |
| D2 | "Your last nine years were in consumer tech. What translates to selling data infrastructure to businesses, and what doesn't?" | EXP | [inferred] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Selection scaffold, per F8: pick the nearest work your material carries that involved a business counterparty, say what it was and which part was yours, at its own scope. Then name what you would need to learn about the buying side, and who you would ask. If nothing comes to mind, say so plainly, then say how you would learn it. Do not describe how enterprise buying works as if you had done it | F8 is the gap a consumer-tech background invites, and the skeptic stem "I don't see X in your background" fits it. EXP because it scores whether your story survives cross-examination |
| D3 | "Why leave nine years at a large consumer-tech company for an emerging-products role here, and why now?" | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Answer slot: give your actual reasons, in your own words, in three beats: what you want more of; what in this role speaks to it, from the JD ("own GTM strategy for two new product lines") and your note's priorities; why the timing. If there is no particular reason for the timing, say so plainly and stay with what draws you to the role. Pull toward, not away from; say nothing about your employer you would not say to them | The why-leave, why-here, why-now probe every skeptic runs, sharper for a peer who may be working with you for years. EXP because it tests motivation consistency over the career story |
| D4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" | Choose the honest answer from your material, which D1 has already rehearsed: "I don't have classic sales-ops or quota-setting experience." Then the ramp plan, as a plan. Keep it consistent with D1; contradictory answers are what a data-driven peer notices. Answer slot: if there is a second area where you are thin, name it in your own words; if the quota gap is the only one you can name, say so and stop | The standard skeptic stem. F7 is the stated gap, and consistency between D1 and D4 is what is being scored. JD because it maps to the requirements directly |

### Bank E — Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "11 years — 2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc in order: two years of strategy consulting at a top firm; nine years in product strategy and ops at a large consumer-tech company. Name your three summary lines at their scope: "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "proposed a store-surface change credited with a ~$400M ARR uplift". End on your own reason for this role. Do not add titles, team sizes or outcomes that these sentences do not carry | The probable opener; a casual question is still scored for economy and fit. EXP because it is a CV walk-through |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Name the tools you use and what for, in your own words: "I use AI tools daily." Answer slot: if you built or shipped anything with AI, say what and which part was yours; if you use tools, say so plainly and stay with how you use them. You can add a curious, honest note about Compass as a product you would want to understand, without claiming anything about it | The JD lists AI as a plus and the casual register hides a scored probe. JD because it maps to that line; F6 is the adjacent evidence |

### Bank F — Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has run quota for a living?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus"; "built a partner-level revenue model used in carrier negotiations"; "skilled in SQL/Tableau" | Pause, restate, then three beats in a minute: the acknowledgment ("I don't have classic sales-ops or quota-setting experience"), then what you do bring from the quotes, then what the role asks for in the JD line "own GTM strategy for two new product lines". Do not claim to beat the comparator; say what the role needs. Hold through two follow-ups; concede specifically that someone with quota experience would know that part sooner | The time-boxed form of D1, for the pressure persona. JD because it scores the role's requirements against the hire |
| F2 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold the position the quote carries: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: say who built, shipped and measured it and which part was yours, in your own words; if you cannot separate the parts, say so plainly. Concede specifically and do not fold: crediting is not yours to claim, the proposal is. Never convert "proposed" into drove, delivered or owned | The pressure stem for the single most attackable figure. EXP because it scores attribution honesty |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "You've moved through pricing and monetization roles and spent a stretch at an early-stage company. What from that stretch do you most want Emerging Products to keep?" | Tied to his own path. It converts the hardest fit probe into a peer conversation and shows you read his profile |
| RQ2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it answers his real concern, whether you add to or reduce his load |
| RQ3 | "Where do Sales Strategy and Emerging Products GTM touch on the two new lines, and where is that line disputed today?" | Surfaces the seam before it bites, and gives A1 and A4 a real answer to anchor on |
| RQ4 | "How will Compass's first year be judged, and how does that sit with the profitability priority?" | Shows you read the stated priorities and are thinking about trade-offs, not features |
| RQ5 | "Which numbers does the VP look at first when judging the new lines, and who owns their definitions?" | Speaks to a data-driven peer's native concern: definitions, ownership and what counts |
| RQ6 | "Where does the bundling threat show up in what you see: discounting, win rates, deal timing?" | A pricing-spine interviewer will have a view, and it tests the CO frame from your note against his data |

## Prohibited claims

What this pack will not coach, and why. Built before the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| The annual volume targets were quotas | Inflated form of F5 | F5's quote at its own scope: "set annual volume targets with cross-org consensus". The limit is the pack's observation: the material says volume targets, not quotas |
| Drove, built, owned or generated the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". The material says proposed and credited, not delivered or owned |
| Designed partner motions | Inflated form of F4 | F4's quote at its own scope: "built a partner-level revenue model used in carrier negotiations". The material says a model, not a motion |
| Owned go-to-market for a product | Inflated form of F1 | F1's quote at its own scope: product strategy and ops at a large consumer-tech company. The material does not say go-to-market |
| Built or shipped AI products | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily". The material says use, not building |

## Sources

**Provided documents:** your message: the role, the JD highlights, the candidate summary, Dan's profile summary, and your research note.

**Searches sent (both refused; permission was not granted):**

- "Northwind Data company values" — refused
- "Dan Kovac Northwind Data Director Sales Strategy" — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Both calls refused. Would have named published values for VAL questions and, only if a values round were detected, a cheat sheet |
| 2. Interview process, role family | skipped | Your words fix the loop (one 60-minute peer conversation), which sets persona priors |
| 3. Strategy and recent news | skipped | Your research note supplies the three priorities and the competitive frame; its currency was not checked |
| 4. Interviewer public footprint | unavailable | Refused. Would have added talks or writing for the interviewer read and RQ1; the read rests on your summary of his profile |
| 5. Representative JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text → the six requirement quotes become the JD's own words and any mid-list requirement gets a question; today only your highlights are quoted
- The CV text → fit-snapshot evidence rests on summary sentences now; real CV lines add beats and can lift medium rows
- Your answers to the slots (what the ~$400M figure counted and which part was yours; what the revenue model took in; what your volume targets involved) → regenerate F1, F2, F4 and F5 and the banks that draw on them
- Dan's own talks or writing, or search permission for his public profile → the interviewer read and RQ1 rest on his public footprint, not just your summary of it
- Northwind's published values page → VAL questions; a cheat sheet follows only if a values round is documented
- The recruiter's prep note → coverage of any pre-declared focus areas or deliverables
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; needs search permission) → a richer strategy brief for C1 to C3 and current context for Compass and the bundling threat
- Prep time available → a prioritized schedule
- A tuesday-dossier.md from a job-underwriter pass → verified evidence and a prohibited-claims list that would bind this pack
