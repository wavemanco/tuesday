I'll read the reference files the skill points to before building the pack.
The references are read. Next I'm building the pack. The recruiter's email sets out all three rounds, so I'm using loop mode: one shared fit snapshot, then a mini-pack for each round.
The prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-8-canned-e272b52e/ashgrove-credit-union_member-experience-lead_interview_pack.md`, Dara. I built it as three rounds, from the recruiter's email: a recruiter screen, then the Head of Member Services, then the two-branch-manager panel (which also scores the four values). It has one shared fit snapshot, a persona table, question bank and reverse questions per round, and a values cheat sheet in the panel round.

- **Quotes:** Every claim about your past is quoted from the four sentences in your message. Where those sentences stop, the pack has an answer slot for you to fill truthfully or decline plainly.
- **Interviewers:** There is no interviewer read, because none are named yet.
- **Research:** I ran no searches. Your pasted values, the recruiter's email, the July 2026 strategy brief and the JD already covered everything a search would have.
- **Highest-ROI prep:** Question D1 is the one most worth rehearsing. It asks what the step up is from one branch's complaints log to the whole process across branches and the contact centre.

Say the word and I'll play the Head of Member Services and run you through D1 with follow-ups.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste your CV, or just its complaints and reporting lines? Several rows rest on four sentences of yours, and your own wording would upgrade them. You can skip this if you'd rather.
2. Has the recruiter said how the 20-minute case runs (written, role-play or discussion)? It would reshape G1 to G3.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead — Ashgrove Credit Union — interview pack for Dara

**Loop:** three rounds on 3 December 2026, as the recruiter's email sets them out. Round 1 is 30 minutes with the recruiter. Round 2 is 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural. Round 3 is 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation, and the panel scores against the four values. Interviewer names are not assigned yet, so there is no interviewer read in this pack.

**Built:** 24 November 2026, nine days before the loop. Loop mode: one shared fit snapshot, then a mini-pack per round with its own persona weights, bank and reverse questions.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: every sentence about your past comes from words you gave me, quoted next to it, and anything past those words is an answer slot for you to fill truthfully or decline plainly. No deliverable was announced, so there is no build section. The 20-minute case is rehearsed live in the round 3 bank (G1 to G3).

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows a published Ashgrove value, not generic virtue |
| EXP | Whether your own account of your work survives follow-up questions |
| JD | Whether you can do the stated job, including the parts you have not done |
| CO | Whether you know Ashgrove's strategy well enough to think at its altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

## Prep triage (nine days)

Do these in this order. Everything else in the pack is insurance.

1. **Day 1:** decide your own answers to A2 to A5 (reason for moving, pay, notice, location). The recruiter round comes first on 3 December and these have only your answer.
2. **Days 1 to 3:** rehearse D1 aloud until it is boring, with B1 as its short version. D1 is the highest-ROI prep in this pack, because the gap between one branch's log and a process spanning branches and the contact centre is the first thing a hiring manager will test.
3. **Days 2 to 5:** choose four real occasions, one per value, for F1 to F4 using the selection scaffolds. If an occasion does not come to mind for a value, the honest branch in each cell is ready.
4. **Days 4 to 7:** say G1 and G2 aloud in structure, then C4 and E1.
5. **Days 8 to 9:** one full run of each round's top questions, then stop.

## The fit snapshot

Evidence cells hold only your own sentences from your message. There is no CV text in this pack, so every quote comes from that message. No JD requirement here is a gate in the sense of a licence, location, pay or schedule term; the years requirement is experience and is graded as such.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not the process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: expect a probe on what followed once a complaint was in the log. If any step after that was yours, say which and how, in your own words; if the log was where your part ended, or there was no such step, say so plainly and stay with the log |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "Never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your sentence says you built the monthly complaints spreadsheet your regional manager uses; it does not show what the spreadsheet counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what it counted. If it counted either, say which and how a figure was counted, in your own words; if it counted something else, or you do not know how part of it was counted, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence says you trained new tellers on the escalation script, not that you coached supervisors, and the words stay at tellers: "trained new tellers on our escalation script." Answer slot: expect a probe on whether any of it reached supervisors. If you ever helped a supervisor through an escalation, say what and how, in your own words; if not, or it was not yours, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show any work with digital teams. Answer slot: if you have worked with anyone on a digital or self-service change for members, say what it was and what part was yours; if you have not, say so plainly and say what you would want to learn first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on length: your sentence states six years, three of them as a branch supervisor. Lead with it in its own terms and stop. It is a line with nothing inspected behind it, so expect a probe on it |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | Your sentence says formal complaints log; it does not show whether external rules governed it. Answer slot: expect a probe on which rules or timeframes the log was kept to. If you worked to any, say what they were and how you kept to them, in your own words; if the log was an internal record without outside rules you worked to, or this was not yours to know, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated absence. Words: "I've never presented to anyone above regional level." Then how you would prepare for a senior audience, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your sentence says spreadsheet; it does not say what tool it was built in or what it did. Answer slot: expect a probe on how it worked. Say what it was built in and what the sheet did, in your own words; if you do not know how part of it worked, or it was not yours, say so plainly and stay with the spreadsheet you built |

## Grounding brief

Facts below are quoted from your summary of the July 2026 strategy brief the recruiter sent. The recruiter sent it to you, so every candidate holds it; bring one item to show you read it, then add a view of your own, and never recite it. The brief is the only strategy source, and its July 2026 date is the age to keep in mind. If anything has moved since, the recruiter is the person to ask.

| Fact | Source | What it likely means in these rooms (the pack's reading) | Provenance |
|---|---|---|---|
| "move 40% of member service to digital channels by 2028" | Strategy brief, July 2026, as you summarised it | Complaints that start in an app are a design signal for the digital teams the JD names. Feeds E1 and G3 | [inferred] |
| "consolidate eight branches into five hubs over 2027" | Same | Complaints open when a branch closes need a named owner. The branch managers on the panel may be living this. Feeds E2, F3 and G3 | [inferred] |
| "launch a small-business lending product in Q1 2027" | Same | Not in the JD, so low priority; mention only if asked | [inferred] |
| "the main competitive pressure is app-only banks" | Same | Members may compare Ashgrove's complaint handling with app-speed service. Feeds A6 and E1 | [inferred] |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B1, D1, G1, H1 |
| "report monthly on complaint volumes and resolution times" | B2, C5 |
| "coach branch supervisors on escalations" | C1, G2, H1 |
| "work with digital teams on self-service journeys" | C3, E1 |
| "4+ years in financial-services customer operations" | A1, B3 |
| "experience handling regulated complaints" | D2, G1 |
| "confident presenting to senior leaders" | C4 |
| "comfortable with Excel reporting" | B2, C5 |

Every published value has a question: Members First, Always (F1), Plain Words (C2, F2), Neighbours, Not Numbers (F3), Own the Fix (F4).

---

# Round 1 — Recruiter screen (30 minutes)

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A) | A friendly walk-through, then pay, notice, location and the reason for moving, all still scored | 6 questions. A recruiter screen's prior is Conversational plus a light Skeptic, the email gives the recruiter the first slot alone ("30 minutes with me"), and the four logistics rows are required in a recruiter screen | A 90-second arc, and your own answer ready for each logistics row |
| Skeptic, light (B) | Quiet knockout checks on the two things the JD names that you have not done, and on the years | 3 questions. The JD names the contact centre and a years floor, and your message states the contact-centre absence | Say the absence plainly, then the plan, and keep the register calm |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey from retail banking to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A 90-second arc in beats the quotes state: six years in retail banking, the last three as a branch supervisor, handling the branch's formal complaints log, training new tellers on the escalation script. Say them in your own words and at those scopes. Answer slot: your reason for moving toward this role. Give your actual reason in your own words; if it is still forming, say that plainly and say what draws you to the role | F6 and F1 are the spine of the arc. A casual opener is still scored on economy, so it is EXP: it tests whether your account hangs together |
| A2 | "Why are you looking to move from your current role?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words, in a sentence or two, and keep it to what is true. If a follow-up comes, return to the same reason rather than adding a new one. Your message does not state a reason, so the pack supplies none | The recruiter's motivation-consistency check; tagged EXP because it tests whether the reason matches what you tell the Head of Member Services (D3) |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first and respond after you hear it. If asked about your current pay, you may decline and return to what you are looking for | Pay is a logistics row in every recruiter screen; JD because it concerns the listed job's terms. Your message states no figure, so the pack supplies none |
| A4 | "What is your notice period, and when could you start?" | JD | [generic] | Logistics slot: give your actual notice period and your earliest start date, in your own words | Notice is a logistics row; JD because it concerns the job's terms. Your message states none, so the pack supplies none |
| A5 | "Is there anything about location or working pattern we should know?" | JD | [generic] | Logistics slot: give your own constraints in your own words, or say there are none. If the recruiter has not said which site the role is based at, ask | Location is a logistics row; the hubs plan makes site a live topic. Your message states none, so the pack supplies none |
| A6 | "What do you know about Ashgrove, and why a credit union?" | CO | [grounded] | Bring one item from the strategy brief to show you read it, then one view of your own from the member's side, for example what moving "40% of member service to digital channels by 2028" changes about how a complaint reaches Ashgrove. Name a value only if it truly drew you, by its official name. Answer slot: why a member-owned organisation, in your own words | The brief is available to every candidate, so reciting it scores as homework and a view of your own scores as judgment. CO because it tests altitude |
| B1 | "The role covers the contact centre as well as branches. How do you see that, coming from branches?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say it plainly first: "Never worked in a contact centre." Then hold what your sentence carries: "I handled the branch's formal complaints log." Then the plan, said as a plan: what you would ask contact-centre colleagues to show you before you changed anything. Never describe contact-centre work as if you had done it | The short version of D1. F2 is the gap the JD names in its first line, so a recruiter screening for it is likely; JD because it scores a stated requirement |
| B2 | "The monthly spreadsheet you built — who uses it, and what does it show?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold the sentence: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what it showed. If it counted either, say which and how a figure was counted, in your own words; if it showed something else, or you do not know how part of it was counted, say so plainly and stay with the spreadsheet you built | F3 and F9 are the reporting evidence and rest on one sentence, so a probe is likely. EXP because it tests what was yours |
| B3 | "The role asks for four years or more in financial-services customer operations. How does yours line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Lead with the sentence in its own terms: six years in retail banking, the last three as a branch supervisor. Say that and stop; let the recruiter decide whether it fits their phrase. Do not relabel branch work in the JD's words | F6 is a years floor, a common knockout in a first screen; JD because it scores the stated requirement |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Could you tell me how the 20-minute case in the panel round runs — written, role-play or discussion — and whether there is anything to prepare?" | The format is un-researchable and shapes how you rehearse G1 to G3 |
| R1.2 | "Which branches are the two panel managers from, and will anyone from the contact centre or the digital team be in the process?" | Names were not yet assigned when the email arrived; the answer tells you who is in the room for F2 and F5 |
| R1.3 | "From what the Head of Member Services has said, what would make someone in this role a success at six months?" | It gives you the manager's own words for round 2 |

---

# Round 2 — Head of Member Services (45 minutes, your future manager, mostly behavioural)

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (C) | "Tell me about a time" prompts mapped to the JD and to the values | 5 questions. The email calls the round "mostly behavioural", which lifts this above the hiring-manager prior of Case plus Skeptic | Pick real occasions in advance; "we" for context, "I" for contribution; where no occasion comes to mind, say so plainly |
| Skeptic (D) | Persistent probing of the gap between one branch's log and the whole process | 3 questions. A manager buying capability derisks gaps, and F1, F2 and F7 are the biggest | Rehearse the objection until it is boring; hold what the quotes carry and concede the rest specifically |
| Case / Strategist (E) | Live problems on the strategy | 2 questions. A manager prior includes Case, but "mostly behavioural" lowers it | Clarify, then structure aloud, using Ashgrove's own words |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4 at its own scope: you trained new tellers on the branch's escalation script. Say that, not "supervisors". Answer slot: the JD's coaching line makes a probe on how it landed likely. If a teller used the script in a real escalation and it mattered, say what happened and what part was yours; if no such moment comes to mind, or it was not yours, say so plainly and stay with training the tellers | F4 is the evidence for the coaching line and the likeliest place for a follow-up. JD because it scores the stated responsibility, and the open prompt is why it is not EXP |
| C2 | "Tell me about a time you had to explain a complaint outcome to a member who was not happy with it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one specific occasion where a member heard an outcome they did not want and your explanation had to work the first time. It needs a named stake, what you said, and what the member did next. Plain Words is the test: if the member needed it explained twice, say what you changed, if you changed anything. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — handling the branch's formal complaints log — or how you would explain it | Plain Words is the published value closest to a complaint outcome. VAL because the story is scored against the value, not against the job |
| C3 | "Tell me about a time you worked with a team outside your own to fix something for members." | JD | [grounded] | Selection scaffold: pick a time you worked with a team outside your own on something that changed how members used a service. It needs a named other team, what you needed from them, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or say how you would approach a digital team on a self-service journey and what you would want to learn first | F5 has no evidence, so the pack does not map a story; the JD's digital-teams line makes it likely. JD because it scores the stated responsibility |
| C4 | "Tell me about the most senior person you have presented to, and how it went." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Start from your own words: "I've never presented to anyone above regional level." Answer slot: expect a probe on your most senior audience. If you presented to anyone at regional level, say who, what and how it went, in your own words; if you did not, say so plainly. Then, said as a plan and never as a past, how you would prepare for a senior audience: lead with the decision you need from them and keep supporting detail ready until asked | F8 is a stated absence, so the honest answer is brief and the plan carries the weight. JD because it scores the stated requirement |
| C5 | "Tell me about something you built that other people relied on in their work." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 and F9: you built the monthly complaints spreadsheet your regional manager uses. Say it at that scope. Answer slot: if a request or a problem led you to build it, say what, in your own words; if it came from no particular request, say so plainly. Then what it showed, as in B2 | The JD's reporting lines make this the natural place to use F3 and F9. EXP because it tests what was actually yours |
| D1 | "You handled one branch's complaints log. This role owns complaints across branches and the contact centre. What is the step up, and how would you take it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Concede specifically: "Never worked in a contact centre." Name the limit before it is asked for: your material shows one branch's log and no contact-centre work, and the words never widen to cover branches generally. Follow-up 1, "So you are not ready": restate the log, concede the contact centre in the same breath, go to the plan. Follow-up 2, "What would you do in the first weeks?": a plan only, listening before changing anything, asking how each channel handles a complaint and where it breaks, as questions rather than findings. Follow-up 3, "What if the contact-centre team will not take advice from a branch person?": agree it is fair and say how you would earn it, by learning their process first. Answer slot: if any step after a complaint went into the log was yours, say which; if not, say so plainly and stay with the log | F1 and F2 are the biggest gap against the JD's opening line, so some form of this question is certain. JD because it scores the headline requirement; the ladder is the deepest in the pack because this is the objection a rehearsed, non-defensive answer changes most |
| D2 | "What external rules, if any, shaped how your branch's formal complaints were handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open with the sentence: "I handled the branch's formal complaints log." Answer slot: the JD's line on regulated complaints makes this probe likely. If any outside rules or timeframes governed the log, say what they were and how you kept to them, in your own words; if it was an internal record without outside rules you worked to, or this was not yours to know, say so plainly and stay with the log | F7 rests on one sentence that does not show whether rules applied. JD because it scores the stated requirement |
| D3 | "You have spent six years in retail banking. Why move to a role that spans branches and the contact centre?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Answer slot: your actual reason, in your own words. It should be the same reason you gave in A2; a second, different reason is what a manager notices. If part of the reason is the contact centre, say so only if it is true | Motivation consistency across rounds is what the Skeptic scores. EXP because it tests whether your account hangs together |
| E1 | "We aim to move 40% of member service to digital channels by 2028. What happens to complaints as that happens, and what would you want to know first?" | CO | [grounded] | Clarify first: what counts toward the 40%, which journeys move first, how a complaint is recorded when it starts in an app. Objective: no complaint loses its owner as channels change. Segment by journey, complaint type and members who cannot or will not use digital. Metrics: volumes and resolution times by channel, with the same definitions across channels. Risk: members pushed to digital who needed an explanation, which is Plain Words. Differentiate from the brief: treat complaints that start in digital journeys as design feedback to the digital team | The brief is common to every candidate, so the divergence is the scoring point. CO because it asks for thinking at Ashgrove's altitude, and CASE delivery |
| E2 | "Eight branches become five hubs over 2027. What happens to complaints that are open when a branch closes, and how would you keep hold of them?" | CASE | [grounded] | Clarify: timeline per branch, which system holds the log, who owns an open complaint at closure. Objective: every open complaint keeps a named owner through cutover, which is Own the Fix. Segment open complaints by age, type and member. Approach: owner named at cutover, a plain-words message to members. Metrics: open complaints by age at closure, resolution times before and after. Risk: members who feel their town's branch vanished, which is Neighbours, Not Numbers | A live problem from the brief that touches two values at once. CASE because it asks for structure on a problem in the role |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "How does complaints reporting reach senior leaders today, and what do they most want from the monthly report?" | It addresses F3 and F8 together and tells you the format before you build in it |
| R2.2 | "How do branches and the contact centre hand a complaint to each other today, and where does it break?" | It shows you are learning the part you have not done (F2) rather than hiding it |
| R2.3 | "What would you want to be true of complaints handling before the first hub opens in 2027?" | It ties the role to the strategy brief in the manager's own terms |
| R2.4 | "In the first month, who should I spend time with, and what would you want me to leave alone while I learn?" | It names the learn-before-changing approach D1 rehearses and invites guidance on it |

---

# Round 3 — Panel of two branch managers (60 minutes, including a 20-minute case; scored against the four values)

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (F) | Scenario probes mapped to the four published values | 5 questions. The email says "The panel is also the values round — they score against the four values" | A real occasion per value where one exists, and the honest branch where none does |
| Case / Strategist (G) | The 20-minute escalation case | 3 questions. The email names "a 20-minute case on a complaint escalation" | Clarify, structure aloud, challenge one premise respectfully |
| Peer Evaluator (H) | "Where is the seam between your role and my branch" | 2 questions. The role coaches branch supervisors (JD), so branch managers are partly stakeholders; this is the pack's reading and is not stated in the email | Principles, not pretended knowledge of their seam; say what you bring them |

A panel blends the top personas of its members; names are not assigned, so the weights are blended and are not per-member. The loop is documented by your own email, so these weights rest on it and not on an archetype.

## Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold: choose a time you decided for the member when it cost the branch something. It needs a named stake, the choice and what happened to the member. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: F1, "I handled the branch's formal complaints log and trained new tellers on our escalation script." |
| Plain Words | If a member needs it explained twice, it was written wrong | F4 carries training on a script, not writing one: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot in F2 asks whether you ever changed any wording |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold: choose a time a number and a branch's place in its town pulled different ways. If no such time comes to mind, say so plainly, then say how you would weigh it. The hubs plan sits behind this value, so ask how it treats towns rather than taking a side |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1 carries the log: "I handled the branch's formal complaints log and trained new tellers on our escalation script." One specific complaint you stayed with is an answer slot in F4 |

## Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one occasion where you chose the member's side when it cost the branch something. It needs a named stake, your choice and what happened to the member. Say "I" for your part and "we" for the context. If no such time comes to mind, say so plainly, then give the nearest thing your material carries — handling the branch's formal complaints log — or how you would decide | Members First, Always is the value's own wording, so it is the likeliest opener of a values round. VAL because the story is scored against the value |
| F2 | "Tell me about a time something you wrote or said to a member had to be explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Your sentence says you trained new tellers on the escalation script; it does not say you wrote or changed it. Answer slot: if you ever rewrote wording, whether a script, a letter or anything member-facing, because it needed explaining twice, say what and why, in your own words; if not, or it was not yours, say so plainly and stay with training the tellers on the script | Plain Words has a precise test, and F4's script is the one piece of member-facing wording in your material. VAL because it is scored against the value |
| F3 | "Tell me about a time you weighed a number against what a branch meant to its town." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold: pick one occasion where a figure and a branch's place in its town pulled different ways. It needs a named stake, your choice and what followed. If no such time comes to mind, say so plainly, then say how you would weigh it. Expect the hubs plan behind this question; do not take a side on it, and ask how it treats towns | F6 shows only that you have worked from branches. Neighbours, Not Numbers is the value the brief's consolidation touches most, so the panel may test it; this is the pack's reading. VAL because the story is scored against the value |
| F4 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 at its own scope: you handled the branch's formal complaints log. Answer slot: pick one specific complaint you stayed with. Say what the problem was, who else had to act, what you did and when it was solved, in your own words, and say plainly which parts were others'. If none comes to mind, or you handed it on, say so plainly and stay with handling the log. Own the Fix: whoever finds the problem keeps hold of it | F1 carries the log, and the value is the one a complaints role most directly claims. VAL because it is scored against the value |
| F5 | "Which of our four values would you find hardest to live up to, and why?" | VAL | [grounded] | Pick the one you would honestly find hardest, name it by its official name, and say why, from your own habits. Then say what you would do about it, as a plan. A pick you cannot explain reads as a dodge | A self-assessment question a values panel uses to test candour. VAL because it scores honesty about the values |
| G1 | "A member has complained about the same issue twice. The branch's record says it is resolved and the contact centre's says it is open. The member arrives at your branch angry and asks for a manager. Walk us through what you do, and what you would fix afterwards." | CASE | [generic] | Say the structure aloud. Clarify: what the complaint is, what was promised, which record is right, and whether a deadline applies to this type of complaint — ask what the clock is, do not assert it. Objective: the member leaves knowing who holds it and when they will hear. Approach: take hold of it now, say plainly what you have and have not yet checked, check both records, name one owner and a date. Metrics: time to resolution, repeat contacts. Risks: promising what you cannot confirm, passing the member between channels. Afterwards: why the two records disagreed | A practice case the pack wrote from the JD's escalation and contact-centre lines; the panel's own case is unknown. CASE because it asks for structure on a live problem, and the pack labels it a pattern |
| G2 | "A branch supervisor wants to handle an escalation themselves and does not want you to take it over. What do you do?" | CASE | [generic] | Clarify: what is at stake for the member and what the deadline is. Objective: the member's complaint is solved and the supervisor's capability grows. Approach: ask them to talk it through first; agree who holds what; step in only if the member or the deadline is at risk; debrief afterwards. Risks: taking over teaches nothing, leaving it risks the member. Metrics: resolution time, whether the supervisor handles the next one alone | A practice case from the JD's coaching line, written for a panel of managers whose supervisors this role would coach. CASE because it tests reasoning in the role |
| G3 | "Some months after a hub opens, complaint volumes there rise. What would you look at, and what would you tell us?" | CASE | [grounded] | Clarify: volume or rate, which complaint types, which former branches' members, which channel. Objective: a fair read before a conclusion. Segment by type and by origin. Make sure the same definitions of volume and resolution time apply before and after. Tell the panel what you know, what you do not, and what you would check next, in plain words | A live problem drawn from the hubs plan. CASE because it tests reporting judgement, which the role owns monthly |
| H1 | "Our supervisors will look to you on escalations. Where is the line between what we handle in branch and what comes to you, and what happens when we disagree?" | CASE | [generic] | Propose principles and do not pretend to know their seam: the member stays with whoever found the problem until it is explicitly handed over, which is Own the Fix; agree handoff points with the branch managers first; when you disagree, the member comes first and you review together afterwards. Say what you would bring them: a monthly view of what is coming up in their branch | A peer-style question, since the panel's managers own the branches the role coaches. CASE because it tests reasoning about a seam |
| H2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Answer as a principle first: "we" for context, "I" for contribution, and name others' parts. If asked for an instance, pick a real occasion where work spanned teams and say which part was yours; if none comes to mind, say so plainly, then say how you would handle it | A standard peer probe on collaboration. EXP because it tests attribution honesty |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "Which kinds of complaint come back to your branch most, and where do supervisors feel least supported on escalations?" | It asks the panel about their branches, in the terms the role is built around |
| R3.2 | Reciprocity: "What could someone in this role do in their first month that would genuinely help your supervisors?" | It turns the panel from assessors into the people the role serves |
| R3.3 | "How are your teams and members hearing about the move to hubs, and what would you want this role to do about complaints that come out of it?" | It meets Neighbours, Not Numbers head on and tests the strategy brief against the panel's own view |
| R3.4 | "Where has Own the Fix been hardest to live up to here?" | It shows you take the value as practice and not as a slogan |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says one branch's log, not the process across branches. F1's slot stays inside the log |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment your sentence gives: "Never worked in a contact centre." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script." The limit is the pack's observation: your material says tellers, not supervisors |
| Reported complaint volumes and resolution times to senior leaders | Inflated form of F3, and a negative you stated, F8 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." F8's own words: "I've never presented to anyone above regional level." |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says formal log, not whether outside rules governed it |
| Presents to senior leaders | Negative you stated, F8 | The plain acknowledgment your sentence gives: "I've never presented to anyone above regional level." Then the plan, never a past |

## Sources

Provided documents: the JD you pasted; the values text you copied this morning from ashgrovecu.org/about/values (a URL named as the source of pasted text, not a link read); the recruiter's email on the three rounds; your summary of the July 2026 strategy brief the recruiter sent; your own background in your message. No CV text was provided. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values text supplies all four value names and their meanings, so the values cheat sheet and F1 to F5 rest on it |
| 2. Ashgrove interview process, member services roles | skipped | The recruiter's email names the three rounds, who runs each and what each holds, so the loop and persona weights rest on it |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief supplies current priorities, so E1, E2 and G3 rest on it |
| 4. Interviewer names | n/a | No names were assigned, so there was no query to form; the interviewer read is absent |
| 5. A representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names for the Head of Member Services and the two branch managers → a public-footprint read, persona weights tuned per person, and a reverse question tied to one of their own career paths
- Your CV text, or the complaints and reporting lines from it → F1 to F9 currently rest on four sentences of yours, and your own wording would replace the inferred bridges. For F3 and F9 the artifact that raises confidence is the spreadsheet itself, or a redacted copy or its column headings, and for F1 and F7 a sample entry's headings from the complaints log
- Your answers to the slots in F1, F3, F4, F5, F7 and F9, said outside a drill → each answer enters the snapshot as a quote and the bridges and guidance for those rows regenerate
- The recruiter's word on the 20-minute case format, written, role-play or discussion → G1 to G3 restructure around it; one email to the recruiter
- The full text of the July 2026 strategy brief → E1, E2 and G3 move from four summarised lines to quoted ones, and the brief's age can be checked against anything newer
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) covering recent Ashgrove news, interviewer talks and loop reports → CO and CASE questions move from reasoning on four lines to sourced; say the word and I will run it
- A `tuesday-dossier.md` from an earlier evaluation → it would carry confirmed evidence and flagged limits into this pack; none is needed to use it
