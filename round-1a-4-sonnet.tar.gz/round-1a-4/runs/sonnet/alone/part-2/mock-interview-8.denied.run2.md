I'll read the reference files the skill points to before writing anything.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-8-denied-7d689534/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as a loop, with a mini-pack for each of the three rounds on 3 December. Each has its own persona weights, question bank and reverse questions. No interviewer names were given, so there is no interviewer read. I ran no web searches, because your pasted values, the recruiter's email, the strategy brief and the JD already covered everything a search would have fed.

The question the pack names as your highest-ROI prep is D2, in round 2. It asks where your experience stops: one branch's complaints log against the whole process across branches and the contact centre.

- **Drill:** say the word and I'll play the Head of Member Services on D2, or the panel on H1, the escalation case.
- **Dossier:** I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
- **Word version:** I can convert the pack to a Word document if you'd like one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead — Ashgrove Credit Union — interview pack (loop mode)

**Candidate:** Dara
**Date of the loop:** 3 December 2026, three rounds
**Round 1:** 30 minutes with the recruiter (name not given)
**Round 2:** 45 minutes with the Head of Member Services, who would be your manager (name not given), mostly behavioural
**Round 3:** 60 minutes with a panel of two branch managers (names not given), including a 20-minute case on a complaint escalation. The panel is also the values round and scores against the four values.
**Built:** 24 November 2026, from the JD, the values text, the recruiter's email, the strategy brief as you relayed it, and your background as you described it. This is a first version, not a regeneration.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each round has its own persona weights, its own question bank and its own reverse questions. The fit snapshot, the grounding brief, the prohibited claims and the sources are shared by all three rounds.
- **Type key.**
  - VAL: whether past behaviour shows the company's published values.
  - EXP: whether the claims you make about your own work survive follow-up.
  - JD: whether you can do the listed job, gaps included.
  - CO: whether you know the company and its strategy.
  - CASE: a live problem, scored on structure and reasoning.
- **Guidance is scaffolding, not a script.** Say it in your own words. Every claim about your own past rests on a sentence you wrote in your message, quoted in the Provenance column.
- **An answer slot is an instruction for the interview, not a question for me.** It tells you what to say if something is true and what to say if it is not. Both branches are fine answers, and the honest branch is never a confession.

## Prep triage

Sized to the nine days from 24 November to 3 December. If you have only a few hours, do items 1 and 2 and stop.

| Order | When | Do this | Where |
|---|---|---|---|
| 1 | 24 to 26 November | Rehearse the contact-centre and scope objection aloud until it is boring | D2, then B1 and D1 |
| 2 | 24 to 28 November | Settle your own facts for the slots: what the monthly spreadsheet counted, which tool it was, what governed the formal complaints, and your notice period, pay expectation, reason for looking and location limits | F3, F7, F9; A3 to A6 |
| 3 | 29 November to 1 December | Choose one real story per value, then run the 20-minute case aloud against a timer | G1 to G4, H1 to H3 |
| 4 | 1 to 2 December | Rehearse the manager round: behavioural stories, the monthly report, the digital question and presenting to leaders | C1 to C3, E1, E2, F1, F2, D3 |
| 5 | 2 December | One live drill on D2 or H1, then read the grounding brief once and choose your reverse questions | Drill, the grounding brief, reverse questions |

Everything else is insurance.

## Fit snapshot (shared)

No requirement in the JD is a gate. The only year-count requirement is length of experience, which is graded like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, with nothing inspected behind it. The words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat before and after the log likely. If any step before or after the log was yours, say which and what you did, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log |
| F2 | "branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap you stated, and wording cannot close it. Words: "Never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The sentence shows a monthly complaints spreadsheet that a regional manager uses. It does not show what the spreadsheet counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what it tracked. If it counted either, say which and how, in your own words; if it counted neither, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says tellers and a script, not supervisors and coaching. The words stay there: you trained new tellers on your escalation script. Answer slot: the JD says supervisors, so expect a probe on whether you have guided anyone at supervisor level. If you have, say how, in your own words; if you have not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing about digital work. Answer slot: if you have worked with a digital, product or app team, on anything, say what the work was and what part was yours; if you have not, say so plainly and say what you would ask them first, as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length, but a self-reported line with nothing inspected behind it, so expect a probe on it. Lead with the quote's own terms: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | The sentence says formal complaints. It does not show whether outside rules or deadlines governed them. Answer slot: the JD says regulated, so expect a probe on what governed them. If outside rules or timescales applied, say which, in your own words; if only the branch's own process applied, or you do not know what governed them, say so plainly and stay with the formal log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past. No claim of comfort the material does not carry |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, not which tool. Answer slot: if it was Excel, say so and say what the monthly file did, in your own words; if it was another tool, or part of it is not something you would call yourself comfortable with, say so plainly and stay with the spreadsheet you built |

## Grounding brief (shared)

The strategy brief is Ashgrove's July 2026 document, sent by the recruiter and relayed in your message. I have the four points you gave me, not the full text. Use the company's own vocabulary: the JD and the values text say "members", not customers.

| # | What it says | Provenance | How it shows up in this pack |
|---|---|---|---|
| GB1 | "move 40% of member service to digital channels by 2028" — your message, from the brief | [grounded] | F1 and F2 in round 2; reverse question R6 |
| GB2 | "consolidate eight branches into five hubs over 2027" — your message, from the brief | [grounded] | J1 and R9 in round 3, where the panel is branch managers; G3 sits next to it |
| GB3 | "launch a small-business lending product in Q1 2027" — your message, from the brief | [grounded] | Reverse question R5; a new product is a new source of complaints |
| GB4 | "the main competitive pressure is app-only banks" — your message, from the brief | [grounded] | F1 and H1 |
| GB5 | "member-owned, about 900 staff" — JD | [grounded] | A2 |

---

# Round 1 — recruiter screen, 30 minutes

### Persona weights

The recruiter's email is a loop source: it names each round and who runs it. The weights below follow the recruiter-screen prior, adjusted by what the JD makes likely.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport | Friendly, unstructured; logistics asked casually | High. A recruiter screen is mostly this register, and pay, notice, location and the reason for leaving are asked in it | Build A1 as a 90-second arc from its quote only; treat A3 to A6 as scored |
| Skeptic (light) | Knockout checks on the gaps, in a friendly voice | Medium. The JD's contact-centre line meets F2, and its regulated-complaints line meets F7 | Say the stated limit plainly, give the plan, move on: B1, B2 |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey. How did you get from where you started to where you are now?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Story-mapped on F6: the six years in retail banking and the last three as a branch supervisor, which are the beats the quote states. Tell them in your own words in about 90 seconds. Close with your own reason for wanting this role, which only you can supply | F6 is the evidence for the experience requirement. EXP because an opening biography is scored for economy and for whether it matches the CV line |
| A2 | "What drew you to Ashgrove?" | CO | [grounded] | Choose one thing you actually care about from the grounding brief or the values, such as GB5's member ownership or a value by name, and say in your own words why it matters to you. Do not recite the values page, since every prepared candidate can. If nothing specific draws you yet, say what you have found so far and what you want to learn | A casual motivation question that is still scored. CO because it tests homework depth; the guidance makes no claim about your past |
| A3 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot. Give your actual reason in your own words, in a sentence or two. None was given to me, so none is supplied here | A reason-for-leaving question is asked in every recruiter screen. EXP because it tests consistency with the rest of your story |
| A4 | "What are you looking for salary-wise?" | JD | [generic] | Logistics slot. Give your own number, or ask for the role's band first; either is a normal answer. If asked what you earn now, you may redirect to the role's band, with no figure | The recruiter screen checks that the job's terms fit. JD because the pay belongs to the listed job |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period | Start-date fit is checked here and nowhere else. JD because notice is a term of taking the listed job |
| A6 | "Is there anything about location, or getting between sites, that we should know?" | JD | [generic] | Logistics slot. State your own location limits, or say there are none | The JD covers branches and a contact centre, and GB2 may change the site pattern, so the question is likely. JD because location is a term of the listed job |
| B1 | "The role covers the contact centre as well as the branches. How does your background fit that?" | JD | [grounded] "Never worked in a contact centre", "I handled the branch's formal complaints log" | Concede first and plainly, in your own words: "Never worked in a contact centre." Then stay with what the second quote carries: you handled the branch's formal complaints log. Close with how you would learn the contact centre, said as a plan. Keep it under a minute; a recruiter wants a clean answer, not a defence | F2 is the stated gap and F1 is the nearest material. JD because it is the first place the contact-centre line gets tested |
| B2 | "Tell me about the complaints you handled — what kind were they?" | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F7 as far as the quote goes: you handled the branch's formal complaints log. Answer slot: the JD says regulated, so expect a probe on what governed them. If outside rules or timescales applied, say which, in your own words; if only the branch's own process applied, or you do not know what governed them, say so plainly and stay with the formal log | F7 is the requirement most likely to be a knockout. EXP because it tests what the logged complaints actually were |

### Reverse questions — round 1

| # | Question | Why it lands |
|---|---|---|
| R1 | "What happens after the panel on 3 December — who decides and how quickly?" | It shows you are planning, and it settles the timeline you will need for notice |
| R2 | "Is there anything in my background you would want me to address before I meet the Head of Member Services?" | It surfaces an objection while you can still prepare for it, and it gives the recruiter a way to help you |

---

# Round 2 — Head of Member Services, 45 minutes

### Persona weights

The email says this person would be your manager and the round is mostly behavioural.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" prompts, STAR-shaped | High. The email says mostly behavioural | One story per prompt; "we" for context, "I" for what you did; where no story comes to mind, use the honest branch |
| Skeptic | Quiet, persistent probing of the gaps | High. The hiring-manager prior is to derisk gaps, and this person would own the outcome of a weak hire | Rehearse D2 until it is boring; hold the quote, concede the limit, give a plan |
| Data-Driven Prober | Asks what the monthly spreadsheet counted | Medium. The role reports monthly, and F3 and F9 rest on one sentence | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Case / Strategist | Strategy questions at the company's altitude | Low. The hiring-manager prior is Case, but the email says mostly behavioural, so one strategy question is enough | F1 only: clarify, objective, approach, metrics, risks |

### Question bank

**D2 is the highest-ROI prep in this pack.** The scope jump from one branch's log to the whole process across branches and the contact centre is where the material is thinnest, and it will be asked in some form.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, because no quoted sentence carries a story with an ending. Pick a case you stayed with from first report to resolution: it needs what the problem was, what you yourself did, and how it ended. If no such case comes to mind, say so plainly, then give the nearest thing your material carries, that you handled the branch's formal complaints log, or how you would handle it | Own the Fix is the value this manager is likeliest to test in person. VAL because it scores a published value, not generic virtue |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold. Choose a time the hard truth actually landed and the relationship was intact afterwards; name the stake, what you said, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The standard behavioural stem for a manager who will be the one told hard truths. VAL because it scores behaviour under pressure toward a senior |
| C3 | "Tell me about a time you taught or coached someone and it did not land the first time." | JD | [grounded] "trained new tellers on our escalation script" | Selection scaffold, with the nearest material named: you trained new tellers on your escalation script. Pick a time the training did not land at first; name the person, what you changed, and how it ended. If no such time comes to mind, say so plainly and stay with the tellers. Answer slot: if you have guided anyone at supervisor level, say how; if not, say so | F4 is the coaching requirement and the material stops at tellers. JD because the coaching of supervisors is a listed duty |
| D1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre", "I've never presented to anyone above regional level" | Your material carries two stated limits, so choose the one that is true for you and say it plainly: "Never worked in a contact centre" or "I've never presented to anyone above regional level". Then say how you would close it, as a plan. Naming a limit before they do is the credibility move. Answer slot: if digital work is a weaker area for you, say so | F2 and F8 are the stated gaps, and F5 is silence. JD because it scores honest self-assessment against the listed duties |
| D2 | "The role owns the complaints process end to end across branches and the contact centre. Where does your experience stop?" | JD | [grounded] "I handled the branch's formal complaints log", "Never worked in a contact centre" | Hold what the quote carries: "I handled the branch's formal complaints log." Concede the limit before it is pressed: "Never worked in a contact centre." Follow-up 1, how would you take that on: say it as a plan in your own words, who you would learn from and what you would look at first, with no past claimed. Follow-up 2, one branch's log is a long way from the whole process: agree it is a narrower scope and return to the log. Answer slot: if any step beyond the log was yours, say which and what you did; if there was none, or it was not yours, say so plainly. Follow-up 3, what worries you most: name the one worry you actually hold. Never add to what was yours | F1 and F2 are the biggest gap and the most predictable objection. JD because it scores whether you can do the listed job, gaps included; the three follow-up levels are what make it the deepest rehearsal |
| D3 | "The JD asks for confidence presenting to senior leaders. Where are you on that?" | JD | [grounded] "I've never presented to anyone above regional level" | Say it plainly: "I've never presented to anyone above regional level." Claim no comfort the material does not carry. Then say what you would do to get ready for the first such presentation, as a plan in your own words | F8 is a stated gap. JD because it is a listed requirement, and the answer to it is a plan, not a story |
| E1 | "Walk me through the monthly complaints spreadsheet — what did it track?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the sentence says: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: the JD names volumes and resolution times, so expect a probe on what it tracked. If it counted either, say which and how each was counted, and name the assumption behind a figure that you would defend least; if it counted neither, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet | F3 is the evidence for the monthly reporting duty and rests on one sentence. EXP because it tests what you actually built |
| E2 | "Which tool did you build it in, and how would you describe your Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if it was Excel, say so and say what the monthly file did, in your own words; if it was another tool, or part of it is not something you would call yourself comfortable with, say so plainly and stay with the spreadsheet you built | F9 is graded on the word spreadsheet alone. JD because Excel reporting is a listed requirement |
| F1 | "We want 40% of member service on digital channels by 2028. What does that mean for how members complain, and for this role?" | CO | [grounded] | Think aloud. Clarify first: which complaint routes are digital today, and what counts as a digital complaint. Objective: members get a fix without having to explain twice. Then metrics in the JD's own terms, complaint volumes and resolution times by channel, and risks to name, such as members who still need a person. GB4's app-only banks are the comparison members will make. The guidance makes no claim about your past | GB1 is the strategic change this role sits inside. CO because it tests whether you can think at the company's altitude |
| F2 | "What experience do you have working with digital teams on self-service?" | JD | [grounded] | Answer slot: if you have worked with a digital, product or app team, on anything, say what the work was and what part was yours; if you have not, say so plainly, then say what you would ask them first, as a plan | F5 is silence in your material, and the JD names the duty. JD because digital teams are a listed duty |

### Reverse questions — round 2

| # | Question | Why it lands |
|---|---|---|
| R3 | "What would a good first ninety days look like for whoever holds this role?" | It shows you are planning to deliver, and it tells you how this manager will judge the first quarter |
| R4 | "How do complaints move between the branches and the contact centre today, and what would you most like to change?" | It goes straight at the end-to-end duty in the JD and lets the manager describe the problem in their own words |
| R5 | "Who will own complaints from the small-business lending product launching in Q1 2027?" | GB3 makes a new product a new source of complaints, so this shows you think about the role's near future |
| R6 | "How will you judge whether the 40% digital target is working for members who complain?" | It ties the JD's monthly reporting to GB1 and invites the manager to say what they would measure |

---

# Round 3 — panel of two branch managers, 60 minutes, with a 20-minute case

### Persona weights

The email says the panel is also the values round and includes a 20-minute case. Names are not assigned, so the panel gets one blend instead of one persona per member.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Questions mapped to the four published values | High. The email says they score against the four values | One real story per value; G1 to G4 |
| Case / Strategist | A live complaint escalation, 20 of the 60 minutes | High. The email names the case and its length | Clarify before structuring; think aloud; challenge one premise respectfully; H1 to H3 |
| Peer Evaluator | "What would you need from us?" and seam questions | Medium. The JD has you coaching branch supervisors, who report into branch managers, so the panel is pricing what you cost their branches. This is my reading, not a fact from the email | Reciprocity first: what you bring their branches; propose seam principles, not a pretended seam |
| Case / Strategist (company level) | One strategy question about GB2 | Low. Branch managers may be directly affected by the hub plan, which the material does not show | J1 only; do not take a position on which branches |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our value is Members First, Always: we decide from the member's side of the counter. Tell me about a time you did that." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Choose a time a member's position was not the easiest one for the branch; name the member's side, what you decided yourself, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, that you handled the branch's formal complaints log, or how you would decide | First of the four values; a published value with a mapped scaffold is required for each. VAL because the panel scores against the value by name |
| G2 | "Our value is Plain Words: if a member needs it explained twice, we wrote it wrong. Tell me about something you made clearer for members or colleagues." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold. Choose a time you made something clearer: what was unclear, what you changed, and how you knew it worked. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, that you trained new tellers on your escalation script, or how you would approach it | Plain Words is the value closest to the JD's complaints-process duty. VAL because it scores a published value |
| G3 | "Our value is Neighbours, Not Numbers: every branch is part of its town. Tell me about a time you worked with a branch's local situation in mind." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold. Choose a time the branch's own town or members shaped what you did; name the situation, your part, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, that you spent the last three years as a branch supervisor, or how you would approach it. Leave the hub plan for J1 | This value sits beside GB2, and branch managers will hear it personally. VAL because it scores a published value |
| G4 | "Our value is Own the Fix: whoever finds the problem keeps hold of it until it is solved. Tell me about a time the fix depended on people outside your own team." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold. Choose a case that crossed a team or branch boundary; name who else was involved, how you stayed on it, and how it ended. If no such case comes to mind, say so plainly, then give the nearest thing your material carries, that you handled the branch's formal complaints log, or how you would keep hold of it | The JD's across-branches-and-contact-centre line makes handovers the place this value is tested. VAL because it scores a published value |
| H1 | "A member has complained three times about the same fee error in three weeks. The branch says it is resolved; the contact centre says it is open; the member says they will move to an app-only bank. You have twenty minutes. What do you do?" | CASE | [generic] | This is an example shape; the real case is not known yet. Clarify first: what the member was told, what the log shows, and what rules or timescales apply to the complaint. Objective: one owner, the member's problem fixed, and the member told in plain words. Then segment, branch record against contact-centre record; approach; metrics in the JD's terms; risks. Challenge one premise respectfully, such as why two records disagree. The guidance makes no claim about your past | The panel's 20-minute escalation case. CASE because it scores structure and the use of the company's own vocabulary. GB4 is why the app-only bank detail is plausible |
| H2 | "A branch supervisor escalates a complaint to you without having logged it. What do you do, and what do you say to them?" | CASE | [grounded] "trained new tellers on our escalation script" | Clarify first: what happened, and what the member needs now. Fix the member's problem before the record. Then coach: ask the supervisor how they see it, agree what to log, and point to the escalation script you trained tellers on, the nearest material your quotes carry. Answer slot: if you have guided anyone at supervisor level, say how; if not, say so plainly and stay with the tellers | F4 is the coaching duty. CASE because it is a live problem from the role, with JD delivery |
| H3 | "Your monthly report shows one branch's resolution times at twice the others. What do you do before you talk to the branch manager?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Check how the figure was counted before anyone is blamed, then name the assumption behind it that you would defend least, in your own words. If you built it, say so: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if you know how resolution times were counted, say so; if you do not, say so plainly. Then the branch conversation: ask first, and keep the town in mind | F3 and F9 are the reporting evidence, and a panel of branch managers is the audience for a number about a branch. CASE because it is a live reporting problem |
| I1 | "Our supervisors are busy. How would you coach them on escalations without adding to the load?" | JD | [grounded] "trained new tellers on our escalation script" | Reciprocity first: what you would bring a branch, then what you would need from it. Propose principles, not a fixed seam: ask what already works, agree who owns the member's problem at each handover. Nearest material: you trained new tellers on your escalation script. Answer slot: if you have guided anyone at supervisor level, say how; if not, say so plainly | F4 is the coaching duty. JD because it is a listed duty, asked by the people whose supervisors it affects |
| I2 | "Where is the line between your role and a branch manager's, and what happens when we disagree about a complaint?" | JD | [generic] | Seam principles, not a pretended seam: say you would agree it with them early. For disagreement, show spine and tact together: state your view, ask for theirs, and agree who decides before the next case. The guidance makes no claim about your past | A peer-style seam question from people who will work beside the role. JD because the answer scores partnership fit |
| J1 | "Ashgrove plans to consolidate eight branches into five hubs over 2027. What should that mean for how complaints are handled?" | CO | [grounded] | Do not take a position on which branches. Ask what the panel is seeing from their side. Then name two things to watch: complaint handovers when a branch's members move to a hub (Own the Fix), and how a town's complaints are visible in the data when its branch has changed (Neighbours, Not Numbers). The guidance makes no claim about your past | GB2 is the biggest structural change in the brief and the panel may be directly affected by it. CO because it tests altitude. The brief you gave me does not say which branches are affected |

### Reverse questions — round 3

| # | Question | Why it lands |
|---|---|---|
| R7 | "What could a new person in this role do in their first month that would genuinely help your branches?" | A reciprocity question for people who will work beside the role. It reverses the frame from what you need to what you bring |
| R8 | "How do supervisors in your branches handle an escalation today, and where would coaching help most?" | It turns the JD's coaching duty into their own description of the problem |
| R9 | "How do you see the move to five hubs changing complaint handling in your area?" | GB2 is the live change; it lets the panel speak first and shows you see it |
| R10 | "Which of the four values do you see tested hardest in your branch?" | The panel scores against the values, so asking which one bites shows you take them seriously |

---

# Values cheat sheet (round 3)

A values-style round is documented by the recruiter's email: "The panel is also the values round — they score against the four values." The four values below are quoted from the values text you pasted. No quoted sentence of yours carries a complete story for any value, so each is a scaffold, and the real prep is choosing one true story per value.

| Value (official name) | Working meaning (paraphrased) | Your mapped story | Provenance |
|---|---|---|---|
| Members First, Always | Decisions start from the member's position | Selection scaffold on G1, nearest material F1: "I handled the branch's formal complaints log". Pick a time the member's side was not the easy one; if none comes to mind, say so plainly and say how you would decide | [grounded] |
| Plain Words | If a member has to ask twice, the fault is in the wording | Selection scaffold on G2, nearest material F4: "trained new tellers on our escalation script". Pick a time you made something clearer; if none comes to mind, say so plainly and say how you would approach it | [grounded] |
| Neighbours, Not Numbers | Each branch belongs to its town, not to a total | Selection scaffold on G3, nearest material F6: "6 years in retail banking, the last 3 as a branch supervisor". Pick a time local context shaped what you did; if none comes to mind, say so plainly and say how you would approach it | [grounded] |
| Own the Fix | The person who finds a problem stays with it until it is solved | Selection scaffold on G4 and C1, nearest material F1: "I handled the branch's formal complaints log". Pick a case you stayed with from first report to resolution; if none comes to mind, say so plainly and say how you would keep hold of it | [grounded] |

---

# Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B1, D2, H1, J1 |
| "report monthly on complaint volumes and resolution times" | E1, H3, F1 |
| "coach branch supervisors on escalations" | C3, H2, I1 |
| "work with digital teams on self-service journeys" | F2, F1 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | B2, H1 |
| "confident presenting to senior leaders" | D3 |
| "comfortable with Excel reporting" | E2 |

## Prohibited claims

What this pack will not coach, and the honest form of each. The limits are the pack's own observations, not words for you to say, except where you stated the negative yourself.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log". Your material says the branch's log, not the process end to end. D2's slot stays inside the log |
| Has contact-centre experience | Negative you stated, F2 | Your own words: "Never worked in a contact centre." No slot |
| Coached or managed branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script". Your material says tellers and a script. C3, H2 and I1 keep the slot to whether you have guided anyone at supervisor level |
| Reported on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses". Your material says you built the spreadsheet, and not what it counted or who presented it. E1's slot asks only what it tracked |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log". Your material says formal, not regulated. B2's slot asks only what governed them |
| Presented to senior leaders | Negative you stated, F8 | Your own words: "I've never presented to anyone above regional level." No slot |
| Advanced Excel skill | Inflated form of F9 | F9's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses". Your material says spreadsheet. E2's slot asks which tool |

## Sources

**Provided documents.**
- The JD as pasted in your message.
- The values text pasted in your message, which you copied on 24 November 2026 from ashgrovecu.org/about/values. That page was named as where the text came from, so it was not fetched.
- The recruiter's email about the process, as pasted.
- The 2026 strategy brief published in July 2026, as the four points you relayed. I did not read the brief itself.
- Your background as described in your message. No CV text was provided.
- No `tuesday-dossier.md` was present, so no dossier sections were consumed.

**Searches and fetches sent.** None.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the values cheat sheet and G1 to G4. It was not re-checked against the live page |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email names all three rounds, who runs each, and what each holds, which fixes the persona weights for every round |
| 3. `Ashgrove Credit Union strategy` | skipped | The July 2026 brief you relayed, under six months old, fixes the grounding brief and the CO questions F1 and J1 |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No interviewer names were given, so there was no query to form. The interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions |

## Upgrade menu

- Your CV text → the rows resting on one sentence of yours (F1, F3, F4, F7, F9) may gain more quotes, and some selection scaffolds in C1 to C3 and G1 to G4 could become story-mapped answers
- An anonymised sample of the monthly complaints spreadsheet, such as its column headings → F3 and F9 could move from medium to high, and E1 and E2 would become defend-the-detail answers instead of slots
- Your notice period, pay expectation, reason for looking and any location limits → A3 to A6 would carry your own words instead of instructions
- Names and roles of the Head of Member Services and the two branch managers → an interviewer read, persona weights per person, and a reverse question tied to each person's path
- The recruiter's answers to two questions, whether the 20-minute case gives you material in advance and whether you present your answer, plus whether each of the four values is scored separately → H1 to H3 and G1 to G4 would be tailored to the real format
- A deeper research pass, offered once — up to 6 more searches and 2 more fetches, several more minutes → a fuller strategy brief, interviewer public footprint, loop reports for this role family and recent org context, which would sharpen F1 and J1 and the reverse questions
- A `tuesday-dossier.md` with verified evidence from an earlier review → medium-confidence rows could be upgraded, and its prohibited claims would replace the ones built locally here
