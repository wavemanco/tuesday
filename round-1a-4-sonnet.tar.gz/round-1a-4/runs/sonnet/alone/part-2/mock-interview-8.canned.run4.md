I'll read the reference files the skill points to before building the pack.
Only the provenance labels use brackets. One rationale cell mentions a label in backticks, so I'll plainly reword it.
Dara, your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-8-canned-ef04d8a8/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it in loop mode, with a mini-pack per round. Each round has its own persona weights, question bank and reverse questions. The values cheat sheet sits with round 3, since the panel scores against the four values. It runs to 29 questions across the three rounds.

- **Sources:** I built it only from what you pasted: your background, the JD, the values, the recruiter's email and the four strategy points. I ran no web searches. There's no CV, so every "your CV" line is really your message.
- **Highest-ROI prep:** B3 in round 2. It asks "your background is one branch's log, so why should you own the whole process?" The pack coaches you to name the contact-centre limit first. You then hold on what you actually said and answer follow-ups with a plan, not extra claims.
- **Gaps you stated:** You said you've never worked in a contact centre or presented above regional level. The pack uses your own words for both and puts them on a not-coached list.
- **Open slots:** Where your material is silent, the pack gives answer slots, not invented stories. The silent areas are digital teams, what the spreadsheet counted, and whether the complaints log followed any rules. The same goes for pay, notice, working pattern and reason for moving in the recruiter screen.
- **Values:** Only two of the four values (Plain Words and Own the Fix) map to your own sentences. Members First and Neighbours, Not Numbers are selection scaffolds, ending in a plain "say so if nothing comes to mind" branch.

Say the word and I'll play the Head of Member Services on B3, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead — Ashgrove Credit Union: interview pack for Dara

Three rounds on 3 December 2026 (loop mode). Interviewers are unnamed so far.

| Round | Who | Length | Shape, from the recruiter's email |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Screen |
| 2 | Head of Member Services, your would-be manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute case on a complaint escalation; the panel also scores against the four published values |

Built from your message alone: no CV was supplied, so every "your CV" line below is your own message. The rounds are taken in the order the recruiter listed them.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words.
- Question IDs run by persona across the whole pack: A is Conversational, B is Skeptic, C is Values/Behavioral, D is Case/Strategist, E is Peer Evaluator. Each round below lists the IDs it uses.
- Type key: **VAL** is values alignment, **EXP** is a work-experience deep-dive, **JD** is role and job-description driven, **CO** is company and strategy knowledge, **CASE** is a live problem.
- An **answer slot** is an instruction for the interview, not a question for you now. It names a probe the interviewer is likely to make and gives two honest branches. If you did the thing, say how, in your own words. If you did not, or it was not yours, say so plainly and go back to what your own sentences carry.
- The 20-minute case in round 3 is live, so D3 to D5 rehearse a structure, not a prepared answer.

## Prep triage (9 days; the three rounds are 135 minutes of interviewing on one day)

| Order | Do this | Tied to |
|---|---|---|
| 1 | Write your own answers to the four logistics questions (pay, notice, working pattern, reason for moving). Twenty minutes, then leave them alone | A3 to A6 |
| 2 | Say the highest-ROI answer aloud three times, limit first, with someone interrupting it with the follow-ups | B3 |
| 3 | Build a five-minute walk-through of your monthly complaints spreadsheet and say it aloud to another person, since presenting upward is the thing you have said you have not done | B4, D1, C2 |
| 4 | Run the case twice, timed at 20 minutes, using the structure in D3; then choose one story for each value from the scaffolds in C5 to C8, or settle on the honest branch | D3, C5 to C8 |
| 5 | The day before: pick three reverse questions per round and read the grounding brief once | Reverse questions, Grounding brief |

Everything else in this pack is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not a process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat around the log likely. If any steps beyond the log were yours to run, say which, in your own words; if the log was the extent of it, or the steps were not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The sentence reaches monthly complaints reporting and does not show what the spreadsheet counted. The words stay at: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet counted. If volumes or resolution times were in it, say how each was counted; if either was not, say so plainly and say what the spreadsheet did hold |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your sentence says training tellers on a script, not coaching supervisors, and the words stay there: "trained new tellers on our escalation script." Answer slot: expect a probe on whether you have guided other supervisors. If you have supported another supervisor through an escalation, say what it was and what part was yours; if not, or it was not yours, say so plainly and stay with the tellers |
| F5 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | The word "formal" in your sentence does not show what the log was kept under, and this pack does not read it as showing more. Answer slot: the JD's complaints-experience line makes a probe on what the log had to follow likely. If any rules or deadlines governed the log, say which and what part of keeping to them was yours; if none did, or you do not know, say so plainly and stay with the log |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length. Lead with the quote's own terms, six years and the last three as a branch supervisor, because a stated period beats an adjective. Expect a probe on it, since a CV line alone has nothing inspected behind it |
| F7 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for it, said as a plan and never as a past. Never a claim to have presented to senior leaders |
| F8 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence says "spreadsheet" and does not name the tool. Answer slot: if it was built in Excel, say so and say what it did; if it was another tool, say so plainly and say what you have used |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing here. Answer slot: if you have worked with a digital or product team on anything members used, say what it was and what part was yours, in your own words; if not, say so plainly, then say how you would start |

No row is a gate: the JD's requirements are experience, not terms such as a licence, location or pay.

## Grounding brief

From the 2026 strategy brief (July 2026) as relayed to the pack. The brief itself was not pasted, so only these four points are held.

| Fact | Source | Where it shows up in answers | Provenance |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | Strategy brief, July 2026 | A2, D2, D5; links to the "Plain Words" value | [grounded] |
| Consolidate eight branches into five hubs over 2027 | Strategy brief, July 2026 | E3, D4, C7; the round-3 panel are branch managers, so expect it to be live for them | [grounded] |
| Launch a small-business lending product in Q1 2027 | Strategy brief, July 2026 | Know it exists; this pack does not predict questions on it | [grounded] |
| Main competitive pressure is app-only banks | Strategy brief, July 2026 | A2, D2: a reason the member-side and plain-words values matter against app-only rivals | [inferred] |

---

# Round 1 — the recruiter (30 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly chat plus logistics: pay, notice, working pattern, reason for moving | Highest. A recruiter screen's prior is Conversational plus a light Skeptic, and the email gives it 30 minutes; the risk is treating it as unscored | A prepared 90-second arc for the journey question; your own answers to the four logistics questions |
| Skeptic (light) | Knockout checks against the JD | Lower. Your own message states two limits that the JD's list will meet | Say each limit plainly and first, then the plan |

Depth: six Conversational questions (four are logistics slots) and two Skeptic.

## Bank

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Three beats, each one a clause the quotes state: six years in retail banking, the last three as a branch supervisor; the complaints log and the escalation-script training; the monthly complaints spreadsheet. Keep it to about 90 seconds and end on this role. Answer slot: give your own reason for this role next, in one sentence of your own words | F6, F1, F4 and F3 are the rows a recruiter will check against the JD. EXP because it tests what you did; the delivery is conversational |
| A2 | "What draws you to Ashgrove specifically?" | CO | [grounded] the four published values and the 2026 strategy points | Use their words accurately: name a value by its published name, or one strategy line such as the digital target. The reason itself is yours: say which value or line connects to something you did, and only the part you can back; if none connects yet, say so plainly and say what interests you | Recruiters test motivation, and the values names are what a candidate gets quizzed on. CO because it scores homework from the published material |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first. If asked what you earn now, you can redirect to the band for this role | Pay is the recruiter's standard question. Nothing in your message states a figure, so the answer is yours alone |
| A4 | "What's your notice period, and when could you start?" | JD | [generic] | Logistics slot: give your actual notice period, and say any date you cannot move | Standard screen item; the pack supplies no notice from you |
| A5 | "The job works across branches and the contact centre. What working pattern does that need to fit?" | JD | [grounded] the JD's "across branches and the contact centre" | Logistics slot: say where you can work and how often, in your own words | The JD names two kinds of site, and the brief has eight branches becoming five hubs over 2027, so where you can work may matter. The pack makes no assumption about your location |
| A6 | "Why are you looking to move?" | EXP | [generic] | Logistics slot: give your actual reason in one or two sentences, in your own words, keeping it to what is true | The reason-for-leaving item every screen scores for consistency with the rest of your story |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches, and I don't see contact-centre experience. How do you see that?" | JD | [grounded] "Never worked in a contact centre" | Hold-then-concede in the other order: concede first, because it is your own sentence. Say it plainly: "I haven't worked in a contact centre." Then a plan, said as a plan and never as a past: what you would learn first, such as how complaints reach the centre, where they hand over to branches, and what its numbers show. Add nothing about exposure you have not stated | F2 is the first knockout a recruiter reads for. JD because it scores a stated requirement |
| B2 | "Have you handled regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log" | Start with your own words: "I handled the branch's formal complaints log." Answer slot: expect a probe on what the log had to follow. If any rules or deadlines governed it, say which and what part of keeping to them was yours; if none did, or you do not know, say so plainly and stay with the log | F5 is the thinnest evidence against a headline JD requirement, so it will be asked in some form. JD because it scores the stated requirement |

## Reverse questions, round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Is there anything in my background you would like me to expand on before the next two rounds?" | The recruiter feeds the next rounds, so this surfaces the objection early and shows you want it tested |
| 2 | "What does the process look like after today, and who decides at each stage?" | Concrete process knowledge, and it shows you are planning the day |
| 3 | "How are complaints reported to senior leaders today, and who reads that report?" | Points at the reporting part of the JD, which is where F3 and F7 sit |
| 4 | "Where does the role sit between the branch network and the contact centre?" | Shows end-to-end thinking and invites the recruiter to say how the contact centre is structured |
| 5 | "Which of the strategy's digital and hub changes will this role touch first?" | Ties your question to the 2026 strategy points rather than a generic one |

---

# Round 2 — Head of Member Services, your would-be manager (45 minutes)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time…" questions on escalation, reporting, senior audiences | Highest. The recruiter's email says this round is mostly behavioural | Story-map only from your quoted sentences; "we" for context, "I" for your contribution; where no story comes to mind, use the honest branch |
| Skeptic | Probing the gap between one branch's log and the whole process | High. A manager is buying capability and derisking gaps, and your own message states two limits | Name the limit first, hold on what your sentences carry, give a plan |
| Case / Strategist | One or two live problems on reporting and digital | Lower. A hiring-manager prior is Case plus Skeptic, but "mostly behavioural" pulls it down | Clarify, then structure, then answer; think aloud |

Depth: four Values/Behavioral, three Skeptic, two Case.

## Bank

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached a colleague through a difficult escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | The nearest thing your sentence carries is the escalation script and the new tellers you trained on it; start there, in those words. Answer slot: the JD asks for coaching supervisors. If you also took a colleague through a live escalation, choose that, say what it asked of them and what you did; if training the tellers is the nearest thing, say so plainly and tell that. Never describe an outcome you did not see | F4 is where the JD's coaching line presses. JD because it scores a stated responsibility; an open prompt, so you choose the instance |
| C2 | "Walk me through the monthly complaints spreadsheet you built. What went into it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say it in the quote's words. Answer slot: if volumes or resolution times were in it, say how each was counted and name the assumption behind either that you would defend least; if you do not know how a figure was counted, say so plainly. Answer slot: if you know what the regional manager used it for, say so; if you do not, say that | F3 and F8 meet in this question. EXP because it tests what the spreadsheet actually was; the weakest-assumption move is built in |
| C3 | "Tell me about a time you had to tell someone more senior something they did not want to hear." | VAL | [grounded] "I've never presented to anyone above regional level" | Selection scaffold: pick a time with a named stake, what you actually said, and how the relationship stood afterwards. Your own sentence sets the ceiling on the audience, so choose a story at or below regional level and say it at that level. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7 is the limit this question reaches for. VAL because it scores whether the hard truth landed, not generic virtue |
| C4 | "Tell me about a time you worked with a team outside your own on something members used." | JD | [generic] | Selection scaffold: pick a time with a named counterpart team, what each side owned, and what changed for members. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would work with a digital team | F9 has no evidence in your material, so this is a scaffold and not a story. JD because the digital-team line is a stated responsibility |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B3 | "The job is the whole complaints process, branches and contact centre. Your background is one branch's log. Why should I believe you can own it?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre"; "6 years in retail banking, the last 3 as a branch supervisor" | **Highest-ROI prep in the pack.** Name your limit before it is asked: "I haven't worked in a contact centre." Then hold on what your sentences carry, and no further: "I handled the branch's formal complaints log," and your six years, the last three as a branch supervisor. Follow-up 1, what is different between a log and the whole process, is an answer slot: if any steps beyond the log were yours to run, say which; if the log was the extent, or they were not yours, say so plainly. Follow-up 2, how you would get up to speed, is a plan: who you would learn from first and what you would look at. Follow-up 3, what if the centre's team knows more than you, gets the same answer: you would learn from them, and you claim nothing else. Hold through all three by returning to the log, never by adding to it | This objection will be asked in some form, and F1 and F2 are where the material is thinnest against the JD's headline line. A rehearsed, non-defensive answer changes the interview. JD because it scores the stated requirement |
| B4 | "You would present these numbers to senior leaders each month. What is the most senior audience you have presented to?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment, in your own sentence: "I've never presented to anyone above regional level." Then a plan, said as a plan: how you would prepare the first monthly report and who you would ask to listen first. Do not describe a senior audience you have not faced | F7 is a stated limit against the JD's presenting line. JD because the premise comes from the JD |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose from the two limits your own sentences state, say the weaker one first, and give the plan for each. If you have no digital-team work, say so plainly rather than choosing a third limit for effect | Standard Skeptic stem; F2 and F7 are the honest answers. JD because it scores self-assessment against the listed job |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sketch how you would report monthly on complaint volumes and resolution times across branches and the contact centre. What do you need to know first?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Clarify first: what counts as a complaint in each channel, when the clock starts and stops, who owns each data source. Then objective, segmentation, approach, metrics, risks, thinking aloud. Challenge one premise respectfully, such as whether branch and contact-centre definitions match. Answer slot: if the spreadsheet you built defined a complaint or a resolution date, say how; if it did not, say so plainly. If it was built in Excel, say that | F3 and F8, delivered live. CASE because the interviewer scores structure; JD content |
| D2 | "We aim to move 40% of member service to digital channels by 2028. Which complaints would you keep away from self-service, and why?" | CO | [grounded] strategy brief, 40% by 2028 | Name your criteria before any examples. Ask what counts as member service in the 40%, as your one respectful premise challenge. Tie it to their value of Plain Words: if a member needs it explained twice, the journey is wrong. The criteria and the answer are your own reasoning | A strategy-grounded question most candidates cannot touch. CO because it needs the brief; F9 is the row behind it |

## Reverse questions, round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good first 90 days look like from your side?" | Lets your would-be manager define success, which your later answers can echo |
| 2 | "Where do complaints get stuck today between the branches and the contact centre?" | Shows end-to-end thinking and goes straight at the central part of the job |
| 3 | "Which senior leaders see the monthly report, and what do they need from it?" | Prepares the audience you have said you have not faced (F7) |
| 4 | "How are supervisors supported on escalations today, and what would you want this role to change?" | Starts the coaching conversation from listening, which F4 needs |
| 5 | "Is there anything in my background you would want evidence on before the panel?" | Surfaces the objection while there is still a round left to answer it |

---

# Round 3 — panel of two branch managers (60 minutes, including a 20-minute case)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Stories scored against the four published values | Highest. The recruiter's email says the panel scores against the four values | One story per value, or the honest branch; the hard truth must land in the story |
| Case / Strategist | The 20-minute complaint-escalation case | High. Twenty of the sixty minutes is the case | Clarify, objective, segmentation, approach, metrics, risks; say the framework aloud first |
| Peer Evaluator | Seam-splitting: what you coach versus what they manage | Medium to high. The JD has the role coaching branch supervisors, so branch managers are people this hire works beside; this is the pack's inference from the JD | Reciprocity: what you bring them as well as what you need; propose seam principles rather than pretending to know the seam |
| Skeptic | The contact-centre and coaching limits, in collegial packaging | Lower. Round 2 carries most of it, but objections return in other registers | The same limit-first answers as round 2 |

Depth: four Values/Behavioral, three Case, three Peer, two Skeptic.

## Bank

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "Members First, Always: tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] the published value, "we decide from the member's side of the counter" | Selection scaffold: pick a time when what the member needed and what a rule, a target or a queue pressed for pointed different ways. It needs the member's position, what you decided, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Every published value gets a VAL question. No quoted sentence carries this story, so it is a scaffold. VAL because it scores behaviour against the named value |
| C6 | "Plain Words: tell me about a time something had to be explained twice, and what you changed." | VAL | [grounded] the published value "if a member needs it explained twice, we wrote it wrong"; "trained new tellers on our escalation script" | The escalation script and the tellers you trained on it are the beats your sentence carries; start there. Answer slot: if you ever changed the wording of a script, a letter or an explanation because it needed explaining twice, say what and why; if you did not, or the wording was not yours, say so plainly and stay with training the tellers | F4 is the only row near words and scripts. VAL because the value's own test is explaining twice |
| C7 | "Neighbours, Not Numbers: tell me about a time you took account of what a member's community meant to how you handled their case." | VAL | [grounded] the published value "every branch is part of its town" | Selection scaffold: pick a time when who the member was, in the town you served, changed how you handled their complaint. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not offer views on which branches should stay open | The panel are branch managers, and the brief has branches becoming hubs, so the pack expects this value to carry weight with them; that is an inference. VAL because it scores the named value |
| C8 | "Own the Fix: tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] the published value "whoever finds the problem keeps hold of it until it is solved"; "I handled the branch's formal complaints log" | Your sentence carries the log. Answer slot: if any complaint stayed with you from the day it came in until it was solved, say what happened and what part was yours; if no complaint did, or the log was the extent of it, or others closed them, say so plainly and stay with the log | The value mirrors the JD's end-to-end ownership line, so it is F1 again in values clothing. VAL because it scores the named value |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D3 | "A member has complained three times, at the branch, by phone and in the app chat, and says nobody will take ownership. Walk us through your next hour, your next week, and what you change afterwards." | CASE | [generic] | Say your structure aloud first. Clarify in the first two or three minutes: what the complaint is, what the member has been told, and which deadlines or reporting duties apply to this complaint type, asking rather than guessing. Then objective: this member's immediate need and one named owner, which is the Own the Fix value. Then approach: a reply in plain words, the cause across the three channels, what gets recorded and reported. Close with risks and what you would measure. Challenge one premise respectfully, such as whether the three complaints are one case. The panel may use a different scenario; the structure is what carries | The recruiter's email says 20 minutes of the round is a complaint-escalation case. The label is generic because the actual case is unknown. CASE because the panel scores structure and reasoning |
| D4 | "Imagine one of our branches is moving into a hub next year and its members start escalating complaints about the change. What do you do?" | CASE | [inferred] derived from the brief's eight-to-five hub plan; typical of a change programme | Clarify what is decided and what members are actually complaining about, and separate complaints about service from complaints about the change. Name one owner, answer in plain words without promising anything you cannot, and route what you learn back to whoever runs the change. Do not argue the strategy | The panel are branch managers and the brief has the hub plan, so this is a likely shape of case. The brief does not say complaints will rise, so the pack does not assume it |
| D5 | "A member starts in the app, is sent to the contact centre, then walks into a branch. Where did we fail, and what do you fix first?" | CASE | [inferred] derived from the JD's self-service line and the 40% digital target | Diagnose by journey step and by handover. A member should not have to repeat themselves, which is the Plain Words test. Say what you would count, such as repeat contacts and handovers. Answer slot: if you have worked with a digital team, say what and what part was yours; if not, say so plainly and say how you would work with one | F9 has no evidence, so this question has to be answered by structure. CASE because it is a live diagnosis; JD content |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our supervisors are already stretched. Where is the seam between what you would coach and what we manage, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not facts about their branches: agree the line with them rather than announce it, and ask where it sits today. Offer what you bring as well as what you need, such as showing each branch what its complaints data shows. Say how you would disagree: early, in private, and on the member's case | F4 as the panel will test it: the people the role coaches report to these two. JD because the coaching line is stated |
| E2 | "Tell me about a time you and a manager saw an escalation differently." | EXP | [generic] | Selection scaffold: pick a time with a named stake, what you said, and how the working relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer stem on disagreement, asked as a past-behaviour question. EXP because it scores what actually happened |
| E3 | "Eight branches become five hubs over 2027. What would you want from branch managers like us while that happens?" | CO | [grounded] strategy brief, eight branches into five hubs over 2027 | Reciprocity first: ask what they need from this role during the change, then say what you would want. Stay within what the brief says, and if they say more, listen and ask. Show you see members as people in towns, which is the Neighbours, Not Numbers value, without offering a view on closures | CO because it needs the brief. This is the question where the panel's own jobs are at stake, so the pack asks you to listen first |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B6 | "You would be coaching our supervisors on escalations. Why would they listen to you?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Hold on what the sentences carry: the last three of your six years as a branch supervisor, and the new tellers you trained on the escalation script. Answer slot: if you have supported other supervisors through an escalation, say what and what part was yours; if not, or it was not yours, say so plainly and stay with the tellers. Plan: ask them what hurts most before you coach anything | F4 in the panel's words |
| B7 | "Our counters and the contact centre run differently. Where would you be least sure of yourself?" | JD | [grounded] "Never worked in a contact centre"; "6 years in retail banking, the last 3 as a branch supervisor" | Say it plainly: "I haven't worked in a contact centre." Then what you do bring from the branch side, in the words of your sentence: the last three of your six years as a branch supervisor. Then the plan: you would learn the centre's side from its team | F2 returning in a collegial register. JD because it scores the stated requirement |

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decisions start from the member's position, not the institution's | Selection scaffold, C5: a time the member's need and a rule or target pulled apart; if none comes to mind, say so plainly, then the nearest thing your material carries, or how you would handle it |
| Plain Words | If a member needs something explained twice, the wording was the failure | F4 — "I handled the branch's formal complaints log and trained new tellers on our escalation script". The script and the training are the beats; whether you changed any wording is the answer slot in C6 |
| Neighbours, Not Numbers | Each branch is part of its town, so who the member is matters | Selection scaffold, C7: a time a member's community changed how you handled their case; if none comes to mind, say so plainly, then the nearest thing your material carries, or how you would handle it |
| Own the Fix | Whoever finds a problem stays with it until it is solved | F1 — "I handled the branch's formal complaints log". The log is the beat; whether any complaint stayed with you start to finish is the answer slot in C8 |

## Reverse questions, round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do your supervisors find hardest about escalations today?" | Coaching starts with listening; it shows you want their view before offering yours |
| 2 | "What could a new person in this role do in their first month that would genuinely help your branches?" | The reciprocity question for peers: it asks what you can give, not only what you need |
| 3 | "How do you hear about a complaint today, and how quickly does it reach you?" | Opens the escalation path without presuming how it fails, and shows you think about ownership |
| 4 | "What would you want the complaints process to do for your members while the hub changes happen?" | Keeps you on the member's side and avoids opining on the strategy |
| 5 | "Where do the contact centre and your branches work well together, and where not?" | Shows you will learn the contact-centre side from the people who live with it (F2) |

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches (F1) | A1, B3, C8, D3 |
| Across branches and the contact centre (F2) | B1, B3, B7, D5 |
| Report monthly on complaint volumes and resolution times (F3) | C2, D1 |
| Coach branch supervisors on escalations (F4) | C1, B6, E1 |
| Experience handling regulated complaints (F5) | B2, D3 |
| 4+ years in financial-services customer operations (F6) | A1, B6 |
| Confident presenting to senior leaders (F7) | B4, B5, C3 |
| Comfortable with Excel reporting (F8) | C2, D1 |
| Work with digital teams on self-service journeys (F9) | C4, D2, D5 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: the material says the branch's log, not a process across branches. B3's slot stays inside the log |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script." B6's slot stays with the tellers |
| Wrote or designed the escalation script | Inflated form of F4 | The quote says trained on the script, not wrote it. The pack's observation, not words for you |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." C2's slot asks only what it counted |
| Handled regulated complaints | Inflated form of F5 | F5's quote at its own scope: "I handled the branch's formal complaints log." The pack does not read "formal" as more. The slot asks only what the log had to follow |

## Sources

**Provided documents:** the JD as pasted; the values text as pasted, copied on 24 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; the four points of the 2026 strategy brief (July 2026) as relayed; your background as written in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text is pasted in full, so the four names and definitions are in hand; the cheat sheet and C5 to C8 rest on it |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email establishes the loop: three sessions, with who runs each and what it holds; persona weights follow it |
| 3. `Ashgrove Credit Union strategy` or recent news | skipped | The four brief points are in hand and under six months old; they fix the CO questions. Wider context is an upgrade-menu item |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV text → the "your message" evidence in F1, F3, F4, F6 and F8 becomes CV lines, and some answer slots may resolve
- The artifacts that would raise your confidence bands: a redacted extract of the complaints log, the escalation script, the monthly spreadsheet (or its column headings), any report you have presented → F1, F3, F4, F5 and F8 move from `medium` or `low` toward `high`
- Your answers to the slots, stated outside a drill (notice, pay approach, working pattern, reason for moving, what the spreadsheet counted, whether the log was governed by rules, any digital-team work) → the rows that draw on them regenerate
- The interviewers' names or titles when assigned → an interviewer read, tuned persona weights, and a reverse question tied to each person's path
- The recruiter's answer on the case format (whether you get material in advance or it is live, and whether a pre-read exists) → a tailored build for D3, one email
- The full 2026 strategy brief text → richer CO and CASE questions than the four relayed points
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes → a grounding brief on Ashgrove's recent organisational context and reports of how this loop runs in practice
- A `tuesday-dossier.md` from an earlier session → verified evidence and a prohibited-claims list; this pack built its own
