I'll read the reference files the skill points to before drafting.
The pack is written and saved. Here is the summary.

Your prep pack is saved as `Larkfield-Systems_engineering-manager_interview_pack.md`, in this session's working directory. I built it as a loop with a shared fit snapshot, then a mini-pack for each of the three rounds. It has 26 questions in all: 9 for the Director, 9 for the panel and 8 for the VP. Each round has its own persona weights and reverse questions. I assumed no interviewer names or full JD, so I worked from your one-line role description.

The web searches for company values and strategy were refused. The pack therefore has no values cheat sheet, and the "where is Larkfield heading" question (K2) is generic. The pack suggests asking the Director on Tuesday where engineering is investing, so you have something real for Monday.

The highest-ROI prep is A1: "you've never owned a hardware-adjacent roadmap, and this role partners with hardware." Rehearse it first.

Say the word and I'll play the Director as a Skeptic on A1 so you can drill it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the full JD, or any recruiter notes on the panel or VP round, such as a stated focus or an exercise to prepare? Either would replace guesses with quoted requirements.
Can you paste your CV, or just the lines about the team lead role, hiring and the reliability quarter? That would give the fit rows a second source.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Interview pack (loop mode): Engineering Manager, Larkfield Systems

**Candidate:** Yusuf. **Loop:** three scheduled rounds, in this order.

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1 | Director of Engineering | 45 min | Hiring manager, your would-be boss |
| 2 | Two staff engineers and a product manager | 60 min | Panel |
| 3 | VP Engineering | 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

No interviewer names were given, so there is no interviewer read. The role description in this pack is the one-line version you supplied, not a full JD. The pack was built without company research, because both searches were refused (see Sources).

## How to use this pack

- **Personas** describe how a question arrives: who is asking and in what style. **Types** describe what is being scored.
- **Type key:** VAL is values and behavioral alignment. EXP is a deep-dive on your own work and attribution. JD is the role's stated requirements. CO is company and strategy knowledge. CASE is a live problem from the role.
- Guidance is scaffolding, not a script. Say it in your own words. An **answer slot** is an instruction for the interview: answer it from your real experience, or say plainly that the practice was not yours or never existed. Either branch is a good answer.
- The shared sections (fit snapshot, prohibited claims) come first. Each round then has its own persona weights, question bank and reverse questions.

## Prep triage

1. **Before Tuesday:** rehearse A1 until it is boring. It is the highest-ROI prep in this pack, because it is the objection this loop is most likely to raise in some form, and it aims at where your material is thinnest. Then A2, B1 to B3, and the 90-second arc in D1.
2. **On Tuesday:** use the reverse questions in Round 1 to learn how the squads are structured and where the company is heading. Round 3's K2 depends on the second answer.
3. **Before Thursday:** C1 and E1 (the 60% figure, from both angles), E2, and G1.
4. **Before Monday:** L1, J1, J2 and J3.
5. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from your message's role description. Evidence is your own sentences, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | medium | [grounded] | transferability | Your material says a team lead of six, in payments; the role is two squads in device-management services, so the scope and the domain both go beyond the quote. Words at the quote's scope: "I've been a team lead of six for three of my nine years in engineering." Answer slot: the two squads make a probe on leading beyond one team likely. If any of what you led spanned more than one stream or team, say what and which part was yours; if none did, say so plainly and stay with the team of six |
| F2 | "own delivery" — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote carries one decision about where the team's time went, with an on-call result after it, and says nothing about delivery commitments. Words at its scope: "I pushed a reliability quarter through against roadmap pressure, and my team's on-call burden dropped 60% after." Answer slots for the figure: how the 60% was counted, what it is sensitive to, the assumption you would defend least, and which part was yours; "I don't know how it was counted" is an honest answer. Second slot: if you owned delivery commitments to anyone, say what; if not, or not yours, say so plainly and stay with the reliability quarter |
| F3 | "hiring" — your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a one-line claim with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms: you run it, for backend roles. Answer slots for the figure: the 40 counts interviews; say how it was counted and which of them were yours. Second slot: say what running the loop covered, and where a decision was someone else's, say so plainly |
| F4 | "growth for 11 engineers" — your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | low | [inferred] | discovery | The quote says team lead and is silent on what that covered for the people on the team, so no words are written for you. Answer slot: if developing the people on your team was part of leading it, say what and how, in your own words; if it was not, or it sat with someone else, say so plainly and say how you would approach it |
| F5 | "partner with hardware and product on roadmap" (hardware side) — your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The quote is about owning; your material is silent on working beside a hardware team short of that. Answer slot: if you have worked beside one, say what and which part was yours; if not, say so plainly |
| F6 | "partner with hardware and product on roadmap" (product side) — your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote shows a roadmap pressure and a decision, not who it came from or how it was worked through. Answer slot: if the pressure came from product, say how you worked it through together; if it came from elsewhere, or there was no working-through, say so plainly and stay with the reliability quarter |

The role description does not say whether a lead or manager layer sits between the EM and the 11 engineers. Your material says you have not managed managers (F5). Whether the role needs it is a fact to learn from the Director, not to assume (reverse question 1, Round 1).

## Round 1: Director of Engineering, 45 minutes (hiring manager)

### Persona weights, with reasoning

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of what the role needs and your material does not show: hardware roadmaps, managing at scale, the domain switch | Highest. A hiring manager is derisking gaps, and you named two of them yourself (F5). The relationship prior is Case plus Skeptic | Rehearse A1 until boring. Concede the stated facts in your first sentence, hold what the quotes carry, ramp plan stated as a plan |
| B. Case/Strategist | Live problems from the real roadmap: a slipped hardware date, a squad capacity trade-off | High. The prior says hiring managers bring problems from their actual roadmap, and the role is about delivery | Clarify first, then objective, options, risks, how you would communicate; say your structure aloud |
| C. Data-Driven Prober | Goes at the 60% | Low to mid. A hiring manager reading a one-page summary will likely stop on the one number you gave | Know what you can and cannot say about how it was counted |
| D. Conversational | The opening "walk me through your journey" | Low as a style, but the opener is scored | A 90-second arc made only of sentences you have said |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role partners with hardware on the roadmap, and you've said you've never owned a hardware-adjacent roadmap. How do you see that?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Hold, then concede, in that order of honesty: open with the stated fact, "I haven't owned a hardware-adjacent roadmap." Then give the ramp plan as a plan: what you would want to learn first, whom you would ask, and how you would test your understanding before committing dates. Say it in your own words, in the future tense. Hold through two follow-ups by returning to the fact, never by adding to it. If asked what is closest, answer slot: if you have worked beside a hardware team, say what and which part was yours; if not, say so plainly | F5 is the largest gap in the loop and the one you flagged first, so some form of this question is near-certain. JD because it scores a stated requirement; the Skeptic delivers it |
| A2 | "You've said you've never managed managers. What does that mean for this role?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Say the stated fact first: "I haven't managed managers." Then ask the Director how the two squads are structured and whether a lead layer exists, which is a real question to them, not a dodge. Do not guess the structure. If the role is eleven direct reports, say what you would want to understand about doing that at that size, as a view rather than a claim about the past | F5 and the role's open structure (see the note under the fit snapshot). JD because it tests whether the gap matters to this specific role |
| A3 | "You've led a team of six. Here it's eleven across two squads. What changes?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Start at the quote's scope: "I've been a team lead of six for three of my nine years in engineering." Then answer the question as a view: what you would keep, what you would need to learn, how you would find out in the first weeks. Answer slot: if any of what you led spanned more than one stream or team, say what and your part; if none did, say so plainly and stay with the team of six | F1 and F4: the step from six to eleven is a number from the role and a number from your quote, and the Skeptic will lay them side by side |
| A4 | "You're at a payments company. Why industrial IoT, and why now?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A selection scaffold, because no quote carries the reason: give your actual reason in three beats: what draws you to device-management work, why the manager role, why this company. Any reason that is partly about leaving, say plainly. Do not claim domain experience; "currently at a payments company" is the whole of what your material says about your domain. If the true reason is thin on one beat, say so and say what you want to find out | F1's domain step. JD because motivation consistency is how the Skeptic tests the fit |
| B1 | "Two squads, eleven engineers. A hardware launch date moves three weeks earlier than planned. Walk me through your first week." | CASE | [generic] | Clarify before structuring: what moved and who decided, what is fixed on the hardware side, which software work sits on the critical path, what the squads are already carrying. Then objective, two or three options with their costs, risks, and who you would tell and in what order. Challenge one premise politely. State your assumptions aloud, because you do not have the hardware context. A live problem needs no claim about your past, so none is made | F2 and F5 as a live problem: delivery pressure with a hardware dependency. CASE because it scores structure; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| B2 | "A product manager wants a customer-driven feature next quarter, but the squads are carrying heavy on-call load. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure first: what the feature is worth, what the on-call load is costing, what the options are, how you would decide and with whom. You may point to the reliability quarter at its own scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you made the case to anyone, say how and to whom; if the decision was made another way, say so plainly. Never present the 60% as proof the approach works here | F2 and F6. CASE with an EXP edge: the Director may hear the reliability quarter in it and probe |
| B3 | "You inherit two squads on day one. What do you need to know first, and how does your first 90 days go?" | CASE | [generic] | Open with what you would ask, not what you would do: how each squad is doing, what the hardware dependencies are, who the strongest voices are, what the Director expects to change. Then listening, a small number of early commitments, and a plan to learn the hardware cadence. Do not claim a method you have not used; frame the plan as a plan | F1 and F5. Hiring managers use this to see whether you diagnose before acting |
| C1 | "Your team's on-call burden dropped 60%. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Four answer slots, each in your own words: how the 60% was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Name the weakest assumption before they do. "I don't know how it was counted" is an honest branch. Keep your sentence's "after": it says the drop followed the reliability quarter, and it says nothing about cause | F2: a headline number is a magnet for probing. EXP because it tests attribution; the weakest-assumption move turns a gotcha into credibility |
| D1 | "Walk me through your career so far." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc with only what your quote carries: nine years in engineering, three as a team lead of six, now at a payments company. Add why you are here, in your own words. Anything further is whatever you can say aloud and stand behind under a follow-up | F1. Casual openers are scored for economy and genuine interest |

### Reverse questions for the Director

| # | Question | Why it lands |
|---|---|---|
| 1 | "How are the two squads structured today: is there a lead layer between the EM and the eleven, or do they report to the role directly?" | It resolves the managing-managers question with facts instead of a guess, and it shows you are thinking about the work, not defending a gap |
| 2 | "Where do software dates depend on the hardware roadmap, and how does the planning cadence between them work today?" | It maps the gap you named instead of hiding it |
| 3 | "What would tell you in six months that this hire was right?" | It makes you a partner in defining success, not a candidate being scored |
| 4 | "Where is engineering investing over the next year, and where does this role sit in that?" | It is the company-direction question, asked of the person who can answer it; the answer feeds K2 on Monday |
| 5 | "What is open on hiring and on growing the people in the two squads right now?" | It ties to F3 and F4 and surfaces what you would inherit |

## Round 2: panel, two staff engineers and a product manager, 60 minutes

### Persona weights, with reasoning

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| E. Data-Driven Prober | Staff engineers pressing on how you decided, how the number was counted, how deep the reliability story goes | Highest. The prior for technical specialists is Prober plus Pressure, and the 60% is your one hard number. Pressure follow-ups are folded in here | Know what you can and cannot say; name your weakest assumption; hold the quote's scope |
| F. Peer Evaluator | The seam between EM and staff engineers; how you work with product; credit and disagreement | High. I added this for the whole panel because the role statement names partnering with product, and an EM works beside staff engineers. Adjust if you know the panel's tone | Propose seam principles instead of pretending to know the seam; reciprocity framing |
| G. Case/Strategist | A live problem on the device-management side | Mid. Panels like a shared problem to think through aloud | Clarify, structure, think aloud |
| H. Values/Behavioral | The PM's style: how you hire, what you look for | Low to mid. A cross-functional interviewer asks the people questions; the prior points to Values plus Conversational | A story map from the one quoted hiring sentence |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "On-call burden dropped 60%. Which part of that was your decision and which was the team's?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | The attribution probe. Your sentence has two parts you can stand behind: you pushed a reliability quarter through against roadmap pressure, and the burden dropped after. Answer slots: what was yours, what was the team's, what else changed in that period, in your own words; if you do not know what else changed, say so. Do not say the quarter caused the drop unless you can show it | F2. Staff engineers who own reliability will test the line between your decision and the team's work |
| E2 | "Tell me about a time you chose reliability over the roadmap. What did you actually decide?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-map on the quote only: the reliability quarter, the roadmap pressure, the on-call drop after. Answer slots for the middle of the story, where interviewers go: what the pressure was and who applied it, how you made the case, what was set aside; if there was no such trade-off or it was not yours to make, say so plainly and return to the quarter. Hold the story through two follow-ups | F2 and F6 at once. JD because reliability against delivery is the core of "own delivery" |
| E3 | "Device-management services run on fleets of devices in the field. Where do you think the hard problems are?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Calibrated candor: the staff engineers own this domain and will know in a sentence if you bluff. Say plainly what you do not know. Then give your view of where you would look, as a hypothesis, and ask them where the real difficulty sits; asking is the strong move. Never claim device-management experience; the quote you have is a payments company | F1's domain step. JD because it scores the stated domain; the Prober delivers it |
| F1 | "Where is the seam between an EM and a staff engineer here? Who decides technical direction when you disagree?" | JD | [generic] | Offer seam principles, not claims: you would own outcomes, priorities and the people questions; staff engineers would shape technical direction; where you disagree you say so openly and decide how to decide. Selection scaffold for the follow-up: pick a time you disagreed with a senior engineer, with a named stake and a clear ending; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer Evaluator's stem. JD because it tests partnership fit with the people you would work beside |
| F2 | "Product wants dates, hardware has its own constraints. How do you work with both without just relaying messages?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Short and honest: "I haven't owned a hardware-adjacent roadmap." Then principles: get both sides' constraints visible in one place, say what you can and cannot commit to and why, change the plan in the open. Frame this as how you would work, not as how you have. Answer slot: if you have done any of it beside a hardware team, say what and your part; if not, say so plainly | F5 and F6 in the PM's own register. JD because it scores the partnership requirement |
| F3 | "Tell me about a time you and a product partner disagreed about priorities." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Open prompt. If the reliability quarter is your story, use only its beats: you pushed it through against roadmap pressure. Answer slots: whether the pressure came from product, what each side wanted, how it ended; if the pressure came from elsewhere, say so and pick a different story. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F6. The PM can score it directly, and the theme comes from the role's product-partnership line |
| G1 | "A release leaves a share of the fleet failing to update, and customers are noticing. You're the EM. What do you do in the first hour, and the first day?" | CASE | [generic] | Clarify: how many devices, what the failure looks like, whether rollback is possible, who is affected. Then contain, communicate, diagnose, decide, review. Say what you would hand to the staff engineers and what you would own: the communication, the priorities, the people. You will not know the platform; say so and say how you would learn it in the moment | F1 and F2 under pressure. A live problem needs no claim about your past |
| G2 | "Another team wants our squads to take on a new integration. We have eleven engineers across two squads. How do you decide?" | CASE | [generic] | Clarify the ask and the cost of saying no; look at current commitments, on-call load, hiring status; options include yes, not yet, a smaller scope or a trade-off to be made visibly. Say how you would decide and with whom, as a method, without claiming you have done this | F1 and F6: capacity against partner demand |
| H1 | "How do you hire? What do you look for, and how do you tell?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start at the quote: you run your team's hiring loop for backend roles, with about 40 interviews last year. Answer slots: what running the loop covered, and where a decision was someone else's; how the 40 was counted and which of them were yours. Then what you look for, as your own view, in your own words | F3. A PM and staff engineers care about who joins their team, so the hiring probe will be real |

### Reverse questions for the panel

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new EM do in their first month that would genuinely help your work?" | The reciprocity question: it asks what you can give them, not only what you need |
| 2 | "Where do you most want the EM involved, and where most want them to stay out?" | It invites seam principles from the people who will live with you |
| 3 | "How does roadmap planning with hardware work today, and where does it hurt?" | The PM and staff engineers see the pain first-hand; it shows you are mapping F5, not avoiding it |
| 4 | "What is on-call and reliability like for the squads today?" | It connects to your reliability work without claiming anything new |
| 5 | "What is one thing about how the squads work that you would want a new EM to leave alone?" | It shows respect for what exists before you change it |

## Round 3: VP Engineering, 30 minutes ("values and leadership philosophy")

The recruiter's own words describe a values-style round. Larkfield's published values were not retrievable (searches refused), so there is no values cheat sheet in this pack and the VAL questions use story maps and selection scaffolds. Pasting the official values page would add it (upgrade menu).

### Persona weights, with reasoning

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| J. Values/Behavioral | Leadership philosophy, a hard truth delivered, helping someone grow | Highest. The recruiter's description is a loop source for exactly this, and it outweighs the skip-level prior | A story where one of your quoted sentences carries it; a scaffold with an honest branch where none does |
| K. Case/Strategist | Strategy-flavored: where Larkfield is heading, how hardware and software commitments work | Mid. The prior for a skip-level is strategy plus Pressure; 30 minutes leaves room for one or two | Say how you think, and say plainly what you do not know about the company |
| L. Pressure | "Sixty seconds: why you?"; "how much of that was you?" | Mid to low. Skip-levels test composure, and your two stated gaps make a short, direct challenge likely | Pause, restate the question, concede what you stated, hold what the quotes carry |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "How do you think about leadership? What makes an engineering manager good?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Lead with two or three beliefs, in your own words. For one, use a quoted sentence at its scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: why you did it, and what it cost you, in your own words; if you would frame it differently now, say so. A belief stated as a belief is fine; do not present it as something you have practiced where your material does not show it | F2. A leadership-philosophy question is scored on whether stated beliefs are backed by something you did |
| J2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Open prompt. If the reliability quarter is your story, use only its beats: you pushed it through against roadmap pressure. Answer slots: who you told, how it landed, what happened to the relationship; if the pressure did not come from leadership, say so and choose another example. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F2 and F6. A stem from the values persona, themed by the recruiter's description of the round |
| J3 | "Tell me about a time you helped someone on your team grow." | VAL | [generic] | A selection scaffold, because no quote carries a story: pick a time that has a named person (no name needed), a thing you did, and a change you can describe. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would approach it | F4. The role's "growth for 11 engineers" is a stated requirement, and a VP will go straight at it |
| J4 | "Why do you want to manage rather than stay technical?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Your reason, in your own words. What your material carries is three years as a team lead of six, in nine years of engineering: say what you found in that, as your reason, not as a claim of how well you did it. Add what you want to learn at this scale | F1 and F4. Motivation consistency, at VP altitude |
| K1 | "Hardware and software run on different clocks. How would you think about commitments across two squads?" | CASE | [generic] | A philosophy question with a structure: what you would want to know about each side's constraints, how you would separate what is fixed from what is a guess, how you would communicate confidence levels. Say plainly you have not owned a hardware-adjacent roadmap (a fact you stated), and that this is how you would approach it | F5 at leadership altitude. CASE because it asks for reasoning, not recall |
| K2 | "What do you know about where Larkfield is heading?" | CO | [generic] | No company research was available, so this answer cannot be pre-built. Do not bluff. Say what you know, drawn from the Director on Tuesday (reverse question 4) and the recruiter, and say what you would want to know. Then link one thing you heard to how you would run the squads | The honest cost of the refused searches: a `[generic]` CO question until you have the sources. Strategy fluency separates candidates at this altitude |
| L1 | "You have thirty seconds: why should we hire someone who hasn't managed managers and hasn't owned a hardware roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap"; "9 years engineering, 3 as a team lead of 6, currently at a payments company"; "I run our hiring loop for backend roles — about 40 interviews last year" | Pause. Concede both facts in your first sentence: "I haven't managed managers, and I haven't owned a hardware-adjacent roadmap." Then what your material does carry, at its scope: three years as a team lead of six, and you run your team's hiring loop for backend roles. Hold that through two follow-ups; do not widen it. Close with how you would close the two gaps, as a plan | F5, F1 and F3 under pressure. The hold-then-concede structure: concede what you stated and never fold on what the quotes carry |
| L2 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer slots, in your own words: which part was yours, which was the team's, and anything else that changed in that period; "I don't know how it was counted" is an honest branch. Do not defend more than the sentence carries: you pushed the reliability quarter through, and the burden dropped after | F2. The stem for a pressure persona; skip-levels use it to test whether you claim more than you did |

### Reverse questions for the VP

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do you want engineering managers here to be best at?" | It invites the philosophy question back to the person who set it |
| 2 | "Where is engineering investing over the next year, and where does this role sit in that?" | It signals altitude, and it is the CO question you could not pre-build |
| 3 | "What is the hardest trade-off between hardware and software timelines you have seen here, and how was it worked through?" | It shows you are learning the gap in F5 from the person with the widest view |
| 4 | "What does growth look like for managers here? What does the path from this role look like?" | It is honest interest in the manager-of-managers step you have not taken |
| 5 | "What separates managers who do well here from those who struggle?" | It asks for the bar directly |

## Coverage: requirement to question IDs

| Requirement | Questions |
|---|---|
| "Lead two squads building device-management services" (F1) | A3, A4, B3, D1, E3, G1, G2, J4 |
| "own delivery" (F2) | B1, B2, C1, E1, E2, J1, L2 |
| "hiring" (F3) | H1, L1 |
| "growth for 11 engineers" (F4) | A3, J3, J4 |
| "partner with hardware and product on roadmap" (F5, F6) | A1, A2, B1, B2, F2, F3, K1, L1 |

## Prohibited claims (not coached in any round)

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads, or managed a team of eleven | Inflated form of F1 | F1's quote at its own scope; the limit is the pack's observation: your material says a team lead of six, not two squads or eleven. A3's slot stays inside the team of six |
| Line-managed the people on the team of six | Inflated form of F1 and F4 | F1's quote at its own scope. F4's slot asks only what leading the team covered for the people on it |
| Owned hiring decisions or built the hiring process | Inflated form of F3 | F3's quote at its own scope: you run the loop for backend roles. H1's slot asks what running it covered |
| The reliability quarter caused the 60% drop, or the drop was yours | Inflated form of F2 | F2's quote at its own scope: the burden dropped after the quarter. C1, E1 and L2 ask only for counting, sensitivity, weakest assumption and what was yours |
| Owned or co-owned a hardware-adjacent roadmap | Contradicted by your own statement (F5) | The plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." |
| Managed managers | Negative you stated (F5) | The plain acknowledgment: "I haven't managed managers." |

## Sources

Provided: your message (the role description, the three rounds, your background). No dossier, CV or full JD was provided.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

Queries sent:

- `Larkfield Systems industrial IoT company values` — refused
- `Larkfield Systems industrial IoT device management strategy news` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was refused. It would have fed a values cheat sheet and mapped VAL stories for Round 3; the upgrade menu offers it |
| 2. `Larkfield Systems interview process engineering manager` | skipped | Your message already gives each round, who runs it and how long, which fixes the persona weights |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The search was refused. It would have supplied a grounded K2 and any other CO question; K2 is `[generic]` for now |
| 4. interviewer public footprint | n/a | No names were given, so there was no query to form |
| 5. representative `Engineering Manager` JD | skipped | The role description you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full JD text → the six fit rows now rest on one line of role description; the real requirements (on-call, domain, location, travel) become quoted rows, and mid-list items get their own questions
- Your CV → F1 to F4 get a second source. The artifacts that would raise their confidence from medium are field-specific: for F2, the on-call dashboard or incident-review figures behind the 60%; for F3, the loop's scorecards or debrief records; for F1 and F4, a team structure or review document
- Your answers to the slots in F1, F2, F3, F4 and F6 → regenerates those rows and the questions that draw on them, with your words quoted in
- If you have ever worked beside a hardware team in any capacity → F5 and A1 can be regraded
- The recruiter's notes for the panel and the VP round (any exercise, stated focus, interviewer names) → a graded-deliverable section if one was announced, an interviewer read, and tailored reverse questions
- The official Larkfield values page, pasted → a values cheat sheet with a story map for Round 3
- A strategy brief or a recent article, pasted → K2 and other CO questions become `[grounded]`
- Deeper research (up to 6 more searches and 2 more fetches, several more minutes) → company strategy brief and recent org context; the search tool was not permitted in this session, so this works only if it is allowed
- A `tuesday-dossier.md` from job-underwriter, optional → verified evidence and any unresolved risks carried in, replacing the objection this pack inferred
