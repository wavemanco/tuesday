I'll read the skill's reference files before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-4-denied-d4268d12/quartzline_product-manager-platform-apis_interview_pack.md`. It's built for Thursday's 45-minute hiring-manager conversation. It has 18 questions across five interviewer styles, with answer guidance for each, plus a fit snapshot, six reverse questions and a list of claims it won't coach.

- **Highest-ROI prep:** the underwriter's objection ("never held the PM title or owned a roadmap") is question A1. The guidance is to concede plainly first, then bridge only from your confirmed integration and roadmap-input work, with the limit named. E2 is the 60-second version.
- **Prohibited claims:** the pack never coaches holding a PM title, owning a roadmap, or setting priorities for a squad.
- **Slots to fill in your own words:** F3, F4, F5 and F6 are answer slots, because your confirmed evidence doesn't show whether you shipped an API product, worked with API docs or schemas, or worked in agile delivery. Write what's true or say plainly that it wasn't yours.
- **No research:** all three web searches (Quartzline values, interview process, strategy) were refused. The pack has no company-specific facts, and the case questions are generic. I didn't retry. The upgrade menu says what permission or a pasted careers page would add.

I asked no questions because the dossier supplied the role and your evidence, and you gave the round type.

Say the word and I'll play the hiring manager on A1, the question the pack names as highest-ROI.
I can also write a `tuesday-dossier.md` update recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** a 45-minute conversation with the hiring manager, on Thursday. The interviewer's name was not given, so there is no interviewer read. The pack rests on `tuesday-dossier.md` (job-underwriter, dossier version 1.1). Web research was refused in this session, so company values, loop details and strategy are not established anywhere in this pack.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores.

| Type | What it scores |
|---|---|
| VAL | Past behavior against the company's published values |
| EXP | Whether the experience claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Wherever a cell says "Answer slot", the words are yours: say what is true, or say plainly that it was not yours or did not happen.

## Prep triage

You have until Thursday. Do these in order.

1. Say A1 aloud until the concession comes out first and without apology, then E2 as the 60-second version of the same answer. The underwriter named this objection, and it is the highest-ROI prep in the pack.
2. Write your own answers to the slots in A3, A4, C1 and D3, then say them aloud once each.
3. Run B2 and B1 as spoken structures (clarify, objective, segmentation, approach, metrics, risks).
4. Pick two reverse questions from section 11. Take 1 and 2 first.

Everything else is insurance.

## Fit snapshot

The evidence column holds only your confirmed sentences from the dossier, in its own words. The dossier's confidence notes are carried in the Confidence column, not the quote.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile (R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's positioning: adjacent evidence, never PM experience. Your material shows no product manager title or role, and `prohibited_claims` keeps it that way. Words at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs" and "I ran quarterly roadmap-input sessions feeding client evidence to product." The limit comes before it is asked for. Plain acknowledgment, sourced to the dossier's `prohibited_claims`: "I haven't held the product manager title." The sessions line is medium confidence, confirmed with limited inspectable proof, so expect a probe |
| F2 | "Owning a roadmap and prioritization authority (R1 sub-claim)" — dossier uncertain_or_weak_areas | none given | none | [grounded] | capability | The dossier records this as an `acknowledge_gap` area. The words are the plain acknowledgment, sourced to that field and to `prohibited_claims`: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: learn how roadmap decisions are made today with the two squad leads, and how adoption is measured, before proposing changes. No bridge is built here |
| F3 | "Shipped API or platform products" — dossier role_profile (R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [grounded] | transferability | Your material says integrations of the vendor's REST APIs led from scoping to go-live, and says nothing about shipping an API or platform product itself. The words stay at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the requirement's own wording makes a probe likely on whether you shipped the API or platform product itself. If you did, say what and which part was yours; if not, or it was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile (R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes touch REST APIs, architecture and a written playbook, and do not show whether API docs or schemas were part of that work. Answer slot: the requirement names API docs and schemas, so expect a probe on them. If you read or wrote any in those integrations, say which and what you did with them; if you did not, say so plainly and stay with the integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile (R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes carry client-facing integration work and a client-evidence channel to product. They do not show whom else you worked with. Answer slot: if others beyond the clients were part of the scoping-to-go-live work, say who and what you did with them; if not, say so plainly and stay with the clients and the sessions. The sessions line carries the medium caveat |
| F6 | "Agile delivery experience" — dossier role_profile (R5) | none given | low | [grounded] | discovery | The dossier's allowed strategy is `clarify`, and no confirmed sentence speaks to this requirement. Answer slot: the requirement names agile delivery, so expect a probe on whether you have worked that way inside a product org. If you have, say how in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline's squads define it |

## Persona table

The relationship prior for a hiring manager is Case/Strategist plus Skeptic. The dossier names an objection that is a Skeptic item at its core, so that persona leads. The loop is one session, from your own description: 45 minutes with the hiring manager. No interviewer information exists to adjust further.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the title and roadmap gap | Highest. The underwriter named an objection of exactly this kind, and a 45-minute hiring-manager round is where gaps get derisked | Rehearse the objection until it is boring: concede first, bridge from quoted adjacent work only, name the limit before it is asked, give a ramp plan as a plan |
| B. Case/Strategist | Live problems from the actual role: adoption, prioritization across two squads, partner discovery | High. Hiring managers buy capability, and the JD's own responsibilities hand them four ready-made cases | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| C. Data-Driven Prober | Reads your claims line by line and asks how the number was counted | Medium. The 30+ figure is a headline number, and a hiring manager with limited time will test one claim deeply | Know what you can and cannot say about how 30+ was counted, and say plainly when you do not know |
| D. Conversational | A friendly walk-through-the-journey opener | Medium. Usually the first five minutes, and still scored | A 90-second arc built only from your confirmed sentences, then the motivation in your own words |
| E. Pressure | A time-boxed challenge, such as sixty seconds on why you | Low to medium. It is likely only as a compressed form of A1, not as a style for the whole session | Pause, restate the question, anchor in what you stated, hold through two follow-ups, concede specifically |

## Requirement coverage

| Requirement or responsibility | Covered by |
|---|---|
| R1: 3+ years product management experience | A1, A5, D1, E2 |
| R1 sub-claim: owning a roadmap and prioritization authority | A1, A2, A5, B2 |
| R2: shipped API or platform products | A3, A4 |
| R3: technical fluency: API docs, schemas | B3, C2, D2 |
| R4: stakeholder management across engineering, sales, customers | B2, C3 |
| R5: agile delivery experience | D3 |
| Responsibility: run discovery with integration partners | B4 |
| Responsibility: write specs and drive delivery with two engineering squads | B2, C2 |
| Responsibility: define and track adoption metrics | B1, B5 |
| Headline figure: 30+ integrations | C1, E1 |

## Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | The underwriter named this objection (`likely_interviewer_objections`), so it gets the deepest rehearsal. Move one, concede first and plainly, with words sourced to `prohibited_claims` and the `acknowledge_gap` area: "I haven't held the product manager title, and I haven't owned a roadmap." Move two, the adjacent case with its limit named before it is asked for: "What I bring is adjacent: I led 30+ end-to-end client integrations of the vendor's REST APIs, and I ran quarterly roadmap-input sessions feeding client evidence to product." The sessions line is medium confidence, so answer slot: if you are asked what you can show of them, say what you can show and what you cannot. Move three, follow-ups. If asked "so what did you decide?", return to the two quotes and add nothing. If asked "why isn't the years requirement disqualifying?", concede that you do not have the years in the seat, stay with the adjacent case and do not argue the requirement away. If asked for your first 90 days, give a plan, not a past: learn how roadmap decisions are made with the two squad leads and how adoption is measured, before proposing anything | Named by the underwriter, and it sits on F1 and F2, where the material is thinnest. JD because it scores the title requirement and its roadmap sub-claim, and the premise is the interviewer's, not adopted as yours |
| A2 | "Which roadmap decisions would you want to make alone on day one, and which would you leave to the squad leads?" | JD | [inferred] derived from the role_profile responsibility "Own the roadmap for the partner-facing API platform" | This question asks about the future and needs no claim about your past, so the guidance makes none. Answer with a principle: you would ask first what the current split is, you would not assume authority the squad leads hold, and you would propose the decision rights you want to agree after you have seen how decisions are made today. Then turn it round: ask which decisions this PM makes alone. That is reverse question 1 | The JD asserts roadmap ownership against two squads, and the dossier flags the authority split as unevidenced. Asked here as a plan, it tests judgment about authority without inviting a claim of having had it (F2) |
| A3 | "Tell me about a time you shipped an API or platform product." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3 at the quote's own scope: you led integrations of the vendor's REST APIs, and the beats are the quote's own: scoping, requirements, architecture, UAT, go-live. Tell them in your own words. Answer slot: the requirement's wording makes a probe likely on whether you shipped the API or platform product itself. If you did, say what and which part was yours; if not, or it was not yours, say so plainly and stay with the integrations you led. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry | R2 is a must-have, and F3 is where the question presses. JD because it scores the stated requirement |
| A4 | "On the integrations you led, where did your responsibility end?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | A boundary question rehearsed so the honest edge is ready. Hold the quote: you led them end to end. Answer slot: say which of scoping, requirements, architecture, UAT and go-live you carried yourself, in your own words, and where anyone else took over; if a stage was not yours, say so plainly. Never extend the boundary past what you can defend on a second question | An end-to-end claim invites a where-did-it-stop probe, and a clean edge is a credibility gain. EXP because it tests what was actually yours (F3, F5) |
| A5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] dossier `acknowledge_gap` area: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name the roadmap area, because the dossier's `acknowledge_gap` area already does: "I haven't owned a roadmap." Then the ramp plan, as a plan: ask the squad leads how decisions are made today, learn how adoption is measured, and agree what you will own first. Do not bridge here. Calibrated candor on the weakest part reads as judgment, and a bluff on a competency the hiring manager owns is the failure | The Skeptic's stock question lands on F2. JD because it scores honest self-assessment against the listed job |

### B. Case/Strategist (high weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner adoption of a newly released API endpoint is flat after six weeks. What do you need to know first, and how do you diagnose it?" | CASE | [generic] | Clarify first: what counts as adoption here and how it is measured today, which is an open question for this role. Then objective, a segmentation of partners by where they are in integrating, an approach for each segment, the metrics you would watch and the risks to your own diagnosis. Challenge one premise respectfully, for instance whether flat adoption is a product problem at all. The question presupposes nothing about your past | The JD makes adoption metrics a responsibility, and the dossier says the current baseline is unstated. `[generic]` because it is a pattern for the problem, not a fact about Quartzline |
| B2 | "A partner is pressing for a breaking schema change next quarter, one squad lead wants to finish a reliability backlog first, and sales has made a commitment. How do you decide?" | CASE | [generic] | Clarify who owns the call, which is itself the open authority question. Set the decision criteria before the options: partner impact, cost of delay, risk to existing integrations. Name what you would need from each squad lead, how you would make the trade-off visible to sales and the partner, and what you would do if the squad leads disagree with you. State the assumptions aloud. The question needs no claim about your past, so the guidance makes none | It puts R4's three stakeholder groups and the two-squad setup into one live problem, and it probes the authority gap without asking you to claim authority (F2, F5) |
| B3 | "A partner's integration keeps failing in UAT on a schema mismatch. Where do you look first, and what changes in the documentation or the spec?" | CASE | [generic] | Separate the contract from the implementation: is the documented schema wrong, ambiguous or ignored? Reproduce, find which side deviates, decide what is a docs fix, a spec fix or a versioning decision, and say who you would pull in from the owning squad. Then what you would measure so it does not recur. The question needs no claim about your past | R3 asks for fluency with API docs and schemas, and a live schema problem tests it without asking you to claim any (F4) |
| B4 | "You have two weeks to run discovery with six integration partners. Plan it." | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Clarify the decision the discovery must inform, then who to speak to and why, the questions that separate stated wants from observed pain, and how findings reach the squads. If it helps, mention your sessions at the quote's own scope: you ran quarterly roadmap-input sessions feeding client evidence to product. They carry a medium caveat, so answer slot: if asked what you can show of them, say what you can show and what you cannot. Do not describe what the evidence changed unless you can say it plainly | Discovery with integration partners is a listed responsibility. CASE because it is a live plan, with F5's medium-confidence sessions as the one place your own material may come up |
| B5 | "Which three adoption metrics would you track for the partner API platform, and how would you set a baseline?" | CASE | [generic] | Pick metrics that move at different stages: reaching a first working integration, depth of use afterwards, and retention of partners over time. Say what each tells you, how you would measure it, and what would make you distrust it. For the baseline, say plainly that you would first find out what is already measured and how. The question needs no claim about your past | Adoption metrics are a responsibility and the baseline is an open question in the dossier, so the honest move is to ask before inventing one |

### C. Data-Driven Prober (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ client integrations. How was that counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The figure counts integrations, and it stays attached to that noun. The pack supplies no counting method. Answer slot: say how the 30+ was counted, in your own words, or say plainly that you do not know how it was counted. Answer slot: say what the count is most sensitive to, such as where you started and stopped counting. Answer slot: name the assumption behind the figure you would defend least, before the interviewer does. Answer slot: say which part of the count was yours. "I'd want to check the exact number" is an honest branch | A headline figure is a magnet for probers. EXP because it tests precise attribution of F1's and F3's evidence |
| C2 | "Walk me through the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Beats at the quote's own scope: you wrote the internal integration playbook your team uses. Tell what it covers in your own words. Answer slot: the JD's spec-writing responsibility makes a probe likely on how the playbook compares with writing specs. If any of it was written for engineering squads, or included API or schema documentation, say what; if not, say so plainly and stay with the playbook as it is. The dossier marks this evidence high confidence and inspectable, so it is the safest ground you have. Check whether you may share it before offering to walk through it | The playbook is the inspectable proof behind F4's and F3's evidence. EXP because a prober can ask to see it |
| C3 | "Tell me about a time sales and engineering wanted different things from the same client integration." | JD | [inferred] derived from the role_profile requirement "Stakeholder management across engineering, sales, customers" | Selection scaffold, because none of your confirmed sentences carries this story. Pick an instance that has a named disagreement, your own part in resolving it, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Do not supply who was involved or how it ended unless that is what happened | R4 is an important requirement, and F5 shows the evidence is thin on whom you worked with beyond clients |

### D. Conversational (medium weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey: how did you get from integration work to wanting to be a product manager?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, each a confirmed sentence in your own words: you led the integrations, you wrote the playbook, you ran the roadmap-input sessions. The arc ends at the sessions, with no step beyond them, so it stays adjacent to the role, not inside it. Answer slot: say in your own words what drew you to the product side; if it is not about the product work itself, say that plainly | The biography question opens most hiring-manager conversations and is scored. It carries F1's evidence in the order the underwriter's positioning wants |
| D2 | "What are you actually playing with in the API space these days?" | JD | [generic] | Selection scaffold. Pick something you have genuinely used or read, such as a documentation set or a schema approach, and say what you noticed about it, and what you would copy or avoid. If nothing comes to mind, say so plainly, then say what you would look at first and why | A casual question about the JD's technical-fluency topic is still scored (F4) |
| D3 | "What does a good delivery cycle with a squad look like to you?" | JD | [grounded] role_profile requirement "Agile delivery experience" | The dossier's strategy is `clarify`, and no confirmed sentence speaks to it, so nothing about your past goes into the answer unless you supply it in the slot. Answer slot: the requirement names agile delivery, so expect a probe on whether you have worked that way inside a product org. If you have, say how in your own words; if you never worked that way, say so plainly. Then the honest follow-through: ask how Quartzline's two squads run their cycle, and say what you would want to confirm about how they define it | R5 is preferred, and F6 has no evidence. The dossier calls the gap a discovery gap, so the answer is a clarification, not a claim |

### E. Pressure (lower weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That integration work: how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause and restate the question. Hold the quote through two follow-ups: you led them, end to end. Concede specifically, never generally. Answer slot: say which parts others carried or shared, in your own words, and if no part was shared, say so plainly. Never fold the core claim to restore harmony, and never add to it under pressure. The dossier rates this evidence high confidence, and the playbook is inspectable, which is why holding is safe | The pressure form of A4. EXP because it scores attribution under challenge (F3) |
| E2 | "Sixty seconds: why you over a PM with three years in the seat?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A1 compressed to a minute. Concede in the first sentence, sourced to `prohibited_claims` and the `acknowledge_gap` area: "I haven't held the product manager title or owned a roadmap." Then one adjacent sentence with its limit: "I led 30+ end-to-end client integrations of the vendor's REST APIs and ran quarterly roadmap-input sessions feeding client evidence to product, which is adjacent, not the same job." Then stop. Do not fill the silence | A time-boxed version of the named objection. A prepared concession is the only thing that survives the clock (F1, F2) |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The underwriter's second condition: decision authority against the two squad leads is asserted in the JD and not evidenced. It reads as diligence, and you genuinely need the answer before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier flags adoption metrics as a named responsibility with no stated baseline. It shows you are already thinking about B1 and B5 |
| 3 | "What would you want to have seen from me by day 30, and by day 90?" | It asks the hiring manager to define success, and it gives you the ramp plan's shape from the person who will judge it |
| 4 | "Who would I learn roadmap ownership from here, and how do the two squad leads and the PM work through a disagreement today?" | It names the gap you have already conceded and asks how Quartzline closes it, so the concession is a plan and not a confession |
| 5 | "Where do integration partners most often get stuck today?" | It invites the hiring manager to describe real partner friction and shows discovery instincts without a claim about your past |
| 6 | "Is there anything in my background you would want me to address before we finish?" | It gives the hiring manager the chance to raise the title and roadmap objection, with you holding the rehearsed answer from A1 |

## Prohibited claims

These are the claims this pack will not coach. The first three come from the dossier's `prohibited_claims`. The last three are built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The plain acknowledgment, sourced to that field: "I haven't held the product manager title." Then the adjacent quotes at their own scope |
| Having owned a product roadmap | Dossier `prohibited_claims`, and the `acknowledge_gap` area on roadmap ownership | The plain acknowledgment, sourced to those fields: "I haven't owned a product roadmap." Then a ramp plan as a plan. No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | Not claimed or implied anywhere. In B2 and A2 it appears only as a decision you would reason about as a future PM |
| Shipped the API or platform product itself | Inflated form of F3 | F3's quote at its own scope: you led integrations of the vendor's REST APIs. The limit is the pack's observation: your material says integrations, not a shipped product. A3's slot stays on what you led |
| Shaped the roadmap through the sessions | Inflated form of F1 and F5 | The quote at its own scope: you ran quarterly roadmap-input sessions feeding client evidence to product. The pack's observation is that the material says what the sessions fed, not what was decided |
| Managed stakeholders across engineering and sales | Inflated form of F5 | F5's quote at its own scope: client-facing integration work. The limit is the pack's observation: your material shows clients, not who else was involved. C3's scaffold ends in its honest branch |

## Sources

Provided documents: `tuesday-dossier.md` from job-underwriter, dossier version 1.1, generated 2026-08-14, pasted in the conversation. Sections consumed: `role_profile` (the JD-equivalent requirements and responsibilities), `decision` (context only), and `handoff_to_mock_interview` (verified candidate evidence, uncertain areas with their allowed strategies, the named objection, risks and employer questions for the reverse bank, and prohibited claims). The dossier carried no `evidence_map`, `risk_register` or `evidence_state`, so none of those fed the pack. The persona weights and the loop rest on your own description of the round: one 45-minute conversation with the hiring manager.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | The search was refused, so no values were established. It would have fed a values cheat sheet, which is also dropped because no loop source documents a values round |
| 2. `Quartzline interview process product manager` | unavailable | The search was refused. It would have checked the loop structure, which currently rests only on your own words |
| 3. `Quartzline API platform strategy news` | unavailable | The search was refused. It would have grounded CO and CASE questions in current strategy, so B1 to B5 are `[generic]` |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative Product Manager, Platform APIs JD | skipped | The dossier's `role_profile` already supplies the requirements and responsibilities the fit snapshot and JD-tagged questions rest on |

Queries sent: "Quartzline company values" (refused); "Quartzline interview process product manager" (refused); "Quartzline API platform strategy news" (refused).

## Upgrade menu

- Permission to search, or a pasted Quartzline values page and careers page → a values and loop check, and CO and CASE questions grounded in current strategy in place of B1 to B5's generic setting
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief for the CO and CASE questions, public talks and writing by your interviewer if you have a name, and loop reports for this role family
- The hiring manager's name → an interviewer read, tuned persona weights and a reverse question tied to their own path
- The recruiter's prep email → focus areas, and coverage of any pre-declared deliverable
- An agenda or output document from one of the quarterly roadmap-input sessions → moves F1's and F5's medium-confidence evidence toward inspectable
- The raw CV behind the confirmed claims → more of F3, F4 and F5 can be story-mapped in your own words
- Your own answers to the slots in F3, F4, F5 and F6, stated here in the conversation → those rows regenerate from your words
