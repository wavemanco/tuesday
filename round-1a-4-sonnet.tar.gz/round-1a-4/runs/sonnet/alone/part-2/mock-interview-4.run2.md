I'll read the skill's reference files before building the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-4-denied-2ae02618/quartzline_product-manager-platform-apis_interview_pack.md`. I built it for a 45-minute hiring-manager conversation with an unnamed interviewer, using your dossier for the requirements, verified evidence and prohibited claims.

- **Web search was denied.** All three searches were refused, so nothing about Quartzline's values, loop or strategy is researched. The cases come from the JD's responsibilities instead, and the pack has no company-knowledge questions. Sources and the upgrade menu say what that cost.
- **Top rehearsal:** A1 is the objection the underwriter named: no PM title, no roadmap, so why you over a PM with three years in the seat. It runs through four beats and three follow-ups. The first beat concedes the gap using the dossier's own prohibited-claims wording. The second bridges at the scope of the 30+ integrations and the playbook. The third names the limit as adjacent work. The fourth is a ramp plan.
- **Roadmap ownership:** it gets a plain acknowledgment and a ramp plan, with no bridge, as the dossier requires. The quarterly roadmap-input sessions are medium-confidence and stay at their own scope.
- **Open slots:** agile delivery, adoption metrics, API docs and schemas, and specs have no evidence behind them yet. They are answer slots with an honest second branch, not scripted claims.
- **Contents:** 21 questions across six personas, a requirement-coverage table, six reverse questions including your two employer questions, and a prohibited-claims list.

Say the word and I'll play the Skeptic on A1 so you can rehearse it live.
I can also save an updated `tuesday-dossier.md` recording what this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

Hiring-manager conversation, 45 minutes, Thursday. The interviewer is not named. Built from your underwriting dossier (conditional_go) and your note that this is a conversation with the hiring manager.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Each question carries one of each.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. None in this pack: no values round was detected and no values page could be read |
| EXP | Whether a claim about your work survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy. None in this pack: research was refused, so nothing about Quartzline's strategy is established |
| CASE | A live problem from the role, scored on structure and reasoning |

Guidance is scaffolding, not a script. Every sentence in it about your past rests on a quote shown in that row's Provenance cell. Where the material does not reach, the guidance is an answer slot: an instruction for the interview, with an honest second branch.

The objection the underwriter named, A1, is the highest-ROI prep in this pack. It will be asked in some form, and a rehearsed, non-defensive answer changes the conversation.

## Prep triage

Sized to the time before Thursday. Do these in order.

1. Say A1 aloud until it is boring: the concession, the bridge at its own scope, the limit named before it is asked for, the ramp plan, then the three follow-ups.
2. Run E1 (the sixty-second version) and A2 straight after A1, so the same concession comes out the same way under time pressure.
3. Rehearse C1 and C2, the 30+ integrations, and D1, the 90-second arc. D2 carries a medium-confidence caveat you should volunteer.
4. Learn B2 and B4 as structures, and memorize the first two reverse questions.

Everything else is insurance.

## Fit snapshot

Requirement lines are quoted from the dossier's role_profile. Evidence cells hold only the verified entries quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile (R1) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's strategy is bridge, positioned as adjacent and never as PM experience. Your material says integration leadership and a playbook, not product management, and the words stay at that scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Plain acknowledgment, sourced to the dossier's prohibited_claims field: "I haven't held a product manager title or role." Answer slot: if any of scoping, requirements or architecture was yours to decide, say which and how you decided; if those were set elsewhere, say so plainly and stay with leading the integrations |
| F2 | "Shipped API or platform products" — dossier role_profile (R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | The quoted claim is high-confidence and inspectable through the playbook, but it says client integrations of the vendor's APIs through go-live, not shipping an API product, so this row grades reach and stays low. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through go-live." Answer slot: if any of the 30+ went live through work that was yours, say which and what part; if it was someone else's, say so plainly and stay with leading the integrations |
| F3 | "Technical fluency: API docs, schemas" — dossier role_profile (R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The quotes carry REST API integration work and a playbook, and neither names API docs or schemas. Words stay at: "I led integrations of the vendor's REST APIs, including architecture, and I wrote the internal integration playbook my team uses." Answer slot: if the integrations or the playbook involved reading or writing API documentation or schemas, say which and what you did with them; if they did not, say so plainly and stay with the integrations and the playbook |
| F4 | "Stakeholder management across engineering, sales, customers" — dossier role_profile (R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | Clients and product appear in the quotes; engineering and sales appear in none. The roadmap-input quote is confirmed with limited inspectable proof, so expect a probe and volunteer where your part stopped. Words: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if the work put you in front of engineering or sales colleagues, say who and what part was yours; if it was clients and product only, say so plainly |
| F5 | "Agile delivery experience" — dossier role_profile (R5) | none given | low | [grounded] | discovery | The underwriter's strategy is clarify, and no verified entry speaks to this requirement. Answer slot: the JD's agile line makes a probe on how delivery ran likely. If you worked inside an agile process, say how it ran and which part was yours; if you never worked that way, say so plainly, then say what you would want to confirm about how Quartzline's squads define it |
| F6 | "Own the roadmap for the partner-facing API platform" — dossier role_profile (responsibility, with the R1 sub-claim of roadmap and prioritization authority) | none given | none | [grounded] | capability | The underwriter's strategy is acknowledge_gap: no bridge. Words, sourced to the dossier's prohibited_claims field: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan said as a plan and never as a past: what you would learn first and from whom. No slot, and the roadmap-input quote in F4 and F7 is not offered as a stand-in |
| F7 | "Run discovery with integration partners" — dossier role_profile (responsibility) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | Confirmed with limited inspectable proof, so expect a probe. Words at the quote's scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: if you gathered the client evidence for those sessions through conversations with clients, say how; if it reached you another way, say so plainly and describe the sessions as they were |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile (responsibility) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote touches requirements and UAT and does not show whether specs were written or squads driven. Answer slot: if you wrote requirements or specs that engineers built from, say what they covered and who built from them; if you did not, say so plainly and stay with leading the integrations through UAT and go-live |
| F9 | "Define and track adoption metrics" — dossier role_profile (responsibility) | none given | none | [grounded] | discovery | Nothing in the material shows or denies it. Answer slot: if you defined or tracked any measure of how clients used the APIs, say what was counted and how; if none was, say so plainly, and say what you would measure first |

The dossier lists no hard gates, and no requirement here is a term such as a credential or location, so no gate row appears.

## Reading the interviewer

Not included: no interviewer name or profile was provided. Persona weights below rest on the hiring-manager round type. See the upgrade menu.

## Persona table

Weights start from the hiring-manager prior (Case and Skeptic dominant) and are adjusted by the dossier. No loop source beyond your own note was available, so the loop is one 45-minute conversation and no values-style round is assumed.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet, persistent probing of the title and roadmap gap, then of agile and shipped products | Highest, 5 questions. The hiring-manager prior, plus the underwriter named this exact objection from evidence you confirmed | Rehearse A1 until boring. The bridge uses only the quoted integration and playbook sentences, with the limit named first |
| Case and Strategist (bank B) | Live problems from the role: diagnose flat adoption, settle two squads' priorities, a partner's off-roadmap request | Highest, 5 questions. The hiring-manager prior; the JD's responsibilities (roadmap, specs, two squads, adoption metrics) are all case material | Clarify, then objective, segmentation, approach, metrics, risks. Ask who decides before deciding anything |
| Data-Driven Prober (bank C) | Takes the 30+ line and asks how it was counted and what was yours | Medium-high, 4 questions. The one headline number in the verified evidence is a defend-the-number target | Know what you can and cannot say about how it was counted, and say plainly where you do not know |
| Conversational (bank D) | Friendly opener, "walk me through the journey", casual follow-ups on the roadmap-input sessions | Medium, 3 questions. A 45-minute manager conversation usually opens this way, and casual questions are still scored | A 90-second arc built only from the three quoted sentences, with the roadmap-input limit volunteered |
| Pressure (bank E) | Time-boxed challenge on why you over a PM with the seat time | Low, 2 questions. The objection can arrive compressed, even in a friendly conversation | Hold the quoted position through two follow-ups, concede the title and roadmap plainly, never fold on the core claim |
| Peer Evaluator (bank G) | The seam with the two squad leads and credit across teams | Low, 2 questions. Decision authority versus the squad leads is an open risk in the dossier | Propose seam principles rather than pretending to know the seam; ask the authority question |

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | The highest-ROI rehearsal in this pack, the objection the underwriter named. Hold-then-concede in four beats. One, concede first, before it is extracted: "I haven't held a product manager title or role, and I haven't owned a product roadmap" (both negatives are the dossier's prohibited_claims items named in Provenance). Two, hold the bridge at the quotes' scope and call it adjacent, never PM experience: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I wrote the internal integration playbook my team uses." Three, name the limit yourself: this is adjacent work, not the PM job. Four, a ramp plan said as a plan: what you would learn first and from whom, starting with who decides what between the PM and the squad leads and how adoption is measured today. Follow-up 1, "Which parts of those were your call?" Answer slot: if any of scoping, requirements or architecture was yours to decide, say which and how you decided; if those were set elsewhere, say so plainly and stay with leading the integrations. Follow-up 2, "Have you ever set prioritization for an engineering squad?" The dossier's prohibited_claims item "Having set prioritization for an engineering squad" supports one answer: "I haven't set prioritization for an engineering squad." Then return to the ramp plan, and do not reach for the roadmap-input sessions, which are feeding evidence to product (D2). Follow-up 3, "Then why not just hire the PM?" Add nothing: restate the two quoted sentences and the plan, and concede the real risk, the missing PM years, rather than arguing it away | F1 and F6 are where the title and roadmap gap sits, so this arrives in some form in a hiring-manager round. JD because it scores the core requirement, with Pressure-style follow-ups built in |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | Name the real weakest part first, in your own words, and make it the one the dossier records: roadmap ownership and prioritization authority. The words the dossier supports: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the ramp plan as a plan: what you would learn in the first weeks, from the squad leads and from partners, and how you would find out how adoption is measured. Do not offer a bridge on this one | F6 is the row with no credible evidence, and a weakest-part question lands exactly there. JD because it asks about the listed job |
| A3 | "Why move from integration work into product management, and why this platform?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The question's premise is the quoted integration work. The reason is yours and the pack does not supply one. Selection criteria: pick the real reason, tie it to something specific about a partner-facing API platform that you can say in your own words, and keep it to what is true. If the honest answer is that the reason is still forming, say so plainly, then say what you want to find out in this role | F1 is the transition the interviewer is pricing. EXP because it tests whether the story hangs together, and a motive is the one thing nobody can write for you |
| A4 | "Tell me about how you've worked with agile delivery teams." | JD | [grounded] | No quote speaks to this requirement. Answer slot: the JD's agile line makes a probe on how delivery ran likely. If you worked inside an agile process, say how it ran and which part was yours; if you never worked that way, say so plainly, then say what you would want to confirm about how Quartzline's squads define it, and ask it back | F5 is a clarify area, so the honest answer is a question-shaped one. JD because it scores the preferred agile requirement |
| A5 | "What API or platform products have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F2: the integrations, the thirty-plus, and the stages the quote names, told in your own words. Answer slot: the JD's line makes a probe on what went live through your work likely. If any of the 30+ did, say which and what part was yours; if it was someone else's, say so plainly and stay with leading the integrations. If a follow-up asks directly whether the product itself was yours, answer what was asked in your own words, then return to the integrations | F2 is a must-have with adjacent evidence only. JD because it scores a stated requirement head on |

### Bank B: Case and Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Adoption of a partner API looks flat. How would you diagnose it?" | CASE | [inferred] | Derived from the JD's adoption-metrics responsibility and framed as typical for the role, not as Quartzline's practice. Structure it aloud: clarify first, starting with how adoption is defined and measured today and what the baseline is, which the dossier lists as unknown; then the objective; then segment partners by where they are in their integration; then one hypothesis per segment; then the metric you would watch for each; then the risks. Challenge one premise politely: is it flat, against what baseline. The question needs no claim about your past, so the guidance makes none | F9 and the dossier's open adoption baseline make this the likeliest case. CASE because it scores structure, and the first clarifying question is itself the reverse question you need answered |
| B2 | "The two squad leads want different priorities for next quarter. How do you decide?" | CASE | [inferred] | Derived from the JD's two-squad responsibility. Ask who decides first, because decision authority versus the squad leads is unestablished: say it aloud as the first clarifying question. Then criteria, kept visible and agreed before options; the evidence from partners; the options and their costs; how the two leads reach a decision with you; and when you would take it to the hiring manager. Propose these as principles for a seam, and do not claim a right to override. The question needs no claim about your past | F6 and the dossier's authority risk meet here. CASE because it is a live problem from the role |
| B3 | "A large partner asks for a custom endpoint that is not on the roadmap. What do you do?" | CASE | [inferred] | Derived from the JD's roadmap responsibility. Clarify who is asking and what is blocked; test whether this is one partner's need or several; consider what the existing API can do; decide what evidence would justify roadmap input and bring that evidence to the roadmap discussion with the squad leads. Practice the polite no and the not-now in your own words. No claim about your past is needed | F6 and F7 make a request-versus-roadmap question likely. CASE because it scores judgment under a specific tension |
| B4 | "You start Monday. What do your first 30 days look like?" | CASE | [inferred] | A ramp plan said as a plan, never as a past. Listen first: both squad leads, then partners; pin down who decides what; get the adoption baseline; and agree what you will and will not promise in the first month. This is also the ramp plan A1 and A2 point to, so the same words should recur | F6 is an acknowledge_gap area, and the answer to it is a ramp plan. CASE because it asks for a structured plan on the role |
| B5 | "Outline the spec for a new endpoint. What is in it, and what do you ask engineering first?" | CASE | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Derived from the JD's specs responsibility. Structure: the problem and the partner evidence for it, who is affected, the success measure, scope and non-goals, open questions for engineering, rollout and documentation, risks. Ask engineering about constraints and effort before committing to scope. Answer slot: the quote names requirements, so if you wrote requirements that engineers built from, say what they covered and who built from them; if you did not, say so plainly and stay with the structure | F8 is a discovery area, so the case doubles as a probe. CASE because it scores structure, with a slot where your own record might help |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through one of the 30+ integrations, from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Story-mapped on F2: pick one integration and tell it through the stages the quote names, scoping, requirements, architecture, UAT and go-live, in your own words. Answer slot: the quote gives the stages, not what happened in each. If any decision at architecture or UAT was yours, say which and how you decided; if it was set elsewhere, say so plainly and stay with how you led it. You can offer to walk the interviewer through the playbook you wrote | F2 and F3 rest on this evidence, and it is the strongest inspectable material you have. EXP because it tests what was actually yours |
| C2 | "Walk me through how the 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The defend-the-number move, in your own words. Answer slot: say what counted as one integration, what the figure is sensitive to, the assumption behind it you would defend least, and which part of the 30+ was yours. If you do not know how a figure was counted, say that plainly. Do not offer a method you cannot repeat under a second question | F1 and F2 depend on this one headline figure, so a prober starts here. EXP because it tests attribution |
| C3 | "The role needs fluency with API docs and schemas. Where has that shown up in your work?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Say what the quotes say: REST API integrations including architecture, and the playbook you wrote. Answer slot: the JD's line makes a probe on documentation and schemas likely. If the integrations or the playbook involved reading or writing API documentation or schemas, say which and what you did; if they did not, say so plainly and stay with the integrations and the playbook | F3 is an important requirement with adjacent evidence only. JD because it scores the stated requirement |
| C4 | "The role defines and tracks adoption metrics. What have you measured?" | JD | [grounded] | No quote speaks to this. Answer slot: if you defined or tracked any measure of how clients used the APIs, say what was counted and how; if none was, say so plainly, and say what you would measure first | F9 has no evidence in the material, so the honest answer is a slot with a plan as its second branch. JD because it scores a listed responsibility |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each one of the quoted sentences, in your own words and in this order: leading the integrations, writing the playbook, running the quarterly roadmap-input sessions. The third is confirmed with limited inspectable proof, so volunteer where your part stopped before anyone extracts it. Then close on why this role, in your own reason. No beat beyond the three is supplied | F1, F4 and F7 are the evidence a journey question draws on. EXP because it opens the attribution conversation |
| D2 | "Tell me about the roadmap-input sessions. How did they work?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Medium confidence: confirmed, limited inspectable proof, so expect the probe and volunteer the limit. Say what the quote says and no more. Answer slot: if you gathered the client evidence through conversations with clients, say how; if anything changed on the roadmap as a result, say what and who decided; if nothing did, or the decision was product's, say so plainly. Never present the sessions as owning the roadmap | F7 and F4 rest on this quote. EXP because it is the claim with the least inspectable proof behind it |
| D3 | "Tell me about working with engineering, sales and customers at the same time." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Selection criteria: pick an integration where more than one of those groups wanted different things; it needs a named stake, what you did, and a working relationship intact at the end. Your quoted work reaches clients; whether it reached engineering or sales is an answer slot: if it did, say who and what part was yours; if it did not, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is a transferability row, and this open prompt takes the JD's stakeholder line directly. JD because it scores the stated requirement |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has done this job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | The compressed A1. Pause and restate the question. Concede in one clause: "I haven't held a product manager title or role." Hold in one: "I led 30+ end-to-end client integrations of the vendor's REST APIs, through go-live." Name the limit: it is adjacent work. Close on the plan. Hold through two follow-ups; do not add to the quote | F1 is the likeliest pressure target. JD because the content is the same requirement as A1 |
| E2 | "That result. How much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold what the sentence carries: you led them. Answer slot: if some of the stages were shared or set elsewhere, say which and who by; if all of it was yours, say that plainly, and say what the playbook shows. Concede specifically where it was not yours, and never fold on the core claim to restore harmony | F1 and F2 depend on the attribution of this one line. EXP because it tests precision under pressure |

### Bank G: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "The role owns the roadmap and the squads own delivery. Where is the seam, and what happens when we disagree?" | CASE | [inferred] | Derived from the JD's roadmap and two-squad lines. Do not pretend to know the seam: say it is the thing you would want to settle first, and ask which roadmap decisions the PM makes alone. Then offer principles: decisions made on partner evidence, disagreements surfaced early and decided by a named person, nothing relitigated after the call. No claim about your past | F6 and the dossier's authority risk sit under this. CASE because it is a live seam problem |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection criteria: pick a piece of work that spanned teams, say we for context and I for your own contribution, and name one thing someone else did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The integration work spans client and vendor teams in general, but nothing in F1 to F9 shows how credit was handled. EXP because it tests attribution style |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "3+ years product management experience" | A1, A2, A3, E1 |
| "Shipped API or platform products" | A5, C1, E2 |
| "Technical fluency: API docs, schemas" | C3, C1 |
| "Stakeholder management across engineering, sales, customers" | D3, D2, B2 |
| "Agile delivery experience" | A4 |
| "Own the roadmap for the partner-facing API platform" | A1, A2, B2, B3, G1 |
| "Run discovery with integration partners" | D2, B1, B3 |
| "Write specs and drive delivery with two engineering squads" | B5, B2, G1 |
| "Define and track adoption metrics" | C4, B1 |

## Reverse questions

Role-generic, because no interviewer was named. The first two come straight from the dossier's open risks and employer questions.

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts the authority and the dossier found no evidence for it. The answer decides whether the role is what it says, and it reads as diligence |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are named as a responsibility with no baseline stated. The answer tells you whether you inherit a measure or define one |
| 3 | "How do the two squads run delivery today, and where does product sit in that rhythm?" | F5 is a clarify area: the JD says agile and does not say how it is practiced. This lets you confirm how it is defined without claiming a practice |
| 4 | "Who talks to integration partners today, and how does what they say reach the roadmap?" | The role runs discovery with partners. The answer shows where the discovery work sits now and what you would take over |
| 5 | "What would the first 90 days need to deliver for you to call this hire a success?" | It turns the ramp plan from A1 and B4 into the manager's own criteria, and it tells you what they expect at day one |
| 6 | "What is the hardest part of this role that is not in the posting?" | An open invitation to name the real difficulty, which is also where your answer to A2 will be tested |

## Prohibited claims

What this pack will not coach, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | prohibited_claims: "Having held a product manager title or role". Plain acknowledgment: "I haven't held a product manager title or role." The F1 quote at its own scope. No bridge that implies the title |
| Having owned a product roadmap | Dossier prohibited_claims, and the acknowledge_gap area | prohibited_claims: "Having owned a product roadmap". Plain acknowledgment plus a ramp plan, said as a plan. The roadmap-input quote stays at its own scope in F4 and F7 and is not a stand-in |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | prohibited_claims: "Having set prioritization for an engineering squad". Plain acknowledgment: "I haven't set prioritization for an engineering squad." B2 and G1 coach a decision process as a plan, never as a record |
| Shipped API or platform products | Inflated form of the F2 evidence | The F2 quote at its own scope. The limit is the pack's observation: your material says client integrations of the vendor's REST APIs through go-live, not shipping an API product. A5's slot stays inside the integrations |
| Wrote API documentation or schemas | Inflated form of the F3 evidence | The F3 quote at its own scope. The pack's observation: your material says an integration playbook, not API docs or schemas. C3's slot stays inside the integrations and the playbook |
| Ran product discovery with partners | Inflated form of the F7 evidence | The F7 quote at its own scope. The pack's observation: your material says roadmap-input sessions feeding client evidence to product, with limited inspectable proof. D2's slot stays inside the sessions |

## Sources

Provided documents: your message, and tuesday-dossier.md (dossier version 1.1, generated by job-underwriter) pasted in the conversation. The dossier supplied: role_profile (every requirement and responsibility line quoted above, standing as the JD); handoff_to_mock_interview (the verified evidence, the three weak areas with their allowed strategies, the named objection, the opportunity risks, the employer questions and the prohibited claims); decision (context only). Fit-snapshot grading and the strategies are the underwriter's; the answer slots and bridges are this pack's.

Searches sent: "Quartzline company values" (refused); "Quartzline interview process product manager" (refused); "Quartzline API platform strategy news" (refused). No page fetches were sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | The search was refused. It would have fed a values cheat sheet if a values-style round were detected. None is, so the pack has no VAL questions |
| 2. Quartzline interview process, product manager | unavailable | The search was refused. It would have established the loop and moved persona weights. Weights rest on the hiring-manager round type and the dossier |
| 3. Quartzline strategy and recent news | unavailable | The search was refused. It would have grounded CO and CASE questions in Quartzline's current strategy. The cases here are grounded in the JD's responsibilities instead, and the pack has no CO questions |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. Representative product manager JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → a Reading the interviewer section, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- The recruiter's prep email, if there is one → coverage of any focus areas or pre-declared deliverable
- Permission to run web searches → Quartzline's values, loop structure and current strategy, which would add CO questions, a strategy-grounded case, and a values cheat sheet if a values round turns out to exist. A deeper pass would add up to 6 further searches and 2 further fetches and take several more minutes
- One written output of a roadmap-input session, such as an agenda, notes or a deck → F4 and F7 could move from medium confidence toward high, and D2 would no longer be a probe you have to volunteer around
- The raw CV behind the confirmed claims → more quotes for the fit snapshot, which would turn scaffold questions such as G2 into story-mapped ones
- Your own answers to the answer slots in F2, F3, F5, F7, F8 and F9 → each answer, once stated, enters the snapshot as quoted evidence and the rows that draw on it are regenerated
