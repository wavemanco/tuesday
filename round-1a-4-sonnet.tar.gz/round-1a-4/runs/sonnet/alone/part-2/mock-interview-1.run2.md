I'll read the reference files the skill requires before building anything.
Fixing two errors I spotted in the saved pack: a sloppy coverage row and wrong type counts.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-1-denied-64da42f7/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. I built it for one 60-minute conversation with Dan as a peer, so the persona weights come from that relationship and your notes on him.

- **Coverage:** 22 questions across six personas, weighted Prober and Peer first, then Skeptic, Case, Conversational and Pressure. Each row has a type tag, provenance, answer guidance and rationale. The pack also has a fit snapshot, a Dan read, six reverse questions, a prohibited-claims list and an upgrade menu.
- **Highest-ROI prep:** D1, "no classic sales-ops or quota-setting." Dan's function sits right beside that gap. After that, A1 and A2, the defense of the ~$400M figure, which a data-driven peer will press.
- **Research:** I ran no web research. All three searches I sent were refused for permission, so nothing about Dan or Northwind's values was verified. The Dan read and the Compass, bundling and profitability questions rest only on your notes, and the Sources section says so.
- **Evidence:** Everything about Priya is quoted from your notes, not her CV. Where your notes were silent, such as whether she has launched a product, run a SQL analysis herself, or designed a partner motion, the guidance is an answer slot for her to fill in her own words. It is not a claim made for her.
- **Left out:** There's no values cheat sheet, prep triage or delivery coaching, because there was no values round, no prep time and no assessment.

I can play Dan live on D1, the "no sales-ops or quota-setting" question, and give feedback against the pack's guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, a peer (both report to the same VP). **Round:** one 60-minute conversation.

Built on this assumption: a single peer conversation, so no values-style round is detected and persona weights come from the peer relationship, adjusted by what you told me about Dan. Everything about Priya here comes from your notes, not from her own CV, so each quote below is labeled "the coach's notes". The JD lines are your highlights, not the full posting.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in Priya's own words, and only what she actually did.

| Type | What it scores |
|---|---|
| VAL | Past behavior against the company's published values. None in this pack: no values page was read and no values round was detected |
| EXP | Whether claims from her background survive scrutiny, and what was actually hers |
| JD | A stated responsibility or requirement of the role, gaps included |
| CO | Company and strategy knowledge, at Northwind's altitude |
| CASE | A live problem from the real job, scored on structure and reasoning |

An **answer slot** is an instruction for the interview, not a question for you: it names what the interviewer will probably probe, then gives two honest branches, one if she did the thing and one if there was no such step or it was not hers. Provenance labels: `[grounded]` is traceable to your message, `[inferred]` is derived from it, `[generic]` is a pattern with no claim about Northwind or Priya.

**Highest-ROI prep in this pack: D1**, the "no classic sales-ops or quota-setting" question. It will arrive in some form, and Dan's function sits right beside it. Rehearse it until it is boring, then rehearse A1 and A2, the defense of the ~$400M figure.

Not in this pack, and why: prep triage (no prep time given), graded deliverables (none announced), a grounding brief (no deep research ran), a values cheat sheet (no values round detected), delivery coaching (no assessment provided).

## Fit snapshot

Requirements are quoted from your JD highlights. Evidence is quoted only from your notes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops at a large consumer-tech company, not a launch or a GTM plan, and the words stay there: "I did two years of strategy consulting at a top firm, then nine years at a large consumer-tech company in product strategy & ops." Answer slot: the JD's two-new-product-lines line makes a probe on whether any of your work took a product to market likely. If any did, say which and what part was yours; if none did, or none was yours, say so plainly and stay with the product strategy and ops work. Expect a probe, since nothing is inspected behind a coach's summary |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | Your material says she proposed the change and that it was credited with the uplift. It does not say who credited it, how the figure was counted, or what the change grew from. Words: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's whitespace line and a data-driven interviewer make a probe on how the opportunity was found and how the figure was counted likely. If you know, say so in your own words; if you do not know how it was counted, or the change did not come from that kind of search, say so plainly and stay with what you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | discovery | The skill is stated and no piece of work is. Words: "I'm skilled in SQL and Tableau." Answer slot: the JD's independent-analysis line makes a probe on specific work likely. If there is work in SQL or Tableau you can walk through, say what it was and what you did in it; if there is none you can walk through, say so plainly and say where your skill with them comes from |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not the design of a partner motion, and the words stay at the model: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: the JD marks this requirement as required, so expect a direct probe. Say what the model did in the negotiations and what part of it was yours; if the work you did with partners was the model and nothing else, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms, so lead with it as written: "I set annual volume targets with cross-org consensus." Your material does not say which orgs, or whether they disagreed, so nothing is added about either. Expect a probe, since nothing is inspected behind the line |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote reaches the requirement in other terms, at the scope of use: "I use AI tools daily." Your material says use, not building or launching anything with AI, and nothing is added. Expect a probe on which tools and for what |
| F7 | Not a JD line: the peer's own function, "Director of Sales Strategy at Northwind" — your message | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't had classic sales-ops or quota-setting experience." Then the nearest thing your material carries, at its own scope, is F5's volume targets and the consensus behind them. Then how you would learn Dan's side of it, said as a plan and never as a past |

## Reading the interviewer

Public footprint only. A web search for Dan was not permitted in this session, so this section rests on your notes alone.

| Signal | What it means for this round | Where it lands | Provenance |
|---|---|---|---|
| He "self-describes as 'relentlessly data-driven'" — your message | Expect every number to be asked down to its inputs, and expect "I don't know how it was counted" to be received better than a confident guess | A1, A2, A3, F1 | [grounded] |
| "pricing and monetization roles" are his career spine — your message | Cases tilt toward pricing, packaging, discounting and unit economics, which is his native language | B5, C3 | [inferred] |
| "one early-stage-startup chapter" — your message | A scrappiness probe on how she works with less around her is likely | D3, reverse question R1 | [inferred] |
| He is a peer, "both reporting to the same VP" — your message | He is pricing what her hire costs and adds to his own work, so reciprocity matters more than self-promotion | B4, reverse questions R2 and R6 | [grounded] |

**Mirror opportunity:** his public path is pricing and monetization roles. The nearest sentence of hers is F4's "built a partner-level revenue model used in carrier negotiations". That makes shared vocabulary around revenue and negotiation fair to use, but the material says a revenue model, not pricing work, so she should not call it pricing. No row's evidence carries her side of a startup chapter, so that is not offered as a shared jump.

## Persona table

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Dan asks for inputs, denominators and sensitivity on the ARR figure, the revenue model and the volume targets | High. The peer relationship prior includes it, and "relentlessly data-driven" raises it further | Know what you can and cannot say about how each number was counted, and say plainly when you do not know. Name the weakest assumption you know of before he does. Offer to walk through a piece of work only if you can walk through it. See A1 to A5 |
| Peer Evaluator | Seam-splitting between sales strategy and emerging-products GTM, "what would you need from my team", credit | High. It is the peer prior, and the shared VP makes the seam a live question | Reciprocity framing: what you bring his team, not only what you need. Propose seam principles instead of pretending to know the seam. See B1 to B5 |
| Skeptic | The sales-ops and quota gap, the move from consumer to B2B, partner-motion design | Medium-high. F7 is the largest stated gap and sits next to his function | Rehearse the single most predictable objection (D1) until it is boring. Build bridges only from what the quotes carry, and state the limit plainly |
| Case / Strategist | One live problem on pricing, packaging, whitespace or Compass | Medium. His pricing spine tilts any case to unit economics, and 60 minutes leaves room for about one | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully. See C1 to C4 |
| Conversational / Rapport | The opener ("walk me through the journey") and a casual AI question | Medium as the opener, low as the whole style. The opener is near-certain in any first conversation | Prepare the 90-second arc and treat the casual AI question as scored. See E1, E2 |
| Pressure | A time-box or an attribution challenge on the headline number | Low-medium. His profile signals probing, not stress, but a credited figure invites one "how much was you" | Pause, restate, anchor in what the quotes say, hold through two follow-ups before conceding anything real. See F1, F2 |
| Values / Behavioral | Scenario probes against published values | Low. One peer conversation, no values round detected, and Northwind's values were not read | No bank. If a values question arrives, treat it as the open-prompt shape in B2 |

## Question banks

Ordered by weight. 22 questions. Type counts: EXP 9, JD 8, CASE 3, CO 2, VAL 0.

### Requirement coverage

| JD requirement or interviewer lens | Covered by |
|---|---|
| "own GTM strategy for two new product lines" | B5, C1, C3, D4, F2 |
| "identify whitespace across land/adopt/expand/renew" | A5, C2, C4 |
| "run independent analysis in SQL and Tableau" | A4, A5 |
| "partner-motion design experience required" | A3, D4 |
| "strong cross-functional influence" | B1, B2, B3, B4 |
| "AI experience a plus" | C1, C3, E2 |
| "relentlessly data-driven" (Dan's own words) | A1, A2, A3, F1 |
| No sales-ops or quota-setting (F7) | D1, F2 |

### A. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You proposed a store-surface change that was credited with roughly $400M of ARR uplift. How was that number counted?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Open in the quote's own terms: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Then the four slots, each in your own words. How it was counted: if you know, say how; if you do not know how the figure was counted, say that plainly. What it is most sensitive to. The assumption behind it you would defend least, named before Dan names it, if you know of one. Which part was yours: the quote says you proposed the change, so anything beyond the proposal is said only if it was yours. Do not supply a method you cannot repeat under a second question | F2 carries the headline figure and is the natural first target for a prober. EXP because the defend-the-number rule applies to every headline metric, and the question tests attribution and counting, not the result |
| A2 | "If one assumption behind that figure turned out to be wrong, which one would move it the most?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The second level of the same defense. Name the assumption in your own words. If you do not know which one would move it most, say so plainly and say what you would want to check first, instead of inventing one. Do not retreat from what you proposed. Concede only what you specifically cannot speak to | Probers go two levels deeper than the first answer, and this forces the weakest-assumption move out loud. It is EXP because it scores whether she knows her own figure, and it pairs with A1 as one rehearsal |
| A3 | "You built a partner-level revenue model that was used in carrier negotiations. What was it built to answer?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | The beats the quote states: a revenue model, at partner level, used in carrier negotiations. Tell them in your own words. Answer slot: say what question it was built to answer and what went into it; if you do not remember what went in, say so plainly instead of reconstructing it. If you know how the negotiations used it, say so; if you do not, say that. Claim nothing the model decided or won | F4 is the nearest evidence to the partner requirement, and a revenue model is native ground for a pricing-and-monetization interviewer. EXP because it tests what she built and what was hers |
| A4 | "Tell me about a piece of work you did in SQL or Tableau: the question, the data, what you found." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold. Pick one piece of work you can walk through from memory: the question it answered, where the data came from, what you found, and what it was used for. Say what you did in it and what others did. If no such piece comes to mind, say so plainly, then give the nearest thing your material carries, "I'm skilled in SQL and Tableau", as you would describe it, or how you would approach one | The JD's analysis line is a hard requirement and F3 gives a skill, not a story. A prober will ask for the story, so the honest branch is rehearsed ahead of the probe. JD because it scores the stated requirement |
| A5 | "A product line's net revenue retention drops two points in a quarter. Walk me through your first three queries." | CASE | [generic] | Clarify first: how the metric is defined and counted, and over what cohorts. Then segment (stage, size, tenure, product), say your first query aloud before you run it, state two hypotheses and what result would kill each. Close with what you would check next and the metric you would judge by. No claim about your past | A live diagnosis on the "renew" end of the JD's lifecycle line, delivered in a data-driven register. `[generic]` because it is a pattern for the problem, not a fact about Northwind. CASE because it scores structure under a number he will care about |

### B. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where do you think the seam is, and what happens when we disagree?" | JD | [generic] | You do not know the seam yet, so say that first. Then offer principles instead of a map: agree metric definitions before debating results; name each decision's owner before the work starts; disagree on the data first, and take it to the shared VP only with both versions written down. Ask him where that differs from how his team works today. No claim about your past | The persona stem for a peer, and the cross-functional requirement made concrete. JD because it scores a stated requirement; delivery is collegial, which is why the persona is Peer |
| B2 | "When have you got several orgs to agree on something they each had a stake in?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | The beats the sentence states: the annual volume targets, and the cross-org consensus. Tell it in your own words. Answer slot: the JD's cross-functional influence line makes a probe on where the orgs disagreed likely. If they did, say what about and what part was yours; if they did not, or you were not the one who brought them together, say so plainly and stay with the targets and the consensus | F5 is the only evidence for a requirement the peer personally cares about. EXP because it tests what she actually did; an open prompt, so it presupposes no event |
| B3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Give your principle first, in a sentence. Then use the quote at its own scope: "I proposed the change", and let him ask who built it. Answer slot: if others' work was needed to turn the proposal into the result, say whose and what, in your own words; if it was not, say so plainly. Never imply the result was yours alone | Peers price credit-sharing because they will share a VP. It also reuses F2 from the attribution side, so the same figure is defended two ways. EXP, with a collegial delivery |
| B4 | "What would you need from my team in your first thirty days, and what could you do for it?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Ask first: how his team defines the lifecycle stages today, and which numbers he treats as the source of truth. Then offer, within the quote: if you can walk through the revenue model you built, offer to do that as a worked example. Offer nothing you cannot stand behind in the room | The reciprocity move from the peer persona: what she brings his team, not only what she needs. JD because it tests the cross-functional requirement, and it pairs with reverse question R2 |
| B5 | "Suppose your launch plan needs discounting to land enterprise customers, and profitability is a stated priority. How do we settle that between us?" | CO | [grounded] | Use the priorities you were given: enterprise expansion and reaching profitability. Clarify first: which customers, what margin floor, who owns the discount decision today. Then propose a decision rule both teams can read, with a data trigger to revisit it. Say where you would defer to his team. No claim about your past | His pricing spine makes this the case he is most likely to enjoy. CO because it needs Northwind's stated priorities, from your research note; CASE in delivery |

### C. Case / Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is launching. If you owned GTM for one of the new lines, which one motion would you test first, and what would you need to know?" | CASE | [generic] | Clarify first: whether Compass is one of the two lines, who the buyer is, and what the first success metric is. Then state a hypothesis early, name the segment you would test, and say how you would know within a quarter. Say the one premise of the question you would challenge. No claim about your past | The role's core job and the Compass launch from your research note, as a live problem. `[generic]` because the answer is a method, and what Compass is for stays a question |
| C2 | "A much larger platform vendor bundles a competing capability into its suite. What does that do to your whitespace map across land, adopt, expand and renew?" | CO | [grounded] | Bring the consensus point once, that bundling threatens the stage where customers already live in the larger vendor's suite. Then one thesis with reasons: where you would defend, where you would differentiate, and one place you would decline to compete. Ask which stage he sees most exposed. Do not recite the research note; depart from it with a reason | The bundling threat is the stated competitive pressure, and a note any prepared candidate has. The anti-pick is what separates judgment from homework. CO because it scores strategy at the company's altitude |
| C3 | "Profitability is a priority. How would you decide between pricing Compass as an add-on, bundling it, or charging by usage?" | CASE | [generic] | Clarify first: what it costs to serve, who buys it, and whether it must defend an existing product. Then lay out the three options on two axes, revenue per customer and risk of the bundling threat. Name the data you would want and the assumption you are least sure of. Use his vocabulary, not a framework name | Pricing and packaging is his spine, so this is the case he is most able to judge. CASE; `[generic]` because it is a method, not a claim |
| C4 | "You have 90 days. How do you find the whitespace across land, adopt, expand and renew for one of the lines?" | JD | [generic] | Say the plan in order: agree stage definitions with his team first; segment the installed base by stage; look in SQL for where conversion or adoption drops; size the largest gap with its weakest assumption stated; validate with the field before presenting. Close on the first deliverable and who reviews it | The JD's whitespace line asked as a plan. JD because it scores a stated responsibility; CASE delivery. Agreeing definitions with his team is the peer-aware move |

### D. Skeptic (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting in your background. How does that work in a role that sits next to sales strategy?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | **Highest-ROI prep.** Hold, then concede. State it plainly: "I haven't had classic sales-ops or quota-setting experience." Then the nearest thing at its own scope: "I set annual volume targets with cross-org consensus." Then the plan, said as a future: what you would learn from his team first and how you would ramp. Follow-up one, asking whether that is the same thing: repeat the plain acknowledgment and do not argue the equivalence. Follow-up two, asking what you would do in thirty days: give the plan. Never present the volume targets as quotas | F7 is the largest stated gap and Dan's function sits beside it, so this arrives in some form. JD because it scores a stated job fit; Skeptic because it probes the gap quietly. The negative has a source, so the question may state it |
| D2 | "You spent nine years at one large consumer-tech company. Why move to B2B data infrastructure, and why now?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Your actual reason, in your own words: why leave, why here, why now. The quote gives only the shape of the move, so do not invent a motive or a trigger. Choose one reason you can defend under a second question, and tie it to what the role does. If your honest reason is mixed, say so | The "why leave, why here, why now" probe is the Skeptic's core. EXP because the quote is the only sentence it rests on, and the motive is hers to say |
| D3 | "Northwind has about 3,000 people. What changes for you when the company around you is smaller?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Selection scaffold. Pick a time you worked with less support than you were used to: it needs a named constraint, what you did without the support, and how it ended. If no such time comes to mind, say so plainly, then say what you would do first to learn how work gets done here | Dan's early-stage chapter makes a scrappiness probe likely; the size figure comes from your role description. EXP because it tests adaptation from past behavior, with an honest branch where none is carried |
| D4 | "The role lists partner-motion design experience as required. Where does that show up in your background?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The answer starts and stays at the quote: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: say what the model did in those negotiations and what part was yours; if the work you did with partners was the model and nothing else, say so plainly and stay with the model. Then offer the ramp: what you would study first on how Northwind's partners work today | The JD marks it required, so this is a direct probe on F4, where the quote is adjacent. JD because it scores a stated requirement |

### E. Conversational / Rapport (weight: medium-low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the quote as its spine: two years of strategy consulting at a top firm, then nine years at a large consumer-tech company in product strategy & ops. Then three proof points, each at its quoted scope: the partner-level revenue model, the volume targets with cross-org consensus, and the store-surface change you proposed. Close on your own reason for this role | The opener is near-certain and scored even when it feels casual. EXP because it tests whether the story hangs together |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say which tools and what for, in your own words: "I use AI tools daily." If most of it is personal workflow, say so; do not claim you built or launched anything with AI. Connect it to Compass as curiosity, and ask what Dan has seen so far | The JD flags AI as a plus and Compass is a stated priority, so a casual question here is scored. JD because it scores the plus-skill |

### F. Pressure (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ARR result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, restate, anchor: "I proposed the change." Hold that through two follow-ups. Answer slot: if others' work was needed to produce the result, say whose and what; if you do not know how the credit was assigned, say so plainly. Concede that specifically and never fold on the proposal itself | The stem from the persona model, aimed at the number most likely to be pressed. EXP because it scores attribution under pressure |
| F2 | "Sixty seconds: why you over someone who has run quota and territory planning for years?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "built a partner-level revenue model used in carrier negotiations" | Concede first, in the plain acknowledgment: "I haven't had classic sales-ops or quota-setting experience." Then two quoted items, each at its scope: the partner-level revenue model used in carrier negotiations, and the annual volume targets set with cross-org consensus. Tie them to what the JD asks, and say what you would learn first. Do not say you are better; say what you bring | A time-boxed version of D1, because the pressure style tests the same gap. JD because it scores job fit, and it is the Pressure persona's counter-offer test |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What did your early-stage chapter change about how you approach pricing and monetization decisions?" | Ties to Dan's own path, from your note, and turns a probe into a peer conversation |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows she is thinking about his load |
| R3 | "Is Compass one of the two lines this role covers, or does the role sit alongside it?" | The material leaves this open, and the answer reshapes C1 and C3 |
| R4 | "How are the lifecycle stages defined today, and who owns those definitions?" | Speaks to a data-driven peer in his terms and shows she wants the definitions before the debate |
| R5 | "With a much larger vendor bundling, which stage worries you most?" | Draws on the stated competitive threat and asks for his judgment, not a recitation |
| R6 | "What does our VP most want the two of us to agree on in the first ninety days?" | Both report to the same VP, so this surfaces the shared goal and the likely seam |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience, including describing the annual volume targets as quotas | Negative the coach stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." The volume targets stay at F5's quote. No slot |
| Delivered or drove the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says proposed and credited with, not who delivered it or who credited it. A1's slots ask only how it was counted and which part was hers |
| Designed partner motions | Inflated form of F4 | F4's quote at its own scope. The material says a revenue model used in negotiations. D4's slot stays with what the model did |
| Owned GTM for a product launch | Inflated form of F1 | F1's quote at its own scope. The material says product strategy and ops, not a launch |
| Ran independent analysis end to end in SQL and Tableau | Inflated form of F3 | F3's quote at its own scope. A4's slot asks only for work she can walk through |
| Has AI product or AI GTM experience | Inflated form of F6 | F6's quote at its own scope. The material says daily use of AI tools, not building or launching with AI |

## Sources

**Provided documents:** your message, which holds the JD highlights, a summary of Priya's background, a profile summary of Dan, and your research note on Northwind's priorities (enterprise expansion, the Compass launch, profitability) and its main competitive threat (bundling by a much larger platform vendor). No dossier was present.

Searches sent, all refused because web search was not permitted in this session:

- "Northwind Data company values data infrastructure" — refused
- "Dan Kovac Northwind Data Director of Sales Strategy" — refused
- "Northwind Data Compass AI copilot launch" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Every call was refused. It would have supplied value names for VAL questions; no values cheat sheet is built either way, since no values round is detected |
| 2. Interview process, role family | skipped | Your words fix the loop: one 60-minute conversation with Dan, a peer |
| 3. Northwind strategy and recent news | unavailable | The one call was a quick check of your pasted research note and it was refused, so the note is used as given and unverified. B5, C1, C2 and C3 rest on it |
| 4. Dan Kovac, Northwind Data | unavailable | The call was refused. It would have added his public talks or writing to the interviewer read and a sharper reverse question |
| 5. Representative JD | skipped | Your JD highlights fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the six JD-derived rows (F1 to F6) become direct quotes, and any gates the highlights omit (location, pay, travel) can be checked
- Priya's own CV → F1 to F7 quote her own lines instead of a coach's summary, and the "expect a probe" caveats on each can be re-graded
- Inspectable artifacts for this field, such as the carrier-negotiation revenue model, the volume-target memo or the store-surface proposal with its credited-uplift source → F2, F4 and F5 can move from `medium` to `high`
- Priya's answers to the answer slots in F1 to F4 → each slot row becomes a story-mapped row, and A1, A3, A4 and D4 become story-mapped answers
- The recruiter's prep email, with any stated focus areas → coverage assumed from the peer prior becomes coverage confirmed, and any announced case gets its own build section
- Search access → Northwind's values page and Dan's public footprint can be read, and the three refused queries rerun. A deeper pass, with up to 6 more searches and 2 more fetches and several more minutes, adds a strategy brief and recent org context
- A `tuesday-dossier.md` from an earlier session → verified evidence, absolute prohibited claims and a named top objection, none of it required
