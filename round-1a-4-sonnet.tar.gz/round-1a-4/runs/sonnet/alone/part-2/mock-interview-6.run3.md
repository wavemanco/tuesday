I'll read the reference files the skill points to before writing anything.
The pack is written and saved. I'm sending the closing message now.

Your prep pack is saved as `larkfield-systems_engineering-manager_interview_pack.md` in the working directory. It's a loop pack: one shared fit snapshot, then a mini-pack for each of the three rounds. Each round has its own persona weights, a bank of 9–10 questions, and 5 reverse questions. There are 29 questions in total.

- **Search was refused.** All three searches (values, interview process, strategy) were denied, so I used only what you told me. That means no Larkfield values cheat sheet and no company-strategy questions. The Sources section shows each call and what it would have fed.
- **Built on your words only.** I had four sentences of background and your role summary, with no CV, full posting or interviewer names. Where your material is silent, such as team growth or device work, the guidance is an answer slot for you to fill truthfully rather than a story I invented.
- **Highest-ROI prep is B1.** It asks "which part of this role would you be weakest at on day one?" and uses your own words: "I've never owned a hardware-adjacent roadmap" and a team lead of six. You'll likely hear it in all three rounds.
- **Same story in every round.** The reliability quarter and the 60% figure come up in several rounds, so rehearse one consistent version. The pack doesn't turn "dropped 60% after" into "because".

I can run a live drill, playing the Director, the panel or the VP, starting on B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
One extra I haven't built: a one-page map of which story you tell in which round, so the three interviewers hear a consistent account. Say so if you want it.
I can convert the pack to Word if you'd like.

1. Has the recruiter said what the panel will cover or asked you to prepare anything, such as a presentation or a case? If so, I'll add a build section for it.
2. Can you paste the full posting and your CV, or should I stay with what you've told me? With them, more rows and questions would be built on your actual wording.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack — Engineering Manager, Larkfield Systems (loop of three rounds)

Candidate: Yusuf. Mode: loop — one shared fit snapshot, then a mini-pack per round.

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering | 45 min | Hiring manager, your would-be boss |
| 2 | The Thursday after | Two staff engineers and a product manager | 60 min | Panel |
| 3 | The following Monday | VP Engineering | 30 min | Skip-level. The recruiter's description: "values and leadership philosophy" |

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows values and leadership principles, not generic virtue |
| EXP | Whether claims about your experience survive scrutiny, including what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy. None in this pack, because research could not run (see Sources) |
| CASE | A live problem set in the role: structure and reasoning |

Provenance labels: `[grounded]` rests on your message, with your own sentence quoted beside it. `[inferred]` is this pack's derivation, with the derivation named. `[generic]` is a role-family pattern with no claim about you or Larkfield. An answer slot is an instruction for the interview, not a question for you now: say what is true, in your own words, and take the honest branch if the practice was not yours or never existed.

## Prep triage

Three rounds in two weeks, so the same few stories will be heard by different people who may compare notes. In order:

1. B1, the hold-then-concede answer on the weakest part of the role. It is this pack's highest-ROI prep (explained under Round 1). Rehearse it out loud until it is boring.
2. A3 and E1 together: the reliability-quarter story and the 60% figure. Both come up in more than one round (A3, E1, F1, G2, H1), so the account has to be identical every time.
3. A1 and D1, the two live cases. Practice thinking aloud.
4. G1, your leadership philosophy in your own words, before Monday.
5. The reverse questions for each round.

Everything else is insurance.

## Fit snapshot (shared across all rounds)

The role description and round descriptions are the ones in your message. No full posting or CV was supplied, so every candidate quote is a sentence from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" and "for 11 engineers" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material says a team lead of 6, which is one team at a smaller headcount than the role names. Words stay at that scope: "three years as a team lead of six." Answer slot: if any of that role involved working across more than one team, say how, in your own words; if it was one team, say so plainly and stay with the team of six |
| F2 | "own delivery" — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The sentence touches delivery trade-offs but does not show whether you owned delivery. Answer slot: expect a probe on how delivery was run; if any of it was yours, say which part and how you decided, in your own words; if it was not yours, say so plainly and stay with the reliability quarter as the sentence states it |
| F3 | "hiring" — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms: you run the loop, in your words. Lead with it as stated. Expect a probe on the figure and on what parts of the loop were yours; the pack's observation is that the sentence says backend roles and about 40 interviews, and nothing about who made the final decisions |
| F4 | "growth for 11 engineers" — role description in your message | none given | none | [grounded] | discovery | Nothing in your material shows this. Answer slot: if you have helped any engineer grow, say who and how, in your own words; if not, say so plainly and say how you would start |
| F5 | "building device-management services" — role description in your message | none given | none | [grounded] | discovery | Nothing in your material shows device-related work; your sentence names a payments company. Answer slot: if any of your services dealt with devices or equipment in the field, say how; if not, say plainly that your work has been in payments and say what you would learn first, as a plan |
| F6 | "partner with hardware and product on roadmap" (the product side) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The sentence mentions roadmap pressure but not who applied it or whether you partnered with product. Answer slot: if you worked with product on a roadmap trade-off, say what you did and what product gave up; if the pressure came from elsewhere, or product was not involved, say so plainly and stay with the sentence |
| F7 | "partner with hardware and product on roadmap" (the hardware side) — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | discovery | You stated that you have never owned a hardware-adjacent roadmap; the requirement says partner, and your sentence is silent on partnering. Plain acknowledgment, from your own sentence: "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked alongside hardware people in any way, say how; if not, say so plainly |
| F8 | Leading at manager level. Not in the role description; raised by your own message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never managed managers." Then how you would approach it, said as a plan and never as a past. Never a claim to have led leads, and nothing added to make the gap feel smaller |
| F9 | "values and leadership philosophy" — the recruiter, as relayed in your message (Round 3) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The sentence carries one decision under pressure, and it states no principle behind it. Answer slot: say in your own words what you were protecting when you made that call; if it was not a principle but a circumstance, say so plainly |

No gate rows: the role description contains no term (authorization, location, schedule, pay, travel, credential) that your material could fail to meet.

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 two squads, 11 engineers | A2, A4, B2, C1, H2 |
| F2 delivery | A1, A3, B1, I1, I2 |
| F3 hiring | A4, C2, E2 |
| F4 growth | G4 (no second question: the material gives nothing to rehearse beyond the slot) |
| F5 device-management domain | B3, B4, E3, I2 |
| F6 product partnership | A3, F1, F2 |
| F7 hardware partnership | A1, B1, F2, H3 |
| F8 manager level | B1, H2 |
| F9 values and leadership philosophy | F1, G1, G2, G3, H1 |

## Prohibited claims

What this pack will not coach. Built from the snapshot before any question was written.

| Not coached | Basis | Honest form |
|---|---|---|
| Having managed managers or led leads | Negative you stated, F8 | The plain acknowledgment: "I've never managed managers." No slot |
| Having owned a hardware-adjacent roadmap | Negative you stated, F7 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." The slot asks only about working alongside hardware people |
| Having led two squads or an engineering organisation | Inflated form of F1 | F1's quote at its own scope: a team lead of 6. The limit is the pack's observation: your material says one team of six, not two squads |
| Having owned delivery or the roadmap | Inflated form of F2 and F6 | The reliability-quarter sentence at its own scope. The slot asks which part of the trade-off was yours |
| The reliability quarter caused the 60% drop | Inflated form of F2 | The sentence says the burden dropped "after" the quarter, and the pack does not turn that into cause. E1 and H1 hold slots for how much of it was yours |
| Having made hiring decisions or hired a given number of people | Inflated form of F3 | The hiring-loop sentence at its own scope. The slot asks which parts of the loop were yours to shape |

---

# ROUND 1 — Tuesday, Director of Engineering (hiring manager), 45 min

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems on the squads' roadmap, hardware dependencies, hiring | High. The hiring-manager prior is Case/Strategist plus Skeptic, and your message gives no interviewer profile to adjust it | Clarify, then objective, options, risks. Think aloud; challenge one premise respectfully |
| Skeptic | Probing the scope jump (F1), the missing hardware and manager-level experience (F7, F8) and the domain switch (F5) | High. Same prior; your own message names the gaps this persona is built to probe | Rehearse B1 until it is boring: say the weakest part first, hold, concede in specifics |
| Conversational | The opener and a hiring question in a friendly register | Medium. Round openers are almost always conversational and still scored | Prepared 90-second arc (C1); treat C2 as scored |
| Pressure, Peer, Prober | Not banked for this round | Low. Nothing in the round description points to them. They get their weight in Rounds 2 and 3 | — |

## Bank A — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Hardware slips a change your squad's date depends on by three weeks. Walk me through your first week." | CASE | [generic] | Clarify first: what exactly slipped, what it blocks, what product has been told. Then objective, options, the message to product, and the risks. Think aloud and challenge one premise respectfully. The case asks about no past, so this guidance makes none | The role's hardware-partnership line (F7) is where a hiring manager tests live. CASE because it asks for structure on a role problem; generic because it is a pattern, not a fact about Larkfield |
| A2 | "You take over two squads and eleven engineers. What do you want to know in your first thirty days, and who do you ask?" | CASE | [generic] | Structure it: commitments and dependencies, the state of hiring and growth on each squad, the people to ask, and what you would leave alone at first. Said as a plan, never as a past. No claim about your history is needed | Tests F1 at the altitude of the new scope. CASE because it is a plan for the role; generic because it makes no claim about this team |
| A3 | "Tell me about a time you pushed back on roadmap pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the sentence, in its beats: a reliability quarter, which you pushed through, against roadmap pressure, with the on-call burden down 60% after. Tell them in your own words. Answer slot: expect a probe on who applied the pressure and how it was resolved; if you can say, say it in your own words; if no one specific applied it, or the resolution was not yours, say so plainly and stay with what the sentence states. The 60% figure is rehearsed in E1 | F2 and F6 are the evidence for delivery trade-offs, and this story will be heard in several rounds. EXP because it tests what was actually yours |
| A4 | "You have one hiring slot and two squads asking for it. How do you decide?" | CASE | [generic] | Clarify what each squad's gap costs and what is planned; set the criteria aloud; decide; say how you tell the squad that did not get it. No claim about your past | F1 and F3 meet here. CASE because it is a decision problem from the job, generic because it is a pattern |

## Bank B — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." and "9 years engineering, 3 as a team lead of 6, currently at a payments company." | The highest-ROI prep in this pack, and the hold is only what your sentences carry. Name the weakest part before they do: "I've never owned a hardware-adjacent roadmap." Then stay at the scope of what you said: "3 as a team lead of 6." Hold through two follow-ups by returning to those sentences, never by adding to them. Likely follow-ups: what that costs the squads, and what happens the first time hardware moves a date you gave product. Concede in specifics (what you do not yet know), and give your first weeks as a plan, not a past. If asked about managing managers, your words are "I've never managed managers." Answer slot: if you have worked alongside hardware people in any way, say how, in your own words; if not, say so plainly | F7 and F8 are your own stated gaps and F5 is silent, so this question arrives in some form in this round and probably in the next two. JD because it scores the listed job including its gaps; the deepest rehearsal because a calm, specific concession changes the interview |
| B2 | "You have led a team of six. This is two squads and eleven engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Hold at F1's scope: three years as a team lead of six. Answer slot: the role description names two squads, so expect a probe on working across more than one team; if any of that lead role did, say how, in your own words; if it was one team, say so plainly. Then say what you expect to change as a plan, naming what you would ask first | F1 is a transferability row: adjacent work, a step in scope. JD because it scores the scope requirement |
| B3 | "Why industrial IoT, and why now, coming from payments?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | The pack cannot supply your reasons. Criteria: one reason about the work (use the role description's own words: device-management services, delivery, hiring, growth), one reason for leaving that does not depend on criticising your employer, and one that is true. If no reason about the domain comes to mind, say so plainly and say what draws you to the role's scope instead | F5 is silent in the material, so motivation-consistency is the likeliest follow-on to B1. JD because it scores fit with the listed job |
| B4 | "What do you know about device management, and where are you thinnest?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Answer slot: if any of your services dealt with devices or equipment in the field, say how, in your own words; if none did, say plainly that your work has been in payments and say what you would learn first, as a plan. Do not borrow vocabulary you have not used | F5 has no evidence, and domain is the other half of the scope jump. JD because it scores a listed requirement |

## Bank C — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | A 90-second arc with only the beats the sentence states: nine years in engineering, three as a team lead of six, now at a payments company. Then why this role, in your own words (B3). Stop there | An opener is scored for economy. F1 supplies the beats; EXP because it frames everything the Director will probe next |
| C2 | "How do you run hiring today?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Story-mapped on F3 in the sentence's own terms: you run the loop, for backend roles, about 40 interviews last year. Answer slot: the role description gives you hiring for eleven engineers, so expect a probe on which parts of the loop were yours to shape; if any were, say which and how you decided; if the loop's design or its decisions were not yours, say so plainly and describe your part | F3 is your strongest direct row and the Director owns the headcount. EXP because it tests what was yours |

## Reverse questions — Round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What would success look like in this role at ninety days and at a year?" | Shows you aim at their measure of the job, and tells you what they will score you on |
| R1.2 | "Where do the squads' commitments and hardware's timelines collide most today?" | Goes straight to the part of the role you have not owned (F7) as a learner, which turns the gap into curiosity |
| R1.3 | "How are the eleven engineers spread across seniority, and are there leads inside each squad?" | Tells you how much of the role is leading people versus leading leads (F8) without conceding anything |
| R1.4 | "What would make you regret this hire six months in?" | Brings the Director's objection into the open while you can still address it |
| R1.5 | "How do you want us to handle a disagreement about priorities between you and me?" | Signals you are thinking about working with them as your manager |

---

# ROUND 2 — Thursday after, panel: two staff engineers and a product manager, 60 min

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting with staff engineers, "what do you need from us", disagreement | High. Panel rule: blend the top two personas of each member's relationship. Staff engineers weigh what you would cost and contribute to their work | Reciprocity (D4); propose principles for the seam rather than claiming to know it |
| Data-Driven Prober | Probes of the 60% and the 40 interviews to their assumptions | High. Same rule: the technical-specialist prior is Prober plus Pressure, and your two figures are exactly what a Prober picks up | Say how each figure was counted, or say plainly that you do not know; name the weakest assumption first |
| Values / Behavioral | The product manager's stories about disagreement and trade-offs | Medium. Cross-functional prior. Your message gives no names, so the split of the hour between the three is unknown | Use F1 once, with the PM's lens: what product gave up |
| Pressure | Possible from the staff engineers | Low. Not banked here; it gets its weight in Round 3 | — |

## Bank D — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A staff engineer on your squad disagrees with your technical call two days before a commitment. What do you do?" | CASE | [generic] | Clarify what they disagree with and what the commitment depends on; listen for what you might be missing; decide who decides and say so; keep the relationship intact whichever way it goes. No claim about your past | Staff engineers test whether a manager makes their work lighter or heavier. CASE because it is a live problem; generic because it is a pattern |
| D2 | "How do you decide what you step into and what you leave to the staff engineers?" | JD | [generic] | Propose principles instead of claiming to know their seam: where the decision is irreversible, where it crosses squads, where you hold context they lack. Say you would learn where the current seam sits from them first. No claim about your past | A seam question from peers pricing your cost to them. JD because it scores the manager-and-staff split the role implies |
| D3 | "Tell me about a time you made a call the engineers on your team disagreed with." | EXP | [generic] | Selection scaffold: pick a time that has a named stake, a moment you held your position, and an intact relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The pack's quotes do not carry a story of engineers disagreeing, so no story is mapped. EXP because it checks conduct under disagreement |
| D4 | "What do you need from us in your first month, and what can we count on from you?" | JD | [generic] | Reciprocity first: what you would offer their work (clarity on priorities, a shield for focus time, their load kept in view), then what you need. Offer only what you would do, as a plan | The reciprocity question for a peer-weighted panel. JD because it scores partnership fit |

## Bank E — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "The 60% drop in on-call burden: how was it counted?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Defend the number, in your own words, on four slots: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Where you do not know how it was counted, say so plainly. The sentence says the burden dropped after the quarter, so do not say the quarter caused all of it unless you can show that. Name your weakest assumption before they do | The 60% is a headline figure and a magnet for probers (F2). EXP because it tests attribution honesty |
| E2 | "The 'about 40 interviews': is that interviews you conducted or interviews across the loop?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say what the figure counts, in your own words, and where you do not know, say so. The sentence says about 40, so keep the "about". Answer slot: which of those were yours to run or shape; if only some were, say so plainly | F3's figure is the other number on your list. EXP because it checks precision |
| E3 | "How would you know a reliability investment in a device-management service paid off?" | CASE | [generic] | Clarify what failure looks like for the service and for the people on call; propose a baseline and a before/after window; name what else could move the metric; say what you would not conclude. This is a method, not a claim about your past | The Prober tests the reasoning behind F2 and F5 rather than the figure itself. CASE because it is a role problem; generic because it is a pattern |

## Bank F — Values / Behavioral and cross-functional (the product manager)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time engineering and the roadmap pulled in different directions." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The same story as A3, told with the product manager's lens. Beats from the sentence: a reliability quarter, pushed through, against roadmap pressure, burden down 60% after. Answer slot: expect a probe on what product gave up and how they were brought along; if you did bring anyone along, say how, in your own words; if not, say so plainly and stay with the sentence | F2, F6 and F9 draw on this one sentence, and the same account in every round is the point. VAL because it scores how you handled a conflict of priorities |
| F2 | "When hardware dates and product asks conflict, how would you work with me?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Open with the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then principles, said as a plan: surface the conflict early, agree on who decides, keep product informed of what moves. Answer slot: if you have worked alongside hardware people, say how; if not, say so plainly | F6 and F7 meet in the PM's chair. JD because it scores the partner-with-product-and-hardware requirement |
| F3 | "What do you need from a product manager to do your job well?" | VAL | [generic] | Selection scaffold: pick the two things that are true for you and give one reason for each. If none comes from your experience, say so plainly and say what you would ask for | A cross-functional courtesy question that is still scored. VAL because it tests working style with a partner function |

## Reverse questions — Round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What do you wish engineering management did differently for the squads?" | Asks the staff engineers for their view of the job, which is what they came to give |
| R2.2 | "Where does work between the squads and hardware get stuck most?" | Puts the hardware seam (F7) in front of three people who live it |
| R2.3 | "How does product learn about device-side constraints today?" | Aimed at the product manager; it shows you are thinking about the same seam from their side |
| R2.4 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer-weighted panel |
| R2.5 | "Which decisions do the staff engineers own today, and which ones does the EM?" | Tells you the seam D2 is about, from the people who would draw it with you |

---

# ROUND 3 — Monday, VP Engineering, 30 min ("values and leadership philosophy")

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Leadership philosophy, hard truths, mistakes | High. The recruiter's description of this round, as relayed in your message, names values and leadership philosophy | Map your stories (G2); where none of your sentences carries a story, use a selection scaffold with the honest branch |
| Pressure | Time-boxed challenges on scope and attribution | Medium. The skip-level prior is Case/Strategist plus Pressure; at 30 minutes, expect interruptions | Pause, restate, anchor in what you said, hold through two follow-ups, concede specifically |
| Case / Strategist | One altitude-raising problem about the org | Low. Part of the skip-level prior, but the recruiter's description tilts this round away from cases | Clarify, structure, say what you do not know |

No published Larkfield values are in hand, so there is no values cheat sheet in this pack. The VP's own values are unknown to this pack.

## Bank G — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The pack does not write your principles; they have to be yours. Criteria: two or three, each tied to one specific thing you did. The reliability-quarter sentence is one story you could tie a principle to, in its own beats. Answer slot: say what you were protecting when you made that call; if it was a circumstance rather than a principle, say so plainly. If no principle comes to mind, say so plainly and give the nearest thing your material does carry | F9 is the round's stated purpose and the material states no principle. VAL because it scores leadership philosophy directly |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the sentence if it fits: roadmap pressure, a reliability quarter pushed through, burden down 60% after. Answer slot: whom you told and how it landed; if the hard truth landed, say how; if it did not, or you were not telling leadership, say so plainly and pick a different instance or say none comes to mind | F9 draws on one sentence, so say honestly whether it is this question's story. VAL because it scores honesty under pressure |
| G3 | "Tell me about a time you got something wrong as a lead." | VAL | [generic] | Selection scaffold: pick a real mistake with a named stake, what you did when you saw it, and what changed after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not manufacture a mistake | The pack's quotes do not carry a mistake. VAL because it tests self-assessment |
| G4 | "How do you think about growing the engineers on your team?" | VAL | [generic] | Answer slot: if you have helped an engineer grow, say who and how, in your own words; if not, say so plainly, and say what you would do first as a plan. The pack supplies no growth practice for you | F4 is the row with no evidence and "growth" is in the role description. VAL because it is a leadership-philosophy question |

## Bank H — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "That result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold: the sentence says you pushed the quarter through. Pause, restate the question, and hold through two follow-ups. Concede specifically: what the sentence does not show is how much of the 60% the quarter explains. Answer slot: if you know how much came from the quarter, say how you know; if you do not, say so plainly. Do not move from "after" to "because" | F2 under pressure. EXP because it is the attribution probe. The hold is only what the sentence carries |
| H2 | "Sixty seconds: why should two squads and eleven engineers go to someone who has led six?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." and "I run our hiring loop for backend roles — about 40 interviews last year." | A sixty-second structure from the sentences only: nine years in engineering, three as a team lead of six, the hiring loop you run. Concede the scope step in plain words. If probed on managing managers: "I've never managed managers." Stop at the concession; do not add a claim to cover it | F1 and F8 under time pressure. JD because it scores the scope requirement |
| H3 | "A hardware lead asks why they should trust an engineering manager from payments. What do you say?" | JD | [grounded] "currently at a payments company" in "9 years engineering, 3 as a team lead of 6, currently at a payments company." and "I've never managed managers and never owned a hardware-adjacent roadmap." | Concede the true part first: "I've never owned a hardware-adjacent roadmap." Then say what you would do, as a plan: ask before assuming, learn their constraints, agree how dates are shared. Answer slot: if you have worked alongside hardware people, say how; if not, say so plainly | F7 in its sharpest form. JD because it scores the hardware-partnership requirement |

## Bank I — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Two squads, finite engineers, and hardware and product both pulling. How do you split effort between new features, reliability and hardware-driven work?" | CASE | [generic] | Clarify what the current commitments and the on-call picture are; set a principle for the split and say what would change it; say who you would consult. Think aloud and state what you do not know. No claim about your past | The VP tests altitude and judgment on F2. CASE because it is a role problem; generic because it is a pattern |
| I2 | "What would you want to know about the services' reliability before you commit to a delivery plan?" | CASE | [generic] | Clarify what failure looks like and who feels it; what the on-call picture is; where reliability debt and committed dates collide. Say how you would find out. No claim about your past | F2 and F5 at VP altitude. CASE because it asks for the questions behind a plan |

## Reverse questions — Round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What does good leadership of two squads look like to you, in one concrete example you have seen?" | Invites their philosophy, which is the round's purpose |
| R3.2 | "What is a decision on this org you would make differently with hindsight?" | Asks for candour, which is what a values conversation rewards |
| R3.3 | "How does engineering decide between reliability work and feature commitments here, and who has the last word?" | Ties to the one story you will have told, without repeating it |
| R3.4 | "What would you want an EM here to be known for after a year?" | Tells you the VP's bar |
| R3.5 | "How do you want EMs here to grow, including toward managing managers?" | Raises F8 as a question about growth, with no claim attached |

---

## Sources

Provided documents: your message (the role description, the three round descriptions, and four sentences of background). No posting, CV, interviewer profile or assessment was supplied.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The search was sent and refused. It would have fed a values cheat sheet; none is in this pack |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Sent and refused. It would have checked the loop; the three rounds come from your own words, which establish them |
| 3. `Larkfield Systems industrial IoT device management strategy news` | unavailable | Sent and refused. It would have fed CO questions; there are none |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | The role description you gave fixes the fit snapshot's requirement rows |

Queries sent, with outcomes: `Larkfield Systems values` — refused. `Larkfield Systems interview process engineering manager` — refused. `Larkfield Systems industrial IoT device management strategy news` — refused.

## Upgrade menu

- Interviewers' names → an interviewer read per round, persona weights adjusted to their public footprint, and a reverse question tied to each person's own path
- The full posting → the nine requirement rows firm up and any requirement not in your summary gets a question
- Your CV → the evidence column can draw on more than four sentences, so more questions become story-mapped instead of selection scaffolds
- The recruiter's prep notes for each round (any pre-declared deliverable, what the panel covers) → coverage tuned to the round and a build section for anything graded
- Larkfield's published values, pasted → a values cheat sheet for Round 3
- A pasted strategy brief, or search access → CO questions grounded in Larkfield's current priorities, and a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) if search is available
- The artifact behind the 60% (an on-call dashboard or incident count) and behind the hiring-loop figure → the confidence on F2 and F3 rises from what you said to what can be shown
- `tuesday-dossier.md` → a pack that can hold verified evidence and absolute prohibitions across sessions
