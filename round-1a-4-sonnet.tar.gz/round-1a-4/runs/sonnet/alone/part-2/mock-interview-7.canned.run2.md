I'll read the reference files the skill points to before building the pack.
Research is done: the values page and loop page both fetched, plus the strategy and interviewer searches. Now I'll write the pack.
Femi, your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-7-canned-83fe59e1/saltmarsh-games_live-operations-producer_interview_pack.md`.

I built it for a hiring-manager round with Tobias. Saltmarsh's careers page says every loop includes a single 60-minute "Outage Hour" with the hiring manager. It has a live-incident tabletop on a simulated outage, then a values conversation, and there is no take-home. So the pack weights tabletop-style case questions and the three published values most heavily.

The question I'd rehearse most is C2. It's the "you've never worked on a game with in-app purchases" question, set against Saltmarsh's September 2026 move to a season pass.

I only saw search snippets of the Project Larkspur announcement and Tobias's GDC talk, not the full pages. Read both before Friday.

Say the word and I'll play Tobias on C2, with follow-ups that react to what you say. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias the person you'd report to? If he's not, I'll reweight every bank.
2. Did the recruiter say anything about the tabletop, such as its format or what it covers? If so, I'll replace my invented scenarios with the real one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: the 60-minute interview on Friday, built as the hiring-manager round. Saltmarsh's careers page describes its loop as a recruiter call, then one 60-minute interview with the hiring manager, called the Outage Hour (a live-incident tabletop, then a values conversation). Whether Tobias is the hiring manager is assumed, not confirmed.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script: tell it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | The stated responsibilities and requirements, including gaps |
| CO | Homework on the company and its current strategy |
| CASE | A live problem from the actual role, scored on structure and reasoning |

An answer slot is an instruction for the interview, not a question for me. Answer it from your own experience, or say plainly that the practice was not yours.

## Prep triage

You have three days and I don't know the hours per day, so this is ordered by value and each step stands alone.

1. Say C2 aloud with its three follow-ups until the plain acknowledgment sounds boring. This is the highest-ROI prep in the pack.
2. Run A1, A2 and A3 aloud, timed, asking your clarifying questions before you structure anything. The tabletop is half the hour.
3. For B1 to B4, decide for each value whether one of your quoted sentences carries a story or whether you will use the honest branch.
4. Read the Project Larkspur announcement, the values page and the full text of Tobias's GDC talk (I only saw search snippets of the last two), then prepare A5, F2 and R2 to R3.
5. Pick three reverse questions and say them aloud once.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, not a live-events calendar across two, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely. If you ever balanced a second title's or team's calendar, say how, in your own words; if not, say so plainly and stay with the main title you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team" — your message | low | [inferred] | discovery | Your material does not show which teams the calendar work involved; the stated negative is about leading, and the JD's verb is coordinate. Words: "I haven't led a team." Answer slot: if any of design, art, engineering or community were people you worked with on a drop, say which and how it worked, in your own words; if the calendar did not involve them, or someone else coordinated them, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presenting monthly retention numbers, not a post-event review and not owning KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event review line makes a probe on whether you have run one likely. If a review followed any content drop and you ran or took part in it, say which part was yours; if none did, or the numbers were defined by someone else, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in wording, but a line with nothing inspected behind it, so expect a probe. Lead with the checklist in the quote's own terms: you wrote it, and your QA team still uses it. The JD's word is manage and the quote's is wrote, so the words stay at wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | The years are stated; your material does not say whether the main title was a live service. Answer slot: the JD's live-service line makes a probe on that likely. If the title kept running with updates, say what kept it live, in your own words; if it did not, say so plainly and stay with the four years and the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap in wording, but nothing inspected behind it. Lead with it in its own terms: you ran it, weekly, for two years, for the main title. Probes will go to how much was yours (D2) |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in wording, but nothing inspected behind it, so expect a probe on how the numbers were counted (E1). "I don't know how it was counted" is an honest branch for any part you did not define |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: a written document your QA team still uses. Offer it in its own words, "I wrote the release checklist our QA team still uses", and let the interviewer judge the writing. Nothing added about how clear it was or who said so |
| F9 | No JD line asks for it. Saltmarsh's Project Larkspur announcement (September 2026, read as a search snippet) describes a move to a season-pass model for two titles, so in-app-purchase experience is a likely probe: the pack's reading, not a stated requirement — Project Larkspur page | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Reading the interviewer

Public professional footprint only. The talk page was read as a search snippet, not in full.

| Observation | Source | Provenance | What it means for you |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games; previously a QA lead at a console studio | GDC 2026 talk page, search snippet | [grounded] | Release discipline and QA vocabulary are native to him, so expect weight on A6 and B3 |
| His talk "Patch Notes Are a Promise" argues a live team is judged by how often its patch notes describe what actually shipped | GDC 2026 talk page, search snippet | [grounded] | Expect probes on whether what you announce matches what is built: A3, B2, D3. A claim you cannot stand behind is the thing this interviewer is most likely to find |
| Shared vocabulary: the release checklist and QA. Your side is "Wrote the release checklist our QA team still uses" (F4) | Your message; talk page snippet | [inferred] | Use his words (checklist, what shipped, patch notes) where they are true of you. Do not build on a shared path: yours is not a QA-to-live-ops jump |

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A Case/Strategist | The Outage Hour's live-incident tabletop on a simulated outage during a live event | Highest. The careers page names the tabletop as one of the two parts of the single session | Clarify, then objective, then approach, then player communication, then review. Think aloud; challenge one premise |
| B Values/Behavioral | The values conversation that follows the tabletop, on three published values | High. Same source. A values-style round is detected on that basis | Where a quoted sentence carries a story, map it; where none does, use the scaffold and its honest branch. "We" for context, "I" for your part |
| C Skeptic | Probing the stated gaps: leading a team, in-app purchases, live-service years | High. F9 is stated unmet and F2 carries a stated negative; the JD asks for coordination and KPI ownership, and Project Larkspur moves titles to a season pass | Rehearse C2 until it is boring: one plain acknowledgment, what your material does carry at its scope, a plan stated as a plan |
| D Pressure | Interruptions inside the tabletop | Medium. The format simulates urgency, but whether Tobias interrupts is not established | Pause, restate, hold the position through two follow-ups, concede specifically |
| E Data-Driven Prober | Retention numbers and the KPIs the post-event review reports | Medium. The JD asks for comfort with retention metrics and F7 is the only quantified-metric line, with no figure given | Know what you can say about how each number was counted; say plainly where you don't know |
| F Conversational | The opener and any friendly aside | Low to medium. A short opener is likely in a 60-minute session; the page does not describe one | A 90-second arc made only of your own sentences |
| Peer Evaluator | Not built | The session is described as with the hiring manager, so no peer round is established | Reweight if you tell me the interviewer is a peer |

## Question banks

Highest-ROI prep in this pack: C2.

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A5, D2 |
| "coordinate design, art, engineering and community teams on each update" | A1, A2, C3 |
| "own the post-event review and the KPIs it reports" | A4, E3 |
| "manage the release checklist with QA" | A6, B3 |
| "3+ years producing live-service games or apps" | C4 |
| "experience running a content calendar" | A5, D2, F1 |
| "comfortable with player-retention metrics" | E1, E2, E3 |
| "clear written communication" | A3 |

### A. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It's the first hour of a weekend event. Players say they can't claim the event reward and the support queue is climbing. You're the producer on call. What do you need to know first?" | CASE | [inferred] | Ask before you answer: how many players, which platforms and builds, since when, and what changed just before it started. Then say your objective aloud: stop harm to players first, restore second, explain third. Name who you would pull in by function: engineering for the cause, QA to verify any fix, community for what players are told. Think aloud and name one premise you would check. If you don't know how Saltmarsh runs incidents, say you would follow their process and ask what it is. The question needs no claim about your past, so the guidance makes none | The careers page describes a live-incident tabletop on a simulated outage during a live event; the scenario details here are invented for rehearsal, hence the label. CASE because it scores structure |
| A2 | "Engineering says a fix is hours away and might break another system. Do you hold the event, extend it, or ship the fix? Walk me through your call." | CASE | [inferred] | Lay out the three options and what each trades: player harm now, reversibility, what QA can verify in the time. Commit to one recommendation and say what new information would change it. Say who you would expect to make the final call and that you would bring them a recommendation, not only options. Say plainly what you don't know, and invent no figure the interviewer did not give. No claim about your past is made | A decision under uncertainty is the usual second beat of a tabletop, but the page gives no scenario, so this is a pattern. CASE because it scores reasoning, not the right answer |
| A3 | "Write the first message players see. What does it say, and what does it leave out?" | CASE | [inferred] | Say what is known and what is not yet known. Promise no fix time you cannot commit to. Say where and when the next update will come. No blame, no speculation about cause. Short plain sentences, players addressed first. No claim about your past is made | The values page says "we announce what is built, not what is hoped" and the talk page title is about patch notes, so the wording of a player message is a likely scored detail; derived from both, not a stated rubric. Covers the written-communication line (F8) |
| A4 | "The event is over and the outage is fixed. What goes into the post-event review, and which KPIs do you report from it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Start with what you would bring: a timeline, the cause as best known, player impact, what the release checklist did or did not catch, actions with named owners. For KPIs, name the two or three you would propose and what you would want from analytics before committing, in your own words. On your own record, stay at the quote: "I presented the monthly retention numbers to the studio head." Answer slot: if a review followed any content drop and you ran or took part in it, say which part was yours; if none did, say so plainly and stay with the numbers you presented | F3 is the JD's post-event review and KPI requirement against thin evidence. JD because it scores the stated responsibility, with CASE delivery |
| A5 | "Saltmarsh is moving to one shared events calendar and a single live-ops group from February 2027. When two titles want the same weekend, how do you decide?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Propose principles, not their seams. Name what collides (engineering and QA time, community attention, player attention) and the order you weigh it, with the players first, because the values page says the players win when the calendar and the players disagree. Say you don't know how the new group is structured and would ask. Answer slot: the JD says two titles; if you ever balanced more than one calendar or team's content, say how; if not, say so plainly and stay with "I ran the weekly content-drop calendar for our main title for the last two years." | Project Larkspur is the one current-strategy fact found, read as a search snippet only, so read the announcement itself before Friday. CO because it tests homework; F1 is where the two-titles probe lands |
| A6 | "You inherit our release checklist on day one. What do you look at first, and what do you ask QA?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | At your own scope: "I wrote the release checklist our QA team still uses." Then the approach as a plan: read how releases have actually run against it, ask QA where it is slow or skipped, change little at first, and treat the checklist as belonging to the people who use it. Answer slot: if you revised your checklist over time, say what prompted a change; if it has stayed as first written, say so plainly | F4 is the strongest quote against a JD line, and the interviewer's QA background makes this the likeliest place for depth. JD because it scores the stated checklist responsibility |

### B. Values/Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the schedule and the players disagreed. Which one won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | No quoted sentence carries a story of the calendar and the players pulling apart; the calendar sentence is only the setting. Choose a time a planned drop and the player experience pulled different ways. It needs a named stake, the decision, who made it and what part was yours, and what changed afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Players Before Plans is the first published value. VAL because it scores behavior against that value, not the calendar skill (F1) |
| B2 | "Tell me about a time you had to tell people something would not ship the way it was announced." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | The checklist sentence is a written release step and says nothing about an announcement, so use it only as context. Choose a time a date, scope or promise changed after it was said aloud. It needs who you told, how, what it cost, and how they took it. If no such time comes to mind, say so plainly, then say how you would handle it: what is built, said plainly, and what is not, said as not yet | Ship the Patch Not the Promise is the second published value, and the interviewer's talk is about the same theme. VAL because it scores behavior, not the checklist (F4) |
| B3 | "Tell me about a time you left a process or a checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | The beats the quote states: the checklist, written by you, still used by your QA team; tell them in your own words. Answer slot: if the checklist replaced an earlier way of working, say what prompted it; if nothing earlier existed, or you can't say, say so plainly and stay with the checklist as it stands | Leave the Build Greener names the checklist directly, so F4 is the story this value was written for. VAL because it scores whether the behavior matches the value |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | The quote carries presenting to the studio head, not an unwelcome message, so it is a setting, not a story. Choose a time a number or status you presented was not what the room wanted. It needs a named stake, the plain words you used, what happened after, and whether the relationship held. If no such time comes to mind, say so plainly, then stay with the numbers you presented, at that scope, or say how you would handle it | The interviewer's talk argues for honest announcements, so unwelcome truths are a likely theme. VAL because it scores candor. F3 is the only line that puts you in front of senior people |

### C. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team"; "never worked on a game with in-app purchases" | Choose from your own material and name it plainly. Your material states two limits: you have never led a team, and you have never worked on a game with in-app purchases. Say whichever you judge weaker, in your own words, without softening ("I haven't led a team" or "I haven't worked on a game with in-app purchases"). Then what you would do in the first weeks: ask, shadow, read. Promise no speed | The standard Skeptic opener, and the likeliest way the stated gaps (F2, F9) surface unprompted. JD because it scores honest self-assessment against the listed role |
| C2 | "Saltmarsh is moving two titles to a season pass from February 2027, and you've never worked on a game with in-app purchases. How do you get useful, and how fast?" | JD | [grounded] "never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head" | The deepest rehearsal in the pack. Part one, said once and flat, no apology: "I haven't worked on a game with in-app purchases." Part two, what your material carries at its scope: "I presented the monthly retention numbers to the studio head." That is retention, not revenue, so do not stretch it. Part three, a plan stated as a plan: who you would sit with, which numbers and offers you would read first, what you would ask the post-event review to show. Rehearse three follow-ups: how long, what you would get wrong first, who you would lean on. For how long, give your own honest estimate, or say what you would need to see first. Hold the plan through all three; concede specifically what you don't yet know | F9 is the only gap row you have stated as unmet, and the Larkspur announcement puts the gap where the company is heading; it may arrive as a question about KPIs rather than purchases, so rehearse the structure, not the wording. JD because it scores the stated KPI responsibility (F3) |
| C3 | "This role coordinates design, art, engineering and community on every update, and you've never led a team. What's your plan for getting four disciplines moving together?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say once, plainly: "I haven't led a team." Then method, stated as what you would do: one shared view of the week's state, agreed cut-off times, and who decides what when two disciplines disagree. Answer slot: if you worked with any of those four disciplines on a content drop, say which and how it went, in your own words; if you did not, or someone else coordinated them, say so plainly and stay with the calendar you ran | F2 is a low-confidence row whose JD line names four disciplines, and its stated negative makes this question likely. JD because it scores the coordination responsibility |
| C4 | "The role asks for three-plus years producing live-service games. Where do your four years fit?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Say it at its own scope: "4 years as an associate producer at a puzzle-game studio." Answer slot: if your main title kept running with updates, say what kept it live, in your own words; if it did not, say so plainly. Do not borrow the JD's term for your title unless it is what it was | F5 grades the years against a requirement your material does not settle. JD because it scores the stated experience line |
| C5 | "Why leave a puzzle-game studio for live operations here, and why now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | Your reasons are yours and I won't write them. Answer slot: give your actual reasons, in your own words: what pulls you to this role and what you would be leaving. Structure only: the pull before the push, one specific thing about this studio you actually read (the values page, the talk, the Larkspur announcement), and 60 to 90 seconds in all | Motivation consistency is the Skeptic's second standard probe, and a studio change invites it. EXP because it tests whether your story survives cross-examination |

### D. Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, over a producer who has already run in-app-purchase events?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "never worked on a game with in-app purchases" | Hold, then concede. Hold on what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years" and "I wrote the release checklist our QA team still uses." Concede the gap specifically: "I haven't worked on a game with in-app purchases." Do not claim to beat the rival on it. Hold through two follow-ups by returning to the calendar and the checklist, never by adding to them | A time-boxed comparison is the standard stress probe; F9 gives it its target. JD because it scores fit against the listed role |
| D2 | "That calendar you ran: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: say what part you set and what you took in from others, in your own words; if the content or timing was set by someone else and you ran the schedule, say so plainly. The quote says "ran" and the hold goes no further. Hold the quote through two follow-ups; concede the specific part that was not yours, and do not fold on the rest | Attribution probes exist to catch inflation, and F1 is the line most open to it. EXP because it tests what was actually yours |
| D3 | "Stop. The fix failed and the studio head wants a number for how many players are affected in the next ten minutes. Give me your call." | CASE | [inferred] | Pause one beat and restate the ask. Say what you know and what you don't, give a recommendation with its limit, and decline a number you can't stand behind. Say what you would say instead: what is known, and when the next update comes. Concede the uncertainty specifically and do not fold. No claim about your past is made | An interruption mid-tabletop tests composure; the page does not say Tobias interrupts, so this is a rehearsal pattern. The values page's line about announcing what is built supplies the stance. CASE because it scores live reasoning |

### E. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The four slots a metric raises, each in your own words: how the figure was counted, what it is sensitive to, the assumption you would defend least (say it before they do), and which part was yours: defining, pulling or presenting. "I don't know how it was counted" is an honest branch for any part you did not build. Nothing here names a method or a definition, and the pack supplies none | F7 is the only metric line, and it carries no figure, so the probe goes to the counting. EXP because it tests what survives scrutiny |
| E2 | "Day-7 retention for players who joined during the event is flat against the week before. Was the event a success?" | CASE | [generic] | Clarify first: flat against what baseline, which cohort and how defined, what else changed that week, and what decision rides on the answer. Then say what the data can and cannot tell you and name the weakest assumption in your own reading. No claim about your past is made | A live retention problem from the JD's retention line, asked as a decision. [generic] because it is a pattern for the problem, not a fact about this employer |
| E3 | "Which retention numbers do you want in the first post-event review you own, and which would you distrust?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Your picks are yours; say why, and say which you would distrust and what you would check. Answer slot: if you chose the metrics you presented monthly, say which and why; if they were set for you, say so plainly | F3 and F7 meet here: the review's KPIs against the one retention line. JD because it scores the stated KPI responsibility |

### F. Conversational (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc made only of your own sentences, in this order: the four years as an associate producer at a puzzle-game studio, the weekly content-drop calendar you ran for the main title over the last two years, the release checklist you wrote that your QA team still uses, the monthly retention numbers you presented to the studio head. Then why this role: answer slot, your actual reason, the same as C5. First person, past tense, no sizes, no praise | An opener is likely in any hour and is scored. EXP because it tests whether the biography matches the CV |
| F2 | "Have you had a look at our patch notes?" | CO | [inferred] | Answer slot: if you read any, say what you noticed, in your own words; if not, say so plainly. Before Friday, if the patch notes for the titles in the Larkspur announcement are public, read the recent ones and note one thing each says plainly and one thing you would ask about | His talk is about patch notes (search snippet), so an interviewer's own theme is a likely friendly aside. Derived from the talk and values pages, not a stated question. CO because it tests homework |

## Values cheat sheet

Official names from Saltmarsh's values page, which was fetched.

| Value | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players disagree, the players win | F1: "I ran the weekly content-drop calendar for our main title for the last two years" carries the calendar, not a disagreement, so use B1's scaffold: a named stake, the decision, your part, what changed. If none comes to mind, say so plainly and give the nearest thing or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F4: "Wrote the release checklist our QA team still uses" carries a written release step, not an announcement, so use B2's scaffold. If none comes to mind, say so plainly and say how you would handle it |
| Leave the Build Greener | Each release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses" is the story this value names; see B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came into live operations from QA. What did QA teach you about live ops that you wish more producers knew?" | Ties to his own path, so the conversation turns from interrogation to peer talk, and it sits next to the checklist line (F4) |
| R2 | "Your GDC talk argues a live team is judged by whether its patch notes describe what shipped. How does this team check that before a release goes out?" | Shows you read his work and puts the values page's "what is built" line into practice. Read the full talk first; I only saw a snippet |
| R3 | "Project Larkspur moves to one shared events calendar from February 2027. Which two titles would this role's calendar cover, and does the role sit in the new single live-ops group?" | The JD says two titles and the announcement retires per-title teams; research can't settle how they connect, so the question is useful, not decorative |
| R4 | "What does a good first 90 days look like for the post-event review and the KPIs it reports?" | The JD gives you ownership of both (F3), and the answer tells you which numbers matter before you are asked to defend any |
| R5 | "With the move to a season pass, which numbers will the post-event review lead with?" | Asks the question your stated gap (F9) will otherwise raise, from curiosity rather than defense |
| R6 | "What would make you say, in six months, that this hire was the right call?" | Standard, and it gets the success criteria in the interviewer's words |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed the design, art, engineering or community teams | Negative you stated, F2 | "I haven't led a team." The coordination slot in F2 stays inside the calendar you ran |
| Ran a live-events calendar across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says one main title |
| Owned the post-event review and the KPIs it reports | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says presenting monthly retention numbers, not a review |
| Managed each release through the checklist with QA | Inflated form of F4 | F4's quote at its own scope: you wrote it, and your QA team still uses it |
| Four years producing live-service games | Inflated form of F5 | F5's quote at its own scope: four years as an associate producer at a puzzle-game studio. The limit is the pack's observation: the material does not say live-service |
| Worked on monetization, in-app purchases or a season pass | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." Then a plan, stated as a plan |

## Sources

Provided documents: your message, with the JD text and your background.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Query "Saltmarsh Games values" returned saltmarshgames.com/values, which was fetched. It supplied the three value names and meanings: the values cheat sheet and B1 to B4 |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Query returned saltmarshgames.com/careers/interviewing, which was fetched. It established the loop: one 60-minute session with the hiring manager, a tabletop then a values conversation, no take-home. Persona weights and the values-round decision follow from it |
| 3. `Saltmarsh Games mobile studio news strategy` | yes | Query returned saltmarshgames.com/news/project-larkspur, read as a search snippet only because the fetch budget went to targets 1 and 2. It supplied A5, C2 and F9 |
| 4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` | yes | Query returned talks.gdconf.example/2026/patch-notes-are-a-promise, read as a search snippet only. It supplied the interviewer read and R1 and R2 |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias is the hiring manager, plus anything the recruiter said about the tabletop → reweights the persona table and replaces the invented scenarios in A1 to A3 and D3 with the real format
- The release checklist itself, a calendar export and a retention report you presented (the inspectable artifacts in this field) → F1, F3, F4 and F7 move from `medium` toward `high`
- Your answers to the answer slots in F1, F2, F3 and F5 → those rows regenerate with your words quoted in, and the matching bank guidance stops being a slot
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the full Larkspur announcement and Tobias's talk, plus any candidate reports on the Outage Hour; say so if you want it
- A `tuesday-dossier.md` from a prior evaluation of this role → verified evidence and a pre-ranked objection list in place of this pack's local inference
