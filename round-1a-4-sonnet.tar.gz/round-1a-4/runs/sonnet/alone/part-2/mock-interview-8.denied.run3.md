Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it as a three-round loop pack for 3 December, from the recruiter's email, your JD, the values and your summary of the strategy brief. It has no interviewer read, because no names are assigned yet.

The question to rehearse first is C1, the round 2 question on the contact centre. You said you've never worked in one, and the role owns the process across it. The pack's second priority is G1, the round 3 escalation case.

Say the word and I'll play the Skeptic on C1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste your CV, or the complaints and reporting lines from it? I've worked only from your summary. More of your own sentences would let several answer slots (F1, F3, F4, F7, F8) become story-mapped answers.
2. Do you want a deeper research pass, with up to 6 more searches and 2 more fetches over several more minutes? The pack already rests on the brief, values and loop you sent, so it would add recent organisation news and candidate reports of Ashgrove's process.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Member Experience Lead — Ashgrove Credit Union — interview prep pack

**Candidate:** Dara. **Mode:** loop (three rounds on 3 December 2026, per the recruiter's email). **Interviewers:** the recruiter (round 1); the Head of Member Services, who would be your manager (round 2); a panel of two branch managers (round 3). No names are assigned yet, so there is no interviewer read.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An "Answer slot" is an instruction for the interview, not a question for you now. Where the pack says your material does not show something, that is the pack's observation, not words for you to say.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Ashgrove's published values, not generic virtue |
| EXP | Whether your own account survives scrutiny: what was actually yours |
| JD | The stated requirements of the role, including where you are thin |
| CO | Whether you know Ashgrove's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

**Highest-ROI prep in this pack: C1** (the contact-centre question, round 2). You have said you have never worked in a contact centre, the role owns the process across the contact centre, and a future manager testing for gaps will reach it. Rehearse it until it is boring. G1 (the round 3 case) is second.

## Fit snapshot (shared across all three rounds)

Evidence cells hold only your own sentences, quoted from your message. The JD lists no term the candidate either meets or does not (no licence, location, schedule or pay term), so no row is a hard gate. The 4+ years line is a length-of-experience requirement and is graded like any other.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log and a script you trained new tellers on, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how far your part ran beyond the log likely. If you handled steps beyond the log, say which and what part was yours; if the log was where your part sat, or it was not yours, say so plainly and stay with the log |
| F2 | "and the contact centre" — JD, the same duty line as F1 | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says you built a monthly complaints spreadsheet your regional manager uses; it does not say what the spreadsheet counts, so the words stay there: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's monthly-reporting line makes a probe on what the spreadsheet counted, and how, likely. If you know what it counted, say so in your own words; if you do not know how a figure in it was counted, or it counted something else, say so plainly and stay with the spreadsheet |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | Your sentence says spreadsheet and does not say which tool, and the pack does not resolve that upward. Answer slot: the JD's Excel line makes a probe on what it was built in and what you did in it likely. Say what it was built in and what you did, in your own words; if it was not Excel, or you did not build all of it, say so plainly and stay with what you built |
| F5 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare for senior audiences, said as a plan and never as a past. Never a claim to having presented to leaders, and nothing added to make the gap feel smaller |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | Your sentence already carries the length in other terms. Say it as written, with each figure staying on its own noun: the 6 years are in retail banking and the last 3 are as a branch supervisor. The JD's phrase stays the employer's vocabulary and is not put into your history |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your sentence says the branch's formal complaints log; it does not say what governed how those complaints had to be handled. The words stay: "I handled the branch's formal complaints log." Answer slot: the JD's requirement makes a probe on what governed the log's complaints likely. If you know what governed them, say what and what it required of you, in your own words; if you do not know, or nothing did, say so plainly and stay with the log |
| F8 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence says new tellers and our escalation script, and the words stay at that scope: "trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on who you have trained beyond new tellers, and how you knew it worked, likely. If you have trained others, say who and on what; if the new tellers were the whole of it, or you did not see the effect, say so plainly and stay with the tellers |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Strong evidence would be a named online or app step, what changed in it and your part in the change. Answer slot: the JD's digital line makes a probe on any work you have done with digital teams or online journeys likely. If you have, say what and what part was yours; if you have not, say so plainly and say what you would want to learn about the journeys first |

## Grounding brief

This rests on your summary of the July 2026 strategy brief, which is about four months old at 24 November 2026. The brief itself was not in the conversation, so wording below is your summary's, not the brief's.

| Item | What your summary says | Where it surfaces in your loop | Provenance |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | E1, F9, reverse question RQ6 | [grounded] |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | H3, reverse questions RQ1 and RQ7 | [grounded] |
| New product | "launch a small-business lending product in Q1 2027" | Reverse question RQ8 | [grounded] |
| Competitive frame | "the main competitive pressure is app-only banks" | E1 risks, G1 | [grounded] |
| Ashgrove's own vocabulary | The JD and values page say "member", "self-service journeys", "Plain Words"; use "member", not "customer" | Every answer | [grounded] |

The brief is equally available to every candidate and to your interviewers. Bring one item from it to show you read it, then one view of your own with its concession (E1 shows the shape).

## Round 1 — Recruiter screen (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / rapport (5 questions) | Friendly journey question, then pay, notice, location and reason for leaving | High: the relationship prior for a recruiter screen is Conversational plus a light Skeptic, and the email names a 30-minute call with the recruiter | A 90-second arc from your own sentences; treat the casual questions as scored; give your own logistics answers |
| B. Skeptic, light (3 questions) | Knockout checks in a friendly register on contact centre, presenting and years | Medium: F2 and F5 are limits you stated against JD lines, and F6 is the one the screen will check against the years | Say the limit first, plainly, then what you carry at its own scope |
| Not weighted | Pressure, Prober, Values, Case, Peer | Low: the prior table gives a 30-minute recruiter screen none of these | None needed here |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey so far, and what's drawing you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc on the beats those sentences state: the 6 years in retail banking, the last 3 as a branch supervisor; the branch's formal complaints log and the escalation script you trained new tellers on; the monthly complaints spreadsheet your regional manager uses. Tell them in your own words, at their scope. The why-this-role beat is your own reason, in your own words; use one of Ashgrove's four published values only if it is true for you | A journey question opens most recruiter screens and everything after it builds on it. EXP because it tests whether your arc matches your own account; F6, F1 and F3 are what it must carry |
| A2 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure or range in your own words, or ask for the role's band first. If asked what you earn now, you can decline or redirect without giving a number | A recruiter screen carries a pay question, and the only safe answer is your own. JD because it concerns the listed job's terms |
| A3 | "What's your notice period, and when could you start?" | JD | [generic] | Logistics slot: give your actual notice period in your own words | The recruiter plans the loop around start dates. JD because it concerns the job's terms |
| A4 | "Where would you be working from, and does the location of this role work for you?" | JD | [generic] | Logistics slot: give your actual location and any limit in your own words. If you do not yet know where the role is based, say so and ask the recruiter | Location is checked at the screen. JD because it concerns the job's terms |
| A5 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason in your own words | Motivation consistency is scored at the screen and re-tested in round 2. EXP because it tests whether your account holds across rounds |
| B1 | "The role covers the contact centre as well as the branches. What's your experience of contact centres?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The light version of C1, which carries the full hold. Say the limit first: "I've never worked in a contact centre." Then what you do carry, at its own scope: "I handled the branch's formal complaints log." Then one sentence on how you would learn the contact centre, as a plan and never as a past. Answer slot: if you have had dealings with a contact centre from the branch side, say what they were and what part was yours; if not, say so plainly and stay with the plan | F2 is a limit you stated against a duty the screen will check, and F1 is the adjacent work. JD because it scores the listed duty; Skeptic delivery because it probes the gap in a friendly register |
| B2 | "This role reports to senior leaders every month. What's your experience of presenting to them?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Say the limit first: "I've never presented to anyone above regional level." Then what you built, at its scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you have presented from it to your regional manager or others, say to whom and how it went in your own words; if it was sent and not presented, or you did not present it, say so plainly and stay with the spreadsheet. The hold-then-concede version is C3 | F5 is the second limit you stated, and the JD names senior leaders outright. JD because it scores the stated requirement; the screen asks it lightly and round 2 asks it hard |
| B3 | "The role asks for 4+ years in financial-services customer operations. How does your experience line up?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say it as written, keeping each figure on its own noun: "6 years in retail banking, the last 3 as a branch supervisor." Let them do the matching; you do not need to restate the JD's phrase as your history, and no slot is needed because the sentence carries the length | F6 is the cleanest row in the snapshot, and a recruiter checks it first. JD because it is a stated requirement; the answer is short on purpose |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Where is the role based now, and where does it sit once the branches become hubs?" | Settles the location slot in A4 and shows you read the consolidation in the strategy brief |
| RQ2 | "Who owns complaints in the contact centre and in the branches today, and does this role take over both or sit across them?" | Tells you how far the end-to-end duty in F1 and F2 actually runs, before round 2 tests it |
| RQ3 | "Once the Head of Member Services and the two branch managers are assigned, could you share their names?" | Unlocks the interviewer read and persona reweighting; the email says interviewers beyond their roles are not yet assigned |
| RQ4 | "Is there anything to read or prepare before the 20-minute case?" | The email names the case but not its format; the answer decides how G1 is rehearsed |

## Round 2 — Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| D. Values / behavioural (4 questions) | "Tell me about a time" prompts on escalations, handoffs and unwelcome messages | High: the recruiter's own words are "mostly behavioural" | Story-map from your sentences where one carries it; a selection scaffold ending in its honest branch where none does; "we" for context, "I" for contribution |
| C. Skeptic (3 questions) | Quiet probing of the contact-centre, regulated-complaints and senior-presenting gaps | High: the relationship prior for a hiring manager is Case/Strategist plus Skeptic, and F2 and F5 are limits you stated against headline duties | Rehearse C1 until it is boring; bridges only from adjacent evidence you stated; hold through two follow-ups, then concede specifically |
| E. Strategist and Prober, blended (2 questions) | One strategy question from the brief; one walk-through of your spreadsheet | Lower: the prior favours Case, but the recruiter says mostly behavioural, so the weight drops. The spreadsheet walk-through stays because F3 and F4 are unresolved | Clarify before structuring; say plainly what you do not know about how your own figures were counted |
| Not weighted | Pressure, Peer, Conversational | Low: no signal for them in this round beyond what C3 already rehearses | None needed here |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you coached someone through handling an escalation." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F8 at its scope: "trained new tellers on our escalation script." The beats the sentence states are the new tellers, the escalation script and the training; tell them in your own words. Answer slot: the JD's coaching line makes a probe on who you have trained beyond new tellers, and how you knew it worked, likely. If you have trained others, or saw a change in how someone handled an escalation, say who and what you saw; if the new tellers were the whole of it, or you did not see the effect, say so plainly and stay with the tellers | F8 is the evidence for the coaching duty and the likeliest place a manager asks you to stretch it. EXP because it tests what was actually yours; open-prompt shape because the JD raises the theme |
| D2 | "Tell me about a time you handed a complaint on to someone else. How did you make sure it was dealt with?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick one handoff where you can name who received it, what they were told, and how you knew the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "trained new tellers on our escalation script", or say how you would handle it. Do not describe a handoff you did not make | The JD's escalation theme and the round 3 case on escalation make handoffs a likely probe. EXP because it tests a real instance; F1 is the nearest row, and the quote does not carry a story, so the pack gives a scaffold |
| D3 | "Tell me about a time you worked across more than one team to get something resolved." | JD | [grounded] | Selection scaffold: pick a time the fix sat partly with another team; it needs a named team, what you needed from them, and how it ended. The JD asks for work across branches, the contact centre and digital teams, so the story is more useful if it crossed a channel or a function. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The JD's three-team scope (F1, F2, F9) makes cross-team work a natural theme. JD because it scores the listed duty; the guidance makes no claim about your past |
| D4 | "Tell me about a time you had to give someone senior an unwelcome message." | VAL | [generic] | Selection scaffold: choose a time the hard truth actually landed, with a named stake, what you said, and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Where your material shows no such time, do not supply an ending | A standard behavioural stem a future manager uses to test candour. VAL because it scores whether the hard truth lands; generic because no entity-specific fact supports it |
| C1 | "The role owns the complaints process across branches and the contact centre. Which part would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Name the limit before they do: "I've never worked in a contact centre." Then what you carry, at its own scope: "I handled the branch's formal complaints log." Hold through the follow-ups. If asked how you would own a process you have not seen from the inside, stay with the plan: say in your own words what you would ask to see first and whom you would ask. If told the contact-centre team will know more than you, concede specifically that you do not yet know how handling there differs from a branch's, and say what you would do first to find out; do not claim contact-centre knowledge or reach for a comparable. If given a case (a member gets different answers in a branch and on the phone), use the G1 structure and say where a step depends on contact-centre practice that you would ask rather than guess. Answer slot: if you have had dealings with a contact centre from the branch side, say what they were and what part was yours; if not, say so plainly and stay with the plan | F2 is a limit you stated against the role's headline duty, so a manager testing for gaps reaches it first, and F1 is its pair. JD because it scores the stated requirement; Skeptic delivery because it probes the gap. This is the question with the most follow-up levels, the most exact concession wording and a limit named before it is asked for |
| C2 | "The role asks for experience handling regulated complaints. Tell me about the formal complaints you handled." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F7 at its scope: "I handled the branch's formal complaints log." The beats the sentence states are the log, that it was the branch's, and that the complaints were formal; tell them in your own words. Answer slot: the JD's requirement makes a probe on what governed how those complaints had to be handled likely. If you know what governed them, say what and what it required of you, in your own words; if you do not know, or nothing did, say so plainly and stay with the log | F7 is a single mid-list line in the JD, the kind a manager scores one by one. JD because it scores the stated requirement; the question's premise is the JD's, and the guidance does not adopt it |
| C3 | "This role reports monthly to leaders more senior than anyone you've presented to. Why should I be comfortable with that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Hold-then-concede. Say the limit plainly: "I've never presented to anyone above regional level." Hold on what you built, at its scope: "I built the monthly complaints spreadsheet our regional manager uses." Concede specifically that you do not yet know what Ashgrove's leaders will ask of the report, and say in your own words how you would find out. Hold through two follow-ups by returning to what you built, never by adding to it. Answer slot: if you have presented from the spreadsheet to your regional manager or others, say to whom and how it went; if it was sent and not presented, say so plainly | F5 is the second stated limit, and a future manager is the first senior audience you would face in this role. JD because it scores the stated requirement; Skeptic delivery because it is a pressure-style challenge to a gap |
| E1 | "Our strategy is to move 40% of member service to digital channels by 2028. What does that mean for how we handle complaints?" | CO | [grounded] | Think aloud: clarify which journeys move first and what stays with a person; objective (the member's side of the counter, in plain words); segment complaints into those a self-service journey can settle and those that need a person; approach; how you would tell it is working; risks, including a member who must explain twice and the app-only banks the brief names as the main competitive pressure. Bring the 40% by 2028 as your proof you read it, then one view of your own with its concession: complaints show where self-service journeys fail, so digital design should read them, and you have not seen Ashgrove's data. Also say what you would not do: push every complaint into self-service. Answer slot: the JD's digital line makes a probe on any work you have done with digital teams likely. If you have, say what and your part; if not, say so plainly and say what you would want to learn first | The brief is public to every candidate, so the answer needs a view beyond it. F9 is a row with no evidence, so the slot is here, where the probe will arrive. CO because it scores strategy fluency |
| E2 | "Walk me through the monthly complaints spreadsheet you built. What does it show, and what is it built in?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say it at its scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's reporting and Excel lines make probes on what it counted and how, what tool it was built in, and who read it likely. Say each in your own words. The weakest-assumption move: name the counting choice you would defend least, or say plainly that you do not know how a figure in it was counted. If it was not built in Excel, or you did not set what it counts, say so plainly and stay with what you built | F3 and F4 are the rows with the most unresolved questions, and a spreadsheet you built is the one thing you can be walked through in detail. JD because it scores the reporting requirement; Prober delivery because the follow-ups go two levels deep |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ5 | "What would you want complaint reporting to the leadership team to look like by the end of my first quarter?" | The JD names monthly reporting; the answer tells you what the audience in F5 expects and shows you think in outcomes |
| RQ6 | "With the move to digital, which self-service journeys do you expect this role to work on first with the digital teams?" | Ties the JD's digital line (F9) to the 40% by 2028 target in the brief, and tells you where to aim your learning |
| RQ7 | "How do the branches and the contact centre hand a complaint to each other today, and where does it get stuck?" | Turns the contact-centre gap (F2) into a conversation about the real handoff and signals that your plan to learn it is concrete |
| RQ8 | "The strategy adds a small-business lending product in Q1 2027. Do you expect it to bring complaint types you don't see today?" | Shows you read the whole brief rather than the digital line alone, and asks about the future of the role rather than its present |

## Round 3 — Panel of two branch managers (60 minutes, including a 20-minute complaint-escalation case; also the values round)

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| F. Values / behavioural (4 questions) | One scored prompt per published value | High: the recruiter says the panel is the values round and scores against the four values | Map a story to each value where a sentence of yours carries one; a selection scaffold ending in its honest branch where none does; land the hard truth |
| H. Peer evaluator (3 questions) | The seam between branch and complaints process; credit when work spans teams; what the hubs mean for towns | Medium: branch managers sit above the supervisors this role coaches, so the seam is theirs to test | Reciprocity framing (what you bring them, not just what you need); propose seam principles rather than pretending to know the seam |
| G. Case / strategist (2 questions) | The 20-minute escalation case, with a coaching follow-up | Medium by time (20 of 60 minutes), delivered as two questions because G1 carries the follow-up levels | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Not weighted | Skeptic, Pressure, Prober | Low: the contact-centre and presenting limits may still come up from a panel member, and C1 and C3 cover them | None needed here |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Members First, Always: pick a time the member's view and an internal process or measure pointed different ways, name what you decided and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would handle it | Members First, Always is the value the recruiter's email makes certain to be scored. VAL because it scores a published value; the quote does not carry a story, so the pack gives a scaffold |
| F2 | "Tell me about a time a member needed something explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for Plain Words ("if a member needs it explained twice, we wrote it wrong"): pick a time you treated the repeat as a problem with the wording and not the member, and say what you changed. The nearest sentence you have is "trained new tellers on our escalation script". Answer slot: if the script's wording was something you shaped or changed, say what; if you only taught it, say so plainly and stay with the tellers | Plain Words asks whose fault the repeat was, which is the hard truth the panel is listening for. F8 is the nearest row. VAL because it scores a published value |
| F3 | "Tell me about a time what a branch means to its town changed how you handled something." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold for Neighbours, Not Numbers: pick a time a decision took the town into account against a figure or a rule, with a named stake and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "the last 3 as a branch supervisor", or how you would handle it | The panel are branch managers, so this value is theirs. F6 carries the years but no story, so the pack gives a scaffold. VAL because it scores a published value |
| F4 | "Tell me about a problem you found that you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1 at its scope for Own the Fix: "I handled the branch's formal complaints log." The sentence states the log and nothing about how long any item stayed with you. Answer slot: if one problem stayed with you until it was solved, say which, what you did and how it ended; if the log passed items on to others, or none stayed with you, say so plainly and describe how you would keep hold | Own the Fix is the value closest to the complaints log. VAL because it scores a published value; the slot is there because the quote does not say how long anything stayed with you |
| G1 | "Here is a case. A member's complaint has been passed between a branch and the contact centre and is still open weeks later. The member writes to say they are moving to an app-only bank. Walk us through what you would do, and what you would want to know first." | CASE | [generic] | Think aloud: clarify who holds it now, what the member was told and by whom, what the member wants, and what rules set the timing (ask; do not assume). Objective: the member's side of the counter, with one person keeping hold until it is solved. Segment what can be fixed today, what needs another team, and what is a wider problem. Approach in plain words. How you would tell it is working. Risks, including a member who must explain twice. Challenge one premise respectfully: was it passed, or lost? Where a step depends on contact-centre practice, say that is where you would ask. The guidance makes no claim about your past | The email names a 20-minute case on complaint escalation but not its content, so this is a rehearsal pattern and not a prediction. CASE because it scores structure; generic because it makes no entity-specific claim |
| G2 | "You've resolved it. A branch supervisor tells you your escalation steps don't work in their branch. How do you respond?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Structure: listen first; find where the step actually broke; separate a wrong step from a step that was not understood, and remember Plain Words; decide who changes what; close the loop. If asked what you carry, it is "trained new tellers on our escalation script" and no wider. Answer slot: if you ever changed a script or step after feedback, say what and what part was yours; if you did not, say so plainly and describe how you would | F8 is the coaching duty, and a case follow-up is how a panel tests it. CASE because it is a live problem from the role; the quote is the only claim about your past the cell makes |
| H1 | "Our branches sit alongside your role. When a branch and the complaints process disagree on what to do with an escalation, who decides?" | JD | [generic] | Propose seam principles, not a map you do not know: one owner keeps the complaint until it is solved; the person closest to the member keeps a say in what is decided. Say you would ask what is decided where today before proposing anything. Offer reciprocity: what the branch gets from you, not only what you need from it. The guidance makes no claim about your past | Branch managers are the people this role coaches and works beside, so the seam is their question. JD because it scores the coaching and ownership duties; generic because it makes no entity-specific claim |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold: use "we" for context and "I" for your own contribution, and keep each at its scope; the nearest sentence you have is "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if others contributed to it, say who and what; if it was yours alone, say so plainly | A standard peer stem on credit-sharing; branch managers will have seen candidates over-claim. VAL because it scores partnership fit |
| H3 | "Eight branches are becoming five hubs over 2027, and some towns will lose a branch. How would you want complaints handled for members in a town that loses its branch?" | CO | [grounded] | Think aloud, and lead with the member and the town before figures; Neighbours, Not Numbers is the value being scored, and the sentence you have about a spreadsheet is not the one to lead with. Clarify what is known about the hub plan and say you would ask; structure by what members in those towns will need from a person and what they can do themselves; name the risk of a member who must explain twice. The guidance makes no claim about your past | The consolidation is in the strategy brief and is the panel's own organisation changing, so it is the strategy question they will care most about. CO because it scores strategy at the company's altitude |

### Values cheat sheet

Round 3 is the values round, per the recruiter's email. Value names and definitions are as pasted from the values page.

| Value (official name) | Working meaning (paraphrased) | Your mapped story | Questions |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold ending in its honest branch (F1 row; the nearest sentence is "I handled the branch's formal complaints log and trained new tellers on our escalation script.") | F1 |
| Plain Words | If a member needs it explained twice, the writing was wrong | F8 row: "I handled the branch's formal complaints log and trained new tellers on our escalation script." carries the script, not its wording, so the slot in F2 settles whether you shaped it | F2, G2 |
| Neighbours, Not Numbers | Every branch belongs to its town | Selection scaffold ending in its honest branch; no sentence in the snapshot carries a story for it (F6 row has the years: "6 years in retail banking, the last 3 as a branch supervisor.") | F3, H3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1 row: "I handled the branch's formal complaints log and trained new tellers on our escalation script." carries the log, not how long anything stayed with you, so the slot in F4 settles it | F4, G1 |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ9 | "When a complaint escalates from your branch today, what do you wish happened differently?" | Asks the panel about their own side of the seam in H1 and gives you the real friction to work on |
| RQ10 | "What could a new Member Experience Lead do in their first month that would genuinely help your branch?" | The reciprocity question for a panel who work beside the role |
| RQ11 | "Can you give me an example of someone in your branch owning a fix?" | The panel scores against the four values, so asking for a story of one shows you read them and invites the panel to describe what good looks like |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B1, C1, G1, D2 |
| "report monthly on complaint volumes and resolution times" | E2, RQ5 |
| "coach branch supervisors on escalations" | D1, G2, H1 |
| "work with digital teams on self-service journeys" | E1, D3, RQ6 |
| "4+ years in financial-services customer operations" | B3, A1 |
| "experience handling regulated complaints" | C2 |
| "confident presenting to senior leaders" | B2, C3 |
| "comfortable with Excel reporting" | E2 |

## Prohibited claims

What this pack will not coach, built from the fit snapshot before any question was written. A claim on this list is not asserted, softened or implied in any cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says one branch's log, not the process across branches |
| Has contact-centre experience | A negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." Then a plan, never a past |
| Has presented to senior leaders | A negative you stated, F5 | The plain acknowledgment F5 gives: "I've never presented to anyone above regional level." Then a plan, never a past |
| Reported on the complaints figures the JD names | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The limit is the pack's observation: the material says a spreadsheet, not what it counted |
| Coached branch supervisors | Inflated form of F8 | F8's quote at its own scope: "trained new tellers on our escalation script." The limit is the pack's observation: the material says new tellers, not supervisors |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says a formal complaints log, not what governed it |
| Six years of complaints experience | Inflated form of F6 and F7, with the figure moved to a different noun | F6's quote with each figure on its own noun: "6 years in retail banking, the last 3 as a branch supervisor." |

## Sources

Provided documents: the JD, the published values, the recruiter's email, your summary of the July 2026 strategy brief, and your background, all from your message. The values were copied from ashgrovecu.org/about/values on 24 November 2026; that page was not fetched. The strategy brief itself was not in the conversation, only your summary of it. No dossier was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The pasted values page fixes the values cheat sheet and the VAL questions |
| 2. Ashgrove Credit Union interview process, member experience | skipped | The recruiter's email fixes the loop: three rounds, who runs each, the case and the values round |
| 3. Ashgrove Credit Union strategy and recent news | skipped | Your summary of the July 2026 brief, about four months old, fixes the grounding brief and the CO questions |
| 4. Interviewer name and Ashgrove Credit Union | n/a | No name has been assigned, only roles, so no query can be formed; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or the complaints and reporting lines from it → F1, F3, F4, F7 and F8 gain more of your own quoted sentences, and some answer slots can become story-mapped answers
- Your answers to the answer slots, said outside a drill (what the spreadsheet counted and what it was built in, what governed the formal complaints log, who you have trained beyond new tellers) → the rows that draw on them regenerate, and D1, C2 and E2 firm up
- The names of the Head of Member Services and the two panel branch managers → an interviewer read, persona weights read from their public footprint, and a reverse question tied to their own path
- The recruiter on the 20-minute case: its format and any pre-reading → G1 and G2 retuned to the real case
- The strategy brief itself, pasted → the grounding brief moves from your summary's wording to the brief's own
- Hours available before 3 December → a prep schedule sized to your time, naming the few things to do in order
- A tuesday-dossier.md from job-underwriter, if you have one → verified evidence, claims to avoid and an allowed strategy per weak area replace the locally built prohibited list
