I'll read the reference files the skill requires before writing anything.
I've saved the pack and I'm now checking it against the skill's rules: that quotes match your wording exactly, and that the cells have no stray brackets, question marks or pipes.
The check script needs approval, so I'll skip it and review by hand. One upgrade-menu line reads ambiguously, because "F1 to F6" could mean fit rows or bank IDs. I'll fix it.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-1-denied-ee45a18b/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 22 questions across seven personas, built for a peer conversation with Dan. I also tried a script to check that the quoted lines match your wording exactly, but it needed approval, so I checked by hand instead.

- **Research:** all three web searches (company values, interview process, Dan's public footprint) were refused, and I didn't retry. The pack rests only on what you gave me. That means no values cheat sheet, and Dan's profile read uses only your description of him. The Sources section says this.
- **Assumption:** I used the JD highlights as the JD and treated this as one 60-minute session. Your note about Compass is used as a stated priority. I don't assume it is one of the two new product lines.
- **Persona weights:** Prober is highest at 5 questions and Peer Evaluator next at 4. Dan's "relentlessly data-driven" and pricing background push Prober and Case up. The Values bank stays small because I found no published values.
- **Highest-ROI rehearsal:** D1 is the sales-ops and quota objection. Priya's own "No classic sales-ops or quota-setting experience" is quoted as the plain concession. It has four levels, ending in a ramp-plan slot for her to fill in. A1 and H2 (the ~$400M figure) and C4 and D2 (partner-motion design) come next.
- **Gaps held back:** partner-motion design and taking a product line to market are the thinnest rows. Priya's material shows a model used in carrier negotiations and a product strategy and ops function. Neither is claimed beyond that, and the "Prohibited claims" section lists what the pack won't coach. Answer slots mark where only Priya can say what she actually did.

I can play Dan live on D1, the highest-ROI question, if you pick a persona or question.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
I can convert the pack to a Word document if you'd like.

1. Did the recruiter name any focus areas or a pre-announced deliverable (POV, presentation, take-home)? A deliverable would add its own build section.
2. Can you paste the full JD text? The fit snapshot would then quote the JD's own lines instead of your highlights, and any requirement the highlights omitted would get a question.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

- **Candidate:** Priya
- **Interviewer:** Dan Kovac, Director of Sales Strategy. A peer: both roles report to the same VP.
- **Format:** one 60-minute conversation with Dan. Your own words establish this single session, so persona weights below rest on that and not on an assumed loop.
- **Built from:** your message only (JD highlights, not the full JD; a summary of Priya's background; a description of Dan's profile; your research note). The web searches I sent were refused, so nothing here comes from outside what you gave me.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Every question carries one type tag:

| Tag | Meaning |
|---|---|
| VAL | Behavioral: whether past behavior shows a value, here drawn from persona themes because no published company values are in hand |
| EXP | Work-experience deep-dive: whether CV claims survive scrutiny and attribution is precise |
| JD | Role and JD-driven: can the candidate do the listed job, gaps included |
| CO | Company and strategy knowledge, at the company's altitude |
| CASE | A live problem set in the role; it asks about no past |

Guidance is scaffolding, not a script. Where a guidance cell says "answer slot", it is an instruction for the interview: answer from what Priya actually did, or say plainly that the practice was not hers or did not exist. Nothing in the pack supplies a method, number or event she did not state.

**Highest-ROI prep:** D1, the sales-ops and quota objection. It is the one the material most exposes against a Director of Sales Strategy, it will arrive in some form, and a rehearsed, non-defensive answer changes the conversation. Next: A1 and H2 (the ~$400M figure, in prober and pressure registers), then C4 and D2 (partner-motion design, the JD's "required" item).

**Requirement coverage**

| JD requirement (JD highlights) | Questions |
|---|---|
| "own GTM strategy for two new product lines" | C1, C3, D2, H1 |
| "identify whitespace across land/adopt/expand/renew" | C2, C3 |
| "run independent analysis in SQL and Tableau" | A4, C2, B4 |
| "partner-motion design experience required" | C4, D2, A2 |
| "strong cross-functional influence" | A3, B1, B2, B3, B4 |
| "AI experience a plus" | E2, C3 |
| Sales-ops and quota familiarity (not in the highlights; a peer in Sales Strategy is the likeliest to probe it) | D1, H1 |
| Headline figure, ~$400M ARR | A1, B2, H2 |

## 4. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material gives the function, product strategy and ops, and does not show taking a product line to market. The words stay there: "I spent nine years in product strategy and ops at a large consumer-tech company." Answer slot: the JD's two-new-lines line makes a probe on taking a product to market likely. If any of your work launched or positioned a product, say which part was yours; if none did, or it was not yours, say so plainly and stay with the product strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The quote is a proposal and a credited uplift, not a lifecycle-stage analysis, and the words stay at that scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD names four lifecycle stages, so expect a probe on whether any of your work was cut by stage. If it was, say which stages and how; if it was not, or the work was not framed that way, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The tools are covered in the quote's own terms: "I'm skilled in SQL and Tableau." It is a CV line with nothing inspected behind it, and it says skilled, not that analyses were run independently. Answer slot: Dan's self-description as "relentlessly data-driven" makes a probe on an analysis you ran yourself likely. If you wrote the queries and built the views, say which analysis and what it was for; if others did that work, or you used the tools differently, say so plainly and stay with the tools you use |
| F4 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | The quote says use, names no tool and does not show building or launching anything with AI. Answer slot: if you can name the tools and what you use each for, say so in your own words; if the use is narrower than daily, or you cannot name a concrete use, say so plainly and stay with what you do use |
| F5 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The quote is a model that was used in negotiations, not the design of a partner motion, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD's partner-motion line makes a probe on motion design likely. If any part of a partner motion's design was yours, say which part and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the model |
| F6 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe on how the consensus was reached. Lead with the quote's own terms: "I set annual volume targets with cross-org consensus." Answer slot: if the consensus was contested, say where the disagreement lay and how it resolved; if it was reached without dispute, say so plainly and stay with the targets and the consensus |
| F7 | Sales-ops and quota-setting familiarity, the native ground of a Sales Strategy peer (role-family expectation, not a JD line) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the coach's notes say so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller, and F6's targets are not offered as the missing thing |

## 7. Reading the interviewer

Source: the description of Dan's profile you gave me. My searches for his public footprint were refused, so nothing beyond your description is used.

| Signal (as you described it) | What it means for this conversation |
|---|---|
| Self-describes as "relentlessly data-driven" | Every number is probed to its assumptions. Expect A1 to H2 in some form, and name your weakest assumption before he does |
| Career spine in pricing and monetization roles | Cases will tilt toward pricing, packaging and unit economics (C3). That is his native vocabulary |
| One early-stage-startup chapter | Builder stories land well with him; expect probes on pace and on working with less cover (D3) |
| Peer, same VP | He is pricing what this hire costs and adds to his own work: seam, credit and reciprocity questions arrive collegially (bank B), and objections from other banks come back in friendly packaging |

**Mirror opportunities.** Dan's path is pricing and monetization; F5's evidence cell holds "built a partner-level revenue model used in carrier negotiations". That is shared vocabulary around revenue modelling and nothing more. It is not a shared jump, and it is never offered as pricing experience (section 13). No shared-background angle is coached.

## 8. Persona table

| Persona | Bank | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | A | Line-by-line probing of the figures and the SQL/Tableau claim; follow-ups two levels deep | Top: the peer prior plus "relentlessly data-driven" in his own description | Know what you can and cannot say about how each number was counted, say plainly when you do not know, name the weakest assumption first |
| Peer Evaluator | B | Seam, credit, disagreement, "what would you need from me" | Top: a peer prior, and a hire reporting to the same VP puts the seam on the table | Offer seam principles instead of pretending to know the seam; frame what you bring his team as well as what you need |
| Case / Strategist | C | Live problems from Northwind's stated priorities, tilted to pricing and packaging | High: the JD asks for GTM ownership and whitespace work, and his spine makes pricing angles his natural cases | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Skeptic | D | Gap probing, delivered quietly: sales-ops and quota, partner motion, big-company background | Medium: peers ask gap questions collegially and the material has stated gaps (F7) and thin rows (F1, F5) | Rehearse D1 until it is boring; bridge only from stated adjacent evidence; plan, not past |
| Conversational / Rapport | E | Opening "walk me through the journey"; a casual AI question | Medium-low: a 60-minute peer chat usually opens this way, and the JD flags AI as a plus | A 90-second arc built from your quoted sentences; treat the AI question as scored |
| Values / Behavioral | G | Behavioral prompts inside the conversation | Low: your words describe one conversation with a peer and not a values round, and no published values are in hand | Pick stories by the scaffold; if none fits, say so and give the nearest thing |
| Pressure | H | A time-boxed "why you" and a "how much was you" | Low: a peer is less likely than a skip-level to stress-test composure, but both probes follow naturally from his data-driven style | Pause, restate, hold through two follow-ups, concede specifically |

## 9. Question banks

### A. Data-Driven Prober (top weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that ~$400M ARR number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the quote says, in your own words: you proposed the change, and the uplift was credited to it. Then the four defend-the-number slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least (name it before Dan does), and which part was yours. If you do not know how it was counted, say so plainly | F2 is the headline figure and the first thing a data-driven interviewer opens. EXP because it tests whether the number survives scrutiny, not JD fit |
| A2 | "Walk me through the inputs to that partner-level revenue model, and which one you would trust least today." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: you built a partner-level revenue model, and it was used in carrier negotiations. Tell them in your own words. Answer slot: expect a probe on what went into the model and how it was checked. If you know the inputs and how it was validated, say so, naming the weakest assumption you know of first; if you do not know, or part of it was not yours, say so plainly and stay with what you built | F5 holds the nearest evidence on partner economics, and Dan's pricing and monetization spine makes a model the natural thing to open. EXP because attribution and assumptions are what is scored |
| A3 | "Tell me how those annual volume targets got set." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the quote states: annual volume targets, with cross-org consensus. Answer slot: expect a probe on method and data. If you used a method, say which in your own words and what data went into it; if there was no formal method, or the targets were set partly by others, say so plainly and stay with the targets and the consensus. The pack's observation: it does not call these targets quotas, and F7 records that quota-setting is not in your material | F6 is the cross-functional evidence and the likeliest bridge Dan tests toward his own ground. EXP because the probe is on how the claim was produced |
| A4 | "Tell me about an analysis you ran yourself in SQL and Tableau, from the question to the decision it fed." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick an analysis where you wrote the queries and built the view yourself. Name the question, the data source, one check you ran on the result, and what decision it fed. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, that you are skilled in SQL and Tableau, or say how you would approach one. Offer to walk through it end to end | The JD says independent analysis, and F3 does not show it. JD because it scores a stated requirement; an open prompt, so no event is supplied |
| A5 | "Which metric would you refuse to use to judge a new product line two quarters after launch, and why." | CASE | [generic] | No claim about your past. Name the metric, say what it hides, give the replacement, then state the assumption behind the replacement before Dan asks. Think aloud | A live problem that tests assumption discipline on the JD's new-lines work. CASE because it asks about no past |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our two teams sit under the same VP. Where is the seam on the new lines, and what happens when we disagree?" | JD | [grounded] | You do not know the seam, so do not pretend to. Propose principles: one owner per decision, shared definitions of the numbers, disagreements put to the VP with both views written down. Then ask Dan where he sees the seam and what he would want from the role there | The relationship is peer and same-VP, so this is near certain. JD because F6's influence requirement is what it scores |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Dan can pivot from the credited uplift, so be exact: the quote says you proposed the change and the uplift was credited to it. Answer slot: if others contributed to that change, say who and what they did; if not, say so plainly. Give one rule you actually work by on credit, in your own words | F2 is where a credit probe lands. EXP because the persona stem scores attribution honesty |
| B3 | "Tell me about a time you disagreed with a peer team on a number or a target." | VAL | [grounded] "set annual volume targets with cross-org consensus" | The quote carries consensus, not disagreement, so this is a selection scaffold. Pick the instance where you held a position and the other team's case was real. Name the number, what each side wanted, how it resolved, and the relationship afterwards. If reaching that consensus involved such a disagreement, say so, since it is the nearest instance; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Disagreement style with an equal is the core peer score. VAL because it scores behavior; no published value is in hand, so the theme comes from the persona |
| B4 | "In your first ninety days, what would you need from my team, and what could you take off my plate." | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity first. What you bring his team stays at the quote's scope: analysis in SQL and Tableau. Make no offer on pricing, quotas or sales-ops, which are his ground. For what you need, ask where his team's analysis load is heaviest and what he would want first | A peer is pricing what the hire costs and adds. F3 is the offer and F7 is the boundary. JD because it scores partnership fit in this seat |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Northwind's stated priorities are enterprise expansion, the Compass launch and reaching profitability. Sketch the GTM plan for one new line in its first two quarters. What do you need to know first?" | CASE | [grounded] | Clarify first: which line, who buys it today, what installed base you would expand into, and what profitability allows in launch spend. Then objective, segmentation, approach, metrics, risks. Challenge one premise, for example whether the first two quarters should go after new enterprise accounts or the existing base. Name bundling by a much larger platform vendor in the risks | The user's research note supplies the priorities and the threat, and the role owns GTM for new lines. CASE because it is a live problem; CO content |
| C2 | "Take land, adopt, expand and renew. How would you find whitespace for a new line, and what would you pull from the data?" | JD | [grounded] | No claim about your past. Define one measure per stage, find where cohorts stall between stages, size the gap per segment, then rank by payoff against effort given the profitability priority. Say what the SQL pull is and what the Tableau view would show, and state the weakest assumption in your sizing | The JD's whitespace line, in Dan's data-driven register. JD because it scores the stated requirement, with CASE delivery |
| C3 | "A much larger platform vendor starts bundling a competing capability into its suite. How do you protect the economics of Compass without discounting your way out of profitability." | CASE | [grounded] | Clarify who is exposed and which buyers see the bundle as their real alternative, and challenge the premise that it is a like-for-like substitute. Options: change the value metric or packaging, lean on partner-led distribution, compete on depth. Then set a discount floor and a cost-to-serve view, since profitability is a stated priority. Use unit-economics vocabulary, which is Dan's | The bundling threat is the user's research finding, and Dan's pricing spine tilts the case toward packaging. CASE because it is live; CO because it needs the company's frame |
| C4 | "Design the partner motion for one of the new lines. Which partners, what do they get, and how do you know it is working." | CASE | [grounded] "built a partner-level revenue model used in carrier negotiations" | Structure it: objective, partner types, what each gives and gets, measures (sourced and influenced pipeline, by stage), risks, including conflict with direct sales, where you propose a principle and ask Dan. Partner type names are generic labels, not claims about Northwind. If you refer to your past, say only the quote: you built a partner-level revenue model used in carrier negotiations. The pack's observation: the material shows a model used in negotiations, not a designed motion, so frame this as how you would design it | The JD says partner-motion design is required and F5 is adjacent only. CASE because it is a live design problem; JD content |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I do not see classic sales-ops or quota-setting in your background. How would you handle that in this seat." (**highest-ROI rehearsal**) | JD | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" | Level 0, no defending: "I don't have classic sales-ops or quota-setting experience." Level 1, hold on the quote at its own scope: you set annual volume targets with cross-org consensus. Say what that is, and do not call it quota-setting. Level 2, if Dan says a volume target is a quota under another name: hold at the quote's scope, concede that you cannot speak to how the sales side builds quota, and ask where the differences matter to him. Level 3, "what do you do on day one": give a plan in your own words (whom you would ask, what you would read, which planning cycle you would sit in on, by when); the pack supplies no names, systems or dates. Never fold on the targets-with-consensus claim to restore harmony, and never stretch it | F7 is the biggest gap against a peer whose function is sales strategy, and F5 and F1 sit behind it. JD because it scores whether the candidate can do the listed job gaps included; Skeptic delivery |
| D2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Pick one and say it before Dan picks for you. The pack's observation: partner-motion design (F5) and taking a line to market (F1) are where your material is thinnest against the JD. Answer slot: if you name partner-motion design, say what your quote carries, that you built a partner-level revenue model used in carrier negotiations, then what you would learn first, as a plan; if you judge another item weaker, say that and why | A standard Skeptic stem and it forces a calibrated, not defensive, answer. JD because it scores honest self-assessment against the listed requirements |
| D3 | "Nine years at one large company. How do you see yourself adapting here?" | EXP | [grounded] "then 9 at a large consumer-tech company in product strategy & ops" | Selection scaffold: pick an instance where you worked without the usual support or resources, and name the constraint, what you did and the result. Answer slot: if you worked that way at any point, say when and what you did; if you did not, say so plainly and say how you would learn the pace here | Dan's startup chapter makes pace and scrappiness likely probes of a big-company background (F1). EXP because it tests whether the career story survives cross-examination |

### E. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" "then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc built from the beats the quotes state: two years of strategy consulting at a top firm, then nine years in product strategy and ops at a large consumer-tech company. Tell them in your own words. End with your own one-sentence reason for this move; the pack holds none from you, so it supplies none. Link to the role in the JD's terms only | A peer chat almost always opens here, and it is scored. EXP because it checks that the story is consistent with the CV |
| E2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Answer slot: name the tools and what you use each for, in your own words. If the use is narrower than daily, or you cannot name a concrete use, say so plainly. Do not let the answer drift into building or launching an AI product; your material does not show that. Ask what Compass is meant to do rather than speculating | F4 is low-confidence, so this is a clarify-strategy row. JD because AI is a stated plus, asked casually |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem kept at low weight: no published values are in hand and this is not a values round. VAL because it scores behavior |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the metric and the customer pulled apart and name what you chose and what it cost. Profitability is a stated Northwind priority, so be ready for the follow-up on the cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; the profitability priority makes the trade-off angle likely. VAL because it scores behavior |

### H. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds. Why you, over someone who has run a sales-strategy or GTM function?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "skilled in SQL/Tableau" "No classic sales-ops or quota-setting experience." | Pause, restate the question, then answer inside sixty seconds with the three quotes at their scope and no claims about the other candidate. Hold through two follow-ups. Concede specifically: "I don't have classic sales-ops or quota-setting experience." Never fold on the three quoted claims | F5, F6 and F3 are the evidence and F7 is the concession. JD because it scores fit against the listed job under time pressure |
| H2 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause. Anchor in the quote: you proposed the change, and the uplift was credited to it. Hold that through two follow-ups. Answer slot: if others built, launched or measured the change, say who and what; if you do not know how the credit was assigned, say so plainly. Never move from proposed to delivered | A1's number again, in a pressure register. EXP because the stem scores attribution under pushback |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has been in pricing and monetization. How does that shape how you would want the new lines packaged, and where does that leave what you would want this seat to own?" | Ties to Dan's own path and opens the seam question on his terms |
| R2 | "What did the early-stage chapter change about how you plan, compared with your other roles?" | Ties to his path and converts a pace probe into a peer conversation |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it signals you are thinking about his load |
| R4 | "Are the two new lines the same ones tied to the Compass launch, or separate bets?" | Fixes the scope of C1 and C3 and shows homework from the stated priorities |
| R5 | "Where is the bundling threat showing up in deals today, and what does your team already do about it?" | A CO question from the research note; it invites his data |
| R6 | "When your team and this seat disagree on a number, how does the VP expect us to resolve it?" | Answers B1's seam question from his side and shows you plan for disagreement |
| R7 | "What would a strong first quarter in this seat look like, in numbers you would check?" | Speaks to a data-driven interviewer in his own register |

## 13. Prohibited claims

Built locally from the fit snapshot before the banks were written. No guidance cell asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM for, or took to market, a product line | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says product strategy and ops, not GTM for a product line |
| Designed a partner motion or programme, or ran partner negotiations | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says a model used in negotiations, not the motion or the negotiating |
| Priced products or ran monetization pricing | Inflated form of F5 | F5's quote at its own scope: a partner-level revenue model. Shared vocabulary with Dan only; the limit is the pack's observation |
| Set quotas or did sales-ops, including treating annual volume targets as quota-setting | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." F6's quote stays at its own scope. No slot |
| Delivered or owned the ~$400M ARR uplift, or explained how it was sized | Inflated form of F2 | F2's quote: proposed, and credited with. The limit is the pack's observation; A1's slots ask only how it was counted, what it is sensitive to, the weakest assumption and which part was yours |
| Built, shipped or led an AI product | Inflated form of F4 | F4's quote at its own scope. E2's slot asks only what tools are used and for what |
| Ran independent end-to-end analyses as a fact | Inflated form of F3 | F3's quote at its own scope. A4 is a scaffold with an honest branch, not an asserted claim |

## 14. Sources

**Provided documents:** your message: JD highlights (not the full JD), a summary of Priya's background, a description of Dan's profile, the research note on Northwind's priorities and competitive threat. No dossier was present.

**Searches sent (all refused, none retried):**
- "Northwind Data company values": refused
- "Northwind Data interview process strategy GTM": refused
- "Dan Kovac Northwind Data Sales Strategy": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions mapped to named values; neither section exists in this pack |
| 2. `Northwind Data interview process` | unavailable | Every call was refused. It would have shown whether other rounds exist and whether a values round is documented. Persona weights rest on your description of one conversation instead |
| 3. `Northwind Data strategy` / recent news | skipped | The research note you pasted supplies the three priorities and the competitive threat, which fix the CO and CASE content. Its age is not known |
| 4. `Dan Kovac Northwind Data` | unavailable | Every call was refused. The interviewer read rests on your description of his profile alone |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions, though they are highlights and not the full text |

## 15. Upgrade menu

- Full JD text → the six JD rows (F1 to F6) quote the JD's own lines instead of your highlights, and any requirement the highlights left out gets a question
- Permission to run web research (values page, loop structure, Dan's public footprint) → a values cheat sheet if a values round is documented, a persona reweighting if there are more rounds, and a richer interviewer read
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, only if search is permitted → a company strategy brief that sharpens C1 and C3
- Whether Compass is one of the two new lines → C1 and C3 narrow from the stated priorities to the actual line
- The recruiter's focus areas or any pre-declared deliverable → coverage of that deliverable and a reweighted bank
- Priya's own answers to the answer slots (the slots in A1, A2, A3, B2, E2 and fit rows F1, F2, F3, F4, F5, F6) stated outside a drill → those rows become quoted evidence and the slots upgrade
- An inspectable artifact behind the claims: the revenue model's documentation, the proposal memo behind the store-surface change, a Tableau workbook or an analysis write-up → medium becomes high on F2, F3 and F5
- Any other scheduled rounds → per-round mini-packs with their own persona weights
- A `tuesday-dossier.md` → verified evidence, per-gap strategy limits and an evidence-derived top objection in place of the one inferred here
