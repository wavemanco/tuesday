I'll read the reference files the skill points to before writing anything.
The pack is written and saved. My web searches were refused in this session, so I built it from your JD and background alone.

Your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round with Tobias, since you didn't say how he relates to the role. It has 20 questions across six personas, a fit snapshot, reverse questions and a list of claims it won't coach.

The searches were refused, so the company's values, interview loop, strategy and Tobias's background are all missing. The persona weights rest on the hiring-manager assumption. The Sources section lists each refused search, and the upgrade menu says what rerunning them would add.

The pack puts most prep time on one question: B1, "You've never worked on a game with in-app purchases. How would you handle that in this role?" The pack also treats "never led a team" as a likely probe (B3, F2).

Say the word and I'll play Tobias on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did the recruiter mention any focus areas or something to prepare in advance? The answer would reweight the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack — Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations (your message). **Round:** 60 minutes, Friday. **Relationship:** not stated; this pack assumes a hiring-manager round, and the persona weights below say what changes if that is wrong.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Every guidance cell is scaffolding for your own words, not a script, and each one rests only on sentences you wrote, quoted in its row. Where your material is silent, the cell is an answer slot: an instruction for the interview with an honest branch in both directions.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. No bank here: no values source was available and no values-style round is documented |
| EXP | Whether your experience survives scrutiny, and how precisely you attribute it |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework on the company and its games |
| CASE | A live problem from the role, scored on structure |

## Prep triage

You have until Friday. Do these in order; everything else is insurance.

| Order | Do | Where |
|---|---|---|
| 1 | Say B1 aloud until the first sentence stops costing you anything, then B3 and F1 | Bank B, Bank F |
| 2 | Rehearse C1 and C2 with the answer slots filled from your own memory of how the numbers were produced | Bank C |
| 3 | Play both Saltmarsh titles if you can, then prepare D2 | Bank D |
| 4 | Walk through A2, A3 and A4 out loud using the clarify, structure, metrics, risks shape | Bank A |
| 5 | Run B2 and B4 once each, then the D1 arc once | Banks B and D |

Everything else is insurance.

## Fit snapshot

Rows F1 to F8 are the JD's requirements. F9 and F10 are not in the JD: your message raised them, and an interviewer is likely to.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one title and weekly content drops, not events and not two titles, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's line makes a probe on events and on more than one title likely. If any of your drops were timed events, say how they were scheduled; if you ever planned across more than one title, say so; if neither, say so plainly and stay with the weekly calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team, and never worked on a game with in-app purchases" — your message | low | [inferred] | discovery | The first quote does not show who the calendar was coordinated with, and the second says any coordination was not as a team lead. Answer slot: the JD names all four disciplines, so expect a probe on which you worked with. If you worked with any of them on the drops, say which and what you needed from each; if none, or someone else did the coordinating, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you ran a post-event review or owned KPIs. The words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's line makes a probe on what sat behind those numbers likely. If you wrote or ran any review of a release or drop, say what it covered; if you presented numbers someone else produced, or reviews were not yours, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in the quote's own terms, but nothing is inspected behind it, so expect a probe on how the checklist is used. Lead with what the quote says: you wrote it, and your QA team still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [inferred] | discovery | Your material shows four years in the role and two years of weekly drops; it does not show whether the other two years, or the title, were live-service. This is a years requirement, not a gate, and the pack reads a stated years line as likely to be checked literally, which is a risk to name. Answer slot: if the earlier years were on a live-service title, say so; if they were not, or you are unsure, say so plainly and give the two years in the quote's words |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, and your strongest row, though a statement with nothing inspected behind it. Lead with the quote's own terms: weekly, content-drop, main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in role terms, but expect the probe to land on how the numbers were counted (C1). Lead with the quote: monthly, to the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a written document that others still use. Reword only that quote: "I wrote the release checklist our QA team still uses." Nothing is added about its contents or how it was received |
| F9 | Not in the JD — raised by your message | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I have never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F10 | Not in the JD — raised by your message | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | You stated this one too. Words: "I have never led a team." Then how you would get work moving without that authority, as a plan, never as a past |

## Persona table

The weights rest on one assumption and one gap. The assumption: Tobias is your hiring manager, which you did not say. The gap: no loop source for Saltmarsh was available (all searches were refused), so the loop falls back to the Generic archetype, screen then hiring manager then panel, and no round is documented. If Tobias is a skip-level, Case/Strategist and Pressure rise and Peer falls; if he is a peer, Peer and Prober rise.

| Persona | Weight and questions | How it shows up here | Why this weight | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | high, 5 (A1 to A5) | Live problems from the JD's plan, coordinate and review duties | Hiring-manager prior puts it first; the JD's duties are plan-and-run tasks that turn easily into cases | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Skeptic | high, 5 (B1 to B5) | Probing the stated gaps: in-app purchases, no team lead, one title, years | Hiring-manager prior puts it second, and F9, F10 and F1 give it direct material | Rehearse B1 until it is boring; say each limit first, then a plan |
| Data-Driven Prober | medium, 3 (C1 to C3) | Walking the retention numbers to their assumptions | The JD names retention metrics and KPIs, and F3 and F7 are where a probe lands; the prior alone does not put it high | Say how the numbers were counted if you know, say you do not know if you do not |
| Peer Evaluator | medium, 3 (E1 to E3) | Seam questions with design, art, engineering, community and QA | The JD names four teams plus QA; the delivery is collegial even when the interviewer is a manager | Seam principles, not pretended knowledge of this studio's seam |
| Conversational | low, 2 (D1, D2) | The biography opener and a casual question about the games | Arrives in almost any round, still scored | A 90-second arc built only from your own sentences |
| Pressure | low, 2 (F1, F2) | Time-boxed why-you challenges aimed at the stated gaps | The hiring-manager prior does not point here, but the stated gaps invite it | Pause, restate, hold the quoted position through two follow-ups, concede the limit specifically |
| Values/Behavioral | none, no bank | Not rehearsed | No values source was available, and under the Generic archetype no values-style round is detected | Upgrade menu: a pasted values page or the recruiter's loop description would add it |

## Question banks

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A2, B2 |
| "coordinate design, art, engineering and community teams on each update" | B3, E1, E2 |
| "own the post-event review and the KPIs it reports" | A3, A4, C1, C2, C3 |
| "manage the release checklist with QA" | A1, E3 |
| "3+ years producing live-service games or apps" | B4, D1, F2 |
| "experience running a content calendar" | A2, B2 |
| "comfortable with player-retention metrics" | A3, C1, C2, C3 |
| "clear written communication" | A4, E3 — scored through the artifacts it produces rather than asked on its own; reverse question 7 reaches it too |
| Not in the JD: in-app purchases and leading a team (F9, F10) | B1, B3, B5, F1, F2 |

### A. Case/Strategist (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your Saturday event depends on a feature engineering now says won't be ready until Monday. It's Wednesday. What do you do?" | CASE | [generic] | Think aloud in order. Clarify first: what exactly slips, what the event needs from it, whether a cut-down version stands alone. Then options: ship without it, move the date, swap the content. Then who decides and who is told, on the other teams and with players. Then what you record so the next calendar learns from it. Name the option you lean toward and the one fact that would change your mind. The question needs no claim about your past, so the guidance makes none | A live problem built from the JD's coordination and release-checklist lines (F2, F4); CASE because it scores structure, and `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "We run two titles. Sketch how you'd plan a quarter of live events across both. What do you need to know first?" | CASE | [grounded] | Clarify before structuring: each title's goal for the quarter, any fixed dates, what the teams can build, how the two audiences differ. Then objective, segmentation by title, approach (what is fixed and what has room to move), what each event reports afterward, and the risks, such as one team being needed by both titles at once. Challenge one premise politely, for example whether the two titles should share a rhythm. No claim about your past | The JD's headline duty (F1, F6); CASE with JD content, since it scores the stated requirement in live form |
| A3 | "Day-7 retention on one title is down 20% across the weeks after an event. Diagnose it." | CASE | [generic] | Clarify first: which cohorts, platforms and versions, whether the drop starts when the event starts or when it ends, what else shipped, whether the definition of the number changed. Then segment, for example new against returning players, rank two or three hypotheses, say what data you would pull for each, and say what you would not conclude yet. Say plainly which part you would hand to someone who owns the data. No claim about your past | The JD's retention line (F7) as a live problem; CASE rather than EXP because it asks about no past, and `[generic]` because it is the persona's stock shape |
| A4 | "An event missed its target. Walk me through the post-event review you would run, and what goes on the first page." | CASE | [grounded] | Structure it as a plan: what the event was meant to do, which numbers answer that, what the result was against what you expected, what players did, what you would change next time, who needs to read it. On the written side, say the first lines carry the answer and the detail sits behind them. Say "would", not "did". No claim about your past | The JD's post-event review and written-communication lines (F3, F8); CASE with JD content, because the review is the artifact the JD says the role owns |
| A5 | "You start Monday. What do you do in your first 30 days?" | CASE | [generic] | A plan, not a past. What you would read first: the calendar, past post-event reviews and the release checklist. Who you would meet. Which definitions you would confirm before touching a number. What you would leave unchanged for the first event you plan. Include asking which purchase-related measures the titles report, since that is where your material is thinnest. No claim about your past | Gives a calm place to put the limits in F9 and F3 as a plan; CASE because it scores structure, `[generic]` because the first month is a stock shape |

### B. Skeptic (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked on a game with in-app purchases. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head" | **Highest-ROI prep in this pack.** The limit, named before it is asked for: your material shows no purchase work, so no claim about spend, conversion or pricing is open to you. Level one: say it first, flat, "I have never worked on a game with in-app purchases." Level two, when they ask how you would cope: a plan in the future tense. Ask which purchase-related measures the two titles report and how each is defined, read the past post-event reviews, ask who owns those numbers and sit with them for the first events. Level three, when they press that this is the heart of the job: concede specifically that you cannot speak to how purchases behave around an event, then return to your own words and stop: "I presented the monthly retention numbers to the studio head." Let them draw the line from there. Level four, when they say so you're not ready: hold. You are claiming a plan, not readiness, and you do not add to the quote | F9 is the biggest stated gap and the likeliest question in any round, so a non-defensive answer here changes the interview. JD because the KPI line makes it a requirement probe; the delivery is the Skeptic's |
| B2 | "You ran the weekly content-drop calendar for your main title. Our job is a live-events calendar across two titles. Where does your experience stop and the job start?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Concede the scope it states: one title. Answer slot: if any of the drops were timed events, say how they were scheduled; if they were content releases only, say so plainly. Answer slot: if you planned across more than one title, say so; if not, say so and stay with the calendar. Hold through two follow-ups by returning to the calendar, never by adding to it | F1 is where the JD's two-title, live-events wording presses on the evidence; JD because it scores the stated duty, delivered as a Skeptic's quiet probe |
| B3 | "You've never led a team. The job is coordinating design, art, engineering and community on every update. How would you get four teams moving on a date?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Say the limit first: "I have never led a team." Answer slot: the JD names all four disciplines, so expect a probe on which you worked with on drops. If you worked with any, say which and what you needed from each; if none, or someone else did the coordinating, say so plainly. Then a plan in the future tense: one calendar everyone can see, a named decider for each trade-off, early warning when a date is at risk. Never describe getting people to follow you, since the quote says you have not led | F10 and F2 together are the second-likeliest objection; JD because the coordination line is the requirement, delivered as a Skeptic's probe on authority |
| B4 | "The JD asks for 3+ years producing live-service games or apps. Which of your years count?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Give the quotes in order: four years as an associate producer at a puzzle-game studio, and the last two running the weekly content-drop calendar for the main title. Answer slot: if the earlier years were on a live-service title, say so; if they were not, or you are unsure, say so plainly and stay with the two years in the quote's words. Do not round the number up | F5 is where the JD's number meets the evidence and is the row most likely to be read literally; JD because it scores a stated requirement |
| B5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Pick the one your material shows from F9 and F10, or from the limits noted in F1 and F3, and name it plainly. Then one concrete step for your first week, as a plan. Choose one; a list of five reads as dodging, and a strength dressed as a weakness is the answer interviewers mark down | The persona's stock probe, and F9 is the honest answer; JD because it scores fit against the whole listing |

### C. Data-Driven Prober (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Defend-the-number, in your own words. Answer slot: if you know how the numbers were counted, say it; if you do not, say so plainly and say who did. Answer slot: say what the figure is most sensitive to, and name the assumption behind it that you would defend least before they do; if you cannot name one, say so. Then the part that was yours: "I presented the monthly retention numbers to the studio head." The pack supplies no method, baseline or definition | F7 and F3 are where a prober starts; EXP because it tests whether the claim survives, with the weakest-assumption move because it is a metric |
| C2 | "That's the retention reporting. What part of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold-then-concede. Hold the quote at its scope through two follow-ups: "I presented the monthly retention numbers to the studio head." Answer slot: if you also pulled the numbers, explained why they moved or recommended anything from them, say which; if the numbers came from someone else and you presented them, say so plainly. Concede the limit the moment it is true; never fold on the quote itself | The attribution probe aimed at F3; EXP with Pressure delivery |
| C3 | "Tell me about a time a retention number moved and you changed what was planned." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: pick a time with a named number, a decision (say whether it was yours) and a change afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is presenting the monthly retention numbers to the studio head, or say how you would act | An open prompt on the JD's retention and KPI lines (F3, F7); the pack holds no story for it, so it is a scaffold with its honest branch |

### D. Conversational (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get from where you started to here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc built only on those four beats, in that order, each at its own scope: four years as an associate producer at a puzzle-game studio, the last two running the weekly content-drop calendar for the main title, the checklist QA still uses, the monthly retention numbers presented to the studio head. Answer slot: why this role and why now, in your own words; the pack has no reason of yours to quote, so give your actual one | The biography opener is almost certain in any round (F5, F6, F4, F7); EXP because it tests the CV's story |
| D2 | "Have you played either of our titles? What would you change about how they run events?" | CO | [generic] | Before Friday, play both if you can and note what you see: how the event rhythm feels, what changes between sessions. If you have not played them by Friday, say so plainly, then talk about a live-service game you do play, in your own words. Offer one observation rather than a redesign, framed as something you would ask Tobias about. Claim no knowledge of the titles' internals | Research could not run, so nothing here rests on a fact about Saltmarsh's games; CO because it scores homework, and `[generic]` for that reason |

### E. Peer Evaluator (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design wants an event bigger than engineering can build by the date. Where do you land?" | CASE | [generic] | Seam principles, not a pretended knowledge of this studio's seam. Who owns each side of the call, what each team needs to see, make the trade visible in writing, set the date by what is dependable rather than what is wanted. Concede you do not yet know how this studio splits the decision and would ask in week one. No claim about your past | The JD's four-team coordination line (F2) as a seam problem; CASE because it is a live disagreement |
| E2 | "Tell me about a time you disagreed with engineering or design about a date." | EXP | [generic] | Selection scaffold: pick a time with a named stake, what you proposed, how it ended and whether the relationship held. Use "we" for context and "I" for your piece. If no such time comes to mind, say so plainly, then describe how you would handle it | An open prompt on the JD's coordination line (F2), and the pack has no sentence of yours that carries this story, so it stays a scaffold; EXP because it tests a real instance |
| E3 | "Tell me about the release checklist you wrote. How does QA use it today, and what would you change?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Say it in the quote's words: "I wrote the release checklist our QA team still uses." Answer slot: if you have changed it since you wrote it, say what and why; if it has not changed, say so plainly. On what you would change, say what you actually see, or say you have not revisited it. Describe nothing about its contents or sign-off beyond what you know first-hand | F4 is the JD's checklist line in near-literal terms; JD because it scores the stated duty, with a Peer delivery because QA is a partner team |

### F. Pressure (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you, rather than someone who has run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team, and never worked on a game with in-app purchases" | Pause and restate the question. Hold on two quotes: the weekly content-drop calendar you ran for the main title for the last two years, and the release checklist your QA team still uses. Concede the limit at once and specifically: "I have never worked on a game with in-app purchases." Do not say you are better; say what your own words carry and stop. Hold through two follow-ups by returning to those quotes | The stated gap (F9) in a time-boxed delivery; JD because it scores fit, with Pressure's hold-then-concede |
| F2 | "You're an associate producer. This role owns the calendar and the KPIs. What makes you ready?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Never led a team, and never worked on a game with in-app purchases" | Hold on the quotes: four years as an associate producer at a puzzle-game studio, and the last two years running the weekly content-drop calendar for the main title. Concede: "I have never led a team." Answer slot: if any decision on the calendar was yours to make, say what it was; if the decisions sat with someone else, say so plainly and stay with running the calendar | F1, F3 and F10 meet in the JD's word "own"; JD because it scores the stated requirement, with Pressure's challenge to seniority |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which two titles would I be working on, and what does the event calendar look like for each over the next quarter?" | Shows you think in calendars, and gets the shape of the work the JD only names |
| 2 | "Which KPIs does a post-event review report today, and who defines them?" | The JD says the role owns the KPIs the review reports, so the definitions are the first thing to learn, and asking is honest about what you have not yet seen |
| 3 | "Do the titles' events touch in-app purchases, and if so, what would you want a new producer to learn about that first?" | Turns your stated gap into a ramp conversation you start rather than defend |
| 4 | "What would a good first 90 days look like, and how would you and I tell I was on track?" | Gets the manager's own success measure and echoes A5 |
| 5 | "How do design, art, engineering and community agree an update's date today, and where is it hardest to hold?" | Maps the coordination problem (F2) from the inside, and invites a real answer |
| 6 | "How does the release checklist work with QA today, and what part would you most like to improve?" | Ties to what you wrote (F4) and lets you listen before proposing |
| 7 | "Could I see what a good post-event review looks like here?" | Reaches the written-communication line and shows how you would calibrate |

## Prohibited claims

Claims this pack will not coach, with the basis for each and the honest form. Nothing in the banks asserts, softens or implies any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led or managed the design, art, engineering or community teams | Negative you stated (F10) | "Never led a team, and never worked on a game with in-app purchases", with the plain acknowledgment "I have never led a team" |
| Has worked on, run events for or reported on a game with in-app purchases | Negative you stated (F9) | The same quote, with the plain acknowledgment "I have never worked on a game with in-app purchases" |
| Planned and ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one title and weekly content drops, not events and not two titles |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you presented monthly retention numbers, not that you ran a review or owned a KPI |
| Managed QA's release process | Inflated form of F4 | F4's quote at its own scope. Your material says you wrote the checklist QA still uses |
| Has 3+ years producing live-service games | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer, and the last two running the weekly drops |

## Sources

Provided documents: the job description pasted in your message, and the background you described in the same message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, all refused by the host:

- "Saltmarsh Games values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games mobile studio strategy news" — refused
- "Tobias Wrenfield Saltmarsh Games" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet and VAL questions; absent, so there is no values bank |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have named the loop and set persona weights; absent, so the loop falls back to the Generic archetype and the weights rest on the hiring-manager assumption |
| 3. `Saltmarsh Games mobile studio strategy news` | unavailable | Would have grounded A2 and D2 and allowed a grounding brief; absent, so those are generic or JD-only |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have fed an interviewer read and a reverse question tied to his path; absent, so none is offered |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission granted, then a rerun of targets 1 to 4 → Saltmarsh's published values, any documented loop, recent strategy and Tobias's public footprint: a values cheat sheet if a values round is documented, an interviewer read, persona weights tied to his path, and a reverse question about it
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on the company, so A2 and D2 stop being generic
- Your answers to the slots in F1, F2, F3 and F5 → those rows get your own words, and B2, B3, B4, C1 and C2 become story-mapped rather than slots
- The recruiter's prep email, or Tobias's role relative to the job → coverage of any announced focus or deliverable, and persona weights that stop resting on an assumption
- The checklist itself, or a page from a retention deck you presented → F4, F3 and F7 can rise from medium to high on an inspectable artifact
- A pasted copy of Saltmarsh's published values or careers page → a values cheat sheet, section by section, from the source
- A `tuesday-dossier.md` → verified evidence and a named top objection in place of the inferred one
