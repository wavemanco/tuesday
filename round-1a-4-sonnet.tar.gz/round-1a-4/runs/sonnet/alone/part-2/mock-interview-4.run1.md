I'll read the reference files the skill requires before building the pack.
Your prep pack is saved. I built it for the hiring-manager round using the dossier, so I had nothing to ask you. The file is /var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-4-denied-5022590b/Quartzline_product-manager-platform-apis_interview_pack.md.

The pack has 18 questions across five interviewer styles. A1 is the highest-ROI prep. It's the objection the underwriter named: you haven't held the PM title or owned a roadmap, so why should they hire you?

The guidance in A1 follows the dossier's strategies. It concedes the title and roadmap gaps plainly, and holds on the integration, playbook and roadmap-input-session lines you confirmed. The three prohibited claims stay out. The pack coaches no claim to a PM title, roadmap ownership or squad prioritization.

Web search was refused, so I ran no research on Quartzline's values, interview process or strategy. The pack's weights come from the hiring-manager pattern, and the case questions are generic. The upgrade menu says what a pasted page or granted search access would add.

Several rows have answer slots, where the pack can't say whether you did something. Answer those in your own words, or say plainly you didn't.

Say the word and I'll play the skeptical hiring manager on A1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

Hiring-manager round, 45 minutes, Thursday. Interviewer name not given, so there is no interviewer read. Built on `tuesday-dossier.md` (job-underwriter v1.1, decision conditional_go); research was attempted and refused, so company values, loop and strategy are not in this pack (Sources).

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (none in this pack; no values were retrievable) |
| EXP | Whether your own claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack; the strategy search was refused) |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now: answer it from your own experience, or say plainly it was not yours or never existed. Labels: `[grounded]` traces to your dossier or the JD lines in it; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about you or Quartzline.

## Prep triage (Tuesday to Thursday)

1. Say A1 aloud until it is boring: the concession, the two quotes, the limit, three follow-ups. This is the highest-ROI prep in the pack.
2. Memorize the two employer questions (reverse questions R1 and R2) and the plan sentence in F2.
3. Answer the slots in F1, F3 and F5 to F9 in your own words, in a message to me if you like; a stated answer becomes quoted evidence and those rows regenerate.
4. Defend the 30+ out loud once (C1), then run B1 to B3 as thinking-aloud practice.

Everything else is insurance.

## Fit snapshot

Evidence cells quote the dossier's `verified_candidate_evidence` entries; the dossier row ID names the requirement the entry is read against, since the dossier does not key those entries to requirements. The dossier lists no hard gates, and the JD lines in it name none, so there are no gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier R1 | low | [grounded] | transferability | The underwriter's framing: adjacent, never PM experience. Words at the quote's scope: "I ran quarterly roadmap-input sessions, feeding client evidence to product." The dossier's prohibited_claims item "Having held a product manager title or role" sources the plain acknowledgment: "I haven't held a product manager title." The sessions entry is confirmed with limited inspectable proof, so volunteer its limit before a prober finds it. Answer slot: the JD's R1 and the sessions make a probe on what happened to the evidence likely. If any of it changed what product did, say what and how you know; if you could not see what product did with it, or nothing changed, say so plainly and stay with the sessions you ran |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records an acknowledge_gap area, "Owning a roadmap and prioritization authority (R1 sub-claim)", and the prohibited_claims item "Having owned a product roadmap". Words: "I haven't owned a product roadmap." Then a plan, never a past: the first thing to learn is which roadmap decisions are the PM's alone and which belong to the squad leads. No bridge here and no slot |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R2 and "Wrote the internal integration playbook her team uses" — dossier R2 | medium | [inferred] | transferability | The dossier grades both entries high against their own claims; against R2 the pack grades medium because the material says integrations of the vendor's APIs, not a shipped API or platform product. Words at their scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" and "I wrote the internal integration playbook my team uses." Answer slot: the JD's R2 makes a probe on what you shipped likely. If you shipped anything beyond one client's integration, say what and how it reached others; if not, or it was not yours, say so plainly and stay with the integrations and the playbook |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R3 | low | [inferred] | discovery | The quote touches REST APIs and architecture without showing docs or schemas. Answer slot: the JD names API docs and schemas, so expect a probe on them. If you read, wrote or reviewed either in those integrations, say which and what you did; if you did not, or that was another team's, say so plainly and stay with the integrations you led |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R4 and "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier R4 | medium | [inferred] | transferability | The quotes carry clients and product; they do not mention sales or engineering. Words at their scope: the integrations you led and the sessions you ran. Answer slot: the JD lists engineering and sales beside customers. If you worked with either on those integrations, say with whom and about what; if not, say so plainly and stay with the clients |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The evidence may exist and was not established; the underwriter's strategy is clarify. Answer slot: the JD asks for agile delivery experience, so expect "how does your work ship?" If the work you led ran in an agile way, say how in your own words; if you never worked that way, say so plainly, and add what you would want to confirm about how Quartzline defines it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier R1 and "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R1 | medium | [inferred] | transferability | The quotes carry sessions and scoping with clients, which is adjacent to discovery and does not say discovery. Words at their scope; keep your own word "clients", not the JD's "partners". Answer slot: the JD makes a probe on how you learn what a partner needs likely. If you asked clients what they needed before work began, say how you ran it; if not, say so plainly and stay with the sessions and the scoping |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier R2 | low | [inferred] | discovery | The quote lists requirements without showing a spec or a squad. Answer slot: the JD names specs and two squads. If you wrote requirements others built from, say what form they took and who built; if not, say so plainly and stay with the integrations you led |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | The material is silent. Answer slot: the JD makes a probe on what you counted likely. If you counted anything about how clients used an integration, say what and how; if you counted nothing, say so plainly, and say what you would count first |

## Persona table

Weights rest on the hiring-manager relationship prior and the dossier, not on a documented Quartzline loop: no loop source was retrievable, so the Generic archetype applies and is not tilted.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A Skeptic | Quiet probing of the title and roadmap gap | Highest. A hiring manager is derisking gaps, F1 is low and F2 is none, and the underwriter named this objection | Rehearse the concession and the held quotes until boring; ramp plan said as a plan (A1, A2) |
| B Case/Strategist | Live problems from the roadmap, adoption and squads | Highest. Hiring managers buy capability through live problems, and the JD's responsibilities are live problems | Clarify, objective, segmentation, approach, metrics, risks; think aloud; no claims about your past (B1 to B5) |
| C Prober | Reads the quoted lines closely; asks how the 30+ was counted | Medium. Q1 carries a headline figure and the sessions entry is medium confidence | Know what you can and cannot say about the count; say plainly when you do not know (C1 to C3) |
| D Conversational | Friendly walk-through opener | Medium. A 45-minute conversation will open casually and still be scored | A 90-second arc built only from your three quoted lines (D1 to D3) |
| E Pressure | Time-boxed challenge on authority | Low to medium. The objection can arrive time-boxed | Pause, restate, hold two follow-ups, concede specifically (E1, E2) |
| Peer, Values | No bank | Low. The squad leads are peers but not this interviewer, and no values-style round was detected | B3 and E2 cover the squad seam; no values bank because no values page or loop source was read |

## Question banks

### A Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" and "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The deepest rehearsal here; the underwriter named this objection, and each negative in it is sourced: prohibited_claims "Having held a product manager title or role" and "Having owned a product roadmap", and the acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)". Open with the concession: "I haven't held a product manager title, and I haven't owned a product roadmap." Hold on the quotes, nothing added: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" and "I ran quarterly roadmap-input sessions, feeding client evidence to product." Name a limit before it is asked, sourced by prohibited_claims "Having set prioritization for an engineering squad": "I haven't set prioritization for an engineering squad." Follow-up 1, what changed because of your sessions: answer slot, if any of it changed what product did, say what and how you know; if you could not see what product did with it, or nothing changed, say so plainly and stay with the sessions you ran. Follow-up 2, why not a PM with three years of the job: hold, add nothing, repeat the concession in the same words, and give the plan: learn which roadmap decisions are the PM's and which are the squad leads', and how adoption is measured today. Follow-up 3, "that is a big bet": stay on the same two quotes and the same concession, and let them draw the inference | F1 and F2 are the widest gaps and this objection arrives in some form. JD because it scores R1, the must-have; the underwriter named it, so it is theirs and not inferred |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] acknowledge_gap: "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it before they do: "I haven't owned a product roadmap" (sourced by the acknowledge_gap area above and prohibited_claims "Having owned a product roadmap"). Then the plan, as a plan: first learn which roadmap decisions are yours and which belong to the squad leads, and how adoption is measured today. Add nothing about the past to soften it | F2 is the one capability gap, and Skeptics ask for the weakness directly. JD because it scores the listed responsibilities |
| A3 | "When have you shipped an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" and "Wrote the internal integration playbook her team uses" | Story-mapped on F3 at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live", then "I wrote the internal integration playbook my team uses." Do not answer as if either were a shipped product. Answer slot: the JD's R2 makes a probe on what you shipped likely. If you shipped anything beyond one client's integration, say what and how it reached others; if not, or it was not yours, say so plainly and stay with the integrations and the playbook | R2 is a must-have and F3 is adjacent, so the probe lands here. JD because it scores a stated requirement; open prompt, so it presupposes no event |
| A4 | "Tell me about how you've worked in an agile delivery setting." | JD | [grounded] | The guidance makes no claim about your past. Answer slot: the JD asks for agile delivery experience. If the work you led ran in an agile way, say how in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how Quartzline defines it | F6 is a clarify area with no quote that speaks to it. JD because R5 is a stated requirement, preferred rather than must-have |
| A5 | "You ran roadmap-input sessions — what happened to what clients told you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Say it at its scope: "I ran quarterly roadmap-input sessions, feeding client evidence to product." The entry is confirmed with limited inspectable proof, so volunteer the limit: your material shows the sessions and the feeding, not an outcome. Answer slot: if you saw what product did with the evidence, say what and how you know; if you did not, or none of it was acted on, say so plainly and stay with the sessions | F1 and F7 rest on this one medium-confidence line, so a prober will find the seam here. EXP because it tests what was actually yours |

### B Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit the roadmap for the partner API platform. What do you do in your first thirty days?" | CASE | [generic] | Clarify first, aloud: who the partners are, what the roadmap holds now, which decisions are yours and which the squad leads', and how adoption is measured today. Then objective, a short plan, metrics, risks. Challenge one premise respectfully: you would confirm decision rights before proposing any roadmap change. No claims about your past | The JD's roadmap line and the dossier's unknowns on authority and adoption make this the natural opening case. CASE because it is a live problem; `[generic]` because it is a pattern, not a fact about Quartzline |
| B2 | "Adoption of a partner API has been flat for two quarters. Diagnose it." | CASE | [generic] | Ask what adoption means here before diagnosing. Split by partner type and by stage, list hypotheses, name the data that would separate them, say which you would test first. State the weakest assumption in your plan aloud. No claims about your past | The JD's metrics line (F9) and the dossier's missing baseline point here. CASE; `[generic]` for the same reason as B1 |
| B3 | "The two squad leads disagree about what ships next quarter, and each wants you on their side. What do you do?" | CASE | [generic] | Ask about decision rights first, and say you would confirm them rather than assume authority. Then bring the evidence you would gather, the options, the trade-off, and who decides if the room does not converge. Make no claim of authority over a squad | The dossier flags decision authority versus the squad leads as unevidenced. CASE because it is a live seam problem; covers F8's squads |
| B4 | "A partner tells you your API is painful to integrate. Run me through the conversation." | CASE | [generic] | Questions first: what they tried, what failed, what they needed. Separate the symptom from the request, say what you would capture and how you would close the loop. No claims about your past | JD's discovery line (F7). CASE because it asks for live structure |
| B5 | "A partner asks for a breaking change to an endpoint other partners use. How do you think it through, and what goes in the spec you hand the squad?" | CASE | [generic] | Impact on other partners, versioning and deprecation options, what you would ask engineering, the trade-off you would recommend. Then the spec's skeleton: problem, who is affected, the change, compatibility, rollout, success measure. Make no claim to have written one | Covers the JD's specs line (F8) and technical fluency (F4) as a live problem. CASE |

### C Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start with the sentence at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: say how the figure was counted, meaning what counted as one integration, and what a different count would change; if you do not know how it was counted, say so plainly. Name the assumption behind the figure you would defend least, before they do. Say which part was yours: the quote says led, so hold at led, and if others carried parts, say so | A headline figure is where probers start. EXP because it tests attribution and counting; F3 and F4 draw on the same line |
| C2 | "Walk me through the integration playbook you wrote." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beats the quote states, in your own words: you wrote it, it is internal, your team uses it. It is the one high-confidence, inspectable item, so be ready to point to a page. Answer slot: the JD's R3 makes a probe on API docs and schemas likely. If the playbook covers how clients read either, say how; if it does not, say so plainly and describe what it does cover | F3 and F4 both lean on it, and it is the evidence an interviewer can ask to see. EXP because it checks what you wrote |
| C3 | "Which API docs or schemas have you worked with directly?" | JD | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the quote carries: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: if you read, wrote or reviewed API docs or schemas in those integrations, say which and what you did; if you did not, or that was another team's, say so plainly and stay with the integrations | F4 is `low` and a discovery row; the JD's R3 raises it. JD because it scores a stated requirement |

### D Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" and "Wrote the internal integration playbook her team uses" and "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats, each one sentence you already have: you led the integrations, you wrote the playbook, you ran the sessions. Answer slot: the material does not carry why you want product work; say that reason in your own words, and if it is not yet clear to you, say so plainly | The casual opener is still scored. EXP because it is your own history; F1, F3 and F7 supply the beats |
| D2 | "Tell me about a time you had to align engineering, sales and customers." | EXP | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Selection scaffold: pick a time with a named stake where all three groups mattered, a moment you made a call, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the integrations you led, at its scope, or how you would handle it | The JD's R4 raises it; F5 carries clients and product only, so the story-mapped form is not available. EXP because it asks for a past instance |
| D3 | "What's pulling you toward product work?" | EXP | [generic] | The pack has no reason of yours to build on. Give your own reasons in one or two sentences: why product, why a platform of APIs, why now. If one clear reason does not come, say that plainly rather than reaching for a theme | A motivation probe is near-certain when the title changes. EXP; `[generic]` because it makes no claim about you |

### E Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That 30+ — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, then hold at the verb the quote carries: "I led them." Name which parts were others', specifically, if any were. Hold through two follow-ups; concede only what you actually do not know, such as how the count was kept | Attribution is the pressure persona's native probe. EXP; F3, F4 and F5 rest on the same line |
| E2 | "You would inherit a roadmap you didn't build. Convince me in sixty seconds you won't just defer to the squads." | JD | [grounded] prohibited_claims: "Having set prioritization for an engineering squad" | Concede specifically: "I haven't set prioritization for an engineering squad." Hold with a plan, not a past: ask which decisions are the PM's, bring evidence to the squad leads, and say when you would escalate. Do not claim authority you have not been given | F2 and the dossier's authority unknown make this the pressure form of the objection. JD because it scores the ownership responsibility |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years product management experience | A1, A2, E2 |
| Own the roadmap | A1, A2, B1, B3 |
| R2: Shipped API or platform products | A3, C2 |
| R3: Technical fluency | C2, C3, B5 |
| R4: Stakeholder management | D2, B3 |
| R5: Agile delivery | A4 |
| Run discovery with integration partners | A5, B4 |
| Write specs and drive delivery with two squads | B3, B5 |
| Define and track adoption metrics | B2 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts decision authority and nothing evidences it; the answer tells you what you would be accepting | [grounded] dossier questions_for_employer |
| R2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption metrics are a named responsibility with no stated baseline; you need it to judge the job | [grounded] dossier questions_for_employer |
| R3 | "What does the three-years-of-product-management line stand in for, and which parts matter most for this seat?" | It opens your one transferability gap on your terms and invites them to name what to show | [inferred] from F1 |
| R4 | "How does partner feedback reach the roadmap today, and who collects it?" | It tests how much of the job is discovery, without any claim about your sessions | [inferred] from F7 |
| R5 | "How are the two squads organized, and how does work come to each?" | The JD names two squads and says nothing about their split | [inferred] from F8 |
| R6 | "What would you want the new PM to have learned by the end of the first quarter?" | It turns the ramp plan in A1 into their stated expectation | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | dossier prohibited_claims | F1's quote at its own scope; plain acknowledgment sourced by prohibited_claims: "I haven't held a product manager title." |
| Having owned a product roadmap | dossier prohibited_claims and the acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" | "I haven't owned a product roadmap." No bridge and no slot |
| Having set prioritization for an engineering squad | dossier prohibited_claims | "I haven't set prioritization for an engineering squad." No bridge and no slot |
| Shipped an API or platform product | Inflated form of F3 | F3's quotes at their own scope; the limit is the pack's observation, the material says integrations and a playbook, not a shipped product. A3's slot stays inside the integrations |

## Sources

Provided: `tuesday-dossier.md`, job-underwriter envelope v1.1, generated 2026-08-14. Consumed: role_profile, decision (context only), and handoff_to_mock_interview (high_priority_requirements, verified_candidate_evidence, uncertain_or_weak_areas, likely_interviewer_objections, opportunity_risks_to_validate, questions_for_employer, prohibited_claims). Not in the file, so not used: evidence_map, evidence_state, risk_register.

Searches sent, each refused (the host did not grant search permission):

- "Quartzline company values" — refused
- "Quartzline interview process product manager" — refused
- "Quartzline strategy API platform news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Would have supplied published value names for VAL questions and a cheat sheet if a values round were documented; none built |
| 2. Quartzline interview process, product manager | unavailable | Would have fixed loop structure and persona weights; the Generic archetype and the hiring-manager prior apply instead |
| 3. Quartzline strategy and recent news | unavailable | Would have grounded CO and CASE questions in current strategy; the CASE bank is `[generic]` and there is no CO question |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; no interviewer read |
| 5. Representative JD for the title | skipped | The dossier's role_profile supplies the requirements and fixes the fit snapshot |

## Upgrade menu

- Search access, or a pasted Quartzline values page and strategy summary → values cheat sheet if a values round is documented, and CO and CASE questions grounded in current strategy
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, once search access is granted → strategy brief, interviewer footprint and loop reports
- The interviewer's name → an interviewer read, reweighted personas and a reverse question tied to their path
- The recruiter's prep email → any stated focus areas or pre-declared case or deliverable, which would get its own build section
- Your answers to the slots in F1, F3, F4, F5, F6, F7, F8 and F9, stated in a message → each answer becomes quoted evidence and those rows and their banks regenerate
- Notes or a readout from one roadmap-input session → could lift F1's and A5's sessions evidence from limited to inspectable proof
- Your raw CV → rows now quoted from the dossier would quote your own lines
- The current posting text, since the dossier is dated 2026-08-14 → requirement rows regenerate if the posting has changed
