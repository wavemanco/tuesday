# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Treated as the hiring manager running the Outage Hour (Saltmarsh's single 60-minute interview, per its interviewing page). That relationship is an assumption: your note gives his title, not your reporting line.
**Interview:** Friday. 60 minutes.

## How to use this pack

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding to rehearse from, not a script to recite. Where a cell says "Answer slot", it is an instruction for the interview itself: answer from your own experience in your own words, and either branch is a good answer.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Saltmarsh's published values |
| EXP | Whether what you say you did survives follow-ups |
| JD | The listed responsibilities and requirements, gaps included |
| CO | What you know about the company and where it is heading |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar, not live events and not two titles, and the words stay at that scope: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-title line makes a probe on the step to a second title likely. If any of your calendar work covered more than the main title, say what, in your own words; if it did not, say so plainly and stay with the main title's calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team" — your message | low | [inferred] | discovery | Your material shows a calendar you ran and a team you have not led, and does not show whether other disciplines were coordinated on the drops. Answer slot: the JD's coordination line makes a probe likely. If you got people from design, art, engineering or community to hit a drop date, say which and how, in your own words; if none, or it was not yours to do, say so plainly and stay with the calendar. If the probe turns to leading people, your own words are: "I've never led a team." |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presenting the monthly retention numbers, not what followed an event or who chose what was reported, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event line makes a probe on what went into those numbers likely. If you chose or explained any of them, say which and how, in your own words; if you presented numbers someone else chose, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | Reword only the quote: "I wrote the release checklist our QA team still uses." It adds nothing about running releases against the checklist, and the answer stays at what was written and that QA still uses it. Nothing inspected sits behind the line, so expect a probe on it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | presentation | Reword only those quotes: "I've spent four years as an associate producer at a puzzle-game studio, and for the last two I ran the weekly content-drop calendar for our main title." Your material says associate producer and does not say live-service, so a probe on the title or the service model is likely and the answer stays at the quotes |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you ran it, weekly, for the main title, for two years, because a named record beats an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap, but nothing inspected sits behind it. Lead with the quote's own terms: monthly, retention, to the studio head. The probe that follows is how those numbers were counted, which D1 rehearses |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | presentation | Reword only the quote: "I wrote the release checklist our QA team still uses." A written document that is still in use is the only written evidence your material carries, and the answer stays at that |
| F9 | Season-pass model for both titles from February 2027, per the Saltmarsh news summary; not in the JD (source: search result, Sources) | "never worked on a game with in-app purchases" — your message | none | [inferred] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Reading the interviewer

Public professional footprint only. The GDC page was seen as a search snippet; the page itself was not opened (Sources).

| Fact | Source | Provenance | Practical implication |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games | Your message; the GDC 2026 talk page | [grounded] | He owns the calendar and the outcome you would report into |
| Previously a QA lead at a console studio | GDC 2026 talk page snippet | [grounded] | Release and QA vocabulary is his native language; A2 and B3 are where yours meets it |
| GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | GDC 2026 talk page snippet | [grounded] | Precision about what is built versus hoped is likely to be listened for; A5 and B2 rehearse it. This is a reading of his published theme, not a prediction of his questions |

**Mirror opportunity (shared vocabulary):** his QA background and the release checklist. The one sentence of yours that meets it is F4's: "Wrote the release checklist our QA team still uses". Say it at that scope; do not stretch it into running releases.

## Persona table

Weights come from three passes. The hiring-manager prior favours Case and Skeptic. The loop source adjusts it: the interviewing page describes one 60-minute hiring-manager interview that is "a live-incident tabletop on a simulated outage during a live event, then a values conversation", so Values rises to the top tier beside Case. His published theme lifts the Prober a little.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop: an outage mid-event, decisions under uncertainty | High. The interviewing page names the tabletop as the first half of the hour | Clarify, objective, options, risks, comms, review. Think aloud and challenge one premise politely |
| Values / Behavioral | The second half: scenario probes against Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener | High. The page names a values conversation, so a values-style round is detected | Pick a story per value from your own material, or say plainly when none comes to mind. Prepare B1 to B4 |
| Skeptic | Quiet probing of the gaps: the in-app-purchase absence, no team led, one title, associate title | Medium. Hiring managers de-risk gaps, and F2, F5 and F9 are where your material is thinnest. C1 is the highest-ROI prep in this pack | Say the limit first, in your own words, then the plan. Never bluff a competency he personally owns |
| Data-Driven Prober | Line-by-line questions on the retention numbers | Medium. The JD asks for comfort with retention metrics and F3 and F7 rest on one line | Know what you can and cannot say about how each number was counted; say plainly when you do not know |
| Pressure | Time-boxed challenges inside the tabletop, or a "how much was you" cut | Low to medium. The page does not describe the tabletop as stressful; a time-boxed incident can feel that way | Pause, restate, hold the position through two follow-ups, concede specifically |
| Conversational | Opener, "walk me through the journey", reaction to company news | Low, but an opener is always asked and still scored | A 90-second arc built from your own sentences; treat the casual questions as scored |

## Question banks

### A. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a weekend event. Thirty minutes ago reward claims started failing for some players, and community says the reports are climbing. You're the producer on call. What do you need to know first, and what do you do in the next hour?" | CASE | [grounded] | Clarify first, thinking aloud: how many players, since when, what changed, what is confirmed versus only reported. Objective: players first, then the event, which is the published value Players Before Plans. Then the hour: who you pull in (engineering to diagnose, QA on any fix, community on what players are told), the decision between pausing, patching and waiting, and a check-in rhythm. Say publicly only what is confirmed built, which is Ship the Patch Not the Promise. Close with what goes into the review. The guidance makes no claim about your past | The loop page describes a live-incident tabletop on a simulated outage during a live event, and this is its likeliest shape. CASE because it scores structure; F2 is the coordination the role asks for |
| A2 | "Engineering can ship a fix in two hours. QA says it needs four to test it properly. Community wants to tell players it's fixed now. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Separate what is known from what is wanted. Ask what QA's four hours cover and whether a reduced pass with a named risk exists. Weigh the player harm of the bug against the risk of a bad fix, name who owns the call, and say it aloud. Announce only after the fix is built and verified. If you mention your past, it is the quote at its own scope: "I wrote the release checklist our QA team still uses." Add nothing about how it was used in an incident | This puts the producer between engineering, QA and community, which is where the JD's release-checklist line sits (F4). CASE because the answer is a decision, not a record |
| A3 | "From February, Tidepool Tactics and Lantern Row share one events calendar. Before you built the first quarter of it, what would you want to know?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify what is shared and what stays per title, where seasons begin and end, and who settles a collision for the same slot. Then objective, constraints, how you would sequence the first quarter, risks and the measure you would watch. Your own past is the quote at its scope: "For the last two years I ran the weekly content-drop calendar for our main title." The pack's observation is that your material shows one title. Answer slot: if any of your calendar work had to decide between competing demands for the same slot, say how it was decided and by whom, in your own words; if that never arose, say so plainly and answer from the structure | The news summary of Project Larkspur (Sources) describes a shared events calendar from February 2027, so this is the strategy-grounded case. F1 is where the two-title step is thinnest. The summary is a search snippet, so ask in the room rather than assert |
| A4 | "After an event ends, the post-event review lands with you. What goes in it?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Structure it: what was planned versus what shipped, the player measures you would choose and why, what went wrong and what was fixed, what changes in the checklist or calendar next time (Leave the Build Greener), and who receives it. Your own past is the quote at its scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose or explained any of those numbers, say which and how, in your own words; if you presented numbers someone else chose, say so plainly and stay with the monthly presentation | The JD's post-event line is a stated responsibility, and F3 is its thinnest evidence. JD because it scores the listed duty; the delivery is a case |
| A5 | "Write the player-facing patch note for the fix you just shipped. Three lines, out loud." | JD | [grounded] | Say what changed for players, what is still open, and promise nothing. Plain verbs, no adjectives. Only what is built goes in. The guidance makes no claim about your past | The JD asks for clear written communication (F8) and Saltmarsh's value is Ship the Patch Not the Promise; his GDC theme is the same idea. JD because it scores a listed requirement, delivered as a mini-task |

### B. Values / Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar said ship and the players said otherwise." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Your sentence carries the calendar, not a clash with players, so this is a selection scaffold. Pick one drop where what players were showing you and the date disagreed. It needs a named drop, what you saw, what happened to the date, and what was yours to decide versus someone else's. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Players Before Plans is the published value. F6 is the calendar evidence. VAL because it scores behaviour against a named value |
| B2 | "Tell me about a time you held back an announcement because the thing wasn't built yet." | VAL | [grounded] | A selection scaffold, because none of your sentences carries this story. Pick a moment with pressure to say something early, a named announcement, what you said instead, and what stayed intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Ship the Patch Not the Promise is the published value, and his talk title is "Patch Notes Are a Promise". VAL because it tests behaviour, not slogan familiarity |
| B3 | "Tell me about a time you left a release process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: the checklist, and that QA still uses it, are the beats the quote states; tell them in your own words. Answer slot: the published value names the checklist, so expect a probe on what changed in it over time. If it changed after releases, say what changed and who changed it; if it was written once and left, or the changes were not yours, say so plainly and stay with "I wrote the release checklist our QA team still uses." | Leave the Build Greener names the checklist directly, and this is the one value where one of your sentences already sits. VAL; F4 is the evidence |
| B4 | "Tell me about a time you told someone senior something they didn't want to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | A selection scaffold. Pick a time with a named stake, what you said, how it landed and what the relationship looked like afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is presenting retention numbers to the studio head, or how you would handle it | The persona stem is the standard hard-truth probe, and a Head of Live Ops will weigh how the news travels up. F7 is the nearest evidence, and it does not show an unwelcome message |

### C. Skeptic (weight: medium)

C1 is the highest-ROI prep in this pack: it will arrive in some form, and the answer is the same boring, non-defensive sentence every time.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases" | Say the limit first, before he asks for it. Your own words: "I've never worked on a game with in-app purchases." Then the plan, said as a plan and not a past: what you would read, watch and ask in your first weeks, in your own words. Follow-up one, "how would you close that?": the plan again, with who you would ask. Follow-up two, "does that worry you for a first event cycle?": concede specifically that it is the part where you would lean on others, and hold on what you did say you did: "For the last two years I ran the weekly content-drop calendar for our main title." Never describe in-app-purchase work you have not done | F9 is the stated gap and the most probable objection for a live-ops role at a studio announcing a season-pass model. JD because it scores honest self-assessment against the listed job; the deepest rehearsal is the point |
| C2 | "This role coordinates design, art, engineering and community teams on each update, and you haven't led a team. How would you get them moving together?" | JD | [grounded] "Never led a team" | Acknowledge it plainly: "I've never led a team." Then answer how you would coordinate without authority, as a method: one date, one owner per discipline, what each needs from the others, and how you would surface a slip early. Answer slot: if you got people from other disciplines to hit a drop date in the calendar you ran, say how, in your own words; if you did not, or it was not yours to do, say so plainly and stay with the calendar | F2 is a discovery row where the stated negative meets a JD line. JD because the coordination duty is listed |
| C3 | "Your title was associate producer, and this is a producer role across two titles. What's different?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" | Own the title in its own words: "I've spent four years as an associate producer at a puzzle-game studio." Hold there; do not claim an equivalence. Answer slot: if the scope of your work changed over the four years, say what changed, in your own words; if it did not, say so plainly and stay with the calendar you ran. Then say what you expect to be different at two titles as a view, not a history | F5 carries the title and the years and does not show the live-service model. EXP because it tests whether the title survives a follow-up |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the retention numbers you presented each month." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The quote carries that they were monthly, retention, and presented to the studio head. Four slots, each in your own words: which measures they were, how each was counted, what the number was most sensitive to, and the assumption you would defend least. Name that weakest assumption before he does. If you do not know how a figure was counted, say so plainly. Answer slot: if you also pulled or analysed them, say so; if they came from someone else and you presented them, say so plainly | F7 is the whole retention evidence and nothing inspected sits behind it, so a prober goes straight here. EXP because it tests attribution and counting |
| D2 | "When did a retention number change something you did?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | A selection scaffold. Pick one moment with a named number, what you decided, who else decided, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the monthly presentation, or how you would use a retention number to change a plan | The JD asks for comfort with retention metrics (F7). JD because it scores the requirement through a behaviour |
| D3 | "After an event, which single player metric do you trust least, and why?" | JD | [generic] | Name one metric you would actually distrust, say what it hides, and say what you would read beside it. This is the weakest-assumption move turned into a position. The guidance makes no claim about your past | A pattern question that rehearses naming a metric's limit aloud. JD for the retention-metrics line; `[generic]` because it carries no fact about Saltmarsh |

### E. Pressure (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a producer who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "never worked on a game with in-app purchases" | Pause, restate the question, then hold: "For the last two years I ran the weekly content-drop calendar for our main title, and I wrote the release checklist our QA team still uses." Concede the limit in one sentence: "I've never worked on a game with in-app purchases." Do not claim to be stronger than that producer. Hold through two follow-ups; concede only what is true | A time-boxed comparison with a rival who has the thing F9 lacks. JD because it scores fit against the listed job; the structure is hold then concede |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold on the quote: "I wrote the release checklist our QA team still uses." Answer slot: if anyone else shaped it, say who and in what way, in your own words; if you wrote it yourself, or it is no longer as you wrote it, say so plainly and return to the quote | An attribution probe on the line he is most likely to care about given a QA background (F4). EXP because it tests what was actually yours |

### F. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you get into live ops producing?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc made of your own sentences, in order: the four years as an associate producer at a puzzle-game studio, the calendar, the checklist, the retention numbers. Add only your own reason for wanting live operations here, in your own words, and borrow from the three published values only where it is true for you | Every interview opens here, and it is scored. F5 to F7 supply the arc. EXP because it tests whether the story hangs together |
| F2 | "So what do you make of what we announced in September, Project Larkspur?" | CO | [grounded] | Say what the announcement says first, from the news page: a season-pass model for Tidepool Tactics and Lantern Row, one shared events calendar from February 2027, and per-title event teams replaced by a single live-ops group. Then your own view, with one concession and one question for him. Do not claim inside knowledge or experience with the model; F9 is the stated gap. Read the page itself before Friday, since this pack only saw its summary | The strategy-grounded company question at the news page's own date. CO because it tests homework |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A3, B1, C3 |
| Coordinate design, art, engineering and community teams on each update | A1, A2, C2 |
| Own the post-event review and the KPIs it reports | A4, D1, D3 |
| Manage the release checklist with QA | A2, B3, E2 |
| 3+ years producing live-service games or apps | C3, F1 |
| Experience running a content calendar | A3, B1, F1 |
| Comfortable with player-retention metrics | D1, D2, D3 |
| Clear written communication | A5 |

## Values cheat sheet

A values-style round is detected: the interviewing page names a values conversation. Value names are Saltmarsh's published ones (values page).

| Value | Working meaning, paraphrased | Mapped story |
|---|---|---|
| Players Before Plans | When the schedule and what players are showing you disagree, favour the players | F6: "I ran the weekly content-drop calendar for our main title for the last two years" carries the calendar, not a clash. Selection scaffold in B1 |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | None of your sentences carries it. Selection scaffold in B2, with its honest branch |
| Leave the Build Greener | Each release leaves the codebase and the checklist better than it was | F4: "Wrote the release checklist our QA team still uses". Story-mapped in B3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came to live operations from QA. What do you still reach for from that side when an event goes wrong?" | Tied to his own path; it turns a probe into a peer conversation and meets F4's vocabulary |
| R2 | "Your talk argues a live team is judged by whether its patch notes describe what actually shipped. How do you see that on your own team?" | Shows you read his published theme, and invites the example behind it |
| R3 | "Project Larkspur retires per-title event teams for a single live-ops group. How does this role sit inside that group?" | The JD says two titles and the announcement says one group; the answer tells you what you would actually be joining |
| R4 | "Where does the producer's authority end when design, art and engineering disagree about a date?" | Shows you have thought about coordination without authority (F2), and tells you what the job really holds |
| R5 | "What would you want the new producer to have done by the end of their first event cycle?" | Turns the first months into something concrete you can be measured against |
| R6 | "What does the Outage Hour tell you about a producer that a CV cannot?" | Shows you understand why the loop is built this way, and invites feedback on what he watches |

## Prohibited claims

Built before the banks. These are not coached, and no answer slot, hold or rationale asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated: "Never led a team" | The plain acknowledgment: "I've never led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated: "never worked on a game with in-app purchases" | The plain acknowledgment: "I've never worked on a game with in-app purchases." No slot |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says presenting the numbers, not what followed an event. A4 and D1 keep their slots inside the numbers you presented |
| Planned and ran live events for two titles | Inflated form of F1 | F1's quote at its own scope: one title's weekly content-drop calendar. A3's slot stays inside the calendar you ran |
| Managed the release checklist across releases | Inflated form of F4 | F4's quote at its own scope: you wrote it and QA still uses it. B3's slot stays inside what changed in it |
| Four years as a producer | Inflated form of F5 | F5's quote at its own scope: associate producer, at a puzzle-game studio |

## Sources

Provided: the JD text and your background, both in your message. No dossier was supplied.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

Searches and fetches sent:

- Search "Saltmarsh Games values": returned saltmarshgames.com/values
- Search "Saltmarsh Games interview process live operations producer": returned saltmarshgames.com/careers/interviewing
- Search "Saltmarsh Games strategy news": returned saltmarshgames.com/news/project-larkspur (September 2026). Snippet only; the page was not opened
- Search "Tobias Wrenfield Saltmarsh Games": returned talks.gdconf.example/2026/patch-notes-are-a-promise. Snippet only; the page was not opened, and its ".example" domain is one I could not verify, so treat the interviewer facts as unconfirmed beyond that snippet
- Fetch saltmarshgames.com/values: read in full
- Fetch saltmarshgames.com/careers/interviewing: read in full. It establishes the loop: a recruiter call, then one 60-minute interview with the hiring manager (tabletop, then values conversation), and no take-home

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and B1 to B3: the three values by official name |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Persona weights, the Case and Values tilt, and the detected values-style round; no graded deliverable, so no build section |
| 3. `Saltmarsh Games strategy` / recent news | yes | A3, F2 and R3; the news page was seen only as a snippet |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, A5, B2, R1 and R2; snippet only, domain unverified |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → opens the Project Larkspur page and his talk in full, and adds a grounding brief on strategy and recent org context. Offered once; say the word to run it
- Your own answers to the answer slots in F1, F2 and F3 → those rows become quoted evidence and the guidance that leans on them gets sharper
- A redacted copy of the release checklist → the artifact that could lift F4 from medium to high
- One monthly retention report you presented, redacted → the artifact that could lift F7 from medium to high
- The recruiter's notes on the Outage Hour (what the tabletop covers, whether any written exercise appears) → replaces the assumed coverage of the Case bank
- Hours available before Friday → a prep schedule sized to them
- Confirmation that Tobias is the hiring manager → reweights the personas if he is not
- A tuesday-dossier.md → verified evidence and a sourced objection for the Skeptic bank, in place of the inferred ones here
