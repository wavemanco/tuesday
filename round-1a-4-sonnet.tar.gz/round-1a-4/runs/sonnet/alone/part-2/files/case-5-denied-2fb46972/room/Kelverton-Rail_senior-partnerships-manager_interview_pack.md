# Interview pack: Senior Partnerships Manager, Kelverton Rail

Round 2, Tuesday. Panel of two, 60 minutes: Deepa (VP Partnerships, your future manager, per the recruiter) and Ross (Commercial Director). The first 15 minutes are your POV with no slides; the rest is Q&A. Built from your message and the recruiter's email as you quoted it. No JD, no market report text and no web research were available to this pack, and every section says where that shows.

## How to use this pack

- Personas describe how a question arrives (who is asking, in what register). Types describe what is being scored.
- Type key: **VAL** is behavior against published values. **EXP** is a deep-dive on your own work and what was actually you. **JD** is the stated role and its gaps. **CO** is company and strategy knowledge. **CASE** is a live problem or judgment call.
- Provenance key: `[grounded]` rests on something you or the recruiter wrote, quoted beside it. `[inferred]` is derived from an adjacent source. `[generic]` is a role-family pattern with no claim about Kelverton or about you.
- An answer slot is an instruction for the interview, not a question for you now: say what is true in your own words, and if the practice was not yours, or never existed, say so plainly and return to what your own words carry.
- Guidance is scaffolding, not a script. Rehearse only what you actually did.

## Prep triage (about four hours)

1. About 90 minutes: build and speak the POV (section 5). Pick one thesis, write the operator close, and run it aloud twice against a 15-minute timer. This is the one graded deliverable, and it opens the panel.
2. About 45 minutes: B1 (the highest-ROI rehearsal in this pack) and D1, aloud, holding through two follow-ups each.
3. About 30 minutes: C1 and C2. Write down what you know, and do not know, about how the roughly £4M was counted. "I don't know how that was counted" is an honest answer.
4. About 30 minutes: E1 (your 90-second arc), then pick three of the reverse questions.
5. About 15 minutes: reread the market report once, only to choose one consensus item and one point you would depart from (section 5).

Everything else is insurance.

## Fit snapshot

No JD was supplied, so the requirements are the recruiter's own words, quoted, plus one role-family expectation written as plain prose.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your words at their own scope: you spent the last four years running the ISV channel at a payments company and took it from 6 partners to 40. The pack's observation is that your material says an ISV channel, not operator partnerships. Answer slot: the recruiter's words make a probe on what carries over likely. If any part of how you grew that channel shapes how you would approach operator partnerships, say which part and why, in your own words; if none carries over, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your words at their own scope: five years in transport consulting, in bus and light rail network planning. The pack's observation is that your material names bus and light rail, not train operating companies. Answer slot: expect a probe on train operators specifically. If any of that work touched them, say what it was and which part was yours; if none did, say so plainly and stay with bus and light rail |
| F3 | "Ross will push on commercials" — recruiter's email | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message; "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your words: "I've never carried a direct quota, only influenced revenue." The figure is the roughly £4M of influenced revenue, kept at that scope. Answer slot: a figure on your side of the table raises four probes, how it was counted, what it is most sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; if you do not know how it was counted, say so plainly |
| F4 | Selling into rail operators — role-family expectation written as plain prose, no JD supplied | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Never a claim to rail selling, and nothing added to make the gap feel smaller |

## 5. Graded deliverable: the 15-minute POV

The recruiter's words, quoted: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it" and "Please land on what it means for the operators themselves." Both are in your message.

**Grounded facts to build on.** From F1: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." From F2: "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." The gaps stay in view too: F3 and F4 hold your own stated limits, and the POV should not walk around them.

**Thesis options.** Pick one. Each carries a concession you say aloud, not one you wait to be asked for. These are rehearsal shapes, not claims about Kelverton: you have the market report and the pack does not.

| # | Thesis | What it commits you to | Mandatory concession | Provenance |
|---|---|---|---|---|
| T1 | Start from the operator's problem, not Kelverton's product: choose a small number of operator relationships and shape the 18 months around what each operator can do differently by the end | A short list of relationships you would deepen, and the operator-side outcome for each, in your own words | It slows the visible breadth of the program, and it depends on how well you can learn the operators' problems, which F4 says you have not yet done from the selling side | [generic] |
| T2 | Depth before breadth: in the first 18 months, fewer and stronger operator partnerships beat a long list. It departs from the shape of F1's quote, which counts partners ("took it from 6 partners to 40"), so say that out loud as a choice and give your reason | A depth-first sequence, with what would have to be true for you to switch to breadth | The one quoted result you can point to is about breadth, so you are arguing against your own record and should say what you would watch for to know you were wrong | [generic] |
| T3 | Build the partner ecosystem around the operators rather than only with them, so that other parties extend what the scheduling software does for an operator | Which kinds of third parties you would pursue first, only as far as you can justify | It depends on whether Kelverton's product has any surface for others to build on. That is exactly what A2 has you ask before committing, and your material does not say | [generic] |

**Differentiate from the report.** The market report was circulated inside Kelverton, and Deepa and Ross can recite it. Reciting it scores as homework. Bring one item from its shortlist to show you read it, then one thing you would do differently and why. Choose both yourself: the pack has not seen the report and will not name them.

**The anti-pick.** Say one thing you would deliberately not do in the 18 months, and why. A partnerships role includes saying no, and a POV with no no is a wish list.

**The close the recruiter asked for.** End each thesis with what changes for an operator by month 18: what they do differently, or no longer have to do. Say it in the operator's terms, in your own words. Do not end on Kelverton's revenue.

**Run of show for 15 minutes.** About one minute: state your thesis in a sentence and say you will end on the operators. Seven to eight minutes: the thesis, your consensus item, your departure from it, and the anti-pick. Three to four minutes: what it means for the operators. About one minute: your concession, and what you would want to learn in the first 90 days. Then stop and invite questions.

## Persona table

The loop is one 60-minute panel, established by the recruiter's words as you gave them. Weights blend the top two personas of each panelist's relationship.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Follow-ups on the POV: what you would need to know first, what you would refuse, how success is measured | High. The recruiter announced the POV, and Deepa is your future manager, a hiring-manager relationship that carries live problems from the roadmap | Clarify, then objective, then approach, then metrics, then risks; think aloud; challenge one premise respectfully |
| Skeptic | The rail gap and the quota gap, asked quietly and more than once | High. F3 and F4 are limits you have stated yourself, so the objection is certain to arrive in some form, probably from Deepa | Rehearse B1 until it is boring: the plain acknowledgment, the hold on what your own words carry, a ramp stated as a plan |
| Data-Driven Prober | The £4M figure, line by line: how counted, what is yours | Medium-high. "Ross will push on commercials" is the recruiter's line, and F3 holds the only figure in your material | Know what you can and cannot say about how it was counted, and say plainly when you do not know |
| Pressure | Time-boxed challenges, such as sixty seconds on why you over a candidate who has sold into rail | Medium. Ross is a Commercial Director pushing on commercials, which tends to arrive in a pressure register | Pause, restate, hold a challenged position through two follow-ups before conceding anything real |
| Conversational | The opening biography question, and the "any questions for us" slot | Medium. A panel usually opens and closes in a friendlier register, and both slots are still scored | A 90-second arc built from your own quoted sentences, and reverse questions that are not generic |
| Values/Behavioral | Not banked | Low. No source in hand names a values-style round, and no company values page was available | None needed. Reconsider if the recruiter mentions one |
| Peer Evaluator | One seam question, D3, not a bank | Low. Neither panelist is a peer, but a Commercial Director may ask where partnerships ends and direct selling begins | Propose seam principles, not a pretended knowledge of the seam |

Question depth follows weight: A has five, B four, C, D and E three each.

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months, and what that means for the operators themselves." | CASE | [grounded] | This is the graded deliverable, so build it from section 5, not here. Say your thesis in the first minute in one sentence, then the evidence, the concession, and the close on the operators. It makes no claim about your past beyond what section 5 quotes | The recruiter announced it, so F1 and F2 both ride on it. CASE because it scores structure and judgment live, with JD content because it is the stated task |
| A2 | "What would you want to know about our current operator partnerships before you commit to a direction?" | CASE | [generic] | Ask before you structure: what the partnerships are today, who the operators are on the other side of them, what each side gets, what is working and what is not, and what is not for you to change. Say them as questions you would ask, not as findings. The pack has no information about Kelverton's current partnerships and supplies none | Clarifying first is what a strategist round scores. `[generic]` because it is a pattern for the problem and not a fact about this employer |
| A3 | "What would you say no to over the next 18 months?" | CASE | [generic] | Name one specific thing you would decline and give the reason in the operator's terms and in Kelverton's. Name it only if you could defend it to Ross as a commercial choice. Do not offer a no that is easy to give | The role includes saying no, and the anti-pick in section 5 is the same move. It separates judgment from a wish list |
| A4 | "What changes for an operator, day to day, if your plan works?" | CASE | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Answer from the operator's seat, in your own words. You can point to the sentence at its own scope: five years in transport consulting, in bus and light rail network planning. Answer slot: the recruiter asked you to land on the operators, so expect a probe on train operators specifically. If any of your work touched them, say what it was and what part was yours; if none did, say so plainly and stay with bus and light rail | F2 is the evidence for the operator lens, and the recruiter's explicit close makes this likely. CASE because it asks for the operator's day, with a JD flavor from the stated requirement |
| A5 | "How will we know by month 18 that it worked?" | CASE | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Name two or three measures and say which one an operator would recognise. Your own quoted result counts partners, which says little about operators on its own, so pair a partner-side measure with an operator-side one of your choosing. Do not quote a target you cannot defend, and the pack supplies none | F1 and F3 meet here, because Ross will push on commercials. CASE with a JD edge: the measure is where partnership and commercial scrutiny meet |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. What makes you credible with our operators in your first month?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | **The highest-ROI rehearsal in this pack.** Start with the plain acknowledgment: "I've never sold into rail specifically." Then hold on what your own words carry: five years in transport consulting, in bus and light rail network planning. Hold that through two follow-ups by returning to it, never by adding to it. Then concede one specific thing, in your own words: the one thing about selling to operators you would most need to learn first. If you cannot name one, say so plainly. Finish with a ramp, said as a plan: who you would learn from and what you would read, naming only what is real | F4 is the largest stated gap and Deepa is the person who inherits it, so it will arrive in some form. JD because it scores a stated requirement; the hold-then-concede structure is the rehearsal |
| B2 | "You've said you've only influenced revenue and never carried a direct quota. What would accountability for commercial outcomes look like for you here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Plain acknowledgment first: "I've never carried a direct quota, only influenced revenue." Then your position on accountability, which is yours to state: what you would want agreed in the first weeks and how you would want it measured. Answer slot: if the role carries a target, ask how it is set rather than assuming it, since the pack does not know. If it would be your first, say so plainly | F3 sets this up, and the recruiter's own line about Ross points at it. JD because commercials are part of the stated job |
| B3 | "Why move from payments to rail, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Your actual reason is yours to give, and nothing in the material carries it. Answer slot: say why, in your own words, and say what you would want from this role that the last one did not give you. Do not borrow a reason from the market report you cannot defend. If the honest answer is mixed, say it is mixed | F1 and F2 are the two halves of the story the Skeptic will test for consistency. EXP because it tests whether your arc survives cross-examination |
| B4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick the real one, not the safe one. F3 and F4 hold the two you have stated, and you can name either at its own scope. Say it in a sentence, say what you would do about it as a plan, and stop. Do not follow it with a list of strengths | The standard Skeptic question, aimed at the gaps you have already named. Calibrated candor beats bluffing a gap someone on the panel may own |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that roughly £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say how it was counted, what it is most sensitive to, and the assumption behind it you would defend least, each in your own words. Name that weakest assumption before Ross does. If you do not know how part of it was counted, say so plainly, and say what you do know. Keep the word "influenced" and do not drift to "generated" or "closed" | A figure on a CV is where a prober starts, and Ross will push on commercials. The pack supplies no method or baseline, because one you cannot repeat under a second question is worse than none |
| C2 | "How much of taking the channel from 6 partners to 40 was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: say which part was yours and which part others did, in your own words. If a team or other functions did part of it, say so, and hold what was yours through two follow-ups. If the honest share is smaller than the sentence suggests, say that, and stay with what you did | The standard attribution probe on F1. EXP because it tests what was actually yours; the pressure edge is the hold |
| C3 | "An operator wants a trial before committing. What commercial terms would you put on the table, and what would you refuse?" | CASE | [generic] | Treat it as a live problem, and say your clarifying questions first: what the trial is meant to prove, who decides afterwards, and what a refusal costs. Then your terms and your refusals in the operator's terms and Kelverton's. It needs no claim about your past, and the pack makes none. Say plainly where you would take advice from commercial colleagues | Ross will push on commercials, so some version of a live commercial problem is likely. `[generic]` because the pack has no information about Kelverton's pricing or terms |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, rather than someone who has already sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Hold-then-concede in sixty seconds. Concede first and plainly: "I've never sold into rail specifically." Then hold on your own words: five years in transport consulting, in bus and light rail network planning, and the channel you took from 6 partners to 40. If challenged, return to those sentences without adding to them. Pause before you start | F4 again in its pressure form. JD because it is the stated gap; the time box is the persona's |
| D2 | "If we put a revenue target on this role in year one, would you take it?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Answer slot: your actual position is yours to give. If you would, say what you would want agreed with it. If you would not, say so plainly and say what you would commit to instead. Do not give an answer you would not stand behind. The pack does not know whether the role carries a target, and you can ask | F3 in a form that forces a position. A pressure question tests whether you can hold one without defending it |
| D3 | "Where is the seam between partnerships and direct sales here, and what happens when we disagree about an operator account?" | CASE | [generic] | Propose seam principles instead of pretending to know where the seam is: who owns the operator relationship, who owns the commercial terms, and how a disagreement gets decided and recorded. Say that you would want to learn how it is settled today. Hold your position through one pushback, then concede what you do not yet know | A Commercial Director may probe the seam, in the Peer Evaluator register. It makes no claim about your past, so none is made |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc with beats from your own sentences: five years in transport consulting, in bus and light rail network planning; nine years in partnerships; the last four running the ISV channel at a payments company, and taking it from 6 partners to 40. Answer slot: end on why this role, in your own words, since the material does not carry it. Keep it to 90 seconds | The opener is scored for economy and fit even when it sounds casual. F1 and F2 are the two halves of the arc |
| E2 | "Why Kelverton?" | CO | [generic] | Your real reason is yours to give. Answer slot: say it in your own words, and tie it to one thing about Kelverton you can name and defend. The pack has no company research and supplies no fact about Kelverton. If your reason is partly the market report you read, say so | A motivation question in a friendly register, still scored. `[generic]` because the research that would ground it was unavailable |
| E3 | "What stood out to you in our report, and what would you challenge?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Pick one item you found most convincing and one you would question, and say why for each. It is the consensus-and-departure move from section 5, so prepare it once and use it twice. Answer slot: the pack has not seen the report and supplies none of its content. If there is part you did not take in, say so plainly and name what you did | The report is internal, and the recruiter attached it, so this is one of the likeliest questions in the room. CO because it tests homework depth and your altitude |

## Requirement coverage

| Requirement | Source | Questions |
|---|---|---|
| POV on operator partnerships over 18 months | Recruiter's email | A1, A2, A3, A5 |
| Land on what it means for the operators | Recruiter's email | A1, A4, B1 |
| Commercials | Recruiter's email | A5, B2, C1, C2, C3, D2, D3 |
| Selling into rail operators | Role-family prose, no JD | B1, B4, D1 |
| Why this move, why now | Not stated by the recruiter; added because every panel asks | B3, E1, E2 |
| The market report | Recruiter's email | E3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would tell you in the first 90 days that this hire was the right one?" | It asks Deepa for her own success measure, which is also the measure you will be held to, and it shows you are thinking past the interview |
| 2 | "Which operator relationships are in the best shape today, and which would you most like to change?" | It gets Deepa talking about the real starting position, which A2 needs, and it signals that the POV was a hypothesis |
| 3 | "How do you want partnerships measured commercially, and who sets that?" | It puts the commercial question to Ross on your terms and tells you whether the role carries a target, which F3 and D2 depend on |
| 4 | "Where do partnerships and the direct commercial team overlap on an operator account, and how is a disagreement settled today?" | It shows you have thought about the seam before being asked, and it gives you D3's answer from the inside |
| 5 | "Which findings in the market report are you acting on, and which are you still debating?" | It treats the report as a live argument, not a text to recite, and it tells you where your departure in section 5 will land |
| 6 | "What makes this role hard to be good at?" | It invites candor, and the answer tells you whether the gap in F4 matters most to Deepa or to Ross |

No interviewer profile was available, so none of these is tied to either panelist's own career path.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or to train operating companies | Negative you stated, F4 | The plain acknowledgment F4 gives: "I've never sold into rail specifically." No slot |
| Has carried a quota | Negative you stated, F3 | The plain acknowledgment F3 gives: "I've never carried a direct quota, only influenced revenue." No slot |
| Generated, closed or owned the roughly £4M | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue." The limit is the pack's observation: your material says influenced, not closed or owned. C1's slot asks only how it was counted and which part was yours |
| Has run operator partnerships, or knows the train operating companies | Inflated form of F1 and F2 | F1's and F2's quotes at their own scope. The limit is the pack's observation: your material says an ISV channel and bus and light rail network planning. A4's slot stays inside those |
| Single-handedly took the channel from 6 partners to 40 | Inflated form of F1 | F1's quote at its own scope: "took it from 6 partners to 40." The limit is the pack's observation: your material does not say who else was involved. C2's slot asks which part was yours |

## Sources

Provided documents: your message, including the recruiter's email as you quoted it and your own background summary. The market report is named in your message but its content did not reach this pack, so nothing in the pack is drawn from it.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

Every search was refused (the web search tool was not permitted in this session), so nothing from the web is in this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Query sent: "Kelverton Rail company values", refused. Would have moved a values cheat sheet, but none is built because no source in hand names a values-style round |
| 2. `Kelverton Rail interview process partnerships` | unavailable | Query sent: "Kelverton Rail interview process partnerships manager", refused. Would have checked the loop; your own words establish this round, so the persona weights stand on them |
| 3. `Kelverton Rail strategy` / recent news | unavailable | Query sent: "Kelverton Rail scheduling software train operating companies strategy news", refused. Would have moved the CO questions and a grounding brief, which both stay generic |
| 4. `Deepa VP Partnerships Kelverton Rail` | unavailable | Query sent: "Deepa VP Partnerships Kelverton Rail", refused. Would have moved an interviewer read and a reverse question tied to her path. No query was sent for Ross |
| 5. representative Senior Partnerships Manager JD | unavailable | Query sent: "Senior Partnerships Manager rail technology job description train operators", refused. Would have moved the JD-derived rows from role-family prose to a labelled representative JD |

## Upgrade menu

- The JD text → F4's role-family row becomes a quoted requirement, any further requirements get their own questions, and a gate such as a location or travel term would be surfaced
- The market report's text → section 5's consensus-and-departure step becomes concrete, E3 and the CO bank become grounded, and any stale framing in it can be flagged
- A fuller CV → F1 to F3 gain evidence beyond your summary, and answers can be story-mapped to specific work instead of a one-line arc
- Your answers to the slots in F1, F2 and F3, stated outside a drill → those rows are regenerated on your own words, and C1, C2 and A4 become story-mapped
- A reply from the recruiter on whether the role carries a commercial target → F3, B2 and D2 change shape
- Deepa's and Ross's full names and public profiles → an interviewer read and a reverse question tied to each one's path
- Search permission, and a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → values, loop and strategy sections built on sources, not on your words alone
- A tuesday-dossier.md → verified evidence quotes, a ranked objection list and prohibited claims from a prior evaluation; the pack stands without one
