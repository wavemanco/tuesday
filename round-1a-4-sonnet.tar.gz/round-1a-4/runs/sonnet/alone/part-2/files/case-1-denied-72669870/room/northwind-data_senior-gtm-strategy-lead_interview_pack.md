# Mock-interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. He would be Priya's peer, both reporting to the same VP. **Round:** a single 60-minute conversation with Dan. **Mode:** session. First version.

## 2. How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding to rehearse from, not a script: say it in your own words, and say only what you did.

| Type | What it scores |
|---|---|
| VAL | Behavior against the company's published values. No question carries this tag here: no values-style round is detected and no values page was in hand, so no values cheat sheet is included |
| EXP | Whether the CV's claims survive scrutiny, and what was actually yours |
| JD | The stated responsibilities and qualifications, gaps included |
| CO | Company and strategy knowledge, thinking at Northwind's altitude |
| CASE | A live problem set in the role, scored on structure and reasoning |

Answer slots are instructions for the interview, not questions for you to answer here. Each lets you answer from your own experience, or say plainly that the practice was not yours or never existed. Both are good answers.

**The highest-ROI prep in this pack is D1.** It is the sales-ops and quota-setting objection, which your own note states as a gap, asked by someone who runs sales strategy. It will be asked in some form. Rehearse it until it is boring.

## 4. Fit snapshot

The requirements are the JD highlights you supplied. The evidence is Priya's own sentences from your notes, quoted exactly.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy & ops, not go-to-market for a launch, and the words stay at "product strategy & ops". Answer slot: the JD's two-new-product-lines line makes a probe on commercial planning likely. If any plan for taking a product to customers was yours to set, say what and how you decided, in your own words; if there was none, or it was not yours, say so plainly and stay with product strategy & ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | The quote is a proposal credited with an uplift, and says nothing of which lifecycle stage it touched. Words stay at its scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD's land/adopt/expand/renew line makes a probe on lifecycle stage likely. If the change touched a stage, say which and how you know, in your own words; if it was not framed in those terms, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The quote already names both tools, but it is a skills line with nothing inspected behind it, so expect a probe. Say it in its own terms. Answer slot: if there is an analysis you ran yourself in either tool, be ready to walk it end to end; if the queries or dashboards were built by others, say so plainly and say what you ran |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a partner-level revenue model used in carrier negotiations, not a partner motion, and the words stay there. Answer slot: the JD marks this requirement as required, so a probe on what a partner motion consisted of is likely. If any part of such a motion was yours to design, say which and how you decided; if there was no such part, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms, so lead with it as written. Answer slot: expect a probe on how the consensus formed. If any org pushed back, say about what and what moved; if none did, say so plainly |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | low | [inferred] | discovery | The quote shows use, and the material does not show whether it reaches AI work in this role's terms. It is coached as a clarify note, not as a story. Answer slot: say which tools and what for, in your own words; if the use is mostly personal productivity, say so plainly |
| F7 | Sales-ops or quota-setting fluency: not in the JD highlights; a likely probe given the interviewer's function | "No classic sales-ops or quota-setting experience" — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and the candidate's note states it. Words: "I have no classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. The adjacent quote, F5's "set annual volume targets with cross-org consensus", stays at its own scope: targets, not quotas |

No gate rows: the JD highlights state no term such as location, pay, schedule or a credential. A full JD may add one.

## 7. Reading the interviewer

Public footprint was not researched: the searches were declined (see Sources). This read rests on the profile description you gave me.

| What the profile shows | Practical implication |
|---|---|
| Self-described "relentlessly data-driven" | Expect every number to be probed to its assumptions. Know how each figure was counted, name the assumption you would defend least before he does, and say plainly where you do not know. Bank B is built for this |
| Career spine in pricing and monetization | Pricing, packaging and unit economics are his native language. Bank C leans that way. Do not claim pricing experience your material does not state |
| One early-stage-startup chapter | Expect some interest in how you work with limited resources. The pack has nothing from your material on this, so answer from your own experience only |
| Peer, same VP | He is pricing what you cost and contribute to his work. Reciprocity framing (what you bring his team) beats listing needs |

Mirror opportunities:

| His public path | Your side, quoted from a named row | How to use it |
|---|---|---|
| Pricing and monetization roles | F4: "built a partner-level revenue model used in carrier negotiations" | A shared revenue-model vocabulary. Ask how he thinks about partner terms against direct terms; do not claim pricing work |
| One early-stage-startup chapter | None: no row carries a startup side | Not offered as a mirror. It is a reverse question only (R2) |

## 8. Persona table

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Peer Evaluator | Seam-splitting between Sales Strategy and the new role, "what would you need from me", credit and disagreement | High (5 questions). Peer relationship is the strongest prior, and he and Priya report to the same VP | Reciprocity framing; propose seam principles rather than pretending to know the seam; a disagreement story with spine and tact |
| B. Data-Driven Prober | Line-by-line on the revenue model, the targets and the ARR figure; asks for the SQL or Tableau work | High (5). The self-description is the strongest signal in the profile, and the $400M figure is a magnet | Know what you can and cannot say about how each number was counted; name the weakest assumption first; offer to walk one analysis end to end |
| C. Case/Strategist | A live problem on Compass, bundling or profitability, in pricing and packaging terms | Medium (3). Peers do not run long cases, but his pricing spine and the three stated priorities make short ones likely | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| D. Skeptic | Quiet probing of the sales-ops and partner-motion gaps and of why leave consumer for B2B | Medium (3). Gaps in F4 and F7 are the likeliest friction point for someone who owns sales strategy | Rehearse D1 until boring; bridge only from adjacent quotes; give a ramp plan; do not bluff a competency he owns |
| E. Conversational | "Walk me through the journey", "what are you playing with in AI" | Low-medium (2). A peer chat will open warm, and the JD's AI plus can arrive casually | A 90-second arc; treat the AI question as scored |
| P. Pressure | A time-boxed "why you", "how much was actually you" | Low (2). A peer rarely interrupts, but a data-driven one may press on attribution | Pause, restate, hold through two follow-ups, concede specifically |
| G. Values/Behavioral | A behavioral story on an unpopular truth or a customer-over-metric call | Low (2). No values-style round is documented, and this is one conversation, so these come from persona themes, not published values | Selection scaffolds with an honest branch; "we" for context, "I" for contribution |

## 9. Question banks

### A. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where do you see the seam between Sales Strategy and what you would own, and what happens when we disagree?" | JD | [generic] | Propose principles, not a map of a seam you cannot see yet. Say what you would ask first: what his team already owns for the two new lines, and which definitions and numbers it reports against. Principles to offer: one owner per decision, shared metric definitions, and disagreements settled on the data first, then taken to the shared VP with both options laid out. The question needs no claim about your past, so the guidance makes none | F1's requirement presses on this seam most directly. JD because it scores the role's cross-functional mandate; the persona is Peer Evaluator because the seam is the peer's central worry |
| A2 | "A new product line will pull on my team's data and my reps' time. What would you need from me, and what could you take off my plate?" | JD | [grounded] "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau" | Lead with what you bring, then what you need. For how you work across orgs, use the quote in its own terms: you set annual volume targets with cross-org consensus. On the plate: you are skilled in SQL/Tableau, and what that lets you take off his plate is a proposal for how you would work, not a record. Answer slot: if there was a point where one org's interests pulled against another's in that target work, say what you did; if there was not, say so plainly | F5 and F3 are the evidence on cross-functional influence and independent analysis. JD because it scores the influence requirement; the reciprocity move is the peer's version of it |
| A3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the quote says: you proposed the change, and it was credited with the uplift. Answer slot: if others built, shipped or measured it, say who did what, in your own words; if the whole of it was yours, say so plainly. Name credit you gave, only if you did | F2 is the largest credited result and the likeliest place a peer probes sharing. EXP because it tests attribution honesty, not a stated value |
| A4 | "Tell me about a time you held a view against another team and the relationship survived." | EXP | [grounded] "set annual volume targets with cross-org consensus" | The quote carries consensus across orgs and nothing about conflict. Answer slot: if any org pushed back on a target, say about what, what you held, and what moved; if consensus came without pushback, say so plainly and use the scaffold: pick a time you held a position with an equal, with a named stake, a point you did not fold on, and a working relationship intact afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5's quote does not show whether disagreement occurred, so the pack does not supply one. EXP because the quote is the evidence; the disagreement-with-equals theme comes from the Peer Evaluator persona |
| A5 | "What could you do in your first 30 days that would make my life easier?" | JD | [generic] | A plan, not a past. Principles: learn the existing definitions and the numbers his team reports, then produce a first look at whitespace for one of the lines across land, adopt, expand and renew for him to pressure-test. Frame it as what you would offer him, then ask what he would want first | F1 and F2 are the role's two headline asks, so a first-month plan is where they get tested for a peer. JD because it scores the stated responsibilities; it doubles as the reciprocity rehearsal |

### B. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that ~$400M ARR number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The defend-the-number answer, in your own words, with four slots. How it was counted: say how if you know; if you do not know, say so plainly. What it is sensitive to: say, or say you do not know. The assumption behind it you would defend least: name it before he asks. Which part was yours: the quote says you proposed the change. The pack supplies no method, baseline or model | F2's figure is the headline number on the CV and a data-driven prober's first target. EXP because it tests whether the number survives its own assumptions |
| B2 | "Who credited that uplift to your proposal?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot: if you know who credited it and on what basis, say so in your own words; if you do not know how the credit was assigned, say so plainly, and return to what the quote says, that you proposed the change | F2 again, from the attribution side. EXP because "credited with" is a passive in the quote and a prober will ask by whom |
| B3 | "Tell me how the partner-level revenue model worked and how it was used in the carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Beats the quote states: you built it, it was partner-level, it was a revenue model, and it was used in carrier negotiations. Answer slot: expect a probe on what the model took in and what you chose against what you inherited; if any inputs or structure were your choice, say which and why, if inherited or supplied by others, say so plainly. Name the assumption you would defend least, in your own words; if none comes to mind, say what you would check first | F4 is the only partner-facing evidence and the model is the artifact to inspect. EXP because the probe is on what was built and by whom |
| B4 | "Show me an analysis you ran yourself in SQL or Tableau, end to end." | JD | [grounded] "skilled in SQL/Tableau" | Scaffold: choose one analysis you ran yourself, with a question you asked, the data you used, what you found and what it changed. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it. Offer the walk-through before being asked, since he is data-driven | F3 is a skills line and the JD names independent analysis. JD because it scores the stated requirement; the prober tests it by demanding the artifact |
| B5 | "How would you tell whether a new product line is landing, being adopted, expanding and renewing? What would you measure first, and where would the data come from." | JD | [generic] | A structure, not a record. Clarify what is the unit of a customer and of adoption for the line, define each stage by an observable event, and ask what data exists before choosing metrics. State your weakest assumption aloud. The question needs no claim about your past, so the guidance makes none | F2's requirement is whitespace across the four stages, and this is how a prober tests it without a CV line. JD content, CASE delivery; tagged JD because it scores the stated requirement |

### C. Case/Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Take Compass, the copilot launch. How would you find the whitespace across land, adopt, expand and renew?" | CASE | [grounded] your research note: an AI copilot launch ("Compass") | Clarify first: who the first customers are and what counts as adoption. Then objective, segmentation, approach, metrics, risks. Challenge one premise politely, for example whether the same segments fit all four stages. Do not assume Compass is one of the two lines; you can ask | F2's requirement applied to a stated Northwind priority. CASE because it is a live problem; grounded on the research note you supplied |
| C2 | "A much larger platform vendor bundles a competing capability into what customers already buy. How does that change the GTM for a new line, including price and packaging?" | CO | [grounded] your research note: bundling by a much larger platform vendor | Ask what the bundle contains and who buys it. Then segment: customers for whom the bundle is good enough against those where Northwind's depth should win, and set price and packaging per segment. Keep it in pricing terms, which is his native language. No claim about your past | The competitive threat in your note is the likeliest strategy question, and his pricing spine tilts it toward packaging. CO because it scores company-level thinking; it is also a case in delivery |
| C3 | "Profitability is a stated priority next to growth. Where would you spend GTM effort on a new line, and where would you refuse to?" | CASE | [grounded] your research note: reaching profitability | Frame the trade-off first: what growth and profitability each reward in the first year. Pick criteria for effort, such as cost to land against expansion potential, and name one place you would say no, with the reason. The role's real job includes saying no, so include the anti-pick | Profitability is the third stated priority and the one candidates skip. CASE because it needs a position, not recall |

### D. Skeptic (weight: medium) — D1 is the highest-ROI prep

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see sales-ops or quota-setting in your background. How would you handle that part of this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience"; "set annual volume targets with cross-org consensus" | Hold, then concede, in this order. Concede first and exactly: "I have no classic sales-ops or quota-setting experience." Then the adjacent quote at its own scope: "I set annual volume targets with cross-org consensus." Then a plan, said as a plan: what you would learn first and from whom, starting with how his team works today. Follow-up one: he may say volume targets are not quotas. Concede the difference and do not claim equivalence; say what you do not yet know, in your own words, and who you would ask. Follow-up two: he may ask for your first quarter. Give the plan, not a past. Follow-up three: he may ask why not hire someone from sales ops. Do not bluff a competency he owns. Name the limit before he does, then say what you do bring from your quotes | F7 is the stated gap and the objection the pack names as highest-ROI. JD because the role is Sales Strategy-adjacent; Skeptic because it probes a gap under cross-examination |
| D2 | "The role requires partner-motion design experience. Where does yours come from?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | The hold is only what the quote carries: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of a partner motion was yours to design, say which and how you decided, in your own words; if there was no such part, or it was not yours, say so plainly and stay with the model. Hold through two follow-ups by returning to the model, never by adding to it | F4 is the one requirement marked required and the evidence is adjacent, not direct. JD because it scores a stated requirement; Skeptic because the answer is judged by candor |
| D3 | "Why leave a large consumer-tech company for B2B data infrastructure, and why now?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" | The reason is yours; the pack has none from your material. Answer slot: give your actual reason, in your own words, then tie it to the role as the JD states it. If part of the reason is the JD's own scope (two new lines, whitespace across the four stages), say that, and keep it consistent with E1's arc | Motivation consistency is the Skeptic's second scoring axis. JD because it scores fit with the stated role; the quote is the only evidence of what is being left |

### E. Conversational (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with the beats the quotes state: two years in strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy & ops. Then land on why this role, from D3's answer. Add one concrete line from the other quotes, such as the partner-level revenue model, only in its own words | F1 holds the nine years; the arc is the one answer every interviewer asks. EXP because it is the CV told aloud |
| E2 | "What are you actually playing with in AI these days?" | JD | [inferred] "uses AI tools daily" | Say the quote in your own words, then the slot. Answer slot: say which tools and what for; if it is mostly personal productivity, say so plainly, and do not claim to have built AI features | F6 is a low-confidence row, and the JD's AI plus is the likeliest casual question. JD because the casual register hides a scored requirement |

### P. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau"; "No classic sales-ops or quota-setting experience" | Pause and restate the question. Hold on what the quotes carry: you built a partner-level revenue model used in carrier negotiations, you set annual volume targets with cross-org consensus, and you are skilled in SQL/Tableau. Concede in the same breath: "I have no classic sales-ops or quota-setting experience." Do not say what these prove; describe them and let him infer | F4, F5, F3 and F7 together are the whole honest answer. JD because it scores fit to the role; Pressure because of the time box |
| P2 | "That ARR result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause. Hold the quote at its scope: you proposed the change. Answer slot: if others built, shipped or measured it, say who and what, in your own words; if it was all yours, say so plainly. Hold through two follow-ups, concede specifically, and never fold on the proposal itself | F2's attribution is the likeliest pressure point on the headline number. EXP because it tests attribution honesty |

### G. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | A selection scaffold: pick a time the data said something leadership did not want, with a named stake, a moment you did not soften it, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No quoted sentence carries this story, so the pack supplies none. EXP because it scores past behavior; the theme comes from the Values persona's stems, not a published value |
| G2 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] | A selection scaffold: pick a time with a named customer need, the metric it cost, and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Same shape as G1; the customer theme is also a Northwind enterprise-expansion theme in your note. EXP because it scores past behavior |

### Requirement coverage

| Requirement | Questions |
|---|---|
| own GTM strategy for two new product lines | A1, A5, C1, C2, C3, P1 |
| identify whitespace across land/adopt/expand/renew | B5, C1 |
| run independent analysis in SQL and Tableau | B4, B5, A2 |
| partner-motion design experience required | D2, B3 |
| strong cross-functional influence | A2, A3, A4, A1 |
| AI experience a plus | E2 |
| Sales-ops or quota-setting fluency (not in the highlights) | D1, P1 |
| Defend-the-number: the ~$400M ARR figure | B1, B2, P2 |

## 11. Reverse questions

| # | Question to ask Dan | Why it lands |
|---|---|---|
| R1 | "Your career has run through pricing and monetization. How does that shape how you think about GTM for a new product line here?" | Ties to his own path and invites him to talk in his native language, which turns an evaluation into a peer conversation |
| R2 | "You spent one chapter at an early-stage startup. What from it do you still use here?" | Ties to his path; shows you read his profile, not just the company's |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are pricing what you cost him |
| R4 | "Which are the two new product lines, and is Compass one of them?" | Shows you worked from the stated priorities, and the answer reweights several of the banks |
| R5 | "When enterprise expansion, Compass and profitability conflict in GTM planning, how are the trade-offs made, and who makes them." | Grounded in the three priorities from your note; probes the seam and the decision rights between you |
| R6 | "How is the bundling threat from a much larger platform vendor changing how you plan price and packaging for new lines." | His pricing spine makes this the question he has most to say about |
| R7 | "Six months in, what numbers would you look at to say this hire was working." | He is data-driven, so a measurable bar is the language he trusts |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Sales-ops or quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I have no classic sales-ops or quota-setting experience." No slot |
| Designed or ran a partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says a revenue model, not a motion. D2's slot stays inside the model |
| Owned GTM for a product line | Inflated form of F1 | F1's quote at its own scope. The material says product strategy & ops, not go-to-market |
| Drove or generated the ~$400M ARR | Inflated form of F2 | F2's quote at its own scope: a proposal, credited with the uplift. B1, B2 and F2's slots stay inside it |
| Did whitespace analysis across land, adopt, expand and renew | Inflated form of F2 | F2's quote at its own scope; the limit is the pack's observation that the material does not show a lifecycle framing |
| Built or shipped AI products or features | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily" |

## 14. Sources

Provided documents: your message, which supplied the JD highlights, the candidate summary, the description of Dan's profile, and your research note on Northwind's three stated priorities and its main competitive threat. No `tuesday-dossier.md` was in context.

Searches sent: all three were refused, so nothing came back and nothing from the web is used.

| Query | Result |
|---|---|
| Northwind Data company values principles | refused |
| Northwind Data interview process strategy GTM role | refused |
| Dan Kovac Northwind Data Director Sales Strategy | refused |

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The search was refused. It would have fed a values cheat sheet and VAL questions. None is included, and no values-style round is detected from your description of a single conversation |
| 2. Northwind Data interview process, GTM role | unavailable | The search was refused. It would have documented the loop. Persona weights rest on your description of one 60-minute conversation with a peer |
| 3. Northwind Data strategy and recent news | skipped | Your research note supplies the three priorities and the competitive threat, which fix the CO and CASE questions |
| 4. Dan Kovac, Northwind Data | unavailable | The search was refused. It would have grounded the interviewer read in his public footprint. The read rests on the profile description you gave me |
| 5. Representative role JD | skipped | The JD highlights you supplied fix the fit snapshot and the JD-tagged questions |

## 15. Upgrade menu

- The full JD text: the requirement column quotes the posting itself instead of your highlights, and any gate such as location, pay or schedule would appear as its own row
- Priya's CV text, or her own answers to the answer slots on F1, F2, F4 and F6: rows now at medium or low confidence can be upgraded, and the weakest-assumption move in B1 and B3 can be built from her words. For the ARR figure the artifact that would raise the band is the memo or analysis that credited the uplift; for the revenue model, the model file or its documentation
- The recruiter's prep email, focus areas or any pre-declared deliverable: this pack assumes none, and a declared deliverable would get its own build section
- Search access, or a pasted values page and Dan's profile text: the values cheat sheet, the loop structure and a grounded interviewer read all depend on the three refused targets
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): a strategy brief section, Dan's talks and writing, loop reports for this role family, and recent org context. It needs search access
- A `tuesday-dossier.md`: verified evidence and a sourced list of prohibited claims, which would sharpen D1 and the prohibited list
