# Live Operations Producer — Saltmarsh Games: interview prep pack

- **Role:** Live Operations Producer, Saltmarsh Games (mobile game studio)
- **Interviewer:** Tobias Wrenfield, Head of Live Operations — relationship to the role not confirmed; this pack assumes a hiring-manager round
- **Format:** one 60-minute interview, Friday 27 November 2026
- **Candidate:** Femi

## How to use this pack

Personas describe how a question arrives (who is asking, in what style). Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Past behavior against values or principles |
| EXP | Whether the claims about your work survive follow-up questions |
| JD | The listed responsibilities and requirements, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Reasoning on a live problem from the role |

Question IDs run by persona: A Case/Strategist, B Skeptic, C Data-Driven Prober, D Conversational, E Values/Behavioral, G Peer, H Pressure. The letter F is skipped so it cannot be confused with the fit-snapshot rows F1 to F10.

An answer slot is an instruction for the interview, not a question for you now. It tells you where the interviewer will probe and gives you two honest branches. Either branch is a good answer; a bluffed one is not.

## Prep triage

You have Tuesday to Thursday. In order:

1. Say B1 and B2 aloud until they are boring. B1 is the highest-ROI prep in this pack (reasoning in the question bank).
2. Run A1 to A4 out loud once each, thinking aloud with the structure in the guidance. These are the likeliest live problems in a hiring-manager round.
3. Time the D1 arc to 90 seconds.
4. Run C1 and C3, saying the answer-slot branches that are true for you.
5. Play both Saltmarsh titles for a session each, so D2 and D3 have your own observations in them.

Everything else is insurance.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The years and the title are the quote's, and the words stay there. Your material does not show whether the game was run as a live service. Answer slot: the JD's live-service line makes a probe on that likely. If it was run that way, say how, in your own words; if it was not, or you do not know, say so plainly and stay with the four years and the title you held |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you ran it, it was weekly, it was for the main title, for the last two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title. The JD says live events across two titles, and the words stay at the quote's own scope. Answer slot: if any of the drops were time-limited events, or you planned for more than one title, say which and what was yours, in your own words; if not, say so plainly and stay with the weekly calendar you ran |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The quote says the calendar, not which teams you worked with on it. Answer slot: the JD names four disciplines, so expect a probe on who you worked with. If you worked with any of those teams on the drops, say which and what you did with them, in your own words; if some were not part of your drops, say so plainly |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | The quote says you presented the numbers each month to the studio head. It does not say you owned a review or chose what was reported, and the words stay at the quote. Answer slot: if you reviewed drops afterward or chose what the numbers covered, say how, in your own words; if the numbers were prepared by others, or there was no review of each drop, say so plainly and stay with the presenting you did |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | The quote says you wrote the checklist and that QA still uses it. It does not say you ran releases against it. Answer slot: if you ran releases against it or worked with QA on it, say how, in your own words; if QA runs it without you, or you only wrote it, say so plainly and stay with the writing. The checklist itself is the inspectable artifact that would raise the confidence |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in the quote's terms: monthly retention numbers, presented to the studio head. Expect a probe on how those numbers were counted (C1); the pack supplies no method |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written checklist touches the requirement without showing it was clear. Answer slot: if other writing of yours was relied on by others, say what it was and who used it, in your own words; if the checklist is your main example, say so and offer to show it |
| F9 | In-app-purchase experience (not in the JD; a role-family expectation the pack checks for) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. The JD does not mention monetization, and whether Saltmarsh's titles use in-app purchases is not established here |
| F10 | Leading a team (not in the JD, which asks for coordination, F4) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | You have said so. Words: "I haven't led a team." Then how you would work with the four disciplines, said as a plan and never as a past. Nothing added to make the gap feel smaller |

The JD sets no eligibility terms such as location, pay or a credential, so no row here is a gate.

## Persona table

The relationship is not confirmed. The prior for a hiring manager is Case/Strategist plus Skeptic. No source establishes Saltmarsh's loop, so the weights rest on that prior and the generic archetype (flat tilt), not on this company's documented process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: a retention dip, a calendar under strain, a failed build | High. Hiring-manager prior; the JD is made of plannable work (calendar, update coordination, review, checklist). 4 questions | Clarify, objective, segments, approach, metrics, risks, thinking aloud; challenge one premise politely |
| Skeptic | Quiet probing of the gaps you named (F9, F10) and the scope limits (F3, F5, F6) | High. Hiring-manager prior; your own message flags two gaps. 5 questions | Rehearse the sourced plain acknowledgments until they are boring; hold, then concede only what the sentence says; give a plan, not a past |
| Data-Driven Prober | Line-by-line questions on the retention numbers and the checklist | Medium. The JD asks for comfort with retention metrics and the review's KPIs, and your own material names monthly retention numbers. 3 questions | Say how the numbers were counted if you know; say plainly if you do not; name the assumption you would defend least |
| Conversational | A friendly opener, then casual questions about games and motives | Medium. Most interviews open this way and a 60-minute slot has room for it. 3 questions | A timed 90-second arc built from your own sentences; treat casual questions as scored |
| Values/Behavioral | Scenario prompts on cross-team disagreement and unwelcome news | Low to medium. No values round is established, and no published values were retrieved. 2 questions, themed on the JD's coordination line and a standard stem | Selection scaffold ending in its honest branch |
| Peer Evaluator | Seam and credit questions from someone who works next to the role | Low to medium. The JD makes the role cross-team, but the assumed relationship is a manager. 2 questions | Propose seam principles; frame what you bring, not only what you need |
| Pressure | Time-boxed challenges, "how much was actually you" | Low. No signal of a stress style. 2 questions | Pause, restate, hold through two follow-ups, concede one specific thing |

## Question banks

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "3+ years producing live-service games or apps" | B3, D1 |
| "Plan and run the live-events calendar for two of our mobile titles" | A2, B2, H2 |
| "experience running a content calendar" | A2, B2, H2, D1 |
| "coordinate design, art, engineering and community teams on each update" | A3, B4, E1, G1, G2 |
| "own the post-event review and the KPIs it reports" | A4, C1 |
| "manage the release checklist with QA" | A3, C3 |
| "comfortable with player-retention metrics" | A1, C1, C2 |
| "clear written communication" | A3, C3 |

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Retention on one of our titles dips in the second week of a live event. Diagnose it." | CASE | [generic] | Clarify before structuring: what the dip is measured against, for which players, since when, and what else shipped or changed in the same window. Then state the objective, split the players into segments, rank the likely causes, say what you would check first and who you would ask on each team, and name the risk of acting on thin data. Challenge one premise politely, such as whether the dip is real or an artifact of the comparison. Think aloud. The question needs no claim about your past, so the guidance makes none | The JD's retention-metrics line (F7) asked as a live problem; CASE because it scores structure rather than recall. `[generic]` because it is a pattern, not a fact about Saltmarsh |
| A2 | "You have six weeks of events to schedule across two titles, and design, art and engineering are all near capacity. How do you build the calendar?" | CASE | [generic] | Clarify what is fixed and what can move: each team's lead time, QA and release windows, any date other teams cannot shift. State the objective for the period. Sequence by dependency rather than by appeal, leave buffer before dates others cannot move, say what you would cut first and who decides, and say how each team sees the calendar. Name one trade-off you would refuse. Think aloud; no claim about your past is needed | The JD's calendar and coordination lines (F3, F4) as a decision, not a record; JD content with CASE delivery, tagged CASE for how it is scored |
| A3 | "A build for Thursday's event fails QA on Wednesday afternoon. Walk me through the next 24 hours, including what you would write to the four teams." | CASE | [generic] | Confirm what exactly fails and how severe it is. Lay out the options with the cost of each: fix and hold the date, cut the broken part, move the date, ship with a known issue. Say who decides and who is told, and when. Then draft the message live: what happened, what is affected, the decision, when the next update comes. Close with what you would change on the checklist afterward. No claim about your past is needed | The JD's release-checklist and written-communication lines (F6, F8) in one live problem; CASE because the message is written in the room |
| A4 | "What do you want in a post-event review, and what would you refuse to report?" | CASE | [generic] | Say what the event was for, stated before it ran; what the results are compared to; what the event could and could not have caused; what is reported, to whom, and what gets decided from it. A strong answer to the second half is a number reported with no stated comparison. No claim about your past is needed | The JD's post-event-review line (F5) asked about judgment, which a prober would otherwise test through your history |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Say it plainly first: "I haven't worked on a game with in-app purchases." Then hold it through two follow-ups. Follow-up one, "How would you get up to speed?": give a plan, said as a plan, covering what you would ask to see in the first weeks, who you would ask, and how you would learn how an event's goal is set here. Follow-up two, "What worries you most?": name one honest worry in your own words. Concede exactly what the sentence says and nothing wider; do not reach for something adjacent you have not stated, and do not apologize it into something larger | F9 is the largest gap your own message shows and the one no wording closes, so a Skeptic aims here; it gets the most follow-up levels and the exact concession wording. JD-tagged because the question scores readiness for the role, though the JD itself is silent on monetization, which the reverse questions address |
| B2 | "Your calendar was weekly content drops on your main title. This role plans live events on two titles. How do you see the gap?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold at the quote's scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events and two-titles lines make a probe likely. If any drops were time-limited events, or you planned for more than one title, say which and what was yours, in your own words; if not, say so plainly and stay with the weekly calendar you ran. Hold through two follow-ups by returning to the quote, never by adding to it. Then give a plan: what you would want to learn first about each title's event cadence and each team's dependencies | F3 is the second-widest distance between the quote and the JD. JD because it scores the stated requirement; the question's premise is the interviewer's and the guidance does not adopt it |
| B3 | "You've been an associate producer. Why is a Producer role the right next step?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Start at the quote: you spent four years as an associate producer at a puzzle-game studio. Answer slot: if any of that work went beyond the associate title, such as decisions that were yours to make, say which and how you decided, in your own words; if the associate scope held throughout, say so plainly. Then say what you would want to be judged on at ninety days, as a plan | F1 and the title step; EXP because it tests whether the years amount to what the title asks |
| B4 | "This role coordinates four disciplines on every update, and you've never led a team. How do you get them moving?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say it plainly: "I haven't led a team." Answer slot: the JD's coordination line makes a probe on how you worked with other teams likely. If you worked with any of design, art, engineering or community on the drops, say which and what you did with them, in your own words; if you did not, or the drops were not arranged that way, say so plainly. Then give a plan for how you would work with the four disciplines, said as a plan | F10 and F4; the negative in the question has a source, your own message. JD because it scores the coordination line |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] | Choose honestly from where your material is thinnest, which the fit snapshot shows at F3, F5, F6, F9 and F10. Name it plainly, in the plain-acknowledgment or slot wording of that row, and say how you would close it in the first month. If monetization is your pick, the sourced sentence is "I haven't worked on a game with in-app purchases." Do not pick something harmless to sound strong | The standard Skeptic stem; JD because it asks for a self-assessment against the listed requirements |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the retention numbers you presented each month." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The beats the quote states: they were retention numbers, monthly, presented to the studio head; tell them in your own words. Answer slot: say how the numbers were counted, what they were sensitive to, the assumption behind them you would defend least, and which part was yours, in your own words. If you did not build them, or you do not know how a figure was counted, say so plainly. Naming your weakest assumption before the interviewer does is a credibility gain | F5 and F7; the question is premised on the quote only. EXP because it tests the claim, not the topic |
| C2 | "What does retention tell you about a live event, and what doesn't it?" | JD | [generic] | Say what it can show (whether players came back after the event) and what it cannot (why they did, and whether the event caused it rather than something else changing in the same window). Say what you would pair it with and why a before-and-after comparison is fragile. No claim about your past is needed | The JD's retention-metrics line (F7) as a judgment question; `[generic]` because it is a pattern |
| C3 | "Tell me about the release checklist your QA team still uses. How does it get used on a release?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | The beats the quote states: you wrote it, and QA still uses it. Answer slot: the JD's checklist-with-QA line makes a probe on how it is used each release likely. If you ran releases against it or worked with QA on it, say how, in your own words; if QA runs it without you, or you only wrote it, say so plainly and stay with the writing. If you can share a redacted copy, offering it is stronger than describing it | F6 and F8; EXP because the checklist is the one artifact in your material an interviewer can ask to see |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through your journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in this order, one beat per quoted sentence, in your own words: the four years as an associate producer, the calendar you ran for the last two years, the checklist, the monthly retention numbers. Then why this role, in your own words. Answer slot: the JD says live-service, so if the game was run that way, say how; if it was not, say so plainly | F1 to F7; the first question of most interviews and the most-rehearsed one. EXP because it is your history, told in order |
| D2 | "What are you actually playing these days, and what do you make of its live events?" | JD | [generic] | Name a mobile game you actually play, ideally one of the two Saltmarsh titles. Say one thing you notice about how its events are paced or announced. If you play none, say so plainly and say how you have been studying the genre. Never name a game you have not played | The conversational stem on the JD's live-events line (F3); casual questions on hot JD topics are still scored |
| D3 | "Why Saltmarsh, and why now?" | CO | [generic] | Give your own reason in your own words. Ground it in something you saw in the titles after playing them. Leave out claims about Saltmarsh's strategy or recent moves: the pack could not establish them, and a stale claim costs more than none. If you have not yet played the titles, say so plainly | Motivation consistency; CO because it scores knowledge of the company, and `[generic]` because company research was refused |

### E. Values/Behavioral

No published Saltmarsh values and no values round were established, so no values sheet is built. These two themes come from the JD's coordination line and a standard stem.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time design and engineering wanted different things from the same update." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection criteria: pick a time two disciplines wanted different things, with a named stake, what each wanted, what you did, and how the relationship stood afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the calendar sentence at its own scope, or say how you would handle it | F4; an open prompt whose theme is the JD's coordination line. VAL because it scores behavior, not a published value |
| E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection criteria: pick a time you had unwelcome news, with a named stake, what you said, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is presenting the monthly numbers to the studio head at its own scope, or say how you would handle it. Do not describe any number as unwelcome unless it was | A standard Values stem; the quote is the nearest thing your material carries to an audience of leadership (F5) |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design, art and engineering all want the same slot in the calendar. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who owns the dates, who owns the content, who decides when they collide, and where it escalates. Add what you bring to the other teams, not only what you need from them. No claim about your past is needed | The JD's coordination line (F4); peer questions arrive as collaboration cases, so JD content with CASE delivery |
| G2 | "How do you handle credit when an update spans design, art, engineering and community?" | VAL | [generic] | Say how you would name each contribution and where, and why. Keep to principle; if you want to use an example, it must be one of your own sentences from the snapshot, at its own scope | A standard peer stem on the JD's four-team line (F4) |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over someone who has run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Pause, restate the question, then hold on the two sentences you can stand behind: the calendar you ran for the last two years, and the checklist you wrote. Concede one thing, exactly: "I haven't worked on a game with in-app purchases." Hold through two follow-ups; do not widen either sentence to win the minute | F3 and F9 under time pressure; JD because the comparison is a fit challenge |
| H2 | "That calendar — how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence at its scope. Answer slot: say which parts were yours alone and which were shared or set by others, in your own words; if priorities were set above you, say so plainly. Naming the shared parts yourself is stronger than being asked | F2 and F3; the attribution probe that exists to catch inflation |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How is an event's goal set here, and does monetization figure in it?" | Honest about F9 without confessing again: it asks the thing the JD leaves out and shows you are thinking about what the events are for |
| 2 | "What does a good post-event review look like here, and who reads it?" | Shows the review is the part of the job you care about (F5) |
| 3 | "Where does the calendar run tightest today, and which team's lead time is the constraint?" | Shows you think in dependencies (A2), and the answer tells you what the first month really is |
| 4 | "What would you want me to have learned by the end of the first month, and by ninety days?" | Turns B3's ninety-day plan into the interviewer's own measure |
| 5 | "How is the release checklist used with QA today, and what would you change?" | Opens the F6 topic on your terms and signals interest in the artifact you wrote |
| 6 | "How does the community team get involved when an event goes wrong?" | Tests the fourth discipline in the JD's coordination line, the one your material says least about |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for the main title. B2's slot stays inside the calendar |
| Owned the post-event review or the KPIs it reports | Inflated form of F5 | F5's quote at its own scope. The material says the numbers were presented to the studio head, not that a review was owned |
| Managed releases with QA | Inflated form of F6 | F6's quote at its own scope: the checklist was written and QA still uses it. C3's slot stays inside that |
| Has in-app-purchase experience | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |
| Has led a team | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't led a team." No slot |

## Sources

Provided documents: the JD text and your background, both in your message. No dossier was present.

Research was attempted and not available in this session: every search was refused, so nothing about Saltmarsh Games was retrieved, and nothing in this pack states a Saltmarsh fact.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Query | Outcome |
|---|---|
| Saltmarsh Games values | refused |
| Saltmarsh Games interview process live operations producer | refused |
| Saltmarsh Games mobile studio strategy news | refused |
| Tobias Wrenfield Saltmarsh Games | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The values cheat sheet, had a values round been documented; none was, so section 10 is dropped either way. VAL questions are themed on the JD and standard stems |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Loop structure and persona weights; they rest on the hiring-manager prior and the generic archetype, said so in the persona table |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | CO questions grounded in strategy; D3 is `[generic]` and a grounding brief is absent |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to run web searches, or Saltmarsh's values or careers page pasted in → grounded company questions, any documented loop structure, and a values sheet if a values round is documented
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; offered once) → a strategy brief and a read on Tobias Wrenfield's public talks and writing, if the same search permission is granted
- Whether Tobias is your future manager, a peer or a skip-level → reweights every bank and the persona table
- The recruiter's email: stated focus areas or any pre-declared exercise → a graded-deliverable build section if one was named
- The names of the two titles → sharper A2, D2 and D3
- A redacted copy of the release checklist and one monthly retention slide → F6, F7 and F5 move toward high confidence, and C1 and C3 can be rehearsed against the real artifacts
- Your own answers to the slots in F1, F3, F4, F5, F6 and F8, said outside a drill → those rows become quoted material and the questions that draw on them regenerate
- A tuesday-dossier.md, if you already have one → verified evidence and a prohibited-claims list that replaces the one built here
