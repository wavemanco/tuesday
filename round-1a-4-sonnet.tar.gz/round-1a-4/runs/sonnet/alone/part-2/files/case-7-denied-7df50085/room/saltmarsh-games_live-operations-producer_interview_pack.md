# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (you did not say; the persona weights rest on that assumption). Format: 60 minutes, Friday.

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Guidance is scaffolding for your own words, not a script. An "Answer slot" is an instruction for the interview: it asks nothing of you here, and either honest branch meets it.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (none in this pack: no published values were read and no values round is documented) |
| EXP | Whether your own claims survive scrutiny: what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its products |
| CASE | A live problem from the actual role, worked aloud |

Provenance labels: `[grounded]` traces to your message or the JD you pasted; `[inferred]` is derived from them and the derivation is named; `[generic]` is a role-family pattern with no claim about you or Saltmarsh.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not a live-events calendar and not two titles, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles line makes a probe on running two calendars likely, and its live-events wording makes a probe on how events differed from drops likely. If you ran more than one calendar, or any of your drops were timed events, say how, in your own words; if not, say so plainly and stay with the one calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams you worked with. Answer slot: the JD names four teams, so expect a probe on which you worked with directly. If you worked with any, say which and what part was yours, in your own words; if none, or it was not yours, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you owned a review or chose the KPIs, and the words stay there: "Presented the monthly retention numbers to the studio head." Answer slot: if you had a hand in which numbers went in or how they were defined, say what; if the numbers came from elsewhere, say so plainly and stay with the presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it, not that you ran releases against it, and the words stay there: "Wrote the release checklist our QA team still uses." Answer slot: if you also worked releases through it with QA, say how it worked, in your own words; if QA ran it without you, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio.", "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and two running the calendar, and does not say whether the title was live-service. Answer slot: the JD's live-service wording makes a probe on this likely. If the title was updated after launch, say how you would describe it, in your own words; if it was not, or only partly, say so plainly and stay with the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with the calendar in the quote's own terms: weekly, content drops, your main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but nothing inspected behind it, so expect a probe on how the numbers were counted. Lead with the quote's terms: monthly, retention numbers, the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | A written document that a team still uses is the one written artifact in your material. Reword only that: you wrote it and QA still uses it |

## Persona table

Loop: your note establishes one 60-minute session run by Tobias Wrenfield. No source says whether other rounds exist, so no values-style round is detected and the fallback archetype is Generic (flat weights, said plainly). Relationship prior for a hiring manager: Case/Strategist plus Skeptic. Seven personas exist; Values is dropped (nothing documents a values round), and the remaining six carry the pack.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (weight 5) | Live problems from the role: two calendars, a late dependency, a retention dip | High. The role is a planning job and a Head of Live Operations will likely test planning aloud | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (weight 5) | Quiet probing of the move from one puzzle title to a two-title mobile role | High. Hiring-manager prior, and your own message names two things you have not done | Rehearse the likeliest objection (B2) until it is boring; say each limit plainly; return to what your own sentences carry |
| Data-Driven Prober (weight 3) | Line-by-line questions on the retention numbers and the review | Medium. The JD names retention metrics and KPIs; no seniority signal that this interviewer is metrics-first | Say what you know about how the numbers were counted and say plainly what you do not |
| Conversational (weight 3) | "Walk me through the journey", casual questions about the checklist and calendar | Medium. Most sessions open this way, and casual questions are still scored | Pre-script a 90-second arc from your own sentences |
| Peer Evaluator (weight 2) | Seam questions between production and design, art, engineering, community | Low to medium. The interviewer is likely your manager, but the JD's coordination line invites this style | Propose seam principles; do not pretend to know their seam |
| Pressure (weight 2) | A time-boxed "why you", a "how much was you" | Low. Nothing signals a stress style, but your gaps make the probes easy to ask | Pause, restate, hold through two follow-ups, concede one thing specifically |

## Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Imagine two titles each have an event landing in the same fortnight and one shared art team. How would you plan the next eight weeks of the calendar?" | CASE | [generic] | Ask first: what is already locked, each title's usual cadence, what the art team can take, who decides when dates collide. Then objective, what can move and what cannot, a draft sequence, how you would tell each team, and what you would watch. Challenge one premise politely, for example whether both events need to land together. The question needs no claim about your past, so the guidance makes none | The two-titles line of F1 makes a planning case the likeliest opener. CASE because it is a live problem; JD flavor in the rationale |
| A2 | "The role runs one calendar across two titles. How would you run both at once?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you ran, at its scope: the weekly content-drop calendar for your main title, over two years. Then answer as a plan: what you would want to find out first and how you would keep the two calendars visible side by side. Answer slot: if you ever ran more than one title's calendar, say how; if you did not, say so plainly and describe the one you ran | F1 is the thinnest part of the fit, so this is asked in some form. JD because it scores the stated two-titles requirement |
| A3 | "Retention dips two weeks after an event ends. How do you diagnose it?" | CASE | [generic] | Clarify first: which retention measure, against what baseline, which players, and whether anything else shipped. Then list competing explanations, what data separates them, and what you would do this week versus after the data arrives. Say which explanation you would rule out last and why. No claim about your past | F7 and F3 make a metrics case likely from a hiring manager. CASE because the answer is reasoning, not history |
| A4 | "An update's art will not be ready the day before release. What do you do?" | CASE | [generic] | Find the real constraint first, then name the options (slip, cut, ship reduced) and who decides each. Say how design, art, engineering and community each hear about it, and what you would write down for the post-event review. No claim about your past | F2 and F4 make a dependency case likely. CASE; the coordination and checklist lines of the JD supply the theme |
| A5 | "What do you know about our two titles, and what would you look at first as their producer?" | CO | [generic] | Research failed in this build, so nothing here is known about Saltmarsh. Before Friday, play both titles and note what you can see from outside, such as cadence and events. In the room, say what you saw and what you cannot know from outside, then what you would ask first. Do not recite a fact you did not verify | Homework depth is scored in any hiring-manager round. CO; it stays generic until research or a recruiter brief arrives |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose one limit your own material shows and say it plainly in your own words, then say what you would do in the first weeks about it, as a plan. Your message gives two to choose from: leading a team, and in-app purchases. Do not offer a weakness you do not have to sound modest, and do not pick one the role does not need | A Skeptic asks this stem of anyone changing context; F1 and F2 are the likeliest places. JD because it scores honest self-assessment against the listed role |
| B2 | "You haven't worked on a game with in-app purchases. How do you plan to get up to speed?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The highest-ROI rehearsal in this pack. Start with the plain acknowledgment: "I haven't worked on a game with in-app purchases." Then give what your own sentences carry, each at its own scope: "Presented the monthly retention numbers to the studio head." Then a plan, said as a plan: what you would learn first and who you would ask. Hold through two follow-ups by returning to those sentences, never by adding to them. Never say your retention work covers it | Inferred from your own message, not from the JD: the interviewer runs live operations at a mobile studio and this gap is the one your message states. F3 shows where it bites. JD because it presses a requirement area; Skeptic delivery |
| B3 | "You haven't led a team. This role coordinates design, art, engineering and community on each update. What makes that a fit for you?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Acknowledge it first: "I haven't led a team." Then say how coordination differs from leading, only as you would say it yourself. Answer slot: if you worked with any of those four teams to get something out, say which and what part was yours; if none, or if it was not yours, say so plainly and stay with the calendar you ran | F2 is the row with no evidence, and the stated negative makes this the natural pair. JD because the JD names the four teams |
| B4 | "Why this move, from a puzzle studio to a mobile live-ops role at Saltmarsh, and why now?" | EXP | [generic] | Selection scaffold: pick the reason that is actually yours, one that explains why live operations and why a larger studio, and that you can say in two sentences without apologizing for the move. Answer slot: give your actual reason; if you do not yet have a Saltmarsh-specific one, say so plainly and name what you would want to learn | Motivation consistency is a Skeptic staple. EXP because it scores whether your story holds together; generic because no reason was given |
| B5 | "The role asks for 3+ years producing live-service games or apps. How does your time at the puzzle studio count toward that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Say it at its scope: four years as an associate producer at a puzzle-game studio, and two of them running the weekly content-drop calendar for your main title. Answer slot: if the title was updated after launch, say how you would describe it, in your own words; if it was not, or only partly, say so plainly and stay with the calendar you ran | F5 is a discovery row, so the probe is likely and the answer is yours to supply. JD because it scores the requirement directly |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what the sentence says: monthly, retention numbers, the studio head. Answer slot: say how the numbers were counted, what they are sensitive to, which assumption behind them you would defend least, and which part was yours, each in your own words; where you do not know one, say plainly that you do not | F7 and F3 draw on this one sentence, so it is the magnet for a prober. EXP because it tests what was actually yours |
| C2 | "Which retention measures would you look at first after an event ends, and what does each one tell you?" | JD | [generic] | Name the measures you have actually used and what each shows and misses; for any you have not used, say so plainly and say how you would learn it. No claim about your past beyond what you choose to say | F7 requires comfort with retention metrics; JD because it scores that requirement, with a generic frame |
| C3 | "How would you structure a post-event review for an event that underperformed?" | JD | [generic] | Structure it: what was intended, what happened, the likeliest reasons and how you would tell them apart, what changes next time, and who is told. Say plainly what the review cannot attribute. Answer slot: if you have written or sat in a review of a content drop, say what it covered; if there was none at your studio, say so plainly | F3 includes owning the review. JD because the JD names the review; generic because the structure is a pattern |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in this order: four years as an associate producer at a puzzle-game studio; the last two running the weekly content-drop calendar for your main title; the release checklist you wrote that QA still uses; the monthly retention numbers you presented to the studio head. Then one sentence on why this role, in your own words. Say only what the sentences say | The opener is scored even when it feels casual. EXP because it checks that your story matches the claims |
| D2 | "Tell me about running your content calendar week to week." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Tell it at its scope: weekly, content drops, your main title, two years. Answer slot: if planning what went into each week was yours, say how you decided; if the content was set by others and you ran the schedule, say so plainly | F6 is the cleanest evidence in the pack and a prober will start there. JD because it scores the calendar requirement |
| D3 | "Tell me about the release checklist you wrote." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Two beats, both from the sentence: you wrote it, and QA still uses it. Answer slot: if you also worked releases through it with QA, say how it worked; if QA ran it without you, say so plainly and stay with the checklist. If your studio allows, a blank page of it can show clear writing | F4 and F8 both rest on this sentence. JD because the JD names the checklist and QA |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Design, art, engineering and community each want something different from the schedule. How do you decide whose request moves?" | CASE | [generic] | Propose principles rather than claim a seam: what the update is for, what each team loses by moving, who owns the final call and how it is recorded. Ask who owns that call at Saltmarsh. No claim about your past | F2 names the four teams. CASE because it is a live decision, peer-style |
| E2 | "Which of design, art, engineering and community have you worked with directly on an update?" | JD | [grounded] | The row asks a fact only you hold. Answer slot: say which and what part was yours, in your own words; if none, or if it was not yours, say so plainly and stay with the calendar you ran | F2 has no evidence, so this question must be answered from your memory, not from the pack |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who has run live events on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | Pause and restate. Concede one thing specifically: "I haven't worked on a game with in-app purchases." Hold on what your sentences carry, each at its scope: the weekly calendar, the checklist, the retention numbers. Hold through two follow-ups by returning to them, and do not widen them | Pressure interviewers use the stated gap as the lever. JD because it scores fit against the listed role |
| F2 | "You ran that calendar for two years. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold "I ran it" at the sentence's scope: weekly, content drops, your main title, two years. Answer slot: say which parts of what went into it were yours and which were decided by others; if you do not know how it was split, say so plainly | F6 and F1 rest on this sentence, and attribution probes are standard. EXP because it scores precise attribution |

## Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A2, D2 |
| "coordinate design, art, engineering and community teams on each update" | A4, B3, E1, E2 |
| "own the post-event review and the KPIs it reports" | A3, C1, C3 |
| "manage the release checklist with QA" | D3, A4 |
| "3+ years producing live-service games or apps" | B5, D1 |
| "experience running a content calendar" | D2, F2 |
| "comfortable with player-retention metrics" | A3, C1, C2 |
| "clear written communication" | D3 — one question only, since nothing else in the material shows writing |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first 90 days look like for this producer, and what would you want to have seen by day 30?" | It makes the interviewer state their scoring sheet, and it shows you are planning your ramp |
| R2 | "Of the two titles, which is heavier on the calendar today, and how do their calendars interact when events collide?" | It shows you are thinking about two titles, not one, and the answer shapes how you would sequence work |
| R3 | "How is the post-event review used: who reads it, and what has it changed?" | The review is part of the role, so it asks what the work leads to |
| R4 | "Which KPIs does the review report, and which of them would this role own versus report?" | It separates ownership from reporting, which matters for a candidate new to the studio's metrics |
| R5 | "When a date moves on an update, who makes the call between design, art, engineering and community?" | It asks about decision rights instead of claiming to know them, and prepares you for E1 |
| R6 | "Where do new producers on live operations usually need the most support in their first months?" | It invites a ramp conversation on the interviewer's terms, and shows you plan to learn |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or on its events or revenue KPIs | Negative you stated: "Never led a team, and never worked on a game with in-app purchases." | The plain acknowledgment: "I haven't worked on a game with in-app purchases." A ramp plan is said as a plan, never as a past |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one main title and content drops |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says presenting retention numbers |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says writing the checklist |

## Sources

Provided: the JD text and your background, both in your message.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Search was sent and refused. It would have moved a values cheat sheet and the VAL bank; neither is in this pack |
| 2. Saltmarsh Games interview process | unavailable | Search was sent and refused. It would have moved the persona weights beyond the hiring-manager prior |
| 3. Saltmarsh Games strategy and news | unavailable | Search was sent and refused. It would have moved A5 and grounded the CO and CASE questions in the two titles |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Search was sent and refused. It would have moved an interviewer read and a tailored reverse question; both are absent |
| 5. Representative Live Operations Producer JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

Queries sent, all refused: "Saltmarsh Games mobile studio company values"; "Saltmarsh Games interview process Live Operations Producer"; "Saltmarsh Games news strategy mobile titles"; "Tobias Wrenfield Saltmarsh Games Head of Live Operations".

## Upgrade menu

- Round and relationship (is Tobias your future manager, a skip-level or a peer) → reweights every bank and the persona table
- The recruiter's note on what the 60 minutes will cover, or any task to prepare → a graded-deliverable section if one was announced
- Web search access → Saltmarsh's published values, any documented loop, and recent news, so A5 and the CO questions become grounded and a values bank is added if a values round turns up
- The interviewer's published talks or writing → an interviewer read and a reverse question tied to their path
- Your answers to the slots in F1, F2, F3, F4 and F5 (the teams you worked with, whether your title was live-service, how the retention numbers were defined, how QA used the checklist) → those rows gain quoted evidence and the guidance beside them becomes story-mapped
- A `tuesday-dossier.md` from an earlier evidence review, if you have one → verified evidence and an objection ranking in place of the inferred one in B2
