# Interview pack (loop mode): Engineering Manager, Larkfield Systems

**Candidate:** Yusuf. **Rounds:** Tuesday, 45 min, the hiring manager (a Director of Engineering, your would-be boss). The Thursday after, 60 min, a panel of two staff engineers and a product manager. The following Monday, 30 min, the VP Engineering, described by the recruiter as "values and leadership philosophy". No interviewer names were given.

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each round has its own persona weights, bank and reverse questions. The fit snapshot, prohibited claims, sources and upgrade menu are shared.
- **Type tags:** VAL is behavioral or values alignment. EXP is a deep-dive on your own experience. JD is the stated role. CO is company and strategy knowledge. CASE is a live problem.
- **Guidance is scaffolding, not a script.** Every sentence about your past is one of your own sentences, quoted. Where your material stops, the guidance holds an **answer slot**: an instruction for the interview with two honest branches. If you did the thing, say how, in your own words. If you did not, or it was not yours, say so plainly and return to what you did say. The second branch is a limit, not a confession.
- **Highest-ROI prep in the pack: TA1**, the hardware-roadmap gap. It arrives from the Director on Tuesday and returns in collegial form from the panel (PA3, PC2) and in time-boxed form from the VP (VB1). Rehearse it until it is boring.
- **Research was not available.** The web searches were refused in this session, so the pack holds nothing about Larkfield's values, strategy or hiring process beyond your own words. The company-knowledge question (VC2) is generic for that reason, and there is no values cheat sheet.

## Fit snapshot (shared)

Requirements come from the role description in your message. Quotes are yours.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description, your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | medium | [grounded] | transferability | Your material says a team lead of 6 for 3 of 9 years, at a payments company. It does not say two squads or device management, and you have said you have never managed managers. Words: "I've never managed managers." Then the scope your quote carries: 3 of my 9 years in engineering have been as a team lead of 6. Answer slot: the role's two squads make a probe on leading more than one team likely. If any of your work covered more than the team of 6, say what. If not, or it was not yours, say so plainly and stay with the team of 6 |
| F2 | "own delivery, hiring and growth for 11 engineers" — role description, your message (delivery) | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | Your quotes carry a team of 6 against the role's 11, and one reliability quarter pushed through against roadmap pressure, with nothing inspected behind either. Words stay at that scope: "I pushed a reliability quarter through against roadmap pressure." Answer slot: "own delivery" makes a probe on how you committed to and tracked delivery likely. If you did, say how, in your own words. If someone else did, or there was no set way, say so plainly and stay with the quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" — role description, your message (hiring) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | No gap in terms, but a self-reported line with a figure, so expect a probe. Lead with the quote's terms: you run the loop for backend roles. The figure comes second. Defend-the-number slots, in your own words: how the 40 was counted, whether they were interviews you conducted or the loop's total, the assumption you would defend least, and which part was yours. Where you do not know, say so plainly. The quote says backend roles, so the pack makes no claim about other disciplines |
| F4 | "own delivery, hiring and growth for 11 engineers" — role description, your message (growth) | none given | none | [grounded] | discovery | Your material says nothing about developing engineers. Answer slot: if you have helped anyone grow in their work, say what you did and what part was yours. If not, say so plainly and say what you would do first in the role, as a plan and not a past |
| F5 | "partner with hardware and product on roadmap" — role description, your message (hardware) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | You stated the absence, and nothing wording can do closes it. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, as a plan and never a past. The pack's observation is that your statement is about owning, the role says partner, and your material is silent on whether you have worked alongside hardware. Answer slot: if you have worked alongside a hardware team, say what the contact was. If not, say so plainly |
| F6 | "partner with hardware and product on roadmap" — role description, your message (product) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | discovery | The quote carries roadmap pressure and a reliability quarter. It does not say who the pressure came from or whether product was a party. Answer slot: if the pressure came from product, say what the exchange was and what part was yours. If it came from elsewhere, or no product partner was involved, say so plainly and stay with the quarter |
| F7 | none in the role description; the headline figure in your own message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | none | No gap in terms, but the likeliest figure to be probed. Keep the quote's order: the burden dropped "after" the quarter, so say "after" and add no cause. Defend-the-number slots, in your own words: how the 60% was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Where you do not know how it was counted, say so plainly |
| F8 | "values and leadership philosophy" — the recruiter's description of the VP round, relayed in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | low | [inferred] | transferability | The only leadership decision in your material is the reliability quarter. A philosophy is a principle and the quote is one decision. Answer slot: if there is a principle you would name from that quarter, say it in your own words. If it was a one-off call and not a principle, say so plainly and say how you would approach a similar choice |

No requirement in the material is a gate (a term such as location, pay, schedule or a credential), so there are no gate rows.

## Round 1 — Tuesday: the hiring manager (45 min)

**Persona weights.** Relationship prior for a hiring manager: Case/Strategist and Skeptic. The Skeptic moves to the top because two limits you stated (F1, F5) sit directly on the role's own lines. Prober, Peer and Pressure appear in later rounds.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (3 questions) | Quiet, persistent probing of hardware, managers and "why now" | Highest. The Director would be your boss and is buying capability while limiting risk. F5 and F1 are your own stated gaps and the role description names both areas | Rehearse TA1 until it is boring. Concede only in the words you stated. Return to your quotes and never add to them |
| Case/Strategist (3 questions) | Live problems from the role: take over two squads, a hardware slip against a product date | High. This is the hiring-manager prior, and the role description is operational | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Conversational (2 questions) | "Walk me through the journey", hiring chat | Lower. A 45-minute first conversation with a boss usually opens this way, and the casual questions are still scored | A 90-second arc built from your quoted sentences |

### Skeptic (TA)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| TA1 | "You haven't owned a hardware-adjacent roadmap, and this role partners with hardware and product on roadmap. Where does that leave you on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure."; "9 years engineering, 3 as a team lead of 6, currently at a payments company." | The deepest rehearsal in the pack. Concede first, in your stated words: "I've never owned a hardware-adjacent roadmap." Then hold only what the quotes carry: "I pushed a reliability quarter through against roadmap pressure." Say what you did and let the Director draw any inference; do not say it shows you can partner with hardware. Follow-up one, "that's software, not hardware": agree, and give a plan, never a past. Say what you would ask someone on the hardware side in your first week, in your own words. Follow-up two, "how much of your first quarter is catching up": concede the uncertainty specifically, say what you would not yet know, and do not fold on the team of 6 you have led. Answer slot: the role's "partner with hardware" makes a probe on any working contact with hardware likely. If you have worked alongside a hardware team, say what the contact was. If not, say so plainly and return to the quarter | F5 is your stated gap and the role's partnership line presses on it, so this is the objection most likely to arrive in some form. JD because it scores a stated requirement, and Skeptic because it probes the gap quietly. It is named the highest-ROI prep because it recurs across all three rounds |
| TA2 | "You've never managed managers, and this role has you leading two squads and 11 engineers. What changes for you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap."; "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Concede in the stated words: "I've never managed managers." Then the scope your quote carries: 3 of your 9 years as a team lead of 6. Do not call the step small or large; the pack does not know how the two squads are structured, so ask the Director (R-T1). Answer slot: if any of your team lead work covered coordinating other leads or more than the team of 6, say what. If not, or it was not yours, say so plainly and stay with the team of 6. Hold through two follow-ups by returning to the quote's scope, never by widening it | F1 is where the role's two squads and 11 engineers outrun your quotes. JD because it scores the first requirement, Skeptic because it asks you to price your own gap |
| TA3 | "Why industrial IoT, why this role, and why now?" | JD | [generic] | A selection scaffold, because your material carries no reason for the move and the answer has to be yours. Pick one part of the role description that actually draws you and say why that part and not the others: "Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap." One specific reason beats three. If no single part draws you, say so plainly, then say what you are looking for in a next role. Expect it twice in different words; keep the reason the same | Motivation consistency is the Skeptic's core score. JD because the answer must point at the stated role, and generic because it makes no claim about your past |

### Case/Strategist (TB)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| TB1 | "You take over two squads and 11 engineers. What do you need to know first, and what do you do in your first 30 days?" | CASE | [generic] | Clarify before structuring. Ask how the work divides between the squads, what each is committed to deliver and to whom, where the hardware dependencies sit, and how each engineer is doing. Then objective, segmentation (delivery, people, hardware and product relationships), approach, metrics, risks. State assumptions as assumptions, not as Larkfield's facts. Challenge one premise respectfully, for example whether the first 30 days are for changing things or for listening. The question needs no claim about your past, so the guidance makes none | A hiring manager asks for a live problem on the role's own first lines (F1, F2, F3, F4). CASE because it scores structure, and generic because no company facts were available |
| TB2 | "Hardware tells you a firmware release your next quarter depends on will slip, and product wants to hold the date. Talk me through it." | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Clarify first: what exactly depends on the release, what is movable, who owns the date on each side. Then options: resequence work that does not depend on it, descope, re-date with product, a partial release. Say what you would tell the squads and name the decision you would not take alone. Think aloud. If you reach for your quarter, say it as you said it, "I pushed a reliability quarter through against roadmap pressure", and do not present it as a hardware precedent | The role's hardware and product partnership (F5, F6) turned into a live problem on the hiring manager's own roadmap. CASE with a JD flavor |
| TB3 | "Tell me about the reliability quarter on your team." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the beats the quote states, in your own words: the on-call burden, a reliability quarter, pushing it through against roadmap pressure, and the 60% drop after it. Answer slot: the role's roadmap partnership makes a probe on how the pressure was handled likely. If you worked it out with product or others, say how and what part was yours. If it was settled another way, or not in any set way, say so plainly and stay with the quarter. Keep the 60% to "after", never "because"; its full rehearsal is PB1 | F2 and F7 are the one story your material carries, so it is the story the Director is likeliest to ask for. EXP because it tests what was actually yours |

### Conversational (TC)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| TC1 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company."; "I run our hiring loop for backend roles — about 40 interviews last year." | A 90-second arc on beats the quotes state, in your own words: 9 years in engineering, 3 of them as a team lead of 6, currently at a payments company, and running the hiring loop for backend roles. End on why this role, which is yours to say (the TA3 scaffold). A casual opener is still scored | F1 and F3 supply the arc. EXP because it tests whether your biography holds together |
| TC2 | "You run hiring where you are. How do you decide who's right for a team?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Open on the quote: "I run our hiring loop for backend roles." Answer slot: the role's "own ... hiring" makes a probe on how you decide likely. If you have a consistent way, say what it is in your own words. If the decision rests with others, or you have no set way, say so plainly and stay with running the loop. If asked about the figure, see PB2 | F3 is your strongest requirement match, so a Director gives it a casual opening and then probes it. EXP because it tests how you decide, not only that you hire |

**Reverse questions, Tuesday** (R-T)

| # | Question | Why it lands |
|---|---|---|
| R-T1 | "How are the two squads structured today: do the 11 engineers report to the role directly, or through leads?" | The role description does not say, and the answer tells you how far your stated "never managed managers" matters |
| R-T2 | "How does the roadmap get set between engineering, hardware and product, and where would this role sit in that?" | It shows you are already thinking about the part of the role you have not owned (F5), and it turns the gap into a working question |
| R-T3 | "What would you want this role to have changed or learned by the end of the first quarter?" | It asks for the Director's real scorecard and gives you something specific to answer against |
| R-T4 | "Is this a new role or a backfill, and what did the squads most need from it?" | It gets the context behind the vacancy and shows you are scoping the job, not just the title |
| R-T5 | "What does hiring and growth look like for these squads right now: open roles, and where engineers want to develop?" | It covers two of the role's three named responsibilities (F3, F4) and shows you will ask about the people side |

## Round 2 — the Thursday panel: two staff engineers and a product manager (60 min)

**Persona weights.** Panel rule: blend the top two personas of each member's relationship. Names were not given, so this is assigned by role. The staff engineers get Prober and Peer. The product manager gets Peer and Conversational (cross-functional). Peer leads because all three people's work would change with this hire. Prober is close behind, since staff engineers are the likeliest to test depth.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (3 questions) | Seam-splitting between you and the staff engineers, "what do you need from me", credit and disagreement. Objections from Tuesday return in collegial form | Highest. All three would work beside you daily, and the hardware and product gaps (F5, F6) come back here as questions about partnership | Reciprocity first: what you bring them, then what you need. Offer seam principles, not a pretended knowledge of their seam |
| Data-Driven Prober (3 questions) | Inputs and denominators on the 60% and the 40 interviews, and a technical-judgement case near device management | High. Two staff engineers read for detail, and both figures are headline metrics (F3, F7) | Say what you can and cannot say about how each figure was counted. Name the weakest assumption before they do |
| Conversational (2 questions) | A product manager's friendlier questions on working with product | Lower. A cross-functional interviewer often opens casually, but the answers are still scored | Treat each as scored. Use your own words and your quoted sentences only |

### Peer Evaluator (PA)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| PA1 | "Where's the line between what an engineering manager decides and what the staff engineers decide, and what happens when we disagree?" | CASE | [generic] | Propose seam principles rather than pretend to know their seam. Ask how decisions are made today. Then offer principles in your own words: who is accountable for each kind of decision, what gets written down, how a disagreement escalates and when it does not need to. Say what you need from them and what they get from you. It is a method; the guidance makes no claim about a past disagreement. If they ask for a real example, use the PA2 scaffold | The peer prior, applied to staff engineers whose technical authority overlaps the role (F1, F2). CASE because it asks for a live structure |
| PA2 | "How do you handle credit when work spans teams? Tell me about a time." | EXP | [generic] | A selection scaffold. Pick a time work crossed teams and you had to say who did what; it needs a named piece you did, a named piece others did, and an intact relationship afterwards. "We" for context, "I" for contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for the peer. EXP because it tests attribution honesty, and generic because no quoted sentence carries a story here |
| PA3 | "Product and engineering disagree about what goes in the quarter. What do you need from me as the PM, and what do I get from you?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Reciprocity first, as a method and not a past: what you would bring the product partner, such as early notice of delivery risk and a clear account of what the squads can commit to. Then what you need: how priorities are decided and who decides. Answer slot: if the roadmap pressure in your reliability quarter came from product, say how you handled it with them and what part was yours. If it came from elsewhere, or no product partner was involved, say so plainly and leave the quarter out | F6 is the role's product-partnership line and the stated hardware gap (F5) returns here as the PM's concern. CASE because it is a live seam problem |

### Data-Driven Prober (PB)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| PB1 | "Your on-call burden dropped 60%. Walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The defend-the-number rehearsal, four slots, each in your own words: how the 60% was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Where you do not know how it was counted, say so plainly; that is an honest branch. Keep the quote's order: the burden dropped "after" the quarter. Say "after", and do not say "because" unless you can say how you know. Name the weakest assumption before they do | F7 is the headline figure, and quantified claims are the first thing a prober tests |
| PB2 | "About 40 interviews last year. Yours, or the loop's? How was that counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Four slots again, in your own words: whether the 40 were interviews you conducted or the loop's total and how they were counted, what the figure is sensitive to, the assumption you would defend least, and which part was yours. Say "about", as you did, and say plainly what you do not know exactly. Start from the quote: "I run our hiring loop for backend roles." | F3's figure has no stated denominator, so a prober asks which kind of interview it counts |
| PB3 | "Devices in the field need a software update, and some are offline. What do you want to know before we agree a plan?" | CASE | [generic] | A probe of how you think near the domain, not a test of device-management knowledge you have not claimed. The pack's observation: your material names a payments company and does not mention device management. Clarify before structuring: what happens to a device that fails the update, how a bad release is stopped and reversed, who owns the firmware side, what "done" means for the fleet. Think aloud, name what you would defer to the engineers on, and say plainly where you would need to learn | The role description's "device-management services" (F1) makes a domain-adjacent case likely from staff engineers. CASE because it scores clarifying questions over the right answer |

### Conversational (PC)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| PC1 | "Tell me about working closely with a product partner." | EXP | [generic] | A selection scaffold. Pick a time you worked through a decision with a product partner; it needs a named decision, what each side wanted, and how it ended between you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Where it overlaps the reliability quarter, the F6 slot applies | The role's product partnership (F6) is a likely casual question from a PM. Generic because your material names no product partner |
| PC2 | "Tell me about a time you held a line against roadmap pressure." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Story-mapped on the beats the quote states: a reliability quarter, roadmap pressure, you pushed it through, and the burden dropping 60% after it. Answer slot: if anything was deferred to make room, say what and how product responded. If nothing was formally deferred, or you do not know, say so plainly and stay with the quarter | The PM will hear this quote from the other side: what product gave up. F2 and F6 are the rows involved |

**Reverse questions, panel** (R-P)

| # | Question | Why it lands |
|---|---|---|
| R-P1 | To the staff engineers: "Where do you want an engineering manager to stay out of technical decisions, and where to step in?" | It turns the seam question (PA1) into their answer and tells you their expectations |
| R-P2 | To the staff engineers: "What is the biggest recurring friction between the squads and hardware?" | It shows you are already working on the part of the role you have not owned (F5) |
| R-P3 | To the product manager: "How do you want to hear about delivery risk, and how early?" | It is the reciprocity move, putting their working need first |
| R-P4 | To all three: "What could a new engineering manager do in their first month that would genuinely help your work?" | The peer reciprocity question; it shows you are pricing what you can give them |
| R-P5 | "How are on-call and reliability work handled on these squads today?" | It connects to the one story you carry (F7) and invites them to tell you where the real pain is |

## Round 3 — the following Monday: the VP Engineering (30 min)

**Persona weights.** The skip-level prior is Case/Strategist plus Pressure. The recruiter's description, "values and leadership philosophy", documents a values-style round, so Values/Behavioral goes to the top. Thirty minutes with a VP is short, so Pressure is next: expect time-boxed answers and interruptions.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (3 questions) | Scenario and story probes on how you lead | Highest. The recruiter's own words name it. No published Larkfield values were available, so these stories are not mapped to named values | Choose stories where the hard truth landed, and where your material shows none, say so rather than supplying an ending |
| Pressure (3 questions) | A sixty-second "why you", "how much was actually you", being overruled | High. Skip-level prior and a short slot. Your two stated gaps are easy targets for a time-boxed challenge | Pause, restate, answer in order. Hold through two follow-ups, concede specifically, and never fold on a quote |
| Case/Strategist (2 questions) | A short altitude question on two squads, and what you know about the company | Lower. The recruiter's framing points at values, but a VP asks strategy questions in any case | Clarify, choose, give a reason, and keep it brief |

### Values/Behavioral (VA)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| VA1 | "What's your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The VP listens for a principle you can show, not a slogan. Your material carries one decision: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if there is a principle you would name from that quarter, say it in your own words. If it was a one-off call and not a principle, say so plainly and say how you would approach a similar choice. Describe what you did and let the VP draw the inference; do not say what the quarter was proof of | F8 is the recruiter's own description of this round. VAL because it scores values and leadership, though no published Larkfield values were available to map to |
| VA2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold. Pick a time you told someone senior something they did not want to hear; it needs a named stake, a moment you did not soften it, and an intact relationship at the end. Whether the reliability quarter involved leadership is yours to say; the pack does not know. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for the values interviewer. The F8 row holds no story that carries it, so the scaffold is the honest form |
| VA3 | "You'd own hiring and growth for 11 engineers. How do you think about each?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Hiring: start from "I run our hiring loop for backend roles" and let the rest be your own words on what you look for. Answer slot: if you have a consistent way of deciding, say it. If not, say so plainly. Growth: your material says nothing on developing engineers. Answer slot: if you have helped someone grow in their work, say what you did and what part was yours. If not, say so plainly and say what you would do first in the role | F3 and F4 are two of the role's three named responsibilities. JD because it scores the stated role, and the VP's leadership lens makes the people side likely |

### Pressure (VB)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| VB1 | "Sixty seconds: why you, and not someone who has already managed managers or owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap."; "9 years engineering, 3 as a team lead of 6, currently at a payments company."; "I run our hiring loop for backend roles — about 40 interviews last year."; "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause, restate the question, then answer in order. Concede first and specifically: "I've never managed managers and never owned a hardware-adjacent roadmap." Then hold what the quotes carry at their scope: 3 of 9 years as a team lead of 6, you run the hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Do not widen any of them. Hold through two follow-ups by returning to those sentences, concede uncertainty on what the material does not show, and never fold on what it does | The TA1 objection in time-boxed form (F1, F5). Pressure scores composure, and JD scores the stated requirement |
| VB2 | "That reliability result. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Hold then concede. Hold what is yours in the quote's words: you pushed the quarter through. Concede specifically: the drop came "after" it, and unless you can say how you know the quarter caused it, say plainly that you do not know how much of the 60% was the quarter. Answer slot: which parts of the work were the team's, in your own words. If you do not know the split, say so plainly. Do not claim the drop | F7 and F2 are the attribution probe's target, and the persona stem asks it directly. EXP because it tests what was yours |
| VB3 | "Tell me about a time you were overruled on a roadmap decision." | EXP | [generic] | A selection scaffold. Pick a time a decision on the roadmap went against you; it needs the decision, who made the call, what you did next, and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The role's roadmap partnership (F5, F6) turned into a behavioral probe. Generic because no quoted sentence carries it |

### Case/Strategist (VC)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| VC1 | "Two squads, 11 engineers, hardware and product both pulling on the roadmap. What's the first thing you'd protect?" | CASE | [generic] | A short case in a short round. Clarify what is most fragile, whether that is delivery, people or the partnerships. Pick one, give your reason, and say what you would trade for it. Keep it to what you can say in under two minutes. The question asks for no claim about your past, so the guidance makes none | The role's whole scope (F1, F2) put at altitude. CASE because it scores a choice and its reasoning |
| VC2 | "What do you make of where Larkfield is as a company right now?" | CO | [generic] | The pack has no research on Larkfield, because web search was not available, so it supplies no facts. Before Monday, read the company's own site and careers page and bring two or three things you verified yourself, said as what you read and where. Where you could not verify something, say what you would want to learn. Do not repeat a claim you cannot source | A VP checks altitude and homework. CO because it scores company knowledge, and generic because the research did not run. The upgrade menu says what would change that |

**Reverse questions, VP** (R-V)

| # | Question | Why it lands |
|---|---|---|
| R-V1 | "What does a good first year look like for an engineering manager here, in your view?" | It asks for the VP's scorecard in the VP's own terms |
| R-V2 | "What leadership habit do you most want managers here to have?" | It answers the recruiter's "leadership philosophy" framing from their side and gives you their vocabulary |
| R-V3 | "How does engineering decide between reliability work and new features across the company?" | It connects to the one story you carry (F7) without retelling it |
| R-V4 | "What is something you have changed your mind about as a leader recently?" | It invites a candid answer and signals you want a real conversation, not a rehearsed one |
| R-V5 | "How do you support managers who are new to a part of the business, such as hardware?" | It names your own stated gap (F5) as a question about support, and shows you plan to ask for it |

## Requirement coverage (shared)

| Requirement | Question IDs |
|---|---|
| "Lead two squads building device-management services" | TA2, TB1, PB3, VC1, VB1 |
| "own delivery ... for 11 engineers" (delivery) | TB1, TB3, PC2, VC1 |
| "own ... hiring ... for 11 engineers" (hiring) | TC2, PB2, VA3 |
| "own ... growth for 11 engineers" (growth) | VA3, with R-T5. One question only, because the role description says nothing more about growth |
| "partner with hardware and product on roadmap" | TA1, TB2, PA3, PC1, VB1, VB3 |
| "values and leadership philosophy" (VP round) | VA1, VA2, VB2 |
| Headline figures in your message (the 60% and the 40 interviews) | TB3, PB1, PB2, VB2 |
| Company knowledge | VC2, generic: none grounded, because the research did not run |

## Prohibited claims (shared)

What this pack will not coach, and why. It was built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F1 | The plain acknowledgment: "I've never managed managers." No slot |
| Owned or shaped a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot on ownership. F5's separate slot asks only whether you have worked alongside hardware |
| Led two squads or 11 engineers | Inflated form of F1 and F2 | The quote at its own scope: "9 years engineering, 3 as a team lead of 6". The limit is the pack's observation: the material says a team of 6, not two squads |
| The reliability quarter caused a 60% cut in on-call burden | Inflated form of F7 | The quote at its own scope: the burden "dropped 60% after" the quarter. The slots ask only how the figure was counted and how much was yours |
| Decided who gets hired, or owns hiring beyond the loop | Inflated form of F3 | The quote at its own scope: "I run our hiring loop for backend roles". The slots ask only how the 40 was counted and which part was yours |

## Sources

**Provided documents:** your message in this conversation (the role description, the three round descriptions, and your background sentences). No tuesday-dossier.md was present.

**Searches sent, all refused (the host did not grant permission to search):**

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT strategy news" — refused
- "Engineering Manager device management platform industrial IoT job description" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Would have fed a values cheat sheet and mapped the VAL questions to published value names. Section dropped; VA1 to VA2 stay generic |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Would have confirmed loop structure and case formats. Your own words establish the three rounds and who runs each, so the persona weights stand on them |
| 3. Larkfield Systems strategy and recent news | unavailable | Would have grounded a CO or CASE question in current strategy. VC2 stays generic |
| 4. Interviewer name and Larkfield | n/a | No names were given, so there was no query to form. There is no interviewer read |
| 5. Representative Engineering Manager JD | unavailable | Would have turned the role description's three lines into a fuller requirement list for the JD-tagged questions |

## Upgrade menu

- Web search permission, or Larkfield's values page and a recent strategy summary pasted in → a values cheat sheet with each VAL question mapped to a published value name, CO and CASE questions grounded in current priorities, and VC2 becoming grounded
- A deeper research pass, offered once → up to 6 more searches and 2 more fetches, several more minutes, covering the strategy brief, interviewer talks and writing, role-family loop reports and recent org context; it needs search permission and your yes
- The full JD text → the three role-description lines become the whole requirement list, any mid-list item gets its own row and question, and the coverage table is rechecked against it
- Your CV → F4 and F5 could gain quoted evidence, and F2, F3 and F7 firm up where it carries more than your message did
- An inspectable artifact for the 60% (for example the on-call paging or incident dashboard export for that period, or the quarter's retrospective) and for the 40 interviews (for example the hiring loop's scorecards or calibration log) → F3 and F7 move from medium to high confidence
- The interviewers' names and titles → an interviewer read, persona weights tuned per person, and a reverse question tied to each person's own path
- The recruiter's focus areas or format notes for each round, usually one email → coverage assumed from round-type priors becomes grounded, and any pre-declared exercise gets its own build section
- Your answers to the answer slots in F1, F2, F4, F5 and F6, in your own words → those rows regenerate with your sentences, and the guidance that draws on them with them
- A tuesday-dossier.md from a separate job-underwriter pass → verified evidence and allowed strategies per weak area, in place of the gaps this pack inferred from your message
