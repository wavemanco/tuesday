# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Round:** hiring-manager conversation, 45 minutes, Thursday. Interviewer name not given.
- **Built from:** your `tuesday-dossier.md` (decision `conditional_go`: bridge positioned as adjacent, never as PM experience; squad authority to verify in the interview).
- **Persona weights rest on:** your own description of the round and the relationship priors. No Quartzline loop source was read (Sources).

## How to use this pack

Personas describe how a question arrives; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Past behavior against the company's published values. None in this pack: no values source was read |
| EXP | Whether a claim about your experience survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy. None in this pack: the research that would ground it was refused |
| CASE | Structure and reasoning on a live problem from the role |

Answer slots (instructions ending without a question mark) are for the interview, not for this chat. Meet one by taking either branch honestly, from your own experience. Bank letters skip F so that bank IDs cannot be confused with the fit rows F1 to F9.

## Prep triage (Thursday)

1. **A1, aloud, until it is boring.** The underwriter named this objection; it will arrive in some form.
2. **C1 and E2.** Your 30+ integrations figure and what part of it was yours.
3. **C3.** The roadmap-input sessions carry a medium-confidence limit; say it before you are asked.
4. **A4 and A5.** The two slots where your material is silent or thin.
5. **Reverse questions 1 and 2.** They answer the two risks the dossier left open.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the dossier's `role_profile`. Evidence is quoted from `handoff_to_mock_interview.verified_candidate_evidence`; the confidence notes the dossier appended to those entries are not part of the quotes and sit in the Confidence column and the bridge. Rows F1 and F2 carry the dossier's own grading. The others are this pack's grading, because the dossier named no strategy for them, and are labelled `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | low | [grounded] | transferability | Dossier strategy: bridge. Words, each at its quote's own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation: the quotes show integration leadership and input to product, not a product manager title or role. The second quote is confirmed with limited inspectable proof, so volunteer that it rests on your account before a prober finds it. Never offered as PM experience |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this (R1 sub-claim, `allowed_interview_strategy: acknowledge_gap`, confidence none) and lists `prohibited_claims` "Having owned a product roadmap" and "Having set prioritization for an engineering squad". Words: "I haven't owned a roadmap, and I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan and never as a past: "I'd start by learning how roadmap decisions are made today, and where the squad leads' calls end and mine begin." No bridge |
| F3 | "Shipped API or platform products" — dossier role_profile R2, must_have | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | low | [inferred] | discovery | The dossier gave this requirement no strategy. The pack's observation: your material says integrations of the vendor's REST APIs, not the shipping of the API itself, and the words stay at the quote. Answer slot: expect a probe on which of the stages in that sentence were yours; if some were shared or someone else's, say which; if the requirement's wording does not fit the work you did, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3, important | "Wrote the internal integration playbook her team uses" — dossier verified evidence 2; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | medium | [inferred] | discovery | The playbook is the dossier's one inspectable artifact: have it to hand. Words: "I wrote the internal integration playbook my team uses." Neither quote says whether API docs or schemas were part of it. Answer slot: expect a probe on API docs and schemas; if you read, wrote or reviewed them in that work, say which and how; if that work did not involve them, say so plainly and stay with the REST integrations and the playbook |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4, important | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [inferred] | transferability | The quotes show clients and product. The pack's observation: they do not show sales or engineering stakeholders. Words stay at the quotes' scope. Answer slot: the requirement names engineering and sales; if you worked with either in that work, say who and about what; if you did not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — dossier role_profile R5, preferred | none given | none | [grounded] | discovery | Dossier strategy: clarify. No verified entry speaks to this requirement, so nothing is quoted for it. Answer slot: expect a probe on agile delivery inside a product org; if you worked that way, say how, in your own words; if you never did, say so plainly, then say what you would want to confirm about how Quartzline's squads define it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified evidence 3 | medium | [inferred] | transferability | The quote is input sessions feeding product, which is adjacent to discovery and not the same work, and the words stay at the quote. Answer slot: expect a probe on how you learned what partners needed; if you set up conversations with them to find out, say what and how; if the evidence reached you some other way, or you only passed it on, say so plainly and stay with the sessions |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified evidence 1 | low | [inferred] | discovery | The sentence touches requirements and go-live inside client integrations and does not show whether engineering squads were involved. Answer slot: expect a probe on whether you have written specs for engineers; if you did, say for what and with whom; if you did not, say so plainly and describe how you would take a request to a spec as a plan |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | The dossier's unknowns say adoption is named as a responsibility with no baseline stated. Answer slot: if you defined or tracked any partner-facing measure, say what was counted; if you did not, say so plainly, and say you would first ask how adoption is measured today and what the baseline is |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title and roadmap gap, then the thin requirements | Highest. Hiring-manager prior; the dossier names the objection; F2 is a recorded gap | Rehearse A1 until boring; concede specifically, hold on what the quotes carry, close with a plan | A (5) |
| Case / Strategist | Live problems from the real job: a roadmap call, adoption, a partner conversation | Highest. Hiring-manager prior: they are buying capability on the actual roadmap | Clarify, objective, segmentation, approach, metrics, risks; say the structure aloud; ask who decides | B (5) |
| Data-Driven Prober | Goes line by line through the 30+ figure and the sessions | Medium. F1 carries a headline figure and a medium-confidence claim; the role owns adoption metrics | Know what you can and cannot say about how the figure was counted; say plainly when you do not know | C (3) |
| Conversational | Opening biography and why-this-role, in a friendly register | Medium. A 45-minute conversation opens this way; casual questions are still scored | A 90-second arc built from your quoted sentences only | D (3) |
| Pressure | Time-boxed challenge on why you over a PM with the job's years | Lower. The hiring-manager prior favours Skeptic and Case; A1's follow-ups already carry the pressure | Hold through two follow-ups; concede the sourced gaps specifically; never fold on the quotes | E (2) |
| Peer Evaluator | The seam with the two squad leads, and how credit is shared | Lower. Not a peer round; the dossier's unknown on squad authority makes the seam question likely | Propose principles for the seam; do not pretend to know it; ask who decides | G (2) |
| Values / Behavioral | Scenario probes against published values | Low. No loop source documents a values-style round, and no values page was read | None built; revisit if the recruiter names a values round | none |

## Question banks

Quotes used in Provenance, exactly as in the fit snapshot: Q1 is "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; Q2 is "Wrote the internal integration playbook her team uses"; Q3 is "Ran quarterly roadmap-input sessions feeding client evidence to product". The cells below write each quote out in full, because a reference to Q1 is not a quote.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims: "Having held a product manager title or role"`; `prohibited_claims: "Having owned a product roadmap"` | **Highest-ROI prep in the pack; the underwriter named this objection, and both negatives in it come from the dossier fields cited here.** Beat 1, concede first and plainly: "I haven't held a product manager title or role, and I haven't owned a roadmap." Beat 2, what you carry, at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live," and "I ran quarterly roadmap-input sessions feeding client evidence to product." Name the limit before it is asked: the second is input to a roadmap, not ownership of one, and it rests on your account rather than a document. Beat 3, a plan said as a plan: learn how decisions split with the two squad leads and how adoption is measured today. Follow-up 1, "input is not ownership": agree, and return to the quote. Follow-up 2, "a PM with three years has made these calls": hold by returning to the quotes, concede the roadmap and prioritization calls specifically, never claim equivalence. Follow-up 3, "so why take the risk": answer with the plan and one of your reverse questions. Never describe the integration work as product management, and never say what the work "shows" | Bridge on F1 and acknowledge_gap on F2, as the dossier set them. Asked as the underwriter wrote it; JD because it scores R1 directly |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] `prohibited_claims: "Having owned a product roadmap"`; `prohibited_claims: "Having set prioritization for an engineering squad"` | Name the sourced gaps first: "I haven't owned a roadmap, and I haven't set prioritization for an engineering squad." Then the plan from F2 in one sentence. If you want a second item, take the agile question from A5 and say what you would want to confirm. Do not list gaps the dossier does not record, and do not volunteer a bridge on roadmap ownership | F2 and F6 are the recorded gaps; the skeptic persona asks this to test calibrated candor. JD because it is scored against the listed job |
| A3 | "How would you earn credibility with the two engineering squads in your first month?" | JD | [generic] | A plan, with no claim about your past. Ask who decides what before proposing anything; learn what each squad is carrying; bring the partner evidence you have into their planning and let them judge it; agree how you will disagree. Say that the authority split is something you would confirm rather than assume | The dossier's unknown on decision authority versus the squad leads makes this the natural seam question for a skeptical manager. JD because the squads are in the listed job; `[generic]` because it is a pattern |
| A4 | "Tell me about a time you worked on getting an API or platform product into customers' hands." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3: the integrations, in the quote's own words, and the stages the sentence lists. Answer slot: expect a probe on which of those stages were yours; if some were shared or someone else's, say which; if the requirement's wording does not fit the work you did, say so plainly and stay with the integrations. Hold the quote's scope through follow-ups and add nothing to it | F3 is a must-have with no strategy from the dossier, and the likeliest place a quote gets stretched. An open prompt from the JD's requirement; JD because it scores R2 |
| A5 | "How has delivery been organised in the teams you've worked in?" | JD | [grounded] | No quoted sentence speaks to this, so nothing about your past goes in the answer. Answer slot: the JD asks for agile delivery experience, so expect a probe on it; if you worked that way, say how, in your own words; if you never did, say so plainly; then say what you would want to confirm about how Quartzline's squads define it | F6 is a `clarify` area: the evidence may exist and was never established. JD because it scores R5 |

### B. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner says a missing endpoint is blocking their launch, and two other partners haven't mentioned it. How do you decide whether it earns a place on the roadmap — what do you need to know first?" | CASE | [generic] | Clarify first: how many partners are affected, what it blocks, the workaround, the cost to the squads. Then objective, options, how you would weigh them, the metric you would watch, the risk. Name who you would take the call to and say you would confirm where the decision sits rather than assume it. The question needs no claim about your past, so the guidance makes none | F2 is the recorded gap, and a hiring manager tests it with a live roadmap call. CASE because it is delivered as a live problem, `[generic]` because it is a pattern |
| B2 | "How would you tell whether partner adoption of the API is healthy, and what would you measure first?" | JD | [grounded] | Start where the role starts: ask how adoption is measured today and what the baseline is, since the dossier lists neither. Then propose a first measure in your own terms, say what would make you distrust it, and how you would check it. This is a plan, not a past | F9 raises adoption metrics as a responsibility with no baseline. JD for the responsibility, CASE in delivery |
| B3 | "A sales lead has promised a partner a feature the squads haven't scoped. What do you do?" | CASE | [generic] | Structure: separate the commitment from the request; find out what was actually said and to whom; bring in the squad leads before you answer anyone; set what you can and cannot confirm; decide how the next such promise gets routed. No claim about your past | F5 names engineering, sales and customers, and the material shows only clients and product, so a live case on the missing sides is likely. CASE; `[generic]` |
| B4 | "You have an hour with a partner's engineering lead who has just finished integrating. What do you ask?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Structure the hour: what they were trying to do, where they got stuck, what they would change, what they would not tell sales. If you draw on your own work, say it in the quote's words and stop there. Answer slot: the JD asks you to run discovery with integration partners, so expect a probe on whether you have done this; if you have, say how, in your own words; if you have not, say so plainly and describe the plan | F7 is a transferability row; this tests the discovery responsibility live. CASE with JD content |
| B5 | "A schema and its docs page change for a partner-facing endpoint. What do you check before calling it ready for partners to build on?" | JD | [generic] | Structure, in your own terms: does the schema match the docs; what breaks for existing integrations; how the change is versioned and announced; what a partner would try first. Add nothing about your past. If asked how you know this, answer from F4's answer slot | F4 covers R3, technical fluency, which is a mid-list requirement and easy to leave unrehearsed. JD scored through a CASE delivery |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "30+ client integrations — walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The number counts client integrations, so keep it attached to that noun. Answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. "I don't know exactly how that was counted" is an honest branch. Do not supply a method, a baseline or a period you did not give | The one headline figure in your material, so a magnet for a prober. EXP because it scores attribution |
| C2 | "Adoption is a named responsibility here. What would your first metric be, and what would make you distrust it?" | JD | [generic] | Name one measure in your own terms and the assumption behind it that you would defend least, before the interviewer does. Ask for today's baseline before committing to a target. A plan, not a past | F9 plus the weakest-assumption move the prober rewards. JD, CASE in delivery |
| C3 | "Tell me about the quarterly roadmap-input sessions — who was in the room, and what happened to the evidence you brought?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Beats at the quote's own scope: quarterly sessions, client evidence, going to product. Volunteer the limit first: this one rests on your account, with little you can show. Answer slot: expect a probe on whether the evidence changed what was built; if it did, say what and which part was yours; if it did not, or you only passed it on, say so plainly and stay with the sessions. Do not describe the sessions as setting or shaping the roadmap | F7 and F1 lean on this quote and it is the medium-confidence one, so the dossier expects a probe. EXP because it tests what was actually yours |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc, one sentence per quote, each in its own words: the integrations, the playbook, the roadmap-input sessions. Add no years, titles or outcomes the quotes do not carry. Your reason for moving toward product is yours to give, in your own words; this pack has no source for it | The opener is scored. EXP because it sets which claims the rest of the conversation probes |
| D2 | "What draws you to this role, and to platform APIs in particular?" | JD | [generic] | Your own reason, in your own words. The role's own facts you can use are the partner-facing API platform, discovery with integration partners, and two squads. Do not claim to know Quartzline's strategy; no company research was read | Motivation consistency is the second thing a skeptical manager checks. JD because it ties to the listed role; `[generic]` because no company facts are used |
| D3 | "Tell me about the integration playbook you wrote for your team." | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Only what the sentence states: you wrote it, and your team uses it. The dossier calls this entry inspectable, so have the playbook to show. Do not add what it changed or who contributed unless you say so from your own memory, and say plainly if you do not remember | F4's strongest evidence, and the only entry with an artifact behind it. EXP |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims: "Having held a product manager title or role"` | Pause, restate the question, then hold: "I haven't held a product manager title or role. I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Hold through two follow-ups by returning to that sentence; concede specifically where pushed (title, roadmap, prioritization), never fold on what the quote carries, and never claim equivalence. The full form is A1 | The pressure form of A1, tested for composure. JD |
| E2 | "That integration work — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | The sentence's verb is "Led", so hold that scope. Answer slot: say which stages were yours and which were shared; if some were shared or someone else's, say so plainly and stay with what you led. Concede the specific part, not the whole | C1's attribution probe in its pressure register. EXP |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Take me from a partner request to something two squads can build. Where do you need them, and where do they need you?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Propose seam principles instead of pretending to know the seam: what you bring from the partner side, what the squads decide, how a disagreement gets settled. Answer slot: the JD asks you to write specs, so expect a probe on whether you have written them for engineers; if you did, say for what and with whom; if you did not, say so plainly and give the approach as a plan. If you draw on your own work, use the quote's words, which include requirements and go-live, and stop there | F8 and the dossier's unknown on squad authority. CASE with JD content |
| G2 | "How do you handle credit when work spans several teams?" | EXP | [generic] | A selection scaffold: pick a time work crossed teams; it needs a named stake, how credit was shared, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The collegial form of attribution honesty. EXP |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1, 3+ years product management experience (F1) | A1, A2, E1, D1 |
| Roadmap and prioritization authority, R1 sub-claim (F2) | A1, A2, B1, E1 |
| R2, shipped API or platform products (F3) | A4, E2 |
| R3, technical fluency (F4) | B5, D3 |
| R4, stakeholder management (F5) | A3, B3, G2 |
| R5, agile delivery (F6) | A5 |
| Discovery with integration partners (F7) | B4, C3 |
| Specs and delivery with two squads (F8) | A3, G1 |
| Adoption metrics (F9) | B2, C2 |
| Company and strategy knowledge | none: the research that would ground a CO question was refused, and a generic one would be padding |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's open risk: decision authority is asserted in the JD and not evidenced. Their answer tells you what you would actually own |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second open risk: adoption is a named responsibility with no baseline stated. It also shows you start from the measure |
| 3 | "How do the two squads run delivery today, and who decides what a sprint holds?" | Answers F6 from the employer's side and takes the seam question from G1 to the facts |
| 4 | "What does discovery with integration partners look like at the moment — who runs it, and how often?" | Shows what you would inherit in F7's area and signals you think in partner conversations |
| 5 | "What would a good ramp look like for someone strong on the partner side and new to owning a roadmap?" | Carries the sourced gap into the room as a plan, so the manager hears it from you and decides what support looks like |
| 6 | "What would a strong first quarter in this role look like?" | A generic close that gives you the manager's own scoring sheet; `[generic]` |

## Prohibited claims

Built before the banks. Entries 1 to 3 come from the dossier's `prohibited_claims`; entry 4 is built here from a sentence you did say.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | `prohibited_claims: "Having held a product manager title or role"` | "I haven't held a product manager title or role," then the quote at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." |
| Having owned a product roadmap | `prohibited_claims: "Having owned a product roadmap"`; also the dossier's `acknowledge_gap` area for F2 | "I haven't owned a roadmap," then the ramp plan from F2. No bridge |
| Having set prioritization for an engineering squad | `prohibited_claims: "Having set prioritization for an engineering squad"`; also the `acknowledge_gap` area for F2 | "I haven't set prioritization for an engineering squad," then the ramp plan from F2. No bridge |
| Shipped an API or platform product | Inflated form of the quote behind F3 | The quote at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The limit is the pack's observation: your material says integrations of the vendor's REST APIs, not the shipping of the API. A4's slot stays inside the integrations |

## Sources

- **Provided:** `tuesday-dossier.md`, dossier_version 1.1, generated by job-underwriter, dated 2026-08-14. Sections consumed: `role_profile` (requirements, responsibilities, unknowns), `decision` (context only), and all of `handoff_to_mock_interview` (high-priority requirements, verified evidence, weak areas with their strategies, the objection, risks, employer questions, prohibited claims). No `evidence_map`, `evidence_state` or `risk_register` was present. The dossier's decision prose gives a broader summary of your history than its verified entries do; this pack uses only the entries.
- **Web research:** 3 searches were sent and all were refused (permission was not granted), so nothing was returned and nothing from the web is in this pack.
  - `Quartzline company values` — refused
  - `Quartzline interview process product manager` — refused
  - `Quartzline partner API platform strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have fed a values cheat sheet and VAL questions; none built |
| 2. `Quartzline interview process product manager` | unavailable | Would have fixed the loop and the persona weights; weights rest on your description of the round and the relationship priors |
| 3. `Quartzline strategy` / recent news | unavailable | Would have grounded a CO or CASE question and a grounding brief; none built, so the CO type has no question |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given; there is no interviewer read |
| 5. representative Product Manager, Platform APIs JD | skipped | The dossier's `role_profile` supplies the requirement text that the fit snapshot and JD questions use |

## Upgrade menu

- Search permission, then a rerun of targets 1 to 3 → a values and loop check, current strategy for a CO or CASE question, and a persona weighting read from Quartzline's own documented loop. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and recent org context
- The interviewer's name → a reading of their public path, persona weights adjusted to it, and one reverse question tied to their own career
- The recruiter's prep note → stated focus areas, or any declared deliverable (a presentation, a take-home), which would get its own build section
- Your own answers to the slots in F3, F4, F5, F6, F7, F8 and F9, said or typed in your own words outside a drill → those rows regenerate from your sentences, and the `[inferred]` grading becomes `[grounded]` where your answer reaches the requirement
- An agenda or notes from one roadmap-input session → raises the medium-confidence quote behind C3 and F7, since the dossier's gap there is limited inspectable proof
- A current copy of the posting → confirms the five requirements and two unknowns still stand (the dossier is dated 2026-08-14)
