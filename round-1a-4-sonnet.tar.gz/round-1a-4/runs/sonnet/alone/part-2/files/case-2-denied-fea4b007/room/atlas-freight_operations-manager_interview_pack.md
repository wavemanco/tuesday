# Interview pack: Operations Manager, Atlas Freight

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer and relationship:** not known. This pack is built for a full loop with near-flat persona weights, and says so wherever it matters.
**Research:** web search was refused in this session, so nothing here comes from outside the JD and your message. The Sources section shows what that cost.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it scores. Every question carries one of each, plus a provenance label and the sentences of yours its guidance rests on.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer from what really happened, and if the practice was not yours or never existed, say so plainly. The highest-ROI prep in this pack is **A1**, the three-supervisors-to-twelve question. Do that one until it is boring.

## 2. Fit snapshot

The JD has no gate requirements (a term you either meet or don't, such as a licence, location or schedule), so there are no gate rows. The "5+ years" line is an experience requirement and is graded like any other.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution work and a peak-season plan for a site. It does not say terminals, and it does not say more than one site. Words: "I have 7 years in warehouse and distribution ops, and I ran the site's peak-season surge plan two years running." Answer slot: the four-site line makes a probe on multi-site work likely. If any of your work covered more than one site, say which and what part was yours; if it was one site, say so plainly and stay with that site. Do the same for terminal work versus warehouse work |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material gives a mis-pick rate, not on-time performance or cost per shipment. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names both measures. If you tracked either, say which and how it was counted, in your own words; if you did not, say so plainly and stay with the mis-pick figure |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The JD says twelve and your material says three, and the words stay at three: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if any part of your role reaches beyond those three, say what and which part was yours; if none does, say so plainly. The ramp to twelve is spoken as a plan, never as a past |
| F4 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" names the tool and does not show whether you built reports in it. Answer slot: the JD says build reporting. If you built reports in Excel that others used, say what they covered and who used them; if your Excel work was not reporting, say so plainly |
| F5 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives seven years in operations and a current supervising role. It does not say how many of the seven were spent leading people. Answer slot: if the leadership years reach five, say how long you have supervised or managed; if they do not, say so plainly and stay with the seven years of operations |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a certification with nothing inspected behind it, so expect a probe on where you have applied it. Lead with it in its own terms: "I'm green belt certified." |

## 3. Persona table

The loop is not established: no source in hand names Atlas Freight's rounds, and your note does not say who you are meeting. Weights therefore rest on the generic archetype (screen, hiring manager, panel), which means near-flat weights, and that is a noticeably weaker basis than knowing the round. The tilt below comes from the JD's own content.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A, 5 questions) | Quiet probing of the scale jump, the terminal-versus-warehouse change, and Power BI | Highest. The JD's headline asks are twelve supervisors, four sites and Power BI, and F3, F1 and F5 are where your material is thinnest | Rehearse A1 until it is boring. Bridges come only from your quoted sentences, with the limit said plainly, plus a ramp plan |
| Case/Strategist (B, 4 questions) | Live problems from the job: on-time slipping, cost per shipment rising, a surge, deciding where to spend a day | High. The JD is an operations ownership role, and an operations manager is typically tested on live problems. The pack cannot show that for this company | Clarify, objective, segment by site and shift, hypotheses, data, first action, risks. Think aloud and challenge one premise |
| Data-Driven Prober (C, 3 questions) | Line-by-line on the 40% figure and the pick-path redesign | Medium. It is the one hard number in your material, so any careful reader will go to it | Say how it was counted, or say plainly you do not know; name the weakest assumption you know of before they do |
| Conversational / Rapport Builder (D, 3 questions) | "Walk me through the journey", "why Atlas", the green belt | Medium. A friendly opener exists in most loops, and casual questions on JD topics still score | A 90-second arc built only from your quoted sentences; treat casual questions as scored |
| Pressure (E, 2 questions) | Interrupts, time-boxes, asks how much was really you | Low to medium. There is no signal this loop uses it, but E1 mirrors the likeliest attribution probe | Pause, restate, anchor in your words, hold through two follow-ups, concede specifically |
| Peer Evaluator (F, 2 questions) | Seam-splitting between sites and shifts, credit across teams | Low to medium. Four sites that depend on each other make this natural, if a site peer is in the loop | Offer seam principles rather than pretending to know the seam; reciprocity framing |
| Values/Behavioral (G, 2 questions) | Stories about coaching supervisors and giving hard news | Low to medium. No values round is established, and the company's published values are not in hand, so these are open prompts on JD themes | Selection scaffolds with the honest branch; no values are named because none were researched |

## 4. Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You currently lead three supervisors. This role has twelve, across four sites. Why isn't that too big a jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI prep in this pack, and the hold is only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." State the difference as the job's fact and not your own: the role is twelve, your current team is three. Concede it without softening. Then a ramp plan, spoken in the future tense, from your own thinking, never as something already done. Answer slot: if any part of your current role reaches beyond those three supervisors, say what and which part was yours; if none does, say so plainly and go to the plan. Follow-up 1, "why would it carry over": return to the quote and the plan and add nothing. Follow-up 2, "what would you get wrong first": name one thing you would need to learn, in your own words | F3 is the widest gap against the JD's headline requirement, so this question arrives in some form. JD because it scores a stated requirement; it is the deepest-rehearsed item because the jump is numeric and visible |
| A2 | "Your background is warehouse and distribution. Where does a terminal differ, and where would you need to learn?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say it at its scope: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's terminal line makes this probe likely. If any of that work was terminal work, say what and what part was yours; if it was all warehouse and distribution, say so plainly. Then ask the interviewer what differs at their terminals rather than asserting it, and give your first-weeks plan to learn it | F1 is the evidence for the terminal requirement and the likeliest place to be probed on kind of work |
| A3 | "The JD wants reporting built in Excel and Power BI. Where are you with each?" | JD | [grounded] "solid Excel" "never used Power BI" | Power BI first, because it is plain: "I've never used Power BI." Then a plan, said as a plan, for how you would get to working competence, in your own words. For Excel: "My Excel is solid." Answer slot: if you built reports in Excel that others relied on, say what they covered and who used them; if your Excel work was not reporting, say so plainly. Do not describe Power BI work, even in outline | F5 is a stated gap and F4 is thin, so this is asked straight. JD because it scores a named tool requirement |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" "never used Power BI" | Pick one gap your own material shows, say it plainly, then the plan. The two it shows most clearly are the supervisor count and Power BI. Choose the one you can speak to with a concrete plan. "Nothing" is the one answer that fails | F3 and F5 are the candidate's clearest gaps; the Skeptic's standard stem lets them choose, which tests candor |
| A5 | "The role asks for five years of operations leadership. How much of your seven years was leading people?" | JD | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | Hold what the quotes say: "I have 7 years in warehouse and distribution ops" and "I'm currently a senior shift manager over 3 supervisors." Answer slot: if the leadership part reaches five years, say when it started and what you led; if it does not, say so plainly and stay with the seven years of operations. Never round seven up into seven of leadership | F6 is a requirement the JD marks required, and the material is silent on leadership years. JD because it scores a stated threshold |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance at one of our four terminals has slipped over three weeks. Diagnose it." | CASE | [generic] | Clarify first: how on-time is defined and measured, over what period, which customers or lanes. State the objective, segment by shift and by day, form two or three hypotheses, name the data you would pull, and say your first action and its risk. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | On-time performance is the JD's first named metric (F2); CASE because it is a live problem. Generic because no company research ran |
| B2 | "Cost per shipment is rising at one site and flat at the other three. Where do you start?" | CASE | [generic] | Clarify what is in the cost, over what period and on what volume. Compare the odd site to the other three across cost lines, then separate volume effects from rate effects before blaming anything. Say what you would check on site and what you would ask the site lead. No claim about your past | The JD's second named metric (F2). Generic pattern for the problem, not a fact about Atlas |
| B3 | "Peak season is eight weeks out and two of our four sites are short on labor. Walk me through your plan." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure it live: demand forecast, labor gap by site and shift, options and their costs, a decision point, and how you would track it daily. Your story link is only what the quote says: "I ran the site's peak-season surge plan two years running." Answer slot: if you set parts of that plan, say which parts and how you decided, in your own words; if the plan was set for you or the parts were not yours, say so plainly and stay with the two years | F1 and the JD's daily-ownership line make surge planning likely; CASE with an EXP link, since the quote is the one real surge claim |
| B4 | "You have twelve supervisors across four sites and can be at one site today. How do you decide where to go?" | CASE | [generic] | Ask what you see each morning and what flagged. Then criteria: where performance is slipping, where a supervisor needs support, where a decision needs you in person. Say how the other three are covered while you are away. No claim about your past | F1 and F3 together: the multi-site cadence is the heart of the role. CASE because it asks for a decision rule |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The four slots a figure raises, each in your own words and none supplied by the pack: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F2's only number is the likeliest prober target; EXP because it tests whether the claim survives |
| C2 | "Take me through the pick-path redesign. What was your part?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The beats the sentence states: the pick path was redesigned, and the mis-pick rate fell 40%. Answer slot: say which steps were yours and which were shared, in your own words; if others did parts, say so plainly. Do not add steps, tools or a timeline you did not give | F2 again, from the attribution side. EXP |
| C3 | "The JD asks you to drive down cost-per-shipment and improve on-time. Which numbers did you track in your current role?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you tracked on-time or cost per shipment, say which and how each was counted; if the numbers you tracked were others, such as mis-pick rate, say so; if none of the JD's two was yours, say so plainly and stay with "I cut mis-pick rate 40% by redesigning the pick path." Never name a metric you did not own | F2's two JD measures are not in your quote, so this slot is where a probe lands |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" "currently a senior shift manager over 3 supervisors" | A 90-second arc with only the beats your sentences state: seven years in warehouse and distribution ops, and now a senior shift manager over three supervisors. Why a multi-site terminal role is next is an answer slot: say your actual reason in your own words; if you do not yet have a clear one, say so and name what draws you to the role | F6 and F3 supply the arc. EXP because it tests the story's coherence |
| D2 | "What drew you to Atlas Freight?" | CO | [generic] | Company research did not run, so use only what the JD itself says: "Operations Manager, Atlas Freight (regional logistics, 800 employees)". Selection scaffold: pick what draws you to a regional operation of that size and to owning daily terminal work. Read the company's own site before the interview. If nothing specific draws you yet, say what draws you to the role | Asked in almost every loop. Generic because no strategy or values page was fetched |
| D3 | "Lean and Six Sigma come up a lot with us. Where have you used them?" | JD | [grounded] "green belt certified" | "I'm green belt certified." Answer slot: if you applied the method to real work, say which work and what you took from the method; if the certification has not been applied, say so plainly. Do not retro-label other work as a green belt project unless it was | F7 is a plus in the JD; the likeliest probe is on application, not the certificate |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, then anchor in the quote: "I cut mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups. Answer slot: if others contributed, say which parts and whose; if it was all yours, say so plainly. Concede only specifics you actually do not know | The Pressure form of C2; the same material, delivered with interruption. EXP |
| E2 | "Sixty seconds: why you over a candidate who already runs a multi-site network?" | JD | [grounded] "7 years in warehouse and distribution ops" "cut mis-pick rate 40% by redesigning the pick path" "ran the site's peak-season surge plan two years running" "green belt certified" | Pause, then give only quoted facts in order: "7 years in warehouse and distribution ops", the mis-pick result, the two surge seasons, the green belt. Concede the two JD gaps in the same breath: you are over three supervisors today, and you have never used Power BI. Let the interviewer draw the inference. Do not claim you are better than the other candidate | F1 to F7 compressed. JD because it scores fit against the posting under time pressure |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Two of your four sites hand work to each other, and one keeps missing its numbers. How do you raise it with the other site's lead?" | CASE | [generic] | Seam principles, not a script: agree the shared measure first, bring data rather than blame, ask what the other site needs, and agree who decides if you still disagree. No claim about your past | F1 and F3: four sites imply peers. CASE delivered collegially |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams, where credit could have been contested and was shared. It needs what was yours, what was theirs and the outcome. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A standard peer stem; generic because no peer interviewer is established |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a message that was hard to hear and a relationship that held afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Standard values stem; Atlas Freight's values are not in hand, so no value is named |
| G2 | "Tell me about a time you had to coach a supervisor whose performance wasn't where it needed to be." | VAL | [generic] | Selection scaffold: pick a time with a specific supervisor behavior, a conversation you led and a result you can describe honestly. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The JD's supervisor-leadership line (F3) raises the theme. Generic because the pack has no coaching story from you |

## 5. Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A2, B3, B4, F1 |
| "drive on-time performance ... down" | B1, C3 |
| "cost-per-shipment down" | B2, C3 |
| "lead a team of 12 supervisors" | A1, A4, B4, E2, G2 |
| "build reporting in Excel/Power BI" | A3, A4 |
| "5+ years operations leadership required" | A5, D1 |
| "Lean/Six Sigma a plus" | D3 |

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Of the four sites, which is hardest to run today, and what makes it hard?" | It points your interest at the real job rather than the posting, and the answer shows where a new manager would spend the first weeks |
| R2 | "How are on-time performance and cost-per-shipment measured today, and where does that reporting live?" | They are the JD's two named metrics, and the answer shows whether reporting is built or still to be built |
| R3 | "How are the twelve supervisors spread across the sites, and how long have they been in role?" | It connects to the scale jump in F3 and shows you think about the team before the numbers |
| R4 | "Who owns the reporting tools today, and what would you expect me to build versus inherit?" | The JD says build reporting; this separates a new build from maintenance, which bears on F4 and F5 |
| R5 | "What would a successful first six months look like on the two metrics?" | It ties success to the JD's own measures and tells you what you will be judged on |
| R6 | "What are the next steps in the process, and what is the timeline?" | A logistics question that lets you plan, and a normal close |

## 7. Prohibited claims

What this pack will not coach, built from the snapshot before any question was written.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material says warehouse and distribution work and one site's surge plan, not terminals or four sites. A2's slot stays inside what you did |
| Led or managed twelve supervisors | Inflated form of F3 | "I'm currently a senior shift manager over 3 supervisors." The pack's observation is that the JD says twelve and your material says three |
| Drove down on-time failures or cost per shipment | Inflated form of F2 | F2's quote at its own scope: mis-pick rate, 40%, pick path. C3's slot asks only which numbers you tracked |
| Seven years of operations leadership | Inflated form of F6 | "7 years in warehouse and distribution ops." The pack's observation is that your material does not say how many of those years were spent leading people |
| Has used Power BI | Negative you stated, F5 | The plain acknowledgment: "I've never used Power BI." No slot |

## 8. Sources

Provided documents: the JD text in your message, and your own background in your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have fed a values cheat sheet and the VAL questions by value name; none is written |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have named the loop's rounds, so persona weights rest on the generic archetype instead |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have grounded CO and CASE questions in current priorities; B1 to B4 and D2 are generic as a result |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics terminals news strategy" — refused

Nothing about Atlas Freight beyond the JD's own line is used anywhere in this pack. The name is a common one, and a same-named company's facts would be worse than none.

## 9. Upgrade menu

- The round type and who you are meeting (recruiter, hiring manager, peer, skip-level) → persona weights recomputed; a recruiter screen adds logistics questions on pay, notice, location and reason for leaving
- Your answers to the answer slots in A1, A2, A5, B3, C1 to C3 and D3 → fit rows F1 to F4 and F6 upgrade from slots to quoted story maps
- The interviewer's name → an interviewer read and a reverse question tied to their path
- The company's own values, careers or about page pasted in, or web search allowed → CO and CASE questions become `[grounded]`, loop structure comes from a source, and a values cheat sheet is built if a values round is documented
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → strategy brief and recent organization context for CO questions; offered once
- Any before-and-after mis-pick report or shift scorecard behind the 40% figure → F2 can rise from medium to high
- The recruiter's prep email → coverage of any stated focus areas or pre-declared deliverable
- How many hours you have before the interview → a prioritized prep triage
- A tuesday-dossier.md from an earlier evidence review → verified evidence and risks carried in; not required
