# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer(s) and relationship: not known. No CV, no JD, no research results: this pack is built on role-family patterns and labelled `[generic]` throughout. Nothing here is a fact about Stripe.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values (none read yet, so these use persona stems) |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy homework |
| CASE | A live problem from the role, scored on structure |

Because nothing about you is in hand, every guidance cell is a selection scaffold ending in an honest branch. Send a CV and each scaffold becomes a story map built from your own sentences.

## Fit snapshot (worksheet variant)

No JD was supplied, so the requirements below are role-family patterns in plain prose, not quotations. No evidence was supplied, so every evidence cell is empty. Fill each row yourself before the interview.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating a launch or change across several teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a specific launch or change you coordinated, with your own part named separately from the team's. Selection scaffold: pick one such occasion; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Designing or running an operating rhythm or process for product teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or ran, with what it replaced or changed. Selection scaffold: pick one; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Using metrics to judge product or program health (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a metric you used or built and how it was counted. Selection scaffold: pick one; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Prioritizing competing requests from many teams (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a time you said no or sequenced requests and how it was received. Selection scaffold: pick one; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influencing people you do not manage (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer team and its outcome. Selection scaffold: pick one; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Communicating clearly to senior leaders (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a hard message you delivered upward and what happened. Selection scaffold: pick one; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

Weights are flat. Your note says final round but not who you meet or how many sessions it holds, and no loop source was read, so the loop is not established. Fallback archetype: Generic (screen, hiring manager, panel), flat weights. If your final is several sessions, send the schedule and the pack splits per session.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of gaps and motivation | Medium-high: any final round re-tests what earlier rounds flagged. Four questions because the highest-ROI prep sits here | Rehearse the weakest-on-day-one answer until it is boring; build bridges only from what you actually did |
| B. Case / Strategist | Live problems from the role | Medium-high: product operations is a judgment role, and a live problem is the cheapest way to see it. Four questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| C. Values / Behavioral | Scenario probes against published values | Medium: no values page read, so stems only. Two questions | Pick stories where the hard truth actually landed; "we" for context, "I" for contribution |
| D. Conversational | Friendly, scored anyway | Medium: openers appear in every round. Three questions | A 90-second journey arc; never "I think you've covered everything" |
| E. Pressure | Time-boxes, devil's advocate | Medium: final rounds often test composure. Three questions | Pause, restate, hold through two follow-ups, concede specifically |
| F. Peer | Seam-splitting, collaboration | Medium: a peer may be in the loop. Three questions | Reciprocity framing; seam principles rather than a pretended seam |
| G. Data-Driven Prober | Counting and assumptions | Lower-medium: no figures known. Two questions | Say how a number was counted, or that you do not know |

## Question banks

Highest-ROI prep: A1. It is the likeliest question in some form for any candidate, and a rehearsed, non-defensive answer changes the interview. It is a placeholder until a CV shows where your real biggest gap is.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick one real area where your experience is thinnest, name it in a sentence, say plainly what you have and have not done in it, then give a 30-day ramp stated as a plan, not a past. Do not invent a fake weakness. If no area comes to mind, say so plainly, then say what you would ask the team in week one to find out | Candor about a gap is what the Skeptic scores; JD because it tests the role itself |
| A2 | "Why this role, and why now?" | JD | [generic] | Two reasons in your own words, both pointing toward the work rather than away from a past employer; no disparagement. If a reason is not yet clear to you, say so plainly and give the part that is | Motivation consistency is the Skeptic's core test; JD because it asks about this job |
| A3 | "Product operations means different things at different companies. What does it mean to you?" | JD | [generic] | Give your working definition in two sentences, say which parts you have done and which you have not, and ask what it means here. If you have not done it before, say so plainly and say what you would learn first | Surfaces a mismatch in definition early; JD because it tests understanding of the role |
| A4 | "Where would you want the most support from this team in your first 90 days?" | JD | [generic] | Name one or two real areas, say what you would do yourself first, then what you would ask for. If nothing comes to mind, say so plainly and say how you would find out | Tests self-awareness and ramp realism |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A product change ships across several teams that depend on it, and one team says it won't be ready. What do you need to know first, and what do you do?" | CASE | [generic] | Clarify first: what is slipping, what depends on it, who decides. State the objective, split the options (delay, descope, stage the rollout), pick one with the metric you would watch and the risk you accept. Challenge one premise politely | A live coordination problem, the heart of the role; asks nothing about your past |
| B2 | "A metric the product teams track dropped 20% week over week. Diagnose it." | CASE | [generic] | Ask how it is defined and whether the drop is real before diagnosing: measurement, a recent change, a segment, seasonality. Say the order you would check things and what would change your mind | The stem tests clarifying before structuring |
| B3 | "Several product teams ask your team for help at once and you cannot serve everyone. How do you decide?" | CASE | [generic] | Name the criteria you would use and say them aloud, who you would consult, how you would say no, and what you would measure afterward. Say which criterion you would trade away first | Prioritization under load is central to the role |
| B4 | "Design the operating rhythm between product, engineering and go-to-market for a fast-moving product area. What do you set up first, and what do you leave out?" | CASE | [generic] | Start with the problem the rhythm solves, then the smallest set of recurring forums, the information each needs, and one thing you would deliberately not add. Name how you would know it is working | Tests process design and restraint |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection criteria: a named stake, a moment you did not soften it, and a relationship intact afterward. Use "I" for what you said and did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Hard-truth stories are a standard stem; no values page was read, so it is a stem |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection criteria: a real customer impact, a metric that pointed the other way, and what you decided. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests whether customer focus survives a trade-off |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc from your own history: where you started, the one or two turns that matter, and why this role is the next step. Every claim should be one you can defend to a second question | The casual question is scored for economy and interest |
| D2 | "Why this company?" | CO | [generic] | Give reasons you can actually back: what you have used or read, and what draws you. This pack read nothing about Stripe, so add real homework before the interview. If your reasons are thin, say so plainly and give the part that is genuine | Homework depth; generic until research runs |
| D3 | "What have you used or read about the company's products lately?" | CO | [generic] | Say what you actually used or read, and one observation that is yours. If you have not looked yet, say so plainly and say what you would look at first | Casual question that tests real engagement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then give two points you can back from your own record. Hold through a push; concede specifically what an internal candidate knows that you do not. If you cannot back a point, drop it | Composure and honest self-assessment |
| E2 | "Pick a result you're proud of. How much of it was actually you?" | EXP | [generic] | Name your part separately from the team's, in "I" terms for what you did and "we" for context. Concede what others carried. If a result was mostly the team's, say so plainly | Attribution probe |
| E3 | "Product operations just slows teams down. Convince me it isn't overhead." | JD | [generic] | Hold your position through two follow-ups: say what the function should cost and return. Then concede specifically where the criticism is fair, such as process without an owner. Do not fold on the core point | Hold-then-concede on the role's own legitimacy |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Propose principles rather than a pretended seam: who owns the decision, how disagreement escalates, how you keep each other informed. Offer one disagreement style you actually use. If you have no example, say so plainly | Turf awareness |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Give your practice as one you follow, in your own words; if a past example comes to mind, say what you did. If none does, say so plainly and say how you would handle it | Collaboration norms |
| F3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Name one or two real asks and one thing you could offer the team early. Keep it reciprocal | Reciprocity signal for a peer |

### G. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Pick a number you'd cite from your own work. How was it counted, and which assumption behind it would you defend least?" | EXP | [generic] | Say how it was counted as far as you know, name the weakest assumption before they do, and say plainly if you do not know how part of it was counted. Do not explain a method you cannot repeat | Metric defense |
| G2 | "How would you tell whether product operations is working here, and what would mislead you?" | CASE | [generic] | Name two measures, say how each could be gamed or misread, and what you would watch beside it. Say what you would first want to learn about how it is measured today | Measurement judgment |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 cross-team launch coordination | B1, B4, F1 |
| F2 operating rhythm and process | B4, E3, A3 |
| F3 metrics and health | B2, G1, G2 |
| F4 prioritization | B3, A4 |
| F5 influence without authority | F1, F2, F3 |
| F6 communicating to leaders | C1, E1, D1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would make the first 90 days in this role a clear success?" | Shows you think in outcomes and gives you the scoring sheet |
| R2 | "Where does product operations sit relative to product, engineering and go-to-market, and where is the seam today?" | Shows you think about seams, not just tasks |
| R3 | "What is the hardest thing about this role that doesn't show up in the description?" | Invites candor and signals realism |
| R4 | "How does the team decide what it takes on and what it says no to?" | Prioritization is the job; you hear how they actually do it |
| R5 | "What has changed about how product teams work together in the last year, and what is still unsolved?" | Shows interest in current state, not archival |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer interviewer |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None listed yet | No candidate material was supplied, so there is no sentence to widen and no stated negative | Send a CV or describe your background; entries are built from your own quoted sentences and the claims a candidate reaches for under pressure |

## Sources

Provided documents: none. Your message named the company, the role and the round only.

Searches sent, all refused by the host (nothing came back):

- `Stripe operating principles values`: refused
- `Stripe interview process Product Operations Manager`: refused
- `Stripe strategy news 2026`: refused
- `Stripe Product Operations Manager job description responsibilities`: refused

Fetches: none sent.

Research tier: L1 — searches 4 sent of 6, all refused; fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Would have given the official value names for a values cheat sheet and VAL questions |
| 2. `Stripe interview process Product Operations Manager` | unavailable | Would have established the loop and set the persona weights from it |
| 3. `Stripe strategy` / recent news | unavailable | Would have grounded CO and CASE questions in current priorities |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Would have supplied inferred requirements to quote in the fit snapshot |

## Upgrade menu

- Your CV or a description of your background → the six worksheet rows become a real fit snapshot, each scaffold becomes a story map from your own sentences, and A1 is replaced by your actual biggest objection
- The JD text → the generic requirements become quoted `[grounded]` requirements and the coverage table is checked against the JD's own list
- Permission to search the web → Stripe's official value names, the documented loop and current strategy, which add a values cheat sheet, grounded CO and CASE questions and a loop-based persona weighting; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief
- The recruiter's prep note → coverage of any stated focus areas or a pre-declared deliverable such as a presentation or take-home
- The interviewer's name and role → persona weights read from their public footprint and a reverse question tied to their path
- If your final is several sessions, the schedule → per-session mini-packs
- A `tuesday-dossier.md`, if you have one → verified evidence and prohibited claims arrive pre-checked
