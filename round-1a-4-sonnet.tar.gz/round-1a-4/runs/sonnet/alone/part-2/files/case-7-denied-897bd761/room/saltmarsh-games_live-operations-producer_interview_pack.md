# Interview prep pack: Live Operations Producer, Saltmarsh Games

- Candidate: Femi
- Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be the hiring manager, since your note did not say. Every persona weight below follows from that assumption.
- Round: one 60-minute interview. The material says nothing about what the hour will hold, so the weights rest on the hiring-manager prior, not on a documented Saltmarsh process.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores. Each question carries both.
- Type key: VAL is values or behavior alignment. EXP is a deep-dive on your own experience. JD is a stated responsibility or qualification. CO is company or strategy knowledge. CASE is a live problem from the role.
- Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- An answer slot is an instruction for the interview. It is not a question for me, and nothing in this pack needs a reply before Friday.
- Fit-snapshot rows are F1 to F9. Question banks use the letters A, B, C, D, E and G, skipping F so the two never collide.

## Prep triage

Three sittings, in this order, each tied to the pack. Everything else is insurance.

1. Day 1: say A1 aloud until the concession and the hold come out in the same words every time, then A2 and A3. These are your stated limits, and they are the questions most likely to be asked.
2. Day 2: do B1, B3 and B4 aloud, thinking out loud with the clarify, structure, answer order. Then rehearse the D1 arc to under 90 seconds.
3. Day 3, the day before: say C1 and E1 aloud, choose your reverse questions, and find which two titles the JD means so A5 and D2 have something you have actually seen in them.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: the weekly content-drop calendar, for your main title, for the last two years |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, not live events and not two titles, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live events and two titles make a probe likely on whether your calendar held anything beyond the weekly drops, and whether you ever worked across more than one title. If either was so, say what it was and what part was yours, in your own words; if not, or it was not yours, say so plainly and stay with the calendar you ran |
| F3 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | none | [grounded] | discovery | Your material states a limit on leading and does not show whether you worked with any of these four disciplines on a drop. The plain words are the stated limit: "I've never led a team." Answer slot: the JD names four disciplines on each update, so expect a probe on which of them you worked with. If you worked with any, say which and what part was yours, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar you ran. This row is the centre of A1, the highest-ROI rehearsal |
| F4 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says presenting the monthly retention numbers, not owning a review or its KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event review and KPIs make a probe likely on whether you reviewed anything after it ran and who decided what was reported. If any of that was yours, say which part, in your own words; if no such review existed, or it was not yours, say so plainly and stay with the monthly presentation |
| F5 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it, not that you managed releases against it with QA. The words: "I wrote the release checklist our QA team still uses." Answer slot: the JD's manage-with-QA line makes a probe likely on how the checklist was used release to release. If you ran releases against it with QA, say how, in your own words; if QA ran it without you, or you wrote it and others managed it, say so plainly and stay with having written it |
| F6 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | As stated, the four years clear the JD's 3+, and a length of experience is not a gate. The material does not say whether the game was a live-service title. The words: "I was an associate producer at a puzzle-game studio for four years." Answer slot: the JD says live-service, so expect the probe. If the title was live-service, say in your own words what that meant; if it was not, say so plainly and stay with the weekly calendar you ran |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in wording, but nothing inspected behind it, so expect to be asked how the numbers were counted (C1). Lead with it as written: you presented the monthly retention numbers to the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | Derived from the checklist quote: a written document that others use touches the requirement without showing it was clear, and nothing else in your material is a written sample. Answer slot: expect to be asked for an example. If something you wrote that others relied on carries it, say what it was and who used it, in your own words; if nothing beyond the checklist does, say so plainly and stay with the checklist |
| F9 | role-family requirement, no JD line and unquoted: familiarity with in-app purchases in mobile live-service games | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. The words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

Weights start from the hiring-manager prior (Case and Skeptic dominant), then follow the fit snapshot. No interviewer profile was available, so nothing was adjusted for Tobias personally. Depth follows weight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Skeptic | Quiet probing of your stated limits and the jump from one title to two | Highest. You named two limits yourself (F3, F9), and F2, F4 and F5 each stop short of the JD's wording | Rehearse A1 until it is boring: concede the limit plainly, hold only what your quotes carry, give a plan said as a plan | A, 5 questions |
| Case / Strategist | Live problems from the JD's own duties: calendar clashes, a release call, a post-event review, a retention dip | Highest. The hiring-manager prior says so, and the JD is a list of operational duties that turn directly into live problems | Clarify first, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise politely | B, 5 questions |
| Data-Driven Prober | Goes line by line through the retention numbers you presented | Medium. The JD asks for retention-metric comfort and KPI ownership (F4, F7), and the numbers are the one metric in your material | Know what you can and cannot say about how they were counted, and say plainly where you do not know | C, 3 questions |
| Conversational / Rapport Builder | Opens with "walk me through the journey", asks what you play | Medium. A one-hour conversation usually opens this way, and casual questions here still score | A 90-second arc built only from your own sentences; real games you actually play | D, 3 questions |
| Pressure | Time-boxes you and asks how much was actually you | Lower. Nothing in the material points to a stress style, but F5 and F6 give it easy targets | Pause, restate, hold through two follow-ups, concede specifically | E, 2 questions |
| Values / Behavioral | Past-behavior prompts | Lower. No values page was reachable and no loop source names a values round, so none is detected. These two use standard behavioral prompts only | A scaffold that ends in the honest branch when no story comes to mind | G, 2 questions |
| Peer Evaluator | Seam-splitting between adjacent teams | Not banked. A Head of Live Operations is unlikely to interview as your peer, and the coordination themes already sit in A1 and B1 | n/a | none |

## Question banks

Highest-ROI prep in the pack: A1.

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role coordinates design, art, engineering and community teams on each update, and you haven't led a team. What makes you think you can get four disciplines moving together?" | JD | [grounded] "Never led a team" ; "I ran the weekly content-drop calendar for our main title for the last two years." | Concede first, plainly: "I've never led a team." Then hold only what your quote carries: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD names four disciplines on each update, so expect a probe on which of them you worked with. If you worked with any, say which and what part was yours, in your own words; if you did not, or it was not yours, say so plainly and stay with the calendar you ran. Follow-up 1, "so none of them answer to you?": same acknowledgment, same quote, nothing added. Follow-up 2, "what would you do in week one?": a plan said as a plan, never as a past, such as what you would ask each discipline about how they want to hear about dates and changes, then turn it back with reverse question 4. Nothing in this answer says you led, managed or directed anyone | F3 is where the JD's coordination line meets a limit you stated, so this objection arrives in some form. JD because it scores a stated responsibility, and it gets the deepest rehearsal because a rehearsed, undefensive concession changes how the next question lands |
| A2 | "You haven't worked on a game with in-app purchases. If either of our titles has them, what would you want to understand in your first month?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I've never worked on a game with in-app purchases." Add no claim of equivalence. Then answer as a plan, in your own words: the things you would ask and who you would ask, framed as questions you would bring, not things you already know. Answer slot: if you have any exposure to purchases by another route, say what it was and that it was not your work; if you have none, say so plainly and go straight to the plan | F9 is a stated gap that the JD never mentions, so the interviewer will either raise it or notice it. JD because it scores whether the role can be done despite the gap; the question is conditional because the pack has no source on Saltmarsh's titles |
| A3 | "You've been an associate producer for four years. Which parts of this job would be new to you?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." ; "I ran the weekly content-drop calendar for our main title for the last two years." ; "Wrote the release checklist our QA team still uses." ; "Presented the monthly retention numbers to the studio head." | Sort the JD's list into three groups using only your quotes. First, what you say in the quote's own words: the weekly calendar, the checklist, the retention numbers you presented. Second, what answers through a slot: F2 two titles, F3 coordination, F4 the review. Third, what you say plainly you have not done: "I've never led a team" and "I've never worked on a game with in-app purchases." Answer slot on F4: if any post-event review or KPI choice was yours, say what; if no such review existed, or it was not yours, say so plainly and stay with the monthly presentation | A self-aware sort beats a defensive answer to a gap question. F2, F3, F4 and F6 are the rows it draws on; EXP because it tests the CV's claims against the JD's scope |
| A4 | "You ran the weekly content-drop calendar for your main title. This role runs live events for two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say the quote at its own scope first. Answer slot: if you ever worked on a calendar for more than one title, or alongside another title's calendar, say how and what was yours; if not, say so plainly and stay with your main title's weekly calendar. Then, as a plan: what you would want to learn about each title's calendar before changing anything, in your own words | F2 is transferability: the material carries a calendar, not events and not two titles. JD because it scores the headline responsibility directly |
| A5 | "Why live operations, why mobile, why Saltmarsh, and why now?" | CO | [generic] | Selection scaffold, not a story: give your own reason for each of the four. If a reason is thin, say so plainly and say what you want to find out. Before Friday, find out which two titles the JD means and spend time in them, so "why Saltmarsh" has something you have seen in it. Say nothing about Saltmarsh's strategy or values: this pack holds none | Motivation consistency is the Skeptic's standard probe. Tagged CO because "why here" tests homework, and `[generic]` because no company research was available |

### B. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Both of our titles want the same weekend for their biggest event of the month, and engineering says only one can ship safely. Walk me through what you do." | CASE | [generic] | Makes no claim about your past. Clarify first: what "safely" means, what moving either event costs, what each event is for. Then objective, options, a recommendation with its trade-off, and who you tell. Challenge one premise politely, such as whether the date is fixed for both | The JD's calendar and coordination duties (F2, F3) become a live problem here. CASE because it scores structure under a realistic clash |
| B2 | "An event has just ended. What should the post-event review contain, and which KPIs does it report?" | CASE | [generic] | Makes no claim about your past. Start from what the event was meant to do, choose KPIs from that goal, compare against a baseline, name who reads the review and what decision it should feed. Name the weakest assumption in your own KPI choice before they do | Turns the JD's review-and-KPIs line (F4) into a design question that needs no past. CASE with JD content, because it scores the stated responsibility |
| B3 | "A drop is due to ship on Thursday and QA finds a bug on Wednesday evening that isn't a crash. Ship or hold?" | CASE | [generic] | Makes no claim about your past. Clarify severity and who is affected, then the options (ship, hold, ship with a fix to follow), who owns the call, and what the community team needs to hear either way. Say what the release checklist would need to record | The JD's manage-the-checklist-with-QA line (F5) as a decision under time pressure. CASE because the score is the structure and who you bring in |
| B4 | "Retention on one title dipped in the week after an event. Diagnose it." | CASE | [generic] | Makes no claim about your past. Clarify first: which retention measure, which players, compared with what. Then list what else changed in that week, whether the measure itself changed, and what you would check first. Name the assumption in your diagnosis you would defend least | F7 is comfort with retention metrics, and a diagnosis tests it live without leaning on a figure. CASE with JD content |
| B5 | "You inherit both titles' calendars on day one. What do you want to know before you change anything?" | CASE | [generic] | Makes no claim about your past. Plan, in order: what is already committed, what each calendar is meant to achieve, who has to say yes to a change, and what has worked or failed before. Say that you would change nothing until you had asked | Covers the two-title scope (F2) as a plan and sets up your reverse questions. CASE with JD content, and a safe place to show your process without overclaiming |

### C. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | The quote at its own scope: you presented them monthly to the studio head. Answer slot: if you know which retention measure it was and how it was counted, say so in your own words, along with what the figure is most sensitive to and the assumption you would defend least. If you do not know how it was counted, or someone else produced the numbers, say so plainly and stay with presenting them | F7 and F4 draw on this one sentence, so it is the number a prober goes to first. EXP because it tests what was actually yours |
| C2 | "After you presented those numbers, did anything change?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if something changed because of what you presented, say what, and what part was yours, in your own words. If nothing did, or you do not know, say so plainly and stay with presenting monthly. Do not describe a decision you did not see made | A prober asks what the number was for. F4 is the review-and-KPIs row, and the honest branch is rehearsed here before it is needed |
| C3 | "Which retention measure would you trust least when judging a short event, and why?" | JD | [generic] | Makes no claim about your past. Reason aloud: name the measure, the weakness (small groups, other changes at the same time, how the window is defined), and what you would pair it with. Finish by naming what you would want to know before relying on it | F7 asks for comfort with retention metrics; this tests judgment about them rather than recall of one |

### D. Conversational / Rapport Builder (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." ; "I ran the weekly content-drop calendar for our main title for the last two years." ; "Wrote the release checklist our QA team still uses." ; "Presented the monthly retention numbers to the studio head." | A 90-second arc in these beats: four years as an associate producer at a puzzle-game studio; for the last two, the weekly content-drop calendar for your main title; you wrote the release checklist QA still uses; you presented the monthly retention numbers to the studio head. The last beat is yours: why live operations and why now, in your own words. If the move is more drift than plan, say so plainly | F1, F5, F6 and F7 are all in the arc, so the casual opener is where the whole fit is first heard. EXP because it is your own history, told once and consistently |
| D2 | "What are you actually playing in live-service mobile these days?" | JD | [generic] | Name one or two games you genuinely play, and say what you notice about how their events run. Name only games you actually play. If you play none, say so plainly and say what you will study before starting | Casual questions about hot topics in the JD are scored. JD because it tests fluency in the job's own domain; `[generic]` because it says nothing about Saltmarsh |
| D3 | "Tell me about something you've written that other people relied on." | JD | [inferred] "Wrote the release checklist our QA team still uses." | The checklist quote at its own scope. Answer slot: if anything about it made it clear, such as who used it and what they did with it, say so in your own words; if there is a better written example, use that. If nothing beyond the checklist comes to mind, say so plainly and stay with it. Do not describe how it was received unless you know | F8 is the one row with low confidence, and the JD names written communication. JD because it scores the stated requirement; the quote is the only written artifact in the material |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That checklist, how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Pause and restate the question. Hold: "I wrote the release checklist our QA team still uses." Answer slot: if QA or others added to it, say what they added; if you wrote all of it, say so plainly; if you do not remember who added what, say that. Hold through two follow-ups, concede only what is true and specific, and never fold the core claim | F5 is the row with the clearest artifact, so the attribution probe lands here. EXP because it is exactly the "how much was you" test |
| E2 | "Sixty seconds: why you over someone who has run live events on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" ; "I ran the weekly content-drop calendar for our main title for the last two years." | Concede first: "I've never worked on a game with in-app purchases." Then hold only the calendar quote at its own scope, and finish with the plan from A2. Do not claim equivalence, and do not run past the minute | F9 and F2 together are the sharpest comparison an interviewer can make. JD because it scores fit for the stated role; the time-box is the pressure delivery |

### G. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time you gave leadership news they did not want. It needs a named stake, a moment you did not soften it, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the quote above at its own scope (it does not show the numbers were unwelcome), or how you would handle it | A standard behavioral prompt, since no published Saltmarsh values were reachable. F4 is the only row where you faced leadership |
| G2 | "When did you put a player's experience ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a decision cost a number but protected the player, with the stake and your part named. If no such time comes to mind, say so plainly, then say how you would weigh the two | A standard behavioral prompt for a live-service role. No quote in the material carries it, so it is a scaffold with its honest branch |

### Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A4, B1, B5 |
| "coordinate design, art, engineering and community teams on each update" | A1, B1 |
| "own the post-event review and the KPIs it reports" | A3, B2, C1, C2, C3 |
| "manage the release checklist with QA" | B3, E1 |
| "3+ years producing live-service games or apps" | A3, D1 |
| "experience running a content calendar" | A4, D1 |
| "comfortable with player-retention metrics" | B4, C1, C2, C3 |
| "clear written communication" | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "When the two titles' calendars collide on engineering time, who makes the call, and what does the producer bring to it?" | The JD's coordination line (F3) leaves authority unstated. The answer shows how much weight the role carries, and it signals you think about the seam, not just the schedule |
| 2 | "What does a good post-event review look like here, and what has one changed recently?" | The JD makes the producer owner of the review and its KPIs (F4). This finds out whether reviews drive decisions and shows you care about outcomes over reports |
| 3 | "What would you want a new producer to have done by day 30 and by day 90?" | Lets you hear the bar for the gaps you named (F3, F9) and respond to it, rather than leaving it to the Skeptic |
| 4 | "How do design, art, engineering and community learn what is landing on each update, and where does that go wrong today?" | Turns A1's week-one plan into a real conversation about their process, and surfaces the pain you would be hired to fix |
| 5 | "Which title would I start on, and what state is its calendar in?" | The JD covers two titles. A concrete start shows you are already planning and gets you the information that B5 says you need |
| 6 | "How do commercial goals shape what goes on each title's calendar?" | A neutral way to learn the commercial side you have not worked on (F9) without claiming to know it. It turns a stated gap into curiosity |
| 7 | "Where does the release process pinch for QA today?" | Lets you talk about the checklist (F5) from the process side, with no claim about releases you did not run |

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team, or directed other people | Negative you stated, F3 | "I've never led a team." No slot, and no softening |
| Has worked on a game with in-app purchases, or run purchase-linked events | Negative you stated, F9 | "I've never worked on a game with in-app purchases." No slot |
| Ran live events across two titles | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says one main title and weekly content drops, not live events across two titles |
| Owned the post-event review and its KPIs | Inflated form of F4 | F4's quote at its own scope. The material says presenting the monthly retention numbers, not owning a review |
| Analysed or produced the retention numbers | Inflated form of F7 | F7's quote at its own scope. The material says you presented them |
| Managed releases against the checklist with QA | Inflated form of F5 | F5's quote at its own scope. The material says you wrote it and QA still uses it |

## Sources

Provided documents: the JD text you pasted, and your own note on your background. No dossier was in context.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Searches sent, each refused (permission to search was not granted, so nothing came back):

- `Saltmarsh Games values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games mobile studio news strategy` — refused
- `Tobias Wrenfield Saltmarsh Games` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have fed a values cheat sheet if a values round were detected; absent, and G1 and G2 are standard prompts |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have fixed the loop and the persona weights; they rest on the hiring-manager prior instead |
| 3. `Saltmarsh Games mobile studio news strategy` | unavailable | Would have grounded a CO or CASE question in current strategy; A5 is `[generic]` instead |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have supplied an interviewer read and a reverse question tied to his path; both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied already fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is your future manager, a skip-level or a cross-functional interviewer → reweights every bank and the persona table
- The recruiter's notes on what the hour will cover, or any exercise → coverage built to it, and a build section if a deliverable was announced (usually one email to the recruiter)
- Permission for web search → the Saltmarsh values, loop, strategy and Tobias's public footprint, which would add an interviewer read, a strategy-grounded CO or CASE question, a values sheet if a values round is detected, and a reverse question tied to his path
- Deeper research, if you want it: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief for a differentiator question and recent org context
- The names of the two titles → A5 and D2 become `[grounded]` against what you have seen in them
- Your answers to the slots on F2, F3, F4, F5, F6 and F8 → each discovery or transferability row becomes a grounded story, and the matching banks regenerate
- The release checklist itself, a calendar export or a retention report → the artifacts that could lift F5, F1 and F7 from medium to high
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence for the snapshot and a prohibited-claims list from that evidence
