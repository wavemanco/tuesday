import re, sys

p = sys.argv[1]
L = open(p).read().split('\n')


def sub(i, a, b):
    assert a in L[i - 1], (i, a)
    L[i - 1] = L[i - 1].replace(a, b)


sub(43, 'E2, F3,', 'E2, J3,')
sub(98, '(B1, C1, H1)', '(B1, C1, L1)')
sub(128, 'F1 to F5', 'J1 to J5')
sub(129, 'G1 to G3', 'K1 to K3')
sub(130, 'H1 to H3', 'L1 to L3')
m = {'F': 'J', 'G': 'K', 'H': 'L'}
for i in range(136, 147):
    L[i - 1] = re.sub(r'^\| ([FGH])(\d) \|', lambda x: '| ' + m[x.group(1)] + x.group(2) + ' |', L[i - 1])
sub(154, 'Selection scaffold, F1 (question F1)', 'Selection scaffold (question J1)')
sub(155, 'question F2', 'question J2')
sub(156, 'question F3', 'question J3')
sub(157, 'question F4', 'question J4')
sub(175, 'C3, F4, G1, C1', 'C3, J4, K1, C1')
sub(176, 'B1, C1, C2, H1', 'B1, C1, C2, L1')
sub(177, 'C4, G3', 'C4, K3')
sub(178, 'D2, G2, H2', 'D2, K2, L2')
sub(182, 'C5, D1, G3', 'C5, D1, K3')
sub(204, 'F1 to F4', 'J1 to J4')
open(p, 'w').write('\n'.join(L))
