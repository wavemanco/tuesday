# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Date of all three rounds:** 3 December 2026. **Mode:** loop (three scheduled rounds, so one shared fit snapshot and a mini-pack per round).

| Round | Format | Who | Name known |
|---|---|---|---|
| 1 | 30 minutes | The recruiter | Not given |
| 2 | 45 minutes, mostly behavioural | The Head of Member Services, who would be your manager | Not assigned |
| 3 | 60 minutes, including a 20-minute case on a complaint escalation; also the values round, scored against the four values | Panel of two branch managers | Not assigned |

## How to use this pack

- **Personas describe how a question is asked; types describe what it scores.** Each round has its own persona weights, with the reasoning shown so you can change them if you know something the pack does not.
- **Type key:** VAL (behavioural, scored against published values), EXP (your experience, tested for what was actually you), JD (a stated requirement of the role), CO (company and strategy knowledge), CASE (a live problem).
- **Guidance is scaffolding, not a script.** Say it in your own words. Where a cell says "Answer slot", it is an instruction for the interview: answer from your real experience, or say plainly that the practice was not yours. Both are fine answers.
- **IDs run by round and persona:** A and B are round 1, C to E round 2, F to H round 3.
- **Evidence is quoted.** Every claim the pack makes about your past is one of your own sentences, quoted. Where your message was silent, the pack asks you to fill the slot rather than filling it for you.
- Nothing in the JD is a pass-or-fail term such as authorisation, licence, location or pay. The fit snapshot therefore has no hard-gate rows.

## Fit snapshot (shared across all three rounds)

Evidence comes from the background you gave in your message; no CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process around it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages around the log likely. If any stage was yours to decide, say which and how you decided, in your own words; if the log was the part you handled, or there was no such stage, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet, and the words stay there; it does not show what the spreadsheet counted. Answer slot: if it showed volumes or resolution times, say which and how each was counted; if it showed something else, or neither, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence says new tellers and the script, and the words stay there: "trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on who else you have guided likely. If anyone beyond the new tellers was among those you guided on escalations, say who and what your part was; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show it either way. Answer slot: if you have worked with any digital or product team, say with whom, on what, and what part was yours; if not, say so plainly and say what you would want to learn from that team |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on the years. It is a line from your message with nothing inspected behind it, so expect a probe on the term customer operations. Lead with the sentence in its own terms: 6 years in retail banking, the last 3 as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says formal complaints, not regulated ones, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's regulated line makes a probe likely. If those complaints came with rules from a regulator, say which rules and which part of meeting them was yours; if you are not sure they did, or meeting them was someone else's job, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A stated absence, so the words are yours: "I've never presented to anyone above regional level." Then how you would prepare for a first senior presentation, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your sentence says spreadsheet, not Excel. Answer slot: if you built it in Excel, say so and describe what it did in your own words; if it was another tool, say so plainly and stay with the spreadsheet you built |

## Grounding brief: what the July 2026 strategy says

The full brief was not pasted. This table is your summary of it, so read the original for exact wording before 3 December.

| Item | What it says | Provenance | Where it shows up in this pack |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] your summary of the brief | E1, reverse questions R2 |
| Branch network | Consolidate eight branches into five hubs over 2027 | [grounded] your summary of the brief | E2, J3, round 3 reverse questions |
| New product | Launch a small-business lending product in Q1 2027 | [grounded] your summary of the brief | A2 only; no round is built around it |
| Competition | The main competitive pressure is app-only banks | [grounded] your summary of the brief | E1, A2 |
| Organisation | Member-owned, about 900 staff | [grounded] the JD | A2 |

---

# Round 1: recruiter screen (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A1 to A6) | Friendly walk-through of your background, motivation, then pay, notice, location and reason for leaving | High. A recruiter screen starts from this persona by default, and the recruiter's email describes a 30-minute chat with them | Rehearse a 90-second arc. Treat every casual question as scored. On logistics, your own answer is the only safe one |
| Skeptic, light (B1, B2) | Knock-out checks against the JD in a friendly register | Medium. F2 and F8 are stated gaps and F7 is a probable early check, so some knock-out questioning is likely, but a 30-minute screen leaves little room | Name the gap plainly before it is named for you, stay with what you have said, and give a plan rather than a past |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc using only those three sentences at their own scope: six years in retail banking, the last three as a branch supervisor; the complaints log and the escalation script; the monthly spreadsheet. Tell each beat in your own words and add no detail the sentences do not carry. Close with one sentence of your own on why you want this role; the pack does not supply your reason | F6 is the headline requirement and the recruiter's first check. EXP because it tests whether the story is yours and consistent |
| A2 | "What drew you to Ashgrove?" | CO | [grounded] | Pick one thing that genuinely matters to you, either one of the four published values by its name or one point from the 2026 strategy summary, and say why in your own reasons. Naming a value by its published words signals homework. If nothing in them draws you, say plainly what does, rather than praising something you do not feel | Open motivation question; CO because it scores homework depth. Grounded in the published values and the strategy summary |
| A3 | "What salary are you looking for?" | JD | [generic] | Logistics slot. Give your own figure, or ask for the role's band first. If asked what you earn now, you can redirect to the role's band and what you are looking for, with no figure given. Nothing here supplies a number | The pay logistics question every recruiter screen carries; JD because it concerns the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot. Give your actual notice period from your own contract, in your own words | Recruiter logistics; JD because it concerns the listed job's terms |
| A5 | "Where would you be based, and is anything about location or travel between sites a constraint for you?" | JD | [generic] | Logistics slot. State your actual position on base location, working pattern and travel, as it really is. The JD states no location, so there is nothing to match; give your own position | Recruiter logistics. The recruiter's own wording covers branches and a contact centre, so site travel is a fair thing to raise |
| A6 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot. Give your actual reason in a sentence or two, and say the same thing in all three rounds | The reason-for-leaving question; EXP because it tests whether your story holds together across rounds |
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" "I've never presented to anyone above regional level" | Pick the gap you will actually name and say it plainly, in your own words: "I've never worked in a contact centre" or "I've never presented to anyone above regional level". Follow it at once with how you would learn it, said as a plan: whom you would sit with, what you would read, what you would ask first. Do not soften the fact or add experience to it | The standard skeptic opener, aimed at F2 and F8, the two stated gaps. JD because it scores the listed requirements |
| B2 | "Tell me about your experience handling regulated complaints." | JD | [grounded] "I handled the branch's formal complaints log" | Open with the sentence as you said it: "I handled the branch's formal complaints log." Answer slot: the JD's regulated line makes a probe on what made them regulated likely. If those complaints came with rules from a regulator, say which rules and which part of meeting them was yours; if you are not sure they did, or meeting them was someone else's job, say so plainly and stay with the log | F7 is a likely early knock-out check for a role that owns a regulated process |

### Reverse questions: round 1

| # | Question to ask | Why it lands |
|---|---|---|
| R1.1 | "Is there anything the panel expects me to prepare or bring for the 20-minute case?" | The recruiter's email names a case but no pre-declared material, so this settles whether a deliverable exists |
| R1.2 | "Do you know yet who I will meet in rounds two and three?" | Names are unassigned, and they would let this pack add an interviewer read |
| R1.3 | "How much of this role's day-to-day sits with the contact centre, compared with the branch network?" | It asks about the scope that matters most for F2 and shows you read the JD closely |
| R1.4 | "How is the role expected to change as branches move into hubs during 2027?" | It shows you read the strategy brief, and it is a question only the recruiter's side can answer |
| R1.5 | "What happens after 3 December, and when would you expect to decide?" | A clean process question that closes the call |

---

# Round 2: Head of Member Services, your future manager (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (C1 to C5) | Quiet, persistent probing of the gaps in the JD match, often phrased as behavioural questions | Highest. The relationship prior for a hiring manager is Case/Strategist plus Skeptic, and F2 and F8 are stated gaps in a role whose first JD line names the contact centre | Rehearse the C1 objection until it is boring: name the limit, hold what your sentences carry, give a plan |
| Values/Behavioral (D1 to D3) | STAR-shaped stories | Medium-high. The recruiter's email calls this round mostly behavioural, which lifts this persona above the hiring-manager prior; it sits below Skeptic only because your gap questions arrive in behavioural form | Use "I" for your contribution and "we" for context; where no story comes to mind, say so plainly |
| Case/Strategist (E1 to E3) | Questions on Ashgrove's own strategy and what it does to complaints | Medium. A manager buying capability tends to test altitude; the 2026 strategy summary gives specific material | Clarify, then structure, then think aloud; challenge one premise respectfully |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role owns complaints across the branches and the contact centre. You haven't worked in a contact centre, so how do you see that?" | JD | [grounded] "Never worked in a contact centre" "I handled the branch's formal complaints log" | **The highest-ROI rehearsal in this pack.** Level 1: say the fact plainly, "I've never worked in a contact centre," then stay with what your sentence carries: "I handled the branch's formal complaints log." Level 2, if pressed on carry-over: describe the log at that scope, do not claim the contact centre works the same, and say you would expect to learn the difference before judging it. Level 3, if pressed on day one: give a plan, never a past, in your own words: whom you would sit with, what you would read, what you would ask before changing anything, and when you would report back what you had learned. Hold the log and the plan through all three levels; concede only the specific thing you have not done | F2 is a stated gap against the JD's first line, and this question will arrive in some form in all three rounds (B1, C1, L1). The deepest rehearsal is spent here because wording cannot close the gap, only honesty and a plan can. JD because it scores a stated requirement |
| C2 | "What would you do in your first 60 days to get across the contact-centre side?" | CASE | [generic] | Structure it as a plan, with no claim about your past: what you would ask first, whom you would sit with, what you would read, what you would hold off changing, and what you would bring back to the Head of Member Services at day 60. Think aloud and name the one assumption you would test first | The natural follow-up to C1, asked as a live problem. CASE because it scores structure; generic because it is a pattern, not a fact about Ashgrove |
| C3 | "You handled a branch's formal complaints log. This role covers branches and the contact centre. Where does your experience stop?" | EXP | [grounded] "I handled the branch's formal complaints log" | Say where it stops, at the sentence's own scope: "I handled the branch's formal complaints log." The pack's observation is that your material says the branch's log, not the process around it. Answer slot: if you have seen how other branches or teams handled complaints, say what you saw and what your part was; if not, say so plainly and stay with the log | F1 is where the JD's end-to-end line presses hardest. EXP because it tests how far the claim travels |
| C4 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the sentence: you built it, it is monthly, and your regional manager uses it. Answer slot: the JD's monthly-reporting line makes a probe on volumes and resolution times likely. If it showed those, say which and how each was counted, and name the assumption behind a figure you would defend least; if it showed something else, say so plainly. Answer slot: say what tool it was built in; if it was not Excel, say so plainly | F3 and F9 both rest on this one sentence, so it is the spot most likely to be probed for the denominator. EXP because it tests attribution and method |
| C5 | "The role asks for confidence presenting to senior leaders. What's your experience of that?" | JD | [grounded] "I've never presented to anyone above regional level" "I built the monthly complaints spreadsheet our regional manager uses." | Say the fact in your own words: "I've never presented to anyone above regional level." Then give a plan, never a past: how you would prepare for a first senior presentation. Answer slot: if you have talked anyone through what the spreadsheet showed, say who and what happened; if you only handed it over, say so plainly | F8 is a stated gap against a JD requirement. JD because it scores the listed requirement |
| D1 | "Tell me about a time you had to tell someone more senior something they did not want to hear." | VAL | [generic] | No sentence of yours carries this story, so use selection criteria: pick a time you told someone more senior something unwelcome. It needs a named stake, the moment you said it, and how the working relationship stood afterwards. If no such time comes to mind, say so plainly, then say how you would handle it | An unpopular-truth stem tied to the JD's senior-leader line. VAL because it scores behaviour. Generic because it is a persona stem, not a fact about Ashgrove |
| D2 | "Tell me about a time you coached someone and had to change your approach." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The story has the beats your sentence states: you trained new tellers, on your branch's escalation script. Tell it in your own words. Answer slot: if you changed how you trained them at any point, say what you changed and why; if you did not, say so plainly and describe the training as you gave it | F4 and the JD's coaching line make this a likely behavioural question. EXP because it tests what the training actually was |
| D3 | "Tell me about a time you disagreed with a colleague about how to handle a member's issue." | VAL | [generic] | Selection criteria: choose a disagreement where you can say what each side wanted, what you did, and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then say how you would handle it | A standard behavioural probe for a role that works across teams. Generic because no sentence of yours carries it |
| E1 | "We aim to move 40% of member service to digital channels by 2028. What happens to complaints as that happens, and what would you want to know first?" | CO | [grounded] | Clarify before you structure: what counts inside the 40%, and whether complaints are inside it. Then objective, the segments you would look at (channel, complaint type, member), approach, metrics in the JD's own terms (volumes and resolution times by channel), and risks. Use the value "Plain Words" as a lens: a member who cannot escalate from the app has been told something badly. Challenge one premise respectfully, such as whether digital means fewer complaints reaching branches | The strategy summary gives the live problem, and the JD's self-service line points at it. CO because it scores company-altitude thinking |
| E2 | "Eight branches are consolidating into five hubs over 2027. What does that do to complaints, and to the supervisors you would be coaching?" | CO | [grounded] | Same structure as E1. Name who is affected (members in each town, supervisors, branch managers), what you would want to know first, and what you would watch in the numbers. Use "Neighbours, Not Numbers" as a lens. Do not claim knowledge of Ashgrove's plans beyond what the brief says | The second strategy move that touches the role, and the one most likely to be live for the round 3 panel. CO because it scores strategy fluency |
| E3 | "The role works with digital teams on self-service journeys. What's your experience of working with digital teams?" | JD | [grounded] | Answer slot: if you have worked with any digital or product team, say with whom, on what, and which part was yours. If you have not, say so plainly, then say what you would want from that team and what you would bring them from the complaints side | F5 has no evidence, so this is a pure answer slot and the likeliest place to be caught unprepared |

### Reverse questions: round 2

| # | Question to ask | Why it lands |
|---|---|---|
| R2.1 | "What would a good first 90 days look like for this role?" | It lets your future manager define success in their own words |
| R2.2 | "Where are complaints handled best today, and where is it hardest: branches or the contact centre?" | It asks about the scope of your known gap without hiding it, and it signals ownership |
| R2.3 | "How does this role fit with the digital teams' plan to move 40% of service to digital by 2028?" | It ties your question to the 2026 brief and to the JD's self-service line |
| R2.4 | "Which colleagues would I depend on most, and what do they need from this role?" | It shows partnership thinking before the panel round tests it |
| R2.5 | "What would make you say in a year that this was the right hire?" | It lets the manager state the measure you will be held to |

---

# Round 3: panel of two branch managers (60 minutes, including a 20-minute case; also the values round)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (J1 to J5) | Scenario probes scored against Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix | Highest. The recruiter's email says the panel is also the values round and scores against the four values, which makes this persona certain | Map a story to each value where one of your sentences carries one; where none does, use the scaffold and the honest branch |
| Case/Strategist (K1 to K3) | The 20-minute complaint-escalation case | High. The recruiter's email says 20 of the 60 minutes are a case | Clarify, structure, think aloud; keep ownership and plain words visible in the answer |
| Peer Evaluator (L1 to L3) | Seam questions between branches and your role: what you need from them, how disagreements get settled | Medium. Branch managers are the people whose supervisors you would coach, so they are pricing what the hire adds to or takes from their branches. This is a judgement from the role, not from their profiles, which are unknown | Reciprocity: what you bring their branch, not just what you need. Propose seam principles rather than pretending to know the seam |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Members First, Always: we decide from the member's side of the counter. Tell me about a time you did that." | VAL | [grounded] "I handled the branch's formal complaints log" | No sentence of yours carries a story that shows this value, so use selection criteria: pick a decision where the member's side and the branch's side pulled apart. It needs a named stake, what you chose, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log," or how you would handle it | The first of the four published values, scored by name. VAL because it scores behaviour against that value |
| J2 | "Plain Words: if a member needs it explained twice, we wrote it wrong. When have you re-explained or rewritten something so that it landed first time." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Use selection criteria first: pick an explanation to a member or colleague where you can say what was unclear and what you changed. The nearest sentence of yours is the training one, at its own scope: you trained new tellers on your escalation script. Answer slot: if you changed how the script was explained or worded, say what and why; if you did not, say so plainly | The second published value, and the one the JD's self-service work leans on. VAL because it scores behaviour |
| J3 | "Neighbours, Not Numbers: every branch is part of its town. When have you shown that in how you worked." | VAL | [grounded] | No sentence of yours carries a story for this value, so use selection criteria: pick a time you weighed what a branch means to its town against a number or a process, and say what you did. If no such time comes to mind, say so plainly, then say how you would handle it. Expect it to be asked with the eight-to-five hub consolidation in the room | The third published value. Likelihood of the hub link is the pack's reading of the 2026 summary; it is not something the panel has said |
| J4 | "Own the Fix: whoever finds the problem keeps hold of it until it is solved. When have you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection criteria: pick a problem you found and stayed with, naming the point where it could have been passed on and what you did instead. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log," or how you would handle it. Do not describe a resolution your sentence does not state | The fourth published value, and the one the complaints log sits closest to. VAL because it scores behaviour |
| J5 | "Which of our four values would be hardest for you to live by in this role, and why." | VAL | [grounded] | Choose honestly. Do not pick a value only because it makes a safe weakness. Say what makes it hard and what you would do about it, in your own words | A candour question that tests self-assessment against the published values |
| K1 | "A member has complained twice about the same issue. The branch says it is resolved; the contact centre's record says it is open. The member is now saying they will take it outside. Walk me through what you would do." | CASE | [generic] | A practice case, not a prediction of the panel's. Clarify first: what the member has been told and by whom, what has been promised, and what time limits apply, taking those from the answer rather than assuming them. State the objective (put it right for the member, and keep one person holding it). Then who you would talk to first, how you would tell the member in plain words, how the two records become one, and what you would learn for the next case. Think aloud and challenge one premise respectfully | The recruiter says 20 minutes of the panel is a complaint-escalation case. Generic because the actual case is unknown |
| K2 | "The branch supervisor involved says the member is being unreasonable. What do you say to them." | CASE | [generic] | A coaching conversation, not a verdict. Listen first, find out what the supervisor saw, agree what must happen next, and say what you will take responsibility for. Use plain words and no blame. Do not claim you have coached this before | The JD's supervisor-coaching line applied to the case. Generic because it is a rehearsal structure |
| K3 | "A month later, what would you report to senior leaders about this case." | CASE | [generic] | Report in the JD's own terms, volumes and resolution times, then the one thing the case taught you about the process and what you propose to change. Say plainly what the figures do not show | The JD's monthly-reporting line and the senior-leader line together. Generic because it is a structure |
| L1 | "You would sit between our branches and the contact centre. Where is the seam, and what happens when we disagree about a complaint." | CASE | [generic] | Propose principles rather than claiming to know the seam: one owner for each complaint, one record, an agreed point at which a disagreement goes to you, and an agreed way to say who fixed what. Say you would want the panel's view of where it breaks today | The seam question every peer evaluator asks. It is the third place F2 can be probed |
| L2 | "What could you do in your first month that would genuinely help a branch like ours." | JD | [generic] | Reciprocity framing: listen first, ask what is slowing escalations down in your branch, and agree one small thing you can take off their hands. Do not promise outcomes | The JD's coaching line, asked as a peer. It tests whether you add to the branch's load or reduce it |
| L3 | "How do you handle credit and blame when a complaint spans the branch and the contact centre." | VAL | [generic] | Selection criteria: pick a time you shared credit or took responsibility on work that spanned teams. If no such time comes to mind, say so plainly, then say how you would handle it. "We" for context, "I" for your own part | A peer-evaluator stem. Generic because no sentence of yours carries it |

### Values cheat sheet (round 3)

The recruiter's email says the panel scores against the four published values, so they are mapped here. No sentence of yours carries a story that demonstrates a value; the table gives selection scaffolds instead.

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold (question J1): a decision where member and branch pulled apart, with a stake, a choice and an outcome. If none comes to mind, say so plainly, then give the nearest thing: "I handled the branch's formal complaints log." (F1) |
| Plain Words | If a member needs it explained twice, the writing was wrong | Selection scaffold (question J2): an explanation you changed so it landed first time. Nearest sentence: "I handled the branch's formal complaints log and trained new tellers on our escalation script." (F4) |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold (question J3): a time you weighed a branch's place in its town against a number. If none comes to mind, say so plainly |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold (question J4): a problem you found and stayed with. Nearest sentence: "I handled the branch's formal complaints log" (F1). If none comes to mind, say so plainly |

### Reverse questions: round 3

| # | Question to ask | Why it lands |
|---|---|---|
| R3.1 | "What do your supervisors find hardest about escalations today?" | It puts the coaching mandate in their terms and gets the problem from the people who own it |
| R3.2 | "How are the hub changes being talked about in your branches, and what would you want from this role while they happen." | It ties the 2026 brief to the people most affected by it |
| R3.3 | "What could a new person do in their first month that would genuinely help your branch." | The reciprocity question for a peer-style panel |
| R3.4 | "When a complaint crosses between your branch and the contact centre, what goes wrong most often." | It tests the seam from their side and gives you the real problem |
| R3.5 | "Where do you see Plain Words working best in your branch today." | It shows you want an example of the value in practice, not just its name |

---

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Own the member complaints process end to end" | C3, J4, K1, C1 |
| "across branches and the contact centre" | B1, C1, C2, L1 |
| "report monthly on complaint volumes and resolution times" | C4, K3 |
| "coach branch supervisors on escalations" | D2, K2, L2 |
| "work with digital teams on self-service journeys" | E1, E3 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | B2 |
| "confident presenting to senior leaders" | C5, D1, K3 |
| "comfortable with Excel reporting" | C4 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: the material says the branch's log, not the process around it. C3's slot stays inside the log |
| Has contact-centre experience, or knows how a contact centre runs from the inside | Negative you stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." Plans are said as plans, never as a past |
| Has presented to anyone above regional level | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." Plans are said as plans, never as a past |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script." The limit is the pack's observation: the material says new tellers |

## Sources

**Provided documents:** the JD as pasted; Ashgrove's values as you copied them on 24 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the three rounds; your summary of the 2026 strategy brief published in July 2026 (the brief itself was not supplied); your background as given in your message (no CV).

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values fix the values cheat sheet and J1 to J4; naming each value from the pasted text |
| 2. Ashgrove interview process, member services | skipped | The recruiter's email establishes the loop (three rounds with who runs each), which fixes the per-round persona weights |
| 3. Ashgrove strategy and recent news | skipped | Your summary of the July 2026 brief supplies the priorities and moves that feed E1, E2 and the grounding brief |
| 4. Interviewer name | n/a | No interviewer names are assigned, so there was no query to form; the interviewer read is absent |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV text, so that F1 to F9 evidence cells quote it rather than your message and more stories can be mapped to the four values
- Your answers to the answer slots in F1, F3, F4, F5, F7 and F9 (for example what the spreadsheet counted and in what tool, whether the formal complaints fell under a regulator's rules, and any digital-team contact), which would turn six discovery or transferability rows into mapped stories
- One real story per value, in your own words, which would turn the four scaffolds in the values cheat sheet into mapped stories
- The full July 2026 strategy brief, which would replace your summary with its own wording in the grounding brief
- Interviewer names and titles once assigned, which would add an interviewer read, personalised persona weights and a reverse question tied to each interviewer's own path
- The recruiter's prep email, or any note on the case format, which would show whether a graded deliverable exists for round 3
- Hours available before 3 December, which would add a prioritised prep schedule
- A deeper research pass, up to 6 more searches and 2 more fetches over several more minutes, covering Ashgrove's strategy, role-family loop reports and recent organisation context, which would add current context to E1 and E2
- A `tuesday-dossier.md` from an earlier evidence pass, which would add verified evidence, any prohibited claims it records, and an evidence-derived objection in place of the one inferred here
