# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one 60-minute panel. First 15 minutes: your spoken POV, no slides. The rest: Q&A.
**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director).
**Built on:** the recruiter's email as you quoted it, and your own description of your background. No JD, no CV text, and no sight of the market report. The web searches were refused, so nothing here is researched; Sources says exactly what that left out.
**Highest-ROI prep in this pack: C1**, the "you've never carried a quota" question. Your material states the gap, the recruiter says Ross will push on commercials, and a rehearsed, non-defensive answer changes the second half of the interview.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Every question has both, plus a provenance label.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none are banked here; see the persona table) |
| EXP | Whether your claims survive scrutiny: what was actually you |
| JD | Whether you can do the stated job, gaps included |
| CO | Homework and thinking at the company's altitude |
| CASE | Structure and reasoning on a live problem from the actual role |

Provenance labels: `[grounded]` rests on something you or the recruiter wrote, quoted beside it. `[inferred]` is a derivation, named. `[generic]` is a rehearsal pattern with no claim about Kelverton or about you.

Guidance is scaffolding, not a script. Wherever a cell says "Answer slot", it is an instruction for the interview: say what is true in your own words, and if the practice was not yours or never existed, say that plainly and return to what your own sentence carries. A slot is never a prompt to supply a detail you do not have.

## 2. Prep triage (four hours, spread over the weekend)

| Block | Time | Do this | Where |
|---|---|---|---|
| 1 | 60 min | Build the POV from the three theses, record yourself once, cut it to 13 minutes so the close on operators is not squeezed | Section 4; A1, A4, A5 |
| 2 | 60 min | Say C1 aloud until the plain acknowledgement is boring, then B1 and B5 aloud for the £4M, including "I don't know how that part was counted" if it is true | C1, B1, B5 |
| 3 | 45 min | The rail credibility answer and the sixty-second "why you" | C2, D1 |
| 4 | 45 min | Commercial structure questions: say them as a structured view, not a history | B3, B4, D2, D3 |
| 5 | 30 min | One full timed run of the 15 minutes, then pick your reverse questions | Section 4; Section 9 |

Everything else in this pack is insurance.

## 3. Fit snapshot

No JD was supplied, so the requirements below are the recruiter's own words as you quoted them, plus two role-family rows written as plain prose.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email, as you quoted it | "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material says an ISV channel; it does not say operators were among those partners. Words at the quote's own scope: "For my last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: the recruiter's "operator partnerships" makes a probe on how an ISV partner differs from an operator likely. If the ISV relationships resembled operator relationships in a way you can name, say how, in your own words; if they did not, say so plainly and stay with the channel you ran |
| F2 | "land on what it means for the operators themselves" — recruiter's email, as you quoted it | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The limit is the pack's observation: your material says bus and light rail network planning, not train operating companies. Words at that scope: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: "from the other side" is your phrase and the pack does not know which side you mean. If your consulting work was for operators, say what you saw of their decisions, in your own words; if it was not, say so plainly and stay with the network planning you did |
| F3 | "Ross will push on commercials" — recruiter's email, as you quoted it | "never carried a direct quota, only influenced revenue" — your message; "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your own words give the plain acknowledgment: "I've never carried a direct quota; what I've had is influenced revenue, roughly £4M." The material says influenced, and the words stay there. Answer slot: if any commercial terms in the ISV channel (pricing, discounts, structure) were yours to set or negotiate, say which and how you decided; if none were, say so plainly and answer commercial questions as a structured view |
| F4 | Grow and manage a portfolio of partners — role-family requirement from the title "Senior Partnerships Manager", no source quoted | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [generic] | none | No gap, but a self-reported figure with nothing inspected behind it, so expect it to be probed. Lead in the quote's own terms: you took the channel from 6 partners to 40, and the revenue was influenced. The probes are on how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours (B1, B2, B5) |
| F5 | Credibility partnering into train operating companies — role-family requirement, from your description of Kelverton as selling scheduling software to them, no source quoted | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## 4. The 15-minute POV: build section

**What was announced:** "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves." (recruiter's email, as you quoted it). That is a graded deliverable, and the close is named: operators.

**Facts to build on**
- F1: "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" — your message. This is the only partner-programme proof point your material gives, and it is an ISV channel.
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message. Use at its own scope.
- F5: "Never sold into rail specifically" — your message. Say it early and plainly in the POV, as a premise you are being straight about, so nobody else has to raise it.

**Three defensible theses.** Pick two. They are `[generic]` stances, written without the report, so test each against it before you commit.

| Thesis | What it says | Mandatory concession | What it means for operators (your close) |
|---|---|---|---|
| T1: Depth before breadth | In 18 months, a small number of operator partnerships done well beats a wide programme. Your own record in F1 is partner count; the pack's observation is that count may be the wrong first measure for operators | Slower headline growth than a channel measured by partner count, and you have not run operator partnerships (F1) | What they would see: fewer, more specific asks of them, with something concrete back for each |
| T2: Prove it with a few, then publish what they learned | Sequence by operator readiness; turn early results into something operators can show each other | It depends on operators' willingness to be early and on results arriving inside the 18 months | What they risk by going first, and what makes going first worth it |
| T3: Make the economics legible before scaling | Agree with Ross's side how a partnership is measured and paid for before widening it | Partnerships alone do not set commercial terms; this needs the commercial function, and you have never carried a direct quota (F3) | What an operator is asked to commit, what it costs them, and what they get back |

**Differentiating from the report.** The market report is equally available to both interviewers and to any other prepared candidate, so reciting its shortlist scores as homework. Bring one item from it to prove you read it, then one place you diverge, with a reason from the operator's side, then one anti-pick: something this role should say no to. Candidates for the anti-pick, to test against the report: chasing partner count as the goal, or a broad programme before one reference operator exists.

**Timing (a plan, not a claim):** about 1 minute on what you assumed and what you would want to know; 3 on one consensus item and why it matters; 7 on two theses with their concessions; 3 to 4 on what is different for an operator in 18 months. Say the close in three parts: what they see, what they are asked to do, what they risk. Name only specifics you take from the report or your own reading, and say aloud when something is an assumption.

## 5. Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A, 5 questions) | Deepa, your future manager: the POV itself, then live problems from her own roadmap | High. Hiring-manager prior is Case/Strategist plus Skeptic, and the recruiter built the first 15 minutes around a strategy deliverable | Clarify, then structure, then answer; challenge one premise respectfully; close on operators |
| Data-Driven Prober (B, 5) | Ross: "will push on commercials", so the £4M, the 6-to-40 and the economics of a partnership | High. The recruiter named the push, and your headline figures are your main commercial evidence (F3, F4) | Know how each number was counted, say plainly when you do not, name the weakest assumption first |
| Skeptic (C, 3) | Deepa, and Ross from the commercial side: the quota and rail gaps | Medium. Hiring-manager prior, and both gaps are stated in your own material | Rehearse C1 until boring; bridge only from what you have said; plan, never past |
| Pressure (D, 3) | Ross: the sixty-second "why you" and the objection from an operator | Medium. "Push" suggests it, but nothing in the recruiter's email says stress style | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational (E, 2) | Opening minutes after the POV, and motivation questions | Low to medium. Panel openers are friendly but still scored | A 90-second arc built only on your own sentences |

Not banked: Values (no values-style round is detected: the loop is established by your own account of it as one panel session and nothing says it assesses values; no cheat sheet is included), and Peer (neither interviewer is a peer).

## 6. Question banks

### A. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months, and land on what it means for the operators themselves." | CASE | [grounded] the recruiter's brief for the first 15 minutes | This is the deliverable; build it from Section 4, not from this cell. Shape: your assumptions in a minute, one grounded item from the report, two theses with a concession each, and the last three to four minutes entirely on operators: what they see, what they are asked to do, what they risk. Mark assumptions aloud as assumptions | The recruiter announced it as the opening, so it is certain to be asked. CASE because it is a live structuring task; F1 and F2 are the rows it leans on |
| A2 | "What would you want to know that you don't yet, before committing to that plan?" | CASE | [generic] | Name two or three unknowns, each tied to the decision it would change: which operators come first, what operators get from Kelverton today, what the commercial side can offer. Say who you would ask first. Do not fill an unknown with a guess about Kelverton's operators or numbers | A Strategist scores clarifying before answering, and your view is built without insider access (F1). CASE; it is also where a candid limit reads as judgment |
| A3 | "Take two operators, one large and one small, same product. How does your approach differ, and what does each get out of it?" | CASE | [generic] | Structure: what each needs, what each risks by committing, what you would ask of each, what each gets back. The last part is the one the recruiter asked you to land on. Keep it a method: you are not claiming to have partnered with either kind | The recruiter's "what it means for the operators themselves" turned into a live problem. CASE; F2 is the row it tests, and the guidance makes no claim from it |
| A4 | "Which of the priorities in our market report would you not pursue, and why?" | CO | [generic] | Reciting the report scores as homework. Bring one item to show you read it, then one place you diverge with a reason from the operator's side, then the thing you would say no to. Choose all three from your own reading: this pack has not seen the report | The report is a shared artifact, so differentiation is the signal. CO because it tests altitude on their strategy; the anti-pick is where the role's judgment shows |
| A5 | "How would we know in eighteen months that it had worked?" | CASE | [generic] | Offer two or three measures: one an operator would recognise as theirs, one Ross would recognise as commercial, one you could see early. Then name the assumption you would defend least before they ask, in your own words. Do not quote a target you cannot explain | Closes the POV on operators and doubles as the first commercial probe. CASE; it rehearses the weakest-assumption move on a number you have not been given yet |

### B. Data-Driven Prober (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Say it at the quote's scope: roughly £4M of influenced revenue, influenced and not owned. Answer slots for what a figure raises: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. For each, say what you know in your own words; if you do not know how something was counted, say so plainly. Do not let "influenced" become a stronger word under a second question | F4 is a headline figure and Ross will push on commercials. EXP because it tests whether the number survives scrutiny |
| B2 | "You took it from 6 partners to 40. What part of that was you personally?" | EXP | [grounded] "took it from 6 partners to 40" | Start from the quote in your words. Answer slot: a figure raises which part was yours. If you personally brought in some of the partners, say how many you know of and how, in your own words; if the team or the partners did some, say so plainly and return to the channel you ran. Be ready for what counted as a partner and say what you know of it | F4's second headline figure and the usual attribution probe. EXP; the question is premised only on the quote |
| B3 | "How would you structure the economics of an operator partnership, and who carries the risk if it doesn't land?" | CASE | [grounded] "never carried a direct quota, only influenced revenue" | Open by saying this is a structured view and that you have not carried a direct quota. Then: what each side is trying to achieve, the options for how value is shared, who carries what risk under each, and what you would need from Ross's team to choose. Answer slot: if any commercial terms in the ISV channel were yours to set or negotiate, say which and how you decided; if none were, say so plainly and answer from the structure | The recruiter says Ross will push on commercials, and F3 states the gap. CASE because it is a live commercial problem, so the guidance asks for structure, not a history |
| B4 | "What does a partnership cost us to run, and when does it pay back?" | CASE | [generic] | Say which cost lines you would ask Ross's team to confirm before offering any estimate, and what would change the payback. Answer slot: if you tracked what the ISV channel cost to run, say what you tracked; if you did not, say so plainly and say what you would measure first. Do not offer a payback figure you cannot defend | A commercial director will test unit economics. CASE; F3 is the row it presses |
| B5 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | The weakest-assumption move: name the one you know of, in your own words, before they do, then say what you would check. The pack does not name it. If you cannot name one, say plainly that you do not know how the number was built. Concede the assumption without retreating from the number at its own scope | The standard Prober stem for F4's figure. EXP; converting a gotcha into a credibility gain is the whole move |

### C. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never carried a quota. Why should I trust you with commercial outcomes here?" | JD | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue" | The highest-ROI rehearsal in this pack. The hold is your own words: "I've never carried a direct quota; what I've had is influenced revenue, roughly £4M." Hold through two follow-ups by returning to those words, never by adding to them. Follow-up one will ask what the difference is in practice; answer slot: say in your own words what influenced revenue meant day to day, and if you cannot say how it was attributed, say so plainly. Follow-up two will ask whether you would take a number here; answer slot: say your actual position, and if you would want the commercial model first, say so. Concede specifically that influenced is not owned, and say nothing that implies otherwise | The recruiter named Ross's push and F3 states the gap, so this arrives in some form. JD because it scores an expectation of the role; Skeptic persona, Pressure delivery |
| C2 | "You've never sold into rail. What would be different about partnering with train operating companies, and how quickly would you be credible?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Open with the plain acknowledgment: "I've never sold into rail specifically." Then what your material carries, at its scope: "I spent five years in transport consulting, in bus and light rail network planning." Name the limit before they do: bus and light rail, not train operating companies. Answer slot: say in your own words which side "the other side" was and what you saw of operators' decisions; if the work was not for operators, say so plainly and stay with the planning you did. Then the ramp as a plan, in the future tense: who you would listen to first and what you would read | F5 is a stated gap and F2 is its only adjacent evidence. JD; the persona is the future manager checking whether you can be credible with operators |
| C3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Pick one item from your own material and say how you would cover it as a plan. Your two stated gaps are selling into rail and a direct quota; choose the one you would rather say first. Do not reach for a weakness the material does not show just to sound candid, and do not dress a strength as a weakness | A stock Skeptic stem, and F3 and F5 are the honest answers. JD; it rehearses calibrated candor |

### D. Pressure (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already sold to train operators?" | JD | [grounded] "took it from 6 partners to 40"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "Never sold into rail specifically" | Pause, restate. Hold-then-concede in three beats, your words: "For my last four years I ran the ISV channel at a payments company and took it from 6 partners to 40." Then "I spent five years in bus and light rail network planning." Then concede: "I've never sold into rail specifically." Do not claim to be the better candidate; let them draw that. Hold through two follow-ups by returning to the three sentences | A time-boxed challenge on the F5 gap. JD; Pressure scores composure, not content |
| D2 | "An operator tells you the partnership costs them more than it gives them. You have thirty seconds." | CASE | [generic] | Pause and restate the objection. Ask what they are comparing it against. Answer from what the partnership gives them, and say what you would take back to the commercial team rather than offering terms yourself. Concede what you do not know about their costs | A live operator objection in Ross's commercial register. CASE; it tests the operator-side view the recruiter asked for |
| D3 | "You have no number to carry. What would you commit to in year one?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Commit to measures and a date by which you would set a target, not a figure you cannot defend. Answer slot: if you would commit to a number now, say it with its assumptions, in your own words; if you would want to see the commercial model first, say so plainly and say what you would check. Hold two follow-ups, and concede what you cannot yet know | F3's gap turned into a target-setting probe. JD; Pressure delivery of a commercial expectation |

### E. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the journey: consulting, then partnerships, then here." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | A 90-second arc with the two beats your sentences state: five years in transport consulting, in bus and light rail network planning; then the last four years running the ISV channel at a payments company, from 6 partners to 40. The connective is yours: your material does not say what moved you between them. Answer slot: say in your own words what drew you from each to the next; if there was no single reason, say so plainly | A casual opener that is still scored. EXP; F1 and F2 give the two beats and nothing else |
| E2 | "What draws you to scheduling software for train operators?" | CO | [generic] | A selection scaffold: pick one thing that genuinely draws you and name a specific, from the market report or from anything you have seen yourself, with one link to what it means for operators. If nothing specific comes to mind, say so plainly and say what you are most curious to learn. Do not claim knowledge of operators' scheduling problems you have not named | Motivation for the move into rail is asked casually by almost every warm interviewer. CO; the F5 gap makes a vague answer costly |

## 7. Requirement coverage

| Requirement | Questions |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" (F1) | A1, A2, A4, A5, Section 4 |
| "land on what it means for the operators themselves" (F2) | A1, A3, A5, D2, E1 |
| "Ross will push on commercials" (F3) | B1, B3, B4, B5, C1, D2, D3 |
| Grow and manage a portfolio of partners (F4, role-family) | B1, B2, B5, E1 |
| Credibility partnering into train operating companies (F5, role-family) | C2, C3, D1, E2 |
| Anything on the JD itself | none, because no JD was supplied; the upgrade menu says what it would add |

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail or has train operating company relationships | Negative you stated, F5 | The plain acknowledgment: "I've never sold into rail specifically." No slot |
| Carried a quota or owned a revenue number | Negative you stated, F3 | "I've never carried a direct quota; what I've had is influenced revenue, roughly £4M." The figure stays influenced |
| Owned, closed or delivered the £4M | Inflated form of F3 and F4 | The quote at its own scope: "roughly £4M of influenced revenue". The limit is the pack's observation, not words for you: the material says influenced |
| Personally recruited the partners, or set the channel's strategy alone | Inflated form of F4 | The quote at its own scope: "took it from 6 partners to 40". B2's slot asks only which part was yours |
| Knows train operating companies from the inside | Inflated form of F2 | The quote at its own scope. The limit is the pack's observation: the material says bus and light rail network planning, not train operating companies |

## 9. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To Deepa: "What would success look like in this role at six months and at eighteen, and which operator relationships does that depend on?" | It ties straight back to your POV and shows you are thinking about the same 18-month window |
| R2 | To Ross: "How do partnership-influenced deals show up in the commercial model today, and how would you want this role measured?" | It turns the quota gap into a practical question about how the role is held to account, and tells you what C1 is really testing |
| R3 | To Deepa: "Where does the team already disagree about the report's priorities?" | It signals you read it critically rather than reciting it, and invites the live debate your A4 answer joins |
| R4 | To both: "What do operators tell you today a partnership with Kelverton means to them?" | It is the question the recruiter asked you to land on, turned around; the answer shows how operator-centred the team is |
| R5 | To Deepa: "What have you already tried in operator partnerships that didn't land?" | A practical question a future manager can answer honestly, and it protects you from proposing something already tried |
| R6 | To both: "What would you want to see from me in the first ninety days?" | It converts the interview into planning together and tells you what the commercial side will judge first |

## 10. Sources

**Provided documents:** your message, which quotes the recruiter's email and describes your background and Kelverton. The market report attachment did not reach me and I have not read it. No dossier was present.

**Searches sent (all refused, none returned anything):**
- "Kelverton Rail values": refused
- "Kelverton Rail interview process partnerships manager": refused
- "Kelverton Rail scheduling software train operating companies strategy news": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Senior Partnerships Manager rail technology job description train operating companies": refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The search was refused. It would have fed a values read; no values-style round is detected here, so the cost is limited to VAL-themed questions |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | Refused. It would have documented loop structure; the loop stays as you described it |
| 3. `Kelverton Rail` strategy and recent news | unavailable | Refused, and the report's content is not in hand. It would have supplied CO and CASE material grounded in their current priorities; A4 and E2 stay `[generic]` |
| 4. `Deepa VP Partnerships Kelverton Rail` | unavailable | Refused. It would have fed an interviewer read and a reverse question tied to her path; there is none |
| 5. representative `Senior Partnerships Manager` JD | unavailable | Refused. It would have supplied `[inferred]` requirements; F4 and F5 are role-family prose instead |

## 11. Upgrade menu

- The JD text → the role-family rows F4 and F5 become quoted `[grounded]` requirements, the coverage table gains real rows, and JD-tagged questions stop resting on the recruiter's email alone
- The market report's text, or its headline findings pasted → a grounding brief section, a real consensus item, divergence and anti-pick for Section 4, and A4 and E2 turn from `[generic]` to `[grounded]`
- Your CV lines for the payments company and the consultancy → the "took it from 6 partners to 40" and £4M rows can be checked against what is written, and the five partnership years that your message does not describe could carry stories
- An inspectable artifact for the influenced-revenue figure, such as the partner pipeline report or attribution export that produced it → F3 and F4 can rise from `medium` to `high`
- One email to the recruiter asking which commercial topics Ross is likely to press on (pricing, terms, margin, payback) → bank B is aimed instead of inferred
- Public profile links or surnames for Deepa and Ross → an interviewer read, persona weights read from their footprint, and a reverse question tied to their path
- Search access → company values, documented loop structure and current strategy; a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) is available once search is permitted
- A tuesday-dossier.md from job-underwriter → verified evidence and prohibited claims arriving ready-made, in place of the ones built here from your message
