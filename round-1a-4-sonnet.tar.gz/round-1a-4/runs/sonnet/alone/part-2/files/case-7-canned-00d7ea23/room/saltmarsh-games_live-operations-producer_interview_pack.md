# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager. The session is the one 60-minute interview the company's interviewing page describes. Built for Femi.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did. Every line in quotation marks inside a guidance cell is proposed language, pending your approval and your edits.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | A stated responsibility or requirement in the job description |
| CO | Whether you know the company's current strategy and products |
| CASE | Structure and reasoning on a live problem |

## Prep triage

Do these in order. Everything else is insurance.

| Order | Do this | Where |
|---|---|---|
| 1 | Say the C1 answer aloud until it is boring. It is the highest-ROI prep in this pack | C1 |
| 2 | Run the outage tabletop aloud, timed, twice | A1, A2, E1 |
| 3 | Choose your own stories for the values conversation. B3 and B5 already have a quoted sentence behind them | B1 to B5 |
| 4 | Play both titles and read each latest patch notes against what the update changed | F2, A3 |
| 5 | Settle your honest answers to the two slots a prober will hit first: which years were live-service, and how the retention numbers were counted | C4, D1 |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | Your material gives four years as an associate producer and does not say how many were on a live-service game. Words: "For four years I was an associate producer at a puzzle-game studio." Answer slot: the JD's three-plus-years line makes a probe on which years were live-service likely. If any of the four were, say which and what you did in them, in your own words; if some were not, say so plainly and stay with the years you can name |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, not a live-events calendar or a second title. Words: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events and two-titles wording makes a probe likely on what a drop held and how a second title would change the calendar. If any drops were timed events, say how they differed from other drops; if none were, say so plainly and stay with the weekly drops you ran |
| F3 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it. The calendar itself is the inspectable artifact a producer keeps, so expect a probe. Lead in the quote's own terms: weekly, content-drop, main title, two years |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | The first quote touches the calendar and does not show which teams you worked with. The JD says coordinate, not lead, and you have said you never led a team, so the plain words are: "I haven't led a team." Answer slot: if you worked with design, art, engineering or community on the drops, say which and what you needed from each, in your own words; if some of those you did not work with, say so plainly |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you ran a post-event review or chose KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you set which numbers went into those reports, or reviewed a drop afterward, say what, in your own words; if that was not yours, say so plainly and stay with presenting the numbers |
| F6 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in the terms you stated, but a prober will ask how the numbers were counted. D1 holds the slots for that. Use the quote's own terms: monthly, retention numbers, studio head |
| F7 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | A checklist your QA team still uses is written work other people rely on. The bridge rewords only that quote: "I wrote the release checklist our QA team still uses." Your material shows no player-facing or stakeholder writing, and nothing is added for it |
| F8 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it, not that you ran releases against it with QA. Words: "I wrote the release checklist our QA team still uses." Answer slot: the JD's manage-with-QA wording makes a probe on how a release ran against it likely. If you ran releases against it with QA, say how; if QA ran it, or it was used without you, say so plainly and stay with writing it |
| F9 | Comfort with a paid season-pass game. Not in the JD; derived from Saltmarsh's September 2026 announcement (search result, see Sources) | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [inferred] | capability | The gap is one you stated. Words: "I haven't worked on a game with in-app purchases." Then a learning plan, said as a plan and never as a past (C1). Nothing is added to make the gap smaller |

The JD names no gate-type terms such as authorization, location or schedule, so no row is a hard gate.

## Reading the interviewer

Public professional footprint only, from one talk page.

| What is published | Source | What it means for you |
|---|---|---|
| Head of Live Operations at Saltmarsh Games; GDC 2026 talk "Patch Notes Are a Promise" | The talk page (see Sources) | He owns the function this role sits in, and his own published subject is patch-note honesty |
| His argument: a live team is judged by how often its patch notes describe what actually shipped | The talk page | Expect scrutiny of anything you say about announcing versus shipping: A1, E1, B2. Reverse question 1 picks up his argument |
| Previously a QA lead at a console studio | The talk page | The release checklist and QA hand-off will be read closely, so the F8 slot matters |

Mirror opportunity: release checklists. His background is QA; your quoted sentence is "Wrote the release checklist our QA team still uses." (F8). Offer it at its own scope and let him ask more. It is shared vocabulary, not a shared career jump, and the pack does not coach you to present it as one.

## Persona table

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The tabletop: a simulated outage during a live event | High. The interviewing page documents a live-incident tabletop on a simulated outage as the first part of the session, and the hiring-manager prior also tilts to cases | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully. A1 to A5 |
| Values / Behavioral | The values conversation after the tabletop | High. The same page says the tabletop is followed by a values conversation, and three values are published | Map a story to each value where a quoted sentence carries one; where none does, pick from your own experience, and if none comes to mind say so plainly. B1 to B5 |
| Skeptic | Probing the in-app-purchase and never-led-a-team gaps | Medium-high. A hiring manager is derisking gaps, and the season-pass announcement sits against your stated F9 gap | Rehearse the C1 objection until it is boring: state the limit plainly, hold what your quotes carry, concede specifically. C1 to C4 |
| Data-Driven Prober | Retention numbers and the post-event review | Medium. The JD names retention metrics and post-event KPIs, and you presented monthly retention numbers (F5, F6) | Say what you know about how the numbers were counted and say plainly what you do not. D1 to D3 |
| Pressure | Time-boxed moments inside the tabletop | Low-medium. The page does not say the tabletop is time-boxed; a live incident is a natural place for it | Pause, restate, hold a position through two follow-ups, concede only what is real. E1, E2 |
| Conversational | The opening and the closing | Low. Any 60-minute session opens with a biography question, and casual questions are still scored | A 90-second arc from your own sentences. F1, F2 |
| Peer Evaluator | Not weighted | The loop source names one session with the hiring manager and no peer round. No questions are written | None needed |

Persona weights rest on a documented loop: one 60-minute session with the hiring manager. The one assumption is that Tobias is that hiring manager.

## Question banks

Proposed language in every guidance cell is pending your approval.

### A. Case / Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Day two of a live event. A hotfix went out last night, crash reports are climbing, and some players can't enter the event. You're the producer on call. Walk me through your first fifteen minutes." | CASE | [inferred] derived from the interviewing page's tabletop on a simulated outage; the scenario itself is invented | Say your frame aloud first. Clarify: what is known, who is affected (platform, version, how many players), whether the hotfix is the cause, who owns the incident. Objective: protect players first, which is the company's own first value, "when the calendar and the players disagree, the players win". Approach: decide pause, rollback or continue with engineering. Send one short player message with only what is confirmed and when the next update comes. Keep a time-stamped record for the post-event review. Close with the risk you would name and what you do not yet know. The guidance makes no claim about your past | The page describes a simulated-outage tabletop, so this is the likeliest format. CASE because it scores clarification and structure; no fit row is involved since it asks about no past |
| A2 | "Engineering says the fix needs until tomorrow. Community already announced the event ends tonight, and art has a reward drop tied to that date. Do you extend the event?" | CASE | [inferred] derived from the same page and the values page | Make the call and show the trade. Ask what players have already lost. Compare extending with compensating. Lean on the published value: when the calendar and the players disagree, the players win. Name what an extension costs downstream and who you tell. State the assumption your call rests on, and concede what you cannot know from the chair. Challenge one premise politely, for example whether the original date is the only one players were told. The guidance makes no claim about your past | A tabletop follow-up is usually an escalation of the first problem; this one tests the value the company publishes first. CASE, with VAL overtones |
| A3 | "From February 2027, Tidepool Tactics and Lantern Row move to a season pass with one shared events calendar. What do you want to know before you build the first month of it?" | CO | [grounded] research: the Project Larkspur announcement. "I ran the weekly content-drop calendar for our main title for the last two years." | Use the announcement's own vocabulary once: season pass, shared events calendar. Clarify before structuring: what the pass rewards and how events feed it; which events would cross both titles; who arbitrates when the titles' dates collide; what the per-title teams hand over. Then compare with your quoted sentence at its own scope: a weekly content-drop calendar for one main title, and say that it was one title. Answer slot: if you ever had to reconcile two schedules, say how; if not, say so plainly and put the questions above in its place. The JD does not name its two titles, so ask which they are (reverse question 2) | The announcement is the freshest strategy fact in the research, and the JD's two-title line (F2) sits beside it. CO because it scores knowing the company's current moves |
| A4 | "Day-seven retention for new players dropped the week after an event. Diagnose it." | CASE | [generic] | Clarify first: which cohort, against what baseline, and whether anything else shipped that week, such as a version, a store change or a campaign. Check the data before the game: did an instrumentation change move the number? Segment new versus returning players, event participants versus non-participants, platform, country. Rank the hypotheses and check the cheapest one first. Answer slot: name, in your own words, the assumption in your diagnosis that you would defend least | The JD asks for comfort with player-retention metrics (F6) and the stem is a standard live-ops diagnosis. CASE because it scores structure; the weakest-assumption slot is the metric-type bar |
| A5 | "Talk me through what has to be true before an event update ships. The release checklist." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F8. The beats are the ones the quote states: you wrote the checklist, and your QA team still uses it. Tell them in your own words. Say what it contains in your own words; this pack supplies no items. Answer slot: the JD's manage-with-QA wording makes a probe on how a release ran against it likely. If you ran releases against it with QA, say how; if QA ran it, or it was used without you, say so plainly and stay with writing it | F8 is the JD's checklist requirement and your strongest quoted artifact. JD content with CASE delivery |

### B. Values / Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which won?" | VAL | [grounded] | Players Before Plans, in the company's words: "when the calendar and the players disagree, the players win". Selection scaffold: pick an instance where a date or planned drop pulled against what players were experiencing. It needs a named stake, the call you made, and who you told. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it using the A2 structure | The values page publishes this value first, and the loop page says a values conversation follows the tabletop. VAL; no fit row carries a story for it |
| B2 | "Tell me about a time you held back an announcement because the thing wasn't built or fixed yet." | VAL | [grounded] | Ship the Patch Not the Promise: "we announce what is built, not what is hoped". Selection scaffold: pick an instance where an announcement or a date was ready and the work was not. Name the stake, what you said instead, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | The second published value, and the subject of the interviewer's own talk. VAL; no fit row carries a story for it |
| B3 | "When have you left a process or a checklist better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Leave the Build Greener: "every release leaves the codebase and the checklist better than it found them". Story-mapped on F8: you wrote the checklist, and your QA team still uses it. Answer slot: if you changed the checklist over later releases, say what changed and why, in your own words; if it was written once and not revised, say so plainly and stay with writing it | The third published value names the checklist itself. VAL, with a quoted sentence behind it |
| B4 | "Tell me about a time you delivered an unpopular truth to a stakeholder." | VAL | [generic] | Selection scaffold: pick an instance with a named stake, what you actually said, and a relationship still intact afterward. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | A standard values-round prompt tied to the honesty theme of the interviewer's talk. VAL; no fit row carries a story for it |
| B5 | "Tell me about a time a number you presented was not the number the room wanted." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F5. The beats are the quote's: monthly, retention numbers, the studio head. Answer slot: if any month's numbers were unwelcome, say what you said and which part of it was yours; if none were, say so plainly and stay with presenting them | Links the honesty values to the one metrics sentence you have. VAL, with an EXP edge |

### C. Skeptic (weight: medium-high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our two titles are moving to a season pass. You haven't worked on a game with in-app purchases. Where does that leave you on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. Open with the limit, in your own words: "I haven't worked on a game with in-app purchases." Then what you can say at its own scope: the weekly content-drop calendar for your main title, and the monthly retention numbers you presented. Do not say it transfers; let him draw the inference. Then a plan, said as a plan: play both titles, read how the pass and the events fit together, ask which KPIs the post-event review reports, ask who owns the revenue-side numbers and sit in. Hold through three follow-ups. (1) "Why not someone who has shipped a pass?" Return to the limit and the plan; never add to the past. (2) "What would you get wrong in month one?" Answer slot: name, in your own words, the thing you would most likely get wrong; if you do not know, say so. (3) "You'd report KPIs you've never owned?" Return to the F5 quote at its own scope, then the plan | The announcement makes the season pass the likeliest place for a hiring manager to press, and F9 is the gap you stated. JD because it scores a gap against the role; deepest rehearsal because it will be asked in some form |
| C2 | "You've never led a team. How would you get design, art and engineering to move when a date slips?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the limit in your words: "I haven't led a team." Then describe how you would do it: who you tell first, what you offer each discipline, and what you would keep in the calendar. Answer slot: if you coordinated with design, art, engineering or community on the drops, say which and what you needed from each; if some of those you did not work with, say so plainly. Stay with the weekly calendar you ran for the main title | The JD's coordination line (F4) is where the stated never-led gap meets the role. JD, with a pressure edge |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Presented the monthly retention numbers to the studio head." "Wrote the release checklist our QA team still uses." | Calibrated candor beats bluffing. Choose the requirement where your sentences reach least, and say what each of your sentences covers. F2, F5 and F8 are the rows where your quotes sit beside the JD line without reaching it. Use the quotes at their own scope, then give a ramp plan for the one you name. If you pick another, hold it to the same rule: say only what your sentence says | A standard hiring-manager question aimed at the F-row gaps. JD because it scores the stated requirements |
| C4 | "The JD asks for three-plus years producing live-service games. Which of your four years was that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Answer slot: say which years were live-service and what you did in them, in your own words; if some were not, say so plainly and stay with the years you can name. Do not round the four years up to three-plus years of live-service production | F1 is a discovery gap and a literal reading of the line is common. JD because it scores the requirement directly |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Defend-the-number slots, each in your own words: how the number was counted; what it is sensitive to; the assumption you would defend least; and which part was yours. If you do not know how it was counted, say so plainly. This pack supplies no method, baseline or figure | You gave no figure, so the probe goes to how the numbers were made (F6). EXP because it scores whether your claim survives a second question |
| D2 | "After an event ends, what would you put in the post-event review, and which KPIs would it report?" | JD | [inferred] derived from the JD's post-event review line | Structure it as a plan, not a past: what was planned versus what happened, player impact, results against a baseline set before the event, and what changes next time (the published value, leave the checklist better than you found it). Choose KPIs tied to the event's goal and ask which ones the group already reports. Answer slot: if you have reviewed a drop afterward, say what it covered in your own words; if not, say so plainly and stay with presenting the monthly numbers | The JD gives you the post-event review and its KPIs (F5). JD because it scores that line; a probe on the answer is likely |
| D3 | "Retention is the headline metric here. Which retention measure would you use to judge an event, and what is the weakest assumption in it?" | JD | [generic] | Pick one measure and say what you would compare it against. Answer slot: name, in your own words, the assumption you would defend least. State it before he does; it turns a gotcha into credibility | The JD asks for comfort with retention metrics (F6), and the weakest-assumption move is the metric-type bar. JD because it scores that requirement |

### E. Pressure (weight: low-medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Ninety seconds. Players are mid-event, it's broken, and engineering says two hours. What does community say right now?" | CASE | [inferred] derived from the tabletop page and the values page | Pause and restate the question. Draft two sentences aloud: what is confirmed, and when the next update comes. Hold the published principle, "we announce what is built, not what is hoped". If he says "just tell them it's fixed", hold, and say why in one line. Concede specifically what you do not know, such as the time to fix. The guidance makes no claim about your past | Pressure inside the tabletop is the likeliest form. CASE with a pressure delivery; it also tests the written-communication line |
| E2 | "That calendar you ran. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold what the quote carries: "For the last two years I ran the weekly content-drop calendar for our main title." Hold it through two follow-ups. Answer slot: if you set the dates, say so; if others set them and you ran the schedule, or someone else ran part of it, say so plainly and return to the quote. Never fold on the core claim just to restore harmony | The attribution probe is the standard pressure move on a CV line. EXP because it scores what was yours |

### F. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc in your own words, using the four quoted sentences at their own scope and in this order. Add nothing to them. Answer slot: why Saltmarsh and why now are yours to say; this pack supplies no reasons | The opening biography question is near-universal and still scored. EXP because it is your own record in order |
| F2 | "Have you played either of our titles, and what did you notice about how events run?" | CO | [grounded] research: the announcement and the talk page | Instruction for before Friday: play Tidepool Tactics and Lantern Row, and read each latest patch notes against what the update changed. His published argument is that patch notes are judged by whether they match what shipped. Answer only with what you saw; if you have not played one, say so plainly. The JD does not name its two titles, so confirm which with reverse question 2 | The company's titles come from the announcement, and the talk page makes patch-note accuracy his theme. CO because it scores homework depth |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "3+ years producing live-service games or apps" | C4, C3, F1 |
| "experience running a content calendar" | E2, A3, F1 |
| "Plan and run the live-events calendar for two of our mobile titles" | A3, A2, C3 |
| "coordinate design, art, engineering and community teams on each update" | C2, A1, A2 |
| "own the post-event review and the KPIs it reports" | D2, B5, D3 |
| "manage the release checklist with QA" | A5, B3 |
| "comfortable with player-retention metrics" | A4, D1, D3 |
| "clear written communication" | E1, B2, B3 |
| Not in the JD: season pass and in-app purchases (F9) | C1, A3 |

## Values cheat sheet

A values conversation is documented in the loop source, so every published value gets a row.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the player experience pull apart, the player experience wins | No quoted sentence carries one. Selection scaffold in B1: a named stake, the call, who you told; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence carries one. Selection scaffold in B2, ending the same way |
| Leave the Build Greener | Each release leaves the build and the checklist better than it found them | F8: "Wrote the release checklist our QA team still uses." Beats: you wrote it, and QA still uses it; B3 holds the slot on later changes |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Your GDC talk argued that a live team is judged by whether its patch notes match what shipped. After an update, who checks that, and how?" | It picks up his published argument and shows you researched him, not only the company |
| 2 | "Which two titles does this role cover, and with per-title event teams retiring from February, what does the producer own in the first quarter?" | It settles whether the JD's two titles are the ones in the announcement and shows you read the strategy |
| 3 | "You came to live operations from QA. What carried over that you would want a new producer to have?" | It ties to his own path and invites a conversation about the release checklist |
| 4 | "What would you want a new producer to have learned about how the season pass works by the end of the first month?" | It shows you plan to close the in-app-purchase gap and asks what good looks like |
| 5 | "What does the post-event review look like today, and which KPIs does it report?" | It tests your JD requirement against the real practice and previews the work |
| 6 | "What would make you say in six months that this hire is working?" | It asks for the success bar you will be measured against |

## Prohibited claims

Built from the fit snapshot before the banks were written.

| Not coached | Basis | Honest form |
|---|---|---|
| Worked on a game with in-app purchases, or a season pass | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." A plan, said as a plan. No slot |
| Led a team, or the design, art, engineering or community teams | Negative you stated, F4 | The plain acknowledgment: "I haven't led a team." C2's slot asks only which teams you worked with |
| Planned the live-events calendar for two titles | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says one main title and a content-drop calendar |
| Owned the post-event review and chose its KPIs | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says presenting the numbers |
| Managed the release checklist with QA on each release | Inflated form of F8 | F8's quote at its own scope. The limit is the pack's observation: your material says writing it, and QA still using it |
| Three-plus years producing live-service games | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says four years as an associate producer |

## Sources

Provided documents: the JD text; your background in your own words.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and B1 to B3: three published values by name |
| 2. Saltmarsh Games interview process, live operations producer | yes | Loop: one 60-minute hiring-manager session, tabletop then values conversation, no take-home; persona weights and the values section follow it |
| 3. Saltmarsh Games strategy and recent news | yes | A3, F2, C1 and reverse questions 2 and 4. The announcement was read as a search-result snippet, not fetched |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Interviewer read and reverse questions 1 and 3. The talk page was read as a search-result snippet, not fetched |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches and fetches sent:

- Search "Saltmarsh Games values" returned https://saltmarshgames.com/values
- Search "Saltmarsh Games interview process live operations producer" returned https://saltmarshgames.com/careers/interviewing
- Search "Saltmarsh Games mobile studio news strategy" returned https://saltmarshgames.com/news/project-larkspur
- Search "Tobias Wrenfield Saltmarsh Games" returned https://talks.gdconf.example/2026/patch-notes-are-a-promise
- Fetch https://saltmarshgames.com/values returned the page text
- Fetch https://saltmarshgames.com/careers/interviewing returned the page text

What the sources say, as read: the announcement is dated September 2026 and says Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027, retiring per-title event teams in favour of a single live-ops group. The talk page describes Tobias Wrenfield as Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio.

## Upgrade menu

- Confirmation that Tobias is the hiring manager, and anything the recruiter said about what the tabletop covers: it would confirm or reweight every bank, and usually takes one email
- A screenshot or export of a weekly content-drop calendar you ran: the inspectable artifact that would move F2 and F3 from medium toward high
- Which of your four years were on a live-service title, and what you did in each: it would turn F1's slot into quoted evidence and update C4
- Your own answers to the slots in F2, F4, F5 and F8: each would become a quoted sentence, and the rows and banks that draw on them would be regenerated
- A writing sample such as a patch note or a review document: it would give F7 real evidence
- A tuesday-dossier.md from an earlier evaluation of this role: it would add verified evidence, binding prohibited claims and an evidence-derived top objection in place of the one inferred here
