# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi. **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Round:** the single 60-minute interview, built on the assumption that Tobias is the hiring manager running it (the careers page, read in Sources, describes that interview as a live-incident tabletop followed by a values conversation). Persona weights rest on that assumption and move if it is wrong.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: use your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether the claims in your material survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's current strategy |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` is traceable to your message, the JD or cited research; `[inferred]` is derived from an adjacent source with the derivation named; `[generic]` is a role-family pattern with no claim about this company or you. An answer slot is an instruction for the interview, not a question for you to answer here.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not a live-events calendar and not two titles, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on running more than one calendar likely. If your calendar ever had to be fitted around another title or team, say how, in your own words; if it did not, or you ran only the one, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams the weekly drops involved. The JD's word is coordinate; the sentence in F9 says you have not led a team, which is a different claim from not coordinating, and the material is silent on coordinating. Answer slot: if you worked with any of design, art, engineering or community on a drop, say which and what each needed from you, in your own words; if none, or someone else ran that side, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says presenting the monthly retention numbers, not owning a review or the KPIs, and the words stay there: "Presented the monthly retention numbers to the studio head." Answer slot: the JD's own line makes a probe on who chose what was reported likely. If any of that choosing was yours, say which, in your own words; if you presented numbers someone else chose, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap in terms, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you wrote the checklist, and your QA team still uses it. Do not widen it to managing releases |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | A years requirement is graded like any other, not a gate. Your material gives four years as an associate producer and two on the calendar, and does not say whether the title was live-service throughout. Answer slot: if the title was live for all four years, say so; if only for some, say which years and stay with the two on the calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | Your closest direct match. Lead with it in its own terms: weekly, your main title, the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement in role terms. You gave no figure, so expect a probe on how the numbers were counted; D1 rehearses it |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A written document others use touches the requirement but does not show how much else you wrote. Answer slot: if you wrote anything beyond the checklist that others relied on, name it in your own words; if not, say so plainly and stay with the checklist |
| F9 | "two of our mobile titles" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The Outage Hour tabletop: a simulated outage during a live event | High. [grounded] The careers page describes the interview as a live-incident tabletop on a simulated outage, then a values conversation. The hiring-manager prior also tilts to Case. The scenario itself is not public | Clarify, objective, who you pull in, decision, communication, what you record. Think aloud, challenge one premise |
| Values/Behavioral | The second half of the same hour | High. [grounded] Same page: a values conversation follows the tabletop, and the three published values are fetched | A story or an honest scaffold per value; "we" for context, "I" for contribution |
| Skeptic | Quiet probing of in-app purchases, team leadership, two titles and live-service years | High. Hiring-manager prior, plus F2, F3, F5 and F9 are exactly where the material is thin | Rehearse C1 until it is boring. Bridges only from your own sentences |
| Data-Driven Prober | Follow-ups on how a retention number was counted and who wrote the checklist | Medium. [inferred] The interviewer's published thesis is about patch notes matching what shipped, which suggests attention to precise claims | Know what you can and cannot say about how the numbers were counted; say plainly when you do not know |
| Pressure | Time-boxed pushback inside the tabletop | Low to medium. No source says the tabletop is time-boxed; the sixty-second stem is standard for a hiring manager weighing a gap | Pause, restate, hold through two follow-ups, concede only what is true |
| Conversational | An opener such as "walk me through the journey" | Low to medium. A recruiter call comes before this round per the careers page, so the opener is likely short but still scored | A 90-second arc built only from your own sentences |
| Peer Evaluator | Not included | The round is a hiring-manager interview, so a peer register is not plausible | Add a bank if you learn a peer joins the hour |

## Reading the interviewer

| Point | Detail | Provenance |
|---|---|---|
| Career pattern | Head of Live Operations at Saltmarsh, previously a QA lead at a console studio | [grounded] one search result, not fetched |
| Published argument | GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | [grounded] same search result |
| Implication 1 | Precise claims are the currency. Say what shipped, not what was hoped; this matches the published value Ship the Patch Not the Promise | [inferred] from the talk title and the values page |
| Implication 2 | A QA background suggests the checklist is a natural topic. Mirror opportunity: "Wrote the release checklist our QA team still uses." (F4) is your side of a shared vocabulary; use it only at that scope | [inferred] |
| Implication 3 | Do not open with the talk unless asked; a reverse question about it lands better (see Reverse questions) | [generic] |

Public professional footprint only. Nothing else about the interviewer was sought.

## Question banks

### A. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is the second evening of a live event. Players report the event reward isn't arriving and the support queue is climbing. You're the producer on call. What do you do in the first thirty minutes, and what do you post to players first?" | CASE | [generic] | Think aloud in this order. What you need to know first: what is failing, who is affected, which platforms, whether it began with a change. Objective: limit harm to players while facts are unclear. Who you pull in and what you ask each; the JD names design, art, engineering and community, so name the ones whose answer you need. The decision you put to the team: pause, patch, extend or compensate. What you record for the review. For the player notice: what is known, what is being done, when the next update comes, nothing promised that you cannot yet confirm. Challenge one premise respectfully, for example whether the fault is event-only. The question needs no claim about your past, so the guidance makes none | The careers page describes a tabletop of this kind, so this is the likeliest shape of the first half. CASE because it scores structure under pressure; the written notice carries the JD's written-communication line. `[generic]` because the real scenario is not public |
| A2 | "A weekend event launches Friday at 18:00. At 14:00 QA tells you one reward tier still fails on one platform, and the event has been announced. Ship, delay or cut the tier, and who decides?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Clarify what fails, how severe, whether the tier can be switched off, and the fix time. Lay out each option with its cost, recommend one, and say what would change your mind. Hold the recommendation through a challenge and concede the cost of the option you rejected. On the checklist, say what your sentence says: "I wrote the release checklist our QA team still uses." Answer slot: the JD's checklist-with-QA line makes a probe on a time a checklist item blocked a release likely. If one did, say what it was and what part of the call was yours; if none ever did, or the call was not yours, say so plainly and stay with the checklist you wrote | Rests on F4 and the JD's release-checklist requirement; the published value about announcing only what is built pulls the same way. CASE with JD content |
| A3 | "From February, two titles share one events calendar and both want the same weekend for their biggest event. Engineering can support one. How do you decide?" | CASE | [inferred] "I ran the weekly content-drop calendar for our main title for the last two years." | Derivation: the shared-calendar premise comes from the Project Larkspur announcement result and the JD's two-title line; the scenario is this pack's, not a known Saltmarsh case. Clarify what each event is for, what has been promised to players, and what engineering can move. Set criteria: player impact, commitments made, cost of moving each, what can be staggered. Decide, and say what you tell the team that loses the slot. Say plainly what you ran: "I ran the weekly content-drop calendar for our main title for the last two years." This question is about two titles, so answer it as a plan. Answer slot: if you ever had to choose between two things wanting the same drop date, say what you chose and how, in your own words; if you never did, say so plainly and give the plan | F1 is the evidence for the calendar requirement and its limit. CASE because it asks for a decision with a stated criterion |
| A4 | "Day-7 retention for players who joined during this event is down against the last event. Diagnose it." | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Clarify first: down by how much, which cohort and platform, what changed in the event, the build or the player mix. Say how you would count day-7. Segment, rank hypotheses, name what you would check first, and say what you could not tell yet. Name the assumption in the measurement you would defend least. Your sentence is "Presented the monthly retention numbers to the studio head." Answer slot: the JD's retention line makes a probe on whether you also diagnosed movements likely. If you did, say how you went about one, in your own words; if you presented numbers someone else analysed, say so plainly and answer this as the plan | F7 and the JD retention requirement. CASE because it is a live diagnosis |
| A5 | "We have announced a single live-ops group and one shared events calendar from February. What do you think that changes about this role?" | CO | [grounded] research: Project Larkspur announcement result | Say what you read: per the announcement result, Project Larkspur moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027 and retires per-title event teams in favour of a single live-ops group. Then give a hypothesis tied to the JD's two-title calendar, and say what you would want to confirm. Do not claim knowledge beyond the announcement; ask which parts are settled. No claim about your past | The differentiator question most candidates will not touch. Only the search result was read, not the full page, so treat details as provisional |

### B. Values/Behavioral (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the schedule and the players pulled in different directions. What did you do?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Value: Players Before Plans, published as "when the calendar and the players disagree, the players win". Selection scaffold: pick a time a date you owned conflicted with something players needed. It needs a named stake, the moment you chose, and what happened to the date. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it. "We" for context, "I" for your part | The careers page names a values conversation as the second half. Rests on F6 only for the nearest-thing fallback |
| B2 | "Tell me about a time you had to say something wasn't ready." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Value: Ship the Patch Not the Promise, published as "we announce what is built, not what is hoped". Selection scaffold: pick a time you held back or corrected a claim before it reached others. It needs the claim, who wanted it, and what you said. If none comes to mind, say so plainly, then give the nearest thing: "I wrote the release checklist our QA team still uses", or how you would handle it | VAL on the value closest to the interviewer's published talk title. Rests on F4 |
| B3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Value: Leave the Build Greener, published as every release leaving the codebase and the checklist better than it found them. Story-mapped beats the sentence states: you wrote the checklist; your QA team still uses it. Answer slot: the value's wording makes a probe on how the checklist changed after a release likely. If it was revised after releases, say what changed and why, and what part was yours; if it was not revised, or the changes were not yours, say so plainly and stay with the checklist you wrote | F4 is the only quote carrying a story for this value. VAL because it scores a specific published value |
| B4 | "Tell me about a time a retention number you presented was not what the room wanted to hear." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time a number you presented was unwelcome. It needs the number, the room, what you said and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing, "Presented the monthly retention numbers to the studio head", or how you would handle it. "I" only for what you said | The unpopular-truth stem applied to F3 and F7. VAL with EXP content |

### C. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've said you haven't worked on a game with in-app purchases. What does that cost you in your first three months, and how do you close it?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | **Highest-ROI prep in this pack.** Open by saying it plainly, first: "I haven't worked on a game with in-app purchases." Then the plan, as a plan: what you would learn first and from whom, in your own words. Level 1, "so you can't read the revenue side": concede that, and stay with what your material carries, "Presented the monthly retention numbers to the studio head." Level 2, "that's a different thing": agree it is different; do not argue that it transfers. Level 3, "why take the risk on you": return to what you ran, in its own words. The limit: your material says nothing about revenue figures, so never imply you have seen them. Never claim to understand monetisation | The most predictable objection to this candidate, aimed exactly where F9 is stated. JD because it scores a listed role, mobile titles, against a stated gap |
| C2 | "The JD has you coordinating design, art, engineering and community on every update. You've said you've never led a team. Where does that bite?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Say it plainly: "I haven't led a team." You may point out that the JD's word is coordinate; say that as a reading of the JD, not as proof. Answer slot: the JD's line makes a probe on which teams you worked with directly likely. If you worked with any of design, art, engineering or community on the weekly drops, say which and what each needed from you; if none, or someone else ran that side, say so plainly and stay with the calendar you ran. Hold through one follow-up; concede what you have not done | F2 is silent and F9 is stated; this question pushes on both. JD because it scores a listed duty |
| C3 | "The role runs the calendar for two titles. What is different about two from the calendar you ran?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the sentence at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." Then a plan for what you would set up first with two titles, said as a plan. Answer slot: if you ever worked around a second title's schedule, say how, in your own words; if you did not, say so plainly and give the plan | F1's limit rehearsed before the probe arrives |
| C4 | "Your four years were at a puzzle studio. Walk me through a typical week on the content-drop calendar you ran." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped beats the sentences state: four years as an associate producer at a puzzle-game studio; the last two on the weekly content-drop calendar for your main title. Tell the week in your own words. Answer slot: the JD asks for 3+ years of live-service work, so expect a probe on whether the title was live throughout. If it was live for all four years, say so; if only for some, say which years and stay with the two on the calendar | F5 is a discovery row, so the probe is likely. EXP because it tests whether the calendar claim survives a walk-through |

### D. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which retention number did you present most, and how was it counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Defend-the-number slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F7; the metric probe every prober runs. No figure was given, so every slot is open |
| D2 | "Walk me through the post-event review you would run. What is the first KPI and who is in the room?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer as a plan: purpose, what you would report first and how it is counted, who is in the room, and what the review decides. Answer slot: the JD says you would own the review, so expect a probe on whether you have run one. If you have run reviews of released content, say what yours covered, in your own words; if not, say so plainly and answer as the plan | F3, the JD's ownership line. JD with CASE delivery |
| D3 | "You wrote the release checklist. Has it changed since, and who changed it?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say what the sentence says: you wrote it; your QA team still uses it. Answer slot: if it has been revised since, say what changed and who did it; if it has not, or the changes were not yours, say so plainly | F4 is the line a QA-trained interviewer is likeliest to open up |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, with no in-app-purchase experience, over a candidate who has it?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Pause and restate. Hold what your sentences carry: "I ran the weekly content-drop calendar for our main title for the last two years." Concede plainly: "I haven't worked on a game with in-app purchases." Do not claim you would learn faster or that the gap is small. Hold through two follow-ups | C1 in time-boxed form. Pressure scores composure, not content |
| E2 | "That checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold what the sentence says: you wrote it. Answer slot: if others contributed, say who and what; if you wrote it alone, say so plainly. Do not narrow or widen the sentence under pressure | Attribution probe on F4 |

### F. Conversational (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from your sentences: four years as an associate producer at a puzzle-game studio; the last two on the weekly content-drop calendar for your main title; you wrote the release checklist your QA team still uses; you presented the monthly retention numbers to the studio head. Then give your own reason for live operations and for Saltmarsh, in your own words | The biography opener is scored even when it feels casual. Rests on F5, F6, F4 and F7 |
| F2 | "I gave a talk this year called 'Patch Notes Are a Promise.' Where do you land on that?" | CO | [grounded] research: the GDC 2026 talk result | The result describes the argument as a live team being judged by how often its patch notes describe what actually shipped. Say in your own words what that means for player trust and what an honest note contains: what is known, what is fixed, what is pending. If you have only read the abstract, say so. No claim about your past | A plausible rapport move from this interviewer. Only a search result was read, so keep it to that scope |

## Values cheat sheet

The careers page documents a values conversation, and the three values are published at saltmarshgames.com/values.

| Value | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Players Before Plans | When a plan and the players' interest diverge, the players' interest wins | Selection scaffold on F6: nearest thing in your material is "I ran the weekly content-drop calendar for our main title for the last two years." Pick a time a date you owned conflicted with something players needed; if none comes to mind, say so plainly, then give that sentence or how you would handle it (B1) |
| Ship the Patch Not the Promise | Announce what exists, not what is hoped for | Selection scaffold on F4: nearest thing is "Wrote the release checklist our QA team still uses." Pick a time you held back or corrected a claim; if none comes to mind, say so plainly, then give that sentence or how you would handle it (B2) |
| Leave the Build Greener | Each release should leave the code and the checklist in better shape | Story on F4: "Wrote the release checklist our QA team still uses." Beats: you wrote it; QA still uses it. Whether it was revised after releases is an answer slot (B3) |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You came into live operations from QA. What from that background ended up mattering most when running live events, and what should a producer take from it?" | Ties to the interviewer's own path, and invites the conversation about checklists you already have a sentence for |
| R2 | "Your talk argues a live team is judged by whether its patch notes match what shipped. How do you measure that here?" | Shows you looked at their published thinking and asks for a measure, which suits a producer who reports KPIs |
| R3 | "With per-title event teams moving into one live-ops group, where would this role sit, and how many titles' calendars would it carry?" | Uses the announcement and the JD's two-title line; the answer shapes your first quarter |
| R4 | "What does a good first ninety days look like, and what would tell you in the first month that the hire is working?" | Lets you ask what success is before they judge it |
| R5 | "What separates the producers who did well in their first six months here from those who struggled?" | Surfaces the real bar, including how much weight falls on the monetisation side |
| R6 | "Where would you expect me to need the most support first?" | Gives you room to raise the in-app-purchase gap yourself, in your words, and to ask how it is usually closed |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, C3, C4 |
| "coordinate design, art, engineering and community teams on each update" | A1, C2 |
| "own the post-event review and the KPIs it reports" | D2, A4, D1 |
| "manage the release checklist with QA" | A2, B3, D3, E2 |
| "3+ years producing live-service games or apps" | C4, F1 |
| "experience running a content calendar" | C3, C4, B1 |
| "comfortable with player-retention metrics" | A4, D1, B4 |
| "clear written communication" | A1 — none other, and why: your material gives one written artifact, so a second question would only repeat F8's slot |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative you stated, F9 | "I haven't led a team." No slot |
| Has worked on a game with in-app purchases or monetisation | Negative you stated, F9 | "I haven't worked on a game with in-app purchases." No slot |
| Ran the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says a weekly content-drop calendar for your main title |
| Owned the post-event review and the KPIs | Inflated form of F3 | F3's quote at its own scope: presenting the monthly retention numbers |
| Managed releases with QA | Inflated form of F4 | F4's quote at its own scope: you wrote the checklist QA still uses |

Coordination across design, art, engineering and community, and live-service years, are not listed: the material is silent on both, so they are answer slots (F2, F5).

## Sources

**Provided:** the job description and your background, both in your message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Search "Saltmarsh Games values" returned saltmarshgames.com/values, fetched. Supplies the three value names for B1 to B3 and the values cheat sheet |
| 2. Saltmarsh Games interview process, Live Operations Producer | yes | Search returned saltmarshgames.com/careers/interviewing, fetched. Establishes this session as a single 60-minute hiring-manager interview, tabletop then values conversation, no take-home. Fixes persona weights and drops graded deliverables |
| 3. Saltmarsh Games strategy and recent news | yes | Search "Saltmarsh Games mobile studio news strategy" returned saltmarshgames.com/news/project-larkspur. Result text only, not fetched. Feeds A3, A5 and R3 |
| 4. Tobias Wrenfield Saltmarsh Games | yes | Search returned talks.gdconf.example/2026/patch-notes-are-a-promise. Result text only, not fetched. Feeds the interviewer read, F2 and R1, R2 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

No dossier was present.

## Upgrade menu

- The recruiter's note on the Outage Hour (which title or scenario the simulated outage uses, and who runs it) → A1 to A3 can be tuned to the real scenario, and the hiring-manager assumption is confirmed or corrected
- Your answers to the answer slots on F1, F2, F3, F5 and F8, in your own words → those rows move from discovery or transferability toward `[grounded]` guidance
- Your release checklist, a content-calendar sample or a retention deck (the artifacts a producer's work leaves behind) → F4, F6 and F7 can rise from medium to high confidence
- A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes: the full Project Larkspur announcement, more of Tobias's talks and writing, loop reports and recent org context → A5, F2 and the reverse questions become firmer; run only on your say-so
- A tuesday-dossier.md from an earlier evidence-checking pass → verified evidence and strategy limits per weak area, replacing the inferred top objection
- How many hours you have before Friday → a prioritised prep schedule
