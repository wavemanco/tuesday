# Interview prep pack — Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Built:** 24 November 2026, for three rounds on 3 December 2026 (loop mode: one shared fit snapshot, then a mini-pack per round).
**Interviewers:** none assigned yet, so there is no interviewer read and persona weights rest on the round types the recruiter described, not on named people.

| Round | Who (from the recruiter's email) | Length | What it is |
|---|---|---|---|
| 1 | The recruiter | 30 min | Screen |
| 2 | Head of Member Services, who would be your manager | 45 min | Mostly behavioural |
| 3 | Panel of two branch managers | 60 min | Values round, scored against the four published values, including a 20-minute complaint-escalation case |

## How to use this pack

- **Personas describe how a question is asked; types describe what is scored.** Types: **VAL** (behaviour against Ashgrove's published values), **EXP** (does your background survive scrutiny), **JD** (the listed job, including its gaps), **CO** (company and strategy knowledge), **CASE** (a live problem).
- Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.
- **Answer slots** are instructions for the interview, not questions for you now. Each has two honest branches, and the second always allows that the thing never happened or was not yours. Both branches are good answers.
- **Question IDs** run by persona: A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Pressure, G Peer Evaluator, H Data-Driven Prober. There is no F, because F1 to F9 are fit-snapshot rows.

## Prep triage

The window is 24 November to 3 December, nine days; you haven't said how many hours a day you have, so this is ordered by value, not by hours.

| When | Do | Tied to |
|---|---|---|
| First | Rehearse the highest-ROI question aloud until the concession is boring: the jump from one branch's complaints log to the whole process, with the contact centre in it | B3, then B1, B4, E1 |
| Next | Do the round 3 case aloud twice, saying the structure out loud, using Ashgrove's own words from the values | D3, D4, then the values sheet C5 to C8 |
| Then | Decide your own answers to pay, notice, location and reason for the move, so round 1 costs you nothing | A2 to A5 |
| Then | Write out, privately, your answers to the slots in F3, F5 and F7, and send them to me to upgrade the pack | F3, F5, F7 |
| Last | Skim the grounding brief and the reverse questions for each round | Grounding brief, RQ1.1 to RQ3.5 |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not a process across branches, with nothing inspected behind it, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat around the log likely. If any step before or after a complaint reached the log was yours to handle, say which, in your own words; if the log was the whole of it, or the rest was not yours, say so plainly and stay with the log. The contact-centre half is F2 |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence reaches monthly complaints reporting, and your material does not show what the spreadsheet counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours tracked. If it tracked either, say how it was counted, in your own words; if it tracked something else, or you do not know how a figure was counted, say so plainly and say what you would track first |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says new tellers and an escalation script, not supervisors, and the words stay there: "trained new tellers on our escalation script." Answer slot: if any of those tellers struggled with the script, say what you did and what part was yours; if none did, or you delivered the script as it was given to you, say so plainly and stay with the training |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material speaks to this, and the pack writes nothing from it. Answer slot: if you have worked with any team outside your own on something members would notice, say what and what part was yours; if you have not, say so plainly and say how you would approach it |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The sentence already covers the years. Say it in its own terms, six years in retail banking and the last three as a branch supervisor, and let the interviewer draw the match to the JD's wording. A length requirement is a risk to cover, not a gate |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | The sentence says formal complaints on a log, and your material does not show what rules or deadlines governed them. Answer slot: expect a probe on whether the complaints on that log had set rules or deadlines you worked to. If they did, say what they were and what your part was, in your own words; if you do not know, or the log had none, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated limit. Words: "I've never presented to anyone above regional level." Scope matters: it says above regional level, so do not widen it into never presenting at all. Then how you would prepare, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The sentence reaches reporting in a spreadsheet, in other terms from the JD's. Use your own words: "I built the monthly complaints spreadsheet our regional manager uses." If asked which tool it was, name it as it actually was |

## Grounding brief

From your summary of the 2026 strategy brief Ashgrove published in July 2026. I have not seen the brief itself, and I have not checked whether anything has changed at Ashgrove since July, so ask the recruiter if any of it has moved.

| Item | What your summary says | Provenance | How it may surface |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] | Case and CO questions on what self-service means for complaints: D2, D4, C3 |
| Branch consolidation | "consolidate eight branches into five hubs over 2027" | [grounded] | The panel are branch managers and some may be personally affected, so raise it gently: D4, RQ3.2, A4 |
| Small-business lending | "launch a small-business lending product in Q1 2027" | [grounded] | Least likely to surface for a complaints role; know it exists and do not volunteer it |
| Competition | "the main competitive pressure is app-only banks" | [grounded] | May frame why self-service journeys and complaint handling matter: D2 |
| Employer | "member-owned, about 900 staff" | [grounded] | JD wording; supports A6 |

---

# Round 1 — The recruiter (30 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly walk-through, logistics, motivation | Highest. A recruiter screen's prior is conversational, the recruiter's email calls it a 30-minute conversation, and logistics (pay, notice, location, reason for the move) take most of it | A prepared 90-second arc; treat casual questions as scored |
| Skeptic (light) | Knockout checks on the JD's requirements | Medium. The gap rows F2, F7 and F8 are what a recruiter would check first | Say the plain limit early, then the plan |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background and what brought you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc with the beats your sentences state: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log and training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. The last beat, why this role, is the one your material does not hold, so give your own reason, ideally tied to something Ashgrove has published. If no clear reason comes to mind, say so plainly rather than inventing one | The opener of any screen, drawing on F6, F1 and F3; EXP because it tests whether the story you tell matches the background |
| A2 | "What salary are you looking for?" | JD | [generic] | Logistics slot: decide before 3 December whether you will give your own figure or ask for the role's band first, and do that. This pack supplies no number. If asked what you earn now, you may decline politely and steer back to the role's band, with no figure | Pay is a standard recruiter check; the JD you pasted states none, which is the pack's observation. JD because it concerns the listed job's terms |
| A3 | "What is your notice period?" | JD | [generic] | Logistics slot: state your actual notice period, in your own words, as it really is. No figure is supplied here | Start-date fit is a screen item; JD because it concerns the job's terms |
| A4 | "Where are you based, and how do you feel about working across more than one site?" | JD | [grounded] the JD's "across branches and the contact centre" and the brief's "consolidate eight branches into five hubs over 2027" | Logistics slot: state where you actually are and what travel between sites you can actually do. If it is unclear where the role would be based, ask the recruiter, since the brief has branches moving into hubs | Location is a screen item and the JD names more than one site; JD because it concerns the job's terms |
| A5 | "What is behind your move now?" | EXP | [generic] | Logistics slot: give your actual reason in your own words. Aim for a reason about what draws you to this role, kept free of criticism of anyone. If your honest reason is a mix, give the part you are comfortable saying | The reason for the move is checked for consistency with the rest of your story; EXP because it concerns your own history |
| A6 | "What draws you to a member-owned credit union?" | CO | [grounded] the JD's "member-owned" and the value "Members First, Always — we decide from the member's side of the counter." | Selection scaffold: choose the one reason that is truly yours, then tie it to one thing Ashgrove has published, such as the value's own words. If no reason beyond the job fitting comes to mind, say so plainly rather than inventing one | Shows you read what Ashgrove says about itself; CO because it tests homework |
| A7 | "Which parts of this role feel closest to what you do now, and which furthest?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Closest, in your own sentences: handling the branch's formal complaints log, training new tellers on the escalation script, and building the monthly complaints spreadsheet. Furthest, said plainly: "I've never worked in a contact centre" and "I've never presented to anyone above regional level." Then one line on how you would start on each, as a plan | Covers F1 to F9 in one answer and shows self-awareness before the interviewer finds the gaps; JD because it walks the requirements |
| B1 | "The role covers the contact centre as well as branches. What contact-centre exposure do you have?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment first: "I've never worked in a contact centre." Then stop and offer a plan: your own first step to learn how complaints reach and move through it. Answer slot: if your branch work ever put you in contact with a contact centre's complaint handling, say what it was and what part was yours; if it did not, stop at the acknowledgment | F2 is the pack's largest stated gap, so a recruiter will test it early; JD because the contact centre is in the JD |
| B2 | "The role needs experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold what the sentence carries: "I handled the branch's formal complaints log." Answer slot: expect a probe on whether the complaints on that log had set rules or deadlines you worked to. If they did, say what they were and what your part was; if you do not know, or the log had none, say so plainly and stay with the log | F7 is the second knockout the recruiter can check from the JD; JD because it scores the stated requirement |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| RQ1.1 | "What does the Head of Member Services most want solved in the first six months?" | Surfaces the manager's priorities before round 2 and shows you think about outcomes | [generic] |
| RQ1.2 | "Do branches and the contact centre run complaints the same way today, or as separate processes?" | Tests the end-to-end scope of the role, where F1 and F2 meet | [generic] |
| RQ1.3 | "Is the panel case a live scenario or something I should read beforehand?" | The recruiter can answer, and it decides how you prepare the 20-minute case | [grounded] |
| RQ1.4 | "Will the 2027 hub changes affect where this role is based?" | Ties to the strategy brief and answers A4 properly | [grounded] |
| RQ1.5 | "Can you tell me who will be on the panel and the Head of Member Services, and what each is looking for?" | Names would unlock an interviewer read and sharper weights | [generic] |

---

# Round 2 — Head of Member Services, your future manager (45 minutes)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | "Tell me about a time" prompts | Highest. The recruiter says this round is mostly behavioural. Whether this manager scores against the values is not stated; only the panel is | Own stories where a sentence carries one, scaffolds where none does |
| Skeptic | Probes the jump from one branch's log to the whole process | High. A hiring-manager round buys capability and derisks gaps, and F1, F2 and F8 are the gaps | Hold, concede the limit before it is asked, then the plan |
| Case / Strategist | Reporting and digital-shift scenarios | Medium. Hiring-manager prior, and the JD names reporting and self-service | Clarify, objective, approach, metrics, risks |
| Data-Driven Prober | One probe on the monthly spreadsheet | Low. You have one quantified artifact to defend | Know what you can and cannot say about how it counted |
| Pressure | A time-boxed "why you" | Low. Possible in a manager round, not signalled | Pause, restate, hold, concede specifically |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you helped a colleague get an escalation right." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4, at the sentence's scope: you trained new tellers on the escalation script. Say the limit yourself: tellers, not supervisors. Answer slot: if any of those tellers struggled with the script, say what you did and what part was yours; if none did, or you delivered the script as given to you, say so plainly and stay with the training. Use I for what you did, we for context | The JD's coaching line is F4, and this behavioural prompt tests what was actually yours |
| C2 | "Tell me about a time you kept hold of a complaint until it was properly closed." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The Own the Fix theme, and the JD's "end to end". Your sentence carries only that you handled the branch's formal complaints log, so choose one complaint you can tell from start to finish without adding to it: what it was, what you did, how it ended. If the log was record-keeping and others did the resolving, say so plainly and describe what handling the log involved | Hiring managers test ownership; VAL because Own the Fix is published, EXP because it tests a real instance |
| C3 | "Tell me about a time you worked with a team outside your own to change something members would notice." | JD | [grounded] the JD's "work with digital teams on self-service journeys" | Selection scaffold: pick a time you worked with another team on something members would notice. It needs a named problem, who you worked with, what changed and what part was yours. If no such time comes to mind, say so plainly, then say how you would approach working with digital teams on self-service journeys | F5 has no evidence; the pack names the gap and does not fill it |
| C4 | "Tell me about a time you delivered an unpopular truth to someone more senior." | VAL | [generic] | Selection scaffold: pick a time that has a named stake, the moment you said it, and a relationship still intact afterwards. Choose a case where the hard truth actually landed; if it did not, say so. If no such time comes to mind, say so plainly, then say how you would handle it | Reporting complaint results to senior leaders is the role's job, and F8 shows no stated experience above regional level |
| B3 | "You've handled your branch's formal complaints log, and this role owns the process across every branch and the contact centre. How would you make that jump?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI rehearsal in this pack.** (1) Hold, at the sentence's scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." (2) Name the limit before it is asked: "I've never worked in a contact centre." (3) Give the plan as a plan: your own first steps to learn how complaints reach and move through the contact centre before you change anything. Then expect four follow-ups. L1 "What would be different in a contact centre?" Answer slot: if you know of a difference from your branch work, say it; if not, say plainly that you do not yet and what you would find out first. L2 "Who would you learn from?" Name roles, not people you have not met. L3 "Why take a risk on someone who hasn't done it?" Return to the sentence you held and the limit you conceded; add nothing to either. L4 "Is one branch's log really enough?" Concede its scope in your own words and return to the plan | F1 and F2 are the largest gaps and this objection will be asked in some form; JD because it scores the stated requirement |
| B4 | "This role presents to senior leaders. Where is your experience of that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Keep its scope. Answer slot: if you have presented at regional level, say what and to whom, plainly; if what you gave your regional manager was the spreadsheet rather than a presentation, say so. Then how you would prepare, as a plan, such as asking what senior leaders want to see | F8 is a stated limit and the JD lists it; JD because it scores the requirement |
| B5 | "Walk me through how a formal complaint moved through your branch's log, from first contact to closure." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Describe only the steps you actually handled, in order, in your own words. Answer slot: the JD's end-to-end line makes closure a likely probe. If your part began after a complaint reached you, or ended before it closed, say where your part started and stopped; if there was no such sequence, say so plainly and describe what handling the log involved | Probes whether the log sentence reaches the JD's end-to-end ownership; EXP because it tests what was yours |
| H1 | "The role leans on Excel reporting. Tell me about the monthly complaints spreadsheet you built: what is in it and who reads it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold the sentence: you built it, it is monthly, your regional manager uses it. Answer slot: the JD names volumes and resolution times. If your spreadsheet tracked either, say how each was counted; if it tracked something else, say what. Name the assumption behind a figure you would defend least, or say plainly that you do not know how a figure was counted. If asked the tool, name it as it was | Defend-the-number rehearsal for the one artifact you built; EXP because it tests attribution |
| D1 | "A senior leader gets one page on member complaints each month. What goes on it, and what would you ask before building it?" | CASE | [grounded] the JD's "report monthly on complaint volumes and resolution times" | Clarify first: who reads it, what decision it serves, what already exists. Objective, then the JD's two measures, then how you would show whether each is moving, then one risk, such as numbers standing in for members. Say the structure aloud and challenge one premise respectfully. This makes no claim about your past | Tests the reporting responsibility as a live problem rather than a record |
| D2 | "Ashgrove's brief aims to move 40% of member service to digital channels by 2028. Which kinds of complaint would you keep with a person, and why?" | CASE | [grounded] the brief: "move 40% of member service to digital channels by 2028" | Ask before answering: which complaint types are most common and how they arrive now. Then offer criteria to test, such as how upset the member is, how complex the case is, and whether a deadline applies, and say which you would test first. Offer them as criteria, not as facts about Ashgrove's complaints | A strategy-grounded question; CO and CASE because it needs the company's own vocabulary |
| E1 | "Sixty seconds: why you over someone who has worked in a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause and restate the question. Hold: you handled the branch's formal complaints log, trained new tellers on the escalation script, and built the monthly complaints spreadsheet your regional manager uses. Concede: "I've never worked in a contact centre." Hold through two follow-ups and never fold the core to restore harmony | A time-boxed Pressure challenge on the most predictable comparison |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| RQ2.1 | "How would success be measured for this role at six and twelve months?" | Shows you think in outcomes and makes the reporting expectation explicit | [generic] |
| RQ2.2 | "Where does the complaints process hand a member from one team to another today?" | Goes straight at end-to-end ownership | [generic] |
| RQ2.3 | "Which self-service journeys are planned, and where would complaints data help most?" | Connects the digital shift in the brief to F5 | [grounded] |
| RQ2.4 | "What would you want me to learn first about the contact centre?" | Names your gap openly and turns it into a ramp plan | [generic] |
| RQ2.5 | "How often would I present to senior leaders, and what do they usually ask for?" | Answers F8 with real information and shows you plan to prepare | [generic] |

---

# Round 3 — Panel of two branch managers (60 minutes, values round, with a 20-minute case)

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Stories scored against the four published values | Highest. The recruiter says the panel scores against the four values | One story or scaffold per value, with the hard truth landing |
| Case / Strategist | The 20-minute complaint escalation case | High. The recruiter states the case and its length | Say the structure aloud, use Ashgrove's own words |
| Peer Evaluator | Seam and credit questions from the people whose supervisors you would coach | High. The two panellists are branch managers, and the JD has you coaching branch supervisors; their reporting lines are not stated, so this is the likeliest style, not a certainty | Offer seam principles and what you bring them; do not pretend to know their seam |

## Values and principles sheet

| Value (official name) | Working meaning (paraphrased) | Mapped story | Question |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. Selection scaffold: a real choice between a member's interest and an easier internal path, what you decided, how it ended. If none comes to mind, say so plainly, then say how you would decide | C5 |
| Plain Words | If a member needs it explained twice, the wording was wrong | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | C6 |
| Neighbours, Not Numbers | Every branch belongs to its town, and a number must not replace the place behind it | F3: "I built the monthly complaints spreadsheet our regional manager uses." | C7 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." | C8 |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C5 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] the value "Members First, Always — we decide from the member's side of the counter." | Selection scaffold: pick a time with a real choice between a member's interest and an easier internal path. It needs the choice, what you decided and how it ended, with no identifying details about the member. If no such time comes to mind, say so plainly, then say how you would decide | The first of four scored values, and no quote carries a story, so the pack gives criteria and not a plot |
| C6 | "Tell me about a time something you said or wrote had to be explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The Plain Words theme, mapped on F4 at its scope: you trained new tellers on the escalation script. Answer slot: if any wording in the script or the training was changed because tellers needed it explained twice, say what and why and what part was yours; if the script was used as given, or the wording was not yours, say so plainly and stay with the training | Plain Words is scored, and the escalation script is the nearest quoted sentence |
| C7 | "You built a monthly complaints spreadsheet. How do you keep the numbers from standing in for the members and the branch behind them?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold the sentence, then answer for Neighbours, Not Numbers. Answer slot: if the spreadsheet ever showed a pattern for one branch, say what it was and what happened, in your own words; if it did not show branches separately, or nothing came of it, say so plainly and say how you would keep the branch visible beside the number | Neighbours, Not Numbers is scored, and F3 is the one artifact that looks like numbers |
| C8 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The Own the Fix theme. Your sentence carries only that you handled the branch's formal complaints log, so choose one problem you can tell start to end: what you found, what you did, how it ended. If the log held problems you passed on rather than solved, say so plainly and describe your part | Own the Fix is scored, and F1 is the quote closest to it |
| D3 | "A member has complained to the branch twice about the same issue and is back in branch, angry. The supervisor says it was resolved. Walk us through what you do." | CASE | [generic] | The core of the 20 minutes. Say the structure aloud. Clarify: what the complaint was, what resolved meant, whether it is formal, what the member wants now. Objective: the member leaves knowing who holds it. Approach: member first, then the supervisor, then the process. Metrics and risks last. Use Ashgrove's words where they fit, such as deciding from the member's side of the counter and whoever finds the problem keeping hold of it. Challenge one premise respectfully. This makes no claim about your past | The recruiter says the case is a complaint escalation; CASE because it is a live problem from the role |
| D4 | "A member's complaint arrives in the app, and the branch nearest them is moving into a hub. How does the process cope?" | CASE | [grounded] the brief: "move 40% of member service to digital channels by 2028" and "consolidate eight branches into five hubs over 2027" | Clarify what the member needs and who holds the complaint. Then who owns it across channels, how the member learns who has it, and what the hub change should not break. Ask what exists before proposing anything, since you do not know Ashgrove's process | Strategy-grounded, and it tests whether you think at Ashgrove's altitude; CO and CASE |
| D5 | "Two escalations land together: a member's fee complaint, and a supervisor who thinks a colleague mishandled a complaint. Where do you start, and why?" | CASE | [generic] | Prioritisation, said aloud: what you would ask first about each, what cannot wait, what you would do about each today and who you would tell. Make the trade-off explicit rather than hiding it | A second escalation shape in case the panel's case differs from D3 |
| G1 | "A branch supervisor has mishandled an escalation and their branch manager is in the room. Where is the seam between your job and theirs?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Propose seam principles and do not claim to know the seam: ask what the manager expects, coach in private, and tell the manager what changed. You can say you were a branch supervisor for the last three of your six years in retail banking, which is your own sentence. Do not assert more than that | The panel are branch managers and the JD has you coaching supervisors; the Peer persona probes the seam |
| G2 | "What would you need from branch managers to make this role work, and what would you give them?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Reciprocity, said as a plan: what you would ask for, such as early word of a problem, and what you would give, such as a clearer monthly picture of their branch. The only thing you can say you have done is your own sentence: you built the monthly complaints spreadsheet your regional manager uses | The Peer persona prices what you cost and add to their work |
| G3 | "How do you handle it when you and a branch manager see a complaint differently?" | VAL | [generic] | Selection scaffold: pick a time you disagreed with an equal, held your position and kept the relationship. It needs the disagreement, what you said and where it ended. If no such time comes to mind, say so plainly, then say how you would handle it | Peer evaluators test disagreement style with equals |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| RQ3.1 | "What do branch supervisors find hardest about escalating a complaint today?" | Shows you want to hear from the people you would coach | [generic] |
| RQ3.2 | "How are you thinking about complaints handling while branches move into hubs in 2027?" | Ties to the brief; ask it gently, because the managers may be personally affected | [grounded] |
| RQ3.3 | "When a complaint sticks between a branch and the contact centre, who notices first?" | Speaks to Own the Fix and to the contact-centre gap | [generic] |
| RQ3.4 | "What does a good month for complaints look like from your side of the counter?" | Echoes the value's own phrase lightly | [grounded] |
| RQ3.5 | "What could a new person do in the first month that would genuinely help your branch?" | The reciprocity question for people you would work alongside | [generic] |

---

## Requirement coverage

| Requirement | Questions |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | A7, B1, B3, B5, C2, C8, D3, D4 |
| Report monthly on complaint volumes and resolution times | H1, D1, A7 |
| Coach branch supervisors on escalations | C1, G1, G2 |
| Work with digital teams on self-service journeys | C3, D2, D4 |
| 4+ years in financial-services customer operations | A1, A7 |
| Experience handling regulated complaints | B2, B5 |
| Confident presenting to senior leaders | B4, C4, D1, E1 |
| Comfortable with Excel reporting | H1, A7 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or ran the complaints process across branches | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one branch's formal complaints log, not a process across branches. The slots stay inside the log |
| Has worked in a contact centre, or handled contact-centre complaints | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." Then a plan, never a past |
| Has presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." Keep its scope: it does not say you never presented at all |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: formal complaints on a log. The pack's observation is that your material does not show what governed them. The slot asks only about rules or deadlines you worked to |
| Coached or trained branch supervisors on escalations | Inflated form of F4 | F4's quote: you trained new tellers on the escalation script. The limit is the pack's observation: tellers, not supervisors |
| Wrote or owned the escalation script | Inflated form of F4 | F4's quote: you trained new tellers on "our escalation script". Whether you wrote any of it is an answer slot, with the honest branch that you did not |

## Sources

Provided documents: the job description you pasted; Ashgrove's four values as you copied them on 24 November 2026 from ashgrovecu.org/about/values (not fetched by me); the recruiter's email on the three rounds; your summary of the July 2026 strategy brief the recruiter sent (I have not seen the brief itself); your own background. No dossier was consumed.

No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values fix the cheat sheet's four names and meanings |
| 2. `Ashgrove interview process member experience` | skipped | The recruiter's email already fixes three rounds, who runs each, their lengths and the panel's values scoring, so persona weights rest on it |
| 3. `Ashgrove strategy` / recent news | skipped | Your summary of the July 2026 brief supplies current priorities; it is under six months old, so the grounding brief draws on it |
| 4. `{interviewer name} Ashgrove` | n/a | No interviewer has been assigned, so there is no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Names and roles of the Head of Member Services and the two panellists → an interviewer read, persona weights tuned to them, and a reverse question tied to each one's path
- Your answers to the slots in F3, F5 and F7, said plainly in your own words → those rows become `[grounded]` with stronger evidence and the questions B2, B5, C3 and H1 get story maps instead of slots
- An anonymised view of the monthly complaints spreadsheet or the report it fed → F3 and F9 can rise from medium to high, because the spreadsheet is the inspectable artifact in this field
- The recruiter's word on whether the 20-minute case is live or has a pre-read → a build section if anything is pre-declared
- Your own pay, notice, location and reason for the move, decided → A2 to A5 become your words rather than instructions
- Hours available each day → the triage can be sized to your time
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a check on whether anything at Ashgrove has changed since July 2026, plus public reports of the loop
- A tuesday-dossier.md from an earlier fit check (job-underwriter) → verified evidence and any prohibited claims it records, never required
