# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds on 3 December 2026, per the recruiter's email.

| Round | Who | Length | What the recruiter said |
|---|---|---|---|
| 1 | The recruiter | 30 min | Not described beyond the slot |
| 2 | Head of Member Services, your would-be manager | 45 min | "mostly behavioural" |
| 3 | Panel of two branch managers | 60 min | Includes "a 20-minute case on a complaint escalation"; the panel "is also the values round — they score against the four values" |

Interviewer names are not yet assigned, so there is no interviewer read and persona weights rest on the round descriptions above, not on anyone's public footprint.

**Highest-ROI prep in this pack: D1 (round 2).** It is the contact-centre half of the role, where your own material states a limit. Rehearse it until it is boring.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for your own words, not a script. An "answer slot" is an instruction for the interview: answer it from what actually happened, and if the practice was not yours or never existed, say so plainly. That is a good answer, not a failed one.

| Type | What is being scored |
|---|---|
| VAL | Whether past behaviour shows one of Ashgrove's published values |
| EXP | Whether your own background claims survive a follow-up |
| JD | A stated responsibility or requirement in the job description |
| CO | Whether you can think at Ashgrove's altitude (strategy, members, competition) |
| CASE | A live problem from the actual role, reasoned aloud |

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted only from your own message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD (branch side) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The pack's observation: your material says the branch's log and teller training, not the process across branches. Words stay at that scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot: the JD's end-to-end line makes a probe on what happens to a complaint beyond the branch likely. If any complaint you handled went on to another team or branch, say what you saw of it, in your own words; if none did, or you had no view past the branch, say so plainly and stay with the log you handled |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (contact-centre side) | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I've never worked in a contact centre." Then, as a plan and never as a past, what you would want to learn first. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says you built a monthly complaints spreadsheet your regional manager uses; it does not show what the spreadsheet counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours counted. If it counted either, say which and how it was counted, in your own words; if it did not, or you do not know how a figure was counted, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence says new tellers and the escalation script, not supervisors. Words stay at that scope: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on how the coaching went in practice likely. If you have coached a peer or a supervisor, say who and what you did, in your own words; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing on digital teams or self-service. Answer slot: the JD's digital line makes a probe likely. If you have worked with a digital or online team on anything members use, say what and your part, in your own words; if not, or it was not yours, say so plainly and say, as a plan, how you would learn what members try online before they complain |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap in the length: lead with the numbers as you stated them, "6 years in retail banking, the last 3 as a branch supervisor." It is a line with nothing inspected behind it (an employment record would be the inspectable proof), so expect a probe on what the three supervisor years covered, answered from your own history |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | The pack reads "formal complaints log" as possibly regulated; your material does not say which rules the log sat under. Answer slot: the JD's regulated line makes a probe on what governed the log likely. If it was kept under a regulator's or the credit union's own rules, say which, in your own words; if you do not know, or it was an internal log only, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I've never presented to anyone above regional level." Then, as a plan and never as a past, how you would prepare for a senior audience. Nothing added to make the gap feel smaller |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The pack reads "spreadsheet" as possibly Excel; your sentence does not name the tool. Answer slot: the JD names Excel, so expect a probe on the tool. Say which tool it was and what it did, in your own words; if it was not Excel, say so plainly and stay with the spreadsheet you built |

The JD names no gate (no licence, location or schedule term), and its length-of-experience line (F6) is graded as experience, not as a gate.

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | A6, B1, B2, D1, G1, F4 |
| "report monthly on complaint volumes and resolution times" | D4, G3 |
| "coach branch supervisors on escalations" | C2, G2, H2 |
| "work with digital teams on self-service journeys" | D3, E1 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | D2, C1 |
| "confident presenting to senior leaders" | C3 |
| "comfortable with Excel reporting" | D4 |

## Grounding brief

The strategy facts below are the ones you relayed from the July 2026 brief the recruiter sent. The pack has not read the brief itself, so check wording against it before quoting figures aloud.

| Fact | Source | Provenance | Where it surfaces |
|---|---|---|---|
| 40% of member service to move to digital channels by 2028 | your message, strategy brief July 2026 | [grounded] | A2, E1, reverse questions R2 |
| Eight branches consolidated into five hubs over 2027 | your message, strategy brief July 2026 | [grounded] | A5, E2, F3 |
| A small-business lending product launches in Q1 2027 | your message, strategy brief July 2026 | [grounded] | A2, reverse questions R2 |
| The main competitive pressure is app-only banks | your message, strategy brief July 2026 | [grounded] | A2, E1 |

## Round 1: the recruiter (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; "walk me through the journey" | High: recruiter screens tilt conversational, and the recruiter's own email gives no other format | A 90-second arc built from your quoted lines; treat every casual question as scored |
| Skeptic (light) | Checks the knockout gaps quietly | Medium: your stated limits (F2, F8) sit against the JD's headline lines, and a screen is where a recruiter checks them | State each limit plainly once, then one future-tense step |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Three beats, each in your own words: the six years and the three as a supervisor; the log and the teller training; the spreadsheet. Answer slot: the closing beat is why this role. Give your own reason, drawing on what the JD says the job holds; if a part of the JD is not part of your reason, leave it out. Keep to about 90 seconds | F6 covers the years, F1, F4 and F3 the other beats. EXP because it tests whether your own account holds together before the later rounds test it |
| A2 | "What do you know about us, and why Ashgrove?" | CO | [grounded] | Use only what you can source: the JD's "member-owned", one value by its exact name, and one fact from the strategy brief (the 40% digital goal, eight branches to five hubs, small-business lending in Q1 2027, app-only banks as the main pressure). Say, in future tense, what you would want to do in the role; make no claim about your past here | The research a recruiter can score in a minute. CO because it checks homework against Ashgrove's own published words |
| A3 | "What are you looking for on salary?" | JD | [generic] | Logistics slot: give your own figure, or ask what the band for the role is first. If asked what you earn now, you can decline and bring it back to the range for this role. The pack supplies no figure | A recruiter-screen logistics probe on the listed job's terms; the only safe answer is your own |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words, and any earlier start only if it is true | Recruiter-screen logistics; JD because it concerns the listed job's terms |
| A5 | "Where would you be working from, and does getting to our sites work for you?" | JD | [grounded] | Logistics slot: state your own location and travel facts in your own words; the pack has none. The brief you relayed has eight branches consolidating into five hubs over 2027, so sites may change; if you have a view on how far you can travel, say it plainly | Recruiter-screen logistics; the hub plan is why this question has more weight here than usual |
| A6 | "What's prompting you to look at a move?" | EXP | [generic] | Logistics slot: give your actual reason in one or two sentences, in your own words. Frame it as what you are moving toward only as far as that is true. The pack supplies no reason | The reason for leaving is checked for consistency against later rounds, so it must be yours |
| B1 | "The role covers the contact centre as well as the branches. What's your contact-centre experience?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold only what the quote carries. Words: "I've never worked in a contact centre." Then one plan sentence, in your own words, on what you would want to learn first. Do not add adjacent claims to soften it | F2 is a stated limit, and a recruiter screen is where it is first checked. JD because it scores the headline requirement |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose from the limits your own material states, the contact centre or presenting above regional level, and name it plainly: "I've never worked in a contact centre" or "I've never presented to anyone above regional level." Then one future-tense step. Do not offer a limit your material does not state, and do not offer a strength in place of an answer | F2 and F8 are the two stated limits. JD because it is a probe on fit against the listed responsibilities |

### Reverse questions: recruiter

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would the Head of Member Services most want the person in this role to have changed by month six?" | Gives you the outcome to anchor round 2 on, and shows you think in results |
| 2 | "Is there anything to prepare for the 20-minute escalation case, or is it cold?" | Uses the recruiter's own detail and sets how much to rehearse G1 to G3 |
| 3 | "How does the panel score the four values: by example, or across the whole hour?" | Tells you whether each value needs its own story ready (F1 to F4) |
| 4 | "How does the contact-centre side of this role work with the branches today?" | Shows you are closing the F2 gap, and gives you material for D1 |
| 5 | "What happens after the three rounds, and when would I hear?" | Process question; closes the screen without a generic "no questions" |

## Round 2: Head of Member Services (45 minutes, your would-be manager)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gap between your background and the JD's headline lines | High: the manager is buying capability and derisking gaps, and F1, F2, F4, F5 and F8 are the thin rows | Rehearse D1 until it is boring; hold, concede specifically, then a plan |
| Values / Behavioral | "Tell me about a time…", STAR-shaped | High: the recruiter described the round as "mostly behavioural" | Quoted-line story maps; "we" for context, "I" for your own part |
| Case / Strategist | Live questions on the role's roadmap | Medium: a manager's round often tests the strategy, and the brief gives them material | Clarify, structure, think aloud, challenge one premise respectfully |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns complaints end to end across branches and the contact centre. Which part of that is furthest from what you've done?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **Highest-ROI rehearsal in the pack.** Hold only what the quotes carry: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Concede the limit specifically: "I've never worked in a contact centre." Then a plan in future tense, in your own words, of what you would ask the contact-centre team first. Follow-up 1, "So why should we trust you with the half you haven't worked in?": return to the plan, never add experience. Follow-up 2, "What do you expect to be different about a complaint that arrives that way?": say what you would ask, not what you know. Follow-up 3, "How would you earn that team's respect?": a plan again. The limit is named before it is asked for: your material says the branch's log, not the process across branches | The most predictable objection to this candidate: F2 is stated and F1 stops at the branch. JD because it scores the first line of the JD. The Skeptic tone makes the concession the test |
| D2 | "You handled the branch's formal complaints log. What rules did that sit under?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: the JD's regulated line makes this probe likely. If the log was kept under a regulator's or the credit union's own rules, say which, in your own words; if you do not know, or it was an internal log only, say so plainly and stay with the log you handled | F7 is `low` confidence and the JD asks for "regulated complaints", so this is the second likeliest probe. JD because it scores that requirement directly |
| D3 | "What have you done with digital teams on self-service?" | JD | [grounded] | Answer slot: if you have worked with a digital or online team on anything members use, say what and your part, in your own words; if not, or it was not yours, say so plainly. Then, as a plan, how you would learn what members try online before they complain | F5 is silent in your material and the JD names digital teams. The premise is the JD's, so the slot lets it be false |
| D4 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the spreadsheet is in the quote's own words. Answer slot: the JD names volumes and resolution times and Excel. If it counted either, say which and how each was counted; say which tool it was; if it counted neither, or you do not know how a figure behind it was counted, say so plainly. Name, in your own words, the part of it you would trust least before they do | F3 and F9 are the rows this question tests. EXP because it checks a claim you made; the weakest-assumption move is the metric-question bar |
| C1 | "Tell me about a time you handled a complaint that was hard to resolve." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a complaint from the log you handled; it needs a named stake, what you decided and which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the log you handled, or how you would handle it | An open behavioural prompt on the JD's core theme. F1 is the evidence, and it carries the log only |
| C2 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story map on the quote: new tellers and the escalation script, at that scope. Answer slot: the JD's coaching line is for supervisors, so expect a probe on how the coaching went in practice. If you have coached a peer or a supervisor, say who and what you did; if not, say so plainly and stay with the tellers | F4 is transferability. JD because it scores "coach branch supervisors on escalations" |
| C3 | "Tell me about the most senior group you have presented to." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Plain first sentence: "I've never presented to anyone above regional level." Then name what you actually presented at regional level and to whom, in your own words; if the spreadsheet was sent rather than presented, say so. Then, as a plan, how you would prepare for a senior audience | F8 is a stated limit against the JD's "confident presenting to senior leaders". JD because it scores that requirement |
| E1 | "Ashgrove wants 40% of member service on digital channels by 2028. Which complaints would you move to self-service, and which would you never?" | CO | [grounded] | No claim about your past. Clarify first (what counts toward the 40%), then objective, segmentation, approach, metrics, risks. Challenge one premise respectfully. If the follow-up is about app-only banks, say what a member would expect from a credit union that an app would not give them, in your own words | The brief gives a strategy fact; digital self-service is also the JD's fourth line, F5. CO because it tests altitude |
| E2 | "Eight branches become five hubs over 2027. What happens to the complaints process through that year?" | CO | [grounded] | No claim about your past. Clarify first: which complaints come from affected branches, and who owns one that is open at the moment of change. Tie it to "Own the Fix" and "Neighbours, Not Numbers" by their exact names | The brief's biggest operational change sits on the role's own territory. CO with a CASE delivery |

### Reverse questions: Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does the complaints process look like across branches and the contact centre today, and where does it break?" | Asks for the real problem, and starts the plan D1 needs |
| 2 | "How will the move from eight branches to five hubs change who handles complaints?" | Shows you read the brief and think about ownership during the change |
| 3 | "What would the 40% digital goal mean for the complaints process, and for the monthly numbers?" | Links F3 and F5 to the strategy |
| 4 | "What would success look like in my first ninety days, and what would worry you?" | Invites the manager to name any doubt, which you can then answer |
| 5 | "Who would I report the monthly numbers to, and what do they decide from them?" | Prepares you for the senior-presenting line (F8) |

## Round 3: panel of two branch managers (60 minutes, includes a 20-minute case; scored on the four values)

### Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes mapped to the four values | High: the recruiter said the panel "is also the values round — they score against the four values" | One story per value, or a selection scaffold ending in its honest branch |
| Case / Strategist | The 20-minute escalation case | High: the recruiter named it | Clarify, structure, think aloud; ask about the contact-centre handover rather than assume it |
| Peer Evaluator | Seam-splitting between a lead and the branches | Medium: branch managers are the people whose supervisors this role coaches | Reciprocity; propose seam principles rather than pretending to know the seam |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a decision where the member's interest and a branch process pulled apart; it needs a named stake, what you decided and what was yours to decide. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the log you handled, or how you would decide | Tests "Members First, Always". F1 carries the log only, so the story has to be chosen, not supplied |
| F2 | "Tell me about a time something needed explaining twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story map on the quote: new tellers and the escalation script, at that scope. Answer slot: the value is about wording that has to be repeated. If a teller needed the script explained again or you changed how it was put, say what and what you did; if not, say so plainly and stay with training the tellers | Tests "Plain Words". F4 is the nearest evidence |
| F3 | "Tell me about a time you kept your local community in mind when making a call at work." | VAL | [grounded] | Selection scaffold: pick a decision where a town's interest was weighed against a figure; it needs a named place, a named stake and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would weigh a hub change for a town's members | Tests "Neighbours, Not Numbers". No quote in your material carries a story for this value, so it is a scaffold. The hub plan makes it timely |
| F4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story map on the quote: the log you handled. Answer slot: the value is that whoever finds the problem keeps hold of it. If there was a complaint you carried to resolution, say what it was, what you did and who else was involved, in your own words; if none stayed with you to the end, or the log was not yours to close, say so plainly | Tests "Own the Fix"; it also bears on F1's end-to-end line |
| G1 | "A member has been passed between the branch and the contact centre twice and still has no answer. You have twenty minutes: what do you do, and what do you change afterwards?" | CASE | [generic] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Clarify first (what the member raised, what they have been told, what clock or rule applies). State the objective from the member's side. Say who keeps hold of it now. Give the member a plain answer. Then the process fix and what you would report monthly. Ask how the contact centre hands a case over rather than assume it; if asked why, "I've never worked in a contact centre" | A rehearsal case on the recruiter's named topic; it invents no fact about Ashgrove |
| G2 | "A branch supervisor sends you every complaint straight away. How do you coach them?" | CASE | [generic] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Ask what is driving it first. State a principle: the supervisor keeps hold of what they can settle, you take what they cannot. Agree what "settle" means in plain words, then a check-back. If asked about your coaching experience, stay at "I trained new tellers on our escalation script." | F4 is transferability, and the JD's coaching line is a supervisor line |
| G3 | "How would you know in month three whether complaints are being handled better? Which numbers would you bring us each month?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Start from the two measures the JD names, volumes and resolution times. Say what each leaves out and what you would add, and ask what they track now. Name, in your own words, the number you would trust least. If you used a similar view before, stay at the quote | F3 and F9. CASE because it is a live design problem; the JD's reporting line is the raising source |
| H1 | "Our supervisors are busy at the counter. What would you need from us, and what could we count on from you?" | CASE | [generic] | Reciprocity: say what you would ask of them and what you would take off them, as principles. No claim about your past | The peer evaluator prices what the hire costs the branches |
| H2 | "Where do you draw the line between a supervisor settling a complaint on the spot and sending it up to you?" | CASE | [generic] | Propose a principle rather than claim to know their seam. Link it to "Own the Fix": a supervisor who found the problem keeps hold of it, and you keep hold of what they pass up. Ask where they draw it today | Tests the seam, and the tension between coaching and taking over, F4's territory |

### Values / principles cheat sheet

| Value | Working meaning (paraphrased) | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, F1: selection criteria in the question bank above, ending in its honest branch |
| Plain Words | If a member has to be told twice, the wording was wrong | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Slot in F2 |
| Neighbours, Not Numbers | Each branch is part of its town | Scaffold, F3: selection criteria above, ending in its honest branch |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Slot in F4 |

### Reverse questions: branch-manager panel

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do your supervisors find hardest about escalations today?" | Gets the real problem F4's coaching would address |
| 2 | "When a complaint comes from your branch, what do you want to hear back, and how soon?" | Shows you think about the branch's side, not only the process |
| 3 | "How do you see the move to hubs in 2027 touching how members in your area raise complaints?" | Ties "Neighbours, Not Numbers" to the brief |
| 4 | "Which of the four values is tested hardest in your branch day to day?" | Lets the panel pick the value they care about most |
| 5 | "What could a new complaints lead do in the first month that would genuinely help your branch?" | Reciprocity question for a peer-style panel |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope; the limit is the pack's observation: your material says the branch's log, not the process across branches |
| Has contact-centre experience | Negative you stated, F2 | "I've never worked in a contact centre." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." |
| Has handled regulated complaints | Inflated form of F7 | F7's quote at its own scope; the limit is the pack's observation: your material says the formal log, not which rules governed it |
| Has presented to senior leaders | Negative you stated, F8 | "I've never presented to anyone above regional level." No slot |
| Reported complaint volumes and resolution times to leaders | Inflated form of F3 | F3's quote at its own scope; the limit is the pack's observation: your material says a spreadsheet your regional manager uses, not what it counted |
| Built the complaints reporting in Excel | Inflated form of F9 | F9's quote at its own scope; the limit is the pack's observation: your sentence does not name the tool |

## Sources

Provided documents: the JD; the four values as copied on 24 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the process; your account of the July 2026 strategy brief (the brief itself was not read); your background. No `tuesday-dossier.md` was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values fix section 10 and the VAL questions by name |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email names three rounds, who runs each and what the panel holds, so it fixes the loop and persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | The relayed July 2026 brief fixes the CO questions and the grounding brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names yet, so no query could be formed; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The supplied JD fixes the fit snapshot and the JD questions |

## Upgrade menu

- Your CV → rows F1, F3, F4, F6, F7 and F9 could cite CV lines beside your message, and the spreadsheet itself or an anonymised extract of the log would be the inspectable proof that lifts medium confidence
- Your answers to the slots in F1, F3, F4, F5, F7 and F9 → each answered slot becomes quoted evidence and regenerates the guidance cells that draw on it
- The two interviewers' and the Head of Member Services' names, once assigned → an interviewer read, persona weights from their public footprint and a reverse question tied to their own path
- How many hours you have before 3 December → a prep triage ordered by value, closing with an "everything else is insurance" line
- The recruiter's answers on the 20-minute case format and how the four values are scored (one email) → a tighter round 3 bank
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes; not run unless you say so) → a check of the brief against Ashgrove's own publications, recent organisation context and, once names exist, interviewer footprints
- A `tuesday-dossier.md` from an earlier evaluation of the role → verified evidence and absolute prohibited claims, which would tighten the highest-ROI objection and the strategy per weak area
