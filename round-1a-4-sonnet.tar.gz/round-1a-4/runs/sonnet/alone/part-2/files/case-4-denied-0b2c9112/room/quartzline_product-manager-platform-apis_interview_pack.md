# Interview prep pack: Product Manager, Platform APIs at Quartzline

Round: a 45-minute conversation with the hiring manager (name not given), Thursday. Built from the dossier you carried in, with the hiring manager as the relationship.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows good judgment on values, here without published values to anchor on |
| EXP | Whether your claims survive scrutiny: what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you understand the company and its platform |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for this conversation: where the pack cannot know what happened, it tells you what to say if it did and what to say if it did not. Both branches are honest answers. Provenance labels: `[grounded]` rests on a document you provided, `[inferred]` is this pack's derivation, `[generic]` is a role-family pattern with no claim about Quartzline or about you.

## Prep triage

Do these in order; everything else is insurance.

1. A1, aloud, until the concession and the two quoted sentences come out without effort. This objection will arrive in some form.
2. E1, the same answer in sixty seconds.
3. C1 and C2: how the thirty-plus was counted, and one integration walked from scoping to go-live.
4. B1 and B3: say your structure aloud before filling it.
5. Reverse questions 1 and 2, the two the dossier left open.

Everything else is insurance.

## Fit snapshot

The dossier lists no hard gates. Requirements are the dossier's `role_profile` lines; evidence cells are the dossier's `verified_candidate_evidence`, quoted without the confidence notes attached to them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD, must_have (dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [grounded] | transferability | Dossier strategy: bridge, positioned as adjacent and never as PM experience. The pack's observation: your material shows integration leadership and a playbook, and does not show product management, let alone three years of it. Words: the first sentence at its own scope, said in the first person, and the playbook sentence likewise, then say plainly that this is adjacent to the role. Plain acknowledgment, sourced by the dossier's `prohibited_claims` item "Having held a product manager title or role": "I haven't held a product manager title or role." |
| F2 | "Own the roadmap for the partner-facing API platform" — JD responsibility (dossier role_profile) | none given | none | [grounded] | capability | A gap wording cannot close, and the dossier records it: its `acknowledge_gap` area is "Owning a roadmap and prioritization authority (R1 sub-claim)", and its `prohibited_claims` include "Having owned a product roadmap" and "Having set prioritization for an engineering squad". Words: "I haven't owned a roadmap." Then a ramp plan said as a plan and never as a past: what you would read first, who you would sit with, what you would ask about adoption. No bridge from other evidence, because the underwriter looked and found none |
| F3 | "Shipped API or platform products" — JD, must_have (dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | transferability | The dossier grades no gap for this requirement, so the grading is the pack's own. Your material says client integrations led through go-live; it does not say a product of yours went out, and the words stay at the quote's scope. Answer slot: the JD's line makes a probe on what went live likely. For any go-live you led, say what went live and what part was yours, in your own words; if what went live was a client's integration rather than anything of yours, say so plainly and return to the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — JD, important (dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote names REST APIs and architecture and does not say whether docs or schemas were part of the work. Answer slot: if you worked with API docs or schemas in these integrations, say how, in your own words; if you did not, say so plainly and say what you would want to confirm about how this team defines fluency |
| F5 | "Stakeholder management across engineering, sales, customers" — JD, important (dossier role_profile) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes reach customers and product; the JD also names engineering and sales, which they do not show. The second quote is confirmed with limited inspectable proof, so expect a probe and volunteer the limit first: say what you can show and what is your own account. Answer slot: if you worked with engineering or sales in these integrations, say how; if one of the three was not part of your work, say so plainly and stay with the clients |
| F6 | "Agile delivery experience" — JD, preferred (dossier role_profile) | none given | low | [grounded] | discovery | Dossier strategy: clarify. No verified sentence speaks to this requirement, so nothing is quoted. Answer slot: the JD's line makes agile delivery the probe. If you have worked inside agile delivery cycles, say how, in your own words; if you have not worked that way, say so plainly. Either way, add what you would want to confirm about how this team defines it |

## Persona table

The loop rests on your own words: one 45-minute conversation with the hiring manager. No interviewer profile exists, so no interviewer signals adjust the weights, and no values-style round is detected.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the title and roadmap gap | Highest. A hiring manager buys capability and derisks gaps, and the underwriter named this objection from evidence you confirmed (F1, F2) | Rehearse A1 until it is boring: concede first, then the quoted sentences at their own scope, then a ramp plan |
| B. Case / Strategist | Live problems from the role: roadmap choices, adoption, squad conflict | Highest. The hiring-manager prior pairs it with the Skeptic, and the role's responsibilities are decision problems you can reason about aloud without a past to claim | Clarify, objective, segmentation, approach, metrics, risks; say the structure aloud; challenge one premise respectfully |
| C. Data-Driven Prober | Reads the evidence line by line, asks how the 30+ was counted | Medium. Raised above its prior because one claim is a headline figure and one is confirmed with limited proof (F5) | Know what you can and cannot say about each figure and say plainly when you do not know |
| D. Conversational / Rapport | Opens with the journey; casual questions on the JD's topics | Medium. Most conversations open this way, and casual questions are still scored | A 90-second arc built only from your sentences (D1); treat D2 and D3 as scored |
| E. Pressure | Time-boxes, asks why you over a PM with three years | Low to medium. A hiring manager may test composure on the title gap | Pause, restate, hold through two follow-ups, concede specifically |
| F. Peer Evaluator | Seam and credit questions about the two squads | Low. The role works beside two squad leads, but the person in the room manages the role | Propose seam principles instead of pretending to know the seam |
| G. Values / Behavioral | Scenario prompts about unpopular truths and customers | Low. No loop source documents a values round, and no Quartzline values were researched | Selection scaffolds only; none of your sentences carries these stories |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | The highest-ROI rehearsal in this pack, and the underwriter named this objection. Both negatives have a source: `prohibited_claims` carries "Having held a product manager title or role" and "Having owned a product roadmap". Level 1, concede first and plainly: "I haven't held a product manager title or role, and I haven't owned a roadmap." Then the two sentences at their own scope, in the first person, and say it is adjacent to the role and you are not presenting it as product management. Level 2, "what would you be missing on day one?": name it once, "owning a roadmap and prioritization authority", then a ramp plan said as a plan: read the roadmap and its history, learn from both squad leads how priorities are decided today, ask what the adoption baseline is. Level 3, "why not the PM with three years?": hold. Concede that such a PM has done the job and you have not, do not argue you would be better, return to the two sentences, and turn to who decides what (reverse question 1). The roadmap-input sessions stay out of this answer: the underwriter closed the roadmap area to bridging | F1 and F2 are where the JD presses hardest, and the underwriter's own objection is better evidence than one inferred from the JD. JD because it scores R1; the deepest rehearsal because every other bank returns to it |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] | Lead with the acknowledged area, sourced by the dossier's `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)": "Owning a roadmap and setting priorities for a squad is the part I haven't done." Then the ramp plan from A1. Second area, answer slot: the JD's agile line is the probe. If you have worked inside agile delivery cycles, say how, in your own words; if you have not worked that way, say so plainly, and say what you would want to confirm about how this team defines it | A standard Skeptic stem, and the honest answer is already fixed by F2; the second area is F6, which the underwriter marked as unclear rather than absent |
| A3 | "Which API or platform product have you shipped?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Lead with the sentence at its own scope, in the first person. Answer slot: the JD's second requirement makes a probe on what went live likely. For any go-live you led, say what went live and what part was yours, in your own words; if what went live was a client's integration rather than anything of yours, say so plainly and return to the integrations you led | F3 is a must-have the quote reaches only at the edge. The question's premise is the JD's, and the guidance does not adopt it |
| A4 | "Why product, and why now?" | EXP | [generic] | Give your actual reason in your own words; the pack does not supply one. Keep it connected to the work your sentences carry rather than replacing it. If asked why now rather than earlier, answer from your own timeline; if there is no particular reason for the timing, say so plainly | The motivation probe every career-change candidate meets; EXP because it tests whether the story stays consistent under a second question |
| A5 | "When have you worked inside an agile delivery cycle with product and engineering?" | JD | [grounded] | No quoted sentence of yours speaks to this, so the dossier's `clarify` strategy applies: a question-shaped answer, not a bridge. Answer slot: the JD's line is the interviewer's probe. If you have worked inside agile delivery cycles, say how, in your own words; if you have not worked that way, say so plainly. Then ask: "Here's what I'd want to confirm about how you define it — what does the delivery cycle look like for the two squads?" | F6 is the one row the underwriter classed as discovery, so the right output is a clean answer that does not guess |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Several partners want different things and the quarter has room for two. How do you decide what the platform does next, and what do you need to know first?" | CASE | [generic] | Clarify first: what the platform is meant to achieve this year, and how decisions get made today. Objective, then segment the partners by what they are trying to do, then criteria you would apply, then the trade-off you would name aloud. Challenge one premise respectfully, for example who sets the capacity. If asked whether you have done this, return to A1: "I haven't owned a roadmap; here is how I would reason about it." The structure is the answer, and it claims no past | The roadmap is the first responsibility in the role profile; CASE because it asks for reasoning rather than history |
| B2 | "How would you define and track adoption for the partner API platform?" | CASE | [generic] | Start by asking how adoption is measured today and what the baseline is; the dossier leaves both open. Then choose a definition and defend it, for example partners live in production versus partners signed up, time from kickoff to first live call, depth of use after go-live. Name the definition's weakest assumption yourself, and say what you would measure first. Give no figure | Adoption metrics are a named responsibility with no stated baseline; the question lets you turn that unknown into a reverse question |
| B3 | "Two squads each want the same quarter of effort. Who decides, and how do you influence it if the call isn't yours?" | CASE | [generic] | Ask who decides today before answering; the role's authority over the two squad leads is not established. Then propose seam principles instead of pretending to know the seam: shared criteria agreed up front, partner evidence brought to the decision, a named escalation path. Concede plainly that you do not yet know how this organization splits it | The squad-authority question is the dossier's second condition for this role; this question surfaces the answer while testing reasoning |
| B4 | "A partner's integration has been stuck for weeks. How do you find out whether it's a product problem or a partner problem?" | CASE | [generic] | Ask what stuck means first: no calls, failing tests, or waiting on the partner. Then say what evidence you would look at, who you would talk to on both sides, which hypotheses each would separate, and what you would do with the answer. If a real integration comes to mind, tell only what you did in it | Running discovery with integration partners is a named responsibility; CASE because it is a live diagnosis |
| B5 | "What do you make of where the partner API platform fits at Quartzline, and what would you want to know?" | CO | [grounded] | Company research did not run for this pack, so stay at what the role profile says: the platform is partner-facing, two engineering squads deliver it, and adoption is a tracked metric. Say that, then spend the answer on what you want to know: how adoption is measured today and the current baseline, and which roadmap decisions this PM makes alone. Do not recite company facts from memory | The only CO question the available material supports; `[grounded]` in the dossier's role profile, with the honest cost that it stays at the posting's altitude |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Thirty-plus integrations — how was that counted, and which assumption behind the number would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say the figure as your sentence has it: it counts integrations. Four slots, each in your own words: how it was counted, what the count is sensitive to, the assumption you would defend least, and which part was yours; the sentence says Led, and your answer on part stays inside it. If you do not know how some part was counted, say so plainly | The headline figure in your material; F1 rests on it |
| C2 | "Pick one of those integrations and walk me through it from scoping to go-live." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Choose one you can speak to end to end. The beats are the five your sentence states: scoping, requirements, architecture, UAT, go-live, in that order, in your own words. Add only detail you can stand behind under a second question | The sentence is high confidence with the playbook as inspectable proof, so this is the walk-through it can bear; EXP because it tests attribution stage by stage |
| C3 | "Tell me about the playbook you wrote — what's in it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The one artifact in your material with inspectable proof. Lead with the sentence in the first person, then describe the contents from the document itself, which you can reread before Thursday if you can open it. Beyond the sentence, such as how widely it is used or what changed since, answer only what you know; where you do not, say so plainly and return to the team that uses it | High confidence, so the strongest ground in the interview; a Prober will try to move from the document to claims about it |
| C4 | "How did the quarterly roadmap-input sessions work?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Confirmed, with limited inspectable proof: expect a probe, and volunteer the limit before it is extracted. Say what you can show and what is your own account. The beats are the sentence's: the sessions were quarterly, you ran them, and they fed client evidence to product. If the interviewer asks beyond the sentence, answer only from what you know, and where you do not know, say so plainly and return to the sessions you ran | F5's medium-confidence seam, rehearsed so the limit is yours to name |

### D. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | A 90-second arc with three beats. One, the integration work, your first sentence at its own scope. Two, the playbook, the second sentence. Three, why this role, in your own words: the pack supplies no reason and does not guess one. Stay in the first person and stop before you claim more than the sentences do | The opener is scored even when it feels casual; the arc is the one thing you can fully script from your own sentences |
| D2 | "What are you actually working with in API docs and schemas these days?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Start from the REST APIs your integrations were built on, at the sentence's own scope. Answer slot: the JD's line makes docs and schemas the probe. If you work with them in these integrations, say how, in your own words; if you do not, say so plainly and say what you would want to confirm about what fluency means for this team | F4 is a discovery row, and a casual question about a named skill is still scored |
| D3 | "Tell me about working across engineering, sales and customers." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Customers: the client integrations you led, at the sentence's own scope. Product: the roadmap-input sessions, with the limit volunteered as in C4. Engineering and sales are not in your sentences. Answer slot: if you worked with either in these integrations, say how, in your own words; if one was not part of your work, say so plainly and stay with the clients | F5 covers three stakeholder groups and the quotes reach two of them |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Pause, restate the question, then three sentences: the concession from A1, the quoted sentence in the first person, and that it is adjacent to the role. Stop. Hold through two follow-ups by returning to the sentence and never by adding to it. Concede specifically that a PM with three years has done the job and you have not | A1 under time pressure; the same position, shorter, so composure is the thing being tested |
| E2 | "That figure of thirty-plus — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold what the sentence says: you led them. Answer slot: if any stage or integration was shared with someone else, say which, plainly; if it was all yours to lead, say that. Concede the specific part, never the core claim | An attribution probe; the preparation is candor rehearsed |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our squads sit side by side — where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose principles rather than pretending to know the seam: who decides what is agreed up front, partner evidence brought to the disagreement, an escalation path when evidence does not settle it. Ask who owns what today, which is also reverse question 1. No claim about a past | The role works beside two squad leads whose authority the dossier leaves unestablished |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams and credit mattered, with a named stake and an intact relationship afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A Peer stem; none of your sentences carries this story, so the guidance is a scaffold |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to a stakeholder." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a message the other side did not want, and a relationship still intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A persona stem, not a Quartzline value; none of your sentences carries this story |
| G2 | "When did you put a customer ahead of an internal priority?" | VAL | [generic] | Selection scaffold: pick a time the two pulled apart, with what you weighed and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A persona stem; included so the style is not met for the first time live |

### Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| "3+ years product management experience" | A1, A2, E1, E2, D1 |
| "Own the roadmap for the partner-facing API platform" | A1, A2, B1, B3 |
| "Shipped API or platform products" | A3, C2 |
| "Technical fluency: API docs, schemas" | D2 |
| "Stakeholder management across engineering, sales, customers" | D3, C4 |
| "Agile delivery experience" | A5, A2 |
| "Run discovery with integration partners" | B4 |
| "Write specs and drive delivery with two engineering squads" | B3, F1 |
| "Define and track adoption metrics" | B2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's open risk: decision authority is asserted in the posting and not evidenced. The answer tells you whether the role is the one you are preparing for |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The second open risk: adoption is named as a responsibility with no baseline stated. It reads as diligence and answers something you need before accepting |
| 3 | "What would a strong first ninety days look like, and what would you want me to have learned by the end of them?" | It invites the hiring manager to describe the ramp A1 offered, so your plan is checked against theirs |
| 4 | "Where would you expect someone coming from the integration side to need the most support?" | It names the gap on your terms and lets the hiring manager say where their real concern sits |
| 5 | "How do partners' requests reach the platform today, and who triages them?" | It tests the roadmap-input seam from the receiving end and shows what the role inherits |
| 6 | "What is the biggest open question on the platform's roadmap right now?" | It moves the conversation from your past to a live problem you can reason about, as in the Case bank |

## Prohibited claims

What this pack will not coach, and why. The first three come from the dossier's `prohibited_claims`; the last two are built here from your own sentences.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | The first quoted sentence at its own scope, then the plain acknowledgment: "I haven't held a product manager title or role." |
| Having owned a product roadmap | Dossier `prohibited_claims`, and the `acknowledge_gap` area "Owning a roadmap and prioritization authority (R1 sub-claim)" | The plain acknowledgment: "I haven't owned a roadmap." Then a ramp plan said as a plan. No bridge |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | The plain acknowledgment: "I haven't set prioritization for an engineering squad." Then B3's principles, said as how you would reason |
| Shipped an API or platform product | Inflated form of F3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" at its own scope. The limit is the pack's observation: the material says integrations led through go-live. A3's slot stays inside what went live |
| Shaped the roadmap through the roadmap-input sessions | Inflated form of F5 | "Ran quarterly roadmap-input sessions feeding client evidence to product" at its own scope. The limit is the pack's observation: the material says the sessions fed product. C4 stays at the sessions you ran |

## Sources

- Provided: the dossier you carried in, version 1.1, dated 2026-08-14. It supplied `role_profile` (the requirements and responsibilities quoted here), `handoff_to_mock_interview` (verified evidence, weak areas and their allowed strategies, the objection behind A1, risks and employer questions behind the reverse bank, prohibited claims), and `decision` as context only. This pack rests on that dossier's date; if the posting changed since, the requirement rows may need regenerating.
- Loop: your own words, one 45-minute conversation with the hiring manager. No values-style round is detected.
- Searches sent, all refused (search permission was not granted): "Quartzline company values"; "Quartzline interview process product manager"; "Quartzline API platform strategy news". Nothing from the web is used in this pack.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Every call was refused. It would have decided whether published values theme the VAL bank, and whether a values cheat sheet applies |
| 2. Quartzline interview process | unavailable | Every call was refused. It would have checked the loop; persona weights rest on your own description of the round instead |
| 3. Quartzline strategy and recent news | unavailable | Every call was refused. It would have grounded the CO and CASE banks; B5 stays at the posting's altitude |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative JD | skipped | The dossier's role profile already fixes the requirement rows and the JD-tagged questions |

## Upgrade menu

- The interviewer's name → a read of their public path, persona weights adjusted from it, and a reverse question tied to their own career
- The recruiter's prep email → any announced focus areas or deliverables, which would add a build section
- Search permission for this session → the three refused L1 searches re-run; the CO and CASE banks stop being generic where the web supports them
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, needs search permission) → a Quartzline strategy brief and sharper CO and CASE questions; offered once
- A record of the roadmap-input sessions, such as an agenda or notes → F5's quote moves from limited proof toward inspectable, and C4 gets a document to point to
- Your answer to the slots on F3, F4, F5 and F6, said outside a drill → those rows regenerate from your own words and A3, D2, D3 and A5 become story-mapped
- The full posting text → a check of the dossier's requirement lines against the original, and any lines the dossier dropped
