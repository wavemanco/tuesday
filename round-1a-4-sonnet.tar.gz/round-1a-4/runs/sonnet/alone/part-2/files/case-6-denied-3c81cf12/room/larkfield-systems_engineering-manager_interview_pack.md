# Interview pack (loop mode): Engineering Manager, Larkfield Systems

Candidate: Yusuf. Three scheduled rounds, one shared fit snapshot, one mini-pack per round.

| Round | When | Who | Relationship | Format |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering (name not given) | Hiring manager, your would-be boss | 45 min |
| 2 | The Thursday after | Two staff engineers and a product manager (names not given) | Panel: technical peers plus a cross-functional partner | 60 min |
| 3 | The following Monday | VP Engineering (name not given) | Skip-level executive, described by the recruiter as "values and leadership philosophy" | 30 min |

The loop is built from your own account of it. Larkfield's documented interview process was not established (see Sources), so persona weights rest on your description of each round, not on the company's published loop.

## How to use this pack

- Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding for a spoken answer, not a script.
- Type key: VAL = behavioral and values alignment; EXP = work-experience deep-dive; JD = role and job-description driven; CO = company and strategy knowledge; CASE = hypothetical or live problem.
- Provenance key: `[grounded]` traces to what you wrote or to the role description you pasted; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about you or Larkfield.
- An "answer slot" is an instruction for the interview, not a question for you now. Each has two honest branches; the second always allows that the thing never happened or was not yours. Either branch is a good answer.
- Everything the pack says about your past is one of your own sentences, quoted. Anything not quoted is a slot or a plan, never a claim.

## Prep triage (three rounds, about two weeks)

1. Before Tuesday: say A1 and A3 aloud until the plain acknowledgments are boring. The same objection returns at executive altitude in I1, so this prep pays twice. A1 is the highest-ROI prep in the pack.
2. Before Tuesday: D1 (the 60%) and C1 (your 90-second arc). The sentence behind D1 is reused in E2, H1 and I2.
3. Between Tuesday and Thursday: F1 and F2 (your hiring-loop figure and how the loop works), then E2.
4. Between Thursday and Monday: I1 and I2, then H1 and H2. Send the Larkfield values page if you can find it, because it turns H into a mapped bank.
5. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description in your message. Evidence is your own words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says a team lead of six and says nothing about more than one team, and the words stay there: "I spent three years as a team lead of six." Answer slot: the two-squads line makes a probe on leading across more than one stream of work likely. If any part of your six was split across more than one line of work, say how it was run; if it was one team, say so plainly and stay with leading it |
| F2 | "building device-management services" — role description in your message | "currently at a payments company" — your message | low | [inferred] | discovery | The quote gives your current setting and nothing about devices, so the pack does not bridge. Answer slot: the role is a device-management one, so expect a probe on what you know of it. If any service you have built or run connects to physical devices, say what; if none does, say so plainly and say what you would want to learn first |
| F3 | "own delivery, hiring and growth for 11 engineers" (delivery) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence is about a team's on-call burden and one reliability quarter, with nothing inspected behind the figure; it does not say you owned a roadmap's delivery. Words stay at its scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: expect the figure to be probed on how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours; answer in your own words, and if you do not know how it was counted, say so plainly. If you are asked what roadmap work that quarter affected, say what you know of it and what was yours to decide; if none of that was yours, say so and stay with the sentence |
| F4 | "own delivery, hiring and growth for 11 engineers" (hiring) — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap in the quote's own terms, but a message line with nothing inspected behind it, so expect a probe. Lead with the loop as you said it: you run it, for backend roles. Two limits are the pack's observation, not words for you: the quote says backend roles only, and it does not say whether the 40 counts interviews you gave or interviews the loop held |
| F5 | "own delivery, hiring and growth for 11 engineers" (growth) — role description in your message | none given | none | [grounded] | discovery | Your material says nothing on developing engineers, and the pack will not supply it. Answer slot: if you have supported a specific engineer's development, say what you did, in your own words; if you have not, or it was not yours, say so plainly and say how you would approach it as a plan, never as a past |
| F6 | "partner with hardware and product on roadmap" (hardware) — role description in your message | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | Your stated limit: "I haven't owned a hardware-adjacent roadmap." The quote speaks to owning a roadmap and the role says partnering, so the material is silent on working alongside hardware people. Answer slot: if you have worked with hardware people in any form, say what and which part was yours; if you have not, say so plainly and say how you would find out their constraints in your first weeks |
| F7 | "partner with hardware and product on roadmap" (product) — role description in your message | "against roadmap pressure" — your message | low | [inferred] | discovery | The phrase touches roadmap pressure without saying where it came from or who you worked with. Answer slot: if product people were part of that quarter, say how you worked with them and what was yours; if they were not, or the pressure came from elsewhere, say so plainly and stay with the sentence |

Your other stated limit, "I've never managed managers", is not a requirement row because the role description does not say whether either squad has leads. It is handled in A3 and I1, and R1's reverse question 2 asks the Director.

## Prohibited claims (what this pack will not coach)

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated: "I've never managed managers" | The plain acknowledgment: "I haven't managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative you stated: "never owned a hardware-adjacent roadmap" | The plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." F6's slot asks only about working alongside hardware people, never about owning |
| Led two squads or a team of eleven | Inflated form of F1 | F1's quote at its own scope; the pack's observation is that your material says one team lead of six |
| Owned delivery of a roadmap | Inflated form of F3 | F3's quote at its own scope; the observation is that the sentence is about a reliability quarter |
| The reliability quarter caused the 60% drop | Inflated form of F3: the sentence says the burden dropped after the quarter | Say it as the sentence does, "dropped 60% after I pushed a reliability quarter through"; D1 and I2 rehearse what you know about attribution |
| Owned hiring for the team or set headcount | Inflated form of F4 | F4's quote at its own scope: you run the loop, for backend roles |
| Conducted 40 interviews yourself | Inflated form of F4: the figure's scope is unclear | Say the sentence as written, and answer F1 in the bank below from what you know |

---

# Round 1: Tuesday, Director of Engineering (hiring manager), 45 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the two limits you stated: hardware roadmap, managing managers; "why this role" | High. A hiring manager's prior is Case plus Skeptic, and a would-be boss is derisking exactly what you told me you lack | Say each limit plainly, then a plan; never bridge past what your sentences carry |
| Case/Strategist (B) | Live problems from the actual role: a slipped hardware date, a first-30-days plan, roadmap versus reliability | High. Same prior; the role description gives them three live topics (two squads, delivery, the hardware and product roadmap) | Clarify, then objective, options, communication, risks; think aloud |
| Conversational (C) | Opening arc, growth of engineers | Medium. Openers are almost always conversational; the role names growth | Pre-scripted 90-second arc; treat the casual questions as scored |
| Data-Driven Prober (D) | Your 60% figure | Low to medium. One quantified claim in your material; probers go where figures are | Know what you can and cannot say about how it was counted |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Part of this role is partnering with hardware on the roadmap. What have you done that looks like that?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in the pack. Open with your own limit, plainly: "I haven't owned a hardware-adjacent roadmap." Then hold, using only what you can stand behind. Answer slot: the role description puts hardware partnership on the roadmap, so expect a probe on working with hardware people. If you have worked with hardware people, say what that was and which part was yours; if you have not, or it was not yours, say so plainly and say how you would find out their constraints in your first weeks. Follow-up one: "How would you find out what hardware's constraints on the roadmap actually are?" Answer as a plan: who you would ask first, and what you would want written down. Follow-up two: "What would worry you most?" Concede specifically what you do not yet know, and do not fold on what you have said. Never describe hardware work you have not done | F6 is the likeliest place to be probed, and this question will arrive in some form; JD because it scores a stated requirement, with Skeptic delivery |
| A2 | "You'd be owning delivery, hiring and growth for eleven engineers across two squads. What changes for you at that size?" | JD | [grounded] "3 as a team lead of 6" | Start from your own words: "I spent three years as a team lead of six." The question asks about a future, so the rest is a plan, not a past: what you would want to learn first about each squad, what you would keep from how you led six, and what you would ask the Director to be clear about. Answer slot: if asked what you did at six that you would do differently, say what you know of it, in your own words; if nothing comes to mind, say so plainly and stay with the plan | F1 is the scale gap; JD because the eleven and two squads are the role's own terms |
| A3 | "Which part of this role is furthest from what you've done so far?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | An open Skeptic prompt, and your own sentence answers it. Choose which limit to name first and say it plainly: "I haven't owned a hardware-adjacent roadmap" or "I haven't managed managers". Then a plan, not a past: what you would do in the first weeks about it. Do not say what the role probably involves; if you do not know whether either squad has leads, say that and ask. Keep it to about 60 seconds, and stop | The two stated limits are what a boss weighs first; JD because it scores the role's fit, Skeptic because it invites you to disqualify yourself |
| B1 | "A hardware partner slips a firmware date by six weeks, and two customers are waiting on a feature that depends on it. Walk me through your next two weeks." | CASE | [generic] | Clarify first: what exactly slipped, what depends on it, what is flexible, who decides. Then the objective, the options (re-sequence work, split the release, descope), what you would tell product and hardware and when, and the risks. Challenge one premise respectfully, for example whether all the work really depends on the date. The question needs no claim about your past, so the guidance makes none | A live problem from the role's hardware and product roadmap line (F6, F7); generic because it is a pattern, not a fact about Larkfield |
| B2 | "You've just taken over two squads and a roadmap you didn't set. What do your first 30 days look like?" | CASE | [generic] | A plan, not a history: listen first (each squad, product, hardware), learn the commitments already made, find out what is on fire, and agree with the Director what success looks like at day 30 and day 90. Say what you would not change in the first month. Make no claim about having done it before | Hiring managers ask this to see whether you will act before you listen; generic because it presupposes nothing about you |
| B3 | "Product wants a new capability next quarter, and your squads are carrying a reliability backlog. How do you decide?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure the decision first: what the backlog is costing, what the feature is worth and to whom, who sets priority, what can run in parallel. Then, if it fits, your own sentence at its own scope as the nearest thing you have said: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: the role's roadmap-partnership line makes a probe on how you made that case likely. If you made it, say how, in your own words; if someone else made it, or no formal case was made, say so plainly and stay with the sentence | F3 and F7 are your closest material to the delivery requirement; CASE delivery with an EXP follow-up |
| C1 | "Walk me through your journey so far." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A 90-second arc whose beats are the sentence's: nine years in engineering, three as a team lead of six, now at a payments company. Do not add a turning point or a reason that is not yours. Answer slot: the role is a new kind of job, so expect "why this role". Give your own reason in your own words; if you have not settled one, say so plainly and say what you are trying to find out | The opener is scored; F1 is the evidence for the leadership beat |
| C2 | "Tell me about a time you helped an engineer grow." | JD | [generic] | A selection scaffold, because your material carries no sentence on this. Pick a time with a named person, what they wanted, what you did, and what changed afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach growing engineers as a plan | F5 is a discovery gap; the role names growth, so it is a free miss if unrehearsed |
| D1 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say the sentence at its scope. Answer slot: the four things a figure raises are how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each from what you actually know, in your own words; if you do not know how it was counted, say so plainly. Name your weakest assumption before they do, and do not say the quarter caused the drop; the sentence says it dropped after | The only headline figure on your material, and probers go there (F3); EXP because it tests attribution honesty |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would tell you, three months in, that this hire is going well?" | It turns an unknown bar into criteria you can aim at, and shows you think in outcomes |
| 2 | "How are the two squads organised today — is there a lead or senior engineer I'd work through?" | It finds out whether managing managers matters, without volunteering a limit |
| 3 | "Where does the roadmap conversation between hardware, product and engineering happen today, and who is in it?" | It addresses your biggest gap by asking how the seam works rather than claiming you know it |
| 4 | "Where do hardware timelines and software delivery pull against each other most?" | It shows you are already thinking about the role's real tension |
| 5 | "What do candidates tend to underestimate about this job?" | It invites candour from your would-be boss, which often reveals what the team has learned the hard way |

---

# Round 2: Thursday, panel (two staff engineers and a product manager), 60 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (E) | Seam-splitting, collaboration, disagreement style, credit-sharing | High. All three panellists are not your boss; the panel prior blends each member's relationship, and the PM and staff engineers are partners the role works with | Reciprocity framing; propose seam principles, not a pretend seam; a disagreement story that shows spine and tact |
| Data-Driven Prober (F) | Your hiring-loop number, how your loop works, reliability judgment | High to medium. Staff engineers verify depth, and your hiring line is a figure | Know what you can and cannot say; say plainly when you do not know |
| Cross-functional / Conversational (G) | Customer-first values, curiosity about the domain | Medium. The PM is a cross-functional interviewer; the recruiter gave no focus areas for this round | Pick stories where the hard truth landed; if your material shows none, say so |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Product and engineering sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a map you do not have: who owns which question, how trade-offs get decided and made visible, how disagreement is resolved without either side going around the other. Add reciprocity: what you would give the PM (clarity on what the squads can carry), not only what you need. Say what you would want to learn from the PM first. The question needs no claim about your past | The role's product-partnership line (F7); generic because it is a pattern |
| E2 | "Tell me about a time you disagreed with someone about priorities." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | The beats are the phrase's: you pushed a reliability quarter through, against roadmap pressure. Tell it in your own words. Answer slot: the role's roadmap line makes a probe on who the pressure came from and how you worked through it likely. If you can say who and how, say it; if it was not a disagreement with a particular person, or the working-through was not yours, say so plainly and stay with the quarter. End where your sentence ends, with the on-call burden dropping 60% after | F7 is thin on who the pressure came from; VAL because it scores disagreement style, with EXP follow-ups |
| E3 | "How do you handle credit when work spans teams?" | VAL | [generic] | A principle and a scaffold, no claim about your past: name the contribution of each side specifically, say it where the audience that matters hears it, and avoid claiming a shared result as your own. If a real example comes to mind, use it; if none does, say so plainly and give how you would handle it | A standard peer probe; generic because it is the persona's stem |
| F1 | "You mention about 40 interviews last year. What does that number cover?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say it as written: you run the loop, for backend roles. Answer slot: the quote does not say whether the 40 is interviews you gave or the loop's total. Say which, in your own words, and what it counts; if you do not know how it was counted, say so plainly. Name the assumption you would defend least before they do | The figure is a probing target; F4 is the evidence, and the scope is the unclear part |
| F2 | "You run the loop for backend roles. Walk me through how it works." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start from the sentence: you run the loop, for backend roles. Answer slot: the role puts hiring in scope and staff engineers sit on loops, so expect a probe on how the loop is structured and how interviewers align. If you set any of it, say what and why, in your own words; if the structure was set by others, or there is none, say so plainly and describe how you ran your part. The sentence says backend roles only, so do not extend to other disciplines | Staff engineers will test depth behind a hiring claim; F4 says backend, and a squad building devices may hire beyond that, which the pack cannot establish |
| F3 | "How would you decide whether the reliability work a squad asks for is the right size?" | CASE | [generic] | Structure it: what the service's users need it to do, what failing costs, how you would find out where the squad is now, what you would measure (name the metric if you have one, do not invent it), what you would compare it to, and who decides. Show you would listen to the staff engineers' judgment rather than overrule it. No claim about your past | A technical-judgment case from the role's delivery line (F3); generic because it presupposes nothing about you |
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold, because your material carries no sentence on this. Choose a time with a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A cross-functional values stem; the recruiter gave no focus areas for this round |
| G2 | "What are you actually curious about in device management or industrial IoT?" | CO | [grounded] "currently at a payments company" | Be honest about where you start: you are at a payments company. Answer slot: the role is a device-management one, so expect a probe. If any service you have built or run connects to physical devices, say what; if none does, say so plainly and say what you would want to learn first and how. Do not claim knowledge of Larkfield's products; none is established here | F2 is a discovery gap and the panel will test genuine interest; CO because it is domain knowledge, with Conversational delivery |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What could a new manager do in the first month that would genuinely help your work?" | The reciprocity question for peers: it asks what you can give, not only what you need |
| 2 | "When roadmap and reliability pull in different directions, how does product decide with engineering today?" | It asks the PM about the seam you have been asked about |
| 3 | "What do you wish hardware and software leads did differently with each other?" | It invites the staff engineers to name a real problem and shows you are thinking about the seam |
| 4 | "What's an engineering decision here you're proud of, and one you'd redo?" | It converts an evaluation into a peer conversation and reveals team norms |
| 5 | "How do you want a manager to show up in your design discussions?" | It signals you will not overrule technical judgment, which staff engineers weigh heavily |

---

# Round 3: Monday, VP Engineering ("values and leadership philosophy"), 30 min

### Persona weights

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (H) | Scenario probes on how you lead, your philosophy, a hard truth delivered | High. The recruiter's own words describe this round as values and leadership philosophy | Pick stories where the hard truth landed; where your material shows none, say so rather than supplying an ending |
| Pressure (I) | Time-boxed answers, "why you", "how much of that was you" | Medium to high. A skip-level or executive prior is Case plus Pressure; 30 minutes means short, interrupted answers | Pause, restate the question, hold a challenged position through two follow-ups, concede specifically |
| Case/Strategist (J) | Altitude questions about reliability standards and the company | Medium. The executive prior includes strategy; the recruiter did not say there is a case | Clarify, structure, then answer; use the company's vocabulary only once you have it |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Choose the story where the hard truth actually landed. If the reliability quarter fits, its beats are only the phrase's: you pushed it through, against roadmap pressure, and the on-call burden dropped 60% after. Answer slot: if you can say who you told and what happened to the relationship afterwards, say it in your own words; if the story was not a conversation with leadership, or the ending was not yours, say so plainly and use another story or the nearest thing your material does carry. If no story comes to mind, say so plainly | A values stem from the recruiter's description of the round; F3 is your closest material, held at its own scope |
| H2 | "How would you describe your leadership philosophy, and where did it come from?" | VAL | [grounded] "3 as a team lead of 6" | A selection scaffold: state two or three principles you actually hold, and for each give one example from your own work that you can support under a follow-up. The only leadership experience your material states is "3 as a team lead of 6", so any example must come from your own account of that, in your own words. If a principle has no example you can stand behind, say it as a belief and say so plainly | The recruiter named leadership philosophy as the round's content; F1 is the evidence for the leadership beat |
| H3 | "Tell me about a hiring decision where you changed your mind." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | A selection scaffold, because your sentence says you run a loop and says nothing of a case where you changed your mind. Choose one with a named reason for the first view, what changed it, and what you learned. Answer slot: if you have such a case, tell it, in your own words; if you do not, say so plainly, then say how you check your own first impressions as a plan. Do not describe a calibration process you do not use | The role's hiring line and the leadership theme meet here; F4 is the evidence, and the story itself is yours to choose |
| H4 | "Tell me about feedback that changed how you lead." | VAL | [generic] | A selection scaffold: pick a real piece of feedback, say who gave it, what you did with it, and what is different now. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you seek feedback as a plan. Do not use a manufactured weakness | A standard leadership-philosophy probe; generic because your material carries no sentence for it |
| I1 | "You have 60 seconds: why you, when other candidates may have run a hardware roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" and "9 years engineering, 3 as a team lead of 6, currently at a payments company" and "I run our hiring loop for backend roles — about 40 interviews last year" | Hold-then-concede. Pause, restate the question, and name the limit plainly: "I haven't owned a hardware-adjacent roadmap." Then hold only what your sentences carry: nine years in engineering, three as a team lead of six, you run a hiring loop for backend roles, and a reliability quarter after which on-call burden dropped 60%. Do not claim a comparison with other candidates, or anything about hardware. Hold through two follow-ups by returning to those sentences, never by adding to them; concede specifically what you do not yet know about hardware and say how you would learn it. Do not fold on what you said, and do not argue your way into a claim you cannot back | The Round 1 objection returns at executive altitude (F6); JD because it scores fit, with Pressure delivery |
| I2 | "That 60% on-call result — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold-then-concede. Your sentence says "I pushed a reliability quarter through" and "my team's"; hold exactly that. Answer slot: if you can say which part was yours and which was your team's, say so, in your own words; if you do not know how the share divides, say so plainly. Concede the attribution you cannot make, and do not say the quarter caused the drop | The attribution probe is the stem for Pressure; F3 is the evidence and is limited to the sentence's scope |
| J1 | "What does reliable mean for a device-management service, and how would you set the bar for two squads?" | CASE | [generic] | Clarify first: reliable for whom, and what failure costs them. Then structure: who relies on the service, what failure looks like to them, what you would measure (name the metric if you have one, do not invent it), and who decides the bar. Say you would learn the answer from Larkfield's people before committing. No claim about your past | A strategy-altitude case from the role's delivery and device-management lines (F2, F3); generic because it presupposes nothing about you |
| J2 | "What would you want to understand about Larkfield's strategy before taking this role?" | CO | [generic] | Because nothing about Larkfield's strategy was established here, ask rather than assert: where the company wants to grow, what the hardware and software roadmap is optimising for, what the squads are expected to deliver this year, and how engineering is expected to scale. Make no claim about Larkfield; the upgrade menu says what research would add | A CO question that goes generic without research, which is the honest cost of the refused search |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "How do the company's values show up in engineering decisions in practice?" | The recruiter framed this round around values, so you ask for the practice, not the poster |
| 2 | "What do your best engineering managers do that others don't?" | It shows you are calibrating to a standard, and gives you your own rubric |
| 3 | "What are you most hoping engineering will do differently in the next year or two?" | It moves to the VP's altitude and hands you a strategy hint |
| 4 | "Where do you see managers new to hardware-adjacent work struggle most, and what helps?" | It addresses your gap openly at the right altitude without claiming to have solved it |
| 5 | "What would make you glad, a year from now, that you hired me?" | It asks the VP to define success in their own words |

---

## Requirement coverage

| Requirement (role description) | Questions |
|---|---|
| "Lead two squads building device-management services" | A2, B2, F3, G2, J1 |
| "own delivery" | B1, B3, E2, F3, I2, J1 |
| "hiring" | F1, F2, H3 |
| "growth" | C2, H2, H4 |
| "partner with hardware" | A1, A3, B1, I1 |
| "partner with ... product on roadmap" | B1, B3, E1, E2 |

## Sources

Provided documents: your message (the role description, the three round descriptions, and your background).

Searches sent, all refused:

- "Larkfield Systems industrial IoT values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Every call was refused. It would have fed a values cheat sheet for Monday's round; none is built because no published values are in hand, and H uses persona stems and the recruiter's description instead |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Every call was refused. It would have checked the loop and the round formats; weights rest on your account of each round |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Every call was refused. It would have fed CO and CASE questions; J2 and G2 are generic as a result |
| 4. `{interviewer name} Larkfield Systems` | n/a | No interviewer names were given, so no query could be formed; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | The role description you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Full JD text → the seven fit rows are graded against one line of role description today; a full JD would add requirements and JD-tagged questions
- Your CV → the quotes come from your message alone; a CV would add evidence rows, and an inspectable artifact for the reliability quarter (an on-call or incident dashboard export, or the quarter's plan) would lift F3 from medium and sharpen D1 and I2
- Your answers to the answer slots in A1, A2, F1, F2 and E2 → rows F1, F3, F4, F6 and F7 are regenerated with your words, and the matching guidance becomes story-mapped
- Interviewer names for each round → an interviewer read, persona weights tuned to their public footprint, and at least one reverse question tied to each person's own path
- Any focus areas or pre-declared exercise from the recruiter for each round → coverage of a graded deliverable, and sharper persona weights, especially for Thursday's panel
- Larkfield's published values page, pasted → the Monday round gets a values cheat sheet with a mapped story per value
- Search access, or a pasted strategy brief → the three refused L1 targets (values, loop, strategy) are run, and J2, G2 and the case questions stop being generic; a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, is available on your say-so
- A `tuesday-dossier.md` → verified evidence and absolute prohibited claims would replace what this pack builds locally from your message
