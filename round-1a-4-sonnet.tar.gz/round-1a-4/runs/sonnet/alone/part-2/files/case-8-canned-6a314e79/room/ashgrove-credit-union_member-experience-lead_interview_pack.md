# Member Experience Lead, Ashgrove Credit Union: interview pack for Dara

Loop pack for 3 December 2026, three rounds, built on 24 November 2026.

- Round 1: 30 minutes with the recruiter.
- Round 2: 45 minutes with the Head of Member Services, who would be your manager, mostly behavioural.
- Round 3: 60 minutes with a panel of two branch managers, including a 20-minute case on a complaint escalation. The panel is also the values round and scores against the four published values.

No interviewer names are assigned yet, so there is no interviewer read. Persona weights come from the round types in the recruiter's email.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores.
- Type tags: VAL (does past behaviour show a published value), EXP (does a CV claim survive scrutiny), JD (can you do the listed job, gaps included), CO (do you know the company and its strategy), CASE (a live problem from the role).
- Question IDs run by persona (A, B, C, D, E, G in rounds 1 and 2; H, J, K in round 3). F1 to F9 are fit-snapshot rows, so no persona uses F.
- Guidance is scaffolding, not a script. Where it says answer slot, it is an instruction for the interview: answer from your own experience, or say plainly it was not yours. Neither branch is a failure.
- Every claim about your past in this pack is one of your own sentences, quoted. If a line sounds bigger than what you told me, cut it.

## Prep triage (nine days: 24 November to 3 December)

1. C1, the highest-ROI rehearsal in the pack. Say the hold and the concession aloud daily until they are boring. Start today.
2. Answer the slots in F1, F3, F4, F5 and F7 in writing, in your own words, and send them to me. The rows and the banks regenerate from what you say (upgrade menu).
3. J1 and J2, timed to 20 minutes, aloud, twice each. Practise the structure, not a model answer.
4. H1 to H4: one story per published value, from your own material, or the honest branch ready.
5. A3 to A6: decide your real answers on reason for looking, pay, notice and location before the recruiter asks.
6. Two reverse questions per round.

Everything else is insurance. A1 is one story told the same way in all three rounds, so you don't tell it three ways in one day.

## Fit snapshot (shared by all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal complaints log, not the process end to end, and nothing inspected sits behind it. The words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat around the log likely. If any stage outside the log was yours, say which and what you decided, in your own words; if none was, or it was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. No adjacent quote is stretched to cover it |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | The sentence says a monthly complaints spreadsheet, not what it contained. The link to the JD's reporting line is this pack's derivation. Answer slot: expect a probe on the spreadsheet's contents. Say what it showed and how each figure was counted, in your own words; if you do not know how a figure was counted, say so plainly |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Tellers, not supervisors. The words stay at "trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on who you have taught likely. Say who you have trained or guided on escalations beyond the tellers, in your own words; if it was only the tellers, say so plainly |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing on digital teams. Answer slot: if you have worked with a digital or product team on anything a member uses, say what, and what part was yours; if you have not, say so plainly and say what you would bring to such a team |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The quote already reaches the length. Say it in its own terms: "I have 6 years in retail banking, the last 3 as a branch supervisor." Let them map it to the JD's phrase; do not relabel your history in the JD's words |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | The sentence says a formal complaints log; it does not say what the log was kept against. Answer slot: expect a probe on this. Say what the log was kept against, whether rules, deadlines or internal standards, in your own words; if it was tied to none, or you do not know, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You have stated the limit. Words: "I haven't presented above regional level." Then how you would prepare, as a plan and never as a past. The pack's observation: your material does not show whether the JD's senior leaders sit above that level at Ashgrove |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Reword only the quote: keep your word, spreadsheet, and say "I built the monthly complaints spreadsheet our regional manager uses." The JD says Excel and the sentence does not. Answer slot: name the tool it was built in, in your own words |

## Grounding brief (the four facts from the July 2026 strategy brief as you relayed them, plus the JD)

| Item | What the material says | Provenance | Where it comes up |
|---|---|---|---|
| Who they are | "member-owned, about 900 staff" — JD | [grounded] | A2 |
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | G1, G2, round 2 reverse questions |
| Branch network | Consolidate eight branches into five hubs over 2027 | [grounded] | J3, round 3 reverse questions |
| New product | Launch a small-business lending product in Q1 2027 | [grounded] | round 2 reverse questions |
| Competitive pressure | The main pressure is app-only banks | [grounded] | J1, G1 |

Use the brief's own words (digital channels, hubs, app-only banks). Bring one item to prove you read it, then your own view; do not recite the list.

## Round 1: recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; the journey question; logistics asked casually | High: the recruiter-screen prior is conversational (personas.md), and the email gives this round no behavioural or case content | Pre-script the 90-second arc (A1); treat the casual logistics as scored (A3 to A6) |
| Skeptic (light) | Knockout checks on the JD's hard lines | Medium: the JD names regulated complaints and the contact centre, and F2 is a negative you stated | Plain acknowledgment, no stretching (B1, B2) |

### A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped in three beats, each a clause the quotes state: the six years in retail banking and the last three as a branch supervisor; the branch's formal complaints log and training new tellers on the escalation script; the monthly complaints spreadsheet the regional manager uses. About 90 seconds, in your own words. Close on why this role, in your own reason (A2); the pack supplies none | The Conversational opener. F1, F3, F4 and F6 are the rows it draws on; EXP because every beat will be checked against the CV later |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Pair one published fact with your own reason. Facts in hand: "Own the Fix — whoever finds the problem keeps hold of it until it is solved." and the brief's 40% of member service on digital channels by 2028. Your reason: say your actual reason, in your own words; the pack supplies none. One fact, not the list, because the recruiter sent you the brief and will hear it back | Motivation consistency is the recruiter screen's job (personas.md); CO because it tests whether you read what they sent |
| A3 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason in one or two sentences, in your own words, and turn it toward what you want next. The pack supplies no reason. If the reason is hard to say, say less of it, not something different | A reason-for-leaving question is a standard recruiter row; EXP because it tests the story's consistency across rounds |
| A4 | "What are you looking for on salary?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first and respond to it. Decide before 3 December. If asked what you earn now, you can decline to say and return to the band. The pack supplies no figure | The role's terms; the only safe answer is yours |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, as your contract states it | The role's terms, asked of every candidate |
| A6 | "Where would you be working from, and could you work across more than one branch?" | JD | [grounded] | Logistics slot: say your own constraint on where and how often you can work, in your own words. Ask where the role is based, because the JD you pasted does not say. The pack supplies no constraint | The JD's "across branches" line raises it; the JD gives no location |

### B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role needs experience handling regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold the sentence at its scope: "I handled the branch's formal complaints log." Answer slot: say what the log was kept against, whether rules, deadlines or internal standards, in your own words; if it was tied to none, or you do not know, say so plainly and stay with the log | F7 is the thin row; JD because it scores a stated requirement |
| B2 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Plain acknowledgment first: "I haven't worked in a contact centre." Then the nearest work at its own scope: you handled the branch's formal complaints log and trained new tellers on the escalation script. Then, in your own words, what you would ask to see or learn first, as a plan. Stop there | F2 is a stated limit, and a recruiter checks it first; JD because the JD names the contact centre |

### Reverse questions: round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "Can you share the names or roles of the two branch managers before 3 December?" | Unlocks an interviewer read |
| 2 | "What form does the 20-minute case take: written, spoken, any materials?" | Removes the biggest unknown in round 3 |
| 3 | "Who does the contact centre report to today?" | Surfaces the contact-centre scope in F2 |
| 4 | "How soon after 3 December will you decide, and who does?" | Standard process close |
| 5 | "Is there anything in my background you'd want me to address before round 2?" | Gives the recruiter a chance to flag an objection early |

## Round 2: Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the gaps: scope of the log against the whole process, contact centre, presenting up | High: a manager is buying capability and de-risking gaps (personas.md), and F1, F2 and F8 are where the material is thinnest | Rehearse C1 until it is boring; plain acknowledgments from stated negatives only |
| Values / Behavioral | Past-behaviour prompts | High: the recruiter's email calls this round mostly behavioural | Selection scaffolds with honest branches (D1, D2) |
| Data-Driven Prober | Walks the spreadsheet and the reporting line | Medium: the JD requires monthly reporting and Excel, and the spreadsheet is your reporting evidence (F3, F9) | Say what it showed and how it was counted, or that you do not know (E1) |
| Case / Strategist | The role's roadmap, digital shift | Low to medium: a manager prior, adjusted down by "mostly behavioural" | Clarify, then structure (G1) |

### C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You handled your branch's formal complaints log. This role owns the process across branches and the contact centre. Which part of that wider process have you owned?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | The highest-ROI rehearsal in this pack. Open with the hold: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Name the limit before they press: "I haven't worked in a contact centre." The pack's observation: your material says the log, not the process end to end. Answer slot: if any stage outside the log was yours, say which and what you decided; if none was, or it was not yours, say so plainly and stay with the log. Follow-up 1, "what happens to a complaint after it leaves your log?": answer from what you saw, or say you did not see it. Follow-up 2, "could someone from a contact centre do this better?": concede that specific point in your own words and hold only what the quotes carry; say what you would learn first, as a plan. Follow-up 3, "so why you?": return to the same sentence, add nothing, stop | F1 and F2 are where the JD's headline presses hardest on the material, so this objection arrives in some form; JD because it scores the stated requirement, with a Skeptic delivery |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose between the two limits you have stated, the contact centre or presenting above regional level, whichever you honestly think is the bigger. Say it plainly ("I haven't worked in a contact centre" or "I haven't presented above regional level"), then one sentence on how you would close it, as a plan. Do not pick a trivial weakness to avoid these; the pack does not rank them for you | F2 and F8 are stated limits, and this stem asks for them by name; JD because it scores the requirement list |
| C3 | "What's the most senior group you've presented to?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented above regional level." Answer slot: if you have presented to your regional manager or any group, say what it was and how it went, in your own words; if you have presented to no one, say so plainly. Then how you would prepare, as a plan | F8; JD because the JD asks for confidence presenting to senior leaders |
| C4 | "You trained new tellers on the escalation script. What changes when the person you're coaching is a supervisor?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold: "I trained new tellers on our escalation script." Answer slot: say who you have trained or guided on escalations beyond the tellers, in your own words; if it was only the tellers, say so plainly. Then your own view of what differs, as a view and not a past event | F4; JD because it scores the coaching line |

### D: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time a complaint didn't go as it should have, and what you did." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold, themed on the JD's complaints ownership and "Own the Fix": pick a time where you stayed with it. It needs a named stake, what you did and when, how it ended, and which part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log," or how you would handle it | Open prompt; the theme comes from the JD and the Own the Fix value; VAL because it tests behaviour against a published value |
| D2 | "Tell me about a time you delivered an unpopular truth to someone senior." | VAL | [generic] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and an intact relationship at the end. If no such time comes to mind, say so plainly. Your spreadsheet is a report your regional manager uses; do not claim a hard truth landed through it unless it did | A persona stem for Values interviewers; F3 is the nearest row, and the honest branch is a real option |

### E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about the monthly complaints spreadsheet you built. What did it show?" | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the sentence at its scope. Then the four defend-it slots, each in your own words: what it showed, how each figure was counted, what the figures are most sensitive to, and which part you would defend least. If you do not know how a figure was counted, say so plainly. Name which parts were yours | F3; EXP because it tests whether the one reporting claim survives two follow-ups |
| E2 | "How would you build the monthly report on complaints for our senior leaders?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | A method answer with no claim about the past: define each measure before reporting it, say who reads it and what you want them to decide, and say what the figures cannot tell them. Answer slot: name the tool your spreadsheet was built in, in your own words | F9 and the JD's Excel and monthly-reporting lines; JD because the answer is a design |

### G: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Ashgrove wants 40% of member service on digital channels by 2028. Which complaints should stay with a person, and why?" | CO | [grounded] | A reasoning answer, no claim about your past. Sort by what the member needs, not by channel. Say what you would need to know first. Challenge one premise respectfully, for example whether 40% of service means 40% of complaints. Use the brief's words and name app-only banks only as the pressure the brief names | Strategy-grounded CO from the brief; CO because it needs company altitude, with CASE delivery |
| G2 | "Tell me about working with a digital or product team." | JD | [grounded] | Selection scaffold: pick a time you worked with people who built or changed something a member uses. Name what you needed from them and what they needed from you. If no such time comes to mind, say so plainly, then say what a complaints lead brings to a digital team, as a view | F5 is empty; the JD's digital line raises it; the honest branch matters most here |

### Reverse questions: round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "Where does complaint ownership sit today between the branches and the contact centre, and where does it split?" | Shows you read the JD's scope line and gets the real shape of F1 and F2 |
| 2 | "Which complaint journeys does the 40% digital target touch first?" | Ties your questions to the brief; shows the digital line matters to you |
| 3 | "Who reads the monthly complaints report today, and what do they do with it?" | Opens the reporting audience (F3, F8) without claiming anything |
| 4 | "With the small-business lending product launching in Q1 2027, what complaints would you expect it to create?" | Uses the brief's launch date and signals forward thinking |
| 5 | "What would make you hesitate about my background for this role?" | Brings the objection into the room while you can answer it |

## Round 3: panel of two branch managers (60 minutes, 20-minute escalation case, values-scored)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes scored against the four published values | High: the recruiter's email says the panel scores against the four values | One story per value, or the honest branch (H1 to H4) |
| Case / Strategist | The 20-minute complaint-escalation case | High: the email names the case, 20 of the 60 minutes | Clarify, objective, approach, metrics, risks; challenge one premise (J1 to J3) |
| Peer Evaluator, adapted | Where the branch's job meets yours; credit and disagreement | Medium, this pack's inference: the role coaches branch supervisors, so the panel owns the other side of that seam | Propose seam principles, not facts about Ashgrove (K1 to K3) |

### H: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided from the member's side of the counter when it was harder for you." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold on Members First, Always: pick a time with a named stake, what the easier option was, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, the branch's formal complaints log, at its scope, or how you would handle it | The value's own words raise it; VAL; the quote carries no story, so this is a scaffold |
| H2 | "Tell me about a time something had to be explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on Plain Words, with the beats the sentence states: you trained new tellers on the escalation script. Answer slot: if you changed any wording of the script, or how you explained it, say what and why; if you did not, or it was not yours to change, say so plainly and describe how you taught it | The value's own words raise it; F4 carries the nearest story |
| H3 | "Tell me about something you did for the town your branch serves that no target asked for." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Selection scaffold on Neighbours, Not Numbers: pick a time with the people it was for, why it was not on any target, and what it cost. If no such time comes to mind, say so plainly, then say that you were a branch supervisor for the last three years, at that scope, and how you would handle it | The value's own words raise it; F6 is the nearest row and carries no story of its own |
| H4 | "Tell me about a time you found a problem that wasn't yours and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold on Own the Fix: pick a time you found it, kept it, and it was solved, with which part was yours. Answer slot: if you kept hold of any complaint until it was solved, say which and what was yours; if the log's job ended at recording, or you passed items on, say so plainly and describe how the log worked | The value's own words raise it; F1 is the nearest row, and a probe on what the log did is likely |

### J: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member has raised the same problem three times, at the counter and then by phone, and each time was told it is with someone else. They say they are thinking of moving to an app-only bank. You own the process. What do you do first?" | CASE | [generic] | A structure, no claim about your past. Clarify aloud first: what the member was told, by whom, what is unresolved, and whether any deadline applies (say you would confirm which). Objective: the member knows who holds it and when they will hear. Approach: one named owner today, a call back in plain words, trace the handoffs, fix this one, then ask why it bounced. Metrics and risks last. Challenge one premise respectfully, for example whether this is a one-off or a pattern | The brief's competitive pressure plus the JD's ownership line; a practice case, since Ashgrove's own case is unknown |
| J2 | "A branch supervisor tells you they keep complaints at branch level because escalating makes the branch look bad. What do you do?" | CASE | [generic] | Ask before you tell: what they have seen escalation do. Concede what is real in their view. Separate what escalation protects for the member from how it looks for the branch. Agree one concrete change. No claim about your past | The JD's coaching-on-escalations line, set as a live problem |
| J3 | "Over 2027, eight branches become five hubs. A member whose branch is affected complains that the service has gone. Who owns that complaint, and what do they tell the member?" | CASE | [grounded] | Keep to the complaint, not the merits of the plan: the panel's business is theirs. Say what you would need to know first, then one owner and plain words. Tie to Neighbours, Not Numbers. Challenge one premise respectfully, for example whether the member is complaining about the change or about a failure. No claim about your past | The brief's consolidation plan; CASE because it is a live problem with a CO frame |

### K: Peer Evaluator, adapted

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Where is the seam between a branch manager's job and yours when a complaint arrives, and what happens when we disagree?" | CASE | [generic] | Offer seam principles, not facts about Ashgrove: the member sees one owner; the branch keeps what only the branch can see; you agree who decides before it is needed. Say how you would raise a disagreement. No claim about your past | Panel members own the other side of the JD's branch-coaching line; CASE because it is a live design |
| K2 | "Our supervisors know their members better than you ever will. How do you coach them without telling them how to do their job?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Say that you were a branch supervisor for the last three years, at that scope, and nothing about what it was like. Then your approach as a view: ask what they do and why before you suggest anything. Answer slot: if you have coached anyone beyond the tellers, say who, in your own words; if not, say so plainly | F4 and F6; JD because the coaching line is stated |
| K3 | "What would you want to find out in your first month before changing anything?" | CASE | [generic] | A listening plan: where complaints enter, who holds them at each handoff, what members were told, what the monthly report shows, and what each branch needs from you. No claim about your past | The JD's ownership line set as a plan; CASE |

### Values / principles cheat sheet

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold (H1). F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." carries no story of its own |
| Plain Words | If a member needs it explained twice, the writing was wrong | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script." with the slot in H2 |
| Neighbours, Not Numbers | Every branch belongs to its town | Scaffold (H3). F6: "6 years in retail banking, the last 3 as a branch supervisor." is the nearest sentence |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." with the slot in H4 and D1 |

### Reverse questions: round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would you want from this role when a complaint comes through your branch?" | Puts the panel's needs first; the seam in K1 |
| 2 | "How do you expect the move to hubs to change how complaints reach this role?" | Shows you read the 2027 plan and lets them speak to it |
| 3 | "What does a good escalation from a supervisor look like to you?" | Gets their standard for J2 and K2 |
| 4 | "Can you give me an example of Plain Words or Neighbours, Not Numbers shaping a decision in your branch?" | The panel scores on the values; this shows you take them seriously |
| 5 | "What could a new person in this role do in the first month that would help your branch?" | Reciprocity: what you bring, not just what you need |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own the complaints process end to end across branches | C1, J1, K3 |
| ...and the contact centre | B2, C1, C2 |
| Report monthly on complaint volumes and resolution times | E1, E2 |
| Coach branch supervisors on escalations | C4, J2, K2 |
| Work with digital teams on self-service journeys | G1, G2 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B1 |
| Confident presenting to senior leaders | C2, C3 |
| Comfortable with Excel reporting | E1, E2 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's formal complaints log, not the process end to end |
| Worked in or across a contact centre | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I haven't presented above regional level." C3's slot asks only what you have presented |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "trained new tellers on our escalation script." |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope; the slot asks only what the spreadsheet showed |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope; the slot asks only what the log was kept against |
| Excel reporting expertise | Inflated form of F9 | F9's quote: "spreadsheet", in your word |

## Sources

Provided documents: the JD text; the four published values, copied by you on 24 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the process; the four facts you relayed from Ashgrove's July 2026 strategy brief (the brief itself was not in this conversation, so the grounding rests on your summary); your background paragraph. No dossier. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the cheat sheet and the VAL questions |
| 2. `Ashgrove interview process member experience` | skipped | The recruiter's email names all three rounds, their lengths and who runs them, so the loop and persona weights are fixed |
| 3. `Ashgrove strategy` / recent news | skipped | The brief relayed from July 2026 supplies current priorities for G1, J3 and the reverse questions |
| 4. `{interviewer name} Ashgrove` | n/a | No names assigned yet; the interviewer read is absent and the upgrade menu says what names unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names for rounds 2 and 3 → an interviewer read, persona weights adjusted from public professional footprint, and a reverse question tied to their own path
- Your own answers to the slots in F1, F3, F4, F5 and F7, said in a message outside any drill → those rows move from discovery or transferability to quoted material, and the scaffolds in B1, D1, E1, G2 and H4 become story maps
- A redacted extract or screenshot of the monthly complaints spreadsheet (columns only, no member data) → the one inspectable artifact that can lift F3 and F9 from medium to high
- The recruiter's answer on the form of the 20-minute case and any materials → a build section if a deliverable is declared, and the J cases retuned to the real format
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports, recent organisation context, and panellists' public footprint once names are known
- A tuesday-dossier.md from an earlier session, if you have one → verified evidence and prohibited claims in place of the ones built here
