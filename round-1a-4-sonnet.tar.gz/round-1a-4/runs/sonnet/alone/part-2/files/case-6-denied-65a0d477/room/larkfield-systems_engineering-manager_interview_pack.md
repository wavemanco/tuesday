# Interview pack: Engineering Manager, Larkfield Systems (loop of three rounds)

Candidate: Yusuf. Role: Engineering Manager at Larkfield Systems (industrial IoT, ~600 people).

| Round | When | Who | Length | Relationship |
|---|---|---|---|---|
| A | Tuesday | Director of Engineering (name not given) | 45 min | Hiring manager, your would-be boss |
| B | The Thursday after | Two staff engineers and a product manager (names not given) | 60 min | Panel |
| C | The following Monday | VP Engineering (name not given) | 30 min | Skip-level; the recruiter's description: "values and leadership philosophy" |

Built in loop mode: one shared fit snapshot and sources, then a mini-pack per round with its own persona weights, bank and reverse questions. The loop is established by your own message (three sessions, who runs each), so no archetype fallback is used.

## How to use this pack

- Personas describe how a question is asked; types describe what it scores. Rehearse both.
- Type key: VAL = behavioral or values alignment; EXP = experience deep-dive, whether your claims survive scrutiny; JD = role-driven, the stated job including its gaps; CO = company and strategy knowledge; CASE = a live problem from the role.
- Provenance labels: `[grounded]` traces to what you gave me; `[inferred]` is derived from a named adjacent source; `[generic]` is a pattern with no claim about you or Larkfield.
- Guidance is scaffolding, not a script. Where a cell says "Answer slot", it is an instruction for the interview, addressed to your answer there: it asks nothing of you here, and it needs your own words from your own experience.
- Every sentence about your past in this pack is one you wrote, quoted. The pack's observations about what your material does not show are analysis, not words for you to say.

## Prep triage

Three rounds in about two weeks. Do these, in this order, and treat everything else as insurance.

1. Before Tuesday: A1 (the highest-ROI rehearsal in the whole pack), then A7, A8 and A9.
2. Between Tuesday and Thursday: B4 and B9 (the same reliability story, defended two ways), then B1.
3. Between Thursday and Monday: C5 (the pressure version of A1), then C1 and C4.
4. Everything else is insurance.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the role description in your message; evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role description in your message | "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | medium | [grounded] | transferability | Your material says a team lead of 6, and the words stay at that scope: "Nine years in engineering, three of them as a team lead of 6." The pack's observation: it does not show two squads, eleven people or device-management work. Answer slot: the role text makes a probe on what changes from 6 to two squads likely. Say what you think changes, in your own words, as a view and not a past; if you haven't thought it through, say so plainly and say what you would ask first |
| F2 | "own delivery, hiring and growth for 11 engineers" (the delivery part) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The words stay at the quote's scope: "I pushed a reliability quarter through against roadmap pressure", and the burden "dropped 60% after". The pack's observation: the sentence says the drop came after the quarter, not that the quarter caused it, and says nothing about delivery dates or commitments. Answer slot: if delivery commitments were yours to hold, say which and how you tracked them, in your own words; if delivery was owned elsewhere, say so plainly and stay with the reliability quarter. The 60% raises the defend-the-number slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours |
| F3 | "own delivery, hiring and growth for 11 engineers" (the hiring part) — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | The quote already reaches hiring in role-relevant terms, so lead with it as written: you run the loop, for backend roles, and the figure is about 40 interviews. The pack's observation: it says interviews, not hires or decisions, so keep that noun. Expect the figure to be probed (how it was counted, what part of the loop is yours, what it is sensitive to) |
| F4 | "own delivery, hiring and growth for 11 engineers" (the growth part) — role description in your message | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the role text makes a probe on growing engineers likely. If you have developed anyone, say who and how, in your own words; if growing people was not yours to do, or has not come up, say so plainly and say how you would approach it |
| F5 | "partner with hardware and product on roadmap" — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. The pack's observation: the sentence is about owning a roadmap, so it is silent on partnering. Answer slot: if you have worked alongside a hardware or product counterpart on what a roadmap held, say how, in your own words; if you haven't, or it wasn't yours, say so plainly and stay with the reliability quarter |

Requirement coverage:

| Requirement | Covered by | Note |
|---|---|---|
| F1 Lead two squads, device-management services | A2, A3, B1, C6, C8 | Device-management domain: A4, B8, C7 |
| F2 Own delivery | A4, A5, A7, B4, B9 | |
| F3 Own hiring | A8, B5, C3 | |
| F4 Own growth | B3, C2 | Round A has no growth question; the Director may still ask, so use B3 and C2 as rehearsal |
| F5 Partner with hardware and product on roadmap | A1, A6, B7, B8, C5, C6 | |

The reverse questions in each round add to this coverage.

---

## Round A: Tuesday, Director of Engineering (hiring manager, 45 min)

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the step-up and the hardware gap | Highest, 3 questions. Hiring manager prior (they are derisking gaps), and your own message names the two gaps | Rehearse the A1 objection until it is boring; state limits in your own quoted words; bridge only from what you said |
| Case/Strategist | Live problems from the squads' actual roadmap | High, 3 questions. Hiring manager prior: expect live problems | Clarify, objective, options, trade-offs, communication; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Reads your two figures and asks how they were counted | Medium, 2 questions. Both of your figures (60%, about 40) are headline numbers | Know what you can and cannot say about how each was counted; say so plainly where you do not know |
| Conversational | The "walk me through the journey" opener | Low, 1 question. Still scored | A 90-second arc built only from your own sentence |

### Question bank A

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." / "I run our hiring loop for backend roles — about 40 interviews last year." / "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The highest-ROI prep in this pack. Name it before they do, in your own quoted words: "I've never owned a hardware-adjacent roadmap." Then stop; do not widen or soften it. Hold what your quotes carry: you run the hiring loop for backend roles, and you pushed a reliability quarter through against roadmap pressure. Say them as facts and let the Director draw the inference. Follow-up 1, what have you done about it: answer slot, if you have worked alongside a hardware or product counterpart on what a roadmap held, say how, in your own words; if you haven't, or it wasn't yours, say so plainly and stay with the two quotes. Follow-up 2, why take the risk: hold the same two quotes, repeat the concession in the same words, say what you would want to learn first as a plan and never as a past, then stop. The honest branch is a limit, not a confession | F5 is the role's one stated partnership with hardware and the place your material is thinnest, so this objection arrives in some form in every round; JD because it scores the stated requirement, asked by the Skeptic persona |
| A2 | "You've been a team lead of 6. This role is two squads and 11 engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Start from your own words: "3 as a team lead of 6." Say the number as it is. Answer slot: say what you think changes at that size, in your own words, as a view and not a past; if you haven't thought it through, say so plainly and say what you would ask the Director first. Do not describe a two-squad or eleven-person experience | F1 is the step-up the role text itself sizes, and the Director will test it; JD because it scores a stated requirement |
| A3 | "What's drawing you from a payments company to industrial IoT?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Give your actual reason, in your own words; the pack does not have it. Answer slot: if the pull is something in the role's content, say which part; if it is something else, say that plainly. Keep it identical to what you will say to the panel and the VP; they compare notes | F1 supplies the move; the reason is only yours. EXP because it tests consistency of your own story |
| A4 | "A hardware team slips a release your next quarter depends on, and product wants the date held. Walk me through what you do." | CASE | [generic] | Clarify before structuring: what slipped and by how much, how firm the date is, what else the squads have committed. Then the objective, the options for date and for scope, who you bring in and what you tell each, and what gets written down. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The role text pairs delivery with partnering with hardware and product (F2, F5); this is that seam as a live problem. `[generic]`: a pattern for the problem, not a fact about Larkfield |
| A5 | "On-call load is climbing on one of your two squads while both have committed dates. What gives?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Same structure: clarify (how bad, which squad, what is committed), objective, options, the trade-off you would make and say aloud, how you would communicate it. If you bring in your own reliability quarter, it carries only your sentence: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if asked what the pressure was or who applied it, say what it was, in your own words; if you can't say, say so plainly | F2 is your nearest evidence for delivery trade-offs, and this is the problem it invites. CASE because the structure is scored; the story is optional |
| A6 | "Tell me what you'd want to learn in your first 30 days about how hardware and software plan together here." | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Ask before answering: how dates are planned across hardware and software today, who owns each dependency, what the squads can see of the hardware roadmap. Then say it as a plan. If the limit comes up, your words are: "I've never owned a hardware-adjacent roadmap." Nothing about having done it | F5 is the thin row; this question turns the gap into a clarify-first answer the Director can score. CASE because clarifying is the score |
| A7 | "Your on-call burden dropped 60%. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Say it at its own scope: it dropped 60% after you pushed the quarter through. Answer slots, all in your own words: how the 60% was counted; what it is most sensitive to; the assumption behind it you would defend least; which part of the drop was yours. If you don't know how it was counted, say so plainly. Don't say the quarter caused it unless you can back that on a second question | F2 holds your only headline figure besides the interview count; probers go straight to it. EXP because it tests attribution |
| A8 | "You said about 40 interviews last year. How was that counted, and which part of the loop is yours?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say it at its scope: you run the hiring loop for backend roles; the figure is about 40 interviews. Answer slots, in your own words: how the 40 was counted; what part of the loop you run; what the figure is sensitive to. If part of the loop was set by others, or you don't know how it was counted, say so plainly. Keep interviews as interviews | F3 is your strongest-fitting row, and so its figure gets the defend-the-number treatment. EXP because it tests what was actually yours |
| A9 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Three beats from your sentence, in order: nine years in engineering, three of them as a team lead of 6, currently at a payments company. Answer slot: the moves between those, and what draws you here, are yours; the pack has neither. Cut it to about 90 seconds | The rapport opener is still scored (F1). EXP because it checks the story hangs together |

### Reverse questions: Round A

| # | Question | Why it lands |
|---|---|---|
| RA1 | "What would make the first six months a success in your eyes?" | Asks your would-be boss for the scoring sheet and shows you are thinking about delivery (F2) |
| RA2 | "How is the roadmap split today between work that depends on hardware and work that doesn't, across the two squads?" | Opens F5, the thinnest row, as curiosity, and gives you facts to answer A6 with |
| RA3 | "Where are the two squads on delivery and on-call right now, and what's your read on why?" | Invites the same conversation your reliability quarter was about (F2) without claiming a parallel |
| RA4 | "How have hiring and growth plans been set for the 11 so far, and what's open?" | Covers F3 and F4 and shows you expect to own them |
| RA5 | "What would you want from me in the first month that you aren't getting from the team today?" | A reciprocity question for a first-line boss: it signals you are asking what is needed, not what you are owed |

---

## Round B: the Thursday panel (two staff engineers and a product manager, 60 min)

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between an EM and staff engineers, credit, "what would you need from us" | Highest, 3 questions. A panel blends each member's top two; staff engineers you would work beside lean peer, and the PM is cross-functional | Reciprocity: what you bring them as well as what you need; propose seam principles, not a made-up seam |
| Data-Driven Prober | The staff engineers reading your claims closely | Medium, 2 questions. Technical-specialist prior | Say what you can and cannot say about how each claim was counted |
| Values/Behavioral | The PM asking behavior-based questions about working with product | Medium, 2 questions. Cross-functional prior; the role text raises partnering with product | Map the story only to what your sentence carries; choose a story where the hard truth landed, or say none comes to mind |
| Case/Strategist | A live problem from device management | Low, 1 question | Clarify first; say where you want their view |
| Pressure | One of the staff engineers probing attribution | Low, 1 question | Hold, then concede specifically |

The names and exact relationship of the staff engineers to the squads are unknown; the weights are a blend until you tell me.

### Question bank B

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between an engineering manager and a staff engineer, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam here: who decides what, what gets escalated, how a disagreement gets settled. Ask them where it sits today. Reciprocity: what you bring them, not only what you need. The question needs no claim about your past, so the guidance makes none | The panel will be pricing what you add to their work; JD because it scores how the stated job meets theirs. `[generic]` because it is a pattern |
| B2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick a time work spanned two teams and credit had to be shared: a named piece of work, what you said, how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. No sentence of yours carries this story | A staple Peer Evaluator probe. VAL because it scores collaboration behavior; scaffold only because nothing you wrote carries it |
| B3 | "How would you help a staff engineer who wants a bigger scope?" | JD | [grounded] | Say how you would approach it, in your own words, as an approach. Answer slot: the role text puts growth in your remit (F4). If you have developed anyone, say who and how; if you haven't, or it wasn't yours to do, say so plainly and stay with how you would go about it | F4 is your one row with no evidence given, and staff engineers are where a growth probe feels real. JD because it scores a stated responsibility |
| B4 | "You pushed a reliability quarter through against roadmap pressure. What was the pressure, and which part of the decision was yours?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Start from your sentence: "I pushed a reliability quarter through against roadmap pressure." Answer slots, in your own words: what the pressure was; which part of the decision was yours. If it was shared or someone else's, say so plainly and return to the sentence. If you cannot say what the pressure was, say so | F2 is your only delivery evidence, so staff engineers will pull on it; EXP because it tests attribution |
| B5 | "You run the hiring loop for backend roles. How would you assess a backend candidate for these squads?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say it at its scope: you run the hiring loop for backend roles. Answer slot: how you assess a candidate is yours to say; if the criteria were set by others, say so plainly and say how you would set them for these squads. Nothing about device-management hires that you have not made | F3 is your strongest-fitting row, and staff engineers will want to know who they will work with. JD because it scores the stated hiring responsibility |
| B6 | "Tell me about a time you and a product counterpart wanted different things from a roadmap." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The nearest story you wrote is the reliability quarter: you pushed it through against roadmap pressure. Answer slot: if the pressure came from a product counterpart, say who wanted what and what you did, in your own words; if it came from elsewhere, say so plainly and tell it as it was. If another story fits better, use it and say what it was | The role text raises partnering with product (F5), and your sentence is the only adjacent one. VAL because it scores working-with behavior |
| B7 | "What do you want from a product partner, and what do you offer them?" | JD | [grounded] | Say it as a view in your own words, with both halves, what you need and what you give. No past claim is needed; if you have worked with a product counterpart on a roadmap, say how, and if you haven't, say so plainly | F5 asks you to partner with product, and the PM is the person scoring it. JD; reciprocity framing |
| B8 | "A firmware update fails on a subset of devices in the field. Who do you pull in, and what do you want to know in the first hour?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Ask before answering: how many devices and which, whether it can be rolled back, who owns the device side. Structure the response. Where it reaches past what you have done, your plain words are: "I've never owned a hardware-adjacent roadmap." Then say whose view you would want | A staff-engineer problem from the role's own domain (device-management services). CASE because clarifying is the score |
| B9 | "That reliability result. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pause and restate. Hold what the sentence carries: you pushed the reliability quarter through against roadmap pressure. Concede specifically, in your own words: answer slot, if others on the team did parts, say which; if you don't know how the drop divides between the quarter and anything else, say so plainly. Hold through two follow-ups rather than widening the claim | F2 is the claim a Pressure persona would press on attribution. EXP because it scores precise attribution; hold-then-concede is the type's bar |

### Reverse questions: Round B

| # | Question | Why it lands |
|---|---|---|
| RB1 | "If you could change one thing about how the squads work today, what would it be?" | Shows you listen before acting; staff engineers answer it with their real concerns |
| RB2 | "How do staff engineers and the EM split calls on technical direction versus delivery today?" | Gets the seam from B1 stated in their words |
| RB3 | To the product manager: "When hardware dates move, how do you and engineering settle what slips?" | Opens F5 and shows you are asking before assuming |
| RB4 | "What could a new EM do in the first month that would genuinely help you?" | The reciprocity question: the panel is likely to be working beside you |
| RB5 | To the product manager: "What does a good reliability or tech-debt quarter look like from the product side?" | Ties to F2 and tests whether the roadmap pressure you described is typical here |

---

## Round C: the following Monday, VP Engineering (values and leadership philosophy, 30 min)

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes on leadership, hiring, growth | Highest, 4 questions. The recruiter's own words: "values and leadership philosophy" | Map a story only where your sentence carries one; otherwise a selection scaffold ending in the honest branch; "we" for context, "I" for your contribution |
| Pressure | Time-boxed, devil's-advocate probes at skip-level | Medium, 2 questions. Skip-level prior | Pause, restate, hold twice, concede specifically |
| Case/Strategist | Altitude questions: the org, the market | Medium, 2 questions. Skip-level prior; 30 minutes keeps this short | Clarify first; use the company's vocabulary only from what you have read |

Larkfield's published values were not available to me (see Sources), so no values cheat sheet is included and VAL questions are themed on the recruiter's description and standard behavioral stems. If you read Larkfield's values page, name the values and I will map them.

### Question bank C

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | Pick a time with a named stake, a moment you didn't fold, and a relationship that was intact at the end. Your nearest sentence is the reliability quarter, pushed through against roadmap pressure. Answer slot: if the pressure came from leadership and you told them something they didn't want to hear, say what and how it landed; if it did not, say so plainly and choose another time, or say none comes to mind and describe how you would handle it | The recruiter's "values and leadership philosophy" makes this stem likely (F2 is the nearest evidence). VAL because it scores behavior under leadership pressure |
| C2 | "What's your philosophy on growing engineers?" | VAL | [grounded] | Say your actual view, in your own words. Answer slot: the role text puts growth in your remit (F4); if you have grown anyone, say who and how; if you haven't, or it wasn't yours, say so plainly and say how you would start. A philosophy with no example reads as an answer to a different question | F4 has no evidence given; a leadership-philosophy round is where a growth question lands. VAL because it scores leadership behavior |
| C3 | "When has a hiring decision been hard for you?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." | Say it at its scope: you run the hiring loop for backend roles. Answer slot: if a specific decision was hard, say what it was and what you did; if none stands out, or the decision was someone else's, say so plainly and say how you hold your own bar | F3 is the strongest row, and a VP checks the judgment behind the volume. VAL because it scores judgment, not process |
| C4 | "What does good engineering leadership look like to you, and where are you still learning it?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." | Give your view in your own words. For "where are you still learning", use the plain words you have: "I've never managed managers" and "I've never owned a hardware-adjacent roadmap." Pick whichever is true for what you are being asked and stop there. No story of having managed managers | The open leadership-philosophy slot; F5 and the managers sentence are your stated limits. VAL because it scores self-assessment |
| C5 | "You've never owned a hardware-adjacent roadmap. Sixty seconds: why you?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." / "I run our hiring loop for backend roles — about 40 interviews last year." / "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." | The Pressure version of A1. Pause, restate the question, concede first in the same words: "I've never owned a hardware-adjacent roadmap." Hold the two quotes: you run the hiring loop for backend roles; you pushed a reliability quarter through against roadmap pressure. Follow-up "that's not hardware": agree plainly. Follow-up "so why is this a bet worth making": answer slot, give your own reason; if it is only those two quotes, say that and stay there. Don't offer them as proof | F5 is the objection aimed at this role's partnership line; JD because it scores the stated requirement under pressure. Hold-then-concede is the type's bar |
| C6 | "Two squads, 11 engineers, with hardware and product both pulling on the roadmap. What do you want your first 90 days to produce?" | CASE | [generic] | Clarify before structuring: what the squads have committed, where hardware and product disagree, what the VP expects first. Then objective, what you would learn, what you would change and what you would leave alone, how you would check in with the Director and the VP. State it as a plan. The question needs no claim about your past, so the guidance makes none | The role text sizes the job (F1) and names the pull from both sides (F5); a skip-level asks about altitude. CASE because structure is the score |
| C7 | "What do you know about where industrial IoT device management is heading, and where does Larkfield sit?" | CO | [generic] | No research reached Larkfield for this pack, so don't recite from memory. Answer slot: if you have read Larkfield's materials, say what you took from them in your own words; if you haven't, say so plainly and ask the VP what they see as the next two years. A plain question beats a recycled market claim | Skip-levels use strategy fluency as a separator. `[generic]` because research was unavailable; this row is the one most improved by adding research |
| C8 | "Why you over someone who has already led two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." | Pause. Hold only your sentence: "3 as a team lead of 6." Concede the comparison plainly: your material says a team of 6, not two squads. Answer slot: give your own reason in your own words; if it is only what the quote carries, say so and stay there. Hold through two follow-ups; don't claim two-squad experience | F1 is the scale step. JD because it scores fit to the stated job, in the Pressure register |

### Reverse questions: Round C

| # | Question | Why it lands |
|---|---|---|
| RC1 | "What does engineering leadership here need to look like in two years that it doesn't today?" | A VP-altitude question that shows you are thinking about the org, not only the role |
| RC2 | "What would you want to be different in how engineering and hardware plan together?" | Opens F5 at the level where it is decided |
| RC3 | "How do you decide when an engineering manager is ready for more, such as more squads or managers?" | Asks about the growth path without apologising for the managers sentence in F5 |
| RC4 | "What has the best engineering manager you've worked with done that most don't?" | Invites the leadership philosophy the round is about, in the VP's words |
| RC5 | "How does disagreement between engineering and the business usually get settled here?" | A values question that gets you a real answer to rehearse against C1 |

---

## Prohibited claims

What this pack will not coach, and why. Built from the fit snapshot before the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot on owning |
| Managed managers | Negative you stated, F5 | The plain acknowledgment: "I've never managed managers." No slot |
| Led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation: the material says a team of 6 |
| Cut on-call burden by 60% through the reliability quarter | Inflated form of F2; the quote says the burden dropped after | F2's quote at its own scope. Slots stay on how the figure was counted and which part was yours |
| Set or owned the roadmap decision | Inflated form of F2; the quote says "pushed", not owned | "I pushed a reliability quarter through against roadmap pressure." B4's slot stays inside that sentence |
| Hired about 40 engineers, or made the hiring decisions | Inflated form of F3; the quote says interviews | "I run our hiring loop for backend roles — about 40 interviews last year." |

## Sources

Provided documents: your message (the role description, the three rounds and their descriptions, and your background). No dossier was provided.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Every search was sent and refused by the host's permission step; nothing came back and nothing from them is used.

| Query | Result |
|---|---|
| `Larkfield Systems industrial IoT company values` | refused |
| `Larkfield Systems interview process engineering manager` | refused |
| `Larkfield Systems industrial IoT device management strategy news` | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have fed a values cheat sheet for Round C, with Larkfield's value names; its absence is why the pack has none |
| 2. `{company} interview process {role family}` | unavailable | Would have checked the loop; your own message already establishes it, so the pack's persona weights rest on that |
| 3. `{company} strategy` / recent news | unavailable | Would have grounded C7 and RC1 in Larkfield's current priorities; both are `[generic]` |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given, so there was no query to form; there is no interviewer read |
| 5. representative `{role title}` JD | skipped | The role description you supplied fixes the five fit rows and the JD-tagged questions |

## Upgrade menu

- Search access, then the refused targets run (values, loop, strategy) and, once, a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) → a values cheat sheet for Round C, Larkfield-specific CO and CASE questions, and C7 and RC1 move from `[generic]` to grounded
- The full job description → F1 to F5 requirements become fuller and quoted, and any requirement beyond the role summary gets a JD-tagged question
- Your CV → evidence cells beyond your message, especially F4 (growth) and F1 (two squads, device work), where evidence may exist that your message does not show
- An artifact behind the 60%, such as an on-call or paging report, and behind the interview count, such as a hiring-system export → F2 and F3 confidence can move from medium toward high
- Your answers to the answer slots in rows F1 to F5, said outside a drill → those rows are regenerated from your own words
- Interviewer names, and whether the two staff engineers sit inside the squads you would lead → a real interviewer read, per-member persona weights for Round B, and a reverse question tied to someone's path
- The recruiter's focus areas for Round B and any named values for Round C → coverage of any focus area or pre-declared deliverable, and a values cheat sheet if values are named
- A `tuesday-dossier.md` from an earlier underwriting pass → verified evidence and constraints, so the highest-ROI objection is taken from it instead of inferred
