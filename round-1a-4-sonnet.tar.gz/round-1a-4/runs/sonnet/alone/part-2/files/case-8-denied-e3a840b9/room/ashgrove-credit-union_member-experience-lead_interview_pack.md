# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop on 3 December 2026, three rounds, prepared as a loop with per-round mini-packs.

| Round | Who | Length | What it is |
|---|---|---|---|
| 1 | The recruiter | 30 min | Screen |
| 2 | Head of Member Services, your future manager | 45 min | Mostly behavioural |
| 3 | Panel of two branch managers | 60 min | Includes a 20-minute complaint-escalation case; also the values round, scored against the four values |

The interviewers' names are not yet assigned, so there is no interviewer read in this pack.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored.

| Type | What it is really testing |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your own account of your work survives follow-up questions |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you have done your homework on the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding for what you say aloud, not a script. Every claim about your past rests on a sentence you wrote, quoted next to it. Where the pack cannot know something, it gives an answer slot: say the true thing in your own words, or say plainly that it was not yours or did not exist. Both are honest answers.

## Prep triage

You have nine days (24 November to 3 December). Do these in order. Everything else is insurance.

| Order | Do this | Tied to |
|---|---|---|
| 1 | Decide your own answers on pay, notice, location and reason for looking. Only you can; the pack supplies none | A2, A4, A5, A6 |
| 2 | Say the B4 hold and concession aloud until it is boring; have someone play the three follow-ups | B4 (highest-ROI prep) |
| 3 | Choose a real story for each of the four values, or settle on the honest branch | C3 to C6, values cheat sheet |
| 4 | Do the 20-minute case aloud, timed, structure named first. This is also your presenting practice | E1, B7 |
| 5 | Work out what your spreadsheet counted, in your own words | D1, D2 |
| 6 | Pick two reverse questions per round | Reverse questions in each round |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the log's stages likely. If any stage was yours to set, say which and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your material says what you built and who uses it, not what it counted. Answer slot: the JD's monthly-reporting line makes a probe on what the spreadsheet counted likely. Say what it counted, in your own words; if you do not know how something in it was counted, say so plainly and stay with the spreadsheet you built |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | low | [inferred] | discovery | Your material says a spreadsheet, not which tool. Answer slot: if it was built in Excel, say so and say what you built in it; if it was another tool, say so plainly and say what the tool was |
| F5 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | The words stay at their scope: "I trained new tellers on our escalation script." The material says tellers and a script, not supervisors. Answer slot: the JD's coaching line makes a probe on supervisor-level coaching likely. If you have coached anyone at that level, say who and what, in your own words; if not, say so plainly and stay with training tellers on the script |
| F6 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have worked with a digital team, say what the work was and which part was yours; if you have not, say so plainly, then say how you would start, as a plan |
| F7 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on its face, but a CV-style line with nothing inspected behind it, so expect a probe on what those years covered. Lead with the line in its own terms: six years in retail banking, the last three as a branch supervisor |
| F8 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your material says formal, and does not say what governed the log. Answer slot: the JD's complaints-experience line makes a probe on what made the log formal likely. Say what made it formal in your branch, in your own words; if you do not know, or it was the bank's process and not yours to set, say so plainly and stay with the log you handled |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan and never as a past |

## Grounding brief

From the 2026 strategy brief the recruiter sent, as you summarised it in your message (the brief itself was not in front of me; it is dated July 2026, about four months old).

| Item | What the brief says | Provenance | Where it may surface (the pack's reading) |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] | The JD's self-service line sits here: B6, E3 |
| Branch network | "consolidate eight branches into five hubs over 2027" | [grounded] | Two branch managers sit on the panel; whether their branches are affected is not known. It meets the value Neighbours, Not Numbers: C5, E2 |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] | Your material and the brief do not say how complaints about it will be handled; a fair reverse question in round 2 |
| Competition | "the main competitive pressure is app-only banks" | [grounded] | Gives "why Ashgrove" a current frame: A3, E3 |

Sound current, not archival. Cite the brief as the brief; do not claim to know how the credit union runs beyond it.

## Persona table

Weights per round, with the reasoning shown. Recalibrate if you know something I do not.

| Persona | Round 1 | Round 2 | Round 3 | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| Conversational | high | low | low | A recruiter screen's prior is conversational with a light Skeptic; casual questions are still scored | A 90-second arc for the biography; treat the logistics questions as scored |
| Skeptic | medium | high | low | A hiring manager is derisking gaps, and F2 and F9 are stated gaps; your recruiter called round 2 mostly behavioural, so the Skeptic shares the round with behavioural questions | Rehearse the single most likely objection (B4) until it is boring; hold what the quotes carry, concede the rest specifically |
| Values / Behavioral | low | medium | high | The recruiter said the panel is the values round and scores against the four values; round 2 is mostly behavioural | A story per published value where your material carries one, otherwise the honest branch; "we" for context, "I" for what you did |
| Data-Driven Prober | none | medium | low | Round 2 is behavioural, but the spreadsheet is the one artifact you built | Know what you can and cannot say about how it counted; say plainly when you do not know |
| Case / Strategist | none | low | high | The panel includes a 20-minute complaint-escalation case | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Peer Evaluator | none | none | medium | The panel is two branch managers who will work beside this role | Reciprocity framing; propose seam principles rather than claiming to know their seam |
| Pressure | none | none | low | Possible in a panel, but nothing in the recruiter's note signals it | Pause, restate, hold through two follow-ups |

---

## Round 1: the recruiter (30 minutes)

Weights: Conversational 6 questions, Skeptic 3 questions.

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc in the order the quotes give: six years in retail banking, the last three as a branch supervisor; handling the branch's formal complaints log; building the monthly complaints spreadsheet your regional manager uses. Close on why this role, in your own words; the pack does not supply your reason. Stop at 90 seconds | The conversational persona's usual opener; F7, F1 and F3 are the rows it touches. EXP because it tests whether the story is told at the scope the evidence carries |
| A2 | "What's prompting you to look at a move now?" | EXP | [generic] | A logistics slot: give your actual reason, in your own words, in one true sentence, then stop. The pack supplies no reason and nothing here tests it | The recruiter row of the persona priors names the reason for leaving as a standing check; EXP because it tests consistency of motive. It draws on no fit row |
| A3 | "Why Ashgrove?" | CO | [grounded] | Pick one of the four published values, by name (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix), and say in your own words why it matters to you. If you want a current frame, cite the brief as the brief: "move 40% of member service to digital channels by 2028" or "the main competitive pressure is app-only banks". Do not claim to know more about how Ashgrove runs than you have read | The recruiter sent you the brief, so reading it is expected; CO because it scores homework, not experience |
| A4 | "What salary are you looking for?" | JD | [generic] | A logistics slot: give your own figure, or ask what the role's band is before giving one. The JD you supplied states no pay. If asked what you earn now, you may decline politely and return to the role. The pack gives no figure | The recruiter row of the persona priors lists pay as a standing check; JD because it concerns the listed job. No fit row bears on it |
| A5 | "What's your notice period?" | JD | [generic] | A logistics slot: give your actual notice period in your own words. If you are not sure, say you will confirm it rather than guess | Same logistics block as A4; JD because it is a term of the listed job |
| A6 | "Where are you based, and does moving between sites work for you?" | JD | [generic] | A logistics slot: say where you can work and how often, in your own terms. The JD does not say where the role sits or how much it moves between branches and the contact centre, which is why the first reverse question below asks | The JD's "across branches and the contact centre" makes site movement a plausible logistics question; JD because it is a term of the listed job |

### Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" | Name a real gap, not a disguised strength. The plain acknowledgment: "I haven't worked in a contact centre." Then a plan, not a past: what you would want to see first when you got there, in your own words. This is the light version of B4 | F2 is the stated gap and the likeliest opening probe; JD because it scores the listed responsibilities |
| B2 | "This role presents to senior leaders. How do you feel about that?" | JD | [grounded] "I've never presented to anyone above regional level" | The plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare, as a plan, in your own words. The panel's 20-minute case is a live chance to show it | F9 is the second stated gap; JD because the JD lists the requirement |
| B3 | "What experience do you have with regulated complaints?" | JD | [grounded] "I handled the branch's formal complaints log" | Say what the quote carries: "I handled the branch's formal complaints log." Answer slot: the JD's complaints-experience line makes a probe on what made the log formal likely. Say what made it formal in your branch, in your own words; if you do not know, or it was the bank's process and not yours, say so plainly and stay with the log you handled. Name no rule, regulator or deadline unless you can say how it applied | F8 is the JD requirement with the thinnest evidence; JD because it scores a stated qualification |

### Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "Where is the role based, and how much does it move between branches and the contact centre?" | Resolves the location and movement terms the JD leaves open, and shows you read "across branches and the contact centre" as a working pattern |
| R1-2 | "For the 20-minute case on the panel: will I get any material beforehand, and do I present or talk it through?" | Un-researchable and it changes how you rehearse E1 and B7; recruiters can usually answer it |
| R1-3 | "When will I know who the two branch managers are and which branches they run?" | Lets you tune the panel prep to real people, and the answer feeds the upgrade menu |
| R1-4 | "How does the panel score the four values: one conversation, or a sheet per value?" | Shows you take the values round as scored, which the recruiter said it is |
| R1-5 | "What happens after the panel, and on what timeline?" | Closes the process cleanly and keeps you from guessing |

---

## Round 2: the Head of Member Services, your future manager (45 minutes)

Weights: Skeptic 4 questions, Values / Behavioral 2, Data-Driven Prober 2.

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "This role owns complaints across every branch and the contact centre. Where does your experience stop and this role start?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre"; "trained new tellers on our escalation script" | Highest-ROI prep in this pack. Open with the hold and name the limit before it is asked: "I handled the branch's formal complaints log. I haven't worked in a contact centre." Follow-up 1, "So how do you own it end to end?": answer slot, if any stage beyond the log was yours to set, say which and how you decided; if there was no such step, or it was not yours, say so plainly and return to the log. Follow-up 2, "Then why you?": return to what the quotes carry, the log and "trained new tellers on our escalation script"; concede only the contact centre, specifically, and give a plan for learning it. Follow-up 3, "What if the contact centre does it completely differently?": a method, not a past: you would want to see how a complaint travels before changing how it travels, and a complaint should have one named holder while you learn. Never fold on the log; never stretch it | F1 and F2 are the pack's biggest gap and the objection most likely to arrive in some form. JD because it scores the headline responsibility; deepest rehearsal here, with three follow-ups, an exact concession and the limit named first |
| B5 | "You've been a branch supervisor. This role coaches supervisors on escalations. What changes?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "trained new tellers on our escalation script" | The two sentences at their own scope: for the last three years a branch supervisor; trained new tellers on your escalation script. Answer slot: the JD's coaching line makes a probe on supervisor-level coaching likely. If you have coached anyone at that level, say who and what, in your own words; if not, say so plainly and stay with training tellers. Then how you would approach it as a plan | F5 is a transferability row: adjacent work with a stated limit. JD because the coaching line is a listed duty |
| B6 | "How have you worked with digital teams on self-service?" | JD | [grounded] | Answer slot: the JD names this duty and your material does not show it either way. If you have worked with a digital team, say what the work was and which part was yours; if you have not, say so plainly. Then a plan: the brief says "move 40% of member service to digital channels by 2028", so say how you would start, for example by looking at why members complain, as intent and not as something you did | F6 is silent in the material. JD because it is a listed duty; the brief supplies the current context |
| B7 | "Each month you'd show complaint results to senior leaders. What would you show, and how would you open?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Start with the plain acknowledgment: "I've never presented to anyone above regional level." Then structure, as a plan: say the answer first, then what you want leaders to decide, in plain words. The JD names complaint volumes and resolution times as the monthly content. Answer slot: say what the spreadsheet you built counted, in your own words; if you do not know how something in it was counted, say so plainly. Practise this one aloud | F9 and F3 meet here. JD because both the presenting and the monthly reporting are listed duties |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, a moment you did not soften it, and a relationship still intact at the end; prefer a time the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Round 2 is mostly behavioural and this is the persona's standard stem; no fit row carries it, so it is a scaffold. VAL because it scores behaviour against the Own the Fix and Members First values |
| C2 | "Tell me about a time you coached someone through a difficult escalation." | EXP | [grounded] "trained new tellers on our escalation script" | Story map on the one sentence: you trained new tellers on your escalation script. Answer slot: the JD's coaching line makes a probe on a live escalation likely. If you ever coached someone through one, say who, what happened and what part was yours; if the training was the script only, say so plainly and describe the training you gave | F5; EXP because it tests what you actually did, not the title |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | The sentence at its scope: you built it; your regional manager uses it. Four slots, each in your own words: what it counted and how an item got in, what it is most sensitive to, the assumption you would defend least, and which part was yours. If you do not know how something was counted, say so plainly. Never supply a figure you cannot repeat | F3; EXP because it is the one artifact you built and the likeliest to be probed |
| D2 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: your material says a spreadsheet, not the tool. If it was Excel, say so and say what you built in it, in your own words; if it was another tool, say so plainly. If you can bring a copy with all member data removed, that is the inspectable proof; do not bring real member records | F4; JD because "Excel reporting" is a listed requirement |

### Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What do leaders see about complaints today, and what would you most want to change in that picture?" | Frames your first month around the monthly reporting duty and shows you think about the reader |
| R2-2 | "Where does the process between branches and the contact centre work least well today?" | Own the Fix in practice: the owner of the process finds where a complaint changes hands |
| R2-3 | "As eight branches become five hubs over 2027, what will this role own in that change?" | Ties to the brief and to the panel's world; answers whether the role touches the transition |
| R2-4 | "Which self-service journeys come first, and how will complaint reasons feed that choice?" | Connects the JD's digital line to the 40% target without claiming experience you have not stated |
| R2-5 | "What support do supervisors get on escalations now, and what should change?" | Shows you see coaching as a gap to close, and tells you what you would inherit |

---

## Round 3: the panel of two branch managers (60 minutes, with a 20-minute case; also the values round)

Weights: Values / Behavioral 4 questions, Case 3, Peer Evaluator 2, Pressure 1.

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C3 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold, with the log as the place to look: pick a time what suited the member and what was easiest for the branch pointed different ways. It needs a named decision, what it cost, and what the member got. Do not state an outcome the log did not give you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always, from the values page. F1 is the nearest sentence, and it carries no decision, so this is a scaffold. VAL because it scores a published value |
| C4 | "Tell me about a time something you said or wrote had to be explained to a member twice." | VAL | [grounded] "trained new tellers on our escalation script" | The nearest sentence is: you trained new tellers on your escalation script. Answer slot: Plain Words is on the values page. If any wording in that script ever changed because members needed it explained twice, say what changed and what part was yours; if not, or it was not yours, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Plain Words, from the values page. F5 is the nearest sentence. VAL because it scores a published value |
| C5 | "Every branch is part of its town. Tell me about a time you weighed what was right for one branch's community against what was efficient." | VAL | [grounded] | Selection scaffold: pick a time a local need and a standard way of working pulled apart. It needs a named stake, what you chose, and what happened to the people affected. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Keep the story about members, not about whether consolidation is right; whether either panelist's branch is affected is not known | Neighbours, Not Numbers, from the values page; the brief's eight-into-five hubs makes it live for branch managers. No fit row carries a story, so it is a scaffold |
| C6 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story map on the one sentence: you handled the branch's formal complaints log. Answer slot: Own the Fix is on the values page. If you kept hold of one particular complaint until it was solved, say what kind it was and what part was yours, in your own words; if the log was where complaints were recorded and someone else solved them, or you cannot name one, say so plainly | Own the Fix, from the values page; F1 is the nearest sentence. VAL because it scores a published value |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A member complained at a branch and was told it was dealt with. They've now rung the contact centre, upset, saying nobody came back to them. The branch supervisor says the record is closed. Walk us through it." | CASE | [generic] | Say the structure aloud first. Clarify: what was complained about and when, what the member was told and by whom, what the record shows, and who holds it right now; ask whether it counts as a formal complaint and what time limits apply, and say you would check the rule rather than quote one. Objective: the member is heard today and the complaint has one holder until it is solved. Approach: contact the member in plain words and say who has it; talk to the supervisor to coach, not blame; ask why the branch record and the contact-centre view disagreed. Metrics: complaints reopened, time to resolve. Risks: the member's frustration, and what the process hides. Challenge one premise politely: does "closed" mean the member's problem is solved, or only the record? Pace it for 20 minutes | The panel's stated 20-minute escalation case; CASE because it is a live problem. It presupposes nothing about your past, and its pattern is generic rather than this employer's exercise |
| E2 | "Over 2027 eight branches become five hubs. A town loses its branch and complaints from that town rise. What does the complaints process do?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" | Clarify: what the complaints are about (access, service, the closure itself) and who is making them. Segment members by how they reach Ashgrove: branch, phone, app. Approach: one named holder for that town's complaints, plain-words replies, a view of the volumes and resolution times by town. Risk: filing a complaint about the closure as a service failure, or the reverse. Challenge one premise: does a rise mean the process is failing, or that members are being heard? Use the value's words, Neighbours, Not Numbers, once and naturally | Strategy brief, via the grounding brief. CASE because it is a live problem on the actual roadmap; it presupposes nothing about your past |
| E3 | "Forty percent of member service is meant to move to digital by 2028. A member starts a complaint in the app. What should and should not be automated?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" | Clarify what the app does today; you do not know. Objective: the member does not explain it twice (Plain Words). Approach: an automated acknowledgment is fine, but a named person owns the complaint and the member can reach a human easily. Metrics: time to first human reply, reopened complaints. Risk: a form that makes complaining harder than leaving, with app-only banks as the pressure the brief names | The JD's self-service line (F6) meets the brief's digital target. CASE because it is a live problem |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "You'd set the process and we run the branches. Where's the line on who decides a complaint's outcome, and what happens when we disagree?" | JD | [generic] | Propose principles, not a map you cannot know: ask where the line sits today, then say the member's outcome is decided by whoever holds the complaint with the facts, while process rules are the role's. On disagreement: say it plainly, take it to the evidence, and keep the relationship. Do not tell a story you have not lived; if you have one about disagreeing with someone at your level, tell it in your own words | The panel is two branch managers, so the seam question is likely. JD because it tests how the listed duties meet their work |
| F2 | "What would you want from us, and what would we get from you?" | JD | [generic] | Reciprocity: what they would get is the role's mandate, a single owner for the process, a monthly view of complaints, and coaching for supervisors. What you would want: to hear how escalations feel from their side of the counter. State both as intent, not as a record | The peer persona's counter-strategy; JD because it ties to the duties in the listing |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who has run a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "Never worked in a contact centre" | Pause and restate. Hold what the quotes carry: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Concede the one thing, specifically: "I haven't worked in a contact centre." Then what you would learn first, as a plan. Do not claim to be better; say what you bring. If pushed with "that's not an answer", hold again on the same quotes and concede nothing further | F2 returns here in its harshest packaging; JD because it scores the stated requirement. Hold-then-concede is the pressure bar |

### Round 3 values / principles cheat sheet

The recruiter said the panel scores against these four values, as published on ashgrovecu.org/about/values.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold, C3: pick a time what suited the member and what was easiest for the branch pointed different ways, with a named decision, a cost, and what the member got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the writing was wrong | F5: "trained new tellers on our escalation script". Answer slot as in C4: if any wording changed because members needed it explained twice, say what and what part was yours; if not, say so plainly |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold, C5: pick a time a local need and a standard way of working pulled apart, with a named stake and what happened to the people affected. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log". Answer slot as in C6: if you kept hold of a particular complaint until it was solved, say what kind and what part was yours; if not, say so plainly |

### Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What could a new Member Experience Lead do in the first month that would genuinely help your branch?" | The reciprocity question for a peer panel: it asks what you bring them, not only what you need |
| R3-2 | "When a complaint at your branch goes to escalation, what do you wish happened differently?" | Gets their real pain on the table and shows you start from their side |
| R3-3 | "How do your members tell you about a problem today, and what changes when they use the app?" | Connects the digital shift to branch reality and gives you material for E3 |
| R3-4 | "Which of the four values is hardest to hold on an ordinary day in a branch?" | Treats the values as lived, which is what the panel scores |
| R3-5 | "As the network changes over 2027, what do you hope stays local?" | Neighbours, Not Numbers as a question, without assuming whether their own branch is affected |

---

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Own the member complaints process end to end" | B4, B3, C6, E1 |
| "across branches and the contact centre" | B1, B4, E1, G1 |
| "report monthly on complaint volumes and resolution times" | B7, D1 |
| "coach branch supervisors on escalations" | B5, C2, F1 |
| "work with digital teams on self-service journeys" | B6, E3 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | B3 |
| "confident presenting to senior leaders" | B2, B7, E1 |
| "comfortable with Excel reporting" | D1, D2 |
| The four published values | C3, C4, C5, C6 |

## Prohibited claims

What this pack will not coach, and why. Each entry sits on a quote in the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log, not the process. B4's slot stays inside the log |
| Has worked in a contact centre or handled contact-centre complaints | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F9 | The plain acknowledgment F9 gives: "I've never presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F5 | F5's quote at its own scope. B5's and C2's slots stay with tellers and the script |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. D1's slot asks only what the spreadsheet counted |
| Handled regulated complaints | Inflated form of F8 | F8's quote at its own scope. B3's slot asks only what made the log formal |

## Sources

Provided documents: the job description as pasted in your message; the four values as pasted from ashgrovecu.org/about/values on 24 November 2026; the recruiter's email about the three rounds; the 2026 strategy brief as summarised in your message (the brief itself was not read); your background as written in your message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove Credit Union values | skipped | The pasted values page, copied this morning, already fixes the values cheat sheet and the VAL questions |
| 2. Ashgrove interview process, member services roles | skipped | The recruiter's email fixes the loop: three sessions, who runs each and what each holds |
| 3. Ashgrove strategy and recent news | skipped | The strategy brief summary fixes the CO and CASE questions and the grounding brief |
| 4. Interviewer name and Ashgrove | n/a | No interviewer has been assigned, so there is no name to query; the interviewer read is absent |
| 5. Representative Member Experience Lead JD | skipped | The supplied JD fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The interviewers' names, once assigned: an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each of their paths
- The recruiter's answer on the 20-minute case (material beforehand, and whether you present): a rehearsal shaped to the real format, and a graded-deliverable build section if anything is pre-declared
- Your own answers to the slots on F1, F3, F4, F5, F6 and F8: those rows become quoted evidence, and the matching guidance becomes story-mapped instead of a slot
- A copy of your monthly complaints spreadsheet with all member data removed: the inspectable artifact that can lift F3 and F4 from their current confidence
- Your pay, notice, location and reason-for-looking answers: they would be quoted into A2, A4, A5 and A6 as your words
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): role-family loop reports and recent organisation context; say yes and I will run it
- A tuesday-dossier.md from an earlier evidence check, if you have one: verified evidence, a named top objection and a prohibited-claims list, which would sharpen the guidance without being required
