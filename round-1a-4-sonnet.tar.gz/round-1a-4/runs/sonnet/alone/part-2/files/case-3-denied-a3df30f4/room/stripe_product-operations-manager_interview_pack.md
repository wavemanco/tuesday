# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer(s): not given. Relationship: not given, so the weights below are blended. Background (CV or notes): not given, so the fit snapshot is a worksheet.

## How to use this pack

- Personas are how a question is asked; types are what it scores. Guidance is scaffolding for your own words, not a script.
- Every guidance cell that touches your past is a selection scaffold: it tells you what kind of story to pick and ends with the honest branch, saying so plainly when nothing comes to mind. Nothing in this pack states what you did, because nothing about your background has been provided.
- Bank letters skip F so they cannot be confused with fit-snapshot rows F1 to F8.
- Type key:

| Tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually you |
| JD | Role-driven: can you do the listed job, including its gaps |
| CO | Company and strategy knowledge: homework depth, thinking at the company's altitude |
| CASE | A live problem from the role: structure and reasoning on the spot |

## Fit snapshot (worksheet variant)

No CV, notes or job description were provided, so every evidence cell reads `none given`. The requirements are role-family patterns for product operations written without a source, shown as plain prose and labeled `[generic]`; none is a quote from a Stripe posting. The right-hand column says what strong evidence looks like and gives a selection scaffold to run against your own history. No row is a gate row, because nothing provided states a term such as location, schedule or work authorization.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinates cross-functional product launches or releases so several teams ship together (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a launch you can name, the teams involved, and which decisions were yours. Selection scaffold: pick one launch where you were the person holding the plan together; if no such launch comes to mind, say so plainly, then give the nearest coordination work your material does carry, or how you would run one |
| F2 | Runs or improves planning and operating rhythms, such as roadmap reviews, prioritization and status reporting (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a recurring process you can describe end to end and say what changed because of it. Selection scaffold: pick a rhythm you set up or changed, not one you only attended; if none comes to mind, say so plainly, then give the nearest thing or how you would design one |
| F3 | Uses data to define metrics and diagnose the health of a product or process (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a figure you can explain: how it was counted, what it is sensitive to, which assumption you would defend least, and which part was yours. Selection scaffold: pick one number you can defend under a second question; if you do not know how a figure was counted, say so plainly rather than explaining it |
| F4 | Turns customer, field or partner feedback into inputs product teams act on (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a feedback channel or synthesis you handled and something a product team did differently afterwards. Selection scaffold: pick one instance where feedback reached a decision; if none comes to mind, say so plainly, then give the nearest thing or how you would build the loop |
| F5 | Designs and scales processes and tools so teams work with less friction (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a process or tool you introduced, how adoption was earned, and how you knew it helped. Selection scaffold: pick one you introduced rather than inherited; if none comes to mind, say so plainly, then give the nearest thing or how you would approach it |
| F6 | Influences senior stakeholders across product, engineering and go-to-market without direct authority (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a senior person, what was at stake, and the state of the relationship after. Selection scaffold: pick a time you moved or lost an argument without formal authority; if none comes to mind, say so plainly, then give the nearest thing or how you would handle it |
| F7 | Communicates clearly in writing and aloud, including to executives (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a document or briefing you can point to and an audience that acted on it. Selection scaffold: pick one piece of communication where the audience was senior; if none comes to mind, say so plainly, then give the nearest thing |
| F8 | Has a coherent reason for product operations as a career and for this company now (role-family, no source) | none given | none | [generic] | discovery | Strong evidence is a reason you would say the same way to a friend. Selection scaffold: three beats, what pulled you toward the work, why this company, why now; where a beat has no reason of your own, say so plainly and give the one you do have |

## Persona table

Built on one assumption, since your note said only "final round": a blend of a hiring-manager-style session and a peer or cross-functional session. No loop source was read, so the archetype fallback is Generic, which carries flat weights; the depth below tilts only by those two relationship priors. If your final is several back-to-back sessions, the weights could differ per session.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 4 questions) | Quiet probing of gaps and of why this role, why now | High: a hiring-manager prior is Case plus Skeptic, and a final round is where a decision gets derisked | Rehearse the weakest-point answer until it is boring; concede specifically, never bluff |
| Case / Strategist (bank B, 4 questions) | Live problems from the role: diagnose, plan, design | High: same hiring-manager prior, and product operations work is problem-shaped | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Peer Evaluator (bank D, 3 questions) | Seam-splitting between teams, credit, disagreement | Medium: the peer prior, and cross-functional partners are the role's daily counterparts | Reciprocity framing; propose seam principles rather than pretend to know the seam |
| Data-Driven Prober (bank E, 3 questions) | Numbers probed to their assumptions | Medium: the peer prior pairs Peer with Prober | Know how each figure was counted; say plainly when you do not |
| Values / Behavioral (bank C, 2 questions) | Scenario probes mapped to published values | Low to medium: no loop source documents a values round and Stripe's values were not retrieved, so none is detected; the questions use the standard stems | Pick a story per stem where one fits; otherwise the honest branch |
| Conversational (bank G, 2 questions) | Friendly, unstructured, still scored | Low: no recruiter-screen cues in your note, but a casual opener is still scored | A 90-second arc for the biography question |
| Pressure (bank H, 2 questions) | Time-boxed, devil's-advocate challenges | Low: no signal either way; kept short | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

Highest-ROI prep: A1. Without your background the pack cannot name the specific objection you will face, so it names the one probe that comes in some form wherever fit is being checked, and gives it the deepest rehearsal, with three follow-up levels.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Deepest rehearsal. Pick the one requirement where your own material is thinnest (use F1 to F8 as the checklist) and name it plainly. Follow-up 1, "why that one and not another?": restate your reason in one sentence. Follow-up 2, "what if closing it takes longer than you expect?": concede specifically, say who you would ask and what you would do in the first thirty days. Follow-up 3, "does that worry you?": hold your position calmly, neither dismissing the gap nor catastrophizing it. If no weakness comes to mind, say so plainly, then name the area where you would lean on the team first | Every row F1 to F8 is open, so which one is thinnest depends on you; this probe scores honest self-assessment and arrives in some form in fit-checking rounds. JD because it tests the listed job |
| A2 | "Why product operations, and why now?" | EXP | [generic] | Three beats in your own words: what pulled you toward the work, why this company, why now. Each reason must be one you would say the same way to a friend. Where a beat has no reason of your own, say so plainly and give the one you do have. Avoid claiming a passion you cannot back with a specific | F8 is the row it draws on; motivation consistency is what a Skeptic scores. EXP because it tests whether your story holds together |
| A3 | "Product operations sits between product, engineering and the business. Where does the role get ignored or resisted, and what do you do about it?" | JD | [generic] | A structure, not a story: name two or three failure modes, say what you would do about each and which stakeholder you would involve. If you have seen one first hand, one plain sentence on it in your own words; if you have not, say you are reasoning from the role | F5 and F6 are where this role depends on adoption rather than authority; this asks how you would think about that. Asked as a reasoning problem so it needs no claim about your past |
| A4 | "Why should we choose you over someone who has done this exact job elsewhere?" | JD | [generic] | Say what you would bring in terms you can substantiate in the room, then concede what they may have that you do not, specifically. Do not describe an advantage you cannot support with a named example. If you cannot name one, say so plainly and speak to how fast you would learn | A comparative probe aimed at the gap rows F1 to F7; the concession is the scored behavior. JD because it tests fit to the listed job |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A launch involving three teams is slipping and nobody agrees on why. What do you need to know first, and what do you do in your first week?" | CASE | [generic] | Clarify before structuring: what slipping means, how fixed the date is, who decides trade-offs, what each team says. Then objective, the likely causes by team, your first-week actions, the metric you would watch, the risk of your plan. Challenge one premise respectfully, for example whether the date is the real constraint | F1 and F6 as a live problem; tests clarify-then-structure rather than the right answer. Presupposes nothing about your past |
| B2 | "A key weekly metric dropped twenty percent. Diagnose it." | CASE | [generic] | First check the measurement itself (definition, pipeline, data freshness), then segment (product, region, customer type, time), then recent changes, then external factors. Say what data you would pull in what order, and what would make you stop | F3 as a live problem. The twenty-percent drop is the stem, so the guidance is a method, not a finding |
| B3 | "Ten product teams each plan their own way. Design an operating cadence: what do you standardize, and what do you leave alone?" | CASE | [generic] | State the objective first, then your principle for the line between standard and local (for example, standardize what other teams depend on, leave local what only the team feels). Cover rollout, how you would earn adoption, how you would know it worked, and the main risk | F2 and F5 as a live problem; strategy-and-process altitude is what a hiring manager scores in an operations role |
| B4 | "Where would product operations create the most leverage at Stripe right now?" | CO | [generic] | Research on Stripe was not available when this pack was built, so this guidance is generic and no fact about the company appears here. Use your own current reading: name one area you can cite a source for, state a hypothesis for how this role would help, say how you would test it, and say plainly what you do not know. Do not recite a public report's shortlist; bring one consensus item and one reasoned divergence | The CO question the coverage rules ask for, left generic honestly. Becomes grounded if research is added |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship afterwards. "We" for context, "I" for what you did. Name what landed and what did not. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 and F7. The standard values stem; this pack cannot map it to a published Stripe value because none was retrieved |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two pulled apart, say what the metric was and what you gave up, and what the customer outcome was. Name only what you actually weighed. If no such time comes to mind, say so plainly, then give the nearest thing or how you would handle it | F4. Standard values stem; tests whether behavior, not a slogan, shows customer focus |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Offer principles rather than pretend to know the seam: who owns the decision, who is consulted, how a disagreement escalates and how fast. Show spine and tact together, and say what you would want to learn about how this team prefers to work | F6 as a live scenario. No claim about your past is needed or made |
| D2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work spanned teams and credit mattered; say what you did about it in your own words. If no such time comes to mind, say so plainly, then say how you would handle it | F6 and F7. The standard peer stem; scores whether you add to or reduce your peer's load |
| D3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Reciprocity framing: lead with what you could offer (clarity, follow-through, a lighter coordination burden), then two specific asks. Offer only what you could actually deliver in a month | F5 and F6; reciprocity is the Peer counter-strategy. JD because it tests how you would work in the role |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick one number from your past work you would stand behind. Walk me through how it was counted." | EXP | [generic] | Selection scaffold: choose a figure you can explain under a second question. Cover how it was counted, what it is sensitive to, and which part was yours. If you do not know how it was counted, say so plainly rather than explaining it. If no figure comes to mind, say so plainly, then give the nearest thing or how you would measure it | F3. The defend-the-number rehearsal; no figure has been supplied, so none appears here |
| E2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Follow-up to E1. Name the assumption you know of before they do; it converts a gotcha into credibility. If you do not know of one, say so plainly and say how you would find out | F3. The weakest-assumption move |
| E3 | "In your first week you are handed a dashboard two teams disagree about. How do you find out which number to trust?" | CASE | [generic] | Clarify what each team means by the number, trace both to source, reconcile definitions before values, agree one owner for the definition, and say how you would stop the disagreement recurring | F3 and F5 as a live problem; a Prober's delivery on a role-shaped case |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in three beats: where you are now, how you got here in a few steps, why this role. Say only what you can stand behind if asked a follow-up on any step; end on A2's reason. If a step has no clear reason, say so plainly and move on | F8. Casual-register questions are still scored; this one is the likeliest opener |
| G2 | "What is something about how product teams work that you have been thinking about lately?" | JD | [generic] | Pick a topic you have a real view on, say the view, say what would change your mind. If nothing comes to mind, say so plainly, then name the area you most want to learn about in this role | F2 and F5. A casual question about the job's own subject, scored for genuine interest and economy |

### H. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, give one reason and one proof point you can support, stop. Hold through a challenge; concede a specific thing an internal candidate has, without folding on your own case | A time-boxed composure test; no claim about your past is made by the guidance |
| H2 | "Think of the result you are proudest of. How much of it was actually you?" | EXP | [generic] | Hold-then-concede: say plainly what you did, name what others did, and hold that line through two follow-ups. Concede specifically what you do not know about the outcome. If no result comes to mind, say so plainly | F3 and F6. The attribution probe; the preparation is precision about your own part |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 launch coordination | B1 |
| F2 planning and operating rhythms | B3, G2 |
| F3 metrics and diagnosis | B2, E1, E2, E3, H2 |
| F4 feedback into product | C2 |
| F5 process and tooling | A3, B3, D3, E3, G2 |
| F6 senior stakeholders without authority | A3, B1, C1, D1, D2, D3, H2 |
| F7 communication | C1, D2 |
| F8 motivation | A2, G1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a successful first ninety days look like, and how would you tell?" | Shows you think in outcomes and gives you the scoring sheet for the role |
| R2 | "Where does this role sit relative to product, engineering and go-to-market, and where do the handoffs fray?" | Signals you understand adoption without authority, and surfaces the hardest part of the job |
| R3 | "Tell me about a time this team recently changed its mind on something important. What prompted it?" | Invites a story about how decisions really get made, which no job description shows |
| R4 | "How is the work of this role measured, and what would you most like measured that is not?" | Shows metric fluency and hands the interviewer a chance to name a real gap |
| R5 | "What is the hardest trade-off this role will face in its first year?" | Signals you expect trade-offs rather than a clean brief |
| R6 | "What could a new person do in the first month that would genuinely help your team?" Ask this one if the interviewer is a peer | The reciprocity question: it turns a peer evaluation into a collaboration |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your own past that you have not said to this pack | No CV, notes or statements were provided, so no sentence of yours is quoted and no inflated form can be built | Answer slots and selection scaffolds only; supply your background and this section is rebuilt from your wording |
| Any specific fact about Stripe's values, interview loop or strategy | Research was refused in this session, so nothing about Stripe is sourced | Questions B4 and C1 to C2 stay generic; add a source and they ground |

## Sources

Provided documents: your message (company, role, round type). No dossier, JD, CV or interviewer profile.

Searches sent, all refused:

- "Stripe values operating principles": refused
- "Stripe interview process product operations manager": refused
- "Stripe strategy 2026 news": refused
- "Stripe Product Operations Manager job description responsibilities qualifications": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have fed a values cheat sheet and mapped the VAL questions to Stripe's named values; moved nothing |
| 2. Stripe interview process, product operations | unavailable | Would have established the loop and set persona weights from documented rounds; weights rest on the Generic archetype instead |
| 3. Stripe strategy and recent news | unavailable | Would have grounded B4 and added strategy-based CASE questions; B4 is generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative product operations JD | unavailable | Would have turned F1 to F8 into quoted `[inferred]` requirements; they stay `[generic]` prose |

## Upgrade menu

- JD text: F1 to F8 become quoted `[grounded]` requirements, every requirement gets a JD question, and any gate terms (location, schedule, work authorization) are surfaced
- Your CV or a few lines on your background: the worksheet becomes a real fit snapshot with your own sentences quoted, selection scaffolds become story maps, the prohibited list is built from your wording, and A1 can be replaced by your actual highest-ROI objection
- Interviewer names and titles: an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their path
- The round schedule, if your final is several sessions: per-session mini-packs with their own weights
- The recruiter's prep email: stated focus areas and any pre-declared deliverable, which gets its own build section
- Web research on Stripe, permitted or pasted (values page, candidate guide, strategy brief): a values cheat sheet if a values round is documented, B4 and a strategy-grounded CASE question made current, and persona weights from a documented loop; a deeper pass is available too, up to 6 more searches and 2 more fetches, several more minutes
- A tuesday-dossier.md: verified evidence and prohibited claims arrive pre-checked, and the highest-ROI objection comes from evidence rather than being assumed
