# Interview pack: Senior Partnerships Manager, Kelverton Rail

- Round: second round, panel, 60 minutes: a 15-minute POV from you, then Q&A
- Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director), as your recruiter described them
- Built from: your message, which quotes the recruiter's email. No job description, CV or interviewer profile was supplied, and no research ran (see Sources)
- Working assumption: "operator partnerships" means Kelverton's relationships with train operating companies, read from the recruiter's wording

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values. No values-style round is detected for this loop, so no VAL questions appear |
| EXP | Whether your claims survive scrutiny and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and market knowledge, and whether you can think at the company's altitude |
| CASE | A live problem from the real role, scored on structure and reasoning |

IDs run by persona (A, B, C, D, E). Where guidance says "answer slot", it is an instruction for the interview, not a question for you now.

## Prep triage (four hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 90 min | Build and rehearse the POV aloud against a timer. Pick one thesis, write its spine, say it through twice | The graded deliverable section, A1 to A4 |
| 2 | 60 min | Rehearse the objection until it is boring: say the concession first, then hold through two follow-ups | B1, B2, D1 |
| 3 | 45 min | Ross's commercials: write down in your own words what you do and do not know about how the figures were counted, then say it aloud | C1 to C3, D2, F3, F4 |
| 4 | 45 min | Reread the report with A5 and E2 in mind, choose your reverse questions, then run the POV and B1 back to back | Reverse questions |

Everything else in this pack is insurance.

## Fit snapshot

You supplied no job description, so the requirements are the recruiter's own words, quoted from your message, plus one role-family requirement written from no source. Your evidence column holds your own sentences only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — the recruiter's email, as quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material says you ran the ISV channel for four years and took it from 6 to 40 partners, with nothing inspected behind it. It does not show whether any of those partners resembled an operator, and it shows nine years in partnerships with only the last four placed. Words: "I ran the ISV channel at a payments company for four years and took it from 6 partners to 40." Answer slot: the recruiter's "operator partnerships" makes a probe on what carries over likely. If any part of what you did with ISV partners carries over to operators, say which part, in your own words; if none of it does, say so plainly and stay with the channel you ran |
| F2 | "what it means for the operators themselves" — the recruiter's email, as quoted in your message | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | discovery | Your material says bus and light rail network planning and names no train operating company, with nothing inspected behind it. "The operator world from the other side" is your phrase and will be taken literally. Answer slot: if any of that planning work was with or for train operating companies, say which kind and what you saw there; if it was bus and light rail only, say so plainly and say what you would check first about how rail differs |
| F3 | "Ross will push on commercials" — the recruiter's email, as quoted in your message | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically, and I haven't carried a direct quota — only influenced revenue." Then how you would learn the commercial side, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F4 | "Ross will push on commercials" — the recruiter's email, as quoted in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | discovery | The figure is "roughly £4M of influenced revenue", and nothing in your material says how it was counted. Expect the four defend-the-number probes. Answer slot: say how it was counted, what it is most sensitive to, which assumption behind it you would defend least, and which part was yours; where you do not know how it was counted, say so plainly. Keep "influenced" and "roughly" in every sentence |
| F5 | Work credibly with senior operator-side counterparts (role-family requirement, no source) | none given | none | [generic] | discovery | Strong evidence here would be a named senior counterpart on the partner's side and a decision you moved together. Selection scaffold: pick a time you worked with a senior commercial or operational counterpart at a partner; it needs a named stake, a point where you disagreed, and a relationship that held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

No row is a gate: nothing in your message or the recruiter's wording states a term such as location, schedule, pay, travel or right to work. A job description would settle that.

## Graded deliverable: the 15-minute POV

The recruiter asked for "a short POV on where you'd take our operator partnerships over the next 18 months", with no slides, landing "on what it means for the operators themselves". It is graded, so build it as an assignment.

**Facts you can build on**

| Fit row | Your sentence, quoted | Use it at its own scope |
|---|---|---|
| F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Opening credential for the partnership side. It does not say operators |
| F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Opening credential for the operator side. It says bus and light rail |
| F3 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Say the limit yourself, early, so Ross does not have to find it |

**Theses**

| Thesis | What it commits you to | Mandatory concession | Where Ross will press | Provenance |
|---|---|---|---|---|
| T1: Go deep with a few operators before going wide | A small set of named operator partnerships, each with a joint plan and agreed measures | Coverage: operators outside the set get less attention, and losing one deep partner hurts | What each deep partnership has to return commercially, and when | [generic] |
| T2: Make the operator's own outcome the unit of the partnership | Agreeing with each operator at the start what better looks like for them, and reporting against it | Operators must give time and data, and outcomes may take longer than 18 months to show | What it costs, who carries the risk if the outcome does not move, how value is shared | [generic] |
| T3: Build an ecosystem of adjacent partners around the operators | Adding partners that serve operators, widening what Kelverton can offer them | It spreads attention away from the operators themselves, which is where the recruiter asked you to land | What the extra partners add commercially, and what they dilute | [generic] |

T3 is the one that draws on the ISV channel in F1. Whether that experience carries to an operator ecosystem is the F1 answer slot, so use T3 only if you can fill that slot honestly.

**Differentiation.** The report came from Kelverton's own strategy team, so both panelists know it and every prepared candidate has read it. Do three things with it. Bring one item from it that you expect every candidate to cite, to prove grounding. Then give one point where your thesis departs from it, with reasons, as a hypothesis you would test and never as a correction. Then give the anti-pick: one thing the report points at that you would decline to prioritise in the first 18 months, and why. The pack has not seen the report, so it names none of these for you.

**The close the recruiter asked for.** End on what it means for the operators themselves: what an operator's planners and commercial team would see differently at month 18, and what they would be asked to give. Take the change from the report's operator-facing material and your own reading, not from this pack. Name the one thing operators would have to give (time, data, a commitment), because Ross will ask what it costs them.

**Shape for the fifteen minutes** (generic pacing, not a script): one minute on what you assumed and what you would want to know, two on the objective, six to eight on the thesis and approach, two on the risk and your concession, two on the operators. Aim to finish a little under fifteen so the panel can interject.

## Persona table

Weights rest on relationship priors and on the recruiter's own wording. No public footprint for Deepa or Ross was available, so no signal adjusts them.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (weight 5) | Live problems on the POV: what you'd need to know, which operator first, how you'd measure it | High. The recruiter set a 15-minute POV on the next 18 months, and a future-manager panelist falls under the hiring-manager prior | Clarify, objective, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (weight 4) | Quiet probing of the two gaps you named, and why this move now | High. F3 is a stated gap, and the hiring-manager prior includes the Skeptic | Rehearse B1 until it is boring; bridge only from the stated adjacent evidence; bring a ramp plan |
| Data-Driven Prober (weight 4) | The figures: how counted, what counted as a partner, how much was you | High. The recruiter wrote that Ross "will push on commercials", and F4 is a quantified claim | Know what you can and cannot say about how each number was counted, and say plainly when you do not know |
| Pressure (weight 3) | Time-boxed "sixty seconds" challenges, interruption, "so why should we count that" | Medium. A commercial director's push fits the executive prior, but the recruiter's email says nothing about interruption | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Conversational (weight 2) | An opening "walk me through the journey" and casual market questions | Lower. Likely as an opener from a future manager, but a 60-minute panel with a fixed POV leaves little room | A 90-second arc; treat casual questions about the market as scored |

Not included: Values/Behavioral, because no loop source names a values round (the recruiter's email names a POV and Q&A); Peer, because neither panelist is described as a peer.

## Question banks

### A. Case/Strategist (Deepa's likely register)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've got fifteen minutes: where would you take our operator partnerships over the next 18 months, and what does that mean for the operators themselves?" | CASE | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | The graded deliverable; build it in the graded deliverable section. Say aloud what you assumed and what you would want to know, then the objective, one thesis, the approach, the risk with its concession, and the close on the operators. Use your own history only at the scope of the two quoted sentences: bus and light rail network planning, and running the ISV channel from 6 partners to 40 | The recruiter's own ask, so it is the likeliest item in the session; F1 and F2 are the evidence it leans on. CASE because it is a live problem, though it is also JD content |
| A2 | "What would you need to know about our operators before you'd commit to that plan?" | CASE | [generic] | Clarify before committing. Group what you would ask into what operators need, what they can give, and how the commercial arrangement works; for each, state your working assumption aloud so the panel hears a plan, not a list of gaps. Challenge one premise of your own plan respectfully | A manager testing whether you clarify before structuring. `[generic]` because the pack has no research on Kelverton's operators |
| A3 | "Name the first operator partnership you'd pursue, and the first you'd decline." | CASE | [generic] | Give your criteria aloud before naming anything, then apply them. The decline is the anti-pick from the graded deliverable section: say what you would not do in 18 months and what you give up by not doing it. Name operators only if the report names them | The role's real job includes saying no, so a candidate with only a yes-list looks like a consensus answer. CASE because it asks for a decision with criteria |
| A4 | "How would you know in month 12 that it's working, for the operators and for us?" | CASE | [generic] | Two short lists, one in operator terms and one in Kelverton terms, then say which assumption in them you would defend least. Name no figures: the pack has none to give you, and an invented target is the first thing Ross would test | Tests whether you land on operators, as the recruiter asked, and whether you can say what success costs. CASE with JD content |
| A5 | "You've read the report. Where would you push on it?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Your own words: you have read it. Bring the one consensus item first, then the one point where your thesis departs, as a hypothesis. Answer slot: if the report is silent on something your thesis needs, say what you would want to find out; if you agree with it throughout, say so plainly and say what you would do differently in sequence. The pack has not seen the report and names nothing from it | The report is the panel's own document and equally available to every candidate, so reciting it scores as homework and a reasoned departure scores as judgment. CO because it tests company-altitude thinking |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never sold into rail and you've never carried a quota. Why should we believe you can take our operator partnerships forward?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | **The highest-ROI prep in this pack.** Hold only what the quotes carry: you ran the ISV channel and took it from 6 partners to 40; you spent five years in transport consulting on bus and light rail network planning. Concede before the second follow-up asks: "I haven't sold into rail specifically, and I haven't carried a direct quota — only influenced revenue." Then give a ramp plan, said as a plan. First follow-up, likely "what carries over?": answer slot. If something from the ISV channel or the planning work carries over, say what, in your own words; if nothing does directly, say so plainly and return to what you ran. Second follow-up, likely "so we'd be taking a risk": agree plainly that rail selling and a direct number are unproven, and add nothing to the record | F3 is the stated gap, and F1 and F2 are the adjacent evidence it is weighed against, so this objection will arrive in some form from either panelist. JD because it scores the role's commercial side directly |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Your own message names two gaps, which are the safe candidates: "I haven't sold into rail specifically" and "I haven't carried a direct quota." Pick the one you think matters more, say so plainly, and say how you would close it, as a plan. If you believe the weakest part is something else, say that instead | An open prompt scoring honest self-assessment; F3 is the evidence behind it |
| B3 | "You moved from transport consulting into payments partnerships. Why partnerships here, and why now?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Keep the arc to what your two sentences state: consulting on bus and light rail network planning, partnerships at a payments company running the ISV channel. Your reasons are an answer slot: say in your own words what pulled you to this move and what you want from it; if the reasons are mixed, say so plainly | Motivation consistency, the Skeptic's standard probe; the material holds no reasons, so the pack supplies none. EXP because it tests whether your path holds together |
| B4 | "Walk me through your first 90 days. What do you need to learn before you're useful?" | JD | [generic] | A plan, not a past. Name what you would learn about operators, about Kelverton's commercial model, and which senior counterparts you would build relationships with, choose three, and order them. Say what you would ask Deepa for | Turns F3 and F5 into a ramp plan, which the Skeptic counter-strategy calls for. JD because it scores readiness for the role |

### C. Data-Driven Prober (Ross's likely register)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You describe roughly £4M as influenced revenue. Walk me through how that was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot, in your own words: how it was counted, what it is most sensitive to, the assumption behind it you would defend least (say it before Ross does), and which part was yours. If you do not know how it was counted, say so plainly. Keep "influenced" and "roughly"; do not call it closed, direct or booked | F4 is a headline figure and the likeliest target for the commercial director's push. EXP because it tests attribution |
| C2 | "Six to forty partners. What counted as a partner at each end?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: the definition at each end is yours to state. If it changed over the four years, say how; if it did not, say so. Say which part of the growth was yours, in your own words, and stay at the scope of your sentence | A number stays attached to its noun: this one counts partners, not revenue. F1 holds it. EXP |
| C3 | "Of that £4M, how much would have happened without you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Answer slot: if you can separate what you influenced from what would have happened anyway, say how you did it; if you cannot, say so plainly, and say what you would want measured. Do not offer a split | The counterfactual is the standard next level down for an influenced figure; F4. EXP |
| C4 | "Walk me through how an operator partnership makes money for us and for the operator." | CASE | [generic] | A live problem; it presupposes nothing about your past. Say first what you do not know, such as who pays whom for what, and ask. Then structure it: what each side puts in, what each takes out, what is shared, what could make it uneconomic for one side. Name the assumption you would defend least | The commercial director's version of the POV, and the place F3 matters most. CASE because you reason from the problem and no experience is claimed |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." and "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." and "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pause and restate the question. Hold in one breath on the two quoted facts at their own scope. Concede in the second breath: "I haven't sold into rail specifically." Do not claim to be better; say what you would bring and what you would need to learn. Hold through two follow-ups, conceding only what is unproven and naming it | Composure on the F3 gap, time-boxed. JD because it scores the stated fit |
| D2 | "You say influenced. Why should a commercial director count that as anything?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Do not argue that influenced is as good as direct; your own sentence says it is not a direct number. Concede that limit specifically. Answer slot: if you can say what the influenced figure measured in your employer's own terms, say it; if you cannot, say so plainly and return to how it was counted (C1) | The hold-then-concede test on F3 and F4 together, in Ross's own domain. EXP |
| D3 | "Your plan needs a lot from operators. What happens when the first one says no?" | CASE | [generic] | Pause and restate. Then three options: change the ask, change the partner, change the plan, and say what you would learn from the no. Hold your thesis, concede the dependency and the sequencing risk by name | Pressure applied to the POV itself, so the thesis is tested live. CASE |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey. How did you get from where you started to here?" | EXP | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | A 90-second arc with only the beats your sentences state: transport consulting on bus and light rail network planning; partnerships, the last four years at a payments company running the ISV channel, 6 partners to 40. Answer slot: your message gives nine years in partnerships and four at the payments company; say in your own words what the other years were and where the consulting sits among them. End on why this role, in your words, because the pack holds no reasons | The usual casual opener from a future manager, and it is scored. F1 and F2 supply the beats; the gap in the nine years is why the slot is there |
| E2 | "What are you actually looking at in rail-tech right now?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Casual register, scored. Answer slot: say what you took from your own reading of the report and one thing you would want to test with them; if nothing in rail-tech has held your attention beyond the report, say so plainly and say what you would look at first. The pack has not seen the report and names nothing from it | A casual question about a hot topic, asked with the report in the room. CO |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "where you'd take our operator partnerships over the next 18 months" | A1, A2, A3, A4, D3 |
| "what it means for the operators themselves" | A1, A2, A4, C4 |
| "Ross will push on commercials" | B1, B2, C1, C2, C3, C4, D1, D2 |
| Work credibly with senior operator-side counterparts (F5, no source) | B4 |

## Reverse questions

| # | Ask | Why it lands |
|---|---|---|
| R1 | To Deepa: "What would make the first six months a clear success in this role, and what would tell you it wasn't working?" | It asks for her scoring sheet directly and gives your ramp plan (B4) something to aim at |
| R2 | To Ross: "How are partnership results counted here, and would this role be accountable for a direct number, an influenced one, or both?" | It puts the F3 difference on the table in your own terms, before it is used against you |
| R3 | To Ross: "What commercial constraint on this plan might I not see from outside?" | It shows you expect his lens and invites the constraint your POV may have missed |
| R4 | To Deepa: "Which operator relationships today would you point to as the model for the ones you want more of?" | It tells you what good looks like to your future manager, and tests T1 against reality |
| R5 | To either: "Is there anything in the report you'd like a new partnerships lead to push on rather than accept?" | It follows A5 and signals you read the report as an input, without correcting anyone |
| R6 | To either: "What happens after this round, and who else will be involved?" | Process clarity; it costs nothing and is rarely asked |

No interviewer profile was available, so none of these is tied to a panelist's own path; research would add that.

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Sold into rail, or has rail commercial experience | Negative you stated, F3 | The plain acknowledgment F3 gives: "I haven't sold into rail specifically." No slot |
| Carried a quota or a direct number | Negative you stated, F3 | "I haven't carried a direct quota — only influenced revenue." No slot |
| Closed, owned or booked the £4M | Inflated form of F4 | F4's quote at its own scope, "roughly £4M of influenced revenue". The limit is the pack's observation: the material says influenced, not direct. C1 stays inside how the figure was counted |
| Built the ISV channel, or set its strategy | Inflated form of F1 | F1's quote at its own scope: running the ISV channel, 6 partners to 40. The material says the channel was run, not which stages of it were yours to set |
| Has run partnerships with operators, or knows train operating companies from inside | Inflated form of F1 and F2 | F2's quote at its own scope: bus and light rail network planning. The material names no train operating company |

## Sources

Provided documents: your message, which quotes the recruiter's email. The market report is named in your message as read, but its content was not supplied, so it is not in hand and nothing in the pack is taken from it.

Searches sent, all refused (web search was not permitted in this session):

- "Kelverton Rail values": refused
- "Kelverton Rail strategy news train operating companies scheduling software": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused
- "Senior Partnerships Manager job description rail technology train operating companies": refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Every call was refused. It would have fed any values-themed questions and the close of the POV. No values round is detected, so the cheat sheet is dropped either way |
| 2. Interview process, partnerships roles | skipped | The recruiter's email, as quoted in your message, fixes the loop: one panel session, two named panelists, 60 minutes, a 15-minute POV then Q&A. Persona weights follow from it |
| 3. Kelverton Rail strategy and recent news | unavailable | Refused. It would have moved A5 and E2, and supplied a grounding brief (dropped). The report you read would answer it if its content were in hand |
| 4. Interviewer footprint (Deepa, Ross) | unavailable | Both calls refused. The interviewer read is absent, and the reverse questions are not tied to a panelist's path |
| 5. Representative Senior Partnerships Manager job description | unavailable | Refused. It would have given the fit snapshot JD-style requirement rows; they are now the recruiter's wording and one role-family row |

No dossier was supplied, so none was consumed.

## Upgrade menu

- The job description (or the recruiter's posting) → F5 and the role-family requirement become quoted JD lines, the JD-tagged questions gain a raising source, and any gate (location, schedule, pay, travel, right to work) becomes visible. A one-line email to the recruiter would get it
- Your CV → the evidence column quotes CV lines instead of your message, and E1's slot about the other years of the nine is answered. An attribution report or partner scorecard behind the £4M and the 6-to-40 count, if you are free to share it, is the inspectable artifact that would lift F1 and F4 toward `high`
- The text of the market report, if you are free to share it → a grounding brief, A5 and E2 built against its actual shortlist, and a named consensus item and anti-pick for the POV
- Allowing web search in this session → targets 1, 3, 4 and 5 run, the interviewer read appears, and reverse questions can follow a panelist's own path
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes; needs search allowed) → a strategy brief, the panelists' talks and writing, loop reports for this role family, and recent organisation context
- Your answers to the answer slots (F1, F2, F4, C1 to C3, E1) → each becomes new quoted evidence and the rows that draw on it are regenerated
- A `tuesday-dossier.md`, if you have one → the highest-ROI objection would come from verified evidence rather than inference, and weak areas would carry strategy limits
