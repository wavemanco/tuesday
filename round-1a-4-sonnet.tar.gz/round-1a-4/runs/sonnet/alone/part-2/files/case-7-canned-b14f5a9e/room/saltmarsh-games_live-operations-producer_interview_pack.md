# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager, not confirmed.
**Round assumed:** Friday is the 60-minute hiring-manager interview that Saltmarsh's careers page calls the Outage Hour. This is an assumption. If it is wrong, the persona weights below change.
**Start here:** C1 is the highest-ROI prep in this pack. It will be asked in some form, and a calm, rehearsed answer changes the interview.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only say what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows Saltmarsh's published values |
| EXP | Whether what you say you did holds up under follow-ups |
| JD | The stated job and its requirements, gaps included |
| CO | How well you know the company's current direction |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to your message, the JD you pasted, or the research listed in Sources. `[inferred]` is a derivation, named in the row. `[generic]` is a role-family pattern with no claim about you or Saltmarsh. An answer slot is an instruction for the interview, not a question to you: say your own version if it is true, and if it is not, say so plainly and return to what you did do.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one main title's weekly content-drop calendar, not a live-events calendar and not two titles. Words: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events and two-titles lines make a probe likely on whether any of your drops were time-limited events. If any were, say which and what part was yours, in your own words. If none were, say so plainly and stay with the weekly calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show whether those teams fed your calendar. Answer slot: the JD's coordinate line makes a probe likely. If any of those teams had to be ready for your content drops, say which and what you did to line them up, in your own words. If the calendar involved none of them, or lining them up was not yours, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says presenting retention numbers, not owning a post-event review or its KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if a review followed any of your drops or events, say what it covered and what part was yours. If none did, say so plainly, stay with the monthly numbers, and say how you would run the first review |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it, not that you ran it on each release. Words: "I wrote the release checklist our QA team still uses." Answer slot: if you also worked it with QA on release days, say how, in your own words. If you did not, or QA ran it without you, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | discovery | The years requirement is not a gate, and four years clears the number on its face. What your material does not show is whether the main title was a live-service game. Answer slot: if it was updated on a live schedule, say so and how, in your own words. If it was not a live-service game, say so plainly and stay with the weekly content-drop calendar |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a statement with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you ran it, weekly, for the last two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap, but nothing inspected behind it. Lead in the quote's terms: you presented the retention numbers, monthly, to the studio head. You gave no figures, so no defend-the-number slot arises; if asked how the numbers were counted, see D1 |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | Point at the document and say only what the quote says: "I wrote the release checklist our QA team still uses." A named written document that another team still uses is stronger than the word "clear", and the quote does not say why it is still used |
| F9 | Leading people: a role-family expectation, not in your JD and not quoted | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap you stated yourself. Words: "I haven't led a team." The JD's verb is coordinate, which the quote does not address, so move to a plan said as a plan and never as a past: how you would line up four disciplines you do not manage |
| F10 | Working on in-app-purchase monetization of live events: a role-family expectation, not in your JD and not quoted | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap you stated yourself, and the one that matters most given the season-pass move in Sources. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work |

## Reading the interviewer

| Fact | Source | Provenance | What it means for you |
|---|---|---|---|
| Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio | Search result for a GDC 2026 talk listing; page not fetched, see Sources | [grounded] | Release checklists and QA are his native vocabulary, so expect depth on D3 and B3. Lead with the checklist in the plain terms of F4 and do not stretch it |
| His GDC 2026 talk "Patch Notes Are a Promise" argues a live team is judged by how often its patch notes describe what actually shipped | Same search result | [grounded] | It matches the value "Ship the Patch Not the Promise". Announce only what is built and known, and say what you do not know yet. A2 rehearses this |
| He is your hiring manager for this round | Careers page says the loop's single interview is with the hiring manager; you named Tobias as your interviewer | [inferred] | Derived, not confirmed: the page says hiring manager and you named him, but no source says he is that person. If he is not, tell me and I will reweight |

Mirror opportunity, shared vocabulary only: he came up through QA and you wrote a checklist QA uses, so say it in your own words from F4: "I wrote the release checklist our QA team still uses." No row of your material carries a career-jump parallel, so none is offered. Public professional footprint only.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (weight 5) | A live-incident tabletop on a simulated outage during a live event | Highest. The careers page, fetched, describes the hour as a tabletop first. The facts that fix the weight are the tabletop and the hiring-manager relationship | Clarify first, then objective, approach, comms and risks. Say your structure aloud and challenge one premise politely |
| Values / Behavioral (weight 5) | A values conversation on the three published values | Highest, tied. The same page puts a values conversation in the same hour, so a values-style round is documented and section 10 applies | Map a story to each value where a quoted sentence carries one. Where none does, pick honestly and say so |
| Skeptic (weight 3) | Probes your stated gaps: no team lead, no in-app purchases, one title not two | Mid. A hiring manager is buying capability and derisking gaps, and you stated both F9 and F10 yourself | Rehearse C1 until it is boring: plain acknowledgment, adjacent evidence at its own scope, a plan |
| Data-Driven Prober (weight 3) | Walks your retention numbers and your checklist line by line | Mid. The JD names retention metrics and KPIs, and he has a QA background. Nothing found calls him data-driven, so no upward adjustment | Know what you can and cannot say about how the numbers were counted, and say plainly when you do not know |
| Conversational (weight 2) | Opening biography and the "any questions for me" slot | Low. No unstructured round is documented, but openers and the reverse slot are still scored | A 90-second arc built only from your own sentences, and real reverse questions |
| Pressure (inside A2) | Time-boxed injects during the tabletop | Unknown. The page does not say whether the tabletop is time-boxed, so A2 rehearses it in the hold-then-concede shape without a separate bank | Pause, restate, hold one position through two follow-ups, concede specifically |

A peer persona is not plausible with a Head of Live Operations, so it has no bank.

## Question banks

### Bank A: Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Picture the first evening of a weekend event. Reports come in that a reward screen won't load for some players, and the event clock is running. You're the producer on call. What do you ask first, and what do you do in the first hour?" | CASE | [generic] | Say your structure aloud before you use it. Clarify first: who is affected and on which platforms, what changed in the last build or config, whether it is growing, whether it can be rolled back or switched off, and who owns each decision. Then one sentence of objective. Then actions in order: contain, tell players what is known, decide what happens to the event clock, assign owners, set the next check-in. Close with the risks you are carrying and how you will review it afterwards. The question needs no claim about your past, so the guidance makes none | The careers page describes a live-incident tabletop, so this is the likeliest shape of the first half. CASE because it scores structure, and `[generic]` because it is a pattern for the problem, not a fact about this employer |
| A2 | "You told players an hour. Engineering now says the fix needs a full build that won't land before the event ends, and community wants to post that a fix is 'coming soon'. What do you tell players, and what exactly do you write?" | CASE | [grounded] | Hold, then concede. Hold one position through two follow-ups: say only what is built and known. Saltmarsh's own line is "we announce what is built, not what is hoped", so "coming soon" is out because no date is built. Concede specifically: what you do not know yet (when, how many players, whether the event can be extended) and who decides the extension. Say the two or three sentences you would post, aloud and in plain words, because the written message is the answer. If they push you to protect the calendar, the lens is "when the calendar and the players disagree, the players win" | Tests the pressure shape inside the tabletop and the JD's written-communication line (F8's requirement) in one question. The two quoted lines come from the fetched values page. CASE because it is a live problem, with VAL content |
| A3 | "Two titles, same Sunday. Both have an event ending, one slips a day, and both teams ask you for the same release slot. How do you decide?" | CASE | [inferred] | Derived from the JD's two-title scope, not a known Saltmarsh situation. Clarify what is fixed and what can move, what has already been told to players, and what QA can cover. State your decision criteria aloud (player impact, what was promised, QA capacity), say who you would consult, and name what you do not know about how the two titles work. The question needs no claim about your past, so the guidance makes none | F1 is the evidence for one calendar and the JD asks for two, so this is where the step up is tested. CASE with JD content, `[inferred]` because the scenario is this skill's derivation from the JD line |
| A4 | "Saltmarsh announced Project Larkspur in September: a season-pass model and one shared events calendar for Tidepool Tactics and Lantern Row from February 2027, with per-title event teams folded into one live-ops group. What would you want to understand before planning a shared calendar across two titles?" | CO | [grounded] | Ask, don't assert. Questions worth asking: which events are shared and which stay per-title, who breaks a tie when both titles want a date, how the season pass sets the calendar's rhythm, and how reviews will compare across the two titles. Say plainly you have read the announcement, not internal plans. The season pass is a monetization change, so do not claim familiarity with it (see C1). The question needs no claim about your past | The one strategy-grounded question, from the Larkspur result in Sources, which was a snippet and not a fetched page. CO with CASE delivery. Whether these two titles are the role's two is unconfirmed, and R2 asks |
| A5 | "The outage is over. Walk me through the post-event review you would run and the KPIs it would report." | CASE | [grounded] "Presented the monthly retention numbers to the studio head." | Structure it: a timeline of what happened, what players experienced, what held and what failed, decisions and who made them, actions with an owner and a date. Choose the three or four KPIs you would report, tie each to a decision it informs, and say which you trust least and why. On your past, your words are: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe likely. If a review followed any of your drops, say what it covered and what part was yours. If none did, say so plainly, stay with the monthly numbers, and say how you would run the first one | F3 is the evidence and the likeliest place to be pushed, since the JD asks to own the review. CASE with JD content: the question is hypothetical and the slot guards the past |

### Bank B: Values / Behavioral (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans: when the calendar and the players disagree, the players win. Tell me about a time you put the players ahead of the calendar." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | The quote carries a calendar, not a conflict, so this is a selection scaffold. Pick a week when a drop's date and the players' experience pulled apart. It needs a named stake, what you changed, and who agreed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years", or say how you would handle it | The first published value, from the fetched values page. F1 and F6 hold the calendar, but nothing in them is a conflict, so no story is supplied |
| B2 | "Ship the Patch Not the Promise: we announce what is built, not what is hoped. Tell me about a time you held back an announcement, or corrected one." | VAL | [grounded] | Pick a time something was about to be announced before it was ready, or was announced and proved wrong. It needs what was said, what was actually built, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it. The question needs no claim about your past, so the guidance makes none | The second published value, and it echoes Tobias's talk (see Reading the interviewer). No quoted sentence carries an announcement story, so it is a scaffold |
| B3 | "Leave the Build Greener: every release leaves the codebase and the checklist better than it found them. Tell me about a time a release left your process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4, with only the beats the sentence states: you wrote the checklist, and QA still uses it. Say it in your own words. Answer slot: the value's checklist line makes a probe on how it changed likely. If it changed after any release, say what and why. If it did not, or the changes were not yours, say so plainly and stay with having written it and QA still using it | The third published value names the checklist, and F4 is the one quoted sentence that touches it. Also the line Tobias's QA background makes likeliest to be probed |
| B4 | "Tell me about a time you had to put an uncomfortable number in front of someone senior." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Your words: "I presented the monthly retention numbers to the studio head." Answer slot: if any month's number was one you would rather not have shown, say what it was and how you said it, in your own words. If every month was routine, say so plainly and describe how you presented them. Do not supply a hard truth that landed unless it happened | A standard values stem that suits a producer who reports numbers up. F7 is the only quoted sentence near it, and it carries no uncomfortable moment |
| B5 | "Which of our three values would be hardest for you to live by?" | VAL | [grounded] | Pick one and say why, in terms of a real decision that pulled against it. Honest candor scores better than a polished answer. If no past decision comes to mind, say so plainly, then say how you would handle it. The question needs no claim about your past, so the guidance makes none | Tests self-awareness against the published values, which the fetched values page names |

### Bank C: Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't worked on a game with in-app purchases, and Tidepool Tactics and Lantern Row are moving to a season pass. How would you get up to speed, and where would you be wrong first?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message; "I ran the weekly content-drop calendar for our main title for the last two years."; "Presented the monthly retention numbers to the studio head." | The highest-ROI rehearsal in this pack. The limit first: your material shows no monetization work, and this pack will not coach any. Level 1, the plain acknowledgment: "I haven't worked on a game with in-app purchases." Level 2, adjacent work at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years" and "I presented the monthly retention numbers to the studio head". Do not call either monetization experience. Level 3, a plan said as a plan: what you would learn first, as questions to ask (how the pass is structured, who owns pricing and reward decisions here, what the review should report beyond retention). Follow-up "Retention isn't revenue": concede it, "That's right, the numbers I presented were retention numbers". Follow-up "Where would you be wrong first?": name one thing you would expect to check twice, in your own words, without claiming to know the economy. Follow-up "Isn't that a risk?": restate the gap, the plan, and ask what he would want to see from your first event. Hold through two follow-ups and never fold on the plain acknowledgment | F10 is the biggest stated gap and the season-pass move makes it live, so this is the most predictable objection to you. JD content in a Skeptic delivery. The two adjacent quotes come from F1 and F3 |
| C2 | "You haven't led a team, and this job means lining up design, art, engineering and community on every update. Why should I believe that works?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the plain acknowledgment: "I haven't led a team." The JD's verb is coordinate, which is the thing being asked, and your material does not say whether you did it. Answer slot: if any of those teams had to be ready for your content drops, say which and what you did to line them up, in your own words. If none did, or it was not yours, say so plainly and stay with "I ran the weekly content-drop calendar for our main title for the last two years". Then a plan said as a plan: how you would learn what each team needs and by when | F9 and F2 meet here. The question's premise is a negative you stated, and the JD's coordinate line raises the slot |
| C3 | "The JD asks for 3+ years producing live-service games or apps. Take me through how your weekly content-drop calendar ran." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years." | Your words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if the title was updated on a live schedule, say so and how a week ran, in your own words and which parts were yours. If it was not a live-service game, or parts of the week were not yours, say so plainly and stay with the calendar | F5 and F6 are the requirements. EXP because it tests what was actually yours, JD because it scores the stated requirement |

### Bank D: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You presented monthly retention numbers to the studio head. Which measures were in them, and how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Your words: "I presented the monthly retention numbers to the studio head." Answer slot: say which measures were in them and how they were counted, in your own words. Name the assumption behind them that you would defend least, and say which part of them was yours. If you do not know how a figure was counted, say so plainly and return to presenting them each month | F7 is the evidence. A prober's first question on any quantified line is how it was counted, and you gave no figures, so the slots are only the four a figure raises. EXP with JD content |
| D2 | "Day-7 retention is down after a weekend event, compared with the one before. What do you check before you say the event caused it?" | CASE | [generic] | Clarify the definition first. Then check who was in each cohort, what else changed in the same window (builds, other events, store features), and whether the sample is big enough to read. State the weakest assumption in your own reading, and separate what the data shows from your hypothesis. Never present a causal claim you cannot back. The question needs no claim about your past, so the guidance makes none | The JD's retention-metrics line (F7's requirement) asked as a live diagnosis. CASE with JD content, `[generic]` because it is a pattern for the problem |
| D3 | "Walk me through the release checklist you wrote for QA: what it covers, and how it gets used on release day." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Your words: "I wrote the release checklist our QA team still uses." Answer slot: the JD's manage-with-QA line makes a probe on release day likely. If you ran it with QA on release days, say how, in your own words. If QA ran it without you, or it was used differently, say so plainly and stay with having written it and QA still using it | F4 is the evidence, and Tobias's QA background makes this the line most likely to be pressed. EXP because it tests what was actually yours |

### Bank E: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc built only from these four sentences, in your own words: the role, then the calendar, then the checklist, then the retention numbers. Then your actual reason for wanting this role. Give your own reason, because this pack does not supply one. End on what you want to work on at Saltmarsh | An opener is always asked and it is scored. F5, F1, F4 and F3 hold the four beats, and the reason for the move is deliberately left in your hands |
| E2 | "What's a live event in a mobile game that you thought was done well, or badly?" | CO | [generic] | Pick one you experienced as a player. Say what it asked of players, what worked, and what you would change. If no such event comes to mind, say so plainly, then say which one you would look at first and why. The question needs no claim about your past, so the guidance makes none | A casual question that is still scored as a signal of genuine interest in live games. CO because it tests how you think about the genre |

## Requirement coverage

| JD requirement | Questions covering it |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, A4, C3 |
| "coordinate design, art, engineering and community teams on each update" | A1, C2 |
| "own the post-event review and the KPIs it reports" | A5, D1, D2 |
| "manage the release checklist with QA" | D3, B3 |
| "3+ years producing live-service games or apps" | C3, E1 |
| "experience running a content calendar" | C3, B1 |
| "comfortable with player-retention metrics" | D1, D2, B4 |
| "clear written communication" | A2 |

## Values cheat sheet

A values-style round is documented: the careers page says the hour ends with a values conversation.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | B1: selection scaffold. The F1 sentence carries a calendar, not a conflict, so pick a real week or say plainly none comes to mind |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | B2 and A2: selection scaffold. No quoted sentence carries an announcement story |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | B3 on F4: "Wrote the release checklist our QA team still uses." Only those beats, plus the answer slot on how it changed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk 'Patch Notes Are a Promise' argues a live team is judged by how often its patch notes describe what actually shipped. How does this team check that today, and where does it slip?" | Ties to his own published argument and his QA path, and moves him from interviewing to talking shop |
| R2 | "Project Larkspur folds per-title event teams into one live-ops group. Are the two titles in this role the ones it names, and where does this role sit in that group?" | Shows you read the strategy, and settles the scope the JD leaves open |
| R3 | "What would a good first event look like for someone in this role, and what would you want to see by the end of it?" | Turns your stated gaps into a shared ramp plan and surfaces how success is measured |
| R4 | "How are post-event reviews used today: who reads them, and what has changed because of one?" | Tests the JD's own-the-review line and shows you care whether reviews change anything |
| R5 | "When an event goes wrong mid-run, who decides to pause or extend it: the producer, you, or the game team?" | Probes real decision rights and connects to Players Before Plans |
| R6 | "How do design, art, engineering and community hand work to the producer on an update today, and where does it hurt?" | Asks about the seams the JD's coordinate line depends on |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran a live-events calendar, or calendars for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one main title's weekly content-drop calendar. A slot on whether any drops were time-limited events stays inside the calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: presenting the monthly retention numbers. The limit is the pack's observation, and the slot asks only what any review covered and what part was yours |
| Managed the release checklist with QA on each release | Inflated form of F4 | F4's quote at its own scope: you wrote it and QA still uses it |
| Led a team, or has experience leading people | Negative you stated, F9 | The plain acknowledgment F9 gives: "I haven't led a team." Then a plan said as a plan |
| Worked on in-app purchases or monetized events | Negative you stated, F10 | The plain acknowledgment F10 gives: "I haven't worked on a game with in-app purchases." Then a plan said as a plan |

## Sources

Provided documents: the JD text and your background, both pasted in your message. No `tuesday-dossier.md` was present.

Research tier: L1, searches 4 of 6, fetches 2 of 2

Searches and fetches sent:

- Search "Saltmarsh Games values": returned https://saltmarshgames.com/values
- Search "Saltmarsh Games interview process live operations producer": returned https://saltmarshgames.com/careers/interviewing
- Search "Saltmarsh Games mobile studio news strategy": returned https://saltmarshgames.com/news/project-larkspur
- Search "Tobias Wrenfield Saltmarsh Games": returned https://talks.gdconf.example/2026/patch-notes-are-a-promise
- Fetch https://saltmarshgames.com/values: returned the three values and their one-line meanings
- Fetch https://saltmarshgames.com/careers/interviewing: returned the loop description

Two source cautions. The Project Larkspur announcement is a search-result snippet only: the page was not fetched. The talk listing is also a snippet only, and its URL uses a `.example` host, which is a reserved placeholder domain, so confirm that the talk exists before you cite it to Tobias.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and bank B: three values by official name |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop: a recruiter call, then one 60-minute hiring-manager interview with a tabletop and a values conversation, and no take-home. Persona weights follow it |
| 3. `Saltmarsh Games strategy` or recent news | yes | A4 and R2 from the Project Larkspur snippet, and the weight on C1 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Reading the interviewer, R1 and the D3 emphasis |
| 5. representative `Live Operations Producer` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Friday is the Outage Hour and Tobias is your hiring manager → persona weights confirmed or reweighted, and the interviewer read corrected if needed
- The recruiter's prep email, including which two titles the role covers → the tabletop's real format and the scope behind F1, A3 and R2
- Your own answers to the answer slots on F1, F2, F3, F4 and F5, typed here outside a drill → each becomes quoted evidence, and those rows and their banks regenerate with story maps in place of slots
- A past content-drop calendar, the checklist document itself, or a monthly retention deck → rows F6, F4 and F7 can rise from medium to high confidence
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → the Larkspur announcement and Tobias's talk read from their own pages, a strategy brief for the CO bank, and recent org context
- A `tuesday-dossier.md` from an earlier evaluation of this role, if you have one → verified evidence and constraints in place of the objection and prohibited list this pack built itself
