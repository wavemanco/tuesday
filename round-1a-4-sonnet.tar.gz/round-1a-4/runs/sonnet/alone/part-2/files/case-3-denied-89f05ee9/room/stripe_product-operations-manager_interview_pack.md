# Stripe — Product Operations Manager: final-round prep pack

- **Role:** Product Operations Manager
- **Company:** Stripe
- **Round:** final round; interviewer(s), their relationship to the role and the number of sessions are not known
- **Built on:** the role and company named in your request, with no CV, no job description, no interviewer information and no company research (web search was refused this turn). Everything below is labeled for what it rests on, and nothing in it is a fact about Stripe or about you.

## 1. How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: with no CV in hand, every guidance cell is a structure or a selection scaffold, and none says anything about your past. Add your CV and the cells become story-mapped to your own sentences.

Highest-ROI prep in this pack: **B1**, the weakest-on-day-one question, which is the working pick until your CV shows where your real gap is. Rehearse it until it is boring, then B2.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior demonstrates specific values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny; what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem set in the role |

## 2. Fit snapshot (worksheet variant)

No CV and no job description were supplied, so this is a worksheet: the requirements are role-family patterns written as plain prose, not quotes from Stripe's posting, and every evidence cell reads `none given`. Each row says what strong evidence looks like, then a selection scaffold ending in its honest branch.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating a launch or program across several teams — typical of the role family, no posting supplied | none given | none | [generic] | discovery | Strong evidence is a named launch or program, who was involved, and which part you owned. Pick one that fits that shape from your own history; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Designing and running operating rhythms such as planning, reviews and launch readiness — typical of the role family, no posting supplied | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or changed and what it replaced. Pick the one where your own part is clearest; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Using data to find, size and track product or operational problems — typical of the role family, no posting supplied | none given | none | [generic] | discovery | Strong evidence is a number you were responsible for, with how it was counted and which part was yours. Pick one you can walk through end to end; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influencing people you do not manage and communicating with senior stakeholders — typical of the role family, no posting supplied | none given | none | [generic] | discovery | Strong evidence is a moment you moved a decision without authority, with a named stake. Pick one where the outcome is not in doubt; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritizing and creating structure under ambiguity — typical of the role family, no posting supplied | none given | none | [generic] | discovery | Strong evidence is a time the work had no defined shape and you chose what came first and why. Pick the one with the clearest reasoning; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Building tooling, documentation or automation that lets ways of working scale — typical of the role family, no posting supplied | none given | none | [generic] | discovery | Strong evidence is a tool or template other people kept using without you. Pick one where you can say what it replaced; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Understanding the company's products and the customers who use them — typical of the role family, no posting supplied | none given | none | [generic] | discovery | Strong evidence is what you have actually read, used or tried, named specifically. Choose from your own homework; if little comes to mind, say so plainly, then say what you would study first |

## 3. Persona table

Relationship and session structure are unknown, so the weights are blended from the generic final-round and hiring-manager priors in the persona model and tilted toward live problems because the role is operating work. They rest on a pattern, not on Stripe's documented process. If you tell me who you are meeting, they get recomputed.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| A. Case / Strategist | Live problems set in the role: plan this, diagnose that | Highest: an operating role is scored on structure, and a final round often carries a live problem | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully | [generic] |
| B. Skeptic | Quiet probing of gaps and of why this role, this company, now | High: a final round weighs motivation consistency and honest self-assessment | Rehearse the single most predictable objection until it is boring; say limits plainly and pair them with a ramp plan | [generic] |
| C. Peer Evaluator | Seam-splitting with adjacent teams, collaboration scenarios | Medium: this role works across teams, so a peer or cross-functional panelist is plausible | Reciprocity framing; propose seam principles rather than claiming to know the seam | [generic] |
| D. Data-Driven Prober | Pushes any number or metric two levels deep | Medium: operations roles lean on measurement | Know how each figure was counted, name the weakest assumption before they do, and say plainly what you do not know | [generic] |
| E. Conversational / Rapport Builder | Friendly, unstructured; scored anyway | Medium: a final round usually opens or closes with one | A 90-second arc ready for the biography question; treat casual questions as scored | [generic] |
| F. Values / Behavioral | Scenario probes, STAR-shaped stories | Lower here: Stripe's published values and loop are not established, so a values round is not detected. If you are told one exists, this weight rises | Choose stories where the hard truth actually landed; say "we" for context and "I" for your part | [generic] |
| G. Pressure / Stress | Interrupts, time-boxes, tests composure | Lower: no signal that this loop uses it | Pause, restate, hold a challenged position through two follow-ups, concede only what is true | [generic] |

## 4. Question banks

Every question below carries only a label in Provenance because the guidance makes no claim about your past. Answer slots are instructions for the interview, not questions for you now.

### A. Case / Strategist (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch involving four teams is two weeks out and nobody agrees whether it is ready. What do you do first, and what do you need to know?" | CASE | [generic] | Clarify first: what ready means, who decides, what cannot be undone. Then agree launch criteria, surface where the teams actually disagree, name one decision owner and one forum, list the top risks, say what you would report and when. Challenge one premise aloud, such as whether the date is the real constraint | Tests F1 and F2 as a live problem; CASE because it asks about no past |
| A2 | "Adoption of a recently shipped feature is 20 percent below plan. Diagnose it." | CASE | [generic] | Clarify the metric definition and the baseline, then check measurement before behavior: instrumentation, segment mix, timing. Rank hypotheses by likelihood and cost to test, and name the cheapest first test and what result would change your mind | A metric-drop diagnosis is the standard CASE form; it covers F3 |
| A3 | "Design the operating rhythm for a product organization whose teams each plan and review in their own way. What goes in it and what stays out?" | CASE | [generic] | Start from the decisions that need a regular forum, not from meetings. Propose the smallest rhythm that serves them, name an owner for each part, say what you would deliberately leave to teams, and say how you would tell in a quarter whether it is working and what you would retire | Covers F2 and F5; a process-design case, so CASE |
| A4 | "Pick a Stripe product you have used or studied. How would you judge whether the way it is launched and supported is working?" | CO | [generic] | Choose from what you have actually read or used and name the source. State only what you can verify, then give the signals you would look at and what you would ask the team. If you have not studied one, say so plainly and say what you would look at first | Covers F7; CO because it scores homework depth, and generic because no Stripe research ran |
| A5 | "Three teams each ask for the same two engineers next quarter. How do you handle it?" | CASE | [generic] | Clarify what each team needs and by when, set explicit criteria, decide who decides, make the tradeoff visible to all three, and say what you would concede and what you would escalate | Covers F4 and F5 under conflict |

### B. Skeptic (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Highest-ROI rehearsal in this pack. Name one real gap from your own honest assessment, not a disguised strength. Then give a concrete ramp plan said as a plan: what you would learn, from whom, in what order. If no gap comes to mind, say so plainly, then name the area where you would ask the most questions in your first month. Hold this through two follow-ups by returning to the plan | The most predictable objection in any final round; the working pick until your CV shows where your real gap is. JD because it scores fit including its gaps |
| B2 | "Why product operations, why Stripe, and why now?" | EXP | [generic] | Three short parts in your own words: what draws you to the work, what draws you to this company, and why this moment. Keep it consistent with what you told the recruiter. If one part is unsettled, say so plainly rather than building a reason | Motivation consistency is the Skeptic's core score; EXP because it tests your own history of choices |
| B3 | "How is product operations different from program management, and where would you draw your own line?" | JD | [generic] | Define each in your own words, say where they overlap, and offer a principle for the boundary such as who owns the outcome and who owns the process. Do not claim to know how Stripe draws it; say you would ask | Tests whether you understand the role itself; covers F2 |
| B4 | "What in your background is furthest from what this role needs, and how would you close it?" | JD | [generic] | Pick the real distance, not a rehearsed humility line. Say it in one sentence, then give the closing plan. If your background and the role overlap fully, say so plainly and name where the work would still be new | Cross-checks B1 from another angle; covers F1 to F6 |

### C. Peer Evaluator (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of pretending to know the seam: decision rights, who owns the outcome, who owns the process. Then say how you disagree: evidence first, the decision owner named, a clear escalation path. Add what you would want from the peer | Covers F4; JD because it scores how the job works across teams |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Use "we" for context and "I" for your own part. Pick a real example where credit was shared or contested; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing probe; VAL because it scores behavior toward peers |
| C3 | "What could you do for my team in your first month, and what would you need from me?" | JD | [generic] | Lead with what you bring: reducing a load, clarifying a decision, a first deliverable. Then state two or three specific needs. Keep both modest and honest about a first month | Reciprocity framing; covers F5 |

### D. Data-Driven Prober (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a number you have been responsible for reporting. Walk me through how it was counted." | EXP | [generic] | Pick one you can defend end to end. Say in your own words how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how part of it was counted, say that plainly. If no such number comes to mind, say so, then describe how you would count it | The defend-the-number rehearsal, ready before your CV supplies the figures; covers F3 |
| D2 | "How would you tell whether a product operations team is making launches better rather than just busier?" | CASE | [generic] | Separate outcomes from activity. Name two or three candidate measures, say what each can mislead you about, and say which you would trust least and why. Start from what teams would notice, then pick what can be counted | Covers F3 and F2; CASE because it is a live measurement problem |
| D3 | "Two dashboards show different weekly active numbers for the same product. How do you find out which is right?" | CASE | [generic] | Clarify the definitions first: what counts as active, which window, which population. Then compare sources and time zones, check for duplication, and decide who owns the definition going forward. Say plainly what you could not tell from the data alone | Covers F3 |

### E. Conversational / Rapport Builder (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc in your own words, in order, with a reason for each move and ending at this role. Practice it aloud; it becomes story-mapped once I have your CV | The opener a friendly interviewer uses; scored anyway |
| E2 | "What are you reading or working on in product or operations these days?" | JD | [generic] | Name something real and specific, and say what you took from it. If nothing comes to mind, say so plainly and name what you would pick up first | A casual question about the field; scored for genuine interest |
| E3 | "What would success look like for you in the first year?" | JD | [generic] | Offer two or three outcomes tied to what the team needs, hedged by what you would learn in the first months. Say that you would test them with your manager | Covers F5; a friendly framing of a scored question |

### F. Values / Behavioral (weight lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, what you said, how it was received and what changed. Choose one where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F4; included because a final round can include a values conversation even if one is not documented |
| F2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a decision where the two conflicted, name the metric and the customer need, and say what you gave up. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F7; Stripe's published values are not established, so this stays generic |

### G. Pressure / Stress (weight lower)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then give the one or two things your own material says you bring, in your own words. Hold through two follow-ups; concede specifically what an internal candidate may know that you do not | A composure test; JD because it scores fit |
| G2 | "Product operations is just project management with a nicer title. Convince me otherwise." | JD | [generic] | Hold your position through two pushes: state the difference in one sentence, give one example of what the work changes beyond running tasks. Concede the overlap plainly and without folding on the core | Pairs with B3; covers F2 |

## 5. Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1 Cross-team launch coordination | A1, B4, E1 | |
| F2 Operating rhythms and process design | A1, A3, B3, D2, G2 | |
| F3 Data and measurement | A2, D1, D2, D3 | |
| F4 Influence without authority and senior communication | A5, C1, F1 | |
| F5 Prioritizing under ambiguity | A3, A5, C3, E3 | |
| F6 Tooling, documentation, scale | none, and why | No question asks about tooling in this pack: the requirement is role-family prose, and a tooling question would need your CV or the posting to premise it |
| F7 Knowing the products and customers | A4, F2 | |

No CV supplied, so there are no headline metrics for defend-the-number questions beyond D1's open prompt.

## 6. Reverse questions

Choose two or three, depending on who is in the room.

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What does a strong first six months look like for someone in this role, and how will you tell?" | It makes the success criteria explicit, so you can check your answers to E3 against them |
| R2 | "Where does product operations sit relative to the teams it supports, and where do decisions get made when they disagree?" | It shows you are thinking about the seam from C1 and gets the real answer |
| R3 | "What is the one thing about how launches or planning run today that you would most like fixed?" | It surfaces the actual problem the role is meant to solve and signals an operator's instinct |
| R4 | "What have people found hardest to get right in their first quarter here?" | It tells you what to watch for and shows you plan to avoid it |
| R5 | "How do you know product operations work is done well, and which part of that is measured?" | It shows you care about outcomes over activity, as in D2 |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | A reciprocity question, useful if the interviewer is a peer |

## 7. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any specific about your past work: figures, scope, ownership, stakeholders or outcomes | No CV or message from you states one, so any such detail would be invented | Your own words once you have shared them; until then, the answer slots and selection scaffolds above, each ending in an honest branch |
| Any fact about Stripe's values, process or strategy | No research ran; web search was refused | Nothing: A4 asks you to state only what you have verified yourself |

## 8. Sources

Provided documents: your request naming the role, the company and the round. No CV, job description or interviewer information was supplied.

Searches sent, all refused, none returned a result:

- "Stripe operating principles values" — refused
- "Stripe interview process Product Operations Manager" — refused
- "Stripe strategy news 2026" — refused
- "Stripe Product Operations Manager job description responsibilities" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Every call was refused. It would have fed a values cheat sheet and the Values bank |
| 2. Stripe interview process, product operations | unavailable | Every call was refused. It would have fed persona weights and whether a values round exists |
| 3. Stripe strategy and recent news | unavailable | Every call was refused. It would have fed grounded CO and CASE questions |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | The call was refused. It would have grounded the fit snapshot rows as `[inferred]` |

## 9. Upgrade menu

- Your CV or a few lines on your background: the seven worksheet rows become quote-grounded, guidance becomes story-mapped, and the highest-ROI objection is derived from your real gap instead of the working pick in B1
- The job description: the generic requirement rows become grounded, JD-tagged questions are re-pointed to the posting's own words, and F6 gets a question if the posting asks for it
- Who you are meeting and how the final is structured: if your final is several sessions, send the schedule and I will build per-session mini-packs with their own persona weights; a name adds an interviewer read and a tailored reverse question
- The recruiter's prep email, or anything it names such as focus areas, a presentation or a take-home: a take-home or presentation gets its own build section
- Search permission, then a research pass on Stripe's published values, documented interview process and current strategy: it grounds the CO and CASE questions and, if a values round is documented, adds a values cheat sheet; a deeper pass adds up to 6 further searches and 2 further fetches and takes several more minutes
- A `tuesday-dossier.md` from an earlier evaluation of this role: it would add verified evidence and claims to avoid, so the pack can be grounded and constrained without re-asking
