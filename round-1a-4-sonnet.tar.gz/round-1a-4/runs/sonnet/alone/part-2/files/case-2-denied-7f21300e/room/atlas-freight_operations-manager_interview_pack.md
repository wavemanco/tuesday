# Interview prep pack: Operations Manager, Atlas Freight

**Interviewer:** not known. **Round and relationship:** not known, so this is a full-loop pack with flat persona weights (the Generic archetype: screen, then hiring manager, then panel). Knowing the round would sharpen it; the upgrade menu says how.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows good judgment and values, asked as a behavioral prompt |
| EXP | Whether your background claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its level |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. Where a slot offers two branches, either honest branch is a good answer. The pack never writes your past for you.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift role over 3 supervisors in warehouse and distribution, plus one site's surge plan. It does not say terminals, and it does not say more than one site. The words stay there: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's 4 sites make a probe on working across sites or in a terminal likely. If you have, say where and what your part was, in your own words; if not, say so plainly and stay with the shift role you hold |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says mis-pick rate, not on-time performance or cost per shipment, with nothing inspected behind the figure. The words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names both measures, so expect a probe on what you track. If you track either, say what and what it showed, in your own words; if you track neither, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote says 3 and the JD says 12. The words stay at the quote: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have led more than 3 supervisors at any time, say when and how many, in your own words; if not, say so plainly and give the number as it is |
| F4 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" states a skill level, not what it produced, and the material is silent on reporting, so the bridge is not stretched. The words stay at the quote: "solid Excel." Answer slot: the JD pairs Excel with reporting, so expect a probe on what you have used it for. Say what, in your own words; if none of it was reporting, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to dashboard or Power BI work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | medium | [inferred] | discovery | The quote states seven years of operations work; the material does not show how many of them were spent leading people, and the JD's line is about leadership. Answer slot: expect a probe on when you began leading and for how long. Say when, in your own words; if the leading years are fewer than the JD asks, say the number plainly and stay with it |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap on the line itself, but a certificate the pack has not seen, so expect a probe on it. Lead with it in your own terms: "green belt certified." The quote does not name the scheme, so the pack names none |

## Persona table

Weights are flat: no round type, interviewer or loop source was available, so the pack falls back to the Generic archetype and says so. Bank depth instead follows where the fit snapshot is thinnest, so the Skeptic bank is deepest.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet probing of the distance between your role and this one: 3 supervisors against 12, one site against four, Power BI | Flat prior because the round is unknown. Deepest bank because F1, F3 and F5 are where the quotes sit furthest from the JD | Rehearse A2 until it is boring: put both numbers on the table yourself, then hold at the quotes |
| Data-Driven Prober (bank B) | Reads the 40% line and asks how it was counted | Flat prior. F2 holds the only figure in your material, so any prober reaches it | B1 and B2: the four slots a figure raises, plus naming the assumption you would defend least |
| Case / Strategist (bank C) | Live problems on on-time performance, the first 90 days, peak flex across sites | Flat prior. The JD makes daily operations the job, so a hiring manager would likely test it live | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Pressure (bank D) | Time-boxed or interrupted: "why you", "how much was you", the Power BI risk | Flat prior. The JD's scale (12 supervisors, 4 sites) is a natural place for a skip-level to press | Pause, restate, hold the quote through two follow-ups, concede only what is specific and true |
| Conversational (bank E) | A friendly opener and casual questions on the JD's plus-skills | Flat prior. Casual questions in any round are still scored | A 90-second arc built from your quotes; treat E2 and E3 as scored |
| Values / Behavioral (bank G) | Behavioral prompts | Flat prior. No published values were read and no loop source names a values round, so none is detected; these are the persona's standard stems | Selection scaffolds with an honest branch where nothing comes to mind |
| Peer Evaluator (bank H) | Seam-splitting between sites, credit across teams | Flat prior. The JD names 4 sites, so a site-level peer on the panel is plausible but unconfirmed | Propose seam principles instead of pretending to know the seam; "we" for context, "I" for contribution |

## Question banks

Highest-ROI prep in this pack: A2, the 3-supervisors-to-12 question. It will be asked in some form, and a rehearsed, non-defensive answer changes the interview.

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "currently a senior shift manager over 3 supervisors" | Name the gap before they do, choosing the one your material shows most plainly: "I have never used Power BI." Then a plan, said as a plan, with nothing in it that has already happened. If they press on scale, the words stay at your quote: "I'm currently a senior shift manager over 3 supervisors." One clear gap said calmly beats a list | The Skeptic's standard stem. F5 is the one gap with a stated negative, so it is the cleanest to name; F1 and F3 are handled in A2. JD because it scores the stated requirements |
| A2 | "This role leads 12 supervisors across four sites. Help me see how your current job gets you there." | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops" | Put both numbers on the table yourself before they do: "This role is 12 supervisors across 4 sites; I'm currently a senior shift manager over 3 supervisors, with 7 years in warehouse and distribution ops." Follow-up 1, have you led more than 3: answer slot, if you have, say when and how many; if not, say so plainly and return to the 3 you lead now. Follow-up 2, have you worked across sites: answer slot, if you have, say where and what your part was; if not, say so plainly and stay with the role you hold. Follow-up 3, so why you: hold on the quotes and never widen them, and give your first weeks as a plan, with nothing in it that has already happened. Hold through all three by returning to the quotes, never by adding to them | F1 and F3 are the widest gaps between the JD's numbers and your quotes, so this objection arrives in some form in any round that tests scale. JD because it scores the stated requirement; Skeptic delivery. Deepest rehearsal: three follow-up levels |
| A3 | "The reporting here is built in Excel and Power BI. Where are you with each?" | JD | [grounded] "solid Excel"; "never used Power BI" | Take the halves separately, each at its own scope. Excel: "solid Excel." Answer slot: the JD pairs Excel with reporting, so expect a probe on what you have used it for; say what, in your own words; if none of it was reporting, say so plainly and stay with "solid Excel". Power BI: "I have never used Power BI," then a plan, said as a plan. Do not describe a workbook or dashboard you did not build | F4 and F5 are the two halves of one JD line, and asking it as one line makes you separate them aloud. JD |
| A4 | "You've been on the shift side. Why is a bigger operations role the right step now?" | EXP | [generic] | Give your actual reason in your own words, in a sentence or two, about what draws you to work at this scale; the pack does not write it. Keep it about what pulls you toward this role, not about what is wrong where you are. If no clear reason comes to mind, say so plainly, then say what in the JD interests you | Motivation consistency is the Skeptic's other half: why here, why now. EXP because it tests the reason for the move, not a JD item; `[generic]` because it makes no claim about your past |
| A5 | "We need 5+ years of operations leadership. How many of your seven were leading people?" | JD | [inferred] "7 years in warehouse and distribution ops" | Start from the quote: "7 years in warehouse and distribution ops." Answer slot: the JD's line is about leadership years, so say when you began leading people and for how long, in your own words; if the leading years are fewer than the JD asks, say the number plainly and stay with it | F6 is a discovery row: the material states seven years of work, not seven years of leading. JD because it scores a stated requirement |

### Bank B: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that 40% was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the line at its scope: "I cut mis-pick rate 40% by redesigning the pick path." Then the four slots a figure raises, each in your own words: how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly. The pack supplies no baseline, period or method, and a method you cannot repeat under a second question is worse than none | F2's quote is the only figure in your material, so it is the magnet for any prober. EXP because it tests whether the claim survives scrutiny |
| B2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The weakest-assumption move: name, before they do, the assumption you would defend least, in your own words. If you do not know of one, say plainly that you do not know more about how the figure was counted than you have said. Do not name an assumption for effect | The Prober's standard stem; it converts a gotcha into a credibility gain. EXP, with the same row as B1 as its basis (F2) |
| B3 | "Mis-pick rate is a quality measure. What do you track on on-time performance and cost per shipment?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Keep the quote at its scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names both measures, so say which, if any, you track and what they showed, in your own words; if you track neither, say so plainly and say which you would look at first at Atlas | F2 bridges a quality measure to the JD's two measures, and this is the likeliest probe on it. JD content, Prober delivery |
| B4 | "How do you know, at the end of a shift, that it ran well?" | JD | [inferred] "currently a senior shift manager over 3 supervisors" | Answer slot: say what you look at to judge a shift, in your own words; if there is no fixed measure, say so plainly and say what you would put in place first. Do not name a measure you do not use | Daily operations ownership (F1) is scored on whether it is measure-driven. JD because it tests the stated duty |

### Bank C: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance at one of the four sites has slipped for two weeks. What do you want to know first?" | CASE | [generic] | Clarify first: which lane and shift, what changed, how on-time is defined and measured. Objective: restore on-time performance without raising cost per shipment. Segment: inbound, dock and yard, loading, outbound, staffing, equipment. Then approach, the metrics you would watch, and the risks. Challenge one premise, such as whether two weeks is a trend or noise. Think aloud. The case asks for no claim about your past | The JD's headline duty set as a live problem (F2's requirement). CASE; `[generic]` because it is a pattern for the problem, not a fact about this employer |
| C2 | "Sketch your first 90 days across the four sites." | CASE | [generic] | Clarify what has been asked of you and by whom. Then, as a plan: a per-site baseline of on-time performance and cost per shipment before any change; a conversation with each of the 12 supervisors; one fix small enough to land in the window and one named as longer; what you would report and to whom. Say it as a plan, not as something done | F1 and F3 together: a new person across four sites and twelve supervisors. CASE, `[generic]` |
| C3 | "Peak season is coming and volume will jump at all four sites. How do you plan for it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Open from the quote: "I ran the site's peak-season surge plan two years running." The beats the sentence states are the plan, that you ran it, and the two years; tell them in your own words and stop there unless asked. What the plan contained is yours to say from memory; the pack supplies none of it. Then give the four-site version as a structure (what you would clarify per site, what is shared, what is local), said as how you would approach it, not as something you have done | F1 is thin on scale, and the surge quote is the closest story to the JD's operations ownership. CASE delivery, EXP content |
| C4 | "What would you want on a daily dashboard for the four terminals?" | CASE | [generic] | Structure: the decisions it serves; the JD's two measures first (on-time performance, cost per shipment); the leading indicators behind them; who reads it and when; where the data comes from; how exceptions show. Tool-agnostic: say what you would want, and treat the tool question openly. The case asks for no claim about your past | F4 and F5: a design answer shows how you think about reporting without a claim about tools. CASE, `[generic]` |

### Bank D: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That mis-pick result — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause, restate the question, then hold the line: "I cut mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups. Answer slot: say which parts were yours and which were others', as specifically as you can, in your own words; if a part was not yours, say so plainly and say what was. Concede only what is specific and true, and never fold on the sentence itself | The Pressure stem for attribution. F2's figure is the one place a "how much was you" probe has something to bite. EXP |
| D2 | "Sixty seconds: why you over someone who already runs multiple terminals?" | JD | [grounded] "7 years in warehouse and distribution ops"; "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "currently a senior shift manager over 3 supervisors" | Three beats in your own words, each one a quote: the 7 years in warehouse and distribution ops; the surge plan you ran two years running; the mis-pick result. Hold them through a push. Do not compare yourself with the other person's record and do not claim terminal or multi-site work. Concede the scale difference by stating your role as it is: "currently a senior shift manager over 3 supervisors" | The time-boxed "why you" stem, aimed at F1 and F3. JD because it scores fit to the role |
| D3 | "You've never used Power BI and we report in it every day. Why take the risk?" | JD | [grounded] "never used Power BI" | Hold-then-concede. Concede plainly and first: "I have never used Power BI." Then hold, through two follow-ups, on a plan said as a plan: what you would do in your first weeks to get working in it and whom you would ask. Nothing in it that has already happened, and no course or project mentioned as done | F5 is the one stated gap, and the Pressure version tests whether you stay level when it is pushed. JD |

### Bank E: Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path" | A 90-second arc built from those four sentences. Choose an order that is true, join them in your own words, and end on your actual reason for this role, which the pack does not write. Practice it aloud to 90 seconds | The opener in a friendly round is scored for economy. EXP because it tests whether your account hangs together |
| E2 | "What do you know about Atlas Freight, and what drew you to us?" | CO | [generic] | Research could not run for this pack, so nothing here is about Atlas beyond the JD's own line: regional logistics, 800 employees, 4 sites. Read their own site and recent news before the interview and bring only what you actually found, with where you found it. Say what drew you in your own words. Do not hand the JD back as if it were research | The CO slot goes generic without research, which is the honest cost here. CO; `[generic]` |
| E3 | "You're green belt certified. What do you actually use from it these days?" | JD | [grounded] "green belt certified" | Say it as you did: "green belt certified." Expect them to ask which certification and what it covered; answer from the certificate itself, in your own words. Answer slot: the JD lists Lean/Six Sigma as a plus, so expect a probe on use. If you use any of it now, say what, in your own words; if the belt was training and not part of your current work, say so plainly. Claim only the use you can describe | F7 is a plus-skill asked casually, which is how the Conversational persona asks about them. JD |

### Bank G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time you told a senior person something they did not want to hear. It needs a named stake, what you actually said, and how the relationship stood afterward; choose one where the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's standard stem, since no Atlas values page was read. VAL; `[generic]` |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time a customer's need and an internal number pulled apart. It needs the two things in tension, what you chose, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona's second standard stem; in logistics it also touches the JD's on-time and cost measures. VAL; `[generic]` |

### Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our sites sit side by side. Where's the seam between them, and what happens when we disagree?" | CASE | [generic] | Do not pretend to know the seam. Offer principles: shared definitions of on-time and cost per shipment, a named owner for shared resources and for peak flex, a way to escalate a disagreement, and ask how it works today. Bring what you would offer them, not only what you would need | The JD names four sites, so seams between them are a live topic. CASE; `[generic]` |
| H2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Use "we" for context and "I" for your contribution. Pick a time work spanned teams; it needs what was yours, what was others', and how credit was said aloud. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer stem for credit-sharing. VAL; `[generic]` |

### Requirement coverage

| Requirement (source) | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" — JD | A1, A2, C1, C2, C3, D2, H1 |
| "drive on-time performance and cost-per-shipment down" — JD | B3, B4, C1, C4 |
| "lead a team of 12 supervisors" — JD | A2, C2 |
| "build reporting in Excel/Power BI" — JD | A1, A3, C4, D3 |
| "5+ years operations leadership required" — JD | A5 |
| "Lean/Six Sigma a plus" — JD | E3 |
| The one headline figure in your material (the 40%) | B1, B2, D1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance measured across the four sites today, and what is the current target?" | It is one of the two measures the JD names, and asking about the measure shows you think in the terms you would own |
| R2 | "Where does the daily reporting live today, and how much of the Power BI side is built versus still to be built?" | It lets you learn what the ramp really is on the tool you have not used, and reads as diligence on the JD's reporting line |
| R3 | "What does the supervisor team look like across the sites today, and where do you see the biggest gaps?" | It is aimed at the scale of the role (F3) and tells you what you would walk into |
| R4 | "What would a strong first 90 days look like, and what would you want learned by day 30?" | It turns the first-90-days case (C2) into a shared plan and tells you how success is judged |
| R5 | "What separates someone doing well in this role from someone struggling at six months?" | It surfaces the real bar without asking for reassurance |
| R6 | "How do peak periods get planned across the sites today, and who owns that plan?" | It opens the door to the surge-plan quote (F1) from the interviewer's side, and shows you think across sites |
| R7 | "Who else will I meet in the process, and what does each person look at?" | It fills the one structural gap in this pack (round and relationship unknown) and is a normal question for any candidate |

## Prohibited claims

What this pack will not coach, with its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Runs, or has run, terminal or multi-site operations | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says a shift role over 3 supervisors in warehouse and distribution and one site's surge plan, not terminals or more than one site. A2's slots stay inside the role you hold |
| Improved on-time performance or lowered cost per shipment | Inflated form of F2 | F2's quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." B3's slot asks only what you track |
| Led a team of 12 supervisors, or supervisors beyond the 3 you lead | Inflated form of F3 | F3's quote at its own scope: "I'm a senior shift manager over 3 supervisors." A2's slot asks only whether you have led more than 3, and allows no |
| Has used Power BI, or built dashboards or reports in it | Negative you stated, F5 | The plain acknowledgment F5 gives: "I have never used Power BI." No slot |
| The pick-path redesign was a Lean or Six Sigma project | A link between F2 and F7 that the material does not state | F2 and F7 at their own scope, separately. The pack observes the material does not connect them; no slot names it |

## Sources

Provided documents: the JD text you pasted and the background you described in your message. No dossier was present, so none was consumed.

Searches sent, each refused (the host did not grant search permission), so none returned anything:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news 2026" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have fed a values cheat sheet and the VAL questions; section 10 is dropped, and bank G uses the persona's standard stems |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have named the loop's rounds; persona weights rest on the Generic archetype and are flat |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have grounded the CO and CASE questions in current strategy; E2 and the CASE banks are `[generic]` |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Round type and who you are meeting (the recruiter's invite or an email to them) → the flat persona weights become specific, the banks are reweighted, and any pre-declared deliverable gets its own build section
- The interviewer's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their own path
- Search access (the three searches above were refused here) → Atlas Freight's values, documented loop and current strategy, which would ground E2 and the CASE banks; a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, can be run on your say-so
- Your answers to the slots in F1, F2, F3, F4 and F6 → those rows move from a thin bridge to a story you can rehearse, and their banks regenerate
- A before-and-after mis-pick report, or the surge plan document, for F2 and F1 → medium evidence confidence can rise toward high once something inspectable sits behind the figure
- Your green belt certificate for F7 → the scheme and level named from the document, not from the pack
- A `tuesday-dossier.md` from an earlier evaluation of this role → a named top objection and prohibited-claims guardrails in place of the ones inferred here
