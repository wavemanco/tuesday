I'll read the reference files the skill points to before building the pack.
Your prep pack is saved as `atlas-freight_operations-manager_interview_pack.md`. It has 20 questions across six interviewer styles, a fit snapshot, a "claims I won't coach" list, and reverse questions. I built it for a hiring-manager round, since you didn't say who you're meeting. Search permission was denied, so nothing in it is researched from Atlas Freight itself. The "why Atlas Freight" answer is a scaffold you fill in, and the Sources section shows the three refused searches.

The pack names A1 as your highest-ROI rehearsal: "You're over 3 supervisors today and this role has 12 across four sites. What changes?" The other likely probes are the Power BI gap, how much of your seven years was actual leadership, and how the 40% mis-pick figure was counted.

Say the word and I'll play the skeptical hiring manager on A1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is interviewing you (future manager, peer, recruiter or a panel), and did the recruiter mention any focus areas or something to prepare? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

- Role: Operations Manager (regional logistics, 800 employees, 4 sites)
- Interviewer: not given. Built for a hiring-manager round, assumed because the round type was not stated.
- Timing: interview next week

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script, and every claim about your past is a sentence you wrote, quoted next to it. Where the pack cannot know something, it leaves an answer slot for you to fill from memory in the interview.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your background survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

Sized to about a week. Do these in order; each is tied to a section or question.

1. A1, the highest-ROI rehearsal in this pack. Say it aloud until it is boring.
2. A4, then A3. The Power BI answer is a plain sentence plus a plan. If you learn some Power BI before the interview, say only what you have actually done by then.
3. C1 and E2. Work out, from memory, how the 40% was counted and which part was yours.
4. A2 and A5. Know your own answers on years of leadership and on scope beyond your current role.
5. B1, B2 and B4. Say each structure aloud once.
6. D1 and D2. Fix the 90-second arc, and pull two facts from Atlas Freight's own website.
7. Pick three reverse questions.

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is your own words, nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material shows a shift-manager role and a surge plan, and does not show terminal work or more than one site, so the words stay at that scope: "I'm currently a senior shift manager over 3 supervisors" and "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on scope likely. If your current role reaches more than one site, say how, in your own words; if it does not, say so plainly and stay with the role you hold |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is a mis-pick result, and your material does not show on-time or cost-per-shipment measures, so the words stay at that scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot for the figure: say how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours, in your own words; "I don't know how it was counted" is an honest answer. Answer slot: if you tracked other measures of your own work, say which; if not, say so plainly and return to the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors, and the words stay there: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's team-of-twelve line makes a probe on how you lead supervisors today likely. If you run a routine with your 3, say what it is, in your own words; if there is no set routine, or it is not yours, say so plainly and stay with the 3 |
| F4 | "build reporting in Excel/Power BI" — JD, Excel half | "solid Excel" — your message | low | [inferred] | discovery | "solid Excel" is a self-rating and does not show what it was used for. The probe here is derived from the JD's reporting line, and no past is written from it. The words stay at the rating: "I'd call my Excel solid." Answer slot: say what you have used Excel for and who relied on the result, in your own words; if it was a working tool and not something others relied on, say so plainly and stay with that |
| F5 | "build reporting in Excel/Power BI" — JD, Power BI half | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used Power BI." Then how you would get to working use, said as a plan in future tense and never as a past. Nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material gives seven years in operations and a current supervisory role, and does not show how many of the seven years were spent leading people. Answer slot: the JD's line makes a probe on that likely. Say which years were leading and in what role, in your own words; if only part of the seven was, say so plainly and state that part |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | discovery | "green belt certified" touches the requirement and does not show which program the belt was in or whether Lean was part of it. The words stay at the quote: "I'm green belt certified." Answer slot: expect a probe on the belt. Say which program it was in, and if you used it on any project, say what, in your own words; if the certification stands on its own, say so plainly and stay with it |

No row is a hard gate: the JD's 5+ years line is a length-of-experience requirement, graded like any other row.

## Persona table

Weights start from the hiring-manager prior, since the round type was not stated. No loop source established Atlas Freight's loop, so they rest on that prior and the fit snapshot, not on a documented process. Recalibrate if you know who is interviewing.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet, persistent probing of scale, years and tools | High. It is a hiring-manager prior, and F3, F1 and F6 are discovery or transferability rows with F5 a stated capability gap, so the probes have material | Rehearse A1 until boring: the quotes at their own scope, the difference said before they say it, the plan in future tense |
| Case / Strategist (bank B) | Live problems from the role: a slipping on-time number, rising cost, a peak surge | High. It is a hiring-manager prior, and the JD's central measures give an interviewer ready-made cases | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober (bank C) | Reads the background line by line; asks how the 40% was counted | Medium. F2 holds a headline figure, and figures are what probers go to first | Know what you can say about how the figure was counted and say plainly what you do not know; name the weakest assumption before they do |
| Conversational / Rapport Builder (bank D) | A friendly opener and motivation questions | Medium. Openers appear in most rounds, and casual questions are still scored | A 90-second arc built only from your own sentences; treat the casual questions on the JD's hot topics as scored |
| Pressure (bank E) | Time-boxed challenge: why you, how much was you | Low. It is not a hiring-manager prior, but F2's attribution probe can arrive in this register | Pause, restate, hold the position through two follow-ups, concede specifically |
| Peer Evaluator (bank F) | Seam-splitting between sites, shared resources, what you bring the team | Low. It matters only if other site leads meet you, and the relationship is unknown | Offer seam principles instead of pretending to know the seam; lead with what you bring |
| Values / Behavioral (no bank) | Stories mapped to published values | Low. No loop source documents a values round, and no published values are in hand | None until a values page or loop description exists; see the upgrade menu |

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This role has four sites and a team of 12 supervisors, and you're over 3 today. What changes at that scale?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Open at the quote's scope: "I'm currently a senior shift manager over 3 supervisors." Say the difference out loud before they do: three supervisors today, twelve in this job. Then give the plan in future tense and in your own words: how you would get to know each site and each supervisor first, and what you would put in place. The pack supplies none of those specifics. Answer slot: expect a probe on how you lead supervisors today. If you run a routine with your 3, say what it is, in your own words; if there is no set routine, or it is not yours, say so plainly and stay with the 3. Hold through two follow-ups by returning to your three, never by adding to them | F3 is the widest distance between your quote and the JD, with F1 beside it, so this question will arrive in some form. JD because it scores the stated team requirement |
| A2 | "The role asks for five-plus years of operations leadership. How much of your seven years was that?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Start with the quotes at their scope: seven years in warehouse and distribution ops, and a current role as a senior shift manager over 3 supervisors. Answer slot: say which of the seven years were leading people, and in what role, in your own words; if only part of the seven was, say so plainly and state that part; if most of it was hands-on, say so plainly and return to your current role. Do not round the leadership years up to seven | F6 is a discovery row: the material shows the years, not how many were leading. JD because the requirement is the posting's own, and it is the likeliest screen question after A1 |
| A3 | "What have you used Excel for in your operations work?" | JD | [inferred] "solid Excel" | Say the rating at its own scope: "I'd call my Excel solid." Answer slot: the JD asks for reporting in Excel and Power BI, so expect a probe on what the Excel was used for. Say what it was, in your own words, and who relied on the result; if it was a working tool and not something others relied on, say so plainly and stay with that. No report, dashboard or model is named here because none is in your material | F4 is low-confidence and a discovery row, so the pack asks and does not assert. JD because it covers the Excel half of the reporting line; inferred because the probe is derived from the JD |
| A4 | "The reporting here is built in Excel and Power BI. You've never used Power BI, so how do you get to working use, and how fast?" | JD | [grounded] "never used Power BI" | Say the plain sentence first: "I have never used Power BI." Then the plan, in future tense: what you would learn first, who you would ask, and how you would judge that you had reached working use. Name a timeline only if you can stand behind it. If you spend time on Power BI before the interview, say only what you have actually done by then. Never present the plan as a past | F5 is a gap you stated, so the honest move is to rehearse the sentence and the plan until neither sounds defensive. JD because Power BI is half of a listed requirement |
| A5 | "This role owns daily terminal operations across four sites. Where's the distance between that and your job today?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | Lead with your two sentences at their scope: "I'm currently a senior shift manager over 3 supervisors" and "I ran the site's peak-season surge plan two years running." Answer slot: the JD says terminal operations across four sites, so expect two probes. If your work has included terminal or cross-dock settings, say so, in your own words; if not, say so plainly and say what in your daily work carries over. If your current role reaches more than one site, say how; if it does not, say so plainly | F1 pairs a scope gap with a setting gap, and a hiring manager owns this one personally. JD because it scores the first line of the posting |

### Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance has slipped at one of the four sites over the last two weeks. Walk me through your first day." | CASE | [generic] | Clarify first: how on-time is defined here, which lanes and customers, since when, what else changed. Then the objective (stop the slide, find the cause), a split by shift, lane, customer and day, a short list of hypotheses, the data you would pull, one quick containment step against one root-cause step, who you would talk to on the floor, and what you would report back and when. Think aloud and challenge one premise respectfully. This is structure for a live problem and claims nothing about your past | The JD's on-time line (F2's requirement) turns into a live case in a hiring-manager round. CASE because it scores structure, not experience |
| B2 | "Cost per shipment has crept up for a quarter across the network. Where do you look first?" | CASE | [generic] | Clarify the measure: what counts in the numerator, what in the denominator, whether it is a rate, mix or volume effect. Then split the cost into its drivers, separate what moved from what stayed flat, and form two hypotheses you can test fast. Say what you would pull, who owns each driver, and which fix is quick against which is structural. Name the risk of cutting cost at the expense of on-time. Claims nothing about your past | The other half of the JD's measures, asked as a decision. CASE because the interviewer scores the split and the sequencing |
| B3 | "Peak season is coming and two of the four sites will run well over plan. How do you plan for it?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Open with the quote as context only: "I ran the site's peak-season surge plan two years running." Then build the network version as structure: clarify the forecast and service commitments, set the objective, segment the sites, choose the levers, set triggers and checkpoints, name the risks. Say it as the plan for this network, not as a replay of yours. What was in your plan, and how it went, is yours to tell from memory; the pack has none of it | F1 holds the surge-plan quote, and a hiring manager can turn it into a live problem. CASE because it scores planning at a larger scale; the quote is the entry point only |
| B4 | "Walk me through how you would run the day across four sites. What do you look at first, and who do you call?" | CASE | [generic] | Structure it as a daily rhythm you would set up: a start-of-day exception review across the sites, a way of ranking which site needs you, supervisor check-ins at set points, escalation rules, an end-of-day close and one number per site you would watch. Say what reporting you would want in front of you and, in future tense, how you would build it. Claims nothing about your past | F1's four-site line is the part of the role your material shows least. CASE because it scores how you would organise time and attention, which no quote can answer |
| B5 | "How would you use Lean or Six Sigma in a regional freight network, and where would you start?" | JD | [grounded] "green belt certified" | Say the quote: "I'm green belt certified." Then the approach as structure: pick one process with a measurable problem, define it and baseline it, find the cause with the people who run it, test a fix at one site first, then standardise. Answer slot: expect a probe on the belt. Say which program it was in, and if you used it on any project, say what, in your own words; if the certification stands on its own, say so plainly and stay with it | F7 is a discovery row for a plus requirement. JD because the posting names it; the structure is generic and the claim is only the quote |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Then the four slots, each in your own words: how it was counted, what it is sensitive to, which assumption you would defend least, and which part was yours. Name the weakest assumption before they do. If you do not know how it was counted, say so plainly instead of reconstructing a method. The pack names none of these for you | F2's figure is the one every prober goes to first. EXP because it tests whether the number survives and who it belongs to |
| C2 | "We measure on-time performance and cost per shipment. What did you track in your current job?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Start with the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: expect a probe on measures beyond mis-pick rate. Say which ones you tracked, and how each was counted, in your own words; if you tracked none beyond it, say so plainly and return to the mis-pick result | F2's requirement is a pair of measures the material does not show. JD because it scores the stated job measures; the slot keeps the answer inside what you tracked |
| C3 | "Walk me through the surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | The quote carries three beats: you ran it, it was the site's peak-season plan, and it was two years running. Tell those in your own words. The pack holds nothing about what was in the plan, how it went or who else contributed, and the interviewer will ask each. Rehearse your own answers aloud from memory; if you do not remember, or it was not yours, say so plainly | F1 holds this quote and a prober will want the denominator behind it. EXP because it tests what was actually yours |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc in three beats: "7 years in warehouse and distribution ops", then "currently a senior shift manager over 3 supervisors", then your own reason for this role, in your own words, since the pack has none to give. End on the role, not the history | F6 and F3 carry the only background in the pack, so the arc is built from them alone. EXP because it frames everything that follows |
| D2 | "Why Atlas Freight?" | CO | [generic] | No verified company facts are in this pack. Choose two reasons: one from the JD's own lines that you actually want, such as the four-site scope or the supervisor team, and one fact you read on Atlas Freight's own website or in recent news before the interview. If no reason comes to mind, say so plainly and say what draws you to the role as written | The research behind this question was not available, so it is a selection scaffold, which the upgrade menu says how to upgrade. CO because it scores homework |
| D3 | "Tell me about a time you had to get a supervisor to change how they worked." | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Pick one instance with your 3 supervisors that has a named stake, what you actually said or did, and how the working relationship stood afterwards. Use "we" for context and "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The JD's supervisor-team line (F3's requirement) is the theme. EXP because it scores a past instance, and the pack supplies none |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who already runs several sites?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | Pause and restate the question. Hold: choose one or two of your quotes and say them at their own scope. Concede specifically: your team today is three supervisors, against twelve in this job. Do not claim you would outperform them, and do not fold on the core. Three or four sentences fit the minute | F1 and F3 are the gaps this question leans on. JD because it scores fit against the posting under time pressure |
| E2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Hold through two follow-ups by returning to what the quote says. Answer slot: say which part was yours and who else contributed, in your own words; if the redesign or the result was shared, or not yours alone, say so plainly. Concede what you do not know, such as how it was counted, specifically (C1) | F2's figure with an attribution probe on it. EXP because it tests precise credit |

### Bank F: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Two sites both need the same trucks or extra labor on the same day. How do you decide, and what happens when the other site lead disagrees?" | CASE | [generic] | Offer principles rather than pretending to know the seam: a visible rule for priority, such as customer commitments first, data on the table, a clear escalation point, and a debrief afterwards. Show spine and tact together. Claims nothing about your past | F1's four-site line makes shared resources a live problem. CASE because it scores how you decide and disagree |
| F2 | "What could you do in your first month that would help the people you would work alongside, rather than what you need from them?" | JD | [generic] | Frame it as reciprocity: what you would take off their plate, what you would make visible, what you would ask for in return. Keep it to plans in future tense. Claims nothing about your past | A peer prices what the hire costs them. JD because it scores the collaborative part of owning several sites |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A5, B4, F1 |
| "drive on-time performance and cost-per-shipment down" | B1, B2, C2 |
| "lead a team of 12 supervisors" | A1, D3 |
| "build reporting in Excel/Power BI" | A3, A4 |
| "5+ years operations leadership required" | A2 |
| "Lean/Six Sigma a plus" | B5 |
| The 40% mis-pick figure, as a headline metric | C1, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance defined here, and where does it stand against target today?" | It shows you ask for the definition before the number, and you leave knowing what you would be measured on |
| R2 | "Which of the four sites would you hand me first, and why?" | It signals ownership and tells you where the hardest problem is |
| R3 | "What does reporting look like today across Excel and Power BI, and who builds it?" | It puts the reporting question on the table and shows how much you would build against consume |
| R4 | "What would the twelve supervisors say about how they are led today?" | It shows you are thinking about the team before changing anything |
| R5 | "What would success look like at 90 days and at a year, on the two measures in the posting?" | It turns the JD's measures into targets you can plan against |
| R6 | "What is the biggest operational risk across the four sites in the next twelve months?" | It shows you think about risk and lets the interviewer talk about what worries them |

## Prohibited claims

What this pack will not coach, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team of twelve supervisors | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says 3 supervisors. A1's slot stays with the 3 |
| Owned terminal operations across four sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: your material shows a shift-manager role and a surge plan, not terminal work or more than one site |
| Drove on-time performance and cost per shipment down | Inflated form of F2 | F2's quote at its own scope: the mis-pick result. C2's slot asks only what you tracked |
| Redesigned the pick path single-handedly | Inflated form of F2 | F2's quote at its own scope. E2's slot asks which part was yours |
| Built reporting or dashboards in Excel | Inflated form of F4 | "solid Excel" at its own scope. A3's slot asks only what it was used for |
| Has used Power BI | Negative you stated, F5 | The plain acknowledgment F5 gives: "I have never used Power BI." No slot |
| Five-plus years leading operations teams | Inflated form of F6 | F6's quotes at their own scope. The limit is the pack's observation: your material gives seven years in operations, not how many were leading |
| Used Lean or Six Sigma to deliver the mis-pick result | Inflated form joining F7 and F2 | Each quote at its own scope, with no link between them. B5's slot asks only about the belt |

## Sources

Provided documents: the job description text and your background, both pasted in your message.

Searches sent, none returned:

- "Atlas Freight regional logistics company values": refused
- "Atlas Freight interview process operations manager": refused
- "Atlas Freight regional logistics strategy news 2026": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Every call was refused. It would have fed a values cheat sheet, if a values round was documented, and D2 |
| 2. Atlas Freight interview process, operations manager | unavailable | Every call was refused. It would have fixed the loop and the persona weights, which now rest on the hiring-manager prior |
| 3. Atlas Freight strategy and recent news | unavailable | Every call was refused. It would have grounded D2 and added strategy-based CO and CASE questions |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who is interviewing you, and whether it is a recruiter, hiring manager, peer or panel → persona weights re-ranked, banks added or dropped
- The recruiter's prep email, if one exists → any focus areas or pre-declared task, which would get its own build section
- The interviewer's name → a short read of their public career path and a reverse question tied to it
- Search access, or Atlas Freight's values page and a recent news item pasted in → D2 and the CO questions become grounded, and a values cheat sheet if a values round is documented. A deeper research pass of up to 6 more searches and 2 more fetches, taking several more minutes, can be offered once search is available
- Your answers to the slots in F1, F2, F4, F6 and F7, typed into this chat → those rows regenerate on your own words, and the confidence on F2, F4 and F6 can rise
- A before-and-after mis-pick report, or whatever scorecard recorded the 40% → F2 can move from medium to high, with the strongest defence for C1 and E2
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence, allowed strategies for the weak rows, and any prohibited claims already recorded
