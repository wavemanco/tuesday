I'll start by reading the skill's reference files.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-3-denied-1d3d0f59/stripe_product-operations-manager_interview_pack.md`. I built it for a final round with flat persona weights, because I don't know who you're meeting or how many sessions there are. The host refused all four of my research searches, and you gave me no JD or CV. So nothing in it is specific to Stripe or to you. Every question is labeled generic, and anything about your own history is a scaffold for you to fill in. The pack's Sources section lists the refused searches and what each would have added.

The question to rehearse first is B1, "Which part of this role would you be weakest at on day one?".

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in this round (future manager, peer, skip-level, cross-functional), and did the recruiter mention focus areas or a deliverable to prepare? The answer reweights every question bank.

Can you paste the job description and a CV or a few lines on your background? I'll proceed without them if you'd rather, but they would turn the generic scaffolds into answers built on your own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe — Product Operations Manager: final-round interview pack

- Company and role: Stripe, Product Operations Manager
- Round: final round; the number of sessions, the interviewers and their relationship to you are not known
- Interviewer: not given
- Built from: your message only (company, role, "final round"). No JD, no CV, and the four research searches were refused by the host, so nothing here is specific to Stripe or to you. Every row is labeled to say so

## How to use this pack

Personas describe how a question is asked; types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

Type key:

- VAL: behavioral and values alignment, past behavior against published values
- EXP: work-experience deep-dive, whether your claims survive scrutiny
- JD: role-driven, whether you can do the listed job, gaps included
- CO: company and strategy knowledge
- CASE: a live problem from the role, delivered on the spot

Persona weights are flat. No source establishes this loop, so the weights rest on the generic fallback pattern (flat weights, no values-style round assumed), not on a documented Stripe process. If your final is several sessions, the schedule would let this become per-session mini-packs.

## Fit snapshot (worksheet)

You gave no CV and no background, so this is the worksheet variant: every evidence cell is `none given`. The requirements are role-family patterns written without a source, not quotes from a posting. Each row says what strong evidence looks like, then gives a selection scaffold you can run against your own history.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating a launch or program across product, engineering and go-to-market teams (role family, no source) | none given | none | [generic] | discovery | Strong evidence names the program, who it spanned and what you personally drove. Selection scaffold: pick a time you kept several teams moving toward one date; it needs a named program, a point where teams disagreed, and your own part in it. If no such time comes to mind, say so plainly, then give the nearest work your material does carry, or how you would handle it |
| F2 | Defining and tracking operating metrics for product health (role family, no source) | none given | none | [generic] | discovery | Strong evidence names the metric, how it was counted and what was yours. Selection scaffold: pick a number you reported or owned, with its definition, its source and the assumption you would defend least. If no such number comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set the first metric |
| F3 | Building or improving planning and review cadences (role family, no source) | none given | none | [generic] | discovery | Strong evidence names the cadence, who attended and what changed afterwards. Selection scaffold: pick a recurring process you set up or reshaped, with who it served and what it replaced. If no such process comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would design one |
| F4 | Turning data into a recommendation for product leadership (role family, no source) | none given | none | [generic] | discovery | Strong evidence is a recommendation you made, the data behind it and what was decided. Selection scaffold: pick an analysis that ended in a recommendation, with your own part in it. If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would structure one |
| F5 | Influencing teams you do not manage (role family, no source) | none given | none | [generic] | discovery | Strong evidence names the disagreement, the people involved and what moved. Selection scaffold: pick a time you changed a plan without authority over the people doing it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

No requirement here is a gate. A posting's terms on location, schedule or work authorization would become gate rows once a JD is in hand.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from product operations work: diagnose, plan, standardize | Flat: no relationship or loop source given | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of gaps, motivation, why here and why now | Flat: no relationship or loop source given | Rehearse the most predictable objection until it is boring; use only adjacent evidence you actually have, or say the limit plainly |
| Values / Behavioral | Scenario probes, STAR-shaped stories | Flat: no loop source documents a values round, so none is assumed | Use "we" for context and "I" for contribution; pick stories where the hard truth actually landed |
| Peer Evaluator | Seam-splitting with adjacent teams, credit and disagreement | Flat: relationship unknown | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober | Definitions, denominators, assumptions | Flat: no CV figures to probe yet | Know how each number was counted, say plainly when you do not, name the weakest assumption first |
| Pressure | Interrupts, time-boxes, devil's advocate | Flat: relationship unknown | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational | Friendly, unstructured, still scored | Flat: relationship unknown | Prepare a 90-second arc; treat casual questions about the role as scored |

## Question banks

All 21 questions are `[generic]`: they rest on persona patterns, not on a JD, your CV or Stripe research. Where guidance would say something about your past, it is a selection scaffold or an answer slot, never a claim.

The highest-ROI prep in this pack is B1. Some form of "where would you be weakest" is the most predictable question for any final round, and once you share a CV its rows will make it specific to you.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch has slipped twice and three teams each say the blocker sits with someone else. How do you find out what is actually blocking it, and what do you need to know first?" | CASE | [generic] | Clarify before structuring: what the launch must achieve, who owns each dependency, what changed between the two slips. Then separate facts from each team's account, name the one blocker to remove first, and say how you would keep the teams aligned afterwards. Challenge one premise aloud, such as whether the date itself is right | A live problem from F1's requirement; CASE because it scores structure, and it makes no claim about your past |
| A2 | "A weekly product health metric drops 20 percent overnight. Diagnose it." | CASE | [generic] | Check measurement before cause: did the definition, the data pipeline or the population change. Then segment by customer type, region and release, form two or three hypotheses, say what data would separate them and what you would report to leadership before you know | A diagnosis problem from F2 and F4's requirements; the order of checks is what is scored |
| A3 | "Leadership wants one operating cadence for twenty teams that all work differently. What do you set up, and what do you refuse to standardize?" | CASE | [generic] | State the objective the cadence serves, then the smallest shared structure that serves it. Name what you would leave to teams and why, how you would test it with a few teams first, and how you would know it is working | F3's requirement as a design problem; the refusal half tests judgment about where process stops helping |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Selection scaffold: choose a real gap, one a good interviewer would believe, and name it in a sentence. Then give a concrete ramp plan: what you would learn first, from whom, and by when. If no gap comes to mind, say so plainly, then name where your material is thinnest, or how you would find out. Never pick a fake weakness | The most predictable objection in any final round, so the deepest rehearsal: rehearse it with two follow-ups until the answer is calm and specific. JD because it scores the role's requirements against self-assessment |
| B2 | "Why product operations, and why now?" | EXP | [generic] | Selection scaffold: two or three true sentences on what drew you to this kind of work and what changed to make now the time, in your own words and consistent with your CV. If your reasons are mixed, say so plainly rather than tidying them | Motivation consistency is what the Skeptic scores; EXP because the answer must match your actual path |
| B3 | "Why Stripe rather than another company?" | CO | [generic] | Use only reasons you can trace to material you have read yourself, and say them in two sentences. This pack could not research Stripe, so it supplies no company facts. If your reasons are mostly about the role, say so plainly and say what draws you to the work | CO because it scores homework depth; generic here because the company research was refused |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship that was intact at the end; use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values probe for F5's requirement; no published Stripe values were available, so it is not mapped to any |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two pulled apart, say what you weighed and what you chose, and say what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona-pattern question; VAL because it scores behavior over stated virtue |
| C3 | "A teammate's launch plan has a risk you think is being under-weighted, and they outrank you. What do you do?" | VAL | [generic] | Say what you would check first, how you would raise it, with what evidence, and to whom. Say what you would do if the answer is no. This is a live scenario, so it asks nothing about your past | CASE-shaped VAL for F1 and F5's requirements; it scores disagreement style without presupposing a story |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know this team's seam: who owns the decision, who owns running it, how disagreements are surfaced early. Ask what the seam looks like today, and say you would adjust to it | Scores turf awareness; relevant to F1 and F3's requirements |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | State your principle in a sentence. If you give an example, take it from your own material and tell it in your own words, "we" for the team and "I" for your part. If no example comes to mind, say so plainly and describe how you would handle it | A collegial form of the attribution probe; F5's requirement |
| D3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Answer both halves: what you would need to learn and from whom, then one thing you could offer early that fits what you know of their work. Keep the offer modest and tied to what you have actually done | The reciprocity probe; scores whether the hire adds or reduces the peer's load |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You are setting the one number at the top of a product operations review. Walk me through how it should be counted." | CASE | [generic] | State what decision the number serves, its exact definition, its source, its denominator and what would make it misleading. Then say who would review the definition and how often | F2's requirement as a live problem; scores whether you know what a figure is sensitive to |
| E2 | "Which assumption behind that number would you defend least?" | CASE | [generic] | Name the weakest assumption yourself, in one sentence, and say what you would check to firm it up. Naming it before the interviewer does is the credibility gain | The follow-up the Prober always asks; rehearse it with E1 |
| E3 | "Walk me through how a number you reported was counted." | EXP | [generic] | Selection scaffold: pick one figure that was yours. Cover how it was counted, what it is sensitive to, the assumption you would defend least, and which part of any movement was yours. If you do not know how a figure was counted, say so plainly. If no such figure comes to mind, say so, then give the nearest thing your material does carry | Headline metrics on a CV are where Probers dig; this pack has no CV yet, so it is a scaffold. F2's requirement |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, then give one point you can support from your own material, in one sentence, and stop. If pressed, hold it through two follow-ups, then concede specifically what you do not know about the team | Scores composure, not content; hold-then-concede is the structure |
| F2 | "You have been talking for two minutes and I still do not have your point. What is it?" | JD | [generic] | Restate the question in one sentence, then give the answer first and the reason second. Do not apologize at length | Tests whether you can compress under interruption |
| F3 | "I am not convinced product operations adds value rather than process. Convince me." | JD | [generic] | Hold your position through two follow-ups: say what the function is for, in terms you can defend. Then concede specifically where process overhead is real, and say how you would tell the two apart | A devil's-advocate probe of the role itself; hold-then-concede structure |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc in three beats taken from your own CV: where you started, the turn, why this role. Build it once you have the CV in hand; this pack cannot write it for you | Casual openers are scored; the arc must match your actual path |
| G2 | "What are you actually playing with these days in the tools or methods your work touches?" | JD | [generic] | Pick one thing you really use or study and say why it interests you. If nothing comes to mind, say so plainly and name what you would want to learn first | A casual question about the craft, still scored |
| G3 | "What does a good week look like for you in a role like this?" | JD | [generic] | Describe the rhythm you would aim for: what you would protect time for, whom you would talk to, what you would produce. Keep it to what you could do, not what you have done | Scores genuine interest and communication economy |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 Coordinating across teams | A1, C3, D1 |
| F2 Operating metrics | A2, E1, E2, E3 |
| F3 Cadences and process | A3, D1 |
| F4 Data into recommendations | A2, E1, F3 |
| F5 Influencing without authority | C1, C3, D2 |
| Motivation and fit (not a requirement row) | B1, B2, B3, F1, G1 — none map to an F row, because they probe fit rather than a requirement |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would success look like in this role after the first ninety days?" | It shows you are thinking about outcomes, and the answer tells you what the team is actually scoring |
| R2 | "Where does work most often get stuck between product, engineering and go-to-market teams?" | It shows you have seen the problem product operations exists for |
| R3 | "Which decision from the last year would you make differently now?" | It invites candor and reveals how the team learns |
| R4 | "What do the people who do well in this team do that others miss?" | It names the unwritten bar and signals you are preparing to meet it |
| R5 | "How does the team decide which efforts get operational support, and what happens to the ones that do not?" | It tests whether prioritization is deliberate, which matters for this role |
| R6 | "If you are a peer: what could a new person do in their first month that would genuinely help your team?" | The reciprocity question, only if the interviewer turns out to be a peer; it shifts the conversation from interrogation to partnership |
| R7 | "What happens after this round, and when should I expect to hear?" | A practical close that avoids the "no questions" signal |

Never answer "I think you've covered everything" in this slot. None of these assumes a fact about Stripe; replace them with sharper ones once research is possible.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None built | You gave no sentences about your past, so there is no wording to inflate and nothing stated to contradict. A claim about your experience that does not come from your own words is not coached anywhere in this pack | Where a question touches your history, the guidance is a selection scaffold or answer slot: say what you did, in your own words, and if it was not yours or never happened, say so plainly |

## Sources

Provided documents: your message (company, role, round). No dossier, JD or CV.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Search refused. Would have supplied official value names for a cheat sheet and VAL mapping; none shown, none from memory |
| 2. `Stripe interview process product operations` | unavailable | Search refused. Would have documented the loop and tuned persona weights; the generic fallback with flat weights stands in, and no values-style round is assumed |
| 3. `Stripe strategy` / recent news | unavailable | Search refused. Would have grounded CO and CASE questions in current priorities; they are generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | Search refused. Would have supplied quoted `[inferred]` requirements; F1 to F5 are unquoted role-family prose instead |

Searches sent, all refused: "Stripe operating principles values"; "Stripe interview process product operations manager"; "Stripe strategy news 2026 annual letter"; "Stripe Product Operations Manager job description".

## Upgrade menu

- The JD text → F1 to F5 become quoted requirements, JD-tagged questions become `[grounded]`, and any gate it states (location, schedule, work authorization) becomes a gate row
- Your CV or a few lines on your background → every fit-snapshot row gets quoted evidence, the scaffolds in B1, B2, C1 to C3, D2, E3 and G1 become story maps, and the highest-ROI objection becomes specific to you
- Who you meet and their relationship to you (manager, peer, skip-level, cross-functional), plus any recruiter guidance on focus areas or a pre-declared deliverable → persona weights stop being flat, and a graded-deliverable build section is added if a deliverable was named
- The interviewers' names → a reading of their public professional path and a reverse question tied to it
- The final-round schedule, if it is several sessions → per-session mini-packs with their own persona weights
- Search access for this session, or Stripe's values page and a strategy brief pasted in → official value names for a cheat sheet and values-mapped VAL questions, a documented loop, and CO questions grounded in current strategy
- A deeper research pass, offered once (up to 6 more searches and 2 more fetches, several more minutes), if searches are permitted → a strategy brief, interviewer footprint and role-family loop reports
- How much prep time you have → a prioritized schedule of the few things to do well, in order
- A tuesday-dossier.md from the job-underwriter skill → evidence-derived objections and fixed limits on what the pack may claim for you, in place of the inferred ones here
