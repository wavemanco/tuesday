I'll start by reading the skill's reference files.
I've built the prep pack and saved it as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-2-denied-6045acef/atlas-freight_operations-manager_interview_pack.md`. It has 22 practice questions across seven interviewer styles, a table of your experience against each JD requirement, and reverse questions to ask them.

I didn't know who you're meeting, so I built it for an unknown round and kept the interviewer-style weights close to flat. Web search wasn't permitted in this session, so nothing in it is researched about Atlas Freight itself. The company-specific parts (values, interview loop, strategy) are missing, and the pack says so.

The question to rehearse most is A1: you lead 3 supervisors today and the role has 12 across four sites. The pack also treats Power BI (you haven't used it) and on-time and cost-per-shipment (your pick-path result is on mis-picks) as likely probes.

Say the word and I'll play the skeptical interviewer on A1 and push back on what you say. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the person you're meeting your future manager, a peer or site lead, or a recruiter, and did anyone tell you what they'll focus on? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
- **Interviewer and relationship:** not known. The pack is a full-loop pack with close-to-flat persona weights, which is noticeably weaker than one built for a named round.
- **Built from:** the JD text and the background you gave in your message. No company research was possible (see Sources).

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: no research ran) |
| CASE | A live problem from the role, reasoned aloud |

Provenance labels: `[grounded]` rests on your own words or a provided document; `[inferred]` is this pack's derivation; `[generic]` is a role-family pattern with no claim about you or Atlas Freight.

**Highest-ROI prep: A1.** The step from leading 3 supervisors to a team of 12 across 4 sites is the objection most likely to be asked in some form. A3 and C3 are next.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift and a surge plan, and does not show whether any of the work was terminal work. Words at their own scope: "I'm currently a senior shift manager over 3 supervisors" and "I ran the site's peak-season surge plan two years running." Answer slot: the JD's terminal wording makes a probe likely. If any of that work was terminal work, say which and what part was yours, in your own words; if none was, say so plainly and stay with the shift and the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material says mis-pick rate, not on-time performance or cost per shipment. Words at their own scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked either measure, say what you counted and how, in your own words; if you tracked neither, say so plainly, stay with the mis-pick rate, and say what you would measure first here |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says 3 supervisors and the JD says 12. Words at their own scope: "I'm currently a senior shift manager over 3 supervisors," and, comparing it with the JD, "The team here is larger than the one I lead today." Answer slot: say the most people you have led at once, in your own words; if that is the 3, say so plainly and stay with the 3 |
| F4 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | medium | [grounded] | discovery | Your material gives 7 years in operations and does not show how many were spent leading people. This is a length-of-experience requirement, not a gate, so it is graded like any other row. Words: "I have 7 years in warehouse and distribution ops." Answer slot: say how many of those years you led others, in your own words; if some were not spent leading, say so plainly and stay with your current role |
| F5 | "build reporting in Excel/Power BI" — JD | "solid Excel" — your message | low | [inferred] | discovery | "solid Excel" gives a skill level, not what was done with it. Answer slot: a probe on what the Excel work actually was is likely. Say what you have used Excel for, in your own words; if the use was not for anything others relied on, say so plainly |
| F6 | "build reporting in Excel/Power BI" — JD | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. The JD's slash does not say whether both tools are needed on day one; reverse question R3 asks |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap: the quote already reaches the requirement. Lead with it in its own terms: "I'm green belt certified." Expect a probe on what it was applied to; D2 rehearses it |

## Persona table

No loop source established the loop, so the fallback is the generic archetype (screen, hiring manager, panel) with flat weights. Depth below tilts toward Skeptic and Case only for the reasons shown; change it if you learn the round.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet, persistent probing of the scale and scope gaps | Higher: F1, F3 and F4 are the widest gaps against the JD, and this style presses exactly there | Rehearse A1 until it is boring: hold what the quotes carry, concede the specific limit, never fold on the core |
| B. Case/Strategist | Live problems from the job: on-time, cost, surge, a new team | Higher: the JD's duties are operational and case-shaped; with no relationship given this is a reading, not a fact | Clarify, then structure aloud; use the cases as live reasoning, not as recall of past events |
| C. Data-Driven Prober | Reads the 40% line by line; asks about Excel and Power BI | Moderate: F2 is the only figure in the material | Know what you can and cannot say about how the 40% was counted, and say plainly when you do not know |
| D. Conversational | A friendly opener and casual questions that are still scored | Moderate: the round is unknown, and any first conversation can open this way | Prepare the 90-second arc in D1 from the quotes it names; treat D2 as scored |
| E. Peer Evaluator | Seams between sites, credit, what you need from other site leads | Moderate: the JD names four sites, so site leads may be in the loop; nothing says they are | Offer principles, not a pretended knowledge of the seams; frame what you would give as well as need |
| G. Pressure | Interrupts, time-boxes, challenges attribution | Lower: nothing in the material points to a stress style | Pause, restate, hold through two follow-ups, concede specifically |
| H. Values/Behavioral | Scenario probes, STAR-shaped stories | Lower: no loop source documents a values round and no published values were read | Pick real instances using the scaffolds; take the honest branch where none comes to mind |

(Bank G and H follow E; the letter F is left unused so question IDs never collide with fit rows F1 to F7.)

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You lead 3 supervisors today and this role has 12, across four sites. What's the hardest part of that step for you?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | The highest-ROI rehearsal in the pack. Hold only what the quotes carry: "I'm currently a senior shift manager over 3 supervisors" and "I ran the site's peak-season surge plan two years running." Name the limit before they do, in exact words: "The team here is larger than the one I lead today." Then say what you would learn first about how the twelve are organised across the sites, as a plan and not a past. Follow-up 1, "How would you run supervisors you don't see every day?": answer as a plan in your own words. Follow-up 2, "Why not someone who already leads twelve?": return to the two quotes and add nothing to them. Answer slot: say the most supervisors you have led at once, in your own words; if that is the 3, say so plainly and stay with the 3. Let the interviewer draw the inference from what you did; do not assert it for them | F3 is the widest gap against the JD and F1 sits beside it, so this objection arrives in some form. JD because it scores the stated team and site scope |
| A2 | "Where does your warehouse and distribution background overlap with terminal operations, and where doesn't it?" | EXP | [grounded] "7 years in warehouse and distribution ops" | Start with what you have: "I have 7 years in warehouse and distribution ops." Answer slot: the JD's terminal wording makes a probe on the overlap likely. Say where the work overlapped, in your own words; if you cannot name an overlap, say so plainly and describe the distribution work. Then say, as a plan, what you would look at first on a visit to a terminal | F1 is where the JD's terminal wording presses. EXP because it tests what was actually the candidate's, with JD content |
| A3 | "Tell me about your experience with on-time performance and cost per shipment." | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say what the quote carries: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost per shipment, say what you counted and how, in your own words; if you tracked neither, say so plainly, stay with the mis-pick rate, and say what you would measure first here. Do not present the mis-pick work as evidence on either measure; describe it and let them connect it | F2 is the evidence for the role's two headline measures and the likeliest place to be probed. JD because it scores the stated responsibility; an open prompt, since the JD raises the theme |
| A4 | "Why this role, and why now?" | JD | [generic] | Give your actual reason in your own words, in one or two sentences, tied to something the JD names, such as the four sites, the supervisors or the numbers. Use only a reason you could stand behind under a follow-up. Answer slot: if your reason is mixed, say so plainly rather than choosing the tidier half | The Skeptic stem on motivation; consistency under cross-examination is what it scores. JD because it is asked against this role's scope; `[generic]` because it needs no claim about the past |
| A5 | "The posting asks for five-plus years of operations leadership. How much of your seven years was leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Hold what the quotes carry: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: say how many of the 7 years you led others, in your own words, with dates you can state; if some of the years were not spent leading, say so plainly and stay with your current role. A number you cannot date should not be said | F4 is the requirement the posting states as required, so a literal count is a natural probe. JD because it scores the requirement directly |

### B. Case/Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "On-time performance has dropped five points at one of your four sites over two months. Where do you start?" | CASE | [generic] | Clarify first: how on-time is defined and measured, which flows or customers it covers, and what changed in the period. Then state the objective, split the problem (inbound, outbound, by shift, by site), choose an approach, name the metrics you would watch, and name the risks. Think aloud, and challenge one premise respectfully, for example what the measure is a measure of. The question needs no claim about your past, so the guidance makes none | A live problem from the JD's on-time duty (F2's requirement), asked as a decision. `[generic]` because it is a pattern for the problem, not a fact about Atlas Freight |
| B2 | "Cost per shipment is up eight percent and on-time is flat. What do you look at?" | CASE | [generic] | Ask how cost per shipment is built before you diagnose it. Then break it into its components, say which you would look at first and why, and name the trade-off between cost and service aloud before recommending anything. State the hypothesis early. No claim about your past is needed, so none is made | The cost half of F2's requirement, as a live problem. CASE because it scores structure; `[generic]` for the same reason as B1 |
| B3 | "Peak season is eight weeks out and the forecast is well above last year. Build me the surge plan." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | You may open with the quote: "I ran the site's peak-season surge plan two years running." Then do the case from first principles, not from recall of what happened, because the quote does not carry the plan's content. Clarify the forecast and the constraints, structure the plan across the four sites, name the metrics and the risks. Answer slot: if a point in the plan is something you did before, say so in your own words; if it is something you would do now, say that instead | F1 holds your one surge sentence; this is the likeliest place the interviewer tests it. CASE because it scores live structure |
| B4 | "You inherit twelve supervisors with uneven performance across four sites. What do you do in your first ninety days?" | CASE | [generic] | Clarify what uneven means and what data exists. Then say how you would see each site, agree shared measures, pick one or two early fixes, and set a cadence. Where reporting is part of the plan, say what you would start with and say that learning Power BI is part of it. Frame it as a plan, never as something you have done | F3 and F6 sit behind this: a team larger than yours today, and a tool you have not used. `[generic]` because it asks about no past |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-pick rate by 40 percent. Walk me through how that was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the quote: "I cut mis-pick rate 40% by redesigning the pick path." Answer slots, each in your own words: how the rate was counted; what the 40% is sensitive to; the assumption behind it you would defend least, named before they name it; which part of the redesign was yours. If you do not know how it was counted, say that plainly. Add no method you cannot repeat under a second question | F2's figure is the only number in the material, so a prober goes to it first. EXP because it tests whether the claim survives |
| C2 | "Tell me about your Excel experience." | JD | [inferred] "solid Excel" | Start with the quote: "I have solid Excel." Answer slot: the JD's reporting line makes a probe on what the Excel work was likely. Say what you have used Excel for, in your own words; if you can name a particular piece of work, give it, and if you cannot, say so plainly | F5 is thin: a skill level with nothing behind it. JD because it scores the stated tool requirement |
| C3 | "What's your experience with Power BI?" | JD | [grounded] "never used Power BI" | Say it plainly: "I haven't used Power BI." Then give a plan, said as a plan: how you would learn it and what you would build first, in your own words. Then ask which tool the role runs on first. Never claim a similar tool or partial experience you have not stated | F6 is a stated gap that will be asked about, so rehearse the honest answer until it is calm. JD because it scores a named tool |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get to where you are?" | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "green belt certified" | A 90-second arc with three beats the quotes state: the 7 years in warehouse and distribution ops; the current role as a senior shift manager over 3 supervisors; the green belt certification. Answer slot: how you got from the start to the current role is not in the material; tell it in your own words, in order, and keep to what you can date | F4 and F7 carry the beats; the middle is yours. EXP because it tests whether the story hangs together |
| D2 | "Tell me about your Lean or Six Sigma background." | JD | [grounded] "green belt certified" | Lead with the quote: "I'm green belt certified." Answer slot: expect "what did you apply it to". If the pick-path redesign used it, say so; if you applied it elsewhere, say where and what part was yours; if the certification has not yet been applied, say so plainly and say what you would apply it to first here | F7 is the plus-skill row. JD because it scores the stated plus; a casual register, so it is still scored |
| D3 | "How would you describe how you lead supervisors?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Selection scaffold: pick one real moment from working with the 3 supervisors you are over, one with a named situation, what you did and what changed. If no such moment comes to mind, say so plainly, then describe how you would lead the larger team | F3's requirement asked as style. JD because it scores the leadership duty |

### E. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Two site leads need the same equipment on the same shift. How do you decide who gets it?" | CASE | [generic] | Offer principles, not a pretended knowledge of the seams: a shared measure, a named decider, an escalation path, and a record of why. Say what you would ask first. No claim about your past is needed | The four-site seam from F1's requirement. `[generic]` because it presupposes nothing about Atlas Freight or you |
| E2 | "How do you handle credit when work spans two shifts or two sites?" | VAL | [generic] | Selection scaffold: pick a real instance where credit or blame was shared, with a named stake, what you did and how the relationship stood afterwards. If no such instance comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer persona's credit-sharing probe, applied to the shift and site structure |
| E3 | "What would you need from the other site leads in your first month, and what would you offer them?" | JD | [generic] | Reciprocity framing: say what you would need, then what you would give, both as plans. Keep the offer to what you will do, not claims about what you have done | The reciprocity move a peer scores; JD because it tests how the role works across sites |

### G. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: that 40 percent, how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Pause and restate. Hold: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say what part of the redesign was yours and who else worked on it, in your own words; if it was a shared effort, say so plainly and say your part. Hold through two follow-ups, then concede one specific thing, such as what you do not know about how it was counted | F2's attribution is the question a time-boxed interviewer asks. EXP because it tests attribution under pressure |
| G2 | "Sixty seconds: why you over someone who has run twelve supervisors across several sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified"; "solid Excel, never used Power BI" | Hold with the quotes at their own scope, in 60 seconds: the 3 supervisors, the 40% mis-pick cut, the surge plan two years running, the green belt. Then concede two specifics in exact words: "The team here is larger than the one I lead today" and "I haven't used Power BI." Do not argue that you beat the other candidate at what they did | F3 and F6 are the two limits this question forces out. JD because it scores the stated fit |

### H. Values/Behavioral (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a real time with a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; no published values were read, so it is not tied to Atlas Freight's own words |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a real decision where the two pulled apart, with what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem that fits a role scored on on-time and cost (F2's requirement) |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A2, B1, B4, E1, E3 |
| "drive on-time performance and cost-per-shipment down" | A3, B1, B2, C1 |
| "lead a team of 12 supervisors" | A1, B4, D3, G2 |
| "build reporting in Excel/Power BI" | C2, C3, B4 |
| "5+ years operations leadership required" | A5, D1 |
| "Lean/Six Sigma a plus" | D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance defined and measured today, and which way is it moving?" | The JD says to drive on-time performance and cost-per-shipment down, and the question shows you want the definition before you commit to a number |
| R2 | "Of the twelve supervisors, how are they spread across the four sites, and who do they report to today?" | It shows you are thinking about team shape, and the answer tells you how A1's step up will actually feel |
| R3 | "Which tool does the reporting run on today, and what would you want built in the first quarter?" | It settles whether Power BI is needed on day one without volunteering more than you have said |
| R4 | "What does a good first ninety days look like, and which site would you want me to learn first?" | It turns B4 into a conversation and signals a plan rather than an assumption |
| R5 | "How does peak season work across the four sites: one plan or four?" | It connects to the surge plan you ran, and tells you the scope of the work you would own |
| R6 | "What could a new person do in their first month that would genuinely help your site?" | Reciprocity for a peer interviewer; it shows you think about their load as well as your own |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned daily operations across several sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says a shift and a surge plan, not daily ownership across sites |
| Led a team of 12 supervisors | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says 3 |
| Drove on-time performance or cost per shipment down | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says mis-pick rate, not either measure |
| Has five-plus years of operations leadership | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says 7 years in operations, not years leading |
| Built reporting or dashboards | Inflated form of F5 | F5's quote "solid Excel" at its own scope. C2's slot asks only what the Excel work was |
| Has used Power BI | Negative the candidate stated, F6 | The plain acknowledgment F6 gives: "I haven't used Power BI." No slot |
| Led Lean or Six Sigma projects | Inflated form of F7 | F7's quote at its own scope: "I'm green belt certified." D2's slot asks only what it was applied to |

## Sources

- **Provided documents:** the JD text and the background, both in your message. No dossier was present.
- **Searches sent, all refused (this session did not grant search permission):**
  - `Atlas Freight regional logistics company values` — refused
  - `Atlas Freight interview process operations manager` — refused
  - `Atlas Freight regional logistics strategy news` — refused
- No pages were fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. It would have fed a values cheat sheet; none is built, and the VAL bank is `[generic]` |
| 2. `{company} interview process {role family}` | unavailable | Every call was refused. It would have fixed the loop and the persona weights; the generic archetype stands in |
| 3. `{company} strategy` / recent news | unavailable | Every call was refused. It would have fed CO questions; none are in this pack |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting and what kind of round it is → reweighted personas and banks; a named interviewer also adds an interviewer read and a reverse question tied to their path
- A recruiter or HR note on focus areas or any pre-declared deliverable → coverage of what they will score, and a build section if a deliverable was announced
- Answers to the slots in F1, F2, F3, F4 and F5 (what you tracked, the most supervisors you led at once, how many of the 7 years you led others, what the Excel work was) → those rows become `[grounded]` story-mapped answers rather than slots
- A dated CV, a before-and-after site KPI report for the pick-path work, and the green belt certificate → F2 and F7 can rise from medium once something inspectable sits behind them
- Search permission, plus Atlas Freight's website or city so the right company is identified → published values, loop structure and strategy, which would add a values cheat sheet if a values round is documented and CO questions
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes), if search is granted → strategy brief, recent organisation context, and role-family loop reports
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence and absolute prohibited claims would replace the locally built list above
