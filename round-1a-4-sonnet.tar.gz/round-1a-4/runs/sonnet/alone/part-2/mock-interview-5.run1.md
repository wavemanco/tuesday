Your prep pack is saved as /var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-5-denied-38319d26/kelverton-rail_senior-partnerships-manager_interview_pack.md. It's built for a panel of Deepa as your future manager and Ross on commercials, using the recruiter's wording and your background note.

- **Searches:** all five web searches were refused. Nothing in the pack comes from outside what you wrote, so every Kelverton-specific question is generic.
- **Market report:** I can't see it, so the pack tells you how to use it in the POV but names no findings.
- **Highest-ROI rehearsal:** this is B2, "you've never carried a direct quota, only influenced revenue". Concede it first in your own words, then hold on the 6 to 40 partners and roughly £4M influenced.
- **POV (first 15 minutes):** the pack builds it as one of two theses plus an anti-pick, each with a concession and a close on what it means for operators.
- **Time:** four blocks sized to your four hours are in the pack, and everything outside them is marked as insurance.
- **Your own wording:** a few questions are answer slots where the pack doesn't know what you did, such as how the £4M was counted. I left them for you to fill in, not guess at.

Say the word and I'll play Ross on B2 or C1. I can also save a tuesday-dossier.md recording the gaps this prep exposed, and I can convert the pack to Word if you want it.

Could you paste the JD if you have one, plus the report's headline findings or shortlist? Either would let me replace the generic parts of the POV build and the role-requirement rows with real ones.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

Second round, 60 minutes, panel of Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: your POV on operator partnerships over the next 18 months, no slides, landing on what it means for the operators. Rest is Q&A, and Ross will push on commercials. Built from the recruiter's email as you quoted it and your own background note. No JD, no market-report text and no web research went into it (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is scored.

| Type | What it scores |
|---|---|
| EXP | Whether your experience survives scrutiny, and what was actually yours |
| JD | The role's stated requirements, gaps included |
| CO | Company and market knowledge, and whether you can think at the company's altitude |
| CASE | A live problem from the role, reasoned out loud |
| VAL | Past behaviour against values |

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for you now. Provenance: `[grounded]` is traceable to what you gave me, `[inferred]` is derived from an adjacent source, `[generic]` is a role-family pattern with no claim about Kelverton or about you.

## Prep triage (four hours)

| Block | Time | Do this | Sections |
|---|---|---|---|
| 1 | 80 min | Draft the POV from the build below, then speak it aloud twice against a timer. Re-read the report first and write which of its points you would defend and which you would not | Graded deliverable, E2, A2 |
| 2 | 55 min | Rehearse the objection aloud until it is boring: concede first, hold what your own words carry, name the limit before they ask | B2 (highest-ROI), D1, D2, B1 |
| 3 | 40 min | Write down, in your own words, what you know and do not know about how each figure was counted | C1, C2 |
| 4 | 30 min | Talk two commercial cases through out loud, structure first | C3, C4, A4 |
| 5 | 35 min | The 90-second journey, the why-rail answer, and three reverse questions | E1, B4, Reverse questions |

Blocks 1 and 2 in the first sitting and 3 to 5 in a later one gives the POV a gap between draft and second run. Everything else is insurance: A1, A3, B3, D3, G1, G2.

## Fit snapshot

The requirements come from the recruiter's own words as you quoted them, plus role-family requirements written as plain prose. There is no JD, so no requirement is a hard gate here: nothing you gave me states a term such as location, notice or pay.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, as you quoted it | "took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material says you took a channel from 6 partners to 40, not that you set a partnership direction for an operator-facing business, and the words stay at that scope: "I took the ISV channel from 6 partners to 40." Answer slot: the POV ask makes a probe on how you decided which partners to add likely. If that was yours to decide, say how, in your own words; if it was not, or there was no such step, say so plainly and stay with the 6 to 40 |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email, as you quoted it | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, not train operating companies or scheduling software, and the words stay there. Answer slot: the operator-focused close makes a probe on which operators you know likely. If any of that work was with train operators, say which and what your part was; if it was bus and light rail only, say so plainly and describe what that work was |
| F3 | "Ross will push on commercials." — recruiter's email, as you quoted it | "roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | Your material carries influenced revenue, with a direct quota stated as something you have not carried. The words: "I've never carried a direct quota, only influenced revenue." Answer slot: if you know how the roughly £4M was counted, say so in your own words; if you do not, say that plainly |
| F4 | Knowledge of selling into rail operators — role-family requirement, no source supplied | "Never sold into rail specifically" — your message | none | [generic] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan and never as a past |
| F5 | Running a partner channel at senior level — role-family requirement, no source supplied | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message | medium | [generic] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: you ran the ISV channel, at a payments company, for the last four of nine years in partnerships |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 POV on operator partnerships, 18 months | Graded deliverable, A1, A2, A4, D3, E2 |
| F2 Land on what it means for operators | Graded deliverable close, A3, B1 |
| F3 Commercials | B2, C1, C2, C3, C4, D2 |
| F4 Rail knowledge | B1, B3, D1 |
| F5 Running a partner channel | B3, C2, E1, G2 |
| Motivation (why rail, why now) | B4, E1 |
| Behavioural, no published values in hand | G1, G2 |

## Graded deliverable: the 15-minute POV

The recruiter announced it, so it is graded. Aim for about 12 minutes spoken and leave the rest for the panel to react.

**Facts to build on**

| Fact | Source | Provenance |
|---|---|---|
| Kelverton is "UK rail-tech, ~600 staff, they sell scheduling software to train operating companies" | your message | [grounded] |
| "no slides needed, just talk us through it" | recruiter's email, as you quoted it | [grounded] |
| "Please land on what it means for the operators themselves." | recruiter's email, as you quoted it | [grounded] |
| F1: "took it from 6 partners to 40" | your message | [grounded] |
| F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | your message | [grounded] |
| F3: "roughly £4M of influenced revenue" | your message | [grounded] |

**Three theses, each a hypothesis to test against the report you have read.** Pick one of T1 or T2, plus T3.

| # | Thesis | Mandatory concession | What it means for operators (the close) | Provenance |
|---|---|---|---|---|
| T1 | Spend the 18 months on a few partner types that shorten an operator's path from signed to running, rather than chasing partner count | Fewer partner types means saying no to inbound interest, and where rollout friction really sits is something Deepa's team can see and you cannot from outside | Fewer vendors to coordinate and a more predictable go-live; what they are asked to commit is a named sponsor | [generic] |
| T2 | Treat a few operators as design partners and the rest as customers, with partnerships owning the design-partner relationships | Depth costs coverage, operators outside the circle may feel passed over, and design partners can pull the roadmap toward themselves | Design-partner operators shape what gets built; the others get a clear reason and a date | [generic] |
| T3 | The anti-pick: no broad partner marketplace or programme launch in the first 18 months | You may cede visibility to rivals, and the report may argue for breadth | A smaller number of well-supported integrations instead of a catalogue to evaluate | [generic] |

**Differentiation.** The report went to interviewers and rival candidates alike, so reciting its shortlist scores as homework only. Bring one item from it that you agree with, named as theirs, to show you read it. Then say where you would diverge and why, then give T3. I have not seen the report, so which thesis fits it is your call.

**Shape.** One minute to frame. Two on what you took from the report. Five on your thesis. Two on what you would not do. Two on the close. The close is three plain statements about operators: what changes for them, what it costs them, and what you would ask of them.

## Reading the interviewers

| Person | What is known | Practical implication | Provenance |
|---|---|---|---|
| Deepa | "VP Partnerships, your future manager" — recruiter's email, as you quoted it | She is deciding whether she wants you on her team: expect strategy cases and the gap questions | [grounded] |
| Ross | "Commercial Director"; "Ross will push on commercials." — recruiter's email, as you quoted it | Expect numbers probed and structure demanded; concede what you do not know rather than filling it | [grounded] |

No public footprint for either was researched, so there is no career pattern and no mirror opportunity in this pack.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Deepa pushing on the POV and live partnership problems | Highest: future manager, plus a POV ask that invites follow-up | Clarify, objective, segmentation, approach, metrics, risks; challenge one premise respectfully |
| Skeptic | Rail and quota gaps, why now | High: your own message states both gaps | Rehearse B2 until it is boring |
| Data-Driven Prober | Ross on the figures and on commercial structure | High: the recruiter said he will push on commercials | Know what you can and cannot say about each figure, and say plainly when you do not know |
| Pressure | Time-boxed challenges to the gaps | Medium: a commercial director may time-box; no direct signal | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational | Deepa's opener | Medium: openers are usually casual and still scored | A 90-second arc |
| Values / Behavioural | One or two behavioural probes | Low: no values-style round is documented | Selection scaffold with an honest branch |

Weights follow the panel blend: the top two personas of each member's relationship, tilted by the recruiter's one signal about Ross. No loop source beyond your own words was available.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What would you need to know in your first month before committing to any of this?" | CASE | [generic] | Clarify first: name the two or three things you would check and which of your POV claims they could overturn. Then say what you would stop doing if a check failed. The question needs no claim about your past, so the guidance makes none | A POV invites the "what would change your mind" probe; CASE because it scores reasoning, not recall |
| A2 | "What did you deliberately leave out of that?" | CO | [generic] | Have T3 ready, with its concession. Say what you left out and why, as a decision rather than an omission. No claim about your past is needed | Rewards judgment over recitation of the report; CO because it scores altitude |
| A3 | "Take one operator. What is different in their day-to-day once a partner integration with us goes live?" | CASE | [generic] | Ask which operator and which function first. Then answer in three parts: what changes, what it costs them, what they must commit. If you do not know their internal workings, say so and say what you would ask | The recruiter asked you to land on operators, so this is the likeliest follow-up; F2 is the evidence it will press on |
| A4 | "Two operators both want first access to the same partner's capability. How do you decide?" | CASE | [generic] | Ask what is at stake for each. State the decision criteria before the decision, and who needs to agree them. Name what Ross would need to weigh in on. Concede what you cannot know from outside | A seam problem with a commercial edge, aimed at both panelists |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail. What won't you know on day one?" | JD | [grounded] "Never sold into rail specifically"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Concede first, in your own words: "I've never sold into rail specifically." Then the nearest thing you have, at its own scope: five years in transport consulting, bus and light rail network planning. Answer slot: the question makes a probe on which operators that work touched likely. If any was with train operators, say which and what your part was; if it was bus and light rail only, say so plainly. Close with how you would close the gap, as a plan: who you would spend your first weeks with and what you would read first | F4 is the stated gap and F2 the adjacent evidence; JD because it scores fit against the role |
| B2 | "You've never carried a direct quota, only influenced revenue. Why would we trust you with a number?" | EXP | [grounded] "never carried a direct quota, only influenced revenue"; "roughly £4M of influenced revenue"; "took it from 6 partners to 40" | **The highest-ROI rehearsal in this pack.** Level 1, concede then hold: "I've never carried a direct quota, only influenced revenue." Hold on what your words carry: you took the channel from 6 partners to 40, with roughly £4M of influenced revenue. Name the limit before they ask: influenced is not booked. Level 2, if they ask who closed it. Answer slot: if you were in the room for the closing, say how; if the closing sat with others, say so plainly and stay with the channel. Level 3, if they ask whether you can handle one. Do not promise: say plainly that being measured on a closed number is a difference you have not lived, then say what you would want agreed with Deepa and Ross up front | F3 is where the commercial push lands hardest and your own message states the limit; EXP because it tests what was actually yours |
| B3 | "What from running an ISV channel in payments carries over to operator partnerships, and what doesn't?" | EXP | [grounded] "running the ISV channel"; "Never sold into rail specifically" | Start with what your words state: you ran the ISV channel, at a payments company. Your material does not show which parts overlap with operator partnerships. Answer slot: if you can name a specific carry-over, say what you did; if you cannot, say so plainly. Then say what you expect to differ, labelled as an expectation | F5 against F4; EXP because it tests whether the transfer is real |
| B4 | "Why leave payments, why rail, and why now?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Give your actual reasons in your own words; the pack knows none of them. Two sentences each. If the transport consulting years are part of the reason, say how; if not, leave them out | Motivation consistency is a core Skeptic score; nothing in the material states the reasons |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that roughly £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Four slots, each in your own words. How it was counted. What it is sensitive to. The assumption you would defend least, named before they do. Which part was yours. "I don't know how it was counted" is an honest branch. Keep "roughly" | A headline figure on the CV; F3 |
| C2 | "Walk me through the 6 to 40. What counted as a partner at each end?" | EXP | [grounded] "took it from 6 partners to 40" | Same four slots, applied to partners: what counted, what the count is sensitive to, the assumption you would defend least, and which part was yours. If some of the 40 came from others' work, say so. The number stays on partners | A headline figure on the CV; F1 |
| C3 | "A partner brings us into an operator and the deal closes. How should we pay for that?" | CASE | [generic] | Clarify what is being rewarded. State the objective: operator outcomes and revenue. Lay out a few structures and their trade-offs, name which you would test first and why. If you have seen one in practice, say which and what happened; if not, say you are reasoning from principles | Ross's commercial push, as a live problem that needs no claim about your past |
| C4 | "Our direct sales team is already working that operator when a partner shows up with the same opportunity. What happens?" | CASE | [generic] | Clarify. Propose principles agreed in advance. Protect the operator from two voices. Invite Ross's view on where he would draw the line | A seam question aimed at Ross's turf |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already sold into rail?" | JD | [grounded] "Never sold into rail specifically"; "running the ISV channel"; "took it from 6 partners to 40" | Pause and restate. Concede first: "I've never sold into rail specifically." Hold on what your words carry: you ran the ISV channel and took it from 6 partners to 40. Hold through two follow-ups by returning to those, never by adding to them. Name the one thing you would need to learn | F4 against F5; JD because it scores fit |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue"; "running the ISV channel" | Answer slot: say your share in your own words; if you do not know the split, say so plainly. Keep "influenced" and "roughly". Hold the channel you ran; do not widen it to closing | F3; the attribution probe |
| D3 | "Eighteen months isn't long. What is visibly different at month six?" | CASE | [generic] | Name one or two observable markers tied to your thesis that you would be accountable for. Concede what depends on others. Invent no statistics | Turns the POV into a commitment |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc with three beats your words state: five years in transport consulting, which your message places before the partnership years; nine years in partnerships; the last four on the ISV channel. Then the link to this role, in reasons only you can give. No beats beyond these | Casual openers are still scored; F2 and F5 |
| E2 | "What in our strategy team's report did you disagree with?" | CO | [generic] | Answer slot: if you disagreed with something, name it and your reasoning; if you agreed, say plainly which finding you would build on and which you were unsure of. Do not manufacture dissent for contrast | The report went to rival candidates too, so disagreement with reasons is what separates you |

### G. Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you did not soften it, and the relationship intact at the end. "We" for context, "I" for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | An open prompt from the persona stem; no values-style round is documented, so weight is low |
| G2 | "When did you put a customer's outcome ahead of an internal metric?" | VAL | [generic] | Pick a time where the outcome and the metric visibly pulled apart, what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The operator-outcome close of your POV makes this a natural follow-up |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Eighteen months in, what does a successful operator partnership look like to the operator's own team, and which of those measures do you already track?" | It keeps the conversation on operators, as the recruiter asked, and shows you think in their outcomes |
| 2 | "How are partnership targets set today: direct, influenced, or shared with sales? Where would this role sit in that?" | It lets Ross answer the quota question on his own terms, before or after B2 |
| 3 | "Where do partnerships and direct sales overlap today, and how are disputes settled?" | Shows you saw the C4 seam |
| 4 | "Which finding in the strategy report is shaping your priorities most, and which are you least sure of?" | Treats the report as a live argument, not a shortlist |
| 5 | "What would you most want a new person from outside rail to learn first?" | Invites the day-one answer to B1 from Deepa's side |
| 6 | "What would tell you in the first 90 days that this role is working?" | Gives you the success measure Deepa will actually use |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or carries rail relationships | Negative you stated, F4 | "I've never sold into rail specifically." No slot |
| Has carried a quota or owned revenue directly | Negative you stated, F3 | "I've never carried a direct quota, only influenced revenue." No slot |
| Has worked with train operating companies | Inflated form of F2 | F2's quote at its own scope; the limit is the pack's observation: your material says bus and light rail network planning. B1's slot stays inside that work |
| Built the partner programme from scratch, or personally signed 34 new partners | Inflated form of F1 | "took it from 6 partners to 40", at its own scope. The limit is the pack's observation: your material says you took the channel from 6 to 40, not how |
| The £4M was booked or closed revenue | Inflated form of F3 | "roughly £4M of influenced revenue". C1's slots stay on how it was counted |

## Sources

Provided: your message, including the recruiter's email as you quoted it and your background note. The market report was attached to the recruiter's email and was not shared with me, so none of its content is in this pack.

Searches sent, all refused:
- `Kelverton Rail values` — refused
- `Kelverton Rail scheduling software train operating companies strategy news` — refused
- `Kelverton Rail interview process partnerships manager` — refused
- `Deepa VP Partnerships Kelverton Rail` — refused
- `Senior Partnerships Manager rail technology job description operators` — refused

Research tier: L1 — searches 5 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Every call was refused. Would have fed a values cheat sheet; none is built |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | Every call was refused. Would have checked loop structure; persona weights rest on your own description of the round |
| 3. `Kelverton Rail` strategy and recent news | unavailable | Every call was refused. Would have grounded the CO questions in current strategy; they are `[generic]` |
| 4. Interviewer footprint | unavailable | Every call was refused, and only Deepa's query was sent. Would have fed the interviewer read; Ross's query was not sent |
| 5. Representative `Senior Partnerships Manager` JD | unavailable | Every call was refused. Would have replaced the role-family rows F4 and F5 with `[inferred]` JD lines |

## Upgrade menu

- The JD text → F4 and F5 become quoted requirements, any gate such as location or start date becomes a fit-snapshot row, and the JD-tagged questions get a raising source
- The report's headline findings or shortlist → the differentiation step in the POV build gets a named consensus item and a named divergence instead of an instruction
- Search permission → values, loop structure, strategy, interviewer footprints and a representative JD at L1; a deeper pass would be up to 6 more searches and 2 more fetches, several more minutes
- Which operators your consulting work touched → F2 and B1 stop being an answer slot
- How the £4M and the 6 to 40 were counted → C1 and C2 stop being answer slots
- A `tuesday-dossier.md` from an earlier evidence check → verified evidence and absolute prohibited claims in place of the locally built list
