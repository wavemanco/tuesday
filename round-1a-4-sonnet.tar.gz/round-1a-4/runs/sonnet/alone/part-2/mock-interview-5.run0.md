I've read the prep-pack rules. Now I'm running the first round of company research on Kelverton Rail: values, interview process, recent strategy, the two interviewers, and a representative JD.
Searches were refused, so I'm building the pack from what you've given me. Company, interview-loop and interviewer facts will be labeled as not researched.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-5-denied-ec30b9f3/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It has 18 questions in five banks, a build section for the 15-minute POV, a fit snapshot and reverse questions. It also has a four-hour prep schedule that puts the POV first.

The web searches I tried (values, interview process, strategy, Deepa, Ross, a sample JD) were all refused. I've said so in the pack's Sources section. Nothing in it is claimed about Kelverton, its operators or the two interviewers beyond your message and the recruiter's email. I also couldn't see the market report, so the report-based question (A3) and the POV's "consensus point vs. divergence" step give you the shape and leave the content to your own reading.

I'd start with B1, the pack's highest-ROI prep. It covers "you haven't sold into rail and you haven't carried a quota", both of which you stated yourself, and it comes with follow-ups and concession wording.

Say the word and I'll play the Skeptic on B1, or Ross on D1 and D2. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description, and a CV if you have one? The pack stands without them, but both would replace rows now quoted from your message with quoted lines.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one panel, 60 minutes, Tuesday. Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are a spoken POV with no slides, then Q&A, where Ross will push on commercials. Built on the recruiter's email as you quoted it, and on your message.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored: VAL (values), EXP (experience deep-dive), JD (role requirements), CO (company and strategy), CASE (live problem).
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview: say it from your own experience, or say plainly it was not yours or never existed. It asks nothing of you here.
- Provenance labels: `[grounded]` traces to something you gave me, `[inferred]` is derived and the derivation is named, `[generic]` is a pattern with no claim about Kelverton or you.
- Nothing about Kelverton, its operators or the rail market was researched (see Sources). Everything company-specific is therefore either your own words or labeled `[generic]`.

## Prep triage (about four hours, over the weekend)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 60 min | Build the POV: pick two theses, write each concession, say the whole thing aloud twice and time it to 14 minutes | Section 5 |
| 2 | 45 min | Rehearse the objection ladder until it is boring: B1, then D1 and D2 | B1, D1, D2 |
| 3 | 40 min | Re-read the market report with section 5 open: one consensus point, one divergence, one thing you would say no to | A3, A4 |
| 4 | 30 min | Defend the numbers: how the £4M and the 6 to 40 were counted, and which part was yours | C1, C2, C3 |
| 5 | 25 min | Say the case answers aloud with the structure, not a script | A1, A2, C4 |
| 6 | 20 min | Pick three reverse questions and the 90-second arc | Section 11, E1 |

Everything else is insurance. B1 is the highest-ROI prep in the pack.

## 4. Fit snapshot

The recruiter's own words stand in for the job description, which I have not seen.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "took it from 6 partners to 40" — your message; "last 4 at a payments company running the ISV channel" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships, and nothing inspected sits behind it. Words: "For the last four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: the ask for a view on operator partnerships makes a probe on what carries over from a payments channel likely. Say which parts you would carry across and which you would not, in your own words; if you think none carries, say so plainly and stay with the channel you ran |
| F2 | "what it means for the operators themselves" — recruiter's email | "bus and light rail network planning, so I know the operator world from the other side" — your message | medium | [grounded] | transferability | The words stay at that scope: your material says bus and light rail network planning, and does not say train operators or who the planning was for. Words: "I did bus and light rail network planning." Answer slot: if you worked with operators directly, say who and on what; if the work was for others, or not with operators, say so plainly and stay with the planning |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | discovery | Your material gives the figure and not how it was counted. Answer slot: Ross is the likeliest to ask how it was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours. Answer each in your own words; if you do not know how it was counted, say so plainly |
| F4 | own a revenue target in a partnerships role — role-family requirement | "never carried a direct quota, only influenced revenue" — your message | medium | [generic] | capability | A gap wording cannot close, and you stated it. Words: "I've never carried a direct quota, only influenced revenue." Then how you would work to a number here, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | partner or sell into rail operators — role-family requirement | "Never sold into rail specifically" — your message | medium | [generic] | capability | You stated this one too. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan with who you would talk to first. Never a claim to rail selling |
| F6 | "no slides needed, just talk us through it" — recruiter's email | none given | none | [grounded] | discovery | Your material does not show how you present unscripted. Answer slot: if you have talked a panel through a view without slides before, say what it was; if you have not, say so plainly, and rehearse this one aloud this weekend |

No gate rows: nothing I have names a term such as location, pay, travel or a credential. A job description may add some.

## 5. Graded deliverable: the 15-minute POV

**The ask, in the recruiter's words:** "where you'd take our operator partnerships over the next 18 months", "no slides needed, just talk us through it", and "Please land on what it means for the operators themselves." The close is set, so build backwards from it.

**Grounded facts you may use** (each only at its own scope):

- F1: "last 4 at a payments company running the ISV channel". Context for what you have seen at the scale of a channel. It is not evidence about rail.
- F2: "bus and light rail network planning, so I know the operator world from the other side". Your angle on operators. It says bus and light rail.
- F3: "roughly £4M of influenced revenue". Use only if Ross asks. It does not belong in the POV.

**First 30 seconds.** The email does not say whether "operator partnerships" means relationships with the operators as customers, partners who serve operators, or both. State your reading aloud and invite correction. It costs ten seconds and tells you what the panel means.

**Timing for 15 minutes:** 1 min framing, 2 min grounding in the report, 7 min on two theses with a commercial line each, 3 min on what it means for operators, 2 min on what you would say no to and what you are least sure of.

| # | Thesis option | Rests on | Mandatory concession | Commercial line for Ross | Provenance |
|---|---|---|---|---|---|
| T1 | Judge each operator partnership by what changes for the operator, and report that before reporting partner counts | The recruiter's own close: "what it means for the operators themselves". No evidence about you is claimed | It is harder to evidence in 18 months than a count, and you do not yet know which operator-side results Kelverton can already see | Name the Kelverton commercial result that sits beside the operator result. Give no figure unless the report or your own record gives one | [inferred] derived from the recruiter's close, to be tested against the report |
| T2 | Go deep with a few operators before going wide | The ask for 18 months. Argued as a view, not as something you have done | Depth concentrates risk in few accounts and slows breadth, so revenue timing moves. Say that before Ross does | Say what you would trade and what you would watch. Give no numbers you cannot source | [inferred] derived from the ask, to be tested against the report |
| T3 | Start from an operator problem, check it with operators, then decide the partnership | F2: "bus and light rail network planning, so I know the operator world from the other side", at that scope | Your planning was bus and light rail. Say you would test the problem with train operators before committing | Say how you would know early if the problem was real: a named operator willing to commit time | [inferred] derived from F2 and the ask, to be tested against the report |

**Differentiate from the report.** The panel's own strategy team wrote it, so reciting its shortlist scores as homework. Bring one consensus point to show you have read it, then one thesis-driven divergence with your reasons, then the anti-pick: one thing you would say no to in the next 18 months (A4 rehearses it). I could not see the report, so you choose these from your own reading; the pack only gives the shape.

**The close, spoken last.** What it means for the operators themselves, in three beats: one thing an operator does differently or stops doing, one thing it costs them, and one thing they can hold Kelverton to. Fill each from the report or your own view, and no further than you can defend.

## Persona table

The panel is two people, so the weights blend the top two personas for each. Kelverton's actual interview structure was not researched. The recruiter's email establishes this session: one panel, 60 minutes, a 15-minute POV then Q&A. Nothing documents a dedicated values round, so none is assumed.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A) | Pushes on the POV: what you would need to know, what you would measure, what you would leave alone | High. The first 15 minutes are a graded POV, and Deepa is your future manager, so hiring-manager priors apply | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud, challenge one premise of your own plan |
| Skeptic (bank B) | Quiet, persistent probing of the two gaps you named yourself | High. Your message states no rail selling and no direct quota, so these are certain to come up in some form | Rehearse B1 until it is boring. Build bridges only from F1 and F2 at their own scope, then a plan |
| Data-Driven Prober (bank C) | Ross on the numbers: the £4M, the 6 to 40, counterfactuals | High. "Ross will push on commercials", and you carry a headline figure | Know what you can and cannot say about how each number was counted. Say plainly what you do not know |
| Pressure (bank D) | Ross time-boxing and interrupting: sixty seconds, why you, how much was you | Medium. A Commercial Director who "pushes" may do it, but I have no signal on his style | Pause, restate, hold the position through two follow-ups, concede specifically |
| Conversational (bank E) | Deepa's opener: walk me through the journey | Low to medium. An opener is likely, but it is scored | A 90-second arc built only from your own sentences |

Peer and Values/Behavioral are not weighted: neither interviewer is a peer, and nothing shows a values round.

## 9. Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've told us where you'd take it. What would you need to know about our operators before you committed to that?" | CASE | [generic] | Clarify before structuring: name two things you would test and who you would ask, then say which part of your POV would change if the answer came back the other way. Claim nothing about Kelverton's operators beyond what the report you read gives you | A POV invites exactly this push. CASE because it scores structure under uncertainty, not a right answer |
| A2 | "Eighteen months out, which two or three measures would you put in front of us, and which would you drop?" | CASE | [generic] | Pair one operator-side result with one Kelverton commercial result. Name the assumption behind your choice that you would defend least. Give no figures. Say what you would drop and why | Ties T1 to Ross's commercial lens. CASE with JD content because it tests the stated 18-month horizon |
| A3 | "Our strategy team's report is where most people start. Where do you part company with it?" | CO | [generic] | I could not see the report, so this is shape only. One point you agree with, to show you read it. One divergence with your reasons. One thing in it you would not pursue. Each in your own words. If you agree with all of it, say what you would sequence differently | The report was written by the panel's own colleagues, so recitation scores as homework and a reasoned divergence scores as judgment. CO because it tests strategy fluency. `[generic]` because the report's content is not in hand |
| A4 | "Which operators would you leave alone for the next 18 months, and why?" | CASE | [generic] | State your criteria before any names. Concede you are choosing with limited information, and say what would change your mind. Name no operator or fact you cannot source from the report | The anti-pick: a role that carries commercial weight includes saying no. CASE, with JD overlap |
| A5 | "Your first 90 days: what do you do, and what do you deliberately not do?" | CASE | [generic] | A plan, never a past: who you would listen to first, what you would learn about rail before proposing anything, and what you would hold back until you had. This is where the F5 gap becomes a ramp | The ramp plan is the second half of B1's answer. CASE because it asks for sequencing |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't sold into rail and you haven't carried a quota. Why would we trust you with our operator partnerships?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue"; "last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40"; "bus and light rail network planning, so I know the operator world from the other side" | **The highest-ROI rehearsal in this pack.** Hold: say your own words first, "I've never sold into rail specifically, and I've never carried a direct quota, only influenced revenue." Then what you did, at its own scope: "last 4 at a payments company running the ISV channel", "took it from 6 partners to 40", and bus and light rail network planning. Add nothing to those. Follow-up one, "influenced isn't owned": concede that it is different from carrying a number. Answer slot: say what "influenced" meant in your own words; if you do not know how it was counted, say so plainly. Follow-up two, "what's different about rail?": give a plan, never a past, with the first three things you would learn and from whom. Follow-up three, "is that enough?": hold, do not say yes. Say you have named the gap yourself and say how you would close it and how they would see it closing | Both negatives are yours, so this objection is certain, and F4 and F5 are where it presses hardest. JD because it scores the role's commercial and domain requirements. Skeptic delivery, but Ross may ask it as Pressure |
| B2 | "You say you know the operator world from the other side. What does that cover, and how far does it reach into train operations?" | EXP | [grounded] "bus and light rail network planning, so I know the operator world from the other side" | Say what you did, at its scope: bus and light rail network planning. Answer slot: if any of it was with train operators, say who and what; if none was, say so plainly and stay with the planning. Do not widen "operator world" beyond what your sentence covers | F2 is the evidence for the operators requirement, and the phrase "from the other side" is the likeliest place to be tested. EXP because it tests what was actually yours |
| B3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Choose from the two gaps you stated yourself, and say them plainly in your own words, each with one plan sentence. Do not invent a third weakness to look balanced | The stock Skeptic stem. Answering it with your own stated gaps converts a probe into candor |
| B4 | "Why this move, why Kelverton, why now?" | EXP | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Three reasons, each a real one of yours, in your own words. The pack supplies none. For the Kelverton reason, use only what you took from the report you read. If a reason is thin, do not pad it | Motivation consistency is always scored, and the panel includes your future manager. EXP because it tests your account of your own move |

### C. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Say the figure as you gave it, with "roughly" and "influenced" kept. Answer slot, in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Do not say whether it is annual or total unless you know | F3 is the headline figure and Ross is told to push on commercials. EXP because it tests whether the number survives its own assumptions |
| C2 | "What counted as a partner when you got to forty?" | EXP | [grounded] "took it from 6 partners to 40" | Say what counted, in your own words, and whether you would count it the same way today. If you do not know, say so plainly | A count is the easiest number to inflate, so it is probed for its definition. EXP, defend-the-number |
| C3 | "How much of the growth from six to forty was yours?" | EXP | [grounded] "took it from 6 partners to 40"; "last 4 at a payments company running the ISV channel" | Hold what the sentences carry: you ran the channel and took it from 6 to 40. Answer slot: say what was yours in your own words; if others contributed, say who and how; if you cannot separate your part, say so plainly | Attribution is the Prober's second question after the number. EXP, with hold-then-concede |
| C4 | "An operator offers to be a flagship partner if we discount. What do you do?" | CASE | [generic] | Clarify first: what exactly is offered, for how long, and what the operator would do in return. Say what you would ask Ross before replying, including who holds pricing authority. Name the trade-off, offer something other than price, and concede you do not know Kelverton's pricing rules. Quote no prices | A live commercial problem that tests judgment without a past claim. CASE with JD content |

### D. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you rather than someone who has sold into rail for ten years?" | JD | [grounded] "last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40"; "Never sold into rail specifically" | Pause and restate the question. Hold on what you did: you ran the channel and took it from 6 to 40. Concede rail selling in your own words: "I've never sold into rail specifically." Do not argue that rail experience matters less. Close on how you would learn it | A time-boxed version of B1. JD because it scores the same requirement under pressure |
| D2 | "How much of that £4M would have come in without you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Hold the framing you gave: influenced revenue. Concede specifically that the counterfactual cannot be proven. Answer slot: if you know how influence was attributed, say it in your own words; if you do not, say so plainly | The Pressure form of C1. EXP, because it tests composure on attribution |
| D3 | "You've given us fifteen minutes of view. What are you least sure of in it?" | CASE | [generic] | Name the weakest assumption in your own thesis before they do, in one sentence, and one thing that would change your mind. This is the weakest-assumption move applied to the POV | It tests whether you know your own argument's limits. The answer should match the concession you wrote for each thesis in section 5 |

### E. Conversational (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc with only the beats your sentences carry: the consulting years, the nine years in partnerships, the last four on the ISV channel. Your message says consulting came "Before that", so confirm the order before you rehearse. It does not describe the first five partnerships years. Answer slot: if asked, say what those were in your own words. Say why you moved in your own words; if it was not a planned move, say so | The biography question is scored even in a friendly register |
| E2 | "What are you actually following in rail tech these days?" | CO | [grounded] "the market report their strategy team circulated internally last quarter, which I've read" | Answer slot: if you follow anything, name it; if nothing beyond the report, say so plainly and say what in the report you found most useful. Do not invent a reading list | A casual question about a JD-adjacent topic. CO because it scores interest in the domain |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 operator partnerships view | A1, A2, A4, A5, section 5 |
| F2 what it means for operators | A2, B2, E1, section 5 |
| F3 commercials | C1, C2, C3, C4, D2 |
| F4 revenue target | B1, B3, A5 |
| F5 rail | B1, B2, B3, D1, E2 |
| F6 unscripted POV | D3, section 5 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would make the next 18 months a clear success for operator partnerships from where you sit, and what would tell you it had missed?" | It asks Deepa for her own measure of success, which tells you what to emphasize in the POV's last two minutes |
| 2 | "How do partnership targets and commercial targets relate here, and who owns which number?" | It shows you expect to be held to a commercial result, which answers the unspoken quota question from Ross |
| 3 | "What is in the strategy team's report that has changed since it was written?" | It shows you read it as a living document and surfaces any staleness before you lean on it |
| 4 | "What do people coming from outside rail most often underestimate in their first 60 days?" | It faces your gap directly and invites coaching rather than judgment |
| 5 | "Where do commercial conversations with operators tend to stall?" | It is a question for Ross in his own territory and gives you something concrete to reference later |
| 6 | "What would you want me to have learned by the end of 90 days?" | It converts the interview into an agreement on a first-quarter goal with your future manager |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail, or knows how train operators buy | A negative you stated, F5 | "I've never sold into rail specifically." Then a plan, not a past. No slot |
| Has carried a quota or owned a revenue number | A negative you stated, F4 | "I've never carried a direct quota, only influenced revenue." No slot |
| Has worked with train operating companies, or has operator-side experience | Inflated form of F2 | F2's quote at its own scope: "bus and light rail network planning". Your material says bus and light rail, not train operators. B2's slot stays inside the planning |
| Built the ISV channel or grew it to forty partners on your own | Inflated form of F1 | F1's quotes at their own scope: "running the ISV channel", "took it from 6 partners to 40". Your material does not say what share was yours, and C3's slot asks only that |
| Won, closed or generated £4M | Inflated form of F3 | "roughly £4M of influenced revenue", at its own scope. C1 and D2's slots ask only how it was counted and whose part it was |

## 14. Sources

**Provided documents:** your message (your background, the company description in your words, and the recruiter's email as you quoted it). The market report is named in your message, but its content was not supplied, so nothing in this pack draws on it.

**Searches sent, all refused** (the host did not grant search permission):

- "Kelverton Rail values": refused
- "Kelverton Rail interview process partnerships": refused
- "Kelverton Rail strategy train operating companies scheduling software news": refused
- "Deepa VP Partnerships Kelverton Rail": refused
- "Ross Commercial Director Kelverton Rail": refused
- "Senior Partnerships Manager rail technology job description": refused

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The search was refused. It would have fed a values cheat sheet if a values round exists. None is documented, so the section is dropped |
| 2. `Kelverton Rail interview process partnerships` | unavailable | The search was refused. The recruiter's email already establishes this session, so only other rounds are unknown |
| 3. `Kelverton Rail strategy` / recent news | unavailable | The search was refused, and the report's content is not in hand. It would have made A3 and E2 `[grounded]` and filled a grounding brief |
| 4. `Deepa` and `Ross` with `Kelverton Rail` | unavailable | The searches were refused. They would have fed an interviewer read and a reverse question tied to a career path |
| 5. representative `Senior Partnerships Manager` JD | unavailable | The search was refused, and no JD was supplied, so fit-snapshot requirements come from the recruiter's words and from role-family prose |

## 15. Upgrade menu

- The job description pasted in → F1 to F6 requirement cells quote the posting, any gate rows appear, and JD-tagged questions are re-checked line by line against it
- Your CV → the evidence cells quote it, and I can check whether it carries more than your message does on quota, partners or rail
- A line on what the first five of your nine partnerships years covered → a new fit-snapshot row, and the arc in E1 gets its missing middle
- The market report's recommendations pasted in → A3 and E2 become `[grounded]`, section 5 gets a real consensus point and divergence to build on, and a grounding brief is added
- One email to the recruiter asking what "operator partnerships" covers (customer relationships, partners serving operators, or both) and whether Ross wants a commercial model or just numbers → sharpens the first 30 seconds of the POV and A1 to A4
- Search permission granted, or a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the values, loop, interviewer public footprint and recent strategy rows get filled, and an interviewer read is added
- A `tuesday-dossier.md` from job-underwriter → verified evidence and stated limits per requirement, and the most likely objection taken from the evidence rather than inferred
