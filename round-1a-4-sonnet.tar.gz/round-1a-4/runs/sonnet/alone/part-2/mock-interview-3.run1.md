I'll read the skill's reference files first, then build the pack.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-3-denied-91dc8b85/stripe_product-operations-manager_interview_pack.md`. I built it for a final round with an unknown interviewer, and it has 21 questions across seven interview styles.

My web searches were refused, so nothing in it is a fact about Stripe. Everything is labeled `[generic]`, and the pack says so in its Sources section. I also had no CV or job description. Because of that, the guidance for questions about your past tells you how to pick a story. It doesn't write one for you.

The question I'd rehearse most is B1, "Which part of this role would you be weakest at on day one?" Every candidate gets some version of it.

I can play the interviewer on B1 or another question, with follow-ups and feedback against the pack's guidance. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions, and convert the pack to Word if you want.

1. Who are you meeting in the final round, and is it one session or several (hiring manager, peer, cross-functional)? Whatever you know from the recruiter helps too. The answer reweights the question banks.
2. Can you paste the job description and your CV, or a paragraph on your background? If not, I'll keep the pack generic.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

Final round. Interviewer and relationship: not given. Built from your message alone: no CV, no job description, no interviewer name, and no research (the searches were refused, see Sources). Everything here is a rehearsal pattern for the role family, labeled `[generic]`; nothing in it is a fact about Stripe.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your experience survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem |

Where a question asks about your past, the guidance is a selection scaffold that ends in an honest branch. I have none of your sentences yet, so I cannot map a story to a question without inventing it.

## Fit snapshot (worksheet)

No CV, no JD and no recruiter words were given, so this is the worksheet variant. The requirements are role-family patterns written as plain prose, not quotes from a Stripe posting. Fill in the evidence column yourself before the interview, using only things you actually did.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Driving alignment across teams on a product launch or change (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a named launch or change, the teams involved, and the part you personally owned. Selection scaffold: pick an occasion with a named stake and a decision that needed several teams; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Building or running an operating rhythm such as planning, reviews or launch checklists (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed, who used it, and what changed after. Selection scaffold: pick one process where you can say what it was for and who used it; if you never ran one, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Using data to judge how a product or process is doing and to recommend changes (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is one figure you can explain: how it was counted, what it is sensitive to, which part was yours. Selection scaffold: pick a figure you can defend to its assumptions; if you do not know how a figure was counted, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Communicating clearly with senior stakeholders in writing and in the room (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a specific message or review you wrote or ran and who received it. Selection scaffold: pick an occasion where the audience was senior to you; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Structuring ambiguous problems and choosing what to work on first (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is a problem that arrived unstructured and the criteria you used to order the work. Selection scaffold: pick one prioritisation call where you can name the criteria; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | A real reason for this company and this role (role-family pattern, no posting) | none given | none | [generic] | discovery | Strong evidence is reasons that are yours and a source you have read yourself. Selection scaffold: write two reasons in your own words and one thing you read that supports them; if you have not read anything yet, say so plainly and say what you are still learning |

## Persona table

No loop source established the rounds, so persona weights rest on the generic archetype, not on a documented Stripe process: flat weights, and no values-style round assumed. A final round can hold several sessions, so this pack blends the hiring-manager, peer and cross-functional priors. Depth in the banks follows those priors, and you should recalibrate if you know the schedule.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (A) | Live problems: launch readiness, a metric drop, a process that stopped working | High: hiring-manager prior, and the role is operating work, so live problems are the natural test | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet probing of the biggest gap, and why this move now | High: hiring-manager prior; the question is asked of every candidate in some form | Rehearse the weakest-on-day-one answer until it is boring; bridges only from things you actually did; add a concrete ramp plan |
| Peer Evaluator (C) | Seam-splitting, credit, what you need from them | Medium: a final round often includes someone who will sit beside you; relationship unknown, so this is a prior | Reciprocity framing; propose seam principles rather than claiming to know the seam |
| Values / Behavioral (D) | Open prompts about unpopular truths, customers versus metrics, disagreement | Medium: cross-functional prior; no values-style round is assumed, so these ride as open prompts | Pick stories where the hard truth landed; "we" for context, "I" for contribution |
| Data-Driven Prober (E) | Inputs, denominators, assumptions behind any number you give | Medium: peer and specialist prior, and an operations role leans on metrics | Say how each figure was counted, name the assumption you would defend least, say plainly when you do not know |
| Pressure (F) | Time-boxed challenge, "why you", "how much was you" | Low to medium: a skip-level or bar-raiser prior, which I cannot place in your loop | Pause, restate, hold through two follow-ups, then concede specifically |
| Conversational (G) | "Walk me through the journey", "why here" | Medium: always present somewhere, and casual questions are still scored | A 90-second arc built from your own CV sentences; treat casual questions as scored |

## Question banks

Highest-ROI prep: B1, "Which part of this role would you be weakest at on day one?" It is asked of every candidate, so it does not depend on a CV I have not seen. A CV would let me aim it at your real gap.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch is two weeks out and three teams disagree on whether it is ready. How do you get to a decision?" | CASE | [generic] | Structure aloud: what ready means and who decides; the facts each team is relying on; the options and the cost of each; a decision path with an owner; how it gets recorded and communicated. Challenge one premise, for example whether the two weeks is fixed. The question needs no claim about your past, so the guidance makes none | Covers F1 and F5 as a live problem. CASE because it scores structure, not recall |
| A2 | "A team's weekly planning meeting has stopped being useful and people skip it. How would you diagnose it and what would you change?" | CASE | [generic] | Clarify what the meeting is for and who it serves; gather what attendees say and what decisions it actually produces; list options from fixing to retiring it; say how you would tell it worked. Think aloud and name the option you would try first and why | Covers F2. CASE because it is a diagnosis delivered live |
| A3 | "An adoption metric for a recently launched product dropped 15% week over week. Walk me through your diagnosis." | CASE | [generic] | Clarify the metric's definition and how it is collected first, then recent changes, segments and timing, then the likeliest causes in order, then what you would check first. Name the assumption you would test before acting | Covers F3. The 15% is the interviewer's hypothetical, not a fact about you |
| A4 | "You have ten process problems across product teams and capacity for three. How do you choose?" | CASE | [generic] | Name your criteria aloud, such as who is affected and how often, cost of waiting, effort, and dependencies. Say which criterion you would drop under time pressure, and which problem you would deliberately leave unfixed and why | Covers F5 and F2. JD content, CASE delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Choose the weakest area honestly from your own material, state it in one plain sentence, then give a concrete ramp plan: what you would learn, from whom, in the first month. Do not pick a disguised strength. If you cannot name one, look at the F rows with no story and start there. Hold through two follow-ups by returning to the plan, never by adding to what you have done | The most predictable question in any version of this loop, so it gets the deepest rehearsal. Covers every F row at once |
| B2 | "What is the biggest difference between what you have done so far and what this role asks?" | JD | [generic] | Name the difference in your own words without apology. Then give the nearest thing your material does carry, at its own scope, and how you would close the rest. If you cannot name the nearest thing, say so plainly and describe how you would handle it | Skeptic stem aimed at the gap without presupposing one. Covers F1 to F5 |
| B3 | "Why this move, and why now?" | EXP | [generic] | Give your own reason in two or three sentences, forward-looking, with no blame on a past employer. It has to be consistent with your answers to G1 and G2. If your reason is mixed, say the true mixed version | Motivation consistency is what a skeptic scores. Covers F6 |
| B4 | "What would make you fail in this role in the first six months?" | JD | [generic] | Name a real risk, such as getting pulled into reactive work or underestimating a stakeholder map, then say what you would do early to guard against it. Keep it a plan, not a history | A future-facing cousin of B1, so it tests whether B1 was candid. Covers F5 |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose seam principles instead of claiming to know the seam: who owns the decision, who is consulted, how you escalate, how you disagree in the open. Say what you would ask them first. No claim about your past is needed | Peer stem. Covers F1 |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say your principle in one sentence, then, if an example from your own material carries it, tell it with "we" for context and "I" for your part. If no example comes to mind, say so plainly and describe how you would handle it | Peer stem on credit. VAL because it scores behavior, not a skill |
| C3 | "What would you need from my team in your first month, and what can you give us?" | JD | [generic] | Lead with what you would give, such as a clear view of what is slowing them down, then what you would need, and keep both modest. Do not claim a result you have not delivered | The reciprocity question a peer asks. Covers F1 and F4 |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. Covers F4 |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick an occasion where the two pulled apart and you can say what you chose and what it cost. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Persona stem. Covers F6 and F5 |
| D3 | "Tell me about a disagreement with a colleague on another team, and how it ended." | VAL | [generic] | Selection scaffold: pick one where you can show spine and tact together, with the outcome stated as it was, not improved. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer-style disagreement story in behavioral form. Covers F1 |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a result you are proud of that had a number attached. How was the number counted?" | EXP | [generic] | Choose a figure you can defend. Say how it was counted, what it is sensitive to, which assumption you would defend least, and exactly which part was yours. If you do not know how it was counted, say so plainly. If you have no figure, choose a result without one and say what you would have measured | Defend-the-number rehearsal, built as a slot because no figure was given. Covers F3 |
| E2 | "What would you measure to know a product operating process is working?" | JD | [generic] | Name two or three measures, say what each would miss, and name the one you would trust least. Ask what the process is for before choosing | Covers F3 and F2 with no claim about your past |
| E3 | "Tell me about an analysis you did yourself, end to end." | EXP | [generic] | Selection scaffold: pick one you can walk through from question to decision, including what you would do differently. If no analysis was yours end to end, say so plainly and say which part was | Persona counter-strategy turned into a prompt. Covers F3 |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then give two points drawn from your own material and nothing wider. Hold through two follow-ups, then concede specifically what an internal candidate would know that you would have to learn | Persona stem. Covers F6 |
| F2 | "That result. How much of it was actually you?" | EXP | [generic] | Asked after E1, D1 or D3. State your part plainly in the words you used before, concede what others did, and do not fold on the part that was yours | Persona stem; attribution honesty is what it scores |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc from your own CV sentences: where you started, two or three turns in your own words, and why this role. I cannot draft it without your CV. If a turn in your path has no clean reason, say so plainly rather than inventing one | Opening biography question; casual but scored. Covers F6 |
| G2 | "Why Stripe, and why product operations?" | CO | [generic] | Give two reasons in your own words and one thing you have read yourself that supports them, naming where you read it. I could not research Stripe, so this pack cannot supply a fact about it. If you have not researched yet, say so plainly and say what you are still learning | Covers F6. CO, but ungrounded until research is run |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Cross-team alignment | A1, B2, C1, C3, D3 |
| F2 Operating rhythm | A2, A4, E2 |
| F3 Data and judgment | A3, E1, E2, E3 |
| F4 Senior stakeholder communication | B2, C3, D1 |
| F5 Structuring ambiguity | A1, A4, B4, D2 |
| F6 Reason for company and role | B3, D2, F1, G1, G2 |

## Reverse questions

No interviewer profile exists, so these are role-generic.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first 90 days look like, and what would you most want changed by then?" | Shows you are planning toward a result, and the answer tells you what the role is really for |
| R2 | "Which teams does this role work with most, and where does that seam usually get tested?" | Shows you think in seams, and it answers C1 for real |
| R3 | "What does a good operating review look like here, and what is it missing today?" | Invites them to name a real problem you could help with |
| R4 | "What is the hardest part of this job that the description does not say?" | A candid question that tends to get a candid answer |
| R5 | "How is the success of this role measured, and who decides?" | Connects to the measurement questions you rehearsed in E2 |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer; it signals partnership, not entitlement |

## Prohibited claims

Nothing is listed. No sentence of yours was given, so there is no wording to inflate and no negative you stated. Every claim about your past in this pack is an open prompt or a selection scaffold, so say only what you actually did.

## Sources

Provided documents: your message only (final round, Stripe, Product Operations Manager). No tuesday-dossier.md was present.

Research tier: L1, searches 4 of 6, fetches 0 of 2

Queries sent, all refused: "Stripe operating principles values"; "Stripe interview process product operations manager"; "Stripe strategy news 2026"; "Stripe Product Operations Manager job description".

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search refused. Would have supplied the published value names for a values cheat sheet; section dropped |
| 2. Stripe interview process, product operations | unavailable | Search refused. Would have established the loop; persona weights fall back to the generic archetype |
| 3. Stripe strategy and recent news | unavailable | Search refused. Would have grounded the CO bank; G2 stays ungrounded |
| 4. Interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative Product Operations Manager JD | unavailable | Search refused. Would have turned the six F rows from `[generic]` to `[inferred]` quotes |

## Upgrade menu

- The job description text → the F rows become quoted `[grounded]` requirements, and every JD question can aim at your real list
- Your CV or a paragraph on your background → the evidence column fills in, selection scaffolds become story maps, and B1 gets aimed at your real gap
- The interviewer's name and role, or the recruiter's prep email → the interviewer read, tuned persona weights, one reverse question tied to their path, and any pre-declared deliverable
- The schedule, if your final is several sessions → per-session mini-packs with their own persona weights
- Permission to run web search → Stripe's published values, a documented loop and current strategy; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add interviewer talks and role-family loop reports
- A tuesday-dossier.md from job-underwriter → verified evidence and sourced limits for each weak area, in place of the objection inferred here
