I'll read the reference files the skill points to before writing anything.
The pack is saved. I built it for a single 60-minute peer conversation with Dan.

Two web searches were refused: one for Northwind's published values and one for Dan's public footprint. The interviewer read rests only on the profile you described. The company context comes from your research note. The pack lists both searches under Sources and the missing inputs in the upgrade menu.

File: `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-2/rooms/case-1-denied-fd492d29/northwind-data_senior-gtm-strategy-lead_interview_pack.md`

It has 24 questions across seven personas, weighted toward the Skeptic and Peer Evaluator. Each has a type, provenance, answer guidance and rationale. It also has a fit snapshot, interviewer read, requirement-coverage table, six reverse questions, a list of claims it won't coach, and the sources and upgrade menu.

The highest-ROI rehearsal is C1, the "no classic sales-ops or quota-setting" objection. The guidance has her concede it plainly and hold only "set annual volume targets with cross-org consensus". She shouldn't call those targets quotas.

Say the word and I'll play Dan as the Skeptic on C1, with reactive follow-ups and feedback against that question's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word if you'd like.

Has the recruiter or the VP said what Dan will focus on, or announced any deliverable such as a POV, a case or a presentation? A yes adds a build section and reweights the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy — a peer (both report to the same VP). **Format:** one 60-minute conversation. **Candidate:** Priya.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Every row carries both, plus a provenance label and a rationale.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether claims about the past survive scrutiny and attribution probes |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge, at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

Guidance is scaffolding, not a script: it is proposed language, pending your approval, and you rehearse only what you actually did, in your own words. An "answer slot" is an instruction for the interview, not a question for this conversation. Say what is true for you, or say plainly that it was not yours or did not exist.

**The highest-ROI prep in this pack is C1**, the "no classic sales-ops or quota-setting" objection. It comes from a peer who runs Sales Strategy, so it will arrive in some form. Rehearse it until it is boring.

## Fit snapshot

The JD side comes from the highlights in your message; the evidence side is your notes on Priya. Confidence and gap type each hold one token.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, which is adjacent to taking new lines to market and not the same task; the words stay at "product strategy & ops". Answer slot: the JD's two-new-lines wording makes a probe on launch work likely. If any of that work was about taking a new offering to market, say what part was yours and how you decided; if none was, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | discovery | The quote shows a proposal and a credited uplift; it does not show how the opportunity was found or whether it touched a customer lifecycle. Answer slot: the JD's lifecycle line makes a probe on how the idea arose likely. If you found it through analysis, say what you looked at; if it came another way, say so plainly and stay with the proposal. Keep "proposed" and "credited with" exactly as they are |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap in terms, but a line of notes with nothing inspected behind it, so expect a request to walk through real work (B3, B4). Lead in the quote's own terms: skilled in SQL/Tableau. Answer slot: the JD says independent. If the analyses were yours end to end, say so; if others set the question or pulled the data, say so plainly and describe what you did |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model that was used in negotiations: economics, not a motion, and use in negotiations, not conduct of them. This is the requirement the JD marks as required, so expect it to be tested hardest (C3). Answer slot: if any part of how the partnership ran was yours to set, say what and how you decided; if none was, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote reaches the requirement in role terms; lead with it as written. Answer slot: expect a probe on who disagreed. If any org pushed back, say who, what, and how it resolved; if consensus came without friction, or the mechanism was not yours, say so plainly and stay with the targets |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | The quote carries use of AI tools, at that scope; the words stay "uses AI tools daily". Answer slot: expect "what are you doing with them". Say which tools and which tasks, in your own words; if a use is thinner than daily, say so |
| F7 | classic sales-ops and quota-setting fluency, the home turf of a Sales Strategy peer (the JD highlights do not list it; plain prose, no quote) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it was stated. Words: "I don't have classic sales-ops or quota-setting experience." Then a ramp plan, said as a plan and never as a past. Never describe volume targets as quotas, and nothing added to make the gap smaller |

## Interviewer read

Based on the profile as you described it. Public searches were refused, so nothing here comes from outside your message.

| Signal (source) | What it implies for the conversation |
|---|---|
| Self-described "relentlessly data-driven" — Dan's profile, your message | Every figure you give gets followed two levels down. The Prober bank (B) is weighted up for this reason, and F3's probe on real work is near-certain |
| "career spine is pricing and monetization roles" — Dan's profile, your message | Case questions tilt toward packaging, pricing and unit economics (D2, D4). Pricing and monetization is his native vocabulary, so use it carefully and ask him rather than lecture |
| "one early-stage-startup chapter" — Dan's profile, your message | Expect a probe on how you work without large-company data and headcount (C5). Nothing in your material carries a startup story, so none is offered |
| Peer, same VP — your message | The conversation is partly "what does this hire do to my load". See A1, A4 and the reciprocity reverse question |

**Mirror opportunities.** Two, each paired with a quoted sentence and no more:
- Shared vocabulary, ARR and monetization, which his path and F2's "proposed a store-surface change credited with a ~$400M ARR uplift" both touch. Use F2's words at their own scope; do not claim pricing work.
- Shared data language: his "relentlessly data-driven" against F3's "skilled in SQL/Tableau".

No shared career jump is offered: no row's evidence carries your side of one.

## Persona table

The loop is one 60-minute conversation with a peer, per your message; no values-style round is documented, so Values is weighted down. Weights follow the relationship prior (Peer Evaluator plus Data-Driven Prober), adjusted by Dan's signals.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| A. Peer Evaluator | Seam-splitting between GTM strategy and Sales Strategy; "what do you need from me"; credit across teams | **High.** Peer relationship, shared VP; the hire changes his workload | Reciprocity framing; propose seam principles, not a pretend seam; one disagreement story that shows spine and tact only if a real one exists (see A2) |
| B. Data-Driven Prober | Reads claims line by line; asks how a number was counted | **High.** "Relentlessly data-driven" plus F2's headline figure | Know and say what you can and cannot say about how the figure was counted; name the assumption you would defend least before he does |
| C. Skeptic | Quiet probing of the gaps: no quota-setting, partner-motion depth, big-company background | **High.** F7 is a stated gap sitting in his function; F1 and F4 are adjacent-only | Rehearse C1 until boring; bridges only from quoted adjacent work; a ramp plan stated as a plan |
| D. Case / Strategist | Live problems on Compass, bundling, pricing, profitability | **Medium to high.** Pricing and monetization spine tilts cases toward packaging and unit economics; the role owns GTM for new lines | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| E. Conversational | Friendly "walk me through the journey" and "what are you playing with in AI" | **Medium.** Every interview opens somewhere; the JD flags AI as a plus | A 90-second arc built only from quoted sentences; treat casual AI questions as scored |
| F. Pressure | Time-boxed "why you" and "how much was you" | **Low to medium.** A peer's register is collegial, but both lines return in collegial packaging | Pause, restate, anchor in what you stated; hold through two follow-ups, concede specifically |
| G. Values / Behavioral | Stories of unpopular truths and customer-over-metric | **Low.** No values-style round is documented, and Northwind's published values could not be retrieved | Selection scaffolds only; the honest branch is available on every row |

## Question banks

Each Provenance cell leads with one label and carries every sentence the guidance rests on.

### A. Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where do you see the seam between GTM strategy for the new lines and Sales Strategy, and what happens when we disagree?" | JD | [generic] | Ask where the seam sits today before proposing one. Then offer principles: who decides and who is consulted is written down up front; shared data definitions come before any argument about the numbers; disagreements start from the data, then go to your shared VP only when they must. Invite his view on each principle. The guidance makes no claim about your past | The role's cross-functional line (F5) plus the peer relationship make the seam the likeliest opening. JD because it scores the stated requirement; the delivery is collegial, which is the Peer persona |
| A2 | "You set targets that touch my team's numbers. How did you get several orgs to agree on one?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Tell it at the sentence's scope: you set annual volume targets, with consensus across orgs. Answer slot: expect a probe on who disagreed. If any org pushed back, say who, what, and how it was resolved, in your own words; if consensus came without friction, or the mechanism was not yours, say so plainly and stay with the targets. Call them volume targets, never quotas | F5 is the evidence for the influence requirement, and a peer will test whether the consensus was earned. EXP because it tests what was actually yours; the word-choice warning comes from F7 |
| A3 | "When work spans teams, how do you handle credit?" | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | An open prompt with a theme from the Peer persona. If the store-surface change is your example, hold the sentence's own verbs: you proposed it, and it was credited with the uplift. Answer slot: if others built or shipped it, say who did what; if you only proposed it, say that plainly. If a different story fits better, pick one where you can name the other teams and what each did | A peer prices credit-sharing because it predicts how the hire behaves around his team. F2's figure is the obvious example, and the verbs must survive a follow-up. VAL because it scores behavior toward others, not a skill |
| A4 | "What would you need from my team in your first 90 days, and what would you bring us?" | CASE | [grounded] "skilled in SQL/Tableau" | The reciprocity answer. Bring: you can run analysis yourself, in the quote's words, "skilled in SQL/Tableau", which means fewer requests to his team for pulls; say which analysis you would run first, as a plan. Ask for: access to the data, the definitions his team already uses, and the history behind current goals and pricing. All plan, no past | Reciprocity is what a peer is scoring: does the hire reduce or add to my load. F3 carries your side. CASE because it asks you to plan a first 90 days live |
| A5 | "If a new line's pricing and its partner motion pull in opposite directions, how do we settle it?" | CASE | [generic] | Structure it: name what each side is optimizing, agree the one metric both answer to, test it on a small cut of data, and decide who has the final call before the disagreement, not during it. Ask how he has seen this settle. No claim about your past | Pricing is his native ground and partner motion is the JD's required item (F4), so the collision is a natural peer case. CASE because it is a live problem; generic because it is a pattern, not a fact about Northwind |

### B. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Four slots, in your own words, none supplied here: how it was counted; what it is sensitive to; the assumption you would defend least, named before he asks; which part was yours. If you do not know how it was counted, say so plainly, and say who would. Hold "proposed" and "credited with" | The headline metric on the CV is where a data-driven peer starts (F2). EXP because it tests the number's provenance |
| B2 | "You proposed the change. What part of that uplift was yours, and what part was other people's?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The attribution follow-up. Say what the sentence says: you proposed it. Answer slot: who else was involved and what each did, in your own words; if you do not know how the credit was split, say so plainly. Never say you delivered or owned the uplift | The second level down on the same number; F2's wording is "proposed" and "credited with", and a follow-up probes the gap between them. EXP, attribution |
| B3 | "Walk me through the partner-level revenue model you built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Describe what it was and how it was used, in the sentence's terms: a partner-level revenue model, used in carrier negotiations. Answer slot: the JD's SQL and Tableau line makes a probe on how it was built and checked likely. If you built or checked it yourself, say which tools and how; if others did, say so plainly and stay with the model and its use. Name the assumption you would defend least only if you know it | F4 and F3 meet here. A data-driven peer asks to see the work behind a claimed model. EXP, with JD content |
| B4 | "Tell me about the last analysis you ran end to end in SQL or Tableau: what did you ask, what did the data say, what did you do?" | JD | [grounded] "skilled in SQL/Tableau" | An open prompt; the theme comes from the JD's independent-analysis line. Pick one where you can say the question, the finding and the decision, in that order. If no such analysis comes to mind, say so plainly, then give the nearest work your material does carry, or how you would approach a first analysis for one of these lines | F3 is a bare skills line, and the JD says independent. JD because it scores the stated requirement; the open form tests whether the claim has a real instance behind it |

### C. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You haven't done classic sales ops or quota-setting. How does that work in a role that sits next to mine?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" | **Highest-ROI rehearsal.** Concede first, in plain words: "I don't have classic sales-ops or quota-setting experience." Then hold at the quote's scope: "I set annual volume targets with cross-org consensus." Do not call them quotas or say they are equivalent. Follow-up 1, "isn't a volume target the same thing?": say what the sentence says and no more. Follow-up 2, "what would you get wrong first?": say what you would ask his team before proposing anything, a plan and not a past. Limit named before he asks: the material does not show quota work | F7 is the stated gap and the one a Sales Strategy peer owns. JD because it scores fit for the role; Skeptic because it is asked quietly and persistently. Deepest rehearsal is justified because it will be asked in some form |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] | Choose the line from your own view. Your material is adjacent rather than direct on F1 and F4 and shows a stated gap on F7, so one of those is a safe choice. Say plainly where your material stops, then give the ramp plan. Do not pick a trivial weakness to look modest | A persona stem, and a direct test of honest self-assessment. JD because it asks about the listed job; the answer carries no claim about your past, so the label stands alone |
| C3 | "Partner-motion design is a requirement here. What part of a partner motion have you owned yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only the quote: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of how the partnership ran was yours to set, say what and how you decided, in your own words; if none was, or it was not yours, say so plainly and describe the model and its use. The honest branch is a limit, not a confession. Hold through two follow-ups by returning to the model, never by adding to it | F4 is the one requirement the JD marks as required, and the quote is economics, not a motion. The rationale for JD is that this is the stated requirement; Skeptic is the delivery |
| C4 | "Why leave a large consumer-tech company for B2B data infrastructure, and why Northwind?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | The reason is yours: say it in your own words, in one or two sentences. For "why Northwind", you can draw on the three priorities you found (enterprise expansion, the Compass launch, profitability) and say which one pulls you and why. Do not offer a reason you do not hold | A motivation-consistency probe from a Skeptic; the career move is the biggest visible discontinuity (F1). JD because it scores fit and intent, and the research note supplies the company-specific half |
| C5 | "You've spent nine years at a very large company. How do you work when the data and headcount aren't there?" | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Selection scaffold: pick a time you got a result with less than you wanted, naming what was missing, what you did instead, and what came out. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would work with a smaller team on two new lines. No claim of a startup story | Dan's one early-stage chapter makes the pace-and-resources probe likely (interviewer read). EXP because it tests whether the big-company record transfers; F1's quote is the only anchor, so the rest is scaffold |

### D. Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Compass is launching, and a much larger platform vendor can bundle a rival into its suite. Sketch the GTM plan. What do you need to know first?" | CO | [grounded] | Clarify first: who the buyers are, what Compass is sold alongside, how the larger vendor packages its offer, and what the profitability goal limits. Then objective, segmentation, approach, metrics, risks, thinking aloud. Differentiate from the research note: bring one consensus item to show grounding, then one position of your own with reasons, and one thing you would decline to do. State one hypothesis early and what data would overturn it | Compass and the bundling threat are in your research note as the launch and the main competitive threat. CO because it needs company knowledge; the persona is Case. Dan's pricing lean makes the pricing angle D2 |
| D2 | "How would you think about packaging and pricing a new line: standalone, add-on, or bundled, given the bundling threat?" | CASE | [generic] | Structure: what the value is and who pays for it, what the alternatives and the bundled rival cost the buyer, which packaging options fit each segment, and the evidence you would pull before committing, in SQL or Tableau. Ask him how Northwind has priced before; it is his ground and invites him to lead. No claim about your past | His career spine is pricing and monetization, so this is likely and he will notice thin pricing logic. CASE, generic because it is a framework for the problem, not a fact about Northwind's pricing |
| D3 | "For a brand-new product, where is the whitespace across land, adopt, expand and renew, and how would you find it with the data we have?" | CASE | [grounded] "skilled in SQL/Tableau" | Structure by stage. For each: what signal says a customer is stuck or ready, which table or dashboard you would ask for, and what decision it would change. Use the quote only for the tool claim: "skilled in SQL/Tableau". Close with the first cut you would run and what would make you wrong. Plan only | F2's requirement as a live problem, and F3's quote as the means. CASE because it is a live problem; JD content |
| D4 | "Profitability is a priority and you're asked to grow two new lines. How do you decide where the first dollar of GTM investment goes?" | CO | [grounded] | Ask what profitability means in numbers and timeframe. Then rank options by expected payback and by what each protects against the bundling threat, say what you would not fund, and name the metric you would check at ninety days. Plan only | Profitability is one of the three priorities in your research note, and the tension with launching two lines is the case. CO because it needs the company's stated priorities |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc of three beats the sentence states: two years of strategy consulting, nine years in product strategy and ops at a consumer-tech company, then this role. For the third beat, say your own reason. If you add work highlights, use them as quoted: "built a partner-level revenue model used in carrier negotiations", "set annual volume targets with cross-org consensus" | The casual register hides a scored question, and the arc is the one answer you can fully script (F1). EXP because it checks the story against the record |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Answer slot: say which tools and which tasks, in your own words, and one thing they are bad at. If a use is thinner than daily, say so. Connect to Compass lightly, as curiosity and not as experience building such a product | The JD flags AI as a plus (F6) and Compass is an AI copilot, so the question will arrive casually. JD because it scores the stated plus |

### F. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has lived in sales ops?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "built a partner-level revenue model used in carrier negotiations" | Pause and restate. Concede in one clause, plainly: "I don't have classic sales-ops or quota-setting experience." Hold on what the quotes carry: "I built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus". Then stop; do not argue that it is equivalent | The C1 objection, delivered under time pressure (F7). JD because it scores fit; Pressure because it tests holding a position without defensiveness |
| F2 | "That ARR number: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Hold through two follow-ups by returning to those words. Concede specifically: say what you do not know about how the credit was assigned. Never fold into "it was all me" or "it was a team effort" | F2's attribution under stress; B1 and B2 are the collegial versions. EXP because it tests precision about your own role |

### G. Values / Behavioral (weight 2)

Northwind's published values could not be retrieved (see Sources), so these are generic persona stems, not mapped to named values.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; low weight because no values round is documented. VAL because it scores behavior |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer's interest and a target pulled apart, say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem for customer-first framing. VAL because it scores behavior |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| own GTM strategy for two new product lines | A1, C2, C4, D1, D2, D4 |
| identify whitespace across land/adopt/expand/renew | D3 |
| run independent analysis in SQL and Tableau | B3, B4, A4, D3 |
| partner-motion design experience required | C3, B3, A5 |
| strong cross-functional influence | A1, A2, A3 |
| AI experience a plus | E2, D1 |
| sales-ops and quota-setting (not in the JD highlights) | C1, F1 |
| headline metric (the ~$400M figure) | B1, B2, F2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've worked across pricing and monetization and an early-stage startup before Sales Strategy here. What carried over, and what didn't?" | Ties to his own path and invites a peer conversation about the same jump you are making |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are thinking about his load |
| R3 | "How do you and our VP split decisions between Sales Strategy and GTM for the new lines, and where have you already disagreed?" | Surfaces the seam A1 probes, and shows you want it explicit |
| R4 | "Which of land, adopt, expand and renew is thinnest on data today for the new lines?" | Shows you plan to start from the data, which he will value |
| R5 | "How is the bundling threat showing up in customer conversations right now?" | Signals current knowledge of the competitive frame in your research note and asks for ground truth |
| R6 | "What would someone in this role most likely underestimate in their first quarter?" | A rapport question that earns real information and shows humility |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has quota-setting or sales-ops experience, or treats volume targets as quotas | Negative the candidate stated, F7 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." F5's quote at its own scope: "set annual volume targets with cross-org consensus". No slot |
| Owned, delivered or measured the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". The limit is the pack's observation: the material says proposed and credited, not delivered or measured |
| Designed the partner motion, or led the carrier negotiations | Inflated form of F4 | F4's quote at its own scope: "built a partner-level revenue model used in carrier negotiations". The limit: a model used in negotiations, not their conduct or a motion's design |
| Owned GTM strategy or launched a product | Inflated form of F1 | F1's quote at its own scope: "9 at a large consumer-tech company in product strategy & ops". The limit: product strategy and ops, not GTM |
| Has AI product or AI strategy experience | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily". The limit: use of tools, not building or launching |

## Sources

Provided documents: your message (JD highlights, Priya's background, Dan's profile description, the research note on Northwind's three priorities and its main competitive threat). No dossier was present.

Searches sent:
- "Northwind Data company values B2B data infrastructure" — refused
- "Dan Kovac Director of Sales Strategy Northwind Data" — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Search refused. Would have named published values for VAL themes; no values-style round is documented, so section 10 is absent either way |
| 2. interview process, role family | skipped | Your message fixes the loop: one 60-minute conversation with a peer. Persona weights follow from that |
| 3. strategy and recent news | skipped | Your research note supplies the three priorities and the competitive threat; it feeds D1 and D4. The note is undated, so treat its currency as unchecked |
| 4. Dan Kovac, Northwind | unavailable | Search refused. The interviewer read rests only on the profile as you described it; public talks or writing could add themes and a tailored reverse question |
| 5. representative JD | skipped | JD highlights were supplied and fix the fit snapshot and JD-tagged rows |

## Upgrade menu

- The full JD text: the six requirement rows now rest on your highlights; full text would turn mid-list items into quoted rows and may add requirements with no question
- Priya's CV: evidence moves from your notes to her own lines. For this field an inspectable artifact would raise F2, F3 and F4 above medium: the memo or deck behind the store-surface proposal, a sanitized Tableau or SQL work sample, or the revenue model itself with the negotiation it fed
- Permission to run web search: Northwind's published values, Dan's public talks or writing (tailored reverse questions, interviewer themes), and the research note's currency. A deeper pass is up to 6 more searches and 2 more fetches, several more minutes
- The recruiter's or VP's stated focus areas or any announced deliverable: adds graded-deliverable build sections and reweights the banks
- Which two product lines the role owns, and whether Compass is one: restructures D1, D4 and the CO weighting
- Your answers to the answer slots in F1, F2, F4 and F5: each becomes quoted evidence and turns an answer slot into a story map
- A tuesday-dossier.md, if you have one: verified evidence and prohibited claims arriving from elsewhere would replace this pack's locally built list
