I'll read the reference files the skill points to before building the assessment.
Research is done, and the assessment follows.

## Decision snapshot

**Should you go for it? On evidence, probably yes. I wouldn't commit until the remote-versus-Leeds conflict (R1, RR1) is settled. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6a, R7 · adjacent: R6b (monitor rating models)
- `important`: direct: R8a · unclear: R8b (recommendations to product)
- `preferred`: direct: R9

R6b (`low`): build is evidenced, monitoring is read downward; R8b (`none`): product side not evidenced.

**Opportunity ledger.** The posting you pasted and the employer's own careers page disagree on location (RR1). Pay is not stated (RR2). Little public footprint beyond the careers page (RR3). Team size and authority are unstated (RR4). The reporting line and scope are clear (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Awaited answers:** which location term is current (R1, RR1), and your own limits on location and pay. If you need remote and the Leeds term is current, R1 becomes `hard_gate_fail` and the status `no_go`. If the role is remote, or you can do Leeds four days a week, it moves to `go` or `conditional_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. The careers page lists this role and the product, but a company-level search found nothing | `[grounded]` JD header and careers page |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, give recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page |
| Working pattern | Contradiction. The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` both quotes |
| People management | The JD lists none, so "never managed anyone" does not meet a stated requirement | `[grounded]` JD silent |
| Hiring manager | Director of Pricing. Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors" (monitoring rating models in small books). Previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result, page not opened |
| Scope read | The talk topic suggests model monitoring matters to this reader, which makes R6b the row to firm up | `[inferred]` from the talk title against the JD's "build and monitor" |
| Seniority read | Your 5 years, the last 2 as senior analyst, sit comfortably against "4+ years" for a senior title | `[inferred]` from your stated years against the JD |
| Pet-insurance knowledge | The JD asks only for "insurance experience a plus". Pet-specific rating is not listed as a requirement | `[grounded]` JD |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900. The posting states no figure, so this is what to expect and not this employer's offer (RR2) | `[generic]` pay survey, 2026, n=612, read from a search snippet only; `[grounded]` JD for the withheld figure |
| Unknowns | Location, pay, team size, who underwrites the policies, decision rights | — |

## Evidence map

Your background is typed prose, so I treat it as CV-equivalent: confirmed claims, nothing yet inspected.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You have not stated a location constraint. The JD and the careers page conflict, so the gate is not settled | `[grounded]` JD and careers page quotes | Confirm your limit and the current term (G1) |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years pricing analytics at a UK motor insurer, the last 2 senior. Confirmed, not yet inspected | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily". Confirmed, with no artifact yet | `[grounded]` your background | Optional: a sanitized notebook or query sample |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver motor book | `[grounded]` your background | Optional: sanitized model documentation |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Present the quarterly pricing review to the head of underwriting | `[grounded]` your background | Optional: a sanitized review deck |
| R6a | Build rating models | must_have | direct | medium | none | Same GLM build as R4. The book was motor, not pet | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | adjacent | low | discovery | You said "maintained", which does not say whether you tracked performance, drift or errors. I read ambiguity downward. Pet books are often small, so monitoring may weigh more here | `[grounded]` your wording; `[generic]` that small books make monitoring harder | G2 |
| R7 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your background | Optional: a sanitized test readout |
| R8a | Recommendations to underwriting | important | direct | medium | none | The quarterly review and the tests were both with underwriting | `[grounded]` your background | none |
| R8b | Recommendations to product | important | unclear | none | discovery | Nothing stated about product teams | `[grounded]` silence in your background | G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a motor insurer. Your experience is motor, not pet | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location terms (R1, hard_gate) | hard_gate | Two employer sources disagree, and I have no limit from you | A failed gate caps the decision however strong the fit | Whether you can be in Leeds four days a week, or need fully remote | The live posting you applied from, or the recruiter's written answer | `[grounded]` the two quotes; `[inferred]` that this decides the status |
| G2 | Monitoring rating models (R6b, must_have) | discovery | "Maintained" is the only word on this | A must-have at `adjacent`. The hiring manager has spoken on this topic | Tracking actual versus expected loss ratios; drift or segment alerts; a model refresh triggered by monitoring; a post-launch review of a rating change | A monitoring dashboard, a review note, or a refresh memo, sanitized | `[grounded]` your wording; `[inferred]` from the talk title that it matters |
| G3 | Recommendations to product (R8b, important) | discovery | Underwriting is evidenced, product is not | The role names both audiences | A test result that changed a product feature or proposition; a pricing input to a product launch; work with product or commercial teams | A readout or memo naming the product audience | `[grounded]` silence on product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Contradictory location terms (see R1) | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | The pasted JD may come from an older or different channel, or the careers page may be out of date. Medium, not high: the employer's own page is a plausible source for either | `[inferred]` from the two quotes; `[generic]` that postings are often copied or republished | Is this role fully remote, or based in Leeds four days a week, and which is current? | unresolved |
| RR2 | Pay not stated in the JD | unknown | — | JD gives no figure | Pay may or may not fall within the band in role reality | `[inferred]` from the JD's silence against the `[generic]` band | What salary range is budgeted for this role? | unresolved |
| RR3 | Little public footprint beyond the careers page | unknown | — | JD: "Brindlemoor (insurtech)" | A company-level search returned nothing. The careers page does confirm the role, product and reporting line | `[grounded]` search result and page; `[generic]` that small insurtechs often have thin footprints | What stage is the company, and who underwrites the policies? | unresolved |
| RR4 | Team size and authority unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The JD does not say whether you would be the only analyst, or what you could decide without sign-off | `[inferred]` from the JD's silence | Who else sits in pricing, and which pricing decisions does this role make? | unresolved |
| RR5 | Clear mandate and reporting line | positive_signal | — | "reports to the Director of Pricing" | The scope and the manager are stated, and the manager has a published pricing background | `[grounded]` careers page and search result | What would success look like in the first year? | noted |

## Application plan

Every row is proposed, not applied. I checked the lines below clause by clause against your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the location term with the recruiter or Odile's team before investing in an application | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the verification questions from RR1 to RR4 verbatim when you speak to them | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Be explicit that your experience is motor, not pet, and don't claim pet-insurance or people-management experience | You have neither, and neither is required | `[grounded]` your background and JD | pending your approval |

`resume_edits_pending_approval`

| # | Proposed line, from your words | Source |
|---|---|---|
| E1 | Built and maintained the GLM rating model for the young-driver motor book | "built and maintained the GLM rating model for our young-driver book" |
| E2 | Ran 14 price tests last year with the underwriting team | "ran 14 price tests last year with the underwriting team" |
| E3 | Present the quarterly pricing review to the head of underwriting | "I present the quarterly pricing review to the head of underwriting" |

Positioning advice, pending your approval: lead with E1 and E2 together, since the JD pairs rating models with price tests. Then add E3 for the presenting requirement. Hold any monitoring claim until G2 is answered.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance", which returned no results and so did not establish the company, and "Brindlemoor careers Senior Pricing Analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved: the contradictions row, R1, RR1, RR3 and RR5. The fetch added nothing beyond the search snippet |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read from the snippet only. Moved: market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read from the snippet only. Public professional facts only. Moved: the hiring-manager and scope-read rows, and the positioning advice |

I can make `tuesday-dossier.md` from this assessment whenever you want it.

## Upgrade menu

- Your stated limits on location and pay would settle R1, and would let me check pay against the band.
- The recruiter's written answer on location would close RR1 and R1.
- A sanitized model-documentation page, a notebook, or a price-test readout would raise R3, R4 and R7 toward `high`. These are the artifacts a pricing analyst actually keeps.
- A monitoring dashboard or a model-review note would raise R6b.
- A deeper research pass on Brindlemoor (funding, leadership, recent news; up to 5 more searches and 2 more fetches) is available if you say the word.

## Questions

- **G1:** Do you need this role to be fully remote, or could you work from Leeds four days a week? Do you also have a pay floor?
- **G2:** On the young-driver model, what did you do after it went live? For example, tracking actual against expected loss ratios, drift or segment alerts, or triggering a refresh. Which parts were you doing yourself?
- **G3:** Have any of your price-test results fed a product or proposition decision, beyond underwriting? What was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.