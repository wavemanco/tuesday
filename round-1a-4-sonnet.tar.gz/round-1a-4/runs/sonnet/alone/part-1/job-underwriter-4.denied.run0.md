**Yes, go for it, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: unclear: R8 (Recommendations for product)
- `preferred`: direct: R9

R1 — location unconfirmed, because you haven't stated it; R8 — your product-facing evidence is unstated.

**Opportunity ledger.** The role is unverified rather than flawed. I couldn't confirm that Brindlemoor exists as described (RR1), pay is withheld (RR2), and the scope behind "own" is open (RR3). Two entries run the other way: the duties are concrete (RR4), and the JD asks for insurance experience in general, not pet insurance specifically (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you're UK-based, so R1 is met; (2) Brindlemoor and the live posting are verified through its own careers page or the recruiter's email domain (RR1); (3) the pet-insurance bridge is framed as adjacent, never as pet-insurance experience (plan row E2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Existence not independently confirmed | `[grounded]` JD header; not checked externally |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` your message |
| Seniority and line management | Titled senior and individual-contributor in tone. The JD asks for no line management, so "never managed anyone" is not a stated requirement gap | `[grounded]` JD silence on management |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Scope read | A pricing function with a director-level leader exists, but team size and whether you'd be the only analyst on the product are unknown | `[inferred]` from the named hiring manager's title against the JD's silence on team |
| Market calibration | Not established. Search was unavailable here, and model memory is not a source for pay or title norms | `[grounded]` no search ran; no `[generic]` band offered |
| Unknowns | Salary; team size; decision rights over rate changes; which rating models already exist; contract basis | — |
| Contradictions | None among the inputs you gave me. The JD against the company's careers page is unchecked | `[grounded]` inputs compared |

## Evidence map

Background taken from your message; no CV was supplied, so every claim is a stated one without an inspectable artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | low | hard_gate | Your location and right to work were not stated. A UK motor insurer employer suggests UK-based but is not a statement of it. | `[grounded]` JD term; `[inferred]` UK-based from your employer | Ask Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics, the last 2 as senior analyst. A years requirement is graded as evidence, not as a gate. | `[grounded]` your stated background | A CV or LinkedIn history would raise to `high` |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily." What you build with them is not specified. | `[grounded]` your stated background | A repo, notebook or query sample you can share |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your motor insurer's young-driver book. The qualifier "young-driver book" carries into any wording. | `[grounded]` your stated background | A sanitized model spec or methodology note would raise to `high` |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers building. What monitoring you ran (drift, loss-ratio tracking) is not stated, and I treat "maintained" as only partial evidence of it. | `[grounded]` your stated background; `[inferred]` monitoring from "maintained" | A monitoring pack or dashboard would raise to `high` |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Results and your design role are not stated. | `[grounded]` your stated background | A sanitized test write-up would raise to `high` |
| R7 | Present to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. | `[grounded]` your stated background | A sanitized deck would raise to `high` |
| R8 | Recommendations for product, not only underwriting | important | unclear | low | discovery | The JD names product as an audience. Your evidence names underwriting only, so product-facing work may exist but is unstated. | `[grounded]` JD; `[grounded]` your silence on product | Ask Q3 |
| R9 | Insurance experience a plus | preferred | direct | medium | none | Five years at a motor insurer. The JD asks for insurance experience in general, not for pet insurance. | `[grounded]` your stated background and JD wording | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-based and remote-eligible (R1, hard_gate) | hard_gate | No statement of your location or right to work | A hard gate that unconfirmed stays visible in the snapshot until answered | Not a recall question; it is a yes or no | none needed | `[grounded]` inputs silent |
| G2 | Recommendations to product, not only underwriting (R8, important) | discovery | Work with underwriting is clear. Work with a product or proposition team is not mentioned | The JD names product as a destination for the results, so this is the one named audience you haven't evidenced | A price-test result that changed a product feature or add-on; a pricing input to a new-product or proposition decision; a recommendation you made to a commercial or product lead | A sanitized recommendation note or a test-readout slide | `[grounded]` your stated background; `[generic]` that a product-facing audience means a different framing |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not independently confirmed as described | risk_signal | medium | "Senior Pricing Analyst — Brindlemoor (insurtech)" | Reasons side by side, none ranked as likely: a company too new or small to show up easily, a stale posting, or not a real hiring employer | `[generic]` pattern for any employer a search could not reach, not a claim about Brindlemoor | Is this role currently open, and where is it listed on Brindlemoor's own careers page? | unresolved |
| RR2 | Salary withheld | unknown | — | JD as pasted states no figure | The figure may sit below what you accept, or the posting may omit it as a style choice | `[inferred]` from the JD's silence; no band available to compare | What salary band is budgeted for this role? | unresolved |
| RR3 | Scope of "own" unclear | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the sole analyst, or may own the analysis without authority over rate decisions | `[inferred]` from the JD's scope language against its silence on team and decision rights | Who is in the pricing team, and who signs off a rate change? | unresolved |
| RR4 | Responsibilities and audiences named concretely | positive_signal | — | "build and monitor rating models, design and read price tests" | The duties match one analytics practice, so the work is probably defined | `[grounded]` JD states the duties | Which rating models are live today, and who built them? | noted |
| RR5 | Pet-specific experience not required | positive_signal | — | "insurance experience a plus" | The posting accepts general insurance experience, so your motor background is the stated ask | `[grounded]` JD wording | Do you hire from other insurance lines for this role? | noted |

## Application plan

Every row and the advice in it is proposed, and final only on your explicit approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the young-driver GLM rating model, the 14 price tests "last year, with the underwriting team", and the quarterly review to the head of underwriting in the top third of the CV, in your own words and scope. Use "built and maintained", not "led" or "owned" | see R4, R6, R7 | `[grounded]` your stated background | pending your approval |
| E2 | Say plainly in the cover note that your pricing background is motor, and that you are applying to carry the same rating and testing work to pet. Do not claim pet-insurance experience or pet-specific rating factors | see R9, RR5 | `[grounded]` your stated background; `[inferred]` the method carries over, since the JD asks for the same practice | pending your approval |
| A1 | Before sending anything, verify Brindlemoor and the posting through its own careers page or the recruiter's email domain | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Address the application to Odile Varga, the named Director of Pricing, and use the register's verification questions in the interview | see RR1 to RR4 | `[grounded]` your message and the register | pending your approval |
| W1 | A one-page sanitized price-test write-up | see R6, R8 | `[grounded]` R6, R8 rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Brindlemoor pet insurance insurtech", "Brindlemoor Senior Pricing Analyst careers") were refused, so nothing was read. It would have moved the contradictions row and RR1 |
| 2. Role-family sweep | unavailable | One search ("senior pricing analyst insurance UK salary remote pricing analytics GLM") was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | unavailable | One search ("Odile Varga Director of Pricing") was refused. It would have moved the scope read and which of your stories E1 leads with |

## Dossier offer

I can write all of this to `tuesday-dossier.md` so you can carry it forward; say so and I will.

## Upgrade menu

- Your CV or LinkedIn history → R2 to `high`, and lets me check E1 against your actual wording.
- A sanitized GLM spec, model-monitoring pack, price-test write-up or decks → R3, R4, R5, R6 and R7 each toward `high`; W1 is the one worth building first.
- A product-facing example → R8 resolves.
- Search access, if you allow it → rows 1 to 3 above run, which can close RR1, calibrate RR2 against the market, and shape A2.
- Your pay floor and any other non-negotiables → a pay or hours gate row, and the hard-gates line stops saying "constraints not given".

## Questions

Q1 (R1) — Are you UK-based and eligible to work in the UK without sponsorship?

Q2 (RR2) — What's your minimum acceptable salary, so I can check the role's pay against it when it's known?

Q3 (G2, R8) — Have you ever taken a pricing result to a product or proposition lead, and what did you recommend and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.