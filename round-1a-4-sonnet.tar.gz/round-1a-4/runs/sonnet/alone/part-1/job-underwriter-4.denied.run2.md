I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**Yes, worth applying to, once two things check out. Status: `conditional_go`.** R2, R3, R4, R5, R6 and R8 meet the stated requirements directly. What holds the status at `conditional_go` is an employer I couldn't verify (RR1) and a location gate I can't yet confirm (R1). Pet insurance (R12) and managing people don't hold it back. The JD asks for no line management, and pet insurance is not a stated requirement.

**Fit ledger.**

- `hard_gate`: unclear: R1 (UK-based, fully remote)
- `must_have`: direct: R2, R3, R4, R5, R6, R8 · unclear: R7 (Monitor rating models)
- `important`: direct: R9 · unclear: R10 (Recommendations for product)
- `preferred`: direct: R11 · adjacent: R12 (Pet-insurance domain)

R7 — "maintained" is not yet "monitored"; R10 — no product-side evidence yet; R12 (`medium`) — a credible bridge, its limit named.

**Opportunity ledger.** The employer and posting are unverified (RR1) and pay is not stated (RR2). Team size and decision rights are not stated (RR3). The duties themselves are concrete (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (UK-based, fully remote); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify, through Brindlemoor's own careers page (RR1); (2) R1 is confirmed; (3) pay, once disclosed, clears your floor (RR2); (4) the pet gap is framed honestly as adjacent, never as pet-insurance experience (R12).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech selling a pet-insurance product; existence and live posting not yet checked (RR1) | `[grounded]` JD header |
| Role | Senior Pricing Analyst, owning pricing analytics for the pet product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` your message |
| Mandate | Build and monitor rating models; design and read price tests; turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| People management | The JD states no line-management requirement. Whether the post has reports is not stated | `[grounded]` JD silence |
| Scope read | "Own pricing analytics" for a single product reads as one analyst with a wide remit, probably in a small pricing function. Team size is unknown | `[inferred]` from "own" plus a single-product scope |
| First-90-days read | Learning the existing rating models and price-test backlog before changing them | `[inferred]` from "build and monitor" and "design and read" |
| Compensation | Not stated. Posting silence is itself worth a question (RR2) | `[grounded]` JD silence |
| Market calibration | Not established: no role-family search ran, and I won't give a salary band from memory | `[generic]` no sweep available |
| Unknowns | Team size, salary, decision rights, tooling, pet-claims data maturity | `[grounded]` JD silence |
| Contradictions | None visible in the pasted JD. It has not been checked against a careers page | `[grounded]` pasted JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Based in the UK, fully remote | hard_gate | unclear | low | hard_gate | You work at a UK insurer, but your location and any constraints were not stated. Unsettled gate, so it stays `unclear` | `[inferred]` from "UK motor insurer" | Question Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years in pricing analytics, the last 2 as senior analyst. Stated, specific, nothing inspected yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Both used daily. Stated and plausible, with no artifact inspected | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Specific, confirmed by you, no inspectable artifact | `[grounded]` your background | A sanitised model spec would raise it to `high` |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The audience is underwriting, not actuarial, and the role names both | `[grounded]` your background | A sanitised review deck would raise it to `high` |
| R6 | Build rating models | must_have | direct | medium | none | You built the young-driver GLM. Its scope beyond that book is not stated | `[grounded]` your background | none |
| R7 | Monitor rating models | must_have | unclear | low | discovery | "Maintained" is close to monitoring but does not say what you tracked or how often. I won't read it upward | `[grounded]` the word "maintained"; `[inferred]` that monitoring may be part of it | Question Q2 |
| R8 | Design and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team." Whether you designed them or only read them is not stated, so I claim only that you ran them | `[grounded]` your background | none |
| R9 | Recommendations for underwriting | important | direct | medium | none | The tests ran with underwriting, and your quarterly review goes to its head | `[grounded]` your background | none |
| R10 | Recommendations for product | important | unclear | none | discovery | No product-side stakeholder appears in your background | `[grounded]` silence in your background | Question Q3 |
| R11 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R12 | Pet-insurance domain knowledge (not stated as required; the product is pet) | preferred | adjacent | medium | transferability | The rating and testing craft carries over from motor. Limit: pet rating factors differ and you have not priced them. Pet rating factors such as breed, age and vet-cost inflation typically differ from motor | `[inferred]` adjacency from your motor work; `[generic]` that pet and motor rating differ | Name the limit plainly in the application (E1, P1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitor rating models (R7, must_have) | discovery | "Built and maintained" the GLM. Nothing says what monitoring you ran | A must-have row at `unclear`. Resolving it could turn R7 `direct` | Tracking actual versus expected loss ratios or claim frequency; refit or recalibration decisions; checking for drift or segment deterioration; a model-performance pack others used | A sanitised monitoring report or dashboard screenshot | `[grounded]` the CV gap; `[inferred]` that it moves the row |
| G2 | Recommendations for product (R10, important) | discovery | Underwriting is covered. No product-team work is mentioned | The JD names product as a recipient of your recommendations | Presenting test results to a product or proposition team; a price change that shaped a product feature or tier | A one-page readout or a recommendation email | `[grounded]` silence in your background |
| G3 | Pet-insurance domain (R12, preferred) | transferability | Motor pricing is credible adjacent work | Pet is the whole product. The first objection in an interview is likely to be "have you done pet?" | Any work with vet-cost or claim-severity trends, age-banded or breed-style rating factors, or renewal pricing on a long-tail book | A short note on how you would approach pet rating factors | `[inferred]` bridge from motor; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | JD gives no salary figure | The figure may sit below what 5 years' experience and a senior title would expect, or the employer may not publish pay | `[grounded]` JD silence; no band available to compare | What salary range is budgeted for this post? | unresolved |
| RR3 | Ownership asserted, resources and team unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may carry the analytics for the product while data, tooling and headcount are unspecified | `[inferred]` from "own" against the JD's silence on team and tooling | Who else is in the pricing team, and what data and tooling will this role have on day one? | unresolved |
| RR4 | Duties are concrete | positive_signal | — | "build and monitor rating models, design and read price tests" | The mandate is specific to a pricing function and reads as a real remit | `[grounded]` JD | What would success look like in the first year? | noted |

## Application plan

All of these are proposed only. Nothing is final until you approve it.

`resume_edits_pending_approval`

| # | Proposed line or action | Source traced to | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with: "Built and maintained the GLM rating model for the young-driver book" | Your words, unchanged | `[grounded]` your background | pending your approval |
| E2 | "Ran 14 price tests last year with the underwriting team" | Your words, unchanged | `[grounded]` your background | pending your approval |
| E3 | "Present the quarterly pricing review to the head of underwriting" | Your words, unchanged | `[grounded]` your background | pending your approval |
| P1 | In a cover note, say plainly that you haven't priced pet insurance and that your motor GLM and price-test work is the adjacent experience. Don't claim pet knowledge or people management | R12 row; nothing beyond your own sentences | `[grounded]` R12 row | pending your approval |
| A1 | Check the posting on Brindlemoor's own careers page before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | In the loop, ask the verification questions of RR2 and RR3 verbatim, and ask Odile what success looks like in year one (RR4) | The register | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Brindlemoor pet insurance insurtech", "Brindlemoor careers Senior Pricing Analyst") were refused. This would have moved RR1, whether the employer exists and the posting is live, and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | One search ("senior pricing analyst pet insurance UK salary remote") was refused. This would have moved the market-calibration row and RR2's comparison against a band |
| 3. Hiring manager's public footprint | unavailable | One search ("Odile Varga Director of Pricing") was refused. A name was given, so the query could be formed. This would have moved the scope read and which story the application plan leads with |

I can write all of this up as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Permission to run web search → RR1 resolves one way or the other, role reality gets a market band for RR2, and the plan can lead with what Odile's public work suggests.
- A live careers-page link to the posting, or the recruiter's email domain → RR1 closes without any search.
- The salary range, and your pay floor → RR2 and R1's constraint check close, and the decision likely simplifies to `go` or `no_go`.
- A sanitised GLM spec or model summary → R4 and R6 to `high`.
- A sanitised copy of the quarterly pricing review deck → R5 and R9 to `high`.
- A price-test readout, with client detail removed → R8 to `high`.
- A monitoring report or dashboard screenshot → R7 can move toward `direct` (G1).

## Questions

Q1 (R1) — Is there anything non-negotiable, such as a UK base or a pay floor, that I should check this role against?

Q2 (G1, R7) — Which ongoing monitoring of the young-driver GLM did you personally run, such as actual versus expected tracking or refit decisions, and how often?

Q3 (G2, R10) — Have you ever taken price-test results to a product or proposition team, not just underwriting, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.