Reading the skill's reference files is done. Next I'm running the research: Quillfield's own site, a pay check for this role, and Tamsin Achebe's public professional profile.
**Short answer: yes, apply, but as a stretch.** You have the core of the role, but two of its headline duties are new to you. I read the posting, then checked Quillfield, the pay band and Tamsin Achebe's public profile.

## Decision snapshot

**Yes, worth applying to as a stretch, because R6a (owning a forecast) and R7b (billing data) are absent must-haves. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two days in the office), R2 (Salary £61,500–£67,000 plus share options)
- `must_have` — direct: R3a, R4 · adjacent: R5 (Strong SQL and spreadsheet modelling), R6b (experience owning a forecast), R7a (working with finance on billing or revenue data) · unclear: R3b (at a B2B software company) · absent: R6a (experience owning a forecast), R7b (billing data)
- `important` — direct: R8

R6a and R7b — absent, and both sit in the posting's headline duties; R5, R7a and R3b — questions of depth or kind rather than absence.

**Opportunity ledger.** A real, funded employer (RR6) with pay stated (RR5). The duties are a broad bundle (RR1), and the reporting line (RR3), option terms (RR4) and whether the role is on Quillfield's own careers page (RR2) are all open.

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days in the office), R2 (Salary £61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol two days a week and the pay range work for you — R1, R2, G6; (2) the forecast and billing duties turn out to be supported, not assumed from day one — R6a, R7b, RR1; (3) your forecast-adjacent work is framed as adjacent, never as forecast ownership — R6b; (4) the role is confirmed live — RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about), page not fetched |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` search result on linkedin.example/in/tamsin-achebe (snippet only); the recruiter naming her is your report |
| Scope read | A hands-on lead across four areas (CRM, billing data, reporting, forecast), probably reporting to a Head of RevOps. The posting gives no reporting line or direct reports | `[inferred]` from Tamsin's title against the posting's "Lead" title and its silence on reports |
| First-90-day outcomes | Not stated | `[grounded]` posting silent |
| Market calibration | Posted range sits inside the middle of the pay band for this title in UK B2B software: median £64,200, interquartile range £57,800–£70,400, n=438. The band is UK-wide, not Bristol-specific, and is what to expect, never this employer's offer (see RR5) | `[generic]` "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example), snippet only; `[grounded]` posting for its own figure |
| Unknowns | Reporting line and team size; who builds the forecast with the CFO today; option terms; success measures | `[grounded]` posting silent |
| Contradictions | None between your description and the About page. The posting itself was not found on Quillfield's own site | `[grounded]` About page; careers search returned nothing |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't said where you live or whether two Bristol days work, so the constraint is unstated | `[grounded]` posting; your message silent | G6 question |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | No pay floor from you yet. Fit stays unclear until you state one | `[grounded]` posting; your message silent | G6 question |
| R3a | 4+ years in revenue ops, sales ops or similar analytics | must_have | direct | medium | none | You state 5 years in sales operations, the last 2 running RevOps for the UK team. Confirmed and specific, but no inspectable artifact yet, so expect a probe | `[grounded]` your message | A CV with dates would raise to high |
| R3b | That experience at a B2B software company | must_have | unclear | low | discovery | You said a B2B payments company. Whether its product counts as software isn't stated, so it takes the lower reading | `[grounded]` your message | Say what the product was (G4) |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, confirmed. Quillfield's CRM isn't named in the posting | `[grounded]` your message | A certification link would raise to high |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily is confirmed regular use. "Strong" and "modelling" aren't established: what models you built isn't stated | `[grounded]` your message | G5 |
| R6a | Experience owning a forecast | must_have | absent | none | capability | You said finance owned the company forecast, so you haven't owned one | `[grounded]` your message | Carry as the main risk; closure path in G1 |
| R6b | Forecast-adjacent work (same requirement as R6a) | must_have | adjacent | medium | transferability | Running the monthly pipeline review with your sales director is real adjacent work. Limit: it isn't forecast ownership, and whether your numbers fed finance's forecast isn't stated | `[grounded]` your message | G1 question |
| R7a | Working with finance on billing or revenue data | must_have | adjacent | low | discovery | Renewal dashboards are revenue-related reporting. Whether finance used them, or you reconciled with finance, isn't stated | `[grounded]` your message | G2 question |
| R7b | Owning billing data | must_have | absent | none | capability | You said you've never worked on billing data | `[grounded]` your message | Closure path in G3; carry as a risk |
| R8 | Build pipeline and renewal reporting | important | direct | medium | none | "Rebuilt our pipeline and renewal dashboards" matches the duty. Finance as a user of them is unconfirmed (G2) | `[grounded]` your message | Offer screenshots to raise to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6a, R6b, must_have) | transferability | A monthly pipeline review you run, but finance owned the forecast | The posting has you running the quarterly forecast with the CFO, the biggest gap on the map | Supplying commit or coverage numbers that went into finance's forecast; explaining a forecast miss; owning stage-conversion assumptions | A sanitised pipeline-review deck or a forecast roll-up | `[grounded]` your message; `[inferred]` that this is the likeliest probe |
| G2 | Finance on revenue data (R7a, R8, must_have) | discovery | Renewal dashboards exist, but their audience and any finance reconciliation aren't stated | It would turn an adjacent row into a direct one | Finance reviewing renewal figures; reconciling CRM renewals to invoiced revenue; ARR definitions agreed with finance | A dashboard screenshot with the figures masked | `[grounded]` your message |
| G3 | Billing data (R7b, must_have) | capability | No billing exposure stated | The posting says you would own it | Short of direct work, a small project on invoice or subscription data would show you can learn it | A sanitised sample-data exercise | `[grounded]` your statement; closure path is `[inferred]` |
| G4 | Software company (R3b, must_have) | discovery | "B2B payments company" doesn't say whether the product was software | It decides whether the 4+ years requirement is met in kind as well as length | A payments platform or SaaS product sold to businesses | A company product page | `[grounded]` your message |
| G5 | SQL and modelling depth (R5, must_have) | discovery | Frequency is stated; modelling depth isn't | "Strong" is the posting's word | Cohort or churn models; forecasting workbooks; queries behind your dashboards | A masked query or workbook | `[grounded]` your message |
| G6 | Location and pay (R1, R2, hard_gate) | hard_gate | Neither constraint stated | A mismatch ends the application, whatever the fit | Your commute and your pay floor | none needed | `[grounded]` your message silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bundled scope | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting ... and run the quarterly revenue forecast with the CFO" | Several specialisms sit under one Lead title at a mid-band salary, so some may be learned on the job. Low because the pay is mid-band and a Head of RevOps is nearby | `[inferred]` from the four duties against the band | Who does the billing-data and forecast work today, and how will this role be supported on it in its first six months? | unresolved |
| RR2 | Posting not found on the company's own careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | The role may be listed only on the job board, the careers page may not be indexed, or the posting may be stale. The employer itself is established | `[grounded]` careers search returned nothing; `[generic]` pattern of posting channels | Is this role live on your careers page, and is the post still open? | unresolved |
| RR3 | Reporting line and team unstated | unknown | — | "Revenue Operations Lead" | It may report to the Head of RevOps with no direct reports | `[inferred]` from Tamsin's title against the posting | Who does this role report to, and does it manage anyone? | unresolved |
| RR4 | Share option terms unstated | unknown | — | "plus share options" | Value depends on grant size, vesting and strike price, none given | `[grounded]` posting silent | What is the grant size, vesting schedule and strike price? | unresolved |
| RR5 | Pay stated and in band | positive_signal | — | "£61,500–£67,000" | The range sits near the middle of the UK B2B software band, so no seniority-pay mismatch | `[grounded]` posting; `[generic]` Ledgerline band | When is the salary reviewed, and how are options refreshed? | noted |
| RR6 | Employer established | positive_signal | — | "Quillfield, the invoicing software company" | Matches the About page: founded 2018, Bristol, funded Series A | `[grounded]` quillfield.co.uk/about snippet | How does the Series A change the revenue team's plans? | noted |

## Application plan

Every row below is proposed. Nothing is final until you approve it, prose advice included.

**Proposed CV edits (`resume_edits_pending_approval`)** — each reorders your own sentences and adds no facts:

| # | Current | Proposed | Traces to |
|---|---|---|---|
| E1 | Not shown to me | "Rebuilt our pipeline and renewal dashboards" as a lead bullet | "I rebuilt our pipeline and renewal dashboards" |
| E2 | Not shown to me | "Run the monthly pipeline review with our sales director" | "I run the monthly pipeline review with our sales director" |
| E3 | Not shown to me | "Running revenue operations for the UK team" (2 years), "Salesforce admin certified" | "the last 2 running revenue operations for the UK team"; "Salesforce admin certified" |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dashboards, the pipeline review and Salesforce admin; say plainly that finance owned your company's forecast | R4, R8 are strongest; R6a is stated, not buried | `[grounded]` your message | pending your approval |
| P2 | Interview framing, to rehearse as your own words: "Finance owned the forecast at my company; I run the monthly pipeline review with our sales director" | Candour on R6a, anchored to R6b | `[grounded]` your message | pending your approval |
| P3 | Tamsin's public path runs from sales operations to Head of Revenue Operations, so open with your pipeline and reporting work, the closest overlap | Which verified story to lead with for this reader | `[inferred]` from her public profile snippet | pending your approval |
| W1 | Optional: a one-page forecast sketch on sample data, labelled illustrative | Narrows G1 and G3 without claiming ownership | `[inferred]` from R6a, R7b | pending your approval |
| A1 | Ask the recruiter to confirm the role is live and who it reports to | RR2, RR3 | `[grounded]` register | pending your approval |
| Q1 | Ask RR1–RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company" (returned "About Quillfield", quillfield.co.uk/about) and "Quillfield careers Revenue Operations Lead Bristol" (no results). Moved role reality's organization and contradictions rows, RR2 and RR6 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software" (returned "Ledgerline 2026 UK Revenue Operations Pay Guide", ledgerline.example). Moved market calibration and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" (returned "Tamsin Achebe — Head of Revenue Operations, Quillfield", linkedin.example/in/tamsin-achebe). Moved the scope read and P3. Only the snippet was read |

I can take a CV or LinkedIn history and build the dossier file (`tuesday-dossier.md`) from this assessment whenever you want it.

## Upgrade menu

- Your Bristol and pay position → R1 and R2 move from unclear to met or failed.
- Your CV with dates → R3a rises to `high`.
- A product description of your employer → R3b closes.
- A Salesforce certification link or a masked dashboard screenshot → R4 and R8 rise to `high`.
- A masked pipeline-review deck or forecast roll-up → R6b strengthens, G1 narrows.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G6 — Does Bristol with two office days a week work for you, and is there a salary floor the £61,500–£67,000 range has to clear?

G1 — When you run the monthly pipeline review, do your numbers feed a forecast that finance builds, and which parts are yours (for example commit calls, coverage, or stage conversion)?

G2 — Did finance use or check your renewal dashboards, and have you touched invoice or subscription-billing data even indirectly?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.