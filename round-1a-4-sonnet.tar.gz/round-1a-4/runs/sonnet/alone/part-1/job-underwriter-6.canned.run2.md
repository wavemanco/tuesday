I've read the posting and the skill's rules. Next I'm running the L1 research: Quillfield's own site, a salary and scope check for this role type, and Tamsin Achebe's public professional footprint.
**Yes, apply, but as a stretch, not a clean match: R6a and R7a are absent, while R3a, R4 and R8 land direct. Status: `conditional_go`.**

I read the posting through your link. It's a short posting, so that is all I had to work from.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3a, R4, R8 · adjacent: R5 (strong SQL and spreadsheet modelling), R6b (run the quarterly forecast with the CFO) · unclear: R3b (at a B2B software company), R7b (working with finance on revenue data) · absent: R6a (owning a forecast), R7a (billing data)

R6a, R7a — absent, named gaps; R6b — a credible bridge, its limit named; R1, R2 — unconfirmed because your location and pay terms weren't given.

**Opportunity ledger.** Pay is stated (RR2) and the employer is attributable (RR6). The open points are who holds the forecast (RR1), the unseen share-option terms (RR3), a posting I couldn't find on the company's own site (RR4), and a broad scope (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol hybrid and the pay band both work for you: R1, R2. (2) The hiring manager confirms who holds forecast accountability and what ramp is expected: RR1, R6a. (3) The posting is confirmed live on the company's own site: RR4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about) |
| Mandate | Own the CRM and billing data. Build the pipeline and renewal reporting that sales and finance run on. Run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern and pay | Bristol, hybrid, two days a week in the office. £61,500–£67,000 plus share options | `[grounded]` JD |
| Stated requirements | 4+ years in revenue operations, sales operations or a similar analytics role at a B2B software company; HubSpot or Salesforce administration; strong SQL and spreadsheet modelling; experience owning a forecast; experience working with finance on billing or revenue data | `[grounded]` JD |
| First-90-days outcomes | The JD states none. Likely the first forecast cycle with the CFO, plus taking over the CRM and billing data | `[inferred]` from the JD's three responsibilities |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield. Previously sales operations manager at Corvane Payments for four years | `[grounded]` search result (linkedin.example/in/tamsin-achebe, snippet only) |
| Scope read | Her title sits above this one, so the Lead probably reports into a function she heads. That sits oddly beside "run the quarterly revenue forecast with the CFO" (RR1). The role also bundles CRM, billing data, reporting and forecasting (RR5) | `[inferred]` from the two titles and the JD's mandate |
| Market calibration | Ledgerline's 2026 UK pay guide gives a median base of £64,200 for a revenue operations lead in UK B2B software (n=438, interquartile range £57,800–£70,400). The posted band sits inside that range and straddles the median. The band is not Bristol-specific, and I did not search scope norms, so this is a pay check only. The posting's figure is the employer's, and the band is not their offer | `[generic]` Ledgerline band; `[grounded]` JD figure |
| Unknowns | HubSpot or Salesforce in use; team size; contract type; share-option terms; billing system; who owns the forecast | `[grounded]` JD silent on each |
| Contradictions | None between the JD and the About page. The careers page I tried (quillfield.co.uk/careers) returned no page, so the posting isn't confirmed on the company's own site (RR4) | `[grounded]` fetch result |

## Evidence map

Your background was given in prose, so it counts as self-report and `medium` is the ceiling on a first pass.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't stated location or office-day constraints, so the gate is neither met nor failed | `[grounded]` JD; no constraint from you | G3 |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | No pay floor was given. The band sits inside the generic market band, but whether it meets your floor is unknown | `[grounded]` JD; `[generic]` band | G3 |
| R3a | 4+ years in revenue operations, sales operations or a similar analytics role | must_have | direct | medium | none | You have five years in sales operations, the last two running revenue operations for the UK team. Self-reported, nothing inspected yet | `[grounded]` your intake message | none |
| R3b | …at a B2B software company | must_have | unclear | low | discovery | Your employer is a B2B payments company. Whether it is a software or product business isn't stated, so the match isn't settled | `[grounded]` your intake message | G4 |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You are Salesforce admin certified. The JD accepts either system. The certificate hasn't been inspected | `[grounded]` your intake message and JD | none |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | You use SQL weekly and Excel daily. That shows use, not strength, and spreadsheet modelling isn't confirmed | `[grounded]` your intake message | offer: a sanitized model or query set would raise it |
| R6a | Experience owning a forecast | must_have | absent | none | capability | You said finance did the company forecast and you never owned it. That is a confirmed gap, not a missing CV line | `[grounded]` your intake message | named closure path in the plan, W1 |
| R6b | Run the quarterly revenue forecast with the CFO (JD responsibility) | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director and rebuilt the pipeline dashboards. Limit: that is pipeline review, not forecast ownership, and not work with a CFO. Role-family norm: a forecast is usually built on top of a pipeline view | `[grounded]` your intake message; `[generic]` forecasting norm | G1 |
| R7a | Experience working with finance on billing data | must_have | absent | none | capability | You said you have never worked on billing data | `[grounded]` your intake message | carried as a material risk |
| R7b | …on revenue data | must_have | unclear | low | discovery | You rebuilt renewal dashboards, which are revenue-related. Whether finance used or checked them isn't stated | `[grounded]` your intake message | G2 |
| R8 | Build the pipeline and renewal reporting | must_have | direct | medium | none | You rebuilt your team's pipeline and renewal dashboards. Whether sales and finance both run on them is R7b's question | `[grounded]` your intake message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6a, R6b, must_have) | transferability | A monthly pipeline review and rebuilt dashboards, but no forecast owned and no CFO-level audience | The JD asks for both owning and running a forecast, so this decides how the application is framed | Producing a commit or best-case view for the sales director; pipeline coverage or renewal projections that finance used; a forecast-accuracy check | A sanitized pipeline or forecast view, or a deck from a pipeline review | `[grounded]` your own account of the gap; `[generic]` that forecasting roles lean on this |
| G2 | Finance and revenue data (R7b, must_have) | discovery | Renewal dashboards exist. Whether finance used, checked or sourced them isn't stated | The JD pairs finance with billing, and R7a is already absent. R7b is the part that could still be direct | Finance asking you for renewal figures; reconciling CRM against finance numbers; renewal data from a finance export | A dashboard screenshot with figures removed, or a data-source note | `[grounded]` intake message; `[inferred]` that this could move R7b |
| G3 | Location and pay terms (R1, R2, hard_gate) | hard_gate | No constraints stated | A failed gate caps the decision however strong the fit elsewhere | — | — | `[grounded]` constraints not given |
| G4 | B2B software employer (R3b, must_have) | discovery | "B2B payments company": product or service model isn't stated | Cheap to settle and affects how the 4+ years reads. Not asked this turn, because it ranks below G1–G3 | A product-based or software-led payments business | The employer's product page | `[grounded]` intake message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast accountability unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The Lead may produce forecast inputs while accountability sits with the Head of RevOps or finance, or the post may be carved out of her remit | `[inferred]` from the JD's wording against Tamsin Achebe's listed title | Who is accountable for the forecast number: this role, you, or the CFO? | unresolved |
| RR2 | Pay stated and within the generic band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The employer is transparent on pay and the range straddles the median | `[grounded]` JD; `[generic]` Ledgerline band | What does the range depend on? | noted |
| RR3 | Share options unspecified | unknown | — | "plus share options" | The grant, vesting and strike terms may be material to total pay or may be minimal | `[grounded]` JD silent on terms | What are the grant size, vesting schedule and strike price? | unresolved |
| RR4 | Posting not seen on the employer's own site | unknown | — | "Revenue Operations Lead, Quillfield" (posting on a jobs board) | The careers page may live at a different address, the post may be new, or it may be listed only via the board | `[grounded]` one careers URL tried, no page; `[generic]` roles often appear on boards first | Can you share the link to this role on Quillfield's own careers page? | unresolved |
| RR5 | Broad bundled scope | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting…, and run the quarterly revenue forecast" | Four areas in one role may mean heavy load without a team, though a 96-person company often runs this as one function | `[generic]` pattern for companies of this size, not a claim about this one | What does the team around this role look like, and what tooling is in place? | unresolved |
| RR6 | Employer attributable | positive_signal | — | "Founded 2018 in Bristol; 96 employees. Series A (£11M) closed in April 2025" | The company exists as the posting describes | `[grounded]` About page snippet | Who would this role work with day to day? | noted |

## Application plan

Every row is proposed and pending your approval, including the positioning rows.

`resume_edits_pending_approval`

| # | Proposed line | Source it traces to |
|---|---|---|
| E1 | Five years in sales operations at a B2B payments company, the last two running revenue operations for the UK team. | "5 years in sales operations at a B2B payments company, the last 2 running revenue operations for the UK team" |
| E2 | Rebuilt the pipeline and renewal dashboards; run the monthly pipeline review with the sales director. | "rebuilt our pipeline and renewal dashboards… run the monthly pipeline review with our sales director" |
| E3 | Salesforce admin certified; SQL weekly, Excel daily. | "Salesforce admin certified. SQL weekly, Excel daily" |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the dashboard rebuild and the monthly pipeline review (R8, R3a). They are your direct stories, and Tamsin Achebe's listed roles are in revenue and sales operations | Her listed titles are in the same function | `[inferred]` from R8, R3a and her listed career | pending your approval |
| F1 | Say it plainly: "Finance owned the company forecast where I work; I ran the monthly pipeline review with our sales director and rebuilt the pipeline and renewal dashboards. I haven't worked on billing data." | Honest framing of R6a and R7a before the interviewer asks | `[grounded]` your intake message | pending your approval |
| W1 | Build a short sample pipeline forecast from dummy data. It would show method, not experience | Partly narrows R6a, R6b | `[inferred]` from the R6a, R6b rows | pending your approval |
| A1 | Ask the recruiter to confirm the office days, the pay range's basis and a link to the posting on Quillfield's own site before you invest in the loop | See R1, R2, RR4 | `[grounded]` RR4 | pending your approval |
| Q1 | Ask RR1, RR3 and RR5 verbatim in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything above from you is self-report from your intake message.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Bristol", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved: the organization row and RR6 (employer attributable), and RR4 (posting not confirmed on the company's own site) |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B SaaS", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration and RR2. It gave pay only, not scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Snippet only, no fetch. Moved: the hiring-manager and scope-read rows, RR1 and P1 |

I can save this analysis as `tuesday-dossier.md` if you'd like it to carry into later steps.

**Upgrade menu**

- Your location and office-day limits and your pay floor → R1 and R2 move to met or failed, and the hard-gates line settles.
- Your CV and the Salesforce certificate → R4 and R3a can rise toward `high`, and the E-lines can be checked against your own wording.
- A sanitized pipeline or forecast view → R6b's bridge strengthens and R6a stays honest.
- A dashboard screenshot with figures removed, or a data-source note → R7b and R8 firm up.
- The recruiter's link to the live posting on Quillfield's site → RR4 closes.
- A deeper research pass on Quillfield (funding and leadership changes, hiring pattern, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

G1 — Have you ever produced numbers that fed into a forecast, such as a commit or best-case view, pipeline coverage or renewal projections, that finance or leadership used? What exactly was yours, and what was finance's?

G2 — Did finance use or check your renewal dashboards, and did their renewal figures come from a finance or billing export, or from the CRM alone?

G3 — Do both the Bristol hybrid terms (two office days a week) and the £61,500–£67,000 band work for you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.