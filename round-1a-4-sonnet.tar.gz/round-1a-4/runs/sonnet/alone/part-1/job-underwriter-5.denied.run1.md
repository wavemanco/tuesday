I've read the skill's rules and the fetch of Pellucid's pages was refused. I'm checking the one rule I haven't read, how set claims about map rows are checked, before I write the assessment.
## Decision snapshot

**Yes, this is worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 against your floor)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery as the warehouse); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R9 is a credible bridge with its limit named. R10 and R11 are unclear because your background is silent on them.

**Opportunity ledger.** The role is coherent and clear on pay. The posted range straddles the market median (RR2), and the stack and seniority bar look ordinary for the title (RR5). Open items: equity is unquantified (RR3), the reporting line and team are unknown (RR4), and I couldn't verify the employer from here (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You confirm R1 and R2 against where you can work and your pay floor.
  2. The posting and employer verify on Pellucid's own careers site (RR1).
  3. BigQuery is framed as adjacent to your Snowflake dbt work, never as BigQuery experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the About text you pasted; not independently checked (see Evidence status) |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts analysts depend on | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 salary plus equity; equity terms not stated | `[grounded]` JD |
| Market calibration | Datawright reports a base median of $151,000 and an interquartile range of $139,000–$163,500 for Senior Data Engineers at Series B–D companies (n=2,310). The posted low end is $3,000 under that median, the midpoint is $157,000, and the top is $2,500 over the range's upper quartile. Pellucid's Series C stage puts it inside the report's B–D band. This is a market band, never this employer's offer. | `[grounded]` JD figures and the recruiter's report as pasted; comparison `[inferred]`; report not independently checked |
| Scope read | Normally scoped: the report's typical scope is one domain's pipelines with no direct reports, and the JD mentions no reports. 5+ years sits at the low end of the report's usual 5–8 years for "Senior". | `[inferred]` from JD silence on reports against the report's norms |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Hiring manager (none named), team size, whether the dbt project already exists or is to be built, equity terms, your location and pay floor | `[grounded]` JD silence |
| Contradictions | None between the pasted JD and the pasted About text; neither was checked against the live pages | `[grounded]` pasted texts compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Work location: Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | A term you meet or don't. You gave no location or work authorization, so the check can't run. | `[grounded]` JD; your background silent | Q1 below |
| R2 | Salary $148,000–$166,000 plus equity, against your pay floor | hard_gate | unclear | none | hard_gate | The range is stated but your floor isn't, so the comparison can't run. The market comparison is in RR2. | `[grounded]` JD; floor not given | Q1 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You told me 6 years at a B2B payroll company. A years requirement is graded as a requirement, not a gate. Confirmed and specific, but no inspectable document yet, so expect a probe. | `[grounded]` your statement | CV or LinkedIn dates would raise to high |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is a judgement an interviewer will probe, and I have no detail on what the Python was used for. | `[grounded]` your statement | A sanitized code sample or repo would raise to high |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Confirmed and specific, no inspectable artifact yet. | `[grounded]` your statement | A sanitized project structure or dbt docs page would raise to high |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the requirement doesn't name BigQuery. BigQuery sits in R9. | `[grounded]` your statement and JD wording | Same artifact as R5 |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration. I have no detail on how many pipelines or who authored them, so I assume none. | `[grounded]` your statement | A sanitized DAG sample would raise to high |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Its size and where it ran aren't stated. | `[grounded]` your statement | A sanitized suite config would raise to high |
| R9 | BigQuery as the dbt-modelled warehouse (implied by the role description, not listed as a requirement) | important | adjacent | medium | transferability | Carries over: dbt modelling work on Snowflake. Limit: you have never used BigQuery, so anything specific to it is untouched, such as its pricing and table-layout features. | `[inferred]` adjacency from your Snowflake dbt work; `[generic]` that BigQuery has warehouse-specific features beyond dbt | G1 |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your background doesn't mention ingestion sources, tools or ownership. Airflow orchestration is indirect context only. | `[grounded]` background silence; `[inferred]` indirect context | G2 |
| R11 | Data contracts the analysts depend on | important | unclear | low | discovery | The Great Expectations suite and dbt models sit near this. Nothing says you agreed schemas or expectations with producers or consumers. | `[grounded]` background silence; `[inferred]` adjacency | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Dbt on Snowflake at about 180 models. You have never used BigQuery. | It is the named warehouse, so the likeliest interview probe is "how would you transfer?" | Personal or sandbox BigQuery use; cost or performance tuning you did on Snowflake; any BigQuery table you queried as a source | A small dbt-on-BigQuery project, or a sanitized Snowflake tuning note | `[grounded]` your statement; `[generic]` that the named warehouse is a common probe |
| G2 | Ingestion from the app and CRM (R10, important) | discovery | The role says ingestion is half the job. Your background mentions orchestration, not sources. | Closing it moves R10 from `unclear` toward `direct` or an honest gap | Loading data from an application database, a CRM, or a third-party API into your warehouse; writing or maintaining connectors; owning a source's schema changes | An architecture diagram, an ingestion DAG, or a runbook | `[grounded]` JD and background silence |
| G3 | Data contracts (R11, important) | discovery | Tests exist; no agreement with consumers or producers is mentioned. | The JD names analysts as the contract's audience | Agreeing column definitions or freshness expectations with analysts; failing a build when an upstream schema changed; documenting model ownership | A model spec, a contract or schema doc, or a test config tied to a consumer | `[grounded]` JD and background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver." | The check was refused, not negative. If it stays unresolved, the entity may be too new or small for a footprint, the posting may be stale or aggregated, or it may not be a real hiring employer. | `[generic]` pattern for companies of this kind, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay stated and in line with market | positive_signal | — | "Salary $148,000–$166,000 plus equity." | Transparent pay, on the upper side of the market median for the stage | `[grounded]` JD range and the Datawright figures as pasted; comparison `[inferred]` | Where in this range would six years of experience land? | noted |
| RR3 | Equity unquantified | unknown | — | "plus equity" | The grant size, vesting and strike may be material to total pay, and none is stated | `[grounded]` JD silence | What is the equity grant for this level, and what are the vesting and strike terms? | unresolved |
| RR4 | No hiring manager, team size or ownership split stated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the sole data engineer, or one of several. Whether the dbt project exists or is to be built is also open. | `[inferred]` from the JD's silence on reporting line and team | Who does this role report to, how many data engineers and analysts are there, and does the dbt project exist today? | unresolved |
| RR5 | Concrete stack and a market-normal seniority bar | positive_signal | — | "5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; orchestration with Airflow or similar" | Requirements are specific and coherent for one domain, with no responsibility-without-authority wording found | `[grounded]` JD; `[inferred]` comparison with the report's scope and years norms | What does success look like at 90 days and at one year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with three lines, each in your own words: "Built our dbt project on Snowflake, about 180 models"; "Used Airflow for orchestration"; "Set up our Great Expectations test suite" | They answer R5, R7 and R8 directly | `[grounded]` your statements | `resume_edits_pending_approval` |
| E2 | Name the gap yourself: "I built our dbt project on Snowflake; I haven't used BigQuery yet." | Keeps the R9 bridge honest | `[grounded]` your statement | pending your approval |
| W1 | Optional: a small dbt-on-BigQuery sample project, if you have time before interviews | Would narrow R9's stated limit | `[inferred]` from G1 | pending your approval |
| Q1 | Ask the verification questions from RR1–RR5 on the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm your location and pay floor against R1 and R2 before investing in the loop | They are the two unconfirmed gates | `[grounded]` R1, R2 | pending your approval |

Everything in this plan is proposed. Nothing is final until you approve it, including the prose in E1 and E2.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both fetches were refused because fetch permission wasn't granted: pellucidlearning.com/careers/senior-data-engineer and pellucidlearning.com/about. Nothing was read, so RR1 stays open. A fetch would have checked that the posting is live and matches the pasted text. |
| 2. Role-family sweep | skipped | The Datawright report you pasted already supplies the market band, scope and years norms, so a search would change nothing (market calibration, RR2, RR5). |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form. |

## Closing

I can write this up as `tuesday-dossier.md` whenever you'd like it.

**Upgrade menu**

- Your location and pay floor → R1 and R2 close, and the decision may simplify.
- A sanitized dbt project structure, DAG sample or Great Expectations config → R5, R7 or R8 can reach `high`.
- Answers to G2 and G3 → R10 and R11 firm up or become named gaps.
- A BigQuery sandbox project or tuning note → G1 and R9's limit narrow.
- Fetch permission for pellucidlearning.com → RR1 can be checked against the live pages.
- The hiring manager's name from the recruiter → I can read their public professional footprint for the scope read and for which story to lead with.
- A deeper research pass on Pellucid (funding, leadership changes, public employee reports; up to 5 more searches and 2 more fetches) → RR1 and the risk register. Say the word and it runs.

**Questions**

- R1, R2: What are your non-negotiables for this move, meaning where you'd work from and the lowest base salary you'd accept?
- G2: Have you owned any ingestion of data from an application database, a CRM or a third-party tool into your warehouse, and if so, which sources, which tools, and what was yours?
- G3: Did you agree schemas, freshness or quality expectations with the people producing or using your models, and how were they enforced?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.