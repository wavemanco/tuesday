I've read the skill's rules and I'm starting the research step. That means checking that Harborlight Health exists and what this role pays. Then I'll write the assessment.
# Job Underwriting Assessment: Senior Product Analyst, Harborlight Health

## Decision snapshot

**Yes, apply. You're a fit on every core requirement, and healthcare is the one real gap. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: direct: R7 · unclear: R6 (metrics layer), R8 (partnering with clinicians), R9 (mentoring two junior analysts)
- `preferred`: adjacent: R10 (healthcare data, HIPAA)

R10 (`medium`) is a credible bridge with its limit named; R9 is a CV silence; R8 has no clinician-facing evidence yet.

**Opportunity ledger.** The scope is clearly defined (RR3), but the employer could not be checked from here (RR1), the pay is withheld (RR2), and no success measures are stated (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the employer and the live posting verify (RR1); (2) the salary range clears your floor, which you haven't told me (RR2); (3) the healthcare bridge is framed as adjacent, never as HIPAA experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people, Series C, with a care-navigation app | `[grounded]` JD header; not independently checked |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, roadmap partnership with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Seniority read | Senior individual contributor with light people-leadership (two juniors) | `[inferred]` from the mentoring line against the absence of a management title |
| Success measures | No first-90-day or first-year outcomes stated | `[grounded]` JD silence |
| Market calibration | Not established: the role-family sweep did not run, so there is no pay band to set against this title | none |
| Unknowns | Salary; location or remote policy; the current state of the metrics layer; whether analytics engineering support exists; how much direct access to clinicians the role has | none |
| Contradictions | None found between sources, but only the JD was available to compare | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years at a consumer-subscription company. It's specific and the requirement is met, but nothing inspectable backs it, so `medium`. | `[grounded]` your statement | An employment history or LinkedIn profile would raise it to `high` |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake at 2M-subscriber scale. "Expert" is a level you self-assess, so expect a live SQL probe. | `[grounded]` your statement | A sanitized query sample would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ tests a year, including the pricing test behind an 11% retention lift. This is the strongest row, but there's no artifact yet. | `[grounded]` your statement | A sanitized test write-up would raise it to `high` |
| R4 | Looker (or similar) and self-serve dashboards | must_have | direct | medium | none | You built the Looker instance from scratch, with 40+ governed dashboards. | `[grounded]` your statement | A dashboard screenshot or a governance doc would raise it to `high` |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly. | `[grounded]` your statement | A sanitized memo would raise it to `high` |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | You describe governed dashboards but not shared metric definitions as such. This may be buried work rather than missing work. | `[grounded]` your statement's silence | G1 |
| R7 | Partner with PMs to turn analysis into roadmap decisions | important | direct | medium | none | Monthly VP Product presentations are stated. Day-to-day PM partnership is implied by running the experimentation program. | `[grounded]` VP Product presentations; `[inferred]` PM partnership from the experimentation program | An example of a roadmap decision your analysis changed would raise it to `high` |
| R8 | Partner with clinicians | important | unclear | low | discovery | You mention no work with clinical or other domain-expert colleagues. Your equivalent may exist outside product teams. | `[grounded]` your statement's silence | G3 |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | Nothing stated on mentoring or managing anyone. | `[grounded]` your statement's silence | G2 |
| R10 | Healthcare data experience, HIPAA (a plus) | preferred | adjacent | medium | transferability | Real overlap: you handled GDPR/CCPA consumer PII and built the warehouse's consent-state model. The limit is that you have no exposure to PHI, HIPAA rules or clinical data standards. | `[grounded]` your statement; `[inferred]` adjacency to HIPAA-type obligations | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Looker governance is stated, but not who defined shared metrics or how changes were controlled | The JD lists it first, so a shaky answer here would be noticed | Writing LookML measures or a dbt or semantic layer; a metric dictionary; resolving "two dashboards, two numbers" disputes; a change process for metric definitions | A metric definitions doc, LookML excerpt, or a governance one-pager | `[grounded]` silence on definitions; `[inferred]` that the 40+ governed dashboards involved some of this |
| G2 | Mentoring (R9, important) | discovery | Nothing on mentoring | The JD names two juniors, so it's a core duty of the role | Onboarding a new analyst; reviewing others' SQL or test designs; running a tutorial or office hours; informal coaching | A named onboarding doc or review checklist | `[grounded]` silence |
| G3 | Clinician partnership (R8, important) | discovery | No evidence of work with domain experts | The role pairs analysts with clinicians. A close analogue would soften the transition | Working with nutritionists, culinary, ops or care-quality teams to shape an analysis or a test | A brief or a write-up where an expert's input changed the design | `[grounded]` silence; `[generic]` that domain-expert partnership is the usual stand-in for this requirement |
| G4 | Healthcare data (R10, preferred) | transferability | Adjacent evidence: GDPR/CCPA PII handling and the consent-state model. Limit: no PHI, no HIPAA rules, no clinical data. Strengthener: a short statement of how you restricted access to sensitive data, plus a plain admission that HIPAA is new to you | Preferred only, but it's the most visible difference from other applicants | Role-based access control on PII; de-identification or pseudonymization; data-subject request handling; audit trails | A sanitized data-governance note | `[grounded]` your statement; `[generic]` that healthcare employers weigh this as a plus, not a gate, when the JD says so |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The company may be too new or small for a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. None of these is more likely than the others, and the check simply didn't run. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated against a floor not given | unknown | — | (no figure in the JD) | The pay may sit below what 6 years plus mentoring duties commands, or the company may simply not publish it. | `[inferred]` from the JD's silence | What is the salary range for this role? | unresolved |
| RR3 | Scope is explicitly defined | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | Responsibilities are concrete and map to a recognizable analytics function, not a bundle of unrelated roles. | `[grounded]` JD | Who owns the metrics layer today, and what shape is it in? | noted |
| RR4 | No stated success measures for the role | unknown | — | (none in the JD) | The role may be accountable for outcomes with no agreed definition of success. | `[inferred]` from the JD's silence | What would a strong first year look like, and which metrics would you expect this role to move first? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Harborlight Health's own careers page, and get the salary range from the recruiter, before investing effort | RR1, RR2 | `[grounded]` register | pending your approval |
| E1 | Lead the resume with: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | R3; every clause traces to your statement | `[grounded]` your statement | `resume_edits_pending_approval` |
| E2 | "Built the company's Looker instance from scratch: 40+ governed dashboards." | R4; your own words | `[grounded]` your statement | `resume_edits_pending_approval` |
| E3 | "Write the monthly metrics memo read by the exec team; present monthly to the VP Product." | R5, R7 | `[grounded]` your statement | `resume_edits_pending_approval` |
| E4 | "Built the data warehouse's consent-state model; handled GDPR/CCPA consumer PII." Do not describe this as HIPAA experience | R10; the line names what you did and stops short of what you didn't | `[grounded]` your statement | `resume_edits_pending_approval` |
| W1 | A sanitized one-page experiment write-up (hypothesis, design, readout, decision) as a work sample | R3, R7; the artifact would raise their bands | `[grounded]` the map | pending your approval |
| Q1 | Ask the RR1, RR2 and RR4 verification questions verbatim in the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Every claim above is your statement and counts as a lead until an artifact backs it.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the search was refused. It would have moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range Looker experimentation 2026"; the search was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can assemble all of this into a `tuesday-dossier.md` if you want to carry it into later turns or interview prep.

## Upgrade menu

- Permission to run web searches → RR1 could close (does the company and the posting exist as described), and the market calibration row would get a pay band.
- Your salary floor, location and remote preference → hard-gate rows would be added and the hard-gates line would stop saying checks are unknown.
- A sanitized experiment write-up, query sample, or metric definitions doc → R2, R3 and R6 move toward `high`.
- The hiring manager's name → role reality's scope read, and which of your stories to lead with.
- A recruiter's answer on salary and success measures → RR2 and RR4 close.

## Questions

G1 — Did you define and own shared metric definitions (in LookML, dbt, or a metrics doc), and how did you control changes to them?

G2 — Have you mentored or onboarded other analysts, formally or informally? Roughly how many people over what period?

G3 — Have you worked directly with subject-matter experts outside product (nutritionists, culinary, ops, support) to shape an analysis or a test? What did they change?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.