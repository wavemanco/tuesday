I'll read the reference files the skill points to before building the assessment.
# Job Underwriting — Product Manager, Platform APIs at Quartzline

## Decision snapshot

**No, this isn't a waste of your time. R3 and R6 are `direct`. R1a, R2, R4 and R7 are `adjacent`. R1b (3+ years of titled product management experience) is `absent`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R6 · adjacent: R1a (product management work), R2 (shipped API or platform products), R4 (stakeholder management across engineering, sales, customers), R7 (specs, delivery, roadmap) · absent: R1b (3+ years of titled product management)
- `important` — unclear: R5 (agile delivery), R8 (adoption metrics)

R1b — a years-and-title requirement that no rewording of your work can meet; R2 and R7 — adjacent, limits named; R8 (`low`) — a lead awaiting your answer.

**Opportunity ledger.** Employer existence is unverified (RR1), pay is not stated (RR2) and first-year success measures are unstated (RR4). One entry runs the other way: the scope is concrete (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. RR1 verifies: the role is live on Quartzline's own careers page.
  2. The title gap is carried openly, with the adjacent bridge (R1a, R6) in front and no claim of PM experience (R1b).
  3. Pay is confirmed workable (RR2).
- **What would turn this to `no_go`:** a non-negotiable of yours that Quartzline's terms contradict, such as a pay floor or a location limit (C1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Existence and a live posting not checked (see evidence status) | `[grounded]` JD header as pasted |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | One PM, one platform, two squads, and an audience of integrators. The audience is the same kind of party you worked with from the vendor side, so the fit is adjacent rather than a different field | `[inferred]` from the JD's scope language against your 30+ client integrations of your company's REST APIs |
| Market calibration | Not established. The role-family sweep did not run, so I'm stating no pay band | — |
| Unknowns | Pay; seniority label; reporting line; decision rights on the roadmap; first-year outcomes; what counts as "shipped API or platform products" | `[grounded]` JD silence |
| Contradictions | None visible inside the JD. No second source was available to check against | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | Product management work: roadmap input, specs, delivery with engineers (the substance of "3+ years product management experience") | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions collecting client feedback for product, wrote requirements documents, and coordinated engineers and product managers on custom builds. Limit: that is input to a roadmap and delivery of client builds, not owning a backlog or prioritization decisions. CV prose only, so `medium` | `[grounded]` CV, self-report | G3; work sample W1 |
| R1b | 3+ years of titled product management experience (must-have) | must_have | absent | none | capability | You have never held a PM title, so no years count toward the figure as written. A years figure is graded, not a gate: it's work-near-it evidence, not a term you meet or don't. A years figure marked must-have is commonly screened literally, so expect the title to be the first objection | `[grounded]` your statement that you've never held the title; `[generic]` screening pattern | Carry as the material risk; G3 closure path; A1, P1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your company's REST APIs end to end and wrote the integration playbook the team uses. That is the implementing side of an API product. The CV does not show you shipped an API product yourself | `[grounded]` CV | G1; W1 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs and integration architecture across 30+ REST integrations. Confirmed in the CV, limited inspectable proof, so expect a schema-level probe | `[grounded]` CV | Offer: a sanitized playbook excerpt or integration-architecture diagram would raise this to `high` |
| R4 | Stakeholder management across engineering, sales, and customers | must_have | adjacent | medium | discovery | The CV covers your engineers, clients' engineers, clients and product managers. Sales and support are not mentioned, so the row takes the lower reading | `[grounded]` CV, with sales and support absent from it | G2 |
| R5 | Experience with agile delivery | important | unclear | none | discovery | The CV is silent on sprints, backlogs or any delivery method. Coordinating engineers on custom builds doesn't establish one | `[grounded]` CV silence | G4 |
| R6 | Run discovery with integration partners | must_have | direct | medium | presentation | Your scoping workshops with clients and quarterly roadmap-input sessions are discovery in substance. The CV words them as implementation work, so the evidence exists but not in this JD's terms. Limit: your clients used your company's APIs, not Quartzline's | `[grounded]` CV | E1, E2 |
| R7 | Write specs, drive delivery with two squads, own the roadmap | must_have | adjacent | medium | transferability | Requirements documents, coordination of engineers, and roadmap input. Nothing shows prioritization trade-offs, backlog ownership, or accountability for a product used across clients | `[grounded]` CV | G1; W1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | The CV is silent. A note from an earlier conversation suggests an internal request-triage tool that support agents adopted. It is unconfirmed and unspecified, so it is a lead for a question and not your claim | `[inferred]` lead from prior-conversation memory, unconfirmed | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Any product you built or owned, and whether it was adopted (R8, R2, R7) | discovery | The CV shows no internal tool or product you owned. An unconfirmed note from an earlier conversation mentions a request-triage tool adopted by support agents | It is the likeliest evidence for "shipped a product" and "adoption", and could move R8 off `unclear` and narrow the limits on R2 and R7 | A tool, script or workflow colleagues adopted; deciding what it did; counting who used it; changing it after feedback | A screenshot, a spec or ticket, usage numbers, a message from a user | `[grounded]` CV silence; `[inferred]` lead from memory, unconfirmed; `[inferred]` that confirming it could move R8 |
| G2 | Working with sales and support (R4) | discovery | Sales and support are not in the CV | Half of R4 is unevidenced. It was not ranked into this turn's questions | Pre-sales scoping calls with account executives; go-live handoffs to support; escalations you resolved | A handoff checklist from your playbook | `[grounded]` CV silence |
| G3 | Titled PM years (R1b) | capability | No credible direct evidence of the title or its years | It is the most likely first objection | Nothing here is hidden experience. The closure path is a work sample (W1), a candid bridge (P1), and a warm route (A1). A product-adjacent step first is another path | A one-page API product brief | `[grounded]` your statement; `[generic]` that these are the usual closure paths |
| G4 | Agile delivery (R5) | discovery | The CV names no method | An `important` row sitting at `unclear` | Attending sprint planning with an engineering team; writing tickets or stories; accepting work against UAT | A sanitized ticket or board screenshot | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. In this session the check could not run | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | "no compensation stated in the posting as pasted" | The posting may not publish pay, or the paste may omit it. Your floor wasn't given, so it can't be checked against anything | `[grounded]` JD silence | What salary band is budgeted for this role? | unresolved |
| RR3 | Concrete scope | positive_signal | — | "Own the roadmap for our partner-facing API platform … two engineering squads" | The role has a named product, audience and team | `[grounded]` JD | Which roadmap decisions does this role make alone, and which sit with sales or leadership? | noted |
| RR4 | Success measures unstated | unknown | — | "define and track adoption metrics" | The PM may be asked to define their own success measures with no stated targets, or the targets exist and weren't pasted | `[inferred]` from the JD naming a metrics duty and no first-year outcome | What would success look like at twelve months, and which adoption measures exist today? | unresolved |

## Application plan

Everything here is proposed and nothing is final until you approve it. The resume lines carry `resume_edits_pending_approval`. Every other row, the cover-note opener and the work sample included, is `pending your approval`. I kept your own sentences and did not recast "scoping workshops" as "discovery". That would change the kind of work, so the JD mapping stays in my analysis and out of your wording.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move this line to the top of your experience: "Led 30+ client integrations of our REST APIs end to end — scoping workshops, requirements documents, integration architecture, UAT, go-live." Wording unchanged | R2, R6 | `[grounded]` CV | resume_edits_pending_approval |
| E2 | Surface, unchanged: "Ran quarterly roadmap-input sessions collecting client feedback for product." | R1a, R6 | `[grounded]` CV | resume_edits_pending_approval |
| E3 | Keep, unchanged: "Wrote the internal integration playbook the whole team uses." | R2, R3 | `[grounded]` CV | resume_edits_pending_approval |
| P1 | Cover-note opener: "I haven't held a product management title. For seven years I've led client integrations of my company's REST APIs end to end and run quarterly sessions collecting client feedback for product." | R1b | `[grounded]` your statements | pending your approval |
| W1 | A one-page, sanitized API product brief: a spec for one change to an API you know well, and how you'd measure its adoption. Add only what you can truthfully say you did | R1a, R2, R7, R8 | `[inferred]` from the limits in those rows | pending your approval |
| A1 | Look for a warm introduction rather than applying cold | R1b | `[generic]` role-family pattern | pending your approval |
| A2 | Confirm the role is live on Quartzline's own careers page before drafting anything | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: a prior-conversation note about a request-triage tool, which prompts a question and nothing more. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent a search on Quartzline's careers and platform pages and it was refused, because search permission wasn't granted. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | I sent a search on PM pay and scope for API-platform roles and it was refused. It would have moved the market calibration line and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

If you'd like to keep this, I can save it as `tuesday-dossier.md`.

## Upgrade menu

- Search permission, or a link to the live posting or Quartzline's careers page → RR1 and role reality's organization row close, and the market band can be set against pay.
- Your answer to G1, plus any artifact (a screenshot, a spec, usage numbers) → R8 and possibly R2 and R7 move.
- A sanitized playbook excerpt or integration-architecture diagram → R3 to `high`.
- Your answers on sales and support (G2) → R4 firms up.
- Your non-negotiables → the hard-gates line stops reading "checks unknown".
- The hiring manager's name → the scope read and which story to lead with.
- A prior resume → it may hold PM-shaped evidence the current one dropped.
- A deeper pass on Quartzline (up to 5 more searches and 2 more fetches), once search is allowed. Say the word.

**G1** — I have an unconfirmed note from an earlier conversation that you may have built an internal request-triage tool that support agents adopted. Did you build or specify something like that? What did you own, who used it, and how did you know it worked?

**G4** — On the custom builds, did the engineers work in sprints or from a backlog? What did you personally do in that cycle: write tickets, join planning, accept work?

**C1** — Do you have non-negotiables Quartzline's terms could touch, such as a pay floor, location or hybrid limits, work authorization, schedule or travel?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.