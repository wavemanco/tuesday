I've read the underwriting rules. Next I'm running the capped L1 research on Brindlemoor, the market for this role, and Odile Varga's public profile. Then I'll write the assessment.
**Probably yes on fit, but settle R1 (location) before you spend effort. The JD says "Fully remote (UK)", and Brindlemoor's careers page says "Leeds office four days a week". Status: `hold_pending_answers`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — direct: R8a · unclear: R8b (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet insurance domain)

R1 — the posting and the careers page disagree on where the work is done; R8b — product-side recommendations not yet evidenced; R10 (`medium`) — a credible bridge from motor, its limit named.

**Opportunity ledger.** The scope is concrete and the hiring manager's published work matches the mandate (RR3). The location terms contradict each other (RR1), the salary is unstated (RR2), and whether the role has reports is unknown (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Awaited answers:** (1) whether the role is remote or Leeds four days a week, and whether Leeds works for you (R1, RR1); (2) your salary floor against what Brindlemoor will pay (RR2); (3) your product-side recommendation work (R8b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech selling a pet-insurance product; the role reports to the Director of Pricing | `[grounded]` JD header and careers page fetched |
| Posting status | Live: the careers page says "Accepting applications" | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Contradiction: the JD says "Fully remote (UK)"; the careers page says "Leeds office four days a week" | `[grounded]` both sources quoted |
| Hiring manager | Odile Varga, Director of Pricing. Gave a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books. Previously head of pricing analytics at Calloway Re for six years | `[grounded]` public profile, from a search result; the page itself was not fetched |
| Management | The JD states no line-management duty or requirement, so your lack of management experience is not a stated gap. Whether the role has reports is unknown | `[grounded]` JD silence; `[inferred]` that it is a single-contributor post, from the report-to-Director line and the absence of any people duty |
| Scope read | A normally scoped senior analyst post on one product. Your five years, two of them senior, sit at the JD's 4+ years | `[inferred]` from the JD's responsibilities against your stated background |
| First-90-days and first-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Market calibration | A senior pricing analyst at UK insurers and insurtechs has a median base of about £58,400, with an interquartile range of £52,100 to £64,900. The posting withholds pay, so this is the band to expect, never Brindlemoor's offer (RR2) | `[generic]` role-family search this session, Pricewell 2026 survey (n=612, not pet-specific, remote or office not split out) |
| Unknowns | Salary; remote versus Leeds; team size and reports; success measures | — |

## Evidence map

Your background was given in prose, which counts as self-report, so `medium` is the ceiling for now.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | Two sources disagree and you have not stated a location constraint. Confidence is `none` because there is no statement of yours to grade yet | `[grounded]` JD and careers page; no constraint given | Ask the employer which is true (RR1); tell me your constraint |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years' pricing analytics at a UK motor insurer, two as senior analyst. Specific and confirmed, no inspectable artifact yet | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily, confirmed by you. No code or repository inspected | `[grounded]` your stated background | A sanitised query or notebook would raise it |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, not inspected | `[grounded]` your stated background | A sanitised model summary (factors, diagnostics) would raise it |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which meets "underwriting or actuarial" | `[grounded]` your stated background | An anonymised review deck would raise it |
| R6 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" is your wording. How you monitored the model (what you tracked, how drift was caught) is not stated, so claim only what you can describe. A probe is likely, since the hiring manager has published on monitoring models | `[grounded]` your stated background; `[inferred]` probe, from the manager's published talk topic | Be ready with one real monitoring example from your own work |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Which parts were yours (design, analysis, readout) is not stated, so the claim stays "ran" | `[grounded]` your stated background | Be ready to say which parts you owned |
| R8a | Recommendations for underwriting | important | direct | medium | none | Tests run with underwriting and a quarterly review presented to its head. That you authored the recommendations is implied, not stated, so confidence stays at `medium` | `[grounded]` your stated background | none |
| R8b | Recommendations for product | important | unclear | none | discovery | Nothing in your background mentions product teams | `[grounded]` silence in your background | Closing question below |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your stated background | none |
| R10 | Pet-insurance domain (not required by the JD; implied by the product) | preferred | adjacent | medium | transferability | You have never worked on pet insurance, which you stated. Motor GLM rating and price testing carry over. The limit is that none of the pet-specific rating work has been exercised. Pet books usually rate on different factors than motor | `[inferred]` from the JD's product description against your stated background; `[generic]` that pet and motor rating factors differ | Say so plainly; see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location (R1, hard_gate) | hard_gate | The JD and the careers page disagree; your constraint is unknown | If Leeds four days is the real term, it may fail a constraint of yours. Wording cannot fix a gate | — (a term, not experience) | A written answer from Brindlemoor on the working pattern | `[grounded]` both sources; `[inferred]` that it decides the status |
| G2 | Product recommendations (R8b, important) | discovery | Underwriting work is evidenced; product-side work is not | An `important` row at `unclear`; a yes would close it | A pricing change you recommended to a product owner; a test result that changed a product feature or tier; a joint review with product | A one-page recommendation note or slide | `[grounded]` silence in your background; `[inferred]` that it is a likely interview topic, since the JD names product |
| G3 | Pet domain (R10, preferred) | transferability | Motor GLM rating and 14 price tests carry over | A missing domain is the likeliest objection to a motor candidate | Any rating work that touched age, breed-like or risk-class factors, claims inflation, or renewal pricing | A short note on what you would check first in a pet book, labelled as a plan, not experience | `[inferred]` bridge from your stated motor work; `[generic]` that domain is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location terms contradict | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The post may have been changed after the JD was written, may be hybrid in practice, or one of the two sources may be out of date. Medium, not high, because a mismatch between two postings is common and unresolved | `[inferred]` from the two quoted sources | Is this role fully remote, or based in Leeds four days a week? | unresolved |
| RR2 | Salary unstated | unknown | — | JD gives no pay figure | The pay may sit inside or outside the market band in role reality | `[inferred]` from the missing figure against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Named manager whose published work matches the role | positive_signal | — | "reports to the Director of Pricing"; talk on monitoring rating models | The role has a senior owner who has published on the work the JD describes | `[grounded]` careers page and public profile | What would success look like in your first year? | noted |
| RR4 | Team and reports unstated | unknown | — | JD lists responsibilities but no team or people duty | The role may be a single contributor or may grow into leading others | `[inferred]` from the JD's silence | Does the role have direct reports now, and is it expected to? | unresolved |

## Application plan

All of these are proposed and pending your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: put your three strongest lines first, in your own words: "Built and maintained the GLM rating model for the young-driver book"; "Ran 14 price tests last year with the underwriting team"; "Present the quarterly pricing review to the head of underwriting". Add no new claim | R4, R7, R5 | `[grounded]` your sentences | pending your approval |
| P1 | Interview framing: "I haven't worked on pet insurance; I've built and maintained GLM rating for motor and I'd learn the pet-specific factors." Claims nothing beyond your own statement | R10 | `[grounded]` your statement | pending your approval |
| M1 | If management comes up, say plainly that you have not managed anyone. The JD does not ask for it | R-none; RR4 | `[grounded]` your statement and JD | pending your approval |
| A1 | Confirm remote versus Leeds before investing in the application | R1, RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Prepare one honest monitoring example from your own model, which the hiring manager's published topic makes a likely probe | R6 | `[inferred]` from the public talk topic | pending your approval |
| Q1 | Ask RR1 to RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Everything about you comes from your message and counts as self-report; the open items are in the queue above.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Confirmed the posting is live and the product and reporting line match. Found the Leeds contradiction (R1, RR1) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read from the result snippet only. Moved the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read from the result snippet only. Moved the scope read, R6 and A2 |

Brindlemoor's stage and size were not established from these sources, only that it sells pet insurance and has a live posting.

I can write this up as `tuesday-dossier.md` if you'd like.

## Upgrade menu

- Your location constraint and salary floor: R1 resolves, and RR2 can be set against your floor.
- Brindlemoor's answer on remote versus Leeds: R1 and RR1 close, and the decision likely becomes `go` or `no_go`.
- An inspectable artifact (a sanitised model summary, a price-test design note, or an anonymised quarterly review deck): R3 to R5 and R7 could move to `high`.
- Your product-side work (G2): R8b closes.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches): say the word and it runs.

## Questions

G1 — Could you work from Leeds four days a week, or is fully remote a requirement for you?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you ever taken a price-test result or rating change to a product owner and had it change a product decision? What did you own, and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

RR2 — What is your salary floor for a move?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.