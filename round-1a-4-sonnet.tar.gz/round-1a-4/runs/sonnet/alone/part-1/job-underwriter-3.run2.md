I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**No, this posting isn't worth pursuing. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin, 5 days a week), R2 (Base pay of $70–85k)
- `must_have`: direct: R4, R5 · unclear: R3 (8+ years growth leadership)
- `important`: unclear: R6 (SEO and content), R7 (Brand, PR, partnerships), R8 (Sales ops), R9 (Team of one, ambiguity)

R1: remote-only against five mandatory on-site days; R2: the posted range sits below your floor; R4, R5: where your evidence lines up; R3: years in leadership titles still unstated.

**Opportunity ledger.** The posted terms collide with both of your stated constraints (R1, R2, via RR1, RR2). The mandate's shape reads as overloaded: seven functions and one person, with no stable metrics and after-hours work as culture (RR3, RR4, RR5, RR6). The employer itself isn't established from here (RR8). One entry runs the other way: you'd report straight to the CEO (RR9).

- **Hard gates:** failed: R1 (On-site in Austin, 5 days a week), R2 (Base pay of $70–85k)
- **Severe red flags:** none found.
- **What would change this:** the posting would have to allow full-time remote work from Portland (R1) and state a base at or above $150k (R2). Neither is yours to change, and wording on your side can't fix either.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, described as an e-commerce enablement startup, Series A, "profitable since day one"; Austin office | `[grounded]` posting header; not established independently (research unavailable) |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | "A team of one to start"; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site 5 days a week, "no exceptions"; "evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside"; equity is unquantified | `[grounded]` JD |
| Success metrics | "Success metrics will evolve as we learn"; none stated | `[grounded]` JD |
| Scope read | Seven functions under one title with no stated team or budget; a bundled mandate | `[inferred]` from the JD's function list set against "team of one" |
| Market calibration | None. The role-family sweep could not run, so there is no band to set the $70–85k against. No market figure is offered from memory | `[grounded]` JD for the posted figure; no band available |
| Unknowns | Equity terms, budget, committed headcount, which functions are executed by hand, board reporting cadence, whether the company and posting are live as described | `[grounded]` JD silence |
| Contradictions | A head-level title and a "team of one" mandate with board visibility, against a base of $70–85k | `[inferred]` from the JD's own terms |

## Evidence map

Your background came as prose only, with no CV. It counts as self-report, so no row is above `medium` except your own constraints.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, no exceptions (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own confirmed constraint. The fit fails because the JD rules out any remote arrangement and you've ruled out relocating | `[grounded]` JD quote and your stated constraint | None within your control; only a changed term resolves it |
| R2 | Base pay of $70–85k (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your confirmed floor. The fit fails because the top of the posted range is $65k below it | `[grounded]` JD figure and your floor | None within your control; only a changed term resolves it |
| R3 | 8+ years growth leadership | must_have | unclear | medium | discovery | You state 9 years in growth, with Growth lead then Head of Growth titles. How many of those years were under a lead or head title isn't stated, so 8+ in leadership is neither met nor missed. Years in leadership titles aren't a gate | `[grounded]` your prose; the split of years is not stated | Recall the years under each title (G1) |
| R4 | Paid acquisition | must_have | direct | medium | none | You say you owned paid, with a budget you controlled, while scaling one company from $8M to $40M ARR over three years. Confirmed and specific, but nothing inspectable yet. Expect a probe on how much of the growth was paid-driven | `[grounded]` your prose | An ARR bridge or budget sheet, sanitized, would raise this to `high` |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You say you owned lifecycle and are deep in Braze. Specific and plausible, but not yet inspectable | `[grounded]` your prose | A sanitized Braze journey map or results dashboard would raise this to `high` |
| R6 | SEO and content | important | unclear | none | discovery | Your prose says nothing about SEO or content ownership. Not evidence of absence | `[grounded]` silence in your prose | See G2 |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | Nothing stated in these areas | `[grounded]` silence in your prose | See G2 |
| R8 | Sales ops | important | unclear | none | discovery | Nothing stated. The JD doesn't say whether this means CRM hygiene, pipeline reporting or quota design | `[grounded]` silence in your prose; `[inferred]` ambiguity from the JD | See G2 |
| R9 | Team of one, thriving on ambiguity | important | unclear | low | discovery | You built and managed teams of 3–7 and owned experimentation. Hands-on solo execution across channels isn't evidenced either way | `[grounded]` your prose on teams; `[inferred]` that solo execution is untested | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Years in leadership titles (R3, must_have) | discovery | 9 years in growth, two titles with "lead" and "Head" in them, no dates | A must-have that the posting states as a number | Start and end dates for the growth lead and Head of Growth roles at both companies | LinkedIn dates, an offer letter, a prior resume | `[grounded]` the prose gives no dates; `[generic]` that a literal years screen is common for numbered requirements |
| G2 | SEO/content, brand/PR/partnerships, sales ops (R6, R7, R8, important) | discovery | No mention in your background | Three functions the posting bundles in; coverage is unknown | Owning a content or SEO program; a launch with PR or partner co-marketing; building lead routing or pipeline reporting for sales | A traffic report, a partner agreement, a CRM or pipeline dashboard | `[grounded]` silence in your prose |
| G3 | Solo execution (R9, important) | discovery | Team leadership is evidenced, hands-on solo work isn't | The JD says "team of one to start" | A period where you ran channels yourself, such as a pre-hire stretch or a new-market launch | A campaign calendar, an experiment log | `[grounded]` your prose; `[inferred]` that this matters here from the JD's team-of-one line |

None of these gaps can move the status while R1 and R2 fail. They matter only if you revisit your constraints.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site five days against remote-only (see R1) | red_flag | medium | "On-site in our Austin office 5 days a week — no exceptions." | For you, the location term is incompatible. Severity stays at the lower value because the gate itself is carried by R1 | `[grounded]` JD quote against your stated constraint | Does "no exceptions" hold for this role in particular? | confirmed |
| RR2 | Base pay below your floor (see R2) | red_flag | medium | "$70–85k base plus meaningful equity upside" | The top of the range is $65k under your floor. Severity stays at the lower value for the same reason as RR1 | `[grounded]` JD figure and your floor | Is the base range fixed for this role? | confirmed |
| RR3 | Seniority–compensation mismatch | risk_signal | medium | "8+ years growth leadership required" with "$70–85k base" | The posted range may sit below what a head-level, seven-function mandate normally pays. This is unconfirmed, because the market sweep did not run | `[inferred]` from the JD's scope and seniority against its pay, no band confirmed | How was this range set, and against what benchmark? | unresolved |
| RR4 | Responsibility without resources; bundled specializations | risk_signal | medium | "Own all revenue growth end to end… You will be a team of one to start" | Accountability for seven functions may come with no budget or headcount | `[inferred]` from the JD's function list against its silence on budget | What budget and headcount are committed for year one, and which functions will I execute myself? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine rather than exceptional | `[inferred]` from the JD's wording | In the last quarter, how many evenings or weekends did the team work, and what offsets it? | unresolved |
| RR6 | Absent success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You'd be accountable to the CEO and the board with no agreed definition of success | `[inferred]` from the JD's wording and its reporting line | What would count as success at 6 and 12 months, in numbers you'd sign off on today? | unresolved |
| RR7 | Equity unquantified | unknown | — | "meaningful equity upside" | The equity may be too small, or too illiquid, to offset the pay gap, or it may be generous. The posting doesn't say | `[grounded]` JD silence | What is the grant: percentage, share count, strike price and vesting? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | Direct CEO reporting line with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role has senior access and visibility | `[grounded]` JD | How often does the board review growth metrics, and who sets them? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pass on this posting and put your effort into openings that are remote and priced to your floor | See R1, R2 | `[grounded]` R1, R2 rows | pending your approval |
| A2 | If you proceed anyway, ask the questions in RR1–RR8 verbatim before any application effort. They become essential, not optional | The register travels with you past a `no_go` | `[grounded]` register | pending your approval |
| A3 | If you proceed anyway, lead with the $8M to $40M ARR story (R4), stated only as you confirm it and with ownership kept precise | It's your strongest row. Nothing is drafted, and no CV edits are proposed | `[grounded]` R4 row | pending your approval |

## Evidence status

Verified: none yet. Your background is prose only and I haven't seen a CV, so its claims are leads. They aren't proof.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A"; the call was refused (search permission not granted). It would have moved role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary base range Series A startup 2026"; the call was refused. It would have moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given (the posting says only "the CEO"), so there was no query to form |

If you'd like a record of this assessment, I can write it out as `tuesday-dossier.md`.

## Upgrade menu

- Search permission, or a link to the live posting on Novaline's own careers page, plus the recruiter's email domain, would run targets 1 and 2. That would settle RR8 and give the market band for RR3.
- Your CV, plus a sanitized ARR bridge, budget sheet or Braze dashboard, would lift R3, R4 and R5 toward `high`.
- Any SEO, brand, PR, partnership or sales-ops work would move R6, R7 and R8 and close G2.
- The CEO's name would sharpen role reality's scope read.
- A deeper pass on Novaline covering funding, leadership churn and recent news is available once, up to 5 more searches and 2 more fetches. Say the word and it runs.

No questions this turn. Nothing I could ask would change a status that rests on two failed gates.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.