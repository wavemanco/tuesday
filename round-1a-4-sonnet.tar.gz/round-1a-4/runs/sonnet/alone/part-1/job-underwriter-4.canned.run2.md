Checking the careers page, because it says Leeds four days a week and your JD says fully remote.
# Job Underwriting Assessment: Senior Pricing Analyst at Brindlemoor

## Decision snapshot

**Yes, apply, as long as the working pattern in R1 suits you. The role says "fully remote" and the employer's own page says Leeds four days a week. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK) working)
- `must_have`: direct: R2, R3, R4, R5, R6a, R7 · adjacent: R6b (Monitor rating models)
- `important`: direct: R8a · unclear: R8b (Recommendations to product)
- `preferred`: direct: R9

R1 — the sources disagree and your own requirement isn't given yet; R6b (`low`) — maintaining a model isn't yet shown to be monitoring it; R8b — product audience not evidenced.

**Opportunity ledger.** The employer and the live posting are established, with a clear reporting line to the Director of Pricing (RR3). The posting contradicts the careers page on location (RR1), and neither source states pay (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK) working); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed and acceptable to you (R1, RR1); (2) the pay band clears your floor (RR2); (3) the monitoring question (R6b) is answered, or the claim is kept as adjacent.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, a UK insurtech that is hiring for this post now | `[grounded]` JD header; careers page fetched, "Accepting applications" |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | The Director of Pricing | `[grounded]` careers page |
| Working pattern | **Contradiction.** The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week". Neither is resolved here | `[grounded]` JD against careers page |
| People management | The JD does not list managing people as a requirement, so your lack of it is not a gap against the stated terms | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Hiring manager | Odile Varga, Director of Pricing. Her public profile lists a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books. It also lists six years as head of pricing analytics at Calloway Re | `[grounded]` profile snippet from search; the page itself was not opened |
| Market calibration | A senior pricing analyst at UK insurers and insurtechs has a median base of £58,400 and an interquartile range of £52,100 to £64,900. This is the band to expect, never Brindlemoor's offer, since the posting withholds pay (RR2) | `[generic]` Pricewell 2026 pay survey (n=612), seen as a search snippet |
| Unknowns | Salary; team size; whether the role has any decision rights over rate changes; the real working pattern | `[grounded]` JD and careers page silent |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) working | hard_gate | unclear | none | hard_gate | You gave no location or schedule requirement, so there is no statement to grade. The JD and careers page conflict, so the role's terms are unsettled too | `[grounded]` JD and careers page quoted; no candidate statement | Ask G1, then put RR1's question to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You describe 5 years of pricing analytics at a UK motor insurer, 2 of them as senior analyst. It is specific, but no document has been inspected | `[grounded]` your intake message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You say "SQL and Python daily". Plausible and specific about frequency, but with no artifact to inspect | `[grounded]` your intake message | A sanitized query or notebook would raise it to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, but not inspected | `[grounded]` your intake message | A sanitized model spec or governance note would raise it to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Underwriting is covered; actuarial leads are not mentioned | `[grounded]` your intake message | none |
| R6a | Build rating models | must_have | direct | medium | none | Same GLM evidence as R4, read for the build half of "build and monitor" | `[grounded]` your intake message | none |
| R6b | Monitor rating models | must_have | adjacent | low | discovery | You "maintained" the model. Maintaining is adjacent to monitoring but does not show it: no mention of performance tracking or drift checks. The lower band applies. The hiring manager's public talk concerns monitoring, so this row matters more than its tier suggests | `[grounded]` "maintained" in your message; `[inferred]` from her talk title that monitoring is a live topic for her | Ask G2 |
| R7 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with the underwriting team. "Ran" is the verb you gave, so ownership of the design stays open | `[grounded]` your intake message | Ask G3 |
| R8a | Recommendations to underwriting | important | direct | medium | none | You present the quarterly pricing review to the head of underwriting and ran the tests with that team | `[grounded]` your intake message | none |
| R8b | Recommendations to product | important | unclear | none | discovery | Nothing you've said involves a product audience. Product teams at a pet insurer sit outside what motor underwriting exposed you to | `[grounded]` your message silent on product; `[generic]` on how product teams relate to pricing | Listed in the gap queue as G4 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | You have motor insurance experience. The JD does not require pet insurance, and you have none. Pet rating uses different risk factors than motor, which is a limit to name | `[grounded]` your message and JD; `[generic]` on pet versus motor rating | Name the pet-insurance limit plainly (A3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The two sources disagree and your requirement is not given | Decides whether this is worth applying to at all | Not applicable; the question is whether the gate is met | The recruiter's or the hiring manager's confirmation | `[grounded]` JD against careers page |
| G2 | Monitoring rating models (R6b, must_have) | discovery | "Maintained" the young-driver GLM, with no detail on what tracking you did | A must-have, and the hiring manager has spoken publicly on this topic | Actual-versus-expected checks; drift or segment-performance reports; alerts or refit triggers; a periodic model review | A sanitized monitoring report, a model governance note, or a dashboard screenshot | `[grounded]` your message silent on detail; `[inferred]` the talk makes it a likely probe |
| G3 | Price-test design (R7, must_have) | discovery | You ran 14 tests; who set the design, sample and success measure is not stated | Interviews for this role usually ask what you personally designed versus ran | Choosing test and control groups; setting sample size or duration; defining the readout; stopping or rolling out a test | A test brief or readout, sanitized | `[grounded]` your message; `[generic]` that interviews probe design ownership |
| G4 | Product audience (R8b, important) | discovery | No evidence of recommendations to a product team | A smaller risk; can wait until later in the process | A pricing change you took to a product or commercial lead; a feature or tier change you modelled | A sanitized deck or memo | `[grounded]` your message silent on product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | JD and careers page disagree on location (R1) | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | The copy you hold may be older or differently sourced than the live page, or the pattern may be flexible in practice. Neither is established | `[inferred]` from the two quotes side by side | Is this role fully remote, or is it based in Leeds four days a week? | unresolved |
| RR2 | Pay not stated (R1 is separate) | unknown | — | JD gives no salary; the careers page excerpt gives none | The figure may sit anywhere in the survey band in role reality, or the employer may not publish pay | `[inferred]` from the missing figure, set against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Clear scope and reporting line | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The role has a defined owner and a senior line, which usually means real decision access | `[grounded]` careers page quote; `[generic]` on what such a reporting line usually brings | Which rate or rule changes would this role recommend, and which would it approve? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with the recruiter or Odile before investing in the application | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | CV edit: lead the experience section with "Ran 14 price tests last year with the underwriting team" and your quarterly pricing review to the head of underwriting. No new facts, only moved up | see R7, R8a | `[grounded]` your own sentences | `resume_edits_pending_approval` |
| P1 | Positioning for this reader: lead with the young-driver GLM you built and maintained. Be ready to say exactly what you tracked on it, once you've answered G2 | see R6a, R6b; her public talk concerns monitoring | `[inferred]` from the talk topic | pending your approval |
| A3 | Say plainly in the application and interview that you haven't worked on pet insurance, and present your motor rating work as your closest experience, with that limit named | see R9 | `[generic]` pet rating differs from motor | pending your approval |
| Q1 | Ask RR1, RR2 and RR3's verification questions verbatim during the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the employer is real and the posting is live, and it surfaced the location contradiction (R1, RR1) |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), read as a snippet only. It moved role reality's market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), read as a snippet only. It moved role reality's hiring-manager row and plan row P1 |

I can package this as `tuesday-dossier.md` if you'd like to carry it into later steps.

**Upgrade menu**

- Your location or schedule requirement, and your salary floor → R1 and RR2 can be checked against what you need.
- Your answer on the working pattern from the employer → RR1 and R1 close, and the decision likely settles to `go` or `no_go`.
- A sanitized monitoring report or governance note → R6b can move from `low`, and R4 can reach `high`.
- A test brief or readout → R7's design ownership resolves.
- Your CV or an earlier version → edits E1 and P1 can be checked against your own wording.
- A deeper research pass on Brindlemoor (leadership and hiring patterns, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

G1 — Is working from home a requirement for you, or is a Leeds office four days a week workable? Roughly what salary would you need?

G2 — On the young-driver model you maintained, what did you personally track over time (for example, actual versus expected, drift or segment performance), and how often?

G3 — For the 14 price tests, which parts did you personally set (the groups, sample size, success measure), and which were set by underwriting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.