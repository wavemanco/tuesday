I've read the skill's reference files. Now I'm running the research it calls for: one search to check that Quartzline exists as described, and one for typical scope and pay for this kind of role.
Nothing could be researched. Both search calls were refused, so everything below rests on the JD and your resume. I couldn't confirm that Quartzline exists as described, and I have no pay or market comparison. Those are the biggest limits on this assessment.

## Decision snapshot

**No, you're not wasting your time, but this posting is a stretch: R1a (3+ years of PM experience) is absent, and R1b and R2 are bridges rather than direct matches. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1b (PM-type work: roadmap, specs, delivery), R2 (Shipped API or platform products) · absent: R1a (3+ years titled PM experience)
- `important` — direct: R4a · adjacent: R6 (Discovery with integration partners), R8 (Launches with sales and support) · unclear: R4b (Sales stakeholders), R5 (Agile delivery), R7 (Adoption metrics)

R3 — your strongest row; R1b and R2 — credible bridges, limits named; R1a — a literal-years requirement that no rewording closes.

**Opportunity ledger.** Under-specified, with nothing alarming found. The employer is unverified because research was refused (RR1), pay and location are unstated (RR2, RR3), and roadmap decision rights are unknown (RR4). RR5 runs the other way: the scope is concrete.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** conditions for go are (1) the employer verifies (RR1); (2) someone with authority confirms that equivalent work can meet the years requirement, or you decide to treat this as a long shot (R1a, A1); (3) the bridges in R1b and R2 are framed honestly as adjacent, never as PM titles or ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B, as stated in the JD header; not independently checked | `[grounded]` JD header, unverified by research |
| Mandate | Own the roadmap for a partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| First-year outcomes | Not stated; adoption metrics are the only success signal | `[grounded]` JD silence |
| Scope read | A real product-ownership scope: a named platform and two squads, with most of the load on discovery and delivery | `[inferred]` from the squad count and the responsibility list |
| Market calibration | Not available: the role-family sweep did not run, so there is no band for title, scope or pay | `[grounded]` search calls refused |
| Unknowns | Pay; location or remote policy; reporting line; whether you'd be the first PM; decision rights over the roadmap; how "adoption" is defined | `[grounded]` JD silence |
| Contradictions | None inside the JD; no careers page was checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years of product management experience (titled) | must_have | absent | none | capability | You said you've never held a PM title. A length-of-experience requirement is graded as a must-have, not a gate. Years requirements may be screened literally before a human reads the application | `[grounded]` your statement and the JD; `[generic]` on screening | A1: ask whether equivalent work counts; no wording closes this |
| R1b | PM-type work: owning a roadmap, writing specs, driving delivery | must_have | adjacent | medium | transferability | Evidence: requirements documents, coordinating engineers and PMs on custom builds, quarterly roadmap-input sessions collecting client feedback for product. Limit: this fed product's roadmap and priorities and does not show you owning them | `[grounded]` CV prose | G2 question: what you decided versus recommended |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the internal integration playbook. Limit: this is implementing a vendor's API product, not building or launching one. A possible internal triage tool is an unconfirmed lead only | `[grounded]` CV prose; lead unconfirmed | G1 question |
| R3 | Strong technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs, and integration architecture across 30+ integrations. Medium because nothing has been inspected yet | `[grounded]` CV prose | Offer: a sanitized playbook excerpt would raise to high |
| R4a | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated your engineers, client engineers and PMs, and ran client workshops | `[grounded]` CV prose | none |
| R4b | Stakeholder management with sales | important | unclear | low | discovery | The resume is silent on sales | `[grounded]` CV silence | G4, not asked this turn |
| R5 | Agile delivery experience | important | unclear | low | discovery | The resume mentions UAT and go-live, not sprints or backlogs | `[grounded]` CV silence | G5, not asked this turn |
| R6 | Discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and roadmap-input sessions are client-facing discovery. Limit: scoped to single implementations, with no evidence of synthesising across partners into priorities | `[grounded]` CV prose | G2 covers it |
| R7 | Define and track adoption metrics | important | unclear | low | discovery | The resume is silent; the triage-tool lead might bear on it but is unconfirmed | `[grounded]` CV silence; memory lead | G1 question covers it |
| R8 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live coordination for client integrations. Limit: client go-lives are not product launches to a market | `[grounded]` CV prose | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product and adoption (R2, R7) | discovery | An unconfirmed note from an earlier conversation that you built an internal tool support agents adopted; your resume doesn't mention it | If confirmed, it could be your one shipped-product and adoption story | An internal tool, script or workflow other teams used; usage you tracked | A screenshot, usage numbers, a short write-up | `[grounded]` resume silence; `[inferred]` that it could lift R2 and R7 |
| G2 | PM-type ownership (R1b, R6) | transferability | You fed product roadmaps; whether you decided or shaped priorities isn't stated | Separates "supplied input" from "owned prioritisation" | Choosing which client asks went to product; writing specs engineers built from | A spec or requirements document, sanitized | `[grounded]` CV prose |
| G4 | Sales and launches (R4b, R8) | discovery | Silent on sales | Two JD duties touch sales | Joint client scoping with sales; handoffs | A sanitized handoff note | `[grounded]` CV silence |
| G5 | Agile (R5) | discovery | Silent | Listed in the JD requirements | Sprint planning or backlog work with squads | A board or ticket examples, sanitized | `[grounded]` CV silence |
| G6 | 3+ years PM (R1a) | capability | No titled PM years | Likely the first filter | None to recover. Closure paths are a waiver, a referral, or roles that don't require the years | None | `[grounded]` your statement |

Questions for G1 and G2 are in the closing block. G4 and G5 aren't asked this turn.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Research was refused, so nothing was checked. The entity may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay unstated | unknown | — | The pasted posting gives no pay | The band may be below what a 7-year senior hire expects, or the figure may simply be withheld | `[inferred]` from JD silence; no band was researched | What is the budgeted range for this post? | unresolved |
| RR3 | Location and work arrangement unstated | unknown | — | The pasted posting gives no location | A constraint of yours could conflict; none were given | `[inferred]` from JD silence | Where is the role based, and is remote or hybrid allowed? | unresolved |
| RR4 | Roadmap ownership vs decision rights | unknown | — | "Own the roadmap for our partner-facing API platform" | Roadmap may be steered by sales commitments or leadership | `[inferred]` from the ownership language against silence on decision rights | Which roadmap decisions does this role make alone, and who can override them? | unresolved |
| RR5 | Concrete scope | positive_signal | — | "drive delivery with two engineering squads" | The mandate is defined and resourced | `[grounded]` JD | Who is on the two squads today, and what shipped last quarter? | noted |

## Application plan

Everything below is proposed and pending your approval. Nothing has been applied to your resume or sent.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Open the summary with your own sentence: "Led 30+ client integrations of our REST APIs end to end" | R2, R3: it's your wording | `[grounded]` your resume | resume_edits_pending_approval |
| E2 | Keep "Ran quarterly roadmap-input sessions collecting client feedback for product" as written. Don't upgrade it to roadmap ownership or add a PM title | R1b, R6: it stays honest | `[grounded]` your resume | resume_edits_pending_approval |
| A1 | Before investing, ask the recruiter whether equivalent work can meet the 3+ years requirement | R1a, RR1 | `[grounded]` map and register | pending your approval |
| A2 | Seek a referral or intro to the hiring manager rather than applying cold | Cold applications meet the years filter first | `[generic]` hiring pattern, not a claim about this employer | pending your approval |
| W1 | A one-page sample spec or adoption-metrics proposal for a public API, using no Quartzline internals | R1b, R7 | `[inferred]` from the gaps | pending your approval |
| Q1 | Ask RR1–RR5's verification questions in the loop | They double as interview prep | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: the internal triage tool, from an earlier conversation; it prompts a question and isn't evidence.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Quartzline logistics technology Series B partner API platform careers"; the call was refused. It would have fed RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "Product Manager API platform B2B Series B salary range scope technical product manager API"; the call was refused. It would have fed market calibration, RR2 and A2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

Extra, beyond this assessment, built only if you approve: a short list of PM-adjacent role types that fit your record better than this posting. This is worth offering because your question was about the pivot overall as well as this role.

I can save all of this as `tuesday-dossier.md` whenever you want a portable copy.

**Upgrade menu**

- Allow web search → the L1 pass can run, which settles RR1 and adds a market band for RR2.
- A sanitized playbook excerpt or a requirements document → R3 to `high`, and R1b firms up.
- Any artifact for the triage tool → R2 and R7 move.
- Your pay floor and location limits → hard gates get checked.
- The hiring manager's name → scope read and which story to lead with.
- After L1 runs: a deeper company check (up to 5 more searches and 2 more fetches) is available on request.

**Questions**

G1 — Did you build an internal tool or workflow that other people adopted, such as the request-triage tool? What did you own, who used it, and how did you know it worked?
G2 — On custom builds and roadmap-input sessions, what did you decide or prioritise yourself, and what did you only recommend?
C1 — Do you have non-negotiables on pay, location or remote work that this role should be checked against? I'm assuming you're still evaluating, not yet applying.
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.