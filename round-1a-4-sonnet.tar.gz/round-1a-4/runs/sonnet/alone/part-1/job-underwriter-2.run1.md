I'm reading the skill's reference files so I can build the assessment in its required format. Next up are the evidence-model rules, the gap and question rules, and the research and grammar rules.
# Decision snapshot

**Not a waste of time, but a reach on the stated must-have. R1a (3+ years of product management experience, as a titled PM) is `absent`, and R1b and R2 are only `adjacent`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4 · adjacent: R1b (PM-shaped work), R2 (Shipped API or platform products) · absent: R1a (3+ years PM, titled)
- `important` — adjacent: R5 (Partner discovery and specs) · unclear: R6 (Sales and support launches), R7 (Adoption metrics), R8 (Agile delivery)

R1a — no titled PM years, which no wording changes; R1b and R2 — bridges with their limits named; R7 (`low`) — one unconfirmed lead behind it.

**Opportunity ledger.** The scope reads as concrete (RR4). It is unverified in this session (RR1), and whether the title-years rule flexes is unknown (RR2). Pay and location are withheld (RR3), and success targets are unstated (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting are verified, which also lifts the cap on `go` (RR1); (2) the recruiter confirms adjacent experience is considered against the 3+ years rule, before you invest heavily (R1a, RR2); (3) R1b and R2 are always framed as adjacent, never as PM or shipped-product experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B — not checked against any outside source | `[grounded]` JD header as you pasted it |
| Mandate | Own the roadmap for the partner-facing API platform; run partner discovery; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| First-year outcomes | None stated. Adoption metrics are named as a duty, with no targets | `[grounded]` JD silence |
| Scope read | Broad single-owner scope covering the whole product loop from discovery to launch | `[inferred]` from the JD's six responsibilities |
| Market calibration | Not run: the role-family sweep was refused, so there is no band for title, seniority or pay | `[grounded]` Evidence status, target 2 |
| Unknowns | Salary and level; location or remote policy; who the role reports to; whether the 3+ years rule flexes; whether the post is new or a backfill | — |
| Contradictions | None visible inside the JD. It was not compared with the careers page | `[grounded]` JD text only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, as a titled PM | must_have | absent | none | capability | You said you have never held a PM title, so there are no titled years to show. The JD labels it must-have, but it is a length-of-experience requirement, not a gate, so the adjacent work in R1b counts as evidence | `[grounded]` your statement | Ask RR2's question to learn whether it flexes |
| R1b | The same requirement, met through PM-shaped work | must_have | adjacent | medium | transferability | Carries over: you ran quarterly roadmap-input sessions collecting client feedback for product, and coordinated engineers and product managers on custom builds. Limit: nothing yet shows you decided what got built, prioritized between requests, or owned an outcome | `[grounded]` your resume summary, self-reported, no artifact | G2 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | Carries over: 30+ end-to-end client integrations of your vendor's REST APIs, plus an internal integration playbook the whole team uses. Limit: you integrated and delivered with the product, and nothing shows you built or launched one | `[grounded]` your resume summary; `[inferred]` that the playbook is the nearest thing to a product you shipped | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, backed by 30+ REST integrations. `medium` because nothing inspectable has been shown yet | `[grounded]` your resume summary | W1 would raise it to `high` |
| R4 | Stakeholder management across engineering and customers (sales is R6) | must_have | direct | medium | none | You coordinated your engineers, the client's engineers and product managers, and ran client workshops through go-live. Carried exactly as you wrote it, with sales left to R6 | `[grounded]` your resume summary | none |
| R5 | Partner discovery and writing specs | important | adjacent | medium | transferability | Discovery is close: scoping workshops and quarterly roadmap-input sessions. Limit: your requirements documents were written for client integrations, not as specs for engineering squads | `[grounded]` your resume summary | G2 |
| R6 | Coordinating launches with sales and support | important | unclear | none | discovery | Your summary mentions go-live with clients but nothing about sales or support, or about product launches | `[grounded]` your resume silence | G3 |
| R7 | Defining and tracking adoption metrics | important | unclear | low | discovery | A prior-conversation lead, an internal triage tool support agents adopted, may bear on this. It is unconfirmed, so it only prompts a question | `[grounded]` memory lead, unconfirmed | G1 |
| R8 | Agile delivery | important | unclear | low | discovery | You coordinated custom builds, but your summary doesn't say what method or cadence they ran on | `[grounded]` your resume silence | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Built and shipped something others adopted (R2, R7; must_have and important) | discovery | A lead only: you may once have built an internal request-triage tool that support agents adopted. Nothing is confirmed, including your role, scope or any usage measure | It is the one thing that could turn R2 from "integrated the product" into "shipped a product", and it may supply R7's metrics | A tool, workflow or template other teams used; a usage count or before/after measure; deciding what it did and did not do | A screenshot, a spec or README, an adoption number, a short write-up | `[grounded]` memory lead, unconfirmed; `[inferred]` that it could move R2 |
| G2 | Decision ownership on builds (R1b, R5; must_have and important) | transferability | Strong coordination and requirements evidence, but no statement of what you decided, traded off or turned down | The PM role is about those decisions, and R1a means this evidence is the whole bridge | Choosing what a custom build included or left out; pushing back on a client request; a feedback theme from your roadmap sessions that product acted on | A requirements document, a decision note, or a roadmap-session summary, sanitized | `[grounded]` resume silence on decisions; `[generic]` that PM interviews probe this |
| G3 | Launches with sales and support; agile cadence (R6, R8; important) | discovery | Client go-lives, but nothing on sales or support, or on sprints or squads | Both are named in the JD, and either could be a quick `direct` | Handoffs to support at go-live; enablement for account teams on a new capability; working in squads, sprints or standups | A go-live checklist or an enablement doc, sanitized | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Nothing was checked, and an unchecked posting is not a suspicious one. Small employers are often simply small | `[generic]` pattern, no claim about this company | Can you point me at the role on your careers site, and who I'd be interviewing with? | unresolved |
| RR2 | A stated must-have you cannot meet as titled years | risk_signal | medium | "3+ years product management experience (must-have)" | The rule may be screened on titled years before anyone reads adjacent experience, or it may be negotiable. The JD does not say | `[generic]` pattern; `[inferred]` that it applies here from the JD's "must-have" label | Would you consider seven years leading API integrations and feeding client input into roadmaps, without a PM title? | unresolved |
| RR3 | Pay, level and location unstated | unknown | — | no pay, level or location appears in the JD as pasted | The level or pay may sit below what seven years at an enterprise vendor earns. No band was gathered, so this cannot be sized | `[inferred]` from the JD's silence against your seven years; the `[generic]` band is unavailable | What are the level and salary range, and is the role remote or office-based? | unresolved |
| RR4 | Responsibilities are concrete and authority is plausible | positive_signal | — | "Own the roadmap for our partner-facing API platform ... drive delivery with two engineering squads" | Roadmap ownership, two named squads and a named domain suggest a real mandate | `[grounded]` JD states each | Which roadmap decisions does this role make alone, and which go to leadership? | noted |
| RR5 | Success measures not defined | unknown | — | "define and track adoption metrics" | The role must build its own metrics, and the targets it will be judged on are unstated | `[grounded]` JD names the duty and gives no targets | What would success look like at six and twelve months? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Get the live careers-page link and the recruiter's email domain before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Put RR2's question to the recruiter early. Say plainly that you have no PM title and your experience is integration leadership with roadmap input | R1a, RR2 | `[grounded]` R1a, RR2 | pending your approval |
| P1 | Lead with the strongest rows, R3, R4 and R5, in your own words. Never describe yourself as a product manager, a roadmap owner or someone who shipped a product. R1b and R2 are bridges and are described as such | R1a, R1b, R2 | `[grounded]` R1a, R1b, R2 | pending your approval |
| W1 | A one-page sanitized excerpt of your integration playbook | R3, R2 | `[grounded]` R2, R3 rows | pending your approval |
| A3 | Seek an introduction through someone who knows the team before applying cold | How hiring often works at companies of this size, not a fact about this one | `[generic]` role-family pattern | pending your approval |

`resume_edits_pending_approval`

| # | Current line | Proposed | Source | Audit note |
|---|---|---|---|---|
| E1 | The line "Led 30+ client integrations of our REST APIs end to end — scoping workshops, requirements documents, integration architecture, UAT, go-live" | Same wording, moved to the top of the experience section | Your resume summary | Wording unchanged, only its order; "30+" stays attached to integrations |
| E2 | "Ran quarterly roadmap-input sessions collecting client feedback for product" | Same wording, moved directly under E1 | Your resume summary | Wording unchanged. I did not write "influenced the roadmap" or "informed product decisions", because neither is in your sentence |

## Evidence status

Verified: none yet. Unverified lead: a request-triage tool that support agents adopted (G1), from agent memory and unconfirmed. It prompts a question only. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Quartzline logistics technology partner API platform careers" was refused. It would have checked the employer, the live posting and the contradictions row (RR1) |
| 2. Role-family sweep | unavailable | The salary and scope search for platform API product manager roles was refused. It would have supplied the market calibration line and sized RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'm offering one extra, outside the above: a short list of the specific proof a PM hiring manager would want to see from someone with your background. It would add a checklist for G1 to G3, and it is built only if you approve.

I can also write all of this to `tuesday-dossier.md` so you can reuse it.

## Upgrade menu

- Your pay floor, location and level limits → gate rows are created and the hard-gates line stops saying "unknown".
- An answer to G1, with an artifact such as a screenshot, spec or adoption number → R2 and R7 can move, and R2 would no longer rest on integrating someone else's product.
- An answer to G2 → R1b and R5 strengthen or stay at their limits.
- A sanitized excerpt of your integration playbook → R3 to `high`.
- The careers-page link, or the recruiter's email domain → RR1 closes, and the cap on `go` lifts.
- The recruiter's answer to RR2 → decides whether this is a real application or only a practice one.
- The salary range → RR3 closes.
- The hiring manager's name → the scope read and which of your stories to lead with.
- Permission to run web search → this fills the market calibration and verifies Quartzline.

**Questions**

G1 — Did you build a request-triage tool that support agents adopted? If so, what did you decide it would and wouldn't do, who used it, and how did you know it worked?

G2 — On a custom build, can you recall a time you decided what went in or stayed out, or pushed back on a client request? What did you own, and what happened?

Constraints — What are your limits for a move: a pay floor, location or remote, and whether you'd take a level below your current one?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.