I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, worth applying to, on conditions. Your six core requirements (R3, R4, R5, R6, R8, R9) are `direct`, and the two hard gates (R1, R2) can't be checked until you tell me your location and pay floor. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Pay $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R8, R9
- `important`: adjacent: R7 (BigQuery); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R7 (`medium`): a Snowflake-to-BigQuery bridge with its limit named; R10, R11: your account is silent on both; R1, R2: waiting on your constraints.

**Opportunity ledger.** The stated pay band sits around the market median (RR1), and the stack and deliverables are concrete (RR6). Team, reporting line, success measures and equity terms are unstated (RR2, RR3, RR4), and I couldn't check that the posting is live (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 is met: you are in the US with work eligibility, or can be in Denver. (2) The band in R2 clears your floor. (3) The posting is confirmed live and unchanged (RR5). (4) BigQuery is stated plainly as not yet used, so R7 stays `adjacent` and is never presented as direct.
- **What would change this:** it becomes `no_go` if R1 fails or the band falls below your floor. It moves toward `go` once R1 and R2 are met and RR5 is confirmed.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; I could not re-read the page |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD as pasted |
| Stated requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD as pasted |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` JD as pasted |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD states none |
| Scope read | Three workstreams (ingestion, modelling, contracts) sit under one title. Whether that is one domain's pipelines, as the report describes for this title, depends on how much of the platform already exists. No direct reports are mentioned | `[inferred]` from the JD's workstreams against the Datawright scope description |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, interquartile range $139,000–$163,500, n=2,310; "Senior" typically 5–8 years; typical scope is one domain's pipelines, no direct reports. The posting's range runs from just under the median to just above the top of the interquartile range. This is the market, not this employer's offer | `[grounded]` Datawright 2026 report as your recruiter supplied it; `[inferred]` that the posting's "salary" means base pay |
| Unknowns | Team size and reporting line; hiring manager (none named); success measures; equity type, size and vesting; whether BigQuery experience is expected on day one | `[grounded]` the JD names none of these |
| Contradictions | None found between the JD and about text as you pasted them | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The posting's terms are clear. You haven't said where you live or whether you can work in the US, so the gate is neither met nor failed. Confidence grades your statement of a constraint, and there isn't one yet | `[grounded]` JD; no candidate statement | Q1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so the band can't be checked against it. The band against the market is in RR1 | `[grounded]` JD; no candidate statement | Q2 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It's unprobed prose, so `medium`. The report's "Senior" range of 5–8 years includes 6 | `[grounded]` your message; `[grounded]` Datawright report as supplied | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. The level of strength can't be inspected from prose. Roles at this level commonly test SQL and Python live | `[grounded]` your message; `[generic]` screening pattern | Offer: a sanitized code sample or model would raise to high |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Specific, with no inspectable artifact yet | `[grounded]` your message | Offer: a sanitized dbt docs or lineage view would raise to high |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and you used it with dbt | `[grounded]` your message | none |
| R7 | BigQuery, the warehouse the role runs on (named in the role description; the requirements ask only for "a cloud warehouse") | important | adjacent | medium | transferability | Snowflake with dbt carries the SQL modelling and warehouse habits. The limit is that you have not used BigQuery, so its cost, partitioning and dbt-adapter specifics are unexercised. Those specifics are what interviewers on a BigQuery stack tend to probe | `[inferred]` requirement from the JD's role description; `[grounded]` your "never used BigQuery"; `[generic]` probe pattern | See G5 |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration. Confirmed and specific, with no inspectable artifact yet | `[grounded]` your message | Offer: a sanitized DAG listing would raise to high |
| R9 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. What it checked, and who consumed the results, is not yet stated | `[grounded]` your message | Offer: a sanitized checkpoint or suite config would raise to high |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | Your account names Airflow for orchestration but not what data your pipelines ingested or from where | `[grounded]` JD responsibility; `[grounded]` your account is silent on sources | See G3, G4 and Q3 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite may be adjacent to agreements with analysts, but you haven't said anything about agreements, schemas or freshness guarantees. I won't assume them | `[grounded]` JD responsibility; `[inferred]` possible adjacency from R9 | See G3, G4 and Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and US work eligibility (R1, hard_gate) | hard_gate | No statement of where you live or your work eligibility | A gate that fails ends the application whatever the fit elsewhere | Where you live; whether you can work in the US; whether Denver is workable for you | Your own answer | `[grounded]` nothing stated |
| G2 | Pay floor against the band (R2, hard_gate) | hard_gate | The band is known, your floor is not | The band straddles the market median, so whether it clears your floor decides the condition | Your minimum base, and whether equity counts toward it | Your own answer | `[grounded]` nothing stated |
| G3 | Ingestion sources (R10, important) | discovery | Airflow is named, the data it moved is not | R10 is the first stated responsibility in the JD and the one your account says least about | Pulling app events or database exports into a warehouse; syncing a CRM or billing system through an API or connector; loading partner files | A sanitized DAG listing, a source inventory, a diagram | `[grounded]` your account is silent; `[inferred]` that this moves R10 toward `direct` |
| G4 | Data contracts (R11, important) | discovery | The Great Expectations suite exists. Agreements with the analysts who used the data are not stated | R11 is the JD's closing responsibility, and your nearest evidence is R9's suite | An agreed schema or freshness guarantee; tests that stopped a bad load before reports; documented model definitions; notice of breaking changes | A suite config, a dbt docs page, a documented SLA (sanitized) | `[grounded]` your account is silent; `[inferred]` adjacency from R9 |
| G5 | BigQuery (R7, important) | transferability | Snowflake and dbt experience, no BigQuery. The adjacent evidence is the dbt-on-Snowflake modelling in R5 and R6. The limit is that BigQuery's cost, partitioning and dbt-adapter specifics are unexercised. A strengthener would be a small dbt project on a BigQuery public dataset, built only if you want to, and described as a practice project | The role runs on BigQuery, so the bridge is the likeliest point of probing | n/a (no question; the bridge case is stated) | A small public repo, only if you choose to build it | `[inferred]` bridge from R5 and R6; `[generic]` that it is the likeliest probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Stated pay against the market (R2) | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range runs from $3,000 under the report's $151,000 median to $2,500 over the top of its $163,500 interquartile range, so this is no seniority-pay mismatch for a Series C company | `[grounded]` JD and Datawright report as supplied; `[inferred]` that the figure is base pay | Where in the range would my experience place me? | noted |
| RR2 | Team, reporting line and hiring manager unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the sole data engineer or one of a team, with or without authority over the contracts it is asked to own | `[inferred]` from the JD's silence | Who does this role report to, and who else works on the data platform? | unresolved |
| RR3 | No first-year outcomes stated | unknown | — | "…and the data contracts our analysts depend on" | The JD lists work but no definition of success | `[grounded]` JD states none | What would a successful first year look like for this role? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | The type, size and vesting of the grant are not given, so total pay can't be assessed | `[grounded]` JD gives no terms | What form and size is the equity, and what is the vesting schedule? | unresolved |
| RR5 | Posting liveness and company details not independently checked | unknown | — | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | I could not re-read either page, so I can't confirm the posting is live or that the facts match. That is a gap in what I could check, not a sign of a problem | `[grounded]` the page read was refused, so the pasted text is the only source | Is this role still open, and when was it posted? | unresolved |
| RR6 | Concrete stack and deliverables | positive_signal | — | "a dbt-modelled warehouse in BigQuery" | The JD names its tools and outputs, which is a clearer posting than most | `[grounded]` JD | Which of these pieces are already built, and which would I build from scratch? | noted |

## Application plan

Proposed resume edits: `resume_edits_pending_approval`.

| # | Current framing (your words; I haven't seen the CV) | Proposed | Why |
|---|---|---|---|
| E1 | "Built our dbt project on Snowflake — about 180 models" | Move to the top of the data-engineering section, wording unchanged | R5; the posting's second named responsibility is dbt modelling |
| E2 | "Set up our Great Expectations test suite" | Place directly after E1, wording unchanged | R9 |

Each line traces to your own sentence. Nothing is added; the edit reorders for this role.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | State BigQuery plainly when it comes up: "I haven't used BigQuery; my dbt work has been on Snowflake" | R7; the limit stays visible | `[grounded]` your own words | pending your approval |
| P2 | Confirm the posting is live and ask the RR2, RR3 and RR4 questions in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P3 | Optional: a small dbt project on a BigQuery public dataset, described as a practice project and never as production | Narrows R7's limit | `[inferred]` from R7 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The fetch of the careers page (pellucidlearning.com/careers/senior-data-engineer) was refused, so nothing was read. It would have moved RR5 and the contradictions row in role reality |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market calibration row and RR1 |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

I can save all of this as a `tuesday-dossier.md` file if you'd like it.

## Upgrade menu

- Your location, work eligibility and pay floor: R1 and R2 close, and the decision resolves to `go` or `no_go`.
- Your current CV text: the E1 and E2 edits become exact, and I can check it against what you told me.
- Sanitized artifacts, such as a dbt docs or lineage view, an Airflow DAG listing, or a Great Expectations suite config: R4, R5, R8 and R9 can rise to `high`.
- A link to the live posting, or the posting date: RR5 closes.
- The hiring manager's name, once you have one: the scope read in role reality sharpens.
- A deeper research pass on Pellucid Learning, covering funding, leadership changes and recent news. It would use up to 5 more searches and 2 more fetches, and would need web permission, which wasn't granted for the last fetch. Say the word if you want it.

## Questions

**Q1 (G1):** Are you based in the US with work eligibility there, or able to work from Denver?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Q2 (G2):** What is your minimum base pay, and does equity count toward it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Q3 (G3 and G4):** In the pipelines you ran at the payroll company, what data did they pull in and from where, and did you ever agree a format or freshness guarantee with the analysts who used it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.