I'll read the reference files the skill points to before building the assessment.
**No. As posted, this isn't worth pursuing. R1 (base pay) and R2 (on-site Austin) are hard gates and both fail. Status: `no_go`.** Your fit isn't what's off. The posting's terms conflict with your two constraints, and the role is also scoped oddly (RR3–RR6).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Compensation: $70–85k base), R2 (On-site in our Austin office 5 days a week)
- `must_have` — direct: R5, R6 · adjacent: R4 (Own revenue growth end to end) · unclear: R3 (8+ years growth leadership)
- `important` — unclear: R7 (SEO/content), R8 (brand, PR, partnerships), R9 (sales ops)

R5, R6 — the core channel work matches on paper; R4 — a credible bridge, its limit named; R1, R2 — these fail on terms, not skill.

**Opportunity ledger.** The role has problems of its own, apart from your constraints. There are seven listed functions for a team of one (RR4), always-on expectations (RR5) and success metrics left open (RR6). The base is also unmeasured against what the mandate suggests (RR3). The conflicts with your constraints are RR1 and RR2, and the employer is not yet established (RR8). One entry runs the other way (RR7).

- **Hard gates:** failed: R1 (Compensation: $70–85k base), R2 (On-site in our Austin office 5 days a week).
- **Severe red flags:** none found.
- **What would change this:** a posted base at or above your $150k floor (R1) and a remote arrangement from Portland (R2). Wording on your side can't change either.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, described as an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header, as claimed by the posting. Not verified (see Evidence status) |
| Mandate | Own all revenue growth end to end across seven listed functions: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Resources | "A team of one to start"; no budget or tooling stated | `[grounded]` JD quote, silence on budget |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site Austin five days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", unquantified | `[grounded]` JD |
| First 90 days / first year | None stated; "success metrics will evolve as we learn" | `[grounded]` JD |
| Scope read | A head-level title, 8+ years required and board access, set against a team of one, a base of $70–85k and open metrics | `[inferred]` from the title and years against the stated team, pay and metrics |
| Market calibration | Not available. The role-family search was not permitted this session, so there is no band to set the $70–85k against | — |
| Contradictions | No careers-page comparison was possible. Within the posting itself, none beyond the title-versus-resources tension in the scope read | `[inferred]` from the posting text alone |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Compensation: $70–85k base plus equity (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own specific floor. The fit fails because the posting's top base is $65k under it, and the equity is unquantified while your floor is on base | `[grounded]` JD quote and your intake message | Surface only. The employer raising the base or you revising the floor are the only resolutions |
| R2 | On-site in Austin, 5 days a week, "no exceptions" (your constraint: remote-only, Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated limit. The posting rules out remote work in plain words | `[grounded]` JD quote and your intake message | Surface only. Only a change of terms resolves it |
| R3 | 8+ years growth leadership | must_have | unclear | medium | discovery | You state 9 years in growth, with Growth lead then Head of Growth titles at two companies. How many of those years were leadership isn't stated. Confirmed and specific, nothing inspected | `[grounded]` your intake message | Confirm the month and year you first held a lead title |
| R4 | Own revenue growth end to end | must_have | adjacent | medium | transferability | Bridge: you scaled one company from $8M to $40M ARR over three years with a budget you controlled. Limit: what you owned was paid, lifecycle and experimentation at B2C subscription companies, not all seven of this posting's functions | `[grounded]` your intake message | A channel or growth P&L for that period would raise it |
| R5 | Paid acquisition | must_have | direct | medium | none | You state you owned paid; confirmed and specific, no artifact inspected, so expect a probe | `[grounded]` your intake message | A spend and efficiency report would raise it to `high` |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and name Braze, SQL and GA4; confirmed, no artifact inspected | `[grounded]` your intake message | A sanitized Braze canvas map or lifecycle dashboard would raise it |
| R7 | SEO/content | important | unclear | none | discovery | No claim exists yet and nothing contradicts one. Silence is not absence | `[grounded]` silence in your intake message | See G3 |
| R8 | Brand, PR, partnerships | important | unclear | none | discovery | Same as R7 | `[grounded]` silence in your intake message | See G3 |
| R9 | Sales ops | important | unclear | none | discovery | No claim exists yet. This may be a B2B function, while your stated history is B2C subscription | `[grounded]` silence in your intake message; `[inferred]` B2B reading from "enablement" and "sales ops" | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Base pay (R1, hard_gate) | hard_gate | $70–85k posted against your $150k floor | A failed gate caps the status at `no_go` | Not applicable. This is a term, not experience | Only a revised posted base closes it | `[grounded]` JD and your message |
| G2 | On-site Austin (R2, hard_gate) | hard_gate | Five days on-site, "no exceptions", against remote-only from Portland | Same | Not applicable | Only a change of terms closes it | `[grounded]` JD and your message |
| G3 | SEO/content, brand/PR/partnerships, sales ops (R7, R8, R9, important) | discovery | Your described work covers paid, lifecycle and experimentation; the other functions are unaddressed | Matters only if you pursue this role. Each is one of seven listed functions | Owning a content or SEO program; running a partnership or affiliate channel; working a sales-ops handoff (CRM routing, lead scoring) | An SEO traffic report, a partnership agreement or revenue summary, a CRM-routing doc | `[grounded]` silence in your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base conflicts with your floor (R1) | red_flag | medium | "$70–85k base plus meaningful equity upside" | The stated range tops out $65k under your floor. Medium, not high, because the conflict is yours and R1 carries it | `[grounded]` JD figure against your stated floor | Is the base for this role negotiable, and what is the highest base the budget for this post allows? | confirmed |
| RR2 | Location conflicts with your constraint (R2) | red_flag | medium | "On-site in our Austin office 5 days a week — no exceptions" | The posting rules out remote work outright. Medium for the same reason as RR1 | `[grounded]` JD against your stated constraint | Is on-site five days fixed for this role, or would the company consider remote for a senior hire? | confirmed |
| RR3 | Seniority–compensation mismatch | risk_signal | medium | "8+ years growth leadership required" with "$70–85k base" | The base may sit below what a head-level role with this mandate pays. This run couldn't measure the band, so it is a question, not a finding | `[inferred]` from the years, title and function list against the stated figure | How was the base set for this role, and what is the equity (percentage, strike price, vesting)? | unresolved |
| RR4 | Bundled specializations; responsibility without resources | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench." | Seven functions for one person may be several roles in one title. No budget or tooling is stated | `[inferred]` from the function list against the stated team and silence on budget | What budget, tools and headcount are committed for the first twelve months, and when is the first hire? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine, not occasional | `[inferred]` from the phrasing, which doesn't say how often | In a typical month, how many evenings or weekends does the team currently work? | unresolved |
| RR6 | Absent success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You may be accountable for all revenue growth with no agreed definition of success | `[inferred]` from the open metrics beside the full-revenue mandate | What revenue number would make year one a success, and who agrees on it? | unresolved |
| RR7 | Seniority of access | positive_signal | — | "Report to the CEO with a dotted line to the board." | Access to leadership is real on paper. Authority over budget is still unstated (RR4) | `[grounded]` JD | Which board members would you work with, and how often? | noted |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Not checked this run because searches were refused | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted | R1 and R2 fail; wording can't fix either | `[grounded]` the two failed rows | pending your approval |
| A2 | Optional: if you want to test whether terms flex, send one note to the employer asking RR1's and RR2's questions before spending any effort. The posting's "no exceptions" makes a yes unlikely | See RR1, RR2 | `[grounded]` JD wording | pending your approval |
| A3 | If you proceed anyway, ask RR3–RR6 and RR8 verbatim in the first conversation, and get the base in writing before any further interviews | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | No CV edits proposed. Nothing here needs repositioning | R4–R6 are already direct or adjacent in your own terms | `[grounded]` map | pending your approval |

## Evidence status

Verified: the candidate-side statements in R1 and R2, which are your pay floor and remote-only status in your own words. Your experience claims (R3, R4, R5, R6) are self-reported, with nothing inspected yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Head of Growth"; the call was refused (permission not granted). It would have fed role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary startup Series A base salary range 2026"; the call was refused. It would have fed the market calibration row and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given; the posting says only "the CEO", so there was no query to form |

## Dossier and upgrade menu

I can save all of this as `tuesday-dossier.md` if you'd like to keep it. Say the word.

- Permission for web search → RR8 resolves one way or the other, the market calibration row gets filled, and RR3 is checked against a band.
- A link to the live posting or Novaline's own careers page → RR8.
- The CEO's or hiring manager's name → role reality's scope read.
- The employer's answers on budget, headcount, metrics, hours and equity → RR3–RR6 close.
- A channel or growth P&L for the $8M→$40M period → R4 and R5 move toward `high`. A sanitized Braze canvas map or lifecycle dashboard does the same for R6.
- Any SEO, partnership, brand or sales-ops work you've done → R7–R9 gain real rows.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.