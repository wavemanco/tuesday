I'll read the skill's reference files before building the assessment.
**No, not as posted. R1 and R2, both hard gates, fail · `no_go`.**

Your instinct is right, and the reasons are in the posting's own terms, not in your qualifications. I assumed you're at the evaluating stage.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (Base pay of at least $150k), R2 (Remote-only work, no relocation)
- `must_have` — direct: R3, R4, R5 · unclear: R6 (SEO and content)
- `important` — unclear: R7 (Brand and PR), R8 (Partnerships), R9 (Sales ops), R10 (Solo operation, no team)

R1 — the posted base sits $65k below your floor; R2 — five days on-site against remote-only; R6 — the one must-have with no evidence yet.

**Opportunity ledger.** The posted terms conflict with both of your constraints (RR1, RR2). The scope and hours read as an under-resourced bundle (RR3, RR4), success measures are undefined (RR5), and equity is unquantified (RR6). The employer is unverified because my searches were refused (RR7). One entry runs the other way: the pay range is posted (RR8).

- **Hard gates:** failed: R1 (Base pay of at least $150k), R2 (Remote-only work, no relocation)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** the employer would have to confirm in writing both a base of at least $150k and a Portland-remote arrangement. The posting says "no exceptions" on location.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD, self-description only; not verified (RR7) |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | Team of one to start; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Hours and location | "Evenings and weekends when it matters"; on-site in Austin 5 days a week, "no exceptions" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside"; the equity terms are unstated | `[grounded]` JD |
| Scope read | Seven functions, no staff and success metrics that "will evolve" is a bundle of several roles under one title | `[inferred]` from the function list set against the team-of-one line and the missing metrics |
| Market calibration | Not run: the role-family sweep was refused, so I give no market band and none is implied. The only comparison is arithmetic: your $150k floor is $65k above the top of the posted range | `[grounded]` JD figure and your stated floor |
| Unknowns | Equity percentage and terms; budget; planned hires; decision rights; who the customer is (merchants or shoppers) | — |
| Contradictions | None within the posting; I couldn't check it against a careers page | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay of at least $150k (your constraint) | hard_gate | hard_gate_fail | high | hard_gate | The posted range tops out at $85k. Confidence grades your own stated floor, not the role | `[grounded]` JD and your stated constraint | Only a written employer change would alter this (Q1) |
| R2 | Remote-only work, no relocation from Portland (your constraint) | hard_gate | hard_gate_fail | high | hard_gate | The posting requires Austin on-site 5 days a week. Wording cannot fix this | `[grounded]` JD and your stated constraint | Only a written employer change would alter this (Q1) |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | You state 9 years: growth lead, then Head of Growth, at two B2C subscription companies. Nothing inspectable yet. A years requirement is not a gate | `[grounded]` your summary | A CV or LinkedIn profile would raise it to `high` |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid and controlled a budget while scaling one company from $8M to $40M ARR over three years. No spend figure or channel mix was given | `[grounded]` your summary | A channel report or spend summary would raise it to `high` |
| R5 | Lifecycle and CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze, GA4 and SQL | `[grounded]` your summary | A sanitized lifecycle program example would raise it to `high` |
| R6 | SEO and content | must_have | unclear | low | discovery | Your summary doesn't mention SEO or content, so it's unknown rather than absent | `[grounded]` silence in your summary | See G1 |
| R7 | Brand and PR | important | unclear | low | discovery | Not mentioned in your summary | `[grounded]` silence in your summary | See G2 |
| R8 | Partnerships | important | unclear | low | discovery | Not mentioned in your summary | `[grounded]` silence in your summary | See G3 |
| R9 | Sales ops | important | unclear | low | discovery | Not mentioned. SQL skill is not evidence of sales operations work | `[grounded]` silence in your summary | See G4 |
| R10 | Solo operation, no team | important | unclear | low | discovery | You built and managed teams of 3–7; working with no staff isn't stated | `[grounded]` your summary | See G5 |

## Gap recovery queue

All five gaps are `discovery`, and none could move the decision, because R1 and R2 decide it. I'd recover them only if you pursue a different role.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content (R6, must_have) | discovery | Nothing stated | Roles that bundle functions usually test every one named | Content programs you owned or directed, SEO work inside a lifecycle or acquisition role | A content calendar, organic traffic report | `[generic]` pattern for bundled growth roles |
| G2 | Brand and PR (R7, important) | discovery | Nothing stated | Part of the stated mandate | Launch announcements, press handling, brand campaigns you ran | A campaign recap, press coverage | `[generic]` pattern |
| G3 | Partnerships (R8, important) | discovery | Nothing stated | Part of the stated mandate | Affiliate, co-marketing or integration deals | A partner program summary | `[generic]` pattern |
| G4 | Sales ops (R9, important) | discovery | Nothing stated | Part of the stated mandate | Pipeline reporting or CRM ownership for a sales team | A reporting dashboard or process doc | `[generic]` pattern |
| G5 | Solo operation (R10, important) | discovery | You managed teams of 3–7 | The posting says "a team of one to start" | A period or project you ran with no staff | A project recap | `[inferred]` from your team history against the posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay below your floor | red_flag | high | "$70–85k base" | The pay is incompatible with your $150k non-negotiable whatever the market says | `[grounded]` JD against your stated constraint | Is the base negotiable above $85k, and what is the ceiling? | confirmed |
| RR2 | On-site 5 days against remote-only | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | Incompatible with your non-negotiable | `[grounded]` JD against your stated constraint | Is any remote arrangement possible for this role? | confirmed |
| RR3 | Seven functions, no staff, 8+ years required, and pay that may not match that scope | risk_signal | medium | "team of one to start — we believe in players who don't need a bench" | The role may be several jobs folded into one title and priced as one. I can't calibrate the pay without the refused sweep, so I take the lower severity | `[inferred]` from the function list against the staffing and pay lines | What budget and hires are committed for the first 12 months? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine, not occasional | `[inferred]` from the phrase "just who we are" | In the last quarter, how many evenings or weekends did the team work? | unresolved |
| RR5 | Success metrics undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be held accountable for revenue with no agreed target | `[inferred]` from the posting's own wording | What would count as success at 90 days and at 12 months? | unresolved |
| RR6 | Equity unquantified | unknown | — | "meaningful equity upside" | The equity may or may not offset the cash gap; the percentage, strike and vesting are all missing | `[grounded]` JD silence | What percentage, strike price and vesting schedule apply? | unresolved |
| RR7 | Employer unverified | unknown | — | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | I couldn't check that the company exists as described or that the posting is live | `[grounded]` my searches were refused; this says nothing about Novaline itself | Can you point me at this role on your own careers page? | unresolved |
| RR8 | Pay range posted | positive_signal | — | "$70–85k base" | The employer discloses compensation up front, which saves time | `[grounded]` JD | Is the range final for this level? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pass on this posting as written | R1 and R2 fail, and a better-fitting wording cannot fix a term | `[grounded]` R1, R2 | pending your approval |
| A2 | Optional: ask the employer once whether the base and the on-site term are fixed, and stop if both are. I haven't drafted any message | The one question a gate allows is whether it's met, not how to work around it | `[grounded]` R1, R2 | pending your approval |
| A3 | If you pursue it anyway, ask the RR3, RR4, RR5 and RR6 questions before spending interview time | They are the questions a candidate most needs answered here | `[grounded]` register | pending your approval |

I've proposed no resume edits, because there is nothing to position toward a role that fails on terms.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for Novaline's existence and careers listing was refused. It would have fed RR7 and role reality's organization row |
| 2. Role-family sweep | unavailable | The search for a market pay band for this title was refused. It would have fed role reality's market calibration and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'll write up this assessment as `tuesday-dossier.md` if you'd like a saved copy.

## Upgrade menu

- Permission to run web searches → RR7 resolves (does Novaline exist and is the role live), and the market pay band for this title replaces the missing calibration in role reality and RR3.
- A CV or LinkedIn profile → R3, R4 and R5 can reach `high`, and any SEO, content, brand, partnership or sales ops work you did that your summary left out would surface for R6–R9.
- Equity terms, committed budget and planned hires → RR6 and RR3 close.
- The hiring manager's or CEO's name → role reality's scope read.

**Q1 (R1, R2):** Do you want to test with Novaline whether the base or the on-site term can move, or treat the posting as closed?

**Q2 (RR7):** May I retry the Novaline and market-pay searches if you grant web search?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.