Checking that the pasted posting and About page are still live on Pellucid's own site, then I'll write the assessment.
**Decision snapshot**

**Yes, this is worth applying to: R3, R4, R5, R6, R8 and R9, the six `must_have` rows, all land `direct`. R1 and R2, the two hard gates, are waiting on your answers. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R8, R9
- `important` — adjacent: R7 (BigQuery named in the role description); unclear: R10 (ingestion from app and CRM), R11 (data contracts for analysts)

R7 — a credible bridge, its limit named; R10, R11 — the CV-level evidence is silent, discovery questions below; R1, R2 — unconfirmed until you state them.

**Opportunity ledger.** The posting states its pay, and its scope is partly unknown (RR1, RR2, RR4). The stated range and the live posting are checked against sources you gave me (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work remote from the US or from Denver (R1); (2) $148,000–$166,000 clears your floor (R2); (3) BigQuery is framed as adjacent to your Snowflake work, never as experience (R7); (4) scope and reporting line check out in the first conversation (RR1, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` About page, fetched |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD, live posting fetched |
| Terms | $148,000–$166,000 plus equity; remote (US) or Denver office | `[grounded]` JD |
| Contradictions | None. The live posting and About page match what you pasted word for word | `[grounded]` both pages fetched |
| Scope read | The JD names three work areas and no team, no reports and no outcomes. That could be one domain's pipelines or the whole reporting stack | `[inferred]` from three named areas against the JD's silence on team and outcomes |
| Market calibration | The report puts Series B–D senior data engineers at a $151,000 median, interquartile range $139,000–$163,500, 5–8 years, owning one domain's pipelines with no direct reports. The posting's low end is $3,000 under that median and its high end is $2,500 over the 75th percentile. Your 6 years sits inside the typical range | `[grounded]` Datawright 2026 report as you supplied it (not independently inspected); `[grounded]` JD figures; `[generic]` for the typical scope, which is a pattern and not a claim about Pellucid |
| Unknowns | Hiring manager, team size and reporting line, equity terms, first-year outcomes, ingestion tooling | `[grounded]` JD silent on each |

## Evidence map

Your background was typed in, so it counts as self-report. Nothing here is above `medium` until you show an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or what you'll accept. Confidence is `none` because there's no statement to grade | `[grounded]` JD term; no candidate statement | Ask G1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't stated a floor, so I can't say whether the range clears it | `[grounded]` JD term; no candidate statement | Ask G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You report 6 years. This is a length requirement, so it's graded on fit and not as a gate. Specific, but no inspectable artifact yet | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily at a payroll company. "Strong" is a judgement an interviewer will test | `[grounded]` your background | Offer: a sanitized query or module sample would raise it |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. That's specific, with no artifact yet | `[grounded]` your background | Offer: dbt docs or lineage screenshot, sanitized |
| R6 | A cloud warehouse | must_have | direct | medium | none | The requirement says "a cloud warehouse," and Snowflake is one. BigQuery appears only in the role description, which is why R7 is its own row | `[grounded]` JD wording and your background | none |
| R7 | BigQuery (named in the role description, not the requirements list) | important | adjacent | medium | transferability | Carries over: warehouse modelling in dbt on Snowflake. Limit: you've never used BigQuery, so its cost model, partitioning and clustering weren't exercised. That limit is what to name wherever the bridge is used | `[inferred]` bridge from Snowflake dbt work; `[grounded]` that you have never used BigQuery | See G4 |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration, which matches directly | `[grounded]` your background | Offer: a sanitized DAG screenshot |
| R9 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, which is ownership of the setup | `[grounded]` your background | Offer: sanitized data docs would raise it |
| R10 | Ingestion from the app and a CRM | important | unclear | low | discovery | Your background doesn't say which sources you ingested or whether they were product and CRM data | `[grounded]` your background silent on sources | Ask G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations suite is adjacent, but nothing says you agreed schemas or SLAs with consumers | `[inferred]` adjacency from the test suite; `[grounded]` background silent on contracts | Ask G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2, hard_gate) | hard_gate | Neither gate is settled by what you've said | A failed gate would make this `no_go`; confirmed gates make it `go` pending the opportunity conditions | Your state or city, a willingness to be in Denver, and a salary floor | Your own statement | `[grounded]` nothing stated |
| G2 | Ingestion from app and CRM sources (R10, important) | discovery | The background doesn't name your source systems | An important row, and the JD names it first in the mandate | Loading product-event or SaaS data (CRM, billing, support) through Fivetran-style tools or custom Python; owning a source's schema changes | A pipeline diagram or README, sanitized | `[grounded]` background silent; `[inferred]` that it matters because the JD lists it first |
| G3 | Data contracts (R11, important) | discovery | A test suite exists, but no consumer-facing agreement is stated | The role names contracts as a deliverable | Agreeing column definitions, freshness or schema rules with analysts; schema-change notices; tests that gate a release | A contract doc, a dbt `contracts` or `tests` config, or a Great Expectations suite sample | `[grounded]` background silent; `[inferred]` adjacency from the test suite |
| G4 | BigQuery (R7, important) | transferability | Strong Snowflake and dbt evidence, no BigQuery | Likely the first thing an interviewer probes | Any BigQuery use at all, including side projects or a free-tier sandbox | A small dbt-on-BigQuery repo, if you choose to build one | `[inferred]` bridge; `[generic]` that a named stack gets probed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope without stated team or authority | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may own the whole reporting stack alone, or sit inside a team | `[inferred]` from three named areas against silence on team and reports | How many data engineers are on the team, who does this role report to, and who owns the CRM and app source schemas? | unresolved |
| RR2 | No hiring manager or outcomes named | unknown | — | "The posting names no hiring manager" (your note) | First-year success may be undefined | `[grounded]` posting silent | What would success look like at 6 and 12 months? | unresolved |
| RR3 | Pay stated and consistent with the market report | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The employer is open about pay, and the range tops the report's interquartile range | `[grounded]` JD against the Datawright figures you supplied | Which part of the range is for someone with my background? | noted |
| RR4 | Equity unspecified | unknown | — | "plus equity" | Grant size, vesting and strike may be unstated at this stage | `[grounded]` JD gives no terms | What are the equity grant, vesting schedule and strike price for this level? | unresolved |

## Application plan

Everything below is proposed and pending your approval, prose included. Nothing becomes CV or outreach language until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV bullet: "Built and own a dbt project of about 180 models on Snowflake, orchestrated in Airflow" | See R5, R6, R8. It uses only claims you gave me | `[grounded]` your background | pending your approval |
| E2 | CV bullet: "Set up the Great Expectations test suite for the pipelines" | See R9. Add a scope or outcome if you can supply one | `[grounded]` your background | pending your approval |
| E3 | Frame BigQuery as "new to me, with the same dbt modelling practice," never as experience | See R7. The limit stays stated | `[grounded]` you have not used BigQuery | pending your approval |
| W1 | Optional: a small public dbt-on-BigQuery repo as a work sample | See R7, G4. It would be real BigQuery evidence only if you build it | `[inferred]` from the gap | pending your approval |
| Q1 | Ask RR1, RR2 and RR4 verbatim in the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and "About Pellucid Learning" (pellucidlearning.com/about) to check your pasted copies. Both match and the posting reads "Accepting applications". This moved role reality's organization and contradictions rows, and no failed-attribution entry is needed |
| 2. Role-family sweep | skipped | The Datawright report you supplied is in hand and fixes the market calibration row and RR3's comparison |
| 3. Hiring manager's public footprint | n/a | The posting names no manager, so there was no query to form |

I'll write `tuesday-dossier.md` if you'd like this saved for later turns.

## Upgrade menu

- Your location and salary floor → R1 and R2 close, and the decision likely resolves to `go` or `no_go`.
- A sanitized dbt docs page, DAG screenshot or Great Expectations data docs → R4, R5, R8 and R9 can reach `high`.
- A contract doc or ingestion diagram → R10 and R11 firm up.
- The hiring manager's name, once you have one → role reality's scope read and which story the plan leads with.
- A deeper research pass on Pellucid (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Which US state or city are you in, would you take the Denver office or only remote, and what's your salary floor?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Which source systems did you ingest into your warehouse (product events, CRM, billing), and what part of those pipelines did you own?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — Have you agreed schemas, freshness or definitions with the analysts or teams who consume your data, and where is that written down?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.