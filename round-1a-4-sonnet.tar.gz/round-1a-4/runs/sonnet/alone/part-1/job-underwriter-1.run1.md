I'll read the reference files the skill points to before building the assessment.
**Yes, apply. You're a fit on the core of the role, and the decision is `conditional_go`.** R1, R2, R3, R4 and R6 are `direct`. The conditions are in the snapshot below.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (Define and maintain the metrics layer)
- `important` — direct: R7a · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R5 — a likely bridge through your governed Looker work, with ownership of metric definitions unconfirmed; R7b and R8 — no evidence yet, both recoverable by recall; R9 (`medium`) — a real adjacency, with a limit named in G4.

**Opportunity ledger.** Sound but unverified. The employer could not be checked from here (RR1) and the pay is withheld (RR2). Location and work model are unstated (RR3). The scope may bundle several specialisms (RR4). One entry runs the other way: the mentoring line suggests an existing analyst team (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting are confirmed on Harborlight's own careers page (RR1); (2) ownership of the metrics layer and the mentoring scope are confirmed in the first conversations (R5, R8, RR4); (3) pay and location are checked against your own limits (RR2, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, care-navigation app | `[grounded]` JD header as pasted; not checked against the company's own site |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, PM and clinician partnership, mentoring two junior analysts | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Scope read | A senior individual-contributor role with light lead duties: five responsibilities, one product, two juniors | `[inferred]` from the responsibility list and the mentoring line |
| Market calibration | Not run: both L1 searches were refused, so there is no role-family band for title, scope or pay | `[grounded]` search calls refused |
| Unknowns | Salary; location or remote policy; who owns metric definitions today; how clinicians work with the analytics team | — |
| Contradictions | None within the pasted material; the JD has not been compared with a careers page | `[grounded]` provided inputs only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company with about 2M subscribers. Self-reported, so `medium` at intake. | `[grounded]` your background summary | A CV with dated roles would corroborate |
| R2 | Expert SQL | must_have | direct | medium | none | You use SQL daily on a Snowflake warehouse and built a consent-state model in it. "Expert" is your word, with no artifact behind it. | `[grounded]` your background summary | Be ready for a live SQL exercise |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. A subscriber base of about 2M supports "scale". Healthcare experiments may run on smaller samples or under clinical constraints, which is untested. | `[grounded]` your summary; `[generic]` that healthcare experiments often differ in sample size and constraints | A sanitized test write-up (hypothesis, power, result) would raise this to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the Looker instance from scratch with 40+ governed dashboards. | `[grounded]` your background summary | Screenshots or a sanitized dashboard would raise this to `high` |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | Governed dashboards imply some definition work, but you have not said you owned shared metric definitions (LookML, dbt or warehouse models). This is the first-listed responsibility, so it matters. | `[inferred]` from "governed dashboards" and the consent-state model; ownership not stated | See G1 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product. | `[grounded]` your background summary | A sanitized memo would raise this to `high` |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | Monthly presentation to the VP Product, and the pricing test is a decision-driving analysis. Which roadmap decisions your work changed is not stated. | `[grounded]` your background summary | Name one decision your analysis changed, in an interview |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your summary touches clinical or other domain-expert partnership. | `[grounded]` background silence | See G2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | The summary is silent on mentoring or managing anyone. | `[grounded]` background silence | See G3 |
| R9 | Healthcare data experience (HIPAA), a plus | preferred | adjacent | medium | transferability | You handled GDPR and CCPA consumer PII and built the warehouse consent-state model. That is adjacent regulated-data work, not healthcare. | `[grounded]` your summary; `[generic]` that HIPAA, as US health-data law, is a distinct regime | See G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R5, must_have) | discovery | Governed Looker dashboards, but no statement that you owned shared metric definitions | It is a must-have, and the JD lists it first | Writing LookML explores or views; owning a canonical definition of retention or churn that several teams used; a metrics dictionary; a dbt or warehouse metrics model | A metrics dictionary excerpt, a LookML sample, a definitions doc (sanitized) | `[grounded]` the summary's silence; `[inferred]` that it is the likeliest probe |
| G2 | Partnering with domain experts (R7b, important) | discovery | No evidence either way | The JD names clinicians as partners | Working with nutritionists, culinary, ops, medical or compliance staff to shape an analysis or a test | A project brief or test plan with the partner named | `[grounded]` the summary's silence |
| G3 | Mentoring (R8, important) | discovery | No evidence either way | The JD says you would mentor two junior analysts | Onboarding analysts; reviewing queries or dashboards; running an analytics guild; coaching a junior through a first experiment | A mentoring plan, onboarding doc or review checklist | `[grounded]` the summary's silence |
| G4 | Healthcare data and HIPAA (R9, preferred) | transferability | GDPR and CCPA PII handling and a consent-state model. The adjacent evidence carries over: the discipline of governing sensitive personal data in a warehouse. The limit: you have not worked with protected health information, HIPAA minimum-necessary access, de-identification or business-associate agreements. The strengthener: a short, honest note of how the consent model maps to those controls, ideally with HIPAA basics learned first. | A preferred item, so a minor risk rather than a blocker; the bridge should be framed as adjacent | The consent-state design doc; access controls or PII tagging you built | A sanitized design doc or data-governance write-up | `[grounded]` your summary; `[generic]` the HIPAA scope |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small for a footprint, the posting may be stale or aggregated, or the role may not represent a real hiring employer; the research calls were refused, so none of these is ranked as likely. | `[generic]` pattern for any unverified posting, not a claim about this company | Can you point me to this role on your careers site, and who would I interview with? | unresolved |
| RR2 | Salary withheld | unknown | — | Compensation is not stated in the JD | Pay may sit below or above the usual range for a senior analyst role; the posting may simply not publish it. | `[inferred]` from the JD's silence; no band was retrieved | What salary range is budgeted for this role? | unresolved |
| RR3 | Location and work model unstated | unknown | — | Location is not stated in the JD | Remote, hybrid or on-site terms could matter once your constraints are known. | `[inferred]` from the JD's silence | Is this role remote, hybrid or office-based, and in which locations? | unresolved |
| RR4 | Bundled responsibilities | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker, partner with product managers and clinicians ... and mentor two junior analysts" | Metrics engineering, experimentation, BI, stakeholder partnership and mentoring may all sit with one person; severity is `low` because one product, a defined team and a senior title make a sensible remit plausible. | `[inferred]` from the length of the responsibility list | Who owns the metrics layer's engineering today, and what data-engineering support does this role get? | unresolved |
| RR5 | Mentoring line implies an existing analyst team | positive_signal | — | "mentor two junior analysts" | The role likely sits inside a team rather than being a lone first analyst hire. | `[inferred]` from the mentoring line | What does the analytics team look like, and who does this role report to? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live and the company is as described, using Harborlight's own careers page, before investing in the application | RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the resume summary with the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift, in your own words and no stronger | R3 | `[grounded]` your background summary | pending your approval |
| E2 | Surface the Looker build as 40+ governed dashboards built from scratch; add a metrics-definition line only if G1 confirms it | R4, R5 | `[grounded]` your summary; R5 limit named | pending your approval |
| E3 | Present the consent-state model and GDPR/CCPA work as adjacent data-governance experience, with no claim of HIPAA, PHI or healthcare work | R9 | `[grounded]` your summary | pending your approval |
| W1 | Prepare a one-page sanitized experiment write-up (hypothesis, design, result) as a work sample | R3 | `[grounded]` R3 row | pending your approval |
| Q1 | Ask RR2, RR3 and RR4's verification questions verbatim early in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none from prior context.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Harborlight Health care navigation app Series C careers Senior Product Analyst" was refused. It would have confirmed the company and the live posting, feeding role reality's organization and contradictions rows and RR1. |
| 2. Role-family sweep | unavailable | The search "senior product analyst digital health salary range 5+ years experimentation Looker" was refused. It would have fed the market calibration line, RR2's pay comparison and the scope read. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Dossier offer

I can save all of this as a portable `tuesday-dossier.md` if you'd like a record to build on.

## Upgrade menu

- Search permission, or a link to Harborlight's careers page → RR1 resolves and the market calibration fills in.
- A metrics dictionary, LookML sample or definitions doc (sanitized) → R5 moves toward `direct`.
- A sanitized experiment write-up, memo or dashboard screenshot → R3, R4 and R6 can reach `high`.
- Any mentoring or domain-expert example → R8 and R7b close.
- Your non-negotiables → the hard-gates line stops reading "checks unknown".
- The hiring manager's name → the scope read and the lead story in the application plan sharpen.

## Questions

1. **G1:** Did you own the definitions of core metrics (retention, churn, activation) in a shared layer such as LookML, dbt or warehouse models? Who else relied on them?
2. **G3:** Have you mentored or guided other analysts, formally or informally? If so, how many, over what period, and what did you own?
3. **Constraints:** Do you have non-negotiables for a role like this (location or remote, pay floor, work authorization, schedule)? The posting states none of them.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.