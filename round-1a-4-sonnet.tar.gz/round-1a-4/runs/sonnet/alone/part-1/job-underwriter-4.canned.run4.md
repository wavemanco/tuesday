I'll read the skill's reference files before building the assessment.
**Yes, apply, with one thing to settle first: the posting and the careers page disagree about where the job is (R1, RR1). Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5a, R6, R7a, R8 · unclear: R5b (monitor rating models), R7b (recommendations for product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance domain)

R1 — the two sources disagree on location; R5b and R7b — your background doesn't say either way, and one answer each settles them; R10 (`low`) — a bridge from motor rating work, its limit named.

**Opportunity ledger.** The role is real and live, and its reporting line matches the posting (RR3). Its working pattern is contradicted between two sources (RR1), and the pay is withheld (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The work location is resolved, and works for you: R1, RR1.
  2. You confirm whether your experience includes monitoring models, not just building and maintaining them, before you lead with it: R5b.
  3. The pet-insurance gap is stated plainly, with your motor pricing as the bridge: R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a live careers listing for this role, accepting applications. The listing says the role owns pricing analytics for the pet-insurance product and reports to the Director of Pricing | `[grounded]` careers page fetched |
| Mandate | Build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week". These contradict each other, and I haven't resolved it either way | `[grounded]` JD and careers page |
| People management | The JD lists no people-management requirement, and doesn't say whether the post has direct reports. Never having managed anyone is not a mismatch against the stated requirements | `[grounded]` JD silent on both |
| Pet-insurance experience | The JD asks for "insurance experience a plus", not pet insurance specifically | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing. Her public profile lists a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books, and six years as head of pricing analytics at Calloway Re | `[grounded]` search result snippet only; the profile page was not fetched |
| Compensation | Not stated in the posting | `[grounded]` JD silent |
| Market calibration | One survey of UK insurers and insurtechs puts senior pricing analyst base pay at a median of £58,400, with an interquartile range of £52,100 to £64,900 (n=612). That is the band to expect, never this employer's offer | `[generic]` Pricewell 2026 survey, from a search snippet |
| Unknowns | Where the job is based; salary; whether the role has reports; how much of the product-side recommendation work you would own | — |

## Evidence map

Your background was given in prose, so every claim here is self-report. That caps confidence at `medium` until you share an inspectable artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | "Fully remote (UK)" | hard_gate | unclear | none | hard_gate | You stated no location constraint, so there is no statement of yours to grade. Fit is `unclear` because the JD says remote and the careers page says Leeds four days a week | `[grounded]` JD and careers page; no constraint given | Q1 in the closing questions; the employer's answer is RR1's question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years of pricing analytics at a UK motor insurer, the last two as senior analyst. Specific, but self-reported | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is specific but gives no scale or artifact | `[grounded]` your background | A code sample or description of a pipeline would raise it |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for your young-driver book. Confirmed and specific, but nothing inspectable yet: expect a probe on how it was built and validated | `[grounded]` your background | A sanitized model summary would raise it to `high` |
| R5a | Build rating models | must_have | direct | medium | none | Same evidence as R4, covering "built" | `[grounded]` your background | as R4 |
| R5b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" doesn't state whether you ran ongoing monitoring (drift, loss-ratio tracking, challenger tests). Ambiguity resolves downward, so this is not asserted. The hiring manager's published talk is on monitoring, which makes this row worth settling | `[grounded]` your background is silent on monitoring; `[inferred]` that "maintained" may include it | G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. The 14 counts tests, not portfolios or segments | `[grounded]` your background | A sanitized test write-up would raise it |
| R7a | Recommendations for underwriting | must_have | direct | medium | none | You ran the tests with the underwriting team and present the quarterly pricing review to the head of underwriting. That shows the audience, not which recommendations were yours | `[grounded]` your background | none |
| R7b | Recommendations for product | must_have | unclear | low | discovery | Nothing in your background mentions a product-team audience | `[grounded]` your background is silent | G2 |
| R8 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | A review deck, sanitized, would raise it |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain knowledge | preferred | adjacent | low | transferability | The posting asks only for insurance experience, but the product is pet insurance. Carry-over is the rating method (GLMs, price testing) from a different line. Limit: none of your work touched pet-specific rating factors or the pet claims environment. Rating factors and claims patterns usually differ materially between lines | `[inferred]` adjacency from your motor GLM work; `[generic]` that lines differ | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | You maintained the model, but monitoring isn't stated | A `must_have` row at `unclear`. The role says "monitor", and the hiring manager has spoken publicly on the topic | Tracking actual vs expected performance after a rate change; drift or segment-level checks; a model refresh triggered by monitoring results; challenger or back-test work | A monitoring dashboard screenshot (sanitized), a model performance report, a refresh note | `[grounded]` background silent on monitoring; `[inferred]` that settling it matters to the interview |
| G2 | Recommendations for product (R7b, must_have) | discovery | Your audience is underwriting; product isn't mentioned | A `must_have` row at `unclear`. A yes would close it; a no would leave it a bridge | Recommending a pricing or rating-structure change to a product or commercial owner; pricing input to a new feature or cover level; a test result that changed a product decision | A recommendation paper or deck extract | `[grounded]` background silent on product |
| G3 | Pet-insurance knowledge (R10, preferred) | transferability | Motor GLM and price-test work; no pet exposure | A `preferred` row. The limit is stated honestly rather than closed with wording | Any work on a small-volume or newly launched book; claims-cost trend work; breed- or age-style rating factors in any line | A short written note on how you would adapt your approach to pet claims data | `[grounded]` your own statement that you have no pet experience |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between JD and careers page | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | One source may be out of date, or the policy may differ by hire. Neither is established. This would be a hard conflict only if you need remote work | `[inferred]` from the two sources disagreeing | Is this role fully remote, or based in the Leeds office four days a week, and which is correct today? | unresolved |
| RR2 | Salary withheld | unknown | — | JD gives no figure | The figure may sit anywhere in the survey band in role reality, or the employer may not publish pay | `[inferred]` from the posting's silence, against the `[generic]` band | What is the budgeted salary range for this role? | unresolved |
| RR3 | Posting is live and consistent on role and reporting line | positive_signal | — | Careers page: "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The employer matches the posting's description, and the posting is live | `[grounded]` careers page fetched | Does this role own the pet-product pricing end to end, or share it with another team? | noted |

## Application plan

Each row is proposed language or action. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: keep your GLM line in your own words, "built and maintained the GLM rating model for the young-driver book", and put it near the top | R4, R5a | `[grounded]` your background | pending your approval |
| E2 | `resume_edits_pending_approval`: give price testing its own line: "ran 14 price tests last year with the underwriting team". Add outcomes only if you confirm them | R6 | `[grounded]` your background | pending your approval |
| E3 | `resume_edits_pending_approval`: state "present the quarterly pricing review to the head of underwriting" as its own line | R8, R7a | `[grounded]` your background | pending your approval |
| P1 | Positioning advice: say plainly that your pricing work is in motor and that you haven't worked on pet insurance, then name the method you'd carry over. Do not describe your experience as pet-insurance work, or as people management | R10 | `[grounded]` your own statements | pending your approval |
| A1 | Ask the employer which working pattern is correct before spending effort on the application | R1, RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2 and RR3 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The employer is attributable and the posting is live, which gave role reality its organization row and RR3. The page contradicts the JD on location, which gave R1 and RR1 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). The result was a snippet only; it moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). The result was a snippet only; it moved the hiring-manager row, R5b's reasoning and G1 |

I'm happy to write this up as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Your pay floor and where you can work from → R1 resolves for you, and RR2 can be set against your floor.
- The employer's answer on remote versus Leeds → R1 and RR1 close, and the decision likely becomes `go` or `no_go`.
- Your CV → checks the E1–E3 wording against your own text, and could close presentation gaps I can't see from prose.
- A sanitized model summary, monitoring report or price-test write-up → R4, R5b or R6 could rise to `high`.
- A product-facing recommendation paper → R7b could close.
- The talk's slides or abstract, if public → sharper positioning for R5b.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

- **R1:** Can you work from the Leeds office four days a week, or do you need this role to be fully remote?
- **G1:** Have you personally monitored a rating model after launch, for example performance against expectation or drift checks? If so, what did you track and what did you do with it?
- **G2:** Have you ever taken a pricing result to a product or commercial owner rather than to underwriting? What was the recommendation and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.