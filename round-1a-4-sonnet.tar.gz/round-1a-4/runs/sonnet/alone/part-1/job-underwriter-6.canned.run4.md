I've read the posting and the skill's decision rules. I'm now reading its research-accounting and question-ordering rules, then I'll write the assessment.
# Job Underwriting: Revenue Operations Lead at Quillfield

## Decision snapshot

**Yes, apply, but as a stretch, not a safe fit: R5, R6 and R9 are adjacent or unclear, and R7 is absent. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R10 (Bristol, two office days), R11 (pay £61,500–£67,000)
- `must_have` — direct: R1, R3, R8 · adjacent: R4 (SQL and spreadsheet modelling), R5 (owning a forecast), R9 (quarterly forecast with the CFO) · unclear: R2 (at a B2B software company), R6 (finance, revenue data) · absent: R7 (finance, billing data)

R5, R9 — the forecast is the widest stretch, since finance owned it in your account; R7 — billing is absent by your own account, though the posting's "billing or revenue data" wording may let R6 carry it.

**Opportunity ledger.** Sound and unusually open about pay (RR3). The open items are who owns the forecast (RR1), the share-option terms (RR4), the missing first-year outcomes (RR5), and a scope that bundles several jobs (RR2).

- **Hard gates:** none failed; unconfirmed: R10 (Bristol, two office days), R11 (pay £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R10 and R11 are acceptable to you; (2) RR1 verifies what the role owns on the forecast and what it only contributes to; (3) you frame R5, R7 and R9 honestly as adjacent or absent, never as experience you have.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | Own the CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options; option terms not stated | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, listed as Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` search-result listing (snippet only); recruiter named her to you |
| Reporting line | The Lead probably reports to the Head of Revenue Operations | `[inferred]` from her title against the posting's silence on reporting |
| Scope read | One person covers CRM administration, billing data, reporting and forecasting, with no team or first-year outcomes stated | `[inferred]` from the posting's list against its silence on staffing |
| Market calibration | The posted range sits inside the middle band of UK B2B software revenue operations leads (median £64,200; interquartile range £57,800–£70,400, n=438). The band is UK-wide, not Bristol-specific, and is no claim about this employer's offer | `[generic]` Ledgerline 2026 pay guide; `[grounded]` posting for the range |
| Unknowns | Forecast ownership; team size; first-year outcomes; option terms; whether the role is on Quillfield's own careers page | — |
| Contradictions | None found between the posting and Quillfield's About page | `[grounded]` both read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in revenue operations, sales operations or similar analytics role | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations for the UK team; stated by you, no document yet | `[grounded]` your statement | none |
| R2 | The above at a B2B software company | must_have | unclear | low | discovery | Your employer is a B2B payments company; whether the posting treats that as B2B software is unverified. Taken at the lower reading | `[grounded]` your statement against the posting | ask in a later turn whether its product is software |
| R3 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; the posting accepts either system. Certification is checkable but not yet seen | `[grounded]` your statement | none |
| R4 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show use; "strong" and "modelling" are not yet shown. Limit: no model you built is described | `[grounded]` your statement | see G3 |
| R5 | Experience owning a forecast | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, and finance owned the forecast. Limit: you have never owned the company forecast, and the review is not a forecast | `[grounded]` your statement | see G1 |
| R6 | Working with finance on billing or revenue data (revenue data) | must_have | unclear | low | discovery | The renewal dashboards touch revenue figures, but whether you worked with finance on them is not stated. The posting's "or" means this row may satisfy the requirement | `[grounded]` your statement; `[inferred]` that the "or" lets R6 carry it | see G2 |
| R7 | Working with finance on billing or revenue data (billing data), and owning the billing data | must_have | absent | none | capability | You have never worked on billing data. Closure path: a named ramp-up plan, with the stretch said plainly | `[grounded]` your statement | closure path in G2 |
| R8 | Build the pipeline and renewal reporting that sales and finance run on | must_have | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Limit: who used them, finance included, is not stated | `[grounded]` your statement | see G2 |
| R9 | Run the quarterly revenue forecast with the CFO | must_have | adjacent | medium | transferability | Pipeline review with a sales director is the nearest work. Limit: no forecast ownership and no CFO-level cadence in your account | `[grounded]` your statement | see G1 |
| R10 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | The term is stated; your location and constraints were not given | `[grounded]` posting; your constraints unknown | closing question |
| R11 | Pay £61,500–£67,000 plus options | hard_gate | unclear | none | hard_gate | The term is stated; your pay floor was not given | `[grounded]` posting; your floor unknown | closing question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership and CFO cadence (R5, R9, both must_have) | transferability | A monthly pipeline review with your sales director; finance owned the forecast | These are the posting's headline duties, and resolving them is the likeliest way to move `conditional_go` toward `go` | Pipeline numbers you supplied that fed finance's forecast; commit or call categories you maintained; scenario or coverage analysis; a quarter-end figure you reconciled with finance | A sanitized pipeline-review pack or a forecast-input template | `[grounded]` your statement; `[inferred]` that this is the likeliest interview probe |
| G2 | Finance and billing/revenue data (R6, R7, R8, must_have) | discovery for R6 and R8, capability for R7 | Renewal dashboards built; no finance collaboration or billing work stated | The posting says "own our CRM and billing data"; billing is absent (R7), so how the renewal work connected to finance sets how far the bridge goes | Reconciling renewal figures with finance; agreeing definitions such as ARR or churn with finance; invoice or contract data in a renewal report | A sanitized renewal dashboard screenshot, or a definitions document | `[grounded]` your statement; `[generic]` that billing data is a distinct specialism |
| G3 | SQL and spreadsheet modelling depth (R4, must_have) | discovery | Usage frequency only | "Strong" is unevidenced, though the row is already adjacent | Queries behind the dashboards; a pipeline-to-revenue model; a renewal forecast sheet | A sanitized query or model screenshot | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may own the model, or prepare inputs while the CFO or Head of Revenue Operations owns the number | `[inferred]` from "with" against the Head of Revenue Operations as hiring manager | On the quarterly forecast, which parts does this role own, such as the model, the assumptions and sign-off, and which sit with the CFO or the Head of Revenue Operations? | unresolved |
| RR2 | Several specializations in one title | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting ... and run the quarterly revenue forecast" | CRM administration, billing data, reporting and forecasting may be more than one person's ramp. Rated low because the pay sits mid-band | `[inferred]` from the list against the pay band; `[generic]` that such bundles appear in smaller firms | Which of these four areas have an owner today, and what support does the role have? | unresolved |
| RR3 | Pay stated and in line with the band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The range is transparent and sits near the median for the title | `[grounded]` posting; `[generic]` band | Is the range fixed, or does it flex with experience? | noted |
| RR4 | Share-option terms absent | unknown | — | "plus share options" | Quantity, vesting and strike price are unstated, so the options' value is unknown | `[grounded]` posting silence; `[generic]` that these terms vary widely | How many options are offered, on what vesting schedule and at what strike price? | unresolved |
| RR5 | No first-year outcomes or team size | unknown | — | "You will own our CRM and billing data" | The posting names duties but no success measures or reporting staff | `[grounded]` posting silence | What would a successful first year look like for this role? | unresolved |
| RR6 | Posting seen on a job board, not on Quillfield's careers page | unknown | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | Quillfield exists as described; the role itself was not found on its own site in this search | `[grounded]` About page found; careers page not returned | Can you point me at this role on Quillfield's own careers page? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your application with two things you stated: you rebuilt the pipeline and renewal dashboards, and you run the monthly pipeline review with your sales director | see R8, R5 | `[grounded]` your statements | pending your approval |
| E2 | Say plainly in the application that finance owned the forecast at your company and that you have not owned one, and don't use forecast-ownership wording | see R5, R9 | `[grounded]` your statement | pending your approval |
| W1 | A one-page sanitized renewal dashboard or pipeline-review extract | see R8, G2, G3 | `[grounded]` rows | pending your approval |
| A1 | Before the interview, ask RR1 and RR5 verbatim; they decide whether the stretch is manageable | see RR1, RR5 | `[grounded]` register | pending your approval |
| A2 | Both your history and Tamsin Achebe's include sales operations at payments companies; mention your sector only as fact | `[grounded]` your statement, her listing | see R2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers"; page: "About Quillfield" (quillfield.co.uk/about). It established the company and its size, stage and product (role reality); no careers page came back, so RR6 stays open |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol UK B2B software"; page: "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). It moved the market calibration and RR3; it returned no norms on scope or title |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield"; page: "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet only. It moved role reality's hiring-manager and reporting-line rows |

## Upgrade menu

- Your pay floor and your view on Bristol with two office days → R10 and R11 close, and the decision is likely to simplify.
- Any forecast-related work (G1) → R5 and R9 bridges strengthen or stay adjacent.
- A sanitized renewal dashboard or query extract → R8 and R4 can reach `high`.
- Whether your employer's product counts as B2B software → R2 closes.
- A deeper research pass on Quillfield (funding, leadership changes, public staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

I can write all of this up as `tuesday-dossier.md` if you want a copy to keep.

**Questions**

1. R10, R11 — Does a Bristol role with two office days a week at £61,500–£67,000 work for you, or is either term a dealbreaker?
2. G1 — Did any of your pipeline data feed finance's forecast, and what did you own in that handoff?
3. G2 — Did you work with finance on the renewal dashboards, and who agreed the definitions or figures?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.