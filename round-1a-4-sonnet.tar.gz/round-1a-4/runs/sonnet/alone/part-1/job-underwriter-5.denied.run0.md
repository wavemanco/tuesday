**Yes, it's worth applying to, on conditions. Status: `conditional_go`.** Your SQL, Python, dbt, Airflow and data-quality experience matches the requirements the posting calls must-haves (R3, R4, R5, R6, R7). The main gaps are BigQuery (R8) and two responsibilities your background doesn't yet speak to (R9, R10). The stated pay is in line with your recruiter's pay report (RR3).

Two things limit this verdict. My attempts to check the live posting were refused (RR1). You also haven't told me your own pay floor or location, so R1 and R2 are unchecked.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay $148,000–$166,000 plus equity), R2 (Remote US or Denver office)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse) · unclear: R9 (Ingestion from app and CRM), R10 (Data contracts analysts depend on)

R8 — a credible bridge from Snowflake, its limit named; R9, R10 — your background is silent, waiting on answers; R1, R2 — waiting on your constraints.

**Opportunity ledger.** Sound on its face: the stated pay sits inside the report's range (RR3). The employer and live posting are unverified from here (RR1). The scope may be broader than the report's typical one (RR2), and the equity and reporting line are unknown (RR4, RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Pay $148,000–$166,000 plus equity), R2 (Remote US or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting is confirmed live on the company's own site (RR1).
  2. Your pay floor and location are checked against R1 and R2.
  3. The team shape and scope are confirmed in the first call (RR2, RR5).
  4. The BigQuery bridge is framed as adjacent, never as BigQuery experience (R8).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` About text you pasted; not checked against the live page |
| Mandate | Build and run the pipelines behind reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD you pasted |
| Pay and terms | $148,000–$166,000 plus equity (size unstated); remote (US) or Denver office | `[grounded]` JD you pasted |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500, n=2,310. The posting's range starts just under the median and ends above the upper quartile, so there is no seniority-pay mismatch. "Senior" typically means 5–8 years, and the JD's 5+ and your 6 years fit that. | `[generic]` for the band and typical seniority, from the recruiter-supplied Datawright 2026 report, with no search run; `[grounded]` for the posting's figures |
| Scope read | The posting spans ingestion, warehouse modelling and contracts, while the report's typical scope is one domain's pipelines with no direct reports. This role may therefore be broader than typical (RR2). | `[inferred]` from the JD's three-part mandate against the report's typical scope |
| Unknowns | Hiring manager (none named); team size; first-90-day and first-year outcomes (none stated); equity terms; your pay floor and location | `[grounded]` JD silence; `[grounded]` your message |
| Contradictions | None between the JD and About text as you pasted them. I couldn't compare either against the live site. | `[grounded]` pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You gave no pay floor, so there is no statement of your constraint to grade. The range is stated and sits inside the report's interquartile range. | `[grounded]` JD; `[grounded]` your message gives no floor | Constraint question in the closing block |
| R2 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You gave no location or work authorization. The posting offers US-remote or Denver. | `[grounded]` JD; `[grounded]` your message gives neither | Constraint question in the closing block |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at one B2B payroll company. This is prose at intake, so `medium` is the ceiling. | `[grounded]` your message | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. No artifact has been inspected. | `[grounded]` your message | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You state building your company's dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse. A sanitized lineage graph or project tree would raise this to `high`. | `[grounded]` your message | Offer: a sanitized dbt lineage graph or project tree |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration. Your ownership of the DAGs is unspecified, so the claim carries that limit. | `[grounded]` your message | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You state you set up the Great Expectations test suite. You haven't mentioned dbt tests, so none are claimed. | `[grounded]` your message | Offer: a sanitized suite config or coverage summary would raise this to `high` |
| R8 | BigQuery warehouse (the stack the JD names) | important | adjacent | medium | transferability | Snowflake and BigQuery are both cloud SQL warehouses, so dbt modelling carries over. The limit is that you have never used BigQuery, so its cost model and platform-specific tuning are unexercised. The JD's own requirement line says "a cloud warehouse", not BigQuery. | `[inferred]` bridge from your Snowflake work; `[generic]` for the BigQuery differences | See gap queue G1 |
| R9 | Ingestion from the company's app and CRM | important | unclear | low | discovery | You describe Airflow pipelines but not what they ingested. Nothing says whether sources were product data, CRM or other SaaS APIs. | `[grounded]` your message silent on sources | See gap queue G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations suite is indirect context. You haven't described agreeing schemas or quality expectations with data consumers. | `[grounded]` your message silent on contracts; `[inferred]` that the test suite is adjacent context | See gap queue G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Strong Snowflake and dbt work; no BigQuery use | The JD names BigQuery as the warehouse, so this is the likeliest probe in a screen. | A personal or sandbox BigQuery project run through dbt | A small public repo or a short write-up of a BigQuery dbt project | `[grounded]` your message says no BigQuery use; `[generic]` that the named stack is probed in screens |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Airflow pipelines described, sources not | The posting leads with ingestion, so source types may decide how far the role is a direct match. | Pulling product-database or event data; loading CRM or other SaaS API data; building connectors or incremental loads | A pipeline diagram or DAG structure, with names removed | `[grounded]` your message silent on sources; `[inferred]` from the posting's ordering that ingestion matters |
| G3 | Data contracts (R10, important) | discovery | A Great Expectations suite, with no consumer-facing agreement described | The JD says analysts depend on these contracts. Whether you set expectations with consumers decides whether R7 carries over. | Agreeing schemas or freshness expectations with analysts; a schema-change process; checks analysts relied on | A sanitized expectation suite or a schema-change note | `[grounded]` your message silent on contracts; `[inferred]` that R7 may carry over |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | My fetch and search to check this were refused, so none of it is confirmed from here. Reasons that could apply: the entity is real and the check simply didn't run, the posting is stale, or the role isn't currently open. None is more likely than the others. | `[generic]` pattern for any unverified posting, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Scope may exceed one domain | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may combine ingestion, modelling and contracts, which could mean owning a platform rather than one domain. I rate it `low` because a mandate this size at a 264-person company can be normal. | `[inferred]` from the three-part mandate against the report's typical scope | How many data engineers are on the team, and which of ingestion, modelling and contracts does this role own end to end? | unresolved |
| RR3 | Stated pay is inside the market range | positive_signal | — | "$148,000–$166,000 plus equity" | The range overlaps the report's interquartile range of $139,000–$163,500 and tops it by $2,500. | `[grounded]` JD figures against the pay report you supplied | Where in this range would an offer for 6 years of experience land? | noted |
| RR4 | Equity unspecified | unknown | — | "plus equity" | Equity type, size and vesting aren't stated, so its value can't be set against the band. | `[grounded]` JD states equity with no terms | What is the equity grant: type, size and vesting schedule? | unresolved |
| RR5 | No hiring manager named | unknown | — | "The posting names no hiring manager" | The reporting line and team shape aren't visible from the posting. | `[grounded]` your note on the posting | Who would I report to, and who else is on the data team? | unresolved |

## Application plan

Everything here is proposed. The edit row is `resume_edits_pending_approval`, and every other row, advice included, is pending your approval. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move two lines to the top of your CV, in your own words: "Built our dbt project on Snowflake — about 180 models" and "Set up our Great Expectations test suite" | They answer R5 and R7 first. Each clause traces to your message and adds no scope. | `[grounded]` your message | resume_edits_pending_approval |
| A1 | Open the posting yourself on the company's own site and confirm it is live and that the pay line matches | Closes RR1 before you spend effort | `[grounded]` RR1 | pending your approval |
| A2 | Say plainly that your warehouse experience is Snowflake, not BigQuery, and that the dbt work carries over | This keeps R8 as adjacent and stays within what you've told me | `[inferred]` from R8 | pending your approval |
| Q1 | In the first call, ask the questions in RR2, RR3, RR4 and RR5 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One fetch of pellucidlearning.com/careers/senior-data-engineer and one search ("Pellucid Learning Senior Data Engineer careers Denver tutoring") were both refused for lack of permission. It would have fed the contradictions row and RR1. |
| 2. Role-family sweep | skipped | The pay report you supplied fixes the market calibration row, RR2 and RR3, so a search would have changed none of them. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

I'll build the full `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Permission for web search and fetch, or the live careers page pasted → RR1 closes, and the contradictions row gets a real check. If you grant web access, a deeper company pass (funding, leadership churn, public employee reports; up to 5 more searches and 2 more fetches) is available.
- Your pay floor, location and work authorization → R1 and R2 resolve, and the hard-gates line stops carrying the unconfirmed flag.
- A sanitized dbt lineage graph or project tree → R5 to `high`.
- A sanitized Great Expectations suite config or coverage summary → R7 to `high`.
- Answers to G2 and G3 → R9 and R10 move to `direct` or `adjacent`, or stay open.
- The hiring manager's name → the scope read and the plan's positioning can be set for that reader.

## Questions

1. **R1, R2:** What is your pay floor, and are you US-based and authorized to work in the US (or able to work from Denver)? A rough number and a yes or no is enough.
2. **G2:** In your payroll company's pipelines, what did Airflow ingest from: product-database or event data, CRM or other SaaS APIs, files? And what did you own end to end?
3. **G3:** Did you ever agree schemas or quality expectations with the analysts or teams using your tables, such as checks they relied on or a schema-change process? What was yours to decide?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.