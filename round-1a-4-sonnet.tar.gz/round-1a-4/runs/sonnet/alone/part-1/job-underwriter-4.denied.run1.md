I'll read the reference files the skill points to before building the assessment.
**Should you go for it?** Yes, apply, on conditions. Your must-have rows R2, R3, R4, R5, R6 and R7 all read `direct`. The conditions are that the employer verifies and that you confirm the UK location term. Status: `conditional_go`.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: unclear: R8 (Recommendations for product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance domain)

R10 — a bridge from motor to pet, limit named in the map; R8 (`low`) — product-side work not yet evidenced; R1 (`low`) — your UK location unconfirmed.

**Opportunity ledger.** The employer could not be checked from here (RR1), pay is not stated (RR2), and team size and decision rights are not stated (RR3). One entry runs the other way: the deliverables are concrete (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verify on the company's own site, per RR1. (2) You confirm the UK-based, fully remote term, per R1. (3) The pet-insurance limit is framed as adjacent, never as pet expertise, per R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, with a pet-insurance product; its existence and the posting's liveness are not verified | `[grounded]` JD as you pasted it; research did not run |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing; public footprint not researched | `[grounded]` as you gave it |
| Management | The JD lists no line-management requirement, so your never having managed anyone is not a stated gap. Whether the post has or will have reports is not stated | `[grounded]` JD as pasted |
| Scope read | A hands-on analytical post reporting into pricing leadership | `[inferred]` from the hiring manager's title and the JD's verbs |
| First 90 days | Likely to take over monitoring of the pet rating models and read in-flight price tests | `[inferred]` from "build and monitor" and "design and read" |
| Market calibration | None given. The role-family sweep did not run, and I won't quote a pay band from memory | — |
| Unknowns | Salary; team size and reports; who decides prices; how mature the pet product is | — |
| Contradictions | None visible within the pasted JD; the careers page was not checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You have not stated where you are based. You work at a UK insurer, which suggests UK-based but does not settle it | `[inferred]` from your UK employer | Closing question G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You say 5 years of pricing analytics, the last 2 as senior analyst. Specific, but CV-equivalent prose with nothing inspected yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily" is specific. "Strong" is a judgment that needs an artifact | `[grounded]` your background | Optional: a sanitized query or notebook would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, not yet inspected | `[grounded]` your background | Optional: sanitized model documentation would raise it to `high` |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" covers the build. The monitoring half rests on "maintained", so claim no more than that wording | `[grounded]` your background | Use your own words, "built and maintained" |
| R6 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with underwriting. Whether you designed them, analysed them or both is not stated, so it resolves to the lower reading until you say. Test design is a likely interview probe | `[grounded]` your figure; `[generic]` that roles like this probe test design | Closing question G2 |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R8 | Turning results into recommendations for product, as well as underwriting | important | unclear | low | discovery | Underwriting side is covered by R6 and R7. Nothing you've said touches a product or proposition team | `[grounded]` silence in your background | Closing question G3 |
| R9 | Insurance experience a plus | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain (inferred: the role is for a pet product; the JD does not require pet experience) | preferred | adjacent | medium | transferability | You've never worked on pet. What carries over is GLM rating and price testing on an insurance book. Limit: no pet-specific rating or claims experience. Expect pet-specific questions because the two lines rate on different factors | `[inferred]` adjacency from your motor work; `[generic]` that the lines differ | Gap G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-based, fully remote (R1, hard_gate) | hard_gate | No statement of where you live or what terms you need | A gate the inputs don't settle stays open and can change the status | A statement of your base and any non-negotiables | None needed | `[grounded]` your input is silent |
| G2 | Design vs analysis on the 14 tests (R6, must_have) | discovery | Count and partner are clear; your role in test design is not | A must-have where the hiring manager's team will read test design closely | Choosing the hypothesis, the split, run length or sample size, the decision rule; reading results; seeing a result change a live rate | A sanitized test write-up, a one-page readout, a template you built | `[grounded]` the CV-equivalent gap; `[generic]` that test design gets probed |
| G3 | Product-side recommendations (R8, important) | discovery | Underwriting audience only | The JD names product as a second audience | A pricing proposal to a product, proposition or commercial team; a pricing-review item that fed a product decision | A deck excerpt or a readout | `[grounded]` silence in your background |
| G4 | Pet-insurance domain (R10, preferred) | transferability | GLM and price-test work on motor | Preferred tier, but it is the likeliest "why you?" objection | Rating-factor work on any non-motor or new product; frequency and severity modelling | A short, honest bridge note | `[inferred]` bridge from your motor work |

Limit of the bridge: it carries method, not pet knowledge. The strengthener is a sanitized sample of your test or model write-up. G4 has no question this turn, because the budget goes to rows that could move the decision.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated in the posting as pasted | unknown | — | "Fully remote (UK)" (the terms end here with no figure) | The figure may sit below what a senior role needs, or the posting as pasted may have dropped it | `[inferred]` from the pasted terms; no market band was researched | What is the salary range for this post? | unresolved |
| RR3 | "Own" pricing analytics with no stated team or decision rights | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the sole analyst, or recommend where others decide. Direct reports may or may not exist | `[inferred]` from the JD's verb against its silence on team and authority | Does the post have reports now or planned, and which pricing decisions does it make versus recommend? | unresolved |
| RR4 | Concrete deliverables stated | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | Scope is defined by named work rather than vague ownership | `[grounded]` JD | What would success look like in the first year? | noted |

## Application plan

Each block below is proposed, not applied.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Built and maintained the GLM rating model for the young-driver motor book" | R4, R5. Your own verbs, nothing added | `[grounded]` your background | resume_edits_pending_approval |
| E2 | CV line: "Ran 14 price tests with the underwriting team last year". Don't write "designed" or "led" until G2 is answered | R6. Keeps the 14 attached to tests | `[grounded]` your figure | resume_edits_pending_approval |
| E3 | CV line: "Present the quarterly pricing review to the head of underwriting" | R7 | `[grounded]` your background | resume_edits_pending_approval |
| P1 | Positioning: lead with GLM rating plus price testing on a UK motor book, and say plainly that pet is the new product for you. Claim no pet-specific knowledge | R10 | `[inferred]` bridge | pending your approval |
| P2 | If asked about people management: say you haven't managed anyone, then describe what you do: working with underwriting on tests and presenting to its head. Don't imply reports | R6, R7; JD lists no such requirement | `[grounded]` your statement | pending your approval |
| Q1 | Ask the RR1, RR2 and RR3 questions verbatim early in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Check the role and company on its own site before investing effort | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst"; both refused. It would have moved RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary remote"; refused. It would have moved the market-calibration row and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. It would have moved the scope read and which story the plan leads with |

I can offer an optional write-up of this assessment as `tuesday-dossier.md`; say the word and I'll produce it.

## Upgrade menu

- Permission to run searches (up to 5 searches and 2 fetches): closes RR1, gives a pay band for RR2, and adds Odile Varga's public professional footprint to the scope read. A deeper pass afterwards (up to 5 more searches and 2 more fetches) is available once, on request.
- A link to the posting on Brindlemoor's own careers page: closes RR1 and checks the pasted JD against the original.
- A sanitized test write-up or readout: R6 to `high` and G2 closed.
- Sanitized model documentation or a notebook: R3 and R4 to `high`.
- Your pay floor and notice period: lets RR2 be set against your constraint.
- A mention of any product-side presentation: R8 resolves.

## Questions

G1 — Are you UK-based, and are there any non-negotiables (pay floor, notice period, fully remote) this role would need to meet?
G2 — On the 14 price tests, which did you personally design (hypothesis, split, run length, decision rule), and which did you analyse? Did any result change a live rate?
G3 — Have you ever taken pricing results to a product, proposition or commercial team, rather than underwriting?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.