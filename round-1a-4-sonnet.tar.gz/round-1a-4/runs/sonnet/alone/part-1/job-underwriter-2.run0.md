I'll read the reference files the skill requires before building the assessment.
I couldn't run the research searches, so everything below rests on your resume and the JD alone. Treat the role as unverified and the market-pay view as missing.

## Decision snapshot

**No, the pivot isn't a waste of your time. This particular role is a stretch you can apply to on conditions: `conditional_go`.** R3, R4 and R7a land `direct`. R1b and R5a land `adjacent`. R1a (3+ years titled PM experience) is `absent`, and you can't fix that with wording.

**Fit ledger.**

- `must_have` — direct: R3, R7a · adjacent: R1b (PM-type work inside a non-PM role), R5a (specs and delivery with squads) · unclear: R2 (Shipped API or platform products), R5b (Own the roadmap), R8 (Agile delivery) · absent: R1a (3+ years titled PM experience)
- `important` — direct: R4 · unclear: R6 (Adoption metrics), R7b (Launches with sales and support)

R1a — absent against the titled-years wording; R1b — the bridge, its limit named; R3 (`medium`) — self-reported, waiting on an artifact.

**Opportunity ledger.** Nothing severe. The employer is unverified in this run (RR1). Pay and work arrangement are unstated (RR2, RR6). The years requirement is worded as a must-have (RR3). First-year outcomes are unstated (RR5). One entry runs the other way: the platform scope is concrete (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer verifies as described, per RR1; (2) your answers to G1 and G2 show a shipped-product or prioritization story, or you apply knowing R2 and R5b stay gaps; (3) the employer says non-titled product work is considered, per RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. I could not check it against the company's own site. | `[grounded]` JD header; not verified |
| Mandate | Own the partner-facing API platform roadmap, run partner discovery, write specs, drive delivery with two engineering squads, define and track adoption metrics, coordinate launches with sales and support | `[grounded]` JD |
| Scope read | A mid-level platform PM post: a named product surface, two squads, and 3+ years required | `[inferred]` from the JD's scope and requirement lines |
| Market calibration | Not produced. The role-family sweep did not run, so I state no title, seniority or pay band rather than recall one. | — |
| Unknowns | Compensation, location or remote terms, reporting line, first-year outcomes, whether non-titled product experience is considered | `[grounded]` JD silence |
| Contradictions | None visible inside the JD. The JD wasn't compared against a careers page. | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience (titled) | must_have | absent | none | capability | You said you have never held a PM title. Experience length isn't a gate. It is a literal requirement that you don't meet as written. | `[grounded]` your statement; `[generic]` that postings with "(must-have)" are often screened literally | Carry as a material risk. Ask RR3's question before investing heavily. |
| R1b | The substance of PM work, done outside a PM title | must_have | adjacent | medium | transferability | Quarterly roadmap-input sessions collecting client feedback for product, requirements documents, and coordinating engineers and product managers on custom builds. Limit: this fed other people's roadmaps and did not set priorities or trade-offs. | `[grounded]` resume, self-reported | Sanitized artifact, see W1 |
| R2 | Shipped API or platform products | must_have | unclear | low | discovery | Your resume shows 30+ integrations of your employer's REST APIs and an internal integration playbook the team uses. Neither is a shipped product. An unconfirmed earlier-conversation note mentions an internal request-triage tool that support agents adopted. It is a lead, not evidence. | `[grounded]` resume; `[inferred]` that the lead could matter | Ask G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Led REST API integrations end to end; Postman, SQL, OpenAPI specs. Self-reported, with no artifact inspected yet. | `[grounded]` resume | Offer: a sanitized playbook excerpt or integration architecture doc would raise it to `high`. |
| R4 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops and roadmap-input sessions with clients' engineers are discovery with integrators. The resume frames them as delivery work. | `[grounded]` resume | Reposition, see E1 |
| R5a | Write specs and drive delivery with engineering squads | must_have | adjacent | medium | transferability | Requirements documents and coordination of your engineers and clients' engineers. Limit: these were specs for custom client builds, not product backlog specs, and the resume doesn't show authority over a squad. | `[grounded]` resume | See G4 |
| R5b | Own and prioritize a product roadmap | must_have | unclear | none | discovery | The resume is silent on who decided what got built or cut. Roadmap input is not roadmap ownership. | `[grounded]` resume silence | Ask G2 |
| R6 | Define and track adoption metrics | important | unclear | low | discovery | No adoption metrics appear. SQL is a relevant skill. The unconfirmed triage-tool lead would bear on this. | `[grounded]` resume silence; `[inferred]` relevance of the lead | Ask G1 |
| R7a | Stakeholder management across engineering and customers | must_have | direct | medium | none | Coordinated your engineers, clients' engineers and PMs across 30+ integrations. | `[grounded]` resume | none |
| R7b | Coordinate launches with sales and support | important | unclear | none | discovery | Sales and support aren't mentioned. | `[grounded]` resume silence | See G5 |
| R8 | Agile delivery | must_have | unclear | low | discovery | The resume shows coordinating builds with engineers but names no sprint or backlog practice. | `[grounded]` resume | See G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product and adoption (R2, R6) | discovery | An adopted playbook, and an unconfirmed lead about a triage tool | R2 is a `must_have` at `unclear`; a confirmed story could move it to `adjacent` or better | An internal tool, connector or template others adopted; a feature request you turned into a spec that engineering built; usage or go-live numbers you tracked | Screenshot, usage numbers, a one-pager, or the playbook | `[grounded]` resume; `[inferred]` that this is the likeliest row to move |
| G2 | Prioritization authority (R5b) | discovery | Input sessions, no decision evidence | Roadmap ownership is the role's core | Deciding what went into or out of a custom build; ranking client requests for product; negotiating scope with engineers | A scoping doc or change log | `[grounded]` resume silence |
| G3 | Titled PM years (R1a) | capability | None, by your own statement | It stays a gap on the page whatever the wording | Closure paths: a role where title isn't required, an internal move, or a shipped side project | — | `[grounded]` your statement; `[generic]` that closure paths like these exist |
| G4 | Specs and delivery bridge (R1b, R5a) | transferability | Requirements docs and cross-team coordination | The bridge is credible, but its limit is that these were client-build specs | A requirements doc that engineering built from; a handoff you ran | A sanitized requirements doc | `[grounded]` resume |
| G5 | Agile and sales or support launches (R8, R7b) | discovery | Silent | Both are asked about in the JD; no question this turn | Sprints you worked inside; go-live handoffs to support or sales | A go-live checklist | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The searches were refused, so this reflects a check not run, not a negative finding. Reasons side by side: a company too new or small for a footprint, a stale posting, or a post that doesn't represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your careers site, and who I would be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | The JD gives no figure | Pay may or may not fit your floor; your floor wasn't given, and PM pay against your current role is unchecked | `[inferred]` from JD silence | What is the salary range, and is it fixed or flexible? | unresolved |
| RR3 | Titled-years requirement worded as a must-have | risk_signal | low | "3+ years product management experience (must-have)" | A literal screen may stop applicants without a PM title before a person reads your evidence. Low, not higher, because the JD's other lines value integration and technical work. | `[generic]` pattern for requirements worded this way | Would you consider product work done in an implementation or solutions role, and what would that evidence need to show? | unresolved |
| RR4 | Concrete scope | positive_signal | — | "Own the roadmap for our partner-facing API platform... drive delivery with two engineering squads" | Named product, named delivery resources | `[grounded]` JD | Who sets priorities between the squads today? | noted |
| RR5 | First-year outcomes not stated | unknown | — | "define and track adoption metrics" | The hire defines the success metrics, so there may be no baseline | `[inferred]` from the JD's wording | What should this role have delivered at 12 months, and how will you judge it? | unresolved |
| RR6 | Work arrangement and reporting line unstated | unknown | — | The JD gives no location or reporting line | Terms may or may not fit constraints you haven't given me | `[grounded]` JD silence | Is the role remote or on-site, and who does it report to? | unresolved |

## Application plan

Everything in this plan, prose and tables alike, is proposed and pending your approval. Nothing is finalized, and nothing goes into your resume or any outreach until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: move "Ran quarterly roadmap-input sessions collecting client feedback for product" and the integration playbook higher, in your own wording. Add the summary line "Solutions engineer and implementation lead (7 years) moving into product management". Don't relabel the role as PM. | R1b, R4 | `[grounded]` resume | pending your approval |
| W1 | A one-page sanitized excerpt of the integration playbook or an architecture doc | R3, R1b, G4 | `[grounded]` rows | pending your approval |
| A1 | Ask RR3's question of the recruiter or hiring manager before investing heavily | R1a | `[grounded]` RR3 | pending your approval |
| A2 | Seek a referral or intro rather than applying cold | Hiring at companies of this size often runs through introductions, so this is a pattern and not a fact about this employer | `[generic]` pattern | pending your approval |
| A3 | Alongside this role, look at roles that count product-adjacent work, since this one requires titled years | R1a | `[generic]` pattern | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: the earlier-conversation note about a request-triage tool, unconfirmed. It only prompts G1.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused, one aimed at Quartzline's site and careers page. It would have moved role reality's organization and contradictions rows and RR1. |
| 2. Role-family sweep | unavailable | A search for the role family's scope and pay was refused. It would have moved the market-calibration row and RR2's pay comparison. |
| 3. Hiring manager's footprint | n/a | No name was given, so there was no query to form. |

Beyond this assessment: a pivot-wide map of target roles and titles that value your background could be built on your approval. This engagement earns it because R1a is a structural gap for this posting.

I can also write this up as `tuesday-dossier.md` whenever you want it.

## Upgrade menu

- Permission to run the two research searches → RR1 and the market-calibration row get real answers.
- A sanitized playbook or integration architecture doc → R3 rises to `high`; R1b and R5a get an inspectable artifact.
- Answers to G1 and G2 → R2, R6 and R5b may move off `unclear`.
- A hiring manager's name → scope read and which story to lead with.
- A sanitized one-pager on the triage tool, if it is real → R2's strongest candidate evidence.

## Questions

G1 — I'm going on an earlier-conversation note I can't confirm: did you build an internal request-triage tool that support agents adopted? If so, what did you own, did real users adopt it, and how did you know?

G2 — On your custom builds, were there times you decided what went into scope and what got cut or deferred? What did you decide, who signed off, and what happened?

RR2 — What pay floor would you need for a move into product, and are there location, remote or travel limits I should check this role against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.