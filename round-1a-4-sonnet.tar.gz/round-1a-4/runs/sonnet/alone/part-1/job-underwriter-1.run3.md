I'll read the skill's reference files before building the assessment.
Research didn't run (see Evidence status), so everything below rests on your background and the pasted JD.

## Decision snapshot

**Yes, apply. You meet the core requirements as you've described them (R1, R2, R3, R4, R5 are `direct`), with open gaps on R6, R7b, R8 and R9. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important` — direct: R7a · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA a plus)

R6 — the metrics-layer claim isn't yet stated; R7b and R8 — your background is silent, so an answer could settle them; R9 — a bridge through GDPR/CCPA and the consent-state model, with its limit named.

**Opportunity ledger.** The posting is concrete about duties (RR5) but silent on pay, location and first-year outcomes (RR2, RR4), and on what support sits beneath the metrics layer (RR3). The employer could not be checked from here (RR1).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, see RR1; (2) pay and location clear whatever floor you hold, see RR2, which I can't test until you state your constraints; (3) your answer to G1 confirms you owned metric definitions, see R6.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up, about 400 people, Series C, with a care-navigation app | `[grounded]` JD header |
| Mandate | Own product analytics for the app: the metrics layer, A/B test design and analysis, self-serve Looker dashboards, partnership with product managers and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Stated requirements | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, written communication with non-technical stakeholders; HIPAA healthcare data a plus | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | One seat spans metric definitions, experimentation, BI build-out, stakeholder partnership and people mentoring, so the data models and tooling under it matter | `[inferred]` from the breadth of duties against the JD's silence on supporting data engineering |
| Market calibration | Not given. The role-family sweep did not run, so I have no band for this title and won't supply one from memory | `[grounded]` the sweep did not run |
| Unknowns | Pay, location and work arrangement, reporting line, first-year outcomes, data and experimentation tooling | `[grounded]` JD silent on each |
| Contradictions | None inside the pasted JD. A check against the careers page was not possible | `[grounded]` JD read; careers page not fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a ~2M-subscriber meal-kit company. It is specific, but it was typed in and no CV or dated record has been inspected | `[grounded]` your intake message | Attach your CV to confirm titles and dates |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse" is specific. "Expert" is your own label and nothing inspectable backs it yet | `[grounded]` your intake message | Offer: a sanitized query set or model definition would raise to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift. What "at scale" means at Harborlight (traffic, platform) is not stated in the JD | `[grounded]` your intake message; `[grounded]` JD silent on scale | Offer: a sanitized test readout would raise to `high` |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | You built the Looker instance from scratch with 40+ governed dashboards. Whether business users built their own content in it (self-serve) is not stated | `[grounded]` your intake message | Offer: dashboard screenshots or LookML excerpts, sanitized, would raise to `high` |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly. This is confirmed but not inspectable | `[grounded]` your intake message | Offer: a sanitized memo would raise to `high` |
| R6 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | Building Looker from scratch with governed dashboards suggests metric definitions were yours. You have not said you defined or maintained a shared metrics layer, so this stays a lead, not a claim | `[inferred]` from the Looker build and "governed dashboards" | G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | The pricing test and the monthly VP Product presentation show analysis reaching product leadership. Day-to-day work with individual PMs is not described | `[grounded]` your intake message | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background touches clinical or other subject-matter experts. This is a gap in the record, not evidence of absence | `[grounded]` background silent | Carried; not asked this turn because of the question budget |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background says nothing about mentoring or managing | `[grounded]` background silent | G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for the warehouse, so privacy discipline carries over. Limit: you have not worked with health data, and consumer PII under GDPR/CCPA is not covered by HIPAA | `[grounded]` your intake message; `[generic]` that HIPAA and GDPR/CCPA are separate regimes | E3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Looker and governed dashboards, but no statement that you defined or maintained shared metric definitions | It's the first duty the JD lists. Confirming it would remove the one `must_have` row that isn't `direct` | Writing the canonical definition of retention or churn that every dashboard used; owning the Looker model or warehouse tables others built on; settling a metric dispute between teams | LookML excerpt, a metrics glossary or definition doc, sanitized | `[grounded]` the CV is silent on definitions; `[inferred]` that confirming it would move R6 |
| G2 | Mentoring (R8, important) | discovery | No mentoring or people-leadership signal | The JD names two junior analysts, so mentoring is a stated duty | Onboarding a new analyst; reviewing a colleague's SQL or experiment readouts; running office hours or a training session, with or without direct reports | Onboarding doc, review checklist, or training deck | `[grounded]` background silent; `[generic]` that senior analyst roles usually probe this |
| G3 | Clinician partnership (R7b, important) | discovery | Nothing on working with domain experts outside product | The JD names clinicians as partners | Translating results for experts in a non-product field and changing a decision with them | A write-up or deck from that work | `[grounded]` background silent |
| G4 | Health data (R9, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model, with no health-data exposure | A preferred row, so a limit to name honestly, not a blocker | Design reviews of the consent model with legal or privacy; access controls or retention rules you set | Consent-model design doc, sanitized | `[inferred]` bridge from the consent-state model; `[generic]` that regulated-data roles ask about this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The check did not run, so this is not a finding about the company | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay, location and work arrangement unstated | unknown | — | The pasted JD gives no figure, location or schedule | The figures may sit outside your range, or the company may simply not publish them in this posting | `[grounded]` JD silent | What salary band is budgeted, and where is the role based? | unresolved |
| RR3 | Support under the metrics layer unstated | unknown | — | "define and maintain the metrics layer" | You may own the definitions, the models and the tooling with no data-engineering help | `[inferred]` from the duty list against the JD's silence on data engineering | Who builds and maintains the data models under the metrics layer, and what experimentation platform is in use? | unresolved |
| RR4 | No stated first-year outcomes | unknown | — | "Own product analytics for our care-navigation app" | Success may be undefined for a broad mandate | `[grounded]` JD silent on outcomes | What would success look like at 90 days and at one year? | unresolved |
| RR5 | Defined duties and team scope | positive_signal | — | "mentor two junior analysts" | The mandate is concrete: named duties, a named team size and named partners | `[grounded]` JD | Who are the two analysts, and where are they in their development? | noted |

## Application plan

`resume_edits_pending_approval` — this covers E1 and E3 and the positioning advice in P1. Each row below is proposed, not final. I ran each over the reframing audit against your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the three claims you confirmed at the top of the CV, in your own terms: "Designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift"; "Built the Looker instance from scratch, 40+ governed dashboards"; "Write the monthly metrics memo the exec team reads" | R3, R4 and R5 are the `must_have` rows with the strongest evidence | `[grounded]` your intake message | pending your approval |
| E3 | Bridge line for health data: "Handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse." State plainly that you have not worked in healthcare. Do not claim HIPAA or health-data experience | R9; the limit is that it is consumer PII, not health data | `[grounded]` your intake message | pending your approval |
| P1 | Positioning: lead with the pricing test, since it is the one claim that ties analysis to a business result. Hold any metrics-layer or mentoring wording until G1 and G2 are answered | R3, R6 and R8 | `[grounded]` R3, R6, R8 rows | pending your approval |
| Q1 | Ask RR1 through RR4's questions in the loop, and RR1's with the employer first | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Confirm the role is live on Harborlight's own careers site before investing in the application | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Stage was not stated, so I've treated this as evaluating.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Harborlight Health care navigation app careers" was refused. It would have confirmed the employer and live posting, feeding RR1 and role reality's contradictions row |
| 2. Role-family sweep | unavailable | The search "senior product analyst digital health salary range experimentation Looker" was refused. It would have set a market band and scope norm for the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'm offering a dossier: say the word and I'll save this as `tuesday-dossier.md` so you can carry it forward.

## Upgrade menu

- Your CV, to confirm titles and dates → R1 firms up and may move toward `high`.
- A sanitized query or model definition → R2 to `high`; a sanitized test readout → R3 to `high`; dashboard screenshots or LookML → R4 to `high`; a sanitized memo → R5 to `high`.
- An answer to G1 → R6 moves from `adjacent` toward `direct`, or stays a named limit.
- An answer to G2 → R8 resolves or stays carried.
- Your pay floor, location and work-authorization constraints → the hard-gates line can finally check them; RR2 resolves.
- Permission for web search → the careers-page and market-band targets (1 and 2) run, which settles RR1 and gives a band for RR2. A hiring manager's name, if you have one, enables target 3.
- Once the L1 targets have run, a deeper pass on funding and leadership news: up to 5 more searches and 2 more fetches.

**Questions** (three, tagged to their rows)

G1 — Did you personally define or maintain the metric definitions behind those Looker dashboards, for example one agreed definition of retention that every dashboard used? What was yours, who else used it, and is there a document or LookML excerpt you could share?

G2 — Have you mentored, onboarded or reviewed the work of more junior analysts, even without direct reports? What did you do, and how did it go?

C1 — Do you have non-negotiables I should check this role against: a pay floor, location or hybrid limits, work authorization, or schedule?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.