I've read the underwriting rules. Next I'll run one quick check that the posting and company exist as pasted, then write the assessment.
**Yes, it's worth applying to, on three conditions: `conditional_go`.** The conditions are RR1 (confirm the employer and posting), R1 and R2 (check the location and pay terms against your own), and R8 (frame BigQuery as adjacent experience, never as direct).

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery) · unclear: R9 (ingestion from app and CRM), R10 (data contracts analysts depend on)

R8 — a credible bridge, its limit named; R9 — discovery open, one question; R10 — discovery open, one question.

**Opportunity ledger.** The stated pay is competitive (RR4). The employer and posting could not be checked here (RR1), the equity terms are missing (RR2), the mandate looks wide (RR3), and no manager or first-year outcomes are named (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) your location and pay floor fit R1 and R2; (3) the BigQuery bridge is framed as adjacent, never as direct experience (R8, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the About text you pasted, not independently checked |
| Mandate | Build and run the pipelines behind reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Stated outcomes | No first-90-days or first-year outcomes are stated | `[grounded]` JD silence |
| Scope read | Four areas (ingestion, warehouse modelling, contracts, running the pipelines) in one role, against a typical scope of one domain's pipelines and no direct reports | `[inferred]` from the JD's list against the pasted report's scope line |
| Market calibration | The report gives a base median of $151,000 and an interquartile range of $139,000–$163,500 for Senior Data Engineer at Series B–D companies, with "Senior" typically 5–8 years. The posting's $148,000–$166,000 starts $3,000 below the median and ends $2,500 above the top of the range, so it sits at or above the middle. This is a market band, not this employer's offer | `[grounded]` Datawright 2026 report (n=2,310) as pasted; `[grounded]` JD for the posted figures |
| Unknowns | Equity terms; hiring manager and team size; success measures; whether remote hires are limited to certain states | — |
| Contradictions | None between the JD and the About text you pasted. Neither page was checked live | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and any location limits weren't given, so nothing can be checked. Confidence grades your statement of the constraint, and there isn't one yet. | `[grounded]` JD; no candidate constraint given | Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor was given. The cash band is stated, but the equity terms are not. | `[grounded]` JD; no candidate constraint given | Q1; RR2's question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You report 6 years at a B2B payroll company. Years are graded as a requirement, not a gate. Self-reported, with nothing inspectable yet. | `[grounded]` your background as stated | Offer: a dated role record or LinkedIn history would raise it to `high` |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. Self-reported, with no inspectable code yet. | `[grounded]` your background as stated | Offer: a sanitized model or script excerpt would raise it to `high` |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project (about 180 models) on Snowflake, which is a cloud warehouse. The posting's warehouse is BigQuery, which is scored separately in R8. | `[grounded]` your background as stated | Offer: dbt docs or a lineage graph screenshot would raise it to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You run Airflow, the named tool. | `[grounded]` your background as stated | Offer: a sanitized DAG screenshot would raise it to `high` |
| R7 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, so you ran it, not just used it. Your dbt tests were not mentioned, and I haven't assumed them. | `[grounded]` your background as stated | Offer: Great Expectations data-docs output would raise it to `high` |
| R8 | The warehouse is BigQuery | important | adjacent | medium | transferability | The requirements list asks for "a cloud warehouse" and names BigQuery only in the mandate, so I scored it separately. Your dbt-on-Snowflake modelling carries over. Limit: you have not used BigQuery, including its cost and partitioning model. Tool-specific ramp-up is plausible but usually probed. | `[grounded]` your background as stated; `[generic]` that interviews probe the named stack | G1 |
| R9 | Ingestion from the app and the CRM | important | unclear | low | discovery | The JD names these sources. Nothing you said covers ingesting from a product database or CRM, so this is open, not absent. | `[grounded]` JD; your background is silent | Q2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | The JD makes contracts a named deliverable. Your background mentions no contract or schema-agreement work. Your test suite may be adjacent, but that is unconfirmed. | `[grounded]` JD; `[inferred]` that the test suite may bear on it | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | You have confirmed dbt modelling at scale on Snowflake and no BigQuery use | The warehouse is named in the mandate, so this is the likeliest probe. Making the bridge concrete narrows it | A small dbt project on BigQuery's free tier; migration or cost-tuning work you did on Snowflake; any BigQuery exposure through an analyst team | A public repo or a short write-up of a dbt-on-BigQuery project | `[grounded]` your background; `[generic]` that a named warehouse gets probed |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Your stated work covers modelling, orchestration and testing, not source ingestion | It is the first item in the mandate, so resolving it could firm up the `conditional_go` | Loading a product database via CDC or snapshots; pulling Salesforce or similar through an API or a connector; building a loader for a third-party SaaS source | An Airflow DAG with sources named, or an ingestion design note | `[grounded]` background silence; `[inferred]` from the JD's ordering that it leads the mandate |
| G3 | Data contracts (R10, important) | discovery | Nothing in your background mentions contracts or schema agreements with consumers | The JD says analysts depend on them | Schema checks at ingestion; agreed definitions with finance or analytics; alerts when an upstream change broke a downstream model | A contract doc, a schema-test config, or a Great Expectations suite tied to a consumer | `[grounded]` background silence |
| G4 | Location and pay terms (R1, R2, hard_gate) | hard_gate | No constraints given | The status stays conditional until these are checked | — | — | `[grounded]` no constraints given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees." | I could not check the entity or the live posting here. The posting may be stale, or the company's footprint may be thin; the reasons are side by side and none is more likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity unstated beyond "plus equity" | unknown | — | "Salary $148,000–$166,000 plus equity" | The equity may be a meaningful grant or a nominal one | `[inferred]` from the posting giving no grant size, type or vesting | What is the equity (type, size range, vesting, current valuation basis) for this level? | unresolved |
| RR3 | Four areas in one role | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role may fold several specialisms into one seat. The posted range is at or above the report's median, so I see no sign it is under-priced | `[inferred]` from the JD against the report's scope line; `[grounded]` posted range vs. report | How many data engineers are on the team, and who owns ingestion, modelling and contracts today? | unresolved |
| RR4 | Pay sits at or above the market median | positive_signal | — | "Salary $148,000–$166,000" | The cash band looks competitive for the title and stage | `[grounded]` JD and the pasted report | Where in the range would someone with my background land? | noted |
| RR5 | No hiring manager and no stated outcomes | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Success may be undefined or just unstated | `[grounded]` JD silence | Who would I report to, and what does success look like in the first year? | unresolved |

All five rows are proposed readings, and nothing is final until you say so.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the recruiter for the live posting link and the company's careers page, and check that the recruiter's email domain matches the company's | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead the application with the dbt project (about 180 models), Airflow and the Great Expectations suite, each stated as it was done on Snowflake. Don't claim BigQuery | R5, R6, R7, R8 | `[grounded]` the rows | pending your approval |
| A3 | Optionally build a small dbt-on-BigQuery project on the free tier. Once it exists, you could cite it; until then, don't | R8, G1 | `[inferred]` as the strengthener for the stated limit | pending your approval |
| A4 | Ask RR2, RR3 and RR5's questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

All rows above are proposals. I won't draft CV or outreach language until you approve them.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused: "Pellucid Learning Senior Data Engineer Denver online tutoring K-12 Series C". It would have checked that the company and posting exist as pasted, which feeds role reality's contradictions row and RR1. RR1 stays open |
| 2. Role-family sweep | skipped | The pasted Datawright report fixes the market calibration and the scope line in role reality, and the pay comparison in RR4 and RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'll keep the evidence file for this assessment as a `tuesday-dossier.md` if you'd like it.

## Upgrade menu

- Your location, pay floor and any must-have terms → R1 and R2 move to met or failed, and the decision firms up.
- A sanitized dbt docs or lineage screenshot, an Airflow DAG, and Great Expectations data-docs output → R3 through R7 can reach `high`.
- An answer on ingestion and contracts → R9 and R10 resolve or become named gaps.
- A link to the live posting and the recruiter's email domain → RR1 closes.
- The hiring manager's name → role reality's scope read, and which story the plan leads with.
- A deeper research pass (up to 5 more searches and 2 more fetches) would cover company funding history, hiring patterns and recent news. It needs search permission, so say the word if you want it.

**Questions**

1. R1, R2 — Where are you based, and do you have a pay floor or any must-have terms (such as remote only)?
2. R9 — Have you built ingestion from a product database or a CRM or other SaaS source? What did you own, and what did it feed?
3. R10 — Have you set up any schema agreements or data contracts with the people consuming your models, and what happened when something upstream changed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.