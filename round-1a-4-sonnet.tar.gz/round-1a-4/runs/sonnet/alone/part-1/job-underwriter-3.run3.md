I'll read the skill's reference files before building the assessment.
## Decision snapshot

**No, not as posted. R1 and R2, both hard gates, fail against your two stated constraints. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin, 5 days a week), R2 (Compensation: $70–85k base)
- `must_have`: direct: R3a, R4, R5, R7 · unclear: R3b (Leadership years), R6 (SEO/content)
- `important`: unclear: R8 (Brand, PR, partnerships), R9 (Sales ops), R10 (Operating as a team of one)

R1 and R2 — the posting's terms against your remote-only and $150k-base constraints; R7 (`medium`) — your strongest match, confirmed but uninspected.

**Opportunity ledger.** The role has problems of its own, apart from your fit: seven functions on one person at $70–85k base (RR3, RR4), always-on language (RR5), success metrics left undefined (RR6), and budget and authority unstated (RR7). Your sense that something is off is borne out by those entries, and the employer is not yet established (RR8). Against that, CEO reporting and a stated profitable history (RR9).

- **Hard gates:** failed: R1 (On-site in Austin, 5 days a week), R2 (Compensation: $70–85k base).
- **Severe red flags:** none found.
- **What would change this:** R1 and R2 would each have to change, and changing one leaves the other failing. Novaline would have to allow remote work from Portland (the posting says "no exceptions") and offer at least $150k base (the posting says $70–85k).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` JD header; the profitability claim is the employer's own and unchecked |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team | "A team of one to start" | `[grounded]` JD |
| Reporting | CEO, dotted line to the board | `[grounded]` JD |
| Location and hours | On-site in Austin five days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside", with no stated equity amount | `[grounded]` JD |
| Success measures | "Success metrics will evolve as we learn"; no first-90-days or first-year outcomes stated | `[grounded]` JD |
| Scope read | Seven functions bundled under one title and one person | `[inferred]` from the JD's responsibility list against "team of one" |
| Market calibration | Not calibrated. No role-family band is offered, and the posting's own $70–85k stands as its figure | `[grounded]` JD for the figure |
| Unknowns | Budget and decision rights; equity terms; whether customers are businesses or consumers; hiring plans after "to start" | `[inferred]` from the JD's silence |
| Contradictions | None between the posting's own statements; the careers page was not checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in the Austin office 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your statement (remote-only, in Portland, not relocating), which is your own, specific and confirmed. Fit fails because the JD rules out remote work outright and you will not be in Austin | `[grounded]` JD quote and your confirmed constraint | Only Novaline changing the term, or you revising the constraint, resolves it |
| R2 | Compensation: "$70–85k base" against your $150k base floor | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your floor, which is your own and confirmed. The top of the stated range is $65k under it. Equity is unquantified and your floor is a base figure, so it does not close the gap | `[grounded]` JD quote and your confirmed constraint | Same as R1 |
| R3a | "8+ years growth leadership required", the span of experience | must_have | direct | medium | none | You state 9 years in growth, confirmed and specific but uninspected. A length-of-experience line is not a gate | `[grounded]` your intake account | Dated roles (CV or LinkedIn export) would raise it |
| R3b | The same line, the leadership part | must_have | unclear | medium | discovery | You held Growth lead, then Head of Growth titles, but the years spent in them are not stated. Ambiguity resolves downward, so it is not counted as meeting 8+ | `[grounded]` your intake account; the years are `[inferred]` as unstated | Ask for the dates of the lead and Head roles (G3) |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid; channels, spend and results are not given | `[grounded]` your intake account | A channel spend and CAC report would raise it |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze; scale and outcomes are not given | `[grounded]` your intake account | A Braze program report would raise it |
| R6 | SEO/content | must_have | unclear | none | discovery | Your account names paid, lifecycle and experimentation but not SEO/content. Silence is not absence | `[grounded]` your account's silence | Ask about it (G4) |
| R7 | "Own all revenue growth end to end", with budget | must_have | direct | medium | none | You scaled one company from $8M to $40M ARR over three years "with a budget I controlled". The title you held through that stretch, and what share of the growth was yours as against the team's, are not stated, so any bullet should say "scaled", not "drove all" | `[grounded]` your intake account | An ARR trajectory or board update would raise it |
| R8 | Brand, PR, partnerships | important | unclear | none | discovery | Nothing in your account touches these | `[grounded]` your account's silence | Ask about it (G5) |
| R9 | Sales ops | important | unclear | none | discovery | Nothing in your account touches it | `[grounded]` your account's silence | Ask about it (G6) |
| R10 | Operating as a team of one | important | unclear | low | discovery | You built and managed teams of 3–7, and you work hands-on in SQL, GA4 and Braze. Nothing says whether you ran every channel yourself | `[grounded]` your account; the hands-on reading is `[inferred]` from the tools you named | Ask about it (G7) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | On-site five days (R1, hard_gate) | hard_gate | Posting says "no exceptions"; you live in Portland and will not relocate | Fails outright; no wording changes it | None applies | Novaline's written change of the term | `[grounded]` JD and your constraint |
| G2 | Base pay (R2, hard_gate) | hard_gate | $70–85k stated against your $150k floor | Fails outright; no wording changes it | None applies | Novaline's written change of the figure | `[grounded]` JD and your constraint |
| G3 | Leadership years (R3b, must_have) | discovery | Titles stated, years in them not | Cannot move `no_go`; it would matter only if R1 and R2 change | Dates for the Growth lead and Head of Growth stints | Dated CV or LinkedIn export | `[grounded]` intake; `[inferred]` that it cannot move the status |
| G4 | SEO/content (R6, must_have) | discovery | No mention in your account | Same | Owning organic landing pages or a content calendar; directing an agency or SEO tooling inside a subscription funnel | Organic traffic report, content roadmap | `[grounded]` intake silence |
| G5 | Brand, PR, partnerships (R8, important) | discovery | No mention in your account | Same | A partnership or affiliate deal, a press launch, a rebrand you led or contributed to | Deal summary, coverage links | `[grounded]` intake silence |
| G6 | Sales ops (R9, important) | discovery | No mention in your account | Same | Lead routing, CRM hygiene or handoff work with a sales team | A process doc, a dashboard | `[grounded]` intake silence |
| G7 | Solo operation (R10, important) | discovery | Team leadership stated, solo execution not | Same | Stretches where you ran the channels yourself, before or between teams | A dated role description | `[grounded]` intake |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | On-site five days against remote-only (R1) | red_flag | medium | "On-site in our Austin office 5 days a week — no exceptions." | Incompatible with your constraint as stated. Medium because the term is plainly stated and says nothing against the employer | `[grounded]` JD against your confirmed constraint | Is any remote or hybrid arrangement possible for this role? | confirmed |
| RR2 | Base pay against your floor (R2) | red_flag | medium | "$70–85k base" | Your floor of $150k is not met even at the top of the range | `[grounded]` JD against your confirmed constraint | Is the base negotiable beyond $85k, and what does the equity represent in percentage and vesting? | confirmed |
| RR3 | Seniority and scope against pay | risk_signal | medium | "8+ years growth leadership required"; "$70–85k base" | Seven functions and 8+ years may be priced below what the scope would normally pay. This is unchecked, since the role-family search did not run | `[inferred]` from the posting's scope against its own figure | What level and scope was this salary band set for? | unresolved |
| RR4 | Bundled specializations, team of one | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops"; "team of one to start" | Several full roles folded into one title, with no stated plan for headcount | `[inferred]` from the responsibility list against "to start" | When do you expect to hire, and into which functions? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be the norm, since "when it matters" is undefined | `[inferred]` from the phrasing | How often have evenings and weekends been needed in the last quarter? | unresolved |
| RR6 | Success metrics undefined | risk_signal | low | "success metrics will evolve as we learn" | Accountability for "all revenue growth" with no yardstick. Low because early-stage ambiguity may be stated honestly | `[inferred]` from the JD's wording | What would a good first-year outcome look like to the CEO? | unresolved |
| RR7 | Budget and decision rights unstated | unknown | — | "Own all revenue growth end to end" | The JD names ownership without naming budget or authority | `[inferred]` from the JD's silence | What budget and sign-off authority does this role hold? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR9 | CEO reporting, profitability stated | positive_signal | — | "Report to the CEO with a dotted line to the board"; "profitable since day one" | Senior access and a self-reported healthy footing; the second is the employer's own claim | `[grounded]` JD states both | How is profitability measured, and what is current runway? | noted |

Apply the verification questions only if you proceed against the status. I'm going only on what you've shared, and I can get this wrong. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted; put the effort into remote roles at your pay floor | see R1, R2 | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Optional: one inquiry to Novaline asking whether remote work and a base of at least $150k are open. State both together, since each alone leaves the other failing | see RR1, RR2; the "no exceptions" wording makes this low odds | `[inferred]` from the posting's wording | pending your approval |
| A3 | If you proceed anyway, ask RR1–RR8's questions verbatim and get terms in writing before any application effort | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | No resume edits proposed | You are not applying; R7 is the line you would lead with if terms change | `[grounded]` R7 row | pending your approval |

Nothing above is final. Each action, including the advice in A1 and A2, awaits your approval.

## Evidence status

Stage assumed: evaluating. Verified: your constraints carried by R1 and R2. Unverified: the background claims behind R3a, R3b, R4, R5, R7 and R10, which are intake prose and not inspected. Rejected inferences: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Novaline e-commerce enablement startup Austin Series A" and "Novaline careers Head of Growth Austin" were refused. It would have moved role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | Search "Head of Growth salary Series A startup base salary range" was refused. It would have moved the market calibration row, RR3 and R2's reasoning |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can save this as `tuesday-dossier.md` if you want a file to keep.

## Upgrade menu

- Search access → R1 and R2 stay failed, but RR8 and RR3 close or firm up, and role reality gets a calibrated band. A deeper pass on funding and leadership churn, hiring patterns and recent news would be up to 5 more searches and 2 more fetches, run only on your word.
- A link to the live posting on Novaline's own careers page → RR8.
- A dated CV or LinkedIn export → R3b, and R3a and R10 firm up.
- An ARR trajectory or board update, a channel spend and CAC report, a Braze program report → R7, R4 and R5 toward `high`.
- Novaline's answers on budget, equity terms and hiring plans → RR7, RR2, RR3 and RR4.
- The hiring manager's name → role reality's scope read.

**Questions:** none this turn. The two failed gates settle the status, and no answer on the other rows would move it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.