I'll read the reference files the skill points to before building the assessment.
Research is done: the live careers page matches your paste. Here is the assessment.

## Decision snapshot

**Yes, this is worth applying to, on conditions. Status: `conditional_go`.** The condition is the two gate checks below, which depend on facts about you that I don't have.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4a, R4b, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery warehouse); unclear: R10 (data contracts), R11 (ingestion from app and CRM)

R9 — a credible bridge, its limit named; R10, R11 — your background doesn't mention them, so they're worth surfacing.

**Opportunity ledger.** Pay is stated and in line with market (RR1). Team size, reporting line and on-call load are not stated (RR2). The equity terms are blank (RR3), and the funding is the company's own statement (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you are in the US or willing to be in Denver, R1; (2) the band clears your pay floor, R2; (3) BigQuery is presented as adjacent to your Snowflake work, with its limit named, never as BigQuery experience, R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016 in Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` about page, in search result |
| Posting status | Live ("Accepting applications") and word-for-word consistent with what you pasted | `[grounded]` careers page fetched |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | One domain of reporting pipelines is a normal senior scope. The posting doesn't say whether this is the only data engineer or one of a team | `[inferred]` from the mandate wording against the missing team size; `[grounded]` the Datawright report's typical scope: one domain, no direct reports |
| Market calibration | Posted $148,000–$166,000 against a base median of $151,000 and an interquartile range of $139,000–$163,500 for Senior Data Engineers at Series B–D companies. The band runs from $3,000 under the median to $2,500 over the upper quartile. "Senior" typically means 5–8 years, and the posting asks for 5+ | `[generic]` Datawright 2026 Data Engineering Pay Report, US, n=2,310, supplied by your recruiter; `[grounded]` JD for the posted figures |
| Contradictions | None between the JD and the careers page. Series C fits the report's B–D cohort | `[grounded]` careers page, about page and report |
| Unknowns | Reporting line and hiring manager (none named), team size, on-call expectations, equity terms, who led the Series C | `[grounded]` JD silence |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you are or what work authorization you hold. Confidence is none because there is no stated claim to grade | `[grounded]` JD; your message silent | Q1 below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor wasn't stated, so the posted band can't be checked against it. The band is near market (RR1) | `[grounded]` JD; your message silent | Q2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. It's specific and self-reported, with no document yet. A years requirement is graded as evidence, not as a gate | `[grounded]` your background as typed | Confirm the dates on your CV |
| R4a | Strong SQL | must_have | direct | medium | none | About 180 dbt models built and a daily SQL practice make this specific and plausible. Nothing inspectable has been seen | `[grounded]` your background as typed | Offer: a sanitized model or query sample would raise to high |
| R4b | Strong Python | must_have | direct | low | discovery | The only claim is "Python daily". It doesn't say what you built with it, so I take the lower band | `[grounded]` your background as typed | See G4 |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Specific, with no artifact yet | `[grounded]` your background as typed | Offer: a model lineage screenshot or sanitized project structure would raise to high |
| R6 | A cloud warehouse | must_have | direct | medium | none | The JD asks for "a cloud warehouse". Snowflake is one, used with your dbt project. BigQuery is named in the mandate and has its own row, R9 | `[grounded]` JD and your background | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration, which is the named tool. How much you owned isn't stated | `[grounded]` your background as typed | Confirm scope in an answer or CV bullet |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. Specific and self-reported | `[grounded]` your background as typed | Offer: a sanitized suite config or coverage summary would raise to high |
| R9 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Snowflake with dbt is the same modelling discipline. You've never used BigQuery, so its own mechanics are untested by you (see G1). BigQuery comes from the mandate line, while the requirements list asks only for "a cloud warehouse", so it sits at important | `[grounded]` JD, and your statement that you haven't used BigQuery; `[inferred]` the adjacency from your Snowflake and dbt work; `[generic]` that warehouses differ in cost and performance tuning | See G1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Your background doesn't mention contracts. The Great Expectations suite may be related, but I won't count it as contract work without your confirmation | `[grounded]` JD; your background silent; `[inferred]` possible link to the test suite | Q3 below |
| R11 | Ingestion from the app and the CRM | important | unclear | low | discovery | Your background doesn't say what source systems fed your warehouse | `[grounded]` JD; your background silent | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Bridge: six years on a dbt-modelled Snowflake warehouse carries over as modelling, testing and orchestration practice. Limit: none of BigQuery's own cost, partitioning and access mechanics has been exercised by you. Strengthener: a small dbt project run on BigQuery | The mandate names BigQuery, so expect the question in a screen | A dbt project of your own against BigQuery; any migration, cost-tuning or partitioning work on Snowflake that you could describe as comparable | A public repo or a short write-up of the BigQuery project | `[grounded]` your statement that you haven't used BigQuery; `[inferred]` bridge from Snowflake work; `[generic]` that the question is likely in screens for a named stack |
| G2 | Data contracts (R10, important) | discovery | No mention in your background | The contracts are one of the JD's named deliverables | Agreed schemas or SLAs with upstream teams; a test suite analysts relied on; dbt model contracts or versioning; a process for announcing breaking changes | A sanitized schema agreement, a contract doc, or a test-suite README | `[grounded]` JD; your background silent |
| G3 | App and CRM ingestion (R11, important) | discovery | No mention of source systems. Not asked this turn | Ingestion is the first item in the mandate | Loading from an application database or event stream; CRM syncs; managing connectors or custom loaders | An ingestion DAG outline or architecture sketch | `[grounded]` JD; your background silent |
| G4 | Python depth (R4b, must_have) | discovery | "Python daily" only. Not asked this turn | A must-have held at the lower band | DAG code, custom operators, loader scripts, test tooling | A sanitized code sample | `[grounded]` your background as typed |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated, and seniority and pay line up with the market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Transparent pay in a band that spans the report's median and upper quartile, with 5+ years matching the report's usual seniority range | `[grounded]` JD for the figures; `[generic]` Datawright report band and seniority range | Where in the band would an offer land for my experience? | noted |
| RR2 | Team, reporting line and on-call load unstated; no hiring manager named | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the sole data engineer owning ingestion through contracts, or one of a team. "Run" may carry on-call duty | `[inferred]` from the mandate wording against the missing team and reporting details | Who would I report to, how large is the data team, and what is the on-call expectation? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | The value depends on grant size, vesting and strike terms, none of which the posting gives | `[inferred]` from the posting's silence | What is the equity grant for this level: amount, vesting schedule and strike? | unresolved |
| RR4 | Funding and headcount rest on the company's own statements | unknown | — | "Series C ($52M, February 2026)" | I could not check the round or headcount outside the company's own pages | `[grounded]` about page only, no outside check | How is the data team's hiring plan tied to the Series C? | unresolved |

## Application plan

These are proposals. Nothing below is final until you approve it, and that covers the positioning advice as well as the resume edits.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your resume with the dbt project, stating that you built it and that it's about 180 models on Snowflake, and with the Great Expectations suite as one you set up | R5, R8: your two strongest, most specific rows, matched to the JD's named requirements | `[grounded]` R5, R8 rows | pending your approval |
| E2 | State BigQuery honestly in the cover note: "dbt on Snowflake, not yet BigQuery", with the modelling that carries over. No BigQuery claim anywhere | R9, G1: naming the limit first reads stronger than being found out | `[grounded]` R9 row | pending your approval |
| W1 | A small dbt project run on BigQuery, public or sanitized | Narrows the one adjacent row. Only worth doing if you want it | `[grounded]` R9, G1 | pending your approval |
| Q1 | Ask the questions of RR2, RR3 and RR4 verbatim in a recruiter or hiring-manager screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Check your floor against the posted band before spending effort. The band is near the report's median, so negotiation room may sit in the upper half | R2, RR1 | `[generic]` report figures, not this employer's flexibility | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). It confirmed the posting is live and matches your paste. Role reality's posting-status and contradictions rows moved; no failed-attribution entry is needed |
| 2. Role-family sweep | skipped | Your pasted Datawright report already holds the pay band and typical scope. It fixes market calibration and the pay comparison in RR1, so a search would change neither |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## Upgrade menu

- Your location, work authorization and pay floor close R1 and R2, which are the two unconfirmed gates.
- A dbt model lineage screenshot, a sanitized Great Expectations suite or a sanitized sample query raises R5, R8 and R4a to `high`.
- An answer on contracts or ingestion resolves R10 and R11, and may move them to `direct`.
- A BigQuery sample project, or a short write-up of one, narrows R9.
- A hiring manager's name, if the recruiter has one, would feed the scope read and the positioning in the application plan.
- A deeper research pass on Pellucid Learning (the Series C investors, leadership changes, public employee reports; up to 5 more searches and 2 more fetches) would address RR4. Say the word and it runs.

I can write all of this up as `tuesday-dossier.md` whenever you want it.

**Questions**

Q1 (R1): Are you based in the US with the right to work there, or would you move to Denver? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q2 (R2): What is your pay floor, and does $148,000 at the bottom of the band clear it? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Q3 (G2, R10): At your payroll company, did you set up agreed schemas, SLAs or checks that analysts relied on, and what did you own in that? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.