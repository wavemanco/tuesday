I'll read the reference files first, since the skill requires them before building the map.
**Yes, apply, on conditions. Status: `conditional_go`.** Your 4+ years, SQL/Python, GLM and presenting requirements all land `direct` (R2, R3, R4, R10). Pet insurance and "design" of price tests are the soft spots (R12, R7). Separately, I couldn't check the employer (RR1).

Research was blocked: the host didn't grant search permission, so none of the three searches ran. Everything below comes from the JD and your own account. Your CV wasn't supplied, so your background is treated as self-report.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R8, R10 · unclear: R7 (Design price tests)
- `important` — unclear: R9 (Recommendations for product)
- `preferred` — direct: R11 · adjacent: R12 (Pet-insurance domain)

R7 — "ran" doesn't settle "design"; R9 (`none`) — product audience has no evidence yet; R12 (`medium`) — a credible bridge, its limit named.

**Opportunity ledger.** The scope is concrete (RR5), but the employer and live posting are unchecked (RR1), pay is not stated (RR2), and the role's decision rights and team shape are unknown (RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify — RR1; (2) you confirm you can work fully remote from the UK — R1; (3) the pet-insurance gap is framed as a bridge from motor, never as pet experience — R12.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; existence and live posting not checked | `[grounded]` JD header; `[grounded]` searches refused this run |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing; no footprint reviewed | `[grounded]` your message |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Seniority and scope read | "Senior" is tied to 4+ years of experience. The JD names no direct reports and no management requirement | `[inferred]` from the JD's requirements list, which omits management |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Stage | Evaluating, assumed because you asked whether to apply | `[inferred]` from your question |
| Market calibration | Not done, since the role-family sweep was refused. I offer no pay band rather than one from memory | `[grounded]` this run's research log |
| Unknowns | Salary, contract basis, decision rights, team size, whether the role has reports | `[grounded]` JD silence |
| Contradictions | None visible between the JD and your account; the JD was not cross-checked against a careers page | `[grounded]` inputs compared |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You didn't state your location or constraints. A UK employer's pricing team is indirect context only | `[grounded]` JD term; your own statement is missing | Gate question in the closing block |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, 2 as senior analyst. Self-reported, CV not seen | `[grounded]` your account | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated, but "strong" is self-assessed and nothing is inspectable yet | `[grounded]` your account | A sanitized notebook or query set would raise it to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book | `[grounded]` your account | Sanitized model documentation would raise it to high |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" is stated. Monitoring is implied by maintenance, not stated, so I take the lower reading | `[grounded]` your account | none |
| R6 | Read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team | `[grounded]` your account | A test read-out deck would raise it to high |
| R7 | Design price tests | must_have | unclear | low | discovery | "Ran" doesn't say whether you set the design (hypotheses, sample sizes, test and control). I resolve downward | `[grounded]` your wording; `[inferred]` that running 14 tests likely involved design, unconfirmed | See G1 |
| R8 | Recommendations to underwriting | must_have | direct | medium | none | The 14 tests were run with the underwriting team, and you present the quarterly review to its head | `[grounded]` your account | none |
| R9 | Recommendations to product | important | unclear | none | discovery | Nothing in your account touches a product audience | `[grounded]` your account's silence | See G2 |
| R10 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting | `[grounded]` your account | none |
| R11 | Insurance experience (a plus) | preferred | direct | medium | none | 5 years at a UK motor insurer | `[grounded]` your account | none |
| R12 | Pet-insurance domain, not asked for by the JD but the product is pet insurance | preferred | adjacent | medium | transferability | Motor GLM pricing carries over as method. Limit: you haven't priced pet risk. Pet pricing typically turns on different rating factors, such as species, breed, age and vet-cost trends | `[inferred]` requirement from the JD's product; `[generic]` on how pet and motor rating differ | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Designing price tests (R7, must_have) | discovery | You ran 14 tests with underwriting; who set the design is unstated | A must-have where "design" is named explicitly; settling it could lift R7 to `direct` | Choosing test and control cells, sizing a sample, setting success metrics, a pre-agreed readout rule | A test plan, a readout deck, a methodology note | `[grounded]` your wording; `[generic]` that roles like this probe the design half |
| G2 | Recommendations to product (R9, important) | discovery | No product audience appears in your account | The JD names product as a second audience | A pricing finding that changed a product feature, a tier or an excess; a proposal to a product owner | A deck or email thread, sanitized | `[grounded]` account silence |
| G3 | Pet-insurance domain (R12, preferred) | transferability | Motor GLM method, no pet exposure | It is the product you'd price, and the bridge needs its limit stated | Rating factors you've modelled that behave like pet ones (age bands, claim frequency and severity); any exposure to health or other non-motor lines | Sanitized model documentation | `[inferred]` bridge from motor GLM work; `[generic]` that pet rating differs from motor |
| G4 | UK-remote gate (R1, hard_gate) | hard_gate | Location and right to work are not stated | A gate the inputs don't settle stays open until you answer | Not applicable; it is a yes or no | None | `[grounded]` inputs silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. No check was possible here, because search was not granted | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (no salary in the JD as pasted) | The figure may or may not fit your expectations; no band was gathered | `[grounded]` JD silence | What salary range is budgeted for this role? | unresolved |
| RR3 | Ownership of pricing without stated decision rights | unknown | — | "Own pricing analytics ... turn the results into recommendations for underwriting and product" | The role may recommend while rating changes are decided elsewhere | `[inferred]` from "recommendations" against the JD's silence on who decides | Which pricing changes does this role decide, and which go to underwriting or product to approve? | unresolved |
| RR4 | Team shape and reports unstated | unknown | — | "Senior Pricing Analyst" | The role may be an individual contributor, or may carry reports. You haven't managed anyone | `[grounded]` JD silence | Who else sits in pricing, and does this role have direct reports now or planned? | unresolved |
| RR5 | Concrete, named outputs | positive_signal | — | "build and monitor rating models, design and read price tests" | The mandate is specific, with named stakeholders | `[grounded]` JD | What would success look like in the first year? | noted |

## Application plan

`resume_edits_pending_approval` — each line stays within your own words:

| # | Current framing | Proposed line | Provenance |
|---|---|---|---|
| E1 | (CV not seen) | "Built and maintained the GLM rating model for the young-driver motor book" | `[grounded]` "Built and maintained the GLM rating model for our young-driver book" |
| E2 | (CV not seen) | "Ran 14 price tests with the underwriting team last year" | `[grounded]` "Ran 14 price tests last year with the underwriting team" |
| E3 | (CV not seen) | "Present the quarterly pricing review to the head of underwriting" | `[grounded]` your account |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the role on Brindlemoor's own careers page, and note the recruiter's email domain, before investing effort | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Confirm to yourself the UK-remote gate before applying | See R1 | `[grounded]` R1 | pending your approval |
| P1 | In a cover note, lead with the motor GLM model, the 14 tests and the quarterly review. Say plainly that pet insurance is a new line for you and that you bring the method, not pet-specific rating experience | See R12; the limit is stated, not hidden | `[grounded]` your account; `[inferred]` framing | pending your approval |
| Q1 | Ask RR2, RR3 and RR4 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | If asked about management, say you haven't line-managed anyone, and ask RR4 | Your own fact, stated plainly | `[grounded]` your account | pending your approval |

## Evidence status

Verified: none yet. All claims are your prose account, CV not seen, so each is a lead for confirmation.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst"; the call was refused. It would have moved RR1 and role reality's organization and contradictions rows |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary remote"; the call was refused. It would have moved market calibration and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have moved the scope read and P1's positioning for that reader |

I'll offer a one-off extra, labeled as beyond the spec: a short cover-note draft built only from E1 to E3 and the R12 bridge, if you want it.

I can write `tuesday-dossier.md` from this assessment whenever you want it.

**Upgrade menu**

- The Brindlemoor careers-page link, or the posting text from their site: RR1 and the contradictions row can be checked from your paste with no search spent. Only 2 of L1's 5 searches remain, so if you grant search I'd spend them on the salary band and the employer, not Odile.
- Your pay floor and your UK location and right-to-work: R1 closes, and a pay check against RR2 becomes possible.
- A sanitized test plan or readout deck: R6 and R7 rise toward `high`.
- Sanitized GLM documentation or a notebook: R3 and R4 rise toward `high`, and G3's bridge sharpens.
- Odile Varga's public talks or writing, if you have any: P1's positioning could be tuned to that reader.

**Questions**

G4 — Are you UK-based and able to work fully remote from there, and is there anything else about location or pay you'd treat as a dealbreaker?
G1 — On the 14 price tests, what did you personally set: the test and control cells, the sample size, the success rule, or the readout? Who else decided?
G2 — Have you ever taken a pricing finding to someone outside underwriting, such as a product owner, and did it change anything?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.