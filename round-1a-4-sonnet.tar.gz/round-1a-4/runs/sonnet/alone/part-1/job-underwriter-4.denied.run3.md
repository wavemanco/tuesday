I'll read the reference files the skill points to before building the assessment.
**Yes, go for it, on conditions. Status: `conditional_go`.** Your background lands `direct` on R2, R3, R4, R5a and R6. Neither "never worked on pet insurance" nor "never managed anyone" is a gate: R9 is an `adjacent` preferred row, and the JD lists no line-management requirement. What stops this being a plain `go` is that the employer is unchecked (RR1) and the UK-remote term is unconfirmed (R1).

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5a, R6 · unclear: R5b (Design price tests)
- `important` — unclear: R7 (Recommendations to product)
- `preferred` — direct: R8 · adjacent: R9 (Pet insurance domain)

R5b — "ran" is not yet "designed", and one answer settles it; R9 — an adjacent bridge, its limit named; R1 — unconfirmed, not failed.

**Opportunity ledger.** The employer is unchecked because search did not run (RR1), pay is unstated (RR2), and the JD is silent on reports and rate-change sign-off (RR3, RR4). One entry runs the other way: the JD names concrete responsibilities that match your work (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm the UK-remote term, R1; (2) Brindlemoor and the live posting verify on its own careers site, RR1; (3) the pet bridge is framed as adjacent, never as pet-insurance experience, R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, described as an insurtech with a pet-insurance product; its existence and the live posting are not checked | `[grounded]` JD header; research unavailable (see Evidence status) |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Hiring manager is Odile Varga, Director of Pricing | `[grounded]` your message |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| First-year outcomes | Not stated. The JD's verbs point to taking over model monitoring and delivering test readouts | `[inferred]` from "build and monitor" and "design and read" |
| Scope read | One product, a Director as manager, a 4+ year floor against your 5. No line management is required, and whether the post has reports is unknown (RR3) | `[inferred]` from the title, the years floor and the JD's silence on reports |
| Market calibration | Not run. No salary band and no title or seniority norm, because search was refused | `[generic]` none available |
| Unknowns | Salary; reports; who signs off rate changes; what test infrastructure exists | `[grounded]` JD silence |
| Contradictions | None inside the pasted JD; there is no careers page to compare it with | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You gave no location or right-to-work statement. A UK motor insurer employer is indirect context only, so this is not established, and not failed | `[grounded]` JD term; `[inferred]` UK base from your UK employer | G1: one question on whether the gate is met |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst, against a 4+ floor. Prose only, nothing inspectable. A years requirement is not a gate | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily". Use is confirmed. "Strong" has no artifact yet | `[grounded]` your message | A sanitised notebook or query set would raise to high |
| R4 | GLM experience; build and monitor rating models | must_have | direct | medium | none | "Built and maintained the GLM rating model for our young-driver book". The scope is that one book, and it is carried as such | `[grounded]` your message | A sanitised model spec or validation note would raise to high |
| R5a | Run and read price tests | must_have | direct | medium | none | "Ran 14 price tests last year with the underwriting team". Read-out ownership is not stated, so "ran" stays "ran" | `[grounded]` your message | none |
| R5b | Design price tests (what to test, how groups are split, run length) | must_have | unclear | low | discovery | "Ran" does not say who designed them. Ambiguity resolves downward | `[grounded]` your message, silent on design | G2 |
| R6 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | "I present the quarterly pricing review to the head of underwriting" | `[grounded]` your message | none |
| R7 | Recommendations that reach product, not only underwriting | important | unclear | low | discovery | Underwriting is evidenced through R6; nothing in your message touches product | `[grounded]` your message, silent on product | G3 |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your message | none |
| R9 | Pet-insurance domain (implied by the product, not a stated requirement) | preferred | adjacent | medium | transferability | You confirm no pet work. The bridge is personal-lines GLM rating and testing. Limit: none of it exercised pet-specific rating factors such as species, breed and age | `[grounded]` your statement; `[generic]` that pet rating uses such factors | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK-remote term (R1, hard_gate) | hard_gate | The JD says fully remote (UK). You haven't said where you are based or your work status | A gate is met or not, and wording cannot change it | None needed; this is your own statement | None | `[grounded]` JD term and your silence on it |
| G2 | Test design ownership (R5b, must_have) | discovery | 14 tests run with underwriting, but not who chose the cells, the split, the run length or the readout threshold | The JD says "design and read". A confirmed design role makes R5b `direct` | Choosing which segments or price points to test; setting the holdout or split; deciding run length or the uplift-versus-loss-ratio threshold; writing the readout | A sanitised test plan, a test log or a readout deck | `[grounded]` your message; `[generic]` that "design" in pricing-test roles usually covers these steps |
| G3 | Reach beyond underwriting (R7, important) | discovery | The review audience is underwriting. Product is not mentioned | The JD names product as a recipient of recommendations | A result that shaped a product feature, a discount structure, a renewal rule or a new tier; a readout to commercial or finance | A recommendation memo or a deck | `[grounded]` your message and the JD |
| G4 | Pet domain (R9, preferred) | transferability | Adjacent: you built and maintained a GLM for a personal-lines motor book. Limit: no pet rating factors, claims patterns or vet-cost trends | A preferred row, so it is a framing risk rather than a blocker. Strengthener: a short note on which of your motor factors would map across and which would not | Nothing to recall; this needs a bridge note, not an answer | A sanitised mapping of your model's factors | `[inferred]` adjacency from your motor GLM; `[generic]` pet vs motor factor differences |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. I could not check, because search was refused, so this records an unchecked employer and not a finding | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` the search was refused | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay unstated | unknown | — | No compensation appears in the JD you pasted | The figure may sit outside what your 5 years warrant, or the posting may simply not publish it. No floor from you and no market band, so I can't compare | `[grounded]` JD silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Reports and team unstated | unknown | — | "Senior Pricing Analyst… Own pricing analytics" | "Own" may mean sole ownership of pet pricing analytics, and the post may or may not carry reports | `[inferred]` from "Own" against the JD's silence on team | Who else works on pricing for this product, and does this post have or expect direct reports? | unresolved |
| RR4 | Authority over rate changes unstated | unknown | — | "turn the results into recommendations for underwriting and product" | The role may produce recommendations while others decide, and the test and model tooling is unknown | `[inferred]` from "recommendations" against silence on decision rights | Who decides on rate changes, and what test and model tooling does the team use today? | unresolved |
| RR5 | Responsibilities are concrete and match your work | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is defined at task level and maps closely onto what you do | `[grounded]` JD against your message | What would a successful first year look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before investing in an application, find Brindlemoor and this posting on its own website and use the contact details there | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with your GLM model for the young-driver book and your 14 price tests with underwriting, in the terms you gave me ("built and maintained", "ran") | R4, R5a | `[grounded]` your message | pending your approval |
| A3 | Say plainly that you are a motor pricer and new to pet. Don't imply pet experience | R9 | `[grounded]` your statement | pending your approval |
| A4 | Don't claim or imply line management. If asked, say you haven't managed anyone | RR3; JD silent on management | `[grounded]` your statement and the JD | pending your approval |
| A5 | Use the quarterly pricing review as the example for a pricing director, since it matches the JD's presenting duty | R6 | `[inferred]` from the hiring manager's title | pending your approval |
| A6 | Ask RR2's pay question early, and RR3 and RR4's questions verbatim in interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Every row above, and any wording advice in it, is `resume_edits_pending_approval`. Nothing is final until you approve it. I've drafted no CV lines yet because I haven't seen your CV.

## Evidence status

Verified: none yet. Claims so far come from your message, which has CV-equivalent standing and is capped at `medium`. Unverified leads: none.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst". The call was refused (search permission not granted). It would have fed the organization row, the contradictions row and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK salary remote pet insurance". The call was refused. It would have fed market calibration and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor". The call was refused. It would have fed the scope read and A5 |

I'll write this up as a `tuesday-dossier.md` for you to keep, if you want it.

**Upgrade menu**

- Your CV → I can draft truthful repositioning lines for approval, each traced to your words.
- A sanitised model spec or validation note → R4 to `high`.
- A sanitised notebook or query set → R3 to `high`.
- A sanitised test plan or readout deck → R5a to `high`, and R5b resolved.
- Your answers to G1–G3 → R1, R5b and R7 move, and the conditions narrow.
- Search permission → I can use the remaining 2 searches and 2 fetches on the employer check (RR1) and the salary band (RR2).
- Your pay floor → RR2 can be compared against it.

**Questions**

G1 — Are you based in the UK and able to work for a UK employer, fully remote, without needing sponsorship?

G2 — On the 14 price tests, which parts of the design (what was tested, how the groups were split, how long it ran, how the result was read) were yours, and which were set by others?

G3 — Have you taken a pricing result to anyone beyond underwriting, such as product, commercial or finance, and what decision came of it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.