I've read the underwriter's rules and the worked report format. Next I'll load the search tool and check that Harborlight Health exists as described, then write the assessment.
# Job Underwriting Assessment — Senior Product Analyst, Harborlight Health

## Decision snapshot

**Yes, apply. On the evidence you gave, you are a fit for the core of this role (R1, R2, R3, R4, R6 are `direct`). Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · unclear: R5 (Define and maintain the metrics layer)
- `important` — direct: R7a · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R10 (Healthcare data experience, HIPAA)

R5 — likely to resolve on one answer; R7b, R8 — nothing recorded yet, which is not the same as absent; R10 (`medium`) — a bridge with its limit named.

**Opportunity ledger.** The posting's scope is concrete (RR3). Two things are open: I could not verify the employer or the live posting (RR1), and pay and work location are not stated (RR2).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Harborlight's own careers page (RR1); (2) your metrics-layer work is confirmed as semantic-layer ownership (R5); (3) the healthcare bridge is framed as adjacent, never as healthcare experience (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health: digital-health scale-up, about 400 people, Series C, care-navigation app | `[grounded]` JD header; not independently verified (RR1) |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, roadmap partnership with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Requirements | 5+ years product analytics, expert SQL, experiment design at scale, Looker or similar, written communication with non-technical stakeholders; HIPAA experience is a plus | `[grounded]` JD |
| Scope read | A senior individual-contributor post with light line leadership: two juniors to mentor, no stated budget or headcount authority | `[inferred]` from "mentor two junior analysts" against the JD's silence on reports or budget |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Unknowns | Pay, location or remote policy, work-authorization terms, hiring manager, who owns the metrics layer today, size of the experiment program | — |
| Contradictions | None found within the JD; no external page was read to compare it against | `[grounded]` JD only |
| Market calibration | Not produced: the role-family sweep did not run, so no pay band or title norm is claimed | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company. This is a length-of-experience requirement, not a gate. Self-reported and unprobed, so `medium` | `[grounded]` your background as typed | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on a Snowflake warehouse over six years. "Expert" is a level you would be judged on in a live exercise; expect a technical screen | `[grounded]` your background as typed; `[generic]` that senior analytics loops usually test SQL live | A sanitized query sample would raise to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran a 30+ tests-per-year program, including the pricing test behind an 11% retention lift. Limit: "at scale" is measured against Harborlight's traffic, which is unknown, and the 11% will be probed for method and attribution | `[grounded]` your background as typed | A sanitized experiment write-up or readout would raise to high |
| R4 | Looker or similar BI tool; self-serve dashboards | must_have | direct | medium | none | You built the Looker instance from scratch with 40+ governed dashboards, which is the JD's named tool | `[grounded]` your background as typed | A sanitized screenshot or LookML excerpt would raise to high |
| R5 | Define and maintain the metrics layer | must_have | unclear | low | discovery | Governed Looker dashboards and a monthly metrics memo suggest you defined metrics, but you did not say you owned the semantic layer, its definitions and its change control | `[inferred]` from the governed dashboards and the metrics memo; `[grounded]` that the layer itself is not described | Closing question R5 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present monthly to the VP Product. The memo is an inspectable artifact if you share a sanitized copy | `[grounded]` your background as typed | A sanitized memo would raise to high |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | Monthly presentations to the VP Product are confirmed. Limit: roadmap influence at PM level is not described | `[grounded]` your background as typed | none |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in your background mentions clinical or other domain-expert stakeholders. This may be unrecorded rather than absent | `[grounded]` background silence | Offer a recall prompt in the gap queue, G2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Your background does not mention mentoring or managing analysts | `[grounded]` background silence | Closing question R8 |
| R10 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You handled GDPR and CCPA consumer PII and built the consent-state model for the warehouse, so you have governed-sensitive-data discipline. Limit: no protected health information and no HIPAA obligations. A preferred item, not a blocker | `[grounded]` your stated PII and consent-model work; `[generic]` that PII regimes and HIPAA differ in scope and obligations | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R5, must_have) | discovery | Governed Looker dashboards, but no statement of who defined and maintained the metric definitions | A `must_have` at `unclear`; a specific answer likely moves it to `direct` | LookML or dbt metric definitions you wrote; a metrics dictionary; a change process for redefining a metric; resolving conflicting numbers between teams | A metrics dictionary excerpt, a LookML file excerpt, a definitions doc | `[grounded]` background silence on the layer; `[inferred]` that this likely resolves to direct |
| G2 | Clinician partnership (R7b, important) | discovery | No domain-expert stakeholders recorded | The JD names clinicians as partners; a close analogue would give a bridge | Working with a nutrition, culinary, food-safety or ops specialist on a metric or test; a domain expert who challenged an analysis | A project note or readout naming the partner | `[grounded]` background silence; `[inferred]` that an analogue may exist |
| G3 | Healthcare data (R10, preferred) | transferability | Consent-state model and GDPR/CCPA PII handling | Adjacent evidence, with the limit stated: no PHI and no HIPAA. The strengthener is a short, honest account of what the consent model enforced and how access was governed | The consent model's design and the controls around it | A sanitized design note | `[grounded]` your PII and consent-model claim; `[generic]` that HIPAA obligations differ from consumer-privacy regimes |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The company may be real and simply not yet checked; the posting may be stale or aggregated; or the posting may not represent a real hiring employer. No reason is more likely than another | `[generic]` pattern for any employer not yet checked, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Pay and work location not stated | unknown | — | "Senior Product Analyst — Harborlight Health" | The pasted text carries no salary, location or remote policy. A posting may withhold them, or the pasted copy may have dropped them | `[grounded]` the pasted JD's silence; `[generic]` that postings sometimes omit these | What is the salary range for this role, and is it remote, hybrid or on-site? | unresolved |
| RR3 | Responsibilities are specific and measurable | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | The scope is concrete and fits one coherent analytics role | `[grounded]` JD | Which product areas does this role cover first, and what does success look like at 12 months? | noted |

## Application plan

Every row below is proposed. Nothing, including the positioning advice in the Why column, is finalized until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the experimentation program: 30+ tests a year, and your own role in the pricing test | R3 is your strongest `must_have` row. State what you owned, the test design and the measurement method, so the 11% survives a probe | `[grounded]` R3 row | pending your approval |
| E2 | Describe the Looker work as a governed instance you built from scratch with 40+ dashboards; add metrics-layer language only if G1 confirms it | R4 is `direct`, R5 is not yet | `[grounded]` R4 and R5 rows | pending your approval |
| E3 | Frame healthcare as adjacent: "consent-state model for the warehouse under GDPR and CCPA". Do not say healthcare experience, HIPAA experience or handling health data | R10 is `adjacent`, with no PHI and no HIPAA in your history | `[grounded]` R10 row | pending your approval |
| A1 | Confirm the posting on Harborlight's own careers page before investing in a tailored application | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR1, RR2 and RR3 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the call was refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range experimentation Looker"; the call was refused. It would have moved the market-calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier and upgrade menu

I can write all of this to `tuesday-dossier.md` if you'd like to keep it or carry it into a later step.

- Your CV or a prior resume → R1 through R4 and R6 confirmed against a document; gaps between CV and prose surface.
- A sanitized metrics dictionary or LookML excerpt → R5 resolves, probably to `direct`.
- A sanitized monthly metrics memo → R6 to `high`.
- A sanitized experiment readout for the pricing test → R3 to `high`.
- A sanitized SQL sample → R2 to `high`.
- Permission to run web search → targets 1 and 2 run: it would confirm that Harborlight exists and the posting is live (RR1) and calibrate pay against the market (RR2).
- The hiring manager's name → role reality's scope read and which story the plan leads with.
- Your constraints (location, pay floor, work authorization) → the hard-gates line is checked against them instead of marked unknown.

**Questions** (all optional; skipping is an answer)

1. R5 — Have you personally defined and maintained the metric definitions behind the Looker dashboards (LookML, a metrics dictionary, or a review process for changing a metric)? What did you own?
2. Constraints — Do you have a location, remote, pay-floor or work-authorization requirement for this move?
3. R8 — Have you mentored, onboarded or reviewed the work of junior analysts? What did you do and for how long?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.