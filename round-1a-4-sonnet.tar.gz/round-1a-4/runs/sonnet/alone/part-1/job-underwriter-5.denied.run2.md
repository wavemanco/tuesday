I'm working through the underwriting skill. I've read its rules and am now checking that the posting and company are live and match what you pasted. After that comes the assessment.
# Job Underwriting Assessment — Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Yes, it's worth applying for, on the conditions below (RR1, R1, R2, R9). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (US remote or Denver office), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery, the posting's named warehouse); unclear: R10 (data contracts analysts depend on), R11 (ingestion from app and CRM)

R9 (`medium`) — a credible bridge from Snowflake, its limit named; R10, R11 — your background is silent on them, so they call for a question, not a verdict.

**Opportunity ledger.** The role is concrete and openly paid (RR5, RR6). I couldn't check the employer from here (RR1), and the reporting line and team shape are unknown (RR2, RR3). The equity is unquantified (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (US remote or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify (RR1); (2) your location, work authorization and pay floor fit the posting's terms (R1, R2); (3) BigQuery is framed honestly as adjacent, never as experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about-page text you pasted; I could not check it against the live page (see Evidence status) |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts rely on | `[grounded]` JD |
| Requirements | Must-have tier: 5+ years, SQL and Python, dbt, a cloud warehouse, Airflow or similar, data quality testing. BigQuery appears only in the responsibilities, so I tiered it `important` as an inferred requirement | `[grounded]` JD; `[inferred]` for R9's tier |
| First 90 days / first year | Not stated | `[grounded]` JD silence |
| Scope read | One domain (reporting pipelines from source to analyst), no direct reports mentioned. This is an ordinary-sized senior post | `[inferred]` from the JD's scope against the report's typical scope |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500; "Senior" typically means 5–8 years, owning one domain's pipelines with no direct reports. The posting's $148,000–$166,000 starts $3,000 under that median, midpoints at $157,000 and tops out $2,500 above the upper quartile. Your 6 years sits inside the typical span. That is the market's band, not this employer's offer | `[generic]` Datawright 2026 report (n=2,310) as sent by your recruiter; `[grounded]` JD for the posting's figure |
| Unknowns | Hiring manager and reporting line; team size and on-call; equity terms; whether the range applies equally to remote and Denver | `[grounded]` JD and your note that no manager is named |
| Contradictions | None between the two passages you pasted. Neither could be checked against the live pages | `[grounded]` pasted text; live checks refused |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | US-based remote, or work from the Denver office | hard_gate | unclear | none | hard_gate | The posting's term is known; you haven't told me where you live or your work authorization, so the gate is neither met nor failed. Confidence is `none` because there's no statement of yours to grade | `[grounded]` JD term; no candidate statement | Question G4 |
| R2 | Salary $148,000–$166,000 plus equity, against your pay floor | hard_gate | unclear | none | hard_gate | Pay is stated and your floor isn't, so I can't call it met. RR5 sets the figure against the market band | `[grounded]` JD figure; no candidate statement | Question G4 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It's a self-report with nothing inspectable behind it, so expect a probe | `[grounded]` your account | Share dated roles (CV) to firm up |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use. "Strong" has nothing inspectable behind it yet | `[grounded]` your account | A shareable code sample or repo excerpt would raise it to `high` |
| R5 | dbt | must_have | direct | medium | none | You built your company's dbt project, about 180 models, on Snowflake. The posting's dbt runs on BigQuery, which is tracked in R9 | `[grounded]` your account | A sanitized dbt docs or lineage page would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the requirement as worded is "a cloud warehouse". BigQuery specifically is split out to R9 | `[grounded]` your account and JD wording | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You used Airflow for orchestration | `[grounded]` your account | A sanitized DAG file would raise it to `high` |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the company's Great Expectations suite. What it covered is unstated | `[grounded]` your account | A suite config or data-docs excerpt would raise it to `high` |
| R9 | BigQuery, the posting's named warehouse | important | adjacent | medium | transferability | Same kind of system (SQL cloud warehouse with dbt on top). Limit: you've never used BigQuery, so its pricing model and table-design features are untested by you. Those features differ from Snowflake's | `[inferred]` adjacency from your Snowflake and dbt work; `[generic]` that the two warehouses differ in these features | See G1 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Your background doesn't mention contracts. The Great Expectations suite is nearby, but a test suite is not a contract between producer and consumer | `[inferred]` from the GE work against your silence on contracts | Question G2 |
| R11 | Ingestion from the app and the CRM | important | unclear | low | discovery | Airflow pipelines imply ingestion work, but you haven't said what the sources were | `[inferred]` from the Airflow use | Question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Strong dbt and Snowflake work; no BigQuery use | It's the one named stack item you haven't touched, and the posting names it in the responsibilities, not the requirements list | Any Snowflake work with partitioning, clustering or cost tuning; side work on BigQuery's free tier or public datasets | A small dbt-on-BigQuery project, if you choose to build one (proposed in the plan, pending your approval) | `[grounded]` your "never used BigQuery"; `[generic]` that cost-model and table-design differences are the usual probe |
| G2 | Data contracts (R10, important) | discovery | No mention in your background | The posting names contracts as something analysts depend on, so it's central to the role | An agreed schema or expectations between a producing team and downstream analysts; breaking-change alerts; versioned source schemas | A schema spec, a contract doc, or GE expectations that gated a source | `[grounded]` your background's silence |
| G3 | Ingestion from app and CRM (R11, important) | discovery | Pipelines implied, sources unstated | Ingestion from these two source types is the first listed job | Pulling product-event data or CRM objects into a warehouse; handling API limits, schema drift or backfills | A sanitized DAG or ingestion design note | `[grounded]` source types not stated |
| G4 | Location, authorization and pay floor (R1, R2, hard_gate) | hard_gate | None of your constraints given | These are terms you meet or don't. If one fails, no strength elsewhere fixes it | Not applicable | None needed — your own statement | `[grounded]` constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states. Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The company may be well established and my checks simply didn't run. Other possibilities: the posting may be stale or aggregated, or it may not represent a live hiring employer. None is more likely than another from here | `[generic]` pattern for failed attribution, not a claim about this company | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Reporting line and team seat unknown | unknown | — | You noted: "The posting names no hiring manager." | The data team's size and where this role sits are unknown | `[grounded]` your note and the JD's silence | Who would I report to, and where does the data team sit? | unresolved |
| RR3 | Run duties and team shape unspecified | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | "Run" may mean on-call or incident duty, and the role may be the sole owner of these pipelines | `[inferred]` from "build and run" against the JD's silence on team and on-call | How many engineers own these pipelines today, and is there an on-call rotation? | unresolved |
| RR4 | Equity unquantified | unknown | — | "Salary $148,000–$166,000 plus equity." | The equity's value depends on terms the posting withholds | `[inferred]` from the JD naming equity without terms | What is the equity (instrument, grant range, vesting) and how is it valued? | unresolved |
| RR5 | Pay disclosed and in line with market | positive_signal | — | "Salary $148,000–$166,000 plus equity." | The range is stated openly and sits in the market's middle-to-upper band, so there's no seniority-pay mismatch | `[grounded]` JD figure; `[generic]` Datawright band | Where in the range would an offer for my experience land, and does it differ between remote and Denver? | noted |
| RR6 | Specific, bounded scope | positive_signal | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The role names its stack and deliverables, which matches the report's one-domain ownership. It gives no success metrics, so I can't call the scope fully defined | `[inferred]` from the JD scope against the report's typical scope | What does success look like at twelve months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before applying, open the careers and about pages at pellucidlearning.com yourself. Confirm the posting is live and matches your pasted text, and that whoever sent you the posting writes from the company's own domain | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with the dbt project and the Great Expectations suite, in your own words (edits below) | see R5, R8 | `[grounded]` your account | pending your approval |
| A3 | Say plainly that your warehouse is Snowflake and you haven't used BigQuery. Suggested line: "My warehouse experience is Snowflake; I haven't used BigQuery yet." Don't use the posting's phrase "data contracts" for your past work unless G2 confirms it | see R9, R10 | `[grounded]` your account | pending your approval |
| A4 | Optional: a small dbt-on-BigQuery project on a public dataset, described as learning work | narrows R9's limit | `[inferred]` from G1 | pending your approval |
| A5 | Ask RR2, RR3, RR4, RR5 and RR6's questions in the loop. Ask RR5's before negotiating | the register doubles as interview preparation | `[grounded]` register | pending your approval |

`resume_edits_pending_approval` — each line below rewords only your own sentences.

| # | Your words | Proposed line | Status |
|---|---|---|---|
| E1 | "Built our dbt project on Snowflake — about 180 models" | Built the dbt project on Snowflake, about 180 models | `resume_edits_pending_approval` |
| E2 | "I set up our Great Expectations test suite" | Set up the Great Expectations test suite | `resume_edits_pending_approval` |
| E3 | "Airflow for orchestration. Python and SQL daily." | Airflow orchestration; Python and SQL daily | `resume_edits_pending_approval` |

I did not write "alone", "led" or "owned the warehouse", because you said none of that.

## Evidence status

Verified: none yet. Your background is intake self-report, so it stays at `medium` until an artifact backs it.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Pellucid Learning online tutoring K-12 Denver Series C" and tried to fetch "Senior Data Engineer — Pellucid Learning" (pellucidlearning.com/careers/senior-data-engineer). Both were refused because permission wasn't granted. They would have settled the contradictions row and RR1, so RR1 stays open |
| 2. Role-family sweep | skipped | The Datawright 2026 figures you pasted already fix the market calibration row and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as a `tuesday-dossier.md` to carry into later sessions — say the word.

## Upgrade menu

- Your CV or a prior resume → R3 through R8 can move from self-report to document-backed, and any presentation fixes get proposed.
- A sanitized dbt docs page, a DAG file, a Great Expectations config or a code sample → the matching row (R4, R5, R7 or R8) can reach `high`.
- Your location, work authorization and pay floor → R1 and R2 close, and the decision could move to `go` or `no_go`.
- Any data-contract or source-ingestion work → R10 and R11 close.
- The hiring manager's name → the scope read in role reality, and which story the plan leads with.
- Search and fetch access, which was declined here → RR1 gets a real check, and so does the pasted funding claim. I could then run a deeper pass (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches).

## Questions

G4 — Where will you work from, do you need sponsorship, and what's your pay floor?

G2 — Have you ever defined or enforced an agreed schema or set of expectations between a system producing data and the people consuming it, and what did you own?

G3 — Which source systems did your Airflow pipelines ingest from, such as product-app events or a CRM, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.