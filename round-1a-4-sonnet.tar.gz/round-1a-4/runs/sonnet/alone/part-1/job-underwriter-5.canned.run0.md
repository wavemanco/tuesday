I've read the skill's reference files, and I'm now loading the web tools. I want to check that the Pellucid posting is still live and matches what you pasted before I write the assessment.
# Job Underwriting — Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Yes, worth applying, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (App and CRM ingestion), R10 (Data contracts for analysts)

R8 — a credible bridge, its limit named; R9, R10 — not recovered yet, not found absent.

**Opportunity ledger.** The employer and posting checked out against your pasted text, and the pay range sits at or above the market median. Open items are the equity terms (RR1), the scope and reporting line (RR2), and the warehouse change from Snowflake to BigQuery (RR3). Positive signals: RR4, RR5.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work remote from the US or from Denver — R1; (2) your pay floor fits the band and the equity is worth having — RR1; (3) BigQuery is presented as a bridge from Snowflake, not as experience you have — R8, RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched |
| Posting status | Careers page shows "Accepting applications", and its text matches what you pasted | `[grounded]` careers page, fetched 2026-11-24 |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | Looks like ownership of one domain's pipelines, in line with the typical senior scope. Whether the role has reports, or sits alone or in a team, is not stated | `[inferred]` from the JD's single-domain wording against the report's typical scope |
| Market calibration | Base median $151,000, interquartile range $139,000–$163,500; "Senior" typically means 5–8 years, with no direct reports. The posting's $148,000–$166,000 starts just under the median and ends just above the upper quartile. Its "5+ years" sits at the bottom of the typical senior span | `[generic]` Datawright 2026 report (n=2,310, Series B–D) for the norm; `[grounded]` JD for the posting's figures |
| Unknowns | Hiring manager and team shape; equity terms; BigQuery ramp expectations; whether pay varies by Denver or remote | — |
| Contradictions | None between your pasted text and the company's own pages | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you live or your US work eligibility, so I can't tell if you meet this term | `[grounded]` JD term; candidate location not given | G1 question |
| R2 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering. Years of experience is not a gate | `[grounded]` your stated background | A CV would let me check it |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact seen | `[grounded]` your stated background | none |
| R4 | dbt | must_have | direct | medium | presentation | You built the dbt project, about 180 models, which is specific and directly relevant. It probably deserves a more prominent place on your CV | `[grounded]` your stated background | E1 pending approval |
| R5 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse | `[grounded]` your stated background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named as the orchestrator you used | `[grounded]` your stated background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | presentation | You set up the Great Expectations suite. That's stronger than "has used testing", so the CV should show what you owned | `[grounded]` your stated background | E2 pending approval; an inspectable artifact would raise to high |
| R8 | BigQuery as the warehouse | important | adjacent | medium | transferability | The role is built on BigQuery and you haven't used it. dbt models and SQL carry over from Snowflake. BigQuery-specific practice (cost control, table design) is untested | `[generic]` that dbt and SQL skills carry across warehouses; `[inferred]` bridge from your Snowflake work | W1 pending approval; named limit goes wherever the bridge is used |
| R9 | Ingestion from the app and CRM | important | unclear | none | discovery | Nothing yet on the sources you ingested or who owned the extraction | `[grounded]` background silent on sources | G3 question |
| R10 | Data contracts for analysts | important | unclear | none | discovery | Nothing yet on agreements, schema guarantees or SLAs with analysts | `[grounded]` background silent | G4 question |

R9 and R10 are tiered `important`, not `must_have`: the JD's requirements list names neither. The mandate sentence does. That's my reading of the posting.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and US eligibility (R1, hard_gate) | hard_gate | The posting requires remote (US) or Denver, and your location isn't stated | A failed gate would change the decision to `no_go` | — | Not needed; a plain answer is enough | `[grounded]` JD term, no input |
| G2 | BigQuery (R8, important) | transferability | Strong Snowflake and dbt evidence, no BigQuery | The role is built on BigQuery, so the interview will probe how fast you ramp | Any personal or sandbox BigQuery project; a cross-warehouse migration; cost tuning on Snowflake | A small repo or note showing a dbt slice running on BigQuery | `[inferred]` from the JD's BigQuery wording; `[generic]` that interviewers probe the warehouse named in the stack |
| G3 | App and CRM ingestion (R9, important) | discovery | The sources you pulled in are unclear | The mandate opens with ingestion, so it's worth knowing what you've built | Loading data from an operational app database, a CRM or billing system through a connector or custom extract; handling schema drift or backfills | A pipeline diagram, a DAG screenshot, a design doc | `[grounded]` background silent on sources |
| G4 | Data contracts (R10, important) | discovery | Your use of dbt may include agreements with downstream analysts, but none are stated | The posting calls out contracts that analysts depend on | Schema or freshness guarantees with analysts; dbt model contracts or exposures; tests tied to a consumer's expectations; incident notices | A dbt `schema.yml`, a data-quality runbook, an SLA doc (sanitized) | `[grounded]` background silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity unquantified | unknown | — | "plus equity" | Grant type, size and vesting aren't stated, so the total offer can't be compared with market base pay | `[inferred]` from the JD naming equity with no terms | What equity is offered for this level, and on what vesting and strike or grant terms? | unresolved |
| RR2 | Team shape and ownership not stated | unknown | — | "Build and run the pipelines" | The role might own a whole platform alone, including on-call, or be one of several engineers | `[inferred]` from the JD's "build and run" against its silence on team and manager | Who does this role report to, who else works on the pipelines, and what is the on-call expectation? | unresolved |
| RR3 | Warehouse change | risk_signal | low | "a dbt-modelled warehouse in BigQuery" | The team may expect production BigQuery fluency on day one, or accept a ramp | `[generic]` pattern that stack-named postings vary in ramp tolerance; `[inferred]` that it matters because R8 is adjacent | How much BigQuery experience do you expect on arrival, and what does onboarding look like for someone coming from Snowflake? | unresolved |
| RR4 | Pay disclosed and in line with market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is transparent and sits at or above the median for the title | `[grounded]` JD range against the pasted report's median and interquartile range | Does the range vary by Denver or remote location? | noted |
| RR5 | Employer verified and recently funded | positive_signal | — | "Series C ($52M, February 2026)" | The company is real, sized as described, and recently raised funds | `[grounded]` About page, fetched | What does the data team's roadmap look like over the next 12 months? | noted |

## Application plan

All items below are proposals, pending your approval, and that includes the written advice as well as the CV wording.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV bullet: "Built and maintained a dbt project of about 180 models on Snowflake", adding what the models served once you tell me | see R4 | `[grounded]` your stated background | pending your approval |
| E2 | CV bullet: "Set up the data quality test suite in Great Expectations" ("set up", as you said, not "led" or "owned") | see R7 | `[grounded]` your stated background | pending your approval |
| W1 | A small BigQuery sandbox project running a slice of a dbt project, described as a learning exercise, not production experience | see R8, G2 | `[inferred]` from the R8 limit | pending your approval |
| Q1 | Ask the RR1 to RR3 questions verbatim in the interview loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Lead with warehouse-portable strengths (dbt, testing, orchestration) and state the BigQuery limit plainly if asked | see R8; the reframing audit rules out saying BigQuery experience | `[grounded]` R4 to R8 rows | pending your approval |

## Evidence status

Verified: none yet. Your background is stated in prose with no CV or artifact, so every row from R2 to R7 is at `medium` at most.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and "About Pellucid Learning" (pellucidlearning.com/about). Both match your pasted text, and the posting shows "Accepting applications": role reality's organization, posting status and contradictions rows, and RR5 |
| 2. Role-family sweep | skipped | The Datawright pay report you pasted already fixes the band, seniority and scope for market calibration and for the pay check against the posting |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

## The offer

I can write all of this up as `tuesday-dossier.md` if you'd like a file to keep.

## Upgrade menu

- Your CV, or a link to a profile → R2 to R7 can be checked against a document and the CV edits tailored to it.
- Your location, US work eligibility and pay floor → R1 closes, and RR4 gets checked against your floor.
- A sanitized Great Expectations suite or dbt docs/lineage view → R7 or R4 to `high`.
- A pipeline diagram or DAG screenshot → G3 closes.
- A dbt `schema.yml` or SLA note → G4 closes.
- The hiring manager's name → the scope read and the positioning in the plan.
- A deeper research pass on Pellucid (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G1 — Where are you based, and are you authorized to work in the US without sponsorship, so that remote (US) or the Denver office applies?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — At your payroll company, what data sources did you ingest, who owned the extraction, and how did you handle things like schema changes or backfills?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G4 — Did you set agreements with the analysts who consumed your dbt models, such as guaranteed columns, freshness times or alerts when a test failed? What did you own?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.