I've read the underwriting rules. Next I'm checking that the company and the posting are real and match what you pasted, which is one fetch of their careers page and one search.
**Yes, it's worth applying, on the conditions below. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R8, R9
- `important`: adjacent: R7 (BigQuery); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R7 is a credible bridge with its limit named; R10 and R11 are not covered by what you've told me yet.

**Opportunity ledger.** The posting is transparent on pay and the salary sits inside the market band (RR2). Team and scope (RR1), the equity terms (RR3) and first-year outcomes (RR4) are unanswered.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The location and pay terms work for you (R1, R2). You haven't stated a floor or a location.
  2. You have real examples of ingestion from application or CRM sources and of data contracts (R10, R11). See G1 and G2.
  3. BigQuery is framed as adjacent to your Snowflake work, never as experience you have (R7, G3).
  4. The scope checks out in interviews: team size and reporting line (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026). These are the company's own statements, and my one search returned only its own About page, so the funding is not independently corroborated | `[grounded]` company About page, as pasted and as returned by search |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD, and the live careers page ("Accepting applications") |
| Stack | dbt, BigQuery, Airflow or similar, Python and SQL, data quality testing | `[grounded]` JD |
| Compensation | $148,000–$166,000 plus equity; the equity amount and terms are not stated | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Scope read | Three named responsibilities (ingestion, modelling, contracts), and "build and run" suggests end-to-end ownership. No team size, reporting line or first-year outcomes are stated, and no hiring manager is named | `[inferred]` from the JD's responsibilities against its silence on team and outcomes |
| Market calibration | Pay: the report's Series B–D senior base median is $151,000 (IQR $139,000–$163,500). The posted low end sits $3,000 under the median and above the 25th percentile, and the posted top end sits $2,500 above the 75th percentile. The posting is at or above market, not a mismatch. Seniority: "Senior" typically means 5–8 years, and the JD's 5+ and your 6 years are within that. Typical scope is one domain's pipelines with no direct reports, and this posting's scope may be wider (RR1). This is a pattern, not a claim about this employer's offer | `[generic]` Datawright 2026 report (n=2,310), supplied by your recruiter; `[grounded]` JD for the posted figures |
| Unknowns | Team size and reporting line; equity grant; first-year outcomes; whether the warehouse already exists or is greenfield | — |
| Contradictions | None between the pasted JD and the live careers page, which carry the same text | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you are or any location constraint, so whether the role's terms fit you is not established | `[grounded]` JD terms; no candidate statement given | Ask: location and work authorization (closing question R1/R2) |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so I can't check the posted range against it. The range sits inside the market band | `[grounded]` JD figure; `[generic]` band from the recruiter's report | Ask: your floor (closing question R1/R2) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You describe 6 years of data engineering. This is your own account with no document behind it yet, so `medium`: expect a probe on the years. Experience length is a risk, not a gate | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" rests on your word, with no inspectable work yet | `[grounded]` your stated background | A code or model sample you can share would raise it to `high` |
| R5 | dbt | must_have | direct | medium | none | You built your company's dbt project, about 180 models, on Snowflake. The scale is your own figure, so `medium` | `[grounded]` your stated background | A sanitized project structure would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the requirement as written is "a cloud warehouse" | `[grounded]` JD wording against your stated background | none |
| R7 | BigQuery, the named warehouse | important | adjacent | medium | transferability | Your dbt-on-Snowflake work carries over. Limit: you have not used BigQuery, so its cost model and platform-specific tuning are untested by you. BigQuery's cost and tuning model differing from Snowflake's is a generic pattern, which is why I'd expect an interviewer to probe it | `[grounded]` you have not used BigQuery; `[generic]` platform differences | See G3 |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | You use Airflow for orchestration. Your depth and ownership of it are not yet described | `[grounded]` your stated background | none |
| R9 | Data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations suite, which is ownership, not just use. Whether it also covers dbt tests is not stated | `[grounded]` your stated background | A sanitized suite excerpt would raise it to `high` |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | The JD names application and CRM sources. Your background gives 6 years of pipelines at a payroll company but doesn't say what the source systems were | `[grounded]` background silent on source systems | See G1 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your Great Expectations work is nearby, but it isn't established that you defined agreed schemas or contracts with consumers | `[inferred]` from the Great Expectations work, which suggests a thread to pull | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM sources (R10, important) | discovery | Six years of pipelines are stated, but not what they ingested from or how | The JD lists it first among responsibilities, and a clear example could move R10 to `direct` | Pulling from a product database or event stream; syncing a CRM or SaaS API (Salesforce, HubSpot or similar) into the warehouse; handling schema changes or late-arriving data | A pipeline diagram, a DAG excerpt or a design note, sanitized | `[grounded]` background silent on sources; `[generic]` that source variety is what interviewers probe here |
| G2 | Data contracts (R11, important) | discovery | The Great Expectations suite is stated, but not whether expectations were agreed with downstream consumers | The JD names contracts analysts depend on. If you did this work, it reads as direct | Agreeing a schema or freshness expectation with analysts; failing a pipeline on a breached expectation; versioning a model's interface | A sanitized expectations file, a contract doc or a model-level test config | `[grounded]` background silent on consumer agreements; `[generic]` that this role family uses the term for producer and consumer agreements |
| G3 | BigQuery (R7, important) | transferability | Strong adjacent evidence: dbt modelling and a cloud warehouse at scale. Limit: no BigQuery use | It's the named stack, so it will be asked about | Adjacent: warehouse cost and performance work on Snowflake | A small personal dbt project on BigQuery would narrow the limit | `[inferred]` bridge from your Snowflake and dbt work; `[generic]` that stack-specific questions follow named-stack roles |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team and scope unspecified | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the sole or first data engineer owning ingestion, modelling and contracts, which is wider than the one-domain norm | `[inferred]` from the JD's three responsibilities against its silence on team; `[generic]` one-domain norm | Who else is on the data team, who does this role report to, and who owns ingestion today? | unresolved |
| RR2 | Pay stated and inside market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Transparent compensation, in line with the market band | `[grounded]` JD; `[generic]` band | What is the full range's basis, and where does your experience place you in it? | noted |
| RR3 | Equity unspecified | unknown | — | "plus equity" | Equity may be small or vague relative to the cash figure | `[inferred]` from the missing grant size and terms | What is the equity grant (type, amount, vesting)? | unresolved |
| RR4 | First-year outcomes not stated | unknown | — | "Build and run the pipelines..." | Success may be undefined for a role with broad accountability | `[inferred]` from the JD's silence on outcomes | What should this role have delivered at six and twelve months? | unresolved |

## Application plan

Every row below is a proposal pending your approval, and that covers the notes as well as the table. Nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location, work authorization and pay floor against R1 and R2 before applying | These are the two unconfirmed gates | `[grounded]` R1, R2 | pending your approval |
| A2 | Lead the resume with your dbt project (about 180 models), Great Expectations suite and Airflow orchestration, in your own numbers and no others | They are the direct must-have evidence (R5, R8, R9) | `[grounded]` your stated background | pending your approval |
| A3 | Describe BigQuery as adjacent: dbt on Snowflake, not yet on BigQuery. Do not claim BigQuery experience | See R7 and G3 | `[grounded]` your stated background | pending your approval |
| A4 | Optionally build a small dbt-on-BigQuery sample project | Narrows R7's limit with an inspectable artifact | `[inferred]` from the gap | pending your approval |
| Q1 | Ask the questions of RR1, RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer), which shows the same text as your paste and "Accepting applications". Searched "Pellucid Learning online tutoring K-12 Series C $52M", which returned only "About Pellucid Learning" (pellucidlearning.com/about). Role reality: the contradictions row, and the employer is attributable. The funding is not independently corroborated |
| 2. Role-family sweep | skipped | Your recruiter's pay report is in hand and fixes the market calibration line and RR2 |
| 3. Hiring manager's public footprint | n/a | No hiring manager is named in the posting, so there was no query to form |

## Closing

I can put this into a `tuesday-dossier.md` file whenever you want it.

**Upgrade menu**

- Your location, work authorization and pay floor → R1 and R2 move to `direct` or `hard_gate_fail`, which could also change the status.
- Examples for G1 and G2 → R10 and R11 move from `unclear` toward `direct`.
- A sanitized dbt structure, expectations file or DAG excerpt → R4, R5, R8 and R9 can move from `medium` to `high`.
- A hiring manager's name → role reality's scope read and which story the application plan leads with.
- A deeper research pass on Pellucid Learning (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

- R1/R2 — Where are you based, do you need sponsorship, and what is your minimum acceptable base?
- G1 — What source systems did your pipelines ingest from (a product database, a CRM, third-party APIs), and what did you own?
- G2 — Did you agree schemas or quality expectations with the analysts who consumed your data, and what happened when one was breached?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.