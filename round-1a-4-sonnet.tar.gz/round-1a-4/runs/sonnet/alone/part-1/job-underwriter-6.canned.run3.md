I've read the posting and the skill's rules. Next I'm reading the last two reference files, then running the company, salary-band and hiring-manager research.
**Yes, apply. Status: `conditional_go`.** R1 and R2 still need checking against your own limits. R7, R8 and R10 are the gaps to be straight about.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3, R5 · adjacent: R4 (B2B software company setting), R6 (SQL and spreadsheet modelling), R7 (Experience owning a forecast) · unclear: R8 (Working with finance on billing or revenue data)
- `important`: direct: R9 · absent: R10 (Own billing data)

R7: a bridge, its limit named; R8: one answer could move it; R10 (`none`): billing data never worked on.

**Opportunity ledger.** The pay is stated and sits in line with the market (RR4). Four things are open: who owns the forecast (RR1), what team and support the role has (RR2), that I couldn't find the posting on Quillfield's own site (RR3), and the share-option terms (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week), R2 (Salary £61,500–£67,000); candidate constraints not given, so checks against them are unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 both work for you; (2) RR1 resolves to a forecast scope you can honestly take on, with R7 presented as adjacent and never as ownership; (3) you accept R10 as a real limit and plan for it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` Quillfield "About" page |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, listed as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. This matches what your recruiter told you. No talks or writing turned up. | `[grounded]` one public profile page and your recruiter's statement |
| Scope read | A "Lead" post under a Head of Revenue Operations, with the forecast run jointly with the CFO. Forecast accountability may be shared rather than yours alone (RR1). | `[inferred]` from the posting's wording and the manager's listed title |
| Market calibration | UK revenue operations lead, B2B software: median base £64,200, interquartile range £57,800–£70,400 (n=438). The stated band is inside that range, close to the median. This is a market pattern, not this employer's offer. The sweep returned pay only, so title and scope norms are not calibrated. | `[generic]` Ledgerline 2026 pay guide; `[grounded]` posting's figure |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Unknowns | Permanent or fixed-term; team size and support; who owns the forecast; billing system in use; option terms | `[grounded]` posting silent on each |
| Contradictions | None between the posting and Quillfield's About page. The posting is not confirmed on Quillfield's own site (RR3). | `[grounded]` About page; careers address tried returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether two Bristol days work, so the gate is unsettled | `[grounded]` posting; your constraints not given | Gate question below (R1, R2) |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | You haven't given a floor or current pay, so the comparison can't be made. The band against the market is in RR4. | `[grounded]` posting; your constraints not given | Gate question below (R1, R2) |
| R3 | 4+ years in revenue operations, sales operations or similar analytics role | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team. Self-reported, nothing inspectable yet. | `[grounded]` your background statement | none |
| R4 | That role at a B2B software company | must_have | adjacent | medium | discovery | Your employer is a B2B payments company. Whether it sells software is not stated. | `[grounded]` your statement; `[inferred]` the software question is open | Check your CV states the product type, if truthful |
| R5 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; certificate not yet seen | `[grounded]` your statement | Certificate or credential ID would raise this to high |
| R6 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show use. "Strong" and "modelling" depth aren't established, and forecast work leans on modelling. | `[grounded]` your statement | Name a model or analysis you built (see upgrade menu) |
| R7 | Experience owning a forecast | must_have | adjacent | medium | transferability | You've never owned the company forecast; finance did. You run the monthly pipeline review with your sales director. Limit: that review is not forecast ownership. | `[grounded]` your statement | Gap queue G1 |
| R8 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | You've never worked on billing data. Revenue data is the other branch of this requirement, and you built renewal dashboards. Whether finance was involved isn't stated. | `[grounded]` your statement; the dashboard link is `[inferred]` | Gap queue G2 |
| R9 | Build pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your team's pipeline and renewal dashboards. Whether finance used them is not stated. | `[grounded]` your statement | none |
| R10 | Own billing data | important | absent | none | capability | You have no billing-data experience and say so. | `[grounded]` your statement | Closure path in G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R7, must_have) | transferability | The monthly pipeline review with your sales director is adjacent. Finance owned the forecast, so ownership is not shown. | The role runs the forecast with the CFO (RR1), and this is the gap most likely to be probed | Supplying pipeline coverage, commit or scenario numbers to the forecast; reconciling your pipeline view to finance's number; building a forecast-vs-actual view | A sanitized pipeline-coverage or forecast-vs-actual report | `[grounded]` your statement; `[generic]` that a forecast-owning role is likely to probe this |
| G2 | Finance collaboration on revenue or billing data (R8, must_have) | discovery | Renewal dashboards exist, but who used them and whether finance was involved is unknown | A must-have currently `unclear`; one answer could move it to `adjacent` | Agreeing renewal or ARR definitions with finance; reconciling dashboard numbers to finance's figures; fixing a mismatch between CRM and finance records | A definitions doc, a reconciliation sheet, a dashboard screenshot | `[grounded]` your statement; `[inferred]` it could move |
| G3 | Billing data ownership (R10, important) | capability | No direct or adjacent evidence | Part of the stated mandate. It stays a real limit unless you learn it. | None. Learn how invoice, credit-note and plan-change records join to CRM accounts, and ask in interviews which billing system is used. | n/a | `[grounded]` your statement; `[generic]` that this is learnable alongside the job |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The forecast may be shared with the Head of Revenue Operations, or the role may be expected to own it alone | `[inferred]` from the posting's wording and the manager's listed title | Who owns the forecast number today, and what would this role own against the CFO and you in the first two quarters? | unresolved |
| RR2 | Team and support unstated | unknown | — | "You will own our CRM and billing data" | A "Lead" title with no reports or analyst support mentioned may mean sole ownership of CRM, billing data, reporting and forecast | `[inferred]` from the posting's silence on team | Does this role have direct reports or analyst support, and who administers the billing system today? | unresolved |
| RR3 | Posting not seen on Quillfield's own site | unknown | — | "Revenue Operations Lead, Quillfield" (on Tallyboard) | The role may be listed elsewhere on their site, or hired through the recruiter only. The one careers address I tried returned no page. | `[grounded]` fetch result; hypothesis `[generic]` | Can you send the link to this role on Quillfield's careers page? | unresolved |
| RR4 | Pay stated and in the market range | positive_signal | — | "Salary £61,500–£67,000 plus share options" | Pay is disclosed and sits near the median of the role-family band | `[grounded]` posting figure; `[generic]` band | What is the review cycle and typical movement within this band? | noted |
| RR5 | Share-option terms unstated | unknown | — | "plus share options" | The options may carry little value depending on vesting and strike price | `[inferred]` from the posting's silence | What are the grant size, vesting schedule and strike price? | unresolved |

## Application plan

`resume_edits_pending_approval`: each line traces to your own words and nothing is applied yet.

| # | Proposed line | Your words it traces to | Provenance | Status |
|---|---|---|---|---|
| E1 | "Ran revenue operations for the UK team (last 2 of 5 years in sales operations at a B2B payments company); rebuilt the pipeline and renewal dashboards." | "5 years in sales operations at a B2B payments company, the last 2 running revenue operations for the UK team… rebuilt our pipeline and renewal dashboards" | `[grounded]` your statement | pending your approval |
| E2 | "Run the monthly pipeline review with the sales director." | "I run the monthly pipeline review with our sales director" | `[grounded]` your statement | pending your approval |
| E3 | "Salesforce admin certified; SQL (weekly use), Excel (daily use)." | "Salesforce admin certified. SQL weekly, Excel daily" | `[grounded]` your statement | pending your approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| F1 | Interview line on the forecast: "Finance owned the forecast at my company, so I haven't owned one. What I run is the monthly pipeline review with the sales director." | Traces to "never owned the company forecast — finance did that" and "run the monthly pipeline review with our sales director". It states the limit, so it can't be read as a claim of ownership. | `[grounded]` your statement | pending your approval |
| A1 | Settle R1 and R2 for yourself before spending application effort | They are the only unsettled gates | `[grounded]` map rows R1, R2 | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR5 verbatim of Tamsin or the recruiter | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A2 | Lead with the pipeline and renewal reporting work (R9). Tamsin's own listed background includes sales operations at a payments company, so the common ground is there to mention, not to presume anything about. | Positioning for this reader | `[inferred]` from the public profile | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Revenue Operations Lead Bristol", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. Moved: the organization row, the contradictions row, and RR3 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B SaaS Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: the market calibration row and RR4. It returned pay only, nothing on title or scope norms |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved: the hiring manager and scope read rows, and A2 |

I can write all of this to `tuesday-dossier.md` for you to keep, if you'd like.

## Upgrade menu

- Your Bristol position and pay floor → R1 and R2 settle, and the decision becomes `go` or `no_go`.
- An answer to G1 or a sanitized forecast-related artifact → R7's bridge strengthens or its limit is confirmed.
- An answer to G2 → R8 moves off `unclear`.
- Your CV, or a model or analysis you built in Excel or SQL → R6's depth gets settled.
- The Salesforce certificate or credential ID → R5 can reach `high`.
- Whether your employer's product is software → R4 settles.
- A deeper research pass on Quillfield (funding and leadership changes, staff and candidate reports, recent news; up to 5 more searches and 2 more fetches) → RR1 to RR3 get checked externally. Say the word and it runs.

**Questions**

- R1, R2: Do Bristol with two office days a week and £61,500–£67,000 both work for you, or is either a limit?
- G1: Have you ever supplied numbers into the forecast finance owned, such as pipeline coverage, commit calls or scenarios? If so, what did you hand over, and to whom?
- G2: In your renewal and pipeline work, did you work with finance on revenue or billing figures, for example agreeing definitions or reconciling numbers? What did you do?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.