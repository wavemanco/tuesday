I'll read the reference files first.
Research is done (one fetch and one search). Here is the assessment.

## Decision snapshot

**Yes, this is worth applying to, with three things to confirm first: R10, R11 and R5. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R10 (Remote US or Denver office), R11 (Salary $148,000–$166,000)
- `must_have` — direct: R1, R2, R3, R4, R6, R7
- `important` — adjacent: R5 (BigQuery in the stack) · unclear: R8 (Ingestion from app and CRM), R9 (Data contracts for analysts)

R5 (`medium`) — a credible bridge, its limit named; R8, R9 — the background you gave is silent on them.

**Opportunity ledger.** The terms are transparent and the posting is live: the pay range is stated and sits in the market band (RR4, RR5). The team shape, equity terms and success measures are unstated (RR1, RR2, RR3).

- **Hard gates:** none failed; unconfirmed: R10 (Remote US or Denver office), R11 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you are US-based and authorized to work there (R10); (2) the $148,000 floor of the range clears your own minimum (R11); (3) BigQuery is framed as adjacent, never as experience you have (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026). These are the company's own claims. Nothing independent confirms the funding or headcount yet | `[grounded]` company About page, returned by search |
| Mandate | Build and run the pipelines behind tutoring-platform reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` careers page, fetched |
| Requirements | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` careers page |
| Terms | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` careers page |
| First-year outcomes | Not stated, and not inferred | `[grounded]` the posting is silent |
| Scope read | One domain owned from ingestion through to the analyst-facing contracts. Whether you'd be on a team or alone is unknown. "Run" may carry operational or on-call duty, which the posting doesn't say | `[inferred]` from "build and run" against the posting's silence on team |
| Market calibration | Datawright 2026 (your recruiter's report), Senior Data Engineer at Series B–D companies, n=2,310: base median $151,000, interquartile range $139,000–$163,500. "Senior" typically means 5–8 years, owning one domain's pipelines with no direct reports. The posting starts $3,000 under the median and ends $2,500 above the top of the interquartile range. Your 6 years sits inside the 5–8 span. Series C sits inside B–D | `[generic]` the report's band, a pattern and not a claim about this employer; `[grounded]` the posting's figures |
| Unknowns | Hiring manager, team structure, equity terms, success measures, on-call expectations | `[inferred]` from the posting's silence |
| Contradictions | None between the text you pasted and the pages I fetched | `[grounded]` careers page and About page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You stated 6 years at a B2B payroll company. It's self-reported, with no artifact, so expect a dates probe | `[grounded]` your stated background | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both is stated. There's no project, scale or artifact, so the "strong" is carried by your word alone | `[grounded]` your stated background | A described project or code sample would raise it to high |
| R3 | dbt | must_have | direct | medium | none | You built your company's dbt project, about 180 models. It's specific, with no inspectable artifact | `[grounded]` your stated background | A sanitized project structure or model-lineage screenshot would raise it to high |
| R4 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The posting names BigQuery only in its mandate line, not in the requirements list | `[grounded]` your stated background; `[inferred]` that Snowflake meets this line | none |
| R5 | BigQuery as the warehouse | important | adjacent | medium | transferability | Same dbt-on-a-cloud-warehouse work, different engine. Limit: you have never used BigQuery. Tiered `important` because the posting names it in the mandate, not the requirements | `[inferred]` bridge from your Snowflake and dbt work | See G1 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You use Airflow for orchestration. Scope and scale aren't stated | `[grounded]` your stated background | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, so ownership is stated | `[grounded]` your stated background | A sanitized suite summary or check list would raise it to high |
| R8 | Ingestion from the app and CRM | important | unclear | low | discovery | You mention Airflow, but not what sources fed it. Low, not none, because pipelines imply some ingestion | `[grounded]` your background is silent on sources | See G2 |
| R9 | Data contracts analysts depend on | important | unclear | low | discovery | A Great Expectations suite tests quality. Whether you set formal agreements with consumers (schema, freshness, ownership) isn't stated | `[grounded]` your background is silent on contracts | See G3 |
| R10 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization weren't stated, so the gate is neither met nor failed | `[grounded]` the posting's terms; no statement from you yet | Question R10 below |
| R11 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | You gave no pay floor, so whether the range meets it is unestablished | `[grounded]` the posting's range; no floor stated | Question R11 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R5, important) | transferability | Six years of dbt on Snowflake and none on BigQuery. The carry-over is the dbt and warehouse-modelling work. The limit is that you haven't run it on BigQuery. A small dbt project on BigQuery would narrow that limit | The mandate line names it, so the stack mismatch is the likeliest first objection | A personal or work project that queried or loaded BigQuery, even once; a migration or comparison exercise you took part in; a dbt project you could re-point at BigQuery | A repo link or a short README for a small dbt-on-BigQuery project | `[grounded]` your background; `[generic]` that a stack mismatch is a common first screen |
| G2 | Ingestion from app and CRM sources (R8, important) | discovery | Airflow is stated, but not which systems fed it | It's a named duty, and which sources you've handled decides how directly it maps | Loading from a product database; syncing from a CRM through an API or ELT tool; handling app event data | A sanitized DAG screenshot or architecture sketch | `[grounded]` your background is silent on sources. Not asked this turn, because of the question budget |
| G3 | Data contracts (R9, important) | discovery | Quality testing is covered. Formal agreements with the analysts who consume your data aren't mentioned | It's a named duty, and a test suite alone may not count as contracts | Agreed schemas or freshness expectations with analysts; named model owners; documented change notices; dbt model contracts | A sanitized contract or YAML excerpt | `[grounded]` your background; `[inferred]` that your testing work is adjacent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team shape and reporting line unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the sole data engineer owning ingestion, warehouse and contracts. That would be wider than the report's one-domain, no-reports scope | `[inferred]` from the posting's silence on team; `[generic]` for the report's typical scope | Who else is on the data team, and who would I report to? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus equity" | Grant size, vesting and valuation basis may be undisclosed, so the equity can't be weighed against the cash range | `[generic]` pattern that postings often omit grant terms | What equity grant comes with this level, and on what vesting and valuation basis? | unresolved |
| RR3 | Success measures unstated | unknown | — | "the data contracts our analysts depend on" | The role may be judged on reporting reliability with no stated targets | `[inferred]` from the posting naming duties and no outcomes | What would a strong first year look like, and how is pipeline reliability measured today? | unresolved |
| RR4 | Pay stated and in the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Transparent pay with no seniority-compensation mismatch: the range's top end clears the report's interquartile range, and its bottom end sits just under the median | `[grounded]` posting against the recruiter's report; the band is `[generic]` | Is the range firm, or does where you land depend on level? | noted |
| RR5 | Posting live and consistent with the company site | positive_signal | — | "Accepting applications." | The role is open, and the company's own pages agree with what you pasted | `[grounded]` careers page fetched | What are the interview stages and the timeline? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with your dbt project (about 180 models), the Great Expectations suite you set up, and Airflow orchestration, in your own stated terms | See R2, R3, R6, R7 | `[grounded]` your stated background | pending your approval |
| E2 | State Snowflake plainly. In the cover note, say you haven't used BigQuery but have run the same dbt workflow on another cloud warehouse | See R5, G1 | `[grounded]` your background; `[inferred]` bridge | pending your approval |
| W1 | A small dbt project on BigQuery, published as a work sample | See G1 | `[inferred]` bridge for R5 | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2 and RR3 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Every row in this plan, and every piece of wording it proposes, is a proposal. Nothing is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). It shows the posting live ("Accepting applications") and word-for-word consistent with your paste. Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about), matching the company description you pasted. It moved role reality's organization and contradictions rows and added RR5. No employer-not-established entry was needed. Both sources are the company's own, so the funding is unconfirmed independently |
| 2. Role-family sweep | skipped | The recruiter's Datawright report is in hand (median, interquartile range, typical scope). It already fixes the market calibration line and the pay check (RR4), so a search could not change them |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form |

If you'd like, I can save this as `tuesday-dossier.md` so it carries into later steps.

## Upgrade menu

- A pay floor and your location and work status → R10 and R11 close, and the decision likely resolves to `go` or `no_go`.
- A described Python or SQL project, or a sanitized dbt project structure or Great Expectations suite summary → R2, R3 and R7 rise to `high`.
- An answer on sources and on contracts → R8 and R9 resolve, and the application plan leads with the stronger story.
- A small dbt-on-BigQuery repo → R5's limit narrows.
- The hiring manager's name → role reality's scope read, and which story the plan leads with for that reader.
- A deeper research pass on Pellucid (funding and leadership changes, public employee reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

R10 — Are you based in the US, and authorized to work there, for this remote or Denver role?

R11 — Does $148,000, the bottom of this range, clear your lowest acceptable base salary?

R9 — Did you ever formalise what your analysts could rely on from your pipelines (schemas, freshness, owners), and what did that look like?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.