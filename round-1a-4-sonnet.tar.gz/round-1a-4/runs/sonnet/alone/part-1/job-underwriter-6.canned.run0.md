I've fetched the posting and read most of the skill's rules. Next I'm reading the decision-snapshot and evidence-vocabulary references, then I'll write the assessment.
**Yes, apply, as a stretch role, with the gaps named up front: `conditional_go`.** R6 (forecast ownership) and R7a (billing data) are the two real gaps, and R1 and R2 can't be checked until I know your constraints.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (salary £61,500–£67,000)
- `must_have` — direct: R3, R4 · adjacent: R5 (strong SQL and spreadsheet modelling), R6 (owning a forecast) · unclear: R7b (working with finance on revenue data) · absent: R7a (billing data)
- `important` — direct: R8

R6 — a credible bridge, its limit named; R7a — absent, and you told me so; R5 (`medium`) — use is stated, depth is not.

**Opportunity ledger.** The employer matches the posting's description and the pay is stated and in range (RR4). The open points are authority and reporting line: who owns the forecast number (RR2) and what "Lead" leads (RR3). I couldn't find the post on the company's own careers page (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days), R2 (salary £61,500–£67,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the salary range meet your constraints (R1, R2); (2) the forecast and billing-data gaps are acceptable to Quillfield as a learning curve, which you test by asking RR2 and RR3 in the loop (R6, R7a); (3) the post is confirmed live on Quillfield's own site (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` search result "About Quillfield" (quillfield.co.uk/about), snippet read |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, two office days a week; £61,500–£67,000 plus share options; option terms not stated | `[grounded]` posting |
| First-90-days and first-year outcomes | Not stated in the posting; none inferred | `[grounded]` posting silence |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` search result "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), snippet read |
| Scope read | The post sits beside a Head of Revenue Operations, so "Lead" may be a senior individual role rather than the head of the function | `[inferred]` from the hiring manager's title against the posting's silence on reports |
| Market calibration | UK revenue operations lead, B2B software: median base £64,200, interquartile range £57,800–£70,400 (n=438). This posting's range midpoint is £64,250, so pay is in line with the band. The band is a pattern, not Quillfield's offer | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` posting for the range |
| Unknowns | Reporting line; who owns the forecast today; team size; option terms; whether the post is on the careers page | — |
| Contradictions | None between the posting and the About page. The careers page I tried had no page at that address | `[grounded]` fetch of quillfield.co.uk/careers returned "No page" |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't said where you're based or what you'll accept, so I can't tell whether the term is met | `[grounded]` posting; your constraints not given | Closing question on R1 and R2 |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | No pay floor given. The band comparison is in role reality | `[grounded]` posting; your floor not given | Closing question on R1 and R2 |
| R3 | 4+ years in revenue ops, sales ops or similar analytics at a B2B software company | must_have | direct | medium | none | You have 5 years in sales ops, the last 2 running revenue operations for the UK team. Your employer is a B2B payments company, and whether the posting counts it as "B2B software" is untested. The years requirement is a risk to name, not a gate | `[grounded]` your statement | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified. You stated it and I haven't seen the credential | `[grounded]` your statement | The credential page would raise to high |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show regular use. They don't show depth or modelling work, and "strong" is the posting's word | `[grounded]` your statement; `[generic]` that interviews for this title probe modelling depth | Offer a sanitized model or query as an artifact |
| R6 | Experience owning a forecast | must_have | adjacent | medium | transferability | Finance owned the company forecast where you worked. You run the monthly pipeline review with your sales director, which is adjacent. Limit: you have not owned a forecast | `[grounded]` your statement | See G1 |
| R7a | Billing data | must_have | absent | none | capability | You have never worked on billing data. The posting also makes billing data part of what the role owns | `[grounded]` your statement; `[grounded]` posting | See G2 |
| R7b | Working with finance on revenue data | must_have | unclear | low | discovery | The posting says "billing or revenue data". Your renewal dashboards suggest revenue-adjacent work, but you haven't said what you did with finance | `[inferred]` from your renewal dashboards | See G3 |
| R8 | Pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Whether finance used them is unstated | `[grounded]` your statement | A sanitized dashboard screenshot would raise to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | Monthly pipeline review with the sales director; finance owned the forecast | The posting names the quarterly forecast with the CFO as a core duty | A pipeline roll-up or commit figure you prepared that finance used; a forecast-accuracy or variance review you ran | A sanitized pipeline review pack | `[grounded]` your statement; `[generic]` that forecasting is usually central to this title |
| G2 | Billing data (R7a, must_have) | capability | No billing data experience, stated by you | The posting says the role owns billing data. Closure paths: a small side project that reconciles renewal figures to invoice data, or asking in interview what "billing data" means in practice | None offered, so I'm not asking | n/a | `[grounded]` your statement; `[generic]` closure path |
| G3 | Working with finance on revenue data (R7b, must_have) | discovery | Renewal dashboards built; finance's role in them unknown | May turn R7b from unclear to adjacent, the only partial bridge to the billing duty | Reconciling renewal or pipeline figures to finance's bookings; agreeing definitions with finance | A metrics-definition doc or a reconciliation sheet | `[inferred]` bridge from the renewal dashboards |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Post not found on the company's own careers page | unknown | — | "Revenue Operations Lead, Quillfield" | The careers address I tried may differ from the real one, or the role may be listed elsewhere | `[inferred]` from one fetch at a guessed address returning "No page" | Is this role listed on Quillfield's own careers page, and what is its address? | unresolved |
| RR2 | Forecast ownership versus the Head of Revenue Operations | unknown | — | "run the quarterly revenue forecast with the CFO" | The Head of Revenue Operations may own the number while this post prepares it | `[inferred]` from the posting against the hiring manager's title | Who owns the forecast number today, and who does this role report to? | unresolved |
| RR3 | "Lead" with no team stated | unknown | — | "Revenue Operations Lead" | The title may carry no direct reports | `[inferred]` from the posting's silence on reports | Does this role manage anyone now, and is that planned? | unresolved |
| RR4 | Pay stated and in the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | Transparent pay, in line with the band in role reality | `[grounded]` posting; `[generic]` band | What are the option terms: vesting, strike price, scheme type? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle R1 and R2 before investing in the application | Hard gates, unconfirmed | `[grounded]` map | pending your approval |
| A2 | Positioning line, traced to your own sentences: "I ran revenue operations for the UK team for two years, rebuilt our pipeline and renewal dashboards, and run the monthly pipeline review with our sales director. I'm Salesforce admin certified." | Leads with R3, R4, R8 and the bridge to R6 | `[grounded]` your statement | pending your approval |
| A3 | Candour line for the forecast: "The company forecast sat with finance; my part was the monthly pipeline review with the sales director." For billing data: "I haven't worked with billing data." | R6 and R7a will be probed, and plain answers hold up better than stretched ones | `[grounded]` your statement; `[generic]` that interviews probe attribution | pending your approval |
| A4 | Use RR1 to RR4 as your verbatim questions in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Tamsin Achebe's published career runs from sales operations at a payments company to Head of Revenue Operations. If you talk to her, lead with your sales-ops-to-RevOps path in plain terms | The only published fact about her I used | `[grounded]` her profile snippet | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned "No page". Moved: role reality's organization row, and RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved: scope read, RR2, and A5 |

I can write a `tuesday-dossier.md` of this assessment if you want to keep it.

## Upgrade menu

- Your location and pay floor → R1 and R2 resolve, which is the biggest swing on the decision.
- A sanitized pipeline review pack → R6's bridge firms up and R8 goes to `high`.
- The Salesforce credential page → R4 to `high`.
- A sanitized dashboard screenshot, query or model → R5 and R8 firm up.
- The real careers-page address → RR1 closes.
- A deeper research pass on Quillfield (funding, leadership churn, public employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

R1 and R2 — Is Bristol with two office days a week workable for you, and is £61,500–£67,000 at or above your pay floor?
G3 — Have you worked with finance to reconcile pipeline or renewal figures against their bookings or revenue numbers? If so, what did you own and what came of it?
G1 — What did your monthly pipeline review produce that your sales director or finance used for forecasting, and what was your part in it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.