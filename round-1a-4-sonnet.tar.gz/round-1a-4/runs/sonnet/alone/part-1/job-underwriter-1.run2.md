I'll read the skill's reference files before building the assessment.
**Yes, apply. R1, R2, R3, R4, R6 and R7 are `direct`, and R5 is `adjacent`. Status: `conditional_go`.**

I couldn't verify Harborlight from here. Both web searches were refused, so the employer-verification step and the pay benchmark didn't run (details under Evidence status).

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6, R7 · adjacent: R5 (metrics layer)
- `important` — unclear: R8 (partner with clinicians), R9 (mentor two junior analysts)
- `preferred` — adjacent: R11 (HIPAA)· absent: R10 (healthcare data experience)

R5 (`low`) — a bridge to confirm, its limit named; R10 — a preferred-tier gap, not a blocker; R8, R9 — not contradicted, not yet evidenced.

**Opportunity ledger.** The employer is unconfirmed from here (RR1), and pay and location are unstated (RR2). Success measures are unstated (RR3). The scope and team structure are concrete (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify on Harborlight's own careers site (RR1); (2) your metrics-layer work is confirmed as yours, not just your dashboards (R5, G1); (3) your constraints are checked against pay and location once they're known (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, with a care-navigation app | `[grounded]` JD header; not independently verified |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, partnering with product managers and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Stage | Evaluating; nothing sent yet | `[inferred]` from your "should I apply" |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silent |
| Scope read | A senior individual-contributor post with two direct mentees and one product surface | `[inferred]` from "mentor two junior analysts" and "the care-navigation app" |
| Market calibration | Not drawn: the role-family sweep didn't run, and I won't give a pay band from memory. The posting states no compensation, which is itself worth a question (RR2) | `[grounded]` JD silent on pay |
| Unknowns | Salary, location or remote policy, reporting line, success measures, clinician involvement, warehouse stack | `[grounded]` JD silent |
| Contradictions | None visible inside the JD; the careers page was not checked | `[inferred]` from the pasted JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a consumer-subscription company; confirmed and specific, no inspectable artifact yet. Experience length is graded as fit, not as a gate | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake over those years. "Expert" is a level, and the interview, not the CV, is where it gets tested | `[grounded]` your background; `[generic]` that SQL depth is usually probed live | A sanitized query or model sample would raise to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift, on about 2M subscribers. Test sizes and your exact role in each decision are not yet stated | `[grounded]` your background | A sanitized experiment readout would raise to `high`; be ready to say what was you versus the team on the pricing test |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | You built the company's Looker instance from scratch, 40+ governed dashboards. "Self-serve" is the JD's word; you haven't said business users explored them unaided | `[grounded]` your background | Screenshot or LookML sample would raise to `high`; confirm the self-serve point (G1) |
| R5 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | Governed dashboards and a monthly metrics memo sit near a metrics layer. You haven't said you owned metric definitions or a semantic model, so the bridge isn't established | `[grounded]` your background; `[inferred]` adjacency from "governed dashboards" | G1 |
| R6 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads. Confirmed, with no sample yet | `[grounded]` your background | An anonymized memo would raise to `high` |
| R7 | Turn analysis into roadmap decisions with product managers | must_have | direct | medium | none | You present to the VP Product monthly, and the pricing test led to a measured retention outcome. Working with individual PMs on a roadmap isn't stated | `[grounded]` your background | Bring one example where an analysis changed a roadmap or pricing decision |
| R8 | Partner with clinicians | important | unclear | none | discovery | Nothing in your background says you worked with a domain-expert stakeholder group | `[grounded]` your background silent | G3 |
| R9 | Mentor two junior analysts | important | unclear | none | discovery | Mentoring isn't mentioned, so the claim is empty rather than contradicted | `[grounded]` your background silent | G2 |
| R10 | Healthcare data experience | preferred | absent | none | capability | You say you have never worked in healthcare | `[grounded]` your statement | Carry as a named gap; don't claim it |
| R11 | HIPAA | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the warehouse's consent-state model. That is the nearest evidence; it did not exercise health-record handling | `[grounded]` your background; `[generic]` that HIPAA rules for health data differ from consumer-privacy regimes | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R5, must_have) | discovery | Dashboards and a metrics memo; no statement of who defined and maintained metric definitions | A must-have at `adjacent`; confirming it could move R5 to `direct` and lift the decision toward `go` | Writing LookML or equivalent definitions; maintaining one agreed definition of a metric such as retention across teams; retiring conflicting definitions | LookML excerpt, a metrics glossary, a definitions doc | `[grounded]` your background; `[inferred]` that the answer moves R5 |
| G2 | Mentoring (R9, important) | discovery | No mention | An explicit duty of the role, so a blank here is more visible than a modest answer | Onboarding a new analyst; reviewing others' queries; informal coaching; a formal direct report | A short description of who and for how long | `[grounded]` your background silent |
| G3 | Clinician-style partnership (R8, important) | discovery | No domain-expert stakeholder work stated | The role's "clinicians" are the unfamiliar half of the stakeholder set | Working with nutritionists, culinary or ops specialists to shape a test or a metric. Not asked this turn; it ranks below G1, G2 and C1 | A project note | `[grounded]` your background silent |
| G4 | HIPAA adjacency (R11, preferred) | transferability | Consent-state model and GDPR/CCPA PII handling | Carries the case that you can learn regulated data handling | Access controls, retention rules, consent logic, audit trails | A one-page description of the consent-state model | `[grounded]` your background. Limit: it is consumer consent, not health records |
| G5 | Healthcare domain (R10, preferred) | capability | None | A preferred item only; real but unlikely to decide alone | Closure path: a HIPAA awareness course, plus reading the care-navigation space before interviews | A completed course certificate | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established — research unavailable this run | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay and location unstated | unknown | — | JD header names neither | The range may sit outside your floor, which isn't given, or may simply not appear in what was pasted | `[inferred]` from the JD's silence | What is the salary range, and where or how is the role based? | unresolved |
| RR3 | Success measures unstated | unknown | — | "Own product analytics for our care-navigation app" | Accountability may come without a definition of success | `[inferred]` from the JD's scope language against its silence on outcomes | What would success look like at six and twelve months? | unresolved |
| RR4 | Concrete scope and team | positive_signal | — | "mentor two junior analysts" | The role comes with named stakeholders and a defined team | `[grounded]` JD | Who would I report to, and how are the two analysts' priorities set today? | noted |

## Application plan

Every row below is proposed. Resume edits are `resume_edits_pending_approval`, and the other rows are `pending your approval`. That covers the advice as well as the edits. Each line traces to a sentence you wrote; nothing here goes anywhere until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with: "Designed and ran the experimentation program, 30+ A/B tests a year, including the pricing test behind an 11% retention lift." | R3, your strongest requirement match | `[grounded]` your background | resume_edits_pending_approval |
| E2 | "Built the company's Looker instance from scratch — 40+ governed dashboards." Don't write "self-serve" until you've confirmed it (G1) | R4, R5 | `[grounded]` your background | resume_edits_pending_approval |
| E3 | "Built the consent-state model for our warehouse; handled GDPR/CCPA consumer PII." Don't write HIPAA or health data | R11 | `[grounded]` your background | resume_edits_pending_approval |
| E4 | In the cover note, say plainly you haven't worked in healthcare, and name the consent-state work as your nearest experience | R10, R11 | `[grounded]` your statement | pending your approval |
| A1 | Confirm the posting on Harborlight's own careers site before investing effort | RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask RR2, RR3 and RR4's questions in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the call was refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range US 2026"; the call was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can save all of this as `tuesday-dossier.md` if you'd like a copy to carry forward.

## Upgrade menu

- Search permission, so targets 1 and 2 can run → RR1 and RR2 get checked, and market calibration is drawn.
- A deeper research pass on Harborlight (funding, leadership, hiring patterns; up to 5 more searches and 2 more fetches) is available once the first pass runs.
- An anonymized experiment readout → R3 to `high`.
- A LookML sample, a metrics glossary or a dashboard screenshot → R4 to `high` and a firmer R5.
- An anonymized monthly metrics memo → R6 to `high`.
- A sanitized SQL sample → R2 to `high`.
- Your actual CV, if it differs from what you typed → I'd re-check the map against it.
- Your pay floor, location and work-authorization terms → hard-gate rows get built and checked.
- The hiring manager's name → scope read and positioning get sharper.

## Questions

G1 — Who owned the definitions behind your Looker dashboards: what did you personally define and maintain, in what tool, and did business users explore them without you?

G2 — Have you mentored or managed analysts, and if so how many, over what period, and what was your role?

C1 — What are your non-negotiables for this move: pay floor, location or remote, work authorization, schedule?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.