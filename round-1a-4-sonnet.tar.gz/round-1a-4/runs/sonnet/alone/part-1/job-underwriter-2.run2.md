I'll read the reference files the skill requires before building the assessment.
Running the L1 research now: two searches, one on Quartzline itself and one on role-family norms for API platform PMs.
Search permission was denied on both calls, so the web research didn't run. The assessment below rests on your JD and resume only, and the research table shows exactly what that cost.

## Decision snapshot

**No, this isn't a waste of your time. But it's a stretch, and the 3+ years PM requirement is the problem (R1, absent). Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R4, R5 · adjacent: R2 (Product management work), R3 (Shipped API or platform products) · absent: R1 (3+ years of PM experience)
- `important` — direct: R6 · unclear: R7 (Sales and support launches), R8 (Agile delivery), R9 (Adoption metrics)

R1 — titled years stay absent whatever the wording; R2 (`medium`) and R3 (`medium`) — real bridges, their limits named.

**Opportunity ledger.** The scope reads as concrete (RR6). The employer is unverified because research didn't run (RR1). Pay, work arrangement and success outcomes are unstated (RR2, RR3, RR4). It's unknown whether the 3+ years is firm (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The posting is confirmed live on Quartzline's own careers page (RR1).
  2. Someone on the hiring side confirms the 3+ years (R1) can be met with equivalent work, or you get a referral past it (RR5).
  3. Your API experience is framed as integrator-side, not as shipping API products, unless G3 confirms otherwise (R3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B. Not yet checked against its own site. | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform: discovery with integration partners, specs, delivery with two engineering squads, adoption metrics, launches with sales and support. | `[grounded]` JD |
| Scope read | One product surface, two squads and named activities. This reads as a normal mid-level platform PM scope, not a bundle of several roles. | `[inferred]` from the squad count and activity list against the "3+ years" bar |
| Seniority | Not stated. The 3+ years suggests mid-level rather than senior or associate. | `[inferred]` from the JD's years requirement |
| First-year outcomes | Not stated. Only "define and track adoption metrics" is named. | `[grounded]` JD silence |
| Pay, location, work arrangement | Not stated. | `[grounded]` JD silence |
| Market calibration | Not established. The role-family sweep didn't run, so I have no band for this title and scope. | — |
| Unknowns | Pay; location; first-year outcomes; roadmap decision rights; whether the years requirement is firm | `[grounded]` JD silence |
| Contradictions | None inside the JD text. The careers page was not checked. | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product management experience | must_have | absent | none | capability | You've said you have never held a PM title, so there is no titled PM tenure. The work near PM duties is carried on R2, so this row stays about the literal requirement. Postings that mark years as must-have are often screened literally, though some employers accept equivalent work. | `[grounded]` your statement; `[generic]` on how such requirements are screened | Ask whether equivalent work counts (RR5); see G1 |
| R2 | Product management work: roadmap, specs, delivery with engineering | must_have | adjacent | medium | transferability | Your CV has requirements documents, quarterly roadmap-input sessions, and coordination of engineers and product managers on custom builds. Limit: it shows no ownership of a roadmap, prioritization decisions or product outcomes. | `[grounded]` CV | A sanitized requirements doc or session summary would raise confidence; see G2 |
| R3 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the internal integration playbook. That is the consumer-and-integrator side. The CV doesn't show API design, versioning, documentation or launch ownership. | `[grounded]` CV | Confirm the triage-tool lead; see G3 |
| R4 | Technical fluency: API docs and schemas | must_have | direct | medium | none | The CV states Postman, SQL and OpenAPI reading, plus integration architecture work. No artifact has been inspected yet. | `[grounded]` CV | none |
| R5 | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your own engineers, client engineers and product managers, and ran client workshops and UAT. Sales is not mentioned, so it is split out as R7. | `[grounded]` CV | none |
| R6 | Run discovery with integration partners | important | direct | medium | none | Scoping workshops and quarterly client roadmap-input sessions are discovery with external parties. Your CV words these as "collecting client feedback", so the wording stays yours. | `[grounded]` CV | none |
| R7 | Coordinate launches with sales and support | important | unclear | low | discovery | The CV is silent on sales or support. | `[grounded]` CV silence | See G4 |
| R8 | Agile delivery | important | unclear | low | discovery | The CV never mentions sprints, backlogs or ceremonies. | `[grounded]` CV silence | See G5 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | The CV has no adoption measures. An earlier-conversation note about a support triage tool is an unconfirmed lead, so it prompts a question and is not counted as evidence. | `[grounded]` CV silence; memory lead unconfirmed | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | 3+ years PM experience (R1, must_have) | capability | No titled PM tenure and no direct PM evidence. Adjacent work is on R2. | It is the one must-have wording can't fix. The closure paths are a target where years aren't screened, a hybrid or product-owner role, or an internal move. | Any stretch where you formally owned a product area, acted as interim PM, or held product-owner duties on a custom build | Org chart, a handover note, a manager's written confirmation | `[grounded]` your statement; `[generic]` that these closure paths are common |
| G2 | Product management work (R2, must_have) | transferability | You supplied requirements and roadmap input and worked next to PMs. Limit: no sign you decided priorities or owned outcomes. | A credible bridge with its limit visible is stronger in interviews than an overstated one. | Deciding what got built first on a custom build; accepting or rejecting scope changes; turning many client asks into one requirement | A sanitized requirements doc, an excerpt of the playbook, a roadmap-input summary | `[grounded]` CV; `[inferred]` the limit, from the CV's silence on prioritization |
| G3 | Shipped API/platform product; adoption (R3 must_have, R9 important) | transferability | Integrator-side evidence only. A request-triage tool support agents adopted is an unconfirmed lead from an earlier conversation. | If you built and owned it, it could be your closest evidence of shipping something real users adopted. | A tool or workflow others used; who asked for it; what you decided; how you knew it was used | Usage figures, a screenshot, a short design note | `[inferred]` from the memory lead; unconfirmed |
| G4 | Launches with sales and support (R7, important) | discovery | The CV doesn't say whether implementation work involved sales or support. | A PM role like this one involves sales and support partners at every launch. | Go-live handoffs to support; joint account planning with sales; customer-readiness briefs | A handoff checklist, a go-live runbook | `[grounded]` CV silence; `[generic]` that PM roles of this kind involve sales and support |
| G5 | Agile delivery (R8, important) | discovery | Nothing on how the engineering work was run. | A lightly weighted requirement, and an easy one to close if true. | Sprint planning with engineers; backlog grooming; UAT tied to sprint demos | A sprint board screenshot, release notes | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Research didn't run, so nothing was checked either way. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | (no figure in the posting) | Pay may sit anywhere in the range, and there is nothing to compare against your floor. | `[grounded]` JD silence | What is the budgeted salary range for this role? | unresolved |
| RR3 | Location and work arrangement not stated | unknown | — | (not stated) | The role may be remote, hybrid or on-site. | `[grounded]` JD silence | Where is this role based, and what is the in-office expectation? | unresolved |
| RR4 | Success outcomes not stated | unknown | — | "define and track adoption metrics" | The JD names an activity (define and track metrics) but no target or first-year result. | `[inferred]` from the JD naming metrics but no targets | What would a successful first year look like, and which adoption numbers matter today? | unresolved |
| RR5 | Years requirement firmness unknown | unknown | — | "3+ years product management experience (must-have)" | The bar may be a hard filter or a proxy for "has done this kind of work". | `[inferred]` from the posting marking it must-have with no equivalence language | Would you consider equivalent work in integration and roadmap input in place of a PM title? | unresolved |
| RR6 | Concrete scope | positive_signal | — | "drive delivery with two engineering squads" | Named squads, a named product surface and named duties suggest a defined role. | `[grounded]` JD states them | Who sets roadmap priorities today, and does this role have the final say on them? | noted |

## Application plan

Everything here is proposed and `pending your approval`. That covers the CV edit, the positioning line and the other actions. Nothing is final, and nothing here claims anything your resume doesn't already say.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | `resume_edits_pending_approval`: move your roadmap-input line and your "coordinated engineers, client engineers and product managers" line up beside the integration bullet, wording unchanged | Surfaces R2 and R6 without adding a claim | `[grounded]` CV | pending your approval |
| E2 | Positioning line, proposed: "Seven years in solutions engineering and implementation, leading 30+ client integrations of our REST APIs; ran quarterly roadmap-input sessions collecting client feedback for product." Every clause traces to your resume. | Your strongest honest summary | `[grounded]` CV | pending your approval |
| E3 | Don't add "Product Manager" or "PM" to any title, and don't write "shipped API products" or "owned the roadmap". | Each would exceed the evidence (R1, R3, R2) | `[grounded]` R1, R2, R3 rows | pending your approval |
| W1 | A one-page sanitized write-up of one integration, from client discovery through requirements to go-live | A work sample would narrow R2's limit | `[grounded]` R2 row | pending your approval |
| A1 | Ask the recruiter or hiring manager about RR5 before investing in the loop, and try a referral instead of a cold application | A person who can weigh equivalent work is the way past a literal years bar. Some employers apply years requirements literally in screening. | `[generic]` role-family pattern, not a claim about Quartzline | pending your approval |
| A2 | Alongside this one, target product-owner, technical PM or integration-product roles with softer years bars, and ask whether your current employer has an internal route | R1 may keep this posting out of reach, so a second route reduces the risk | `[generic]` role-family pattern | pending your approval |

Offer beyond this assessment: a side-by-side of target role types for your pivot (for example platform PM against technical PM against product owner), because R1 may decide this posting and your pivot needs more than one door. Say yes and I'll build it.

## Evidence status

Verified: none yet. Unverified leads: a note from an earlier conversation about a request-triage tool that support agents adopted (unconfirmed; it only prompts G3's question).

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused when I tried them, one aimed at Quartzline's site and careers page and one at role-family norms. It would have checked that Quartzline exists as described and that the role is live (RR1, role reality). It stays unresolved. |
| 2. Role-family sweep | unavailable | It would have given a market band and scope norm for this title (market calibration, RR2, RR5). Not established. |
| 3. Hiring manager's public footprint | n/a | The JD gives no name, so there was no query to form. |

## Closing

If you'd like, I can save this as a `tuesday-dossier.md` to carry forward.

**Upgrade menu**
- Search permission → targets 1 and 2 run: RR1 can resolve, the role gets a market band, and the pay question (RR2) gets a comparison. A deeper L2 pass (up to 5 more searches and 2 more fetches) is also available; say the word.
- A link to the live posting or Quartzline's careers page → RR1 can close.
- Triage-tool details (what you owned, usage evidence) → G3, R3 and R9 can strengthen.
- A sanitized requirements doc, a playbook excerpt or a roadmap-input summary → R2, R4 and R6 can reach `high`.
- Your pay floor and location or remote needs → the hard-gates line resolves, and RR2 and RR3 become checkable.
- The hiring manager's name → the scope read and which of your stories to lead with.

**Questions**

G3 — I have an unconfirmed note from an earlier conversation about an internal request-triage tool that support agents adopted. Is that right? What did you personally own, who used it, and how did you know it was working?

G2 — On your custom builds, did you ever decide what got built or in what order, or was that always the PMs' call? Did the engineers work in sprints you took part in?

Constraints — Do you have a pay floor, a location or remote requirement, or anything else non-negotiable? The posting states none of these (RR2, RR3), so I can't check any of them yet.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.