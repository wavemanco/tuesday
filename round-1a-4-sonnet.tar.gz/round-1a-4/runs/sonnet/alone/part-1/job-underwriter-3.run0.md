I'll read the reference files the skill requires before building the assessment.
**No, this isn't worth pursuing on its current terms. R1 and R2, both hard gates, fail · Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in Austin 5 days a week), R2 (Base pay of $70–85k)
- `must_have` — direct: R3, R4, R5 · unclear: R6 (SEO and content)
- `important` — adjacent: R9 (Run seven functions as a team of one) · unclear: R7 (Brand and PR), R8 (Partnerships and sales ops)

R1 and R2 — terms the posting fixes and you rule out; R4 (`medium`) — direct, confirmed, waiting on an inspectable artifact; R6, R7, R8 — channels your intake doesn't cover; R9 — managing a team of 3–7 isn't running seven functions alone.

**Opportunity ledger.** The posting's terms conflict with both of your non-negotiables (RR3). Separately from fit, it bundles seven functions into one hire with no bench (RR1), normalizes evening and weekend work (RR2), pairs a head-level mandate with a base the posting doesn't justify (RR4), and leaves success undefined (RR5). The employer couldn't be checked (RR6). The CEO reporting line is a real positive (RR7).

- **Hard gates:** failed: R1 (On-site in Austin 5 days a week), R2 (Base pay of $70–85k)
- **Severe red flags:** RR3 (`severity: high`)
- **What would change this:** the posting would have to allow remote work from Portland and a base at or above your $150k floor. It says "no exceptions" on location and states $70–85k, so both terms would have to change at the employer's end. Wording on your side can't move either.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, "e-commerce enablement startup, Series A, profitable since day one," Austin office | `[grounded]` JD header; the company's own description, not checked |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and reporting | A team of one "to start"; reports to the CEO with a dotted line to the board | `[grounded]` JD |
| Working pattern | On-site 5 days a week, "no exceptions"; "evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Success measures | "Success metrics will evolve as we learn"; no first-90-day or first-year outcomes stated | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside," with no equity figures | `[grounded]` JD |
| Scope read | Seven named functions with one owner and no stated budget. A "Head of" title over a team of one is a title that signals ownership rather than staff | `[inferred]` from the function list against the JD's silence on budget and hiring plan; `[generic]` for the title pattern |
| Market calibration | Not established. The role-family search was refused, so no pay band is stated and none is taken from memory | `[generic]` fallback, no band fetched |
| Unknowns | Equity terms, channel budget, hiring plan, who the buyer is (merchant or consumer), who sits on the board | `[grounded]` JD silence |
| Contradictions | Not checked against a careers page, because the search was refused | `[grounded]` no fetch occurred |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week; your remote-only constraint (Portland, no relocation) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated constraint, which is specific and confirmed. The fit fails because the JD says "no exceptions" and you won't work on-site or relocate | `[grounded]` JD quote and your confirmed statement | Surface only; the employer changing terms or you revising the constraint is the sole resolution |
| R2 | Base of $70–85k against your floor of at least $150k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The top of the posted base is $65k under it, and unquantified equity doesn't count toward a base floor | `[grounded]` JD quote and your confirmed statement | Surface only; RR3's question is the one check that applies |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | You state 9 years in growth with Growth lead, then Head of Growth, at two B2C subscription companies. The split between leadership and individual-contributor years isn't stated, so I took the lower band. Years of experience are a requirement here, not a gate | `[grounded]` your intake, which is CV-equivalent | Moot while R1 and R2 fail; confirm the leadership-years split if you proceed |
| R4 | Paid acquisition | must_have | direct | medium | none | You say you owned paid and scaled one company from $8M to $40M ARR over three years with a budget you controlled. That's specific but not inspectable yet. Whether the playbook carries from B2C subscription to this buyer is unstated | `[grounded]` your intake; `[grounded]` posting silent on the buyer | Offer: a sanitized channel budget and results report would raise to high |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You say you owned lifecycle and are deep in Braze, SQL and GA4. It's confirmed but has no artifact yet | `[grounded]` your intake | Offer: a sanitized lifecycle dashboard export would raise to high |
| R6 | SEO and content | must_have | unclear | none | discovery | Your intake lists paid, lifecycle and experimentation and is silent on SEO or content. That means not established, not absent | `[grounded]` intake silence | See G2 |
| R7 | Brand and PR | important | unclear | none | discovery | Intake is silent on both | `[grounded]` intake silence | See G3 |
| R8 | Partnerships and sales ops | important | unclear | none | discovery | Intake is silent on both | `[grounded]` intake silence | See G3 |
| R9 | Run all seven functions as a team of one | important | adjacent | low | transferability | You built and managed teams of 3–7, which shows delegation and ownership. It doesn't show personally executing every channel without support, and the claim sits between bands, so I took the lower | `[grounded]` your intake; the limit is `[inferred]` from the team-management framing | See G4 |

Tiering R4 to R6 as `must_have` and R7 to R9 as `important` is my reading of the JD's list. The JD doesn't tier them itself.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Remote and pay terms (R1, R2, hard_gate) | hard_gate | The posting fixes both and you rule out both | Nothing in the other rows offsets a failed gate | None applies; wording can't solve it | A written statement from Novaline changing its terms | `[grounded]` R1 and R2 rows |
| G2 | SEO and content (R6, must_have) | discovery | Intake doesn't mention it | It's a named function of the role, but the status stays `no_go` while R1 and R2 stand | Owning a content calendar or organic-traffic targets; briefing writers or an agency; reporting on organic revenue | A content-performance report or organic-traffic dashboard | `[grounded]` intake silence |
| G3 | Brand, PR, partnerships and sales ops (R7, R8, important) | discovery | Intake doesn't mention them | The same: they'd raise rows without changing the status | Launch announcements or press coverage; affiliate or co-marketing deals; CRM or pipeline reporting for a sales team | Press links, a partnership agreement summary, a pipeline report | `[grounded]` intake silence |
| G4 | Solo execution across channels (R9, important) | transferability | You managed teams. Hands-on solo work across channels isn't shown | The role is staffed as one person | Periods where you personally ran several channels before the team was built | A first-year plan or scope document from an early stage at either company | `[inferred]` from the team-management framing |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Responsibility without resources: seven functions, no bench | risk_signal | medium | "You will be a team of one to start — we believe in players who don't need a bench." | The mandate may carry full revenue accountability without budget, tools or a hiring plan | `[inferred]` from the JD's function list against its silence on resources | What budget and tooling are committed for paid, content and PR, and when is the first hire planned? | unresolved |
| RR2 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | After-hours work may be routine rather than exceptional | `[inferred]` from "just who we are" normalizing the exception | In the last quarter, how often did the team work evenings or weekends, and how is that time recovered? | unresolved |
| RR3 | Terms conflict with your two non-negotiables (see R1, R2) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" and "$70–85k base" | The posting fixes the two terms you can't accept | `[grounded]` JD quotes against your confirmed constraints | Are the on-site requirement and the base range fixed for this role, or is a remote option or a different band possible? | confirmed |
| RR4 | Seniority and pay mismatch | risk_signal | medium | "8+ years growth leadership required" with "$70–85k base plus meaningful equity upside" | The base may sit below what a head-level, 8+ year, seven-function mandate usually carries, and the equity is unquantified. No market band was fetched, so this stays a hypothesis | `[inferred]` from the JD's own seniority language against its figure; market band not established | What equity is offered (percentage, vesting, strike), and how was the base set? | unresolved |
| RR5 | Absent success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be accountable for revenue with no agreed target | `[inferred]` from the JD's silence on outcomes against "own all revenue growth" | What revenue outcome would make the first year a success, and who decides that? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Reporting line to the CEO with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role has senior access | `[grounded]` JD states it | Who on the board does the dotted line reach, and how often? | noted |

RR6 stands because the searches were refused, not because anything was found against Novaline. Hold each question until you've asked it through contact details on Novaline's own website.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Pass on this posting at its current terms | See R1, R2, RR3 | `[grounded]` R1 and R2 rows | pending your approval |
| A2 | Optional: send one written question to Novaline, through contact details on its own website, asking RR3's question. Only Novaline changing its stated terms can resolve a gate | The posting says "no exceptions," so expect the answer to match | `[grounded]` JD quote | pending your approval |
| A3 | If you proceed regardless, carry RR1, RR2, RR4, RR5 and RR6's questions into the first conversation verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Put effort into other openings whose terms meet your two constraints | R1 and R2 are the deciding rows | `[grounded]` your stated constraints | pending your approval |

Every row above, and any advice around it, is proposed and not final until you approve it. No CV language is proposed.

## Evidence status

Verified: R1 and R2 claims, which are your stated constraints, user-confirmed. Every other row rests on your intake prose and is unverified.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A Head of Growth" and the call was refused. It would have established whether Novaline exists as described and the posting is live (RR6, role reality's contradictions row) |
| 2. Role-family sweep | unavailable | Searched "Head of Growth startup salary 2026 Series A base compensation" and the call was refused. It would have supplied the market calibration line and the pay comparison in RR4 |
| 3. Hiring manager's public footprint | n/a | No name was given (the posting says only "the CEO"), so there was no query to form |

## Closing

I can write this up as `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**

- Search permission for the two refused searches → RR6 and the contradictions row, and a pay band for RR4. A deeper L2 pass (up to 5 more searches and 2 more fetches) would run only on your word, and it can't change the status while R1 and R2 stand.
- Novaline's written answer on remote work and pay (RR3) → the only thing that could move R1 and R2.
- Equity terms and the channel budget from Novaline → RR1 and RR4 close.
- A sanitized channel budget and results report, or a lifecycle dashboard export → R4 and R5 move to `high`.
- Content-performance, press or partnership artifacts → R6, R7 and R8 firm up, with no effect on the status.

**Questions:** none this turn. Nothing a question could recover moves the status while R1 and R2 stand.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.