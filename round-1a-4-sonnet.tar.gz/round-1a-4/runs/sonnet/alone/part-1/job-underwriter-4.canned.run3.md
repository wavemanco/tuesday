I'll read the skill's reference files before building the assessment.
**Verdict: yes, apply, with one thing to confirm first.** The posting says fully remote, but Brindlemoor's own careers page says Leeds, four days a week (R1). Your fit looks strong on everything else. Status: `conditional_go`.

I read the posting and your background as the plan for this turn. I didn't have a CV document, only your summary.

## Decision snapshot

**Yes, you should go for it, provided the working pattern checks out. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (Monitor rating models)
- `important` — adjacent: R8 (Recommendations to underwriting and product)
- `preferred` — direct: R9

R1 — the posting and the careers page disagree on remote; R6b — monitoring isn't evidenced yet; R7 (`medium`) — you ran the tests, design ownership is unconfirmed.

**Opportunity ledger.** The role is clearly scoped and the hiring manager has a public pricing record (RR5). The working pattern is contradicted between two sources (RR1), the salary is withheld (RR2), and the company's footprint beyond its careers page is thin (RR3). The team and authority picture is unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed as compatible with you — R1, RR1; (2) you can evidence monitoring work on your GLM — R6b, G2; (3) the salary lands inside your range — RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. The role is live on `brindlemoor.co.uk`. Company stage and size: not found | `[grounded]` JD header; careers page fetched; a company search returned nothing |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Director of Pricing, Odile Varga | `[grounded]` JD and careers page |
| Working pattern | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | `[grounded]` JD you pasted against the fetched careers page |
| Compensation | Not stated. Senior pricing analysts at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900 (survey n=612). This is the market band, not Brindlemoor's offer | `[generic]` Pricewell 2026 survey, from the search result only; `[grounded]` the JD withholds a figure |
| Scope read | One product, "own" analytics. Nothing in the posting asks for people management or lists direct reports. Your lack of management experience isn't a stated requirement | `[inferred]` from the JD's requirements list and its silence on reports |
| First 90 days | Not stated. Likely a baseline rating model plus monitoring for the pet book | `[inferred]` from "build and monitor rating models" |
| Hiring manager | Odile Varga. Spoke at the 2025 Insurance Pricing Forum, "Small Books, Loud Errors", on monitoring rating models in small books. Previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result (LinkedIn page not fetched) |
| Unknowns | Team size, who else does pricing analytics, salary, working pattern, how large the pet book is | — |
| Contradictions | Remote (JD) against Leeds four days a week (careers page) | `[grounded]` both sources |

## Evidence map

Your background is prose self-report at intake, so `medium` is the ceiling until you show something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The posting and the careers page conflict, and you haven't told me your location or working-pattern needs. `none` here means no constraint stated yet, not a failure | `[grounded]` JD and careers page; no candidate constraint given | Answer the R1 question below; confirm with the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You have 5 years in pricing analytics at a UK motor insurer, 2 as senior analyst. Confirmed, no artifact inspected | `[grounded]` your summary | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "SQL and Python daily", stated but with no inspectable work | `[grounded]` your summary | A sanitized code sample would raise it to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Specific, but no model documentation inspected | `[grounded]` your summary | Sanitized model documentation would raise it to `high` |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD says underwriting or actuarial leads, so this matches the underwriting half | `[grounded]` your summary | A sanitized review deck would raise it to `high` |
| R6a | Build rating models | must_have | direct | medium | none | Same evidence as R4. The limit is a different line of business: motor, not pet | `[grounded]` your summary; `[generic]` pet and motor rating differ, so expect a probe on transfer | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" may include monitoring, but you didn't say so. Resolved downward, it stays `unclear` until you describe what you tracked | `[grounded]` your wording; `[inferred]` that maintenance may include monitoring | G2 |
| R7 | Design and read price tests | must_have | direct | medium | discovery | "Ran 14 price tests with the underwriting team" is clear. Whether you designed them, read the results and made the call isn't | `[grounded]` your summary | G3 |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | discovery | The underwriting side is covered by your tests and the quarterly review. Nothing shows work with a product team | `[grounded]` your summary; no product-side evidence | Optional recall prompt in G4 |
| R9 | Insurance experience a plus | preferred | direct | medium | none | Five years at a motor insurer is insurance experience. It isn't pet insurance, and the JD doesn't ask for pet | `[grounded]` your summary and the JD | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | Two sources disagree and your needs are unknown | Only you or the employer can settle it, and wording can't. It could turn this into a `no_go` | n/a | The employer's written confirmation of the pattern | `[grounded]` the conflicting sources |
| G2 | Model monitoring (R6b, must_have) | discovery | "Maintained" doesn't show what you tracked or what you did when it drifted | The hiring manager's public talk was about monitoring rating models, so this is probably where you'll be probed | Tracking actual against expected loss ratios or claims by segment; spotting a factor drifting after a rate change; a recalibration or refresh you led or contributed to; a monitoring pack someone else relied on | A sanitized monitoring report, a dashboard screenshot, a refresh note | `[grounded]` CV-level silence; `[inferred]` from the talk title that monitoring matters to this manager |
| G3 | Price-test ownership (R7, must_have) | discovery | You ran 14 tests but not who designed them or read the results | Designing and reading tests are two of the role's named duties | Choosing test cells, sample size or duration; reading results and adjusting for volume or mix; recommending a roll-out or a stop | A sanitized test write-up or a results summary | `[grounded]` your wording |
| G4 | Product-side recommendations (R8, important) | discovery | Underwriting is covered; product isn't | Lower impact than G1 to G3, so it isn't in the questions below | Pricing input to a product change; a segment or cover-level recommendation outside underwriting | A recommendation memo | `[grounded]` your summary |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicted | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | The posting copy may be out of date, or the role's terms may have changed. Which is right isn't known | `[grounded]` both quotes; the cause is open | Is this role fully remote, or office-based in Leeds four days a week? | unresolved |
| RR2 | Salary not stated | unknown | — | JD has no figure | The pay may sit inside the market band or outside it | `[generic]` Pricewell band; `[grounded]` the JD is silent | What base salary range is budgeted for this role? | unresolved |
| RR3 | Company footprint thin | unknown | — | The search for "Brindlemoor pet insurance insurtech" returned no results | The company may be new or small. This doesn't question the posting, which is live on its own domain | `[generic]` pattern for smaller companies, not a claim about this one | How large is the pet-insurance book, and how many people work in pricing? | unresolved |
| RR4 | Team and authority unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | You may be the only analyst, or one of several. Decision rights are unclear | `[inferred]` from "own" against the JD's silence on team | Who else works on pricing analytics, and which pricing decisions does this role make itself? | unresolved |
| RR5 | Clear scope and a named, experienced hiring manager | positive_signal | — | "build and monitor rating models, design and read price tests" | The mandate is concrete and the manager has a public pricing background | `[grounded]` JD, careers page, search result | Which of these duties would be the first priority for this role? | noted |

## Application plan

All rows are proposed only.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put your own three lines near the top of the CV, in your own words: "Built and maintained the GLM rating model for the young-driver book"; "Ran 14 price tests last year with the underwriting team"; "Present the quarterly pricing review to the head of underwriting". No new claims are added | R4, R7, R5 | `[grounded]` your summary | `resume_edits_pending_approval` |
| A1 | Confirm the working pattern through contact details on `brindlemoor.co.uk`, before you invest in interviews | RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | In a cover note, state plainly: "My pricing background is in motor insurance, not pet." It's your own sentence and shows you aren't hiding the transfer gap | R6a, R9 | `[grounded]` your summary | pending your approval |
| A3 | If you can evidence monitoring (G2), lead with it for Odile Varga. Her public talk was on monitoring rating models in small books | R6b | `[inferred]` from the talk title; `[grounded]` G2 is still open | pending your approval |
| A4 | Ask RR2, RR3 and RR4 verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Don't claim pet-insurance experience, people management, test design or monitoring work until G2 and G3 are confirmed | R6b, R7, R9 | `[grounded]` the map rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor Senior Pricing Analyst careers"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved the working-pattern contradiction (R1, RR1) and RR3 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey), snippet only. Moved the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga), snippet only. Moved the hiring-manager row and A3 |

Beyond Brindlemoor's own careers page, I found nothing that establishes the company, so company facts here rest on that page alone.

## Closing

I can write all of this up as `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**

- Your location and working-pattern needs, and your pay floor: R1 closes or fails, and RR2 is checked against your floor.
- Sanitized model documentation or a code sample: R3 and R4 move toward `high`.
- A sanitized monitoring report or refresh note: R6b moves from `unclear`.
- A sanitized price-test write-up: R7 moves toward `high`.
- Your actual CV: R2 to R9 are re-read against its wording, and E1 gets checked against it.
- Deeper company diligence (funding, leadership changes, news; up to 5 more searches and 2 more fetches): say the word and it runs.

**Questions**

1. **G1 (R1):** Do you need this role to be remote, or could you do Leeds four days a week? If it's the latter, where are you based?
2. **G2 (R6b):** On the young-driver GLM, what did you monitor, how often, and what happened when it drifted or a rate change landed? What was your part?
3. **G3 (R7):** On the 14 price tests, who designed them (cells, sample size, duration) and who read the results? What did you recommend, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.