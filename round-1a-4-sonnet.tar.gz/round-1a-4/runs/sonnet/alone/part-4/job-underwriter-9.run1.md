I'll read the reference files first.
Reading the offer against your background now. My web searches were refused, so what follows rests on what you pasted.

## Decision snapshot

**Yes, asking for bank details, PPS number and a passport scan after a written offer like this is routine onboarding, not a warning sign. On the job itself: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R10 (Two days a week in the Limerick office), R11 (Salary €38,000–€42,000 against your floor)
- `must_have` — direct: R1, R3, R4, R6, R8 · adjacent: R5 (Monthly payroll for 240 staff) · unclear: R2 (Irish PAYE, PRSI and USC)
- `important` — unclear: R9 (Answering staff payroll queries) · absent: R7 (Pension changes)

R5 — a credible bridge, its limits named; R7 — never done, carried as a risk; R2 — your payroll's jurisdiction isn't stated.

**Opportunity ledger.** The offer matches the ad on title, pay, hybrid pattern and reporting line (RR3). Pension-change ownership (RR1), payroll team cover (RR4) and the contract terms beyond "permanent" (RR2) are unanswered.

- **Hard gates:** none failed; unconfirmed: R10 (Two days a week in the Limerick office), R11 (Salary €38,000–€42,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your hotel-group payroll applied Irish PAYE, PRSI and USC, so R2 resolves (G1); (2) a handover or training for pension changes is agreed before you start (R7, RR1); (3) the pay, commute and notice terms meet your own limits (R10, R11); (4) the written contract confirms the terms (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad and offer; not checked on its own site |
| Mandate | Monthly payroll for 240 staff, starters, leavers, pension changes, monthly payroll-to-ledger reconciliation, staff queries | `[grounded]` ad |
| Offer terms | Permanent, €40,000, hybrid with two office days, reporting to Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Ad against offer | Title, hybrid pattern and two office days match; €40,000 sits inside the ad's €38,000–€42,000 | `[grounded]` ad compared with offer |
| Process | Two in-person interviews at their office, then a written offer from the employer's own domain | `[grounded]` your account |
| Onboarding asks | Bank details, PPS number and passport scan through a portal after you accept, original passport on day one | `[generic]` routine payroll and identity steps after a written offer that names the role and pay |
| Scope read | One payroll cycle with reconciliation and queries; it is unclear whether you would be the only payroll post | `[inferred]` from the ad's silence on team size |
| Unknowns | Probation, pension scheme, notice and start date, payroll software, who covers your leave, who handles pension changes now | `[inferred]` from what the ad and offer omit |
| Contradictions | None between ad and offer | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff at a hotel group, in your own account, with no artifact yet | `[grounded]` your stated background | Keep an employment reference to hand |
| R2 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your account doesn't say which country's rules the hotel payroll ran under, or what your certificate covered. The thread is real, because you ran payroll and hold a payroll certificate | `[grounded]` your account is silent on jurisdiction | G1 |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your stated background | none |
| R4 | A payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024, stated by you; awarding body not stated | `[grounded]` your stated background | Have the certificate copy ready |
| R5 | Run the monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Carries over: running a full payroll cycle end to end. Limit: your cycle was fortnightly, and your headcount was 90, not 240. Strengthener: a clear account of your cycle steps and controls | `[grounded]` your stated background; `[inferred]` adjacency | Describe your cycle steps for monthly use |
| R6 | Process starters and leavers | must_have | direct | medium | none | Stated as part of your hotel-group role | `[grounded]` your stated background | none |
| R7 | Process pension changes | important | absent | none | capability | You've said you never did these and your manager handled them. No direct or adjacent evidence, so it is carried as a risk with a closure path rather than a question | `[grounded]` your own statement | Agree a handover or training plan (A3) |
| R8 | Monthly payroll-to-general-ledger reconciliation | must_have | direct | medium | none | You describe doing the monthly payroll-to-ledger reconciliation | `[grounded]` your stated background | none |
| R9 | Answer staff payroll queries | important | unclear | low | discovery | Your account doesn't mention staff queries, though running payroll for 90 staff makes them plausible | `[inferred]` from the role's nature; `[grounded]` your account is silent | G3 |
| R10 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | low | hard_gate | You attended two interviews in person, but whether the commute works for you isn't stated | `[grounded]` your account; `[inferred]` from the in-person interviews | Question 2 |
| R11 | Salary €38,000–€42,000, offered at €40,000 | hard_gate | unclear | none | hard_gate | The offer is inside the ad's band, but your own floor isn't given | `[grounded]` ad and offer; floor not given | Question 2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI and USC (R2, must_have) | discovery | Payroll experience and a certificate, but no statement of which statutory rules they applied to | A must-have at `unclear`; confirming it is the biggest single thing that firms up the offer | Running Irish tax and PRSI deductions in your payroll; handling Revenue submissions; leaver and starter tax treatment; certificate modules on Irish payroll law | Redacted payslip layout, the certificate syllabus, a Revenue-return screenshot | `[grounded]` your account is silent on jurisdiction; `[generic]` that these statutory deductions are the core of Irish payroll work |
| G2 | Pension changes (R7, important) | capability | No direct or adjacent experience, by your own account | Part of the stated duties, so it will come up from day one | Closure path: ask for a handover or a short training plan, and learn their scheme's rules before starting | The scheme's rules or the employer's pension guide | `[grounded]` your statement; `[inferred]` that it is a day-one duty from the ad's wording |
| G3 | Staff payroll queries (R9, important) | discovery | Not mentioned in your account | Plausible but unconfirmed; low impact on the decision | Answering payslip or deduction questions, correcting errors, liaising with HR | None needed | `[grounded]` your account is silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pension changes listed as a duty, with no handover described | unknown | — | "process starters, leavers and pension changes" | You may be expected to own pension changes from the start, with the current owner unnamed | `[inferred]` from the ad's duty list against its silence on training | Who handles pension changes today, and what handover or training is there for them? | unresolved |
| RR2 | Terms beyond "permanent" and salary not stated | unknown | — | "permanent post of Payroll Administrator at €40,000 a year" | Probation, pension scheme, notice and holiday terms may sit in a contract not yet sent | `[generic]` written terms commonly follow an offer email | Can you send the written contract, including probation period, notice and pension scheme, before I accept? | unresolved |
| RR3 | Offer consistent with the ad on title, pay band, hybrid pattern and reporting line | positive_signal | — | "reporting to Declan Garvagh, Finance Manager, hybrid with two days a week" | The role is defined as advertised | `[grounded]` ad compared with offer | Is this a new post or a replacement, and who was in it before? | noted |
| RR4 | Payroll team size and cover not stated | unknown | — | "Run the monthly payroll for our 240 staff" | You may be the only payroll post, with no cover for leave | `[inferred]` from the ad's silence on team | Is this the only payroll role, and who covers payroll when you are away? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Enter bank, PPS and passport details only in the onboarding portal, reached from the address on Marrowgate's own website; if the link in the email differs, ring or visit the People team using contact details from that website | These details are routine after a written offer, and the portal address is the one thing worth checking | `[generic]` routine onboarding practice | pending your approval |
| A2 | Send RR2's contract question and ask for the written terms before you accept, inside the five working days | Accepting on an email alone leaves probation, notice and pension unknown | `[generic]` employers commonly expect such questions | pending your approval |
| A3 | Ask RR1 and RR4 in a call with Declan Garvagh before accepting, and agree a handover or training for pension changes | Your pension-change gap is your own, so the agreed plan is how it closes (R7) | `[grounded]` R7, RR1, RR4 | pending your approval |
| A4 | If you need more than five working days to check these, ask for the extra time in writing | The deadline is theirs and so is any flexibility | `[generic]` | pending your approval |
| A5 | Proposed wording, `resume_edits_pending_approval` does not apply as no CV edit is proposed; for the call: "I've run starters and leavers and the monthly payroll-to-ledger reconciliation, but pension changes were handled by my manager, so I'd like to understand the handover or training for them." Every clause traces to your own account | Saying it plainly protects you from being expected to know it | `[grounded]` your statements | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association"; the call was refused. It would have checked that the posting is live and the portal and domain match, feeding role reality's contradictions row |
| 2. Role-family sweep | unavailable | Searched "Payroll Administrator salary Ireland 2026 housing association"; refused. It would have calibrated the €40,000 against market norms |
| 3. Hiring manager's public footprint | unavailable | Searched "Declan Garvagh Finance Manager Marrowgate Housing"; refused. It would have informed the scope read and what to ask Declan Garvagh |

## Closing

I can write this up as a `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**
- Your salary floor, commute and notice period → R10 and R11 move from `unclear`, and the hard-gates line can say met or failed.
- A redacted payslip layout or the certificate syllabus → R2 firms up, and R1 and R4 can rise toward `high`.
- Marrowgate's careers page or portal address → the employer check on target 1 can be done by you now.
- Search permission → the three declined checks run, and a deeper pass of up to 5 more searches and 2 more fetches is available.

**Questions**
1. G1 (R2) — Did your hotel-group payroll apply Irish PAYE, PRSI and USC, and which of those did you run yourself, including Revenue submissions?
2. R10, R11 — Is €40,000 at or above the salary you need, does two office days a week in Limerick work for you, and is your notice period fixed or negotiable?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.