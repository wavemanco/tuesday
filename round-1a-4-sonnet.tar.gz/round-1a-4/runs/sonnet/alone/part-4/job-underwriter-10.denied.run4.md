I'll read the reference files the skill requires before building the assessment.
## Decision snapshot

**Yes, it's worth taking the call. I couldn't check Fernquay from here, so verifying it is a condition of going further. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R8 (Two days a week at our Galway office), R9 (Salary €52,000–€60,000)
- `must_have` — direct: R1, R2, R3, R4
- `important` — adjacent: R5 (Own the booking flow end to end), R6 (Run research calls with school owners), R7 (You would be our first designer)

R5 — checkout is one stage of a booking flow, its limit named; R7 (`low`) — you have not been the sole designer, the widest gap on the map.

**Opportunity ledger.** The employer could not be established from here (RR1), the equity terms are unstated (RR2), and what authority and support a first designer gets is unclear (RR3). Against that, the posting is specific about scope, pay and office days (RR4). No request for money, bank details or ID appears in the posting or the WhatsApp message, so the register has no entry for one.

- **Hard gates:** none failed; unconfirmed: R8 (Two days a week at our Galway office), R9 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a live hiring employer: RR1; (2) your own salary floor and office-day limits are checked against the posting: R8, R9; (3) what a first designer decides, and who supports them, is made concrete: RR3, R7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting; not independently established, see RR1 |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Working relationship | Closest to co-founder Ronan Kehoe; first call is with him and Saoirse, the CTO | `[grounded]` posting and WhatsApp message |
| Terms stated | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week at the Galway office | `[grounded]` posting |
| Scope read | A generalist solo-design post: one core flow, research and delivery, with no design peers | `[inferred]` from "first designer" plus "end to end" plus "research calls" |
| First-90-days outcomes | Likely an audit and redesign of the booking flow, plus a research rhythm with school owners; the posting states neither | `[inferred]` from the responsibilities list |
| Market calibration | Not done. No pay or scope sweep ran, so €52,000–€60,000 is not set against a market band here, and I won't quote a band from memory | `[grounded]` no sweep ran |
| Unknowns | Contract basis; equity terms; funding and runway; how many schools use the product; whether the "two engineers" include Saoirse | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the WhatsApp message; neither was checked against Fernquay's own site | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | `must_have` | `direct` | `medium` | `none` | Four years as a product designer at a Dublin travel-booking company, in your own words. Ronan's message says they read a checkout case study, but it hasn't been seen here, so the claim stays at the intake ceiling | `[grounded]` your background plus the WhatsApp message | Share the case study or a link, which could raise this to `high` |
| R2 | Strong Figma | `must_have` | `direct` | `medium` | `none` | "Figma daily" across four years is specific. "Strong" is a level an interviewer tests, and no file has been inspected | `[grounded]` your background | Be ready to screen-share a real file |
| R3 | You have run your own user research | `must_have` | `direct` | `medium` | `none` | You ran monthly usability sessions with customers. Who recruited, who synthesised and what changed are unprobed. R6 carries the limit on the kind of research | `[grounded]` your background | Have one session ready: what you ran and what changed |
| R4 | Happy working directly with engineers | `must_have` | `direct` | `medium` | `none` | You worked in a squad with four engineers. Two engineers and a CTO is a smaller, closer setup, but the working mode is the same | `[grounded]` your background | none |
| R5 | Own the booking flow end to end | `important` | `adjacent` | `medium` | `transferability` | You redesigned a checkout flow, which is one stage of a booking flow. Limit: nothing stated about the stages around it, or about owning them. Your verb is "redesigned", not "owned" | `[grounded]` your background; `[inferred]` that checkout is one stage of a booking flow | G2 |
| R6 | Run research calls with school owners | `important` | `adjacent` | `medium` | `transferability` | Your sessions were usability sessions with customers. Whether those were end travellers or business operators is not stated, so I read it as the narrower end travellers. Limit: discovery calls with small business owners are not shown | `[grounded]` your background | G2 |
| R7 | You would be our first designer | `important` | `adjacent` | `low` | `transferability` | You said you've never been the only designer. Your self-run monthly sessions are the nearest thing, but that they exercised sole-designer judgement is my inference, so the band stays `low` | `[inferred]` bridge from the sessions you ran; `[grounded]` your statement | G3 |
| R8 | Two days a week at the Galway office | `hard_gate` | `unclear` | `low` | `hard_gate` | You moved back to Galway last year, so the location looks workable. You haven't stated your own limits on days or commute, and the posting doesn't say which days | `[grounded]` your move and the posting | G1 |
| R9 | Salary €52,000–€60,000 plus 0.5–1% equity | `hard_gate` | `unclear` | `low` | `hard_gate` | The posting states the pay. You haven't given a floor, so fit against your needs can't be called | `[grounded]` posting; your floor not given | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Your own limits on pay and office days (R8, R9, `hard_gate`) | `hard_gate` | The posting states both terms. Neither your salary floor nor your limits on fixed office days are given | A gate the inputs don't settle stays open, and it is the cheapest thing to settle before investing in a loop | Your floor as a number; whether two fixed days in Galway suit your week | Your own statement is the evidence | `[grounded]` posting terms and the absence of your constraints |
| G2 | Booking-flow ownership and research with operators (R5, R6, `important`) | `transferability` | A checkout redesign and monthly usability sessions. Not stated: what you owned within the flow, and who sat in the sessions | These are the two main responsibilities of the post, and both rest on adjacent work | Deciding the flow beyond checkout, such as availability, confirmation or changes; sessions or calls with operators rather than end travellers | The checkout case study; a session plan or findings summary | `[grounded]` your background; `[generic]` that a first designer in a small booking company is likely to be probed on both |
| G3 | Working as the only designer (R7, `important`) | `transferability` | You have not been the sole designer. Adjacent evidence is the sessions and the redesign you ran | The posting makes this the defining condition of the role, and your answer sets how to position the rest | Choosing design direction on a slice with no design lead or peer; setting your own research cadence; making a call without sign-off from a design lead | A project note or a case study naming who decided | `[grounded]` your statement; `[generic]` that a lone designer is often tested on judgement without a design lead |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | `risk_signal` | `medium` | "We are six people in Galway making booking software for sea-kayak and surf schools." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | `unresolved` |
| RR2 | Equity terms unstated | `unknown` | — | "plus 0.5–1% equity" | The percentage may be before dilution, and the vesting, share class and exercise terms are not given | `[generic]` early-stage equity offers vary on exactly these points | What share class is this, how does it vest, and what is the fully diluted share count today? | `unresolved` |
| RR3 | Responsibility without stated authority or support | `unknown` | — | "You would be our first designer: own the booking flow end to end, run research calls with school owners" | The post may carry the booking flow's outcomes without stated decision rights, a design system, or a ready list of school owners to talk to | `[inferred]` from the scope language against the posting's silence on authority | Which product decisions does the first designer make alone, and how do you reach school owners today? | `unresolved` |
| RR4 | Specific terms and a reachable process | `positive_signal` | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | Pay, equity and office days are stated, and the posting asks for "one messy real project" over a polished deck. Ronan's message cites your checkout case study, which suggests your application was read | `[grounded]` posting and WhatsApp message | What would a good first quarter on the booking flow look like to you? | `noted` |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat the WhatsApp scheduling as ordinary. Before opening the video link, check that the emailed invite comes from an address on the domain of Fernquay's own website | Scheduling by chat for a video call is routine, and this is a check, not a condition | `[generic]` how interviews are commonly scheduled | pending your approval |
| A2 | On the call, ask RR1's question and RR3's question as written | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Ask RR2's equity question, and ask when the pay terms would be confirmed in writing | See R9, RR2 | `[grounded]` register | pending your approval |
| A4 | Lead with the checkout case study they already liked, and say its scope plainly: "I redesigned the checkout flow at a Dublin travel-booking company." Don't claim ownership of the whole booking flow | See R5; the claim stays at your verb "redesigned" | `[grounded]` your background; `[inferred]` that this is the strongest bridge | pending your approval |
| A5 | When R7 comes up, say you haven't been the only designer, then describe the monthly usability sessions you ran as the nearest thing | See R7; you can state it as it was | `[grounded]` your statement | pending your approval |

Every row above is a proposal, and the wording in A4 and A5 covers the advice as well as the table. Nothing is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | `unavailable` | Searches "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers" were refused because search permission was not granted. It would have moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | `unavailable` | Search "first product designer startup Ireland salary equity Galway 2026" was refused. It would have moved role reality's market calibration and set the pay against R9 |
| 3. Hiring manager's public footprint | `unavailable` | Search "Ronan Kehoe Fernquay co-founder" was refused. It would have moved role reality's scope read and which of your stories the plan leads with |

## Dossier offer and upgrade menu

If you want a `tuesday-dossier.md` to carry this forward, say so and I'll write it.

- Your salary floor and any limit on fixed office days → R8 and R9 resolve, and the hard-gates line firms up.
- A link to the live posting or to Fernquay's website → I can read it as an input, which bears directly on RR1 and the organization row.
- Permission to run web search → the three targets above would run, covering the employer's footprint, a pay band against €52,000–€60,000, and Ronan's public professional background.
- The checkout case study, or a Figma file or link → R1, R2 and R5 could rise toward `high`.
- Anything Ronan puts in writing on equity terms → RR2 closes.

## Questions

G1 — What is your salary floor for this move, and do two fixed office days a week in Galway work for you?

G2 — On the checkout redesign and the monthly sessions: what exactly did you own, and who were the people in those sessions?

G3 — Was there ever a stretch, even on one slice of the product, where you decided the design direction without a design lead or peer?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.