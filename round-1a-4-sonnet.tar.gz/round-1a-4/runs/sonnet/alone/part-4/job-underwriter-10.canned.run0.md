I'll read the skill's reference files before building the assessment.
Research is done. I'm reading the reframing-audit reference now, because the plan proposes wording for you to use. Then I'll write up the assessment.
**Yes, it's worth the call, and the WhatsApp is a routine way to schedule one: the message asks you for nothing except time. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (First designer, no design peer)

R7 is a credible bridge from checkout to the whole flow, its limit named; R8 is the real stretch, since you have never been the only designer; R2 turns on your pay floor, which I don't have.

**Opportunity ledger.** The posting states its pay and that pay is inside the survey band (RR1). The open items are where the role is listed on Fernquay's own site (RR2), the equity terms (RR3), runway (RR4) and what success looks like in the first months (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor sits inside the band (R2); (2) the role is confirmed through Fernquay's own channels (RR2); (3) the equity terms in writing and the runway answered on the call (RR3, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It has six people, is based in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is funded by its customers | `[grounded]` About page (fernquay.example/about) |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work closest with Ronan Kehoe | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office, the rest flexible | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | A survey of Irish product designers with 3 to 5 years' experience (n=520) gives a median base of €57,000 and an interquartile range of €51,500 to €62,000. The posting's range sits inside it. That is a survey band, not Fernquay's offer | `[generic]` Tillerby 2026 Ireland Design Salary Report; `[grounded]` posting figure |
| Scope read | A mid-level title with a senior-shaped remit: you would own the flow, the research and the process with no design peer | `[inferred]` from "first designer" and "end to end" set against "3+ years" |
| Hiring manager | Ronan Kehoe is listed as co-founder and CEO of Fernquay, and before that was a product lead at a Galway travel-software company for five years. I saw a search snippet only, not the full profile | `[grounded]` search result snippet (linkedin.example/in/ronan-kehoe) |
| Process | A 45-minute video call with Ronan and Saoirse, with an emailed calendar invite | `[grounded]` the message you pasted |
| Unknowns | Where the role is listed on Fernquay's site; equity terms; runway; first-six-month outcomes | `[grounded]` posting silence |
| Contradictions | The About page names Saoirse Doyle as a co-founder but gives no title, so "CTO" rests on the message. It also lists sailing schools, which the posting doesn't mention. Neither conflicts with the posting | `[grounded]` About page against posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, which meets the location term. Whether two office days suit you hasn't been stated | `[grounded]` your background, stated in prose | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so I can't say whether the range meets it. The range itself is inside the survey band | `[grounded]` posting; `[generic]` survey band | Question R2 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, confirmed in prose with no document inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | You use Figma daily. Their message mentions your checkout case study, which I haven't seen, so nothing is inspected | `[grounded]` your background and their message | A Figma file or the case-study link would raise this to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Whether you also recruited, wrote the guides and synthesised is unstated, and usability sessions test designs where the posting also mentions calls with school owners | `[grounded]` your background; `[inferred]` the usability-versus-discovery difference | A discussion guide or a synthesis, sanitised, would raise this to `high` |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned your company's checkout flow, which is one stage of a booking journey. The limit is that you haven't stated owning the stages around it, such as search, selection and confirmation | `[grounded]` your background; `[inferred]` adjacency from checkout to the full flow | G2 |
| R8 | First designer: no design peer or lead, so you set your own process | important | adjacent | low | transferability | You have never been the only designer. Adjacent: you redesigned checkout and ran monthly sessions, but whether you set those up yourself is unstated | `[grounded]` your statement; `[inferred]` the requirement from "first designer" | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | First-designer working (R8, important) | transferability | Team-embedded design work. Nothing yet shows you setting process, standards or priorities without a design lead | It is the stretch the posting itself describes, and a founder-led team is likely to probe it | Starting the monthly usability sessions yourself; writing component or pattern guidance others followed; defending a design call to a non-designer; any project where you covered design alone, including freelance or side work | The case study, a process note, a pattern-library page | `[grounded]` your statement; `[generic]` that small teams probe this |
| G2 | Booking flow beyond checkout (R7, must_have) | transferability | One confirmed stage, checkout, redesigned | The posting says "end to end", and the answer sets how the bridge is told | Search or availability screens, add-ons or upsells, confirmation and amend or cancel flows, a flow map you drew | A one-page flow map marking the stages you shaped | `[grounded]` your background; `[inferred]` stage list from the posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and inside the survey band | positive_signal | — | "Salary €52,000–€60,000" | The posting is transparent on pay and does not look underpriced for 3 to 5 years' experience | `[grounded]` posting figure; `[generic]` survey band | Is the range fixed, or does it move with experience? | noted |
| RR2 | Role not located on Fernquay's own site | unknown | — | "Product Designer — Fernquay" | The role may be listed elsewhere, or not yet on its site. The one careers address I tried was a guess and returned no page, which says little | `[grounded]` fetch returned no page; `[generic]` small companies often hire off-site | Where is this role listed on Fernquay's own site, and what are the stages after this call? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | A percentage means little without the instrument, vesting, cliff, strike price and dilution | `[generic]` pattern for equity offers | What is the instrument, the vesting schedule and cliff, and the strike price, if it is options? | unresolved |
| RR4 | Runway unstated | unknown | — | "six people in Galway" | The company is funded by its customers, so payroll depends on revenue. A new salary may stretch it, but nothing says it will | `[grounded]` About page says customer-funded; `[generic]` that small payrolls rest on revenue | How many months of runway does Fernquay have with this hire on payroll? | unresolved |
| RR5 | No stated outcomes for a broad mandate | unknown | — | "own the booking flow end to end" | Success may be unmeasured, with one designer expected to cover flow, research and process | `[inferred]` from the posting's scope against its silence on outcomes | What would a good first six months look like for this role? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take the call. Before it, check that the invite and video link come from an address on the domain on Fernquay's own website | A routine step; the check is advice, not a doubt | `[generic]` advice; `[grounded]` the site's domain | pending your approval |
| A2 | Lead with your checkout redesign and the monthly usability sessions, framed in your own words: "I redesigned our checkout flow" and "I ran monthly usability sessions with customers". Don't say "end to end" or "first designer" about your past | Ronan's listed background is travel software, so the booking overlap is the natural opening. R7 and R8 stay adjacent | `[grounded]` your sentences; `[inferred]` the reader's interest from his listed background | pending your approval |
| A3 | Bring one unpolished, real project, if you can share it | The posting says they "would rather see one messy real project than a polished deck" | `[grounded]` posting | pending your approval |
| A4 | Ask RR2 to RR5's questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Nothing above is sent or saved until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and fetched it. Also fetched fernquay.example/careers, a guessed address, which returned no page. Moved role reality's organization and contradictions rows, and RR2 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway 3+ years startup", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe), as a snippet only. Moved the hiring-manager row and A2 |

I can save this as a `tuesday-dossier.md` on request.

## Upgrade menu

- Your pay floor → R2 closes and the decision firms up.
- The case-study link or a Figma file → R4 to `high`, and R7 and R8 get checked against real work.
- A sanitised discussion guide or research synthesis → R5 to `high`.
- Saoirse's title and Fernquay's own listing of the role → RR2 closes.
- A deeper research pass on Fernquay (funding, customer reviews, press; up to 5 more searches and 2 more fetches). Say the word and it runs.
- Mock-interview prep for the call is a separate skill, `mock-interview`.

## Questions

R2 — What is the lowest salary you would accept, and does the equity matter to you?

G1 — Have you set something up or set a standard for a design team without a lead, and what did you own?

G2 — Which stages of the booking journey beyond checkout did you work on, and what were you responsible for?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.