I'm reading the skill's remaining reference files (evidence model, gap rules, research-tier rules) so the assessment follows its required format. Then I'll write it up.
**Worth applying for? Yes, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2, R3
- `must_have` — direct: R4 · unclear: R5 (Clear, timely written records)
- `important` — direct: R8, R10, R12 · adjacent: R6 (Small caseload of your own), R7 (Wound and leg-ulcer care) · unclear: R9 (Continence care), R11 (End-of-life visits)
- `preferred` — absent: R13 (Doppler assessment)

R6 (`medium`) — a credible bridge, its limit named; R5 — a must-have your CV is silent on; R13 — absent, carried as a minor risk.

**Opportunity ledger.** The advert is clear on duties and support, and it offers a named informal chat (RR2). Three things are unconfirmed: the posting was not found on the careers page I tried (RR1), the hours and rota are unstated (RR4), and where you would start in the pay range is unstated (RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm written-records experience, R5 and G1; (2) the post is confirmed live on Calderbrook's own channels, RR1; (3) the caseload and leg-ulcer bridges are framed as adjacent and Doppler as not held, R6, R7, R13.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` "About Calderbrook Community Health" page |
| Mandate | Join the district nursing team caring for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, on an electronic patient record | `[grounded]` advert |
| Working pattern | Pool cars and mileage are provided; hours, rota, weekend and out-of-hours cover are not stated | `[grounded]` advert; silence on hours |
| First-year outcomes | None stated | `[grounded]` advert silent |
| Scope read | A small caseload supported by a senior community nurse reads as a role that expects someone new to community work, so it is not an expert-level post | `[inferred]` from "small caseload" and "supported by a senior community nurse" |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse; at a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. That suggests Doppler is something her team treats as learnable, not that this post comes with training | `[grounded]` forum speaker page; `[inferred]` for the reading |
| Market calibration | The advert's £31,050–£37,800 plus mileage brackets a 2026 survey of England community Band 5 nurses (n=1,240: median £34,300, interquartile range £32,400–£36,600). The survey is a market pattern and not this employer's offer | `[grounded]` advert for the range; `[generic]` survey |
| Unknowns | Hours and rota; induction and sign-off for new community staff; where in the range you would start; whether the post is live on the careers page | — |
| Contradictions | None between the advert and the About page (adult community nursing, Halifax); the careers page was not found | `[grounded]` About page; fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states active registration, revalidation due March 2028. Stated, not checked; the register entry is yours to look up | `[grounded]` CV | You check your NMC register entry before applying |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | Your CV states a full category B licence. Stated, not checked; your driving record is yours to check | `[grounded]` CV | You check your licence record |
| R3 | Based in Halifax | hard_gate | direct | medium | none | You live in Halifax and the team is the Halifax district nursing team. Stated by you | `[grounded]` your message and advert | none |
| R4 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length of experience is not a gate | `[grounded]` CV | none |
| R5 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | Your CV is silent on records and on any system. Ward and home-visit work involve notes, but that does not show what you recorded or in what system | `[grounded]` CV silence | G1 |
| R6 | Hold a small caseload of your own, with senior support | important | adjacent | medium | transferability | Bridge: 18 months visiting patients at home on a discharge-to-assess secondment. Limit: you have never held your own caseload, so I won't call it that | `[grounded]` CV and your statement | G2 |
| R7 | Wound and leg-ulcer care | important | adjacent | medium | transferability | Bridge: wound care including pressure ulcers and surgical wounds. Limit: leg ulcers and compression are not in your CV | `[grounded]` CV | G4 |
| R8 | Catheter care | important | direct | medium | none | Stated on your CV | `[grounded]` CV | none |
| R9 | Continence care | important | unclear | low | discovery | Only catheter care is stated; wider continence care is not | `[grounded]` CV silence | G3 |
| R10 | Insulin administration | important | direct | medium | none | Stated on your CV. The advert also lists care planning, which your CV does not mention; I have not counted it here | `[grounded]` CV and advert | none |
| R11 | End-of-life visits | important | unclear | low | discovery | CV silent. Acute medical wards often involve end-of-life care, but that is a pattern and not your evidence | `[grounded]` CV silence; `[generic]` ward pattern | G3 |
| R12 | Visiting patients in their own homes | important | direct | medium | none | 18 months on a discharge-to-assess team, visiting patients at home in their first week after discharge | `[grounded]` CV | E1 |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have never done one. It is the advert's only desirable, so it is a minor risk and not a blocker | `[grounded]` your statement | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R5, must_have) | discovery | CV says nothing about documentation or systems | The only must-have row that is unclear, so resolving it decides whether condition 1 clears | Writing your own entries on the ward or on discharge-to-assess visits; any electronic record system you used; a record-keeping audit or sign-off | A competency sign-off, an audit result, or a reference naming your documentation | `[grounded]` CV silence; `[inferred]` that this moves the status |
| G2 | Own caseload (R6, important) | transferability | Home visits yes, a caseload of your own no | The advert's central duty, so the bridge and its limit decide how you frame the application | Planning your own day's visits; deciding who needed escalating; handing over to community teams | A discharge-to-assess team description or a reference from its lead | `[grounded]` CV and your statement |
| G3 | End-of-life and continence care (R11, R9, important) | discovery | CV is silent on both | Two duties the advert lists that your CV does not evidence | Caring for dying patients on the ward or at home; bowel and bladder care beyond catheters | Competency records or a reference | `[grounded]` CV silence |
| G4 | Leg-ulcer care and Doppler (R7, R13) | capability | Wound care yes; leg-ulcer compression and Doppler no | Doppler is the advert's only desirable; leg-ulcer care is named in the duties | Applying compression bandaging under supervision; a leg-ulcer clinic placement | A competency record | `[grounded]` CV and your statement. Closure path: ask whether the team trains new community staff in Doppler (RR2). No question this turn, to stay within the budget |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on the careers page I tried | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | I guessed one address and it returned no page, so the post may sit on a different page or a jobs board. That is not a sign of a problem | `[inferred]` from one failed fetch | Where is this post advertised on your own site, and is it still open? | unresolved |
| RR2 | Named contact and stated support | positive_signal | — | "supported by a senior community nurse … contact Rhiannon Mabbott, Community Nursing Team Lead" | The team lead is reachable and the role is built for someone developing in community work | `[grounded]` advert; `[grounded]` forum speaker page | What induction and sign-off do new community nurses get, and is Doppler training offered? | noted |
| RR3 | Start point in the pay range unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | Where you would be placed depends on how your five years are credited. A wide range is common in this kind of post | `[inferred]` from the range; `[generic]` for the pattern | Where in this range would my five years' experience place me? | unresolved |
| RR4 | Hours, rota and cover unstated | unknown | — | "end-of-life visits" | End-of-life visits may bring weekend or out-of-hours work. The advert says nothing about rota | `[inferred]` from the advert's silence | What are the working hours, and is there a weekend or on-call rota? | unresolved |

## Application plan

`resume_edits_pending_approval` — proposed CV edit. Each row below is proposed, not applied.

| # | Current CV wording | Proposed wording | Why | Provenance | Status |
|---|---|---|---|---|---|
| E1 | "Five years as a staff nurse on an acute medical ward at a district general hospital, the last 18 months seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge." | Lead the profile with the secondment: "Registered Nurse (Adult). Five years at a district general hospital, the last 18 months seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge." | See R12. This moves your strongest community evidence to the top and adds no fact | `[grounded]` your CV | pending your approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take Rhiannon Mabbott's offered informal chat before applying. Ask RR1, RR2 and RR4 as written | The advert offers it, and it can confirm the post is live | `[grounded]` advert | pending your approval |
| A2 | Don't claim a caseload or Doppler experience. Frame the secondment as adjacent to a caseload, and say you want Doppler training | See R6, R13 | `[grounded]` R6, R13 rows | pending your approval |
| A3 | Check your NMC register entry and your driving record yourself before applying | See R1, R2; stated, not checked | `[grounded]` R1, R2 rows | pending your approval |
| A4 | Add a written-records line only after G1 is answered | See R5 | `[grounded]` R5 row | pending your approval |

## Evidence status

Verified: none yet.

Your National Insurance number isn't needed here. I haven't used or repeated it, and you can leave it out of anything you send until a credible written offer asks for it. I haven't repeated your NMC number either.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, an address I guessed, and it returned no page. Moved the organization row and RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary Agenda for Change pay scales 2026/27", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the hiring contact row and RR2 |

I can save all of this as `tuesday-dossier.md` to carry forward if you want it.

## Upgrade menu

- A link to the live posting or Calderbrook's careers page → closes RR1.
- Your answer to G1 → resolves R5 and condition 1.
- Any inspectable artifact, such as competency sign-offs for insulin and catheter care, a record-keeping audit, or a reference from the discharge-to-assess lead → raises R8, R10 and R12 toward `high`.
- Your pay floor and hours limits → the hard-gates line can then be checked against your constraints, which it can't be now.
- Rhiannon's answers on pay placement, rota and induction → close RR3 and RR4.
- A deeper research pass on Calderbrook (staff and service reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Which record or system did you write your own entries in, on the ward and on discharge-to-assess visits, and has anyone audited or signed off your documentation?

G2 — On discharge-to-assess, did you plan your own day's visits, decide who needed escalating, and who did you hand over to?

G3 — Have you cared for patients at the end of life, or managed continence care beyond catheters? What did you personally do, and in what setting?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.