I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**Yes, it's worth taking the call, as long as Fernquay checks out (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R8 · adjacent: R6 (Research calls with school owners), R7 (Own the booking flow end to end)
- `important` — adjacent: R9 (First designer, no design peers)

R6, R7 — credible bridges, their limits named; R9 — adjacent, the sole-designer step to probe; R4 (`medium`) — confirmed, waiting on an artifact; R2 — waiting on your pay floor.

**Opportunity ledger.** The message asks only for a 45-minute video call. Nothing in it or the posting asks you to pay, deposit anything, or hand over bank, tax or ID details. I can't establish the firm from here, so check it before the call (RR1). Equity terms (RR2) and success measures and decision rights (RR3) are unstated, and pay, team size and hybrid terms are stated openly (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies, meaning the role appears on its own site and the invite comes from its own domain (RR1); (2) the salary meets your floor (R2); (3) after hearing how design decisions get made and who reviews your work, the sole-designer step is one you want (R9, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, "six people in Galway making booking software for sea-kayak and surf schools"; its existence is not established from here (RR1) | `[grounded]` posting; research not run |
| Role | Product Designer, the company's first designer | `[grounded]` posting |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers, work most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Pay and terms | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in the Galway office, the rest from wherever suits | `[grounded]` posting |
| Market calibration | Not run. The role-family search was not permitted, so the posting's figure is not set against a market band | `[grounded]` posting figure; no band |
| Scope read | A single-product remit: one designer, one core flow, research, and two engineers. The posting names no design peer or lead | `[inferred]` from the posting's list against its silence on design peers |
| First-90-days and first-year outcomes | Not stated | `[grounded]` posting silent |
| Hiring process so far | WhatsApp message from Ronan, calendar invite by email, 45-minute video call with him and Saoirse, the CTO | `[grounded]` your message |
| Unknowns | Equity instrument and vesting; success measures; decision rights; who gives design feedback | `[grounded]` posting silent |
| Contradictions | None between the posting and the message. Saoirse's name and CTO title appear only in the message. Neither text was checked against Fernquay's own site | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week at the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year, which meets the location term. Whether two fixed office days suit you is not stated, and no constraints were given | `[grounded]` your background and the posting | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | Confidence is `none` because no pay floor was given. The fit is `unclear` because nothing settles whether the offer meets one | `[grounded]` posting figure; floor not given | Question R2 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, stated in prose with nothing inspected yet | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed but nothing inspectable has been read. Ronan's message says they saw your checkout case study, so an artifact exists | `[grounded]` your background; `[grounded]` Ronan's message | Share the case study link or a Figma file to raise to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Usability sessions are one kind of research, so expect a probe on method and what you owned | `[grounded]` your background | Share an anonymised readout or interview guide |
| R6 | Run research calls with school owners | must_have | adjacent | medium | transferability | Your sessions were with customers. Limit: nothing shared shows calls with business owners or operators, or whether sessions were interviews or task tests. Medium, the lower band, because the adjacency is inferred | `[grounded]` your sessions; `[inferred]` adjacency to owner calls | See G1 |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow, which is one stage of a booking flow. Limit: ownership of the whole journey, or of an operator-side view, is not stated | `[grounded]` your checkout redesign; `[inferred]` scope gap | See G2 |
| R8 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R9 | Be the first designer, with no design peers | important | adjacent | medium | transferability | You have never been the only designer. You owned the checkout redesign and ran sessions inside a squad. Limit: working without design peers or review is not in what you've shared | `[grounded]` your statement; `[inferred]` from "first designer" in the posting | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Research with business owners (R6, must_have) | transferability | Monthly usability sessions with customers; not stated who the participants were or whether they were interviews or task tests | R6 is a `must_have` row at `adjacent`; the role names research calls with school owners | Calls with suppliers or partners who list on the platform; onboarding or feedback calls with business customers; synthesising support calls | Interview guide, synthesis, or readout, anonymised | `[grounded]` your sessions; `[inferred]` that owner calls differ from consumer sessions |
| G2 | Whole-journey ownership (R7, must_have) | transferability | Checkout redesign; the stages before and after it, and any operator-side view, are not described | R7 is a `must_have` row at `adjacent`; the role says "end to end" | Work on search, availability, cancellation or rebooking; any operator or admin tool you shaped | Journey map or before-and-after flows of what you owned | `[grounded]` your checkout redesign; `[inferred]` limit |
| G3 | Working as the only designer (R9, important) | transferability | Never the only designer; owned a redesign inside a squad | R9 is the step furthest from your history; the posting names no design peer | A project you scoped and decided largely alone; setting up a file or component structure; freelance or side work | One real, messy project, which the posting says it would rather see than a polished deck | `[grounded]` your statement and the posting; `[inferred]` the limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools"; your note that you can't find much about them online | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity terms unspecified | unknown | — | "plus 0.5–1% equity" | The instrument, vesting, strike price and share count behind the percentage are not given, so its value can't be judged | `[inferred]` from the posting's silence | Is the 0.5–1% options or shares, and what are the vesting schedule, strike price and fully diluted share count it is measured against? | unresolved |
| RR3 | Success measures and decision rights unstated | unknown | — | "own the booking flow end to end"; "work most closely with our co-founder, Ronan Kehoe" | The role may be accountable for the flow's results while decisions are shared with the co-founder and engineers, with no stated measure of success | `[inferred]` from the scope language against its silence on measures and authority | What would a good first six months look like, and who makes the final call on booking-flow changes when design and engineering disagree? | unresolved |
| RR4 | Pay, team size and hybrid terms stated concretely | positive_signal | — | "Salary €52,000–€60,000 … Hybrid: two days a week at our Galway office" | Concrete terms are checkable in the offer | `[grounded]` posting states them | Are these the terms an offer would be built on? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the call with the checkout case study Ronan said they liked. Describe it as the redesign of one flow, done inside a squad, with your part separated from the team's | See R4, R7; keeps the claim to what you stated | `[grounded]` your background and Ronan's message | pending your approval |
| P2 | Say plainly that you haven't been the only designer. If a real project fits G3, bring it; if none does, say so | See R9; honesty about the limit reads stronger than a stretch | `[grounded]` your statement | pending your approval |
| P3 | Ask RR1, RR2 and RR3 verbatim on the call. Add: who gives you design feedback? | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P4 | Before the call, check that the invite came from an address on the domain Fernquay's own website uses, and that the role appears on that site. Contact them through details on that site, not the chat | See RR1. Scheduling a video interview by WhatsApp is a routine step at small firms, not a warning sign | `[generic]` role-family pattern | pending your approval |

Every row above, and any wording suggested in it, is pending your approval. I have proposed no CV edits.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Fernquay booking software sea kayak surf schools Galway", "Fernquay product designer job Galway") were refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | One search ("product designer salary Ireland first designer startup Galway") was refused. It would have moved the market calibration row and a pay check on R2 and RR4 |
| 3. Hiring manager's public footprint | unavailable | One search ("Ronan Kehoe Fernquay co-founder") was refused. A name was given, so a query could be formed. It would have moved the scope read and which story the plan leads with |

If you'd like a portable record of this assessment, I can write it up as `tuesday-dossier.md` whenever you say.

## Upgrade menu

- A link to Fernquay's careers page or the posting's original source, and the domain the calendar invite came from: RR1 closes or stays open, and role reality's contradictions row gets checked. Links you give me are read as inputs, not charged as research.
- Your pay floor: R2 resolves.
- A link to the checkout case study or a Figma file: R4 and R7 can move toward `high`.
- An anonymised research readout or interview guide: R5 and R6.
- Your CV or portfolio link: the map is built from your prose, which counts as self-report.
- Permission to run the web searches that were declined: the company check, a market pay band for R2 and RR4, and Ronan's public professional footprint for the plan.

## Questions

1. R2 — What's the lowest salary you'd accept, and do you want the equity to count toward it? I'll check the €52,000–€60,000 against that.
2. RR1 — Can you paste the link to Fernquay's careers page or wherever you found the posting, and say which email domain the calendar invite came from?
3. G1 — In your usability sessions or elsewhere, have you spoken with business owners, such as suppliers or partners, rather than only consumers? What did you own, and what came of it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.