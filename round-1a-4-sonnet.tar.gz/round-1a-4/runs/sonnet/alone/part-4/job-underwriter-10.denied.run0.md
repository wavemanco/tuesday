I'll read the reference files the skill requires before building the assessment.
Short answer: yes, I'd take the call. But I couldn't check whether Fernquay exists as described, because web search wasn't permitted in this session. So my answer depends on that check.

## Decision snapshot

**Yes, take the call. The posting and the WhatsApp message ask you for no money, documents or personal details, but I couldn't confirm Fernquay from here, so the status is capped. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R6 (Own the booking flow end to end)
- `important` — adjacent: R8 (You would be our first designer), R9 (research calls with school owners)

R6 — a credible bridge from checkout, its limit named; R8 — no sole-designer history, as you said; R2 — waiting on your pay floor.

**Opportunity ledger.** The WhatsApp message and the emailed invite are scheduling for a video call, which is routine. The employer could not be checked from here (RR1). Equity terms, design decision rights and runway are unstated (RR2, RR3, RR5). The pay band and hybrid terms are stated plainly (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) the band clears your floor (R2); (3) on the call, decision rights and support for a first designer come back concrete (RR3, R8); (4) the equity terms are stated well enough to value 0.5–1% (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools. Not independently confirmed | `[grounded]` posting text you pasted |
| Mandate | First designer; own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office, the rest flexible | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity; equity terms not given | `[grounded]` posting |
| Scope read | Design, research and flow ownership sit with one person, which is consistent with a one-person design function. No success measures or first-year outcomes are stated | `[inferred]` from the posting's responsibilities against its silence on outcomes |
| Market calibration | Not run. The pay band is the posting's own figure and is not benchmarked | `[grounded]` posting; no sweep ran |
| Unknowns | Company existence and funding, equity terms, who decides the booking-flow priorities, the interview process after this call | — |
| Contradictions | None found between the posting and the message. Ronan Kehoe is named in both, and the message's checkout case study matches your background | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the office days are workable on their face. You haven't said whether you want two fixed office days | `[grounded]` your message | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The band is stated, but you haven't given a pay floor, so I can't say whether it meets it. I haven't benchmarked it either | `[grounded]` posting; no floor stated | G4: your floor |
| R3 | 3+ years of product design | must_have | direct | medium | none | 4 years as a product designer at a Dublin travel-booking company. Confirmed in your own words; CV not seen | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily." No portfolio inspected yet | `[grounded]` your background | A portfolio link would raise it to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. Specific and confirmed, no artifact yet | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned your company's checkout flow, which is one stage of a booking flow. What else you owned, and where your ownership stopped, isn't established | `[grounded]` checkout redesign; `[inferred]` the other stages unknown | G1 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R8 | You would be our first designer | important | adjacent | medium | transferability | You haven't been the only designer anywhere. The bridge is checkout work done with engineers. The limit is that you have not worked without a design peer | `[grounded]` your statement | G3 |
| R9 | Run research calls with school owners | important | adjacent | medium | transferability | Usability sessions with customers carry over. Whether you've run open-ended interviews, or with business owners, isn't stated | `[grounded]` your background; `[inferred]` the interview and audience limits | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking-flow ownership beyond checkout (R6, must_have) | discovery | A checkout redesign. Nothing on date or availability selection, confirmation, cancellation or payment-failure flows | R6 is the role's core mandate, and the call will test how far your ownership went | Designing date or slot selection, add-ons, confirmation or cancellation emails, refund or rebooking flows | The checkout case study Ronan mentioned, plus any before/after flows | `[grounded]` your background; `[inferred]` that the call tests scope |
| G2 | Research with school owners (R9, important) | transferability | Monthly usability sessions with customers | The role has you running calls with business owners. A usability session and an open-ended owner interview are different work, and the bridge must say so | Customer interviews before a redesign, calls with partner or supplier staff, research that changed a decision | A research summary or session guide, anonymised | `[grounded]` your background; `[generic]` that the two research types differ |
| G3 | Working as first or sole designer (R8, important) | transferability | You have not been the only designer | It is the largest step up from your history, and you'll want a truthful way to say it | A project with no design peer to review it, a side project, or a stretch between hires | A project write-up or design-decisions doc | `[grounded]` your statement |
| G4 | Pay floor against the band (R2, hard_gate) | hard_gate | Band stated; your floor unknown | The gate can't be marked met until your floor is known | — | — | `[grounded]` posting; your floor not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. My searches were not permitted, so this is untested, not a negative finding | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who else would I be interviewing with? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Without the instrument, vesting, strike price and share count, 0.5–1% can't be valued | `[inferred]` from the posting's silence on terms | Is the equity options or shares, what is the vesting schedule and strike price, and what is the fully diluted share count? | unresolved |
| RR3 | Decision rights and success measures unstated | unknown | — | "own the booking flow end to end" | Ownership is asserted. Who decides priorities, and what counts as success in the first year, isn't said | `[inferred]` from the scope language against the posting's silence | Who makes the final call on booking-flow priorities, and what would a good first year look like? | unresolved |
| RR4 | Pay band and working pattern stated up front | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week at our Galway office" | Pay and office terms are explicit | `[grounded]` posting | How was the band set, and does it move with experience? | noted |
| RR5 | Runway unknown | unknown | — | "We are six people in Galway" | The posting gives no funding or runway, so I can't tell whether a first design hire is funded for the long term | `[generic]` small companies often don't publish funding | How much runway does the company have at its planned team size, and is this role funded within it? | unresolved |

## Application plan

Nothing here is final until you approve it. That covers the table and the wording suggestions inside it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Join from the calendar invite in your email. Check its sender address is on the same domain as Fernquay's own website, and keep WhatsApp to scheduling | Routine step, with a cheap check | `[generic]` general practice | pending your approval |
| A2 | Lead with your checkout redesign and walk through it as a real, messy project. The posting says they'd "rather see one messy real project than a polished deck" | R6, and the posting's own preference | `[grounded]` posting quote | pending your approval |
| A3 | If asked about being the first designer, say it plainly: "I haven't been the only designer before. I've redesigned a checkout flow and run monthly usability sessions with customers, working in a squad with four engineers." | R8; every clause traces to your own sentences | `[grounded]` your background | pending your approval |
| A4 | Ask RR1, RR2, RR3 and RR5 verbatim | The register doubles as call preparation | `[grounded]` register | pending your approval |

No CV edits are proposed, because I haven't seen your CV.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers"; both refused. It would have moved the organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "first product designer startup Ireland salary equity 2026 Galway"; refused. It would have moved market calibration and R2's comparison |
| 3. Hiring manager's public footprint | unavailable | Searched "Ronan Kehoe Fernquay co-founder"; refused. It would have moved the scope read and the plan's positioning |

If you'd like this carried forward, I can save it as `tuesday-dossier.md`.

## Upgrade menu

- The company's website or careers page (a link, or pasted text) → RR1 and the organization row close, and `conditional_go` may become `go`.
- Your checkout case study and a portfolio link → R4 and R6 can reach `high`, and G1 closes.
- Your pay floor → R2 becomes `direct` or `hard_gate_fail`.
- A link to Ronan's professional profile → the scope read and which story to lead with.
- If you permit web search, I'll re-run targets 1–3. A deeper pass is also available on your word (up to 5 more searches and 2 more fetches).

## Questions

G4 — What is the lowest salary you'd accept, and does €52,000–€60,000 clear it?

G1 — Beyond the checkout redesign, which other parts of your company's booking flow did you personally design or change, and where did your ownership stop? Your checkout case study is the best thing to link.

G3 — Have you ever worked without another designer to review or hand off to, whether on one project, a side project or a gap between hires, and what did you decide on your own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.