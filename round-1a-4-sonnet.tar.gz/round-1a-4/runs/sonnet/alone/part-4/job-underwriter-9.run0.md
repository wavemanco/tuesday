**Yes, this is normal, and the order is the right way round.** They asked for these details after a written offer and after two in-person interviews, not before. The advice never to hand them over is aimed at requests made before there's any offer, or by someone you've never met. That isn't your situation.

**Why each item is routine**
- **Bank details:** they need these to pay you.
- **PPS number:** an employer needs it to register you with Revenue for PAYE, PRSI and USC. You'd collect the same thing from starters yourself.
- **Passport scan, then the original on day one:** employers have to confirm you can work in Ireland. A scan first and the original on your first day is a common way to do it. If you're an Irish or EU citizen, a scan is sometimes more than they strictly need, but asking for one isn't unusual.

**Checks before you enter anything**
1. **Check the sender.** The offer came from people@marrowgatehousing.ie. Compare that domain with the one on Marrowgate's own website. I haven't looked at their site, so I can't confirm it matches.
2. **Phone the office.** Use a number from their website, not one in the email. Ask the People Team to confirm the offer is from them, or mention it to Declan Garvagh, who you met at interview.
3. **Check the portal link.** When it arrives, make sure it sits on their own domain, uses https, and is something the People Team confirms they sent. Don't send these details as email attachments or by reply.
4. **Ask how they store and use the data.** Under GDPR they should be able to tell you who sees it and how long they keep it. A housing association will have a standard answer, and a payroll administrator is entitled to ask.

**Before you accept**
- The email is thin for a permanent offer. Ask for the written contract or terms: start date, notice, probation, pension arrangements, hours and hybrid details. Accepting "in principle" while you wait for these is reasonable, and you have five working days.
- This is an ordinary offer, not a negotiation, but €40,000 is mid-band for the advertised €38–42k. You could ask whether there's room, though that's optional.

**On the role itself**
You meet nearly every requirement. You have the qualification, three years of payroll, the reconciliation work and strong Excel. Pension changes are your one gap, and the ad lists them. Tell them in your acceptance or at onboarding that you've seen pension changes handled but not run them yourself, and ask who will walk you through the first cycle. This is a minor gap with a simple fix.

I can run a fuller assessment of the role if you'd like one. It would also cover the pay band, the company and your fit.