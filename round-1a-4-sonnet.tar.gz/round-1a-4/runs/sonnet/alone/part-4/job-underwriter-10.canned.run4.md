I'll read the skill's reference files first.
# Underwriting: Product Designer at Fernquay

## Decision snapshot

**Yes, it's worth taking forward, and Fernquay checks out from its own public pages (RR1). Status: `conditional_go`.** You've already applied and been invited to a call, so the live question is whether to take the call. I'd take it.

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R7 · adjacent: R6 (Own the booking flow end to end)
- `important` — adjacent: R8 (Research calls with school owners) · absent: R9 (Works as the sole designer)

R6 — checkout is one part of a booking flow, and the end-to-end scope isn't shown yet; R9 — you've never been the only designer; R2 — your pay floor wasn't given.

**Opportunity ledger.** The employer is established and the posting is consistent across sources (RR1), and the pay sits inside the market band (RR5). Open items are the equity terms (RR2), the company's runway (RR4) and who supports a sole designer (RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor sits at or below the range, R2; (2) the equity terms are explained in writing, RR2; (3) there is a credible answer on feedback and support for a first designer, R9, RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people, Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` About page, fernquay.example/about |
| Posting live and consistent | The careers page lists the same role, the same hybrid pattern (two days a week in Galway) and the same €52,000–€60,000 plus equity, and asks for one real project sent to jobs@fernquay.example | `[grounded]` careers page, fernquay.example/careers/product-designer |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Scope read | One person owning one product surface with two engineers is a first-designer remit: broad ownership, thin support | `[inferred]` from "first designer" and the two-engineer team |
| Market calibration | A 2026 Irish survey puts product designers with 3 to 5 years at a median base of €57,000, interquartile range €51,500–€62,000. The posted range sits inside it. This is a market band and not a Fernquay offer | `[generic]` role-family sweep, Tillerby 2026 Ireland Design Salary Report (n=520), as shown in the search result; `[grounded]` posting for the range |
| Co-founder footprint | Ronan Kehoe is listed publicly as co-founder and CEO, previously a product lead at a Galway travel-software company for five years | `[grounded]` public profile, linkedin.example/in/ronan-kehoe |
| Unknowns | Equity terms, company runway, who reviews design work, contract and notice terms | — |
| Contradictions | None found between the posting, the careers page and the About page | `[grounded]` pages read as above |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You say you moved back to Galway last year, so the office days look met. You gave no stated preference, so this is your location and not a confirmed constraint | `[grounded]` your message | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The posting states the range, but you gave no floor, so whether it is met is not established | `[grounded]` posting; your floor not given | G1 question |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Self-reported, no inspectable proof yet. Expect a probe | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed and specific. A portfolio file or published case study is what would inspect it | `[grounded]` your background | offer: link the checkout case study they already saw |
| R5 | Has run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. That is research you ran, but of one kind (usability) | `[grounded]` your background | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned your company's checkout flow, which is part of a booking flow. Nothing yet shows how much of the journey around it (search, selection, changes, cancellations) was yours | `[grounded]` your background; `[inferred]` that the wider journey is untested | G2 question |
| R7 | Works directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with customers of a travel-booking company. Whether they were consumers or business owners, and whether the work was usability testing or discovery interviews, isn't stated. Those are different kinds of research, so the bridge has a limit | `[grounded]` your background; `[inferred]` the limit from what was not said | G3 question |
| R9 | Works as the sole designer (first design hire) | important | absent | none | capability | You've never been the only designer. Roles like this usually also mean setting up tooling and process, with no peer review | `[grounded]` your statement; `[generic]` what sole-designer roles usually involve | G4: closure path, no question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor against the range (R2, hard_gate) | hard_gate | Range stated, your minimum not given | Fixes whether the hard gate is met, and whether an offer would clear it | — | — | `[grounded]` posting; your floor not given |
| G2 | Scope of booking-flow ownership (R6, must_have) | discovery | Checkout redesign confirmed; the rest of the journey is not | R6 is a `must_have` row at `adjacent`. Which parts were yours decides how to describe it | Owning steps before or after checkout (search, selecting dates, changing or cancelling a booking, confirmation emails); deciding what to build or cut, and not only how it looked | The checkout case study they saw, plus a flow map or before/after screens | `[grounded]` background gives checkout only; `[inferred]` that more of the journey may exist |
| G3 | Research with small-business owners (R8, important) | transferability | Monthly sessions with customers; type and audience not stated | The role centres on calls with school owners, and the closer your sessions were, the stronger the bridge | Calls with partners, operators or suppliers; discovery or interview-style sessions; a finding from a session that changed a design | A sanitized discussion guide or a findings readout | `[grounded]` background; `[inferred]` the audience gap |
| G4 | Sole-designer experience (R9, important) | capability | Stated as never done | The first-designer remit is the least covered part of your background | — | — | `[grounded]` your statement. Closure path: be candid, show your own initiative on process, and ask how design feedback would work (RR3). Carried as a risk |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer identity consistent across sources | positive_signal | — | "Six people, based in Galway." (About page) | Fernquay exists as described and the posting is live. Companies this small commonly have a thin footprint, which is why little shows up on a general search | `[grounded]` About page, careers page, co-founder profile; `[generic]` thin footprint pattern | Who else on the team would I work with day to day? | noted |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Percentage given without vesting, share type or a basis for value. The company is customer-funded, so the equity may be worth little or a lot | `[inferred]` from the posting's silence; `[grounded]` About page says funded by its customers | What vesting schedule applies, what class of shares are they, and what is the current ownership split? | unresolved |
| RR3 | Sole designer with no stated design support | risk_signal | low | "You would be our first designer" | Feedback, critique and design leadership may come only from the co-founders. Severity is kept low because the posting itself is open about it | `[inferred]` from "first designer" against no mention of review | Who reviews your design work today, and who decides priorities for the booking flow? | unresolved |
| RR4 | Runway and revenue not stated | unknown | — | "funded by its customers" (About page) | Customer-funded can mean steady revenue or a thin margin, and the posting says nothing on either | `[inferred]`; `[generic]` that small customer-funded companies vary widely in runway | How many schools pay for Kelproster today, and how far does current revenue cover the team's costs? | unresolved |
| RR5 | Pay inside market band | positive_signal | — | "€52,000–€60,000" | The posted range sits within the interquartile range for 3 to 5 years | `[grounded]` posting; `[generic]` survey band, a market pattern and not Fernquay's offer | Is there flexibility within the range for four years' experience? | noted |

## Application plan

I haven't proposed any CV edits. Every row below is proposed and pending your approval, and none is final until you approve it, prose included.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the calendar invite came from an address on fernquay.example, and compare it with jobs@fernquay.example on the careers page | Scheduling a video call over WhatsApp, with the invite by email, is a routine step. The invite is the thing worth matching | `[generic]` routine hiring step; `[grounded]` careers page address | pending your approval |
| A2 | Walk through the checkout case study as "I redesigned our checkout flow, working in a squad with four engineers", then say plainly which parts were yours and which the squad's | Your own sentence, with no wider ownership added. Ronan's background is travel software, so a booking-flow story is close to his own | `[grounded]` your background; `[inferred]` closeness from his profile | pending your approval |
| A3 | Say directly that you haven't been the only designer, and ask how feedback and priorities would work | Candour on R9, with a question that doubles as RR3 | `[grounded]` your statement | pending your approval |
| A4 | Ask the RR2, RR3 and RR4 questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | Decide your pay floor before the call | R2 stays unconfirmed until you do | `[grounded]` R2 | pending your approval |

## Evidence status

Verified: none yet. Everything about your background is unverified self-report until you confirm specifics.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay product designer careers Galway", which returned "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved role reality's organization and contradictions rows, and RR1. Employer is established, so no standing "not established" entry |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway 3-5 years experience startup", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved role reality's co-founder row and plan row A2 |

I'd like to offer the dossier file (`tuesday-dossier.md`) if you want to carry this analysis forward. Say the word and I'll produce it.

## Upgrade menu

- A link to the checkout case study they saw, or its Figma file → R4 and R6 can be inspected, and R4 can reach `high`.
- A sanitized discussion guide or findings readout from your usability sessions → R5 can reach `high`, and G3's bridge gets narrower.
- Your pay floor → R2 closes as met or failed.
- Their answers on equity, runway and design support → RR2, RR3 and RR4 close, and `conditional_go` likely simplifies to `go` or `no_go`.
- A deeper research pass on Fernquay (customer and employee reports, any recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

- **G1** — Is there a minimum salary below which you wouldn't take this, and how does it compare with €52,000–€60,000?
- **G2** — Besides checkout, which parts of the booking journey (search, picking dates, changes, cancellations, confirmations) did you personally design or decide, and what happened as a result?
- **G3** — In your monthly usability sessions, who were the customers (consumers, or business owners such as operators), and was the work testing designs or interviewing them about their needs?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.