# Job Underwriting Assessment: Community Staff Nurse, Band 5 at Calderbrook Community Health CIC, Halifax

## Decision snapshot

**Yes, this is worth applying for, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R5, R7a, R8a · adjacent: R7b (Leg-ulcer care) · unclear: R4 (Clear, timely written records), R8b (Continence care)
- `important` — direct: R9 · adjacent: R6 (Own caseload and care planning) · unclear: R10 (End-of-life visits)
- `preferred` — absent: R11 (Doppler assessment)

R6 — the nearest evidence is the home-visiting secondment, its limit named; R7b, R8b, R10 — CV silent, not shown absent; R11 — never done, a preferred row.

**Opportunity ledger.** The employer is attributable and the pay is stated (RR3). Supervision and pool cars are named in the advert (RR4). Three things are unconfirmed: the posting could not be found on the careers page I tried (RR1), the rota is unstated (RR2), and the post's induction and training are unstated (RR5).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`), both stated in your message and not checked by me; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live and the rota is known (RR1, RR2); (2) any leg-ulcer, continence or end-of-life experience you do have is recovered and evidenced (R7b, R8b, R10), and anything you don't have is stated as a gap; (3) R6 and R11 are framed as nearest-experience and not-yet, never as held skills.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | A community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` Calderbrook "About" page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, on an electronic patient record | `[grounded]` advert |
| Structure | A small caseload of your own, supported by a senior community nurse; pool cars provided | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage. The advert doesn't give the mileage rate | `[grounded]` advert |
| Market calibration | A 2026 survey of English community staff nurses at Band 5 (n=1,240) gives median basic pay £34,300 and an interquartile range of £32,400–£36,600. The posted range brackets that range. In the same survey 24% had a pool or lease car, so the posted pool cars are on the better side. One survey, one source | `[generic]` Wardround 2026 pay guide; `[grounded]` advert for the posted figures |
| Contact | Rhiannon Mabbott is listed as Community Nursing Team Lead for the Halifax district nursing team, after eleven years as a district nurse. She spoke at a 2025 forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page (search snippet) |
| Scope read | Leg-ulcer care looks like a live interest of the team, so R7b and R11 are likely to come up in conversation. Doppler training for newcomers is on her agenda, but nothing here shows this employer offers it | `[inferred]` from the speaker page set against the advert's "desirable" line |
| First-year outcomes | Not stated | `[grounded]` advert silent |
| Unknowns | Rota, weekends and on-call; caseload size; induction and competency sign-off; mileage rate; closing date | — |
| Contradictions | None between the advert and the About page. The careers page address I tried returned no page (RR1) | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active Adult registration, revalidation due March 2028. This is your statement, not something I checked | `[grounded]` your message | You check your own NMC register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Not checked by me | `[grounded]` your message | You check your licence and driving record are current |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. This is a length-of-experience requirement, so it is not a gate | `[grounded]` your message | none |
| R4 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | The CV says nothing about records or systems. Ward nursing involves record-keeping, but which systems you used is not stated | `[grounded]` CV silence; `[generic]` that ward and community nursing both involve patient records | Name the system(s) you have recorded on, if any; later question |
| R5 | Caring for patients in their own homes | must_have | direct | medium | none | 18 months seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge. The limit: short post-discharge visits are not the same as a continuing housebound caseload (see R6) | `[grounded]` your message | none |
| R6 | A small caseload of your own, with care planning | important | adjacent | medium | transferability | You have never held your own caseload. The nearest evidence is the home-visiting secondment. It does not show you carried patients over time or planned their ongoing care. The advert says a senior community nurse supports the caseload | `[grounded]` your statement; `[inferred]` the adjacency from the secondment | See G3 |
| R7a | Wound care | must_have | direct | medium | none | Wound care including pressure ulcers and surgical wounds | `[grounded]` your message | none |
| R7b | Leg-ulcer care | must_have | adjacent | low | discovery | Pressure-ulcer and surgical wound care is adjacent, but nothing says you have managed leg ulcers or applied compression. Low, because it rests on adjacency alone | `[inferred]` from the wound-care claim | See G1 |
| R8a | Catheter care | must_have | direct | medium | none | Catheter care is stated | `[grounded]` your message | none |
| R8b | Continence care (beyond catheters) | must_have | unclear | low | discovery | Continence care other than catheters is not mentioned | `[grounded]` CV silence | See G2 |
| R9 | Insulin administration | important | direct | medium | none | Insulin administration is stated. The advert pairs it with care planning, which sits under R6 | `[grounded]` your message | none |
| R10 | End-of-life visits | important | unclear | low | discovery | The CV is silent on palliative or end-of-life care. An acute medical ward may have given you this experience, but that is not established | `[grounded]` CV silence; `[generic]` that acute medical wards often care for dying patients | See G4 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have never done one. It is desirable, not essential, so it is a minor risk | `[grounded]` your statement | Closure path in G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R7b, must_have) | discovery | Wound care is stated, but nothing on leg ulcers or compression | It is named in the advert, and the team lead has spoken on leg-ulcer clinics. It is the gap most likely to come up in an interview | Dressing or reviewing leg ulcers on the ward or on discharge visits; applying or removing compression bandaging; referring to a tissue viability nurse | A competency record, a training certificate, a reflective account from revalidation | `[grounded]` CV silence; `[inferred]` that it will come up, from the speaker page |
| G2 | Continence care beyond catheters (R8b, must_have) | discovery | Only catheter care is stated | The advert pairs catheter and continence care | Bladder or bowel management plans, continence assessments, catheter-related infection reviews | A care plan template you used, a training record | `[grounded]` CV silence |
| G3 | Caseload ownership (R6, important) | transferability | Home visits on the secondment, with no caseload ownership. The limit is already named in R6 | A bridge with its limit named reads weaker on paper and holds up in interview | Planning your own visit list; deciding visit frequency; escalating changes to a GP or a senior nurse; follow-up visits to the same patients | A secondment job description or handover template | `[grounded]` your statement; `[inferred]` the bridge |
| G4 | End-of-life care (R10, important) | discovery | CV silent | The advert names end-of-life visits as a core duty | Last-days care on the ward, anticipatory medicines, family conversations, a care-of-the-dying pathway | A training record or reflective account | `[grounded]` CV silence; `[generic]` that acute wards may provide this experience |
| G5 | Doppler assessment (R11, preferred) | capability | You have never done one | It is only desirable. The closure path is to ask whether the employer trains staff, not to claim it | Not applicable: there is no adjacent experience to name | A course certificate, once you have done one | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | The posting is not confirmed live | unknown | — | "Current vacancies are listed on our careers page." (About page) | The careers address I tried returned no page. I guessed that address, so the vacancy may sit elsewhere, or be closed | `[grounded]` fetch returned no page; `[inferred]` that the guess may be wrong | Is this vacancy open, and what is the closing date? | unresolved |
| RR2 | Rota and on-call are unstated | unknown | — | "end-of-life visits" | The role may include weekend or evening cover, which the advert doesn't state | `[inferred]` from end-of-life visits against the advert's silence on hours | What is the rota, and are there weekends, evenings or on-call? | unresolved |
| RR3 | Pay is stated and set against the survey range | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The posted range brackets the survey's interquartile range, so pay is transparent and within the usual range. The mileage rate is not given | `[grounded]` advert; `[generic]` survey comparison | What is the mileage rate? | noted |
| RR4 | Support and vehicles are named | positive_signal | — | "supported by a senior community nurse"; "pool cars are provided" | A new caseload-holder has named senior support and does not need a personal car | `[grounded]` advert | How is the senior nurse's support structured: shadowing, case review, how often? | noted |
| RR5 | Induction and competency sign-off are unstated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | The post may expect leg-ulcer skills to be taught on the job, or may expect them on arrival | `[inferred]` from "desirable" against the advert's silence on induction | What induction and competency sign-off do new staff get, including leg-ulcer and Doppler training? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the secondment first in your experience, in your own words: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | R5, R6 | `[grounded]` your message | resume_edits_pending_approval |
| E2 | Add a top line giving your registration as Adult Nurse (active, revalidation due March 2028) and your full UK driving licence, category B | R1, R2 | `[grounded]` your message | resume_edits_pending_approval |
| E3 | Add leg-ulcer, continence or end-of-life lines only if your answers to G1, G2 and G4 confirm the experience. Until then, none of those lines is written | R7b, R8b, R10 | `[grounded]` the rows' own gaps | resume_edits_pending_approval |
| A1 | In the supporting statement, say plainly that you haven't held your own caseload or done Doppler assessment, and give the home-visiting secondment as your nearest experience | R6, R11 | `[grounded]` R6 and R11 rows | pending your approval |
| A2 | Take up the invitation to an informal chat with Rhiannon Mabbott before applying, and ask RR1, RR2, RR4 and RR5 verbatim | The advert invites the contact. The register doubles as your questions | `[grounded]` advert and register | pending your approval |
| A3 | Check your own NMC register entry and your driving record are current before you apply | R1, R2 are stated, not checked | `[grounded]` R1, R2 rows | pending your approval |

## Evidence status

Verified: none yet. A National Insurance number appeared in your message. It isn't needed for this assessment, I haven't used it, and I've left it out of everything here.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse district nursing Band 5 vacancy", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Role reality's organization row, and the contradictions row: the employer is established, the posting is not confirmed live (RR1) |
| 2. Role-family sweep | yes | Searched "district nurse Band 5 community staff nurse salary NHS Agenda for Change 2026/27 pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]` and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Read from the search snippet only, not fetched. Role reality's contact and scope-read rows, and A2 |

If you'd like, I can write all of this up as a `tuesday-dossier.md` you can keep.

## Upgrade menu

- A copy of the full job pack, or the careers-page link → RR1 closes and the closing date is known.
- Your minimum salary, hours or rota limits and any non-negotiables → the hard-gates line can be checked against them (it currently says checks against them unknown), and RR2 and RR3 resolve against your floor.
- A competency record, training certificate or reflective account on leg-ulcer, continence or end-of-life care → R7b, R8b and R10 can rise toward `high`.
- The system(s) you have recorded on → R4.
- The recruiter's answers on RR2, RR4 and RR5 → those rows close.
- A deeper research pass on Calderbrook (funding, leadership changes, staff and patient reports, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1 — Have you ever managed a leg ulcer, applied or removed compression bandaging, or worked alongside someone who did? What did you personally do?

G3 — On the discharge-to-assess secondment, did you plan your own visit list or decide how often to see each patient? Who did you escalate to?

G4 — Have you cared for dying patients on the ward or on discharge visits, such as last-days care or anticipatory medicines? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.