I'll read the skill's reference files before building the assessment.
# Job Underwriting Assessment — Product Designer at Fernquay

## Decision snapshot

**Yes, on what you've shared: it's worth pursuing, and Fernquay's own site and careers page match the posting, so it's a real hiring company. The WhatsApp message asks only for a 45-minute call and points to an emailed invite. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have` — direct: R3, R4, R5, R8 · adjacent: R7 (Own the booking flow end to end)
- `important` — direct: R10 · adjacent: R6 (Research calls with school owners), R9 (Operating as the first designer)

R7 — checkout is one segment of a booking flow, scope to confirm; R9 — first-designer work is new ground, a bridge rather than a match; R2 — your pay floor hasn't been given.

**Opportunity ledger.** The employer checks out against its own pages (RR1), and pay, hybrid terms and the ask for a real project are stated up front (RR2). Still open are design support around a first designer (RR3), equity terms (RR4) and how the role is funded (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. The pay band meets your floor (R2).
  2. The first-designer support and equity terms hold up when you ask about them on the call (RR3, RR4).
  3. The scope of "end to end" is confirmed as something you can own (R7, G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It has six people in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is funded by its customers | `[grounded]` search result for fernquay.example/about |
| Posting match | The careers page lists the same role, the same pay band and the same hybrid terms as your posting. It asks applicants to send one real project to a jobs@ address on the company's domain | `[grounded]` search result for fernquay.example/careers/product-designer |
| Contradictions | None on role, pay or location. The About page names sailing schools and Scotland, which is wider than the posting's wording but not in conflict | `[grounded]` About and careers results against the pasted posting |
| Mandate | Own the booking flow end to end, run research calls with school owners, and ship alongside two engineers. You'd work most closely with the co-founder | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| First 90 days / first year | Not stated | `[grounded]` posting silence |
| Scope read | You'd be the only design voice and the research owner for one product. That breadth is the point of a first design hire, not a stretched mandate | `[inferred]` from "our first designer" and the three stated responsibilities |
| Market calibration | Tillerby 2026 Ireland (n=520) puts product designers with 3 to 5 years at a median base of €57,000, interquartile range €51,500 to €62,000. The posting's €52,000–€60,000 sits inside that range. The survey covers designers generally, not first-designer or equity-bearing roles, so the equity is on top and has no band here | `[generic]` role-family survey result; `[grounded]` posting for its own figure |
| Hiring-manager footprint | Ronan Kehoe is listed as co-founder and CEO at Fernquay, and before that was a product lead at a Galway travel-software company for five years | `[grounded]` search result for his public professional profile |
| Reader read | A founder with a travel-software product background is a plausible reader for your booking-flow work | `[inferred]` from his stated prior role |
| Unknowns | Equity terms; what design exists today; who reviews design; how the role is funded | `[grounded]` posting silence |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the location is met. Whether two set office days suit you wasn't stated, which is why the band is `medium` | `[grounded]` your background | Confirm the office-day fit in G3 |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states the terms. You haven't given a floor, so nothing can say whether the gate is met. Confidence grades your own statement, and there isn't one yet | `[grounded]` posting and your silence on a floor | Ask G3 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. A length-of-experience requirement is graded like any other row, not as a gate | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is confirmed but has no artifact behind it yet. A Figma file or published case study would raise it | `[grounded]` your background | Share a Figma file or the case study (see upgrade menu) |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers, which you ran | `[grounded]` your background | none |
| R6 | Run research calls with school owners | important | adjacent | medium | discovery | Your sessions were with customers of a travel-booking company. Whether those were consumers or business owners isn't clear, and neither is whether you ran discovery conversations as well as usability tests | `[grounded]` your background; limit named | Ask G2 |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned a checkout flow at a travel-booking company, so the domain matches. Checkout is one part of a booking flow, and what you owned beyond it isn't stated | `[grounded]` your background; limit named | Ask G1 |
| R8 | Work directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R9 | Operate as the company's first designer | important | adjacent | medium | transferability | You've owned a flow and run a research cadence, but you have never been the only designer, so setting process and tools alone is untested. The row is `important` because the posting doesn't ask for it in those words | `[inferred]` from "our first designer" against your stated history | Bridge case in G4 |
| R10 | Show one real project (the posting prefers a messy real project to a polished deck) | important | direct | medium | none | Your checkout case study was already seen, and Ronan's message says they "loved" it. I haven't inspected it | `[grounded]` posting and WhatsApp message | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Scope of "booking flow end to end" (R7, must_have) | discovery | A checkout redesign, but nothing on search, availability, confirmation or changes after booking | It decides whether you can say you've owned a booking flow or only its payment step | Availability or date selection; confirmation emails; amending or cancelling a booking; the school-owner side of bookings, if there was one | Flow diagrams, before and after screens, the case study itself | `[grounded]` your background is silent beyond checkout; `[inferred]` that this is the likeliest probe |
| G2 | Research with business owners (R6, important) | discovery | Monthly customer usability sessions, but no detail on who the customers were or what the sessions covered | The role's research is calls with school owners, who are business owners rather than consumers | Interviews with partners, suppliers or small-business users; discovery calls before a design started; research that changed a decision | A session guide, a research summary, a quote bank | `[grounded]` your background; `[generic]` that business-owner research differs from consumer testing |
| G3 | Pay floor and office days (R2 and R1, hard_gate) | hard_gate | Terms stated; your floor and your view of two office days not given | A hard gate that nothing yet settles | Your current salary range, your minimum, any days you can't be in the office | None needed | `[grounded]` posting terms; your floor unknown |
| G4 | First-designer bridge (R9, important) | transferability | You've owned a flow and a research cadence, but always as part of a squad | A first design hire sets process alone | Evidence: the checkout redesign and the monthly sessions. Limit: you have not run design with no design peer. Strengthener: a short first-90-days outline for Fernquay, if you want to offer one | The case study | `[grounded]` your background; `[inferred]` the strengthener |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company exists as described and the posting is live. The thin public footprint you found is what a six-person company founded in 2023 would normally have | `[grounded]` About and careers results; `[generic]` that small young companies have thin footprints | Which schools use Kelproster today, and could I speak to one? | noted |
| RR2 | Terms and ask stated up front | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" and "we would rather see one messy real project than a polished deck" | Pay, location and what to submit are clear, and the pay sits inside the survey range | `[grounded]` posting; `[generic]` survey range | What happens after this call, and who else would I meet? | noted |
| RR3 | Support around a first designer | unknown | — | "You would be our first designer" | No design lead or peer to review work, and existing design may be undocumented | `[inferred]` from "first designer" against the posting's silence on current design | What design exists today (files, components, past research), and who reviews design work in a team of six? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Without type, vesting, strike price or dilution, the equity can't be valued | `[inferred]` from the posting's silence on terms | Is the equity options or shares, on what vesting schedule, and over how many shares in total? | unresolved |
| RR5 | How the role is funded | unknown | — | "funded by its customers" (About page) | The hire is paid from customer revenue, and the posting doesn't say whether the role is budgeted beyond the first year | `[grounded]` About page; `[generic]` that customer-funded teams' budgets track revenue | How is this role funded, and how has revenue moved over the past year? | unresolved |

## Application plan

Everything below is proposed, and nothing is finalized until you approve it. I haven't seen your CV, so there are no resume edits to propose yet.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take the call. Before you do, check that the emailed invite comes from the same company domain as the careers address (jobs@fernquay.example). Confirm the time on WhatsApp and keep the rest in the invite's email thread | The message asks only for a 45-minute call and says the invite is by email. Scheduling by messaging app is common in very small teams | `[grounded]` the careers page's address and your message; `[generic]` on small teams | pending your approval |
| A2 | Lead with the checkout redesign. Describe it in your own words: you redesigned the checkout flow, ran monthly usability sessions with customers, and worked in a squad with four engineers. Don't call it "end-to-end ownership" of the booking flow until G1 is answered | Each clause traces to your own sentences, and R7 stays `adjacent` until then | `[grounded]` your background | pending your approval |
| A3 | Ask RR3, RR4 and RR5 verbatim on the call, plus the pay question from G3 | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | State the R9 limit yourself: you have not worked as the only designer, and say how you'd set process in the first weeks | Naming the limit reads stronger than leaving it to be found | `[inferred]` from R9 | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay careers product designer", which returned "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved role reality's organization, posting match and contradictions rows, and RR1. Both pages were read as search-result excerpts, not fetched |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland first designer startup 3+ years", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved role reality's hiring-manager and reader rows. Public professional role only |

I can write all of this into a `tuesday-dossier.md` file if you'd like to keep it.

## Upgrade menu

- A Figma file or published case study link → R4 and R10 toward `high`, and the evidence for G1. In design, that file is the inspectable artifact.
- Your CV → checks the rest of the map and may surface experience it currently misses.
- Your pay floor and office-day limits (G3) → R2 and R1 close and the gate line firms up.
- Answers to G1 and G2 → R7 and R6 move toward `direct` or settle as `adjacent`.
- A deeper pass on Fernquay (customer reviews, hiring pattern, recent news; up to 5 more searches and 2 more fetches) → RR5 and RR3. Say the word and it runs.

## Questions

**G1** — Beyond checkout, what did you design in the booking flow at the Dublin company (availability, confirmation, amending or cancelling)? What did you own, and what did a squad member own?

**G2** — Who were the customers in your monthly usability sessions (consumers, or businesses and partners)? Did you ever run discovery conversations before a design started, and what changed because of them?

**G3** — What's the lowest salary you'd accept, and does the €52,000–€60,000 band clear it? Are two fixed office days a week in Galway fine, or are there days you can't do?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.