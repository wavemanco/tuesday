I've read the skill's rules. Next I'll load the web search tools and check whether Fernquay exists as described.
**Yes, it's worth taking the call, and the company checks out against its own public pages: `conditional_go`.** The conditions are small and are mostly things to ask on the call.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary meets your floor)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (First designer, no design peers)

R7 — a strong bridge from your checkout redesign, its end-to-end limit named; R8 — the main stretch, since you have never been the only designer.

**Opportunity ledger.** The company and the posting match its own pages (RR1), and the pay sits inside the survey band (RR3). The open items are the equity terms (RR4), the company's runway (RR5) and what support a sole designer gets (RR6). RR7 notes that the co-founder is a product person.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary meets your floor); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) equity terms are concrete and in writing, per RR4; (2) the business can fund the role, per RR5; (3) you get a straight answer on support and design review for a first designer, per RR6 and R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It has six people in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is funded by its customers | `[grounded]` Fernquay "About" page (search result) |
| Mandate | Own the booking flow end to end, run research calls with school owners, and ship alongside two engineers | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` JD and careers page |
| Compensation | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` JD and careers page |
| Scope read | Broad but coherent for a first designer: one product area, direct customer access, and no stated design leadership or review layer | `[inferred]` from the JD's scope against its silence on design support |
| Market calibration | Designers with 3–5 years in Ireland have a median base of about €57,000, with an interquartile range of €51,500–€62,000. The posted band sits around the middle of that. This is a pattern and not a claim about this employer's offer | `[generic]` Tillerby 2026 Ireland Design Salary Report; `[grounded]` JD for the posted figures |
| Hiring manager | Ronan Kehoe is co-founder and CEO, and was previously a product lead at a Galway travel-software company for five years | `[grounded]` public professional profile (search result) |
| Unknowns | Equity type and vesting; runway; who reviews design work; whether Saoirse's CTO title is as the message says (the about page shows her only as co-founder) | — |
| Contradictions | None between the JD, the careers page and the about page. The one difference is the channel: the careers page says to apply by email, and the interview invite came by WhatsApp | `[grounded]` careers page against your message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week in the Galway office | hard_gate | direct | high | none | You live in Galway, so the term is met | `[grounded]` your statement and JD | none |
| R2 | Salary €52–60k fits your floor | hard_gate | unclear | low | hard_gate | The posting states pay, but you haven't given a floor, so I can't check it | `[grounded]` JD; floor not given | Question R2 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | You have 4 years at a Dublin travel-booking company. This comes from your own account, and I haven't seen a CV or artifact | `[grounded]` your statement | CV or case study would raise it |
| R4 | Strong Figma | must_have | direct | medium | none | You use it daily. The case study they praised is probably the inspectable proof, but I haven't seen it | `[grounded]` your statement | Share the case study to raise it |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. The limit is that these are usability sessions, which may differ from open interviews with school owners | `[grounded]` your statement; `[inferred]` limit | Name the format you ran |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers. This team has two | `[grounded]` your statement | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | The strength is that you redesigned checkout for a travel-booking product, the same domain. The limit is that checkout is one stage and I don't know whether you owned the flows around it | `[grounded]` your statement; `[inferred]` limit | See G1 |
| R8 | First designer, no design peers (implied by the posting) | important | adjacent | low | transferability | You have owned a flow and a research cadence inside a squad, but never been the only designer. The posting says outright that this is a first design hire | `[grounded]` your statement and JD | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-to-end ownership (R7, must_have) | transferability | Checkout redesign is confirmed. Search, selection, payment, confirmation and post-booking changes are not described | The posting names the booking flow as the whole job | Work on search or availability, booking changes, cancellations or confirmation emails; deciding what shipped and in what order | The case study, a flow map, a before/after, or a launch note | `[grounded]` your summary; `[inferred]` that breadth is what the call will probe |
| G2 | Working as the only designer (R8, important) | transferability | Always in a design team or squad, never solo | Setting your own process and priorities is the core of the first-designer job | Starting research habits or a shared component set; making design calls without a design lead; a stretch when you were the only designer on a project | A short example of a decision you made alone and its outcome | `[grounded]` your statement; `[generic]` that first-designer roles probe this |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company exists as described. Its about page names Ronan Kehoe as co-founder, and the posting is live on its careers page | `[grounded]` about page and careers page (search results; I read the snippets, not the full pages) | Who else sits on the interview loop beyond you and Saoirse? | noted |
| RR2 | Pay stated and in market range | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The band is realistic for 3–5 years of experience | `[generic]` Tillerby survey band; `[grounded]` JD figures | Where in the band would this role sit? | noted |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The share type, vesting and the dilution basis are not given, so the value is unknowable | `[inferred]` from the posting's silence | What type of equity is it, what is the vesting schedule, and what is the total share count? | unresolved |
| RR4 | Runway unstated for a customer-funded company | unknown | — | "funded by its customers" | A six-person business with no outside funding depends on revenue to pay a new salary. That can be healthy or tight | `[inferred]` from the funding statement; `[generic]` for small bootstrapped firms | How long is the runway for this hire, and what is the revenue trend? | unresolved |
| RR5 | Support for a first designer unstated | unknown | — | "You would be our first designer" | No peer review, mentoring or design leadership is mentioned | `[inferred]` from the JD's silence | Who reviews your design work, and how are priorities decided? | unresolved |
| RR6 | Your reporting line is a founder | positive_signal | — | "work most closely with our co-founder, Ronan Kehoe" | Ronan's earlier role as a product lead suggests he can judge design work directly | `[grounded]` public profile snippet | How do you and Ronan split product decisions? | noted |

The register as numbered here differs from the IDs in my snapshot text. RR3 is equity (the snapshot called this RR4), RR4 is runway (called RR5), and RR5 is design support (called RR6). Use this table's IDs: RR3, RR4, RR5.

## Application plan

All of the language below is a proposal. Nothing becomes final until you approve it, and that covers the advice as well as the table.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the call with the checkout case study they already praised. Describe it in the scope you actually had, and name the usability sessions as your research practice | R4, R5, R7 | `[grounded]` your statement; `[grounded]` Ronan's message | pending your approval |
| E2 | Say plainly that you've worked in squads and not yet as the only designer. Give one example of a decision you made alone | R8 | `[grounded]` your statement | pending your approval |
| Q1 | Ask the questions in RR1 and RR3–RR5 on the call | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A1 | Scheduling an interview over WhatsApp is routine, and nothing in the message asks for money or documents. As a sensible habit, confirm the calendar invite came from a fernquay.example address, and join through the link in that email | Routine verification | `[generic]` ordinary practice | pending your approval |

## Evidence status

Verified: none yet. The CV facts above come from your own description and are leads until you share the case study or CV.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay product designer Galway careers", which returned "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). The company exists as described and the posting is live and consistent: it moved RR1 to a positive signal and the contradictions row |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup first designer 3 years experience", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). It set the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). It moved the scope read and RR6, and shaped E1 |

I read search-result snippets only. I haven't opened any full page.

I can write all of this up as `tuesday-dossier.md` if you'd like to keep it.

## Upgrade menu

- Your CV or the checkout case study would raise R3–R7 toward `high`.
- Your salary floor and any other non-negotiables would settle R2 and the hard-gates line.
- Ronan's answers on equity terms, runway and design support would close RR3–RR5.
- The sender address of the calendar invite would confirm A1.
- A deeper research pass on Fernquay (news, customer reports and leadership history; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1 — Beyond the checkout screens, which other parts of the booking journey did you own, and what did you decide yourself?

G2 — Has there been a project where you made the design calls with no design lead or peer to check with? What was it, and what happened?

R2 — What is the lowest salary you'd accept, and is there anything else about this role you can't compromise on?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.