I'm still reading the skill's reference files so the assessment follows its required format. After that I'll run the company research.
# Job underwriting: Product Designer, Fernquay

*Stage assumed: applied, with a first call offered. I wasn't told the stage, so say if it's wrong.*

## Decision snapshot

**Worth taking the call, on conditions. Fernquay is unverified from here (RR1) and the pay terms haven't been tested against your floor (R9). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R8 · unclear: R9 (Pay and equity against your floor)
- `must_have`: direct: R1, R2, R3, R5 · adjacent: R4 (Own the booking flow end to end)
- `important`: adjacent: R6 (Research calls with school owners), R7 (Being the first designer)

R4: checkout is one part of the flow, and the limit stays named. R7: you have never been the only designer, so frame it honestly. R9: waiting on your floor.

**Opportunity ledger.** Plausible but unverified. The employer isn't established from here (RR1), the equity terms and funding are unstated (RR3, RR5), and nothing says what design support the first designer gets (RR2). The pay range is stated up front and the scope is concrete (RR4, RR6). The WhatsApp scheduling takes no register entry (see A1).

- **Hard gates:** none failed (R8 `direct`); unconfirmed: R9 (Pay and equity against your floor); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a live employer through its own site (RR1); (2) the pay floor and the equity terms hold up (R9, RR3); (3) your sole-designer gap is framed as adjacent, never as solo ownership (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` JD |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` JD |
| Reporting | Works most closely with co-founder Ronan Kehoe, who messaged you; the call includes Saoirse, the CTO | `[grounded]` JD and WhatsApp message |
| Working pattern | Hybrid: two office days a week in Galway, the rest flexible | `[grounded]` JD |
| Compensation | €52,000–€60,000 plus 0.5–1% equity; vesting, share type and the share count the percentage refers to are unstated | `[grounded]` JD |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Scope read | Wide but coherent for a six-person product company: one flow, research and shipping, not several roles bundled. The risk is the missing design support, not the breadth | `[inferred]` from the responsibilities against the team size |
| Market calibration | Not established: my searches were refused, so there is no band to set €52–60k against | `[grounded]` JD figure; band unavailable |
| Unknowns | Where the posting was published and whether it is live; funding; equity terms; who reviews design work | n/a |
| Contradictions | None between the posting and the WhatsApp message: both name Ronan and describe a small Galway team | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company; self-reported, but Ronan has seen your case study | `[grounded]` your account | Link the case study so it can be read |
| R2 | Strong Figma | must_have | direct | medium | none | Daily use for four years; no inspectable file yet | `[grounded]` your account | Case study or file would raise to high |
| R3 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers: running them is stated. Whether you also planned and synthesised them is not | `[grounded]` your account | Confirm your role in the sessions |
| R4 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned checkout, one stage of a booking flow. Limit: the stages before and after checkout are unevidenced | `[inferred]` from checkout against the full-flow remit | G2 |
| R5 | Happy working directly with engineers | must_have | direct | medium | none | Four years in a squad with four engineers | `[grounded]` your account | None |
| R6 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with consumers of a travel-booking product. Calls with small-business owners are a different audience. Limit: no evidence of business-owner discovery | `[inferred]` from the sessions against the owner-call remit | G3 |
| R7 | Being the first and only designer | important | adjacent | medium | transferability | You have never been the only designer. Adjacent strengths: you owned a flow redesign inside a squad. Limit: no evidence of setting design direction alone | `[inferred]` the requirement is implied by "first designer" | G1 |
| R8 | Hybrid, two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway. Whether two fixed office days suit you is unconfirmed | `[grounded]` your move back to Galway | None |
| R9 | €52–60k plus 0.5–1% equity against your floor | hard_gate | unclear | none | hard_gate | Your floor wasn't given, so I can't test it. The market band was unavailable | `[grounded]` JD figure; floor unknown | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole-designer experience (R7, important) | transferability | Never the only designer | This is the likeliest probe in a first-designer interview | Solo stretches while colleagues were away, side or freelance projects, owning a decision with no design reviewer | A short note on one decision you made without a reviewer | `[inferred]` from "first designer" |
| G2 | Flow ownership beyond checkout (R4, must_have) | discovery | Checkout redesign only | The role owns the whole flow | Design work on availability, search, confirmation, changes or cancellations | The case study, plus any shipped before-and-after | `[inferred]` from the checkout evidence |
| G3 | Owner-side research (R6, important) | transferability | Consumer usability sessions | The role's research calls are with school owners | Any B2B, partner or supplier interviews you ran or sat in on | A sanitised discussion guide or findings summary | `[inferred]` from the sessions against the owner-call remit |
| G4 | Pay floor against the stated range (R9, hard_gate) | hard_gate | Floor unknown | A gate I can't test cannot be called met | Your own minimum base, with equity treated as upside | n/a | `[grounded]` floor not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small for a footprint, the posting may be stale or aggregated, or the role may not be a live hire. A thin footprint is common for a six-person company, so this is not evidence of a problem. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers page, and to where your site lists you and Saoirse? | unresolved |
| RR2 | First designer with no stated design support | unknown | — | "You would be our first designer: own the booking flow end to end" | Decision rights and review may sit informally with the founders | `[inferred]` from the JD's silence on who reviews design | Which design decisions would I make alone, and who reviews my work? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The value depends on share type, vesting, strike price and the share count behind the percentage | `[generic]` how equity at small companies works | Are these options or issued shares, what is the vesting schedule, and what share count does 0.5–1% refer to? | unresolved |
| RR4 | Pay stated up front | positive_signal | — | "€52,000–€60,000" | The salary is disclosed, which lets you test R9 early | `[grounded]` JD states the range | Where in the range would you place someone with my experience? | noted |
| RR5 | Funding and runway unstated | unknown | — | "We are six people in Galway" | A six-person company's runway shapes the risk of a first-designer hire | `[generic]` pattern for small software companies | How is Fernquay funded, and how many months of runway does it have? | unresolved |
| RR6 | Scope and evaluation stated plainly | positive_signal | — | "we would rather see one messy real project than a polished deck" | The role has a concrete remit and an evaluation approach you can prepare for | `[grounded]` JD | What would success on the booking flow look like in the first year? | noted |

## Application plan

Everything in this table is proposed, and nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat the WhatsApp message as routine scheduling. Open the video link from the emailed invite itself, and note whether the sender's address matches the domain on the company's own website | Scheduling by chat for a video interview that is held elsewhere is routine. The domain check is ordinary advice, not a finding | `[generic]` common practice at small companies | pending your approval |
| A2 | Lead with the checkout case study, which Ronan has already praised, for R1, R2, R3 and R4 | It is the evidence both founders have seen | `[grounded]` the WhatsApp message | pending your approval |
| A3 | Describe the checkout work as owning one flow inside a squad, never as sole design ownership | R7 is adjacent, and an overclaim would not survive the CTO's questions | `[grounded]` R7 row | pending your approval |
| W1 | Bring one messy real project from the checkout redesign, such as research notes, rejected directions and the engineering trade-offs, with confidential details removed | The posting says it prefers one messy real project to a polished deck | `[grounded]` JD | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR5 verbatim in the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Interview rehearsal for the call is a separate job for mock-interview, not this skill.

## Evidence status

Verified: none yet. Unverified leads: your four years, the checkout redesign, and the monthly sessions, all from your own account. I haven't seen the case study.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer Galway careers"; both were refused. A result would have set RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | I sent "product designer salary Ireland 2026 startup first designer"; it was refused. A result would have set the market calibration and the comparison for R9 |
| 3. Hiring manager's public footprint | unavailable | I sent "Ronan Kehoe Fernquay co-founder"; it was refused. A result would have shaped the scope read and A2 |

## Dossier offer

If you want, I can write all of this up as a `tuesday-dossier.md` to keep.

## Upgrade menu

- Search permission, so targets 1 to 3 can run: RR1 can close, the pay band can be set against R9, and Ronan's public professional footprint can inform A2.
- A deeper research pass (funding and leadership history, public employee reports, recent news; up to 5 more searches and 2 more fetches): say the word and it runs once search is available.
- A link to the live posting and the email domain of the calendar invite: RR1 can close from your side.
- A link to the case study: R1, R2 and R4 can rise to high.
- Your pay floor: R9 resolves.

## Questions

1. (R9, G4) What base salary would you need for this to be worth taking, treating the equity as upside?
2. (R4, G2) Beyond checkout, which other parts of the booking journey, such as search, availability, confirmation or changes, did you design or own, and what shipped?
3. (R7, G1) Have you ever carried design alone for a stretch, where no other designer reviewed your work?

You can answer in text, paste a link or a document, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.