I've read the skill's rules. Next I'm checking whether Velloway Logistics can be found on the public web, then I'll write the assessment.
**No, don't go ahead. RR1, RR2, RR3 and RR4 are severe red flags, so the status is `no_go`.** I'm going on what you've pasted and on three searches.

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Income of at least €30,000 a year)
- `must_have`: direct: R2, R3, R4
- `important`: unclear: R5 (A quiet place to work)

R2, R3, R4: your background matches, on your account alone; R1: the posting sets no floor against your €30,000.

**Opportunity ledger.** The messages ask for payment, a cheque transfer and bank, tax and ID details, all before any written offer, and run the whole process in chat (RR1, RR2, RR3, RR4). I couldn't establish the employer from public sources (RR5). The contact address is not on a Velloway-named domain (RR7), and the pay claim has no floor (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Income of at least €30,000 a year)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would change this:** you'd need an offer in writing, checked through contact details on the employer's own website. It would have to name the pay and hours, ask for no payment, cheque or ID details before you start, and follow interviews held by call or video.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". No website, careers page or other web presence turned up in two searches, so it is not established | `[grounded]` posting; `[grounded]` searches returned nothing |
| Mandate | "Remote Order Processing Coordinator". No duties, team, manager or client are named | `[grounded]` posting |
| Working pattern | Remote, "set your own hours", 15–30 a week | `[grounded]` posting |
| Pay as stated | "Up to €26 an hour plus commission". The posting gives no minimum rate and no commission rate | `[grounded]` posting |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Scope read | "No experience needed" beside a coordinator title and a top rate that is high for the entry level suggests the title and the pay are not tied to real duties | `[inferred]` from the posting's wording against the pay guide below |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median base €31,200 a year, interquartile range €28,400 to €34,100. The guide leaves out commission-only and freelance work, so it is a pattern and not this employer's offer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide |
| Unknowns | Who the employer is, the guaranteed hourly rate, the commission rate, the contract type, and who your manager would be | `[grounded]` posting silent on each |
| Contradictions | The posting names no equipment cost and no cheque. The messages add both, and the "offer" names no pay, hours or contract | `[grounded]` posting against your messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your non-negotiable) | hard_gate | unclear | high | hard_gate | Confidence grades your stated constraint. Fit is `unclear` because "up to €26" and "15–30 a week" set no floor: €26 for 15 hours a week over 52 weeks is €20,280, and €26 for 30 hours is €40,560, so the posting spans your threshold. Commission is unquantified | `[grounded]` posting and your constraint; `[inferred]` arithmetic from the posting's figures | Ask the employer for a guaranteed rate and contracted hours in writing (RR1's route) |
| R2 | Strong attention to detail | must_have | direct | medium | none | You work about 60 Zendesk tickets a day and keep a weekly team tracker. This is your own account, with no artifact to inspect | `[grounded]` your account | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep the team's weekly tracker in Excel. How advanced it is hasn't been stated, so `medium` | `[grounded]` your account | none |
| R4 | Good written English | must_have | direct | medium | none | Written ticket replies daily, and you trained two new starters. Your own account | `[grounded]` your account | none |
| R5 | A quiet place to work | important | unclear | none | discovery | Nothing was said either way. You'd know the answer, so it isn't worth a question | `[grounded]` silence in what you shared | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | "Up to €26 an hour" and 15–30 hours leave the annual figure anywhere from below your floor to above it | Your €30,000 is a hard gate, so a role with no pay floor can't be confirmed against it | Not an experience gap. It is a term of the role | A written offer from a verified employer naming the hourly rate, hours and contract | `[grounded]` posting; `[inferred]` that no floor can be read from it |
| G2 | A quiet place to work (R5, important) | discovery | Nothing stated | Minor, and you'd know | Not applicable | None needed | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | Money is asked of you before any job exists. This request is very likely a scam. Don't pay it. Who sent it, and whether the named employer is involved, is unproven | `[grounded]` the message; `[generic]` that paying up front for work equipment is a known pattern | To the employer, through contact details you find on its own website: "Do you ask new hires to pay for equipment before starting, and did this message come from you?" | confirmed |
| RR2 | Cheque to deposit, balance to forward | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can show as credited and later be returned, which would leave money you sent on as your loss. This request is very likely a scam. Don't deposit the cheque | `[grounded]` the message; `[generic]` that a cheque can be credited and later returned | Same route and question as RR1 | confirmed |
| RR3 | Bank, tax and ID details before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These were asked before any written offer, and the "payroll" reason doesn't hold without one. Sending them could expose you to misuse of your identity and account. This request is very likely a scam | `[grounded]` the message; `[generic]` that such details follow a written offer | Same route as RR1: "Is any step of your hiring asking for these details before a written offer?" | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." Then "you passed the interview and the job is yours" | The interview and the offer both happened in chat only, with no pay, hours or contract in writing. This shows a weakness in the process. It doesn't show who is behind it | `[grounded]` posting and messages | Same route as RR1: "Can I have an interview by call or video, and a written offer?" | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for entities with no footprint, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Pay claim with no floor, against the market band | risk_signal | low | "Earn up to €26 an hour plus commission on every order you process" | "Up to" says nothing about the minimum. At the top rate and 30 hours the claim sits above the guide's salaried band for experienced coordinators, and the posting asks for no experience | `[grounded]` posting; `[generic]` Pennoral 2026 band | What is the guaranteed hourly rate, and what is the commission rate? | unresolved |
| RR7 | HR contact is not on a Velloway-named domain | risk_signal | medium | "email velloway.hr@postmail.example" | Replies from this address may not come from the employer the posting names | `[grounded]` the message | Can you confirm this address belongs to you, through the contacts on your own site? | unresolved |

Hold each of these until you've checked it with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. I couldn't find an employer website to check against, so there's nothing independent to verify with yet, and the sender's identity stays unresolved. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, PPS number or passport photo, no €349, and don't lodge the cheque if it arrives. Don't paste your IBAN into the chat | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Report the posting and the Telegram account to the jobs site you found it on | A report can get the posting removed and protect others | `[generic]` how job sites handle reports | pending your approval |
| A3 | Put your effort into customer-operations, support or order-processing roles that match your Zendesk, Excel and training experience, using your €30,000 floor | The median in role reality is €31,200, so the floor is realistic for salaried posts | `[generic]` Pennoral 2026 guide; `[inferred]` fit from your background | pending your approval |
| A4 | With any employer, ask for pay, hours and contract in writing, expect a call or video interview, and give ID and bank details only in the employer's own portal, after a written offer | A routine and checkable onboarding path | `[generic]` normal hiring practice | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics careers Remote Order Processing Coordinator". Neither returned a result, so the employer is not established and nothing was used. Moved RR5 and role reality's organization row |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland hourly pay", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved market calibration and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save all of this as `tuesday-dossier.md`, whenever you like.

## Upgrade menu

- A link to the live posting on the jobs site, or a link to a Velloway website you find independently → RR5 could resolve either way.
- A written offer from an employer you've verified, naming rate, hours and contract → R1 and RR6 close.
- A deeper research pass on Velloway Logistics (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

1. RR5: Which jobs site was the posting on, and did it link to a company website?
2. Orientation: What roles do you want next? Tell me any location, hours or contract needs beyond the €30,000, and I'll underwrite real openings the same way.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.