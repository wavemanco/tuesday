Search permission was declined, so I worked only from what you pasted. Here's the assessment.

## Decision snapshot

**Worth accepting, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two days a week in the Limerick office), R2 (Salary €38,000–€42,000)
- `must_have`: direct: R3, R5, R6 · unclear: R4 (Irish PAYE, PRSI and USC)
- `important`: direct: R7, R8 · adjacent: R9 (Run monthly payroll for 240 staff) · absent: R10 (Pension changes)
- `preferred`: none in the posting

R9 is a credible bridge with its limit named. R10 is the one real gap, and it is a learnable one.

**Opportunity ledger.** Your question about bank details, PPS number and passport is covered by the first bullet below.

- **Normal request.** Asking for these after you accept a written offer is the standard onboarding step for a payroll role. `[generic]` The employer needs your bank details to pay you and your PPS number to register you with Revenue. It needs ID for its right-to-work check, and bringing the original passport on day one is a common way to complete that.
- **Where the advice you were given applies.** The rule is never to hand these over before an offer, to someone you can't verify, or by email or chat. That doesn't describe your situation. You had two in-person interviews at their office, and the offer is in writing with a salary inside the advertised band. The portal link has not arrived yet, and the check on it is under A1 below.
- **Weaker points.** The offer is thin on terms (RR1). The pension-change duty is new to you (RR2). I couldn't check the employer online (RR3).
- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in the Limerick office) and R2 (Salary €38,000–€42,000). Your own constraints weren't given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. You get the written contract and terms before you resign (RR1).
  2. The portal link comes from the employer's own domain (A1).
  3. A handover plan for pension changes is agreed (RR2, R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, about 240 staff | `[grounded]` JD header |
| Mandate | Monthly payroll, starters, leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` JD |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Working pattern | Hybrid, two days a week in the Limerick office; start date agreed after your notice ends | `[grounded]` JD and offer |
| Scope read | A sole or lead payroll post: it covers the whole cycle, with no mention of a team | `[inferred]` from the JD listing every payroll duty and naming no colleagues |
| Market calibration | Not run, because the sweep wasn't permitted. €40,000 sits mid-band of the posting's own €38–42k | `[grounded]` JD and offer; no `[generic]` band available |
| Unknowns | Payroll software, pension scheme type, contract terms, probation, support during handover | — |
| Contradictions | None between the JD and the offer | `[grounded]` both documents |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | low | none | The term is in the offer. Whether it suits you is a constraint you haven't stated. | `[grounded]` offer; constraint not given | Confirm it works for you |
| R2 | Salary €38,000–€42,000 | hard_gate | unclear | low | none | €40,000 is offered. Your floor wasn't given. | `[grounded]` offer; floor not given | Confirm against your floor |
| R3 | 2+ years running payroll | must_have | direct | medium | none | You stated 3 years of fortnightly payroll for 90 staff. I haven't seen a document. | `[grounded]` your account | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You didn't say the hotel payroll was Irish or that you handled Revenue filings. This is probably true but unstated. | `[grounded]` silence in your account | See G1 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP | `[grounded]` your account | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. I haven't seen the certificate. | `[grounded]` your account | none |
| R7 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | You did exactly this at the hotel group. | `[grounded]` your account | none |
| R8 | Process starters and leavers | important | direct | medium | none | You did both at the hotel group. | `[grounded]` your account | none |
| R9 | Run monthly payroll for 240 staff | important | adjacent | medium | transferability | You ran fortnightly payroll for 90 staff. | `[inferred]` bridge from your account | See G3 |
| R10 | Process pension changes | important | absent | none | capability | You haven't done these yourself; your manager did. | `[grounded]` your account | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory knowledge (R4, must_have) | discovery | Your account doesn't say whether the hotel payroll ran under Irish PAYE, PRSI and USC | A must-have. If it is true, it is probably a one-line confirmation. | Filing payroll returns to Revenue; applying PRSI classes; USC rates; year-end or leaver forms | Your certificate syllabus, or a payslip format with the statutory lines | `[grounded]` silence; `[inferred]` it is likely true given the 2024 certificate |
| G2 | Pension changes (R10, important) | capability | You have not done these. Your manager handled them. | It is a named duty, and you would be the only payroll person. | Having prepared even one enrolment, contribution change or leaver pension notice; watching and supporting your manager | A scheme handbook or a procedure note | `[grounded]` your account; `[generic]` that employers often train on scheme-specific rules |
| G3 | Scale and frequency (R9, important) | transferability | Adjacent evidence: fortnightly payroll for 90 staff, which is a similar cycle at roughly a third of the size. Limit: you haven't run a monthly cycle for 240 staff, and I can't say whether their pay structures are more complex. Strengthener: ask about pay structures and software before you start. | The headcount is nearly three times what you've run. | A larger payroll you supported or covered | A payroll run summary, with identifying details removed | `[inferred]` bridge from your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Offer gives no contract terms | unknown | — | "starting on a date we agree once your notice period ends" | The offer email is a summary, and a full contract follows. It does not mention hours, probation, leave, pension or notice. | `[inferred]` from the email's silence on these | Can you send the written contract and terms (hours, probation, leave, pension, notice) before I give notice? | unresolved |
| RR2 | Pension duty is new to you, and you'd be the only payroll person | risk_signal | low | "process starters, leavers and pension changes" | Pension changes are a learnable task, and employers often provide a handover. Severity is low for that reason. | `[inferred]` from the JD's wording; `[generic]` that employers often provide handover | Who has handled pension changes until now, and what handover or training is planned? | unresolved |
| RR3 | I couldn't check the employer online | unknown | — | "Marrowgate Housing" | Search permission was declined, so the employer was not independently checked. That is a limit of this review. Your two in-person interviews at their office are a check I can't replace. | `[grounded]` search declined | Does the housing body appear on the regulator's public register of approved housing bodies? `[generic]` pointer, not verified by me | unresolved |
| RR4 | In-person interviews and a written offer within the advertised band | positive_signal | — | "two interviews in person at their office" | The hiring process looks ordinary and consistent. | `[grounded]` your account and the offer | Is the first-week induction plan available to share? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | When the portal link arrives, check it points to the employer's own domain, matching `marrowgatehousing.ie`. Don't send documents by email or chat, and ring the office on a number from their own site if unsure. | See RR3 | `[generic]` standard caution, no concern about this employer | pending your approval |
| A2 | Reply within the five working days, asking for the written contract. Accept formally once it matches the offer. | See RR1 | `[grounded]` offer email | pending your approval |
| A3 | Raise pension-change handover and the payroll software at acceptance. Frame your experience as adjacent, never as direct pension-processing experience. | See R10, R9, RR2 | `[grounded]` your account | pending your approval |

All rows are proposals, covering this advice as well as the table. Nothing is final until you approve.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I tried the search "Marrowgate Housing Limerick housing association". It was refused, so I couldn't confirm the employer or the posting. It would have fed RR3. |
| 2. Role-family sweep | unavailable | I tried the search "payroll administrator salary Ireland Limerick 2026". It was refused. It would have given a salary band for the market calibration. |
| 3. Hiring manager's public footprint | unavailable | A name was given (Declan Garvagh), but no search ran, because search permission was declined. It would have informed the scope read. |

## Dossier offer and upgrade menu

I can write all of this into a `tuesday-dossier.md` file if you want to keep it.

- Search permission would let me check the employer, the posting and the salary band, which would close RR3 and the market calibration.
- The written contract would close RR1 and R1–R2 against your terms.
- Your answer to G1 would settle R4 and could lift it to `direct`.
- Your answer to G2 would show whether R10 is `absent` or closer to `adjacent`.
- A deeper research pass (up to 5 more searches and 2 more fetches) is available once search is allowed.

## Questions

- **G1 (R4):** Did your hotel-group payroll run under Irish PAYE, PRSI and USC, and did you submit the returns to Revenue yourself?
- **G2 (R10):** Have you ever prepared a pension enrolment, contribution change or leaver notice, even once, or helped your manager with one?
- **R1/R2:** Do two office days a week in Limerick and €40,000 meet your own limits, or is there a floor or commute limit I should know about?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.