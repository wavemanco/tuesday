I'll read the skill's reference files before building the assessment.
## Decision snapshot

**Yes, worth taking the call, with conditions. I can't establish Fernquay from here, because my searches were declined (see Evidence status). Status: `conditional_go`.** Ronan's message says you have already applied, so I've assumed you are at the interview-scheduling stage. Scheduling a video call by WhatsApp, with the invite emailed, is a routine step. Neither the posting nor the message asks you for money, ID or bank details.

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R9 (Research calls with school owners) · absent: R8 (First designer on the team)

R7 (`medium`) — checkout is one stage of a booking flow, ownership of the whole flow unconfirmed; R9 (`medium`) — usability sessions with customers, school owners a different audience; R8 — never the only designer, by your own account; R2 — a gate waiting on your pay floor.

**Opportunity ledger.** Pay, equity range, working pattern and scope are stated up front (RR6). Open questions remain on equity terms (RR2), funding (RR3), design support (RR4) and success measures (RR5). The employer itself is unverified from here (RR1).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay and this role are confirmed on the company's own site (RR1); (2) the pay band clears your floor (R2); (3) equity terms and funding get straight answers before you commit (RR2, RR3); (4) the checkout work is described as the checkout redesign it was, not as ownership of a whole booking flow (R7).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. Not independently established (RR1) | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Who you'd work with | Co-founder Ronan Kehoe most closely; the call is with Ronan and Saoirse, the CTO | `[grounded]` posting and WhatsApp message |
| Compensation | €52,000–€60,000 plus 0.5–1% equity. Instrument, vesting and share base unstated (RR2) | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office, the rest flexible | `[grounded]` posting |
| Contact channel | WhatsApp message to schedule a 45-minute video call, with the calendar invite and video link sent by email. Routine scheduling for an interview held elsewhere; it asks nothing of you beyond the call | `[grounded]` your message text |
| First-90-days and first-year outcomes | Not stated. The nearest signal is "own the booking flow end to end", so early work plausibly centres on that flow | `[inferred]` from the posting's responsibility wording |
| Scope read | Design, research and flow ownership sit with one hire and no design peer or lead is named | `[inferred]` from "first designer" against the scope list |
| Market calibration | Not run. The role-family sweep returned nothing, so the posted band is not set against a market band here | `[grounded]` Evidence status, target 2 |
| Unknowns | Equity terms, funding and runway, success measures, what design support exists | `[grounded]` posting silence |
| Contradictions | None between the posting and the message (Galway, Ronan, the CTO). The company's own site could not be compared | `[grounded]` the two documents you supplied |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days fit where you live. You haven't stated this as a constraint, so confidence rests on your plain statement of where you live | `[grounded]` posting and your message | none |
| R2 | Salary €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The pay is stated, but you haven't given a floor, so whether it clears your minimum is not settled. Equity terms are open (RR2) | `[grounded]` posting; your floor not given | G3 |
| R3 | 3+ years of product design | must_have | direct | medium | none | You state 4 years as a product designer at a Dublin travel-booking company. This is self-report; no CV or portfolio has been inspected | `[grounded]` your message | none |
| R4 | Strong Figma | must_have | direct | medium | none | You state daily Figma use. "Strong" is the posting's word, and nothing inspected shows depth | `[grounded]` your message | Offer: a Figma file or the case study page would raise this to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. That is research you ran. Its limit: usability sessions are not necessarily interviews about needs (see R9) | `[grounded]` your message | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your message | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | discovery | You redesigned your company's checkout flow, which is one stage of a booking flow. Whether you owned the design decisions, and whether your remit reached search, selection or confirmation, isn't stated. Ronan says he liked the checkout case study | `[grounded]` your message and Ronan's; `[inferred]` that checkout is one stage, derived from how booking flows run from selection to payment | G1 |
| R8 | First designer: no design peer or lead named | important | absent | low | transferability | You say you've never been the only designer. The adjacent evidence is self-directed work (a flow redesign, a monthly research habit), but who set direction in those isn't known. Limit: setting process, standards and priorities alone is not evidenced | `[grounded]` your statement; `[generic]` that first-designer posts usually fall to one person to set process | G4 |
| R9 | Run research calls with school owners | important | adjacent | medium | discovery | Your sessions were with customers of a travel-booking company. Whether they were consumers or businesses, and whether any were interviews rather than task tests, isn't stated | `[grounded]` your message and posting | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ownership of the whole flow (R7, must_have) | discovery | A checkout redesign and a case study Ronan liked, but not who made the final design decisions or how far the remit extended | The posting's lead responsibility is the whole flow, so this is the likeliest probe on the call | Deciding the structure of a flow, not only its screens; owning edge cases and error states; making trade-offs with engineers; owning a result you tracked | The checkout case study, before/after flow diagrams, a summary of usability findings | `[grounded]` your message; `[generic]` that a lead responsibility draws the first probe |
| G2 | Research with business owners (R9, important) | discovery | Monthly usability sessions with customers; audience and format unconfirmed | Research calls with school owners are a named duty | Interviewing customers about how they work, not testing screens; research with small-business operators or partners; recruiting the participants yourself | A discussion guide or a research synthesis, anonymized | `[grounded]` your message; `[inferred]` that interview-style research matters here, from the posting's "research calls" |
| G3 | Pay floor (R2, hard_gate) | hard_gate | The band and equity range are stated; your minimum is not | A gate. It decides whether the call is worth your time | A term, not experience: your minimum, and how much weight you give equity | None | `[grounded]` posting; your floor not given |
| G4 | Sole-designer scope (R8, important) | transferability | Adjacent: a redesign and a research cadence. Limit: no evidence of setting direction with no design peer. Strengthener: the posting prefers "one messy real project" to a polished deck, so a small real piece of work could help | The role has no design peer to lean on | Times you made a design call without a lead; starting a practice yourself; setting conventions for handoff | A small real project, named as yours and as unfinished if it is | `[grounded]` posting wording and your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. You report finding little online; my own searches returned nothing | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The percentage may be options, subject to vesting and dilution, with no share base given, so its value can't be judged | `[inferred]` from the range against the posting's silence on instrument, vesting and share count | Is the equity options or shares, what is the vesting schedule, and what share count does the percentage refer to? | unresolved |
| RR3 | Funding and runway unstated | unknown | — | "We are six people in Galway" | The posting says nothing on how the company is funded or how long its cash lasts, which matters for a salaried first hire | `[inferred]` from the posting's silence | How is Fernquay funded today, and how many months of runway does the current plan assume? | unresolved |
| RR4 | First designer with no named design support | risk_signal | low | "You would be our first designer: own the booking flow end to end, run research calls with school owners, and ship alongside our two engineers" | Design, research and flow ownership in one hire, with no design lead named, may mean setting process alone | `[inferred]` from the scope list against the absence of a design lead | Who has made design decisions until now, and what support does your first designer get in the first three months? | unresolved |
| RR5 | Success measures unstated | unknown | — | "own the booking flow end to end" | No definition of a good first six months, so accountability has no yardstick | `[inferred]` from the posting's silence on outcomes | What would a good first six months look like for this role, and how would you measure it? | unresolved |
| RR6 | Terms stated up front | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week at our Galway office" | Pay, equity range, working pattern, scope and a named manager are in the posting itself | `[grounded]` posting | Which two days are the office days, and is that flexible? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's own website yourself, not through a link in the messages. See whether the role, Ronan and Saoirse are listed, and whether the calendar invite came from an address on that site's domain | See RR1. This is the check that can clear it | `[generic]` routine pre-interview check; `[grounded]` RR1 | pending your approval |
| A2 | Ask the verification questions of RR1, RR2, RR3, RR4 and RR5 verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Describe your work in your own terms: you redesigned your company's checkout flow, ran monthly usability sessions with customers, and worked in a squad with four engineers. Say plainly you haven't been the only designer. Don't describe the checkout work as owning a whole booking flow until G1 is answered | See R7, R8, R9. Each clause traces to a sentence you wrote | `[grounded]` your message | pending your approval |
| A4 | If it helps, offer to bring one small real piece of work rather than a polished deck | The posting asks for exactly that; see G4 | `[grounded]` posting | pending your approval |

Every row above is proposed, the advice and the call framing in A3 included. Nothing is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused: "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer Galway careers". They would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | One search was refused: "first product designer startup Ireland salary equity 2026 Galway". It would have moved the market calibration row and the pay check on R2 |
| 3. Hiring manager's public footprint | unavailable | One search was refused: "Ronan Kehoe Fernquay co-founder". It would have moved the scope read and which story the plan leads with |

I'll offer the dossier whenever you want it: say the word and I'll write `tuesday-dossier.md`.

## Upgrade menu

- Permission to run web search → targets 1–3 run: whether Fernquay exists as described and the role is live (RR1), a pay band for this role (R2), and Ronan's public professional footprint (scope read, which story to lead with).
- A deeper pass on Fernquay (funding, hiring patterns, recent news; up to 5 more searches and 2 more fetches) → feeds RR3 and RR1. It runs only once the first tier can.
- Your pay floor → R2 closes and the hard-gates line resolves.
- The checkout case study link, or a Figma file → R4 and R7 can reach `high`.
- An anonymized discussion guide or research synthesis → R5 and R9 can reach `high`.
- Fernquay's own careers-page address → RR1 can move to `reduced`.

## Questions

**G3** — What is the lowest salary you would accept, and does equity count for anything in that figure?

**G1** — In the checkout redesign, which decisions were yours, and did your remit reach beyond checkout to other stages of the booking flow?

**G2** — Were the customers in your usability sessions consumers booking trips or business customers, and did any sessions work as interviews about their needs rather than task tests?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.