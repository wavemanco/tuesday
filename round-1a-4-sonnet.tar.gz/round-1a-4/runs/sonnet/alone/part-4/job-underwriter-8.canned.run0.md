Reading the skill's output rules before I write the assessment. Next I'll read the remaining reference files.
# Job Underwriting Assessment: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No, don't go ahead with what these messages ask: RR1, RR2, RR3 and RR4 are confirmed severe red flags. Status: `no_go`.** This job is very likely a scam. Don't deposit the cheque. I can't establish the firm from here (RR6), so I'm judging the requests, not the firm.

**Fit ledger.**

- `hard_gate`: unclear: R5 (Pay of at least €30,000 a year)
- `must_have`: direct: R1, R2 · unclear: R3 (Good written English)
- `important`: unclear: R4 (A quiet place to work)

R1 (`medium`): your ticket volume is your own account, with nothing inspectable yet; R5: the posting gives only a ceiling against your floor.

**Opportunity ledger.** The requests for equipment money (RR1), a cheque deposit (RR2), bank, tax and ID details before any offer (RR3) and a process run wholly on Telegram (RR4) are what drive the decision. A contact address that may not be the employer's own (RR5), an employer I couldn't find (RR6) and pay stated only as a ceiling (RR7) add to it.

- **Hard gates:** none failed; unconfirmed: R5 (Pay of at least €30,000 a year)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would change this:** the status moves only if these facts were different: no payment asked of you, no cheque to lodge, no bank, PPS or passport details requested before a written offer, interviews held live, and the employer confirmed independently on its own website.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics, described as hiring remote order processors. A search for its careers page returned nothing, so I can't attribute it to a real employer | `[grounded]` search "Velloway Logistics careers", no results |
| Mandate | Process orders from home; 15–30 hours a week, your own hours | `[grounded]` posting |
| Pay as stated | "Up to €26 an hour plus commission on every order you process"; no base rate and no commission terms | `[grounded]` posting |
| Hiring process | Telegram only: "no calls or video interviews" | `[grounded]` posting |
| Contradictions | The posting says "No experience needed, full training provided" and mentions no costs. The messages then ask you to buy a "work kit, a laptop and headset" for €349 and to deposit a cheque | `[grounded]` posting against your pasted messages |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland have a median base of €31,200, with a middle range of €28,400 to €34,100. That guide excludes commission-only and freelance work, so it is a band for salaried roles and not this employer's offer | `[generic]` role-family search; page: "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide), snippet read only |
| Unknowns | Who the employer is, whether this is employment or contracting, the base pay, the commission terms | `[inferred]` from what the posting leaves out |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day for 3 years, as you describe it. Confirmed by you, nothing inspectable yet | `[grounded]` your background message | none |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Your own account only | `[grounded]` your background message | none |
| R3 | Good written English | must_have | unclear | low | discovery | Ticket work suggests written communication, but you haven't described written output, and nothing was shown | `[inferred]` from your ticket work | none; low stakes while the role fails on its terms |
| R4 | A quiet place to work | important | unclear | low | discovery | You haven't said | `[grounded]` your message is silent | none |
| R5 | Pay: at least €30,000 a year (your stated floor) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because the posting gives only "up to €26" and 15–30 hours. At €26 an hour, €30,000 needs about 22 hours a week all year, and the actual rate and weeks are unknown | `[grounded]` your floor and the posting's terms; `[inferred]` the hours arithmetic | Ask the employer for base pay, once verified |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your €30,000 floor (R5, hard_gate) | hard_gate | Only a ceiling hourly rate, a variable commission and 15–30 hours | It decides whether the role could meet your floor even if everything else checked out | n/a for a gate | A written offer from a verified employer stating base pay and hours | `[grounded]` posting terms |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | The request takes your money before any pay reaches you | `[generic]` pattern of requests like this, not a claim about any named party | Does your company ask new starters to pay for equipment, and who is the equipment partner? | confirmed |
| RR2 | Asked to deposit a cheque and pass money on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque you lodge can later be returned unpaid, while the transfer you sent is gone. This request is very likely a scam. Don't deposit the cheque | `[generic]` pattern of requests like this | See RR1; ask the employer whether it sends cheques to new starters | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | These details were asked for before a written offer naming the role and pay, so they can't be treated as routine onboarding | `[generic]` pattern of requests like this | See RR1; ask the employer which portal onboarding happens in | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | Interview and offer both happened in chat, which leaves no one you can place at a company | `[grounded]` the posting and your messages | See RR1; ask for a live interview with a named person | confirmed |
| RR5 | Contact address may not be the employer's own | risk_signal | medium | "Any problems, email velloway.hr@postmail.example." | The address is at a general mail domain, and I can't tell which domain the employer uses. The messages may not come from who they name | `[inferred]` from the address against the absence of an employer site | Which email domain do your recruiters write from? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Pay stated only as a ceiling | unknown | — | "Earn up to €26 an hour plus commission on every order you process." | The base rate and commission terms are unstated, so the floor in R5 can't be checked | `[grounded]` posting wording | What is the base hourly rate, and how is commission calculated? | unresolved |

Hold each of these until you have checked it with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN (I haven't repeated yours anywhere), no PPS number, no passport photo | See RR3 | `[grounded]` RR3 | pending your approval |
| A2 | Don't pay the €349 | See RR1 | `[grounded]` RR1 | pending your approval |
| A3 | If a cheque arrives, don't lodge it, and tell your bank | See RR2 | `[grounded]` RR2 | pending your approval |
| A4 | Look for Velloway Logistics on your own, find contact details on a website you reach yourself, and send them the RR1–RR4 questions | The register doubles as your questions for the employer | `[grounded]` register | pending your approval |
| A5 | Put your effort into other openings. Your ticket volume, trainer role and Excel tracker are what customer-operations postings ask for | See R1 and R2 | `[grounded]` your background; `[generic]` role family | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers"; no result, so the employer is not established. It produced RR6 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland salary hourly"; the result was "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It moved the market calibration and the R5 reading |
| 3. Hiring manager's public footprint | n/a | No name was given, only a chat handle, so there was no query to form |

## Upgrade menu

- A link to the live posting, or the jobs site's name → RR6 and RR4 can be rechecked against the original listing.
- The employer's own careers page or a named interviewer → RR5 and RR6 close.
- A written offer stating base pay and hours → R5 and RR7 close.
- A deeper research pass on the company name (up to 5 more searches and 2 more fetches) → say the word and it runs.

I can save this as `tuesday-dossier.md` if you want a copy to keep.

**Question** (one, to firm up RR6; answer in text, paste a voice transcript, attach a document, drop a link, or say skip):

RR6 — Do you have a link to the original posting on the jobs site, or the site's name? That would let me check whether the listing is still live and whether it names a company website.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.