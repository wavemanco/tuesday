I'll read the reference files the skill points to before building the assessment.
I've run three searches (the employer, the pay band and the team lead). Next I'm fetching Calderbrook's careers page to check that the posting is live and matches what you pasted.
# Job Underwriting Assessment: Community Staff Nurse, Band 5 at Calderbrook Community Health CIC

## Decision snapshot

**Yes, worth applying for, provided the posting checks out and the working pattern suits you. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (Clear, timely written records)
- `important` — direct: R5a, R7a · adjacent: R6 (Catheter and continence care), R9 (Own small caseload), R10 (Care in patients' own homes) · unclear: R5b (Leg-ulcer care), R7b (Care planning), R8 (End-of-life visits)
- `preferred` — absent: R11 (Doppler assessment)

R9 and R10 are credible bridges, each with its limit named; R5b, R7b and R8 are rows where your CV is silent and a recall prompt may recover evidence; R11 is a confirmed gap with a closure route.

**Opportunity ledger.** The posting is sound on its own terms. It names senior support for the caseload (RR2) and states pay (RR4). Four things are open: whether the posting is live (RR1), what induction there is (RR3), and the working pattern and contract basis (RR5). It makes no request for money, deposits or ID details.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown. R1 and R2 rest on your own statement and have not been checked.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role appears on Calderbrook's own careers page (RR1); (2) the shift pattern and contract basis suit you (RR5); (3) the informal chat confirms induction for leg-ulcer care and Doppler and support for a first caseload (RR3, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | A community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` "About Calderbrook Community Health" page fetched |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, on an electronic patient record | `[grounded]` JD |
| Authority and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` JD |
| First-90-days and first-year outcomes | Not stated | `[grounded]` JD silent |
| Pay | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` JD |
| Market calibration | A survey of Band 5 community staff nurses in England gives a median of £34,300 and an interquartile range of £32,400–£36,600. The posted range spans that interquartile range. The survey also reports mileage paid to 61% of respondents and a pool or lease car for 24%. This is a pattern, not this employer's offer | `[generic]` search "Band 5 community staff nurse district nursing salary Agenda for Change pay scale", page "Wardround 2026 UK Community Nursing Pay Guide"; `[grounded]` JD for the posted range |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. In 2025 she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` community nursing forum speaker page, found by search |
| Scope read | An ordinary entry-level community post: Band 5, a small supported caseload, and a standard district-nursing task list | `[inferred]` from the JD's duties, support wording and Band 5 against the survey's role title |
| Working pattern | Hours, rota, weekend or on-call cover and contract basis are not stated | `[grounded]` JD silent |
| Unknowns | Whether the posting is live; induction and Doppler training; working pattern; mileage rate; where in the range you would start | — |
| Contradictions | None found, but the posting could not be checked against a careers page (RR1) | `[grounded]` careers URL tried returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states Registered Nurse (Adult), registration active, revalidation due March 2028. The statement is specific but I have not seen the register entry, so it is stated, not checked | `[grounded]` CV | You check your own NMC register entry before applying |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | CV states a full UK licence, category B. Stated, not checked | `[grounded]` CV | You check your driving record before applying |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | CV states five years as a staff nurse on an acute medical ward. Specific, but CV-only | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | The CV is silent on documentation and on any electronic record system, so there is nothing to grade either way | `[grounded]` CV silence | G3 |
| R5a | Wound care (other than leg ulcers) | important | direct | medium | none | CV states wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R5b | Leg-ulcer care | important | unclear | low | discovery | The CV does not mention leg ulcers. Work on a medical ward or in the discharge team may have touched them, but nothing says so | `[grounded]` CV silence | G1 |
| R6 | Catheter and continence care | important | adjacent | medium | discovery | CV states catheter care. Continence care is not mentioned, so only part of the requirement is evidenced. I took the lower fit | `[grounded]` CV | G4 |
| R7a | Insulin administration | important | direct | medium | none | CV states insulin administration | `[grounded]` CV | none |
| R7b | Care planning | important | unclear | low | discovery | The CV does not mention care planning | `[grounded]` CV silence | G2 |
| R8 | End-of-life visits | important | unclear | low | discovery | The CV is silent on end-of-life care; the posting makes it a core duty | `[grounded]` CV silence; JD duty | G2 |
| R9 | Hold a small caseload of your own, supported by a senior community nurse | important | adjacent | medium | transferability | You say you have never held your own caseload. The discharge-to-assess secondment is the nearest evidence. The limit is that you have not owned a caseload. The JD's support wording makes this a trainable step | `[grounded]` CV and your statement; `[inferred]` that the support wording makes it trainable | G5 |
| R10 | Care for housebound adults in their own homes | important | adjacent | medium | transferability | 18 months on a discharge-to-assess team visiting patients at home in their first week after discharge. Short-term visits after discharge are not the same as ongoing care for housebound adults, so I took the lower fit | `[grounded]` CV | Lead with it in the CV edit (E1) |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have confirmed you have never done one. It is desirable, not essential. The team lead has spoken publicly about Doppler training for staff new to community work | `[grounded]` your statement; `[inferred]` closure route from the speaker page | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5b, important) | discovery | A wound-care claim that names pressure ulcers and surgical wounds, with no leg ulcers | Leg-ulcer care sits in the posting's duty list beside the Doppler wish, so any experience would narrow the R11 gap | Dressing or compression for leg ulcers on the ward; discharge visits to patients with leg wounds; a tissue-viability or wound-clinic referral you made | A wound-care competency record or a training certificate | `[grounded]` CV silence; `[inferred]` that this ties to R11 from the JD's pairing |
| G2 | End-of-life visits and care planning (R8, R7b, both important) | discovery | The CV is silent on both | End-of-life visits are a named duty. Evidence would show you can do this part of the job, and the CV currently shows none | Nursing dying patients on the ward; end-of-life or rapid-discharge arrangements in discharge-to-assess; writing or updating care plans | A training record or a sanitised care-plan example | `[grounded]` CV silence and JD duty |
| G3 | Written records (R4, must_have) | discovery | The CV says nothing on documentation or which record systems you have used | A `must_have` row at `unclear` | Using an electronic patient record on the ward or in the discharge team; documentation audits; a record-keeping sign-off | A record-keeping audit result or an EPR training record | `[grounded]` CV silence |
| G4 | Continence care (R6, important) | discovery | Catheter care is stated; continence care is not | The posting names both | Continence assessments, bladder and bowel care, continence products | A competency record | `[grounded]` CV |
| G5 | Caseload ownership (R9, important) | transferability | The nearest evidence is home visiting after discharge, not an owned caseload | The posting asks for a small caseload from the start, with senior support | Following up the same patients across several visits; deciding visit frequency or escalating a deterioration on discharge-to-assess | A discharge-to-assess service description or visit log, anonymised | `[grounded]` CV and your statement |
| G6 | Doppler assessment (R11, preferred) | capability | None. You have confirmed you have not done it | It is desirable only. Frame it as a stated gap, not something to hide | None. This is a training need, not a recall gap | Not applicable. A course or in-post training would close it | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not yet seen on the employer's own careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The employer matches its About page. Whether the posting is live and current is unconfirmed because the careers address I tried returned no page; it may sit at another address | `[grounded]` About page fetched; careers URL tried returned no page | Can you point me to this role on your careers page and tell me its closing date? | unresolved |
| RR2 | Senior support named for the caseload | positive_signal | — | "supported by a senior community nurse" | Support exists in some form; its extent is unspecified | `[grounded]` JD | How much time does the senior community nurse set aside for new caseload holders, and for how long? | noted |
| RR3 | Induction and training for community skills unstated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | Training may be offered on joining. The team lead has spoken publicly on Doppler training for staff new to community work; that is her topic, not an employer commitment | `[inferred]` from the speaker page and the JD's "desirable" | What induction and Doppler training do nurses joining from acute wards get, and over what period? | unresolved |
| RR4 | Pay stated, within the survey range; mileage rate and start point unstated | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Stated pay is a sign of transparency; the posted range spans the survey's interquartile range | `[grounded]` JD; `[generic]` survey band | Where in the range would I start, and what is the mileage rate? | noted |
| RR5 | Working pattern, hours and contract basis not stated | unknown | — | "£31,050–£37,800 a year plus mileage" (the only terms given) | Community nursing posts may involve rotas that include weekends. The advert is silent, so nothing is known about this one | `[generic]` role-family pattern; `[grounded]` JD silent | What is the shift pattern including weekends and any on-call, and is the post permanent and full-time? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV summary edit, shown below | see R10, R9 | `[grounded]` CV | `resume_edits_pending_approval` |
| A1 | Take up the informal chat with Rhiannon Mabbott before applying, and ask the register questions RR1, RR3, RR5 and RR2 | The JD offers the chat; the register doubles as interview preparation | `[grounded]` JD and register | pending your approval |
| A2 | Check your own NMC register entry and driving record before applying | R1 and R2 are met on your statement only | `[grounded]` R1, R2 rows | pending your approval |
| A3 | Lead with the discharge-to-assess secondment and state R9 and R11 as gaps | Adjacent evidence reads weaker but holds up better when probed | `[inferred]` from the map | pending your approval |

**Proposed CV summary line (`resume_edits_pending_approval`):**

| Current | Proposed | Source |
|---|---|---|
| Wound care, catheter care and insulin listed in a skills list; the secondment stated lower down | "Registered Nurse (Adult) with five years' acute medical ward experience, the last 18 months seconded to a discharge-to-assess team visiting patients at home in their first week after discharge. Wound care including pressure ulcers and surgical wounds; catheter care; insulin administration." | Your CV sentences, reordered, with no new claim |

**Proposed words for the informal chat (pending your approval):** "I've five years on an acute medical ward, and I spent 18 months seconded to discharge-to-assess, visiting patients at home in their first week after discharge. I haven't held my own caseload or done Doppler assessment, and I'd like to understand what induction and support there is." Each clause traces to your own sentences.

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this, and I haven't used or repeated it. Leave it off applications and give it only through the employer's own portal after a written offer.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched the careers address (calderbrookhealth.example/careers), which returned no page, and the About page, which repeated the search result and added nothing new. Moved role reality's organization row, and the posting-live check is carried as RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing salary Agenda for Change pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved role reality's hiring-contact and scope rows, RR3, and the plan's positioning |

## Upgrade menu

I can emit this assessment as `tuesday-dossier.md` for later use, if you'd like it.

- A link to the live posting on Calderbrook's careers page, or its closing date → RR1 closes.
- An answer on leg-ulcer work (G1) → R5b and the R11 gap narrow.
- An answer on end-of-life and care planning (G2) → R8 and R7b may move to `direct`.
- A record-keeping or EPR training record, or an anonymised example → R4 moves toward `high`.
- Your pay floor, hours and any shift limits → the hard-gate line can check them against RR4 and RR5.
- The chat with Rhiannon Mabbott → RR2, RR3 and RR5 resolve.
- A deeper research pass on Calderbrook (leadership changes, contract history, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

1. G1 — Have you dressed or bandaged leg ulcers, on the ward or on discharge visits, and what did you do yourself? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. G2 — Have you nursed dying patients or arranged end-of-life care, and have you written or updated care plans? What was your part? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. Do you have a pay floor, hours, or shift limits (weekends, nights, part-time) that a role must meet? Answer in text or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.