Reading the skill's reference files is done. I'm loading the web search tools now to check whether Fernquay exists as described.
# Job Underwriting Assessment: Product Designer at Fernquay

## Decision snapshot

**Yes, it's worth pursuing, and on what I could check Fernquay is a real, live employer (RR1). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary meets your pay floor)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R6 (Own booking flow end to end)
- `important`: adjacent: R8 (Research calls with school owners), R9 (First and only designer)

R6: a credible bridge from your checkout redesign, its limit named; R9: you haven't been the only designer before; R8: a different audience from customer usability sessions.

**Opportunity ledger.** The employer matches its own site (RR1) and the pay band sits inside the surveyed range (RR2). Two things are open: what the equity is worth (RR3) and how design decisions are shared with the co-founder (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary meets your pay floor); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. R2: the €52,000–€60,000 range meets your floor.
  2. RR3 and RR4 get concrete answers on the call.
  3. R6 and R9 are framed honestly as adjacent: checkout rather than the whole flow, and a squad rather than solo.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by customers | `[grounded]` About page, fernquay.example/about |
| Mandate | First design hire. Own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in Galway | `[grounded]` posting and careers page agree |
| Pay | €52,000–€60,000 plus 0.5–1% equity. The careers page says "plus equity" without a percentage | `[grounded]` posting and careers page |
| Hiring manager | Ronan Kehoe is co-founder and CEO, and was previously a product lead at a Galway travel-software company for five years | `[grounded]` public profile snippet |
| Scope read | A broad single-designer remit. The person you'd work with most has product experience in your own domain (travel booking), so design decisions may be easier to discuss with him | `[inferred]` from the mandate and his stated background |
| Market calibration | For product designers with 3 to 5 years in Ireland, the median base is €57,000 and the middle range is €51,500–€62,000. The posted band sits inside it. This is a national survey, not a startup-specific one, so it is no claim about this employer's offer | `[generic]` Tillerby 2026 Ireland Design Salary Report (n=520); `[grounded]` posting for the band |
| Unknowns | Success measures for year one, design decision rights, equity terms, runway, who the engineers report to | none |
| Contradictions | None between the posting and the careers page on title, location, hybrid pattern or pay | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | high | none | You moved back to Galway last year, and the posting asks for two office days there | `[grounded]` your message, posting | none |
| R2 | Pay of €52,000–€60,000 plus 0.5–1% equity meets your floor | hard_gate | unclear | none | hard_gate | You haven't stated a floor, so there is nothing to compare the posted band against | `[grounded]` posting; floor not given | Ask for your non-negotiables (closing question) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company, stated by you and not yet inspected. A years requirement is not a gate | `[grounded]` your message | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use is stated. "Strong" shows in an inspectable file or case study | `[grounded]` your message | Share the checkout case study or a Figma file to reach `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Be ready to say which parts you personally ran | `[grounded]` your message | none |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a travel-booking checkout flow. Limit: checkout is one stage of a booking journey, and ownership was shared in a squad | `[grounded]` your message; `[inferred]` that the whole flow is wider than checkout | See G1 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers; here it is two | `[grounded]` your message | none |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with customers who use a product. Calls with small-business owners about how they run their schools are a different conversation | `[inferred]` from the two audiences | See G2 |
| R9 | Be the first designer, with no design peers | important | adjacent | low | transferability | You have never been the only designer, so there is no direct evidence. Squad work with engineers is the nearest thing | `[grounded]` your message | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-to-end booking flow (R6, must_have) | transferability | A checkout redesign, but nothing yet on the stages around it | It is the core of the role, and the call will probe where your ownership stopped | Search and availability, choosing a session, cancellation or rebooking, confirmation emails, mobile, payment edge cases | The checkout case study, a before-and-after of the flow | `[grounded]` your message; `[inferred]` that the call will probe it |
| G2 | Owner-facing research (R8, important) | transferability | Customer usability sessions, no owner or business-side discovery | The posting makes school-owner calls part of the job | Calls with business clients, account managers or internal stakeholders you interviewed | A research plan, a call guide or a synthesis you wrote | `[grounded]` your message; `[inferred]` that the audiences differ |
| G3 | Working as the only designer (R9, important) | transferability | No direct evidence | You'd have no design peers to review your work | Setting up a component library, making design decisions without a design lead, freelance or side projects | A file structure, a library, a side project | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting | positive_signal | — | "Six people, based in Galway ... funded by its customers" | The company exists as described and the posting is live on its own careers page | `[grounded]` About page and careers page | How many schools pay for Kelproster today, and how many months of runway do you have? | noted |
| RR2 | Pay sits inside the surveyed range | positive_signal | — | "€52,000–€60,000 plus 0.5–1% equity" | The band is in line with the survey's middle range for 3 to 5 years, with equity on top | `[grounded]` posting; `[generic]` survey | Where in the range would this role land for my experience? | noted |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | What the equity is worth depends on vesting, options versus shares, and dilution, none of which the posting states | `[inferred]` from the posting's silence | Is the equity options or shares, what is the vesting schedule, and what share count is the percentage based on? | unresolved |
| RR4 | Decision rights beside the co-founder | unknown | — | "You will work most closely with our co-founder, Ronan Kehoe" | Product direction may sit with him, leaving it unclear which design calls you make alone | `[inferred]` from the posting's silence on decision rights | Which product and design decisions would I make alone, and which would go through you? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take the call. Before you click the video link, check that the calendar invite email arrived and that its sender address is on the same domain as the careers page. Scheduling a video call by WhatsApp is a routine step, and nothing in the message asks for money, documents or personal details | The careers page lists jobs@fernquay.example, so that domain is the one to expect | `[grounded]` careers page; `[generic]` that chat scheduling is routine | pending your approval |
| W1 | Prepare your checkout story as one real project, covering what you personally owned versus the squad, what the research showed, and what shipped. The posting says "we would rather see one messy real project than a polished deck" | See R6, R5, R9 | `[grounded]` posting, your message | pending your approval |
| Q1 | Ask RR1, RR2, RR3 and RR4 verbatim on the call. Ask Saoirse how design work reaches the engineers today | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. The claims in R3 to R9 come from your message and are leads, not proof.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about). Searched "Fernquay careers product designer" and fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved the organization and contradictions rows and RR1. The employer is established, so no failed-attribution entry |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup Galway first designer", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Only the public role history was used. Moved the hiring-manager row and the scope read |

If you'd like, I can save all of this as `tuesday-dossier.md` to carry into later sessions.

## Upgrade menu

- Your non-negotiables (pay floor, days, anything else) → R2 closes and the hard-gates line becomes a real check.
- The checkout case study or a Figma file → R4 and R5 to `high`, and G1 can be answered from the file itself.
- Ronan's answers on equity terms and decision rights → RR3 and RR4 close.
- A deeper research pass on Fernquay (funding and runway signals, customer and employee reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. R2: What are your non-negotiables for this role (pay floor, office days, anything else), so I can check them against the posting?
2. G1: In the checkout redesign, which stages around it (search, selecting a session, cancellation or rebooking, confirmation emails, mobile) did you personally design, and where did your work stop?
3. G3: Have you ever made design decisions with no other designer to review them, for example setting up a component library or on a freelance or side project? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.