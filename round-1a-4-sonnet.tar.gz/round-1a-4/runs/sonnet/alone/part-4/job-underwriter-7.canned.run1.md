Status: I've read the underwriting method's reference files. Next I'm loading the web tools to check the employer and the role.
**Yes, this is worth applying for. R1 and R2, the two hard gates, are met as you've stated them. Status: `go`.**

I'm assuming you're still evaluating. I haven't used your National Insurance number, and an application doesn't need it.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R6, R7, R8 · adjacent: R5 (Wound and leg-ulcer care) · unclear: R4 (Clear, timely written records)
- `important` — adjacent: R9 (Own small caseload) · unclear: R10 (End-of-life visits), R11 (Continence and care planning)
- `preferred` — absent: R12 (Doppler assessment)

R5 — leg ulcers are not on your CV; R9 (`medium`) — the discharge-to-assess home visits are the bridge, with caseload ownership untested; R4 — waiting on which record system you used.

**Opportunity ledger.** The role looks sound on what the posting and its public footprint show. Support is built in (RR1) and pay and mileage are disclosed (RR3). The team lead has published on the exact gaps you have (RR5). Caseload size and hours are unstated (RR2), and I could not confirm the posting is live (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a failed check of your own NMC register entry (R1) or driving record (R2) would make it `no_go`. RR4 coming back as not open would end it too.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` its About page, fetched |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning; records on an electronic patient record | `[grounded]` JD |
| Structure | A small caseload of your own, supported by a senior community nurse; pool cars provided | `[grounded]` JD |
| Pay | £31,050–£37,800 plus mileage, disclosed in the posting | `[grounded]` JD |
| Market calibration | A 2026 survey of Band 5 community staff nurses in England gives median £34,300 and interquartile range £32,400–£36,600. The posted range brackets that range, so where you would start depends on how your experience is placed. This is a survey figure, not this employer's offer | `[generic]` Wardround survey (n=1,240); `[grounded]` JD for the posted range |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Scope read | The advert lists Doppler as desirable, and the contact has spoken on training staff new to community work. Together these suggest Doppler is learnable on the job, though the advert does not say so | `[inferred]` from the JD's "desirable" tier and the speaker page |
| Unknowns | Caseload size; hours, weekend and on-call pattern; whether the posting is currently open; Doppler training provision | `[grounded]` JD silent |
| Contradictions | None found between the JD and the About page. The careers page did not open, so the posting itself is unchecked | `[grounded]` About page; careers page not found |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active Adult registration with revalidation due March 2028. That is stated, not checked: nothing here lets me inspect the register | `[grounded]` CV | You check your own NMC register entry before applying |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | You state a full category B licence. Stated, not checked | `[grounded]` CV | You check your own DVLA driving record before applying |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward is specific and confirmed, with no inspectable artifact yet. Expect a probe on it | `[grounded]` CV | none |
| R4 | Clear, timely written records, on an electronic patient record | must_have | unclear | low | discovery | Your CV is silent on records and on which record system you used. Nothing is contradicted | `[grounded]` CV silence | See G2 |
| R5 | Wound and leg-ulcer care | must_have | adjacent | medium | discovery | Pressure ulcers and surgical wounds are stated. Leg ulcers and compression are not mentioned, so wound care carries over but this wound type is untested | `[grounded]` CV | See G1 |
| R6 | Catheter care | must_have | direct | medium | none | Catheter care is stated plainly in your CV | `[grounded]` CV | none |
| R7 | Insulin administration | must_have | direct | medium | none | Insulin administration is stated plainly in your CV | `[grounded]` CV | none |
| R8 | Caring for adults in their own homes | must_have | direct | medium | presentation | Your 18 months on the discharge-to-assess team, visiting patients at home in their first week after discharge, is home-based work. It sits in the last clause of your CV's ward entry | `[grounded]` CV | E1 below |
| R9 | A small caseload of your own, supported by a senior community nurse | important | adjacent | medium | transferability | Bridge: the home visits above. Limit: you say you have never held your own caseload, and the posting builds in senior support for exactly that. Strengthener: ask how the support works | `[grounded]` your statement and CV | See G5 |
| R10 | End-of-life visits | important | unclear | low | discovery | Your CV does not mention end-of-life care | `[grounded]` CV silence | See G3 |
| R11 | Continence care and care planning | important | unclear | low | discovery | Your CV mentions catheter care only. Continence care and care planning beyond it are not stated | `[grounded]` CV silence | See G4 |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have never done one. It is desirable, not essential, and the contact has spoken on Doppler training for new staff | `[grounded]` your statement and JD tier; `[inferred]` that training may be offered | Ask whether training is provided (RR5) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R5, must_have) | discovery | Pressure ulcers and surgical wounds are stated, with no leg ulcers or compression | R5 is a `must_have` at `adjacent`, and leg-ulcer care is the first-named duty in the advert | Dressing or reviewing venous or mixed leg ulcers on the ward; applying or checking compression bandaging; teaching a patient leg care at discharge | A wound-care competency sign-off, a training certificate, or a ward wound-care audit you took part in | `[grounded]` CV scope; `[inferred]` that this is the first duty a hiring nurse would probe, from its first place in the JD |
| G2 | Written records on an electronic record (R4, must_have) | discovery | Silent on record systems | A `must_have` that is unclear. A short answer can move it to `direct` | Ward or D2A entries on an electronic record; home-visit notes written the same day; any documentation audit | A named system, an audit result, or a line from a reference | `[grounded]` CV silence |
| G3 | End-of-life care (R10, important) | discovery | Silent | Visits for it are named in the advert | Caring for dying patients on the ward; family conversations or care planning at end of life; D2A patients who died at home | A ward end-of-life training record | `[grounded]` CV silence |
| G4 | Continence care and care planning (R11, important) | discovery | Catheter care only | Both are named in the advert | Bladder and bowel care plans; discharge care plans in the D2A team | A care-plan template you used | `[grounded]` CV scope |
| G5 | Own caseload (R9, important) | transferability | Home visits in D2A, but no caseload of your own | The role's structure assumes a new caseload holder with senior support | Following the same patients across several visits; deciding visit frequency yourself within D2A | A D2A service description, a reference from its lead | `[grounded]` CV and your statement |
| G6 | Doppler (R12, preferred) | capability | None, and you say so | Desirable only | None. The route is training once in post | A Doppler competency, if the employer provides it | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Senior support built in | positive_signal | — | "supported by a senior community nurse" | A named support route for a new caseload holder | `[inferred]` from the JD's wording; how it works in practice is not stated | How does the senior nurse's support work in practice: shared visits, case review, and how often? | noted |
| RR2 | Caseload size and hours unstated | unknown | — | "a small caseload of your own" | Visit numbers, weekend and on-call duties may be material to you | `[grounded]` JD silent | How many patients is a typical caseload, and what are the hours, weekends and on-call? | unresolved |
| RR3 | Pay and mileage disclosed | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range brackets the survey's interquartile range, so placement within it is the open point | `[grounded]` JD; `[generic]` survey band | Where in the range would five years' post-registration experience place me? | noted |
| RR4 | Posting not seen live | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The employer is established, but I could not open its careers page to see this posting | `[grounded]` careers page not found | Is this role currently open, and what is the closing date? | unresolved |
| RR5 | Informal chat offered; contact's published work matches the gaps | positive_signal | — | "For an informal chat about the role, contact Rhiannon Mabbott" | You can ask about leg-ulcer and Doppler training directly | `[grounded]` JD and speaker page | Does the team train staff new to community work on Doppler assessment? | noted |

## Application plan

Everything below is pending your approval, prose advice and the CV line alike. I have audited each line clause by clause against your own sentences.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | CV line: "Seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge", placed first in your experience section | R8 | `[grounded]` CV | `resume_edits_pending_approval` |
| P1 | Say plainly in any covering text or conversation that you have never held your own caseload and have not done Doppler assessment. Offer the home visits as the bridge, and name the senior-support structure as what you would lean on. Do not claim leg-ulcer care until G1 is answered | R9, R12, R5 | `[grounded]` your statements | pending your approval |
| A1 | Before applying, check your own NMC register entry and your DVLA driving record | R1, R2 | `[grounded]` your stated credentials | pending your approval |
| A2 | Take up the informal chat with the Team Lead and ask the register's questions, RR1 to RR5, as written | Register | `[grounded]` JD invitation | pending your approval |
| A3 | Confirm the posting is open (RR4) before spending effort on the application | RR4 | `[grounded]` RR4 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about); fetched that page. A fetch of calderbrookhealth.example/careers returned no page. Moved: the organization row and the contradictions row, and RR4 (posting unseen) |
| 2. Role-family sweep | yes | Searched "community staff nurse district nursing Band 5 salary Agenda for Change 2026/27 pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved: market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved: the hiring contact and scope read rows, and RR5 |

If you'd like this saved as a dossier, say so and I'll write `tuesday-dossier.md`.

**Upgrade menu**

- Your pay floor and any limits on hours or travel → the hard-gate line can be checked against them instead of flagged unknown.
- Your own check of your NMC register entry and DVLA driving record, as results → R1 and R2 can move to `high`.
- An answer to G1 → R5 can move toward `direct`. A wound-care competency sign-off or certificate would back it.
- An answer to G2 → R4 can move from `unclear`.
- An answer to G3 → R10 can move from `unclear`.
- A link to the live posting on Calderbrook's own careers page → RR4 closes.
- A deeper research pass on the employer (leadership changes, staff and patient reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Have you dressed, reviewed or managed leg ulcers on the ward or in the D2A team, including compression bandaging? What did you do yourself, and was it signed off?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Which electronic record system did you write in on the ward and in the D2A team, and how soon after a visit or shift task did you record it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — Have you cared for dying patients on the ward or in the D2A team, and what part was yours?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.