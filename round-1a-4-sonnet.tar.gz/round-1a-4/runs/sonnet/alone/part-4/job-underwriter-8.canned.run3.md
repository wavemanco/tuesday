I'll read the skill's reference files before building the assessment.
# Job Underwriting Assessment: Remote Order Processing Coordinator, Velloway Logistics

*Stage assumed: applying, in a chat-only process. Your background (typed in the chat) is treated as self-report, so claims from it stay at `medium` confidence at most.*

## Decision snapshot

**No, don't go ahead. RR1, RR2, RR3 and RR4 are requests this process makes of you, and each one is a reason to stop. Status: `no_go`.** Your IBAN is not needed anywhere in this process, and I haven't used or repeated it.

**Fit ledger.**

- `hard_gate`: unclear: R5 (Pay floor of €30,000 a year)
- `must_have`: direct: R1, R2 · adjacent: R3 (Strong attention to detail)
- `important`: unclear: R4 (A quiet place to work)

R3: plausible from your tracker work, never measured; R5: the posting's ceiling-only pay doesn't settle your floor.

**Opportunity ledger.** The posting asks for no money. The messages ask for a payment, a cheque deposit, bank, tax and ID details before any written offer, and a hiring process run wholly in chat (RR1, RR2, RR3, RR4). The employer could not be established from a public search (RR5), and the posted rate sits oddly against the stated entry level (RR6).

- **Hard gates:** none failed; unconfirmed: R5 (Pay floor of €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** a verifiable employer, found by you independently. In writing, no equipment payment, no cheque to lodge, and no bank, tax or ID details until a written offer from that employer. An interview with a named person. Written pay terms that meet R5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". A search for its site and careers page returned no results, so the employer is not established | `[grounded]` search returned nothing |
| Role as posted | Remote order processing, "15–30 a week", "up to €26 an hour plus commission", "No experience needed, full training provided" | `[grounded]` posting |
| Annual value at the posted ceiling | €390–€780 a week at €26 an hour, so €20,280–€40,560 over 52 weeks. "Up to" sets a ceiling, not a rate, and commission is unquantified | `[inferred]` arithmetic on the posting's figures |
| Process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` posting |
| Terms added after applying | The posting mentions no equipment purchase. The messages add a €349 payment and a €2,850 cheque | `[grounded]` posting against your messages |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median base €31,200 a year (interquartile range €28,400–€34,100). The guide excludes commission-only and freelance work | `[generic]` Pennoral 2026 pay guide, one search |
| Unknowns | Employer identity; employee or self-employed; guaranteed hours; commission terms; who the "equipment partner" is | `[inferred]` from the posting's silence |
| Contradictions | Posting and messages disagree on cost to you (none stated against €349 to pay). An interview "passed" with no named interviewer | `[grounded]` your quoted messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. No artifact seen, so `medium` | `[grounded]` your account | none while the role is held |
| R2 | Good written English | must_have | direct | medium | none | About 60 Zendesk tickets a day is written customer communication | `[grounded]` your account; `[inferred]` that ticket work evidences written English | none while the role is held |
| R3 | Strong attention to detail | must_have | adjacent | low | discovery | A trait. Tracker upkeep and training two new starters point to it, but nothing you said measures accuracy | `[inferred]` from your tracker and training work | none while the role is held |
| R4 | A quiet place to work | important | unclear | none | discovery | You haven't said | `[grounded]` silence in your message | none while the role is held |
| R5 | Pay: your floor of at least €30,000 a year | hard_gate | unclear | high | hard_gate | Confidence grades your own stated constraint. Fit is `unclear` because the posting gives a ceiling, a 15–30 hour range and unquantified commission. At €26 an hour your floor needs about 1,154 hours, roughly 22 a week all year, at the top rate every hour | `[grounded]` posting and your constraint; `[inferred]` arithmetic | written pay terms from a verified employer, before anything else |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Attention to detail (R3, must_have) | discovery | Tracker upkeep and training two new starters, no accuracy measure | Only relevant if a verified role of this kind appears | An error-rate or QA result from your ticket work; a tracker you can show with data removed | A sanitized tracker screenshot | `[inferred]` from your account |
| G2 | Quiet place to work (R4, important) | discovery | Not stated | Unknown, easy to close | Your home setup | Nothing needed | `[grounded]` silence |
| G3 | Pay against your floor (R5, hard_gate) | hard_gate | Ceiling rate, hours range, commission unquantified | A hard gate stays unconfirmed until terms are in writing | n/a | A written offer naming rate, guaranteed hours and contract type, from a verified employer | `[grounded]` posting |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A payment up front, promised back later, moves your money before any work or wages exist | `[generic]` pattern: a refund promised "with your first wages" depends on wages that may never come | Do you ever ask new hires to pay for equipment? Please confirm in writing, from your own website's contact details | confirmed |
| RR2 | Cheque deposit and onward transfer demanded | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can be credited provisionally and later returned unpaid. A transfer you send stays sent, so the loss can fall on you | `[generic]` how cheque clearing works; a pattern, not a finding about this sender | Did you issue this cheque, and why would a new hire forward €2,500 of it onward? | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | These details were requested at screening stage, before any written offer naming role and pay | `[generic]` payroll checks normally follow a written offer | Do you collect these details before a written offer? Where, on your own site? | confirmed |
| RR4 | Hiring conducted wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." The offer then came as "you passed the interview and the job is yours!" | Interview and offer both happened in chat, with a mail-provider contact address (velloway.hr@postmail.example) not shown to be the employer's own domain | `[grounded]` the posting and your messages | Who interviewed me, and under what name on your site? | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` possibilities, none ranked; a search returned no results | Can you point me at this role on your own careers site? | unresolved |
| RR6 | Posted rate high against stated entry level | risk_signal | low | "Earn up to €26 an hour plus commission... No experience needed" | €31,200 median salaried (about €15 an hour at 40 hours) is well below €26, so the headline may be a ceiling few reach, or commission-based | `[inferred]` from the posting against the `[generic]` band | What is the guaranteed rate and what share of pay is commission? | unresolved |

This is a hold, and it applies while you check who sent these messages: send no details, pay nothing, and lodge no cheque. These requests are very likely a scam. Don't deposit the cheque. To check, use contact details you find yourself on a website you locate independently, never the Telegram handle or the postmail address. I haven't been able to identify the employer independently, so its identity is unresolved. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send your IBAN, PPS number or passport photo, don't pay the €349, and don't lodge the cheque | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | If anything has already gone out, contact your bank's fraud line at once and say what was sent | Banks can sometimes stop or flag transfers if told early | `[generic]` common bank practice | pending your approval |
| A3 | Stop replying in Telegram while you verify; don't open the cheque's paperwork as an acceptance | see RR4 | `[grounded]` register | pending your approval |
| A4 | Put effort into salaried customer-operations and order-processing posts with a named employer, a live careers page and a call or video interview. Your floor suits that band | see R5 and the market calibration row | `[generic]` Pennoral median; role-family pattern | pending your approval |
| A5 | When you describe yourself, stay on your own facts: about 60 tickets a day in Zendesk; trained two new starters; kept your team's weekly tracker in Excel | Keeps any later CV or message traceable to what you said | `[grounded]` your own sentences | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics official site careers"; no results, so the employer is not established. It moved role reality's organization row and RR5. No page was fetched |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland salary entry level", returning "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It moved the market calibration row and RR6 |
| 3. Hiring manager's public footprint | n/a | No person's name was given, only a Telegram handle, so no query could be formed |

Should you want it, a copy of this assessment can be saved as `tuesday-dossier.md` for later turns.

## Upgrade menu

- A link to the original posting, or the jobs site's name → RR5 and the contradictions row.
- Whether anything has been sent or paid → RR1, RR2, RR3 and plan row A2.
- The employer's own website, if you can find one independently → RR5 could resolve either way.
- A deeper research pass on this employer (news, public reports, name collisions; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

1. (RR2, RR3) Has anything already gone out: your IBAN, PPS number, a passport photo, any payment, or any contact with the bank about the cheque?
2. (RR5) Which jobs site was the posting on, and do you have its link?

You can answer in text, paste the chat, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.