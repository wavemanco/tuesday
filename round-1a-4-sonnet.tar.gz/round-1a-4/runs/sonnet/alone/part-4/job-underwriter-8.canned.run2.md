Still working on your question. I've read the assessment rules and I'm now checking whether Velloway Logistics can be found publicly.
# Job Underwriting Assessment — Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No — don't go ahead. RR1, RR2, RR3 and RR4, each a confirmed severe red flag, are requests to pay for equipment, deposit a cheque, give bank and ID details before a written offer, and be hired wholly by chat. Status: `no_go`.** These requests are very likely a scam. Don't send your IBAN, PPS number or passport photo, don't pay the €349, and don't lodge the cheque. I haven't repeated or used your IBAN. It isn't needed for this assessment.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Income of at least €30,000 a year)
- `must_have` — direct: R2, R3 · unclear: R4 (Good written English)
- `important` — unclear: R5 (A quiet place to work)

R2, R3 — your Zendesk volume and Excel tracker are stated experience, without an artifact to inspect; R4 — the CV doesn't say how much of the ticket work was written.

**Opportunity ledger.** The register holds four severe entries (RR1, RR2, RR3, RR4). The employer could not be established (RR5), and pay terms and the contact address stay open (RR6, RR7). Nothing in the register runs the other way.

- **Hard gates:** none failed; unconfirmed: R1 (Income of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would have to differ for this to move off `no_go`:** (1) no payment, cheque or pre-offer ID and bank requests; (2) the employer verified through its own website; (3) a written offer naming the employer, contract type and pay; (4) an interview held outside chat.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics: not established. Two searches returned nothing, so no site, careers page or posting could be matched to it | `[grounded]` searches returned no results |
| Posting terms | Remote, 15–30 hours a week, "up to €26 an hour plus commission", no experience needed, hiring wholly on Telegram | `[grounded]` posting |
| Pay arithmetic | 15 hours at €26 for 52 weeks is €20,280. 30 hours is €40,560. Both assume the top rate, which is "up to". Reaching €30,000 at €26 needs about 22 hours a week, every week | `[inferred]` from the posting's figures |
| Hiring process | No calls or video. The messages then asked for ID and bank details before the chat interview, a €349 payment, and a cheque lodgement. None of these appeared in the posting | `[grounded]` posting against your messages |
| Offer | Given in chat, with no written offer naming the employer, contract type or pay terms | `[grounded]` your messages |
| Market calibration | The salaried median for order processing and customer operations coordinators in Ireland is €31,200 a year (interquartile range €28,400–€34,100). The survey excludes commission-only and freelance work, so it isn't like-for-like with a variable-hours hourly post | `[generic]` Pennoral 2026 pay guide; `[grounded]` posting for the hourly figure |
| Unknowns | Who the employer is, employee or contractor status, commission terms, guaranteed hours | `[grounded]` posting silent |
| Contradictions | The posting says "full training provided", while the messages require buying a work kit and paying equipment money to a third party | `[grounded]` posting and messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Income of at least €30,000 a year (your stated minimum) | hard_gate | unclear | high | hard_gate | Confidence grades your constraint, which you stated. Fit is unclear: the pay is "up to €26", the hours run 15–30 and commission is unspecified, so €30,000 is reachable only at the top of both | `[grounded]` your constraint; `[inferred]` arithmetic from the posting | Only matters if the role were verified |
| R2 | Strong attention to detail | must_have | direct | medium | none | About 60 Zendesk tickets a day is detail-heavy work you describe. It is self-report with no artifact | `[grounded]` your background | none |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Self-report | `[grounded]` your background | none |
| R4 | Good written English | must_have | unclear | low | discovery | Zendesk is a ticket tool, which usually means written replies, but your account doesn't say how much of your work was written | `[generic]` how ticket tools are used; `[grounded]` your account silent | see G2 |
| R5 | A quiet place to work | important | unclear | low | discovery | Not covered by anything you shared | `[grounded]` background silent | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Income of at least €30,000 (R1) | hard_gate | Pay is a ceiling of €26 an hour with commission undefined and hours variable | Decides whether any verified version of this role could meet your minimum | Not applicable: this is a term of the role, not your experience | A written offer stating a rate, guaranteed hours and contract type | `[grounded]` posting; `[inferred]` that the terms are open |
| G2 | Good written English (R4, must_have) | discovery | Zendesk work is listed, but the share that was written replies is not | Written communication is the role's core task and the CV doesn't evidence it directly | Written ticket replies, escalation notes, and the written guidance you gave the two starters | A sanitized reply template or a quality-review score | `[grounded]` CV silence; `[generic]` that ticket tools usually mean written work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | A fee asked before any pay is a payment request, not a hiring step | `[grounded]` messages state the demand | Is this hiring run through this Telegram account, and does your company ask new hires to pay for equipment? | confirmed |
| RR2 | Cheque to lodge, with most of it sent on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can be credited and later returned unpaid, leaving the money you transferred out as your loss | `[generic]` how cheque clearing works; `[grounded]` messages state the demand | As RR1 | confirmed |
| RR3 | Bank and ID details asked before any offer | red_flag | high | "send your IBAN, your PPS number and a clear photo of your passport" | These details were requested before any written offer, ahead of the chat interview | `[grounded]` messages state the demand | As RR1 | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | The interview and the offer both happened in chat, with no written contract | `[grounded]` posting and messages | As RR1 | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. None of these is ranked as likely | `[generic]` pattern, not a claim about this firm | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | HR contact on a general mail domain | risk_signal | low | "velloway.hr@postmail.example" | The address may not belong to the employer named | `[inferred]` from the domain against an unestablished employer | Is this address one your own website lists? | unresolved |
| RR7 | Pay terms open-ended | unknown | — | "Earn up to €26 an hour plus commission on every order you process" | The rate, guaranteed hours and commission may be well below the ceiling | `[inferred]` from "up to" against no stated floor | What is the guaranteed hourly rate and weekly hours, and how is commission calculated? | unresolved |

Hold each of these until you have checked it with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing further: no IBAN, no PPS number, no passport photo, no €349 payment, no cheque lodgement | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | If you want to check the firm, find its own website and contact details independently, not through the chat or the email in the messages | see RR5, RR6 | `[grounded]` register | pending your approval |
| A3 | Report the posting to the jobs site it came from, and stop replying in the chat | see RR4 | `[generic]` standard reporting step | pending your approval |
| A4 | Redirect your search to salaried customer-operations roles with named employers. Lead your CV with the 60 tickets a day, the Excel weekly tracker and training two new starters, as you described them | see R2, R3 | `[grounded]` your background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and "Velloway Logistics Remote Order Processing Coordinator job"; both returned no results, so the employer is not established. No page was fetched. Moved: role reality's organization row and RR5 |
| 2. Role-family sweep | yes | Searched "order processing coordinator remote salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Moved: the market calibration row |
| 3. Hiring manager's public footprint | n/a | No name was given. "@VellowayHiring" is a handle, not a person's name, so there was no query to form |

I can also save this as `tuesday-dossier.md` if you'd like a file to keep.

## Upgrade menu

- A link to the live posting and the name of the jobs site → RR5 and the contradictions row can be checked against the original text.
- The firm's own website or careers page, if you find one → RR5, RR6 and the organization row close.
- A written offer stating employer, contract type, rate and guaranteed hours → R1 and RR7 close.
- A sanitized written reply or quality score from your Zendesk work → R4 moves up.
- A deeper research pass on the firm (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

- RR5 — Which jobs site was the posting on, and can you paste its link?
- G1 — Do you want hours near 30 a week at €26 to be workable, or should I look at what would suit a salaried €30,000-plus role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.