I'll read the skill's reference files before building the assessment.
## Decision snapshot

**Duinvaart (Operations Analyst): yes, worth applying. Status: `conditional_go`.**
**Kroonhaven (Supply Planner): no, not worth your time as posted. R10, R11 and R14 are must-haves that you can't currently evidence, and you've never worked in planning. Status: `no_go`.**

**Fit ledger: Duinvaart**

- `hard_gate`: unclear: R1 (Hybrid, three days a week in Rotterdam office)
- `must_have`: direct: R2, R3, R4, R5
- `important`: adjacent: R7 (Work with depot managers on route changes); unclear: R6 (Temperature compliance, refrigerated fleet)
- `preferred`: adjacent: R8 (Dutch a plus)

R5: your on-time delivery dashboard matches the posting's headline task; R6: temperature compliance is the open question.

**Fit ledger: Kroonhaven**

- `hard_gate`: unclear: R9 (On-site in Utrecht)
- `must_have`: adjacent: R12 (Run the weekly S&OP meeting), R15 (Fluent Dutch); unclear: R13 (Advanced Excel); absent: R10 (3+ years supply or demand planning in FMCG), R11 (Own the 13-week supply plan), R14 (SAP IBP or a similar planning system)

R10, R11, R14: planning experience and a planning system are not in your history; R12: your weekly review is a bridge with a limit.

**Opportunity ledger.** Duinvaart: the deliverables are concrete (RR3), but I couldn't check the employer (RR1) and the pay is withheld (RR2). Kroonhaven: the mandate is concrete (RR6), but the employer is unchecked (RR4) and the pay is withheld (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in Rotterdam office), R9 (On-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go (Duinvaart):** (1) the Rotterdam three-day pattern works for you (R1, G1); (2) the employer and live posting check out (RR1); (3) temperature compliance is described only as something you'd be learning, unless your answer to G2 shows experience (R6).
- **What would change Kroonhaven:** it would need evidence of planning work in your history for R10, R11 and R14, which you've told me isn't there. Wording can't fix that. Whether to apply anyway is your call. If you do, RR4 and RR5 become the questions to ask first.

## Role reality

**Duinvaart Cold Chain, Operations Analyst**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Cold-chain logistics firm in Rotterdam running a refrigerated fleet and depots | `[grounded]` posting text; nothing else checked |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | An analyst post that reports on operations rather than owning decisions. Route changes are worked "with" depot managers | `[inferred]` from the posting's verbs ("track", "build", "work with") |
| Market calibration | Not run, because the pay search was refused. A 2+ years analyst post is a normal mid-level title, and no pay band is stated here | `[generic]` role-family pattern; `[grounded]` search refused |
| Unknowns | Pay; who decides route changes; team size; what "temperature compliance" data looks like | `[grounded]` posting silent |
| Contradictions | Not checked: no careers page was read | `[grounded]` search refused |

**Kroonhaven Foods, Supply Planner**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Chilled ready-meals food producer in Utrecht | `[grounded]` posting text; nothing else checked |
| Mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | A full-ownership planning seat. The post names plan ownership and a meeting you chair, not support work | `[inferred]` from "own" and "run" in the posting |
| Market calibration | Not run, because the pay search was refused | `[grounded]` search refused |
| Unknowns | Pay; team around the planner; which planning system is in use | `[grounded]` posting silent |
| Contradictions | Not checked: no careers page was read | `[grounded]` search refused |

## Evidence map

Your background is typed prose, so I treat it like a CV: self-reported, `medium` at most until something inspectable exists.

**Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You haven't stated where you live or what commute you'll accept, so the term is neither met nor failed | `[grounded]` posting term; no constraint from you | G1 |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You state 4 years as an operations analyst at a parcel carrier in Amsterdam. Confirmed and specific, but no inspectable artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | "SQL daily" is confirmed. "Strong" is unprobed, so expect a technical screen | `[grounded]` your background; `[generic]` that analyst roles usually test SQL | A sanitized query sample would raise it to `high` |
| R4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard your depot managers use. No artifact yet | `[grounded]` your background | A sanitized dashboard screenshot would raise it to `high` |
| R5 | Track on-time delivery | must_have | direct | medium | none | Your dashboard and weekly route-performance review track on-time delivery at a parcel carrier. The posting's fleet is refrigerated, but the metric is the same | `[grounded]` your background; `[inferred]` that the metric transfers unchanged | none |
| R6 | Temperature compliance across a refrigerated fleet | important | unclear | none | discovery | Nothing in your background touches temperature-controlled freight. It may exist and not have been mentioned | `[grounded]` background silent | G2 |
| R7 | Work with depot managers on route changes | important | adjacent | medium | discovery | Depot managers use your dashboard and you ran the weekly route-performance review. Not established: whether those reviews led to route changes, or whether you attended with depot managers | `[grounded]` your background; `[inferred]` limit from the missing detail | G3 |
| R8 | Dutch a plus | preferred | adjacent | medium | transferability | Your Dutch is conversational. A "plus" is not a requirement, so this counts for you without being claimed as fluency | `[grounded]` your statement | Say "conversational Dutch" plainly |

**Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R9 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You haven't stated a location or commute limit | `[grounded]` posting term; no constraint from you | Ask only if you proceed (same question as G1, for Utrecht) |
| R10 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You've told me you've never worked in planning, and your sector is parcel logistics. A length-of-experience requirement is not a gate, but it is likely to be screened literally | `[grounded]` your statement; `[generic]` that experience years are commonly screened literally | G4 |
| R11 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | Owning a plan is different work from reporting on operations. Your analysis never set a plan | `[grounded]` your statement; `[inferred]` difference in kind from the two job descriptions | G4 |
| R12 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: an S&OP meeting reconciles demand, supply and finance and carries a plan, and your review did none of that as far as you've said | `[grounded]` your background; `[generic]` what S&OP meetings cover | G5 |
| R13 | Advanced Excel | must_have | unclear | none | discovery | Excel isn't in the tools you named (SQL, Power BI) | `[grounded]` background silent | Ask only if you proceed |
| R14 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning system appears in your history | `[grounded]` your background | G4 |
| R15 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is credible adjacent evidence, but "fluent" for running a Dutch-language planning meeting is a higher bar | `[grounded]` your statement; `[inferred]` the bar from the posting's wording | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Rotterdam three-day pattern (R1, hard_gate) | hard_gate | No home location or commute limit from you | The term is unconfirmed, and nothing else decides the Duinvaart status | n/a, a fact about you | n/a | `[grounded]` no constraint stated |
| G2 | Temperature compliance (R6, important) | discovery | Your background doesn't mention temperature-controlled freight | It is half the posting's tracking duty, so the answer decides how strong Duinvaart is | Chilled or pharma parcels; SLA breach reports; any sensor or time-in-transit data you reported on | A sanitized report or dashboard page | `[grounded]` background silent; `[inferred]` that the answer shifts the fit |
| G3 | Route changes with depot managers (R7, important) | discovery | Depot managers use your dashboard, and you ran the weekly review | Decides whether R7 reads `direct` or stays `adjacent` | A review that ended in a depot's route being changed; recommendations you made to depot managers | Meeting notes, a before-and-after route chart | `[grounded]` background; `[inferred]` limit |
| G4 | Planning ownership and planning system (R10, R11, R14, must_have) | capability | No planning work, no planning system, no FMCG | These are the rows that set Kroonhaven to `no_go` | None surfaced; no question is asked | None | `[grounded]` your statement |
| G5 | S&OP meeting (R12, must_have) | transferability | A weekly review you ran at a parcel carrier | Bridge exists, with a stated limit | Cross-team review you ran with finance or sales present | Agenda or deck | `[inferred]` bridge; `[generic]` S&OP scope |
| G6 | Fluent Dutch (R15, must_have) | transferability | Conversational Dutch | A fluency gap in a chairing role is the part you can't edit around | Working meetings held in Dutch | None | `[grounded]` your statement |

Closure paths: G4 has no short one. It would take roles or study in planning before an FMCG planner post, and I'd treat that as a different target role, not a rewrite of your CV. G6 closes with Dutch practice over time.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Duinvaart not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | It may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The check never ran (my search was refused), so this records what I haven't verified, not a finding | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` search refused | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Duinvaart pay withheld | unknown | — | no pay figure in the posting | The figure may sit under the market band or the firm may not publish pay. No band retrieved, and your floor isn't known | `[grounded]` posting silent | What salary range is budgeted for this post? | unresolved |
| RR3 | Duinvaart deliverables stated concretely | positive_signal | — | "build weekly dashboards in Power BI" | The posting names what you'd produce, so success can be judged | `[grounded]` posting | Who reads the weekly dashboard, and what decisions does it feed? | noted |
| RR4 | Kroonhaven not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same reasons as RR1, side by side and not ranked; the check did not run | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` search refused | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR5 | Kroonhaven pay withheld | unknown | — | no pay figure in the posting | Same as RR2 | `[grounded]` posting silent | What salary range is budgeted for this post? | unresolved |
| RR6 | Kroonhaven mandate stated concretely | positive_signal | — | "Own the 13-week supply plan" | Scope and a recurring forum are named | `[grounded]` posting | Who sits in the weekly S&OP meeting and who decides when capacity and forecast conflict? | noted |

## Application plan

For Duinvaart. Everything in this table is proposed, not applied: the resume lines are `resume_edits_pending_approval`, and the actions beside them are `pending your approval`. Each line traces to your own sentences. I haven't seen your CV, so "current" lines are unknown.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Power BI on-time delivery dashboard used by depot managers at a parcel carrier in Amsterdam". I've left out "built" because you didn't say you built it | R4, R5 | `[grounded]` your sentence | `resume_edits_pending_approval` |
| E2 | Resume line: "Ran the weekly route-performance review" | R5, R7 | `[grounded]` your sentence | `resume_edits_pending_approval` |
| A1 | Confirm the employer and the live posting on the company's own site before spending effort | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the RR2 and RR3 questions verbatim in the first conversation | RR2, RR3 | `[grounded]` register | pending your approval |
| A3 | On temperature compliance, say it is something you'd be learning, and don't present it as experience unless G2 supports it | R6 | `[grounded]` R6 row | pending your approval |
| B1 | Kroonhaven, only if you apply anyway: say plainly that you haven't worked in planning and offer the weekly review as a bridge with its limit stated | R10, R11, R12 | `[grounded]` rows named | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht". Both were refused, so nothing was read. It would have moved both Role reality tables' organization and contradictions rows, and RR1 and RR4 |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics salary Rotterdam Netherlands" and "supply planner FMCG salary Netherlands S&OP SAP IBP". Both were refused. It would have moved the market-calibration rows, RR2 and RR5 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I didn't retry the refused searches, so nothing here comes from outside your message.

I can produce `tuesday-dossier.md` from this assessment whenever you want it.

## Upgrade menu

- Search permission, so I can run the two company checks and the two pay searches: RR1, RR4, RR2, RR5 and both market-calibration rows would update. After that, a deeper pass (up to 5 more searches and 2 more fetches) is available once.
- Your current CV: the "current" side of E1 and E2, and any `presentation` gap I couldn't see.
- A sanitized screenshot of the on-time dashboard: R4 to `high`. A sanitized SQL sample: R3 to `high`.
- Your home location and your pay floor: R1 and R9 settle, and RR2 and RR5 can be set against a floor.
- The hiring manager's name for either role: the scope read and which story to lead with.

## Questions

G1. Where do you live now, and is three days a week in Rotterdam workable for you?

G2. Have you worked with temperature-controlled or time-critical freight data, such as chilled parcels or breach reports? If so, what did you personally own?

G3. Did a weekly route-performance review of yours ever lead to a route change at a depot? Who was in the room, and what was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.