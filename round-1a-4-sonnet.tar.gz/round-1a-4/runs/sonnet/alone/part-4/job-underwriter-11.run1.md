I'll read the skill's reference files before building the assessment.
I've finished reading the skill's rules. Next I'll run a few budgeted searches to check both employers exist as described, then write the assessment.
**Yes to Duinvaart, no to Kroonhaven.** Duinvaart is `conditional_go`: RA2, RA3 and RA4, its three must-haves, are `direct`. Kroonhaven is `no_go`: RB2, RB3, RB5 and RB6, all must-haves, are `absent`.

I couldn't check either employer because search permission was denied. Duinvaart can't go above `conditional_go` until its posting is verified.

---

# 1. Duinvaart Cold Chain — Operations Analyst, Rotterdam

## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate` — unclear: RA1 (Hybrid, three days Rotterdam)
- `must_have` — direct: RA2, RA3, RA4
- `important` — direct: RA5a; adjacent: RA6 (depot managers on route changes); unclear: RA5b (temperature compliance)
- `preferred` — direct: RA7

RA5b — temperature compliance not yet evidenced; RA6 — a credible bridge, its limit named.

**Opportunity ledger.** The employer could not be checked (RRA3) and the salary is withheld (RRA2). The office-days term is unconfirmed against your situation (RRA1).

- **Hard gates:** none failed; unconfirmed: RA1 (Hybrid, three days in Rotterdam); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on Duinvaart's own careers page (RRA3); (2) three office days a week in Rotterdam works for you (RA1, RRA1); (3) the route-change link is framed only as far as you can document it (RA6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, operating a refrigerated fleet. Not verified. | `[grounded]` JD header |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | An ordinary analyst scope: three activities, no team or budget implied | `[inferred]` from the JD's responsibility list |
| Market calibration | Not established. No search ran, so no pay or scope band is offered. | no claim made |
| Unknowns | Salary; fleet size; who the depot managers report to; whether any route-change decisions sit with this role | `[grounded]` JD silence |
| Contradictions | None between the JD and your background. The JD couldn't be checked against the company's own site. | `[grounded]` pasted JD only |

## Evidence map

Your background is self-report from your message. That caps most rows at `medium` until you share an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| RA1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You gave no constraints. Your employer is in Amsterdam, but your home location isn't stated. | `[grounded]` JD term; your constraints not given | Question RA1 |
| RA2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Your own words: four years as an operations analyst at a parcel carrier. Logistics is the same sector. | `[grounded]` your stated background | A CV or LinkedIn link would raise it |
| RA3 | Strong SQL | must_have | direct | medium | none | You use SQL daily. Whether it is "strong" is judged on depth, and nothing inspectable has been seen. | `[grounded]` your stated background | Offer a sanitized query sample |
| RA4 | Power BI or Tableau | must_have | direct | medium | none | You use Power BI daily and built the on-time delivery dashboard your depot managers use. | `[grounded]` your stated background | Offer a screenshot of the dashboard with data masked |
| RA5a | Track on-time delivery | important | direct | medium | none | Same dashboard. It is on-time delivery for parcels, not refrigerated freight. | `[grounded]` your stated background | none |
| RA5b | Track temperature compliance across a refrigerated fleet | important | unclear | low | discovery | Nothing in your background mentions temperature or other condition data. You may have tracked something similar and not said so. | `[grounded]` silence in your background | Question GA1 |
| RA6 | Work with depot managers on route changes | important | adjacent | medium | discovery | Depot managers use your dashboard and you ran the weekly route-performance review. You haven't said the review produced route changes, or that you agreed them with depot managers. | `[grounded]` your stated background | Question GA2 |
| RA7 | Dutch a plus | preferred | direct | medium | none | The JD sets no level. You describe your Dutch as conversational. | `[grounded]` JD and your statement | State "conversational" as you said it |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Temperature compliance (RA5b, important) | discovery | Your background covers delivery timing only | It is half of the role's headline responsibility, and the one thing an interviewer here is likely to probe | Reports on condition-sensitive, time-windowed or damaged parcels; service-level breach tracking; any monitoring-data feed you cleaned or reported on | A dashboard page or report extract with data masked | `[grounded]` silence; `[generic]` that a cold-chain interviewer would probe it |
| GA2 | Route changes with depot managers (RA6, important) | discovery | The review is evidenced; a decision that came out of it is not | It separates "I presented the numbers" from "I agreed changes with depot managers", and only the true one can be claimed | A route or depot schedule that changed after your review; a depot manager you worked through it with | A review pack or an email thread, masked | `[grounded]` your wording; `[inferred]` from the missing outcome |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RRA1 | Three fixed office days against an Amsterdam employer history (RA1) | unknown | — | "Hybrid, three days a week in our Rotterdam office" | The commute may or may not suit you, and the three days may or may not be negotiable | `[inferred]` from your last employer's location | Are the three office days fixed, or can they flex by team or season? | unresolved |
| RRA2 | Salary withheld | unknown | — | no figure in the posting | The posting gives no pay information at all; a band would help against your floor, but no search ran | `[inferred]` from the JD's silence | What is the salary range for this role? | unresolved |
| RRA3 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RRA4 | Success is defined by named outputs: weekly dashboards, delivery and temperature tracking | positive_signal | — | "build weekly dashboards in Power BI" | Scope is concrete and measurable | `[grounded]` JD | What would success look like in the first 90 days? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| EA1 | Lead the CV with the on-time delivery dashboard your depot managers use, and the weekly route-performance review you ran, in your own wording | See RA4, RA5a, RA6 | `[grounded]` your stated background | pending your approval |
| EA2 | List Dutch as "conversational", exactly as you described it | See RA7 | `[grounded]` your statement | pending your approval |
| EA3 | Don't claim temperature or cold-chain experience unless GA1 produces it | See RA5b | `[grounded]` RA5b row | pending your approval |
| A1 | Check the posting on Duinvaart's own careers page before spending effort | See RRA3 | `[grounded]` RRA3 | pending your approval |
| Q1 | Ask the interview questions in RRA1, RRA2 and RRA4 verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |

---

# 2. Kroonhaven Foods — Supply Planner, Utrecht

## Decision snapshot

**Not worth applying to. RB2, RB3, RB5 and RB6, all must-haves, are `absent`. Status: `no_go`.**

**Fit ledger.**
- `hard_gate` — unclear: RB1 (On-site in Utrecht)
- `must_have` — unclear: RB4 (Advanced Excel); absent: RB2 (3+ years planning, FMCG), RB3 (13-week supply plan), RB5 (SAP IBP or similar), RB6 (Fluent Dutch)
- `important` — adjacent: RB7 (weekly S&OP meeting)

RB7 — running a weekly review is a bridge, with S&OP content untested; RB4 — Excel level not stated.

**Opportunity ledger.** The role has clear scope (RRB3), but the employer couldn't be checked (RRB1) and the pay is withheld (RRB2).

- **Hard gates:** none failed; unconfirmed: RB1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **What would change this:** a record of planning work in FMCG, which you've told me you don't have; working experience of a planning system; and fluent Dutch. Fixing any one of these wouldn't change the status.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, chilled ready-meals. Not verified. | `[grounded]` JD header |
| Mandate | Own the 13-week supply plan, balance production capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A full planning-ownership role, with the plan and the meeting both owned | `[inferred]` from "own" and "run" in the JD |
| Market calibration | Not established. No search ran. | no claim made |
| Unknowns | Salary; team size; whether the plan sits above or below a senior planner | `[grounded]` JD silence |
| Contradictions | None found in the pasted text | `[grounded]` pasted JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| RB1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You gave no constraints, so the term is neither met nor failed | `[grounded]` JD term; your constraints not given | none while the status is `no_go` |
| RB2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You said you've never worked in planning. A length-of-experience term is not a gate and is graded as a requirement. | `[grounded]` your statement | Closure path in GB1 |
| RB3 | Own the 13-week supply plan and balance capacity against forecast | must_have | absent | none | capability | No planning ownership in your background. Your analysis skills carry over to the work, but that isn't the experience asked for. | `[grounded]` your statement | Closure path in GB1 |
| RB4 | Advanced Excel | must_have | unclear | low | discovery | Your stated tools are SQL and Power BI; Excel isn't mentioned either way | `[grounded]` silence in your background | none; it can't move the decision |
| RB5 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are analysis tools, not planning systems | `[grounded]` your stated tools | Closure path in GB1 |
| RB6 | Fluent Dutch | must_have | absent | medium | capability | You describe your Dutch as conversational, not fluent. Confidence grades your own statement. | `[grounded]` your statement | Closure path in GB2 |
| RB7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: nothing says it reconciled demand, supply and finance, which is what S&OP does. | `[grounded]` your statement; `[generic]` what S&OP covers | none while the status is `no_go` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GB1 | Planning experience and planning systems (RB2, RB3, RB5, must_have) | capability | No credible direct or adjacent planning evidence after your own account | Three must-haves depend on it, and a CV rewording can't create it | A closure path is a different target: a role that supports planners from the analytics side, then planning. | A planning certification or a planning-system course certificate would show the first step | `[inferred]` closure path; `[generic]` that analyst-to-planner moves are common |
| GB2 | Dutch fluency (RB6, must_have) | capability | You are conversational, not fluent | A fluent-Dutch requirement is usually screened on language level | Sustained Dutch coursework toward a recognised level; Dutch used daily at work | A language certificate at a named level | `[grounded]` your statement; `[generic]` how such requirements are screened |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RRB1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RRB2 | Salary withheld | unknown | — | no figure in the posting | The posting gives no pay information at all | `[inferred]` from the JD's silence | What is the salary range for this role? | unresolved |
| RRB3 | Ownership of the plan and the meeting stated | positive_signal | — | "Own the 13-week supply plan" | Decision rights seem real for a role this scope | `[grounded]` JD wording | Which planning decisions does this role make alone? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't apply to this posting. Put the time into roles like Duinvaart's. | See RB2, RB3, RB5, RB6 | `[inferred]` from the map | pending your approval |
| P2 | If you apply anyway, don't describe planning or fluent-Dutch experience, and ask the questions in RRB1 and RRB3 | See RB2, RB6 | `[grounded]` map rows | pending your approval |

---

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals"; both were refused, so neither employer is established. It would have fed role reality and RRA3 and RRB1. |
| 2. Role-family sweep | unavailable | I sent "operations analyst salary Rotterdam logistics SQL Power BI"; it was refused. It would have supplied the market calibration and the pay band for RRA2 and RRB2. |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Permission to search would run targets 1 and 2 and could clear RRA3 and RRB1.
- The Duinvaart posting URL, or its careers-page link, would settle RRA3 directly.
- A masked screenshot of your on-time delivery dashboard, or a sanitized query sample, would raise RA3, RA4 and RA5a toward `high`.
- Your answer to GA1 could move RA5b off `unclear`.
- Your answer to GA2 could move RA6 to `direct`.
- Your salary floor and commute limit would settle RA1 and RRA2.
- The hiring manager's name for either role would feed the scope read.

I can write this up as `tuesday-dossier.md` for Duinvaart if you want it.

**Questions**

RA1 — Will three office days a week in Rotterdam work from where you live, and do you have a salary floor?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

GA1 — Has any dashboard or report of yours tracked something beyond on-time delivery, such as temperature, damage, or time-window breaches on sensitive parcels? What did you own?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

GA2 — In your weekly route-performance review, did findings lead to a route change? Who did you work with to agree it, and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.