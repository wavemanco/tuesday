I'll read the reference files the skill points to before building the assessment.
## Decision snapshot

**Is either worth your time? The first one, yes: A, Duinvaart, is `conditional_go`. The second one, no: B, Kroonhaven, is `no_go` because B3 and B7 (planning experience and a planning system) have no evidence behind them.** I'm assuming you're at the applying stage.

### A — Operations Analyst, Duinvaart Cold Chain: `conditional_go`

**Fit ledger.**

- `hard_gate` — unclear: A1 (Hybrid, three days in Rotterdam)
- `must_have` — direct: A2, A3, A4
- `important` — direct: A5a, A6 · unclear: A5b (temperature compliance across a refrigerated fleet)
- `preferred` — adjacent: A7 (Dutch a plus)

A5b — the cold-chain half of the tracking brief is untested; A7 — conversational Dutch, limit named.

**Opportunity ledger.** The scope is concrete (RA3), but the employer is unchecked (RA1), the salary is withheld (RA2) and your authority over route changes isn't stated (RA4).

- **Hard gates:** none failed; unconfirmed: A1 (Hybrid, three days in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the commute and three office days work for you — A1; (2) temperature-compliance exposure is either found in your history or framed honestly as new — A5b, G1; (3) the employer and live posting check out — RA1.

### B — Supply Planner, Kroonhaven Foods: `no_go`

**Fit ledger.**

- `hard_gate` — unclear: B1 (On-site in Utrecht)
- `must_have` — adjacent: B2 (fluent Dutch), B5 (run the weekly S&OP meeting) · unclear: B4 (own the 13-week supply plan) · absent: B3 (3+ years planning in FMCG), B7 (SAP IBP or a similar planning system)
- `important` — unclear: B6 (advanced Excel)

B3, B7 — no planning evidence; B5 — the closest bridge, limit named; B4 — the one row a recalled answer could still move.

**Opportunity ledger.** The role is clearly specified, but the employer is unchecked (RB1) and the salary is withheld (RB2). The decision rests on fit, not on the opportunity.

- **Hard gates:** none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** you'd need evidence of capacity-versus-forecast planning work (B4) and hands-on use of a planning system (B7). Without that, an application would be competing on a profile the posting doesn't ask for.

## Role reality

| Role | Element | What it is | Provenance |
|---|---|---|---|
| A | Organization | Duinvaart Cold Chain, Rotterdam, with a refrigerated fleet and depots | `[grounded]` JD; existence not checked (RA1) |
| A | Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| A | Working pattern | Hybrid, three office days in Rotterdam | `[grounded]` JD |
| A | Scope read | An analyst post with a defined output, the weekly dashboards. No team, budget or decision rights are mentioned | `[inferred]` from the JD's verbs ("track", "build", "work with") |
| A | Market calibration | Not established: no role-family sweep ran, so pay can't be set against a band | `[grounded]` search refused |
| A | Unknowns | Salary, who decides route changes, working language, first-year outcomes | `[grounded]` JD silent |
| B | Organization | Kroonhaven Foods, Utrecht, with a chilled ready-meals range | `[grounded]` JD; existence not checked (RB1) |
| B | Mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` JD |
| B | Working pattern | On-site in Utrecht | `[grounded]` JD |
| B | Scope read | A full ownership role. The plan and the S&OP forum are yours, not supporting work | `[inferred]` from "own" and "run" |
| B | Market calibration | Not established, for the same reason as A | `[grounded]` search refused |
| B | Unknowns | Salary, team size, which planning system is in use, whether the S&OP meeting runs in Dutch | `[grounded]` JD silent |

Neither posting contradicts anything else you gave me, but I had nothing to check them against.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You work in Amsterdam now, but you haven't said what commute or office days you'll accept, so I can't call this met | `[grounded]` JD term; no constraint from you | G2 |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier. It's your own statement with no artifact yet, so `medium` | `[grounded]` your background | none |
| A3 | Strong SQL | must_have | direct | medium | none | Used daily. No query sample or artifact has been inspected | `[grounded]` your background | offer: a sanitized query would raise to high |
| A4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, and you built the on-time delivery dashboard the depot managers use. A screenshot would make it inspectable | `[grounded]` your background | offer: a sanitized dashboard screenshot would raise to high |
| A5a | Track on-time delivery | important | direct | medium | none | The dashboard you built is this task | `[grounded]` your background | none |
| A5b | Track temperature compliance on a refrigerated fleet | important | unclear | low | discovery | Nothing you've said covers temperature data or cold-chain work. It may exist, since parcel carriers sometimes run chilled lanes, but I won't assume it | `[grounded]` silence in what you gave me | G1 |
| A6 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review, and depot managers use your dashboard. Whether you decided route changes or only informed them isn't stated | `[grounded]` your background | none |
| A7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch carries over for depot conversations. The limit is that it isn't fluent, so Dutch-language documents and meetings may be harder | `[grounded]` your statement; `[generic]` that "a plus" is a soft requirement | none |
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Same open question as A1. Fully on-site is the stricter version | `[grounded]` JD term; no constraint from you | G2 |
| B2 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch carries over, but "fluent" plus a meeting you run weekly points to Dutch at work. The limit is that you'd be chairing in a second language | `[inferred]` from "fluent" next to "run the weekly S&OP meeting" | none |
| B3 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You've told me you haven't worked in planning, and nothing adjacent surfaced. A years-of-experience requirement is likely screened literally, so I treat it as a risk, not a hard gate | `[grounded]` your statement; `[generic]` that such requirements are screened literally | closure path: see G3 |
| B4 | Own the 13-week supply plan, balancing capacity against forecast | must_have | unclear | low | discovery | You've never held a planning role. Whether you did any capacity or volume forecasting inside the analyst job is unknown | `[grounded]` your statement; silence on forecasting | G4 |
| B5 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review. The limit is that S&OP is where demand, supply and finance trade off against a plan you own, and yours was a performance review. Both involve a recurring cross-team forum | `[grounded]` your background; `[inferred]` adjacency | none |
| B6 | Advanced Excel | important | unclear | low | discovery | SQL and Power BI are stated, Excel isn't, and I won't infer it | `[grounded]` silence | low priority, not asked |
| B7 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are analytics tools, not planning systems | `[grounded]` your background | closure path: see G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (A5b, important) | discovery | Nothing in your background touches temperature data | It's half the tracking brief for role A, and it's what the interview will probe | Chilled or pharma shipments, temperature-excursion reports, a cold-chain partner's KPIs, claims or SLA breaches from temperature-controlled lanes | A sanitized report or KPI definition | `[grounded]` silence; `[generic]` that interviews probe the domain-specific half |
| G2 | Location and schedule (A1, B1, hard_gate) | hard_gate | Both roles are in a different city from your current job, A hybrid and B fully on-site | Neither can be called met until your limit is known | None, since this is a term | Not applicable | `[grounded]` JD terms; no constraint from you |
| G3 | Planning experience and a planning system (B3, B7, must_have) | capability | No direct or adjacent evidence for either | These two rows decide B | None found. Realistic closure is demand-planning-analyst or supply-chain-analyst roles that feed planners, or a planning-system certification | Not applicable | `[grounded]` your statement; `[generic]` that analyst-to-planner moves are a common route |
| G4 | Capacity versus forecast work (B4, must_have) | discovery | Silent. The route-performance review may have involved volume forecasts | The one thing that could soften B | Forecasting depot volumes, matching van capacity to demand, peak-season capacity plans | A sanitized forecast sheet | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | Employer and posting not checked | unknown | — | "Duinvaart Cold Chain, Rotterdam" | Nothing is established either way, because my searches were refused | `[grounded]` search refused | Can you point me to this role on your own careers page, and who I'd work with? | unresolved |
| RA2 | Salary withheld | unknown | — | no figure in the posting | The pay may or may not fit your floor, and I couldn't calibrate it | `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |
| RA3 | Concrete, measurable scope | positive_signal | — | "Track on-time delivery and temperature compliance ... weekly dashboards in Power BI" | The work product is defined, so success is visible | `[grounded]` JD states it | Who reads the weekly dashboards, and what happens when compliance dips? | noted |
| RA4 | Authority over route changes unstated | unknown | — | "work with depot managers on route changes" | The role may recommend changes without deciding them | `[inferred]` from "work with" | Does this role decide route changes, or recommend them to depot managers? | unresolved |
| RB1 | Employer and posting not checked | unknown | — | "Kroonhaven Foods, Utrecht" | Same as RA1 | `[grounded]` search refused | Can you point me to this role on your own careers page? | unresolved |
| RB2 | Salary withheld | unknown | — | no figure in the posting | Same as RA2 | `[grounded]` JD silent | What salary range is budgeted for this post? | unresolved |

## Application plan

Everything in this plan, including the prose advice, is proposed and pending your approval. Nothing goes on your CV or to an employer until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | For A, lead the CV with the on-time delivery dashboard that depot managers use. Add figures only if you confirm them | A3, A4, A5a, A6 | `[grounded]` your background | pending your approval |
| E2 | For A, describe the weekly route-performance review as a recurring forum you ran with depot managers | A6 | `[grounded]` your background | pending your approval |
| W1 | A sanitized screenshot of the dashboard, with no customer or confidential data | raises A4 to `high` | `[grounded]` A4 row | pending your approval |
| A1 | For A, confirm hybrid days and the temperature-compliance scope with the recruiter before investing in the loop | A1, A5b, RA1 | `[grounded]` rows named | pending your approval |
| A2 | For B, don't tailor an application. Spend that time on A and on analyst-level roles that feed planners | G3 | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I sent "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals". Both were refused, so I can't say whether either employer exists as described or whether the postings are live (RA1, RB1) |
| 2. Role-family sweep | unavailable | I sent "operations analyst logistics Netherlands salary Power BI SQL" and "supply planner FMCG Netherlands salary SAP IBP". Both were refused, so there's no market calibration and the withheld salaries can't be set against a band (RA2, RB2) |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer and upgrade menu

I can save all of this as `tuesday-dossier.md` if you'd like to keep it or reuse it later.

- Permission to search would let me run the employer and live-posting checks (RA1, RB1) and a salary band for both roles.
- A sanitized dashboard screenshot would raise A4 to `high`. A sanitized query would do the same for A3.
- Your commute limit, office-day limit and salary floor would settle A1 and B1 and let me test RA2 and RB2.
- A hiring manager's name for either role would let me read their public professional background and adjust which of your stories to lead with.
- Any capacity or forecast work you did would move B4 and decide whether B stays closed.

## Questions

1. **G1** — Did your parcel carrier ever handle temperature-controlled or chilled shipments, or did you report on any temperature or condition data? What did you own, and what did you see in the numbers? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **G2** — What's the longest commute and the most office days a week you'd accept, and what's your minimum salary? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **G4** — In the route-performance work, did you ever forecast volumes or match van and depot capacity to expected demand? What did you own, and how did you know the forecast held? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.