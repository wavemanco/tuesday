I'm checking whether Marrowgate Housing is a verifiable organisation, and I'm also looking up the market pay for the role. I read the vetting guidance first, and this is the research step.
Two things first. The web searches were all refused, so nothing below is checked against the public web and everything rests on what you pasted. Also, I haven't used your name or personal details anywhere.

## Decision snapshot

**Yes, what the offer asks for is routine. Payroll and ID details requested after a written offer that names the role and pay, from people you interviewed with in person, are standard onboarding, and nothing you pasted is a red flag. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Hybrid, two office days in Limerick), R2 (Salary €40,000), R3 (Right to work in Ireland)
- `must_have`: direct: R5, R7, R8 · adjacent: R4 (Monthly payroll for 240 staff) · unclear: R6 (Irish PAYE, PRSI, USC)
- `important`: direct: R9, R11 · unclear: R12 (Staff payroll queries) · absent: R10 (Pension changes)

R10: a gap you named yourself; R6 (`low`): not yet stated, one answer settles it; R4: a credible bridge, its limit named.

**Opportunity ledger.** The offer matches the advert on title, pay band and hybrid pattern (RR3). The employer has not been independently established (RR1), the contract terms are not yet in hand (RR2), and the advert doesn't say whether this is a sole post, or who covers the pension work you haven't done (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two office days in Limerick), R2 (Salary €40,000), R3 (Right to work in Ireland); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:**
  1. RR1 clears: the portal address matches the website you can find for them independently.
  2. RR2: the written contract is in hand before you resign anywhere.
  3. R6 and R10 are described honestly, as stated in your own account.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff. Not independently checked: the searches were refused | `[grounded]` the advert and offer you pasted |
| Mandate | Monthly payroll, starters, leavers, pension changes, monthly payroll-to-ledger reconciliation, staff payroll queries | `[grounded]` the advert |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` the offer |
| Working pattern and pay | Hybrid, two office days a week; advert €38,000–€42,000, offer €40,000 | `[grounded]` advert and offer agree |
| Scope read | The advert names no team, so whether this is a sole payroll post is unstated | `[inferred]` from the advert's silence on team |
| Market calibration | Not run, so I have no band to set €40,000 against | `[grounded]` the pay search was refused |
| First-year outcomes | Not stated in the advert | `[grounded]` the advert |
| Unknowns | Sole post or not; who handles pension changes now; probation, notice, hours, pension scheme, leave | — |
| Contradictions | None between the advert and the offer on title, pay, or hybrid pattern | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | You've given no constraint on this. Two in-person interviews show you can reach the office, not that two days a week suits you | `[grounded]` your message and the offer | Q2 |
| R2 | Salary €40,000 (advert €38,000–€42,000) | hard_gate | unclear | none | hard_gate | The offer sits inside the advert's band, but your own floor is not stated | `[grounded]` advert and offer | Q2 |
| R3 | Right-to-work check (passport scan) | hard_gate | unclear | none | hard_gate | Your status is not stated. The check is the employer's routine step | `[grounded]` the offer; your status not stated | Q2 |
| R4 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Carries over: full payroll cycles for 90 staff. Limit: smaller headcount, fortnightly not monthly, and no stated single run at 240 | `[grounded]` your account; limit `[inferred]` from the 90-versus-240 gap | Note your largest single run when interviewing |
| R5 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll, confirmed in your message, with nothing inspected yet | `[grounded]` your account | none |
| R6 | Working knowledge of Irish PAYE, PRSI, USC | must_have | unclear | low | discovery | Your account doesn't say which tax system you ran. Not assumed either way | `[grounded]` silence in your account | Q1 |
| R7 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, stated and specific, nothing inspected | `[grounded]` your account | none |
| R8 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024; certificate not seen | `[grounded]` your account | Keep the certificate to hand |
| R9 | Process starters and leavers | important | direct | medium | none | Stated as part of your hotel-group work | `[grounded]` your account | none |
| R10 | Process pension changes | important | absent | none | capability | You said your manager handled these, so you haven't done them | `[grounded]` your own statement | Say so plainly; ask who supports it (RR4, G2) |
| R11 | Monthly reconciliation of payroll to the general ledger | important | direct | medium | none | You did exactly this monthly, stated specifically | `[grounded]` your account | none |
| R12 | Answer staff payroll queries | important | unclear | none | discovery | Your account is silent on queries | `[grounded]` silence in your account | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R6, must_have) | discovery | Three years of payroll, with the tax system not stated | A must-have the whole role runs on; one answer settles it | Running payslips, tax credit and PRSI class changes, year-end returns, or Revenue queries in Ireland | A sanitised payslip, a year-end checklist, or your certificate's syllabus | `[grounded]` silence in your account |
| G2 | Pension changes (R10, important) | capability | Never done; your manager handled them | A named responsibility, so expect it to come up | Closure path: ask what scheme and training the role comes with, and learn it on the job | The scheme's own guide, once you have it | `[grounded]` your statement |
| G3 | Staff payroll queries (R12, important) | discovery | Nothing stated | A named responsibility | Answering staff about payslips, deductions or leave pay | A query log or a template reply you wrote | `[grounded]` silence in your account |
| G4 | Scale: 240 staff, monthly (R4, must_have) | transferability | 90 staff, fortnightly, plus a monthly reconciliation | A bridge to 240 staff is credible but its limit is size | A peak period or group payroll with more than 90 people on it | A sanitised payroll summary showing headcount | `[inferred]` bridge from your 90-staff work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not independently established | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The searches were refused, so nothing is confirmed from public sources. Small organisations can have a thin footprint, or a posting can be out of date | `[generic]` pattern, not a claim about this employer | Can you point me at this role on your own careers site, and confirm the address the onboarding link will come from? | unresolved |
| RR2 | Contract terms not yet in hand | unknown | — | "starting on a date we agree once your notice period ends" | The offer email may be a summary and a full contract with probation, notice, hours and pension scheme may follow | `[inferred]` from the offer's silence on those terms | Can you send the written contract, including probation, notice period, hours and pension scheme, before I give notice? | unresolved |
| RR3 | Offer matches the advert | positive_signal | — | "permanent post of Payroll Administrator at €40,000" and "Salary €38,000–€42,000" | Terms are consistent across advert and offer, with a named reporting line | `[grounded]` the two texts | Who else is on the payroll team? | noted |
| RR4 | Sole post and pension cover unstated | unknown | — | "Run the monthly payroll for our 240 staff" | You may be the only payroll person, or there may be cover and training for pension changes | `[inferred]` from the advert naming no team | Who handles pension changes today, and what training or cover would I have in my first months? | unresolved |

## Application plan

Everything here, wording included, is proposed and is finalised only on your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | After accepting, enter bank, PPS and passport details only in the portal reached from the address on Marrowgate's own website, not from a link in any other message. Bring the original passport on day one, as asked | see RR1. Being asked for these before any offer is the case to refuse; after a written offer it is a normal step | `[generic]` common onboarding practice | pending your approval |
| A2 | Within the five working days, reply asking for the written contract and terms, and don't hand in notice until it is signed | see RR2 | `[generic]` common practice | pending your approval |
| A3 | Ask Declan the RR4 question. Suggested wording: "Pension changes were handled by my manager at the hotel group, so that's the part I'd most like to learn. Who covers it here and what support is there?" | see R10, RR4. It states only what you told me | `[grounded]` your own account of R10 | pending your approval |
| A4 | Have a figure ready for your largest single payroll run and your Irish tax experience | see R4, R6 | `[grounded]` the R4 and R6 rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association" and "marrowgatehousing.ie careers Payroll Administrator"; both refused. Would have fed role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | unavailable | Searched "Payroll Administrator salary Ireland Limerick 2026"; refused. Would have fed the market calibration line |
| 3. Hiring manager's public footprint | unavailable | Searched "Declan Garvagh Finance Manager Marrowgate Housing"; refused. Would have fed the scope read and the plan's positioning |

## Upgrade menu

- Search permission granted: R1–R3's context firms up, RR1 may close, and a pay band to set €40,000 against.
- Your answer on Irish payroll tax: R6 can rise to `medium`.
- A sanitised payroll summary or reconciliation sheet: R4 and R11 can reach `high`. Your certificate: R8 can reach `high`.
- Your pay floor and office-day limits: R1 to R3 resolve.
- The written contract: RR2 closes.

I can write this up as `tuesday-dossier.md` if you'd like to keep it.

**Questions**

Q1 (R6): Which Irish tax work did you personally do at the hotel group, for example PAYE, PRSI classes, USC, or Revenue returns?

Q2 (R1–R3): Are €40,000 and two office days a week in Limerick within your terms, and is your right to work in Ireland straightforward?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.