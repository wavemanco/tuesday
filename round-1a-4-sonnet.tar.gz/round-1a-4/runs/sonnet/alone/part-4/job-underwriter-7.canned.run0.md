I'll read the reference files the skill requires before building the assessment.
I've read the underwriting rules and I'm now loading the web tools to run the employer and salary checks. After that I'll write the assessment.
**Is it worth applying for?** Yes, on conditions. I read your CV against the advert, checked the employer and the pay range, and found nothing that blocks you. The main gap is that you haven't held your own caseload.

## Decision snapshot

**Yes, worth applying for, with conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3 · adjacent: R5 (own small caseload and care planning), R6 (care of housebound adults in their own homes) · unclear: R4 (clear, timely written records)
- `important`: direct: R7, R9, R11 · unclear: R8 (leg-ulcer care), R10 (continence care), R12 (end-of-life visits)
- `preferred`: absent: R13 (Doppler assessment for leg ulcers)

R5 and R6 — a real bridge through your discharge-to-assess home visiting, with the caseload limit named; R8, R10, R12 and R4 — your CV is silent, so these can be recovered; R13 — Doppler is absent, and the advert lists it as desirable.

**Opportunity ledger.** The employer matches the advert (RR1), the pay is stated (RR6), and support from a senior nurse is promised (RR3). Still open: whether the post is live (RR2), induction and Doppler training (RR4), contract and rota (RR5), and when mileage is paid (RR7).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`), both on your own statement and not yet checked against the NMC register or your driving record; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 yourself, on your NMC register entry and your driving record; (2) the caseload step is framed honestly as adjacent, never as caseload experience (R5, R6); (3) RR2, RR4 and RR5 are answered, ideally in the informal chat the advert offers.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC runs adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. It was founded in 2015 and has 410 staff across four locality hubs | `[grounded]` About page, calderbrookhealth.example/about |
| Role | Community Staff Nurse, Band 5, in the Halifax district nursing team. You would care for housebound adults at home: wounds and leg ulcers, catheters and continence, end-of-life visits, insulin, and care planning, all on an electronic patient record | `[grounded]` advert |
| Requirements | Essential: NMC Adult registration, full UK driving licence (pool cars provided), at least one year post-registration, clear and timely records. Desirable: Doppler assessment for leg ulcers | `[grounded]` advert |
| Scope read | An entry-level community post with a small caseload of your own and a named senior nurse behind you | `[inferred]` from "small caseload of your own" and "supported by a senior community nurse" |
| First-year outcomes | Not stated | `[grounded]` advert silent |
| Unknowns | Contract basis, hours and rota, on-call, induction and competency sign-off, how much accompanied visiting comes first, when mileage is paid | `[grounded]` advert silent on each |
| Market calibration | A survey of Band 5 community staff nurses in England puts median basic pay at £34,300, with a middle half from £32,400 to £36,600. 61% were paid mileage and 24% had a pool or lease car. The advert's £31,050–£37,800 brackets that middle half. This is a pattern, not this employer's offer | `[generic]` Wardround 2026 pay guide (n=1,240), one search; `[grounded]` advert for the stated range |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. At a 2025 forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page (public professional footprint only) |
| Contradictions | None between the advert and the About page. The careers page I tried returned no page, so a live listing is not confirmed (RR2) | `[grounded]` About page; failed fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state Registered Nurse (Adult), registration active, revalidation due March 2028. Stated, not checked | `[grounded]` CV | You check your entry on the NMC register |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Stated, not checked | `[grounded]` CV | You check your DVLA driving record |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length of experience is not a gate | `[grounded]` CV | none |
| R4 | Clear, timely written records on an electronic patient record | must_have | unclear | none | discovery | The CV is silent on records and on any record system. I am not assuming a practice you did not state | `[grounded]` CV silence | Say which record system you used on the ward and in discharge-to-assess |
| R5 | Hold a small caseload of your own; care planning | must_have | adjacent | medium | transferability | Adjacent evidence: 18 months seconded to the discharge-to-assess team, visiting patients at home. Limit: you have never held your own caseload, and I don't know who set your visits or plans. The advert's named senior nurse softens the step | `[grounded]` CV and your statement; `[generic]` that a first caseload is normally supported | See G3 |
| R6 | Care of housebound adults in their own homes | must_have | adjacent | medium | transferability | Your home visits are first-week post-discharge. The advert is ongoing care of housebound adults, and your CV doesn't say housebound | `[grounded]` CV | See G3 |
| R7 | Wound care | important | direct | medium | none | CV states wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R8 | Leg-ulcer care | important | unclear | low | discovery | Pressure-ulcer and surgical wound care is indirect context. Leg ulcers are not mentioned | `[grounded]` CV; `[generic]` that this is a distinct skill area | See G1 |
| R9 | Catheter care | important | direct | medium | none | CV states catheter care | `[grounded]` CV | none |
| R10 | Continence care | important | unclear | low | discovery | Catheter care is indirect context; continence care itself is not stated | `[grounded]` CV | See G5 |
| R11 | Insulin administration | important | direct | medium | none | CV states insulin administration. The advert also says "care planning" for insulin, which is not stated | `[grounded]` CV | none |
| R12 | End-of-life visits | important | unclear | none | discovery | The CV is silent on end-of-life care | `[grounded]` CV silence | See G2 |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have never done one | `[grounded]` your statement | Ask whether training is provided (RR4) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R8, important) | discovery | Wound care is stated, but not leg ulcers | The advert names leg-ulcer care and desires Doppler, so this is where a community interviewer is likely to probe | Dressing venous ulcers on the ward, compression bandaging, tissue-viability link-nurse work, leg ulcers seen during discharge visits | A tissue-viability competency record or training certificate | `[grounded]` CV silence; `[generic]` that a community interview tends to probe it |
| G2 | End-of-life visits (R12, important) | discovery | The CV is silent | End-of-life visits are a named part of the work | Last-days care on a medical ward, anticipatory medicines, syringe drivers, family conversations, a dying patient discharged home | An end-of-life competency sign-off or course certificate | `[grounded]` CV silence |
| G3 | Own caseload and home-based care (R5 and R6, must_have) | transferability | Home visiting in discharge-to-assess is evidenced. Your own caseload is not, and the CV doesn't say what you decided, planned or escalated | These are the two must-have rows at `adjacent`, and a clear bridge is what narrows the main objection | Choosing visit order, writing care plans, escalating a deteriorating patient, discharging patients from the service, working alone in homes | A service description of the discharge-to-assess team or a supervisor's statement | `[grounded]` CV; `[inferred]` that this is the likeliest objection |
| G4 | Written records on the electronic record (R4, must_have) | discovery | The CV is silent. Not asked this turn, because the answer is unlikely to move the decision | A named essential requirement | Documentation in the ward's system, discharge-to-assess notes, an audit of your records | An anonymised audit or training record | `[grounded]` CV silence |
| G5 | Continence care (R10, important) | discovery | Catheter care is stated, and continence care beyond that is not. Not asked this turn | A named responsibility | Bladder and bowel management, continence assessment, catheter changes or trials without catheter | A competency record | `[grounded]` CV |
| G6 | Doppler assessment (R13, preferred) | capability | Never done | A desirable item, so a minor risk | Closure path: ask whether the employer trains staff in it (RR4) | A course certificate, if you do one | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the advert | positive_signal | — | "Calderbrook Community Health CIC, Halifax" | The employer exists as described and runs district nursing in Halifax | `[grounded]` About page and the team lead's speaker page | Which hub would this post be based at, and who is the senior community nurse? | noted |
| RR2 | Posting not confirmed live | unknown | — | "Community Staff Nurse, Band 5" | The vacancy may sit at an address I didn't try, or may have closed | `[inferred]` from the careers fetch returning no page | Is this post still open, and what is the closing date? | unresolved |
| RR3 | Support stated | positive_signal | — | "supported by a senior community nurse" | Support exists, but its amount is not stated | `[grounded]` advert | How much accompanied visiting comes before I carry my own caseload? | noted |
| RR4 | Induction and training not stated for an own-caseload post | unknown | — | "You will hold a small caseload of your own" | Competency sign-off in leg-ulcer, Doppler and end-of-life care may or may not be provided | `[inferred]` from the advert's silence | What induction and competency sign-off do new community nurses get, and is Doppler training provided? | unresolved |
| RR5 | Contract basis, hours and rota not stated | unknown | — | "end-of-life visits" | Visits of this kind may mean evenings or weekends, and the contract may not be permanent | `[inferred]` from the advert's silence | Is the post permanent and full-time, and what are the rota, weekend and on-call arrangements? | unresolved |
| RR6 | Pay stated | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range sits comfortably against the market median and middle half | `[grounded]` advert; `[generic]` Wardround survey figures | Where would someone with five years' acute experience start on the range? | noted |
| RR7 | Mileage beside pool cars | unknown | — | "pool cars are provided" … "plus mileage" | Mileage may apply only to personal-car use | `[inferred]` from the two phrases together | When is mileage paid if pool cars are provided? | unresolved |

## Application plan

`resume_edits_pending_approval`

| # | Current CV framing | Proposed framing | Why | Status |
|---|---|---|---|---|
| E1 | "Five years as a staff nurse on an acute medical ward at a district general hospital, the last 18 months seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge" | Lead the experience with the same sentence, placed first and unchanged in substance. Then list wound care including pressure ulcers and surgical wounds, catheter care and insulin administration in the advert's order | Puts home visiting first, which is R5 and R6's evidence. No fact is added | pending your approval |

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the advert's informal chat with Rhiannon Mabbott. Ask the RR2, RR3, RR4, RR5 and RR7 questions verbatim | The advert invites it, and the register is also your interview preparation | `[grounded]` advert, register | pending your approval |
| A2 | State plainly in your application that you have never held your own caseload and have not done Doppler assessment, and give the discharge-to-assess home visiting as what you have done | Keeps R5 and R13 honest. The line says only what you told me | `[grounded]` your statements | pending your approval |
| A3 | Check your NMC register entry and driving record before applying | R1 and R2 are stated, not checked | `[grounded]` R1, R2 | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this assessment, and I haven't used or repeated it.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC Community Staff Nurse Band 5 district nursing vacancy". Both returned "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers returned no page. Role reality's organization and contradictions rows; RR1 and RR2 |
| 2. Role-family sweep | yes | Searched "Community Staff Nurse Band 5 district nursing salary Agenda for Change 2026/27 pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration; RR6 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Role reality's hiring-contact row; A1 |

I can write all of this to `tuesday-dossier.md` if you want it kept.

## Upgrade menu

- Your own check of the NMC register entry and your driving record → R1 and R2 move from stated to confirmed.
- A discharge-to-assess service description or a supervisor's statement → R5 and R6 strengthen.
- A tissue-viability or end-of-life competency record → R8 and R12 rise from the confidence they hold now.
- A record-keeping audit or an electronic-record training record → R4 firms up.
- The link to the live listing, or the closing date → RR2 closes.
- Rhiannon's answers on contract, rota, induction and Doppler training → RR4, RR5 and RR7 close, and the decision likely simplifies to `go`.
- Any pay floor, hours or contract you will not trade → I can then check them against the post's terms.
- A deeper pass on Calderbrook (leadership and service changes, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

G3 — In your discharge-to-assess role, who decided which patients you visited, and what did you own at a visit (assessing, planning care, escalating, discharging from the service)? Who else was involved?

G1 — Have you managed leg ulcers (compression bandaging, say) or done leg-ulcer assessment, on the ward or in discharge-to-assess? What did you do yourself?

G2 — Have you cared for dying patients, on the ward or at home, including anticipatory medicines or syringe drivers? What was yours to do?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.