I'll read the skill's reference files before writing the assessment.
## Decision snapshot

**Role A, Duinvaart Cold Chain, Operations Analyst: yes, it's worth your time, on conditions · `conditional_go`.**
**Role B, Kroonhaven Foods, Supply Planner: no, skip it. B2, B3 and B6 are three `must_have` rows with no planning evidence behind them · `no_go`.**

**Fit ledger, Role A**

- `hard_gate`: unclear: A1 (Hybrid, three days in Rotterdam office)
- `must_have`: direct: A2, A3, A4
- `important`: direct: A5 · adjacent: A6 (Temperature compliance tracking), A7 (Work with depot managers on route changes)
- `preferred`: adjacent: A8 (Dutch a plus)

A6: a credible bridge, its limit named; A4 (`medium`): confirmed, waiting on a dashboard screenshot.

**Fit ledger, Role B**

- `hard_gate`: unclear: B1 (On-site in Utrecht)
- `must_have`: adjacent: B4 (Run the weekly S&OP meeting), B7 (Fluent Dutch) · unclear: B5 (Advanced Excel) · absent: B2 (3+ years supply or demand planning in FMCG), B3 (Own the 13-week supply plan), B6 (SAP IBP or a similar planning system)

B2, B3, B6: no planning evidence at all, and they are the core of the role; B4: the weekly-meeting habit carries over, the S&OP content doesn't.

**Opportunity ledger, Role A.** Neither the employer nor the posting could be established from here (RRA1), and pay is withheld (RRA2). The tools and metrics are named concretely, which runs the other way (RRA3).
**Opportunity ledger, Role B.** The employer and posting are not established (RRB1) and pay is withheld (RRB2). The owned outputs are named clearly (RRB3).

- **Hard gates, A:** none failed; unconfirmed: A1 (Hybrid, three days in Rotterdam office); candidate constraints not given — checks against them unknown
- **Hard gates, B:** none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found, in either role.
- **Conditions for A:** (1) three office days in Rotterdam turn out workable for you (A1, GA1); (2) the posting and employer verify on the employer's own careers page (RRA1); (3) the temperature-compliance bridge is framed as adjacent, never as cold-chain experience (A6).
- **What would change B:** `no_go` would only move if you had hands-on planning work in FMCG (B2, B3) and experience with a planning system such as SAP IBP (B6). You told me you haven't worked in planning, and wording can't close that.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| A: Organization | Duinvaart Cold Chain, Rotterdam, a refrigerated-fleet operator | `[grounded]` JD header; existence not established, see RRA1 |
| A: Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| A: Terms | Hybrid, three days a week in the Rotterdam office; pay not stated | `[grounded]` JD |
| A: Scope read | An analyst post whose stated floor of 2+ years sits below your four | `[inferred]` from the JD's requirement against your stated tenure |
| B: Organization | Kroonhaven Foods, Utrecht, chilled ready-meals | `[grounded]` JD header; existence not established, see RRB1 |
| B: Mandate | Own the 13-week supply plan, balance capacity against the forecast, run the weekly S&OP meeting | `[grounded]` JD |
| B: Terms | On-site in Utrecht; fluent Dutch required; pay not stated | `[grounded]` JD |
| B: Scope read | A planner-owner post: the plan and the meeting both sit with this one role | `[inferred]` from "own" and "run" in the JD |
| Market calibration | Not run for either role; the salary searches were refused, so no band is offered | `[grounded]` the tally below |
| Unknowns | Pay for both; whether either role is open and live; your location against both offices | `[grounded]` JDs silent; constraints not given |
| Contradictions | None inside either posting | `[grounded]` the two JD texts |

## Evidence map

Your background is typed prose, so it counts as self-report. `medium` is the ceiling until something inspectable arrives.

**Role A**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You haven't stated where you live or what you can commute; your Amsterdam employment is the only hint | `[grounded]` JD; `[inferred]` from the Amsterdam employer, which does not settle it | GA1 |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier, against a floor of 2. Self-reported, nothing inspectable yet | `[grounded]` your background | none |
| A3 | Strong SQL | must_have | direct | medium | none | "SQL daily" is specific; "strong" has no artifact behind it yet | `[grounded]` your background | Offer: a sanitized query or report you wrote would raise to `high` |
| A4 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI, including the on-time delivery dashboard depot managers use | `[grounded]` your background | Offer: a sanitized dashboard screenshot would raise to `high` |
| A5 | Track on-time delivery | important | direct | medium | none | The dashboard you work in measures exactly this | `[grounded]` your background | none |
| A6 | Track temperature compliance across a refrigerated fleet | important | adjacent | low | transferability | The metric-tracking pattern carries over. Nothing you've said touches temperature, excursions or cold-chain data, which is the limit | `[inferred]` adjacency from your delivery-performance work | GA2 |
| A7 | Work with depot managers on route changes | important | adjacent | medium | discovery | Depot managers use your dashboard and you ran the weekly route-performance review. Whether they attended it or acted on route changes is not stated, so I took the lower reading | `[grounded]` your two statements; the link between them is not stated | GA3 |
| A8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch partly meets a "plus". Limit: not fluent | `[grounded]` your statement | State it plainly as conversational |

**Role B**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Location not stated; five days on-site is a term you meet or don't | `[grounded]` JD; constraints not given | GA1 |
| B2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You've never worked in planning, and a parcel carrier is not FMCG | `[grounded]` your statement | closure path in GB3 |
| B3 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No forecasting or capacity-balancing work in your background | `[grounded]` your statement | GB3 |
| B4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly performance review. Limit: it wasn't the reconciliation of demand, supply and finance that S&OP is | `[grounded]` your background; `[generic]` S&OP's scope | none |
| B5 | Advanced Excel | must_have | unclear | none | discovery | You named SQL and Power BI, not Excel | `[grounded]` your background is silent | GB2 |
| B6 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are analytics tools, not planning systems | `[inferred]` from your named tools against the JD | GB3 |
| B7 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is real adjacent ability, but "fluent" is the bar and wording can't close it | `[grounded]` your statement | GB4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Location against both offices (A1, B1; hard_gate) | hard_gate | No location or constraints given | A gate you meet or don't; it can move A's status | Your home base, a realistic commute, any fixed office-day limit | None needed; your own statement | `[grounded]` constraints not given |
| GA2 | Temperature compliance (A6; important) | transferability | Delivery-performance tracking, no temperature data | The cold-chain half of the headline duty | Delivery-window or SLA breach tracking; chilled or pharma parcels; cold-room or excursion logs; any alert-threshold reporting | A sanitized report or screenshot | `[inferred]` bridge from your on-time work |
| GA3 | Depot-manager route work (A7; important) | discovery | Dashboard use plus a weekly review you ran, no stated link | Decides whether A7 is `direct` and whether the dashboard line says "built" or "maintained" | Route changes agreed in your review; depot managers asking for new cuts; a change you backed with data | Review agenda, a route-change summary | `[grounded]` your two statements, link unstated |
| GB2 | Advanced Excel (B5; must_have) | discovery | Not mentioned | Moot while B2, B3 and B6 stand | Pivot models, lookup-heavy workbooks, macros | A sanitized workbook | `[grounded]` background silent |
| GB3 | Planning core (B2, B3, B6; must_have) | capability | No planning work or planning-system use | These three rows are the role's core and are not recoverable by repositioning | A planning-adjacent stretch such as demand or supply analyst, S&OP analyst, or a SAP IBP course | A certification or a reporting project in a planning team | `[grounded]` your statement; `[generic]` closure routes |
| GB4 | Dutch fluency (B7; must_have) | transferability | Conversational | Fluency is a bar, not a keyword | A formal level test (for example a recognised proficiency exam) | A certificate | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RRA1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RRA2 | Pay not stated | unknown | — | (no figure in the posting) | The pay may sit anywhere relative to market, or the employer may simply not publish it | `[generic]` not a claim about this employer | What salary range is budgeted for this post? | unresolved |
| RRA3 | Concrete tools and metrics | positive_signal | — | "Track on-time delivery and temperature compliance … Power BI" | The scope is defined by named metrics and tools | `[grounded]` JD | Which dashboards exist today, and who reads them? | noted |
| RRB1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RRB2 | Pay not stated | unknown | — | (no figure in the posting) | As RRA2 | `[generic]` not a claim about this employer | What salary range is budgeted for this post? | unresolved |
| RRB3 | Owned outputs named | positive_signal | — | "Own the 13-week supply plan … run the weekly S&OP meeting" | The mandate is defined and owned by one person | `[grounded]` JD | Who owns the forecast the plan balances against? | noted |

## Application plan

Every row is proposed, not final. Nothing here is applied until you approve it, and the resume lines carry the marker `resume_edits_pending_approval`.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume line: "Daily SQL and Power BI work, including the on-time delivery dashboard used by depot managers". The verb ("built", "co-built", "maintained") waits on your answer to GA3 | See A3, A4, A5; the wording mirrors your own sentence | `[grounded]` your background | `resume_edits_pending_approval` |
| E2 | Resume line: "Ran the weekly route-performance review" | See A7; nothing is added to what you said | `[grounded]` your background | `resume_edits_pending_approval` |
| P1 | Lead the application with E1 and E2, since the posting names on-time tracking, Power BI dashboards and route changes | See A4, A5, A7 | `[grounded]` JD against your background | pending your approval |
| P2 | Write "conversational Dutch", never "fluent" | See A8, B7 | `[grounded]` your statement | pending your approval |
| P3 | For A, check the live role on the employer's own careers page before sending anything | See RRA1 | `[grounded]` register | pending your approval |
| P4 | For A, ask RRA1 to RRA3's verification questions verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P5 | Skip B; if a planning career interests you, aim first at a planning-adjacent analyst role that uses your SQL and Power BI | See GB3 | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches sent and refused: "Duinvaart Cold Chain Rotterdam operations analyst", "Kroonhaven Foods Utrecht supply planner chilled ready meals". Would have settled RRA1 and RRB1 and checked the postings are live |
| 2. Role-family sweep | unavailable | Searches sent and refused: "operations analyst logistics salary Netherlands Rotterdam", "supply planner FMCG salary Netherlands SAP IBP Dutch required". Would have supplied the market calibration and a pay check for RRA2 and RRB2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer and upgrade menu

I can write this up as `tuesday-dossier.md` if you want to keep it or reuse it later.

- Your location and any fixed limits (office days, pay floor, right to work) → A1 and B1 close, and the hard-gates lines stop reading "constraints not given".
- A sanitized dashboard screenshot → A4 to `high`; a sanitized SQL sample → A3 to `high`.
- The links to the live postings, or search permission → RRA1 and RRB1 close, and a pay band can be set against RRA2.
- A deeper pass on Duinvaart (leadership, hiring patterns, recent news; up to 5 more searches and 2 more fetches) is offered once. It needs search permission first.

## Questions

GA1: Where are you based, and is anything non-negotiable for a job, such as office days, commute, a pay floor, notice period or right to work?

GA2: Have you worked with temperature-sensitive or time-critical freight data, such as chilled or pharma parcels, delivery-window breaches or cold-room logs? If so, what did you track?

GA3: What did you personally own on the on-time dashboard and the weekly route review (building or maintaining the dashboard, who attended the review)? Did depot managers act on route changes that came out of it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.