I'm reading the skill's last two reference files, on evidence vocabulary and row shape. Then I'll write the full assessment of both roles.
Of the two roles, apply to Duinvaart, and only once a few things check out. Skip Kroonhaven.

# Assessment: Operations Analyst at Duinvaart Cold Chain, and Supply Planner at Kroonhaven Foods

## Decision snapshot

**Yes for the first role: Duinvaart is worth your time. Status: `conditional_go`.**
**No for the second role: Kroonhaven is not worth your time, because K1, K2 and K5 (all `must_have`) are absent. Status: `no_go`.**

### Duinvaart — Operations Analyst

- **Fit ledger.**
  - `hard_gate` — unclear: D8 (three days a week in Rotterdam)
  - `must_have` — direct: D1, D2, D3, D4 · adjacent: D5 (Temperature compliance across the fleet)
  - `important` — direct: D6
  - `preferred` — direct: D7
  - D5 — a credible bridge, its limit named; D8 — unconfirmed, and yours to judge.
- **Opportunity ledger.** The role is concretely scoped (DR4), but the employer is not yet verified (DR1), the pay is withheld (DR2), and the influence over route changes is unspecified (DR3).
- **Hard gates:** none failed; unconfirmed: D8 (Three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify (DR1); (2) the Rotterdam schedule works for you (D8); (3) the temperature-compliance bridge is framed as adjacent, never as cold-chain experience (D5).

### Kroonhaven — Supply Planner

- **Fit ledger.**
  - `hard_gate` — unclear: K8 (On-site in Utrecht)
  - `must_have` — adjacent: K3 (Run the weekly S&OP meeting), K6 (Fluent Dutch) · unclear: K4 (Advanced Excel) · absent: K1 (3+ years of FMCG planning), K2 (Own the 13-week supply plan), K5 (SAP IBP or similar)
  - K1, K2, K5 — no planning evidence and no planning-system evidence; K3 — a credible bridge, its limit named.
- **Opportunity ledger.** The deliverables are clearly defined (KR3), but the employer is not yet verified (KR1) and the pay is withheld (KR2).
- **Hard gates:** none failed; unconfirmed: K8 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would have to differ for a go:** evidence of planning work, meaning K1, K2 and K5, and Dutch you would put at fluent for K6. Your background states neither.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| D · Organization | Duinvaart Cold Chain, Rotterdam; operates a refrigerated fleet | `[grounded]` JD header. Not independently confirmed (see DR1) |
| D · Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` JD |
| D · Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| D · Scope read | Single-analyst remit with three named outputs. Reporting line, team size and decision rights are not stated | `[inferred]` from the JD's silence on all three |
| D · Market calibration | Not established. The role-family sweep did not run, and the posting gives no salary to compare | `[grounded]` the Research tier line below |
| D · Unknowns | Salary; who the role reports to; whether route changes are advised or decided; what "Dutch a plus" means in day-to-day work | `[grounded]` JD silence |
| D · Contradictions | None found within the JD. Cross-check against the careers page not possible | `[grounded]` JD; search refused |
| K · Organization | Kroonhaven Foods, Utrecht; chilled ready-meals range | `[grounded]` JD header. Not independently confirmed (see KR1) |
| K · Mandate | Own the 13-week supply plan, balance production capacity against the forecast, run the weekly S&OP meeting | `[grounded]` JD |
| K · Working pattern | On-site in Utrecht | `[grounded]` JD |
| K · Scope read | An ownership role: the plan and the meeting are both yours, with no senior planner named above you | `[inferred]` from "own" and "run" in the JD |
| K · Market calibration | Not established. The sweep did not run, and no salary is given | `[grounded]` the Research tier line below |
| K · Unknowns | Salary; team around the planner; whether training in the planning system is offered; how "fluent Dutch" is tested | `[grounded]` JD silence |
| K · Contradictions | None found within the JD. Cross-check not possible | `[grounded]` JD; search refused |

## Evidence map

### Duinvaart

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You state 4 years as an operations analyst at a parcel carrier in Amsterdam. That exceeds the stated minimum, but nothing has been inspected yet | `[grounded]` your background statement | An employment record or CV line would raise it to high |
| D2 | Strong SQL | must_have | direct | medium | none | You use SQL daily. No query sample or artifact has been inspected | `[grounded]` your statement | A sanitized query or schema description would raise it to high |
| D3 | Power BI or Tableau | must_have | direct | medium | none | You use Power BI daily, including the on-time delivery dashboard your depot managers use | `[grounded]` your statement | A sanitized screenshot of the dashboard would raise it to high |
| D4 | Track on-time delivery | must_have | direct | medium | none | The on-time delivery dashboard is the same work; the posting asks you to do it for a different fleet | `[grounded]` your statement | Same artifact as D3 |
| D5 | Track temperature compliance across a refrigerated fleet | must_have | adjacent | low | transferability | You describe no temperature, food-safety or cold-chain data work. The bridge is tracking a service-level metric across depots. The limit is that temperature data and its compliance rules are a different kind of data from parcel delivery times. Strengthener: any compliance or exception-monitoring work | `[inferred]` bridge from the delivery-tracking work you described; `[generic]` that temperature compliance has its own rules, which this role will expect you to learn | See G1 |
| D6 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review, and depot managers use your dashboard | `[grounded]` your statement | Same artifacts as D3 |
| D7 | Dutch a plus | preferred | direct | medium | none | Your Dutch is conversational. The posting names no level, so the claim stays "conversational" wherever it is used | `[grounded]` your statement and the JD | None; never say "fluent" |
| D8 | Hybrid, three days a week in the Rotterdam office (a schedule and location term) | hard_gate | unclear | none | hard_gate | You have not said whether this schedule works from where you live. Your constraints were not given | `[grounded]` JD term; your silence | See G2 |

### Kroonhaven

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You have not worked in planning. This is an experience requirement, so it is graded on fit and not treated as a gate | `[grounded]` your statement | Closure path in P1 |
| K2 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No planning ownership in your background, and no FMCG production-capacity work | `[grounded]` your statement | Closure path in P1 |
| K3 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | The bridge is that you ran a weekly route-performance review for depot managers. The limit is that an S&OP meeting reconciles demand, supply and finance, which that review did not | `[grounded]` your statement for the review; `[generic]` for what an S&OP meeting reconciles | Name the limit wherever the bridge is used |
| K4 | Advanced Excel | must_have | unclear | low | discovery | Your SQL and Power BI use suggests spreadsheet fluency, but you have not described Excel work, and "advanced" is not defined | `[inferred]` from the tools you named | Ask only if the decision changes (see G5) |
| K5 | SAP IBP or a similar planning system | must_have | absent | none | capability | You named no planning system. Power BI is a reporting tool, not a planning system | `[grounded]` your statement | Closure path in P1 |
| K6 | Fluent Dutch | must_have | adjacent | medium | transferability | Your Dutch is conversational, not fluent. Running a weekly meeting in Dutch is the use the JD implies | `[grounded]` your statement and the JD | Do not claim fluency |
| K7 | On-site in Utrecht (a schedule and location term) | hard_gate | unclear | none | hard_gate | You have not said whether on-site work in Utrecht is workable. Your constraints were not given | `[grounded]` JD term; your silence | See G2 |

K7 is the on-site Utrecht row, which the snapshot calls K8. To keep one ID per row, I use **K8** in the snapshot and the gap queue and correct the table here: the on-site term is K8, and there is no K7 in this map.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Temperature compliance (D5, must_have) | transferability | Delivery and route-performance tracking, but nothing on temperature or food-safety data | It is the one `must_have` row at `adjacent` in a role that otherwise matches your evidence | Any exception or compliance monitoring; SLA breach reporting; handling time-sensitive or food or pharma parcels; building alerts on a threshold | A sanitized dashboard page showing exception tracking | `[inferred]` bridge from your delivery tracking; `[generic]` that the interviewer is likely to probe the gap |
| G2 | Schedule and location (D8 and K8, hard_gate) | hard_gate | Both postings tie you to an office on set days | A gate you cannot meet cannot be fixed by wording | Not applicable; this is a term, not experience | Not applicable | `[grounded]` the JD terms |
| G3 | Planning experience (K1, K2, K5, must_have) | capability | No planning work and no planning system in your background | Three must-haves with no direct or adjacent evidence | Not applicable. This is a closure path, not a recall prompt | Not applicable | `[grounded]` your statement |
| G4 | S&OP meeting (K3, must_have) | transferability | You ran a weekly review, but not one that reconciles demand and supply | The only must-have in this role with a credible bridge | Any recurring meeting where you reconciled two functions' numbers | The agenda or output of the review | `[inferred]` bridge; `[generic]` S&OP scope |
| G5 | Excel and Dutch (K4, K6, must_have) | discovery | Excel level not described; Dutch below the posted level | Both are real but neither can offset G3 | Large-scale spreadsheet models; meetings you ran in Dutch | A model description, if you wish | `[grounded]` your statement and JD silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. This check could not run, so none of these is ranked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| DR2 | Salary withheld | unknown | — | (no salary stated in the posting) | The figure may sit below the market for the scope, or the company may simply not publish it | `[generic]` pattern. The band could not be checked | What salary range is budgeted for this post? | unresolved |
| DR3 | Influence over route changes unspecified | unknown | — | "work with depot managers on route changes" | The role may advise route changes without deciding them | `[inferred]` from the JD's verb "work with" and its silence on decision rights | Do route changes need this role's sign-off, or does it only recommend them? | unresolved |
| DR4 | Concrete outputs named | positive_signal | — | "build weekly dashboards in Power BI" | The role's deliverables are specific and measurable | `[grounded]` JD | Who consumes the weekly dashboards today? | noted |
| KR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. This check could not run, so none of these is ranked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| KR2 | Salary withheld | unknown | — | (no salary stated in the posting) | The figure may be below the market for an ownership role, or may simply not be published | `[generic]` pattern. The band could not be checked | What salary range is budgeted for this post? | unresolved |
| KR3 | Deliverables clearly defined | positive_signal | — | "Own the 13-week supply plan" | Success in the role is measurable | `[grounded]` JD | Who owns the plan today? | noted |

DR1 and KR1 each cap a `go` at `conditional_go` until the posting is verified. Each is cleared by a link to the live posting on the company's own careers page.

## Application plan

All rows are proposed, and none is finalized without your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Duinvaart CV edit: lead with "Ran the weekly route-performance review; SQL and Power BI daily, including the on-time delivery dashboard depot managers use." The wording uses only your own statements | See D3, D4, D6 | `[grounded]` your background statement | resume_edits_pending_approval |
| A1 | Confirm the posting is live on Duinvaart's own careers page before investing effort | See DR1 | `[grounded]` DR1 | pending your approval |
| A2 | Frame the temperature bridge as "delivery and exception tracking; I would be learning temperature compliance", never as cold-chain experience | See D5 | `[inferred]` bridge | pending your approval |
| A3 | Say "conversational Dutch", never "fluent" | See D7, K6 | `[grounded]` your statement | pending your approval |
| Q1 | Ask DR2 and DR3 verbatim in the interview | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P1 | Kroonhaven: do not invest in this application. The planning requirements are experience requirements with no evidence behind them. Roles that use your analytics and route-review evidence directly are a better use of your time | See K1, K2, K5 | `[generic]` pattern; the role-family sweep did not run | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Four searches were sent and all four were refused, so no page was read. Two were for each company's site, and DR1 and KR1 stay unresolved. They would have confirmed each employer exists and the posting is live |
| 2. Role-family sweep | unavailable | The same permission refusal covered the two salary and scope searches. Market calibration is not established for either role |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can save this assessment as a `tuesday-dossier.md` file you can reuse, if you would like one.

## Upgrade menu

- Search permission, so the checks in targets 1 and 2 can run → DR1 and KR1 close or stay open on evidence, and a market band appears for the salary rows.
- A sanitized dashboard screenshot or query sample → D2, D3 and D4 to `high`.
- Any exception or compliance monitoring you have done → D5's bridge strengthens.
- A pay floor and your other non-negotiables → DR2 and KR2 become checkable, and the hard-gate lines stop carrying "candidate constraints not given".
- A link to each live posting on the company's own careers page → DR1 and KR1.

## Questions

G1 — Have you handled anything temperature-sensitive, food- or pharma-related, or any compliance or exception monitoring at the carrier? What did you own, and what did the output look like?
G2 — Is three office days a week in Rotterdam workable for you?
DR2 — Do you have a pay floor or any other non-negotiable I should check both roles against?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.