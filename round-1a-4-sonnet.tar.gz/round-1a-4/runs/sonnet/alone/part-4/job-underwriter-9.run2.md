**Yes, that's normal: a request for your bank details, PPS number and passport scan after a written offer is routine onboarding. Status: `conditional_go`.** Your "never hand those over" rule fits requests that come before an offer or from a sender you can't place. This request came after two in-person interviews and an offer on the employer's own email domain, as far as I can tell. I couldn't verify that domain, because my web searches were refused (see Evidence status).

## Decision snapshot

**Fit ledger.**

- `hard_gate`: unclear: R1 (Right to work in Ireland), R2 (Hybrid, two days a week in Limerick), R3 (Salary €38,000–€42,000)
- `must_have`: direct: R4, R6, R7, R9, R10 · adjacent: R8 (Monthly payroll, 240 staff) · unclear: R5 (Irish PAYE, PRSI, USC)
- `important`: unclear: R12 (Staff payroll queries) · absent: R11 (Pension changes)

R8 is a credible bridge with its limit named; R5 is probably `direct` and one confirmation away; R11 is the one real gap, with a closure path.

**Opportunity ledger.** The offer matches the ad, and two in-person interviews sit behind it (RR3). The written terms haven't arrived (RR1), and payroll cover and pension support are unspecified (RR2, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Right to work in Ireland), R2 (Hybrid, two days a week in Limerick), R3 (Salary €38,000–€42,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the contract or written terms confirm pay, hybrid pattern and pension scheme (R2, R3, RR1); (2) you confirm R5; (3) you tell them plainly that you haven't run pension changes yourself and ask how that is supported (R11, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff. I did not check this independently. | `[grounded]` JD header and offer; not independently checked |
| Mandate | Monthly payroll for 240 staff, starters, leavers and pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in the Limerick office, reporting to Declan Garvagh, Finance Manager | `[grounded]` offer |
| Pay | €38,000–€42,000 advertised; €40,000 offered, inside the advertised range | `[grounded]` JD and offer |
| Scope read | Normal breadth for one payroll owner. It is about 2.7 times your current headcount, on a monthly rather than fortnightly cycle. | `[inferred]` from the JD's duties against your hotel-group scope |
| Market calibration | Not done. The salary search was refused, and market figures from memory aren't a source. | `[generic]` none available |
| Unknowns | Payroll software, team and cover, pension scheme(s), contract terms, probation, start date | none |
| Contradictions | None between the JD and the offer (title, pay, location, hybrid pattern). The careers page was not checked. | `[grounded]` pasted JD against pasted offer |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Right to work in Ireland (the offer's right-to-work check) | hard_gate | unclear | none | hard_gate | Not stated by you. The offer's passport check implies the employer will verify it. | `[grounded]` offer text; your status not given | confirm in the closing questions |
| R2 | Hybrid, two days a week in Limerick | hard_gate | unclear | none | hard_gate | Your constraints weren't given, so I can't say whether the pattern suits you. | `[grounded]` JD and offer; constraints not given | closing question |
| R3 | Salary €38,000–€42,000 (offered €40,000) | hard_gate | unclear | none | hard_gate | Same reason: your floor wasn't given. | `[grounded]` JD and offer; floor not given | closing question |
| R4 | 2+ years running payroll | must_have | direct | medium | none | You describe 3 years of fortnightly payroll for 90 staff. Your own account, no artifact yet. | `[grounded]` your account | none |
| R5 | Irish PAYE, PRSI and USC knowledge | must_have | unclear | low | discovery | You didn't say which tax jurisdiction the hotel payroll ran under. It is probably Irish, but that is an inference. | `[inferred]` from the Irish setting; `[grounded]` silence | G1 |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP. Your account only. | `[grounded]` your account | none |
| R7 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. The certificate is inspectable but I haven't seen it. | `[grounded]` your account | none |
| R8 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | Carries over: end-to-end payroll running. Limit: you ran 90 staff on a fortnightly cycle, so the monthly cycle and the larger headcount are untested. | `[grounded]` your account; `[inferred]` adjacency | G2 |
| R9 | Process starters and leavers | must_have | direct | medium | none | Stated directly. | `[grounded]` your account | none |
| R10 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Stated directly. | `[grounded]` your account | none |
| R11 | Pension changes | important | absent | none | capability | You haven't done these; your manager handled them. Closure path in G3. | `[grounded]` your statement | G3 |
| R12 | Answer staff payroll queries | important | unclear | low | discovery | Not stated. It usually comes with running payroll, but that is a pattern, not evidence. | `[generic]` role-family pattern; `[grounded]` silence | none; low impact |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI, USC (R5, must_have) | discovery | Payroll experience is stated, but not the tax regime | A must-have, and a one-line answer moves it to `direct` | Operating Irish payroll, PAYE returns, USC and PRSI classes, statutory deductions | A payslip layout or procedure note with pay figures removed | `[grounded]` CV silence on jurisdiction |
| G2 | Monthly payroll at 240 staff (R8, must_have) | transferability | End-to-end payroll at 90 staff, fortnightly | The probable interview probe on scale | Peak-period runs, multi-site or multi-department payroll, monthly runs at any previous job | A description of your run process, with names removed | `[inferred]` bridge; `[generic]` that scale is a common probe |
| G3 | Pension changes (R11, important) | capability | You have not done this work | The role names it. Naming it early lets you ask for support rather than being found out. | Setting up or adjusting pension deductions, joiners enrolled into a scheme, or reconciling pension remittances to payroll | Any pension-related procedure note | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Written terms not yet seen | unknown | — | "starting on a date we agree once your notice period ends" | The offer gives role, pay, reporting line and location pattern, but not probation, leave, pension or notice terms. A contract may follow acceptance. | `[grounded]` offer text silent on them | Can you send the contract or written terms, including probation, pension scheme and notice period, before the five-working-day deadline? | unresolved |
| RR2 | Pension changes in the duties; support unspecified | unknown | — | "process starters, leavers and pension changes" | You may be expected to run these from the start. | `[inferred]` from the JD against your R11 gap | Who supports pension changes in my first months, and which pension scheme(s) run through payroll? | unresolved |
| RR3 | Role, pay and reporting line stated in a written offer after two in-person interviews | positive_signal | — | "€40,000 a year, reporting to Declan Garvagh, Finance Manager" | The role is real and defined, and the pay sits inside the advertised range. | `[grounded]` your account of the interviews, the offer and the JD | What would success look like in the first 90 days? | noted |
| RR4 | Payroll cover and system unspecified | unknown | — | "Run the monthly payroll for our 240 staff" | You may be the only payroll owner, with no named cover for leave. | `[inferred]` from the JD's silence on team and system | Which payroll system do you use, and who covers payroll when I'm away? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask for the written terms and RR2's, RR4's and RR1's questions before accepting. If the answers arrive late, ask for a short extension to the five working days. | see RR1, RR2, RR4 | `[grounded]` register | pending your approval |
| A2 | Enter bank, PPS and passport details only in the employer's own portal. Get the address from the employer's own website, not from a link you didn't expect. Stop if anything asks you to pay or enter card details. | Employers do need all three after an offer, for salary, Revenue and right-to-work. Safe handling is a habit worth keeping. | `[generic]` onboarding pattern; this is advice, not a finding about this employer | pending your approval |
| A3 | Ask which ID they accept, and how the passport scan is stored and for how long. Take the original on day one as asked. | A reasonable question, and as the future payroll owner you'll handle the same data. | `[generic]` onboarding pattern | pending your approval |
| A4 | Say plainly that you haven't run pension changes yourself and ask what training and scheme documentation you'll get. Do not describe the hotel work as pension experience. | see R11, G3 | `[grounded]` R11 row | pending your approval |

Everything in this plan, in the table and the prose, is proposed. Nothing is final until you approve it.

## Evidence status

Verified: none yet. Every claim about your background is your own account, not yet confirmed against documents.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches ("Marrowgate Housing Limerick housing association", "Marrowgate Housing careers Payroll Administrator Limerick") were refused. They would have moved the organization and contradictions rows. |
| 2. Role-family sweep | unavailable | One search ("payroll administrator salary Ireland 2026 housing association Limerick") was refused. It would have moved market calibration and the R3 comparison. |
| 3. Hiring manager's public footprint | unavailable | One search (the manager's name with the finance manager title and the employer) was refused. It would have moved the scope read and the positioning. |

I'd like to offer a full dossier of this assessment as a saved file, if that would be useful to you.

## Upgrade menu

- A link to Marrowgate's own website or careers page, which I can read as an input, would settle the contradictions row and give you the portal address to compare against.
- Web search permission would let me run the three declined targets, which move the market calibration and R3.
- A deeper research pass (up to 5 more searches and 2 more fetches) would cover the employer's recent history. Say the word if you want it.
- Your payroll certificate or a de-identified process note would raise R4, R7 and R8 toward `high`.
- Your constraints (pay floor, notice period, hybrid acceptability, work status) would close R1, R2 and R3.

## Questions

1. **R1–R3:** Do you have the right to work in Ireland, and are €40,000 and two office days a week in Limerick acceptable to you, with your notice period leaving a workable start date?
2. **G1 / R5:** Was the hotel group's payroll run under Irish PAYE, PRSI and USC, and did you apply them yourself?
3. **G3 / R11:** Have you touched pensions in payroll at all, such as setting up deductions or enrolling joiners, even if your manager owned the changes?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.