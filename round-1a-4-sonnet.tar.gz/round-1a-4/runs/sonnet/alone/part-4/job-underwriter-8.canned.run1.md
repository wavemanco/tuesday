I'll read the skill's reference files first, then give you the full assessment.
Checking whether Velloway Logistics can be found online, then I'll write up the full assessment.
# Job Underwriting Assessment: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No, don't go ahead. Don't send the IBAN, PPS number or passport photo, don't pay the €349, and don't lodge the cheque. RR1, RR2, RR3 and RR4 are each a demand that should not come before a verified offer. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (pay of at least €30,000 a year)
- `must_have`: direct: R2, R4 · adjacent: R3 (attention to detail)
- `important`: unclear: R5 (a quiet place to work)

R2, R4 and R3 — your Zendesk and Excel background matches what the posting lists; R1 — the posting's own figures don't settle your floor.

**Opportunity ledger.** The posting and the chat ask you to pay for equipment (RR1), hand over ID and bank details before any written offer (RR2), deposit a cheque and send most of it on (RR3), and be hired wholly by chat (RR4). The employer could not be established online (RR5), and the contact address and the pay claim are further signals (RR6, RR7).

- **Hard gates:** none failed; unconfirmed: R1 (pay of at least €30,000 a year)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`)
- **What would change this:** a written offer verified with the employer through contact details you find on its own website, with no payment, cheque or pre-offer ID demand, an interview held live, and a stated rate and hours that meet your €30,000 floor.

Your IBAN and passport aren't needed for any part of this assessment, so I haven't used or repeated them. Please don't paste them into the chat either.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics: a search for the name returned no results, so I can't confirm it exists as the posting describes | `[grounded]` search "Velloway Logistics", no results |
| Role | Remote Order Processing Coordinator, home-based, "set your own hours, 15–30 a week" | `[grounded]` posting |
| Pay as stated | "Earn up to €26 an hour plus commission on every order you process." At €26 an hour the posting's own hours come to about €390 to €780 a week, or roughly €20,280 to €40,560 over 52 weeks. The figure is a ceiling, and the commission is unspecified | `[grounded]` posting figures; `[inferred]` annualised arithmetic |
| Hiring process | Telegram only, "no calls or video interviews" | `[grounded]` posting |
| Market calibration | A 2026 Irish pay guide puts salaried order-processing and customer-operations coordinators at a median base of €31,200 a year (interquartile range €28,400 to €34,100). That is about €15 an hour at 40 hours a week, so "up to €26" with "no experience needed" sits well above it. This is a pattern for the role family, not this employer's offer | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide (salaried roles only); `[inferred]` hourly conversion |
| Unknowns | Who the employer is, the actual rate, the guaranteed hours, the commission terms, who "our equipment partner" is | `[grounded]` posting and chat silent |
| Contradictions | A posting that says no experience is needed, then a "chat interview" described as a pass, then a cheque larger than any starting wage | `[grounded]` posting and messages |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your stated floor. Fit is `unclear` because "up to €26" with 15–30 hours leaves actual pay unstated: at €26 you'd need about 22 hours a week to reach €30,000, and at 15 hours even the top rate gives about €20,280 | `[grounded]` your constraint and the posting; `[inferred]` arithmetic | See RR7; no written rate or guaranteed hours exist to check |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel | `[grounded]` your statement, no artifact seen | none |
| R3 | Strong attention to detail | must_have | adjacent | medium | presentation | About 60 Zendesk tickets a day and a weekly tracker are relevant work, but you've not described accuracy outcomes | `[grounded]` your statement | Not needed for this posting |
| R4 | Good written English | must_have | direct | medium | none | Written ticket handling at about 60 a day, and your messages here | `[grounded]` your statement | none |
| R5 | A quiet place to work | important | unclear | none | discovery | You haven't said | `[grounded]` silence | Yours to judge; it changes nothing here |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Real pay and hours (R1, hard_gate) | hard_gate | "Up to €26" and 15–30 hours, with no written contract or rate | Your €30,000 floor can't be checked, and no answer fixes the demands in RR1 to RR4 | Not applicable; this is the employer's term | A written offer or contract from a verified employer naming rate, guaranteed hours and commission | `[grounded]` posting; `[generic]` that offers from established employers state these in writing |
| G2 | Quiet workspace (R5, important) | discovery | Not stated | Minor; does not affect the decision | Not applicable | none | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Asked to pay for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A payment demanded of a new hire before they've started is a sign of a request that is very likely a scam | `[generic]` known pattern for requests like this; not a finding about any named party | Does your company require new starters to pay for their own equipment, and can you confirm that in writing from an address on your own website? | confirmed |
| RR2 | Bank, tax and ID details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | These details were asked for at the screening stage, ahead of any written offer naming role and pay | `[generic]` payroll checks normally follow a written offer; this request came before one | See RR1; the question and route are the same | confirmed |
| RR3 | Cheque to lodge, most of it to be sent on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque that is lodged and then partly sent on can later be returned unpaid, leaving the money you sent on as your loss | `[generic]` known pattern for requests like this | See RR1 | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | No live interview or written offer exists, so nobody who could be checked has made one | `[grounded]` posting and messages | See RR1 | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer; none of these is ranked as likely | `[generic]` pattern, not a claim about this employer | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Contact address not tied to an employer site | risk_signal | medium | "Any problems, email velloway.hr@postmail.example" | The address is on a mail-service domain rather than one I could connect to an employer website, so the messages may not come from who they name | `[inferred]` from the address and the failed search in RR5 | Can you confirm from your own company domain that this address is yours? | unresolved |
| RR7 | Advertised pay far above the role-family norm | risk_signal | medium | "Earn up to €26 an hour plus commission on every order you process" | "Up to" is a ceiling and the commission is unspecified, so real pay may be well under the figure; severity stays medium because the posting's figure is a maximum | `[inferred]` from the posting against the `[generic]` band in role reality | What is the guaranteed hourly rate, and how is commission calculated? | unresolved |

No positive signal was found.

Hold each of these until you have checked it with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed. This request is very likely a scam, and this posting is very likely one too. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Send nothing: no IBAN, PPS number, passport photo, payment or cheque deposit | See RR1 to RR3 | `[grounded]` register | pending your approval |
| P2 | Stop replying in the chat until you've checked who sent it | See RR4, RR6 | `[grounded]` register | pending your approval |
| P3 | Report the posting to the jobs site where you found it | A posting like this can reach other applicants | `[generic]` how job boards handle reports | pending your approval |
| P4 | Put your effort into other openings built on your Zendesk and Excel experience, aimed at your €30,000 floor | See R1, R2, R4 | `[grounded]` your background and constraint | pending your approval |

No CV edits are proposed.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics", which returned no results, so the employer is not established (RR5, role reality's organization row) |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator job Ireland hourly pay typical", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide); it fed the market calibration row and RR7 |
| 3. Hiring manager's public footprint | n/a | No hiring manager's name was given, only a chat handle, so there was no query to form |

Offer beyond this assessment: a short list of customer-operations role titles to search for, with what from your Zendesk and Excel work to lead with, built only from your own statements and finalized only on your approval.

I can also save this as `tuesday-dossier.md` if you'd like a copy to keep.

## Upgrade menu

- The jobs site name and a link to the posting → RR5 can be checked against the posting itself.
- A written offer or contract from a verified employer → R1 and G1 close.
- A hiring manager's name from the employer's own site → role reality's scope read.
- A deeper research pass on this employer (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

RR2 — While answering their chat questions, did you share any personal or financial details (address, phone, employment history, account details)?

RR5 — Which jobs site was the posting on, and can you link it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.