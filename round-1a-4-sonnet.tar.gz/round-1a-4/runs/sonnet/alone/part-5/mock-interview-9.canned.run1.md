I'm reading the last of the skill's reference files and loading the search tool. After that I'll run light research on the district, then build your pack.
I've saved your prep pack as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-5/rooms/case-9-canned-e147f1aa/Halvering-Elementary_fourth-grade-teacher_interview_pack.md`.

You don't need to share your SSN for prep. I haven't used it, and I'd keep it off any resume or application document.

I built the pack for the panel as the invite describes it, with the principal and two fourth-grade teammates. I didn't have the posting, so I used a typical fourth-grade posting I found, and every row drawn from it is marked `[inferred]`. The pack has 20 questions, a line-by-line fit snapshot and a read on the principal's public background. It also has six reverse questions and a list of claims it won't coach.

- **Your license:** it meets the invite's one hard requirement. Your resume gives an active Illinois license with an elementary endorsement covering grades 1–6, so nothing is asked of you there.
- **Biggest rehearsal (question A1):** expect "you've taught third grade, and this is a fourth-grade role. What makes you ready?" The pack has you concede plainly that you haven't taught fourth grade, keep to your six years in third grade, and add one first step you'd take.
- **Second probe (A2):** your resume says you led your grade level's move to a new curriculum and that you've never been a team lead. The panel can see both on one page, so rehearse them together.
- **District focus:** the district says its panels ask about reading instruction, classroom routines and families. I turned its three published beliefs into questions in the Values bank. Its new reading curriculum for grades 3–5 (from fall 2027) is one case question and two reverse questions.
- **Gaps with answer slots:** your resume doesn't say which subjects you taught or whether you've used assessment data. It also doesn't show classroom routines or conversations with families beyond your weekly email. Those rows are instructions to answer in your own words, or to say plainly it wasn't yours. I didn't fill them in for you.

Say the word and I'll play the panel on A1, the fourth-grade question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Do you have the posting's text? Pasting it would turn the `[inferred]` rows into rows built on the real posting.
2. Did HR or the principal mention any focus areas, or ask you to bring something such as a sample lesson? That would add a build section for it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering-Elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Orrinsford Community School District. One 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given).

Built without the posting itself. The fit snapshot uses a typical fourth-grade posting as a stand-in, and every row drawn from it is marked `[inferred]`.

## Panel at a glance

| Member | Role | Starting persona prior | Source |
|---|---|---|---|
| Dolores Vantongeren | Principal, Halvering Elementary School | Hiring manager: Case/Strategist and Skeptic | Your invite; ilprincipalsforum.example speaker page |
| Fourth-grade team member 1 | Fourth-grade team (name not given) | Peer: Peer Evaluator and Data-Driven Prober | Your invite |
| Fourth-grade team member 2 | Fourth-grade team (name not given) | Peer: Peer Evaluator and Data-Driven Prober | Your invite |

## How to use this pack

Personas describe how a question arrives. Types describe what it scores.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether a claim on your resume survives scrutiny, and what was actually yours |
| JD | The job's stated responsibilities and qualifications, gaps included |
| CO | Whether you know the district's current direction |
| CASE | How you structure a live problem from the job |

Guidance is scaffolding, not a script. Question IDs run by persona (A to E, then G, because F is used by the fit rows). An answer slot is an instruction for the interview, not a question for this conversation: say your own answer, or say plainly that the practice was not yours.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your CV states the license, the endorsement and an active status; it is a CV line with nothing inspected behind it here, and checking it is yours. State it as a fact in the quote's own terms. The endorsement as you state it runs grades 1–6, which includes fourth grade. Nothing is asked of you here, and the license number is used nowhere in this pack |
| F2 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past. Your third-grade years sit on F3, at their own scope |
| F3 | "experience in grades 3 to 5 preferred" — typical posting, K12 Jobs Board (not Halvering's own) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Grade three falls inside the posting's three-to-five range. Lead with the sentence in its own terms. It is a CV line with nothing inspected behind it, so expect a probe on it; a "preferred" line in a typical posting is not a gate |
| F4 | "plan and teach reading, writing, math, science and social studies" — typical posting, K12 Jobs Board | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | The sentence gives the grade and the school, not which subjects. Answer slot: a posting like this makes a probe on subjects likely. Say which of these you taught, in your own words; if you did not teach one, or someone else did, say so plainly and stay with the years you did teach |
| F5 | "differentiate instruction using assessment data" — typical posting, K12 Jobs Board | none given | none | [inferred] | discovery | Your material is silent here. Answer slot: if you used assessment results to change what or how you taught, say what, in your own words; if you did not, or it was not yours to do, say so plainly and say what you would look at first |
| F6 | "keep clear classroom routines" — typical posting, K12 Jobs Board | none given | none | [inferred] | discovery | Your material is silent here. Answer slot: if you run a routine in your room, say which and how it works, in your own words; if a routine was set by your school, or you have none to describe, say so plainly and say how you would set one up |
| F7 | "communicate regularly with families" — typical posting, K12 Jobs Board | "I write a weekly email to families." — your CV | medium | [inferred] | none | Lead with the sentence in its own terms: you write it, every week. It is a CV line with nothing inspected behind it; expect a probe on what the email says |
| F8 | "work with the grade-level team" — typical posting, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead." — your CV | medium | [inferred] | none | Say the first sentence at its own scope, and hold the second beside it: you led a grade level's move, and you have not been a team lead. The panel can see both on one page, so rehearse them together (A2) rather than letting either surprise you |
| F9 | "Families Are Partners: each teacher speaks with every family each term." — Orrinsford Mission and Beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | Your material says the weekly email, and the words stay there: "I write a weekly email to families." Answer slot: expect a probe on what goes in the email and who reads it. Describe a typical one as it actually is, in your own words; if you do not know who reads it, say so plainly and stay with the fact that you write it every week |
| F10 | "Every Child a Reader: no student leaves third grade without a reading plan." — Orrinsford Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | transferability | Two sentences carry reading work at their own scope: a grade level's curriculum move and an after-school club. Say them as written. Answer slot for the move: say which parts were yours to decide and which belonged to the grade level; if the decisions were shared, say so plainly. Answer slot for the club: describe one session as it actually ran |
| F11 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — Orrinsford Mission and Beliefs page | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if an assessment result ever changed what you did next with a student or a class, say what, in your own words; if none did, say so plainly and say how you would use one |

## Panel personas

| Persona | How it shows up here | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A) | Quiet, persistent probing of the fourth-grade gap and the team-lead gap | High. The principal's hiring-manager prior includes the Skeptic, and F2 and F8 each hold a negative you stated. The invite's own title makes F2 the question | Rehearse A1 until it is boring: hold the sentence A1's Provenance quotes, concede the plain fact, give a plan and not a past |
| Peer Evaluator (bank B) | Two teammates asking about seams, disagreement and credit | High. Two of three panelists are teammates, and the peer prior is Peer Evaluator | Reciprocity: what you would ask the team and what your quoted work brings them; propose principles for seams rather than pretending to know the seam |
| Case/Strategist (bank C) | Live problems from the principal's side and the district's literacy plan | Medium. The hiring-manager prior includes it; the district's hiring page names reading instruction and classroom routines as panel topics | Clarify, set the objective, choose an approach, say how you would check it, name a risk; think aloud |
| Data-Driven Prober (bank D) | Walk-throughs of the reading curriculum move and the reading club | Medium. The peer prior includes it, and your resume names two concrete things to walk through | Say plainly what you do and do not know about how something was measured; describe what actually ran |
| Values/Behavioral (bank E) | Questions keyed to the district's three published beliefs | Medium. The district page says the beliefs guide every hire; no separate values round was detected, so this lives inside the one panel | Map a quoted sentence to each belief where one carries it; where none does, choose a real instance or say plainly that none comes to mind |
| Conversational (bank G) | The opening "walk me through" and a casual reading question | Medium-low. Every panel opens somewhere, and casual questions are still scored | A 90-second arc built only from your quoted sentences; your reason for the move is yours to state |
| Pressure | Time-boxed or devil's-advocate challenge | Low; no bank. Nothing in the loop sources points to it, but A1's hold-then-concede covers the one place it would land | Pause, restate, hold through two follow-ups, concede only what is true |

## Reading the interviewer

| Fact (public professional footprint) | Source | What it means for rehearsal |
|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | ilprincipalsforum.example speaker page | Reading instruction is her home ground; expect reading questions to go below the surface (D1 to D3, C1) |
| 2025 forum talk "Small Groups, Big Readers", on weekly reading conferences in grades 3 to 5 | ilprincipalsforum.example speaker page | Her talk's band includes the grade you teach and the grade you want. Your material states no small groups or conferences, so answer any such question from what actually happens in your room, and say plainly if it does not |

No shared jump is offered. Her public path runs from reading specialist to principal, and no row of your evidence carries a matching move on your side. The one overlap in the evidence is the grade band, which is F3's sentence: "Six years teaching third grade at a public elementary school in Joliet." The two teammates have no public footprint in your material, so their personas follow the peer prior.

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade, and this is a fourth-grade role. What makes you ready?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Hold the one sentence your material carries: "Six years teaching third grade at a public elementary school in Joliet." Concede the plain fact: "I haven't taught fourth grade." Then say one first step you would actually take, as a plan and not a past. Follow-up 1, what changes in fourth grade. Answer slot: if your own classroom shows you where fourth grade picks up, say what, in your own words; if it does not, say so plainly and say whom on the team you would ask first. Follow-up 2, why not someone who has taught it. Concede the fact again, return to the quoted sentence, and stop. Hold through both follow-ups without adding to it | F2 is the stated gap and F3 is the nearest evidence, so this question arrives in some form from any panelist. JD because it scores the role itself; it carries the deepest rehearsal because the objection is aimed where the material is thinnest |
| A2 | "You led your grade level's move to a new reading curriculum, but you haven't been a team lead. What was your part?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead." | Say the first sentence at its own scope. Concede the second plainly: "I haven't been a team lead." Do not use either to explain the other away. Answer slot: say which parts of the move were yours to decide and which belonged to the grade level; if the decisions were shared, or someone else's, say so plainly and return to the sentence. Hold through two follow-ups by returning to it, never by adding to it | F8 puts both statements on one page, so a careful reader will ask about the difference. EXP because it tests attribution, which probes exist to catch |
| A3 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade" "I've never been a team lead." | Choose one honestly and say it in a sentence. Your material already names two limits: "I've never taught fourth grade" and "I've never been a team lead." Pick the one you think matters more to this panel, then give one first step you would actually take, future and not past. Do not offer a weakness you do not have in order to sound modest | A standard Skeptic stem, made specific by F2 and F8. JD because it scores fit against the listed job |
| A4 | "Why this move, and why Halvering?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | The reason is yours and the pack writes none. Give your actual reason in a sentence or two. If it includes something about where you work now, say what you are moving toward, and keep every fact you give true | Motivation consistency is what a Skeptic scores; EXP because the answer rests on your own history, which F3 carries |
| A5 | "In your first month a fourth grader needs something you haven't taught before. What do you do?" | CASE | [generic] | A live problem that claims nothing about your past. Structure it aloud: find out what the student needs and what is already known; ask the teammate who has taught it; look at the fourth-grade materials; and, if it will take you a few days, tell the family so. Close with how you would check it worked | F2 turned into a decision, so the answer shows how you would close the gap rather than whether it exists. CASE because it is a live problem; [generic] because it is a pattern for the problem |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You'd be joining a team that already has its routines. Where will the seams be in your first month, and what happens when we disagree?" | JD | [generic] | No claim about your past is needed. Propose principles and do not pretend to know the seam: say you would ask the team first what is settled and what is open, and whose call each routine is. On a disagreement, restate their view, say what you would want to check together, and agree who decides. If you tell a disagreement story, it must be a real one; if none comes to mind, say so plainly and answer as a plan | A peer stem applied to F8's requirement. JD because it scores working with the team; [generic] because it is a pattern |
| B2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say the sentence at its own scope. Answer slot: say what the grade level's teachers did and what was yours, in your own words; if the work was yours alone, or credit never came up, say so plainly and answer as a principle. Use "we" for context and "I" only for what the sentence says you did | Peers price what a hire costs them; F8 is where credit could blur. EXP because it tests attribution |
| B3 | "What would you need from us in your first weeks?" | JD | [grounded] "I write a weekly email to families." "I've run the after-school reading club for the last two years." | Answer in two halves. What you would ask: what is settled, what is open, where plans and routines live. What you can offer, using only words your material carries: "I write a weekly email to families." and "I've run the after-school reading club for the last two years." Say them as things you do, not as proposals | The reciprocity move a Peer Evaluator rewards. JD because it scores fit with the team; F7 and F10 hold the two sentences |
| B4 | "Which of reading, writing, math, science and social studies have you taught, and where would you want a hand?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Anchor on the sentence. Answer slot: say which subjects you taught, in your own words; if you did not teach one, or someone else did, say so plainly and return to the years you did teach. Then name where you would want a hand, honestly | F4's requirement, asked collegially. The subject list is a typical posting's, not Halvering's, which is why this row is [inferred] |

### C. Case/Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader reads aloud smoothly but can't tell you what the passage was about. What do you do over the next two weeks?" | CASE | [generic] | Clarify first: what he reads, what he has been asked, what is already known about him. Then the objective, one approach, how you would check it, and one risk. Challenge one premise respectfully: smooth reading does not say why the meaning is lost. Think aloud and name your own limits | A live reading problem, which the principal's reading background and the district's reading focus make likely (section: Reading the interviewer). CASE because it scores structure; no claim about your past |
| C2 | "Our board adopted a literacy plan with a new grades 3–5 reading curriculum from fall 2027. When it arrives, what would you want to know first?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Ask before you answer: what the curriculum replaces, who chooses, what the team decides together. You may say the sentence as written. Answer slot: if that move shaped what you would ask first, say how, in your own words; if it did not, say so plainly and ask from the structure above | The plan is in the district's news item (Sources), three months old, and your resume has one reading-curriculum sentence. CO because it tests current knowledge; the sentence is quoted at its own scope |
| C3 | "Transitions between subjects are eating into reading time. What do you change?" | CASE | [inferred] | Structure it aloud: find out where the time goes, pick one routine to change, say how you would teach it to students, and say how you would check it held. Answer slot: if you have fixed a routine in your own room, say what you changed and what happened, in your own words; if you have not, say so plainly and answer from the structure | F6's requirement as a live problem. [inferred] because routines come from a typical posting, framed as typical for the role |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did your grade level know the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say the sentence at its own scope. Answer slot: if you looked at any assessment results to judge it, say which and what they showed, in your own words; if nothing was tracked, or it was not yours to track, say so plainly and return to the sentence. Say what you do not know about how well it worked; naming that limit beats having it found | F5 and F11 ask about assessment, and the one quoted sentence on curriculum is the natural place for the panel to look. EXP because it tests what happened |
| D2 | "Walk me through the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years." | Start from the sentence as written, then describe one session as it actually ran. If part of how it ran was set by someone else, or you do not know a detail, say so plainly. Stay with what you did | F10's second sentence is the thing a panel can ask to be walked through. EXP because it checks the claim against detail |
| D3 | "What does a strong reading lesson look like in your room?" | JD | [grounded] | Choose one lesson you actually taught and tell it step by step; the pack supplies none of its steps. If no specific lesson comes to mind, say so plainly, and describe what you aim for, labeled as what you aim for | The district's first published belief is about reading, and its hiring page names reading instruction as a panel topic (Sources). JD because it scores the core of the job |

### E. Values/Behavioral (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader is one of our three beliefs. Tell us about a time you helped a child become a stronger reader." | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." | Neither sentence is a story about one child, so choose a real instance: a named child or group, what you noticed, what you did, what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, in the sentences' own words | The belief is published, so the panel can ask for it by name. VAL because it scores behavior against a stated belief; F10 holds the two sentences |
| E2 | "Families Are Partners. How do you work with families?" | VAL | [grounded] "I write a weekly email to families." | Start from the sentence as written. Answer slot: describe a typical weekly email as it actually is, in your own words, and who reads it; if you do not know who reads it, say so plainly and stay with the fact that you write it every week | F9 and F7 carry this sentence. VAL because it ties your behavior to a published belief |
| E3 | "Teach for Tomorrow, Not for the Test. When has an assessment told you something that changed your teaching?" | VAL | [grounded] | Choose one real instance: what the assessment showed, what you changed next, what happened. The pack supplies none. If no such time comes to mind, say so plainly, then say how you would use an assessment in a fourth-grade lesson | F11 has no evidence behind it, so this question needs a real instance or an honest "none". VAL because it scores behavior against a published belief |

### G. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So — walk me through how you got to this point." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." | A 90-second arc built only from your sentences. First, "Six years teaching third grade at a public elementary school in Joliet." Then the curriculum move and the club, in the words above. Last, why fourth grade and why Halvering, in your own words; the pack does not know them | Every panel opens somewhere, and this is the casual question that is still scored. EXP because the arc rests on F3, F8 and F10 |
| G2 | "What are you reading with children right now?" | JD | [generic] | Answer from what you are actually reading. Name a title only if you really use it. If nothing comes to mind, say so plainly and say what you would put in front of fourth graders and why | A casual question aimed at the job's central topic. [generic] because the pack knows no titles |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Valid Illinois license with elementary endorsement | none; the invite states it as a condition, your material shows it met, and there is nothing to rehearse |
| F2 Fourth Grade Teacher position | A1, A3, A5, G1 |
| F3 Experience in grades 3 to 5 | A1, A4, G1 |
| F4 Plan and teach five subjects | B4 |
| F5 Differentiate using assessment data | D1, E3 |
| F6 Clear classroom routines | C3 |
| F7 Communicate regularly with families | E2, B3 |
| F8 Work with the grade-level team | A2, B1, B2, B3 |
| F9 Families Are Partners | E2 |
| F10 Every Child a Reader | E1, D2, D3, C1 |
| F11 Assessments inform teaching | E3, D1 |
| District literacy plan (current direction) | C2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You spent nine years as a reading specialist before becoming principal. What from that work shows up in how you support fourth-grade teachers?" | Ties to her own path, and invites the principal to talk about her home ground |
| 2 | "Your forum talk covered weekly reading conferences in grades 3 to 5. How does that show up in fourth grade here?" | Shows you read her published work. Ask it only if you have read the talk's description yourself, and do not say you attended |
| 3 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How will fourth-grade teachers be involved in preparing for it?" | Shows current knowledge of the district and asks about the team's role |
| 4 | "What could a new person on the fourth-grade team do in their first month that would genuinely help the team?" | The reciprocity question for the two teammates: it asks what you can give before what you need |
| 5 | "What does a strong first semester look like for a teacher new to fourth grade here?" | Meets F2 head-on and invites the panel to describe the support, which tells you what the ramp is |
| 6 | "The literacy plan includes a family reading night each term at every school. How do fourth-grade teachers take part?" | Connects to Families Are Partners without claiming anything about your past |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't taught fourth grade." No slot |
| Has been a team lead | Negative you stated, F8: "I've never been a team lead." | The plain acknowledgment: "I haven't been a team lead." Beside it, F8's other sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024" |
| Led the reading curriculum change for a school or the district | Inflated form of F8 and F10 | The sentence at its own scope. The limit is the pack's observation, not words for you: your material says the grade level's move, not a school or district adoption |
| Designed or built the reading club's program | Inflated form of F10 | "I've run the after-school reading club for the last two years." The pack's observation: your material says you ran it, not who built it |
| Speaks with every family each term | Inflated form of F9 | "I write a weekly email to families." The pack's observation: your material says the email, not conversations |
| Made sure every child had a reading plan | Inflated form of F10 | The two F10 sentences at their own scope. The pack's observation: your material says a curriculum move and a club, not plans for individual children |

## Sources

Provided documents: your interview invite and your resume text. No posting was provided.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | Fetched the Mission and Beliefs page; the three beliefs by name feed F9, F10, F11 and bank E |
| 2. `Orrinsford Community School District interview process teacher` | yes | A search result stating the hiring is one 45-minute building panel (principal and two grade-level teachers) with reading instruction, classroom routines and families as topics; it fixes the panel structure and the persona weights, and detects no separate values round |
| 3. `Orrinsford Community School District strategy` / recent news | yes | A search result on the board's August 2026 literacy plan; feeds C2 and reverse questions 3 and 6 |
| 4. `Dolores Vantongeren Halvering Elementary School` | yes | A search result on her tenure, her earlier reading-specialist work and a 2025 talk; feeds the interviewer read and reverse questions 1 and 2 |
| 5. representative `Fourth Grade Teacher` posting | yes | Fetched a typical posting; supplies F3 to F8, each marked `[inferred]` |

Searches sent, and what came back:

- `Orrinsford Community School District values mission` → https://orrinsfordschools.example/about/mission-and-beliefs
- `Orrinsford Community School District teacher interview process` → https://orrinsfordschools.example/careers/how-we-hire-teachers
- `Orrinsford Community School District strategic plan news` → https://orrinsfordschools.example/news/board-adopts-literacy-plan
- `Dolores Vantongeren principal Halvering Elementary School` → https://ilprincipalsforum.example/speakers/dolores-vantongeren
- `Fourth Grade Teacher Illinois elementary job posting requirements` → https://k12jobsboard.example/listings/fourth-grade-teacher

Fetches: the Mission and Beliefs page and the K12 Jobs Board posting above. The hiring, news and speaker pages were read only as search-result summaries, not fetched in full.

No `tuesday-dossier.md` was present.

## Upgrade menu

- The posting text, if you have it → F3 to F8 move from `[inferred]` to `[grounded]`, and the JD-tagged questions are retuned to the posting's own lines
- Anything HR or the principal said about focus areas or something to bring → a build section for any pre-declared deliverable, and corrected persona weights
- The names and roles of the two fourth-grade teammates → persona weights read from their own footprint and a reverse question tailored to each
- A printout or screenshot of your license record showing it registered and active → F1 moves from `medium` to `high`
- Your own words on the discovery and transferability rows, F4 to F6 and F9 to F11 → each becomes a quoted story, and the slots in those rows turn into mapped answers
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the district and the principal's talks, and sharper CO questions
- A `tuesday-dossier.md`, if you have one → the objection worth the deepest rehearsal and a prohibited-claims list would come from it instead of being inferred here
