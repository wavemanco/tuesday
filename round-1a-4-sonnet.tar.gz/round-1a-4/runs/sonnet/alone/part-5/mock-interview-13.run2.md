Web search was refused in this session, so the pack rests on your advert, your message and Hannah's message. I'm writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-5/rooms/case-13-denied-cd1f1c06/quillmoor-diagnostics_operations-coordinator_interview_pack.md`. I built it for Hannah's recruiter screen, using her four topics (pay, notice, hybrid, what's prompting a move) as the first bank.

Web search was refused in this session. Nothing about Quillmoor beyond your advert is in the pack, and the Sources section lists the four searches I tried.

Your notice period isn't in your message, so A3 is an instruction to give your actual notice period. Your reason for choosing Quillmoor isn't there either, so B3 is a slot for your own words.

Say the word and I'll play Hannah on B1 (the SAP question, which the pack names as your highest-ROI prep), or on any other question ID.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Candidate:** Sam
**Interviewer:** Hannah Lowther, Talent Partner. Recruiter screen.
**Format (Hannah's message):** Thursday 2pm, a 30-minute phone call. She rings the mobile number on your application. If anything changes, message her on LinkedIn.
**Her stated agenda:** your salary expectations, your notice period, how the hybrid pattern would work for you, and what is prompting a move. Then she tells you about the team and the next steps.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Question IDs run by persona (A1, A2, B1 and so on) so you can ask for a drill on any of them.

| Type | What it is testing |
|---|---|
| VAL | Whether past behaviour shows the company's published values. No bank carries this type here, because no source documents a values round. |
| EXP | Whether your own account of your work holds up, and what was actually you |
| JD | Whether you can do the listed job, gaps included, plus the job's terms: pay, notice, location |
| CO | What you know about the company's strategy. None here; see Sources. |
| CASE | A live problem from the role, reasoned aloud |

Guidance is scaffolding, not a script. Say it in your own words, and say only what you actually did.

The pack's highest-ROI rehearsal is **B1**, the ERP and SAP question. It is the one place your own message states an absence, and the advert names the topic.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and nothing in it mentions planning or QA. Words: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe likely. If your scheduling involved any of those teams, say which and how, in your own words; if it did not, say so plainly and stay with the depots |
| F2 | "track supplier deliveries and chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you chase suppliers when orders slip. A named action beats an adjective |
| F3 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | No gap, but it carries a figure with nothing inspected behind it, so expect the defend-the-number probes (C1, D2). Words stay at the quote: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year |
| F4 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: the advert names weekly dispatch reporting, so a probe is likely. If you have reported on deliveries or dispatch, say what and how often, in your own words; if you have not, say so plainly and stay with what you do when orders slip |
| F5 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | low | [grounded] | discovery | The quote says spreadsheet, not Excel, and does not show how you used it. Answer slot: if the spreadsheet was in Excel, say what it did, in your own words; if it was another tool, say so plainly and stay with the rebuild |
| F6 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap. The quote reaches the requirement in its own terms. Say it as written |
| F7 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system" — your message | none | [grounded] | capability | You stated the absence, and the advert marks ERP a plus, not a requirement. Words: "I've never used SAP; we run our own in-house stock system." Your material does not say what the in-house system covers or whether it would count as similar, so the pack does not claim it. Then how you would go about learning SAP, said as a plan and never as a past |
| F8 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your own statement of a figure is the strongest evidence it can have. The pack observes that the figure sits inside the advert's band. Words: "I'm hoping for £42,000." Nothing is added to it |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | The two halves of your sentence came together, so keep them together if asked. The pack adds no reasoning about the journey |
| F10 | "your notice period" — Hannah's message | none given | none | [grounded] | discovery | Nothing in your material states it. Logistics slot: give your actual notice period |
| F11 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | high | [grounded] | none | Your stated reason and your stated limit. Words stay at the quote. The pack adds no timeline, no earlier search and no other motive |

## Persona table

The weights rest on Hannah's own message, which sets this session: one 30-minute recruiter call with four named topics, then team and next steps. It says nothing about later rounds, so banks D to F are insurance for them, not a documented loop.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport Builder | Friendly, unstructured; pay, notice, hybrid and reasons for leaving arrive as casual questions | High. A recruiter screen leans this way, and Hannah's message lists four topics that are all logistics. Weight 5 | Short, pre-planned answers for the biography question and for each of her four topics. Treat the friendly questions as scored |
| B. Skeptic (light) | Quiet checks on the gaps: SAP, manufacturing, production schedules | Medium. The advert names ERP and a three-way production coordination, and F7 and F1 are where your material is thinnest. Weight 4 | Rehearse B1 until it is boring. Say the limit plainly, then the plan |
| C. Data-Driven Prober | Asks how a figure was counted | Medium-low. You have one figure, in F3. Recruiters rarely drill, but the number invites one question. Weight 3 | Know what you can say about how the figure was counted, and say plainly what you don't know |
| D. Pressure | Time-boxed "why you" challenge | Low. A short nudge at most on a recruiter call. Weight 2 | Hold your sentences, concede exactly what they don't cover, and don't add to them |
| E. Case / Strategist | A live problem from the role | Low for Hannah, likelier from a hiring manager later. Weight 2 | Clarify first, then structure, then say who you tell and what you record |
| F. Peer Evaluator | Seam-splitting with adjacent teams | Low and speculative: no source names a team interview. Weight 2, labelled generic | Propose principles for where teams meet, not a claim to know their seam |

No values bank is built: no source documents a values round for this loop, so none is detected.

## Question banks

### A. Conversational / Rapport Builder (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me about your current role and what you do day to day." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc with three beats, each one a clause your own sentences state: the four years and the role; scheduling deliveries for three depots and chasing suppliers when orders slip; the spreadsheet rebuild and the fall in discrepancies. Tell them in your own words and stop there. Answer slot: the advert's planning, warehouse and QA line makes a probe likely. If your scheduling involved any of those teams, say how; if it did not, say so plainly and stay with the depots | F1, F2, F3 and F6 all draw on this arc, so it is the opener to have smooth. EXP because it tests your own account of your work |
| A2 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot, filled by your own words, and nothing else: "I'm hoping for £42,000." If she asks what you earn now, you may decline and return to your own figure, with no figure from the past attached | F8 holds the figure. JD because it is a term of the listed job, and Hannah named it as her first topic |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period | F10 has no quote, so the guidance is an instruction. Hannah named this topic, so it is certain to arrive |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot, filled by your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on the pattern or the journey, your own words are the same sentence again | F9 holds the position. JD because the pattern is a term of the listed job |
| A5 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot, filled by your own words, quoted whole: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Say it the same way if she asks again. Nothing is added to it | F11 holds the reason. EXP because it is your account of your own situation, and recruiters check it for consistency |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "ERP experience, such as SAP, is a plus for us. Where are you on that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | **The highest-ROI rehearsal in this pack.** The hold is only what the quote carries: "I've never used SAP; we run our own in-house stock system." Then a plan, said as a plan: how you would go about learning it. Follow-up 1, "is your in-house system an ERP": answer slot, if you can say what the in-house system is used for, say it in your own words; if you don't know how it would be classed, say so plainly, and don't call it an ERP. Follow-up 2, "so you'd need training": the plan again, not a past. Follow-up 3, "would that be a problem": concede exactly what the quote concedes, and return to it | F7 is the one row where you stated an absence. The advert names SAP, so this arrives in some form, and a rehearsed, non-defensive answer changes the call. JD because it scores a stated plus |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Choose your own answer; the pack does not pick it for you. The pack observes that your material says delivery scheduling for depots, not production schedules, and does not mention planning or QA. Answer slot: if you have worked with a planning or QA function, say how; if not, say so plainly and stay with the depots. Then how you would learn how a production schedule works, said as a plan | F1 is the transferability gap. JD because it asks you to name a gap in the listed duties |
| B3 | "You come from a wholesaler and we're a manufacturer. What draws you to this role?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" | Answer slot: your material gives a reason for leaving, not a reason for choosing Quillmoor or for choosing this role. Give your own reason in your own words. If the move itself is the only reason you have, say so plainly rather than borrowing the advert's wording. Don't give a reason you wouldn't repeat to a second question | A5's reason is about leaving; the question about choosing Quillmoor is the natural next one, and your material is silent on it. The upgrade menu says what a sentence from you would change |
| B4 | "The role includes a weekly report on on-time dispatch. Have you done anything like that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Answer slot: if you have reported on deliveries or dispatch, say what and how often, in your own words; if not, say so plainly and stay with what you do when orders slip | F4 has no quote, so this is a discovery row and the guidance is a slot. JD because the advert lists reporting as a duty |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. Walk me through how that figure was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Say what the sentence says: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Answer slot: how the figure was counted, what it is sensitive to, and which part was yours, each in your own words. Name the assumption you would defend least; if you don't know how it was counted, say so plainly. The pack supplies no method or baseline | F3 holds the only figure in your material, and a figure is where a prober starts. EXP because it tests attribution |
| C2 | "The role needs someone confident with Excel. What do you do in it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: if the spreadsheet was in Excel, say what it did, in your own words; if it was another tool, say so plainly and stay with the rebuild. Don't list functions you did not use | F5 is a discovery row: the quote says spreadsheet, not Excel. JD because Excel is a stated requirement |
| C3 | "Tell me about a time a supplier order slipped and you chased it." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | The sentence supplies one beat: you chase suppliers when orders slip. Selection scaffold: pick a real time an order slipped and you chased it. It needs the order, what you did, and how it ended. If no single time comes to mind, say so plainly, then describe what you do when orders slip, in the quote's terms | F2 says what you do; an open prompt on the advert's chase-late-orders line tests whether there is a story behind it. EXP because it asks for a real instance |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we pick you over someone who already knows SAP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system"; "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip" | Hold, then concede. Pause and restate the question. Hold on your own sentences: four years as a logistics coordinator; you schedule deliveries for three depots and chase suppliers when orders slip. Concede the quote's own limit: you have never used SAP. Hold that through two follow-ups by returning to the sentences, never by adding a quality they don't state | F7 is where the pressure lands. JD because the advert names ERP as a plus; Pressure because of the time box and the comparison |
| D2 | "That drop in discrepancies: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold what the sentence says: you rebuilt the spreadsheet. The sentence does not say the rebuild alone produced the fall, so the pack does not say it for you. Answer slot: if other things contributed to the fall, say what you know of them; if none did, or you don't know, say so plainly and return to the rebuild | F3's figure under attribution pressure. EXP because the probe is about your share |

### E. Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you at 4pm that a delivery needed for tomorrow's production run will be two days late. Planning, the warehouse and QA all need to know. What do you do?" | CASE | [generic] | Structure it aloud. Clarify first: what is on the delivery, what the run needs, and whether other stock could cover it. Then objective, who you tell and in what order, what you record, and what you propose to planning. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's schedule-coordination line (F1) and its chase-late-orders line (F2). Generic: a pattern for the problem, not a fact about this employer |
| E2 | "The system shows more of an item than the shelf does. How do you approach it?" | CASE | [generic] | Structure it aloud: confirm the physical count, look at recent movements, find where the record and the shelf part, correct the record, and say what you would do about the cause. No claim about your past | From the advert's stock-records line (F3). Generic, for the same reason as E1 |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Planning wants a run moved up and the warehouse says it can't receive the goods in time. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Propose principles, not a claim to know their seam: what each team needs, which constraint is fixed, bringing options rather than complaints, and who decides. No claim about your past | The advert's three-way coordination (F1) produces this seam in real life. Generic |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Open prompt. Selection scaffold: pick a real time work spanned teams. It needs a named piece that was yours and a named piece that was theirs. If no such time comes to mind, say so plainly, then say how you would handle it | Peer stem from `personas.md`. Generic, because no source names a peer round |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "Coordinate production schedules between planning, the warehouse and QA" | A1, B2, E1, F1 |
| "track supplier deliveries and chase late orders" | A1, C3, E1 |
| "keep stock records accurate" | C1, D2, E2 |
| "report weekly on on-time dispatch" | B4 |
| "confident with Excel" | C2 |
| "2+ years in operations or logistics coordination" | A1 |
| "ERP experience (SAP or similar) a plus" | B1, D1 |
| "£38,000–£44,000" | A2 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A4 |
| "your notice period" and "what's prompting a move" (Hannah) | A3, A5 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "How does this role work with planning, the warehouse and QA day to day, and who would I sit closest to?" | The advert's three-way coordination is the heart of the job; asking shows you read it |
| "What does the weekly on-time dispatch report look like now, and who reads it?" | It picks up the advert's reporting duty and tells you what the standard is before you meet the manager |
| "What system does the team use for stock and supplier orders today, and how is someone new to it trained?" | The advert names ERP as a plus; this turns your gap into a practical question about the ramp |
| "Is the two-day Avonmouth pattern fixed, or agreed team by team?" | The hybrid pattern was on Hannah's agenda; this asks the employer something the advert doesn't settle |
| "After today, who would the next conversation be with, and what will they focus on?" | It tells you which bank to rehearse next. Banks D to F are a guess until you know |
| "What made the team open this role, and what would a good first three months look like?" | It signals you are thinking about the work, and the answer tells you what the team is short of |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has ERP or SAP experience | Negative you stated, F7 | The plain acknowledgment F7 gives: "I've never used SAP; we run our own in-house stock system." Then a plan, never a past |
| That the in-house stock system is equivalent to an ERP | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material does not say what the system covers |
| Scheduled production, or worked with planning and QA | Inflated form of F1 | F1's quote at its own scope: deliveries for three depots. B2's slot stays inside that |
| Advanced or expert Excel skills | Inflated form of F5 | F5's quote at its own scope: the spreadsheet rebuild. C2's slot asks only what the spreadsheet was and did |
| That your rebuild alone caused the fall in discrepancies | Inflated form of F3 | F3's quote at its own scope. D2's slot asks only what else, if anything, contributed |

## Sources

Provided documents: the advert for Operations Coordinator at Quillmoor Diagnostics, pasted by you; your own account of your background and what you would tell Hannah, in your message; Hannah Lowther's LinkedIn message about the call.

Searches sent, all refused, so nothing came back from any of them:

- "Quillmoor Diagnostics company values": refused
- "Quillmoor Diagnostics interview process operations coordinator": refused
- "Quillmoor Diagnostics Avonmouth news strategy": refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The search was refused. It would have supplied official value names for VAL themes. No values-style round is detected, so no cheat sheet was due either way |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | unavailable | The search was refused. It would have named later rounds; the persona weights for banks D to F rest on the role's duties instead |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | The search was refused. It would have fed a CO question and a reverse question tied to current priorities; the pack has no CO question |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The search was refused. It would have fed an interviewer read and a reverse question tied to her path; the pack has neither |
| 5. representative `Operations Coordinator` JD | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A3 and F10 move from an instruction to your own words, quoted
- A sentence on why you chose Quillmoor and this role specifically → B3 becomes a story-mapped row instead of an answer slot
- What your in-house stock system is used for, in your own words → B1 and D1 gain a beat from your own account, and F7 can say more than the plain acknowledgment
- Whether the stock-count spreadsheet was in Excel, and how the discrepancy figure was counted → F3, F5, C1, C2 and D2 gain beats instead of slots
- Whether you have ever reported on deliveries or dispatch, and how often → F4 moves from discovery to a quoted row, and B4 becomes story-mapped
- Search permission, or a paste of Quillmoor's careers or values page → the research targets above move from unavailable, and the pack gains a CO question and a company-specific reverse question
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes (offered once; it needs the same search permission) → a strategy brief, recent organisation context, and role-family reports on the process
- Hannah's public LinkedIn profile text, pasted → a short read of her background and a reverse question tied to her path
- A `tuesday-dossier.md` from an earlier evaluation of this role, if you have one → verified evidence and agreed positioning replace the quotes this pack builds from your message alone
