# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

- Role: Remote Administrative Assistant
- Company: Brennock Facilities Ltd
- Interviewer and relationship: the office manager, name not given; whether they would be your manager or a colleague is not stated
- Round: one 30-minute video call, as the invite words it: "The interview is a 30-minute video call with our office manager."
- Assumption this pack is built on: a hiring-manager-style round, because the invite names the office manager and says nothing more about the relationship

## How to use this pack, and what to expect

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

What to expect, from the invite's own words: one video call of 30 minutes with the office manager. Everything beyond that rests on the four duties as you described the ad, and on the persona weights below.

Start with B1, the highest-ROI rehearsal in this pack. Then A1 to A4, C1 and D1. Say each answer aloud at least once.

Type key:

| Tag | Name | One-line meaning |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behaviour shows the employer's published values; none is used here because no values were established |
| EXP | Work-experience deep-dive | Whether what you say about your past survives follow-up |
| JD | Role / JD-driven | Whether you can do the listed duties, including the ones your material does not yet show |
| CO | Company knowledge | How much homework you did on the employer |
| CASE | Hypothetical / live problem | How you structure a real problem from the job |

## Fit snapshot

Requirements are the ad's duties as you described them to me, and the work arrangement from the invite. Quotes in the evidence column are your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says an appointment book for four physios, with nothing inspected behind it, and the words stay there: "I ran the appointment book for four physios." Answer slot: the ad's calendars line makes a probe on your own book likely. If any of the book's rules were yours to set, say which and how you decided; if none were, or it was not yours, say so plainly and describe how you ran it |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: the ad's travel line makes a probe on real bookings likely. If you have booked travel for anyone, say what and for whom, in your own words; if you have not, say so plainly and walk through how you would do it |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it | "I'm good with Word" — your message | low | [grounded] | discovery | Your word is "good", and your material does not show which documents you have prepared. Answer slot: the ad's Word line makes a probe on what you produce likely. If you have prepared documents in Word, name the sorts and who they were for; if you mostly have not, say so plainly and say what you have used it for |
| F4 | "preparing documents in Word and Excel" — the ad, as you described it | "okay with Excel" — your message | low | [grounded] | discovery | Your word is "okay", and it stays "okay". Answer slot: the ad's Excel line makes a probe on what you can do in it likely. If you have used it for something specific, say what; if it was little, say so plainly and say what you would learn first |
| F5 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices and does not say whose invoices they were; the ad's line is about invoices from suppliers. The words stay with what you said: "At the clinic I chased unpaid invoices." Answer slot: if you can say whose invoices they were and what you did when one stayed unpaid, say it in your own words; if you do not know, or it was not yours to decide, say so plainly |
| F6 | "Remote Administrative Assistant" — the invite | none given | none | [grounded] | hard_gate | Your material does not establish whether remote working is open to you. Surfaced, not bridged |

## Persona table

Weights rest on the hiring-manager prior plus the invite's own words (one 30-minute call with the office manager). No loop beyond that call was established, so there is no other round to weight.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live problems from the four duties: a clash in a calendar, a trip to book, a document to check, an invoice that looks wrong | high: the ad's duties are tasks, and a short call with the office manager fits "what would you do" scenarios | Clarify first, then structure, then answer; think aloud |
| Skeptic (bank B) | Quiet probing of F2, F4 and F5, the three thinnest rows | high: three of the four duties rest on rows with no or thin evidence | Rehearse B1 until it is boring; hold, then concede only what is true |
| Conversational (bank C) | "Walk me through the journey", "what do you know about us" | medium: a 30-minute video call usually opens with the biography | A 90-second arc built from your own quoted sentences; treat casual questions as scored |
| Data-Driven Prober (bank D) | Line-by-line questions on "ran the appointment book for four physios" and "chased unpaid invoices" | medium: your background is short, so each line gets read closely | Say what you know about how things were done, and say plainly when you do not |
| Peer Evaluator | Seam and collaboration questions | low: the relationship is not stated; if the office manager is a colleague rather than your manager, this rises and a bank is added | Offer what you would bring to their load, not only what you need |
| Pressure / Stress | Interruptions, time-boxing | low: nothing in the invite suggests it | Pause, restate, hold a position through two follow-ups |
| Values / Behavioral | Scenarios mapped to published values | low: no values were established and the invite names no values round | Not used in this pack |

## Question banks

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two of the people whose calendars you look after ask for the same Thursday 2pm slot, and neither knows the other asked. What do you do?" | CASE | [grounded] "I ran the appointment book for four physios" | Structure it aloud: ask whose slot is fixed and whether either can move; set out the alternatives you can see; tell both people the outcome; note it so it does not repeat. Answer slot: the ad's calendars line makes a probe on your own book likely. If a clash like this came up in the book you ran, say what happened and what part was yours, in your own words; if none did, or it was not yours to settle, say so plainly and go to how you would handle it | F1 is the evidence for the calendars duty, and a live clash is the likeliest way it gets tested; CASE because it scores structure, JD because it covers a stated duty |
| A2 | "My manager needs to be in another city for a 9am meeting and back for a 4pm call the same day. Walk me through how you would book it." | CASE | [generic] | Clarify first: dates, budget, preferences, who approves, what happens if a leg runs late. Then compare options, confirm details with the traveller before booking, and send the itinerary with a copy kept. Answer slot: the ad's travel line makes a probe on real bookings likely. If you have booked travel for anyone, say what and for whom, in your own words; if you have not, say so plainly and walk the process as you would run it | F2 is silent either way, so a live problem is the fair test; CASE with JD content |
| A3 | "A draft letter and a price list need to go out by end of day. What do you check before they leave?" | CASE | [generic] | Name your checks in order: who it is for and what it must do; names, dates and figures against the source; layout and spelling; file name and version; who sends it. Answer slot: the ad's Word and Excel line makes a probe on your own use likely. If you have prepared documents or worked on lists, name what; if you mostly have not, say so plainly and stay with how you would check | F3 and F4 are thin, so the question is asked as a process; CASE tagging because it scores method, JD because it covers a stated duty |
| A4 | "A supplier invoice arrives and the amount is not what we agreed with them. What do you do?" | CASE | [grounded] "chased unpaid invoices" | Structure: do not approve or pay it yet; check what was agreed; find who approves; query the supplier in writing; log it and follow up. Answer slot: your quote is chasing unpaid invoices. If any of those turned out to be wrong or disputed, say what you did, in your own words; if none did, say so plainly and walk through how you would handle this one | F5 is where the duty presses hardest on thin evidence; CASE because the probe arrives as a decision, JD because it scores the invoices line |
| A5 | "This role is remote. How would you keep me up to date on what you have done and what is waiting?" | CASE | [generic] | Offer a simple routine and ask which channel and how often they prefer; flag blockers early; keep a shared task list. Answer slot: if you have worked remotely before, say how you kept people informed; if you have not, say so plainly and describe the routine you would set up | F6 is a gate this pack surfaces and never bridges; this question only rehearses working style, and JD because the title says remote |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel" "chased unpaid invoices" "ran the appointment book for four physios" | The highest-ROI rehearsal in this pack. Name the part that is true for you in one sentence, before they do, then give the plan: what you would ask for and learn in your first week. The pack's own observation: your material shows no travel booking either way, carries Excel as "okay", and carries invoices as chasing, not supplier invoices. Hold-then-concede: if pushed twice, keep the same answer, concede only what is true, and return to "I ran the appointment book for four physios" | F2, F4 and F5 are the thinnest rows and this question reaches all three at once, so it will arrive in some form; JD because it scores the stated duties |
| B2 | "You have been a receptionist in a clinic. Why a remote administrative role now?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" | Selection scaffold: give one real reason you want this kind of work and one real reason you want it remotely, a sentence each. If no clear reason comes to mind, say so plainly, then say what you like about the four duties in the ad | Motivation consistency is the Skeptic's standing test; F6 is the remote row, so the reason for remote is probed; JD because it scores fit with the stated role |
| B3 | "You chased unpaid invoices. How much of that was actually you?" | EXP | [grounded] "chased unpaid invoices" | Hold the words you have: "At the clinic I chased unpaid invoices." Answer slot: say which invoices, who owed them and how you kept track, in your own words; if someone else decided who to chase or kept the list, or there was no list, say so plainly and describe what you did yourself. Hold through two follow-ups by returning to what you did, never by adding to it | F5 is the evidence for the invoices duty, and attribution is exactly what a skeptic tests; EXP because it checks what was yours |
| B4 | "How would you rate your Excel, and what have you actually used it for?" | JD | [grounded] "okay with Excel" | Give your rating in your own word, which was "okay", and keep it there. Answer slot: name what you have used it for, in your own words; if it was little, say so plainly, then say what you would learn first. Name no feature you have not used | F4 is the thinnest of the Office rows, and a self-rating invites the next question; JD because Excel is a stated duty |
| B5 | "I don't see supplier invoices in what you have told me. How would you handle that part of the job?" | JD | [grounded] "chased unpaid invoices" | The pack's own observation: your material says chasing unpaid invoices and does not say whose they were. Describe what you did in those words. Then give a ramp plan as a plan: who approves invoices here, which system is used, what the steps are, and how you would check your own work before sending anything on. Answer slot: if you know whose invoices you chased, say so; if you do not, say so plainly | The second face of F5, asked as a gap; JD because it scores the invoices line, and the guidance never claims supplier-side work |

### Bank C: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey: how did you get from the clinic to this role?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "ran the appointment book for four physios" "chased unpaid invoices" | A 90-second arc with only these beats: two years as a receptionist at a physiotherapy clinic; you ran the appointment book for four physios; you chased unpaid invoices. Answer slot: then say in your own words what drew you to the ad's four duties; if one did not draw you, leave it out | The biography is the likeliest opener of a 30-minute call; F1 and F5 are the beats; EXP because it is your story, told once |
| C2 | "What do you know about us, and what made you apply?" | CO | [generic] | Use only what you have found yourself on the employer's own website or listing, and say it accurately. Pick one or two facts, then say what made you apply in your own words. If you find little, say so plainly and talk about the four duties in the ad | Nothing about the company was established for this pack, so the answer must come from your own reading; CO because it scores homework |
| C3 | "What did you enjoy most about running the appointment book?" | EXP | [grounded] "ran the appointment book for four physios" | One specific thing, from your own experience, in your own words. Link it to the ad's calendars line only if it is true. Add nothing about how the book worked that you would not repeat under a follow-up | F1 again, in a friendly register: casual questions about the core duty are still scored; EXP |
| C4 | "What sort of documents do you prepare in Word day to day?" | JD | [grounded] "I'm good with Word" | Keep your own words: "good with Word". Answer slot: if you prepare documents, name the sorts and who they were for; if you mostly do not, say so plainly and say what you have used Word for | F3 is thin, and the question presupposes a practice your quote does not carry; JD because Word is a stated duty |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the appointment book for four physios in a normal week." | EXP | [grounded] "ran the appointment book for four physios" | Story beats only as the quote states them: the book, the four physios, and you running it, in your own words. Answer slot: the ad's calendars line makes a probe on how it was kept likely. If any rule or process was yours to set, say which and how you decided; if none were, or it was not yours, say so plainly and describe how you ran it day to day | F1 is the line a prober reads first, and "four" is a figure, so how it was counted gets asked; EXP |
| D2 | "How did you decide which unpaid invoices to chase first?" | EXP | [grounded] "chased unpaid invoices" | Answer slot: if you had a way of ordering them, say what it was, in your own words; if there was no order, or someone else set it, say so plainly and describe what you did | F5 under a prober: the premise is an order, so the second branch lets it be false; EXP |
| D3 | "How would you check that a spreadsheet total is right before it goes out?" | CASE | [generic] | Structure: compare it to the source, check the inputs, recalculate it another way, have a second person look, note what you checked. Say your level as you rated it, "okay", and name no feature you have not used | F4 tested as method rather than as a rating; CASE with JD content |
| D4 | "What tools did you use day to day at the clinic?" | EXP | [grounded] "ran the appointment book for four physios" | Answer slot: name the tools you actually used, in your own words, including any the clinic chose for you; if the clinic's system did most of the work, say so plainly | Probers test the tooling behind a claim; F1 is the claim; EXP |

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| "managing calendars" | A1, C3, D1, D4 |
| "booking travel" | A2, B1 |
| "preparing documents in Word and Excel" | A3, B1, B4, C4, D3 |
| "processing supplier invoices" | A4, B1, B3, B5, D2 |
| "Remote Administrative Assistant" | A5, B2 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "Across calendars, travel, documents and invoices, which takes most of the week in this role?" | Shows you read the four duties and tells you where to put your practice time |
| R2 | "Which tools do you use for calendars, travel booking and invoices?" | You learn the setup, and it lets you say honestly what you would learn first |
| R3 | "What would a good first month look like, and how will I get feedback on it?" | Signals you want to be measured and gives you the bar to aim at |
| R4 | "How does the team stay in touch day to day when someone works remotely?" | Shows you have thought about remote working and gets you the real routine |
| R5 | "What happens after this call, and who makes the decision?" | A process question that lets you plan your follow-up and your own timing |
| R6 | "What is the hardest part of this role for someone new?" | Invites the interviewer to name the thing you will be tested on after you start |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for a wider team or for senior staff | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: your material says the book, not meeting calendars |
| Advanced or strong Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel" |
| Expert or advanced Word skills | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word" |
| Processed supplier invoices, or ran accounts payable | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices". The limit is the pack's observation: your material says chasing, not supplier invoices, and does not say whose invoices they were |

## Sources

Provided: your message, which held the invite as you pasted it, the ad's duties as you described them, and your background.

Searches sent:

| Query | What came back |
|---|---|
| Brennock Facilities Ltd values | refused |
| Brennock Facilities Ltd interview process administrative assistant | refused |
| Brennock Facilities Ltd company news strategy | refused |

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities Ltd values | unavailable | All calls refused. Would have fed a values cheat sheet and VAL questions; none is built, and C2 stays `[generic]` |
| 2. Brennock Facilities Ltd interview process administrative assistant | unavailable | All calls refused. Would have named other rounds; the persona weights rest on the invite's own words alone |
| 3. Brennock Facilities Ltd company news strategy | unavailable | All calls refused. Would have grounded a CO question; C2 is generic as a result |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Remote Administrative Assistant job description | skipped | The ad's duties as you described them fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full ad text, pasted → F1 to F5 would quote the ad itself, and any duty you did not mention would get a row and a question
- Answers to the answer slots, in your own words, outside a drill (for example whether you have booked travel, what you have prepared in Word, whose invoices you chased) → the rows they touch would regenerate with your wording
- The interviewer's name and role → a read of their public professional footprint, a tailored reverse question, and persona weights adjusted from it
- Whether the office manager would be your manager or a colleague → reweighted banks, and a Peer bank if it is a colleague
- Anything the employer has said about what the call will cover → coverage built to it instead of assumed
- Company pages you find yourself, such as values or careers material, pasted in → a values cheat sheet if a values round is documented, and a CO bank grounded in them; a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) once search access is allowed in this session
- A tuesday-dossier.md → verified evidence and constraints carried into this pack's guidance
