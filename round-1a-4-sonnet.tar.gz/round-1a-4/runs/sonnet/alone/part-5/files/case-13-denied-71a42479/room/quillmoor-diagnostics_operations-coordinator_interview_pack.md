# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Interviewer: Hannah Lowther, Talent Partner. Round: recruiter screen, a 30-minute phone call on Thursday at 2pm. Hannah will ring the mobile number on your application.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores: **VAL** (values alignment), **EXP** (work-experience deep-dive), **JD** (role and job-description requirements), **CO** (company and strategy knowledge), **CASE** (a live problem from the role).
- Guidance is scaffolding, not a script. Say things in your own words, and only what you actually did.
- Wording in the guidance cells is proposed and pending your approval. You decide what you say.
- An answer slot is an instruction for the interview, not a question for you now. Meet it with either honest branch.
- Research could not run for this pack (every search was refused), so nothing here is drawn from outside the advert, Hannah's message and what you told me. See Sources.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert's line on planning, the warehouse and QA makes a probe on those teams likely. If any of your scheduling involved them, say how, in your own words; if it did not, or it was not yours, say so plainly and stay with the depots |
| F2 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The quote touches deliveries without showing how a supplier's order is followed. Answer slot: if you follow supplier orders in some way, say how, in your own words; if you do not, or someone else does, say so plainly and stay with the depots' deliveries |
| F3 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap, but a self-description with nothing inspected behind it, so expect a probe. Lead with the quote's own terms: you chase suppliers when orders slip |
| F4 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but a headline figure with nothing inspected behind it, so expect a probe on how it was counted. Hold it at its own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. The defend-the-number slots are in C1 |
| F5 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you produce any regular report on deliveries or dispatch, say what it covers and how often, in your own words; if you do not, say so plainly and stay with the depots' scheduling |
| F6 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap. Say it as written: four years as a logistics coordinator at a building-supplies wholesaler |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says a spreadsheet and does not say which tool. Answer slot: if it was built in Excel, say what you did in it, in your own words; if it was another tool, or someone else built part of it, say so plainly |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | capability | The gap is one you stated, and it is listed as a plus. Words: "I haven't used SAP." Then the in-house system at its own scope: "we run our own in-house stock system." Answer slot: if you use that system day to day, say what for; if you do not, or it is not comparable to SAP, say so plainly. Your plan for learning a system like SAP is said as a plan, never as a past |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | Your own constraint, met. Say it in your own words, whole. If asked about it again, return to those same words and add nothing |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Your own figure, and the pack's observation is that it sits inside the advert's band. Say it in your own words. Nothing else is coached on the figure |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish it. The pack's observation only; it asks nothing here |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Say it as you gave it, whole. A follow-up on it gets those same words again |

## Persona weights

Relationship prior: a recruiter screen leans Conversational with a light Skeptic. Hannah's own message names the agenda, and no interviewer profile or loop research exists (searches refused), so the weights rest on that prior plus her stated agenda.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A) | Friendly walk through pay, notice, hybrid and why you are moving | Highest. Hannah listed these four topics herself, and the journey question is standard in the same register | Your own words for each logistics topic; a 90-second arc built from the quotes in A5 |
| Skeptic (B) | Quiet probing of the SAP gap and the production-scheduling adjacency | Medium. The advert lists ERP as a plus and production scheduling as the job, and a screen often checks both before passing you on (F1, F8) | Rehearse B2 until it is boring: the plain acknowledgment, the in-house system at its own scope, a learning plan said as a plan |
| Data-Driven Prober (C) | Light CV probing: the discrepancy figure, Excel, reporting | Low to medium. A recruiter is not scoring depth, but a headline figure invites one follow-up (F4) | Know how the figure was counted, or say plainly you do not know |
| Case / Strategist (D) | A quick scenario or "what do you know about us" | Low. Hannah's agenda is logistics and next steps, so this is likely only in passing | Clarify first, then structure; use only what the advert gives you |
| Pressure (E) | A challenge to your fit, or to how much was you | Low. A friendly screen rarely pushes, but the SAP point can sharpen | Hold your position through two follow-ups, then concede the specific limit |
| Peer Evaluator (G) | Collegial questions on working across teams and with suppliers | Low. The role sits between planning, the warehouse and QA, so a passing question is plausible (F1, F3) | Describe what you actually did; do not pretend to know the seams |

**Highest-ROI prep: B2.** It is the one question where your own words state a gap and the advert names it, so it will arrive in some form. A2 to A4 and A1 are near-certain too, but they are only your own words said aloud.

## Question banks

### Bank A: Conversational (pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Say it in your own words as you gave it: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." A follow-up on it gets those same words again, with nothing added | F12 is a topic Hannah named. EXP because it tests that your story stays consistent across the call |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Your own words: "I'm hoping for £42,000." If asked what you earn now, you may decline and bring it back to this role's band, without giving a figure | F10 is a topic Hannah named. JD because it concerns the advert's own terms |
| A3 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, in your own words. The pack holds none for you | F11 is a gate your material does not establish, and Hannah named it. JD because it concerns the job's start terms |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." A follow-up on the commute gets those words again | F9 is a topic Hannah named. JD because it concerns the advert's two-day pattern |
| A5 | "So, walk me through the journey so far." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with the beats the quotes state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; the stock-count spreadsheet you rebuilt and the discrepancies that fell by about a third over a year. Close with your A1 words for why you are looking | F6, F3 and F4 carry the arc. EXP because it sets out your claims in order before any probe |

### Bank B: Skeptic (pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would be weakest for you on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Name the limit in your own words. The material carries two: you have not used SAP, and your scheduling is of deliveries for three depots. Say it plainly, then say how you would get up to speed, as a plan | F8 and F1 are the two places the advert presses past your quotes. JD because it scores the stated requirements, including the gaps |
| B2 | "Do you have SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | The highest-ROI rehearsal in this pack. Level 1: "I haven't used SAP." Level 2, if asked about other systems: "we run our own in-house stock system." Answer slot: if you use that system day to day, say what for; if you do not, or it is not comparable to SAP, say so plainly. Level 3, if asked how quickly you could pick up a system like SAP: say how you would go about learning it, as a plan; if you have a true earlier example of learning a system, say it, and otherwise leave it out. Level 4, if asked whether that is a gap: concede the specific limit, that it is listed as a plus and you have not used SAP. Never imply you have | F8 is the stated gap the advert names, so this question arrives in some form. JD because it scores a listed requirement |
| B3 | "The role coordinates production schedules between planning, the warehouse and QA. What have you scheduled that touches production?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if any of your scheduling involved planning, the warehouse or QA, say how, in your own words; if it did not, or it was not yours, say so plainly and describe the delivery scheduling you do: "I schedule deliveries for our three depots." Hold there through a follow-up | F1 is where the advert's mandate presses hardest. JD because it scores the stated responsibility |

### Bank C: Data-Driven Prober (pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that discrepancy figure was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what the quote carries: you rebuilt the stock-count spreadsheet, and discrepancies fell by about a third over a year. Answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. Where you do not know how it was counted, say that plainly | F4 is the headline figure on your side. EXP because it tests whether the number survives scrutiny |
| C2 | "What was the spreadsheet built in, and how confident are you in Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say which tool the spreadsheet was built in and what you did in it, in your own words; if it was not Excel, or someone else built part of it, say so plainly | F7 is thin because the quote does not name the tool. JD because the advert asks for Excel confidence |
| C3 | "We report weekly on on-time dispatch. What reporting on deliveries have you done?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you produce any regular report on deliveries or dispatch, say what it covers and how often, in your own words; if you do not, say so plainly and stay with the scheduling: "I schedule deliveries for our three depots." | F5 is the advert's requirement your material is silent on. JD because it scores a stated responsibility |

### Bank D: Case / Strategist (pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A key supplier tells you on Monday morning that an order the warehouse is waiting for will be three days late. What do you do?" | CASE | [generic] | Clarify first: what is waiting on it and how much cover there is. Then set the objective, tell planning, the warehouse and QA what it affects, press the supplier for a firm date, record the change, and say how you would follow up. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier line (F3), asked as a decision. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| D2 | "The system says 120 units and the shelf has 104. What do you do?" | CASE | [generic] | Clarify what was counted and when. Then recount, check recent movements, correct the record, and say how you would stop it recurring. The guidance makes no claim about your past | A live problem from the advert's stock-records line (F4). `[generic]` for the same reason |
| D3 | "What do you know about Quillmoor and what we make?" | CO | [grounded] | Use only what the advert says: a diagnostic-test manufacturer of about 400 staff, with a site at Avonmouth, and a role that coordinates between planning, the warehouse and QA. Anything beyond that you add after reading their own site before Thursday, in your own words. Answer slot: if you find a current fact on their site, name one thing | Company research could not run, so the answer rests on the advert alone. CO because it scores homework, and it arrives casually in a screen |

### Bank E: Pressure (pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you for this job when you have never used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "Never used SAP — we run our own in-house stock system." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause, restate the question, then hold the position the quotes carry: four years as a logistics coordinator at a building-supplies wholesaler, and you schedule deliveries for three depots and chase suppliers when orders slip. Hold through two follow-ups. Then concede the specific limit: "I haven't used SAP." Never fold on the four years to restore harmony | F8 under time pressure. JD because it scores fit against a listed requirement |
| E2 | "How much of that drop in discrepancies was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold on the verb you used: you rebuilt the stock-count spreadsheet. Then concede specifically. Answer slot: if other things also changed that year, say what; if nothing else did, say so plainly; if you do not know how the figure was counted, say that. The material says the rebuild and the fall, not that one caused the other | F4 is the figure a pressure interviewer tests for attribution. EXP because it scores what was actually yours |

### Bank G: Peer Evaluator (pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time two teams wanted different things from you." | EXP | [generic] | Selection criteria: pick a time two groups wanted different things from your scheduling; it needs a named stake, what you did, and an intact working relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The advert's coordination line across planning, the warehouse and QA (F1) raises this theme. No quote carries a story, so it is a scaffold |
| G2 | "Tell me about a time a supplier didn't deliver what was agreed." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-map on the quote's beats: you schedule deliveries for three depots, and you chase suppliers when orders slip. Answer slot: if a particular order slipped, say what happened and what part was yours, in your own words; if you cannot think of one, say so plainly and describe how you chase suppliers when orders slip | F3 is the evidence for the advert's chasing line. EXP because it tests what you actually did |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B1, B3, D1, G1 |
| Track supplier deliveries | D1, G2 |
| Chase late orders | D1, G2 |
| Keep stock records accurate | C1, D2, E2 |
| Report weekly on on-time dispatch | C3 |
| 2+ years in operations or logistics coordination | A5, E1 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B1, B2, E1 |
| Hybrid, two days a week at Avonmouth | A4 |
| £38,000–£44,000 | A2 |
| Notice period (Hannah's message) | A3 |
| What's prompting a move (Hannah's message) | A1, A5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does the process look like after this call, and who would I meet at each stage?" | Hannah said she would cover next steps; this confirms who and what each stage scores, so you can prepare for the next one |
| 2 | "How is the coordination between planning, the warehouse and QA organised today, and is this a new role or a replacement?" | The advert's central responsibility is that coordination, and the answer shows what you would inherit |
| 3 | "Which system does the team use for orders and stock, and how much training does the role come with?" | The ERP line is your likeliest gap, and this turns it into a question about the ramp |
| 4 | "What does the weekly on-time dispatch report look like today, and who reads it?" | It shows you are thinking about the number the role is measured on |
| 5 | "How fixed is the two-days-at-Avonmouth pattern, and is it set days or agreed by the team?" | It checks the pattern's real shape against what you told Hannah, so there are no surprises later |
| 6 | "What would a good first six months look like in this role?" | It signals you are thinking about delivery, and gives you something concrete to refer back to |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Scheduled production, or coordinated production between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation: the material says deliveries for three depots, not production |
| Has SAP or similar ERP experience | Negative the candidate stated, F8, plus an inflated form of "similar" | The plain acknowledgment F8 gives: "I haven't used SAP." The in-house system stays at its own scope: "we run our own in-house stock system." The pack's observation is that the material does not say that system is an ERP |
| Cut stock discrepancies by a third | Inflated form of F4 | F4's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: the material says the rebuild and the fall, not that one caused the other |

## Sources

Provided documents: the advert text, Hannah Lowther's LinkedIn message, and your self-description. No CV, and no tuesday-dossier.md.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Query | Outcome |
|---|---|
| Quillmoor Diagnostics values | refused |
| Quillmoor Diagnostics interview process operations coordinator | refused |
| Quillmoor Diagnostics Avonmouth news strategy | refused |
| Hannah Lowther Talent Partner Quillmoor Diagnostics | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Every search was refused. It would have named the published values; no values round is detected for a recruiter screen, so the cheat sheet is absent either way |
| 2. Quillmoor Diagnostics interview process, operations coordinator | unavailable | Every search was refused. It would have shown later rounds; this session's loop is established by Hannah's own message |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Every search was refused. It would have moved D3 from advert-only to a current-facts answer |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Every search was refused. It would have supplied an interviewer read and a reverse question tied to Hannah's own path |
| 5. Representative Operations Coordinator advert | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A3 becomes your own words, and F11 resolves
- Whether you produce any regular delivery or dispatch report, and what the spreadsheet was built in → F5 and F7 move from discovery to rows with your own quoted words, and C2 and C3 get real answers
- How the discrepancy figure was counted, and what else changed that year → C1 and E2 get your own defend-the-number answers
- Your CV → more rows can quote your own sentences; today the only evidence is your self-description
- Allow web search → the four failed searches rerun, which would add Quillmoor's published values, any documented process, recent news, and Hannah's public professional footprint for a tailored reverse question. A deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, can follow once
- Any recruiter prep note from Hannah → coverage of any later round
- A tuesday-dossier.md from an earlier evaluation → verified evidence and constraints on your weak areas, though it is never needed for this pack
