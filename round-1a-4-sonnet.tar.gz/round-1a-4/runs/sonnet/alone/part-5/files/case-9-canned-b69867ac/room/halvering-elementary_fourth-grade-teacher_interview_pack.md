# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

Panel interview, 45 minutes, Thursday. Panel: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). District: Orrinsford Community School District. Built on the invite and your CV text, with the posting itself not supplied.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores. Every question carries both.
- Types: VAL = whether your past shows the district's published beliefs. EXP = whether your CV claims hold up under questions. JD = the role's stated or typical duties. CO = what you know about the district and its plans. CASE = a live problem set in the role.
- Provenance labels: `[grounded]` rests on a document you gave or on research cited in Sources. `[inferred]` is a derivation. `[generic]` is a pattern with no claim about you or this employer.
- Guidance is scaffolding, not a script. Say it in your own words. Where a cell says "Answer slot", it is an instruction for the interview: answer it truthfully from your own experience, and the second branch is always allowed.
- The highest-ROI prep in this pack is A1, the move from third to fourth grade.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The stated terms meet the requirement, and the grade range you gave includes fourth grade. It is a CV line with nothing inspected behind it, so say it in its own terms and expect it to be confirmed. This pack has not checked your license record; confirming it is current before Thursday is yours to do |
| F2 | "Fourth Grade Teacher position" — the invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your CV | medium | [grounded] | transferability | Your words for the gap: "I haven't taught fourth grade." Your words for the adjacent work stay at their scope: six years teaching third grade at a public elementary school in Joliet. Any wider step is an answer slot: if any of your six years brought you into fourth-grade work, say what it was, in your own words; if none did, say so plainly and stay with third grade |
| F3 | "Every Child a Reader: no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | none | Both quotes speak in reading terms, so lead with them as written: you led your grade level's move to a new reading curriculum in 2024, and you have run the after-school reading club for the last two years. Both are CV lines with nothing inspected behind them, so expect a probe on what each involved. The pack does not say who chose the curriculum or what the club produced, because the material does not |
| F4 | "each teacher speaks with every family each term" — Orrinsford Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | A weekly email is adjacent to speaking with each family; the quote does not say whether you also speak with families directly. Words: "I write a weekly email to families." Answer slot: if you also speak with families directly, say how and how often; if you do not, say so plainly and say how you would meet the district's term-by-term expectation |
| F5 | "assessments inform teaching and never replace it" — Orrinsford Mission and Beliefs page | none given | none | [grounded] | discovery | Nothing in your material touches how you use assessments, and it is not shown absent. Answer slot: the district states this belief, so expect a probe on how assessments shape what you teach next. If they do, say what you look at and what changes, in your own words; if they do not, or that is set elsewhere, say so plainly and say what you would want them to tell you |
| F6 | Teach the core subjects across a fourth-grade day — role-family duty from a search-result snippet of a representative listing, not opened | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [generic] | discovery | Your quote does not say which subjects you taught. No source for this posting raises the requirement, so there is no answer slot. Selection scaffold: pick the subject you would be asked about least comfortably, name what you have actually taught in it, and if nothing comes to mind, say so plainly and say how you would prepare |
| F7 | Set and keep clear classroom routines — role-family duty from the same snippet, not opened | none given | none | [generic] | discovery | Nothing in your material speaks to routines. Selection scaffold: pick a routine you actually use that you can explain in two sentences, what it protects and how students learn it; if none comes to mind, say so plainly and use the first-week structure in C2 as a plan, not a past |
| F8 | Work with the grade-level team — role-family duty from the same snippet, not opened | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [generic] | transferability | The first quote is the adjacent work at its own scope, and your own words limit it: "I've never been a team lead." Do not turn "led our grade level's move" into running the team. If asked directly, give the plain acknowledgment, then return to the quote |

## Reading the interviewer

Public professional footprint only, from the principal's speaker page on the Illinois principals forum site (fetched).

| Fact | Provenance | What it means for you |
|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | [grounded] | Expect reading-instruction questions to be asked by someone who has taught reading as a specialist. C3 and A3 are the likeliest places |
| Gave a 2025 forum talk, Small Groups, Big Readers, covering weekly reading conferences in grades 3 to 5 | [grounded] | Her talk's grade band includes both third and fourth grade. Whether she sees the step between them as small is not known; do not assume it, and do not lean on it. Use her topic as reverse-question material (reverse question 1) |

Mirror opportunities: shared vocabulary only. Her topic is reading in grades 3 to 5; your reading material is F3, whose quotes you may use at their own scope. No shared career jump is offered, because no quoted row carries your side of one. The two fourth-grade teachers on the panel have no public information supplied, so nothing is read about them.

## Persona weights and table

Reasoning: the loop is one 45-minute panel with the principal and two fourth-grade team members (named in your invite). A panel blends the top two personas of each member's relationship: the principal as the hiring-side member gives Skeptic and Case/Strategist; the two teammates as peers give Peer Evaluator and Prober. Adjustments: the principal's reading-specialist background tilts the Case bank toward reading problems; no source says any panel member is data-driven, so Prober stays low; nothing supports a stress style, so Pressure stays low. A values-style round is not detected: neither your invite nor the district's hiring description names one, so there is no separate values cheat sheet, though the district's three published beliefs still theme the Values bank. Weights are my judgment from these sources and you should adjust them if you know the panel.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the move from third to fourth grade and of what "led" meant | High: your own CV states both gaps, and the principal is the hiring-side voice | Rehearse A1 until it is boring: say the gap plainly, hold the adjacent work at its scope, and give a plan in future tense |
| B. Peer Evaluator | Teammates ask how you would work beside them and what you need | High: two of three panelists are teammates who will plan with you | Frame what you bring as well as what you need; offer principles for the seam, not a claim to know it |
| C. Case/Strategist | Live problems in reading, routines and families, plus the district's literacy plan | High: the principal is a former reading specialist and the district's plan covers grades 3 to 5 | Clarify first, structure aloud, name one first step, then how you would check it |
| D. Values/Behavioral | Stories mapped to Every Child a Reader, Families Are Partners and Teach for Tomorrow, Not for the Test | Medium: the district says three beliefs guide every hire, but no separate values round is documented | Use a selection scaffold per belief; one quoted sentence per belief where you have one, otherwise the honest branch |
| E. Conversational | Biography and "what are you reading" openers | Medium: an open conversation is plausible in a 45-minute panel, though no source says how it opens | Have a 90-second arc ready (E1); treat casual questions as scored |
| H. Data-Driven Prober | Pushes on how you know the family email or the curriculum move worked | Low: no signal of this style, but two teammates may probe claims | Say what you know and plainly what you do not |
| G. Pressure | Time-boxed "why you over someone who has taught fourth grade" | Low: nothing suggests a stress style, but G1 is cheap insurance | Hold, then concede the one true gap, and do not fold on the rest |

## Question banks

Ordered by weight. IDs run letter by persona.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're coming from six years in third grade. What will be hardest about moving up to fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Say the gap first, in your own words: "I haven't taught fourth grade." Then the adjacent work at its scope: six years teaching third grade at a public elementary school in Joliet. Then a plan in future tense: what you would ask the two fourth-grade teachers first and what you would watch for in the first weeks. Answer slot: if any of your six years brought you into fourth-grade work, say what it was; if none did, say so plainly and stay with third grade. Follow-up 1, "What is different about fourth grade?": say what you actually know, or that you would find out and from whom. Follow-up 2, "Why should we take someone who has to learn it?": hold the six years, repeat the concession in the same plain words, and add no trait you cannot back with an example from your own material. The limit, named before it is asked: your material says third grade, and it says never fourth | F2 is the clearest stated gap and two panelists teach the grade, so this arrives in some form; JD because it scores fit to the posted grade, asked as a Skeptic would |
| A2 | "Walk me through how you led your grade level's move to a new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The beats are the ones the sentence states: your grade level, the move to a new reading curriculum, 2024, and that you led it. Tell them in your own words. Answer slot: expect a probe on what leading meant and which decisions were yours. If you chose or shaped the curriculum, say how; if it was chosen above you and you led your grade level's move, say so plainly. If asked whether you have been a team lead, the plain answer is "I've never been a team lead," then return to the sentence | F3 and F8 meet here: the quote is the strongest reading evidence and the likeliest to be probed on scope; EXP because it tests what was actually yours |
| A3 | "How do the assessments you give shape what you teach next?" | VAL | [grounded] "assessments inform teaching and never replace it" — Orrinsford beliefs page | The question makes no claim about your past, and neither does this guidance. Answer slot: if assessments change what you teach next, say what you look at and what changes, in your own words; if they do not, or that is set elsewhere, say so plainly and say what you would want them to tell you | F5 has no evidence, and the district states this belief, so the probe is plausible; VAL content, JD delivery, because it scores a stated belief through a duty |
| A4 | "Tell us about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | The beats the sentence carries are: after school, a reading club, run by you, for the last two years. Tell them in your own words. Answer slot: expect a probe on what a session looks like and who it serves. Say what you did; if the format was set by someone else, say so plainly and describe how you ran it. Do not say what the club achieved unless you can say how you would know | F3 supplies the quote; EXP because it checks the claim, and reading is the district's first belief |
| A5 | "Why fourth grade, and why here, and why now?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Your reasons are yours: one sentence on why fourth grade, one on why Halvering, one on why now, with nothing borrowed from the pack. Public sources worth reading before Thursday: the district's three beliefs and the board's August literacy plan (see Sources). Use them only if they match your real reasons | F2 is the quiet motivation probe; JD because it scores fit to this role, with motivation consistency as the real score |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our fourth-grade team plans together. How do you like to work with a grade-level team?" | VAL | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The sentence carries one collaborative fact: it was your grade level's move. Use "our grade level's move" and keep "led" at that scope. Answer slot: expect a probe on what your work with your grade level looked like day to day; say what you did in your own words, and if your part was mostly independent, say so plainly. "I've never been a team lead" stays available if asked | F8 is the nearest evidence for team work; VAL because it scores partnership fit, which is the panel's own subject |
| B2 | "Two of us plan the same unit differently. What happens?" | CASE | [generic] | A live problem, so no claim about your past. Structure it: ask what each plan is meant to achieve, agree what must be common and what can differ, decide who decides and when you revisit. Speak in principles, not as if you already know their seam | Peer probes on disagreement are standard; CASE because it is asked as a live scenario; generic because it is a pattern, not a fact about this team |
| B3 | "What could you do in your first month that would help our team?" | JD | [grounded] "I write a weekly email to families"; "I've run the after-school reading club for the last two years" | Reciprocity, not need. The two things your quotes let you offer are your family communication and your reading club work, offered as "if it's useful" and not as something the team lacks. Answer slot: whether either would carry over to a fourth-grade team; say what you think, and if you are unsure, say so plainly | F4 and F3 are the usable quotes; JD because it scores how you add to the team's load |
| B4 | "You're coming from third grade. What do you need from us in your first weeks?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | State the gap in your words, then ask for specific things in the future tense: time to see how the team runs a unit, who to ask about routines. Close with what you bring back, from B3. Do not say you will learn quickly unless you can name an example from your own material | F2 appears again in peer packaging; JD because it scores readiness to start |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The board adopted a literacy plan in August, with a new reading curriculum for grades 3 to 5 starting fall 2027. How would you get ready to be part of that?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you read it: the plan has structured phonics from kindergarten to second grade, a new grades 3 to 5 reading curriculum from fall 2027, and a family reading night at every school each term. Then clarify before structuring: what is decided, what training exists, what teachers get a say in. Connect your own work only in the quote's words: you led your grade level's move to a new reading curriculum in 2024. Answer slot: which parts of that move would carry over to a different curriculum; if few or none, say so plainly and say what you would learn first. Do not claim to know which curriculum the district chose | F3 is your only reading-change evidence; CO because the plan is the district's current strategy |
| C2 | "It's the first week of school. Which routines would you set up, and why those?" | CASE | [generic] | A live problem, so no claim about your past. Choose three routines and, for each, say what it protects, how students learn it in the first week, and how you would know it is working. Add a routine you actually use only if you can explain it in two sentences | F7 has no evidence and the district's hiring description lists routines among panel topics; generic because the scenario is a pattern |
| C3 | "A fourth grader reads aloud fluently but can't tell you what the passage said. What do you do on Monday?" | CASE | [generic] | A live problem, so no claim about your past. Ask what you would want to know first, name where you think the break is, pick one small step, say how you would check it and what you would tell the family. Think aloud; the principal is a former reading specialist and will follow your reasoning more than the answer | F6 and the principal's background make a reading problem likely; generic because the scenario is a pattern |
| C4 | "A parent emails twice in a week worried their child is falling behind in reading. What do you do?" | CASE | [generic] | A live problem, so no claim about your past. Acknowledge the worry, find out what you know and what you do not, share a plan with a date to check back, and follow up. Tie it to "Families Are Partners" only as the district's belief, not as your history | F4 and the district's family belief make this scenario likely; generic because it is a pattern |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader. Tell me about a time you helped a student who was struggling to read." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: pick one student and a moment where something changed; say what you noticed, what you did and what was yours. The only place your material points is the reading club, so if the moment happened there, say so. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The first belief on the district's page; F3 supplies the quote |
| D2 | "Families Are Partners. Tell me about a time you worked with a family on something hard." | VAL | [grounded] "I write a weekly email to families" | Selection scaffold: pick a time that had a named stake, a conversation you carried, and a relationship intact at the end. The quote supports the weekly email only. Answer slot: if you spoke with the family directly, say how; if the contact was only the email, say so plainly. If no such time comes to mind, say so plainly, then give the email, or how you would handle it | F4 is the evidence and the likeliest place to be probed on "speaks with every family" |
| D3 | "Teach for Tomorrow, Not for the Test. Tell me about a time you changed what you were teaching because of what you learned about your students." | VAL | [grounded] "assessments inform teaching and never replace it" — Orrinsford beliefs page | Selection scaffold: pick one change with a named trigger, what you noticed, what you changed and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5 has no evidence; this is the third published belief |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey: how did you get here, and why fourth grade?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc, each beat one quoted sentence in your own words: six years teaching third grade in Joliet, then leading your grade level's move to a new reading curriculum in 2024, then the reading club, then the weekly email. End with your own reason for fourth grade (A5). Nothing is added between the beats | F2, F3 and F4 together make the arc; EXP because it tests whether the CV story holds as spoken |
| E2 | "Your license and endorsement are current, correct?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the quote's own terms and stop. Confirming your record before Thursday is yours to do; this pack has not checked it | F1 is a posted requirement and is asked casually; JD because it is the invite's stated condition |
| E3 | "What are your readers reading these days?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Name what the club has read recently if you can. Answer slot: if readers choose their own, say how; if there is no fixed approach, say so plainly. Casual questions on reading are scored | F3 is the reading evidence; EXP because it checks the club is real in the details |

### H. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "How do you know families read your weekly email?" | EXP | [grounded] "I write a weekly email to families" | Answer slot: if you have a signal, such as replies or conversations it started, say what you know; if you do not, say so plainly and say what you would look at. Do not state a response rate you have not measured | F4 is a claim with nothing counted behind it; EXP because it tests precision about what you know |
| H2 | "When you led the move to the new reading curriculum, how did you know it was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer slot: if there was a way you checked, say what and what it showed; if nobody checked, or it was not yours to check, say so plainly and return to the move as you described it in A2. Name the assumption you would defend least | F3 again, as a Prober would push it; EXP because it asks for the denominator behind the claim |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a teacher who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | Pause, restate the question, then hold: six years teaching third grade at a public elementary school in Joliet. Concede the one true gap in your own words: "I haven't taught fourth grade." Hold through two follow-ups without adding a claim to fill the space. Do not say you are better than the other teacher | F2 under time pressure; JD because it scores the same fit as A1, with composure as the real score |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold what the sentence says: you led your grade level's move. Answer slot: say which parts were yours, and which were set by others, in your own words. If it was a shared effort, say so plainly; if asked whether you have been a team lead, "I've never been a team lead," then return to the sentence | F3 and F8; EXP because attribution probes check inflation |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 License and endorsement | E2 |
| F2 Fourth-grade position | A1, A5, B4, G1 |
| F3 Every Child a Reader | A2, A4, C1, D1, E3, H2, G2 |
| F4 Families Are Partners | B3, C4, D2, H1 |
| F5 Assessments inform teaching | A3, D3 |
| F6 Core subjects across a fourth-grade day | C3 — role-family duty with no source for this posting, so one case covers it |
| F7 Classroom routines | C2 |
| F8 Work with the grade-level team | A2, B1, B2, G2 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| 1 | "Your 2025 talk was on weekly reading conferences in grades 3 to 5, and you were a reading specialist before becoming principal. How do those conferences run in fourth grade here, and what would you want a new teacher doing in the first month?" | Ties to her own path and published topic, and shows you researched her | [grounded] |
| 2 | "The board's literacy plan brings a new grades 3 to 5 reading curriculum in fall 2027. What is decided, and what do fourth-grade teachers get a say in?" | Shows you read the plan and asks about ownership | [grounded] |
| 3 | "What could a new person do in their first month that would genuinely help the fourth-grade team?" | The reciprocity question for the two teammates | [generic] |
| 4 | "The district says each teacher speaks with every family each term. What does a typical term look like for fourth-grade families?" | Ties to a published belief and clarifies expectations before you say how you would meet them | [grounded] |
| 5 | "What support would a teacher new to fourth grade get in the first year?" | Converts the main gap into a support conversation, and uses only what you have already said | [generic] |
| 6 | "What happens after today, and who would you contact for references?" | The district's hiring description says references come after the panel, so this is a practical close | [grounded] |

## Prohibited claims

What this pack will not coach, with its basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | Negative you stated, F2 | The plain acknowledgment: "I haven't taught fourth grade." Then F2's quote at its own scope |
| Has been a team lead, or ran the grade-level team | Negative you stated, F8 | The plain acknowledgment: "I've never been a team lead." The quote stays at "our grade level's move" |
| Chose or designed the new reading curriculum | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's own observation: your material says you led the move, not who chose the curriculum. A2's slot stays inside the move |
| Improved students' reading results through the curriculum or the club | Inflated form of F3 | F3's quotes at their own scope, which state the move and the club, not outcomes. H2 asks only how you would know |
| Speaks with every family each term | Inflated form of F4 | F4's quote at its own scope: a weekly email. The limit is the pack's observation: your material says the email, not conversations. D2's slot stays inside what you actually did |

## Sources

Provided documents: the interview invite and your CV text, both in your message.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

Searches sent, by query, and what came back:

1. "Orrinsford Community School District mission values" — returned https://orrinsfordschools.example/about/mission-and-beliefs
2. "Halvering Elementary School Orrinsford Community School District interview process fourth grade teacher" — returned https://orrinsfordschools.example/careers/how-we-hire-teachers
3. "Orrinsford Community School District strategic plan news" — returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
4. "Principal Dolores Vantongeren Halvering Elementary" — returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
5. "fourth grade teacher job posting Illinois elementary school requirements Professional Educator License" — returned https://k12jobsboard.example/listings/fourth-grade-teacher

Pages fetched: the Mission and Beliefs page and the principal's speaker page. The hiring description (2), the literacy plan article (3) and the representative listing (5) were used from their search-result text only; those pages were not opened, and the listing's qualifications line was cut off, so nothing from it is used.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. District values | yes | The three published beliefs, which theme the Values bank and rows F3, F4 and F5. No values-style round is documented, so there is no cheat-sheet section |
| 2. Interview process | yes | The hiring description matches your invite: one 45-minute building panel, with the principal and two grade-level teachers. Panel topics it names, reading instruction, classroom routines and families, shaped the Case bank. The invite alone fixes the panel structure |
| 3. Strategy and recent news | yes | The board's August 2026 literacy plan fed C1 and reverse questions 2 and 4 |
| 4. Interviewer name and company | yes | The principal's background and 2025 talk fed the interviewer read and reverse question 1 |
| 5. Representative role listing | yes | A listing's duties fed F6, F7 and F8 as `[generic]` rows; the listing came from a search result, not an opened page, so it raises no answer slot |

## Upgrade menu

- The posting text → F6, F7 and F8 become `[grounded]` rows with quoted requirements, and any extra requirement gets a question
- Anything HR said about a sample lesson, a teaching demo or something to bring → a build section for it
- The names and roles of the two fourth-grade teachers → a sharper peer read and reverse questions
- Something inspectable behind the 2024 curriculum move, such as a team memo or rollout plan, and one behind your license, which you would check yourself → F3 and F1 can move from medium
- Your answers to the answer slots in A1, A2, A3, D2 → the rows they touch are regenerated from your words
- Deeper research, up to 6 more searches and 2 more fetches, several more minutes → opens the three pages used only from snippets and adds district context
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and prohibited-claims constraints that this pack would build on
