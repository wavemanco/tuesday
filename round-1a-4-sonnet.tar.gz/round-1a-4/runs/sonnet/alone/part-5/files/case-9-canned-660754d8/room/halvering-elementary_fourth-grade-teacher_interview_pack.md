# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

- **Employer:** Halvering Elementary School, Orrinsford Community School District
- **Round:** one 45-minute panel on Thursday, per the invite
- **Panel:** Principal Dolores Vantongeren (read here as the hiring-manager seat) and two members of the fourth-grade team (names not given; read as peers)
- **Built on:** the invite and your résumé text; no posting was supplied, so two requirements come from a typical posting and are labeled `[inferred]`

## How to use this pack

Personas are how a question is asked; types are what it is scoring. The guidance is scaffolding for a spoken answer, not a script: say it in your own words, and say only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs, not general virtue |
| EXP | Whether the lines on your résumé survive follow-up; what was actually you |
| JD | The stated role and its requirements, including the gaps |
| CO | Homework on the school and district, and thinking at their altitude |
| CASE | A live problem from the actual job, reasoned aloud |

Answer slots in the guidance are instructions for the interview, not questions for you now. Where the pack observes that your material does not show something, that is the pack's analysis, not words for you to say.

## Prep triage (Thursday)

1. Say A1 aloud until it is boring: the plain sentence about fourth grade, the plain sentence about third grade, then your own plan. This is the highest-ROI prep in the pack.
2. Do E1 and A3 together: they are the same sentence, your grade level's move to a new reading curriculum, asked as a walkthrough and as a challenge.
3. Decide your true branch on the answer slots in D1, D2 and D3 (reading plans, family contact, assessment results). Write each branch down in your own words before Thursday.
4. Run F1 once as a 90-second arc.
5. Pick two reverse questions from R1 to R6.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | No gap on the quote's face: kind (Professional Educator License), issuer (Illinois), endorsement (Elementary Education, grades 1–6), status (registered and active) and expiry (June 30, 2029) are all in your own line, and its grade range includes fourth grade. Say it in those terms. Nothing was inspected behind a résumé line, so confirming that the registration shows active is yours to do before Thursday; this pack does not check it |
| F2 | "Fourth Grade Teacher position at Halvering Elementary School" — the invite | "I've never taught fourth grade and I've never been a team lead." — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then what you would do about it, said as a plan and never as a past. Nothing added to make the gap feel smaller; your third-grade years are F3's row, not a substitute for this one |
| F3 | Teach the core elementary subjects, as a typical fourth-grade posting lists them (search result, K12 Jobs Board) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | transferability | Your material says six years of third grade and does not say which subjects you taught, so the pack adds none. Words at that scope: "I've spent six years teaching third grade at a public elementary school in Joliet." A typical-posting row raises no probe of its own |
| F4 | "assessments inform teaching and never replace it" — Orrinsford Mission and Beliefs, third belief | none given | none | [grounded] | discovery | Your material does not show how you use assessment results. Answer slot: the district's third belief makes a probe on assessment and teaching likely. If results have changed what you taught, say what they were and what you changed, in your own words; if they have not, or that was not yours to decide, say so plainly and describe how you would go about it |
| F5 | "each teacher speaks with every family each term" — Orrinsford Mission and Beliefs, second belief | "I write a weekly email to families." — your CV | low | [grounded] | discovery | The quote is a weekly email, and the material does not show whether you are in touch with families beyond it. Answer slot: the district's second belief makes a probe on family contact likely. If you are in touch with families in other ways, say what they are, in your own words; if the email is the whole of it, or the rest was not yours, say so plainly and stay with the email: "I write a weekly email to families." |
| F6 | "no student leaves third grade without a reading plan" — Orrinsford Mission and Beliefs, first belief | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | low | [grounded] | discovery | The quotes carry a curriculum move and a reading club; they do not show what each student leaves with. Answer slot: the district's first belief makes a probe on reading plans likely. If students in your class left with a reading plan, say what it was and whose it was; if there was no such plan, or it was not yours, say so plainly and stay with what you stated: "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years." |
| F7 | Work with the grade-level team, as a typical fourth-grade posting lists it (search result, K12 Jobs Board) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never taught fourth grade and I've never been a team lead." — your CV | medium | [inferred] | transferability | The first quote is grade-level work, and the words stay at its scope: "I led our grade level's move to a new reading curriculum in 2024." It is not day-to-day teaming, and your CV says you have never been a team lead, so nothing here is worded as team leadership |

## Reading the interviewer

Public professional footprint only. The two fourth-grade team members are unnamed, so there is nothing to read for them.

| # | What is published | Source | What it means for you |
|---|---|---|---|
| I1 | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Illinois principals forum speaker page (fetched) | Reading instruction is her home ground. Expect probes at the level of practice, and expect to be heard on the difference between what you did and what you read about |
| I2 | A 2025 forum talk, "Small Groups, Big Readers," covering weekly reading conferences in grades 3 to 5 | Same page | Her topic spans the grade you teach and the grade you are applying for. If you propose small-group work or reading conferences, offer them as a plan, not as something you have done. See C3, R2 |
| I3 | Her talk covers grades 3 to 5 | Same page | Mirror opportunity: your quote "Six years teaching third grade at a public elementary school in Joliet." (F3) sits inside her grade band. State it plainly and let her draw the link |

## Persona table

Weights are a shown judgment: relationship priors first (principal as hiring manager, teammates as peers), then interviewer signals, then the loop. The invite fixes the loop as one 45-minute panel, so no archetype fallback is used.

| Persona | Seat in this panel | How it shows up | Likelihood, with reasoning | Counter-strategy | Bank |
|---|---|---|---|---|---|
| Skeptic | Principal | Quiet, persistent probing of the fourth-grade gap | Highest (5 questions). The invite's title is fourth grade and your own CV line says you have not taught it (F2); the hiring-manager prior is Case plus Skeptic | Rehearse A1 until it is boring: the plain sentence, the plain sentence, then a plan | A |
| Peer Evaluator | Fourth-grade teammates | What you would add to their load, where the seams are, how you handle disagreement and credit | High (4). The invite says two members of the fourth-grade team sit on the panel; the peer prior is Peer Evaluator plus Prober | Reciprocity: say what you offer before what you need, and keep "we" and "I" straight | B |
| Case/Strategist | Principal | Live problems from the actual job, in reading | Medium (3). The hiring-manager prior, tilted by I1 and I2 toward reading problems | Clarify, then structure, then think aloud; make no claim about your past | C |
| Values/Behavioral | Any member | Stories mapped to the district's three beliefs | Medium (3). The beliefs page says they "guide every hire." No dedicated values round is documented, so no cheat sheet is built, and the beliefs theme the questions instead | A story where one of your sentences carries one, a selection scaffold with an honest branch where none does | D |
| Data-Driven Prober | Teammates, principal | Reads your lines closely and asks how you know | Medium (3). The peer prior, and your curriculum move and reading club are the lines most open to a close read. Your material has no figures, so there is no defend-the-number question | Say what the sentence says, add only what you can repeat under a second question, and say plainly when you do not know | E |
| Conversational | Any member | Biography opener, a walk through your week, a licence confirmation | Lower (2 plus the licence confirmation). The invite does not say how the panel opens; I am treating a biography question as likely, not documented | A pre-built 90-second arc; treat casual questions as scored | F |
| Pressure | None signalled | Interruptions, time-boxing | Low, no bank. Nothing in the invite or the interviewer's public footprint points to it; A3 carries its hold-then-concede move | n/a | none |

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "This is a fourth-grade position and your experience is third grade. What do you expect to be your steepest learning curve?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead."; "Six years teaching third grade at a public elementary school in Joliet." | The highest-ROI rehearsal in this pack. Three beats, about 90 seconds. One: say it plainly, "I haven't taught fourth grade." Two: say what you have, "I've spent six years teaching third grade at a public elementary school in Joliet." Three: say, as a plan and never as a past, what you would do in your first weeks to find out what this grade asks of you; the plan is yours to write, the pack supplies none. Hold through two follow-ups on the same point by returning to beats one and two, never by adding to them. Concede specifically: you cannot say from experience what fourth grade asks of you | F2 is the one gap you stated and the invite's title makes it the likeliest objection, so the pack names it the highest-ROI prep. JD because it scores the stated position, delivered as a Skeptic |
| A2 | "Why Halvering, and why now?" | CO | [grounded] | Give your own reason for moving to fourth grade and for this school; the pack does not know it and supplies none. Two published facts you may anchor to, only if they are true for you: the district's three beliefs by name (Every Child a Reader, Families Are Partners, Teach for Tomorrow, Not for the Test) and the board's August 2026 literacy plan. Pick one, not a recital, and say why it matters to you in your own words. If neither connects, say so plainly and give the reason that is yours | The Skeptic's motivation probe, sharpened by what the research found; CO because it tests homework on this district. The fit-snapshot rows F4 to F6 show where the beliefs press on your material |
| A3 | "You led your grade level's move to a new reading curriculum. How much of that was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold on the sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024." Where they probe, say in your own words which parts were yours and, if others shared it, which were theirs; if you cannot separate them, say so plainly. Hold through two follow-ups by returning to the sentence, and concede only what is true, specifically. Do not lengthen the sentence to answer the challenge | The attribution probe aimed at your strongest line; a pressure-style hold-then-concede. EXP because it tests what was yours. Same sentence as E1 and F7 |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." | Your material supports one honest answer: the stated gap, "I haven't taught fourth grade." Name it first, before they do, then give A1's third beat as your plan. If something else is truly weaker for you, say that instead, in your own words; do not invent a weakness to sound modest | A1's neighbor in the Skeptic's stem; JD because it scores the role's demands against your gap (F2) |
| A5 | "What do fourth graders need from a teacher that third graders don't?" | JD | [generic] "I've never taught fourth grade and I've never been a team lead." | Say any view as a view, not as experience, since you have not taught fourth grade. A strong honest move is to say what you would want to find out and turn it into a question for the two teammates on the panel. The pack supplies no content about fourth grade | A pattern probe for bluffing; `[generic]` because it carries no fact about this school. JD because it scores knowledge of the grade, delivered as a Skeptic. See F2 |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How do you like to work with a team? Tell us what it looks like in practice." | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Peers price what you add to their load, so lead with what you offer. The one grade-level line you can say is "I led our grade level's move to a new reading curriculum in 2024," at that scope and no wider. Describe how you like to work in your own words; the pack knows none of it. Then turn to them and ask what the fourth-grade team already does together | The teaming requirement is `[inferred]` from a typical posting (F7); JD because it scores a stated expectation of the job, delivered as a peer |
| B2 | "What would you need from us in your first month?" | JD | [inferred] "I've never taught fourth grade and I've never been a team lead."; "I've run the after-school reading club for the last two years"; "I write a weekly email to families." | Reciprocity framing. Ask for what your gap makes honest, since "I haven't taught fourth grade," meaning what they would want you to see or learn first. Then offer what you already do, in the quotes' own words: "I've run the after-school reading club for the last two years" and "I write a weekly email to families." Let the team say whether any of it is useful to them, and offer nothing beyond those two lines | The peer stem about what a new person needs, answered with what you bring first; tied to F2 and F5 |
| B3 | "Tell me about a time you and a colleague saw something differently." | EXP | [generic] | Selection scaffold: pick a time with a named stake, what each of you wanted, and how it ended with the working relationship intact. Show spine and tact together: what you held to and what you gave. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer persona's disagreement stem; `[generic]` because no sentence of yours carries a story here. EXP because it asks for a real instance |
| B4 | "How do you handle credit when work spans a team?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use "we" for the grade level's work and "I" only for what your sentence says: "I led our grade level's move to a new reading curriculum in 2024." Name a colleague who contributed only if it is true. Do not widen the sentence to school or district level | The peer persona's credit stem, applied to your one team-level line (F7). EXP because it tests attribution |

### C. Case/Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It is your first two weeks with a new fourth-grade class. How would you find out where each child is as a reader?" | CASE | [grounded] | Clarify first: what the team already uses, what records come with the students, what the school expects and by when. Ask, do not assume. Then objective, approach, how what you learn changes what you teach, and risks, such as leaning on a single test. The district's third belief, assessments inform teaching and never replace it, gives you the closing line. Think aloud. The question needs no claim about your past, so the guidance makes none | A live problem from the district's own published belief (F4); CASE because it scores structure and clarifying |
| C2 | "The board adopted a literacy plan that includes a new grades 3–5 reading curriculum from fall 2027. What would you want to know about that, and how would you want to be part of it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The plan is public, so it proves homework and nothing more: name it once, then ask rather than recite, such as what the timeline is for fourth grade, who is involved, and what teachers get ahead of fall 2027. Say your own sentence at its scope, "I led our grade level's move to a new reading curriculum in 2024," and let them draw the link; do not say you would lead this one. The plan comes from a search result, so confirm it on the district's own page before Thursday | The current-strategy question the research made possible; CO because it tests altitude on the district's own plan. The quote is the only sentence of yours it leans on |
| C3 | "In October, one of your fourth graders is reading well below the rest of the class. Walk us through what you would do." | CASE | [generic] | Clarify first: what the data show and since when, what has been tried, what the child and the family say. Then what you would do in the room, how you would tell it is working, and who you would involve, including the team and the family. If you propose small-group work or one-to-one reading conferences, offer them as a plan, never as something you have done. The question needs no claim about your past, so the guidance makes none | A reading problem pitched to the principal's public focus (I1, I2); `[generic]` because the case is a pattern, not a fact about this school |

### D. Values/Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our first belief is that no student leaves third grade without a reading plan. Tell me about a time you worked out what one particular reader needed." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: pick one reader and one decision, with what you saw, what you tried and how you knew it helped. Answer slot: if students in your class left with a reading plan, say what it was and whose it was; if there was no such plan, or it was not yours, say so plainly. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the club in its own words, "I've run the after-school reading club for the last two years," or how you would go about it | The first published belief, asked of a third-grade teacher (F6). VAL because it scores a named belief |
| D2 | "You write a weekly email to families. Our second belief is that every teacher speaks with every family each term. Where does your family contact stand against that?" | VAL | [grounded] "I write a weekly email to families." | Start from the sentence: "I write a weekly email to families." Answer slot: if you are in touch with families in other ways, say what they are, in your own words; if the email is the whole of it, or the rest was not yours, say so plainly and stay with the email. Do not describe contact you did not have | The second published belief set against your one family-contact line (F5). VAL because it scores whether your practice meets a named belief |
| D3 | "Tell me about a time assessment results changed what you taught." | VAL | [grounded] | Selection scaffold: pick one result that surprised you, what you changed, and what happened. Your material shows no assessment work, so there is no story for the pack to map. Answer slot: if results have changed what you taught, say what they were and what you changed, in your own words; if they have not, or that was not yours to decide, say so plainly and describe how you would go about it | The third published belief (F4), where your material is silent. The honest branch is rehearsed here so it is ready before the probe. VAL because it scores a named belief |

### E. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through how you led your grade level's move to a new reading curriculum in 2024." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on the beats the sentence states and no more: the grade level, the move to a new reading curriculum, 2024. Tell them in your own words. Answer slot: the district's third belief makes a probe on how anyone knew the move was working likely. If any results showed what it changed, say what they were and what they showed; if none were used, or you do not know, say so plainly and return to the move itself | The curriculum move is the line most open to a close read, and the research makes assessment the likeliest direction of probe (F4, F7). EXP because it tests what was yours |
| E2 | "Looking back on that move, is there anything you would do differently?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Answer from what is true. If there is something, name it specifically and say what you would change; if there is nothing you would change, say so plainly rather than inventing a flaw to seem reflective. Add no event the sentence does not carry | The Prober's follow-up on the same sentence; EXP because it tests candor about your own work |
| E3 | "Tell us about the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Tell it from the sentence: an after-school reading club, run by you, for the last two years. Add a specific only if you can repeat it under a second question; the pack supplies none, such as who attends, what you read or what changed. Whatever second question comes, answer from what you know, or say plainly that you do not | A line read closely by teammates; EXP because it tests the claim. It carries the reading side of F6 |

### F. Conversational (weight 2, plus the licence confirmation)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell us about yourself and what brought you to this role." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families." | A 90-second arc built only from those four sentences, in your own words: the six years of third grade at a public elementary school in Joliet, then the grade level's move to a new reading curriculum in 2024, then the after-school reading club, then the weekly email to families. Close with your own reason for fourth grade and for Halvering, as in A2; the pack supplies none | The opener a panel is likely to use; treated as scored. EXP because it sets up every later probe, and the arc touches F3 and F6 |
| F2 | "Take us through a typical week in your classroom." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Your material says the grade and the years, not the week. Describe your week as it truly is, in your own words, and the pack supplies none of it. Say which subjects you teach; if some are shared or taught by others, say so plainly | The conversational way into the core-subjects requirement (F3); EXP because it asks what you actually do |
| F3 | "Can you confirm your licensure and endorsement status?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in your line's own terms: Illinois Professional Educator License, Elementary Education endorsement for grades 1–6, registered and active through June 30, 2029. Confirm the registration status before Thursday; the pack does not check it | The one requirement the invite states as a condition (F1). JD because it scores a stated requirement; expect a confirmation, not a probe |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Illinois licence with elementary endorsement | F3 |
| F2 Fourth Grade Teacher position | A1, A4, A5 (A2 for motivation) |
| F3 Core elementary subjects, typical posting | F1, F2 |
| F4 Assessments inform teaching | C1, D3, E1 |
| F5 Every family each term | D2 |
| F6 Reading plan for each student | D1, C3, E3 |
| F7 Grade-level team, typical posting | B1, B2, B4 |

Two things have no question, with reasons. There is no defend-the-number question because your material states no figures. There is no team-lead question because no raising source names a team-lead requirement; the stated negative is handled in the prohibited list.

## Reverse questions

| # | Question | Why it lands | Tied to |
|---|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. What from that work do you most want fourth-grade classrooms here to carry?" | It converts an interview into a conversation about her own path and shows you read it | I1 |
| R2 | "Your 2025 talk on small groups and weekly reading conferences covered grades 3 to 5. What does that look like in a fourth-grade day at Halvering?" | It shows you read her published work, and the answer tells you what the job's reading day contains | I2 |
| R3 | "With a new grades 3–5 reading curriculum coming in fall 2027, what is the timeline for fourth-grade teachers' involvement?" | It uses the board's public plan to ask a question you could not answer from the plan alone | C2 |
| R4 | "What could a new fourth-grade teacher do in the first month that would genuinely help your team?" | The reciprocity question for the two teammates: it shows you are pricing what you add, not only what you need | B2 |
| R5 | "How does the team put the belief that every teacher speaks with every family each term into practice?" | It shows you read the beliefs, and the answer tells you what family contact is expected | F5 |
| R6 | "What does a strong first year in fourth grade look like here, and who helps a new fourth-grade teacher get there?" | It addresses your one stated gap (F2) as a question about support, not as an apology | F2 |

## Prohibited claims

Built before the banks. Each entry has a basis and an honest form; no cell of this pack asserts, softens or implies any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F2 | Your sentence, "I've never taught fourth grade and I've never been a team lead." The plain acknowledgment from it: "I haven't taught fourth grade." Then a plan, said as a plan |
| Has been a team lead | A negative you stated, F2 | The same sentence. The plain acknowledgment from it: "I haven't been a team lead." Your team-level line stays at its scope: "I led our grade level's move to a new reading curriculum in 2024" |
| Led the move for the school or the district | Inflated form of F7's quote | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The limit is the pack's observation: your material says the grade level, not the school or the district |
| Chose or designed the new reading curriculum | Inflated form of F6's and F7's quote | The quote at its own scope. The limit is the pack's observation: your material says the move, not who chose the curriculum. The slots in A3 and E1 stay inside the move |

## Sources

**Provided documents:** the invite text and your résumé text, both pasted. A government-ID number in your message was not used and appears nowhere in the pack, and your licence number appears in no search. No dossier was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | Query "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs, which was fetched: three beliefs by name and definition. Moved the D bank, F4 to F6 and the slots they raise |
| 2. `Orrinsford interview process elementary teacher` | skipped | The invite fixes the loop: one 45-minute panel on Thursday with the principal and two fourth-grade team members. It decides the persona weights, so a search could not move them |
| 3. `Orrinsford Community School District strategy` / recent news | yes | Query "Orrinsford Community School District strategic plan" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan, a snippet only: an August 2026 three-year literacy plan with a new grades 3–5 reading curriculum from fall 2027. Query "Halvering Elementary School Orrinsford fourth grade" returned no results. Moved A2, C2 and R3 |
| 4. `Dolores Vantongeren Halvering Elementary` | yes | Query "Dolores Vantongeren principal Halvering Elementary" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren, which was fetched. Moved the interviewer read, C3, R1 and R2 |
| 5. representative `fourth grade teacher` posting | yes | Query "fourth grade teacher job description Illinois elementary school district posting" returned https://k12jobsboard.example/listings/fourth-grade-teacher, a snippet only and not this district's posting. Moved F3 and F7 as unquoted `[inferred]` requirements; nothing from it is quoted |

## Upgrade menu

- The full posting text → F3 and F7 become quoted `[grounded]` rows, and any requirement not covered gets a JD-tagged question
- The names and roles of the two fourth-grade teammates → per-member persona weights, an interviewer read for each, and a reverse question tied to each path
- Anything HR says about the format, such as a sample lesson or a writing exercise → a build section for each announced deliverable
- Your own answers to the slots in F4, F5, F6 and A3, stated outside a drill → those rows become quoted evidence and their guidance becomes story-mapped
- Any figure from the reading club or the curriculum move → a defend-the-number question, which has no material to stand on now
- The district's literacy-plan page read in full → C2 and R3 get specifics in place of a search snippet
- A tuesday-dossier.md from job-underwriter → verified evidence, per-gap strategy limits, and an evidence-derived objection in place of the inferred one in A1
