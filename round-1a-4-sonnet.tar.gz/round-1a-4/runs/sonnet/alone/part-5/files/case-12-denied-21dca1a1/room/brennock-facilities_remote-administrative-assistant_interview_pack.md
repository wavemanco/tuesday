# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Interviewer:** the office manager, name not given. **Format:** 30-minute video call, as your message gives it. **Built on this assumption:** the office manager would be your day-to-day manager, so the pack uses hiring-manager weights. If that is wrong, the weights below change.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether what you say about your work survives follow-up questions |
| JD | Whether you can do the listed duties, gaps included |
| CO | Whether you know the company and what it does |
| CASE | How you reason through a live problem from the job |

The guidance is scaffolding, not a script. Where a row quotes your own words, those words are the limit of what the guidance rests on. An answer slot is an instruction for the interview, not a question for you now. Meet it with whichever branch is true.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as your message gives it | "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | presentation | Reword only the quote: "I ran the appointment book for four physios." It says an appointment book, so the pack says nothing about meeting calendars or software. D1 rehearses the follow-up on it |
| F2 | "booking travel" — the ad, as your message gives it | none given | none | [grounded] | discovery | Your material does not show travel booking either way. Answer slot: if you have booked travel for anyone, say what and how, in your own words; if you have not, say so plainly, and say how you would find out the employer's booking process |
| F3 | "preparing documents in Word and Excel" — the ad, as your message gives it (Word half) | "I'm good with Word, okay with Excel" — your message | low | [grounded] | discovery | Use the Word half at its own scope: "I'm good with Word." That is a self-rating and nothing inspected sits behind it. Answer slot: expect a probe on what you have prepared; if you have prepared particular documents, name them; if you have not, say so plainly and return to your rating |
| F4 | "preparing documents in Word and Excel" — the ad, as your message gives it (Excel half) | "I'm good with Word, okay with Excel" — your message | low | [grounded] | discovery | Keep your own word: "I'm okay with Excel." Do not raise it. Answer slot: if there are things you have actually done in Excel, name them; if there are few or none, say so plainly and say what you would practise before a start date |
| F5 | "processing supplier invoices" — the ad, as your message gives it | "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | transferability | The quote says chasing unpaid invoices, which is not the same work as processing them, and the words stay at chasing: "I chased unpaid invoices." Answer slot: expect a probe on whose invoices those were, the clinic's to be paid or ones the clinic owed; say which, in your own words. If your work with invoices stopped at chasing, say so plainly and stay with that |

The requirements come from your description of the ad, not its full text. None of them is a gate: a term such as hours, pay, location or right to work. Your material also says nothing about any of those, so no gate row appears.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live work problem set in the duties: a double-booked slot, a travel request, an invoice that does not match | High. The hiring-manager prior puts it first, and every duty in the ad can be posed as a scenario. A 30-minute call leaves room for few, practical questions | Ask what you need to know first. Then state who decides, what you would do, and what you would record |
| Skeptic | Quiet probing of the thin rows: F2 travel, F4 Excel, F5 invoices | High. The hiring-manager prior puts it first, and F2, F4 and F5 are the rows where your material is thinnest | Rehearse the most likely objection (B1) until it is boring. Hold your own words, concede only what your material states, and give a plan for the rest |
| Conversational | A friendly opening ("tell me about the clinic") that is still scored | Medium. A short video call from an office manager probably opens this way, but nothing in your material says so | Prepare a 90-second arc built only from your own sentences. Treat casual questions on the four duties as scored |
| Data-Driven Prober | Follow-ups on your CV lines: how the book worked, how the invoices were chased | Medium. "Four physios" and "two years" are the figures a prober would press, and the job rests on Excel and invoices | Know what you can and cannot say about each figure, and say plainly when you do not know |
| Pressure | Interruptions, time-boxing, "how much of that was you" | Low. Nothing in your material suggests a stress style, and a short admin call rarely calls for one | Pause before answering. Hold your position through two follow-ups |
| Values / Behavioral | Scenarios mapped to the company's published values | Low. No values round is documented, and the search for the company's values was refused | Not banked. The selection scaffold in B5 covers motivation |
| Peer Evaluator | Seam-splitting between teams | Low. The interviewer is described as the office manager, not a peer | Not banked |

No loop source beyond your own words was available, so the weights rest on the hiring-manager prior and on the one session you described.

## Question banks

The highest-ROI prep in this pack is **B1**, the question on invoices. It is the likeliest place the interviewer finds the distance between your material and the ad, and a rehearsed, non-defensive answer changes the call.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two managers ask you for the same afternoon slot, one for a supplier meeting and one for a site visit. What do you do?" | CASE | [generic] | Structure it aloud: what you would ask first (which is fixed, and who is affected), who decides priority (not you), what you would offer each of them, and how you would confirm the outcome in writing. It needs no claim about your past, so the guidance makes none | The ad's "managing calendars" line (F1's requirement) posed as a decision. CASE because it scores structure, not history |
| A2 | "A director asks you to book a return trip to a client site and gives you only a destination. What do you need to know before you book anything?" | CASE | [generic] | Clarify before you act: dates and times, who is travelling, any budget or approval rule, how bookings are made here, and what the traveller needs sent back. Then say you would confirm the itinerary in writing and block the calendar. It makes no claim about your past | The ad's "booking travel" line (F2's requirement), asked without presupposing you have done it. CASE because the answer is a method |
| A3 | "A supplier invoice arrives with an amount that does not match what was ordered. What do you do?" | CASE | [generic] | Say what you would hold, whom you would ask, and what you would record: do not process it, check it against the order, ask the person who approved the order, and keep a note of what was agreed. If the matching step you are asked about is new to you, say so and ask what the company checks against. It makes no claim about your past | The ad's "processing supplier invoices" line (F5's requirement) as a live problem. CASE because it tests judgement and where you would stop and ask |
| A4 | "I am giving you a spreadsheet of this month's supplier invoices with amounts and due dates. How would you tell me which are overdue?" | CASE | [generic] | Clarify first (which columns, what today's date is, what counts as overdue). Then describe what you would do with the Excel you actually know, in your own terms, and say what you would look up rather than bluff. Finish with how you would report the result in plain words. It makes no claim about your past | The Excel half of the ad's "preparing documents in Word and Excel" line (F4's requirement), tested as a task. CASE with JD content, since the weakest point in F4 is the tool |
| A5 | "The director wants a one-page summary of this month's travel bookings by Friday, from rough notes. How do you go about it?" | CASE | [generic] | Ask who it is for and what decision it supports, what format or template to follow, and what the deadline allows. Then say how you would draft it, who reviews it, and how you would check the figures before it goes. It makes no claim about your past | The Word half of the ad's "preparing documents in Word and Excel" line (F3's requirement), posed as a task. CASE because the answer is a working method |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role involves processing supplier invoices. What have you done with invoices?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | The highest-ROI rehearsal in this pack. Your hold is only what the quote carries: "I chased unpaid invoices." Follow-up one will ask whose invoices they were. Answer slot: say which side of the invoice you were on, in your own words; if you handled invoices in any other way, say how; if your work with them stopped at chasing, say so plainly and stay with that. Follow-up two will press on processing. Hold by returning to what you did, and concede only what you have stated. Then give a plan, not a past: what you would want to learn first and whom you would ask | F5 is the row where the ad's duty is furthest from your words, so this probe arrives in some form. JD because it scores a stated duty, with EXP delivery |
| B2 | "How would you rate your Excel, and what would you need to get up to speed?" | JD | [grounded] "I'm good with Word, okay with Excel" | Use your own rating in your own words and do not upgrade it: "I'm okay with Excel." Answer slot: if there are things you have actually done in it, name them; if there are few or none, say so plainly, and name what you would practise before you start. Hold your rating through two follow-ups and concede the specifics you do not know | F4's thin row, asked directly. JD because it scores a listed tool; the guidance keeps your rating at its own scope |
| B3 | "You have been a receptionist. What makes you ready to be someone's administrative assistant?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Describe what you did, in the quote's own terms: two years as a receptionist, the appointment book for four physios, chasing unpaid invoices. Let the interviewer draw the inference. Answer slot: if you have done anything beyond reception, say what; if you have not, say so plainly and name the duty in the ad you would most want help learning first | The hiring-manager prior puts the background gap first. F1 and F5 are the rows the answer draws on. JD because it scores fit to the listed duties |
| B4 | "Have you booked travel for anyone?" | JD | [grounded] | Answer slot: if you have, say for whom and how, in your own words; if you have not, say so plainly, then say how you would learn the employer's booking process. The material does not show either answer, so the guidance makes no claim | F2 is blank in your material, so the question is likely to arrive as a yes-or-no. JD because it scores a listed duty |
| B5 | "Why this role, and why working remotely?" | JD | [generic] | Selection scaffold: pick one reason tied to the duties in the ad and one tied to working remotely, each of which you would say with a straight face. If no reason comes to mind that you can stand behind, say so plainly, then talk about the part of the ad's duties you would most like to do. It makes no claim about your past | A motivation probe that skeptics use to test consistency. JD with motivation delivery, since the answer must tie to the listed role |

### C. Conversational (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, tell me about the clinic and what you did there." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | A 90-second arc with only the beats the quote states: two years, receptionist, a physiotherapy clinic, the appointment book you ran for four physios, and the unpaid invoices you chased. Tell it in your own words and stop at those facts. Let the interviewer connect it to the ad | The usual friendly opener, and a scored one. F1 and F5 are what it draws on. EXP because it checks that your account matches your CV |
| C2 | "Which part of this job would you feel most at home with: calendars, travel, documents or invoices?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Pick the one your own sentence supports and say why in your own words. The quote supports the appointment book most directly. Then say honestly which duty you would want most help with | An open choice that lets the interviewer see whether your self-assessment matches your material. JD because it ranks the listed duties |
| C3 | "How do you keep yourself organised when you are working on your own from home?" | JD | [generic] | Selection scaffold: pick a real habit or routine you use now. If you have no remote routine to point to, say so plainly, and say what you would set up in your first week. It makes no claim about your past | The role is remote, so the interviewer will ask how you work unsupervised. JD with a rapport register, since it is asked casually |
| C4 | "What do you know about what we do?" | CO | [generic] | Say what the ad and the invite tell you, and say plainly that you have not found more. Then ask the office manager to describe the team and what a typical week looks like. Do not guess at what the company does | Company search was refused in this session, so the pack cannot ground this answer; it stays a pattern. CO because it tests homework |

### D. Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how you ran the appointment book for four physios, day to day." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Start from the quote: you ran the appointment book for four physios. Answer slot: expect follow-ups on the day-to-day of the book; say what you actually did, in your own words. If part of it was someone else's, or there was no such step, say so plainly and return to "I ran the appointment book for four physios." | F1 is where the ad's "managing calendars" duty draws its evidence, so this is the likeliest follow-up. EXP because it checks what was yours |
| D2 | "Four physios over two years. How much of that book was yours alone?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | The defend-the-number move on "four physios". Answer slot: say how the number was counted, whether it held for the whole two years, the part you would defend least, and which part was yours, each in your own words; if you do not know, say so plainly | The attribution probe on F1's headline figure. EXP because it scores what was actually the candidate's |
| D3 | "Tell me about the unpaid invoices you chased. How did that work?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic, where I ran the appointment book for four physios and chased unpaid invoices" | Start from the quote: you chased unpaid invoices. Answer slot: expect follow-ups on how many, how old, and how you chose whom to chase first; if you kept a list or followed a routine, say how, in your own words; if there was no routine, say so plainly and return to "I chased unpaid invoices." Do not state a figure you cannot back | F5's only evidence, so it draws the most pressure. EXP because it checks the line against what you actually did |
| D4 | "What documents have you prepared in Word?" | JD | [grounded] "I'm good with Word, okay with Excel" | Start from your own rating: "I'm good with Word." Answer slot: name the documents you have actually prepared; if there are none to name, say so plainly and return to the rating | F3's thin row, asked as a request for examples. JD because it scores a listed tool |

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "managing calendars" | A1, C2, D1, D2 |
| "booking travel" | A2, B4 |
| "preparing documents in Word and Excel" | A4, A5, B2, D4 |
| "processing supplier invoices" | A3, B1, D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a typical week look like for this role, and what would you want it to have achieved by the end of the first month?" | It ties to the four duties in the ad and shows you are thinking about doing the work |
| 2 | "Which of the four duties takes up most of the week?" | The answer tells you where to practise, and it shows you take the listed duties seriously |
| 3 | "Whose calendars would I be managing, and which tools does the team use?" | It signals that you plan to learn their systems rather than assume yours |
| 4 | "How do supplier invoices reach this role, and who approves them?" | It shows respect for approval and control around invoices, which matters given F5 |
| 5 | "How will I get feedback in the first three months?" | It signals you want to be corrected early, which counters a thin-evidence row |
| 6 | "What happens after this call, and is there anything I should prepare for it?" | A process question with a prep reason: it tells you whether another step follows and what to get ready |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for an office or for senior staff | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: the material says an appointment book, not an office calendar |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: the material says chasing, not processing. B1's slot stays inside the quote's scope |
| Advanced or expert Excel | Contradicted by your own words in F4 | Your quote alone: "okay with Excel" |

## Sources

Provided documents: your message, which holds the invite's text, your description of the ad's duties, and your background.

Searches sent, all refused, none returned a result:

- `Brennock Facilities Ltd company values` — refused
- `Brennock Facilities Ltd interview process remote administrative assistant` — refused
- `Brennock Facilities Ltd news strategy` — refused

No page was fetched. No dossier was consumed.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | The call was refused. It would have fed a values cheat sheet, which is not included because no values round is detected |
| 2. `{company} interview process {role family}` | unavailable | The call was refused. It would have named the loop. The session you described fixes this call's persona weights, so they stand on the hiring-manager prior |
| 3. `{company} strategy` / recent news | unavailable | The call was refused. It would have grounded C4, which stays `[generic]` |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form. The interviewer read is absent |
| 5. representative `{role title}` JD | skipped | Your description of the ad's duties fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → the five requirement quotes become the ad's own words, and any duty your description left out gets a row and a question
- Your CV → F1 to F5 can quote a CV line, and a CV line on travel, Excel or invoices could change a row's confidence or gap type
- A sample you made in Word or Excel, anonymised → F3 and F4 could rise from `low`, because a document you prepared is something that can be inspected
- Answers to the answer slots in F2, F3, F4 and F5, stated outside a drill → each row regenerates from your own words
- The office manager's name → a tailored reverse question, and persona weights read from their public footprint
- Anything written that says what the call will cover → coverage of any announced topic or task
- A search-enabled session → L1 research on values, loop structure and recent news would replace the `[generic]` guidance on C4; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a company brief
- A `tuesday-dossier.md` from an earlier session → the evidence rows would start from verified claims and the prohibited list from recorded limits
