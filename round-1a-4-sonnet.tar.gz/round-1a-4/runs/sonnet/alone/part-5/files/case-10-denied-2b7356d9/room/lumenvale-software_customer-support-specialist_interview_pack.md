# Interview pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (name not given), in a text chat. Built on the assumption that this is a hiring-manager-type round, since the team lead's relationship to the role was not stated.

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did. Answer slots (lines starting "Answer slot") are instructions for the interview, not questions for you to answer here.

| Type | Meaning |
|---|---|
| VAL | Behaviour against the company's published values (none used in this pack: no values source was available) |
| EXP | Whether a claim about your past survives scrutiny |
| JD | A stated requirement from the ad |
| CO | What you know about the company |
| CASE | A live problem from the actual job |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as you listed it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap in the terms, but a self-reported line with nothing inspected behind it, so expect a probe. Lead with your own words: "3 years as a customer service advisor at an energy supplier." C1 rehearses the figure |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Say the tool you used: "I use Freshdesk every day." Your material names Freshdesk, not Zendesk, so Zendesk stays out of your answers. Expect a probe on what you do in it; B4 and D2 rehearse it |
| F3 | "clear written communication" — the job ad, as you listed it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are in the sentence; whether your written replies were clear is not. Answer slot: the ad's line makes a probe likely, and this interview is itself written. If you have a concrete sign your written replies worked, name it; if you have none, say so plainly and say how you would approach a reply here |
| F4 | "confidence handling escalations" — the job ad, as you listed it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: if you have handled a case that went beyond what you could resolve yourself, say what it was and what part was yours; if you have not, or it was passed on without you, say so plainly and say how you would handle one |
| F5 | Supporting a software company's customers and product (role-family, no ad line) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn it, said as a plan and never as a past. The nearest material at its own scope is F2 |
| F6 | Experience you listed that no ad line raises | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Keep it at its scope: four new starters, the refunds process, last year. Expect an attribution probe (E2). Nothing in your material says how the training was structured or how long it ran |

## Persona table

The loop, from the invite's own wording, is one session: a text chat with the support team lead. No other loop source was available, so the weights rest on the relationship prior for a hiring manager, adjusted for the text format.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A Case / Strategist | Live support problems: an angry customer, an escalation, a queue | 5 questions: a hiring manager buys capability on the actual job, and F4 and F3 have nothing in your material to stand on, so live problems are where they get tested | Clarify first, then structure, then answer; think aloud; write each answer as you would send it |
| B Skeptic | Quiet probing of the software gap, escalations and written communication | 5 questions: F5 is a gap you have stated and F4 is silent, which is where a team lead derisks | Rehearse B1 until it is boring; stay inside what your quotes carry; state the limit before it is asked |
| C Data-Driven Prober | Digs into the daily-volume figure and the training claim | 3 questions: the figure in F1 and the claim in F6 are the checkable items on your list | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| D Conversational | Friendly openers: the journey, what you like about the tools | 3 questions: a chat format tends to open casually, and casual questions are still scored | Short messages; a prepared arc for the journey question |
| E Pressure | Time-boxed challenge: why you over someone from software | 2 questions: a text chat gives less room to interrupt, so this persona is the least likely | Pause before replying; hold the claim your quotes carry; concede one thing specifically |

## Question banks

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem and says they want to cancel. Walk me through your next ten minutes." | CASE | [generic] | Structure it aloud: what you would check first, what you would say to the customer now, what you would settle yourself and what you would pass on and to whom, and what you would record. Ask what the team's own rules are rather than guessing them. The question needs no claim about your past, so the guidance makes none | A live problem from the ad's escalation line (F4's requirement), asked as a decision. CASE because it scores structure and judgment under a realistic load |
| A2 | "A customer sends one long, angry message that mixes three different problems. Write me the reply." | CASE | [generic] | Write it as you would send it: acknowledge in one line, separate the three problems, give one next step for each, and say what the customer can expect next. Plain words, short sentences. The question needs no claim about your past, so the guidance makes none | The ad's written-communication line (F3's requirement) asked as a live task, which suits a text chat. CASE with JD content: the reply itself is the evidence |
| A3 | "When would you pass a ticket to someone else, and what goes in the handover so they do not have to ask the customer again?" | CASE | [generic] | Give your criteria as reasoning: what is beyond what you can settle yourself, what needs someone with more authority, what the customer has asked for. Then the handover: what happened, what has been tried, what the customer expects and by when. Ask what the team's escalation route is | The ad's escalation line (F4's requirement) as a decision rather than a record. CASE because it scores how you reason and communicate a handover |
| A4 | "It is Monday morning, there are 200 open tickets and two people are off sick. How do you decide what to answer first?" | CASE | [generic] | Clarify first: what the response targets and priority levels are. Then your ordering logic: urgency, impact, age. Think aloud and name one trade-off you would accept. The question needs no claim about your past, so the guidance makes none | Tests the ad's ticketing-tool line (F2's requirement) through the work a ticketing tool organises. CASE because it scores prioritising under pressure |
| A5 | "What do you know about our product and our customers?" | CO | [generic] | No verified facts about Lumenvale were available to this pack, so none are given here. Answer slot: say what you found in your own reading of the company's website, in your own words; if you have not looked, say so plainly and say what you would look for first | A team lead hiring a person new to software will want to see whether you did any homework. CO because it scores company knowledge; this pack could not ground it, so it stays generic |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have worked in energy, not software. Why would you be effective supporting software customers?" | JD | [grounded] "I've never worked for a software company" and "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" and "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Open with the limit before it is pressed: "I've never worked for a software company." Then hold only what your quotes carry: three years as a customer service advisor at an energy supplier, answering calls and emails, and using Freshdesk every day. Then a plan, said as a plan: what you would do to learn the product. Follow-up one, "How is that different from what you have done": say you cannot compare from experience, and return to the quotes. Follow-up two, "Why take the risk on you": hold the same quotes, concede the product knowledge is yet to be built, and do not widen what the quotes say | F5 is the stated gap and the likeliest first challenge from a team lead. JD because it scores fit to the role as posted, with the limit named before it is asked |
| B2 | "Tell me about a time a customer's issue went beyond what you could resolve on your own." | JD | [grounded] | Selection scaffold, since no sentence of yours carries an escalation. Pick a time with a named stake, what you did, who you handed it to if anyone, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The ad's escalation line (F4) is the raising source, and your material is silent on it. JD because it scores that requirement, including the gap |
| B3 | "The ad asks for clear written communication. What evidence do you have of that?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | The sentence carries emails at its own scope: you answered them. Answer slot: if you have a concrete sign your written replies worked, name it, in your own words; if you have none, say so plainly and say how you would approach a reply here. This chat is itself a sample, so write every message as you would a customer reply | F3 is thin: emails are in the sentence, clarity is not. JD because it scores the stated requirement |
| B4 | "The ad says Zendesk or similar. Your tool is Freshdesk. How would you get up to speed on ours?" | JD | [grounded] "I use Freshdesk every day" | Say it as stated: "I use Freshdesk every day." Do not say it is the same as theirs, and do not claim to know their tool. Then the plan, as a plan: ask what they use and how the team sets it up, and what you would learn first | F2 matches the ad's wording "or similar" but names a different tool, so this is the natural probe. JD because it scores a stated requirement |
| B5 | "Why customer support, why a software company, and why now?" | EXP | [generic] | Answer slot: give your actual reason for the move, in your own words; this pack has none of yours and supplies none. Keep it to what is true for you and tie it to the job's own content | The Skeptic's standard motivation probe, sharpened by F5. EXP because it scores whether your story holds together |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Keep your own word, "around". Answer slot: say how you know the figure, what it moves with, and which assumption in it you would defend least; if you do not know how it was counted, say so plainly. Do not turn it into an exact number or a calls-versus-emails split you do not have | F1's figure is the item on your list a prober checks first. EXP because it scores whether you know your own number |
| C2 | "Walk me through training the four new starters on refunds." | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats the sentence states: four new starters, the refunds process, last year, and that you trained them. Answer slot: if any part of how it ran was yours to set, say what and why; if it was set by someone else, or was informal, say so plainly and describe what you did. Do not call it a programme or say you led it | F6 is a claim a prober can test for attribution. EXP because it scores what was actually yours |
| C3 | "How did you know your replies were good? Did you see any numbers or feedback?" | EXP | [generic] | Answer slot: if you saw a measure or feedback on your replies, name it as it was, in your own words; if you saw none, say so plainly and say how you would want to know. No figure is supplied here | Probes F3 and F1 together from the prober's side. EXP because it scores whether you know what your work achieved |

### D. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get from energy customer service to applying here?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Tell it in a few short messages. The part your quote carries: three years, customer service advisor, an energy supplier, calls and emails. The step to this role is where your reason goes. Answer slot: your actual reason, in your own words; none is supplied here | A casual opener that is still scored. EXP because it checks your story against your own quote |
| D2 | "What do you actually use a ticketing tool for day to day?" | JD | [grounded] "I use Freshdesk every day" | Start from "I use Freshdesk every day." Answer slot: say what you actually do in it that matters to you; if there is something you have not used, say so plainly. Nothing is added to your sentence here | A casual question about the ad's plus-skill (F2). JD because it scores that requirement |
| D3 | "Which part of the ad sounds most like what you already do?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" and "I use Freshdesk every day" | Answer from your quotes, in your own words: the three years of customer service and the daily Freshdesk use. Stop there; do not add duties the ad lists that your quotes do not show | Invites you to pick your strongest rows (F1, F2). JD because it scores self-assessment against the ad |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already works in software support?" | JD | [grounded] "I've never worked for a software company" and "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" and "I use Freshdesk every day" | Hold then concede. Hold: the three years of calls and emails, and daily Freshdesk use. Concede one thing specifically: "I've never worked for a software company." Hold through two follow-ups by returning to the quotes, never by adding to them. Do not claim to be better than people you do not know | The Pressure form of F5. JD because it scores the gap, with composure as the real test |
| E2 | "That training you gave. How much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold: "I trained four new starters on our refunds process last year." Answer slot: if anyone else set the content or did part of it, say who and which part; if not, say so plainly. Concede only what is true, specifically, and do not fold on the sentence itself | The stock attribution challenge applied to F6. EXP because it scores how precisely you attribute |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 "2+ years in customer support" | C1, D1, D3 |
| F2 "experience with Zendesk or a similar ticketing tool" | A4, B4, D2, D3 |
| F3 "clear written communication" | A2, B3, C3 |
| F4 "confidence handling escalations" | A1, A3, B2 |
| F5 software company gap | A5, B1, B5, E1 |
| F6 training claim | C2, E2 |

Highest-ROI prep: B1, the software-company gap, because it will be asked in some form and your answer is stronger when the limit comes first.

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does a good first month look like for someone new to your tools and product?" | Shows you are planning your ramp, which answers B1 before it is pressed |
| "Which kinds of tickets does the team escalate, and who takes them?" | Ties to the ad's escalation line and shows you think about handovers |
| "How does the team tell whether support is going well: which numbers or feedback do you look at?" | Shows you care how the work is scored; useful given C3 |
| "After this chat, what comes next, and in what format, for example a call or video?" | Lets you prepare for the next step, and shows you are planning ahead |
| "What do people who do well here in the first three months tend to do differently?" | Invites the lead to describe their own bar, which you can then work to |
| "What is hardest about supporting your customers right now?" | Gets you real material for any follow-up and signals genuine interest |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2 | "I use Freshdesk every day." The limit is the pack's observation: your material names Freshdesk, not Zendesk |
| Experience supporting software customers or products | Negative you stated, F5 | The plain acknowledgment: "I've never worked for a software company." Then a plan, said as a plan |
| Led, designed or ran a training programme | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year" |
| An exact daily volume, or a calls-versus-emails split | Inflated form of F1 | F1's quote with its own word: "around 60 calls and emails a day" |
| Strong written communication, shown by email volume | Inflated form of F3 | F3's quote at its own scope; the pack's observation is that volume does not show clarity. B3's slot stays inside the quote |

## Sources

Provided: your message, containing the invite text, the four ad requirements as you listed them, and your background. No CV or full job ad text was supplied.

Searches sent:

- "Lumenvale Software company values" — refused
- "Lumenvale Software interview process Customer Support Specialist" — refused

Research tier: L1 — searches 2 of 6 sent, both refused; fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software company values | unavailable | Would have fed a values sheet and VAL questions; none is in this pack, and no values-style round is detected |
| 2. Lumenvale Software interview process, support role | unavailable | Would have named further rounds; the loop here rests on the invite's own wording, one text chat with the support team lead |
| 3. Lumenvale Software strategy and recent news | unavailable | No call was sent because search was refused; would have grounded A5, which stays generic |
| 4. Interviewer name and company | n/a | The interviewer is unnamed, so there was no query to form; there is no interviewer read |
| 5. Representative Customer Support Specialist JD | skipped | The four requirements you listed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → the four requirement rows become the ad's own words and JD-tagged questions gain further requirements
- Lumenvale's own values, product or process material, pasted → A5 and a values sheet could be grounded instead of generic
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → grounded strategy and role-family loop material, offered once
- The support team lead's name → an interviewer read and a reverse question tied to their path
- An example of a written reply or feedback you received, and an escalation you handled, if you have them → rows F3 and F4 move from discovery to grounded
- A reference or employment letter confirming your dates and role → raises F1 from medium to high
- Any note from the recruiter on topics or format, and your available prep time → coverage assumed from round-type priors becomes specific, and a prep triage can be added
- A `tuesday-dossier.md`, if you have one → verified evidence and prohibited claims arrive pre-graded; never required
