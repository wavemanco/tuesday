# Interview prep pack: Customer Support Specialist, Lumenvale Software

**Role:** Customer Support Specialist (remote), Lumenvale Software
**Interviewer:** your support team lead, name not given. **Format:** a text chat, per your message.
**Built on one assumption:** the team lead is the person you would report to, so persona weights follow the hiring-manager prior. If that is wrong, the weights change (see the upgrade menu).

## How to use this pack

- **Personas are how a question arrives. Types are what it scores.** Every question carries one persona (its bank letter) and one type tag.
- Type tags: **VAL** = does past behavior show good customer judgment; **EXP** = do your own claims survive a follow-up; **JD** = can you do the job as the ad describes it, gaps included; **CO** = do you know the company; **CASE** = a live problem from the role, scored on structure.
- The guidance is scaffolding, not a script. Say it in your own words. An **answer slot** is an instruction for the interview, not a question for you now: answer from what really happened, and if it did not happen, say so plainly.
- Provenance: `[grounded]` rests on something you wrote, `[inferred]` is this pack's derivation, `[generic]` is a pattern with no claim about you or Lumenvale. Where a question rests on your words, they are quoted beside the label.
- **Highest-ROI prep in this pack: A2.** The software gap is the objection you stated yourself, and it will arrive in some form. Rehearse it until it is boring.

## Fit snapshot

The ad's requirements are quoted as you listed them in your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you listed it | "3 years as a customer service advisor at an energy supplier" — your message; "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | The three years meet the number, but this is a self-reported line with nothing inspected behind it, so expect a probe. Say it in the quote's own terms: three years, customer service advisor, energy supplier. Keep your title as it is rather than renaming it. The training line is a separate sentence; keep it at its scope: four new starters, the refunds process, last year. Do not turn it into a training role or a programme |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Name the tool you use, as it stands: "I use Freshdesk every day." The ad names Zendesk and your material says Freshdesk, so say nothing about Zendesk. Expect a probe on what you actually do in the tool (C3) |
| F3 | "clear written communication" — job ad, as you listed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | This line says you answered emails, not that they were clear, and it does not split calls from emails; the figure stays attached to both. Answer slot: the ad's line makes a probe on your written replies likely. If you have a way of making sure a reply is clear, say what it is in your own words; if you had none, or it was not yours to set, say so plainly and stay with the emails you answered. The pack also observes that this interview is itself a written exchange, so your messages in it are a sample |
| F4 | "confidence handling escalations" — job ad, as you listed it | none given | none | [grounded] | discovery | Your material says nothing either way about escalations, so the pack writes no escalation claim for you. Answer slot: expect a probe. If you have handled escalations, say what the situation was, where it went and what part was yours, in your own words; if escalating was someone else's job, or there was no such step, say so plainly and say how you would handle one |
| F5 | Experience at a software company (not in the ad as you listed it; a likely probe) | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Your words: "I've never worked for a software company." Then a plan in the future tense: what you would learn first about the product and how you would find out, in your own words. No claim about software or products you haven't used, and nothing added to make the gap feel smaller |

### Requirement coverage

| Requirement | Covered by | 
|---|---|
| "2+ years in customer support" (F1) | A3, D1 |
| "experience with Zendesk or a similar ticketing tool" (F2) | C3, A2 |
| "clear written communication" (F3) | A5, B1, B5 |
| "confidence handling escalations" (F4) | A4, B2, B3 |
| Software-company gap (F5, not in the ad as listed) | A1, A2, B3, E1 |
| The figure "around 60 calls and emails a day" | C1, C2 |
| The training line (F1) | E2, D1 |

## Persona table

| Persona | How it shows up in a text chat | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet, persistent follow-ups on the gaps: software, escalations, written clarity | High. Your interviewer is the support team lead (your message), so the hiring-manager prior applies, and F5 is a gap you stated yourself | Rehearse A2 until it is boring. Hold only what your quotes carry and concede the limit specifically |
| Case / Strategist (bank B, 5 questions) | A live ticket or customer message, possibly one to answer in writing on the spot | High. Same prior; a text chat also makes a live writing task easy to set (B5) | Clarify, then structure, then answer. Say what you would check first and who owns what |
| Data-Driven Prober (bank C, 3 questions) | Pulls apart the one figure you gave | Medium. F3 holds a headline figure, but the prior for this round is lower | Know what you can and cannot say about how it was counted; say plainly where you do not know |
| Conversational / Rapport Builder (bank D, 3 questions) | A friendly opener, then casual questions that are still scored | Medium. It is the pack's judgment that the chat opens with your background, so D1 is prepared | A short arc from your own sentences; treat casual questions as scored |
| Pressure (bank E, 2 questions) | Time-boxes you or asks how much was actually you | Low. No signal points to it; included so you do not meet the style for the first time live | Pause, restate, hold through two follow-ups, concede only what is true |
| Values / Behavioral (bank G, 2 questions) | "Tell me about a time" scenarios about customers | Low. No published Lumenvale values were in hand and your message names no values round, so these use standard stems only | Pick a real instance or say plainly that none comes to mind |

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would be weakest for you on day one?" | JD | [grounded] "I've never worked for a software company" | Say the limit first, in your words: "I've never worked for a software company." Then the plan, in the future tense and in your own words: what you would learn first about the product and how you would find it out. Make no claim about software or products you haven't used | F5 is the one gap you stated yourself, so a weakest-part question lands there. JD because it tests what day one demands |
| A2 | "I don't see software in your background. How would you handle supporting customers of a software product?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Concede the limit early and specifically: "I've never worked for a software company." Follow-up one, "what do you actually do in the tool": return to "I use Freshdesk every day" and C3's slot. Follow-up two, "software customers are different": agree you would have a product to learn, give the plan from A1, and return to the three years without adding to them. Never claim product knowledge you do not have | F5 is the likeliest objection to this candidate, so it gets the most follow-up levels. JD because it scores the fit between the ad and F1, F2 and F5 together |
| A3 | "The ad asks for two years or more in customer support. Walk me through your three years." | JD | [grounded] "3 years as a customer service advisor at an energy supplier" | Tell the beats the quote states, in your own words: three years, customer service advisor, an energy supplier. Say your title as it is. Then stop and let them ask; the quote carries no more beats, so do not invent a middle for the story | F1 is the evidence for the experience requirement and the opening line of any probe on it. JD because it scores a stated requirement |
| A4 | "Tell me about a time you handled an escalation." | JD | [grounded] "answering around 60 calls and emails a day" | A selection scaffold, because your material carries no escalation sentence. Pick a case where the issue went past what you could resolve, or the customer wanted someone more senior. It needs: what the customer wanted, what you did, where it went, how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "answering around 60 calls and emails a day", or how you would handle one | The ad's escalation line makes this open prompt near-certain; F4 is the row with no evidence. JD because it scores a stated requirement |
| A5 | "The role is mostly writing. How do you make sure a written reply is clear to a frustrated customer?" | JD | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you have a way of checking a reply before it goes, say what it is, in your own words; if you had none, or it was not yours to set, say so plainly and stay with the emails you answered. Keep the figure attached to both nouns: calls and emails | F3 is the evidence for the written-communication requirement and it is thin. JD because it scores that line of the ad |

### Bank B: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in for the third time about the same unresolved problem, and the tone is angry. What do you send?" | CASE | [generic] | Read the history first so you do not ask for what they already gave. Acknowledge the repeat in one sentence without defending. Say what happens next and who owns it; promise only what you control. One clear ask if you need information. Record it. The case needs no claim about your past, so the guidance makes none | A live problem from the ad's written-communication and escalation lines (F3 and F4). CASE because it scores structure, not history |
| B2 | "A customer asks for a refund the policy does not allow. Walk me through your reply." | CASE | [generic] | Check the policy and the account first. Say what you can do, not only what you cannot. Do not promise an exception you cannot give; if there is an exception route, name who decides and what the customer should expect. Record the decision and the reason. The guidance makes no claim about your past | Tests F4's escalation requirement through a decision rather than a story. CASE because the policy limit is the problem |
| B3 | "A customer says the product lost their saved work and they have a deadline today. What do you do?" | CASE | [generic] | Do not guess a cause. Gather the facts one message at a time: what they saw, when, what they have tried. Give an honest expectation. Hand it to whoever owns product problems with a note, so the customer does not repeat themselves, and tell the customer what happens next. If you do not know who owns it, say you would find out first | Lets you show reasoning on the F5 gap without claiming product knowledge. CASE because it is a live problem set in the role |
| B4 | "You have thirty tickets waiting and three are urgent, one from an angry customer. How do you decide the order?" | CASE | [generic] | Clarify first: what the team's target response times are, and what urgent means here. Then order by impact and deadline, take quick wins between, and tell waiting customers what to expect. Say your reasoning aloud. The guidance makes no claim about your past | A prioritization problem from the role's daily shape. CASE because structure is what is scored |
| B5 | "Here is a customer message: 'The app keeps crashing and I want my money back!!' Write your first reply now." | CASE | [generic] | Short and plain: acknowledge in one sentence, ask one question or name one thing you can do now, say what happens next, promise nothing you cannot give. Read it once before sending. The guidance makes no claim about your past | F3's requirement tested live, in the medium you are already using. CASE with JD content, since it scores the ad's written-communication line |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: say how the figure was counted, in your own words; if you do not know how it was counted, say so plainly. Name the assumption behind it you would defend least before they do, and say which part of that volume was yours. "Around" signals an estimate, so say it is one. Keep the figure on both nouns | F3's figure is the number a prober goes to first. EXP because it tests whether the claim survives |
| C2 | "How many of those sixty were emails and how many were calls?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: if you know the split, say it; if you do not, say so plainly and stay with "around 60 calls and emails a day". Do not guess a split | The quote does not split the figure, and the split is also the written-communication question in a different form (F3). EXP because it probes the denominator |
| C3 | "Tell me what you actually do in Freshdesk day to day." | JD | [grounded] "I use Freshdesk every day" | Start from the quote: "I use Freshdesk every day." Answer slot: say what you do in it, in your own words, and only what you do; if some of what the tool offers is not something you use, say so plainly. Do not mention Zendesk | F2 is the evidence for the ticketing-tool requirement and it is one sentence. JD because it scores that line of the ad |

### Bank D: Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A 90-second arc in the three beats the quotes state: three years as a customer service advisor at an energy supplier; Freshdesk every day; training four new starters on the refunds process last year. Then the why: say in your own words what draws you to this role at a software company; if no specific reason has formed yet, say so plainly and say what you hope to learn. Add no roles, titles or outcomes | F1 and F2 supply the arc. EXP because it is the CV told aloud, and casual openers are still scored |
| D2 | "What do you know about what we make?" | CO | [generic] | The pack holds no verified facts about Lumenvale's product because research did not run, so it supplies none. Before the chat, read what the company publishes about what it makes and who uses it, and say what you found in your own words. If you cannot find enough to say, say so plainly and ask them to tell you. Never guess | A homework question for a company the pack could not research. `[generic]` is the honest label; the upgrade menu says what would change it |
| D3 | "This role is remote. What does your set-up look like for working from home?" | JD | [grounded] | Answer from your own situation only: the hours you can work, where you are, your equipment. If there is something you would need to check, say so and say when you would know. The guidance supplies no details | The role is remote per your message, which makes this practical question likely. JD because it scores the job's terms |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: we have applicants with software support behind them. Why you?" | EXP | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day" | Pause and restate the question. Hold what the quotes carry: three years as a customer service advisor at an energy supplier, and Freshdesk every day. Do not compare yourself to other applicants and do not offer an adjective as proof. Hold through two follow-ups, then concede the specific limit: "I've never worked for a software company." Never fold the core claim to restore harmony | F5 returns here in its harshest packaging. EXP because it scores composure on a claim you can stand behind |
| E2 | "That training of four new starters. How much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | The whole claim is the sentence: four new starters, the refunds process, last year. Answer slot: say which part was yours, in your own words; if any of it was shared or set by someone else, say so plainly and stay with what you did. Name the assumption behind "four" you would defend least. Add no outcomes | F1's training line is the sentence a pressure interviewer tests for inflation. EXP because it is an attribution probe |

### Bank G: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you put a customer ahead of an internal target." | VAL | [generic] | A selection scaffold: pick a time with a named customer need, the internal constraint, your decision, and how it ended with the customer. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard stem for support roles; no Lumenvale values were in hand to theme it. VAL because it tests past behavior |
| G2 | "Tell me about a time you had to tell a customer something they did not want to hear." | VAL | [generic] | A selection scaffold: pick a time with a clear message, how you said it, the customer's reaction, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Pairs with B2's policy-limit case. VAL because it tests whether the hard truth landed |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role? What would you want me able to do on my own by the end of it?" | It shows you are planning to be useful quickly, and the answer tells you what to learn first, which matters given F5 |
| R2 | "What does the ticket mix look like: how-to questions, problems with the product, billing?" | It shows where you would be productive soonest and tells you where to point your preparation |
| R3 | "How are escalations handled here: who do they go to, and what should a handoff note contain?" | It treats the ad's escalation line as a working process and gives you the real answer to A4 and B3 |
| R4 | "How do new starters learn the product: is there shadowing or a training period?" | It shows you expect to learn the product, which answers the F5 objection forward |
| R5 | "How is quality measured on the team: response times, customer ratings, review of written replies?" | It shows you care about the written-communication standard in F3 and tells you how you would be scored |
| R6 | "After this chat, what are the next steps, and is there a call or video conversation with the team before a decision?" | It tells you whether to prepare spoken answers as well as written ones |

## Prohibited claims

Claims this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has Zendesk experience | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material says Freshdesk, not Zendesk. C3's slot stays inside the tool you named |
| Has worked at or supported customers of a software company | Negative you stated, F5 | Your words: "I've never worked for a software company." Then a future-tense plan, never a past |
| Handled 60 emails a day, or 60 of either kind | Inflated form of F3's figure | F3's quote at its own scope: "answering around 60 calls and emails a day". The limit is the pack's observation: the material gives the combined figure, with no split. C2's slot asks only whether you know the split |
| Ran or owned the refunds training, or a training programme | Inflated form of F1's training line | F1's quote at its own scope: "I trained four new starters on our refunds process last year". The limit is the pack's observation: the material says four new starters and one process, nothing about a programme or a role. E2's slot asks only which part was yours |

## Sources

**Provided documents:** your message, which holds the invite text, your background, and the ad's four requirements as you listed them. No dossier was consumed.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

Queries sent: "Lumenvale Software company values" — refused. "Lumenvale Software strategy news" — refused.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | The search was refused. It would have themed the VAL bank on published values by name; bank G uses standard stems instead |
| 2. Lumenvale Software interview process, support roles | skipped | Your message already fixes the loop: one text chat with the support team lead. That sets persona weights and the bank structure |
| 3. Lumenvale Software strategy and recent news | unavailable | The search was refused. It would have made D2 a company-specific question and allowed a grounding brief; D2 stays generic |
| 4. Interviewer name and company | n/a | No name was given for the support team lead, so there was no query to form; the interviewer read is absent |
| 5. Representative Customer Support Specialist JD | skipped | The four requirements you listed fix the fit snapshot and the JD questions; the full ad would add to them |

## Upgrade menu

- The full job ad text → any requirement beyond the four you listed gets a fit row and a question, and rows F1 to F4 are quoted from the ad itself
- The support team lead's name → an interviewer read from their public professional footprint, persona weights tuned to it, and a reverse question tied to their own path
- How the chat will run (live at a set time or message by message, and for how long) → persona weights and the pacing of B5 and E1 retuned
- Your answers to the slots in A4, A5, C1, C2, C3 and E2 → F3 and F4 rows upgraded from `discovery` to quoted evidence, and A4 and A5 turned into story maps
- Lumenvale's own values or careers page, pasted, or search access → the VAL bank themed on published values, and D2 made company-specific
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, which needs search access → a strategy brief and a grounding section
- How much prep time you have → a prioritized schedule in place of the full pack
- A `tuesday-dossier.md` → verified evidence and a prohibited-claims list that replaces the one built locally here
