# Interview pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (name not given). Format: a text chat. Built as a hiring-manager-style round, one session.

## How to use this pack

- Personas are how a question arrives; types are what it scores. Types: VAL (values alignment), EXP (experience deep-dive), JD (role requirement), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Where a cell says "answer slot", the answer has to come from your own experience, and either honest branch is a good answer.
- In a text chat, the interview is also your writing sample: short, clear, plain replies are part of what is scored.
- No VAL or CO questions are included: no values page or strategy source was available (see Sources).

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad, as you gave it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap on years. It is a line with nothing inspected behind it, so lead with it in its own terms: three years, customer service advisor, energy supplier. The sector differs from the employer's; F5 covers that |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad, as you gave it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Freshdesk is named, and the ad accepts a similar tool. Say it as you said it: "I use Freshdesk every day." Your material names Freshdesk, not Zendesk. Answer slot: if you have used Zendesk, say where and for how long; if not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — job ad, as you gave it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote shows emails among the work, not how clear the writing was. Answer slot: if anything showed how clear your written replies were, such as feedback or a result, say what it was; if nothing did, say so plainly and let this chat show it |
| F4 | "confidence handling escalations" — job ad, as you gave it | none given | none | [grounded] | discovery | Your material says nothing either way on escalations. Answer slot: if you have handled an escalation, say what the situation was and what you did, in your own words; if you have not, or it was not yours to handle, say so plainly and describe how you would handle one |
| F5 | Familiarity with software products — role-family, not in the ad you gave | "I've never worked for a software company" — your message | none | [grounded] | capability | You stated this, so the words are yours: "I've never worked for a software company." Then how you would learn a product, said as a plan and never as a past |

Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in customer support (F1) | C1, D3, E1 |
| Zendesk or a similar ticketing tool (F2) | A4, C1 |
| Clear written communication (F3) | A1, A5, B5, D3 |
| Confidence handling escalations (F4) | A1, A2, A3, B3 |
| Software familiarity (F5, not in the ad) | A3, B1, B2, B4, E1 |

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live support scenarios typed into the chat | Highest. A support team lead is the hiring-manager relationship prior, and the ad's escalation and writing requirements are easiest to test with a scenario | Clarify, state your approach, then reply as you would to the customer |
| Skeptic (bank B) | Quiet probing of the sector change and escalations | High. F5 is a gap you stated, F4 is silent in your material | Hold on "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day"; concede F5 plainly. B1 is the highest-ROI prep in this pack |
| Conversational (bank C) | Friendly opener, journey and motivation | Medium. A chat format favours an easy start, and it is still scored | A short arc built only from your quoted lines |
| Data-Driven Prober (bank D) | Your two figures | Medium. Two figures sit in your material: the daily volume and the four trainees | Say how each was counted, or say plainly you do not know |
| Pressure (bank E) | Short, challenging comparisons | Low. Text rarely carries interruption, but a comparison with other candidates is likely | Pause, restate, hold twice, concede one real limit |

Loop note: the invite describes one session, a text chat with the support team lead, and nothing else about its content. Weights rest on that and the relationship prior; no values-style round is detected.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem and is clearly angry. Write me your reply and tell me what happens next." | CASE | [generic] | Structure: acknowledge the repeat, say you will check the history, say what you will do and by when, name who else needs involving, say what you will record. Keep the reply short and plain. It needs no claim about your past, so the guidance makes none | Tests F3 and F4 live. CASE because it is a decision with a written output; generic because it is a pattern, not a fact about this employer |
| A2 | "A customer asks for something our policy does not allow and demands your manager. What do you do?" | CASE | [generic] | Say what you would offer first, when you would hand over, and how you would hand over so the customer does not repeat themselves. No claim about your past | The escalation line of the ad (F4) asked as a decision |
| A3 | "A bug means a group of customers cannot log in and tickets are piling up. What do you do in your first thirty minutes?" | CASE | [generic] | Clarify what is known, group the tickets, tell customers honestly without promising a fix time, flag it to the right person. Software context is where F5 shows, so think aloud | Software scenario for someone from outside software (F5); the structure is what is scored |
| A4 | "The ad mentions Zendesk or a similar tool. Which tool do you use, and how do you work in it?" | JD | [grounded] "I use Freshdesk every day" | Say it as you said it: "I use Freshdesk every day." Then describe, in your own words, how you use it. Answer slot: if you have used Zendesk, say where and for how long; if not, say so plainly and stay with Freshdesk | F2 is the ticketing-tool requirement; JD because it scores the stated requirement |
| A5 | "Rewrite this for a customer: 'Your refund has been processed per policy 4.2 and will be credited in 5-7 working days.'" | CASE | [generic] | Lead with the outcome, give the timing in plain words, say what to do if it has not arrived, keep the tone warm. No claim about your past | A direct writing sample for F3; the chat format makes it likely |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have not worked for a software company. How will you get up to speed on a product you have never supported?" | JD | [grounded] "I've never worked for a software company" and "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Concede first, in your words: "I've never worked for a software company." Hold on what you did say: "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day." Then a ramp plan, said as a plan: what you would read, whom you would ask, how you would check you had it. Hold through two follow-ups by returning to those quotes, never by adding to them | F5 is the biggest gap and the likeliest objection; JD because it scores a gap against the role |
| B2 | "Which part of this job would you find hardest on day one?" | JD | [grounded] "I've never worked for a software company" | Pick from what your material shows. Selection scaffold: the part must be real, and come with what you would do about it. F5 is the gap your material names. If nothing comes to mind, say so plainly, then name the nearest thing, or how you would handle it | Persona stem for the Skeptic; JD because it asks for honest self-assessment against the ad |
| B3 | "Tell me about a time you handled an escalation." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Open prompt from the ad's escalation line. Selection scaffold: choose a case that went beyond your remit or where the customer asked for someone more senior; it needs the situation, what you did, who it went to, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | F4 is silent in your material, so this is rehearsed before the probe |
| B4 | "Why software support, and why move away from energy?" | JD | [grounded] "I've never worked for a software company" | Give your actual reason, in your own words. Say it in a sentence or two. It must be consistent with everything else you say in the chat | Motivation consistency is what a Skeptic scores |
| B5 | "Your last role mixed calls and emails. Which do you do better, and why?" | JD | [grounded] "answering around 60 calls and emails a day" | Answer slot: say which you do better and why, in your own words; if you have no preference, say so plainly. This role is written, so connect it to the writing | F3; the premise is your quote, not a claim of mine |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day" and "I trained four new starters on our refunds process last year" | A 90-second arc in three beats, each one a quote above, in your own words, then one sentence on why this role. Your reason is yours to give | Casual openers are scored; F1 and F2 are the beats |
| C2 | "Tell me about training the new starters." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell what the sentence says: four new starters, the refunds process, last year. Keep to it, in your own words | Premised on your own sentence only |
| C3 | "What would you want your first month to look like?" | JD | [generic] | Say what you would learn first, whom you would shadow, and what you would ask. A plan, not a past | Ties to F5, as a forward-looking answer |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You say around 60 calls and emails a day. How was that counted, and does it hold on a busy day?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: say how the figure was counted, in your own words, or say plainly that you do not know. Name the assumption behind it you would defend least. Say which part was yours | Every headline figure gets a defend-the-number row |
| D2 | "You trained four new starters. Which part was yours?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Answer slot: say which part was yours, and how the number four was arrived at, in your own words; if you do not know, say so plainly. Stay inside the quote | Second figure in your material |
| D3 | "Roughly how much of that day was email, and how much calls?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: give the split in your own words, or say plainly that you do not know. It matters here because this role is written | F3 and F1 together |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a candidate who has already supported software?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day" and "I've never worked for a software company" | Pause and restate the question. Hold on the first two quotes. Concede once, plainly: "I've never worked for a software company." Do not claim more than the quotes carry | Hold-then-concede, built on F1, F2 and F5 |
| E2 | "Sixty seconds: tell me about the toughest customer you have handled." | EXP | [generic] | Selection scaffold: pick a case with a named situation, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Persona stem; F4 adjacent |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone new in this role?" | Shows you are planning your ramp, which answers F5 before it is asked |
| R2 | "Which ticketing tool does the team work in, and how is a new starter trained on it?" | You can prepare for the tool in advance, and it shows you take F2 seriously |
| R3 | "How are escalations handled here: what gets escalated, and to whom?" | Escalation is in the ad; the answer tells you what the day-to-day standard is |
| R4 | "How is the quality of a written reply judged here?" | Written communication is in the ad; it tells you what to aim for |
| R5 | "What do customers most often write in about?" | Lets you start learning the product before day one |
| R6 | "What is the next step after this chat, and will it include a call or video conversation with the team?" | Lets you prepare for the next stage |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material names Freshdesk, not Zendesk. A4's slot stays inside what you have used |
| Has worked in or supported software | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |

## Sources

- Provided: your message (the invite's wording, the ad's four requirements as you described them, your background). The full text of the ad was not provided.
- Searches sent: "Lumenvale Software values" — refused. "Lumenvale Software interview process customer support specialist" — refused.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Both searches were refused. It would have supported a values cheat sheet and VAL questions |
| 2. Lumenvale Software interview process | unavailable | Refused. It would have documented the loop; weights rest on the invite's description instead |
| 3. Lumenvale Software strategy and recent news | unavailable | No search could run. It would have supported a CO question |
| 4. Interviewer name and company | n/a | The support team lead is not named, so there was no query to form |
| 5. Representative Customer Support Specialist JD | skipped | The four requirements you gave fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full job ad text → F1 to F4 requirements quoted in full, and any mid-list items turned into questions
- The team lead's name → an interviewer read, persona weights adjusted, and a reverse question on their own path
- Search access, or Lumenvale's own careers page pasted → a values-style check, a company-strategy question, and the documented loop
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → grounding brief and role-family loop reports, if you want it
- Your answer to F2's Zendesk slot, and to F3 and F4's slots → those rows move from inferred or silent to grounded
- How much prep time you have → a prioritized prep schedule
- A tuesday-dossier.md → verified evidence and absolute prohibited claims carried into the next pack
