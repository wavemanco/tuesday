# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: an office manager, not named. Round: one 30-minute video call. Relationship assumed: the person you would work with day to day, so a manager-type round. If that is wrong, the persona weights below change.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your background survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed duties, gaps included |
| CO | Whether you know the company and its work |
| CASE | How you reason through a live problem from the role |

Question IDs run A to E by persona. Fit-snapshot rows are F1 to F5. Slots marked "Answer slot" are instructions for the interview itself, not questions to me.

## Fit snapshot

The requirements are the ad's duties as you relayed them in your message, so the full ad text was not seen. The evidence column is your own words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as relayed in your message | "two years as a receptionist at a physiotherapy clinic" — your message; "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your quote reaches the requirement in other terms, so say it as it stands: "I ran the appointment book for four physios." Keep the words "appointment book" and do not rename it. The pack's observation: the material says an appointment book, not meeting calendars |
| F2 | "booking travel" — the ad, as relayed in your message | none given | none | [grounded] | discovery | Your material does not show travel booking, and you have not said there was none. Answer slot: the ad's travel line makes a probe likely. If any of your clinic work involved arranging travel or transport for anyone, say what and for whom, in your own words; if none did, say so plainly and say what you would ask first on a first booking |
| F3 | "preparing documents in Word and Excel" (Word half) — the ad, as relayed in your message | "I'm good with Word" — your message | medium | [grounded] | none | The quote already says it in role-relevant terms: lead with "I'm good with Word." It is a self-assessment with nothing inspected behind it, so expect a probe asking for examples. The examples are yours to choose, and the pack supplies none |
| F4 | "preparing documents in Word and Excel" (Excel half) — the ad, as relayed in your message | "okay with Excel" — your message | low | [inferred] | discovery | Keep the level you gave: okay with Excel. Answer slot: the ad pairs Excel with preparing documents, so expect a probe on what you have used it for. If you used it for some task, say which and what you did; if you did not, say so plainly and say what you would want to learn first |
| F5 | "processing supplier invoices" — the ad, as relayed in your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your words are chasing unpaid invoices, and they stay at that scope: "I chased unpaid invoices." The pack's observation: the ad's line is about supplier invoices, and the material does not say whose invoices the ones you chased were. Answer slot: expect a probe on who the invoices you chased were owed to and what you did on them. If you did anything with invoices the clinic itself had to pay, say what, as it was; if not, say so plainly and stay with the chasing |

## Persona table

The loop rests on your own description: one 30-minute video call run by the office manager. No archetype fallback was needed.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Short "what would you do" scenarios built from the four duties | High. A manager-type round starts with live problems first, and each duty lends itself to a short scenario. Bank A | Clarify first, then structure, and think aloud. Name what you would ask before you act |
| Skeptic | Probes on the invoice side and on travel | High. F2 and F5 are where the material is thinnest against the ad, and a skeptic goes there. Bank B | Rehearse B1 until it is boring: hold your own words, concede the limit once and specifically, return to what you did |
| Conversational | Warm opener: "walk me through your background" | Medium. It follows from the manager-type prior and the video format, not from anything specific to this company. Bank C | A 90-second arc built from your own sentences, then treat casual questions on the duties as scored |
| Data-Driven Prober | Checks what exactly was yours in the appointment book and the invoice chasing | Medium. Invoices and a spreadsheet duty invite precision probes. Bank D | Say what was yours and what was not; say plainly when you do not know something |
| Peer Evaluator | Day-to-day working arrangements for a remote role | Low to medium, and it rises if the office manager is a colleague rather than your manager. Bank E | Offer how you would work with them, not only what you need |
| Pressure | Interruptions, time-boxing | Low. Nothing in the relationship points to it. B carries the hold-then-concede structure | Pause, restate the question, anchor in what you said |
| Values / Behavioral | Not detected | No loop source documents a values round, and the loop is fixed by your own description, so none is assumed | Not applicable |

## Question banks

Requirement coverage:

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, C2, D1 |
| "booking travel" | A2, B2 |
| "preparing documents in Word and Excel" | A4, A5, B3, D3 |
| "processing supplier invoices" | A3, B1, D2 |

No VAL question is included because no published values were obtained and no values round is detected. B1 is the highest-ROI rehearsal in this pack.

### A. Case / Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two managers both ask for the same Thursday 2pm slot, and one of them is travelling that week. What do you do?" | CASE | [generic] | Structure it aloud: what you ask each of them first (how fixed is each request, who needs whom), what alternatives you could offer, how you confirm the outcome in writing, and what you note down so it does not recur. The question needs no claim about your past, and the guidance makes none | A live problem from the ad's calendar duty (F1's requirement). CASE because it scores reasoning, not history; generic because it is a pattern for the problem, not a fact about this employer |
| A2 | "A colleague must be in Cork for a 9am meeting on Tuesday and back that evening. How do you go about booking it, and what do you ask first?" | CASE | [generic] | Ask before you book: the times that are fixed, who approves the cost, whether there is a preferred route or provider, and what receipts are needed afterwards. Then confirm the itinerary back to the traveller. Say it as a method; it claims no booking you have done | The ad's travel duty (F2's requirement) is the least evidenced, so a scenario lets you show method where there is no history. CASE because the interviewer scores the questions you ask first |
| A3 | "A supplier invoice arrives for more than the order said. What happens next?" | CASE | [generic] | Do not pay it yet. Check it against the order, ask who in the business owns that order, ask the supplier to explain the difference, and record what was decided. Say plainly that you would ask who signs off here, since you do not know this company's process | Built from the invoice duty (F5's requirement) as a live problem, so it asks nothing about your past. CASE because it scores caution and method |
| A4 | "We would like a simple sheet tracking supplier invoices: supplier, amount, due date, paid or not. How would you set it up?" | CASE | [generic] | Walk through the columns, how you would make overdue items easy to see, and what you would check with the office manager before building it. Name only the Excel features you would actually use; if the layout needs something you have not used, say so plainly and say how you would find out | A live problem joining the Excel and invoice duties (F4's and F5's requirements). CASE with JD content, because it scores a method and not a claimed skill level |
| A5 | "What documents would you be comfortable preparing for me from day one?" | JD | [grounded] "I'm good with Word" | Start from your own words: "I'm good with Word." Answer slot: name the kinds of document you have actually made in Word, in your own words; if you cannot name any, say so plainly and say what you would ask me to show you first | F3 is rated medium with nothing inspected, so an example is the likeliest next ask. JD because it scores the stated Word duty directly |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You chased unpaid invoices at the clinic. Here the invoices are supplier invoices that we pay. How does your experience connect?" | EXP | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal here. Hold what the quote carries, at its own scope: "I chased unpaid invoices." Do not rename it. Answer slot: expect a probe on who the invoices you chased were owed to and what you did on them. If you did anything with invoices the clinic itself had to pay, say what, as it was; if not, say so plainly and stay with the chasing. Follow-up 1: asked to go a level deeper on the chasing, tell only what you did, in your own words, and say plainly where you do not remember. Follow-up 2: asked whether you could take on the payment side, answer as a plan and not a past, naming what you would ask first and who you would ask. Concede only the limit that is true, once and specifically, then return to what you did | F5 is where the ad's wording and your words sit furthest apart, so this question is the likeliest objection to you, in some form. EXP because it tests what was actually yours |
| B2 | "Tell me about a time you arranged travel or transport for someone." | JD | [generic] | Pick a real occasion that has a named person, a constraint such as a time or a budget, and an outcome you can state. If no such occasion comes to mind, say so plainly, then say what you would ask first on a first booking, or give the nearest thing your own material does carry, in your own words | The ad's travel line raises it, and F2 shows nothing behind it. JD because it scores the duty, and the guidance is a selection scaffold because none of your sentences carries a story here |
| B3 | "How would you honestly rate your Excel?" | JD | [grounded] "okay with Excel" | Say it at the level you gave: okay with Excel. Answer slot: if there is a task you did in Excel, name it and say what you did; if there is not, say so plainly. Then say what you would want to learn first. A plain level plus a learning plan holds up better than a bigger word that the next question breaks | F4 is the lowest-rated evidence row and the ad pairs Excel with the documents duty, so the level will be probed. JD because it scores a stated requirement |
| B4 | "Why this role, and why now?" | EXP | [generic] | Give your actual reason, in your own words, and keep it about the work you want to do rather than about leaving anything behind. One reason said clearly beats three. The pack does not supply the reason | A motivation-consistency probe is standard for this persona. EXP because it scores the reason for moving, and it is generic because no sentence of yours states one |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices"; "I'm good with Word"; "okay with Excel" | A 90-second arc using only what those sentences state: two years as a receptionist at a physiotherapy clinic; you ran the appointment book for four physios; you chased unpaid invoices; you are good with Word and okay with Excel. Let the interviewer draw any link to the ad's duties. Finish with why you want this role, in your own words | The biography question is the usual opener of a friendly round. EXP because it scores your own account of your history; every beat is one the quotes state |
| C2 | "What did running the appointment book involve, day to day?" | EXP | [grounded] "I ran the appointment book for four physios" | Describe the work in your own words, as it was: the four physios and the book you ran. Tell only what you did, and where a detail has gone, say so. Do not add anything because it sounds like what such a job usually contains | F1 is the evidence for the calendar duty, and a casual question about it is still scored. EXP because it checks what you actually did |
| C3 | "What do you know about us, and what drew you to apply?" | CO | [generic] | Say what you have actually read about the company from its own website, and what in the role draws you, in your own words. Do not recite; if you know little, say so plainly and say what you would like to learn. No company research was available for this pack, so it supplies no facts about them | A friendly round will often ask. CO because it scores homework, and generic because the company searches were refused |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "When you say you ran the appointment book for four physios, which part was yours and which was somebody else's?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the sentence as it stands: "I ran the appointment book for four physios." Answer slot: say what was yours to do in it, in your own words; if others also worked in the book, or some of it was decided by someone else, say so plainly. Do not enlarge the book beyond the four physios | The headline figure in F1 is the one a prober tests first. EXP because it scores attribution |
| D2 | "Walk me through how you chased an unpaid invoice." | EXP | [grounded] "chased unpaid invoices" | Tell it in your own words, only as you did it. Where you cannot remember a detail, say so rather than fill it in. Keep to chasing; do not describe any step you did not take | F5 holds the only invoice evidence, and a prober asks for the walk-through. EXP because it checks the claim against the detail |
| D3 | "Tell me about a time you used Excel for work." | JD | [grounded] "okay with Excel" | Choose a real occasion and say what you did in it. Answer slot: if you have one, tell it as it was; if you do not, say so plainly, keep your level as okay with Excel, and say what you would learn first | The ad raises Excel, and F4 is thin, so a prober asks for an instance. JD because it scores the stated duty |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You are working from home and I send three requests on Monday morning, all marked urgent. How do you decide the order?" | CASE | [generic] | Say what you would ask first: which is due soonest, which blocks someone else, which can wait. Then say how you would reply so each person knows when to expect theirs. A method, with no past claimed | A remote role makes prioritising without someone beside you the practical test. CASE because it scores the reasoning |
| E2 | "How would we work together day to day? What would you need from me?" | JD | [generic] | Offer principles and not a demand: how you would like to be briefed, how often you would check in, what you would send back without being asked. Add what you would take off the office manager's plate, not only what you need | The reciprocity move for a peer-style interviewer. JD because it scores fit with how the role runs |
| E3 | "Tell me about a time you disagreed with a colleague about how something should be done." | EXP | [generic] | Choose a real occasion with a named disagreement, what you said, and how it ended with the working relationship intact. If no such time comes to mind, say so plainly, then say how you would handle a disagreement with a colleague | Peer rounds test disagreement style. EXP because it asks about your history, and it is generic because none of your sentences carries a story here |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role?" | It shows you plan to be useful early, and the answer tells you which duty to prepare for first |
| R2 | "Of calendars, travel, documents and invoices, which takes most of the week?" | The answer tells you where to put your prep time, and it shows you treat the four duties as real work |
| R3 | "Which tools do you use for calendars and for tracking invoices?" | It lets you say honestly where you are comfortable and where you would learn, with the real tools named |
| R4 | "Who signs off on a supplier invoice here, and how does it reach that person?" | It follows from A3, shows you think about control as well as speed, and gives you the process in the interviewer's words |
| R5 | "How would you want us to stay in touch day to day, given the role is remote?" | It is the reciprocity question for a peer-style round and answers E2 from their side |
| R6 | "What happens after this call, and when would you expect to decide?" | It lets you plan the days after the interview and tells you whether to prepare for another stage |

## Prohibited claims

Built from the fit snapshot before the banks were written. None of these is coached anywhere in this pack.

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices". The limit is the pack's observation: the material says chasing, and does not say whose invoices they were. B1's slot stays inside the chasing |
| Managed calendars | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios". The material says an appointment book, not meeting calendars |
| Strong or advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel". B3's and D3's slots ask only what you used it for |

## Sources

Provided documents: your message, which held the invitation text, the ad's duties as you relayed them, and your background. The full text of the ad was not provided. No dossier was consumed.

Searches sent:

- `Brennock Facilities Ltd company values` — refused
- `Brennock Facilities Ltd Ireland about strategy news` — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | The search was refused. Published values would have themed VAL questions, so there are none |
| 2. `Brennock Facilities Ltd interview process` | skipped | Your own description of one 30-minute video call with the office manager fixes the loop and the persona weights |
| 3. `Brennock Facilities Ltd strategy` / recent news | unavailable | The search was refused. It would have grounded C3, so C3 is generic |
| 4. interviewer name and company | n/a | No name was given, only the title office manager, so there was no query to form; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | The ad's duties as you relayed them fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → the five requirement quotes become the ad's own lines, and the coverage table is rechecked against its full list
- Your own answers to the slots in F2, F4 and F5 → those rows are regraded and the guidance on B1, B2, B3, D3 becomes story-mapped instead of slotted
- The interviewer's name and role → a tailored reverse question and persona weights read from their public footprint
- Anything you are told in writing about what the call will cover → the coverage assumption replaces round-type priors
- Search permission, or a pasted page from the company's own site → C3 becomes grounded and any published values can theme VAL questions
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy grounding brief and CO questions at the company's own altitude; offered once, and only useful once searching is permitted
- A `tuesday-dossier.md` from earlier work → verified evidence replaces the self-reported rows, and the objection worth the deepest rehearsal is taken from it
