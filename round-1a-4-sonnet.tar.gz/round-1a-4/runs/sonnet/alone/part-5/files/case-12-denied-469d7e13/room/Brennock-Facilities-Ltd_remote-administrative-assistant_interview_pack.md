# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (name not given). Relationship assumed: a hiring-manager-style round, with the office manager as the person you would work with day to day. Format as the invite describes it: one 30-minute video call. Built from your message alone: the ad's duties as you described them, your background, and no company research (see Sources).

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your background survives scrutiny, and what was actually you |
| JD | The ad's stated duties: can you do the listed job, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem from the actual role, reasoned aloud |

No VAL or CO questions appear: no values round is documented for this loop and no company research ran.

## Fit snapshot

Requirements are quoted from your description of the ad, in your message. Evidence is your own words, quoted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says an appointment book for four physios, with nothing inspected behind it, and the words stay at "I ran the appointment book for four physios." It does not say how the book was kept or whose diary a calendar here would be. Answer slot: the ad's "managing calendars" makes a probe on how the book was kept likely. If how it was kept day to day was yours to decide, say how, in your own words; if it was set by someone else, or there was no set way, say so plainly and stay with the appointment book you ran |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show whether any travel was booked. Answer slot: the ad's "booking travel" makes a direct probe likely. If you booked any travel, for anyone, say what and for whom, in your own words; if you did not, say so plainly, then say how you would go about it, as a plan and not a past |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it; the Word part | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | none | No gap in wording, but a self-rating with nothing inspected behind it, so expect a probe, possibly a small task. Keep to the quote's own terms: "I'm good with Word." |
| F4 | "preparing documents in Word and Excel" — the ad, as you described it; the Excel part | "I'm good with Word, okay with Excel" — your message | low | [inferred] | discovery | "Okay" is your own level and the words stay there. Answer slot: the ad pairs Excel with document preparation, so expect a probe on what "okay" covers. If you have used Excel for anything, say what, in your own words; if you have not, say so plainly, and say what you would learn first, as a plan and not a past |
| F5 | "processing supplier invoices" — the ad, as you described it | "I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices; it does not say whose invoices they were or whether any were supplier invoices, so the words stay at "I chased unpaid invoices." Answer slot: the ad's "processing supplier invoices" makes a probe likely, and this is the likeliest place to be pressed. If you handled supplier invoices in any way, say what you did with them, in your own words; if you did not, or it was not yours, say so plainly and stay with the chasing |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | B1, B5, C2, D1 |
| "booking travel" | A3, B2, B5 |
| "preparing documents in Word and Excel" | A4, B4, C3, C4, D3 |
| "processing supplier invoices" | A1, A2, B3, B4, B5, D2 |

## Persona table

Loop as the invite describes it: one 30-minute video call with the office manager. That establishes one session, so no archetype fallback applies. Depth follows weight: 5 / 5 / 4 / 3 / 2.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the distance between the ad's duties and your background | High. A hiring-manager-style round derisks gaps, and F2, F4 and F5 are the thinnest rows | Rehearse the supplier-invoice question (A1, A2) until it is boring; say the limit plainly and stay inside what you did |
| Case/Strategist (B) | Live problems from the job: a clash, a booking, an odd invoice | High. The relationship prior for a manager is live problems from their own workload, and the ad lists four concrete duties | Clarify first, then structure, then decide, then confirm in writing; think aloud |
| Conversational (C) | Friendly walk-throughs of your background | Medium-high. A short video call usually opens with the biography, and casual questions are still scored | A 90-second arc built from your own sentences (C1); treat casual questions about the ad's topics as scored |
| Data-Driven Prober (D) | Line-by-line questions on what you wrote | Medium. Your background is short, so each line gets pressed | Know what each line does and does not say; say plainly when you do not know |
| Peer Evaluator (E) | Collegial questions on working with others | Low-medium. Fit with a small office team is plausible but the invite gives no sign of a peer round | Disagreement with tact: reason, alternative, accept the decision |
| Pressure | Not banked | Low. Nothing in a 30-minute administrative call points to a stress format | none |
| Values/Behavioral | Not banked | None detected. No loop source documents a values round | none |

## Question banks

Highest-ROI prep in the pack: A1, with A2 as its follow-up. It is where the ad and your material sit furthest apart (F5), so it will arrive in some form.

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The ad says processing supplier invoices, and your background says chasing unpaid ones. How do those compare?" | JD | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I chased unpaid invoices." Say that first, in those words, and let the interviewer draw the comparison. Answer slot: if you handled supplier invoices in any way, say what you did with them, in your own words; if you did not, or it was not yours, say so plainly and stay with the chasing. Hold that position through two follow-ups by returning to what you did, never by adding to it | F5 is the widest gap between the ad and the material, so this objection arrives in some form. JD because it scores a stated duty; Skeptic delivery because it presses the gap quietly |
| A2 | "Say a supplier's invoice arrives and the amount doesn't match what was ordered. What would you do?" | CASE | [generic] | A live problem, so the guidance makes no claim about your past. Structure it aloud: what you would ask first (what was ordered, and where that is recorded); what you would do with the invoice meanwhile (hold it, neither pay nor file it as correct); who you would tell (the person who placed the order, then your manager); and what you would record. If you would need to look up a step, say so plainly | The second level of the F5 objection: if the first answer stays inside the chasing, this is where the interviewer tests the plan. CASE because it is a decision, not a record |
| A3 | "Tell me about a time you booked travel for someone." | JD | [grounded] | Your material carries no sentence for this, so this is a selection scaffold. Pick an occasion where you arranged travel or a stay for someone else, with a named person, a date you had to meet and a result you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2 has no evidence, so the question is asked as an open prompt on the ad's own duty. JD because it scores "booking travel" directly |
| A4 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel"; "I ran the appointment book for four physios and chased unpaid invoices" | Choose the honest answer from your own material, then say what you would do first about it. Your own words on Excel are "okay with Excel" and on invoices "chased unpaid invoices"; on booking travel your material says nothing either way. Answer slot: name the part you honestly expect to be slowest at, and the first thing you would do about it, as a plan and not a past; if you do not expect to be weak anywhere, say so plainly and name where you would check your work most | The Skeptic's standard stem; F2, F4 and F5 are where it lands. JD because it scores fit against the ad's list |
| A5 | "You've worked in a clinic's reception. Why this job, and why remote?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic" | Begin from the quote: "two years as a receptionist at a physiotherapy clinic." Your material gives no reason for the move, so the reason is yours to supply. Answer slot: say your actual reason for wanting an administrative role and for wanting it remote, in your own words; if the main reason is the working arrangement, say that plainly rather than dressing it up. Keep it to two or three sentences | Motivation probes are the Skeptic's standard "why here, why now" stem; no fit-snapshot row supplies a reason, which is why the guidance is a slot |

### B. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two colleagues ask you to book the same hour with a third person who is travelling that week. What do you do?" | CASE | [generic] | A live problem, so the guidance makes no claim about your past. Structure it aloud: what you would find out (which request is more urgent, whether either hour can move, where the third person will be); what you would offer both (another time if one can move); who decides if neither can (whoever you support, so you would ask rather than choose); and what you would confirm in writing to all three | F1's requirement asked as a decision rather than a record. [generic] because it is a pattern for the problem, not a fact about this employer |
| B2 | "Your manager asks you to book a trip to Cork next Tuesday, back on Wednesday, within a budget. Talk me through it." | CASE | [generic] | No claim about your past. Structure it: what you would ask first (purpose, times, preferences, the budget limit, who approves, how it is paid); two or three options with the trade-off of each said plainly; the choice confirmed with your manager before anything is booked; and the itinerary and receipts kept in one place | F2 has no evidence, so a live problem lets you show method without a claim. CASE because it is delivered as a task |
| B3 | "An invoice for €1,240 arrives from a supplier you don't recognise, marked urgent. What do you do before it goes anywhere?" | CASE | [generic] | No claim about your past. Structure it: do not pay or forward it as it stands, whatever the label says; check whether the supplier and an order are on file; ask the person who would have ordered; compare the details with earlier invoices from that supplier; tell your manager what you found and record it | F5's requirement asked as a judgement call. A careful process answer is the part of invoice work a thin background can fully show |
| B4 | "Here are forty supplier invoices in a spreadsheet and the total looks wrong. How do you find out why?" | CASE | [grounded] "I'm good with Word, okay with Excel" | Structure it: ask what the total should match; check in plain terms (the count, repeated lines, missing lines, figures stored as text); compare a sample against the invoices themselves; keep the correction traceable. If a step would need looking up, say so plainly: "okay with Excel" is your own level, and honesty about it is part of the answer | F4 and F5 together. CASE because the reasoning is scored, and the Excel level you stated is kept as stated |
| B5 | "It's Friday at four. Your manager wants a trip booked, a supplier is chasing a late payment, and two meetings clash. What goes first?" | CASE | [generic] | No claim about your past. Sort by what has a hard deadline and what is costly to delay; say your order aloud and ask your manager to correct it; say what waits until Monday and who you would tell | Prioritisation across the ad's four duties in one problem. [generic] because it is a role-family pattern |

### C. Conversational (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So — walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios and chased unpaid invoices" | A 90-second arc with the beats your two sentences state: "two years as a receptionist at a physiotherapy clinic", then "I ran the appointment book for four physios and chased unpaid invoices". The last beat is why this job, which your material does not carry. Answer slot: say why you want this role, in your own words, and stop; if you are applying mainly for the remote arrangement, say so plainly | The biography question opens most conversational rounds and is scored; EXP because it tests what was yours |
| C2 | "Tell me about running the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" | The beats are the ones the quote states: you ran the book, and it was for four physios; keep "four" attached to the physios. Answer slot: the ad's "managing calendars" makes a probe on how the book was kept likely. If how it was kept day to day was yours to decide, say how, in your own words; if it was set by someone else, or there was no set way, say so plainly and describe how you ran the book | F1 is the evidence for the calendar duty. EXP because it tests what was actually yours |
| C3 | "What would you most want to learn in your first month?" | JD | [grounded] "I'm good with Word, okay with Excel" | A plan, never a past. Choose one or two items from the ad's list where your own material is thinnest and say what you would do to learn them. Your own words on Excel are "okay with Excel"; naming it here is honest and shows a plan | Turns the F2, F4 and F5 gaps into a ramp plan the Skeptic bank asks for. JD because it scores fit against the ad |
| C4 | "Tell me about a document you prepared in Word that you're pleased with." | JD | [grounded] | Your material carries no sentence about a particular document, so this is a selection scaffold. Pick a document you made yourself, with a purpose, a reader and an outcome you can name. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach a document | F3's requirement asked as an open prompt. JD because it scores "preparing documents in Word" |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. Was the book yours alone, or did others work in it too?" | EXP | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" | Hold the quote: "I ran the appointment book for four physios." Keep "four" attached to the physios. Answer slot: if others also worked in the book, say which part was yours; if it was yours alone, say so plainly | F1's line carries the only figure in your material, so a Prober presses attribution on it |
| D2 | "Over the two years, how did your time split between the appointment book and the invoices?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios and chased unpaid invoices" | Use your own words from the quotes: "two years as a receptionist", "ran the appointment book", "chased unpaid invoices". Answer slot: if you can say roughly how the time split, say so in your own words and say it is an estimate; if you do not know, say so plainly | F1 and F5 sit in one sentence, so a Prober separates them to see which carried more of the work |
| D3 | "You described yourself as okay with Excel. What could you do in it today?" | JD | [grounded] "I'm good with Word, okay with Excel" | Your own words are "I'm good with Word, okay with Excel." Answer slot: say what you can do in Excel today, naming only things you have done, in your own words; if the honest answer is very little, say so plainly and say what you would learn first | F4 is `low` confidence, so the level you stated is the thing a Prober tests. JD because it scores a stated duty |

### E. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "If you disagreed with how I'd asked for something to be done, how would you raise it?" | CASE | [generic] | No claim about your past. Do what was asked unless it would cause harm; raise the concern once, with a reason and an alternative, at a calm moment; then accept the decision and say you will follow it | Disagreement style with the person you support is what a collegial round scores; [generic] because it is a pattern for the problem |
| E2 | "Tell me about a time you disagreed with a colleague, and how it ended." | EXP | [generic] | Your material carries no sentence for this, so this is a selection scaffold. Pick a disagreement where you can name the issue, what you said and how it was left, with the relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Peer persona's standard disagreement probe; an open prompt, so the pack supplies no event |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I be supporting day to day, and what does a typical week of calendar and travel work look like?" | Shows you are thinking about the actual workload behind the ad's first two duties |
| R2 | "How do supplier invoices reach the person processing them, and who approves them?" | Shows you take the invoice duty seriously, and tells you where the process starts |
| R3 | "Which tools do you use for calendars, travel bookings and invoices?" | Tells you what to practise before day one, and links to the gaps in F2, F4 and F5 |
| R4 | "What would a good first three months look like for this role?" | Invites a concrete ramp plan and gives you the standard you will be measured by |
| R5 | "What could a new person do in their first month that would help you most?" | A reciprocity question: it asks what you can contribute, not only what you need |
| R6 | "What happens after this call: is there a further stage, and how will I hear?" | A process question with a prep reason: it tells you whether this is the only conversation to prepare for |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars or diaries for managers or the business | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation, not words for you: your material says an appointment book, not a manager's diary |
| Processed supplier invoices, or ran accounts payable | Inflated form of F5 | F5's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: your material says chasing, and does not say whose invoices they were |
| Advanced or confident Excel skills | Inflated form of F4 | F4's quote at its own scope: "I'm good with Word, okay with Excel." |

## Sources

Provided documents: your message, holding the invite's text, your description of the ad's duties, and your background.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Brennock Facilities Ltd values | unavailable | The search was refused in this session. It would have fed any VAL questions; none are banked, since no values round is documented |
| 2. Brennock Facilities Ltd interview process, administrative roles | skipped | The invite's own description (one 30-minute video call with the office manager) fixes the loop and the persona weights |
| 3. Brennock Facilities Ltd strategy, recent news | unavailable | The search was refused in this session. It would have fed a CO question; none is banked, so company knowledge goes unrehearsed |
| 4. interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative Remote Administrative Assistant JD | skipped | The duties you relayed fix the fit snapshot and the JD-tagged questions; the ad's full text is listed in the upgrade menu |

Searches sent:

- "Brennock Facilities Ltd values" — refused
- "Brennock Facilities Ltd strategy recent news" — refused

## Upgrade menu

- The ad's full text → the requirements in the fit snapshot become exact quotes, and any duty beyond your summary gets its own row and questions
- The office manager's name and whether they would be your day-to-day manager or a colleague → persona weights re-read from the relationship, and a reverse question tied to their own path
- Anything you can say about travel you have booked, how your appointment book was kept, what you have done in Excel, or what you did with supplier invoices (the answer slots in F1, F2, F4 and F5) → those rows gain quoted evidence and the matching banks become story-mapped
- A document or spreadsheet you prepared yourself, with any patient or personal details removed → the Word and Excel rows (F3, F4) can move from self-rating towards inspected evidence
- Search permission in this session → targets 1 and 3 run, adding published values and recent company context, and a CO question grounded in them
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the company and recent org context; needs search permission
- A `tuesday-dossier.md` from an earlier session → verified evidence and any claims to avoid, in place of the prohibited list built here from your message
