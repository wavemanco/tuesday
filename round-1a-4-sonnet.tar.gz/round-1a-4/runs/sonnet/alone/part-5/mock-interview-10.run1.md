Reading the skill's reference files is done, and I'm now running the company research: values, interview process and recent news for Lumenvale Software.
Web search was refused by the permission prompt. I'm building the pack without company research and will label what that cost. Writing the pack file now.
Before the prep, one thing in the invite: it says the hiring process is "carried out entirely on Telegram", that "your interview will be a text chat here", and that "your offer and onboarding will be completed in this chat as well". A hiring process run wholly by chat is a known scam pattern. A chat alone doesn't show who you're dealing with. Until you know, send no money, documents or bank details through it. Check with Lumenvale through contact details you find on its own website or careers page, not through this chat. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `lumenvale-software_customer-support-specialist_interview_pack.md`. I built it for a text-chat interview with the support team lead, treated as a hiring-manager-type round. The ad it uses is the four requirements you relayed, and your background lines are quoted exactly. Web search was refused in this session, so the pack has no Lumenvale values, loop or strategy. The company-knowledge question is labelled generic, and the Sources section shows what each missing search would have changed.

The highest-ROI prep is A1: "I've never worked for a software company", followed by a plan for getting up to speed. A2, on escalations, comes second. Your material has nothing on escalations, so that question is a scaffold, not a story.

Say the word and I'll play the Skeptic on A1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead someone who would manage you, or a colleague on the team? The answer reweights every bank. Do you still have the ad's full text? If so, paste it, because it would turn four relayed lines into quoted ones.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: lumenvale-software_customer-support-specialist_interview_pack.md -----
# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

- Interviewer: "our support team lead", unnamed. Relationship assumed to be a hiring-manager type, because the invite names the team lead and nothing more. If the lead is a future peer instead, the persona weights below change.
- Format: "a text chat", per the invite. Every answer you type is also a sample of your writing.
- Built on: the invite as you pasted it, the ad as you relayed it (four requirements, not the full text), and the background lines in your message. No company research ran (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview, not a question for me.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the values a company holds, not generic virtue |
| EXP | Whether your CV claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Homework depth on the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you relayed it | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. Lead with it in your own title, customer service advisor, rather than the ad's wording, because your sentence is the one you can defend |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you relayed it | "I use Freshdesk every day" — your message | medium | [grounded] | none | Your message offers Freshdesk against this line. Say it as written. Answer slot: expect a probe on what you do in it; say what you actually do there, in your own words. If Zendesk comes up by name, say which tools you have used, in your own words, and stay with the one your message names |
| F3 | "clear written communication" — the ad, as you relayed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote touches written work without showing how any of it read, and the figure joins calls and emails, so it stays joined. The invite says "your interview will be a text chat here", so what you type in the chat is also read against this line. Answer slot: expect a probe on your written replies; say what kind of emails and who they went to, in your own words; if you cannot point to more than answering them, say so plainly and stay with the emails you answered |
| F4 | "confidence handling escalations" — the ad, as you relayed it | none given | none | [grounded] | discovery | Your material does not show this requirement either way. Answer slot: expect a probe asking for an instance; if a contact of yours needed to go beyond the first answer, say what it was and what part was yours, in your own words; if escalations were not part of your work, or none came your way, say so plainly and describe how you would handle one |
| F5 | Not a line in the ad as relayed; you raised it as a concern — your message | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past. The nearest thing your material carries is F2's quote at its own scope. Nothing added to make the gap feel smaller |
| F6 | Not a line in the ad as relayed; an offered strength — your message | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Say it as written. The number stays on the new starters, four people and one process. Expect a probe on how, and on how much was yours |

## Persona table

The loop rests on the invite's own words: one session, a text chat with the support team lead. No values-style round is established, and no company page was read.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the software gap, escalations and the move from energy | High. A team lead hiring for a role usually tests the gaps, and F4 and F5 are the two widest in your material. The hiring-manager prior is Case plus Skeptic | Rehearse A1 until it is boring. Say the gap in your own plain words, then the plan |
| Case / Strategist (B) | Live support scenarios you answer in the chat | High. Same prior, and a typed scenario is the natural live problem in a chat interview | Clarify, then structure, then answer, and challenge one premise politely per case |
| Conversational (C) | A friendly opener, then casual questions about your background and why Lumenvale | Medium. A chat tends to open warmly, and casual questions are still scored | Prepare the 90-second arc in C1 and one specific, accurate reason for C2 |
| Data-Driven Prober (D) | Presses on your two figures and on what you do in Freshdesk | Medium. F3's figure and F6's number are the likeliest targets, and the ad names a tool | Know what you can and cannot say about how each was counted, and say plainly when you do not know |
| Pressure (E) | Short time-boxed challenges, such as "sixty seconds" | Low. A text chat gives less room to interrupt, though quick challenges still translate | Pause, restate, hold the same sentences through two follow-ups, concede once and specifically |
| Values / Behavioral (F) | Behavioral prompts | Low. No values-style round is established and no values were researched | Have one story ready per prompt where your material carries one, and the honest branch where it does not |
| Peer Evaluator | Not built | Not included: nothing says the lead is a peer. Tell me if so and I will add a bank | Not applicable |

## Question banks

The highest-ROI prep in this pack is A1, the software-company gap. It is the one gap you named yourself, and the employer's name makes a probe on it likely. A2, on escalations, is the close second.

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your experience is at an energy supplier, not a software company. How would you get up to speed on a software product?" | JD | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier" | Open with the plain words: "I've never worked for a software company." Then the plan, said as a plan and never as a past: what you would learn first, who you would ask, and how you would check you had understood before answering customers, in your own words. The nearest thing your material carries is "I use Freshdesk every day"; say it at that scope and add nothing. Follow-up one, a customer asks something you do not know: say you would find out and come back rather than guess. Follow-up two, how long until you work alone: give your own honest estimate in your own words, because this pack supplies no figure. Hold the plan through both and concede the gap once | F5 is the gap you named, so this is the likeliest objection to arrive in some form. JD because it scores whether the listed job is doable with the gap |
| A2 | "Tell me about a time a customer's problem needed escalating." | EXP | [grounded] | No sentence of yours carries an escalation, so this is a selection scaffold. Pick a contact that needed more than the first answer: it needs what the problem was, what you did, who else was involved if anyone, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it, as in B2 | F4 has no evidence behind it, so this is where the ad's confidence line gets tested. EXP because it asks for a real instance, and the scaffold supplies none |
| A3 | "You mention answering calls and emails. What makes a written reply good?" | JD | [grounded] "answering around 60 calls and emails a day" | Give your own criteria in your own words, in three or four sentences, because the answer is itself read as a sample of your writing. Say what you check before you send a reply; if you have no routine, say so plainly and say what you would check. Keep the figure as written, "around 60 calls and emails a day", and never as emails alone | F3 is thin evidence against a line the ad names, and in a text chat the answer is scored twice. JD because it scores the written-communication line |
| A4 | "The ad says Zendesk or a similar tool, and your tool is Freshdesk. How quickly could you move across?" | JD | [grounded] "I use Freshdesk every day" | Say it at its own scope: "I use Freshdesk every day." Then the move: what you would do first on an unfamiliar tool, in your own words. Answer slot: give your own honest estimate of how long the move would take; this pack supplies no figure, and if you do not know, say so plainly. Never describe Zendesk work | F2 is a similar-tool match your message offers, not Zendesk itself. JD because it scores the ticketing line |
| A5 | "Why are you moving from an energy supplier into software support?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I've never worked for a software company" | Give your actual reason in your own words; this pack supplies none. Keep it to what draws you toward the work, then stop. If pressed on the move, your own words are: "I've never worked for a software company." Hold it there | Motivation consistency is what the Skeptic scores, and F5 makes the move the visible fact. EXP because it tests whether your story survives cross-examination |

### B. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A customer writes in capitals that they have been charged twice and wants a manager now. Type the reply you would send." | CASE | [generic] | Acknowledge the feeling in one line, say what you will check, say what happens next and when, and say when you would bring someone else in. Keep it short enough to read on a phone. The question needs no claim about your past, so the guidance makes none | A live problem from the ad's written-communication and escalation lines (F3, F4), delivered in the interview's own medium. Generic because it is a pattern for the problem, not a fact about this employer |
| B2 | "A customer's problem is outside what you can fix, and you are not sure who owns it. What do you do?" | CASE | [generic] | Clarify what the customer needs and what is already known. Say what you will not do: guess, or pass the customer around. Hand over with a note the next person can act on without asking the customer again, tell the customer who has it and what happens next, and follow up. If the team has a set route, say you would ask for it first | The escalation line (F4) as a decision, not a record. Generic because it is a pattern |
| B3 | "A customer asks how a feature works and you have never used it. What do you reply?" | CASE | [generic] | Do not guess. Tell the customer you will confirm, find the answer from whatever sources the team provides or from a colleague, reply with the confirmed answer, and note the gap so it is not repeated. This is the plan A1 asks for, in miniature | Rehearses the software gap (F5) as a live problem rather than a confession. Generic because it is a pattern |
| B4 | "Five contacts arrive together: a customer locked out, a refund query, a feature request, an angry repeat contact and a pricing question. Which do you take first, and why?" | CASE | [generic] | Ask what the team's priority rule is. If there is none, order by impact on the customer and how time-sensitive each is, say the assumption you are making, and say what would change your order. Challenge one premise politely, such as whether they are all yours | Scores structure over the right answer. Generic because the scenario is invented for rehearsal |
| B5 | "Rewrite this reply for a customer: 'Unfortunately that is not possible. It is company policy.'" | CASE | [generic] | Say what you can do, give the reason in one plain sentence, and offer a next step, with no blame. Type it, then read it aloud once. Practise three versions so the first one in the chat is not your first | A live test of the written-communication line (F3) in the medium the interview uses |

### C. Conversational (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through your background." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A 90-second arc in the order of your own sentences: "3 years as a customer service advisor at an energy supplier", then "I use Freshdesk every day", then "I trained four new starters on our refunds process last year". End with one sentence, in your own words, on why this role; this pack supplies the reason none. Answer slot: if you are asked what changed over the three years, say what changed; if nothing did, say so plainly and stay with the role as written | The casual opener is still scored. F1, F2 and F6 are the sentences to sequence |
| C2 | "What drew you to Lumenvale?" | CO | [generic] | This pack could not research Lumenvale (see Sources), so it supplies no fact about the company. Before the chat, read the company's own site and pick one specific thing you can say back accurately, with your reason. If nothing specific comes to mind, say so plainly and say what you would want to learn. Never repeat a claim you have not read yourself | CO because it scores homework depth. Generic because no company research ran |
| C3 | "Tell me about the training you did with the new starters." | EXP | [grounded] "I trained four new starters on our refunds process last year" | The beats are the sentence's own: four new starters, the refunds process, last year. Say it as written. Answer slot: expect a probe on how you trained them; say what you actually did, in your own words; if there was no set structure, or it was not yours alone, say so plainly and return to the sentence. Do not add results you did not name | F6 is an offered strength and the likeliest friendly detour. EXP because it tests what was actually yours |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You say you answer around 60 calls and emails a day. How was that counted, and how many were emails?" | EXP | [grounded] "answering around 60 calls and emails a day" | Say the figure as written: "answering around 60 calls and emails a day". Answer slot: say how the figure was arrived at, in your own words, what it moves with, and which assumption in it you would defend least; if you do not know how it was counted, say so plainly. The split between calls and emails is not in your material, so give it only if you know it | Every headline figure gets a defend-the-number row. F3's figure joins two kinds of contact, which is where a probe goes first |
| D2 | "What do you actually do in Freshdesk day to day?" | EXP | [grounded] "I use Freshdesk every day" | Start from the sentence: "I use Freshdesk every day." Answer slot: the ad's ticketing line makes a probe on what you do in it likely; say what you do there in your own words; if your use covers less than the whole tool, say so plainly and stay with what you do | F2 is a CV-style line with nothing inspected behind it, so expect depth probes on it |
| D3 | "What did your role look like across the three years?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | Tell it as the sentence says. Answer slot: if your responsibilities changed over the three years, say what changed and when, in your own words; if they did not, say so plainly and stay with the role as written | F1 is the evidence for the experience line, and a prober checks whether three years is one year repeated |

### E. Pressure (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I've never worked for a software company" | Hold, then concede. Hold with those first two sentences, in your own words, and add nothing to them through two follow-ups. Pause and restate the question before you answer. Concede once, specifically: "I've never worked for a software company." Then stop. Claim nothing about the other person | F5 is the weak assumption in any comparison with a software-support candidate. JD because it scores the stated requirement against the gap |
| E2 | "How much of that refunds training was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence: "I trained four new starters on our refunds process last year." Keep the verb as written: trained. Answer slot: if anyone else was involved, say who and which part was theirs; if it was only you, say so; if you cannot separate your part, say so plainly | F6 has a countable claim, and attribution is the stock pressure probe on it |

### F. Values / Behavioral (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you put a customer ahead of an internal target." | VAL | [generic] | No sentence of yours carries this story, so choose one: it needs a named stake, what you did, and how it ended. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A persona-stem prompt, since no company values were researched. Generic because it is a pattern |
| F2 | "Tell me about a time you had to tell someone something they did not want to hear." | VAL | [generic] | Same scaffold: a named stake, what you did, how it ended. Pick a time where the hard truth actually landed. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | A persona-stem prompt. Generic because it is a pattern |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | A5, C1, D3 |
| "experience with Zendesk or a similar ticketing tool" | A4, D2 |
| "clear written communication" | A3, B1, B5, D1 |
| "confidence handling escalations" | A2, B2 |
| Software-company gap, not in the ad as relayed | A1, B3, E1 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What does the first month look like for someone new to your product?" | It shows you plan to learn the product, which answers the A1 probe before it is asked |
| "What kinds of contacts get escalated, and what does a good handover from support look like?" | It shows you think about escalation from the receiving side, and the answer sharpens B2 |
| "How do you tell, as a team lead, that a written reply was good?" | It turns F3's thin evidence into a conversation about the standard you are aiming at |
| "Which ticketing tool does the team use, and how much of the first weeks is learning it?" | It addresses the Zendesk line (F2) openly and tells you what A4's follow-up will be |
| "What happens after this chat, and is there another stage?" | It lets you prepare for the next step |
| "What makes someone struggle in their first 90 days on the team?" | It invites the lead to name the real risks, so you can answer them in later stages |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material says Freshdesk, not Zendesk |
| Software or SaaS support experience | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Answered about 60 emails a day | Inflated form of F3 | F3's quote at its own scope: "answering around 60 calls and emails a day". Your material joins calls and emails and does not split them |
| Led or ran a training programme, or owned the refunds process | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year". Your material says four new starters and one process |

## Sources

Provided documents: the invite as pasted in your message; the ad as relayed in your message, four requirements and not the full text; the background lines in your message. No dossier was present.

Searches sent, all refused by the host's permission step, so nothing came back:

- "Lumenvale Software company values" — refused
- "Lumenvale Software customer support specialist interview process" — refused
- "Lumenvale Software news strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Would have named the published values for a values cheat sheet; none is built, and F1 and F2 in the Values bank are persona-stem prompts |
| 2. `Lumenvale Software interview process customer support` | unavailable | Would have documented the loop. Persona weights rest on the invite's own words and the hiring-manager prior instead |
| 3. `Lumenvale Software strategy` | unavailable | Would have grounded a CO or CASE question in current strategy; C2 is generic as a result |
| 4. `{interviewer name} Lumenvale Software` | n/a | No interviewer name was given, only the title "support team lead", so there was no query to form |
| 5. representative `Customer Support Specialist` JD | skipped | The four requirements you relayed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → the four relayed requirements become quoted ones, and any terms such as hours, time zone or location would become rows of their own
- Your CV → more of your own sentences in the evidence column, which would upgrade F3, F4 and F5 and replace some selection scaffolds with story maps
- Search permission for this session → Sources rows 1 to 3 would run, upgrading C2 and the Values bank from generic to grounded
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, and it needs the same search permission → a strategy brief and recent company context for the CO questions
- Your own words on an escalation you handled, if there was one → F4 moves from discovery to evidence and A2 becomes a story map
- A sample of a written reply you are proud of, with anything customer-identifying removed → F3 can rise above low confidence and B5 becomes easier to rehearse
- Whether the support team lead would manage you or work beside you → persona weights recomputed, and a Peer bank added if they are a peer
- The team lead's name → an interviewer read and a reverse question tied to their own path
- A `tuesday-dossier.md` from an earlier run, if you have one → verified evidence and constraints for each weak area, never required
