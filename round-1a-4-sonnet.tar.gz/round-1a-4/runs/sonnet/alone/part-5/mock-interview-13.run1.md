I'll read the skill's reference files before building the pack.
Your prep pack is written, and I'm presenting it now. I built it for Hannah's recruiter screen on Thursday at 2pm, working from the advert, her message and what you told me about your background. The company and recruiter searches were refused in this session, so there's no company research or reading of Hannah. The pack's Sources section says so.

The saved file is `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-5/rooms/case-13-denied-24f93284/quillmoor_operations-coordinator_interview_pack.md`.

- **Your four logistics answers:** pay, hybrid and why you're moving each use your own words. Your £42,000 sits inside the £38,000–£44,000 band. Your notice period isn't in what you told me, so that answer is an instruction to give your real one. Check your contract before Thursday.
- **Most likely objection:** SAP. Say it plainly, "I've never used SAP — we run our own in-house stock system", then say how you'd learn it as a plan. The advert lists ERP only as "a plus". The pack calls this the highest-ROI rehearsal, B1. Production-schedule coordination is second, B2.
- **Your stock-count figure:** the pack keeps your sentence as you wrote it, with "about a third". It doesn't claim the spreadsheet caused the drop. Expect "how was that counted?"
- **Thin spots:** weekly dispatch reporting and Excel. The pack has answer slots for both, where you say what's true or say plainly that it isn't yours.

Say the word and I'll play Hannah on A5 (what's prompting the move), then B1, with follow-ups. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Could you paste your CV, or just the lines on the stock-count rebuild and supplier chasing? Right now those rows rest on your description alone, and the exact wording would regrade them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, 30-minute phone call with Hannah Lowther (Talent Partner). She rings the mobile number on your application.
**Her agenda, in her words:** your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, then the team and next steps.
**Built from:** the advert, Hannah's message and your own description of your background. No CV was supplied, and the research searches were refused in this session (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what it is scored on. Guidance is scaffolding, not a script: say things in your own words. An "answer slot" is an instruction for the interview, not a question for you now. A "logistics slot" holds your own stated words for pay, notice, location and your reason for moving.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your experience claims hold up, and what was actually you |
| JD | Whether you meet the advert's stated requirements, gaps included |
| CO | How much you know about the company |
| CASE | How you structure a live problem from the role |

Highest-ROI prep in this pack: B1, the ERP and SAP question. The advert lists ERP experience as a plus, and your message states you have never used SAP, so some version of it is the likeliest objection. Rehearse it until it is boring. B2 is second.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says deliveries for three depots and does not mention production schedules, with nothing inspected behind it. Words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's planning, warehouse and QA line makes a probe on which of those you coordinate with likely. If you work with any of them, say which and what you coordinate, in your own words; if you don't, or it is not yours, say so plainly and stay with the depots |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | The quote already carries the chasing in role-relevant terms, but nothing is inspected behind it, so expect a probe. Lead in its own terms: you chase suppliers when orders slip. C2 rehearses the probe |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | The quote reaches the requirement, and it is a figure with nothing inspected behind it, so expect a defend-the-number probe. Keep the two clauses as the sentence has them: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. The sentence does not say how the two are linked, and the words do not add it |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show whether you report on deliveries. Answer slot: if you report on deliveries or dispatch, say what and how often, in your own words; if you don't, or it is not yours, say so plainly and stay with the scheduling you do |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | The quote meets the requirement in role-relevant terms. Lead with it as written: four years, logistics coordinator |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The quote shows a spreadsheet and does not say which program. Answer slot: if it was Excel, say what you did in it, in your own words; if it was another program, or you are not sure, say so plainly and stay with the sentence |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | Your own words carry the limit: "I've never used SAP." They also carry an adjacent system: "we run our own in-house stock system." Hold those at that scope. Answer slot: if you work in the in-house system yourself, say what you do in it; if you don't, or it is not like an ERP, say so plainly |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Your stated constraint, in your own words. Nothing to bridge and nothing to add |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your stated figure, in your own words. Nothing to bridge and nothing to add |

## Persona table

The relationship prior for a recruiter screen is Conversational plus a light Skeptic. Your own words establish this one session only, so the weights for later rounds rest on pattern, not on a documented Quillmoor process. No values-style round was detected, so there is no Values persona bank.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly agenda questions on pay, notice, hybrid and why you're moving, plus a "tell me about yourself" opener | Highest, 5 questions. It is the recruiter-screen prior, and Hannah's message lists four logistics topics in that register | Know your four logistics answers in your own words; treat the chatty register as scored |
| Skeptic | Quiet probing of the gaps: SAP or similar, production scheduling, weekly reporting | Medium, 4 questions. The advert's requirements meet your message at F1, F4 and F7 | Rehearse B1 until it is boring: say the limit plainly, then stay at what you have said |
| Data-Driven Prober | One question on a CV number or a process line | Low to medium, 3 questions. The stock-count figure is the one number in your material | Know what you can say about how the figure was counted, and say plainly if you don't know |
| Case / Strategist | A live supplier-delay scenario or "what do you know about us" | Low, 2 questions. A 30-minute screen leaves little time, and this rests on the persona model, not on a documented loop | Clarify, structure, then answer, thinking aloud |
| Pressure | A sixty-second "why you" or "how much was you" | Low, 2 questions. Pressure is not the recruiter prior | Pause, hold your position through two follow-ups, concede specifically |
| Peer Evaluator | Planning, warehouse and QA colleagues in a later round | Low for Thursday, 2 questions. The advert names those three functions as your counterparts, and the pattern is a later team conversation | Offer principles for working across teams, not a claim to know their seams |

## Question banks

Requirement coverage:

| Advert requirement | Question IDs |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, D2, F1, F2 |
| Track supplier deliveries and chase late orders | C2, D2 |
| Keep stock records accurate | C1, E2 |
| Report weekly on on-time dispatch | B4 |
| 2+ years in operations or logistics coordination | A1, E1 |
| Confident with Excel | C3 |
| ERP experience (SAP or similar) a plus | B1, B3, E1 |
| Hybrid: two days a week at Avonmouth | A4 |
| £38,000–£44,000 | A2 |
| Hannah's own agenda: notice period | A3 |
| Hannah's own agenda: what's prompting a move | A5 |

### A. Conversational / Rapport Builder (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me about your background and what you're doing at the moment." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc in three beats, each one a clause the quotes state: four years as a logistics coordinator at a building-supplies wholesaler; you schedule deliveries for three depots and chase suppliers when orders slip; you rebuilt the stock-count spreadsheet and discrepancies fell by about a third over a year. Tell it in your own words, with "I" for what the sentences say you did. Stop after the third beat, because your reason for moving is A5's | The opener is the likeliest first question. F5, F2 and F3 are its evidence. EXP because it tests what you actually did |
| A2 | "What sort of salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot, filled with your own words: "I'm hoping for £42,000." Say that and stop. If it comes up again, say those words again. If you are asked what you earn now, you can politely decline to give a figure and return to your own words | Hannah named salary expectations in her message. F9 holds the figure and nothing else is added. JD because pay is a term of the advertised job |
| A3 | "And what's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words. If you are not sure what your contract says, check it before Thursday so you say what is true | Hannah named notice period. Your material does not state one, so the slot holds no figure. JD because it is a term of the job |
| A4 | "How would the hybrid pattern work for you, with two days at Avonmouth?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot, filled with your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she asks about the commute or about more days, say those words again with nothing added | Hannah named the hybrid pattern. F8 is your stated constraint. JD because it scores the advert's stated pattern |
| A5 | "And what's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot, filled with your own words: the Bristol office is closing next year, and the only offer is relocating to Reading, which you don't want. If she asks follow-ups on it, say those words again with nothing added | Hannah named what's prompting a move. EXP because it tests whether your story is consistent |

### B. Skeptic (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "ERP experience, SAP or similar, is a plus for us. What systems have you worked in?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | The highest-ROI rehearsal in this pack. Hold what the sentence carries: "I've never used SAP — we run our own in-house stock system." Answer slot: the advert's "or similar" makes a probe on the in-house system likely. If you work in it yourself, say what you do in it, in your own words; if you don't, or it is not like an ERP, say so plainly and stay with the sentence. First follow-up, a comparison with SAP: if you cannot compare, say so plainly. Second follow-up, how you would get up to speed: say it as a plan, in your own words, never as something you have done. The advert lists ERP as a plus, so the limit is a limit, not a disqualifier | F7 is the one row where your own words carry a stated limit against a named requirement, so this is asked in some form. JD because it scores the advert's ERP line |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. What have you coordinated that's closest to that?" | JD | [grounded] "I schedule deliveries for our three depots" | Hold at the sentence's scope: "I schedule deliveries for our three depots." Answer slot: if you work with any of planning, the warehouse or QA, say which and what you coordinate, in your own words; if you don't, or it is not yours, say so plainly and stay with the depots. Through two follow-ups, return to the depots and add nothing | F1 is the second-thinnest row against the advert's headline duty. JD because it scores the stated responsibility |
| B3 | "Which part of the job would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Say the limit your own words carry: "I've never used SAP." Then how you would learn it, said as a plan. Do not invent another weakness for effect. If the F1, F4 or F6 slots turn out to be gaps for you, you can name them plainly after answering those slots | The stem is the Skeptic's standard question. F7 is the safest honest answer, and F1, F4 and F6 are the other candidates. JD because it scores the whole advert |
| B4 | "The role reports weekly on on-time dispatch. Is that something you've done?" | JD | [grounded] "I schedule deliveries for our three depots" | Answer slot: if you report on deliveries or dispatch, say what and how often, in your own words; if you don't, or it is not yours, say so plainly and stay with "I schedule deliveries for our three depots" | F4 has no evidence behind it, so the honest answer is open. JD because it scores a stated duty |

### C. Data-Driven Prober (weight: low to medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say discrepancies fell by about a third. Walk me through how that was counted." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold the sentence as written: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Keep "about". Answer slots, each in your own words: how it was counted; what the figure is sensitive to; the assumption behind it you would defend least; which part was yours. Name the weakest assumption before they ask. If you do not know how it was counted, say so plainly | F3 holds the one number in your material, and numbers are what probers check. EXP because it tests attribution |
| C2 | "Walk me through what happens when a supplier's order slips." | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | The quote carries two beats: you chase suppliers when orders slip, and you schedule deliveries for the three depots. Answer slot: the advert's track-and-chase line makes a probe on how you find out an order is slipping and what you do next likely. If you have a routine for that, describe it in your own words; if there is no set step, or it is not yours, say so plainly and stay with the sentence | F2 is a CV-style line with nothing inspected behind it. JD because it scores the advert's chasing duty |
| C3 | "How confident are you in Excel, and what do you use it for?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Answer slot: the advert's "confident with Excel" line makes a probe on which program the spreadsheet was in likely. If it was Excel, say what you did in it, in your own words; if it was another program, or you are not sure, say so plainly and stay with "I rebuilt our stock-count spreadsheet" | F6 is `low` because the quote does not name the program. JD because it scores a stated requirement |

### D. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What do you know about Quillmoor?" | CO | [grounded] | Use what the advert says: "diagnostic-test manufacturer, about 400 staff", with the site at Avonmouth. Nothing about strategy, products or recent news was researched, so none is offered here. Say what you have actually read, in your own words, and one honest reason the role interests you. If you have read little beyond the advert, say so plainly | Recruiters often check for basic interest. The search was refused, so this stays at the advert's own words, and the upgrade menu says what research would add. CO because it tests company knowledge |
| D2 | "At 4pm a supplier tells you a delivery that QA needs for tomorrow's production run is two days late. What do you do?" | CASE | [generic] | A structure only, since it asks for no past: what you would ask the supplier first; what you would check on stock; who you would tell, naming the advert's planning, warehouse and QA; what options you would put to them; what you would record; when you would check back. Think aloud | A live problem built from the advert's chasing and production-schedule duties (F1, F2). `[generic]` because it is a pattern for the problem and not a fact about this employer. CASE because it asks for structure |

### E. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we take you forward?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year"; "Never used SAP — we run our own in-house stock system" | Hold the three beats the first three quotes state, at their own scope. If pressed on ERP, concede specifically and once: "I've never used SAP — we run our own in-house stock system." Hold through two follow-ups, and do not fold on the beats or add to them | The pressure stem tests composure. F5, F2, F3 and F7 are the evidence. JD because it scores fit against the advert |
| E2 | "That drop in discrepancies. How much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold the sentence as written. Answer slot: say which part of it was yours, in your own words; if you cannot say, say so plainly and stay with the sentence. Hold through two follow-ups by returning to what you rebuilt, never by adding to it | F3 is where attribution presses hardest. EXP because it tests what was yours |

### F. Peer Evaluator (weight: low for Thursday)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to get two teams to agree on a date." | EXP | [generic] "I schedule deliveries for our three depots" | Selection scaffold: pick a time you needed two sides to agree a date. It needs a named stake, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I schedule deliveries for our three depots", or how you would handle it | The advert's planning, warehouse and QA line raises it (F1). EXP because it asks for a past instance |
| F2 | "What would you need from planning and from the warehouse to make this work?" | CASE | [generic] | A structure only: what information you would need and when, what you would offer in return, and how you would raise a disagreement about dates. Offer principles, and do not claim to know their seam | A reciprocity question, built from the advert's named counterparts. CASE because it asks for reasoning and no past |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Are the two Avonmouth days fixed, or agreed with the team?" | It is on Hannah's agenda, and it settles the practical pattern before any offer |
| R2 | "Which systems does the team work in day to day, and is training on them part of the first weeks?" | ERP is a plus in the advert, and the question is about the ramp, not a claim about you |
| R3 | "Who would I work with day to day across planning, the warehouse and QA?" | It uses the advert's own three functions and shows you read the role |
| R4 | "How is on-time dispatch measured today, and what does the weekly report look like?" | The advert names the report, and the question shows interest in the actual job |
| R5 | "Is this a new role or a replacement, and what would success look like in the first three months?" | It gives you the team's context and shows you are thinking about delivering |
| R6 | "Who would I meet next, and what would that conversation focus on?" | It tells you which persona banks to rebuild for the next round |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having used SAP or an ERP | Negative you stated: "Never used SAP — we run our own in-house stock system" | Your words: "I've never used SAP — we run our own in-house stock system." B1's slot is about the in-house system only |
| Coordinating production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots". The limit is the pack's observation: the material says deliveries, and does not mention production schedules |
| That your spreadsheet cut discrepancies by a third | Inflated form of F3 | F3's quote at its own scope, with its two clauses as written. The limit is the pack's observation: the sentence does not say how the two are linked |
| Strong Excel skills | Inflated form of F6 | F6's quote at its own scope: "I rebuilt our stock-count spreadsheet". C3's slot asks only which program it was in |

## Sources

Provided documents: the advert text, Hannah Lowther's LinkedIn message, and your own description of your background. No dossier was consumed. No CV was supplied.

Searches sent, all refused with no results returned:

- `Quillmoor Diagnostics values` — refused
- `Quillmoor Diagnostics Avonmouth news` — refused
- `Hannah Lowther Quillmoor Diagnostics` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Search refused. It would have fed a values sheet, which is not built anyway because no values-style round is detected |
| 2. `Quillmoor Diagnostics interview process Operations Coordinator` | skipped | Your own words fix this session: a 30-minute recruiter phone call with the agenda Hannah listed |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Search refused. It would have grounded D1 with current context; D1 stays at the advert's own words |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Search refused. It would have supported a reading of the interviewer, which is absent from this pack |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV text, or the exact wording of the stock-count line → F2, F3 and F5 are graded on your message alone, at `medium`; the before-and-after stock-count discrepancy report is the inspectable artifact that would raise F3
- Your own answers to the slots in B1, B2, B4, C2 and C3, stated outside a drill → F1, F4, F6 and F7 are regraded from your quoted words, and the guidance cells that draw on them are rewritten
- Your actual notice period, if you want it quoted → A3 holds your own words instead of an instruction
- Working search access → company values, strategy and news ground D1, and a reading of Hannah's public professional footprint becomes possible; a deeper research pass would be up to 6 more searches and 2 more fetches, several more minutes, offered once
- The schedule or names of any later rounds → per-round mini-packs with their own persona weights, in place of the Peer and Case banks as written for a pattern
- `tuesday-dossier.md` → a pack without one is complete; one would add user-confirmed evidence, claims barred by name, and a stated strategy for each weak area
