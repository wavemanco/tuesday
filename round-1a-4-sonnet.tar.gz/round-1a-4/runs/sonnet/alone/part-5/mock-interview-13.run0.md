I'll read the reference files the skill points to before building the pack.
Saved the pack. I'm running a quick check for stray square brackets before I present it.
Your prep pack is saved as `quillmoor-diagnostics_operations-coordinator_interview_pack.md`, in the working directory. I built it for a recruiter screen, using only the advert and what you told me.

**Research limit:** the web searches I tried were refused, so the pack has nothing on Quillmoor beyond the advert. That includes the company's values, its interview process and anything on Hannah. The Sources section lists what I tried.

**What the pack says**
- **Her four topics (A1–A4):** you gave answers for pay, hybrid and why you're leaving, so the pack gives you your own words back, unchanged. It adds no range, no flexibility on days and no extra reasons.
- **Notice period (A3):** you didn't give one, so that slot tells you to state your actual notice period. If you're unsure of the exact length, say so and offer to confirm it.
- **Biggest likely objection (B1):** the advert's first duty is coordinating production schedules between planning, the warehouse and QA. Your material covers scheduling deliveries for three depots, and the pack holds you to that scope. B1 is the one to rehearse most.
- **SAP (B2):** you've said you haven't used it, and it's listed only as a plus. The pack coaches saying so plainly, then how you'd get up to speed.
- **Your stock-count figure:** there are questions on how "about a third" was counted, what assumption you'd defend least, and how much of the fall was down to you. The pack doesn't supply a method or baseline.
- **Wording to avoid:** the pack lists phrasings you might reach for that go beyond what you said. Examples are "my role is being made redundant" and "three days is fine".

Say the word and I'll play Hannah for a live drill, starting with A1–A4 and then B1.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

- **Round:** recruiter screen, Thursday at 2pm, 30-minute phone call; Hannah Lowther (Talent Partner) rings the mobile number on your application
- **Her stated agenda:** salary expectations, notice period, how the hybrid pattern would work for you, what's prompting a move; then she tells you about the team and next steps
- **Highest-ROI prep:** B1 (the production-scheduling question), then A1 to A4, which are her four stated topics
- **Basis:** the advert and your message only. Web research was not permitted in this session, so nothing about Quillmoor beyond the advert is in this pack, and nothing is taken from memory

## How to use this pack

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Where a cell says "Answer slot", it is an instruction for the interview, not a question for you now: answer it truthfully from your own experience, and either branch is a good answer.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values (none are in hand, so none are used) |
| EXP | Whether your account of your work survives scrutiny and attribution |
| JD | The advert's stated duties, requirements and terms, including their gaps |
| CO | What you know of the company and its strategy |
| CASE | A live problem from the actual role, reasoned aloud |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms. Nothing inspectable sits behind it yet, so expect a probe on dates and duties. Say it in its own terms: 4 years as a logistics coordinator at a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots" — your message | low | [inferred] | transferability | The pack's observation: your material says deliveries and depots, not production schedules, planning or QA. The words stay at that scope: "I schedule deliveries for our three depots." Answer slot: the advert's line makes a probe on which functions your scheduling touched likely. If any of planning, the warehouse or QA was part of it, say which and how, in your own words; if none was, or it was not yours, say so plainly and stay with the three depots |
| F3 | "chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip" — your message | medium | [grounded] | none | The quote already reaches the requirement. Say it as you said it: you chase suppliers when orders slip. Expect a probe on how often and how it ends, which is an F4-style slot, not something the pack fills |
| F4 | "track supplier deliveries" — the advert | "I schedule deliveries for our three depots" — your message | low | [inferred] | discovery | Scheduling deliveries touches tracking without showing it. Answer slot: the advert's line makes a probe on how you follow supplier deliveries likely. If you follow them in some particular way, say how, in your own words; if there was no such tracking, or it was not yours, say so plainly and stay with the chasing |
| F5 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | The quote reaches the requirement. It carries a figure, so it raises four slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Keep "about a third" and "over a year" exactly; the pack supplies no baseline or method. "I don't know how it was counted" is an honest answer |
| F6 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | Your sentence says spreadsheet, not Excel. Answer slot: if it was Excel, say what you did in it, in your own words; if it was another tool, say which; if parts were not yours, say so |
| F7 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system" — your message | low | [grounded] | capability | You stated the absence, so the words are yours: "Never used SAP." The in-house system is stated at its own scope and the pack does not call it an ERP. Answer slot in B2 lets either answer stand. A plus, not a requirement; do not bridge it |
| F8 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | The material says nothing on reporting. Answer slot: the advert's line makes a probe on your reporting likely. If you report regularly on deliveries or stock, say what, how often and to whom; if no regular reporting was part of the job, say so plainly |
| F9 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | A pay term, shown met: the pack's observation is that your figure sits inside the advertised band. Your words are the whole answer, and the pack adds no range, floor or flexibility because you gave none |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | A location and schedule term, shown met at two days. Your sentence is the answer; if she raises more days or the journey, it is the same sentence again |
| F11 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" — your message | medium | [grounded] | none | The reason is stated whole. Keep it whole: any follow-up gets these same words again |
| F12 | "your notice period" — Hannah's message | none given | none | [grounded] | discovery | The material does not state it. Logistics slot: give your actual notice period, in your own words; if you are unsure of its exact length, say so and say you will confirm it |

## Persona table

The loop beyond this call is not established by any source I read, so weights for this call rest on the recruiter-screen prior and on Hannah's own message; later rounds, if you meet them, fall back on a generic screen, hiring manager, panel pattern with flat weights.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Conversational / rapport | Friendly walk through your situation and her four logistics topics | Highest: her message lists four topics and says she then describes the team, which is a conversational screen. Casual questions are still scored | Say your own words for pay, notice, hybrid and the reason for leaving; give the same words again if she circles back. The role arc uses only F1, F3 and F5 | A (5) |
| Skeptic | Quiet check of the advert's gaps | Medium: the advert's first duty and its ERP plus sit against F2 and F7, and a screen is where knockouts are checked | Rehearse B1 until it is boring: hold the quote, state the limit plainly, never add to it | B (4) |
| Data-driven prober | Asks how the one headline figure was counted | Low to medium: F5 is the only figure you gave, and a 30-minute screen leaves little room for depth | Know what you can and cannot say about how it was counted; say plainly if you do not know | C (3) |
| Case / strategist | A short live problem from the role | Low: nothing in her agenda suggests one; kept because later rounds are undocumented | Clarify, then structure, then answer; think aloud | D (3) |
| Pressure | Time-boxed challenge on a gap | Low: possible if she tests the SAP point | Pause, restate, hold the quoted work, concede the one thing you stated | E (2) |
| Peer evaluator | Cross-team scenarios | Low: she is a recruiter, not a peer; the advert's three-function coordination makes it a likely later theme | Reciprocity and seam principles, not claims about teams you did not work with | F (2) |

No values bank: no values round is documented and no published values are in hand.

## Question banks

### A. Conversational (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What's prompting a move for you?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot, filled by your own words and kept whole: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Say it plainly and stop. If she follows up on any part of it, give those same words again rather than adding to them | Hannah named it as the fourth item on her list, and F11 holds your reason as you stated it. EXP because it checks that your reason fits your history, not a skill |
| A2 | "What salary are you expecting?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot, your own figure and nothing around it: "I'm hoping for £42,000." No range, floor or flexibility is coached, because you gave none. If she asks what you earn now, you can decline that and return to the figure you gave and the band in the advert | Salary is first on her list; F9 shows the figure inside the advert's band, so the rehearsal is saying it cleanly. JD because the advert states the pay term |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words. If you are not certain of its exact length, say so plainly and say you will confirm it | Second on her list; F12 shows it is not yet stated anywhere. JD because it is a term of taking the job |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot, your own words whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she raises more days or the journey, give the same words again | Third on her list; F10 is shown met at two days. JD because the advert states the hybrid pattern |
| A5 | "Tell me about your current role." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots and chase suppliers when orders slip" "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc with three beats, each a clause your sentences state: 4 years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell it in your own words and stop there. Answer slot: the advert names planning and QA, so expect a probe on whether your role touched them; if it did, say how; if not, say so plainly and stay with the depots and the suppliers | The biography is where F1, F3 and F5 get heard together. EXP because it tests whether the written account survives retelling |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. What have you done that's like that?" | JD | [grounded] "I schedule deliveries for our three depots" | The highest-ROI rehearsal in this pack. Hold only the sentence: "I schedule deliveries for our three depots." The limit is the pack's observation, not words for you: your material says deliveries and depots, not production schedules. Answer slot: the advert names planning, the warehouse and QA, so expect a probe on which of them your scheduling touched; if any, say which and how, in your own words; if none, or it was not yours, say so plainly and stay with the three depots. Follow-up level 1, if she asks who or what you scheduled with: stay inside the sentence. Level 2, if she asks whether that is comparable: return to the sentence and leave the comparison to her. Level 3, if she asks what you would need to learn: answer as a plan in your own words, never as a past | F2 is where the advert's first duty presses hardest, so this objection arrives in some form. JD because it scores the stated duty |
| B2 | "Have you worked with SAP or any similar system?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Say it plainly: "Never used SAP — we run our own in-house stock system." Answer slot: the advert lists ERP as a plus, so expect a probe on the in-house system; if you use it yourself, say for what, in your own words; if you do not, or it is not comparable to an ERP, say so plainly. Then, as a plan and not a past, say how you would get up to speed on a new system, in your own words. No claim to SAP work | F7 is a stated absence on a plus, not a requirement. JD because it scores the advert's ERP line |
| B3 | "How do you keep track of supplier deliveries?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Start from your sentence: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: the advert's tracking line makes a probe on how you follow deliveries likely; if you follow them in a particular way, say how, in your own words; if there was no such tracking, or it was not yours, say so plainly and stay with the chasing | F4 is discovery: the material touches tracking without showing it. JD because the advert states the duty |
| B4 | "How confident are you in Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Lead with the sentence: "I rebuilt our stock-count spreadsheet." Answer slot: the advert asks for confidence with Excel and your sentence says spreadsheet; if it was Excel, say what you did in it, in your own words; if it was another tool, say which; if parts were not yours, say so | F6 is discovery on the tool's name. JD because Excel is a stated requirement |

### C. Data-driven prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Use the figure at its own size: "about a third", "over a year". Answer slot: say how it was counted, in your own words; if you do not know how it was counted, say so plainly. Do not offer a baseline or method you could not repeat under a second question | F5 carries the pack's one figure. EXP because the probe is on what the number rests on |
| C2 | "Which assumption behind that third would you defend least?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Name, in your own words, the assumption you would defend least before she does; the pack names none because your sentence names none. If you cannot name one, say plainly that you do not know how the figure was counted | The weakest-assumption move turns a gotcha into credibility; F5 is where it applies. EXP for the same reason as C1 |
| C3 | "The role reports weekly on on-time dispatch. What reporting have you done?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Answer slot: if you report regularly on deliveries or stock, say what, how often and to whom, in your own words; if no regular reporting was part of your job, say so plainly and return to "I rebuilt our stock-count spreadsheet" | F8 is discovery: nothing in the material shows reporting. JD because the advert states the duty |

### D. Case / strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a delivery that a production run needs will be a week late. What do you do first?" | CASE | [generic] | Structure it aloud: what you would ask first (what the run needs, what stock covers it, whether the new date is firm, whether another source exists); who you would tell and what you would ask of each, naming planning, the warehouse and QA as the advert does; how the schedule changes; what you would record and chase. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's schedule and chasing duties, covering F2, F3 and F4's requirements as a decision rather than a record. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| D2 | "The system shows 200 units but the shelf count says 180. What do you do?" | CASE | [generic] | Structure it: recount first, then check recent movements for anything unbooked, then correct the record with a note of why, then look for a pattern. Make no claim about your past | A live problem from the advert's stock-records duty (F5's requirement). `[generic]` for the same reason as D1 |
| D3 | "What do you know about Quillmoor?" | CO | [grounded] | From the advert: "diagnostic-test manufacturer, about 400 staff". The pack found nothing more, so do not repeat anything you have not read yourself. Answer slot: if you have read about them, say one thing, in your own words; if you have not, say so plainly and ask her about the team | CO because it scores awareness of the employer; the research that would sharpen it was not available |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has used SAP?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler" "I schedule deliveries for our three depots and chase suppliers when orders slip" "Never used SAP — we run our own in-house stock system" | Pause and restate the question. Hold the quoted work: 4 years as a logistics coordinator at a building-supplies wholesaler, scheduling deliveries for three depots and chasing suppliers when orders slip. Concede the one thing you stated, specifically: "Never used SAP." Do not fold on the work to restore harmony, and do not claim to be better than anyone; say what you bring and let her weigh it | F7 is the gap a pressure interviewer reaches for. JD because it scores the advert's ERP line under time pressure |
| E2 | "That fall in discrepancies — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold on the sentence: "I rebuilt our stock-count spreadsheet." The pack's observation: your sentence states the rebuild and the fall, and does not say what caused the fall. Answer slot: say what part of the fall you can attribute to the rebuild and what you cannot, in your own words; if you do not know, say so plainly. Hold through two follow-ups by returning to the sentence, never by adding to it | Attribution probes exist to catch inflation; F5 is where one would land. EXP because it tests what was yours |

### F. Peer evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Planning and QA disagree about a schedule and you are in the middle. What happens?" | CASE | [generic] | Structure it: hear each side's constraint, find what is fixed and what is not, propose an option, say when you would escalate, record the decision. Make no claim about your past | The advert's three-function coordination makes this a natural seam problem (F2's requirement). `[generic]` because it is a pattern, not a fact about this employer |
| F2 | "How do you handle it when credit for work is shared across teams?" | EXP | [generic] | Selection scaffold: pick a time work spanned teams; it needs a named piece that was yours, one thing you credited another team for, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer stem used as an open prompt; the theme is the advert's cross-function coordination. EXP because it tests attribution honesty |

### Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A5, E1 |
| Coordinate production schedules between planning, the warehouse and QA | B1, D1, F1 |
| Track supplier deliveries | B3 |
| Chase late orders | A5, D1 |
| Keep stock records accurate | C1, C2, D2 |
| Report weekly on on-time dispatch | C3 |
| Confident with Excel | B4 |
| ERP experience (SAP or similar) a plus | B2, E1 |
| £38,000–£44,000 | A2 |
| Hybrid, two days a week at Avonmouth | A4 |
| Hannah's topic: notice period | A3 |
| Hannah's topic: what's prompting a move | A1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Where does the handoff between planning, the warehouse and QA come under most strain week to week?" | Shows you understand the advert's central duty and lets you hear what the work is before a hiring manager tests you on it |
| R2 | "What system does the team use for stock and orders, and how is a new starter trained on it?" | Puts the ERP plus on the table as a learning question, which fits a stated absence and a plan to ramp |
| R3 | "How does the team measure success at six months, and does the weekly on-time dispatch report feed it?" | Ties to the reporting duty and shows you are thinking about outcomes, not tasks |
| R4 | "Are the two Avonmouth days fixed, or agreed within the team?" | Learns how the hybrid pattern actually runs without reopening anything you have already said |
| R5 | "What would a strong first month look like?" | Signals readiness to contribute early and gives you a concrete picture of the first steps |
| R6 | "Is there anything from what I have said today you would like me to expand on before next steps?" | Gives you one chance to repair a weak answer before she writes it up |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots". The limit is the pack's observation: the material says deliveries and depots, not production schedules. B1's slot stays inside the depots |
| Has used SAP | Negative the candidate stated, F7 | "Never used SAP — we run our own in-house stock system". The plain acknowledgment is "Never used SAP"; no slot |
| The in-house stock system is an ERP | Inflated form of F7 | F7's quote at its own scope: "we run our own in-house stock system". The pack's observation: the material does not say whether it is comparable to an ERP; B2's slot lets either answer stand |
| My spreadsheet rebuild cut discrepancies by a third | Inflated form of F5 | F5's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year". The pack's observation: the sentence states the rebuild and the fall, with "about", and does not say what caused the fall |
| Three days a week at Avonmouth is fine | Inflated form of F10 | F10's quote at its own scope: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three". The pack's observation: the sentence says two days is fine and names a limit at three |
| My role is being made redundant | Inflated form of F11 | F11's quote at its own scope: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want". The pack's observation: the sentence says the office is closing and the only offer is Reading, not that your role is being cut |

## Sources

- Provided documents: your message (the advert text, Hannah Lowther's LinkedIn message, and your own statements about your role, pay, location and reasons). No dossier was present.
- Searches sent: "Quillmoor Diagnostics company values" (refused); "Quillmoor Diagnostics Avonmouth Bristol" (refused); "Hannah Lowther Talent Partner Quillmoor Diagnostics" (refused). No fetches. Nothing from the web or from memory is used about Quillmoor, its values, its process or Hannah.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | The call was refused. It would have fed a values cheat sheet and VAL questions, but no values round is documented, so no section is lost |
| 2. `Quillmoor Diagnostics interview process operations` | unavailable | No call sent: searching was refused on every call. It would have documented the later rounds and reweighted the personas beyond this call |
| 3. `Quillmoor Diagnostics` recent news (query sent as "Quillmoor Diagnostics Avonmouth Bristol") | unavailable | The call was refused. It would have fed D3 and a grounding brief; D3 stays on the advert's own description |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | The call was refused. It would have fed a reading of the interviewer and a reverse question tied to her path; the pack has neither |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and every JD-tagged question |

## Upgrade menu

- Your CV, or the stock-count spreadsheet's before-and-after discrepancy report → F1 and F5 gain something inspectable behind them, so their confidence can rise from medium and C1 and C2 stop resting on a single sentence
- Your notice period → F12 and A3 carry your own words instead of an instruction
- Your answers to the answer slots in B1, B3, B4 and C3 (production scheduling, tracking, Excel, reporting) → F2, F4, F6 and F8 regenerate from your own words, and the matching guidance cells become story maps
- Search permission, or Quillmoor's values and careers pages pasted in → a grounding brief, any documented values round, and a sharper D3; a deeper research pass is offered once here: up to 6 more searches and 2 more fetches, several more minutes
- Hannah's public profile link or pasted About text → a reading of the interviewer and a reverse question tied to her path
- Anything Hannah or the advert says about later rounds → a mini-pack per round in place of the generic screen, hiring manager, panel assumption
- A `tuesday-dossier.md` from an earlier evidence check → verified-evidence grading and a binding prohibited-claims list in place of the one built locally here
