Reading the skill's rules took a while. Next I'm running three quick searches on Brennock Facilities Ltd (values, interview process, recent news), then I'll build the prep pack.
Before the prep, one thing in the invite. It asks you to "please transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "please also reply with a photo of your passport and your bank details before the interview", and says "Successful candidates receive a cheque for €1,850 to buy a laptop and desk from our approved vendor: you deposit the cheque and send the balance on to the vendor." Paying a fee, sending passport and bank details before any offer, and depositing a cheque then passing money on are a known scam pattern, and the fee and the cheque arrangement are very likely a scam. Hold all three until you have checked the invite with the employer, using contact details you find yourself on its own website or careers page, not any in the invite or from whoever sent it. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-5/rooms/case-12-denied-0ef20b36/brennock-facilities_remote-administrative-assistant_interview_pack.md`. I built it for a hiring-manager round, assuming the office manager would be your future manager. The pack has 18 questions in five styles, plus reverse questions and a coverage table for the four duties.

- **Likeliest tough question:** your chasing unpaid invoices set against processing supplier invoices (B1). Your material says "chased unpaid invoices", not processing them, so the pack coaches you to hold that line honestly and give a plan for learning the rest.
- **Thinner spots:** travel booking and Excel depth, where your material is silent or modest. Those are slots for your own truthful answer, not claims the pack makes for you.
- **Research:** the web searches I tried on the company were refused, so no company facts are in the pack. Its Sources section says so.

Say the word and I'll play the skeptical interviewer on B1 so you can rehearse it live. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager likely to be your future manager or a peer? The answer reweights the question banks. Can you paste the ad's full text? That would turn the four duties you relayed into its exact wording.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Candidate: Aoife. Interviewer: the office manager, name not given. Format: a 30-minute video call, as the invite states. Relationship assumed: future manager (hiring-manager round), because the invite does not say. This is a first version.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script. Every claim about your past rests on a sentence you wrote, quoted next to it. Where your material does not say, the guidance is an answer slot: answer it truthfully, and if the honest answer is "I haven't", say that plainly.

Type key:

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether what you say about your experience holds up when probed |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, scored on structure and reasoning |

Labels: `[grounded]` traces to something you provided; `[inferred]` is derived from a fetched typical source; `[generic]` is a role-family pattern with no claim about this employer.

## Fit snapshot

The requirements are the four duties you relayed from the ad. The pack built it from your message alone, with no CV and no full ad text.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you relayed it | "ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says an appointment book for four physios, and the words stay there: "I ran the appointment book for four physios." Answer slot: the ad's calendars line makes a probe on how that compares with managing colleagues' diaries likely. If any of it carried over, say what, in your own words; if it did not, or you have not managed anyone's diary, say so plainly and stay with the appointment book |
| F2 | "booking travel" — the ad, as you relayed it | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: if you have booked travel for anyone, at work or elsewhere, say what, in your own words; if you have not, say so plainly, then say how you would learn the employer's way of doing it |
| F3 | "preparing documents in Word and Excel" — the ad, as you relayed it | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | discovery | The words are your own: "I'm good with Word, okay with Excel." Your material does not show what you have prepared in either. Answer slot: if you have made documents or spreadsheets in them, say which, in your own words; if you have not at work, say so plainly, then say what you would practise first |
| F4 | "processing supplier invoices" — the ad, as you relayed it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, not processing supplier invoices, and does not say whose invoices they were. The words stay at scope: "I chased unpaid invoices." Answer slot: if any invoices you handled were from suppliers, or you did more than chase, say what and which part was yours; if you only chased, say so plainly and stay with that |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems drawn from the four duties: a diary clash, a travel booking, a mismatched invoice | High. A hiring-manager round tends to be case-led, and the four duties are easy to turn into short scenarios | Clarify first, then give a short order of steps, then say what you would record. No claim about your past needed |
| Skeptic | Quiet probing of the distance between a clinic reception role and supplier-invoice and travel work | High. Two of the four duties (F2, F4) are where your material is thinnest | Rehearse the likeliest objection until it is boring: say what you did, plainly, then your ramp plan |
| Conversational | Friendly opener, remote-working chat, "what do you want to learn" | Medium. A 30-minute video call usually opens this way, and the questions are still scored | A 90-second arc built only from your own sentences |
| Data-Driven Prober | Line-by-line questions on the appointment book, the invoices and Excel | Medium. Your background is short, so each line will be tested | Know what you can and cannot say about each line; say plainly what you do not know |
| Peer Evaluator | Collegial questions on priorities, handoffs and credit | Medium-low. An office manager may be a peer or a boss, and the invite does not say | Reciprocity: what you would take off their plate, not only what you need |

Weights rest on the relationship prior (hiring manager) and on the one round you described. No loop source establishes more than this one conversation, so the pack does not guess other rounds. No Pressure persona is included: a single 30-minute chat with an office manager gives no source for one. No values-style round is detected, so there is no values cheat sheet.

## Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people you support ask for the same hour on Thursday, and one of them is travelling that day. What do you do?" | CASE | [generic] | Structure it aloud: what you would ask first (whose meeting is fixed, whose can move, and who decides), what options you would offer both people, how you would confirm the outcome in writing, and what you would note down. The question needs no claim about your past, so the guidance makes none | The ad's calendars line (F1), asked as a decision. CASE because it scores structure, not history |
| A2 | "My manager must be in Cork for 9am Tuesday and back for a 5pm meeting. How do you go about booking it?" | CASE | [generic] | Clarify before you book: budget or policy, how flexible the times are, who pays and how, any preferences. Then give two options with the trade-off, confirm the choice, send the itinerary and keep a record. Say it as a method you would use, never as something you have done | The ad's travel line (F2), where your material is silent. CASE lets you show method without a past claim |
| A3 | "A supplier invoice arrives that does not match what was ordered. What do you do?" | CASE | [generic] | Do not pay or process it yet. Check it against the order and delivery, tell whoever placed the order, ask the supplier for a corrected invoice or credit note, and record what happened. Say it as your approach | The ad's invoice line (F4), in a form where the honest answer is a method |
| A4 | "I give you rough meeting notes at 3pm and want a clean one-page summary by 5pm. What do you need to know before you start?" | CASE | [generic] | Ask who it is for, what format, what must be in it, and what the deadline really is. Then draft, check it once, and send. Say it as an approach | The ad's documents line (F3). Scores clarifying before producing |
| A5 | "At 9am you have a diary clash, an invoice due today and a travel change. In what order, and why?" | CASE | [generic] | State what you would check first (what is due when, and what each costs if it slips), say your order aloud, and say who you would tell. Naming your reasoning matters more than the order | Tests prioritising across all four duties. A short answer that shows reasoning scores well |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You chased unpaid invoices. Processing supplier invoices is different work. Where would you be starting from?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I chased unpaid invoices." Answer slot: if any invoices you handled were from suppliers, or you did more than chase, say what and which part was yours; if you only chased, say so plainly and stay with that. Then give your ramp plan as a plan, not a past: how you would learn their approval and payment steps in the first weeks. Hold through two follow-ups by returning to what you did, never by adding to it | F4 is the likeliest place to be probed, because the ad's invoice duty is wider than the quote. JD because it scores the stated requirement |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel" | Name one real part, in your own words, and say how you would close it. Answer slot: the ad's travel line (F2) and invoice line (F4) make those the likeliest. If you have done any of it, say what and which part was yours; if none, say so plainly. Your own words on the tools: "I'm good with Word, okay with Excel." | The stem every Skeptic uses. Candour about a real gap, with a plan, scores better than a bluff |
| B3 | "Your background is a clinic appointment book. What carries over to managing calendars here?" | JD | [grounded] "ran the appointment book for four physios" | Say it at its own scope: "I ran the appointment book for four physios." Answer slot: if any part of how you worked would carry over to colleagues' diaries, say what, in your own words; if you have not managed anyone's diary, say so plainly and say what you would ask on day one. Let the interviewer draw any bigger inference | F1 is adjacent work, not the same work. JD because it scores the calendars requirement |
| B4 | "Why move from reception to a remote admin role, and why now?" | EXP | [generic] | Give your actual reason in one or two sentences, in your own words, pointed at what draws you to this work. No reason is supplied here, and none should be invented. Keep it forward-looking and about the job | The motivation probe every Skeptic runs. EXP because your own account of your path is what is tested |

### C. Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey: how did you get to this point?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" and "ran the appointment book for four physios" and "chased unpaid invoices" | A 90-second arc with only these beats: two years as a receptionist at a physiotherapy clinic; the appointment book for four physios, which you ran; the unpaid invoices you chased. Then your own reason for this role, in your own words. Practise it aloud until it is under two minutes | The opener of most friendly chats and still scored. Built only from the three sentences |
| C2 | "You'd be working from home. What does your set-up look like, and how do you keep your day organised?" | JD | [generic] | Describe your actual set-up and routine, truthfully and briefly. Answer slot: if you have worked from home before, say how it went in your own words; if you have not, say so plainly and say how you would structure a day | The role title in the invite says remote, so expect this. It asks about the present, not a past claim |
| C3 | "What would you most want to learn in your first three months?" | JD | [generic] | Pick from the four duties the one you want to get strongest at, and say how you would learn it. A plan, not a past. Choosing a duty that is a real gap for you reads as self-aware | Casual, but scores genuine interest and honest self-assessment |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about the appointment book for four physios: what was it and how did you use it?" | EXP | [grounded] "ran the appointment book for four physios" | Start with the quote: "I ran the appointment book for four physios." The figure here is the four. Say in your own words how it was counted, the thing about it you would defend least, and which part of running it was yours. If you do not know how something was counted, say so plainly | The CV line a prober tests first. EXP because it scores attribution |
| D2 | "Tell me about chasing unpaid invoices: what was your part in it?" | EXP | [grounded] "chased unpaid invoices" | Say what you did in your own words and where your part ended. Answer slot: if someone else issued or approved the invoices, say so; if you only chased, say so plainly. Never describe a step you did not take | F4 again, collegially packaged. Rehearsing it here means B1 holds under a second follow-up |
| D3 | "You've said you're okay with Excel. What would you be comfortable doing on day one, and what would you need to practise?" | JD | [grounded] "I'm good with Word, okay with Excel" | Start with your own words: "I'm good with Word, okay with Excel." Answer slot: say what you have actually done in Excel; if you have not used something the job may need, say so plainly. Then name one specific thing you will practise before the call or start date, and do it | F3. The ad lists Excel with Word, and your own rating is lower for Excel, so expect the follow-up |

### E. Peer Evaluator (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A colleague hands you a rush task while you're halfway through another. What do you do?" | CASE | [generic] | Say what you would ask (how urgent, what slips, who else is waiting), how you would tell the person whose task waits, and how you would confirm the new order. A method, not a past claim | Tests partnership and priority handling, with a collegial feel |
| E2 | "Where does your job stop and ours start? For example, who approves an invoice?" | JD | [generic] | Offer principles instead of pretending to know their seam: you prepare and flag, the person with authority approves, and you ask when unsure. Then ask how they would like it split | The seam question. The ad's invoice line (F4) makes approval a real topic |
| E3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Pick one time you worked with others on a single task: it needs a named piece that was yours and a fair way of crediting others. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The standard peer stem. Selection scaffold because none of your sentences carries a team story |

## Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | A1, A5, B3, C2 |
| "booking travel" | A2, A5, B2 |
| "preparing documents in Word and Excel" | A4, B2, D3 |
| "processing supplier invoices" | A3, B1, D2, E2 |

CO and VAL coverage is thin because no company page was readable; see Sources.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a typical week of diary and travel work look like, and how many people would I be supporting?" | Shows you are thinking about the scale of F1 and F2, and gives you the facts to prepare |
| R2 | "Which tools do you use for calendars, travel booking and invoices?" | Lets you say honestly what you already know and what you would learn first |
| R3 | "How does a supplier invoice get from arriving to being paid here, and where would I fit in that?" | Shows care about the approval seam (E2) and about getting invoices right |
| R4 | "What would a good first month look like?" | Turns the interview into a plan and signals you expect to ramp up |
| R5 | "How are tasks handed to a remote assistant, and how do you like to be updated?" | Shows you have thought about working at a distance (C2) |
| R6 | "What could a new person do in their first month that would genuinely help you?" | A reciprocity question, useful if the office manager turns out to be a peer |
| R7 | "What is the next step after this call, and when should I expect to hear?" | A prep-reason question about the process: it lets you plan your availability |

## Prohibited claims

Each entry is wording this pack will not coach, with its basis and the honest form. The limit is the pack's own observation, not words for you.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed people's calendars or diaries | Inflated form of F1 | "I ran the appointment book for four physios." Your material says an appointment book, not colleagues' calendars |
| Processed supplier invoices | Inflated form of F4 | "I chased unpaid invoices." Your material says chasing, and does not say whose invoices |
| Strong or advanced Excel skills | Inflated form of F3 | "I'm good with Word, okay with Excel." |

Booking travel is not listed: your material is silent on it, so it is an answer slot in F2 and not a claim to refuse.

## Sources

Provided: your message, which contained the invite text, your account of the ad's duties, and your background.

Searches sent, all refused, so nothing from the web is used in this pack:

- Brennock Facilities Ltd values: refused
- Brennock Facilities Ltd interview process administrative assistant: refused
- Brennock Facilities Ltd news strategy: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | Every call was refused. It would have fed a values cheat sheet and VAL questions, which are absent |
| 2. interview process for the role family | unavailable | Every call was refused. It would have fed persona weights; they rest on the round you described and on a hiring-manager prior |
| 3. strategy and recent news | unavailable | Every call was refused. It would have fed CO questions, which are absent |
| 4. interviewer name | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative role JD | skipped | The duties you relayed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → the four rows above could gain further requirements, and any `[inferred]` or thin rows could become `[grounded]`
- Your CV → more of your own sentences for the fit snapshot, and stories mapped to questions where this pack gives selection scaffolds
- A reference or an anonymised sample of a document or spreadsheet you made → raises F1, F3 and F4 from medium toward high
- The office manager's name and role (future manager or peer) → persona weights and a tailored reverse question
- Whatever the employer has said about what the 30 minutes will cover → coverage of anything it names
- Permission to run web searches, or the employer's own values and about pages pasted in → a values-style check, CO questions, and loop structure
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief for CO and CASE questions
- A tuesday-dossier.md → verified evidence and a prohibited-claims list from a prior assessment, replacing the one built here
