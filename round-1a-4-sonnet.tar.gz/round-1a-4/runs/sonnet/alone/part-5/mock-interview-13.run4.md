I'll read the reference files this skill points to before building the pack.
Search was refused on all four calls, so company and recruiter research is unavailable. The pack leans on your advert and your own words. I'm writing it now.
Your prep pack is saved as `quillmoor-diagnostics_operations-coordinator_interview_pack.md`. It's built for Hannah's 30-minute recruiter screen on Thursday at 2pm, using only your advert, her message and what you told me. All four of my web searches were refused. That means there's no company or Hannah research in it, and the "what do you know about us" question rests on the advert alone.

The most likely hard moment is the production-scheduling question (B1 in the pack). Your material says you schedule deliveries for three depots, and the advert's lead duty is production schedules. B1 gives you words that stay at deliveries, plus a plan for follow-ups, without claiming more.

The pack also keeps a few things at the scope you stated:
- **Pay, hybrid and your reason for moving:** these are in your own words and nothing is added.
- **SAP:** "Never used SAP", then what your in-house system is and what you use it for.
- **Stock-count spreadsheet:** it keeps "about a third over a year". It doesn't say the rebuild caused the fall, or that the spreadsheet was Excel, because your wording doesn't say either.

Say the word and I'll play Hannah on B1 and give you feedback against the pack's guidance.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

What is your notice period? It's the one term your material doesn't cover, and your answer would replace the instruction in A3 with your own words.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call, Thursday 2pm. Hannah Lowther (Talent Partner) rings the mobile number on your application.
**Her stated agenda:** "your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move", then the team and the next steps.
**Built for:** Sam. This is a first version, not a regeneration.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script, and every line you say aloud should be something you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your claims survive scrutiny; what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | What you know about the company and its strategy |
| CASE | A live problem from the role, answered with structure |

An **answer slot** is an instruction for the interview, not a question for you now. It has two honest branches: say what you did in your own words, or say plainly that there was no such step or it was not yours. A **logistics slot** is the same idea for pay, notice, location and reason for leaving: the only safe answer is your own.

The highest-ROI rehearsal in this pack is **B1**, the production-scheduling question. The advert's lead duty is coordinating production schedules, and your material's nearest line stops at deliveries. Some form of that question is the likeliest to arrive.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap on the years, but a self-reported line with nothing inspected behind it, so expect a probe. Say it in the quote's own terms: four years as a logistics coordinator at a building-supplies wholesaler. Your material says a wholesaler and the advert describes a manufacturer; F2 is where that difference bites |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for the depots, not production schedules, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so a probe on who you scheduled with is likely. If any of your scheduling was done with other teams, say which and how, in your own words; if it was not, or was not yours, say so plainly and stay with the depots |
| F3 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms: you chase suppliers when orders slip. Say it in those words, because a named duty beats an adjective. Nothing is inspected behind it, so expect a probe |
| F4 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The sentence says scheduling and chasing; it does not show how deliveries are tracked. Answer slot: if you track supplier deliveries, say how, in your own words; if there is no tracking step, or it was not yours, say so plainly and stay with chasing suppliers when orders slip |
| F5 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The quote reaches the requirement in your own terms. Keep "about a third over a year" exactly as said. Because it is a figure, expect the four questions a figure raises: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. C1 and E2 hold those slots |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says a spreadsheet and does not say which tool. Answer slot: if it was Excel, say what you did in it, in your own words; if it was another tool, or you did little in it, say so plainly and stay with the stock-count spreadsheet |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so: "Never used SAP." The advert marks it a plus, and the "or similar" half is open: your material names an in-house stock system and does not say what it covers. Answer slot: say what that system is and what you use it for, in your own words; if it does not fit the advert's "or similar", say so plainly. How you would learn a new system is a plan, said as a plan, never as a past |
| F8 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not say either way. Answer slot: if you report regularly on deliveries or dispatch, say what and how often, in your own words; if you do not, say so plainly and say what you would want to know first |
| F9 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | Pay is a term, and your figure sits inside the advertised band; that observation is all the pack adds. Say it as you gave it: "I'm hoping for £42,000." Nothing else is coached on it |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert; "how the hybrid pattern would work for you" — Hannah's message | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The term is met as you stated it. Say it in your own words as given and add nothing |
| F11 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish your notice period. It is surfaced, not bridged: no wording changes it, and A3 is a logistics slot for your actual answer |
| F12 | "what's prompting a move" — Hannah's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | The reason is stated and complete. Say it as you gave it; a follow-up on it gets your own words again, nothing added |

## Persona weights and table

**Reasoning shown.**
1. **Relationship prior:** a recruiter screen starts at Conversational plus a light Skeptic.
2. **Her agenda:** Hannah named four logistics topics, then "the team and the next steps". That points to a friendly register, with logistics doing most of the scoring.
3. **The loop:** her message establishes this one session and who runs it. No source names later rounds, so nothing about them is assumed. The three lower-weight personas are hedges for later conversations, kept short.

Recalibrate if you know more about who you meet after this call.

| Persona | How it shows up on Thursday | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational / Rapport | Hannah's four logistics topics, plus an opening "tell me about your background" | Highest (5 questions). Her own agenda is logistics in a conversational register, and casual questions are still scored | A 90-second arc built only from your stated lines; logistics answers in your own words, short |
| B. Skeptic | Quiet probing of the lead duty and the SAP line | High (4). F2 is the advert's lead duty and F7 is a stated gap, so both are predictable even in a friendly screen | Rehearse B1 until it is boring: hold on what your lines say, concede the limit in the quote's own scope, never add to it |
| C. Data-Driven Prober | Reading your stock-count line closely | Medium (3). It is the one figure in your material, and a recruiter can still ask how it was counted | Know what you can say about how it was counted, and say plainly where you do not know |
| D. Case / Strategist | One live scenario about a late supplier or the weekly report | Low (2). Not this call's usual register, but the advert's duties are easy to turn into a scenario | Clarify first, structure, then answer; think aloud |
| E. Pressure | "Sixty seconds, why you?" and an attribution probe | Low (2). A hedge only; her stated agenda is not adversarial | Pause, restate, hold on your stated lines |
| F. Peer Evaluator | Seam questions between planning, warehouse and QA | Low (2). More likely in a later conversation with the team, which no source has named | Offer seam principles rather than pretending to know the seam |

## Question banks

### A. Conversational / Rapport (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, tell me about your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on F1, F2 and F3, with only the beats the quotes state: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip. Say them in your own words in about 90 seconds and stop, letting her draw any link to the advert. Add no adjectives the sentences do not carry | The opener is nearly certain, and an unrehearsed biography runs long. F1 to F3 are the lines it draws on. EXP because it scores whether the account matches the material |
| A2 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | A logistics slot, and the figure is yours: say it as you gave it, "I'm hoping for £42,000." Nothing is added to it. If she asks what you earn now, declining or redirecting to this role's advertised band, "£38,000–£44,000", is an option, and whether to is your call | Hannah named salary expectations first, so this is certain. F9 holds the evidence. JD because pay is a term of the listed job |
| A3 | "What's your notice period?" | JD | [grounded] | A logistics slot: give your actual notice period, in your own words. If you are not sure of the exact length, say so plainly and say you will confirm it | Hannah named it in her message, so it is certain. F11 is the open gate row, which no wording changes. JD because notice is a term of the job she is filling |
| A4 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | A logistics slot, and the words are yours: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on the journey or the limit, your own words were that; nothing is added | Hannah named the hybrid pattern in her message. F10 holds the stated term. JD because the pattern is the advert's own |
| A5 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | A logistics slot: say your reason as you gave it, short: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." A follow-up on the office or on Reading gets those same words, with no reasons added | Hannah named it, and recruiters check that the reason is consistent. F12 is the evidence. EXP because it scores whether your account matches your circumstances |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This job coordinates production schedules between planning, the warehouse and QA. What have you done that's closest to that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | **Highest-ROI rehearsal.** Lead with what the sentence says and stop there. The limit, as the pack's own observation: your material says deliveries for the depots, not production schedules. Your concession words are the quote's own: "What I schedule is deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so a probe on who you scheduled with is likely. If any of your scheduling was done with other teams, say which and how, in your own words; if it was not, or was not yours, say so plainly and stay with the depots. Follow-up 1, "how different is production from deliveries?": say how you see the difference only as far as you know it, and say plainly where you do not. Follow-up 2, "how would you get up to speed?": a plan, said as a plan, never as a past. Follow-up 3, "isn't that a stretch?": hold by returning to the depots; never add to them | F2 is the advert's lead duty and the material's nearest line, so this is the objection that arrives in some form. JD because it scores the stated requirement; Skeptic because it is quiet, persistent probing of the gap. It gets the most follow-up levels because it is the likeliest hit |
| B2 | "The advert says SAP or similar. I don't see SAP in your background. How would you handle that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Plain acknowledgment, from your own words: "Never used SAP." The advert marks it "a plus", so keep the register calm. Answer slot: say what your in-house stock system is and what you use it for, in your own words; if it does not fit the advert's "or similar", say so plainly. Then how you would learn a new system, as a plan and never as a past | F7 is a stated gap, and a recruiter can ask in one line. JD because it scores a listed plus; Skeptic because it targets the gap directly |
| B3 | "What do you know about Quillmoor?" | CO | [grounded] "Operations Coordinator — Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff)." | The only source this pack can stand on is the advert: a diagnostic-test manufacturer of about 400 staff, with an Avonmouth site in Bristol. Say what you read there in your own words. Anything further has to come from a page you have read yourself, because the pack's research was refused. Answer slot: if some part of the role's content appeals, say which; if nothing in particular does yet, say so plainly and say what you would like to learn on the call | A recruiter asks this to check basic homework. CO because it scores company knowledge; it is advert-only because the searches were refused |
| B4 | "You're coming from building supplies and this is diagnostics. What makes the move across sectors make sense?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Start from what the quote says and stay at its scope. Answer slot: if something about diagnostics draws you, say what, in your own words; if the draw is the role's content rather than the sector, say so plainly. Do not claim an interest the advert alone gave you | F1 is a wholesaler and the advert is a manufacturer, so the sector switch is a natural "why". EXP because it tests motivation consistency; Skeptic because it targets background mismatch |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third over a year. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the figure as it stands, "about a third over a year", never rounded or turned into a percentage. Answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption you would defend least, named before she does. If you do not know how it was counted, say so plainly | F5 is the one figure in your material, and any figure is a target for the defend-the-number probe. EXP because it tests whether the claim survives scrutiny |
| C2 | "You rebuilt a stock-count spreadsheet. What tool was it in, and how confident are you with Excel?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say what you rebuilt, in the quote's words. Answer slot, tool: if it was Excel, say what you did in it; if it was another tool, or you did little in it, say so plainly. Answer slot, the rebuild: say what changed in it, in your own words; if it was smaller than "rebuilt" suggests, say so | F6 and F5 meet here: the advert asks for Excel and the sentence says only "spreadsheet". JD because it scores a stated requirement |
| C3 | "How do you track supplier deliveries, and what do you do when one is late?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The chasing half is story-mapped from the quote: "chase suppliers when orders slip". Say it in those words. Answer slot, tracking: if you track supplier deliveries, say how; if there is no tracking step, or it was not yours, say so plainly and stay with chasing. Any further step in how you chase is also an answer slot: if you have a set way, say it; if you do not, say so | F3 is covered by the quote, and F4 is the half it does not show. JD because both halves are in the advert's own line |

### D. Case / Strategist (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you at 9am that a delivery production needs on Monday will now arrive three days late. Walk me through what you do." | CASE | [generic] | Clarify first: what the delivery feeds, how firm the dates are, and what is on hand. Then say who needs to know, with the advert's own list of planning, the warehouse and QA. Set out your options with their trade-offs, choose one, and say what you would record and follow up. Think aloud. This question needs no claim about your past, so the guidance makes none | A live problem built from the advert's lines behind F2, F3 and F4. CASE because it scores structure; generic because it is a pattern, not a fact about this employer |
| D2 | "If you were building the weekly on-time dispatch report, what would you want in it?" | JD | [generic] | Clarify first: what counts as on time, against which date, which orders, and who reads it. Then structure the report and name the risks. Answer slot: if you produce any regular delivery or dispatch figures now, say what and how often; if you do not, say so plainly | F8 has no evidence either way, so this covers the requirement without claiming a practice. JD content with CASE delivery; generic because it makes no claim about you |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we put you through?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause and restate the question. Then three beats from the quotes: four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots; chasing suppliers when orders slip. If she pushes on the sector, hold on those words and concede only the scope they carry: your four years are at a building-supplies wholesaler | F1 to F3 are the lines available. JD because it scores fit to the advert; Pressure because it is time-boxed and invites defensiveness |
| E2 | "That stock-count result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold through two follow-ups by returning to the sentence. "I rebuilt" is your own attribution; the fall is stated alongside it. Answer slot: say what part was yours; if others contributed, or you do not know how much, say so plainly. Concede only what you actually do and do not know, and never fold on the core claim to restore the mood | F5 is attribution-sensitive. EXP because it scores attribution honesty; Pressure because the stem is the standard challenge to a stated result |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "This job sits between planning, the warehouse and QA. Where do you see the seam, and what happens when they disagree about a date?" | CASE | [generic] | Offer principles, not a map you cannot know: who owns the date, what gets recorded, when to escalate. Say what you would ask the team about how it works today. Frame what you bring them, not only what you need. No claim about your past is made | The advert names the three teams the job sits between, as in F2. CASE because it is a live seam problem; generic because it holds no entity-specific claim |
| F2 | "Tell me about a time you had to get two teams to agree on a date." | EXP | [generic] | An open prompt, raised by the advert's planning, warehouse and QA line. Pick a time with two named teams, a date at stake, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing you actually have, or how you would handle it | F2's cross-team coordination is the theme. EXP because it asks you to choose an instance; generic because no quote carries a story for it |

### Requirement coverage

| Stated requirement | Questions covering it |
|---|---|
| "2+ years in operations or logistics coordination" | A1, E1, B4 |
| "Coordinate production schedules between planning, the warehouse and QA" | B1, D1, F1, F2 |
| "track supplier deliveries and chase late orders" | C3, D1 |
| "keep stock records accurate" | C1, C2, E2 |
| "report weekly on on-time dispatch" | D2 |
| "confident with Excel" | C2 |
| "ERP experience (SAP or similar) a plus" | B2 |
| "£38,000–£44,000" | A2 |
| "Hybrid: two days a week at our Avonmouth site in Bristol." | A4 |
| "your notice period" and "what's prompting a move" (Hannah's message) | A3, A5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Is this a new role or a replacement, and who would I report to?" | It shows you are thinking about where the job sits, and the answer shapes how you pitch later rounds |
| R2 | "Which of planning, the warehouse and QA would I work most closely with day to day?" | It picks up the advert's own three teams and tells you where the seam in F1 will actually be |
| R3 | "What system does the team use day to day for stock and orders, and how is someone trained on it?" | It addresses the SAP line from the system side, so the gap is discussed as onboarding rather than as a mark against you |
| R4 | "Who reads the weekly on-time dispatch report, and what is it used for?" | It shows you read the reporting duty as something with an audience and a purpose |
| R5 | "Are the two Avonmouth days fixed days, or agreed with the team?" | It is a practical question about the pattern, and it shows you are planning around the site |
| R6 | "What are the next steps after today, and roughly when would the team hope to have someone start?" | It gets the process and timeline you will need, and links to your notice answer without re-opening it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Scheduled production, or has manufacturing or production-planning experience | Inflated form of F1 and F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: your material says deliveries and a wholesaler, not production or manufacturing. B1's slot stays inside the depots |
| Has used SAP | Negative the candidate stated, F7 | The plain acknowledgment: "Never used SAP." No slot |
| Has ERP experience through the in-house system | Inflated form of F7 | "We run our own in-house stock system" at its own scope. The limit is the pack's observation: your material names a system, not what it covers |
| Rebuilt the stock count in Excel | Inflated form of F5 and F6 | "Spreadsheet" at its own scope; C2's slot asks which tool, either branch honest |
| The rebuild produced the fall in discrepancies | Inflated form of F5 | The sentence at its own scope: you rebuilt it, and discrepancies fell by about a third over a year. The limit is the pack's observation: the sentence states both and does not say how they connect |

## Sources

**Provided documents:** the advert text you pasted; Hannah Lowther's LinkedIn message as you pasted it; your own description of your background, pay, location and reason for moving. No dossier was consumed.

**Searches sent, all refused by the host (no results returned):**
- `Quillmoor Diagnostics company values` — refused
- `Quillmoor Diagnostics Avonmouth Bristol diagnostic tests manufacturer news` — refused
- `Quillmoor Diagnostics interview process operations coordinator` — refused
- `Hannah Lowther Talent Partner Quillmoor Diagnostics` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have named the published values; no values-style round is detected here, so it would have themed VAL wording only |
| 2. `{company} interview process {role family}` | unavailable | Would have shown later rounds and moved persona weights beyond this call; the loop is established for this session only, by Hannah's message |
| 3. `{company} strategy` / recent news | unavailable | Would have moved B3 from advert-only to grounded in current company context |
| 4. `{interviewer name} {company}` | unavailable | Would have supplied a public-footprint interviewer read and a reverse question tied to her path; the section is absent without it |
| 5. representative `{role title}` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A3 moves from an instruction to your own words, and F11 stops being an open gate
- Your CV → F1 to F8 can be graded against the lines you wrote there, and F6 may settle which tool the stock-count spreadsheet was
- Something inspectable behind the stock-count figure, such as a before-and-after count record → F5 can rise from medium toward high, and C1's slots can be answered from the artifact
- Any note from Hannah on the later rounds or who you meet next → persona weights for D, E and F, which are hedges today
- Search access, so the company pages and Hannah's public professional footprint can be read → B3 becomes grounded, and an interviewer read and a reverse question tied to her path become possible
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a strategy brief for sharper CO and CASE questions
- A tuesday-dossier.md, if you already have one → verified evidence and the objection worth the deepest rehearsal come from it instead of this pack's inference
