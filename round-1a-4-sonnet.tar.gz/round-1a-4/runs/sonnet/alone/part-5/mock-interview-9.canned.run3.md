I'll read the reference files the skill points to before building the pack.
Status: I've run my research (4 searches and 2 page fetches on the district, the principal and a representative posting). I'm now writing the pack file.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-5/rooms/case-9-canned-93448125/halvering-elementary_fourth-grade-teacher_interview_pack.md`. It has 20 questions across six interview styles, 7 questions for you to ask them, and your fit table. I built it for a panel: Principal Vantongeren plus two fourth-grade teammates.

Your SSN and license number aren't needed for prep, so I didn't use them and left them out of the pack.

Two findings shape the pack:
- **Biggest prep item:** Question A1 is your likeliest objection, "you've only taught third grade." Rehearse saying your own words, "I haven't taught fourth grade," and then holding what your resume actually says.
- **Two things I found, worth knowing before Thursday:** The district's three published beliefs are "Every Child a Reader," "Families Are Partners," and "Teach for Tomorrow, Not for the Test." The principal is a former reading specialist, and the board adopted a literacy plan in 2026 that brings a new grades 3–5 reading curriculum from fall 2027. Both come from search snippets, so check them on the district's site.

I had no Halvering job posting, so most job-requirement rows rest on a representative posting from a job board and are labeled inferred.

Say the word and I'll play the principal on A1, the question the pack names as your highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Has HR said anything about format or focus, such as a demo lesson, a work sample or topics the panel will cover? A yes would add a build section for it and reweight the question banks.
2. Can you paste Halvering's actual posting? It would turn the inferred rows into grounded ones.
3. Do you want a deeper research pass, up to 6 more searches and 2 more fetches and several more minutes, on district strategy and the principal's talks?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Panel interview, 45 minutes, Thursday. Panel: Principal Dolores Vantongeren and two members of the fourth-grade team (not named in the invite). Built from your invite and your resume text. No job posting was supplied, so the job-requirement rows rest on a representative posting and are labeled inferred.

## How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did. An answer slot is an instruction for the interview, not a question for you now. Questions are lettered by persona (A1, A2, B1 and so on) so a drill can name them.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs, not generic virtue |
| EXP | Whether your own account of your work holds up, and what was actually yours |
| JD | The stated responsibilities and qualifications of the job, including your gaps |
| CO | How well you know the district and its current direction |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage

Built on the invite's "Thursday", taken as the coming Thursday, so about two days of preparation.

1. A1 until it is boring: the highest-ROI prep in this pack. Say the plain limit, hold your quoted material, add nothing.
2. E1 and E2: your 90-second path and your licensure, each in the exact words of your own sentences.
3. A4 and B3: your curriculum move and your family email, each held at its own scope.
4. C1 and reverse questions R1 to R3: the board's literacy plan and the principal's reading background.
5. One story each for D1 to D3, or the honest branch for each.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | No gap on the face of your material, and a gate the material shows met. It is a CV line with no record inspected behind it, so expect HR to check it themselves. Say it in the quote's own terms. The license number is not needed in this pack and stays with you; checking the record is yours |
| F2 | "experience in grades 3 to 5 preferred" — representative posting, K12 Jobs Board (fetched; not Halvering's posting) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Lead with the sentence in its own terms: six years, third grade, a public elementary school in Joliet. The preference comes from a representative posting, so Halvering's own may word it differently or omit it |
| F3 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then a ramp plan said as a plan and never as a past: what you would ask the fourth-grade team first and what you would read before you start, in your own words. Never a claim to fourth-grade classroom work, and nothing added to make the gap feel smaller |
| F4 | "plan and teach reading, writing, math, science and social studies" — representative posting, K12 Jobs Board (fetched) | "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [inferred] | discovery | The quote gives the grade and the years, and does not show which subjects were yours. Answer slot: if you taught these subjects, name which, in your own words; if you taught only some, or some were taught by someone else, say so plainly and stay with the six years in third grade |
| F5 | "differentiate instruction using assessment data" — representative posting, K12 Jobs Board (fetched) | none given | none | [inferred] | discovery | Your material does not show this either way, and the district's page says "assessments inform teaching and never replace it", so a probe is likely. Answer slot: if you have changed what you taught after looking at assessment results, give one instance in your own words; if not, say so plainly and answer as a plan |
| F6 | "communicate regularly with families" — representative posting, K12 Jobs Board (fetched) | "I write a weekly email to families." — your CV | medium | [inferred] | none | Lead with the sentence in its own terms. The pack's observation: the district's page words its belief as each teacher speaking with every family each term, and your quote is an email, so B3 holds a slot on conversations |
| F7 | "work with the grade-level team" — representative posting, K12 Jobs Board (fetched) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your CV | medium | [inferred] | none | Say both at their own scope: you led the move, and you have not been a team lead. Expect the panel to ask where one ends. The words stay with the quotes; what the move involved is an answer slot in A4 |
| F8 | "keep clear classroom routines" — representative posting, K12 Jobs Board (fetched) | none given | none | [inferred] | discovery | Your material does not show routines either way. Answer slot: if you have routines you would bring, name them in your own words; if you did not set them, or there were none, say so plainly and answer as a plan |
| F9 | "Every Child a Reader: no student leaves third grade without a reading plan." — Orrinsford Mission and Beliefs page (fetched) | "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | The words stay at the club: you have run it for two years. Your material says the club, and says nothing about reading plans. Answer slot in D1 stays inside the club |

## Reading the interviewer

Principal Vantongeren only; the two team members are not named, so their rows are peer priors.

| # | Finding | Provenance | Implication |
|---|---|---|---|
| I1 | Principal of Halvering Elementary since 2022 | [grounded] Illinois Principals Forum speaker page, search result snippet | She sets the panel's tone and is the likeliest source of the Skeptic and Case questions |
| I2 | Nine years as a reading specialist before that | [grounded] same snippet | Expect reading questions asked with a specialist's depth (derived reading, inferred) |
| I3 | 2025 forum talk "Small Groups, Big Readers", on weekly reading conferences in grades 3 to 5 | [grounded] same snippet | Your material says nothing about reading conferences. Do not borrow her vocabulary as your practice; ask about it instead (R2) |
| I4 | Shared professional ground, reading instruction. Not a shared career jump | [inferred] pairs I2 with F7 and F9 | Your own sentences are the only offer: "I led our grade level's move to a new reading curriculum in 2024" (F7) and "I've run the after-school reading club for the last two years" (F9). Say them at their own scope |

Public professional footprint only. The snippet was not opened as a full page.

## Persona table

The invite sets one panel session with named roles, so no archetype fallback applies. Weights blend the top two personas of each panelist's relationship.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The principal probing fourth-grade and team-lead gaps | Highest. Principal is a hiring-manager relationship, whose prior is Case plus Skeptic, and your own sentences state both gaps (F3, F7) | A1 until boring: plain limit, hold the quotes, no additions |
| Peer Evaluator | Two fourth-grade teammates asking what you would bring and need | High. Two of three panelists are team members, whose prior is Peer plus Prober | Reciprocity: say what you bring and what you would need; ask about their planning (B1, R4) |
| Case/Strategist | The principal setting live problems from the district's reading work | Medium-high. Hiring-manager prior, plus I2, I3 and the board's 2026 to 2029 literacy plan | Clarify, objective, approach, risks; use the district's own terms (C1 to C3) |
| Values/Behavioral | Stories keyed to the district's three published beliefs | Medium. The district page says the beliefs guide every hire, but no source I read names a values round in this loop | One story or one honest branch per belief (D1 to D3) |
| Conversational | The opening "walk us through" and your licensure | Medium-low. It opens most panels and is still scored | A 90-second arc made of your own sentences (E1, E2) |
| Data-Driven Prober | Reading your CV lines closely | Low. Your CV carries no headline figures, so there is no defend-the-number question | Describe plainly and say what you do not know (F1, F2) |
| Pressure | Interrupting, time-boxing | Low. Nothing in the invite or the research points to it. No bank | A3 covers the one pressured moment likely here |

## Question banks

### A. Skeptic (weight 1, five questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your six years have been in third grade. Which part of fourth grade would you be weakest at on day one?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Name the limit before it is pressed: "I haven't taught fourth grade." Then hold only what the quote carries: six years, third grade, a public elementary school in Joliet. Answer slot: which part of fourth grade would be newest to you, in your own words; if you do not yet know what fourth grade expects, say so plainly and say what you would find out first. Follow-up 1, "how do you know you can do it": return to the quote and concede that you cannot say you know fourth grade. Follow-up 2, "so you are a risk": concede the unknowns you named, specifically, and return to the six years. Never fold on the quote and never add to it | F3 is the largest stated gap and the principal's likeliest question, so this one is named the highest-ROI prep; JD because it scores the grade-level fit of the role |
| A2 | "What would you need to learn before you start, and how would you go about it?" | JD | [generic] | Structure it as a plan in the future tense: who you would ask (the fourth-grade team), what you would read or observe first, what you would do in your first weeks, and how you would check you are on track. Do not say any of it has begun unless it has | The closure path for F3, asked after A1; generic because a ramp plan makes no claim about your past |
| A3 | "Why you over a candidate who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I've never taught fourth grade" | Pause and restate the question. Do not compare yourself with someone you have not met. Offer the three quoted sentences at their own scope, then concede: "I haven't taught fourth grade." Hold through two follow-ups by returning to the same sentences, never by adding to them | F3 in a pressured form; F7 and F9 supply the sentences. JD because it scores fit to the stated role |
| A4 | "You led your grade level's move to a new reading curriculum. Were you the team lead?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Say it plainly: "I've never been a team lead." Then the other sentence at its scope: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: expect a probe on how the move worked with your colleagues; if any part of it was yours to decide, say which, in your own words; if the decision on what the move involved sat with others or with the team, say so plainly and stay with the move you led | F7 holds both sentences; EXP because it tests which part was actually yours |
| A5 | "What is drawing you to fourth grade, and to Halvering?" | JD | [grounded] | Give your actual reason in your own words; this pack does not supply one. Choose one specific thing about fourth grade and one about Halvering that you really know. The district's published material offers: the three beliefs on its Mission and Beliefs page, and the board's August 2026 literacy plan. Say only what you actually find compelling | The Skeptic's why-leave, why-here, why-now; grounded on the research in Sources, and F3 is why the first half is asked |

### B. Peer Evaluator (weight 2, four questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our fourth-grade team plans together. What would you bring to that table, and what would you need from us?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years" | Reciprocity first: offer the two sentences at their own scope, the move you led and the club you have run. Then what you would need, put as questions about their own practice, such as how often they plan and what the planning covers. Promise nothing you have not done | F7 and F9 carry your side; JD because the posting-type requirement is working with the grade-level team |
| B2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work was shared with colleagues; it needs one piece that was clearly yours, one that was not, and the credit said aloud. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The peer stem for credit-sharing; F7 is the row where credit between you and the team is most exposed |
| B3 | "How do you keep families informed?" | JD | [grounded] "I write a weekly email to families" | Say the sentence as it stands: "I write a weekly email to families." Describe what goes in it in your own words. Answer slot: the district's belief is that each teacher speaks with every family each term, so expect a probe on conversations, not only emails; if you have spoken with families, say how and when; if you have not, or only with some, say so plainly and stay with the email | F6 is the evidence; the slot comes from the district's published belief |
| B4 | "A student arrives in our room reading well below grade level. How would you plan with us for that student?" | CASE | [generic] | Clarify first: what is known about the child's reading, from whom, and what the family says. Then the objective, one first change, and how you would check it. Name who on the team you would ask. This is a plan, not a past | Peers price what you would need from them; the case also touches the first belief, F9 |

### C. Case/Strategist (weight 3, four questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The board adopted a 2026 to 2029 literacy plan with a new grades 3 to 5 reading curriculum from fall 2027. What would you want to know first, as a fourth-grade teacher?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you know the plan in its own terms: three years, a new grades 3 to 5 reading curriculum from fall 2027, a family reading night each term. Then clarify, objective, approach, risks: what you would ask about training, timing and how the team is supported. One honest link, told as the sentence has it: "I led our grade level's move to a new reading curriculum in 2024." The new curriculum is the board's; do not say you would run it | The differentiator question most candidates cannot touch; F7 is the one sentence you have on a curriculum change. Plan details come from a search result, so confirm them on the district's site |
| C2 | "Walk us through the routines you would set in your first two weeks." | CASE | [inferred] | Structure it as a plan: name a small number of routines in your own words and say why each comes first. Answer slot: if you use routines now that you would bring, name them in your own words; if you did not set them, or there were none, say so plainly and answer as a plan | F8 is the thin row; inferred because the requirement comes from a representative posting |
| C3 | "A fourth grader's assessment shows they have not met a standard. What do you do next, and what do you do for the rest of the class?" | CASE | [inferred] | Clarify what the result measures and what else you know about the child, then one change, then how you would check it, then the rest of the class. The district's own words are available as a principle: assessments inform teaching and never replace it. Say that only as a principle you hold. Answer slot: if you have changed teaching after an assessment result, give one instance in your own words; if not, say so plainly and answer as a plan | F5 has no evidence, so this is rehearsed as reasoning; CASE because it is a live problem |
| C4 | "Which subjects did you teach in third grade, and which would you want support with in fourth?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer slot: name the subjects you actually taught; if you taught only some, or others were taught by someone else, say so plainly and stay with the six years in third grade. Then name one subject you would want support with, honestly; it follows from A1 | F4 is the row the quote does not settle; JD because it scores the stated subjects |

### D. Values/Behavioral (weight 4, three questions)

The three beliefs are the district's own, from its Mission and Beliefs page. No source I read names a values round, so they theme these questions and nothing more.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our first belief is Every Child a Reader: no student leaves third grade without a reading plan. Tell us about a time you helped a child who was behind in reading." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: one specific child, what you noticed, what you did, what happened; no names. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the club, in those words, or how you would handle it. Answer slot: the belief's reading-plan line makes a probe likely; if you wrote or contributed to reading plans, say how, in your own words; if you did not, say so plainly and stay with the club | F9 is the nearest evidence; VAL because it scores the published belief |
| D2 | "Families Are Partners: tell us about a time a family's input changed what you did in class." | VAL | [generic] | Selection scaffold: a family told you something, you changed one thing, and you can say what happened. Keep it specific and anonymous. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The second belief; F6 is the only family evidence and it is an email |
| D3 | "Teach for Tomorrow, Not for the Test: tell us about a time you used an assessment to change what you taught." | VAL | [generic] | Selection scaffold: a named assessment, what it showed, the change you made, what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The third belief; F5 has no evidence, so the honest branch is likely |

### E. Conversational (weight 5, two questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through your path to this point." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families"; "I've never taught fourth grade" | A 90-second arc with four beats, in this order, each a quoted sentence in your own words: the six years in third grade, the curriculum move you led, the club you run, the weekly family email. Then your reason for fourth grade, in your own words; the pack does not supply it. You may name "I haven't taught fourth grade" yourself before they do | Casual openers are scored; F2, F7, F9 and F6 supply the beats, F3 the early honest line |
| E2 | "Tell us about your license and endorsement." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say the facts in the quote's terms: an Illinois Professional Educator License, elementary education endorsement, grades 1 to 6, registered and active through June 30, 2029. Have your own record to hand if asked for details. Say nothing about other endorsements or approvals; none are stated | F1 is the gate in the invite; JD because it scores the stated qualification |

### F. Data-Driven Prober (weight 6, two questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "What would you look for to tell whether a new reading curriculum is working for your students?" | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Structure: what you would want to see, from whom, over what time, and what would change your mind. Answer slot: if you looked at anything like this in 2024, say what, in your own words; if you did not, or it was someone else's job, say so plainly and answer as a plan | F7 plus F5: the probe a reader of your CV is most likely to reach for; CASE because it asks for reasoning, not a past claim |
| F2 | "Tell us about the reading club: who comes and what the children do there." | EXP | [grounded] "I've run the after-school reading club for the last two years" | The quote gives the club and its two years and nothing more. Describe who comes and what the children do in your own words; where you do not know something, such as exact attendance across the two years, say so plainly rather than estimating | F9; EXP because it checks that the club is as described |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 license and endorsement | E2 |
| F2 grades 3 to 5 experience | E1, C4 |
| F3 fourth grade, never taught | A1, A2, A3, A5 |
| F4 plan and teach the five subjects | C4 |
| F5 differentiate using assessment data | C3, D3, F1 |
| F6 communicate with families | B3, D2 |
| F7 work with the grade-level team | A4, B1, B2 |
| F8 classroom routines | C2 |
| F9 Every Child a Reader | D1, B4, F2 |
| Families Are Partners (belief) | D2, B3 |
| Teach for Tomorrow, Not for the Test (belief) | D3, C3 |

Your CV carries no headline figures, so no defend-the-number question is included.

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. How does that shape what you look for in how fourth-grade teachers handle reading?" | Tied to the principal's own path; turns a probe into a peer conversation | [grounded] I1, I2 |
| R2 | "Your talk on weekly reading conferences covered grades 3 to 5. What does that look like in fourth grade here?" | Shows you read her public work, and asks about conferencing instead of claiming it | [grounded] I3 |
| R3 | "The literacy plan brings a new grades 3 to 5 reading curriculum from fall 2027. How would a teacher new to the grade be supported through that change?" | Shows current knowledge of the district and asks about the thing your gap touches (F3) | [grounded] Sources, query 2 |
| R4 | "What could a new member of the fourth-grade team do in the first month that would genuinely help you?" | The reciprocity question for the two team members; it prices their load, not just yours | [generic] |
| R5 | "What does a strong first semester look like for a teacher new to fourth grade?" | Surfaces the bar you are being measured against, and where F3 is expected to close | [generic] |
| R6 | "How often does the fourth-grade team plan together, and what does the planning cover?" | Practical for B1, and shows interest in the team's actual work | [generic] |
| R7 | "The district's belief is that every teacher speaks with every family each term. How do teams here handle that conversation?" | Shows you read the beliefs and asks how the practice works, where your own evidence is an email (F6) | [grounded] Sources, query 1 |

## Prohibited claims

Not coached in any cell of this pack. Built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade classroom experience | Negative the candidate stated, F3 | The plain acknowledgment: "I haven't taught fourth grade." with "Six years teaching third grade at a public elementary school in Joliet" at its own scope. No slot |
| Has been a team lead, or led the grade-level team | Negative the candidate stated, F7 | The plain acknowledgment: "I've never been a team lead." with "I led our grade level's move to a new reading curriculum in 2024" at its own scope |
| Chose, designed or ran the new reading curriculum | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material says you led the move, not what it decided or ran. A4's slot stays inside the move |

## Sources

Provided documents: your invite and your resume text, pasted in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford Community School District values | yes | Query "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs, which was fetched. Moved D1 to D3, F9 and R7. It names no values round, so no values cheat sheet |
| 2. Interview process, role family | skipped | The invite already fixes the session: one 45-minute panel with the principal and two fourth-grade team members. It fixes the structure and persona weights |
| 3. District strategy and recent news | yes | Query "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan, search snippet only, page not fetched. Moved C1 and R3 |
| 4. Interviewer public footprint | yes | Query "Dolores Vantongeren principal Halvering Elementary School" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren, snippet only. Moved the interviewer read, R1 and R2. The two team members were not named, so nothing was searched for them |
| 5. Representative fourth grade teacher posting | yes | Query "fourth grade teacher job posting Illinois elementary qualifications" returned https://k12jobsboard.example/listings/fourth-grade-teacher, which was fetched. Moved F2 and F4 to F8, all inferred; it is not Halvering's own posting |

## Upgrade menu

- Halvering's actual posting → F2 and F4 to F8 move from inferred to grounded, and the JD-tagged questions are re-aimed at its real requirements
- HR's note on format or focus, such as a demo lesson, a sample of your work or topics the panel will cover → a build section for any announced deliverable, and reweighted personas
- The two team members' names and roles → an interviewer read for each, and a reverse question tied to their paths
- The state's public record for your license, as a printout or screenshot you have looked at → F1 moves from medium to high
- Your own account, in your own words, of the 2024 curriculum move and of who the reading club serves → F7 and F9 regenerate, and the A4 and D1 slots can become story maps
- Whether you have used assessment results to change teaching, and which subjects you taught → F4 and F5 regenerate, and C3, C4 and D3 move from slots toward story maps
- A tuesday-dossier.md from job-underwriter → evidence-derived top objection and absolute prohibited-claim guardrails in place of this pack's local inference
