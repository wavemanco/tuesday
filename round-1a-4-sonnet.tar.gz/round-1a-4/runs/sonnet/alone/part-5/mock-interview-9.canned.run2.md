Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/alone/part-5/rooms/case-9-canned-7587df83/Halvering_fourth-grade-teacher_interview_pack.md`. I built it for the single 45-minute panel that the invite and the district's hiring page both describe. You didn't send the posting, so the job-duty rows come from a representative posting and are labeled `[inferred]`.

- **Gate:** Your licence meets the invite's requirement. It's an active Illinois PEL with an elementary education endorsement for grades 1–6, registered through June 30, 2029. I'd still confirm its status with the issuer before Thursday.
- **Biggest prep item:** A1, the question about moving from third to fourth grade. You said you've never taught fourth grade, so the pack coaches you to say that plainly and then give your six third-grade years at their own scope. A4 and A2 are next, because the principal is a former reading specialist and will probably ask about your reading curriculum move.
- **Team lead:** Nothing I found says the role is a team-lead role. The pack keeps "I led our grade level's move" and "I've never been a team lead" as two separate statements.
- **Social security number:** Your résumé text included one. I didn't use it or copy it into the pack, and the pack doesn't need it. I'd leave it off any copy you send.

I'll play the Skeptic on A1 whenever you want to rehearse it.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the posting's full text and anything HR told you to prepare, such as a demo lesson or a writing sample?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Halvering_fourth-grade-teacher_interview_pack.md -----
# Interview pack: Fourth Grade Teacher, Halvering Elementary School

**Employer:** Orrinsford Community School District. **Round:** one 45-minute panel on Thursday. **Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (names not given). **Relationship read:** a hiring-manager seat plus two peers, so the pack blends both.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for your own words, not a script. Wherever it says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your claims survive scrutiny, and what was actually yours |
| JD | The stated duties and qualifications of the role |
| CO | Whether you know the district's current plans |
| CASE | A live problem from the actual job, answered aloud |

## Prep triage (between now and Thursday)

1. A1, said aloud until it is boring. This is the highest-ROI prep in the pack.
2. A4 and A2, the two attribution probes on your curriculum-move line.
3. C1 to C4, the live problems. Think aloud and structure them.
4. E1, the 90-second arc, and the district's three beliefs and board plan (C2, E3).
5. Pick three reverse questions.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | Your material shows this gate met: Illinois PEL, elementary education endorsement, registered and active, expiring June 30, 2029. Grade 4 sits inside grades 1–6. It is a CV line with nothing inspected behind it, so confirming the status with the issuer before Thursday is yours to do. If asked, say it in the quote's own terms |
| F2 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board posting, a representative posting rather than this school's | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | Your material says third grade, six years, and does not say which subjects were yours. Answer slot: if you taught any of these subjects, say which, in your own words; if some were taught by someone else or not at all, say so plainly and stay with the third-grade teaching you did |
| F3 | "differentiate instruction using assessment data" — K12 Jobs Board posting; "assessments inform teaching and never replace it" — Orrinsford beliefs page | none given | none | [inferred] | discovery | Your material does not show any assessment practice. Answer slot: if you adjusted instruction from assessment results, say what the results were and what you changed, in your own words; if you did not, or it was not yours to do, say so plainly and say how you would start |
| F4 | "Panels ask about reading instruction, classroom routines and how you work with families." — Orrinsford hiring page (routines) | none given | none | [grounded] | discovery | Your material does not show your classroom routines. Answer slot: if you run particular routines, say which and why, in your own words; if you do not, say so plainly and say what you would set up first |
| F5 | "Panels ask about reading instruction, classroom routines and how you work with families." — Orrinsford hiring page (reading instruction); "a new grades 3–5 reading curriculum from fall 2027" — Orrinsford board news | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material says a grade-level curriculum move and an after-school club. It says nothing of day-to-day reading instruction, and the words stay at those two quotes. Answer slot: if you can describe your daily reading teaching, do so in your own words; if the move and the club are the whole of your reading work, say that plainly |
| F6 | "communicate regularly with families" — K12 Jobs Board posting | "I write a weekly email to families." — your CV | medium | [inferred] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you write a weekly email to families. A named, regular practice beats an adjective. It stays an email |
| F7 | "each teacher speaks with every family each term" — Orrinsford beliefs page | "I write a weekly email to families." — your CV | medium | [grounded] | discovery | Your material says the weekly email and does not say whether conversations with families happen. Answer slot: if you speak with families, say when and how, in your own words; if that is not how you work with families, say so plainly and stay with the email |
| F8 | "work with the grade-level team" — K12 Jobs Board posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | transferability | Both quotes stay, each at its own scope: you led the grade level's move, and you have never been a team lead. If asked about leading a team, your words are: "I haven't been a team lead." Answer slot: if colleagues' work was part of the move, say what they did and what you did, in your own words; if not, say so plainly |
| F9 | "Fourth Grade Teacher position" — the invite | "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet." — your CV | low | [grounded] | transferability | Your words are: "I haven't taught fourth grade." Then the third-grade years, at their own scope. What fourth grade asks beyond that is not in your material, so offer it as how you would learn it, never as a past |

## Reading the interviewer

Public professional footprint only. The other two panelists are unnamed, so nothing is read for them.

| Fact | Source | Provenance | What it suggests |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | ilprincipalsforum.example speaker page | [grounded] | Expect the reading questions to be asked by someone with reading-specialist depth, so A4, C1, C2 and G1 are the likeliest places she goes deep |
| 2025 forum talk "Small Groups, Big Readers", covering weekly reading conferences in grades 3 to 5 | same page | [grounded] | Reading conferences in grades 3 to 5 are her stated topic. Do not claim a practice you have not run. Use it for reverse question R2 |
| Shared ground: reading work | your CV | [grounded] | Your own words for it are "I led our grade level's move to a new reading curriculum in 2024" and "I've run the after-school reading club for the last two years" (row F5), and they stay at that scope |

## Persona table

| Persona (bank) | How it shows up here | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A, 5 questions) | The principal in a hiring-manager seat, probing the two gaps you named | Highest. Hiring-manager prior is Case/Strategist plus Skeptic, and F8 and F9 carry stated negatives | Rehearse A1 until it is boring. Open with "I haven't taught fourth grade." then the third-grade years at their own scope |
| Peer Evaluator (B, 4) | The two fourth-grade teammates asking what a new colleague adds and needs | High. Peer prior is Peer Evaluator plus Prober, and F8 is the team row | Reciprocity first: what you bring, quoted at scope (F5, F7), then what you would need |
| Case/Strategist (C, 4) | Live classroom problems, and the board literacy plan | High. Hiring-manager prior; the hiring page names reading instruction, routines and families as panel topics; her published talk is on reading conferences | Clarify, set the objective, approach, check that it worked, name risks. Think aloud |
| Values/Behavioral (D, 3) | Stories tied to the district's three beliefs | Medium. No values-style round is detected: the hiring page names panel topics, not a values assessment. The beliefs page says three beliefs guide every hire, so VAL questions are themed from them | Pick a real story per belief, or say plainly that none comes to mind and give the nearest thing your material carries |
| Conversational (E, 3) | Biography and why-here questions in a friendly register | Medium. No member's prior names it; kept so no style is met first live | A 90-second arc from your own sentences; treat casual questions as scored |
| Data-Driven Prober (G, 2) | Teammates asking how you know the reading club and your teaching work | Low. Peer prior includes it, but your CV carries no figures, so there is nothing to defend by number | Say what you tracked and how, or say plainly that you did not |
| Pressure | Omitted | No member's prior includes it, and nothing in the sources suggests it | n/a |

Loop basis: the district's hiring page and your invite establish one 45-minute building panel (principal plus two grade-level teachers), so these weights rest on this district's documented process, not an archetype.

## Question banks

### Bank A: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What makes you ready for fourth?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't taught fourth grade." Then the years, at their own scope: six years teaching third grade at a public elementary school in Joliet. Follow-up 1, "What would be different?": answer slot. Say only what you know about fourth grade from your own work or from the school's own materials, and where it comes from; if you do not know, say so plainly and say how you would find out. Follow-up 2, "Why not stay in third?": answer slot. Your own reason, in your own words. Follow-up 3, "What if it's harder than you expect?": concede the limit specifically, that you have not taught the grade, and return to the third-grade years. Never describe what fourth-grade teaching is like unless it is yours to describe | F9 is the pack's widest gap and the one stated outright, so this question arrives in some form. JD because it scores the role as posted; Skeptic because it presses on the gap |
| A2 | "You'd be joining our fourth-grade team. How do you see your place on it?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Start from what the quote carries: you led your grade level's move to a new reading curriculum in 2024. If the question turns to leading a team, say it once, without apology: "I haven't been a team lead." Then return to the grade-level move. Answer slot: if colleagues' work was part of the move, say what they did and what you did, in your own words; if it was not, say so plainly and return to your own part | F8 carries both quotes, and the "led" against "never a team lead" pair is where a teammate checks attribution. JD because the posting asks for work with the grade-level team |
| A3 | "Why fourth grade, and why now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: your own reason, in your own words; the pack supplies none. Keep it consistent with A1: no claim to know fourth grade. A shape that holds: one true reason, one thing you bring (the reading club or the weekly email, each at its quote's scope), one thing you would learn | A motivation probe follows any grade change (F9). EXP because it tests the story behind a career move |
| A4 | "Tell us about the 2024 move to a new reading curriculum at your grade level." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Beats the quote states: a new reading curriculum; your grade level's move to it; 2024; "I led". Tell them in your own words. Observation: your material says the grade level's move, so keep it at that scope. Answer slot: the panel's reading focus makes a probe on decisions likely. If decisions about the move were yours, say which and how you made them; if they were made elsewhere, or there were none, say so plainly and describe your part | F5 and F8 are the evidence, and this is the likeliest attribution probe given the reading-specialist background in the interviewer read. EXP because it tests what was actually yours |
| A5 | "Fourth grade means teaching reading, writing, math, science and social studies. Which of those have you taught?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | The subject list is typical for the role per a representative posting, not this school's stated list. Answer slot: if you taught any of these subjects, say which, in your own words; if some were taught by someone else or not at all, say so plainly and stay with the third-grade teaching you did | F2 is a discovery row and the mid-list requirement most likely to go unrehearsed. JD because it scores the duties as posted |

### Bank B: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you want from your teammates in your first month, and what would you bring?" | JD | [grounded] "I've run the after-school reading club for the last two years"; "I write a weekly email to families." | Bring first, at quote scope: you have run the after-school reading club for the last two years, and you write a weekly email to families. Then what you would need: answer slot, your own needs, in your own words; if you do not yet know, say what you would ask first | The peer seat prices what a hire adds to their load, and F5 and F6 are what your material offers. JD because the posting asks for work with the grade-level team |
| B2 | "Tell me about a time you disagreed with a colleague about how to teach something." | VAL | [generic] | Selection scaffold: pick a real disagreement with a named issue, your own position, how it ended, and the relationship intact afterwards. If no such time comes to mind, say so plainly, then say how you would handle it | A standard peer probe on disagreement style; nothing in your material supplies the story, so it is a scaffold |
| B3 | "A teammate runs a routine very differently from how you run yours, and students notice. What do you do?" | CASE | [generic] | Structure it aloud: what exactly differs and what students are seeing; talk to the teammate privately first; ask what each routine is for; look for a shared principle; involve the principal only if student needs are affected. The question needs no claim about your past, so the guidance makes none | A live seam problem from F8's team requirement; generic because it is a pattern for the problem |
| B4 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | "We" for context, "I" for your contribution. Your own word is "led", and it stays at the grade level's move. Answer slot: if colleagues' work was part of the move, say what they did and what you did, in your own words; if not, say so plainly | Credit probes return in peer packaging, and F5's "led" is the line they test. EXP because it tests attribution honesty |

### Bank C: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "It's October and one student in your class is reading well below the others. What do you do in the first two weeks?" | CASE | [generic] | Clarify first: what the assessment shows, what the family already knows, what support exists. Then objective, approach, how you will check it is working, and risks. If you refer to the district's belief, use its own name, "Every Child a Reader", and attribute it to the district. The guidance makes no claim about your past | The hiring page names reading instruction as a panel topic, and F5 shows no daily reading practice, so this is the live version of that gap |
| C2 | "The board adopted a literacy plan this year. What stands out to you about it from a fourth-grade seat?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Read the plan page before Thursday. The research shows: structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term. Fourth grade falls inside grades 3–5. Say what you notice in your own words. Your own curriculum work is the one line you can offer: you led your grade level's move to a new reading curriculum in 2024, and it stays at that scope. Do not correct anything the panel says about the plan | CO question grounded in current strategy, from a board decision of August 2026. F5 is the only row it can draw on |
| C3 | "It's the second week of school. Which routines do you set up first, and why?" | CASE | [generic] | Pick two or three. For each: what it does for students and how you would teach it. Answer slot: name the routines you actually run now; if you would change any for fourth grade, say which and why, or say you would observe first | The hiring page names classroom routines as a panel topic and F4 shows nothing, so this is rehearsal for an open row |
| C4 | "A parent emails on Friday evening upset about their child's reading group. What do you do?" | CASE | [grounded] "I write a weekly email to families." | Structure: acknowledge the message, avoid arguing by email, look at what the child's own results show, offer a conversation, follow up, and tell the principal if needed. The weekly email is the channel your material carries, at that scope, and it does not show how you handle complaints | The families belief and the panel's families topic point here (F6, F7). CASE because it is a decision, not a record |

### Bank D: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you got a struggling reader moving." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold, from the belief "Every Child a Reader": pick a real reader, kept anonymous, with a named stake, a concrete step you took and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I've run the after-school reading club for the last two years", or how you would handle it | F5 is the nearest evidence, and it does not carry a story with beats, so this is a scaffold. VAL because the belief is published |
| D2 | "Tell me about a time a family's view changed what you did." | VAL | [grounded] "I write a weekly email to families." | Selection scaffold, from the belief "Families Are Partners": a real family, their view, what you changed, how it ended. Answer slot: if you speak with families, say when and how, in your own words; if that is not how you work with families, say so plainly and stay with the weekly email. If no such time comes to mind, say so plainly, then give the email or how you would handle it | F7 is the discovery row behind this belief. VAL because the belief is published |
| D3 | "When have assessment results and what a child needed pointed in different directions?" | VAL | [grounded] | Selection scaffold, from the belief "Teach for Tomorrow, Not for the Test": a real case, what the results said, what the child needed, what you did. If no such time comes to mind, say so plainly, then say how you would handle it | F3 shows no assessment practice and the belief says assessments inform teaching and never replace it, so a prepared scaffold matters. VAL because the belief is published |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk us through your journey to teaching." | EXP | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029"; "Six years teaching third grade at a public elementary school in Joliet."; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families." | A 90-second arc, proposed and pending your approval, in this order: the license, the six years of third grade, the curriculum move, the reading club, the weekly email, then why this job. Each beat is a clause its quote states. Answer slot for the start and the why: your own reasons, in your own words, since your material supplies neither | The opening biography question is the one most reliably asked. EXP because it tests a CV told as a story |
| E2 | "What are you trying with your students in reading right now?" | JD | [grounded] "I've run the after-school reading club for the last two years" | Answer slot: name something real. If nothing comes to mind, say so plainly. The club is the one reading item your material carries, at its scope: you have run it for the last two years | Casual questions on hot topics are scored, and reading instruction is a named panel topic (F5). JD because it scores the role's reading duties |
| E3 | "What made you apply to Halvering?" | CO | [grounded] | Answer slot: your own reason. Use only what you read: the district's three beliefs by name, "Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test", and the board's literacy plan. Do not describe Halvering beyond what you read | CO question that rewards homework done on the pages the pack cites |

### Bank G: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How do you know the reading club is working?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Answer slot: if you tracked anything, say what and how, in your own words; if you did not, say so plainly and say what you would look at to know | The beliefs page puts assessment in service of teaching, and F3 and F5 show nothing tracked. Your CV carries no figures, so no defend-the-number slot is raised |
| G2 | "What assessment data did you use in third grade to adjust what you taught?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet." | Answer slot: if you adjusted instruction from assessment data, say what the data was and what you changed, in your own words; if there was no such step, or it was not yours, say so plainly and return to the third-grade teaching you did | F3 is a none-evidence row against a posting requirement, so this probe is likely. JD because it scores a stated duty |

## Requirement coverage

| Requirement | Questions |
|---|---|
| License (F1) | none, and why: the gate is shown met by your material and no question presupposes it; E1 carries it as the opening beat |
| Plan and teach the subjects (F2) | A5 |
| Assessment data (F3) | G1, G2, D3 |
| Classroom routines (F4) | C3 |
| Reading instruction (F5) | A4, B4, C1, C2, D1, E2, G1 |
| Regular communication with families (F6) | C4, D2 |
| Speaking with families (F7) | D2 |
| Work with the grade-level team (F8) | A2, B1 to B4 |
| Fourth Grade Teacher itself (F9) | A1, A3 |

## Reverse questions

| # | Question | Why it lands | Basis |
|---|---|---|---|
| R1 | "You became principal after nine years as a reading specialist. What do you most look for in how a fourth-grade teacher teaches reading?" | Ties to her own published path and invites her view instead of yours | [grounded] ilprincipalsforum.example speaker page |
| R2 | "Your 2025 talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5. What does that look like in a fourth-grade classroom here?" | Shows you read her public work and asks about this school, not the talk | [grounded] same page |
| R3 | "What could a new fourth-grade teammate do in their first month that would genuinely help your team?" | Reciprocity question for the two teammates: it asks about their load, not your needs | [generic] |
| R4 | "The board's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. How is the fourth-grade team getting ready for it?" | Uses a current district decision and asks what the work will be | [grounded] Orrinsford board news |
| R5 | "What does the family reading night look like at Halvering, and what would you want a fourth-grade teacher to bring to it?" | Draws on the plan's family reading night each term and asks how it works in practice | [grounded] Orrinsford board news |
| R6 | "What support does a teacher new to fourth grade get in the first term?" | Asks for the concrete support behind F9 without apologizing for it | [generic] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F9 | "I haven't taught fourth grade." with the third-grade years at their own scope. No slot |
| Has been a team lead | A negative you stated, F8 | "I haven't been a team lead." with the grade-level move at its own scope. No slot |
| Led the school's or district's move to a new reading curriculum | Inflated form of F5 and F8 | The quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024". The limit is the pack's observation: your material says the grade level's move |
| Speaks with every family each term | Inflated form of F7 | The quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says the email, not conversations. D2's slot asks only whether and how you speak with families |

## Sources

Provided documents: the invite and your résumé text (both in your message). No dossier was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | Fetched the beliefs page. Three beliefs by official name; themed D1 to D3, E3 and F5 and F7 |
| 2. Orrinsford interview process | yes | Fetched the hiring page. Establishes one 45-minute panel of the principal and two grade-level teachers and the named panel topics; persona weights follow it |
| 3. Orrinsford strategy and news | yes | Board literacy plan, August 2026, search result only; fed C2, R4, R5 |
| 4. Interviewer, Dolores Vantongeren | yes | Principal since 2022 after nine years as a reading specialist, and the 2025 talk; fed the interviewer read and R1 and R2 |
| 5. Representative Fourth Grade Teacher posting | yes | K12 Jobs Board result, partly cut off. Its qualifications line was not quoted; the license requirement comes from your invite. Fed F2, F3, F6, F8, A5, G2, all `[inferred]` |

Searches and results:

- "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District teacher interview process panel" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren Halvering Elementary School principal" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "Fourth Grade Teacher job posting Illinois elementary school" returned https://k12jobsboard.example/listings/fourth-grade-teacher

Fetches: https://orrinsfordschools.example/about/mission-and-beliefs and https://orrinsfordschools.example/careers/how-we-hire-teachers.

## Upgrade menu

- The posting's full text → F2, F3, F6 and F8 move from `[inferred]` to `[grounded]`, and A5 and G2 are re-sourced to the school's own wording
- Anything HR told you to prepare, such as a demo lesson or a writing sample → a build section for each declared deliverable
- The two teammates' names and roles → a reading of each, and a reverse question tuned to each
- The issuer's own record of your license status → F1 from medium to high
- A sample of your weekly family email, your reading club plan, or the curriculum-move materials you are willing to inspect → F5, F6 and F7 from medium toward high
- Your answers to the slots in A1, A2, A4, A5, F3 and F4 → quoted into the fit snapshot, with the affected rows and guidance regenerated
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on the district and a fuller read of the principal's talks and writing
- A tuesday-dossier.md from an earlier evaluation of this role, if you have one → verified evidence and strategy limits per gap, and a more evidence-based pick for the deepest rehearsal
