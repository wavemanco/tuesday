I'm running three research searches on Larkfield Systems: its values, its interview process and its recent strategy. After that I'll build the three-round prep pack.
Your prep pack for all three rounds is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-6-denied-6ba1c47e/larkfield-systems_engineering-manager_interview_pack.md`. I built it as one loop: a shared fit snapshot and prohibited-claims list, then a mini-pack for each round with its own persona weights, 9 questions and 5 reverse questions. I wrote it from the role description you pasted, since I don't have the full job description.

- **Tuesday, Director of Engineering:** mostly skeptic questions, then case problems, then a couple of conversational ones.
- **Thursday panel:** mostly peer-evaluator questions, then number-probing from the staff engineers. There are two values questions for the product manager.
- **Monday, VP Engineering:** mostly values and leadership-philosophy questions, then pressure questions on your gaps.
- **Highest-priority prep:** question A1, "which part of this role would you be weakest at on day one?" Your answer rests on your own sentence, "I've never owned a hardware-adjacent roadmap," plus a learning plan. The same objection comes back as D2 on Monday and E1 on Thursday, so rehearsing it once helps three times.
- **Your 60% number:** C1 on Thursday and D1 on Monday cover it. The pack only has your sentence saying the drop came "after" the reliability quarter, so it doesn't coach you to say the quarter caused it.

Web search was refused, so nothing about Larkfield's values, interview process or strategy is researched. That means there's no values cheat sheet for Monday. The company-knowledge question (B4) is generic, and the Sources section shows what each refused search would have changed.

Wherever your material is silent, I left an "answer slot" instead of writing words for you. The slots cover leading two squads, growing engineers, working with product, and device-management experience.

Say the word and I'll play the skeptic Director on A1, then follow up on whatever you actually say. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you want it.

1. Can you paste the full job description, or say to go without it? It would replace my paraphrased requirements with the posting's own lines.
2. Do you have interviewer names and any recruiter guidance on what the panel will focus on, or whether you need to bring something prepared? Either would let me tune the personas and reverse questions per person.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview pack (loop mode): Engineering Manager, Larkfield Systems

Candidate: Yusuf. Three rounds, one role.

| Round | When | Who | Relationship | Length |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering, the hiring manager and would-be boss (name not given) | Hiring manager | 45 min |
| 2 | The Thursday after | Two staff engineers and a product manager (names not given) | Panel | 60 min |
| 3 | The following Monday | VP Engineering (name not given), described by the recruiter as "values and leadership philosophy" | Skip-level, values-style | 30 min |

## 1. How to use this, and the type key

- This is loop mode: one shared fit snapshot, prohibited list and sources block, then one mini-pack per round with its own persona weights, question bank and reverse questions. Questions are numbered by persona across the whole pack (A, B, C, D, E, G, V), so a drill or a note can point at one ID.
- Personas are how a question is asked. Types are what it scores.
- The type tags are VAL (values alignment), EXP (work-experience deep-dive), JD (the role's stated duties), CO (company and strategy knowledge) and CASE (a live problem).
- Guidance is scaffolding, not a script. Every sentence about your past is one you wrote, quoted next to the guidance it supports. Wherever the pack does not have your sentence, it gives an "answer slot": an instruction to answer from your own experience, with an honest second branch.
- Provenance labels: `[grounded]` traces to what you supplied, `[inferred]` is a derivation the pack names, `[generic]` is a pattern with no claim about you or Larkfield.
- The highest-ROI prep in the whole loop is **A1**, the hardware-roadmap objection. It returns in other packaging in D2 and E1, so rehearsing it once pays three times.

## 2. Fit snapshot (shared by all three rounds)

Requirements are quoted from the role description you pasted. Evidence is your own words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (the leading-two-squads facet) — role description in your message | "3 as a team lead of 6" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | Your material says nine years engineering, three as a team lead of six, and the words stay at that scope. It does not say two teams. The plain acknowledgment you gave is "I've never managed managers." Answer slot: the two-squad line makes a probe on leading beyond one team likely. If any of your work spanned more than one team, say what it was and which part was yours; if it did not, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" (the delivery facet) — role description in your message | "pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote is a prioritisation fight you won, which is adjacent to owning delivery and does not say you owned delivery commitments. Words: you pushed a reliability quarter through against roadmap pressure. Answer slot: the own-delivery line makes a probe on how delivery was tracked and committed likely. If that was yours, say how in your own words; if there was no such step, or it was not yours, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (the hiring facet) — role description in your message | "I run our hiring loop for backend roles" — your message; "about 40 interviews last year" — your message | medium | [grounded] | none | The quotes already reach hiring in role-relevant terms: a loop you run, for backend roles. Expect a probe on the number, because a CV-style line has nothing inspected behind it and "interviews" does not say who sat in them or how many became hires. Lead with the loop in the quote's own terms |
| F4 | "own delivery, hiring and growth for 11 engineers" (the growth facet) — role description in your message | none given | none | [grounded] | discovery | Your material is silent on developing engineers. Answer slot: the growth line makes a probe likely. If you have helped an engineer grow, say who, what and your part, in your own words; if you have not, or it was not yours, say so plainly and stay with the team of six you led |
| F5 | "partner with hardware and product on roadmap" (the product facet) — role description in your message | "pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote touches roadmap tension without saying whom the pressure came from. Derived from the quote's wording only. Answer slot: if the pressure came from a product counterpart, say who and how it was worked through; if it came from elsewhere, or there was no such counterpart, say so plainly and stay with the quarter |
| F6 | "partner with hardware and product on roadmap" (the hardware facet) — role description in your message | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never owned a hardware-adjacent roadmap." Then a plan, said as a plan and never as a past: who on the hardware side you would sit with first and what you would ask them to teach you. Never a claim to hardware roadmap work |
| F7 | "Lead two squads building device-management services" (the domain facet) — role description in your message | none given | none | [grounded] | discovery | Your material does not show device-management or fleet-style work. Answer slot: the domain line makes a probe likely. If you have worked on services that managed or served devices, say what and your part; if you have not, say so plainly and say what you would study first |

## 3. Prohibited claims (shared)

Built before the banks. No guidance cell, slot, hold or reverse question asserts, softens or implies any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has owned a hardware-adjacent roadmap | Negative you stated, F6 | "I've never owned a hardware-adjacent roadmap." No slot on owning |
| Has managed managers | Negative you stated, F1 | "I've never managed managers." |
| Has led or run two squads, or more than one team | Inflated form of F1 | F1's quote at its own scope: nine years engineering, three as a team lead of six. The limit is the pack's observation: your material says one team |
| Owned delivery commitments or delivery outcomes | Inflated form of F2 | F2's quote at its own scope: you pushed a reliability quarter through against roadmap pressure |
| The reliability quarter caused the 60% drop | Inflated form of the sentence in C1 | The sentence as you wrote it: on-call burden dropped 60% "after" you pushed the quarter through. Cause and share are slots in C1 and D1 |
| Made about 40 hiring decisions or hires | Inflated form of F3 | "about 40 interviews last year", and the loop you run. Who sat in them is a slot in C2 |

## 4. Requirement coverage

| Requirement (role description) | Covered by |
|---|---|
| "Lead two squads building device-management services" | A2, A3, B1, B3, D3 |
| "own delivery" | B1, B2, B5, C1, V4 |
| "hiring" | C2, C3, V5 |
| "growth for 11 engineers" | G2, V6 (your own growth, not the engineers'), plus T4 as a reverse question. No bank question asks about the engineers' growth beyond G2, because your material has no sentence for it |
| "partner with hardware and product on roadmap" | A1, B1, B2, E1, V2, D2 |

---

# ROUND 1 — Tuesday, Director of Engineering (hiring manager), 45 min

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A) | Quiet probing of the gaps: hardware, domain, scale | High. A hiring manager is buying capability and derisking gaps (relationship prior), and F6 and F7 are stated or visible gaps. 4 questions | Rehearse A1 until boring; bridges only from the quotes; a ramp plan said as a plan |
| Case / Strategist (B) | Live problems on the actual roadmap | Medium-high. Hiring-manager prior, and the role is about roadmap partnership. 3 questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Conversational (G) | Opener and casual questions that are still scored | Medium. A 45-minute first conversation with your would-be boss usually opens with the journey. 2 questions | A 90-second arc built from your own sentences; treat casual questions as scored |

The loop itself rests on your own words: three named rounds with named interviewers. What each round actually contains beyond that is not established (see Sources).

## Bank A — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in the pack. The hold is only what the quote carries: "I've never owned a hardware-adjacent roadmap." Then the plan, said as a plan: who on the hardware side you would sit with first and what you would ask them to teach you. Answer slot: if you have had any working contact with hardware or device teams, say what it was and your part, in your own words; if you have not, say so plainly. Hold through two follow-ups by returning to the sentence, never by adding to it; concede the limit specifically and do not claim a substitute | F6 is the stated gap, and the role description names hardware partnership, so this question arrives in some form from the person who would be your boss. JD because it scores a stated duty; the Skeptic delivers it |
| A2 | "We build device-management services. What have you worked on that's close to that?" | JD | [grounded] "3 as a team lead of 6" | Answer slot: the domain line makes this question likely. If you have worked on services that managed or served devices, say what and your part, in your own words; if you have not, say so plainly, then return to what your material does carry: nine years engineering, three as a team lead of six, and say what you would study first | F7 has no evidence behind it, so this is a discovery row rehearsed as a slot, and the question's premise stays open. JD because it tests the stated domain |
| A3 | "You've led a team of six. This is two squads and eleven engineers. What changes?" | JD | [grounded] "3 as a team lead of 6"; "I've never managed managers" | Hold only the quote: nine years engineering, three as a team lead of six, and "I've never managed managers." Answer slot: if any of your work spanned more than one team, say what it was and which part was yours; if it did not, say so plainly and say what you would watch first, as a plan. Do not describe running two teams | F1 is a transferability row: adjacent work with a visible step up. JD because it scores the "two squads" line and the 11-engineer scope |
| A4 | "Why leave a payments company for industrial IoT, and why now?" | EXP | [generic] | The reason is yours and the material gives none, so the guidance supplies none. Answer slot: give your actual reason in your own words, one or two sentences, and keep it consistent with what you say to each later round. Do not borrow a reason from the posting | Motivation-consistency is a Skeptic staple, and the same answer will be checked across three rounds. EXP because it tests whether the story survives cross-examination |

## Bank B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Hardware tells you a device release will slip. Both squads have roadmap commitments built on it. Walk me through your first week." | CASE | [generic] | Clarify first: what slipped, by how much, what depends on it. Then objective, who is affected, options, what you would tell product and when, and the risks of each option. Challenge one premise, for example whether the commitment can move. The question asks about no past, so the guidance claims none | A live problem from the "partner with hardware and product on roadmap" line, built on the F6 gap. CASE because it scores structure |
| B2 | "Product wants a feature, and your team is being paged too often. How do you decide?" | CASE | [grounded] "pushed a reliability quarter through against roadmap pressure" | Structure it: what the pages cost, who is pressing, what the smallest change is that buys relief, how you would show the trade to product. If you reach for your own quarter, tell it only at the quote's scope: you pushed a reliability quarter through against roadmap pressure. Answer slot: if the pressure came from a product counterpart, say who and how it landed; if not, say so plainly | The quarter in your message is the real-world version of this problem; F2 and F5 are the rows it draws on. CASE with an EXP edge, because a strong answer reaches for a real example |
| B3 | "How would you spend your first 90 days across two squads you didn't build?" | CASE | [generic] | Structure: what you need to know before changing anything, who you meet first, what you would deliberately leave alone, and how you would find out where the hardware seam is. The guidance claims nothing about your past | A planning question from the role's scope, and a way to show the ramp plan A1 promised. CASE |

## Bank G — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering"; "3 as a team lead of 6"; "currently at a payments company" | A 90-second arc built only from those three sentences: nine years engineering, three as a team lead of six, now at a payments company. The motivation beat is a slot: say your own reason for this move in your own words. The pack supplies no turning-point stories because none of your sentences carries one | Casual openers are scored for economy and consistency. EXP because it checks the biography against the CV |
| G2 | "How do you help engineers on your team grow?" | EXP | [grounded] "3 as a team lead of 6" | Answer slot: the growth line makes this likely. If you have helped an engineer grow, say who, what you did and what changed, in your own words; if you have not, or it was not yours, say so plainly and stay with the team of six you led. Do not describe a mentoring programme or a leveling process | F4 has no evidence, so this is rehearsed as a slot. EXP because it asks what you actually did |

## Reverse questions — Round 1

| # | Question | Why it lands |
|---|---|---|
| T1 | "What would a good first six months look like for these two squads, in delivery and in hiring?" | It takes the role's own scope as the frame and turns the interview into a shared definition of success |
| T2 | "Where does the hardware roadmap meet the squads' roadmap today, and who is in that conversation?" | You have said plainly that you have not owned this. Asking where the seam is, rather than pretending to know it, is the honest and curious move |
| T3 | "Which of the two squads is harder to lead right now, and why?" | A manager answers this candidly if asked well, and it tells you where your first 90 days go |
| T4 | "How does growth for the 11 engineers work here today: is there a leveling or promotion framework I would inherit?" | It tests whether the growth duty is structured or yours to build, which bears on F4 |
| T5 | "Is this a new role or a backfill, and what do you most want to see in the first 90 days?" | Reveals the history behind the seat and the boss's own expectations |

---

# ROUND 2 — The Thursday after, panel: two staff engineers and a product manager, 60 min

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (E) | Seam-splitting, collaboration scenarios, credit probes | High. The panel will be working alongside whoever gets the role; the peer prior and the PM's cross-functional prior both point here. 4 questions | Reciprocity framing; propose seam principles instead of pretending to know the seam; disagreement stories only where a quote carries one |
| Data-Driven Prober (C) | Reads the CV line by line; denominators, assumptions | Medium-high. Staff engineers are the technical specialists; your CV carries two figures (60% and about 40). 3 questions | Know what you can and cannot say about how each number was counted; say plainly when you do not know |
| Values / Behavioral (V) | A scored behavioural question from the PM | Medium-low. Cross-functional interviewers lean this way, but no loop source says this panel has a values portion. 2 questions | Stories only where a quote carries one; a selection scaffold where none does |

Names are not given, so personas are blended across the panel instead of assigned per member. With names, they would be assigned per person (upgrade menu).

## Bank E — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where does product's roadmap stop and engineering's priorities start, and what happens when we disagree?" | JD | [grounded] "pushed a reliability quarter through against roadmap pressure" | Offer seam principles, not a claim to know this seam: what product owns, what engineering owns, and how a disagreement is escalated and recorded. If you cite your own case, tell it at the quote's scope. Answer slot: if the pressure came from a product counterpart, say who and how it was worked through; if it came from elsewhere, or there was no such counterpart, say so plainly | F5 is low confidence, so the case is coached as a slot and never as your story of working with product. JD because it scores partnership with product |
| E2 | "How do you work with staff engineers when you disagree on a technical direction?" | CASE | [generic] | Reciprocity framing: what you would ask of them, what they can ask of you, and how a disagreement gets decided and written down. Selection scaffold for a story: pick a time you disagreed with a peer or a more senior engineer about technical direction; it needs a named stake, how it resolved and an intact relationship; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The two staff engineers are the most likely sources of this question, and no sentence of yours carries a disagreement story, so a scaffold is the honest form. CASE because it is a live collaboration problem |
| E3 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams, with the other team's contribution named and your own share said plainly. "We" for context, "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer probe, and the role sits at a team boundary. VAL because it tests behaviour more than knowledge |
| E4 | "Our squads depend on a device service your teams will own. What do you need from us in your first month, and what can we count on from you?" | JD | [generic] | Answer in both directions. What you need is information: the architecture, the open incidents, the commitments in flight. What they can count on is what you would put in place, said as a plan. It claims nothing about your past | The reciprocity question the peer relationship calls for, and the one candidates most often answer one-sidedly. JD because it scores the partnership duty |

## Bank C — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your team's on-call burden dropped 60%. Walk me through how that was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend-the-number in your own words, with four slots. How it was counted. What it is sensitive to. The assumption behind it you would defend least. Which part was yours. Where you do not know how it was counted, say so plainly. Hold the sentence at its own scope: on-call burden dropped 60% after you pushed the quarter through. Do not state that the quarter alone caused the drop | The only quantified claim on your CV. Probers go straight here, and "after" invites the cause question the prohibited list guards. EXP because it tests attribution |
| C2 | "About 40 interviews last year. How many were you in the room for, and how many ended in a hire?" | EXP | [grounded] "I run our hiring loop for backend roles"; "about 40 interviews last year" | Answer slot: say how many of the interviews you conducted yourself and how many the loop as a whole ran, in your own words; if you do not know the split or the hire count, say so plainly and stay with the loop you run. Do not turn the interview count into a hire count | F3's number is ambiguous about who sat in the interviews. EXP because it tests attribution |
| C3 | "What would you change about a hiring loop you run, and what would you use to decide?" | JD | [grounded] "I run our hiring loop for backend roles" | Answer slot: the hiring line makes this likely. If you have changed the loop, say what, why and what you used to decide, in your own words; if you have not, say so plainly and say what you would look at first. Do not describe a scorecard or a calibration practice you have not stated | Staff engineers care about the bar they will interview against. JD because it scores the stated hiring duty |

## Bank V — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | If this is your story, tell only its beats as the sentence states them: the reliability quarter, pushing it through, the roadmap pressure, and the on-call drop after. Answer slot: if it meant telling a senior person something unwelcome, say who and what happened, in your own words; if it did not, pick another time, or say so plainly and give the nearest thing your material carries | The quarter is the one sentence that could carry this story, and its limits (F5, low confidence) are what the slot protects. VAL because it scores behaviour against the unpopular-truth stem |
| V2 | "Tell me about a time you and product disagreed about what to build next." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The PM on the panel is the likely asker, and the role's product-partnership line raises the theme. The scaffold is the honest form because F5 is a low-confidence row |

## Reverse questions — Round 2

| # | Question | Why it lands |
|---|---|---|
| H1 | "What could a new engineering manager do in their first month that would genuinely help your work?" | The reciprocity question for a peer panel; it signals you are thinking about their load |
| H2 | "How does a roadmap decision between product and the hardware side reach the squads, and where do people get surprised?" | Staff engineers see the surprises first; it also asks about the seam you have not owned |
| H3 | "What is on-call like for these services today?" | It invites them to describe the load, which is where your own on-call sentence belongs if they raise it, and you do not have to assert it first |
| H4 | "What would you want an engineering manager to do, or stay out of, in technical design decisions?" | It gets the staff engineers' boundary in their own words, and it is the working agreement that E2 rehearses |
| H5 | "What is one decision this team made in the last year that you would make differently now?" | Invites candour and shows you listen for how a team learns |

---

# ROUND 3 — The following Monday, VP Engineering, 30 min, "values and leadership philosophy"

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral (V) | Stories scored against how the VP thinks about leadership | High. The recruiter's own description is "values and leadership philosophy" (relayed by you). That is a loop source that documents a values-style round. 4 questions | A story mapped to each theme where a quote carries one; "we" for context, "I" for contribution; choose stories where the hard truth landed |
| Pressure (D) | Time-boxed, interrupting, tests composure | Medium. Skip-level and executive prior, and 30 minutes forces short answers. Your stated gaps are what a VP would test. 3 questions | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Case / Strategist (B) | Altitude questions on the business | Low-medium. The recruiter's framing points away from cases. 2 questions | Clarify, structure, use the company's vocabulary once you have it |

Larkfield's published values are not in hand (searches were refused), so there is no values cheat sheet and the questions below are themed from the recruiter's description and the persona stems only.

## Bank V — Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V3 | "What is your philosophy of leading engineers, in your own words?" | VAL | [grounded] "3 as a team lead of 6"; "I run our hiring loop for backend roles" | Pick one or two principles that are actually yours, and anchor each in a sentence of your material: leading a team of six, running the hiring loop. Say the principle, then what you did, at the quotes' scope. Answer slot: if you have a principle you have never put into practice, say so plainly rather than inventing a story for it | The recruiter's own description makes this the headline question of the round. VAL because it scores whether stated values match behaviour |
| V4 | "When did you put a longer-term concern ahead of near-term delivery pressure?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | The strongest fit in your material. Tell the beats the sentence states: the reliability quarter, pushing it through, the roadmap pressure, the on-call drop after. Answer slot: who applied the pressure and what the trade was, in your own words; if you do not remember or it was not clear-cut, say so plainly. Land the hard truth, which includes what the quarter cost | The persona stem for this round. F2 is the row, and the quote carries the story only at its own scope. VAL with an EXP edge |
| V5 | "Tell me about a time a hiring call was hard." | VAL | [grounded] "I run our hiring loop for backend roles" | Answer slot: the hiring line makes this likely. If the call was yours, or your input decided it, say what it was and what you decided, in your own words; if the decision was someone else's, say so plainly and stay with the loop you run. Do not state the outcome unless you lived it | A VP reads hiring judgement as leadership philosophy. VAL because it scores behaviour rather than a number |
| V6 | "How do you want to grow as a leader over the next three years?" | VAL | [grounded] "I've never managed managers" | Say the plain acknowledgment first: "I've never managed managers." Then your own next step in your own words, which the pack cannot supply. Do not name a development programme or a mentor you have not mentioned | The honest answer to the leadership-level gap, and a values-round staple. VAL because it tests self-assessment |

## Bank D — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "That 60% on-call drop. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold: you pushed the quarter through against roadmap pressure, and on-call burden dropped 60% after. Hold that through two follow-ups. Concede specifically. Answer slot: which part was yours and which was others', and whether anything else changed in the period, in your own words; if you do not know the split, say so plainly | The persona stem for how much was actually you. The hold is only what the sentence carries, which is the part a second follow-up cannot break |
| D2 | "Sixty seconds: why you over a candidate who has managed managers and owned a hardware roadmap?" | JD | [grounded] "3 as a team lead of 6"; "I run our hiring loop for backend roles"; "I've never managed managers"; "never owned a hardware-adjacent roadmap" | Pause and restate. Anchor in what you stated: nine years engineering, three as a team lead of six, a hiring loop you run. Concede the two negatives plainly: "I've never managed managers" and "I've never owned a hardware-adjacent roadmap." Do not claim to be better; say what you bring and stop | The same hardware objection as A1, now time-boxed and comparative. JD because it scores fit against the role |
| D3 | "You haven't managed managers. Why should I trust you with this scope?" | JD | [grounded] "I've never managed managers"; "3 as a team lead of 6" | Concede plainly: "I've never managed managers." Hold what you did: nine years engineering, three as a team lead of six. Do not adopt "scope" as a fact; the role as described is two squads and eleven engineers, so ask what scope they mean. Answer slot: if you have any experience leading leads or other engineers' leads, say what; if not, say so plainly | A VP is the likeliest person to press on level. JD because it tests the stated scope |

## Bank B — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B4 | "If you joined, what would you want to understand first about Larkfield's business?" | CO | [generic] | Clarify and structure: customers, where the device-management services sit in what they sell, the hardware relationship, and what the company is trying to change this year. The pack has no researched facts about Larkfield, so no company claim is made here; use Larkfield's own vocabulary only after you have read it | The honest cost of declining research: this CO question is generic, and the upgrade menu says what would sharpen it |
| B5 | "How do you decide how much engineering capacity goes to reliability versus roadmap in a device service?" | CASE | [generic] | Structure the trade: what failure costs, what the roadmap is worth, how you would show both to leadership, and how you would revisit the call. If you use your own quarter, tell it at the quote's scope in V4 and nothing beyond | The reliability quarter in your material is a natural bridge, and the role's own-delivery line raises the theme. CASE |

## Reverse questions — Round 3

| # | Question | Why it lands |
|---|---|---|
| M1 | "How would you describe the leadership philosophy you hope engineering managers share here?" | Matches the round's own purpose and lets you hear the VP's language before you reply |
| M2 | "When delivery and reliability conflict, what do you want your managers to do?" | A direct line to the theme your one strong sentence carries, asked rather than asserted |
| M3 | "How does engineering strategy connect to the hardware roadmap at company level?" | Shows altitude and asks about the seam you have not owned |
| M4 | "What would make this hire a clear success to you a year in?" | Turns a values conversation into a concrete bar |
| M5 | "What do engineering managers here most often get wrong in their first year?" | Candour the VP will usually reward, and a ready input for your first 90 days |

---

## Sources

Provided documents: the role description you pasted, the three rounds with who runs them, the recruiter's description of Monday's round as relayed by you, and your own summary of your background. No JD text, CV, interviewer names or recruiter guidance beyond that were provided.

Searches sent, all refused by the host before returning anything:
- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | The values cheat sheet (not produced) and VAL questions mapped to published value names. Round 3 is themed from the recruiter's words only |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | What each round actually contains beyond your own description. The three rounds' persona weights rest on your stated rounds and interviewers' roles |
| 3. `Larkfield Systems strategy` / recent news | unavailable | The CO questions (B4) would carry current facts. They are generic as it stands |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form; there is no interviewer read |
| 5. representative `Engineering Manager` JD | skipped | The pasted role description fixes the fit snapshot rows and the JD-tagged questions |

## Upgrade menu

- Full JD text → the F1 to F7 requirements become the JD's own lines, and any `[inferred]` row can upgrade to `[grounded]`
- Interviewer names → persona weights read from each person's public footprint, a reverse question tied to each interviewer's own path, and per-member personas for Thursday's panel
- The recruiter's guidance for each round (especially what the panel will focus on, and whether anyone is expected to bring a prepared piece) → coverage of any pre-declared deliverable
- Larkfield's published values page, pasted → the Monday values cheat sheet, with each value mapped to a quoted sentence of yours
- Search permission → values, loop and strategy research would run at the default tier and replace B4's generic framing with current facts; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available on request
- Your answers to the slots in F1, F2, F4, F5 and F7, said outside a drill → each answer becomes quoted evidence and those rows regenerate
- A team paging or on-call report covering the reliability quarter, or whatever shows the 60% trend → would raise F2 and the C1 and D1 hold from medium toward high
- A tuesday-dossier.md from an earlier fit check → carries verified evidence, an evidence-derived objection and any prohibited claims, and would sharpen A1 and the prohibited list
