I've read the prep playbook, and I'm now running the company research: values, interview process, strategy, and Tobias's public footprint. Then I'll build your pack.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-7-denied-89689e6f/Saltmarsh-Games_live-operations-producer_interview_pack.md`. It has 21 questions across seven interviewer styles, plus a fit snapshot, a prep schedule for Tuesday to Thursday, reverse questions and a list of claims not to make.

- **Assumption:** I built it for a hiring-manager round, since you didn't say how Tobias relates to the role.
- **Research:** My four web searches (company values, interview process, strategy, and Tobias) were all refused, so nothing came back. The pack has no company facts or interviewer read, and the case questions are generic.
- **Your gaps:** Highest-ROI prep is A2, a question about your lack of in-app-purchase experience. Both gaps you stated are in the pack, with plain wording to rehearse: "I haven't led a team" and "I haven't worked on a game with in-app purchases." The pack offers no wording that suggests otherwise.

I can play the Skeptic on A2 as a live drill, so say the word. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Two questions, since both would reshape the pack:
1. Is Tobias your future manager, a skip-level or a peer, and did the recruiter name any focus areas or something to prepare?
2. Can you paste your CV? I'd swap the quotes from your message for your CV's exact wording.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Saltmarsh-Games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations
**Round:** 60 minutes, Friday. Built as a hiring-manager round, since the relationship was not stated.
**Version:** first pass

## How to use this pack, and the type key

Personas describe how a question is asked. Types describe what is being scored. Answer guidance is scaffolding to rehearse aloud, not a script. Where a cell says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that it was not yours or never existed. Nothing in this pack is a fact about you unless it is quoted from what you told me.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values a company publishes. No values source was available, so VAL items here are themed from standard behavioral prompts |
| EXP | Whether your stated experience survives scrutiny, and how precisely you attribute it |
| JD | Whether you can do the listed job, including the parts you have not done |
| CO | Knowledge of the company and its strategy. None here: company research did not run |
| CASE | A live problem from the actual role, scored on structure and reasoning |

## Prep triage

You have until Friday. In order, with everything else as insurance:

1. Tuesday: write out, in your own words, the two plain statements in section 13 (no team led, no in-app purchases) and rehearse A1 to A3. A2 is the highest-ROI prep in this pack.
2. Wednesday: say B1 to B4 out loud with a timer, then C1 and C4.
3. Thursday: run D1, G1 and G2 aloud, pick your reverse questions, and re-read the fit snapshot.

Everything else is insurance.

## Fit snapshot

No requirement in the JD is a gate (a term such as a licence, location or pay). "3+ years" is graded like any other requirement. Quotes are your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not an events calendar and not two titles, and the words stay there: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's two-titles line makes a probe on scope likely. If any of the drops were time-limited events, or you covered a calendar for another title, say which, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | The quote touches the requirement without showing whether it reaches it. Answer slot: the JD names four teams, so expect a probe on which you worked with. If you worked with any of them on the drops, say which and how, in your own words; if you did not work with them directly, or it was not yours, say so plainly and stay with the calendar |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says you presented monthly retention numbers, not that you ran event reviews or owned the numbers, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: if you also compiled those numbers, or looked at how individual drops performed, say so in your own words; if someone else produced them, or there was no per-drop review, say so plainly and stay with presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | The quote already reaches the requirement: you wrote it, and QA still uses it. It is a one-line claim with nothing inspected behind it, so expect a probe. Say it in the quote's own terms, and bring the checklist itself if you can share it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | The years are stated; whether the title was run as a live service is not. Answer slot: if your main title was run as a live service, say how in your own words; if it was not, say so plainly and stay with the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | The quote reaches the requirement directly. This is your strongest row; lead with it in its own terms |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Nothing inspected stands behind it, so expect to be asked how the numbers were counted. Say what you presented, and say plainly where you do not know how a figure was built |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | One written document is a start and does not show the range. Answer slot: the JD's post-event review and per-update coordination make a probe on what else you wrote likely. If you wrote other material for those purposes, name it; if you did not, say so plainly and stay with the checklist |
| F9 | Leading people. The JD does not ask for it, so this is a role-family question an interviewer may raise (generic) | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A limit you stated. Words: "I haven't led a team." Then what the role needs from you instead, said as a plan and never as a past. Never a claim to people management, and nothing added to make the limit smaller |
| F10 | Experience with in-app-purchase economics on a mobile title. The JD does not ask for it, so this is a role-family question an interviewer may raise (generic) | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A limit you stated. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to monetization work |

## Persona table

Weights rest on the hiring-manager prior in the persona model. No loop source was available, so this is a pattern, not this company's documented process. Tell me the actual relationship and I will reweight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Skeptic | Quiet probing of the gaps: scope, teams, in-app purchases | Highest. A hiring manager is buying capability and derisking gaps, and F1, F2, F9 and F10 are where your material is thinnest | Rehearse the most predictable objection (A2) until it is boring. Use only adjacent evidence you stated, and say the limit plainly |
| B. Case / Strategist | Live problems from the job: plan a calendar, diagnose an event, handle a slipped release | High. The role is planning and coordination, so the manager is likely to test structure | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully per case |
| C. Data-Driven Prober | Pulls on the retention numbers and the checklist | Mid. The JD names KPIs and retention, and F3 and F7 each rest on one line | Know what you can and cannot say about how each number was counted. Name the assumption you would defend least before they do |
| D. Conversational | Friendly walkthrough of your background | Mid. Openers like this are scored even when they feel casual | A 90-second arc built only from your own sentences |
| E. Values / Behavioral | Behavioral prompts | Low. No values source was available and no values round is detected | Pick real instances, or say plainly when none comes to mind |
| G. Pressure | Time-boxed challenge on why you | Low. Rarer at manager level | Pause, restate, hold the position through two follow-ups, concede specifically |
| H. Peer Evaluator | Seams between teams | Low. The role coordinates four teams, so seam questions can come from anyone | Reciprocity framing, and principles for the seam rather than pretending to know it |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Choose from the limits you stated, and say it in plain words: "I haven't worked on a game with in-app purchases." Then say what you would learn first and who you would ask, as a plan. Do not describe any experience you do not have | F10 and F9 are the stated gaps, and this is the stem that asks for them. JD because it scores the whole listing |
| A2 | "You haven't worked on a game with in-app purchases. How would that show up in planning a live-events calendar here?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: "I haven't worked on a game with in-app purchases." Then say what you did run: the weekly content-drop calendar for your main title, for two years. Hold through two follow-ups by returning to those two facts and to your plan for learning the rest. Concede specifically that you have not seen that side. Never claim a monetization decision or result | F10 is the gap closest to a mobile live-events role, which is the pack's own inference from F1 and F10 and not from any research; expect this objection in some form. JD because it scores fit against the listed titles |
| A3 | "You haven't led a team. This role coordinates design, art, engineering and community on every update. How do you get those teams moving?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say "I haven't led a team." Answer slot: if you worked with any of those teams on the drops, say which and how, in your own words; if you did not work with them directly, or it was not yours, say so plainly and stay with the calendar you ran. The JD's word is coordinate, which is your reading of the posting and not a claim about you | F9 and F2. JD because it scores the coordination line |
| A4 | "You've run your main title's weekly calendar. This role runs events for two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say what you ran, in those words. Answer slot: if you ever covered a calendar for another title, say so; if not, say so plainly. Then what you would ask first: how the two titles share the teams and the calendar | F1. JD because it scores the first line of the posting |
| A5 | "Why this role, and why now?" | JD | [generic] | A selection scaffold: your actual reasons, stated once, with nothing borrowed from this pack. If you have no clear reason yet, say so plainly, then give the nearest honest thing | The Skeptic checks motivation consistency; the pack cannot supply your reasons |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "An event's retention comes in below the level you planned. How do you diagnose it?" | CASE | [generic] | Clarify what was planned and how it was measured. State the objective, split the players by who joined and when, list the likely causes, say which metric you would check first, name the risk of reading one event alone. Challenge one premise respectfully. If asked about revenue, say plainly you have not worked with it and ask how the team reads it | The JD's post-event review and KPIs (F3, F7). CASE because it is a live problem |
| B2 | "Sketch the live-events calendar for two titles next month. What do you need to know first?" | CASE | [generic] | Ask about the titles' shared teams and fixed dates, then objective, constraints, a draft structure, and what you would check with each team. Think aloud. The guidance makes no claim about your past | The JD's first line (F1, F6). CASE because it is a planning problem |
| B3 | "An update is due in two days. Engineering says one fix is not ready and community has already announced the date. What do you do?" | CASE | [generic] | Clarify what is at risk, who decides, and what the options cost. Structure: facts, options, who needs to know and when, what the checklist says. Say what you would ask QA | The JD's coordination and release-checklist lines (F2, F4). CASE because it is a live trade-off |
| B4 | "Walk me through what goes into a post-event review and which KPIs you would report." | JD | [generic] | Structure it: purpose, inputs, the few KPIs you would report and why, and who reads it. Name the weakest assumption in any measure you pick. The question asks how you would do it, so the guidance makes no claim about what you have done | The JD's third line (F3). JD because it scores the stated responsibility, with CASE delivery |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented the monthly retention numbers to the studio head. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer in your own words on four things: how the numbers were counted, what they are sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you compiled them, say so; if someone else did, or you do not know how a figure was counted, say so plainly and stay with presenting them. Name no method you did not use | F3 and F7. EXP because it tests attribution |
| C2 | "Which retention measure would you watch first after an event, and why?" | JD | [generic] | A reasoned choice stated as your view, with the assumption behind it named. Answer slot: if the monthly numbers you presented were cut in a particular way, say how; if you do not know, say so plainly | F7. JD because it scores the retention requirement |
| C3 | "How would you separate an event's effect from everything else moving at the same time?" | CASE | [generic] | State what you would compare, what could confound it, and what you could not separate. Honest limits beat a confident method. The guidance makes no claim about your past | F3. CASE because it is a reasoning problem |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey from the puzzle-game studio to this role." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc with those four beats in your own words and no dates beyond what the quotes give. The last beat is an answer slot: say your actual reason for this role, in your own words; if it is not settled, say so plainly and say what draws you | F5, F6, F4, F7. EXP because it is your account of your own background |
| D2 | "What are you actually playing, or watching, in live-service mobile these days?" | JD | [generic] | A selection scaffold: name one real title you follow and one thing about how it runs events that you noticed. If none comes to mind, say so plainly | Casual questions about hot JD topics are scored |
| D3 | "Tell me about the calendar you ran. What did a typical week look like?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | The beats the quote states: weekly, content drops, your main title, two years. Answer slot: describe a typical week in your own words; if it varied, say so | F6 and F1. EXP because it tests whether the line survives detail |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [inferred] "Presented the monthly retention numbers to the studio head" | A selection scaffold: pick a time with a named stake, a moment you did not soften it, and an intact relationship at the end. The nearest sentence your material carries is the one in Provenance; if it fits, say so in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral prompt. The sentence is the nearest one, and it does not say the numbers were unwelcome (F7) |
| E2 | "When have you held a release until QA was satisfied?" | VAL | [inferred] "Wrote the release checklist our QA team still uses" | A selection scaffold: pick a real instance with the trade-off named. If none comes to mind, say so plainly, then give the nearest thing your material carries, which is that you wrote the checklist QA uses | The JD's release-checklist line (F4). VAL because it is a behavioral prompt |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has already run live events on a game with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Never led a team, and never worked on a game with in-app purchases" | Pause and restate. Hold: the calendar you ran and the checklist QA still uses, in those words. Hold through two follow-ups by returning to them. Concede specifically: "I haven't worked on a game with in-app purchases." Do not fold on the core claim to ease the room | F1, F4 and F10. JD because it scores fit against the listing |
| G2 | "That calendar you ran. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: say which parts were yours to decide and which were set by others, in your own words; if others set the priorities, say so plainly, then return to what you ran | F1. EXP because it tests attribution |

### H. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Design wants a bigger event than engineering can safely build in the window. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Propose principles for the seam instead of claiming to know it, say what you would bring to each side, and show spine and tact together. The guidance makes no claim about your past | F2 |
| H2 | "How do you handle credit when an update spans design, art, engineering and community?" | JD | [generic] | State the principle. Answer slot: if you can name a real update that crossed those teams, say so; if not, say so plainly and stay with the principle | F2. JD because it scores the coordination line |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A4, B2, D3 |
| "coordinate design, art, engineering and community teams on each update" | A3, B3, H1, H2 |
| "own the post-event review and the KPIs it reports" | B1, B4, C3 |
| "manage the release checklist with QA" | B3, E2 |
| "3+ years producing live-service games or apps" | D1, G1 |
| "experience running a content calendar" | A4, B2, D3 |
| "comfortable with player-retention metrics" | C1, C2, C3 |
| "clear written communication" | — none, and why: no question can test your writing without presupposing a document your quotes do not carry beyond the checklist. F8 holds it, and B4 is where a written review would come up |

## Reverse questions

No interviewer profile was available, so these are role-generic.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would you want to have seen from the producer on these two titles after the first few months?" | Gets the success measure in your hands before you are scored on it |
| R2 | "How are post-event reviews used today: who reads them, and what has changed because of one?" | Shows you read the role as owning the loop from event to decision |
| R3 | "Where does the calendar get contested between design, art, engineering and community, and who settles it?" | Goes straight at the coordination seam in the JD |
| R4 | "What would you want a producer who is new to in-app purchases to learn first?" | Puts the stated gap on the table on your terms and asks for the ramp |
| R5 | "How do the two titles share people and the calendar: shared teams, or separate ones?" | Tells you the real size of the job behind the posting's first line |

## Prohibited claims

Not coached in this pack, each with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative you stated, F9 | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated, F10 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says your main title's weekly calendar. A4's slot stays inside what you ran |
| Owned the post-event reviews and the KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you presented the numbers. C1's slot asks only who compiled them |
| Managed releases with QA, release by release | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says you wrote the checklist QA still uses |

## Sources

Provided documents: the job description text, and your background as written in your message. No CV, no interviewer profile and no recruiter guidance were provided. No dossier was present.

Searches sent, all four refused by the host, so nothing returned:

- "Saltmarsh Games values" — refused
- "Saltmarsh Games interview process live operations producer" — refused
- "Saltmarsh Games mobile studio strategy news" — refused
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Would have given the official value names for a values cheat sheet if a values round were documented. None is, so VAL items are standard prompts |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Would have set the loop and persona weights. Weights now rest on the hiring-manager prior |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | Would have grounded a CO or CASE question in the company's current priorities. The CASE items are labeled `[generic]` |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Would have given the interviewer read and a reverse question tied to his career path. Both are absent |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your actual relationship to Tobias (future manager, skip-level, peer) and any focus areas the recruiter named → reweights every bank, and adds a build section for any announced deliverable
- Web research on Saltmarsh Games (values, loop, strategy) and on Tobias's public footprint, if you grant search or paste the pages → persona weights from the real loop, an interviewer read, a reverse question tied to his path, and CO questions that stop being `[generic]`
- Your CV → quotes from it replace the message-only quotes in F1 to F10
- Your answers to the slots in F1, F2, F3, F5 and F8 → those rows can rise from `[inferred]` or `discovery` toward `[grounded]`
- The checklist you wrote, or a sample retention report, if you can share them → raises F4 and F7 from `medium` toward `high`
- A `tuesday-dossier.md` from an earlier pass → verified evidence and sharper objection ranking, never required
