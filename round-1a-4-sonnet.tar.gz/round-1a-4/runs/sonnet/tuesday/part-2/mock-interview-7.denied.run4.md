Web search was refused, so I'm building the pack from your JD and your message alone. Anything about Saltmarsh beyond that will be labeled generic.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-7-denied-e025de98/saltmarsh-games_live-operations-producer_interview_pack.md`.

I built it for a hiring-manager round, since your note didn't say how you relate to Tobias. It has 19 questions across six interviewer styles. Web search was refused, so the pack uses only your JD and your message, and the company-specific questions are labeled generic. The pack also lists the four searches I tried. B1 ("Which part of this JD would you be weakest at on day one?") is the question to prep first, because you've stated two gaps yourself: never led a team, and no in-app purchases.

Say the word and I'll play the Skeptic on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias your future manager, a peer, or a skip-level, and did the recruiter name any focus areas or a deliverable? The answer reweights every bank.
2. Do you want to paste your CV, or the lines behind your four years? I built this from your message alone.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

- **Candidate:** Femi
- **Interviewer:** Tobias Wrenfield, Head of Live Operations. 60 minutes, Friday.
- **Relationship:** not stated. This pack assumes a hiring-manager round, since he heads the function the role sits in. If he is a peer or a skip-level, the persona weights change.
- **Research:** web search was not permitted, so nothing here about Saltmarsh, its two titles or Tobias comes from outside your JD and your message. Those rows are labeled `[generic]`, and the Sources section accounts for it.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script. Every wording this pack proposes is pending your approval: change anything you would not truthfully say.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. Not banked: no values page is in hand, and no source names a values round |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | A stated responsibility or requirement in the posting, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem set in the role, answered by structuring it aloud |

## Prep triage

Three days. Do these in order. Everything else is insurance.

1. **Wednesday:** B1 and B2, out loud, until the two plain acknowledgments are boring. Then B3 and B4.
2. **Thursday:** C1, C3 and D1, told only from your own quoted sentences. Run A1 to A3 once each, aloud, with the structure in the guidance. Play both Saltmarsh titles for D2.
3. **Friday morning:** reverse questions V1 to V6, pick three. Reread the prohibited-claims table.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, not a live-events calendar and not two titles. The words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title, live-events line makes a probe on the difference likely. If any of the drops were timed events, say which, in your own words; if there were none, or you ran only the one calendar, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team" — your message | low | [inferred] | discovery | Derived from the JD's coordination line: the quote is about leading, and your material does not show whether you coordinated other disciplines. The JD asks for coordination, not for managing reports. Words: "I've never led a team." Answer slot: if you coordinated any of design, art, engineering or community on a drop, say which and how, in your own words; if you did not, or it was not yours, say so plainly and say how you would start |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented the numbers, not that you owned a review or chose the KPIs. The words stay there: "Presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-KPIs line makes a probe on who chose what was reported likely. If any of it was yours to choose, say which and how you decided; if none was, or it was not yours, say so plainly and describe what you presented |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and QA still uses it, not that you ran it release to release. The words stay there: "Wrote the release checklist our QA team still uses." Answer slot: if you also ran it at each release, say how, in your own words; if QA ran it, or there was no such step, say so plainly and stay with the checklist you wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | Derived from the JD's live-service wording: the quotes carry the years and the title associate producer, and do not say whether the game was a live service. Answer slot: if the main title was updated on an ongoing basis, say how it operated, in your own words; if it was not run as a live service, say so plainly and stay with the calendar you ran |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you ran it, weekly, for your main title, for two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | No gap in terms, with nothing inspected behind it. You gave no figure, so the pack supplies no measure, method or number. Lead with the quote's terms: monthly, retention numbers, the studio head |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | Derived from the JD: one written artifact that is still in use is thin evidence of writing across a role. Answer slot: if you have written anything else of the kind the JD's updates and reviews would need, name it, in your own words; if the checklist is your main example, say so plainly. A sample would raise this row, see the upgrade menu |
| F9 | Experience planning events alongside in-app purchases (a role-family expectation; the JD does not state it) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

Proposed wording in this table is pending your approval.

No row is a hard gate: the JD states no location, schedule, pay or credential term, and "3+ years" is an experience requirement, graded like any other.

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (bank A, 5 questions) | Plan this calendar, diagnose this dip, resolve this clash, in the role's own terms | Highest: the hiring-manager prior, and the JD's duties are planning and coordination problems | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (bank B, 4 questions) | Quiet probing of the gaps: day-one weakness, one title versus two, no purchases experience | High: the hiring-manager prior, and your own message states two gaps (F2, F9) and one-title scope (F1) | Rehearse B1 until it is boring; bridges only from your quoted sentences; calibrated candor over bluffing |
| Data-Driven Prober (bank C, 3 questions) | Reads the CV lines closely, asks how numbers were counted and what part was yours | Medium: set by the JD's KPI and retention lines. No interviewer signal was available | Know what you can and cannot say about each line; say plainly when you do not know |
| Conversational (bank D, 3 questions) | Friendly opener, journey question, casual questions about the titles | Medium: most interviews open this way. Treat the casual questions as scored | A 90-second arc built from your quotes; play both titles first |
| Pressure (bank E, 2 questions) | Time-boxed challenges to your motive and your share of the work | Low: the hiring-manager prior does not lead with it, and no interviewer signal raises it | Pause, restate, hold through two follow-ups, concede only what is true |
| Peer Evaluator (bank F, 2 questions) | Seam-splitting with adjacent teams, credit across teams | Low: the JD's coordination duties invite it, but a Head of function is rarely the peer. If Tobias is a peer, this rises | Reciprocity framing; propose seam principles rather than claiming to know the seam |
| Values/Behavioral | Not banked | Not detected: no source names a values round, and no published values are in hand | Upgrade menu |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You're planning the next eight weeks of live events for a title whose retention has dipped. What do you need to know first, and how do you structure the calendar?" | CASE | [generic] | Structure it aloud: ask what the event calendar is meant to move and by when, what is already locked, and which player groups matter; state an objective; lay out the weeks around fixed dates; name how you would judge each event; name the risks. Challenge one premise respectfully, such as whether the dip is an event problem at all. The question needs no claim about your past, so the guidance makes none | Planning is the JD's first duty, and a hiring manager scores structure over the right answer. F1 and F6 are the rows it tests; CASE because it is a live problem |
| A2 | "Design wants a big seasonal event on the same weekend engineering has a risky client release. What do you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Structure it: get the facts from each side, lay out the options and their costs, say who decides and how you would put it to them, and say what you would write down afterward. If it fits, you can say in the quote's own words that you wrote the release checklist your QA team still uses, and stop there | Tests the JD's coordination and release-checklist lines together (F2, F4). CASE because it is a decision under a clash; the checklist quote is optional support |
| A3 | "An event ran to plan, but retention afterward was flat. How do you review it, and what do you report?" | CASE | [generic] | Structure it: what the event was meant to do, set before it ran; what to compare it against; which player groups moved; what you would conclude and what you would not; and how you would write the result for design, art, engineering and community. Name the measures you would look at and why, and say where your confidence ends | The JD gives the post-event review and its KPIs to this role, so this is the likeliest live problem on F3 and F7. Generic because it is a pattern for the problem, not a fact about Saltmarsh |
| A4 | "Both our titles want the same release slot and the same team's time. How do you decide which gets it?" | CASE | [generic] | Structure it: clarify what each title needs and by when, what the shared constraint is, and who owns the trade-off; set criteria before naming a winner; say how you would tell the loser's team and what you would change next time. Do not claim you have run two calendars; the question asks how you would decide | The JD says two titles, and F1 shows one. CASE keeps it on reasoning rather than on your history |
| A5 | "You start Monday. What do you do in your first thirty days?" | JD | [generic] | A scaffold, not a claim: who you would meet first, among the disciplines the JD names and QA; what you would read before you change anything; what you would ask, including whether earlier post-event reviews exist; and what you would deliver by day thirty. Say plainly where you would be learning | Supports B1's ramp plan. JD because it scores the role's duties; CASE in delivery |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team"; "never worked on a game with in-app purchases" | **The highest-ROI prep in this pack:** it will be asked in some form, and a calm answer changes the interview. Say each gap once, plainly: "I've never led a team." and "I've never worked on a game with in-app purchases." Pick the one you honestly think is bigger and give a plan, not a past: for the team, whom you would ask for dates and how you would write them down; for purchases, whom you would ask to explain how events and offers interact. Rehearse three follow-ups: which worries you more; what you would do in your first month; what if nobody has time to ramp you. Proposed wording for the third, pending your approval: "That would slow me down, and I would ask who can walk me through it first." Never claim a team or purchases experience to soften it | F2 and F9 are your two stated gaps, and a Skeptic aims at exactly those. JD because it scores the posting's requirements, gaps included |
| B2 | "You've run a weekly content-drop calendar for one title. This role runs live events for two. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Story-mapped on F1: the weekly cadence, the main title and the two years are the beats the quote states; tell them in your own words. Answer slot: if any of the drops were timed events, say which; if none were, say so plainly, and then say what you would expect to change, as expectation and not as experience. Hold by returning to the calendar you ran, never by adding to it | The step from one title to two is the gap F1 shows, and the likeliest follow-up to the calendar claim. JD because it scores the first duty |
| B3 | "If a live event you plan sits alongside in-app purchases, how do you think about that?" | JD | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years." | Open with the plain acknowledgment: "I've never worked on a game with in-app purchases." Then give your approach as questions you would ask, not experience you have: who decides what is sold alongside an event, what they need from the calendar, and how results are reported against it. If pushed, return to "I ran the weekly content-drop calendar for our main title for the last two years." | F9 is a stated gap. The JD does not mention purchases, so this is a likely probe, not a listed requirement |
| B4 | "The role owns the post-event review and the KPIs it reports. What have you owned, as against presented?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Hold only what the quote carries: "Presented the monthly retention numbers to the studio head." Answer slot: if any of what was reported was yours to choose, say which and how you decided, in your own words; if none was, or it was not yours, say so plainly and describe what you presented. The honest branch is a limit, not a confession | F3 is where the JD presses hardest against your material, so the probe arrives in some form. JD because it scores the stated duty |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the retention numbers you presented each month." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Story-mapped on F7: monthly, the retention numbers and the studio head are the beats the quote states; tell them in your own words. Answer slot: the JD's player-retention line makes a probe on which measures likely. If you can say which measures you showed and how each was counted, say so; if you did not produce them, or cannot say how one was counted, say so plainly and return to presenting them. Weakest-assumption move: name, in your own words, the assumption behind a number you would defend least, or say plainly that you do not know | The prober reads your line closely. F7 is the evidence; EXP because it tests what was actually yours |
| C2 | "Where does your comfort with retention metrics end?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Start from the quote: "Presented the monthly retention numbers to the studio head." Then name, in your own words, one retention measure or analysis you would want to learn more about, and how you would learn it. Do not claim an analysis you did not do | The JD's comfortable-with line scores a boundary as much as a skill. F7 is the evidence, and an honest edge reads as credibility |
| C3 | "Walk me through the release checklist your QA team still uses." | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F4: you wrote it and QA still uses it, the beats the quote states; tell them in your own words. Answer slot: the JD's manage-with-QA line makes a probe on who ran it from release to release likely. If you did, say how; if QA ran it, or there was no such step, say so plainly and stay with the checklist you wrote | The checklist is your most concrete artifact. EXP because it tests what was actually yours; F4 is the row |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio."; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." | A 90-second arc whose beats are those four sentences, in your own words and at their own scope. For why this role, give your own reason for wanting it; the pack supplies none. Stop before you add a result or a team size you did not state | The biography question is scored even when it sounds casual. F5 to F7 are the rows it carries |
| D2 | "Have you played either of our two titles? What did you notice about their events?" | CO | [generic] | Play both before Friday and say what you saw, in your own words, labeled as a player's view. If you have not played them, say so plainly and say what you would look at first. The pack names no titles and no events, because none were in your material | The company is the one thing the pack could not research. Generic, and it becomes grounded if you paste the titles' names |
| D3 | "Tell me about a time your writing changed how a team worked." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Open prompt, so choose an instance. Your material carries one sentence: you wrote the release checklist your QA team still uses; tell that in your own words and stop at what it states. If no other time comes to mind, say so plainly, then give the nearest thing you did write, or how you would write an update for four teams | The JD asks for clear written communication, and F8 is thin. JD because it scores the stated requirement |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you when you've never led a team?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses." | Pause and restate the question. Hold on two sentences only: "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." Concede explicitly: "I've never led a team." Hold through two follow-ups by returning to those sentences, never by adding to them | F2 is the gap a Pressure interviewer tests for composure. JD because it scores a stated gap |
| E2 | "That retention work: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Hold the position the quote carries: "Presented the monthly retention numbers to the studio head." Answer slot: if you can say which part was yours, say it in your own words; if someone else produced the numbers, say so plainly and return to presenting them. Hold through two follow-ups, then concede only what is true | Attribution probes exist to catch inflation, and F3 and F7 are where yours is thinnest. EXP because it tests what was actually yours |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our art team says the event art needs two more weeks, and the calendar has a date. Where is the seam between production and art, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who owns the date, who owns the quality bar, and how a disagreement gets decided and recorded. Add reciprocity: what you bring to their team, not only what you need. The question needs no claim about your past, so the guidance makes none | The JD's coordination line (F2) tested collegially. JD because it scores the stated duty |
| F2 | "How do you handle credit when work spans teams?" | JD | [generic] | State your principle in a sentence or two. The pack does not carry a story for this one: if a real instance comes to mind, tell it in your own words at its own scope; if none does, say so plainly and give how you would handle it | A common peer probe on cross-team work (F2). Generic because no quoted sentence of yours speaks to it |

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A4, A5, B2 |
| "coordinate design, art, engineering and community teams on each update" | A2, B1, E1, F1, F2 |
| "own the post-event review and the KPIs it reports" | A3, B4, C1 |
| "manage the release checklist with QA" | A2, C3 |
| "3+ years producing live-service games or apps" | B2, D1 |
| "experience running a content calendar" | A1, B2, D1 |
| "comfortable with player-retention metrics" | A3, C1, C2, E2 |
| "clear written communication" | A3, D3 |

You gave no headline figure, so there is no defend-the-number question. If your CV has one, it earns one.

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| V1 | "What would make you say, six months in, that this hire worked?" | It shows you are already thinking about the post-event review and KPIs the JD gives the role, and it tells you what the success measure actually is |
| V2 | "Which retention measures does the studio treat as the headline ones when an event is reviewed, and who signs off on them?" | It turns your retention experience into a collegial question about their practice, and it surfaces who owns the KPIs |
| V3 | "How do design, art, engineering and community hear about the calendar today, and where does the producer sit in that?" | It addresses the coordination duty directly and tells you how much authority the role carries |
| V4 | "Do either of the two titles sell through in-app purchases, and if so, who do I work with on how events and offers fit together?" | It names your known gap as a question about where to learn, which reads as self-awareness rather than a confession |
| V5 | "What does the release process with QA look like now, and what is the part you would most want improved?" | It points at your most concrete artifact, the checklist, and invites them to name the problem you would be hired to solve |
| V6 | "Where does this role most often get stuck: dates slipping, scope, or sign-off?" | Rapport-style interviewers weight this slot heavily, and a specific question reads as preparation, not as a closing pleasantry |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or owned the live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a weekly content-drop calendar for one main title. B2's slot stays inside the calendar you ran |
| Owned the post-event review and the KPIs it reports | Inflated form of F3 | F3's quote at its own scope: the material says presenting the retention numbers, not owning a review. B4's slot asks only which part was yours to choose |
| Ran live-service operations for a title | Inflated form of F5 | F5's quotes at their own scope: an associate producer who ran the weekly content-drop calendar for the main title. The material does not say the title was a live service. D1 and B2 stay inside those sentences |
| Led or managed a team | Negative you stated, F2 | The plain acknowledgment: "I've never led a team." No slot |
| Has in-app-purchase or monetization experience | Negative you stated, F9 | The plain acknowledgment: "I've never worked on a game with in-app purchases." A plan only, never a past. No slot |

## Sources

**Provided documents:** the JD as pasted, and your message about your background. No `tuesday-dossier.md` was present. The loop is one session, the 60-minute interview with Tobias per your message, so this is session mode. Persona weights rest on the hiring-manager prior because the relationship was not stated. No interviewer read was written: only his name and title are known.

**Searches sent, all refused:**

- `Saltmarsh Games values` — refused
- `Saltmarsh Games interview process live operations producer` — refused
- `Saltmarsh Games mobile studio strategy news` — refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | The search was refused. It would have supplied value names for a values cheat sheet and VAL questions if a values round were documented |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | The search was refused. It would have named the loop's rounds; the persona weights rest on your own description and the hiring-manager prior instead |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | The search was refused. It would have grounded D2 and the CASE questions in the studio's current priorities; they are labeled generic |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The search was refused. It would have added an interviewer read and a reverse question tied to his career path |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is your future manager, a peer or a skip-level → reweights every bank and the persona table; a peer raises bank F, a skip-level raises Case and Pressure
- Any recruiter guidance (focus areas, a pre-declared presentation or take-home) → coverage of a graded deliverable the pack cannot otherwise know about
- Your CV, or the lines behind the four years → F1 to F8 evidence cells drawn from your own wording; any figure on it earns a defend-the-number question
- A work sample, such as a past post-event review, a content calendar page or an excerpt of the release checklist → the artifacts this field keeps as proof; it can raise F3, F4 and F8 from medium or low toward high
- Your answers to the answer slots in F1, F2, F3, F4, F5 and F8 → those rows move from discovery or transferability to quoted evidence, and the matching guidance cells get real beats
- The two titles' names, or their store pages pasted → D2, A1 and A4 become grounded in what the titles actually run
- Saltmarsh's careers or values page, pasted → value names, and a values cheat sheet if a values round is documented
- A profile or recent talks of Tobias's, pasted → an interviewer read and a reverse question tied to his path
- A `tuesday-dossier.md`, if you have one → verified evidence and absolute prohibited claims, which tighten every guidance cell
