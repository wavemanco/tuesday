Your mock-interview pack for Priya is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-1-denied-4194b440/Northwind-Data_senior-gtm-strategy-lead_interview_pack.md`. It has 20 questions in tables, grouped by interviewer persona and tagged by question type. Each question has answer guidance and a rationale for including and categorizing it.

I built it for one 60-minute peer conversation with Dan. Web search was denied, so Northwind's values page, its documented interview loop and Dan's public footprint were not researched. Dan's profile and the Northwind priorities come only from what you gave me, and I couldn't verify the research note.

- **Evidence rows:** they rest on your summary of Priya and your JD highlights, not on a CV or the full JD text.
- **Weights:** the Data-Driven Prober gets 5 questions, because Dan calls himself "relentlessly data-driven". The Peer Evaluator gets 4 and the Case/Strategist, Skeptic and Conversational personas get 3 each. Pressure gets 2.
- **Highest-ROI prep (D1):** "I don't see sales-ops or quota-setting in your background." It's the most predictable objection, and the pack scripts the exact concession and three follow-ups.
- **Second priority (D2):** the required partner-motion design line, where her evidence is a revenue model rather than a motion.
- **The ~$400M figure:** it gets its own defend-the-number rehearsal (A1, A2, F2). Her sentence says she proposed the change and it was credited with the uplift, so the pack never coaches "drove" or "owned".
- **Answer slots:** where her material is silent, the guidance is an instruction to answer in her own words. It never invents her stories. Filling those slots would sharpen the pack the most.

There are no values/behavioral or deliverable sections. No values source or announced deliverable was supplied.

Say the word and I'll play Dan as the Skeptic on D1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document.

Did the recruiter give any guidance on focus areas, or announce a deliverable such as a POV, presentation or take-home? If so, I'd add a build section and reweight the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Northwind-Data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya (guidance below speaks to her as "you")
**Interviewer:** Dan Kovac, Director of Sales Strategy — a peer: both report to the same VP
**Round:** one 60-minute conversation, a peer round. The loop comes from the coach's own description, not from a Northwind source.
**Built on this assumption:** the evidence rows rest on the coach's summary of Priya and on JD highlights, not on a CV or full JD text. Web search was not permitted in this session, so Northwind's published values, its documented loop and Dan's public footprint were not researched. The upgrade menu says what each would add.

## How to use this pack

- **Personas** describe how a question will be asked. **Types** describe what is being scored. Every question carries both, so you rehearse the delivery as well as the content.
- **Type key:** VAL = behavioral or values alignment (none banked: no published values were in hand and no values round is documented). EXP = work-experience deep-dive. JD = role or JD-driven. CO = company and strategy knowledge. CASE = hypothetical or live problem.
- **Guidance is scaffolding, not a script.** It is built only from sentences quoted in the Provenance cell. Where your material does not say something, the cell gives an **answer slot**: an instruction for the interview, with an honest branch for "that step never existed or was not mine". A slot asks for no reply here.
- **Type coverage by persona** (a reading of the banks below):

| Persona bank | EXP | JD | CASE | CO | VAL | Total |
|---|---|---|---|---|---|---|
| A. Data-Driven Prober | 4 | 1 | 0 | 0 | 0 | 5 |
| B. Peer Evaluator | 0 | 4 | 0 | 0 | 0 | 4 |
| C. Case / Strategist | 0 | 1 | 2 | 0 | 0 | 3 |
| D. Skeptic | 0 | 3 | 0 | 0 | 0 | 3 |
| E. Conversational | 1 | 1 | 0 | 1 | 0 | 3 |
| F. Pressure | 2 | 0 | 0 | 0 | 0 | 2 |
| Total | 7 | 10 | 2 | 1 | 0 | 20 |

## The fit snapshot

Requirements are the JD highlights from your message; the full JD text was not supplied, so exact wording may differ from the posting. Evidence cells hold the coach's words only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops and a proposed change, not go-to-market ownership, so the words stay at that scope: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: the JD's new-product-lines line makes a probe on launch work likely. If any of your product work was at a launch, say which and what part was yours, in your own words; if not, or it was not yours, say so plainly and stay with the change you proposed |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | Inferred only in that the ARR figure touches the area; the sentence names no stage of land, adopt, expand or renew, and the bridge should not supply one. Answer slot: the JD's four-stage line makes a probe on which stage the change moved likely. If it moved a particular stage, say which and how you know; if the work was not framed in those stages, or you do not know, say so plainly and stay with the change you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap in terms, but a self-report with nothing inspected behind it, so expect a probe. Lead with it in its own terms: you are skilled in SQL/Tableau. The sentence names no analysis; A3 holds the slot where you name one you ran yourself |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The highest-stakes row: the JD marks it required. Your material says a model used in negotiations, not a motion, and the words stay there: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the required-experience line makes a probe on what part of the partner work was yours to decide likely. If any part of how the model was set up or used was yours to decide, say which and how you decided; if none, or it was not yours, say so plainly and stay with the model you built |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms; reword nothing beyond it: "I set annual volume targets with cross-org consensus." Consensus across orgs is what it carries. Answer slot: the influence line makes a probe on where the orgs differed likely. If they differed, say what happened and what part was yours; if they did not, or none of it was yours, say so plainly and stay with the targets |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The quote reaches the plus-skill in other terms, at the scope of use: "I use AI tools daily." Your material says use, not building or launching. Answer slot: the plus-skill makes a casual probe likely (E2). Say which tools and for what, in your own words; if it is general use, say so plainly |
| F7 | Sales-ops and quota-setting familiarity — a role-family expectation beside a Director of Sales Strategy, not in the JD highlights; whether the role needs it is not established | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and your note says so. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. The closest stated work is F5's sentence, offered only at its own scope. Nothing added to make the gap feel smaller |

No row is a hard gate: nothing in the highlights is a term such as location, pay, authorization or schedule. A full JD may add some.

**Requirement coverage** (each stated requirement mapped to the questions that cover it)

| Requirement | Questions |
|---|---|
| F1: GTM strategy for two new product lines | C1, C2, B1, B4, E3 |
| F2: whitespace across land/adopt/expand/renew | C2 |
| F3: independent SQL and Tableau analysis | A3, B3, C2 |
| F4: partner-motion design, required | D2, C3, A4 |
| F5: cross-functional influence | B2, A5, B1 |
| F6: AI experience, a plus | E2 |
| F7: sales-ops and quota-setting, not in the JD highlights | D1, F1, D3 |
| Headline metric, the ~$400M ARR figure | A1, A2, F2 |
| Northwind strategy, from your research note | C1, C2, E3 |

## Reading the interviewer

Public professional self-description and career pattern only, as you supplied them.

| Item | What the material says | What it means for the pack | Provenance |
|---|---|---|---|
| Relationship | Dan is a peer: both report to the same VP | Peer Evaluator and Data-Driven Prober lead the weights; reciprocity matters (B3, R2) | [grounded] |
| Self-described style | His profile says "relentlessly data-driven" — your message | Every number is probed to its assumptions: the ~$400M figure, the revenue model, the targets (A1, A2, A4, A5) | [grounded] |
| Career pattern | A spine of "pricing and monetization roles" — your message | Case questions tilt to pricing, packaging and unit economics (C1, B4); your material shows no pricing work, so the honest posture is to listen and ask | [grounded] |
| Early-stage chapter | "one early-stage-startup chapter" — your message | Expect a probe on moving from a large company to a roughly 3,000-person vendor, and a reverse question on his own path (R1). Your quoted material carries no startup sentence, so nothing is offered as a shared jump | [inferred] |
| Mirror opportunity: shared vocabulary | His monetization language, and your F4 sentence: "built a partner-level revenue model used in carrier negotiations" | Use revenue and monetization vocabulary freely, but at that sentence's scope: a revenue model, not pricing work | [grounded] |

## Persona table

Weighting in three passes: relationship prior, then interviewer signals, then the loop. The loop is one session from your words, so there is no cross-round adjustment, and no values-style round is detected because no loop source documents one and no Northwind values page was read. Recalibrate if you know something this does not.

| Persona | How it shows up with Dan | Weight, with reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| A. Data-Driven Prober | Reads line by line, asks how each number was counted, goes two levels deeper than the answer | Highest, 5 questions. Peer prior, raised by his stated style | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know. Name your weakest assumption before he does |
| B. Peer Evaluator | Seam-splitting between his team and yours, what you would need from him, credit across teams | High, 4 questions. The relationship prior: he is pricing what you cost and add to his work | Reciprocity first: what you bring his team. Propose seam principles instead of pretending to know the seam |
| C. Case / Strategist | Live problems on the new lines, pitched in pricing, packaging and bundling terms | Mid, 3 questions. His pricing and monetization spine tilts cases there; the role is a strategy role | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| D. Skeptic | Quiet probing of the sales-ops and partner-motion gaps, and the move from a large company | Mid, 3 questions. F4 and F7 are the thin rows; the startup chapter adds a pace probe | Rehearse the single most predictable objection until it is boring. Concede the limit in your own stated words, then give a ramp plan |
| E. Conversational | Friendly opener, the AI plus-skill asked casually, a read on the company | Mid, 3 questions. Casual-register questions are still scored, and the JD flags AI | A pre-scripted 90-second arc; treat the casual AI question as scored |
| F. Pressure | Time-boxed "why you" and "how much was you" | Low, 2 questions. Not a peer prior; Dan is likelier to apply it as a prober follow-up | Pause, restate, hold the position your quotes carry through two follow-ups, concede specifically |
| Values / Behavioral | Not banked | No values source in hand and no values round documented. B2 carries the behavioral shape | Re-weight if a values round is confirmed |

## Question banks

The deepest rehearsal is **D1**, the most predictable objection to this candidate. It is the highest-ROI prep in the pack.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Start from the sentence: you proposed a change, and it was credited with the uplift. Three slots, each in your own words: how the figure was counted, what it is sensitive to, and the assumption behind it you would defend least; name that one before Dan does. If you do not know how it was counted, say so plainly and say what you do know. Offer to walk an analysis end to end only if you did it yourself | F1 and F2 rest on this figure, the one headline number, so a data-driven peer opens here; EXP because it tests whether the claim survives its own arithmetic |
| A2 | "What would have to be true for that figure to be wrong?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: say, in your own words, what the figure leans on that you would defend least. Answer slot: if you know what it is sensitive to, say it; if you do not, say so plainly rather than constructing a reason, and say what you would check first. Do not describe a method you did not use | The second level down from A1, which his stated style makes likely; EXP because it tests whether you know your own assumptions (F1) |
| A3 | "Tell me about an analysis you ran yourself, end to end, in SQL or Tableau." | JD | [grounded] "skilled in SQL/Tableau" | Selection scaffold: pick one analysis where you wrote the query or built the view yourself; say the question it answered, the data it ran on, the assumption you would defend least, and what happened to the result. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries, that you are skilled in SQL/Tableau, or how you would approach one. If you did it yourself, offer to walk through it | F3 is a self-report; the JD asks for independent analysis and his style makes this the likeliest verification. JD because it scores the stated requirement; an open prompt, so the pack supplies no analysis |
| A4 | "Walk me through the partner-level revenue model that was used in carrier negotiations." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: you built it, it was partner-level, it was used in carrier negotiations; tell it in your own words. Answer slot: the JD's independent-analysis and partner-motion lines make a probe on what the model took in and how it was used likely. If you chose its inputs or set how it was used, say which and how you decided; if someone else supplied them, or there was no such step, say so plainly and stay with what you built. Say the model was used in the negotiations; do not describe yourself in the room | F4 is the evidence for a required line, and a model is an artifact a data-driven peer will open; EXP because it tests what was actually yours |
| A5 | "Walk me through the annual volume targets you set — what were they counting?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Beats the sentence states: you set annual volume targets, and with cross-org consensus. Keep the word the sentence uses: targets. Answer slot: say what the targets counted, in your own words; if you do not remember or never knew, say so plainly and say what you do know. Then stop; the consensus story is B2 | F5 is the closest stated work to the target-setting his function does; EXP because he will test what the work was and how far it reaches |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side — where's the seam between your work and mine on the new product lines, and what happens when we disagree?" | JD | [grounded] | You cannot know the seam yet, so say that and propose principles: which decisions each side makes alone, which are made together, and how a disagreement is settled before it happens, given you report to the same VP. A disagreement story only if a real one comes to mind; your material carries none, so otherwise say how you would handle it | F1 puts GTM for the lines on you and sales strategy is his; JD because it scores partnership fit with the stated role, and the peer stem is persona-driven |
| B2 | "Tell me about a time you needed another team to agree to something you wanted." | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the targets, and the consensus across orgs; tell it in your own words. Answer slot: if the orgs differed, say what happened and what part was yours; if they did not, or none of it was yours, say so plainly and stay with the targets. Do not add a conflict the sentence does not carry | F5 is the evidence for the influence line; JD because the open prompt scores that requirement, with the behavioral shape a values round would take |
| B3 | "What would you need from me and my team in your first ninety days?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity first: what you offer his team at the scope the sentence carries, that you are skilled in SQL/Tableau. Then what you need, as questions: which data his team treats as the source of truth for each lifecycle stage, and how the new lines' goals are set today | The peer stem, and the slot where "any questions" tends to go generic; JD because it scores whether you reduce or add to his load (F3) |
| B4 | "Where do you see my work and yours overlapping on pricing and packaging for the new lines, if at all?" | JD | [inferred] | Your material shows no pricing work, so this is a listening answer: say you do not yet know how pricing decisions are made here, ask how they are made today, and propose a principle for who sets price and who sets the motion. Do not borrow pricing vocabulary as experience | Inferred from his pricing and monetization spine, not from the JD; JD because it tests turf awareness on the lines in F1 |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A much larger platform vendor starts bundling a comparable capability into its suite. For one of our new product lines, how would you decide between selling it standalone, bundling it with what customers already buy, or competing on price — and what do you need to know first?" | CASE | [grounded] | Clarify first: which line, which products customers already hold, what the rival bundle includes and costs. Objective next: profitability is a stated priority in your research note, so say which you are optimizing. Then segment customers by existing footprint, lay out the three options, name the metrics he will want (win rate against the bundle, price realization, unit economics), and the risks. Think aloud and challenge one premise. Bring the consensus answer to prove grounding, then one divergence with reasons and one thing you would not do | The bundling threat comes from your research note, which I could not verify; CASE with a CO angle, tilted to pricing by his spine, so the guidance makes no claim about your past (F1) |
| C2 | "Profitability is a stated priority and Compass is a launch. How would you decide where go-to-market investment goes across land, adopt, expand and renew for a new product line?" | JD | [grounded] "skilled in SQL/Tableau" | Clarify what Northwind measures at each stage today before answering. Define whitespace in your own terms, form a hypothesis early, and say which analysis you would run in SQL/Tableau and what result would change your mind. Keep the trade-off visible: enterprise expansion against profitability | F2 and F3 meet here; JD content with CASE delivery, because the whitespace line has no other question. Priorities and Compass come from your research note |
| C3 | "Sketch a partner motion for one of the new lines — what do you need to know first?" | CASE | [grounded] "built a partner-level revenue model used in carrier negotiations" | Clarify first: what partners would do for the product, who owns the customer relationship, how partners are paid today. Then objective, partner segments, economics, metrics, risks. You may point to partner-level economics as the lens you have worked with, at the sentence's scope, a revenue model and not a motion. Present the sketch as a design you would propose, not one you have run | F4 is required and thin, so the case rehearses the structure without claiming the experience; CASE because it is a live problem from the JD |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see sales-ops or quota-setting in your background. How would you work alongside a sales strategy team without it?" | JD | [grounded] "No classic sales-ops or quota-setting experience." "set annual volume targets with cross-org consensus" | **Highest-ROI prep in this pack.** The limit comes first, in your own words, then stop: "I don't have classic sales-ops or quota-setting experience." Follow-up 1, what that costs: answer with a plan, naming the first things you would ask his team about how goals and data work. Follow-up 2, what is closest: "I set annual volume targets with cross-org consensus", at that scope only, and say you would want his view on how close that is. Follow-up 3, "so you are learning on the job": concede plainly that part of the ramp is learning from his team, and hold the lines your quotes reach (F3, F5). Do not apologize, and add nothing | F7 is the biggest gap against his function, so this arrives in some form. JD because it scores whether you can do the listed job beside him; the exact concession and the limit are named before he asks |
| D2 | "What part of designing a partner motion have you done yourself?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Hold only what the quote carries: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any part of how the model was set up or used was yours to decide, say which and how you decided; if none was, say so plainly and describe the model. The honest branch is a limit, not a confession. Hold through two follow-ups by returning to the model, never by adding to it | F4 is where the required line presses hardest; JD because it scores the stated requirement, and it is the second-deepest rehearsal after D1 |
| D3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | Choose from where your own material is thinnest: F1, F2, F4 and F7 are the thin rows. Pick one you can truthfully name, say it plainly, then give a ramp plan said as a plan. If your honest pick differs, use yours. Do not name a requirement your quotes already carry (F3). If you pick the sales-ops gap, your words are "I don't have classic sales-ops or quota-setting experience." If no weakness comes to mind, say so plainly, then give the nearest thing your material does carry | A persona stem aimed at the gaps; JD because it scores honest self-assessment against the stated requirements |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with only the beats the sentence states: two years of strategy consulting at a top firm, then nine at a large consumer-tech company in product strategy and ops. Then why this role and why now: say your actual reason, in your own words; if one of the stated priorities in your research note is the reason, say so, otherwise do not borrow one. End on what you want to work on, not a summary | F1; the biography question is the one most often unprepared. EXP because it tests whether the CV story is coherent and economical |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | The sentence is "I use AI tools daily." Say which tools and for what, in your own words; if it is general use rather than building, say that plainly. You may offer a view on how a copilot changes go-to-market, labeled as a view and not experience. Do not claim AI product or launch work | F6; JD because it scores the plus-skill, asked casually. The probe is likely given Compass in your research note |
| E3 | "What's your read on where Northwind stands against the bigger platform players?" | CO | [grounded] | Bring one consensus item to prove homework, from your research note: the stated priorities of enterprise expansion, Compass and profitability, or the bundling threat. Then one thesis-driven divergence with reasons, and what you would not chase. Check each against current public material before the call, since I could not verify the note. Frame it as how you understand it; do not coach yourself to correct him | The note is what a prepared candidate also holds, so recitation scores as homework and departure scores as judgment. CO because it tests company-altitude thinking (F1) |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has carried a quota?" | EXP | [grounded] "No classic sales-ops or quota-setting experience." "built a partner-level revenue model used in carrier negotiations" "set annual volume targets with cross-org consensus" "skilled in SQL/Tableau" | Pause, restate the question, then hold what your quotes carry and no more: the model, the targets with cross-org consensus, skilled in SQL/Tableau. Concede specifically: "I don't have classic sales-ops or quota-setting experience." Make your case on the JD lines you reach (F3, F4, F5), not on being better than the other person. Hold through two follow-ups by returning to those sentences; never fold on them to restore harmony | F7 is the likeliest thing to be pressed under time. EXP because it tests holding a position without defensiveness |
| F2 | "That result — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause first. The hold is the sentence: "I proposed a store-surface change credited with a ~$400M ARR uplift." Answer slot: if more of it was yours than the proposal, say what; if the proposal is the whole of your part, say so plainly. That is the honest answer, not a confession. Concede that you cannot speak for how the credit was counted unless you know. Hold through two follow-ups by returning to the sentence, never by adding to it | F1 and F2; the standard attribution probe aimed at the one headline figure. EXP because it exists to catch inflation |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your background runs through pricing and monetization, with a stretch at an early-stage company. What from that stretch do you still use in sales strategy here?" | Tied to his own path, it turns a probe into a peer conversation and shows you researched him, not just the company |
| R2 | "What could a new person on my side do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it signals you reduce his load before you ask for anything |
| R3 | "Where is the line between your team's work and the go-to-market for the new lines today, and where is it still unsettled?" | It converts B1 from a test into a shared problem and shows you expect an unsettled seam |
| R4 | "Which metrics does your team treat as the source of truth across land, adopt, expand and renew, and where do you distrust the data?" | He describes himself as data-driven, so this invites his own view, and it shows you are thinking about the analysis you would run |
| R5 | "How is the bundling pressure from the larger platform vendor showing up in the deals you see, and how is it shaping the plan for the new lines?" | It uses a strategy point from your research note and puts the CO knowledge in his hands |
| R6 | "What does success look like at ninety days for this role, and who else will I be working with?" | A preparation signal, and it surfaces who the cross-functional partners are |

## Prohibited claims

What this pack will not coach, built from the fit snapshot. The limits stated here are the pack's own observations, not words for you to say.

| Not coached | Basis | Honest form |
|---|---|---|
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F1 and F2 | The quote at its own scope: "proposed a store-surface change credited with a ~$400M ARR uplift". The limit is the pack's observation: the material says proposed and credited, not delivered or owned. A2, A5 and F2 stay inside the proposal |
| Designed or ran partner motions | Inflated form of F4 | F4's quote at its own scope. The material says a revenue model used in carrier negotiations. D2's and A4's slots stay inside the model |
| Presented the volume-target work as quota or sales-ops experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Got resistant orgs to agree, or led alignment across them | Inflated form of F5 | F5's quote at its own scope: "set annual volume targets with cross-org consensus" |
| Built, shipped or led AI products, or ran AI go-to-market | Inflated form of F6 | F6's quote at its own scope: "uses AI tools daily" |

## Sources

**Provided documents:** your message, which held the JD highlights, the candidate summary, the interviewer profile and your research note on Northwind's priorities (enterprise expansion, the Compass copilot launch, profitability, and bundling by a larger platform vendor). I could not verify the note. No dossier was present.

**Searches sent:**
- "Northwind Data company values principles" — refused
- "Northwind Data interview process strategy operations" — refused
- Dan Kovac, Director of Sales Strategy, Northwind Data — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Every call was refused. It would have supplied published value names for VAL-themed questions; none are in this pack |
| 2. `Northwind Data interview process, strategy and operations roles` | unavailable | Every call was refused. It would have established the loop; persona weights rest on your description instead |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the stated priorities and the bundling threat for C1, C2, E3 and R5 |
| 4. `Dan Kovac Northwind Data` | unavailable | Every call was refused. It would have added talks and writing to the interviewer read; that section rests on the profile you gave |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the fit snapshot and JD-tagged questions |

## Upgrade menu

- Full JD text: the six JD requirements now rest on highlights, and the full text could change F1 to F6 wording, add requirements and surface any gate such as location or pay
- Priya's CV, or the exact lines: evidence cells now rest on the coach's summary; the CV would add verbatim sentences and could upgrade F1 to F7 rows
- The write-up behind the ~$400M figure, the revenue model, or the target-setting document: these are the inspectable artifacts for this field, and they could lift F1, F2, F4 and F5 from `medium` or `low`
- Priya's own answers to the slots in F1, F2, F4, F5 and F6: those rows become grounded stories and A1, A2, A4, A5, B2 and E2 sharpen
- Northwind's values page and interview-process details, which need web search to be allowed: values-themed questions, and a check on the loop
- Dan's public talks or writing: his recurring themes become likely questions and a tailored reverse question
- Recruiter guidance on focus areas or a pre-declared deliverable: it would add a graded-deliverable build section
- Prep time available: it would add a prioritized prep schedule
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes, web search required): it would ground C1, C2 and E3 in a verified strategy brief
- A `tuesday-dossier.md`, if one exists: verified evidence and a standing prohibited-claims list that would replace the locally built one
