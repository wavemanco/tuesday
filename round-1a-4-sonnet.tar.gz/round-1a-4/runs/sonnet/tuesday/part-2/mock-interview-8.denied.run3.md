Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-8-denied-92bbf14a/ashgrove-credit-union_member-experience-lead_interview_pack.md`.

I built it as one pack for all three rounds on 3 December, with its own questions, persona weights and reverse questions for each round. I didn't run any web searches. Your messages already gave me the values, the loop and the strategy points, so a search couldn't have changed anything.

- **Contact-centre gap:** this is the one objection that will come up in all three rounds. You've never worked in a contact centre, and the role is branches and contact centre. I made it the top rehearsal (B1, then D1 and K1): say it plainly, then give a future-tense plan.
- **Presenting to senior leaders:** you've never presented above regional level, so D2 handles that the same way.
- **Pay, notice, location and reason for leaving:** these come up in round 1 as A4 to A7. The pack gives no figures or reasons. Those answers have to be yours.
- **The four values:** I mapped Own the Fix and Plain Words to things you actually said. Members First and Neighbours, Not Numbers have no story in your material yet, so they get prompts for picking one, with a plain "I don't have one" as an acceptable answer.
- **Round 3 case:** H1 to H4 cover the 20-minute escalation case and the strategy-based variants (the app channel and the branch-to-hub merger).
- **Wording the pack won't coach:** I won't coach "owned the process end to end", "handled regulated complaints", or "coached supervisors". Your material says the branch's log, a formal log and new tellers.

I can play the Skeptic on B1, the highest-value drill, if you'd like to rehearse it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
I can convert the pack to a Word document if you want one.

1. Can you paste your CV, or a few lines from it? Anything on the complaints log, the spreadsheet, or what you've presented at regional level would restructure several rows.
2. Do you want a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) for company context and the competitive picture? It can't do much for interviewer prep until names are assigned.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three rounds on 3 December 2026.

| Round | Who | Length | Shape |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Screen |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | 20-minute complaint-escalation case; also the values round, scored against the four values |

Interviewer names are not yet assigned, so there is no interviewer read. This is the first version of the pack.

## How to use this pack

Personas are how a question arrives. Types are what it scores. Guidance is scaffolding, not a script: every sentence about your past is one you wrote, quoted in the Provenance cell beside it, and every gap in your material is an answer slot you fill in your own words or answer plainly.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know Ashgrove's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to something you supplied; `[inferred]` is this pack's derivation, named; `[generic]` is a pattern for the role, with no claim about Ashgrove or you.

## Prep triage

All three rounds fall on 3 December, nine days from today (24 November). In order:

1. B1, then D1 and K1: the contact-centre question is the one objection in all three rounds. Rehearse it aloud until it is boring. Everything else is secondary to this.
2. A4 to A7: write your own pay, notice, location and reason-for-leaving answers in a sentence each. The pack supplies none of them.
3. G1 to G4 and C1 to C2: choose, from your real work, the story for each of the four values, or decide you have none and say so plainly.
4. H1: run the escalation case aloud twice against a 20-minute timer.
5. F1 and F2: decide exactly what your monthly spreadsheet counted, and which software it was built in.
6. D2: your answer on presenting to senior leaders.

Everything else is insurance.

## Fit snapshot (shared by all rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process end to end, and the words stay at the log: "I handled the branch's formal complaints log." Answer slot: expect a probe on whether you followed a complaint beyond the log. If you did, say how far and what was yours; if the log was where your part ended, or someone else owned what came after, say so plainly and stay with the log you handled |
| F2 | "and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then a plan in the future tense, in your own words; B1 holds the structure. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet, and does not show what it counted. Answer slot: expect a probe on what it counted. Say what it counted, in your own words; if you are not sure exactly, or it showed something else, say so plainly and stay with what you built |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your material says a formal log, and does not show what governed how it was kept. Answer slot: expect a probe on how the log was kept. If anything about it was set outside the branch, say what, in your own words; if nothing was, or you do not know, say so plainly and stay with the log you handled |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead with it in its own terms: six years in retail banking, the last three as a branch supervisor |
| F6 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then a plan in the future tense, in your own words. Your material does not show what you have presented up to regional level; D2 holds an answer slot for it |
| F7 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms, and the words stay as it says: "I built the monthly complaints spreadsheet our regional manager uses." It says spreadsheet, not Excel, so name the software only as it truly was |
| F8 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and a script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD asks about coaching supervisors. If you have coached a fellow supervisor on an escalation, say what; if not, say so plainly and stay with the tellers |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Strong evidence here would be a named piece of work with a digital or product team and the part you owned. Answer slot: if you have worked with any digital team, or on any self-service channel, say what and what was yours; if not, say so plainly and say how you would approach it |

Reading: none of the JD's lines is a term such as a licence, location or pay, so the snapshot carries no hard-gate rows. Logistics terms (pay, notice, location) come up in round 1 as A4 to A6.

## Grounding brief

| Item | Source | Provenance | Where it can surface |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | the July 2026 strategy brief, as you summarised it | [grounded] | A3, H3 |
| Consolidate eight branches into five hubs over 2027 | the same brief, as you summarised it | [grounded] | A3, H4, R3 reverse questions |
| Launch a small-business lending product in Q1 2027 | the same brief, as you summarised it | [grounded] | A3, R2 reverse questions |
| Main competitive pressure is app-only banks | the same brief, as you summarised it | [grounded] | A3, H3 |
| Member-owned, about 900 staff | the JD | [grounded] | A2 |

The brief is about four months old, inside the six-month freshness window. You gave me a summary of it, not the text.

## Prohibited claims

Built before the banks. These are claims this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not the process end to end. C2 and G4 stay with the log |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says a formal log, not what governed it. B3's slot stays on how the log was kept |
| Worked in, or with, a contact centre | Negative you stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Presented to senior leaders | Negative you stated, F6 | The plain acknowledgment F6 gives: "I haven't presented to anyone above regional level." No bridge |
| Coached branch supervisors | Inflated form of F8 | F8's quote at its own scope: "trained new tellers on our escalation script". C3's slot stays with the tellers |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says the spreadsheet, not what it counted. F1's slot asks only what it counted |
| Built Excel reports or dashboards | Inflated form of F7 | F7's quote at its own scope: the spreadsheet you built. The limit is the pack's observation: your material does not name the software |

## Round 1: the recruiter (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured, with logistics folded in | High. The recruiter-screen prior is Conversational plus a light Skeptic, and your recruiter's own note says only "30 minutes with me". Casual questions here are still scored | A 90-second arc for the biography question; your own one-sentence answers on pay, notice, location and reason for leaving |
| Skeptic | Quiet knockout checks against the JD | Medium. A screen checks the JD's headline lines, and F2 is the visible gap | Rehearse the contact-centre answer until it is boring; plain acknowledgment, then a plan |
| Values/Behavioral | One "why us" question | Low. The recruiter's email puts the values scoring in the panel round, so the main bank sits in round 3 | Pick one value by its official name |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through your journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc whose beats are only those the quotes state: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Tell each at its own scope, in your own words. Close with one sentence on why this role, which the pack does not supply | F5 is the headline experience line, and F1, F7 and F8 are the evidence the arc rests on. EXP because it opens the conversation on your own history |
| A2 | "Why Ashgrove?" | CO | [grounded] "I handled the branch's formal complaints log" | Pick one of the four published values by its official name and say in your own words why it matters to you. The value F1 sits nearest is Own the Fix, "whoever finds the problem keeps hold of it until it is solved", and the quote carries only that you handled the log. Answer slot: if you kept hold of a particular complaint until it was solved, say which and what was yours; if the log was as far as your part went, say so plainly and stay with the log | A friendly opener scored for genuine interest. CO because it tests homework on the published values; F1 is the nearest evidence |
| A3 | "What do you know about where Ashgrove is heading?" | CO | [inferred] derived from the brief's 40% digital target and the JD's channel wording | Ground it with one point from the brief as you summarised it, such as the 40% digital target by 2028. Then one thesis, yours to adopt or drop: as service moves digital, complaints may begin inside digital journeys, which the JD's branches-and-contact-centre wording does not mention. Concede the limit: you have not seen Ashgrove's complaint data, so you would ask where complaints start today. The pack makes no claim about your past here | The grounding brief gives the strategy points; one grounded point plus one reasoned thesis scores as judgment rather than recitation. F9 is why the digital angle matters for this role |
| A4 | "What salary are you looking for?" | JD | [generic] | Logistics slot: give your own figure, or ask for the role's band first. The pack supplies no figure. If asked what you earn now, you can decline to give a figure and steer back to what you are looking for in this role | A recruiter screen checks pay in a friendly register; JD because it is a term of the listed job |
| A5 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words | A knockout check on timing; JD because it is a term of the listed job |
| A6 | "Where are you based, and can you work across branches and the contact centre?" | JD | [generic] | Logistics slot: state where you are based and any limits on travel or working pattern, in your own words. The JD says "across branches and the contact centre" without naming sites, so if it is not clear which sites the role covers, ask the recruiter | The JD's own wording makes a location check likely; JD because it is a term of the listed job |
| A7 | "What's prompting you to look at a move?" | EXP | [generic] | Logistics slot: give your own reason in one or two sentences. The pack supplies none. Keep it about what you are moving toward | Recruiters check reason for leaving for consistency with the rest of your story; EXP because it is about your own history |
| B1 | "The role covers the contact centre as well as branches. How do you see that, given your background?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't worked in a contact centre." Hold only what the quote carries, "I handled the branch's formal complaints log", which is one branch's log. Expect three follow-ups. First, what would you do first: a plan in the future tense, in your own words, covering what you would learn, who you would ask and what you would leave alone until you had. Second, why would branch experience carry across: return to the log and stop. Third, what if contact-centre colleagues see you as a branch person: concede it is a fair concern, and say what you would ask of them. Hold through two follow-ups by returning to the log, never by adding to it | F2 is the stated gap in the role's headline line and the most predictable objection in all three rounds, so a rehearsed non-defensive answer changes the whole day. JD because it scores a listed requirement |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose the one you would name first and say it in the plain words: "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level". Then a plan in the future tense. Naming one yourself turns a probe into candour. Do not volunteer both unless asked | The persona stem for the Skeptic; F2 and F6 are the stated gaps. JD because it scores the listed job's gaps |
| B3 | "The role asks for experience handling regulated complaints. What experience do you have there?" | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F4: "I handled the branch's formal complaints log." Tell it at that scope. Answer slot: expect a probe on how the log was kept. If anything about it was set outside the branch, say what, in your own words; if nothing was, or you do not know, say so plainly and stay with the log you handled | F4 is the requirement the quote touches without showing it reaches. JD because a recruiter checks it as a knockout line |
| B4 | "The role works with digital teams on self-service journeys. What experience do you bring to that?" | JD | [grounded] | Answer slot: if you have worked with any digital team, or on any self-service channel, say what and what was yours; if not, say so plainly, then say how you would approach it. The pack supplies no experience here | F9 has no evidence in your material, and the JD raises it. JD because it is a stated requirement |

### Reverse questions (round 1)

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "After 3 December, how soon do you expect a decision, and who makes it?" | Shows you are planning, and the answer is practical for you |
| R1-2 | "Which sites does the role cover, branches and contact centre both?" | Settles the location slot in A6 and shows you read the JD's "across branches and the contact centre" closely |
| R1-3 | "Of the two branch managers on the panel, what do they most want from this role?" | The recruiter can speak to the panel before you meet them, and it shapes round 3 |
| R1-4 | "Is the digital self-service work in this role mostly design input or day-to-day delivery?" | Clarifies F9's weight in the role |
| R1-5 | "How will the role's success be judged in the first six months?" | A recruiter-level question that gives you the scoring sheet to prepare against |

## Round 2: the Head of Member Services (45 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time" prompts | High. The recruiter calls this round mostly behavioural, which moves Values/Behavioral above the hiring-manager prior | A story where one of your quoted sentences carries it, a selection scaffold with its honest branch where none does |
| Skeptic | The manager derisking the role's gaps | High. A hiring manager is buying capability and checking gaps; F2 and F6 are the stated ones | Plain acknowledgment, then a future-tense plan, then stop |
| Case/Strategist | A live problem from the role | Medium. The hiring-manager prior says expect one; the behavioural framing lowers the share | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | Reads your CV lines closely | Low. You have given no figures, so the probe lands on what the spreadsheet counted and which tool built it | Say exactly what you know; say plainly when you do not |

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you had to deliver an unpopular truth to someone more senior." | VAL | [generic] "I built the monthly complaints spreadsheet our regional manager uses" | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the monthly complaints spreadsheet your regional manager uses, or how you would handle it. Answer slot: if what that spreadsheet showed was ever unwelcome, say what and what you did; if it was not, say so plainly | Persona stem for the Values/Behavioral persona, and the JD asks for confidence before senior leaders (F6). VAL because it scores behaviour, and F3 and F7 are the nearest evidence |
| C2 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1, with the beats the quote states: you handled the branch's formal complaints log. Tell it at that scope. Answer slot: if you followed one complaint from the log to its resolution, say how and what was yours; if the log was where your part ended, say so plainly and stay with the log. The value's own words are "whoever finds the problem keeps hold of it until it is solved" | The published Own the Fix value, and the JD's end-to-end line. VAL because it scores the value; F1 is the evidence. G4 repeats it for the panel |
| C3 | "Tell me about helping someone get an escalation right." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F8, with the beats the quote states: you trained new tellers on the escalation script. Answer slot: the JD asks about coaching supervisors. If you have coached a fellow supervisor on an escalation, say what; if not, say so plainly and stay with the tellers | The JD's coaching line. JD because it scores the listed requirement; F8 is the adjacent evidence |
| D1 | "You've not worked in a contact centre. What do you do about that in your first 90 days?" | JD | [grounded] "Never worked in a contact centre" | B1 carried into the manager round, where the question is the plan. Open with "I haven't worked in a contact centre." Then a future-tense plan in your own words: what you would learn first, who you would ask, what you would not change until you had. Say it as a plan, never as a past | F2 is the likeliest objection from the person who would carry the risk of hiring you. JD because it scores a listed requirement |
| D2 | "What's the most senior audience you've presented to?" | JD | [grounded] "I've never presented to anyone above regional level" | Open with the plain acknowledgment: "I haven't presented to anyone above regional level." Answer slot: say, in your own words, what you have presented and to whom, up to regional level; if nothing, say so plainly. Then a future-tense plan for how you would prepare to present to senior leaders | F6 is a stated gap, and your manager would be the one putting you in front of senior leaders. JD because the line is in the JD |
| D3 | "Why this role rather than another step up in a branch?" | EXP | [generic] | Answer slot: give your own reason in your own words, in two or three sentences. The pack supplies none. Keep it about what the role itself contains | A motivation-consistency question from a manager buying a long-term hire. EXP because it is about your own history |
| D4 | "Your background is one branch. What makes you think you can own the process beyond it?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | Hold only what the quotes carry: six years in retail banking, the last three as a branch supervisor, and the branch's formal complaints log. Concede the limit plainly: the log is one branch's. Hold through two follow-ups by returning to the log, never by adding to it. Then say what you would need to learn to extend it | F1's limit is the pack's observation: the material says the log, not the process. JD because it scores the headline requirement |
| E1 | "Sketch how you'd review the complaints process end to end across branches and the contact centre in your first 90 days. What do you need to know first?" | CASE | [generic] | Clarify first: what exists today, who owns each step, where the data lives. Then the objective, in Ashgrove's own words where they fit (Plain Words, Own the Fix). Segment by branch, contact centre and digital. Then approach, metrics and risks. Think aloud, state your hypothesis early, challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's first line, set as a plan. CASE because the hiring-manager prior says expect a live problem |
| E2 | "Suppose complaint numbers at one branch doubled in a month. Diagnose it." | CASE | [generic] | Clarify first: what counts as a complaint, whether recording changed, which channels, which types. Segment by type, channel, time and branch. Order your hypotheses, say what you would do this week, and say what you would tell the Head of Member Services and when. The question is hypothetical, so the guidance makes no claim about your past | The JD's monthly reporting line, as a diagnosis. CASE because a manager tests structure before answers |
| E3 | "What would you put on the page of a monthly complaints report for the leadership team?" | CASE | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Structure: who reads it and what decision it supports, what you would count, what is getting stuck or ageing, what needs a decision, one line in plain words. Answer slot: say what your own spreadsheet showed, in your own words; if you are unsure, say so plainly | The JD's reporting line, F3 and F7. CASE because it is a design problem; the quote is the nearest evidence |
| F1 | "Walk me through the monthly complaints spreadsheet. What did it show, and who relied on it?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3 with the beats the quote states: you built it, it was monthly, your regional manager uses it. Answer slot: say what it counted and how, in your own words; if you cannot say exactly how something was counted, say so plainly, and name the assumption you would defend least before they do | F3 and F7 are the evidence for the reporting line, with nothing inspected behind it. EXP because it tests what was actually yours |
| F2 | "What's the most involved thing you've built in Excel?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the most involved thing was, in your own words and only as it was. If the monthly spreadsheet is it, say so plainly. Say which software it was built in only if that is true | F7's quote says spreadsheet, not Excel. JD because the JD asks for Excel reporting |

### Reverse questions (round 2)

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What is working in the complaints process today, and what would you most want changed in the first six months?" | Lets you hear the manager's own priorities before you commit to a view |
| R2-2 | "How do complaints figures reach senior leaders today, and what would you want from the monthly report?" | Ties to the JD's reporting line and shows you think about the audience |
| R2-3 | "With eight branches consolidating into five hubs over 2027, how do you expect complaint handling to change?" | Grounded in the strategy brief as you summarised it; signals you read it at the company's altitude |
| R2-4 | "How is complaints readiness being planned for the small-business lending launch in Q1 2027?" | A grounded strategy question that points at a new product line; it shows you thinking ahead |
| R2-5 | "What support would a new lead get in presenting to senior leaders in the first few months?" | An honest question that matches the plan you would give in D2 |

## Round 3: the panel of two branch managers (60 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Stories scored against the four values by name | High. The recruiter says the panel is the values round and scores against the four values | A story per value where one of your sentences carries it, a scaffold with its honest branch where none does |
| Case/Strategist | The 20-minute complaint-escalation case | High. Twenty of the sixty minutes is a case | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Peer Evaluator | "What would you need from me" | Medium. Branch managers are the people whose supervisors you would coach, so seam and credit questions are likely | Reciprocity framing; seam principles rather than pretending to know their seam |
| Skeptic | The contact-centre gap in a branch voice | Low. A third pass at F2, but the panel's weight sits elsewhere | The same plain acknowledgment as B1 |

Panel member names are unknown, so the weights blend the top two personas of the relationship the recruiter described, and the interviewer read is absent.

### Bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [generic] "I handled the branch's formal complaints log" | Selection scaffold for Members First, Always: pick a decision with a named member need, what the usual path did not give them, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is that you handled the branch's formal complaints log, or how you would handle it | The published value by name; the open prompt's theme comes from the value's own words. VAL because it scores the value; no quote carries a decision story, so this is a scaffold |
| G2 | "Tell me about a time you made something easier to understand for a member or a colleague." | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped for Plain Words, on F8's beats: you trained new tellers on the escalation script. Answer slot: if you ever reworded any of the script, or what members were told, say what and why, in your own words; if you taught it as written, say so plainly and stay with the training | The published Plain Words value. VAL because it scores the value; F8 is the nearest evidence |
| G3 | "Tell me about a time you thought about what a branch means to its town." | VAL | [generic] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold for Neighbours, Not Numbers: pick a moment tied to a named member or a local event, and say what you did about it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is the last three years as a branch supervisor, or how you would handle it | The published value by name. The panel are branch managers, and the strategy brief names eight branches becoming five hubs, so this value may carry weight. VAL because it scores the value |
| G4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Use the same story as C2, scored here against Own the Fix by name. Beats are only what the quote states: you handled the branch's formal complaints log. Answer slot: if you followed one complaint from the log to its resolution, say how and what was yours; if the log was where your part ended, say so plainly and stay with the log | The published value, repeated from round 2 for the values scoring. F1 is the evidence |
| H1 | "A member was told by a branch that their complaint was logged. Three weeks later the contact centre has no record of it, and they're at the counter, upset. What do you do, and what do you change afterwards?" | CASE | [generic] | The 20-minute shape. Clarify first: what exactly was logged where, what the member was told, what they want now. Then the objective: one named owner for this member's problem (Own the Fix), and a plain explanation said once (Plain Words). Immediate action, then root cause: why the record did not travel. Then what you change and how you would measure it. Name risks, including any deadline the complaint is running against. Think aloud, state your hypothesis early, challenge one premise. The question is a live problem and makes no claim about your past | The recruiter's email puts a complaint-escalation case in the panel round, so this is the top item for round 3. CASE because it is a live problem |
| H2 | "Now the supervisor who took the complaint says it isn't their fault. How do you handle that conversation?" | CASE | [generic] | Facts first. Separate the fix for the member from the learning for the supervisor. Say what you would ask, what you would agree, and what you would record. The guidance makes no claim about your past | The likely follow-up to H1, and the JD's coaching line. CASE because it is a live problem; F8 is why it needs preparation |
| H3 | "A member raises a complaint inside the app. Where should it go, and who owns it?" | CASE | [grounded] | Clarify first, then the objective: the member should not have to repeat themselves. Name one owner, the handoff to the contact centre or a branch, and how you would measure it. Offer a thesis with its concession: self-service has to leave room for a human, which is the Neighbours, Not Numbers tension, and you have not worked on a digital journey, so say you would ask the digital team. Your material does not show digital-team work, so the guidance makes no claim about your past | The strategy brief's 40% digital target and the JD's digital line. CASE because it is a live problem; F9 is the gap to hold to analysis |
| H4 | "Imagine a member's branch is being merged into a hub and they come to complain about it. What do you do?" | CASE | [grounded] | Listen first and acknowledge what the branch meant to them. Separate what you can fix from what is already decided, and do not take a position on the decision itself. Say what you would pass back to whoever owns the plan. The panel are branch managers, so this lands close to home. The guidance makes no claim about your past | The strategy brief's consolidation of eight branches into five hubs. CASE because it is a live problem scored against Neighbours, Not Numbers |
| J1 | "Our branches sit beside your role. When you and a branch manager disagree about how an escalation should go, where's the seam?" | JD | [generic] | Propose seam principles rather than pretending to know their seam: the member has one owner, the branch keeps the relationship, the lead owns the process and the data. Frame it as what you bring them, not only what you need. If asked for an example of a disagreement, give a real one in your own words; if none comes to mind, say so plainly and say how you would go about it | The Peer Evaluator's seam stem, and the JD's coaching line. JD because it scores partnership in the listed job |
| J2 | "How do you handle credit and blame when a complaint spans a branch and the contact centre?" | VAL | [generic] | Principles, not a past: the member's fix first, the learning shared, credit named for whoever did the work. If asked for an example, give a real one in your own words; if none comes to mind, say so plainly and say how you would handle it | The Peer Evaluator's credit stem, set at the branch-and-contact-centre boundary the JD names. VAL because it scores how you treat colleagues |
| K1 | "You've not worked in a contact centre. How would you earn their trust, and ours?" | JD | [grounded] "Never worked in a contact centre" | The B1 answer, short: "I haven't worked in a contact centre." Then a future-tense plan, plus what you would ask of branch managers in return. Never a claim to contact-centre work | F2 once more, in a branch voice. JD because it scores a listed requirement |
| K2 | "How would you coach a supervisor who has been doing this longer than you?" | JD | [generic] "trained new tellers on our escalation script"; "6 years in retail banking, the last 3 as a branch supervisor" | A method, not a past: ask first how they handle it now, share one observation, agree one change. Your own material carries training new tellers on the script, and the last three years as a branch supervisor, at those scopes. If you have coached a fellow supervisor, say what; if not, say so plainly and stay with the tellers | The JD's coaching line from a panel of branch managers. JD because it scores the listed requirement; F8 is the adjacent evidence |

### Values / principles cheat sheet

Ashgrove's four published values, by official name, as you copied them from ashgrovecu.org/about/values on 24 November 2026.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quote of yours carries a decision story. Selection scaffold in G1, ending in its honest branch |
| Plain Words | If a member needs it explained twice, it was written wrong | F8: "trained new tellers on our escalation script". Answer slot in G2 |
| Neighbours, Not Numbers | Every branch is part of its town | No quote carries a story about a town. Selection scaffold in G3, ending in its honest branch |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log". Answer slot in C2 and G4 |

### Reverse questions (round 3)

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "How do you hear about complaints that start in the contact centre, and what would make that better?" | Shows you are thinking about the branch-to-contact-centre seam from their side |
| R3-2 | "When a complaint escalates to you, what would you need from me, and what would make me worth escalating to?" | A reciprocity question for peers who will work with you |
| R3-3 | "As branches consolidate into hubs, what do you most want to protect about how your branch handles members' complaints?" | Grounded in the brief; shows you take Neighbours, Not Numbers seriously |
| R3-4 | "Where do your supervisors most often get stuck on an escalation?" | Hands you the real coaching target and ties to the JD's coaching line |
| R3-5 | "What would you want to see from me in the first 60 days that tells you the role is helping your branch?" | Signals you measure yourself by their branch's experience |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | A1, A2, B1, B2, C2, D1, D4, E1, G4, H1, H2, K1 |
| "report monthly on complaint volumes and resolution times" | E2, E3, F1 |
| "coach branch supervisors on escalations" | C3, H2, J1, K2 |
| "work with digital teams on self-service journeys" | A3, B4, H3 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | B3 |
| "confident presenting to senior leaders" | B2, C1, D2 |
| "comfortable with Excel reporting" | E3, F1, F2 |

## Sources

Provided documents: the JD, the four published values as copied from ashgrovecu.org/about/values on 24 November 2026, the recruiter's email on the process, your summary of the July 2026 strategy brief, and your background, all from your message. No dossier was present. The brief itself was not supplied.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the cheat sheet: the values text you pasted already supplies the four value names and definitions |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights: the recruiter's email already fixes the three rounds, who runs each and how long each lasts |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO bank: your summary of the strategy brief already supplies the four points |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names are assigned yet, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or a redacted extract of the monthly spreadsheet or the complaints log → F1, F3, F4 and F7 could move from `medium` toward `high`, and more of the banks become story-mapped
- What you have presented at regional level, and to whom → F6 and the D2 slot
- Any work with a digital or product team, or on a self-service channel → F9, B4 and H3
- Whether anything about how the complaints log was kept was set outside the branch → F4 and B3
- The strategy brief's text → A3, H3 and H4 would rest on quoted lines rather than your summary
- The interviewers' names, once assigned → an interviewer read, tuned persona weights and a reverse question tied to their own path
- A line from the recruiter on whether the round-3 case arrives on paper or is spoken, and which sites the role covers → H1 and A6
- A `tuesday-dossier.md` → verified evidence and constraints would replace the inferred objection with an evidence-derived one
