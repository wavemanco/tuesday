Web search was denied, so I'm building the pack from your dossier alone, with company research marked unavailable. Saving it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-4-denied-2089adbb/Quartzline_product-manager-platform-apis_interview_pack.md`. It has 20 questions across six personas, built for a hiring-manager round.

I built it from your dossier alone. All three web searches were denied (Quartzline's values, interview process and strategy), so nothing in it comes from outside your documents. The only company-specific question, D3 ("where is our platform headed"), is labeled generic, and the pack has no values sheet. The Sources section lists each refused search.

The highest-ROI prep is A1, the objection your dossier names: "You have never held the PM title or owned a roadmap…". The pack has you concede both facts in the dossier's own words, then bridge from your integration-leadership quotes with the limit stated up front. It keeps the roadmap-input sessions out of that answer, because the dossier marks roadmap ownership as a gap to acknowledge, not bridge. The pack's prohibited-claims section lists every claim it won't coach.

Say the word and I'll play the Skeptic on A1 for a live drill.
I can also save a `tuesday-dossier.md` that records what this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Role:** Product Manager, Platform APIs, Quartzline
- **Interviewer:** name not given. Relationship: the hiring manager
- **Session:** one 45-minute conversation, Thursday (your message)
- **Built from:** your `tuesday-dossier.md` (job-underwriter, dated 2026-08-14). Web research was not available for this pack; see Sources

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Every question row carries one label in its Provenance column: `[grounded]` rests on your quoted material or a dossier field, `[inferred]` is a derivation, `[generic]` is a pattern with no claim about you or Quartzline. An "answer slot" is an instruction for the interview, not a question to me: answer it from your own experience, or say plainly that the practice was not yours.

Question IDs run A, B, C, D, E, G (no F, so they never collide with fit-snapshot rows F1 to F6).

| Tag | Name | What it is scoring |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values. Not used here: no values round and no published values were in hand |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role, live |

## Prep triage (two days: Tuesday and Wednesday)

1. **Tuesday:** say A1 aloud until the two concessions and the quoted bridge are boring. A1 is the highest-ROI prep in this pack.
2. **Tuesday:** E1, the sixty-second version of A1.
3. **Tuesday:** B3 aloud, starting with the authority question.
4. **Wednesday:** C1 and E2: defend the 30+ number and your share of it.
5. **Wednesday:** D1, a 90-second arc built only from your three quoted sentences.
6. **Wednesday:** read B1 and B2 for structure, then pick two reverse questions from section 6 to ask.

Everything else is insurance.

## 1. Fit snapshot

Evidence cells hold only your own sentences, from the dossier's `handoff_to_mock_interview.verified_candidate_evidence` (cited as dossier handoff 1, 2, 3 in the order the dossier lists them). The dossier attaches confidence notes to each entry; those sit in the Confidence column, not in the quotes. Grading follows the dossier's `uncertain_or_weak_areas` where it speaks. No row is a hard gate: the dossier lists none, and "3+ years" is an experience requirement, not a term you meet or miss.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff 1; "Wrote the internal integration playbook her team uses" — dossier handoff 2 | low | [grounded] | transferability | Dossier strategy is `bridge`, positioned as adjacent and never as product management experience. The material shows integration leadership and a playbook, not the title or role. Words, per `prohibited_claims`: "Having held a product manager title or role" — "I haven't held a product manager title or role." Then the quotes at their own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Add no slot here: a slot asking whether you did product work would imply the claim the dossier prohibits |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities, and the R1 sub-claim in `uncertain_or_weak_areas` | none given | none | [grounded] | capability | Dossier strategy is `acknowledge_gap`: no bridge. Words, per `prohibited_claims`: "Having owned a product roadmap" — "I haven't owned a product roadmap." And per `prohibited_claims`: "Having set prioritization for an engineering squad" — "I haven't set prioritization for an engineering squad." Then a ramp plan, said as a plan and never a past: ask which roadmap decisions are yours alone and which belong to the squad leads, and ask how adoption is measured today. The roadmap-input sessions in F5 stay out of this answer |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff 1 | high | [grounded] | transferability | The dossier lists R2 as a high-priority requirement but not as a weak area, so this grading is the pack's own. Your material says you led client integrations of the vendor's REST APIs, not that you shipped an API or platform product, and the words stay at the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: expect a probe on what went live at the end of those integrations. If you can say what went live and which part of it was yours, say so in your own words; if there was nothing beyond the integration itself, or the go-live was not yours, say so plainly and stay with the integrations you led |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff 1; "Wrote the internal integration playbook her team uses" — dossier handoff 2 | high | [grounded] | discovery | Both quotes touch the requirement, and neither says docs or schemas, so the pack cannot tell whether you worked with them. Say the quotes at their scope. Answer slot: the JD names API docs and schemas, so expect a probe on them. If you worked with them in these integrations or in the playbook, say which and how, in your own words; if you did not, or not in that form, say so plainly and stay with what the quotes state |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff 1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff 3 | medium | [grounded] | transferability | Handoff 3 is confirmed with limited inspectable proof, so expect a probe on it and say plainly what you can and cannot show. Your quotes name clients and product; they do not name engineering or sales as stakeholders, and the JD's word "customers" is not your word "clients", so keep your own. The sessions were input to product: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: the JD names engineering and sales, so expect a probe on working with them. If you did, say how, in your own words; if not, or not in that form, say so plainly and stay with the client integrations and the sessions |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | Dossier strategy is `clarify`. No quote speaks to this requirement itself, so nothing about your past goes in the answer. Answer slot: the JD's wording makes a probe on it likely. If you worked that way, say how, in your own words; if you did not, or not inside a product organisation, say so plainly, and say what you would want to confirm about how Quartzline's squads define it |

## 2. Persona table

Weights rest on the hiring-manager relationship prior (Case/Strategist and Skeptic dominate), adjusted by the dossier, which names one objection that makes the Skeptic bank the deepest. The loop is the one session you described; no outside loop source was available, so nothing beyond the relationship prior and the dossier moves the weights.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title gap, the roadmap gap, and why this move | High: hiring-manager prior, plus the dossier's named objection (F1, F2) | Rehearse A1 until it is boring; bridges only from F1's quotes; concessions in the dossier's own words |
| Case/Strategist | Live problems from the role: breakage, adoption, prioritization, partner requests | High: hiring-manager prior; the role's listed work is roadmap, discovery, specs and adoption metrics | B1 to B5: clarify, then structure, then answer; challenge one premise respectfully per case |
| Data-Driven Prober | Reads your lines closely: counts, docs, the playbook | Medium: your sentences carry a count (30+) and an artifact (the playbook), both easy to probe | C1 to C3: say how the count was made, or say plainly you do not know |
| Conversational / Rapport Builder | Friendly opener, then casual questions that are still scored | Medium: a 45-minute manager conversation usually opens this way | D1 to D3: a 90-second arc built only from your three quotes |
| Pressure | Time-boxes, interrupts, tests composure on the objection | Low: possible in a manager round, not the prior | E1, E2: pause, restate, hold the quote, concede specifically |
| Peer Evaluator | Seam-splitting between you and the squad leads | Low: the interviewer is the hiring manager, but the squads are the role's daily partners | G1, G2: seam principles, not a pretended seam |
| Values/Behavioral | Scenario probes against published values | Not banked: no values-style round was detected, and no published Quartzline values were in hand | None; upgrade menu says what would change this |

## 3. Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; `prohibited_claims`: "Having held a product manager title or role"; `prohibited_claims`: "Having owned a product roadmap"; `prohibited_claims`: "Having set prioritization for an engineering squad" | The highest-ROI rehearsal in this pack, named by the underwriter, so rehearse it deepest. Concede the facts first, in the dossier's words: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then the bridge, with its limit named before it is asked for: "What I have done is lead 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live — and write the internal integration playbook my team uses." Say it as adjacent work, never as the same job. Close with a ramp plan, said as a plan: you would want to learn which roadmap decisions are yours and which belong to the squad leads, and how adoption is measured today. Follow-up one, "leading integrations is not owning a roadmap": agree, repeat the plain acknowledgment, return to the quotes. Follow-up two, "a PM with three years has already set priorities for a squad": concede per `prohibited_claims`: "I haven't set prioritization for an engineering squad." Return to the quotes. Do not say the integrations prove you can do the job; describe what you did and let them draw the inference | The wording is the underwriter's, kept because both negatives in it carry a dossier source. F1 and F2 are where the posting presses hardest, so some form of this arrives. JD because it scores R1 |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `prohibited_claims`: "Having owned a product roadmap" | Name the roadmap, and say it plainly: "I haven't owned a product roadmap." Then the ramp plan from A1: ask which decisions are yours alone and which belong to the squad leads, and ask how adoption is measured today. Do not offer the sessions in F5 as a bridge here. If the interviewer pushes on a second area, the dossier marks agile delivery as unestablished: use A4's slot | F2 is the dossier's acknowledged gap, so it is the honest answer to a weakest-area probe. JD because the question scores the listed work, with a Skeptic delivery |
| A3 | "Have you shipped an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3: say what the quote says, in your own words: you led client integrations of the vendor's REST APIs, from scoping through go-live. Do not answer yes or no to the question as asked; answer from the quote. Answer slot: expect a follow-up on what went live at the end of those integrations. If you can say what went live and which part of it was yours, say so in your own words; if there was nothing beyond the integration itself, or the go-live was not yours, say so plainly and stay with the integrations you led | R2 is a must-have, and F3 is adjacent evidence for it. JD because it scores the stated requirement directly |
| A4 | "Tell me about a time you worked in an agile delivery setup." | JD | [generic] | Dossier strategy for this area is `clarify`, and no quoted sentence speaks to it, so this is a selection scaffold. Pick a time your delivery work ran in a rhythm you can describe: it needs the team, the cadence, and your part. If no such time comes to mind, say so plainly, then say what you would want to confirm about how Quartzline's squads define it, and how you would handle it | F6 is a discovery gap, so the honest preparation is a ready, calm answer in both directions. JD because R5 is the source, though preferred rather than required |
| A5 | "Why this move, and why now?" | CO | [generic] | The pack holds none of your reasons and supplies none. Prepare your own answer in your own words: why product, why this platform, why now. Keep it to what is true for you, and keep it consistent with A1's ramp plan | The Skeptic's why-here-why-now probe tests motivation consistency. CO because it is partly about the company, and `[generic]` because research was unavailable |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner reports that their integration broke after an API release. What do you do first, and who do you pull in?" | CASE | [generic] | Clarify before structuring: what broke, for whom, how severe, and since when. Then objective, who is affected, approach, communication to partners, and the risk of a repeat. Think aloud and name one assumption you are making. The question needs no claim about your past, so the guidance makes none | A live problem on the platform's daily reality. CASE because it scores structure; the role's squads and partners are in the JD |
| B2 | "Adoption of a new partner endpoint has flattened. Diagnose it — what do you need to know first?" | CASE | [generic] | Your first clarifying question is the honest one: how adoption is measured today and what the baseline is. The dossier lists exactly that as unresolved, so asking is diagnosis, not a dodge. Then segment (who started, who stalled, where), form hypotheses, say how you would test each, and state what you would do with each answer | The role lists adoption metrics as a responsibility, and no baseline is stated. CASE because it asks about no past |
| B3 | "We have two squads and one quarter. How would you decide what the API platform builds first?" | CASE | [generic] | Start by asking which of these decisions are yours alone and which belong to the squad leads. Then think aloud: the objective, what partner evidence says, the effort each squad would carry, what you would not build, and who decides. Challenge one premise respectfully, for example the one-quarter horizon. Make no claim to having prioritized before: the question needs none, and `prohibited_claims`: "Having set prioritization for an engineering squad" is on the list | F2 is the area where the posting and the dossier diverge most, and a case is where it is tested live. CASE because it scores reasoning, not history |
| B4 | "Sketch how you would run discovery with integration partners in your first ninety days." | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Structure first: who you would talk to, what you would need to learn, how you would turn it into something a squad can use, and what you would not yet decide. Only if asked what you have done that resembles it: "I ran quarterly roadmap-input sessions feeding client evidence to product." Handoff 3 is confirmed with limited inspectable proof, so volunteer what you can and cannot show before you are asked. Say input, never roadmap decisions | The JD lists partner discovery as a responsibility, and F5 is the only quote near it. CASE because the question is forward-looking |
| B5 | "A large partner wants a custom field and the squad leads say it is a distraction. Walk me through it." | CASE | [generic] | Clarify who decides, then what the partner needs and why, what the squads would give up, the options (build, defer, offer a workaround), and who you would bring evidence to. Say how you would keep the relationship with the squad leads whichever way it goes. Do not claim authority you have not been given: ask where it sits | R4 is stakeholder management across engineering, sales and customers, and F5 is its transferability row. CASE because it is a live conflict |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say you led 30+ end-to-end client integrations — how was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Four slots, each in your own words. How it was counted. What the figure is sensitive to. The assumption behind it you would defend least. Which part was yours. "I don't know how it was counted" is an honest branch. Keep "led" at its own scope and "end-to-end" to the stages the quote lists | The headline figure is the first thing a prober tests, and F3 and F1 rest on it. EXP because it scores attribution |
| C2 | "Tell me about a time you worked with API documentation or schemas." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Story-mapped on F4: the integrations and the playbook, at the quotes' own scope. Answer slot: the JD names docs and schemas, so expect a probe on them. If you worked with them in these integrations or in the playbook, say which and how, in your own words; if you did not, or not in that form, say so plainly and stay with what the quotes state. Do not call the playbook API documentation unless it is | R3 is important rather than must-have, and F4 is a discovery gap. JD because it scores the stated requirement |
| C3 | "Walk me through the integration playbook you wrote — what does it cover?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Story-mapped on F1 and F4: you wrote it, and your team uses it. What it contains comes from the document itself, which the underwriter inspected; describe it from the document and add nothing the document does not say. If asked how you know it works, say only what you actually know | The playbook is the most inspectable thing in your material, so a prober goes there. EXP because it scores what you actually produced |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, one per quote, in your own words. The dossier gives no dates or order, so none are supplied; order the beats by what you want remembered. End with your reason for moving toward product, in your own words; the pack holds none. Handoff 3 is confirmed with limited inspectable proof: volunteer what you can and cannot show. Say input, never roadmap decisions | The opening question is the one every manager asks. EXP because it is the CV arc |
| D2 | "What are you actually playing with in APIs these days?" | JD | [generic] | A selection scaffold: name something you actually looked at and why. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, which is the integrations at the scope the quote states, or say how you would go about it | Casual questions about hot JD topics are scored. JD because R3 is the source |
| D3 | "What do you know about where our partner API platform is headed?" | CO | [generic] | Web research was not available, so the pack holds no facts about Quartzline's direction. Say only what you have read on Quartzline's own public pages yourself. If you have not, say so plainly and turn it into a question about how adoption is measured today and what the roadmap's biggest open questions are. Never recite from memory | The one CO item the pack can honestly carry. `[generic]` because it cannot be grounded without research |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; `prohibited_claims`: "Having held a product manager title or role"; `prohibited_claims`: "Having owned a product roadmap" | Pause, restate, then answer. Concede first per `prohibited_claims`: "I haven't held a product manager title or role." Then the quote at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Then stop. Hold through two follow-ups by returning to the quote; when pushed, concede specifically per `prohibited_claims`: "I haven't owned a product roadmap." Do not say you are the better candidate: the question invites it | The time-boxed form of A1. JD because it scores R1; pressure is the delivery |
| E2 | "Of those 30+ integrations, how much was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Hold on what the quote says: you led them. Answer slot: if parts were done by others, say which and by whom; if you do not know the split, say so; if you carried all of it, say so plainly. Never move "led" to "did" or to "built" | The attribution probe exists to catch inflation, so rehearse the plain version. EXP because it scores what was yours |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our two squads sit on either side of this platform. Where is the seam between you and them, and what happens when we disagree?" | JD | [grounded] `prohibited_claims`: "Having set prioritization for an engineering squad" | Offer seam principles, not a pretended seam: who owns what outcome, who owns what decision, how disagreements escalate. Ask which decisions the PM makes alone, which is the dossier's own open question. Say what you would bring them (partner evidence) rather than only what you need. Per `prohibited_claims`: "I haven't set prioritization for an engineering squad." Say it if the question reaches it | The dossier flags decision authority against the squad leads as unevidenced. JD because R4 and the two-squad responsibility are the source |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | A selection scaffold: pick a time work crossed teams and credit could have blurred; it needs who did what and how you named it. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the integrations at the quote's scope, or say how you would handle it | A standard peer probe on partnership style. `[generic]` because no quote carries a cross-team story |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years product management experience | A1, A2, E1 |
| R1 sub-claim: roadmap and prioritization authority | A1, A2, B3, G1 |
| R2: Shipped API or platform products | A3, C1 |
| R3: Technical fluency: API docs, schemas | C2, D2 |
| R4: Stakeholder management across engineering, sales, customers | B5, G1, G2 |
| R5: Agile delivery experience | A4 |
| Responsibilities: partner discovery, specs and delivery with two squads, adoption metrics | B4, B3 and B5, B2 |

## 4. Reverse questions

At least five, each with why it lands. The first two come from the dossier's `questions_for_employer` and `opportunity_risks_to_validate`. No interviewer profile exists, so none ties to the interviewer's own path.

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's risk is that decision authority is asserted but not evidenced. The answer also tells you whether F2's gap is the one that matters |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's risk is that adoption metrics are a named responsibility with no baseline stated. It is also the honest first clarifier in B2 |
| 3 | "What would a strong first ninety days look like here, and how would you tell?" | Turns A1's ramp plan into the interviewer's own success criteria |
| 4 | "What does partner feedback on the platform look like today, and where does it land in the roadmap?" | Shows interest in discovery and tells you how much of the role is input versus decision |
| 5 | "How are the two squads' areas divided, and where do they meet?" | Prepares G1: the seam is the thing you will be negotiating |
| 6 | "Is there anything about my background that gives you pause for this role?" | Invites the objection you have rehearsed in A1, so you can answer it live instead of leaving it unspoken |

## 5. Prohibited claims

Built before the banks, so the banks are written against it. The first three come from the dossier's `prohibited_claims` and bind every cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | "I haven't held a product manager title or role." Then F1's quotes at their own scope |
| Having owned a product roadmap | Dossier `prohibited_claims`, and the R1 sub-claim marked `acknowledge_gap` | "I haven't owned a product roadmap." No bridge; the sessions in F5 are not offered here |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | "I haven't set prioritization for an engineering squad." |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says leading client integrations, not shipping a product. A3's slot stays inside the integrations |
| Wrote specs for engineering squads | Inflated form of F3: the quote lists "requirements" as a stage, nothing more | F3's quote at its own scope. The material does not say who the requirements were for or whether they were specs |
| Shaped or decided what went on the roadmap | Inflated form of F5's third quote | The quote at its own scope: roadmap-input sessions feeding client evidence to product. The material says input, not decisions |
| Ran discovery with integration partners | Inflated form of F5's third quote, in the JD's vocabulary | The quote at its own scope, in your own word "client", not the JD's "partner" |

## 6. Sources

**Provided documents.** `tuesday-dossier.md`, dossier_version 1.1, generated by job-underwriter on 2026-08-14, about three months before this pack, so the employer-side unknowns may have moved. Sections supplied: `role_profile` (requirements R1 to R5, used as the JD's lines; its responsibilities are used for rows and live problems only) and `handoff_to_mock_interview` (verified evidence, weak areas and strategies, the objection, risks, employer questions, prohibited claims). `decision` was read for context only. Absent from the dossier, so not used: `evidence_map`, `risk_register`, `evidence_state`, `candidate_constraints`. Dossier handoff 1, 2, 3 are the three `verified_candidate_evidence` entries in the order the dossier lists them. Round type and relationship come from your message.

**Searches sent.** All three were refused, so nothing from outside your documents is in this pack.

- `Quartzline company values`: refused
- `Quartzline interview process product manager`: refused
- `Quartzline API platform strategy news`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Would have fed a values cheat sheet if a values round existed. None was detected, so it would have moved nothing here unless the loop turned out to include one |
| 2. `Quartzline interview process product manager` | unavailable | Would have named the loop's rounds and could have reweighted personas. The persona weights rest on the hiring-manager prior instead |
| 3. `Quartzline strategy` / recent news | unavailable | Would have grounded D3 and the CO bank. D3 is `[generic]` for that reason |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative Product Manager JD | skipped | The dossier's `role_profile` supplies the requirement lines, which fix the fit snapshot and the JD-tagged questions |

## 7. Upgrade menu

- Web search access for this session, then I can re-run targets 1 to 3 (values, loop structure, strategy). That would ground D3 and any CO question, and show whether a values round exists. A deeper research pass is also possible: up to 6 more searches and 2 more fetches, several more minutes
- The interviewer's name → a tailored reverse question, an interviewer read, and persona weights from their public footprint
- The recruiter's prep email → coverage of stated focus areas and any pre-declared deliverable
- Anything inspectable from the quarterly roadmap-input sessions (an agenda, notes, or the readout sent to product) → raises handoff 3 from medium confidence and upgrades F5 and B4
- Your raw CV behind the confirmed claims → exact CV sentences for the evidence cells, replacing the dossier's restatements
- Your answers to the answer slots in F3, F4, F5 and F6 (stated outside a drill) → those rows and A3, A4, C2 upgrade from slots to quoted material
- The actual Quartzline JD text → any requirement line the dossier's `role_profile` paraphrases becomes a verbatim quote
