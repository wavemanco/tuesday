I've saved the pack and I'm presenting it now.

Your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. I built it in loop mode, with one mini-pack for each of the three rounds on 3 December and a shared fit snapshot. It uses the background summary in your message, not a CV, and no interviewer names, since none are assigned yet. All research came from the documents you gave me, so I ran no searches. The pack names D1 (the contact-centre objection, rehearsed with the manager) as the highest-value prep.

Say the word and I'll play the Skeptic on D1, or run the round 3 escalation case as the panel.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Would you paste your CV, or just its experience section? Several fit rows rest on one or two sentences of your message, and a CV could turn those answer slots into real stories.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop: three rounds on 3 December 2026. Round 1 is the recruiter, round 2 the Head of Member Services (your would-be manager), round 3 a panel of two branch managers. No interviewer names are assigned yet, so there is no interviewer read.

## How to use this pack

- Personas describe how a question is asked. Types describe what is being scored.
- Guidance is scaffolding, not a script. Every sentence of yours in it is quoted from what you told me; rehearse only what you actually did, in your own words.
- An answer slot is an instruction for the interview, not a question for you now. It gives two honest branches; either one is a good answer.
- Proposed answer wording in every bank below is pending your approval.
- Question IDs run by persona: A and B in round 1, C to E in round 2, F to I in round 3.

| Tag | Name | What it is testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the published values, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny; what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Homework depth; thinking at Ashgrove's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## The loop at a glance

| Round | Length | Who | What the recruiter said about it | Provenance |
|---|---|---|---|---|
| 1 | 30 minutes | The recruiter | "30 minutes with me" | [grounded] recruiter's email |
| 2 | 45 minutes | Head of Member Services | "who would be your manager, mostly behavioural" | [grounded] recruiter's email |
| 3 | 60 minutes | Panel of two branch managers | "including a 20-minute case on a complaint escalation. The panel is also the values round — they score against the four values." | [grounded] recruiter's email |

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's formal log and the script training, not the process end to end, with nothing inspected behind it, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on how far a complaint went beyond the log likely. If any step past the log was yours, say which and what you did, in your own words; if the log was your part, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your sentence shows a monthly complaints spreadsheet your regional manager uses, not what it counted. Words at that scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it counted how many complaints came in or how long they took to resolve, say how each was counted; if it counted something else, say so plainly and say what it did count |
| F4 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your sentence says spreadsheet and does not name Excel, so the pack does not either. Words at scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it was built in Excel, say so; if it was another tool, say which and describe the work in your own words |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | The quote already speaks the JD's terms of years and sector. Lead with it as written: "6 years in retail banking, the last 3 as a branch supervisor." A CV line alone has nothing inspected behind it, so expect a probe on what the branch work covered |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | Your word is formal, the JD's word is regulated, and the bridge does not turn one into the other. Answer slot: if the complaints in that log came under external rules, say which rules and what you did under them; if they did not, or that was not yours, say so plainly and stay with the log you handled |
| F7 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said it plainly. Words: "I've never presented to anyone above regional level." Your sentence does not say you have presented at regional level either, so the pack does not. Then how you would prepare, as a plan and never as a past |
| F8 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says tellers, not supervisors, and the bridge does not swap one for the other. Words at scope: "I trained new tellers on our escalation script." Answer slot: if there was more to the training than the script, say what it was, in your own words; if not, say so plainly and stay with the script |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Nothing in your material speaks to it, so the words are an answer slot: if you have worked with a digital team or on a self-service change, say what and what your part was, in your own words; if not, say so plainly and answer E2 as a live problem |

No headline metric appears in your material, so the pack has no defend-the-number question.

### Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| Own the complaints process end to end across branches and the contact centre | B2, D1, G1, I1 |
| Report monthly on complaint volumes and resolution times | D3, D4, E1 |
| Coach branch supervisors on escalations | C3, G2, H1 |
| Work with digital teams on self-service journeys | E2, G3 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B1 |
| Confident presenting to senior leaders | D2 |
| Comfortable with Excel reporting | D3, D4 |
| Pay, notice, location and the reason for leaving (recruiter logistics) | A3, A4, A5, A6 |

## Grounding brief: Ashgrove's July 2026 strategy

| Item | What the brief says | Provenance | Surfaces in |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] 2026 strategy brief, July 2026 | A2, E2, R2 reverse questions |
| Branch consolidation | Consolidate eight branches into five hubs over 2027 | [grounded] 2026 strategy brief, July 2026 | A2, F3, G3, R3 reverse questions |
| New product | Launch a small-business lending product in Q1 2027 | [grounded] 2026 strategy brief, July 2026 | A2 |
| Competitive pressure | The main competitive pressure is app-only banks | [grounded] 2026 strategy brief, July 2026 | A2, E2 |
| Organisation | Member-owned, about 900 staff | [grounded] the JD | A2 |

---

# Round 1: the recruiter (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; opener, motivation, logistics | High: the relationship prior for a recruiter screen is Conversational plus a light Skeptic, and the recruiter's email makes round 1 a 30-minute conversation | Pre-script a 90-second arc; treat casual questions as scored; ask real reverse questions |
| Skeptic (light) | Quiet knockout checks on the gaps and on why you are moving | Medium: the prior is a light Skeptic, and F2 and F7 are gaps a screen would check; nothing in the email suggests it goes deeper | Rehearse the plain acknowledgment of each stated gap, then a plan |

### Question bank

Proposed answer wording below is pending your approval.

**A. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc using only the beats these sentences state, in your own words and in this order: six years in retail banking; the last three as a branch supervisor; the complaints log and the escalation-script training; the monthly complaints spreadsheet. Close with one sentence of your own on why this role — your reason, not one supplied here | F5 and F1 are the spine of the biography, and a recruiter screen opens here. EXP because it tests that the CV story holds together |
| A2 | "What do you know about Ashgrove, and what draws you to a member-owned credit union?" | CO | [grounded] | Choose one or two facts you can state from the documents you hold: member-owned with about 900 staff (the JD); 40% of member service to digital by 2028, eight branches into five hubs over 2027, a small-business lending product in Q1 2027, app-only banks as the main pressure (the July brief). Then one sentence of your own on what draws you, in your words; if nothing specific comes to mind, say so plainly and name the JD line that does | CO because it scores homework. Every fact here comes from a document you provided, which is the safe ground for a first conversation |
| A3 | "Why are you looking to move at the moment?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words, kept to the reason and what you want next. This pack has not been told your reason and does not supply one | Recruiters ask this to test motivation consistency. EXP because the answer is a fact about your own history |
| A4 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period | A logistics check on the job's terms; JD because it scores a term of the listed job |
| A5 | "What are you looking for in terms of salary?" | JD | [generic] | Logistics slot: give your own figure, or ask what the role's band is first; the pack supplies no figure. If asked what you earn now, you can redirect to the role's band | A logistics check on the job's terms; JD for the same reason as A4 |
| A6 | "Where are you based, and does the working pattern for this role work for you?" | JD | [generic] | Logistics slot: state your own location and any limit on where or how often you can work; if you have none, say so | The JD gives no location or pattern, so this is the recruiter's check on a term not yet visible to you |

**B. Skeptic (light)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about your experience with regulated complaints." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say it at scope: "I handled the branch's formal complaints log." Answer slot: the JD asks for regulated complaints, so expect a probe on whether the complaints in that log came under external rules. If they did, say which rules and what you did under them; if they did not, or that was not yours, say so plainly and stay with the log | F6 is a discovery gap: the material does not show whether the log was regulated. JD because it scores a stated requirement |
| B2 | "The role covers the contact centre, and you've said you've never worked in one. How would you approach that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open with the plain acknowledgment: "I've never worked in a contact centre." Then what your material does carry, at scope: "I handled the branch's formal complaints log." Then a plan, said as a plan: your own first steps for learning how that team works. Never present the branch log as the same work | F2 is the stated gap a screen is built to find. JD because the requirement is in the posting |
| B3 | "Which part of this role would be furthest from what you've done?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose from your own material: it shows two stated gaps, and you pick the one you would name first, plainly, then your first step as a plan. Answer slot: if you see a bigger gap than either, say so in your own words | F2 and F7 are the gaps, and naming one before being asked reads as honest self-assessment. JD because it scores fit against the posting |

### Reverse questions: round 1

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would the first three months need to show for this to look like the right hire?" | Makes the recruiter state the success bar, which tells you what rounds 2 and 3 will score |
| 2 | "How do complaints currently move between the branches and the contact centre?" | Shows you are thinking end to end, and gives you a way to learn the part you have not worked in |
| 3 | "The brief says 40% of member service moves to digital by 2028. Where does the complaints process sit in that?" | Ties the role to the strategy you were sent, so you sound current |
| 4 | "Is there anything in my background you would like me to address before I meet the Head of Member Services?" | Brings the likeliest objection out early, while there is still a round to answer it |
| 5 | "What happens after the three rounds, and when would you expect to decide?" | A normal process question that closes the screen cleanly |

---

# Round 2: Head of Member Services (45 minutes, your would-be manager)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes, STAR-shaped stories | High: the email calls the round "mostly behavioural" | Use "we" for context and "I" for contribution; where none of your sentences carries a story, use the selection scaffold and its honest branch |
| Skeptic | Probes the gaps against a manager's hiring risk | High: the prior for a manager is Skeptic plus Case, and F2 and F7 are stated gaps | Rehearse the plain acknowledgment until it is boring; concede the limit exactly; add a plan |
| Case / Strategist | A live problem from the role's own remit | Medium: part of the manager prior, but the email says behavioural comes first | Clarify, objective, segmentation, approach, metrics, risks; think aloud |

### Question bank

Proposed answer wording below is pending your approval.

**C. Values / Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you said the hard thing, and an intact relationship afterward. Your material shows no such moment, so if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral stem for a manager round. Nothing in F1 to F9 carries this story, so it is a scaffold, not a story map |
| C2 | "Tell me about a time you put a member ahead of an internal metric." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a decision where a rule, target or convenience pulled one way and the member the other, with what you chose and how it ended. That sentence shows the log and the training, not a moment like this, so if none comes to mind, say so plainly, then give the nearest thing it does carry: "I handled the branch's formal complaints log." | Customer-over-metric is a persona stem and echoes the first published value. F1 is the nearest evidence and does not carry it |
| C3 | "The role coaches branch supervisors on escalations. What have you done that's closest to that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say it at scope: "I trained new tellers on our escalation script." Your material says tellers, not supervisors. Answer slot: if there was more to the training than the script, say what it was, in your own words; if not, say so plainly and stay with the script | F8 is transferability: adjacent work that does not reach the requirement, so the honest answer states the distance |
| C4 | "That monthly spreadsheet — how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say it at scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if anyone else supplied data, reviewed it or changed it, say who and what; if all of it was yours, say so plainly and stay with what you built | Attribution probes are standard for a CV claim. F3 and F4 rest on this one sentence, so it is the place to be exact |

**D. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You've said you've never worked in a contact centre, and this role owns that process. What makes you the right person for it?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | The highest-ROI rehearsal in this pack. Level 1: "I've never worked in a contact centre." Then at scope: "I handled the branch's formal complaints log." Follow-up 1, expect "what would you do first?": a plan in your own words, said as a plan. Follow-up 2, expect "why should we take that risk?": concede the limit exactly, the gap is real, and do not claim the log is equivalent. Follow-up 3, expect "what support would you need?": name it in your own words. Hold by returning to the stated limit and the log, never by adding to either | F2 is the objection this loop will ask in some form, and a manager is the person it costs most. JD because it scores the stated requirement; the deepest rehearsal is justified because a calm, non-defensive answer changes the round |
| D2 | "You've said you've never presented to anyone above regional level. This role reports monthly to senior leaders. How do you get ready for that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I built the monthly complaints spreadsheet our regional manager uses." | Open with the plain acknowledgment: "I've never presented to anyone above regional level." Then the work you can point to at scope: "I built the monthly complaints spreadsheet our regional manager uses." Then a plan: how you would prepare, in your own words, as a plan. Answer slot: if you have presented at regional level, say what and to whom; if not, say so plainly | F7 is the second stated gap and the one a manager scores directly, since the role reports upward. JD because it scores the posting's own line |
| D3 | "The JD asks for monthly reporting on volumes and resolution times. What did your spreadsheet track?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say it at scope: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it counted how many complaints came in or how long they took to resolve, say how each was counted and which assumption you would defend least; if it counted something else, say so plainly and say what it did count. If it was built in Excel, say so; if another tool, say which | F3 and F4 are discovery gaps: the sentence does not say what was counted or in which tool. JD because it tests the requirement; the weakest-assumption move applies once you name a count |

**E. Case / Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sketch how you would set up monthly complaint reporting across branches and the contact centre. What do you need to know first?" | CASE | [generic] | Clarify first (what counts as a complaint, where each channel's data lives, who reads the report), then the objective, then the cuts you would show, starting from the JD's own terms of volumes and resolution times, then the risks. The question needs no claim about your past, so the guidance makes none | A live problem built from the JD's reporting line. CASE because it scores structure, and the JD's own words give you the vocabulary |
| E2 | "Where would you want digital self-service to take pressure off the complaints process, and what would worry you?" | CASE | [grounded] | Structure it as a live problem: clarify who the members are and which journeys, then where self-service helps and where a member needs a person, then your worries. The brief's 40% digital target by 2028 is the context to name. Answer slot: if you have worked with a digital team or on a self-service change, say what and what your part was; if not, say so plainly and answer as a live problem | F9 is a discovery gap and the JD pairs the role with digital teams, so a manager would ask. CASE with a CO edge, since the brief sets the 2028 target |

### Reverse questions: round 2

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good first quarter look like in this role?" | Asks your future manager to define success, which is the thing you will be measured on |
| 2 | "How is the role's time split between the branches and the contact centre?" | Signals you are planning the ramp into the part you have not worked in |
| 3 | "Who would I be presenting the monthly numbers to, and how do they like to see them?" | Treats the senior-presenting gap as a preparation task |
| 4 | "How will the move to 40% digital by 2028 change what the complaints process looks like?" | Uses the brief to show you think at the organisation's altitude |
| 5 | "Where do you see my biggest gap against what this role needs, and what support would close it?" | Converts the objection into a conversation with the person who can answer it |
| 6 | "What are the biggest pain points in how complaints are handled today?" | Gets the manager's own view of the problem you would own |

---

# Round 3: panel of two branch managers (60 minutes, includes the values scoring and a 20-minute case)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario probes scored against the four published values | High: the email says the panel "score against the four values" | Map a story to a value where one of your sentences carries one; use a scaffold with its honest branch where none does |
| Case / Strategist | The 20-minute complaint-escalation case, scored on reasoning | High: 20 of the 60 minutes are the case | Clarify, objective, approach, who does what, the record, the risks; think aloud and challenge one premise respectfully |
| Peer Evaluator | Where your role meets theirs; credit and disagreement | Medium: the panel is two branch managers and the JD has you coaching branch supervisors, so the seam is theirs to probe | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Pressure | Time-boxed challenges to your choice over others | Low: no source says the panel will press; kept for composure rehearsal | Pause, restate, anchor in what you said, hold through two follow-ups, concede specifically |

### Question bank

Proposed answer wording below is pending your approval.

**F. Values / Behavioral** (one per published value)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Members First, Always. Selection scaffold: pick a decision with a named stake where the member's view and an easier option differed, what you chose, and how it landed. That sentence shows the log, not a member-side decision, so if none comes to mind, say so plainly, then give the nearest thing it carries: "I handled the branch's formal complaints log." | The published value names the phrase. F1 is the nearest evidence and does not carry a story |
| F2 | "Tell me about a time you had to explain something more than once, and what you did about the way it was said." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Plain Words. Story-mapped on F8: "I trained new tellers on our escalation script." The beats are the script and the training of new tellers. Answer slot: the value's "explained twice" line makes a probe likely on whether anyone needed something re-explained; if so, say what changed and who decided; if not, or it was not yours, say so plainly and stay with the training | The value says that if a member needs it explained twice, "we wrote it wrong". F8 gives the nearest story and carries only the training |
| F3 | "When have you thought about what a decision meant for the town your branch sits in, not only the numbers?" | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Value: Neighbours, Not Numbers. Selection scaffold: pick a decision where the effect on the people your branch serves was part of how you chose, with what you weighed. Your material shows the branch role and no such decision, so if none comes to mind, say so plainly, then give the nearest thing it carries: "the last 3 as a branch supervisor" | The brief's eight-to-five hub plan makes this value likely to be probed by branch managers. That is inference from the brief and the value page, not a known panel script. F5 is the nearest evidence |
| F4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Value: Own the Fix. Story-mapped on F1: "I handled the branch's formal complaints log." The beat is the log. Answer slot: the value's "keeps hold of it until it is solved" line makes a probe on a case followed to its end likely. If a case stayed with you to resolution, say what it was and how it ended; if cases moved on, or it was someone else's, say so plainly and stay with the log | Own the Fix is the value closest to your one stated complaints duty, and the panel scores against it |

**G. Case / Strategist** (rehearsals for the 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "We'll give you a complaint that has escalated from a branch. Talk us through what you would do, starting with what you would want to know." | CASE | [generic] | Think aloud in order: clarify (what happened, what the member has been told, what has already been tried, who holds it now); the objective, decided from the member's side; your approach in plain words; who you tell and who acts; what is recorded; what you would feed back into the reporting. Challenge one premise respectfully. Use the published values as the language of the structure. The case needs no claim about your past, so the guidance makes none | The panel's recruiter-announced case is a complaint escalation. A live problem set in the role, so CASE; the structure rehearsed here is a pattern, not a prediction of the case |
| G2 | "The branch supervisor who escalated it thinks the member is wrong. How do you handle the supervisor?" | CASE | [generic] | Structure: ask first what they saw; separate the member's complaint from the supervisor's view; keep the member's outcome the first priority; agree what happens next and who tells the member; leave the supervisor better equipped for next time. The guidance makes no claim about your past | The JD has you working with branch supervisors on escalations, so a twist on that relationship is a natural second turn |
| G3 | "Eight branches are becoming five hubs over 2027. A complaint comes in from a member whose branch is closing. What changes in how you handle it?" | CASE | [grounded] | Structure: clarify the member's situation and what has been communicated; the objective from the member's side; plain words about what is changing; ownership of the fix stays with whoever finds it. The hub plan is from the July brief; stay with that fact and do not guess at detail beyond it | The brief supplies the premise. CASE with a CO edge: it tests whether you can hold the member's side and the strategy at once |

**H. Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "You'd be coaching branch supervisors on escalations. Where's the seam between your role and ours, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claiming to know the seam: agree who decides what before a case arises, who the supervisor answers to day to day, how a disagreement is raised and settled. Say you would want their view first. The guidance makes no claim about your past | A peer's seam probe on F8's requirement. JD because the coaching line is in the posting |
| H2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Reciprocity framing: credit goes where the work was, named plainly. Answer slot: if a specific piece of cross-team work comes to mind, say what was yours and what was theirs, in your own words; if none comes to mind, say so plainly and say how you would split credit | A standard peer stem, and a place where overstating your share is easiest |
| H3 | "What would you need from us in your first month, and what could you do for our branches?" | JD | [generic] | Answer both halves: what you would ask for, and what you would offer them. The offer is a plan, not a past: say what you would do first for their branches, in your own words | A reciprocity question from a peer panel, scored on partnership, and the pack's reverse question 4 below pairs with it |

**I. Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Sixty seconds: why should we choose you for a role that covers a contact centre you've not worked in?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Pause, restate. Anchor: "I've never worked in a contact centre," then at scope: "I handled the branch's formal complaints log." Hold that position through two follow-ups and never add to it. When pressed, concede the limit specifically and say what you would learn first, as a plan | The hold is the same limit D1 rehearses, in a time-boxed form. F2 is why a panel can press |
| I2 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I built the monthly complaints spreadsheet our regional manager uses." | Choose at most two facts from these sentences and say them at their own scope. Then one sentence of your own on what you would bring, in your words; keep it inside what you have said you did | A persona stem testing composure. It is low-weight because no source says the panel will press |

### Values / principles cheat sheet (Ashgrove's four values, from the page you copied on 24 November 2026)

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | Selection scaffold, F1: pick a decision where a rule, target or convenience pulled one way and the member's view the other; if none comes to mind, say so plainly, then the nearest thing it carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script." |
| Plain Words | If a member needs it explained twice, the wording was wrong | F8: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The beat is the script training; see F2 |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold, F5: pick a decision where the people your branch serves shaped how you chose; if none comes to mind, say so plainly, then the nearest thing it carries: "6 years in retail banking, the last 3 as a branch supervisor." |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The beat is the log; see F4 |

### Reverse questions: round 3

| # | Question | Why it lands |
|---|---|---|
| 1 | "What do your supervisors find hardest about escalations today?" | Starts from their reality, which is Plain Words and Neighbours in practice |
| 2 | "How should this role work with branch managers as eight branches become five hubs?" | Names the plan openly and asks for the panel's view, without guessing their feelings |
| 3 | "What does a complaint resolved well look like from your side of the counter?" | Uses the panel's own scoring language |
| 4 | "What could a new person in this role do in their first month that would genuinely help your branches?" | The reciprocity question, which a panel of peers weights heavily |
| 5 | "How much of the complaints work in your branches happens face to face in town, and how is that changing?" | Ties Neighbours, Not Numbers to the digital shift |
| 6 | "What would make you say the first six months had gone well?" | Gives you the panel's own measure to close on |

---

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: your material says the log and the script training, not an end-to-end process. B1's slot stays inside the log |
| Has worked in a contact centre, or in equivalent work | Negative you stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." Then a plan, never a past. No slot |
| Has presented to senior leaders | Negative you stated, F7 | The plain acknowledgment: "I've never presented to anyone above regional level." No claim about regional level either. No slot |
| Coached branch supervisors on escalations | Inflated form of F8 | F8's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: your material says tellers, not supervisors. C3's slot stays inside the script training |

## Sources

Provided documents: the job description as pasted; Ashgrove's published values as you copied them on 24 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the process; Ashgrove's 2026 strategy brief (July 2026), sent by the recruiter; your own message describing your background. No tuesday-dossier.md was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved section 10 or the VAL questions: the pasted values page fixes all four names and definitions |
| 2. `Ashgrove Credit Union interview process member services` | skipped | Could not have moved the loop or persona weights: the recruiter's email names each round's length, interviewer and content, and says the panel scores against the four values |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO questions: the July 2026 brief you sent supplies current priorities and is under six months old |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or its experience section → F3, F4, F6 and F8 draw only on your message; a CV could upgrade those rows from discovery or transferability and give C4, D3 and B1 real beats
- Answers to the answer slots, stated outside a drill (what the spreadsheet counted and in which tool, whether the formal complaints came under external rules, whether the teller training went beyond the script, any digital or self-service work) → rows F3, F4, F6, F8 and F9 become story maps instead of slots
- Your actual pay figure, notice period, location limits and reason for leaving → A3 to A6 become answers in your own words
- Interviewer names, once assigned → an interviewer read, personas per panel member, and a reverse question tied to each person's path
- The recruiter's answer on what the 20-minute escalation case contains and whether any material arrives in advance → coverage of the case beyond the pattern in G1 to G3; usually one email
- How many hours you have before 3 December → a prioritized prep schedule, with everything else marked as insurance
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes) → candidate reports on Ashgrove's loop and recent organisation context; offered once, run only if you ask
- A tuesday-dossier.md from an earlier job-fit check, if you have one → verified evidence and agreed positioning on the weak areas, so the objection ranking here would be evidence-derived instead of inferred
