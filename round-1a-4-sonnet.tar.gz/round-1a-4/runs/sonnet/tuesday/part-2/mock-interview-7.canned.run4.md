I've run four searches and found Saltmarsh's values, loop, strategy and Tobias's talk. Next I'm fetching the values and interviewing pages, then I'll write the pack.
Your prep pack is saved as `saltmarsh-games_live-operations-producer_interview_pack.md`. It has 19 questions, a fit snapshot against the JD, a reading of Tobias, reverse questions and a values cheat sheet.

I built it on one assumption: that Tobias is the hiring manager. Saltmarsh's interviewing page describes a single 60-minute "Outage Hour" with the hiring manager. That hour is a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home.

- **Banks:** the question banks are weighted to the tabletop and the three published values: Players Before Plans, Ship the Patch Not the Promise and Leave the Build Greener.
- **Highest-ROI prep:** question C3 is "You have never worked on a game with in-app purchases. How would you handle the monetization side of our events?" Saltmarsh's Project Larkspur announcement moves its titles to a season-pass model from February 2027, so expect it.
- **What reads strongly:** your content-drop calendar, release checklist and retention presentations map cleanly to the JD. The weaker rows are events versus drops, two titles, coordinating design, art, engineering and community, and owning the post-event review.
- **Tobias:** he gave a GDC 2026 talk, "Patch Notes Are a Promise", and used to be a QA lead. Your release checklist is the natural bridge to him. I only saw snippets of the talk and the Larkspur announcement, not the full pages.

Say the word and I'll play the Skeptic on C3 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions, or convert the pack to Word.

1. Is Tobias the person you'd report to, and did the recruiter say anything about the tabletop format?
2. Do you want a deeper research pass? It's up to 6 more searches and 2 more fetches and takes several more minutes. It would cover Saltmarsh's strategy, Tobias's talks, loop reports and recent org changes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed: hiring manager (Saltmarsh's interviewing page says the 60-minute interview is with the hiring manager; your note did not say whether Tobias is yours). Format: Friday, 60 minutes.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Saltmarsh's published values |
| EXP | Whether what you say about your work survives follow-up |
| JD | The posting's stated responsibilities and requirements, gaps included |
| CO | Whether you can think at the company's altitude |
| CASE | A live problem from the role, reasoned out loud |

Saltmarsh's interviewing page describes the session as "the Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation, with no take-home. The banks are weighted to that shape.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for one main title, not a live-events calendar and not two titles, and the words stay there: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title events line makes a probe on events likely. If any drops were timed events, or you also worked on a second title's calendar, say which and how, in your own words; if not, say so plainly and stay with the main title's calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show who the calendar was coordinated with. Answer slot: the JD's coordination line makes a probe likely. If you worked with any of design, art, engineering or community on the drops, say which and what you did with each, in your own words; if you did not, or it was someone else's job, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | low | [inferred] | discovery | Presenting numbers is not owning a review, and the bridge is not stretched past the quote: "Presented the monthly retention numbers to the studio head." Answer slot: if you also wrote or ran any review of a drop, or chose which measures were reported, say what; if not, say so plainly and say what you would report first |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap in the quote's own terms, but a CV-style line with nothing inspected behind it, so expect a probe. Lead with it as written: "Wrote the release checklist our QA team still uses." The JD says manage and the quote says wrote; your material does not show who ran sign-off on each release |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material gives the years and the role and does not say whether the title was a live-service game. Not a gate: it is graded like any requirement. Answer slot: if the title kept updating after launch, say so in your own words; if not, say so plainly and stay with the four years |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap: the quote already says it in the JD's terms. Lead with it as written, because a named cadence and a named duration beat an adjective |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement. Your material says presented, not computed, so expect a probe on how the numbers were counted (E1) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [inferred] | presentation | A written document another team still relies on is evidence in other terms. Say the quote as written and let the interviewer draw the inference. Your material holds no other written sample |
| F9 | Working knowledge of in-app purchases on mobile live events — role-family expectation, not in the JD (unquoted); Saltmarsh's Project Larkspur news says the two titles move to "a season-pass model" from February 2027 | "Never led a team, and never worked on a game with in-app purchases" — your message | none | [generic] | capability | A gap the wording cannot close, and you have said so. Words: "I have never worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap smaller |

Requirement coverage:

| JD requirement | Questions |
|---|---|
| Live-events calendar for two titles (F1) | A5, C1, D2 |
| Coordinate design, art, engineering and community (F2) | A1, A3, C2 |
| Post-event review and KPIs (F3) | A4, B4, E2 |
| Release checklist with QA (F4) | A2, B3 |
| 3+ years live-service (F5) | D1, F1 |
| Content calendar (F6) | D2, F1 |
| Retention metrics (F7) | E1, E2 |
| Clear written communication (F8) | A3, D3 |
| In-app purchases, not in the JD (F9) | C3, C1, D1 |

## Reading the interviewer

Public footprint only, taken from a search-result snippet (the page itself was not fetched).

| Observation | Source | What it means for you |
|---|---|---|
| GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | Search result, talks.gdconf.example | Expect precision about the difference between what shipped and what was announced. Be exact about what you did, and say what is known versus hoped in the tabletop (A3, D3) |
| Previously a QA lead at a console studio | Same snippet | QA fluency lands with him. The mirror is F4: "Wrote the release checklist our QA team still uses." Say it as written and stop |
| Saltmarsh's published value "Ship the Patch Not the Promise" echoes the talk's argument | Saltmarsh values page and the snippet | Treat the values half and the tabletop as one test: announce only what is built |

## Persona table

The loop source is Saltmarsh's own interviewing page: one 60-minute session, tabletop then values conversation, with the hiring manager. Weights follow it. The split of minutes between the two halves is not stated.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The tabletop: a simulated outage during a live event | Highest. The page names the tabletop as half of the session. 5 questions | Clarify, then objective, segments, approach, metrics, risks; think aloud; challenge one premise politely |
| Values/Behavioral | The values conversation on three published values | High. The page names it as the other half. 4 questions | Story where one of your sentences carries one; a selection scaffold with an honest branch where none does |
| Skeptic | Probing the gaps you have stated: IAP, team coordination, events versus drops | Medium. A hiring manager is derisking; your own message names two gaps. 3 questions | Rehearse the most predictable objection (C3) until it is boring |
| Pressure | Interruptions and time-boxing inside the live-incident tabletop | Medium. The tabletop is live and incident-shaped; his style is not documented. 3 questions | Pause, restate, hold the structure, concede uncertainty specifically |
| Data-Driven Prober | Retention numbers and how they were counted | Lower. One JD line and one quote. 2 questions | Know what you can and cannot say about how the numbers were counted |
| Conversational | The opener | Lower. 2 questions | A 90-second arc built only from your own sentences |

The Peer Evaluator is not in the pack: the loop source describes one session with the hiring manager and no peer.

## Question banks

### A. Case/Strategist (the tabletop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is day two of a four-day live event. Reward claims are failing for some players and the community channels are filling up. You are the producer on call. What do you want to know first?" | CASE | [generic] | Clarify before you act: what exactly fails, for whom, since when, and what changed just before. Name the objective (protect players, stop the damage). Split affected from unaffected players. Say who you pull in and who owns the decision. Name two or three measures you would watch. Say the risk out loud: any promise you make to players has to be one you can keep. Think aloud throughout | The page names the tabletop as half the session, and F2's requirement is about coordinating teams in an update. CASE because it scores structure |
| A2 | "Engineering says a fix could ship in two hours. QA wants a full regression pass that takes six. Players are waiting. How do you decide?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Lay out the options: ship the narrow fix with a targeted check, switch the broken feature off, or extend the event. Say who decides and what you need from QA to be comfortable. One sentence from your own material is available: "I wrote the release checklist our QA team still uses." Then return to the decision | F4 is the requirement this tests, and the interviewer's QA background (see Reading the interviewer) makes it likely. CASE because the answer is a decision under constraints |
| A3 | "You told players the event ends Sunday. Midweek, a bug stops many players earning the reward track. Write me the first announcement." | CASE | [generic] | Say what you know, what is fixed, what is not, and when the next update comes. Announce what is built and nothing hoped. Do not promise a fix date you cannot verify. Name who reviews the message before it goes out | F8's written-communication requirement and Saltmarsh's value Ship the Patch Not the Promise. CASE because it is a live problem delivered as writing |
| A4 | "After the event ends, what goes in the post-event review, and which KPIs do you report?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head" | Start from the event's goal and choose measures that answer it, compared against a baseline. Cover what happened, what players hit, what you would change, and who owns each action. Answer slot: the JD says you own the review and its KPIs. If you wrote or ran any review of a drop, say how, in your own words; if there was no such review, or it was not yours, say so plainly and return to "Presented the monthly retention numbers to the studio head." | F3 is the thinnest of the core requirements, so it is the likely probe. CASE because it asks for a design, JD because it tests the stated duty |
| A5 | "From February 2027, Project Larkspur puts the titles on one shared events calendar and one live-ops group. If your two titles move onto it, how do you build the calendar?" | CASE | [grounded] | Clarify first: which events stay per-title, which are shared, who arbitrates collisions, and how release windows work with QA. Cover player fatigue across titles and one comms cadence. Name the measures you would use to judge it. The question rests on a search-result snippet, so ask Tobias to confirm how it affects this role (reverse question 3) | The announcement is current strategy, so this is the pack's CO-style differentiator. CASE because it asks for a live design. F1 is the requirement it presses on |

### B. Values/Behavioral (the values conversation)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans. Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a time a scheduled drop or deadline collided with what players were telling you. It needs the plan, the signal from players, what changed, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the weekly content-drop calendar for our main title for the last two years", or how you would handle it | The first of Saltmarsh's three published values. VAL because it scores behaviour against that value |
| B2 | "Ship the Patch Not the Promise. Tell me about a time you had to say something was not ready." | VAL | [grounded] | Selection scaffold: pick a time a date, feature or fix was expected and was not ready. It needs what was expected, who wanted it announced, what you said instead, and how it landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Published value two, and the theme of the interviewer's own talk. VAL because it scores behaviour |
| B3 | "Leave the Build Greener. Tell me about a time a release left the checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: you wrote the checklist and QA still uses it; those are the beats the quote states, told in your own words. Answer slot: the value says each release leaves the checklist better. If the checklist changed after a release, say what prompted the change and what changed; if it was not revised, or revising it was not yours, say so plainly and stay with the checklist you wrote | F4 is your strongest fit to a published value. VAL because the value is the test |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: pick a time the news was unwelcome and you said it anyway. It needs the news, who it was for, what you said, and what followed. Answer slot: if any month's retention numbers were unwelcome and you presented them as they were, say what you said; if none were, or the framing was not yours, say so plainly. If nothing comes to mind, say so, then give the nearest thing your material carries | A standard values probe, tied to F7's quote. VAL because it scores candour |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | Pick the true answer from your own message: "I have never worked on a game with in-app purchases." Then a plan, said as a plan: what you would read, whom you would ask, and what you would shadow in the first weeks. Do not describe adjacent monetization experience you have not told me about | F9 and F1 are the widest gaps. JD because it scores honest self-assessment against the posting |
| C2 | "This role coordinates design, art, engineering and community on every update. What have you coordinated across?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: the JD names this coordination. If you worked with any of those teams on the drops, say which and what you did with each, in your own words; if you did not, or it was someone else's job, say so plainly and return to the calendar you ran | F2 is a row with no evidence. JD because it scores the stated duty |
| C3 | "You have never worked on a game with in-app purchases. How would you handle the monetization side of our events?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases" | **The highest-ROI prep in this pack.** Concede first, in the words you gave me: "I have never worked on a game with in-app purchases." Follow-up one, how would you learn it: say what you would read and whom you would ask, as a plan. Follow-up two, so we would be hiring you to learn on live events: hold on what your quotes carry (the calendar, the checklist, the retention numbers) and do not widen it. Follow-up three, what is the first thing you would not touch alone: name who you would ask before any event with a purchase in it. Never claim adjacent monetization work | F9 is the most predictable objection: Project Larkspur moves the titles to a season-pass model and you stated the gap. JD because it scores the stated duty and your honesty about it |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a producer who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | Pause, restate the question, and answer with only what you said: the calendar, the checklist, the retention numbers, each as written. Concede the gap in one clause: "I have never worked on a game with in-app purchases" (quoted in C3). Hold your position through two follow-ups by returning to the three quotes, never by adding to them | F5, F9 and F4 meet here. JD because it scores the case for the role |
| D2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Restate the quote. Answer slot: the JD's calendar duty makes a probe on who set what likely. If you chose which drops went in which week, say so and how you decided; if the content was set by others and you ran the schedule, or there was no such choice, say so plainly. Hold through two follow-ups by returning to the quote | F1 and F6 are the evidence, and attribution is what a stress interviewer tests. EXP because it scores what was yours |
| D3 | "Stop. Players are posting that we are hiding the outage. What do you post in the next ten minutes?" | CASE | [generic] | Say what you know, what you do not, and the time of the next update. Hold the structure from A1 and A3 under the interruption. Concede uncertainty specifically, for example "I do not yet know the cause", and do not fold the plan to restore calm. No promised fix times | The page's live-incident format makes an interruption plausible, and F8's requirement is written communication under pressure. CASE because it is a live problem |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You presented the monthly retention numbers. Walk me through how those numbers were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: say how the numbers were counted, what they were sensitive to, the assumption you would defend least, and which part was yours, each in your own words. If you did not build them, or do not know how a measure was counted, say so plainly and return to "Presented the monthly retention numbers to the studio head." | F7 says presented, not computed. EXP because it tests attribution |
| E2 | "A title's retention drops 20 percent the week after an event ends. Diagnose it." | CASE | [generic] | Clarify which retention measure and which cohort, then platform, version and what overlapped. Segment players who did and did not take part in the event. Offer hypotheses (the event ending, a bug, a content gap) and what you would check first. Think aloud | F7 and F3 are tested without claiming a past. CASE because it is a live diagnosis |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey. How did you get here?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc made of those four sentences, each said as written. Answer slot: why live operations, and why Saltmarsh, are yours to say in your own words; Saltmarsh's published values are public, and you should say which one lands for you and why in your own terms | The opener is scored even when it feels casual. F5 and F6 are the evidence. EXP because it is the biography question |
| F2 | "What are you actually playing these days, and what would you change about how its live events run?" | CO | [generic] | Selection scaffold: pick a live mobile title you really play, name one event structure to keep and one thing you would change, with the player-side reason. If you play none, say so plainly and say how you would study Saltmarsh's titles first. Before Friday, play the titles Saltmarsh's announcement names if you can | A rapport-style question about the JD's live-events theme. CO because it shows whether you think at the company's level |

## Values cheat sheet

Published values, official page fetched. Meanings are paraphrased from that page.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Selection scaffold ending in its honest branch (B1) |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Selection scaffold ending in its honest branch (B2, A3, D3) |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses" (B3) |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "You moved from QA lead to Head of Live Operations. What did you carry over into how this team runs a release, and what did you have to unlearn?" | Ties to his public path from the talk snippet and signals you researched him, not only the company |
| 2 | "Your GDC talk argued a live team is judged by how often its patch notes describe what actually shipped. How does the team check that internally, and what would that look like for this role?" | Shows you read his argument and asks how it becomes a working habit |
| 3 | "Project Larkspur puts the titles on one shared calendar from February 2027. How does that change what this role owns: two titles, or the shared calendar?" | Surfaces a real scope question that the posting does not answer |
| 4 | "Who owns monetization decisions on an event, and who would I learn that side from in the first month?" | Turns the stated IAP gap into a ramp plan without hiding it |
| 5 | "Which KPIs from the post-event review do you look at first, and what has changed a decision recently?" | Tests how seriously F3's requirement is taken and what good looks like |
| 6 | "What would you want me to have shipped, or learned, by the end of the first event I own?" | Gives you a concrete bar to answer to |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Negative the candidate stated, in F9's quote | "I have never led a team." The JD says coordinate, not lead; no slot |
| Has worked on a game with in-app purchases | Negative the candidate stated, F9 | "I have never worked on a game with in-app purchases." Then a plan, never a past. No slot |
| Ran a live-events calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one main title and content drops. A slot stays inside that calendar |
| Owned the post-event review and its KPIs | Inflated form of F3 | F3's quote at its own scope: presented the numbers. The limit is the pack's observation |
| Managed each release's QA sign-off | Inflated form of F4 | F4's quote at its own scope: wrote the checklist QA still uses |
| Four years of live-service experience | Inflated form of F5 | F5's quote at its own scope: four years as an associate producer at a puzzle-game studio |

## Sources

Provided documents: the job description text and your message.

Searches sent (4): "Saltmarsh Games values" returned saltmarshgames.com/values; "Saltmarsh Games interview process live operations producer" returned saltmarshgames.com/careers/interviewing; "Saltmarsh Games mobile studio strategy news" returned saltmarshgames.com/news/project-larkspur; "Tobias Wrenfield Saltmarsh Games Head of Live Operations" returned talks.gdconf.example/2026/patch-notes-are-a-promise.

Fetches sent (2): saltmarshgames.com/values and saltmarshgames.com/careers/interviewing. The Project Larkspur announcement (September 2026) and the GDC 2026 talk page were read only as search-result snippets. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and B1 to B3: three values by name |
| 2. Saltmarsh Games interview process, live operations | yes | Loop: one 60-minute session, tabletop then values conversation; persona weights and the bank order follow it |
| 3. Saltmarsh Games strategy and recent news | yes | A5, F9's context and reverse question 3, from the Project Larkspur snippet |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | The interviewer read and reverse questions 1 and 2, from the talk snippet |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Whether Tobias is the person you would report to, and anything the recruiter said about the tabletop format → persona weights confirmed or reweighted, and the tabletop bank tuned to its format
- Your CV, as pasted text → fit rows built from its sentences rather than your message, and more story-mapped guidance
- Your answers to the slots in F1, F2, F3 and F5 (events versus drops, who you coordinated with, whether you ran any review, whether the title was live-service) → those four rows leave discovery and A4, C2 and D2 become story-mapped
- The full Project Larkspur announcement, pasted → A5 and reverse question 3 move off a search-result snippet
- The talk itself, as a transcript or slides → a fuller interviewer read and sharper reverse questions
- A tuesday-dossier.md, if you have one from earlier work on this role → verified evidence and a named objection in place of the ones this pack inferred; never required
