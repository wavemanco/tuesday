Web search was denied in this session, so the pack rests on your JD and your background only. I'm writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-2-denied-14568215/atlas-freight_operations-manager_interview_pack.md`.

I couldn't research Atlas Freight. Web search was denied here, so all three searches were refused. The pack rests only on your JD and your background note. It has no company values, no loop structure and no strategy facts, and the company questions are generic. I built it for a hiring-manager round, since you don't know who is interviewing you. The persona weights rest on that assumption.

It has 20 questions across six interviewer styles, a fit snapshot, six reverse questions and a list of claims it won't coach. The three points the pack puts most weight on:

- **Highest-ROI prep (B1):** you manage 3 supervisors today and the role has 12 across 4 sites. Hold the quote at its own scope, concede only what the numbers show, then give a first-30-days plan. Say it as a plan, not as something you've already done.
- **Power BI:** your note says you've never used it. Say that plainly, then say how you'd learn it (B3, D3). Don't imply a course or project you haven't done.
- **Questions for you to answer:** the pack never states how many of your 7 years were spent leading people, and "5+ years leadership" is required. Know that number before the interview (B4). The same goes for how the 40% mis-pick figure was counted and which part was yours (C1, D2).

Say the word and I'll play the Skeptic on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document.

Who are you meeting, and is it a hiring-manager round, a recruiter screen or a panel? The answer reweights every question bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview pack: Operations Manager, Atlas Freight

Role: Operations Manager, Atlas Freight ("regional logistics, 800 employees" — your JD). Interviewer: not known. Round: not known, so this pack is built for a hiring-manager round and says so wherever that assumption moves a weight.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the values or standards the job needs |
| EXP | Whether your background claims survive follow-up questions |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (no research was available, so these are generic here) |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. It names what an interviewer is likely to probe and gives two honest branches. Either branch is a good answer.

## Prep triage

Do these first, in order. Everything else is insurance.

1. B1, the highest-ROI prep in this pack. Rehearse it until it is boring.
2. B3 and D3, the Power BI answer, so the plain acknowledgment sounds calm.
3. C1 and D2, the 40% figure: how it was counted and what part was yours.
4. A1 and A2, the on-time and cost cases, since they are the JD's first two outcomes.
5. B4, the years-of-leadership number, stated plainly.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message, "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift-manager role and a surge plan for the site, not terminal operations and not four sites. The words stay at those scopes: "I'm a senior shift manager over three supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-sites line makes a probe on work across sites likely. If you have led people or operations at more than one site, say where and how, in your own words; if you have not, or it was not yours, say so plainly and stay with the site you work at |
| F2 | "drive on-time performance" — JD | none given | none | [grounded] | discovery | Your material does not show on-time performance. Answer slot: the JD names it first among the outcomes, so expect a probe. If you have owned or moved a timing measure, say which and what it did, in your own words; if you have not, or it was not yours, say so plainly and say how you would diagnose it, as in A1 |
| F3 | "cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | low | [inferred] | discovery | A mis-pick rate is not a cost per shipment; that is the pack's observation, and the words stay at "cut mis-pick rate 40% by redesigning the pick path". Answer slot: the JD's cost line makes a probe on what else the redesign moved likely. If you tracked anything beyond the mis-pick rate, say what, in your own words; if nothing, or it was not yours, say so plainly and stay with the mis-pick rate |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says three supervisors, not twelve, and the number stays with its noun: "I'm a senior shift manager over three supervisors." Twelve is four times that, which is the pack's arithmetic and not words for you. The step up is closed with a plan for the first weeks, said as a plan and never as a past |
| F5 | "build reporting in Excel/Power BI" — JD (the Excel part) | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" says a skill, not a report built for others. Answer slot: the JD's reporting line makes a probe on what you have built likely. If you have built a report in Excel that others used, say what it showed and who read it, in your own words; if not, say so plainly and say what you would build first |
| F6 | "build reporting in Excel/Power BI" — JD (the Power BI part) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have never used Power BI." Then how you would learn it, said as a plan. Never a claim to Power BI work, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message, "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | Your material says seven years in operations and a current role over three supervisors. It does not say how many of the seven years were leadership, and the pack reads it downward. Answer slot: the JD's five-plus line makes this probe near certain. Say how many years you led people, in your own words; if fewer than five, say so plainly and say what that leading covered |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap: "I'm green belt certified." Name the program as it appears on your certificate, in your own words. Expect a probe on how you have used it, handled in C2 and E2 |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: diagnose a slip, cost a lane, plan a disruption | High. Hiring-manager prior (assumed round), and the JD is outcome-driven on on-time performance and cost | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the step up: span, sites, freight terminal versus warehouse | High. Hiring-manager prior, and F1, F4, F6, F7 are where the material is thinnest | Rehearse B1 until boring; hold what your quotes carry; plan, not past, for the rest |
| Data-Driven Prober | Reads every number: how the 40% was counted | Medium. The JD asks for reporting and cost metrics, and your material carries one headline figure | Know how the figure was counted and say plainly if you do not; name the assumption you would defend least |
| Pressure | Time-boxed challenges: why you, how much was you | Medium. Common in managerial rounds, and the Power BI gap invites it | Pause, restate, hold two follow-ups, concede specifically |
| Conversational | Friendly arc questions, "what are you playing with" | Low-medium. A friendly opener is likely whoever the interviewer is | A 90-second arc built from your own sentences; treat casual questions as scored |
| Values/Behavioral | Scenario probes on leading and accountability | Low. No loop source established the loop, so the pack falls back to a generic archetype with flat weights and no assumed values round | Pick instances that fit the criteria in the guidance; if none comes to mind, say so |
| Peer Evaluator | Seam-splitting with an adjacent team | Low, no bank. A peer round is not the assumed one; a name and relationship would change this | Reciprocity framing, if the round turns out to be a peer round |

The weights rest on an assumed hiring-manager round and a generic loop, not on Atlas Freight's documented process. If you know who you are meeting, the weights move.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "On-time performance has slipped at one of our four terminals over the last quarter. What do you need to know first, and how do you diagnose it?" | CASE | [generic] | Clarify first: what on-time means here, against which promised window, and whether the slip is one terminal or the whole network. Then structure: objective, segmentation (by lane, by shift, by cause), approach, metrics, risks. Think aloud. The question needs no claim about your past, so the guidance makes none | F2's requirement, asked as a live problem; CASE because it scores structure |
| A2 | "Cost per shipment has crept up while volumes are flat. Where do you look, and in what order?" | CASE | [generic] | Define the term and its denominator first, then break cost into its parts and look at where each moved against volume and mix. Say which part you would rank first and why. No claim about your past | F3's requirement as a diagnosis; CASE because the interviewer scores the order of your reasoning |
| A3 | "You inherit twelve supervisors across four sites and cannot be everywhere. How do you set up the first thirty days?" | CASE | [grounded] "currently a senior shift manager over 3 supervisors" | Structure it: what you need to learn about each site and each supervisor, what cadence and standards you set, what you leave alone at first. Anchor in your quote at its own scope, "I'm a senior shift manager over three supervisors", and say plainly that twelve is a larger span; the plan is how you close it, said as a plan | F4 and F1 as a live problem; CASE because it is a forward plan, with the quote as context only |
| A4 | "What should a terminal manager's reporting show at six in the morning, and what should the regional view show?" | CASE | [grounded] "solid Excel, never used Power BI" | Design on paper by decisions, not tools: which measures, how often they refresh, who reads them. Stay with "solid Excel"; if asked about the tool, "I have never used Power BI", then how you would learn it, as a plan. Answer slot: the JD's reporting line makes a probe on what you have built likely. If you have built a recurring report, say what it showed and who read it; if not, say so plainly and design it from scratch | F5 and F6; CASE, with JD content |
| A5 | "A storm closes the main lane into one terminal on your busiest day. Walk me through the next four hours." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure the four hours: what you confirm, who you call, what you protect first, how you communicate. One optional line ties to your quote at its own scope: "I ran the site's peak-season surge plan two years running." Do not describe what that plan contained | F1's daily-operations requirement under stress; CASE because it is a live problem |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your current team is three supervisors; this role has twelve across four sites. What is the biggest step up for you?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI prep in this pack, and the deepest rehearsal. Level one, hold: "I'm a senior shift manager over three supervisors." Level two, "so you haven't done this at that scale?": return to the quote and concede what the numbers show, that twelve is four times three, without adding to the quote. Level three, "what would you do in the first thirty days?": the plan from A3, said as a plan. Answer slot: if you have led people or operations at more than one site, say where and how; if not, or it was not yours, say so plainly and stay with the site you work at | F4 and F1 are the biggest step in the JD, so this objection arrives in some form; JD because it scores the stated requirement |
| B2 | "What from warehouse and distribution carries over to running a freight terminal, and what does not?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say what your seven years were, in those words. Answer slot: the JD says terminal operations, so expect a probe on freight terminal or linehaul work. If any of your seven years touched it, say what; if none did, say so plainly and stay with warehouse and distribution ops. Then name, as a plan, what you would learn first | F1's terminal wording; JD because it scores the listed job |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Pick from what your material shows. If it is Power BI: "I have never used Power BI", then how you would learn it, as a plan. Calibrated candor beats bluffing | F6 is your own stated gap; the Skeptic stem asks for it directly |
| B4 | "The posting asks for five-plus years of operations leadership. How many of your seven years were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors" | State the number, in your own words, before they extract it. Answer slot: if fewer than five, say so plainly and say what that leading covered; if five or more, say when it began and what the role was. Never round up | F7 is silent on years of leadership, and the JD marks it required |
| B5 | "Why this role, why Atlas Freight, why now?" | JD, CO | [generic] | Selection scaffold: give your real reasons, in your own words; the pack supplies none. For the company, use only what you can source: the JD says regional logistics, 800 employees, four sites. No research was available, so say nothing about their strategy you cannot back. If you do not know why yet, say so plainly and name what drew you to the JD | Motivation consistency is the Skeptic's core score; CO because it tests homework depth |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend-the-number slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. The pack supplies no method or baseline | F3's headline figure; EXP because it tests attribution |
| C2 | "What did redesigning the pick path involve, and what changed on the floor?" | EXP, JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path", "green belt certified" | Tell the redesign in your own words at the quote's scope: the pick path, redesigned, mis-pick rate down 40%. Answer slot: the JD's Lean and Six Sigma line makes a probe on how you approached it likely. Say how you approached it, in your own words; if it was not a formal method, or not yours, say so plainly and stay with the redesign as you described it | F3 and F8 are two separate quotes, kept separate; JD because it scores the plus |
| C3 | "How do you define cost per shipment, and what is in the denominator?" | JD | [generic] | Define terms before answering and say what you would ask first. Answer slot: if you have owned a cost-per-unit figure, say which and how it was built; if not, say so plainly and walk the structure from A2 | F3's requirement; JD because it scores whether you speak the metric |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already run a terminal network?" | EXP | [grounded] "ran the site's peak-season surge plan two years running", "cut mis-pick rate 40% by redesigning the pick path", "green belt certified" | Pause and restate. Then your three sentences at their own scope, and stop. Describe what you did and let the interviewer draw the inference. Hold through two follow-ups by returning to the quotes, never by adding to them | F1, F3 and F8 are the strongest quotes; EXP because the question tests attribution under time pressure |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold, then concede specifically. Answer slot: say what part of the redesign was yours and what was others', in your own words; if it was not yours, or was shared, say so plainly and describe your part. Never claim the whole figure | F3's figure again, in the Pressure register |
| D3 | "You have never used Power BI and this role is built around reporting. Why should I take that risk?" | JD | [grounded] "solid Excel, never used Power BI" | Hold: "I have never used Power BI. I have solid Excel." Hold through two follow-ups by returning to those two facts, then give the ramp plan, said as a plan. Do not claim a course or project you have not done | F5 and F6 are the sourced gap; Pressure because it tests composure on it |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "green belt certified" | A 90-second arc built from those three sentences and your own words for the steps between; the pack does not have your path. Treat it as scored | F7 and F4 are what a hiring manager hears first |
| E2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Say "I'm green belt certified" at its scope. Answer slot: if you apply it in your current work, say where, in your own words; if you do not, or it was a certification only, say so plainly | F8 is the JD's plus, asked casually |

### F. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you had to hold a supervisor to a standard they were not meeting." | VAL | [generic] | Selection scaffold: pick an instance with a named stake, an action that was yours, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's supervisor-leadership line; VAL because it scores behavior, and generic because no values source was available |
| F2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Same scaffold: a named stake, what you said, what happened after. If no such time comes to mind, say so plainly and say how you would handle it | Persona stem for a values round, which may exist somewhere in the loop |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, A5, B1, B2 |
| "drive on-time performance" | A1 |
| "cost-per-shipment down" | A2, C3 |
| "lead a team of 12 supervisors" | A3, B1, F1 |
| "build reporting in Excel/Power BI" | A4, B3, D3 |
| "5+ years operations leadership required" | B4, E1 |
| "Lean/Six Sigma a plus" | C2, E2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does on-time performance mean here — which measure, against which promised window — and where is it today?" | Pins the definition before you own it, and shows you ask what a number means |
| R2 | "How is cost per shipment calculated here, and which part does this role control most directly?" | Shows you think about the denominator and about what you would actually own |
| R3 | "What does reporting look like today — what is built, in which tools, and who reads it?" | Learns the starting state of the Excel and Power BI work, and signals a ramp plan |
| R4 | "How are the twelve supervisors spread across the four sites, and what is the mix of experience?" | Sizes the span you would take on |
| R5 | "What would a good first ninety days look like, and what would tell you it was off track?" | Gets the interviewer's own scoring sheet for the role |
| R6 | "What support is there in the first month for learning the company's systems and reporting tools?" | Turns the Power BI gap into a question about onboarding |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Power BI, or built Power BI reports | Negative the candidate stated, F6 | The plain acknowledgment F6 gives: "I have never used Power BI." Then a plan. No slot |
| Led twelve supervisors, or a multi-site team | Inflated form of F4 and F1 | The quotes at their scope: "I'm a senior shift manager over three supervisors." The limit is the pack's observation: the material says three supervisors and one site's surge plan. A3 and B1 stay inside it |
| Ran terminal operations | Inflated form of F1 | The quotes at their scope; the material says shift management and a surge plan, not terminal operations. B2's slot stays inside warehouse and distribution ops |
| Reduced cost per shipment | Inflated form of F3 | F3's quote at its own scope: "cut mis-pick rate 40% by redesigning the pick path". C3's slot asks only whether you have owned a cost-per-unit figure |
| Seven years of operations leadership | Inflated form of F7 | "7 years in warehouse and distribution ops" at its scope. B4's slot asks only how many years you led people |
| The pick-path redesign was a green belt project | Inflated form of F3 and F8, two separate quotes | Each quote at its own scope. C2's slot asks how you approached the redesign, in your own words |

## Sources

Provided: the JD you pasted and your background note. No dossier was present.

Searches sent, all refused by the host (permission not granted):

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics strategy news" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call refused. Would have fed a values cheat sheet; none was built, and VAL questions use generic themes |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call refused. Would have fixed the loop and persona weights; the pack uses a generic archetype and an assumed hiring-manager round |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call refused. Would have grounded CO questions and the grounding brief; both are absent or generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting, their role, and the round type → persona weights recomputed, an interviewer read, and a reverse question tied to their path
- Anything the recruiter told you about what to prepare (a presentation, a case, a take-home) → a build section for it
- Atlas Freight's values or careers page pasted in, or web search allowed → grounded CO questions, loop-based persona weights, and a values cheat sheet if a values round exists
- Your CV → the quotes in the fit snapshot move from your message to your CV, and the F1, F4 and F7 rows can be story-mapped more precisely
- Your own answers to the slots in F1, F2, F3, F5 and F7 → those rows regenerate from your words
- Your green belt certificate → F8 from medium to high
- A `tuesday-dossier.md` from an earlier fit check → verified evidence, a named top objection, and prohibited claims set by someone who has looked at the evidence
