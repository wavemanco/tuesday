Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-7-canned-8b66ff08/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 21 questions and covers every JD line. I built it for Saltmarsh's "Outage Hour". Their interviewing page says every loop is a recruiter call, then one 60-minute hiring-manager interview. That interview is a live-incident tabletop on a simulated outage, then a values conversation, with no take-home. I assumed Tobias is that hiring manager.

- **Highest-ROI prep (C1):** "I don't see in-app purchases in your background." Saltmarsh's September 2026 Project Larkspur announcement moves its titles to a season-pass model, so I'd expect this to come up. The pack has you say "I haven't worked on a game with in-app purchases" before being asked twice. You then put your monthly retention presentations beside it, as adjacent work and no more, and give a plan for learning the purchase side.
- **Where your material is thinnest (rows F1 to F3):** You described a weekly content-drop calendar for one title. The JD asks for live events across two titles, and for owning the post-event review and its KPIs. The pack keeps your wording at its own scope. It adds answer slots where the interviewer is likely to probe. The prohibited-claims section lists the stretched versions to avoid.
- **Tobias's angle:** He is a former QA lead who gave a GDC 2026 talk, "Patch Notes Are a Promise". Your release checklist is the nearest shared ground, and the talk echoes the value Ship the Patch Not the Promise. The Larkspur announcement and the talk listing were read from search snippets only, so check them before you lean on specifics.

For the 3-day prep order: C1 and the tabletop questions (A1 to A3) first, then the values stories, then play Tidepool Tactics and Lantern Row.

Say the word and I'll play the Skeptic on C1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Is Tobias the person you'd report to, and did the recruiter tell you anything about the Outage Hour scenario or how it's scored? Either answer reweights the tabletop bank.
2. Do you want a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) to read the Larkspur announcement and Tobias's talk in full?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Built for the 60-minute "Outage Hour" that Saltmarsh's interviewing page describes, on the assumption that Tobias is the hiring manager. Candidate: Femi. Interview: Friday.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows Saltmarsh's published values |
| EXP | Whether your background claims survive follow-up, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's current direction |
| CASE | A live problem, scored on structure and reasoning |

Provenance labels: `[grounded]` rests on your message, the JD you pasted, or a source named in Sources. `[inferred]` is derived from an adjacent source, with the derivation named. `[generic]` is a role-family pattern with no claim about Saltmarsh or about you.

## Prep triage

Three days. Do these in order. Everything else is insurance.

1. Tuesday: C1 out loud, until the plain acknowledgments in it sound ordinary. It is the highest-ROI prep in the pack, because it is the objection built from your own stated gaps (F9, F10).
2. Tuesday and Wednesday: A1 to A3 out loud, structure first. Saltmarsh's interviewing page makes the outage tabletop the first part of the hour.
3. Wednesday: B1 to B4. Decide, per value, whether a real story comes to mind. If none does, the honest branch in each cell is the plan.
4. Thursday: play Tidepool Tactics and Lantern Row (F2), then run F1 as a 90-second arc.
5. Thursday evening: pick three reverse questions.

## Fit snapshot

Gate check: nothing in the JD is a gate. "3+ years" is a titled-years requirement, so it is graded like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for your main title, not events and not two titles, with nothing inspected behind it, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's live-events and two-titles lines make a probe likely. If any drops were timed events, say which and what you did; if none were, or you worked on one title only, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | low | [inferred] | discovery | A weekly calendar touches coordination, but the quote does not say with whom. Answer slot: the JD's four disciplines make a probe on who you worked with likely. If you worked with any of design, art, engineering or community on a drop, say which and what you did; if a discipline was not part of your drops, or the coordination was someone else's, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | low | [inferred] | discovery | Presenting numbers is not owning a review or its KPIs, and the bridge is not stretched. Answer slot: if you also produced or reviewed those numbers, or ran any review after a drop, say what and which part was yours; if you presented numbers someone else produced, or there was no such review, say so plainly and stay with the monthly presentation to the studio head |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap on the checklist itself, but a line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you wrote it, and QA still uses it. "Manage" is the JD's word; the quote says wrote, so keep wrote |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material shows four years as an associate producer and two years on a weekly drop calendar, and does not show whether the first two years were on a title with live content. Answer slot: the JD's titled-years line makes a probe on the other two years likely. If those years were on a live title, say what you produced there; if they were not, say so plainly and stay with the two years you described |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap. Lead with the quote's terms: the weekly content-drop calendar, your main title, the last two years. Nothing inspected sits behind it, so expect a probe; an exported calendar would be the artifact that raises the band |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in the quote's terms: you presented them monthly to the studio head. "Comfortable" is the JD's word and "presented" is yours, so keep presented. Expect a probe on how the numbers were counted (D1) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A checklist others still use is written work, but the quote does not speak to clarity, and the pack will not say it proves it. Words: "I wrote the release checklist our QA team still uses." Answer slot: if other written work of yours was acted on by a team, say what it was; if the checklist is your main example, say so plainly |
| F9 | In-app purchase and season-pass fluency; not in the JD, and raised by the Project Larkspur announcement's season-pass model (Sources, search result) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to purchase-side work, and nothing added to make the gap feel smaller |
| F10 | Leading people; not in the JD, which asks you to coordinate four teams | "Never led a team" — your message | none | [grounded] | capability | A stated gap. Words: "I haven't led a team." Then what your sentences carry, at their own scope, and no claim of leadership |

## Reading the interviewer

Public footprint only, read from search snippets (Sources). The talk page and the studio news page were not opened in full.

| Observation | Source | What it means for Friday |
|---|---|---|
| Head of Live Operations at Saltmarsh; previously a QA lead at a console studio | Talk listing for GDC 2026 | The release checklist (F4) is your nearest shared ground with him |
| GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | Talk listing for GDC 2026 | It echoes the value Ship the Patch Not the Promise. Expect precision about what shipped versus what was planned, and keep every answer at the scope of what you did |
| Mirror opportunity | Pairs his QA background with F4: "Wrote the release checklist our QA team still uses" | Reverse questions 2 and 6 use it. Shared professional ground only, nothing personal |

## Persona table

The weights rest on Saltmarsh's interviewing page, which describes a recruiter call and then a single 60-minute interview with the hiring manager: a live-incident tabletop, then a values conversation. The page does not say how the hour splits. Peer Evaluator is omitted: this is a hiring-manager round, and no peer is named.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The outage tabletop; a shared-calendar planning problem | High. The interviewing page makes the tabletop the first part of the hour, and a hiring manager buys capability on live problems | Clarify first, state the structure aloud, think aloud. Players first, per the published value |
| Values/Behavioral | The second half of the hour | High. The page documents a values conversation in this round, and Saltmarsh publishes three named values | Map a story to each value where your own sentences carry one; where none does, use the selection scaffold and its honest branch |
| Skeptic | Gaps in the JD match: one title, no in-app purchases, no team led | Medium to high. Hiring-manager prior, and you have stated the gaps yourself | Rehearse C1 until it is boring. Acknowledge plainly, bridge only with adjacent sentences you said, give a plan |
| Data-Driven Prober | Retention numbers; what shipped versus what was planned | Medium. His public theme is accuracy of what ships | Know what you can and cannot say about how each number was counted, and say so when you do not know |
| Pressure | Time-boxed answers during the incident | Low to medium. The scenario is urgent, but nothing says the interviewer is a stress style | Pause, restate, anchor in what you said, and hold through two follow-ups |
| Conversational | Opening, company knowledge, writing | Medium. It opens most hours and is still scored | A 90-second arc built from your own sentences |

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Event day, first hour: a chunk of players can't connect and the event clock is still running. Walk me through your first fifteen minutes." | CASE | [inferred] | Say the structure aloud first, then fill it: what you need to know (who is affected, what is confirmed, who is already on it), what you are protecting (players first), who you pull in (engineering, community, QA), what you say now and what you hold until it is built, and what you decide about the event clock. The question needs no claim about your past, so the guidance makes none | The interviewing page describes a live-incident tabletop on a simulated outage during a live event, so this is the likeliest opening. The scenario is a pattern built on that format, hence inferred. CASE because it scores structure under pressure; it also exercises F2's coordination line |
| A2 | "Players are asking in the community channel whether event rewards were lost. Engineering says the fix is two hours away. What do you say, and when?" | CASE | [inferred] | Say what is known and what is not. Promise only what is built, and name when the next update comes. Say who has to approve the wording before it goes out. No claim about your past is made | Tabletops usually move from the incident to the player-facing message, and the published value Ship the Patch Not the Promise points at exactly this. CASE with a VAL flavour |
| A3 | "The outage is over, but the event ran at half strength for six hours. What do you decide about the event, and what goes into the review?" | CASE | [inferred] | Ask what you would need first (how many players, which rewards). Give two or three options with the players-first criterion that picks between them. Then say what the review would hold. Answer slot: the JD's post-event review line makes a probe on whether you have written one likely. If you ran or contributed to a review after a drop, say what it held and which part was yours; if there was no such review, or it was not yours, say so plainly and answer as the approach you would take | Covers the post-event review line of the JD (F3), as a decision first and a document second |
| A4 | "Project Larkspur puts Tidepool Tactics and Lantern Row on one shared events calendar from February 2027. How would you plan the first quarter of it?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Clarify first: which events overlap in audience, what the season-pass milestones are, what QA and engineering can absorb. Then structure, then risks. Say what you ran in the quote's own words and reason forward from it; do not claim shared-calendar work. Answer slot: if you have coordinated across more than one title, say how; if not, say so plainly and reason from the one you ran | The company's current strategy, which is the CO differentiator. CASE because it is a live planning problem; CO because it needs the Larkspur vocabulary. F1 is the evidence and its limit |
| A5 | "Two of design, art, engineering and community want different things for the same release. Where do you start?" | JD | [inferred] "I ran the weekly content-drop calendar for our main title for the last two years" | Put the fixed facts on the table first: the date, what each team needs, what is a hard constraint. Name who decides and when you would escalate. Answer slot: the JD's four disciplines make a probe on who you worked with likely. If you worked with any of them on a drop, say which and what you did; if a discipline was not part of your drops, or the coordination was someone else's, say so plainly and answer as the approach you would take | The JD's coordination line (F2) as a scenario. JD because it scores the stated responsibility, CASE in delivery |

### B. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Players Before Plans: tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a time a scheduled drop and what players wanted pulled apart. It needs a named stake, what you chose, and what happened after. Use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, in these words, or how you would handle it | Value one of three. The sentence you gave describes the calendar and carries no conflict story, so the pack supplies none. Mapped from F6 |
| B2 | "Ship the Patch Not the Promise: tell me about a time what you were ready to announce and what was actually built did not match." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold: pick a time the announcement and the build came apart, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, in these words, and say how you would check an announcement against the build. Do not say what the checklist caught or prevented | Value two, and the one his GDC 2026 talk echoes. F4 is the nearest sentence, and it does not carry an announcement story |
| B3 | "Leave the Build Greener: tell me about a time you left a process better after a release." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: you wrote the checklist, and QA still uses it, which are the beats the quote states. Tell them in your own words. Answer slot: the value's better-than-it-found-it line makes a probe on what prompted the checklist likely. If it came from a specific release problem, say what and what changed; if it was written for another reason, or nothing prompted it, say so plainly and stay with the checklist QA still uses | Value three, and the best-carried of the three. VAL because it scores a published value |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F7: the monthly presentation to the studio head, which is the beat the quote states. Answer slot: if any month's numbers were unwelcome, say what you said and what happened; if none were, or you were passing numbers along, say so plainly and stay with presenting them each month | A standard values-round prompt, and the only quote that puts you in front of leadership |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see in-app purchases in your background. How would you handle that in this role?" | JD | [grounded] "never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head" | **Highest-ROI prep in this pack.** Open with the plain acknowledgment before being asked twice: "I haven't worked on a game with in-app purchases." Put the retention presentation beside it as the adjacent thing you did, and no more: it is not purchase work. Then a plan, said as a plan: what you would ask to see first, and who you would sit with. Follow-up one, "What would you want to know in week one?": answer as a plan, not a past. Follow-up two, "Can you do the job without it?": hold, return to what you did, and concede the specific limit, that the purchase side is something you would have to learn. Never fold on what you did, and never claim familiarity you did not describe | The gap you stated yourself is the one most likely to be probed, and the Larkspur season-pass model is the likely reason. Gap type is capability (F9). Inferred, not named by an earlier underwriting |
| C2 | "The role runs two titles' calendars. How would the calendar you ran for your main title change with two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Describe what you ran, in the quote's words. Then reason about what changes: shared dates, shared QA time, audiences that overlap. Answer slot: if you ever ran or fed more than one title's calendar, say how; if not, say so plainly and reason from the one you ran | The JD's two-titles line, probed against F1 |
| C3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Choose from your own judgment; the pack's reading is that F3, owning the review and its KPIs, is where your material says least. Name it, say what you would do in the first weeks, and say what you already have beside it, in the quote's words. Do not answer none | A standard Skeptic stem; JD because it scores honest self-assessment against the listed job |
| C4 | "You have never led a team, and this role coordinates four disciplines. Why should I trust you to?" | EXP | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | Start with the plain acknowledgment: "I haven't led a team." Then say what your sentences carry, at their scope: the weekly calendar, and the checklist QA still uses. Do not use the word led for any of it. Answer slot: if you coordinated with any of those disciplines without leading them, say how it worked; if you did not, say so plainly and stay with the calendar and the checklist | F10 and F2 together. The JD says coordinate, not manage, so a candid answer that separates the two is the likely good one |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the retention numbers you presented each month." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F7: the monthly presentation to the studio head, in the quote's words. Defend-the-number slots, in your own words: how retention was counted, what it was sensitive to, the assumption behind it you would defend least, and which part was yours, producing the numbers or presenting them. If you do not know how it was counted, say so plainly. No figure is supplied and none is invented | Retention is a headline line of the JD and the only metric you mentioned, so it is the magnet for a prober |
| D2 | "Which numbers go into a post-event review, and which one would you trust least?" | JD | [inferred] | Say what the event was for first, then the numbers that show whether it did that, then the one most easily moved by something else at the same time. Answer slot: if you ran or contributed to a review after a drop, say what it held and your part; if there was no such review, or it was not yours, say so plainly and answer as the approach you would take | F3's requirement as a method question. Inferred because the method is a pattern for the JD line |
| D3 | "A drop goes live and retention is up the following week. How do you decide the drop caused it?" | CASE | [generic] | Structure it: what else changed that week, what you would compare against, whether the lift holds, what you could not tell, and what you would do to find out. No claim about your past is made | A pattern question for anyone who is comfortable with retention metrics (F7), asked as a case |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events for two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | Pause and restate. Say the three sentences in their own words, then stop. Hold through two follow-ups by returning to those sentences, never by adding to them. Concede specifically when pressed: "I haven't worked on a game with in-app purchases" and "I haven't led a team." Do not claim you are the stronger candidate | Tests composure on F1, F5 and F6 together |
| E2 | "That release checklist: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: "I wrote the release checklist our QA team still uses." Answer slot: if others contributed, say what was theirs and what you wrote; if you wrote it alone, say so; if you do not know how it is run now, say so plainly. Do not upgrade wrote to owned or designed | An attribution probe; F4 is where an interviewer from QA will press |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc from those four sentences only: four years as an associate producer at a puzzle-game studio; for the last two, the weekly content-drop calendar for your main title; the checklist QA still uses; the monthly retention presentations. Do not invent when each happened. Close on why this role, in your own words; the pack supplies no reason. Answer slot: the JD's 3+ years line makes a probe on the other two years likely. If they were on a title with live content, say what you produced; if not, say so plainly and stay with the two years | The opener, and a scored one. Covers F5 |
| F2 | "Have you played Tidepool Tactics or Lantern Row? What would you change about their event calendars?" | CO | [inferred] | Play both before Friday. Say what you saw, in your own words, and what you would ask the team before changing anything. Answer slot: if you have played either, say what you observed; if not, say so plainly and say what you would look at first | Titles come from the Larkspur announcement; the JD says two of our mobile titles without naming them, so the match is inferred |
| F3 | "Written communication matters on this job. What is the last thing you wrote that other people had to act on?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F8: you wrote it, and QA still uses it. Answer slot: if there is something more recent, such as an update note or an event recap, say what it was and who acted on it; if the checklist is your main example, say so plainly. Say nothing about what the checklist did beyond that | Covers the JD's written-communication line (F8) |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A4, C2, E1 |
| Coordinate design, art, engineering and community teams on each update | A1, A5, C4 |
| Own the post-event review and the KPIs it reports | A3, D2 |
| Manage the release checklist with QA | B3, E2 |
| 3+ years producing live-service games or apps | F1, E1 |
| Experience running a content calendar | A4, C2, F1 |
| Comfortable with player-retention metrics | D1, D3 |
| Clear written communication | F3 |

## Values cheat sheet

A loop source documents a values conversation in this round, and Saltmarsh's values page names three.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | Scaffold ending in its honest branch (B1). Nearest sentence, F6: "I ran the weekly content-drop calendar for our main title for the last two years" |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | Scaffold ending in its honest branch (B2). Nearest sentence, F4: "Wrote the release checklist our QA team still uses" |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses", with B3's answer slot |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "In your GDC talk you argue a live team is judged by how often its patch notes describe what actually shipped. How does Saltmarsh measure that today, and what would the producer own in it?" | Shows you read his work, and asks what the review and KPI line of the JD means in practice |
| R2 | "You came to live ops from QA. What did that change about how you run a release here?" | Ties to his own path and invites him to talk about the checklist ground you share (F4) |
| R3 | "Project Larkspur describes a single live-ops group. Does this role sit in it, and which two titles would it cover?" | Shows you read the strategy and settles the two-titles question in the JD |
| R4 | "What does a good post-event review look like here, and what has surprised the team most in one?" | Grounds F3 in how Saltmarsh actually works |
| R5 | "What would the strongest person in this role have done by the end of month three that you would point to?" | Tells you the bar and shows you are thinking about delivery |
| R6 | "Where does the release checklist break down today?" | Echoes Leave the Build Greener and invites the QA-lead side of him |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events, or a live-events calendar | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says weekly content drops, not events |
| Ran a calendar across more than one title | Inflated form of F1 | F1's quote: the main title. The material says one title and does not mention a second |
| Owned the KPIs or the post-event review | Inflated form of F3 | F3's quote: you presented the monthly retention numbers. The material says presented, not owned |
| Managed or owned the release process | Inflated form of F4 | F4's quote: you wrote the checklist, and QA still uses it. The material says wrote, not managed |
| Led a team | Negative the candidate stated, F10 | The plain acknowledgment F10 gives: "I haven't led a team." No slot |
| Has in-app purchase experience | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |

## Sources

Provided documents: your message, which carried the JD text and your background. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and B1 to B3: three values by name, from the official page |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop: recruiter call, then a single 60-minute hiring-manager interview, tabletop then values conversation, no take-home. Persona weights, bank A and the values sheet follow it |
| 3. `Saltmarsh Games mobile studio news strategy` | yes | Project Larkspur, September 2026, from the search snippet only (fetch cap reached). Moved A4, F2, R3 |
| 4. `Tobias Wrenfield Saltmarsh Games Head of Live Operations` | yes | Interviewer read and R1 to R2, from the search snippet only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries and what came back:

- `Saltmarsh Games values`: https://saltmarshgames.com/values, then fetched
- `Saltmarsh Games interview process live operations producer`: https://saltmarshgames.com/careers/interviewing, then fetched
- `Saltmarsh Games mobile studio news strategy`: https://saltmarshgames.com/news/project-larkspur
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations`: https://talks.gdconf.example/2026/patch-notes-are-a-promise

## Upgrade menu

- The recruiter's guidance on the Outage Hour, such as what the scenario covers and how it is scored → sharper bank A, and a check on the assumption that Tobias is the hiring manager
- Your CV text → more rows gain exact quotes, and F2, F3 and F8 may move from discovery to presentation
- A release checklist, a calendar export or a retention deck you can describe → F4, F6 and F7 can rise from medium to high
- A piece of writing a team acted on, such as an update note or an event recap → F8 rises from low, and question F3 gets a stronger story
- Your answers to the slots on F2, F3 and F5 → those rows, and the banks that draw on them, regenerate
- A tuesday-dossier.md from an earlier underwriting of this role → verified evidence and an evidence-derived top objection; C1 is inferred here
