Your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-7-canned-2b7a1801/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 22 questions, built on three things I found on Saltmarsh's own pages:

- **Format:** Saltmarsh's careers page describes one 60-minute "Outage Hour" with the hiring manager. It is a live-incident tabletop on a simulated outage during an event, then a values conversation. I assumed your Friday slot is that hour and that Tobias is the hiring manager. I weighted the pack towards the tabletop and the values half.
- **Values:** The published values are Players Before Plans, Ship the Patch Not the Promise and Leave the Build Greener. The pack maps your release checklist to the third. For the other two it gives selection scaffolds, because nothing in your message carries a story for them.
- **Strategy:** Project Larkspur moves both titles to a season-pass model with one shared events calendar from February 2027. Several questions and reverse questions are built on it.

The objection to rehearse first is C1, "Which part of this JD would you be weakest at on day one?" Your own message supplies the answers: you have never worked on a game with in-app purchases and have never led a team. The pack coaches you to say those limits plainly and then give a learning plan, without claiming monetization or team-lead experience.

I read Tobias and Project Larkspur from search summaries only. Read his GDC talk, "Patch Notes Are a Promise", and the full Larkspur announcement before Friday.

Say the word and I'll play the Skeptic on C1 so you can drill it live.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did the recruiter tell you anything about what the Outage Hour covers?
Do you want a deeper research pass on Saltmarsh and Tobias, which is up to 6 more searches and 2 more fetches and takes several more minutes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations. The pack assumes he is the hiring manager the careers page describes. That is unconfirmed.
**Interview:** Friday, 60 minutes. The pack assumes this is the "Outage Hour" the careers page describes. That is also unconfirmed.

### What this loop is

| Fact | Detail | Provenance |
|---|---|---|
| Loop shape | A recruiter call, then the Outage Hour: a single 60-minute interview with the hiring manager. No take-home | [grounded] saltmarshgames.com/careers/interviewing, fetched |
| Outage Hour content | A live-incident tabletop on a simulated outage during a live event, then a values conversation | [grounded] saltmarshgames.com/careers/interviewing, fetched |
| Published values | Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener | [grounded] saltmarshgames.com/values, fetched |
| Current strategy | Project Larkspur, announced September 2026: Tidepool Tactics and Lantern Row move to a season-pass model with one shared events calendar from February 2027, and per-title event teams are retired in favour of a single live-ops group | [grounded] saltmarshgames.com/news/project-larkspur, search snippet only |

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script. Every sentence about your past comes from your own message, quoted in the Provenance column. Where the pack could not say more without inventing it, you get an answer slot instead: an instruction for the interview, with an honest second branch.

Question IDs use letters A to E and G. F is reserved for the fit-snapshot rows.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your experience survives scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company's strategy and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

## Prep triage (Tuesday to Thursday)

1. Rehearse the tabletop aloud: A1 to A3, twice each. The first fifteen minutes of an incident are a structure to say out loud, not a story to remember.
2. Make C1 boring. It is the objection this pack expects in some form. Then C2 and C3.
3. Find real stories for B1 to B5. If no time comes to mind for one, rehearse the honest branch instead.
4. Read the full Project Larkspur announcement and Tobias's GDC talk. The pack saw only short summaries of both.

Everything else is insurance.

## Fit snapshot

The posting you shared states no term of the kind that works as a gate (location, pay, schedule, credential), so there are no gate rows. The 3+ years line is an experience requirement and is graded as one.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | discovery | Your material gives the years and the title, and does not say the game ran as a live service. Words: "I spent four years as an associate producer at a puzzle-game studio." Answer slot: the live-service line makes a probe likely. If the title ran as a live game with ongoing updates, say so in your own words; if it did not, or you are unsure how to put it, say so plainly and stay with the weekly drops you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but nothing inspected behind it, so expect a probe. Lead with it in its own terms: weekly, the main title, two years |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your quote carries content drops for one title, and the JD names live events for two. Words stay at the quote's scope: "I ran the weekly content-drop calendar for our main title." Answer slot: if any drop was an in-game event rather than a content release, say how it was planned; if the drops were not events, or the calendar covered one title only, say so plainly and stay with that calendar |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show which teams the weekly drops involved. Answer slot: if you coordinated any of design, art, engineering or community on a drop, say which and what the coordination was, in your own words; if you did not, or some of those teams were not part of it, say so plainly and return to the calendar you ran |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your quote says you presented monthly retention numbers, which is not the same as reviewing events or owning KPIs. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers went in, or what followed from them, say so in your own words; if the numbers were set by others, or no review followed, say so plainly and stay with presenting them |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | none | No gap, but the quote says wrote, and the JD says manage. Lead with the quote's terms: you wrote it, and QA still uses it. Answer slot: if you ran the checklist release by release, say how; if QA ran it and you wrote it, say so plainly |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | The quote reaches the requirement in role terms. It says you presented the numbers, not that you built them. Lead with the quote's own words, and expect a probe on how they were counted |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | A written document that others still use is the evidence, and it needs no more than its own words: "I wrote the release checklist our QA team still uses." A copy of it, with identifying details removed, would be the inspectable artifact |

## Prohibited claims

Built before the question banks. The banks are written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Four years producing a live-service game | Inflated form of F1 | F1's quote at its own scope. The pack's observation is that your material says associate producer at a puzzle-game studio, and does not say live-service. B-bank and G2 slots stay inside that |
| Ran live events across two titles | Inflated form of F3 | F3's quote at its own scope. The pack's observation is that your material says content drops for one title |
| Led or managed design, art, engineering or community teams | Negative you stated, quoted in C2 | The plain acknowledgment your sentence gives: "I haven't led a team." No slot |
| Has worked on a game with in-app purchases | Negative you stated, quoted in C1 | The plain acknowledgment your sentence gives: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan and never as a past. No slot |
| Owned the post-event review or the KPIs it reports | Inflated form of F5 | F5's quote at its own scope. The pack's observation is that your material says presenting the numbers |
| Managed QA or ran the release process | Inflated form of F6 | F6's quote at its own scope. The pack's observation is that your material says wrote the checklist |
| Built or analysed the retention numbers | Inflated form of F7 | F7's quote at its own scope. The pack's observation is that your material says presented |

## Reading the interviewer

Public professional footprint only. Both facts below come from a search snippet. The talk itself was not fetched.

| Item | Detail | Provenance |
|---|---|---|
| Role | Head of Live Operations at Saltmarsh Games | [grounded] GDC 2026 talk listing, search snippet |
| Earlier path | Previously a QA lead at a console studio | [grounded] GDC 2026 talk listing, search snippet |
| Published argument | In the talk "Patch Notes Are a Promise", a live team is judged by how often its patch notes describe what actually shipped | [grounded] GDC 2026 talk listing, search snippet |
| Implication 1 | Expect your claims to be checked against what you actually did. Keep each one the size of the sentence it rests on. A prober's follow-up (D1 to D3, E2) will test exactly that | [inferred] from the talk's argument and the Ship the Patch Not the Promise value |
| Implication 2 | B2 is a likely place the values conversation touches his own theme, announcement versus what shipped | [inferred] from the talk's argument and the values page |
| Implication 3 | His QA background makes the release checklist (F6) a likely place for detail probes | [inferred] from his earlier path |
| Mirror opportunity | Shared vocabulary only, never a shared path: QA and release checklists. Your sentence to use is "Wrote the release checklist our QA team still uses" (F6) | [inferred] pairing his path with F6's quote |

## Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | The tabletop: a live-incident exercise on a simulated outage during an event | Highest. Hiring-manager prior is Case plus Skeptic. The loop source names the tabletop as half the hour | Clarify, then objective, then segment, then approach, then metrics and risks. Think aloud. Challenge one premise politely |
| B. Values/Behavioral | The second half of the Outage Hour, a values conversation built on the three published values | High. The loop source documents a values conversation, so this persona is guaranteed this session | Map a story to each value where your own sentences carry one. Where none does, use the honest branch. "We" for context, "I" for contribution |
| C. Skeptic | Probes the gaps: no leading a team, no in-app-purchase game, one title against two | Mid-high. Hiring-manager prior. Gaps you stated yourself make these questions near-certain | Rehearse the single most predictable objection (C1) until it is boring. Bridge only from what you stated. State the limit before it is asked for |
| D. Data-Driven Prober | Reads claims line by line against what actually happened | Mid. His published theme (claims versus what shipped) and QA background tilt him toward verification | Know how each thing you say was done and what was yours. Say plainly when you do not know |
| E. Pressure/Stress | Time-boxed or devil's-advocate challenges, possibly inside the tabletop | Low. No source says the loop is built to stress candidates, but a tabletop carries time pressure | Pause, restate, hold the position through two follow-ups, then concede specifically |
| G. Conversational/Rapport | Opening biography and a casual take on the company's direction | Low. Opening minutes of almost any interview, still scored | A pre-built 90-second arc from your own sentences. Treat casual questions as scored |

The Peer Evaluator is not weighted. The loop source puts you with the hiring manager. If Tobias turns out to be a peer or the skip-level, the weights change.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A weekend event started an hour ago and players are reporting they cannot claim the reward. Walk me through your first fifteen minutes, and tell me what the first player message says." | CASE | [generic] | Clarify first: what is broken, for whom, since when, and whether it is spreading. Then who decides whether to pause the event, and who you need in the room across design, art, engineering and community. Then the first message: say what you know, say what you are doing, and promise no fix time you cannot back. Keep a running timeline for the post-event review. The question needs no claim about your past, so the guidance makes none | Live incident, the format the loop source names for the tabletop. F4 and F8 are the rows it exercises: coordination across teams and clear writing under pressure. Scenario details are generic because the real scenario is unknown |
| A2 | "Engineering says the fix is four hours out, and the event's biggest reward day starts in two. What do you decide, and what do you tell players?" | CASE | [grounded] | Lay out the options (pause, extend, compensate, run degraded) and the information each needs. The published value says "when the calendar and the players disagree, the players win", so say which option puts players first and what it costs the calendar. Say what you would tell players and when. Make no claim about your past | The company's first published value applied to a decision. F3's calendar requirement is where this decision lives |
| A3 | "Day-7 retention for players who joined during the last event is 20% below the previous event's joiners. What do you check first?" | CASE | [generic] | Clarify definitions first: which cohorts, what counts as joined, how retention is counted. Then segment: new versus returning, platform and version, acquisition source, whether the outage or a failed reward claim overlapped. Then name the next two checks and the decision each would change. The question needs no claim about your past, so the guidance makes none | Retention diagnosis is a live problem in this role. F5 and F7 are the rows it exercises |
| A4 | "From February 2027 two titles share one events calendar. How do you decide what runs when, and what do you need to know first?" | CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start from the calendar you ran, at its scope: weekly drops, the main title. Then reason aloud about what changes with two titles: audience overlap, collisions, shared capacity, who can say no to an event, and how a clash is resolved. Say what you would ask first rather than assuming the answers | The company's published direction turned into a planning problem. F2 is your starting point and F3 is the stretch beyond it |
| A5 | "The events now serve a season pass that players have paid for. What changes in how you plan and review an event?" | CASE | [generic] | Think from the player's side: what the pass promised, what happens when an event breaks, and how a failed event is made right. Then the review: which measures matter beyond retention, and who owns each definition. Mark where you would need data from the people who run monetization. Make no claim about your past | The season-pass model is the company's stated direction. F5 and F7 meet the monetization side here |

### B. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the plan and the players disagreed, and which one won." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Selection scaffold: pick a time when something you ran on a schedule and something players experienced pulled apart. It needs a named decision, what it cost the plan, and what players got. Tell it in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry (the weekly calendar you ran), or how you would handle it | Players Before Plans, the first published value. F2 supplies the calendar side, and the story itself must come from you |
| B2 | "Tell me about a time what shipped was different from what was announced." | VAL | [generic] | Selection scaffold: choose a real occasion with a named difference between what was said and what was built, what you did about it, and what was said afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Ship the Patch Not the Promise, and the theme of the interviewer's own talk. No quoted sentence of yours carries this story |
| B3 | "Tell me about a time you changed a process after a release went wrong. What was different afterwards?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on the beats your sentence states: you wrote the release checklist, and QA still uses it. Tell those in your own words. Answer slot: if the checklist changed after a release problem, say what changed and who decided; if it did not change that way, or the change was not yours, say so plainly and stay with writing it | Leave the Build Greener names the checklist directly. F6 is the evidence |
| B4 | "When have you told design, art or a stakeholder that something was not ready to ship?" | VAL | [generic] | Selection scaffold: pick a time with a named request, a reason tied to what was or was not ready, and a working relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests the checklist value and the coordination line of the JD together. F4 is the row it presses on |
| B5 | "Tell me about a time you delivered an unwelcome truth to leadership about the numbers." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold, with the nearest thing your material carries: you presented the monthly retention numbers to the studio head. The story needs a number that was bad news, what you said, and how it landed. If no such time comes to mind, say so plainly and stay with presenting the numbers | A standard values probe pointed at the metrics you reported. F5 and F7 are the rows |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "Presented the monthly retention numbers to the studio head"; "I ran the weekly content-drop calendar for our main title for the last two years" | **Highest-ROI prep in the pack.** Pick the weakness that is true and say it first: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: ask for the last few post-event reviews, ask which measures a pass event reports and who owns each definition. Choose steps you would actually take. Then what you do carry, in the quotes' own words: the calendar you ran and the retention numbers you presented. Follow-up 1, "How long until you are fluent?": give a real estimate or say what you would ask. Follow-up 2, "That is a big gap for a season-pass role": restate the limit, concede that you will not know the pass's economics on day one, and return to the plan. Never claim monetization intuition | This objection arrives in some form, and F3, F5 and F7 are the rows it presses on. It gets the most follow-up levels because the limit is stated in your own message |
| C2 | "This role coordinates design, art, engineering and community on every update, and you have never led a team. How do you get a senior engineer to move for a live event?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases"; "Wrote the release checklist our QA team still uses" | Say the limit first: "I haven't led a team." Then answer how you would do it without authority: a clear ask, a deadline tied to the event, and a written checklist others can follow. Answer slot: if you coordinated any of those teams on a drop, say which and how; if you did not, or it was not yours, say so plainly and stay with the checklist you wrote. Do not describe coordinating as leading | The JD's coordination line meets a negative you stated. F4 is the row |
| C3 | "You ran one title's calendar. We are moving two titles to one shared calendar in February. Why is that a step you can take?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the quote at its scope: one title, weekly drops, two years. Concede what is new: a second title and a shared calendar. Then your approach to collisions and audience overlap, as in A4. Answer slot: if you ever planned around another team's or title's schedule, say how; if not, say so plainly and stay with the calendar you ran | Tests whether you inflate one title into two. F3 is the row |
| C4 | "Why this role, and why now?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | The reason has to be yours, and the pack will not supply it. Give it in your own words and tie it to something the JD lists: the events calendar across two titles, or owning the post-event review. Avoid running down your current studio | A motivation probe aimed at consistency. F1 is the career fact it stands on |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through one weekly content drop, from plan to live." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | Story-mapped on the beats your sentences state: a weekly drop on the main title, a calendar you ran, and a checklist QA still uses. Tell one real drop in your own words. Answer slot: if design, art, engineering or community had to be ready before a drop, say how you tracked it; if they did not, or you did not track it, say so plainly and describe the drop as it happened | The most likely EXP probe. F2, F4 and F6 are the rows |
| D2 | "How were the monthly retention numbers you presented defined, and what did they not tell you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what the numbers were in your own words, at the day and cohort definition you know. If you do not know how they were counted, say so plainly. Name the assumption behind them you would defend least before the interviewer does. Say which part of the analysis was yours and which was not | The defend-the-number question for your one metric. F5 and F7 are the rows |
| D3 | "What on that calendar was your call, and what was decided around you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: if you set the order or timing of drops, say how you decided, in your own words; if others set it, or it followed a fixed schedule, say so plainly and describe how you ran it | The attribution-honesty probe. F2 and F3 are the rows |

### E. Pressure/Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses" | Pause, restate the question, then answer in what your sentences carry: you ran a weekly calendar and wrote a checklist QA still uses. Hold that through two follow-ups by returning to those facts, never by adding to them. If pushed on the in-app-purchase gap, concede it specifically and move to the plan from C1 | Tests composure and holding a position without inflation. F2 and F6 are the evidence |
| E2 | "How much of that checklist was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold the quote: "I wrote the release checklist our QA team still uses." Answer slot: if others contributed or reviewed, say who and what; if you wrote it alone, say that; if QA changed it later, say so plainly. Do not describe it as a process you designed | Attribution under pressure. F6 and F8 are the rows |

### G. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc built only from these four sentences, in order: the role, the calendar, the checklist, the retention numbers. Add one clause of your own on why this role, in your own words. Stop there | The opener that is still scored. F1, F2, F6 and F7 are the rows |
| G2 | "Tell me about the main title you worked on, and how it ran as a live game." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Answer slot: if the title ran as a live game with ongoing updates, say how, in your own words, and what the weekly drops were within that. If it did not, or you would not call it live-service, say so plainly and describe how the title was updated | Probes the 3+ years live-service line. F1 is the row |
| G3 | "What have you seen of where Saltmarsh is heading with its two mobile titles?" | CO | [grounded] | Say what you read, from Project Larkspur: the move to a season-pass model, one shared events calendar from February 2027, and one live-ops group. Then one question you would want answered and what it means for the role. Do not claim inside knowledge, and read the full announcement first, since the pack saw a summary only | A CO question drawn from the company's own announcement. No claim about your past is made |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1: 3+ years producing live-service games or apps | G2, G1, C4, E1 |
| F2: experience running a content calendar | D1, D3, C3, E1, G1, A4 |
| F3: plan and run the live-events calendar for two titles | A4, C3, A2 |
| F4: coordinate design, art, engineering and community | C2, D1, A1, B4 |
| F5: own the post-event review and the KPIs | D2, A3, B5, C1 |
| F6: manage the release checklist with QA | B3, E2, D1, C2 |
| F7: comfortable with player-retention metrics | D2, A3, B5 |
| F8: clear written communication | A1, B2, E2 |

## Values cheat sheet

| Value (official name) | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Players Before Plans | When the schedule and the players conflict, the players decide | F2: "I ran the weekly content-drop calendar for our main title for the last two years" carries the calendar side only. Selection scaffold for the story: a named moment players pulled against it, what it cost the plan, what players got. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quoted sentence of yours carries this. Selection scaffold: a real occasion with a named gap between what was said and what shipped, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Leave the Build Greener | Every release leaves the code and the checklist better than it found them | F6: "Wrote the release checklist our QA team still uses" carries the beats you wrote it and QA still uses it. Answer slot: if it changed after a release, say what and why; if not, say so plainly and stay with writing it |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argues that patch notes are a promise. Where in an event cycle does someone check the notes against what actually shipped, and who owns that check?" | Ties to his own published argument and shows you read it. Read the full talk first, since the pack saw only a summary |
| R2 | "You came into live ops from QA. What did that background change about how you run releases, and what would you want a producer here to do differently from one who came up another way?" | Ties to his own career path and turns the hour into a conversation between two people who know the release checklist |
| R3 | "Project Larkspur moves the two titles to one events calendar from February. Does this role sit in the single live-ops group, and what does the first shared calendar look like?" | Shows you read the announcement and tests where the role actually sits. The pack's reading of the JD's two titles is an inference, so ask it as a question |
| R4 | "What does the current post-event review report, and what would you want changed in it in the first quarter?" | Aims at the JD's ownership line and the first thing you would be doing |
| R5 | "How do new producers get up to speed on the monetization side of the event measures here?" | Names the gap as a learning plan before anyone else has to |
| R6 | "What would you want me to have shown you this hour that we have not covered?" | Closes the slot with a real question instead of "I think you've covered everything" |

## Sources

Provided documents: the JD text and your background message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and B bank. Three values by name, from the fetched official page |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop structure: the Outage Hour, a tabletop then a values conversation. Persona weights and A bank follow it. Fetched from the official careers page |
| 3. `Saltmarsh Games strategy news` | yes | A4, A5, G3 and R3. Read from the search snippet only. The fetch budget went to targets 1 and 2 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | Interviewer read, R1 and R2. Read from the search snippet only |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Searches sent, with what came back:

| Query | Returned |
|---|---|
| Saltmarsh Games values | saltmarshgames.com/values |
| Saltmarsh Games interview process live operations producer | saltmarshgames.com/careers/interviewing |
| Saltmarsh Games strategy news | saltmarshgames.com/news/project-larkspur |
| Tobias Wrenfield Saltmarsh Games | talks.gdconf.example/2026/patch-notes-are-a-promise |

Fetches sent: saltmarshgames.com/values and saltmarshgames.com/careers/interviewing, both read in full.

## Upgrade menu

- Whether Tobias is the hiring manager or someone above your would-be manager, and anything the recruiter told you about the Outage Hour → persona weights reset against the real round, and the A bank written against the real scenario instead of generic patterns
- Your answers to the slots in F1, F3, F4, F5 and F6 → those rows become quoted evidence, and the C, D and G banks regenerate against them
- A copy of the release checklist, the weekly calendar or a retention report, with identifying details removed → F6, F8 and F2 can move from medium to high, since those are the artifacts this field keeps
- The full text of the Project Larkspur announcement and of Tobias's GDC talk → A4, A5, G3, R1 and R3 move from summary-level to quoted
- A tuesday-dossier.md from a job-underwriter review of this role → graded evidence and an absolute prohibited-claims list from that review, folded into this pack
