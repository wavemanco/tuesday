Your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-7-canned-8a4d8f94/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager round, assuming Tobias is your future manager.

Say the word and I'll play the Skeptic on C1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you would report to, or someone else on the loop? The answer reweights every bank.

Has the recruiter said anything about what the tabletop covers, such as which title or who plays the other side? Anything you have restructures the Case bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Candidate: Femi. Interviewer: Tobias Wrenfield, Head of Live Operations. Round: hiring-manager round, 60 minutes. This pack assumes Tobias is your future manager; if he is not, the persona weights below change.

## How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only what you actually did.

Provenance labels: `[grounded]` rests on your words, the JD or cited research. `[inferred]` is a derivation, named. `[generic]` is a pattern for rehearsal with no claim about you or Saltmarsh.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior demonstrates Saltmarsh's published values |
| EXP | Whether your experience survives scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, including its gaps |
| CO | Whether you can think at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message; "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [inferred] | discovery | Your material gives four years as an associate producer and two years on a weekly content-drop calendar, and does not say whether the title was a live-service game. Answer slot: the JD's live-service line makes a probe on that likely. If the main title was updated continuously after launch, say so in your own words; if it was not, or you are not sure, say so plainly and stay with the calendar you ran |
| F2 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | The words stay at one title: "For the last two years I ran the weekly content-drop calendar for our main title." Your material says weekly drops on one title, not events and not two titles. Answer slot: the JD's live-events line makes a probe on whether any drops were timed events likely. If some were, say how you scheduled them; if none were, or the schedule was not yours to set, say so plainly and describe the drop calendar you ran |
| F3 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap, but a claim with nothing inspected behind it, so expect a probe. Lead with it in its own terms: the weekly content-drop calendar, for your main title, for the last two years |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message; "Never led a team, and never worked on a game with in-app purchases." — your message | low | [inferred] | discovery | The calendar line touches coordination without showing it, and your material names none of design, art, engineering or community. Answer slot: the JD lists four teams per update, so expect a probe on each. If you worked with any of them on a drop, say which and what that involved, in your own words; if none, or someone else coordinated, say so plainly and stay with the calendar. On leading, your own sentence gives the words: "I haven't led a team." Never a claim to have directed anyone |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | The words stay at presenting: "I presented the monthly retention numbers to the studio head." Your material says presenting, not owning a review or setting the KPIs. Answer slot: the JD's own-the-review line makes a probe likely. If you chose what went into those numbers or wrote up what they meant, say how, in your own words; if the numbers were handed to you or the review was not yours, say so plainly and stay with presenting them |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | Lead with the checklist in the quote's terms: you wrote it, and your QA team still uses it. A named record beats an adjective. The words stay at wrote and still uses, because your material does not say you ran each release against it |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. Expect a probe on how retention was counted, rehearsed in D1 |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | low | [inferred] | discovery | A checklist is writing, but the quote does not show whether it was clear or who read it. Answer slot: the JD asks for clear written communication, so expect a request for an example. If you have another written piece others relied on, name it in your own words; if not, say so plainly and point to the checklist, which your QA team still uses |
| F9 | In-app-purchase familiarity for mobile titles: the pack's inference from the JD's mobile-title and KPI wording; the JD does not state it | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |

No row is a hard gate: the JD's years requirement is experience, not a credential or legal bar.

## Reading the interviewer

| Public fact | What it means for you | Provenance |
|---|---|---|
| Tobias Wrenfield is Head of Live Operations at Saltmarsh Games, and gave a GDC 2026 talk, "Patch Notes Are a Promise", arguing a live team is judged by how often its patch notes describe what actually shipped | Expect answers to be weighed against what was actually delivered. Say what is known and what is not, as in A1 and A4 | [grounded] |
| The same talk page describes him as previously a QA lead at a console studio | A release checklist and a QA relationship will be heard by someone with QA in his path. Describe yours in its own terms, as in B3 and F2 | [grounded] |

Mirror opportunity: shared vocabulary, not shared identity. Your own sentence about the checklist, from F6, is "Wrote the release checklist our QA team still uses." Use it as written; do not stretch it to match his path.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | The tabletop: a live problem on a simulated outage during an event | High. The loop page describes a live-incident tabletop with the hiring manager, and the hiring-manager prior favours this persona | Clarify, state the objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Values / Behavioral | The values conversation after the tabletop | High. The loop page names a values conversation, and the values page publishes three values by name | Map a story to each value where one of your sentences carries one; a selection scaffold where none does; "we" for context, "I" for contribution |
| C. Skeptic | Probing the gaps you have named: in-app purchases, leading a team, four-team coordination | Medium. Hiring-manager prior, plus F4 and F9 where you stated the gap | Rehearse the single most predictable objection until it is boring; bridge only from what you stated; say the limit plainly |
| D. Data-Driven Prober | Retention numbers, KPIs, how a figure was counted | Medium. The JD names KPIs and retention metrics, and F5 and F7 rest on one sentence | Know what you can and cannot say about how the numbers were counted, and say so when you do not know |
| E. Conversational | The opener and the casual question about what you play | Low. Round-type prior for a hiring manager is small, but casual questions are still scored | A 90-second arc built from your own sentences |
| F. Pressure | Time-boxed or devil's-advocate challenges inside the tabletop | Low. No source says this interviewer interrupts; a tabletop is time-pressured by design | Pause, restate, hold through two follow-ups, then concede specifically |
| Peer Evaluator | Not banked | The loop page puts the interview with the hiring manager; if Tobias is a peer, tell me and the banks change | Not applicable |

## Question banks

Type holds one token; the rationale explains any second reading. Highest-ROI prep in this pack: C1.

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, A5, D3 |
| "coordinate design, art, engineering and community teams on each update" | A1, A2, C3 |
| "own the post-event review and the KPIs it reports" | D2, D3 |
| "manage the release checklist with QA" | A2, B3, F2 |
| "3+ years producing live-service games or apps" | C2, E1, F1 |
| "experience running a content calendar" | A5, D3, F1 |
| "comfortable with player-retention metrics" | D1, D2 |
| "clear written communication" | A4 |

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The servers drop forty minutes into a live event and the event timer keeps running. You are the producer on call. What happens in the first fifteen minutes?" | CASE | [generic] | Clarify first: what is down, for which players, since when, and whether progress or rewards are being lost. State the objective in a sentence. Then segment the fifteen minutes: who you pull in (the JD names design, art, engineering and community), what each is asked for, and when players get the next update. Name one risk and one thing you will not promise yet. You have not told me of an outage you handled, so answer as a plan, not a past; if you have lived through one, say so in your own words | The loop page documents a tabletop on a simulated outage during a live event; this is a pattern for it, not its content. F4 is the requirement it presses on |
| A2 | "A hotfix is ready for the live event and engineering wants to skip part of the release checklist. QA says no. What do you do?" | JD | [generic] "Wrote the release checklist our QA team still uses." | Ask what the skipped part protects against and whether a narrower check covers it. State the principle before the call: what players are exposed to if it ships unchecked, against what a delay costs them. Make the call, say what would change it, and say how the exception gets recorded so the checklist is better afterwards. On yourself, say only what the quote says: you wrote the checklist your QA team still uses, and no more | JD content (the checklist-with-QA line, F6) delivered as a CASE. The tabletop is likely to test it, and the Leave the Build Greener value lives here |
| A3 | "The event ends in six hours and the outage has already cost players a third of it. What do you do about the end date?" | CASE | [generic] "I ran the weekly content-drop calendar for our main title for the last two years." | Ask who lost what, then lay out the options (extend, compensate, leave) with what each does to the next item on the calendar. Decide, and say what would change your mind. The published value Players Before Plans says players win when calendar and players disagree. You may say you ran a weekly drop calendar, as quoted; the quote does not say you ever moved a date, so do not | F2 is the calendar requirement this tests. CASE because it asks nothing about your past |
| A4 | "Write me the first message players see about the outage. What does it say, and what does it leave out?" | JD | [generic] | Say it aloud in thirty seconds: what is known, what is not, and when the next update comes. Leave out any fix time you cannot stand behind; the published value Ship the Patch Not the Promise says to announce what is built, not what is hoped | JD content (clear written communication, F8) delivered as a live task. It also tests the value the interviewer's talk is about |
| A5 | "Project Larkspur puts Tidepool Tactics and Lantern Row on one shared events calendar from February 2027. Where would you start planning it?" | CO | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first: which titles, how the season-pass cadence sets event slots, and who decides when two titles want the same week. Then objective, segmentation by title and player group, approach, metrics, risks, with collisions between titles as the main risk. Start from your own words: you ran the weekly content-drop calendar for your main title. That is one title and drops, so say what changes with two, as a plan | The strategy item comes from Saltmarsh's own news page, cited in Sources. F2 and F3 are the rows it draws on; whether this role is the Larkspur role is a reverse question |

### B. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time what players were doing or saying changed your plan." | VAL | [generic] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick a time a plan, date or calendar moved because of what players experienced; it needs a named stake, what you chose and what followed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the calendar quoted here, or how you would handle it | Players Before Plans is a published value, so it gets a question. Your material carries a calendar, not a story, so this is a scaffold |
| B2 | "Tell me about a time you were asked to announce something before it was built." | VAL | [generic] | Pick a time you held an announcement back or corrected one; it needs the pressure to announce, what you did, and what players or colleagues saw after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. See the interviewer read for why this value matters to him | Ship the Patch Not the Promise is a published value and the theme of the interviewer's talk. No quoted sentence carries a story, so this is a scaffold |
| B3 | "Tell me about a time you left a process or a checklist better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | Story-mapped on F6: you wrote the release checklist, and your QA team still uses it. Those are the beats the quote states; tell them in your own words. Answer slot: the Leave the Build Greener value says each release leaves the checklist better, so expect a probe on whether it changed after later releases. If it did, say what changed and why; if it has not changed, or the changes were not yours, say so plainly and stay with: you wrote it and QA still uses it | Leave the Build Greener names the checklist, and F6 is your one quoted sentence that fits it |
| B4 | "Tell me about a time you had to tell leadership something they did not want to hear." | VAL | [generic] "Presented the monthly retention numbers to the studio head." | The quote gives a setting, presenting to the studio head each month, and does not say any number was unwelcome. Pick a time the hard truth landed and the relationship held. If none comes to mind, say so plainly, then give the nearest thing your material does carry, the monthly presentation as quoted, or how you would handle it | A standard values probe from the persona stems, not a published value. F5 is the nearest row, and it supplies no ending |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have told me you have never worked on a game with in-app purchases. How would you handle that in this role?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | The highest-ROI rehearsal in this pack. Say the plain acknowledgment first, in your own words: "I haven't worked on a game with in-app purchases." Then give your learning plan as a plan: what you would ask for in the first weeks and from whom. Hold through two follow-ups by returning to your own work at its own scope: you ran the weekly content-drop calendar for your main title. Concede the gap specifically each time; never reach for adjacent knowledge you have not stated | F9 is the gap you named, so this objection arrives in some form. JD because it scores a mobile-title requirement the pack infers |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Choose honestly from your own material; F4 and F9 are the candidates. Say it plainly, then say your first step. If you pick leading, the words are "I haven't led a team." Do not name a weakness to look modest | A near-certain skeptic stem, aimed at F4 and F9 |
| C3 | "You have never led a team, and this role coordinates design, art, engineering and community on every update. How do you get four groups moving?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Never led a team, and never worked on a game with in-app purchases." | Open with the acknowledgment: "I haven't led a team." The JD says coordinate, not manage; say how you would work without authority, as a plan. Answer slot: if you worked with any of those groups on a drop, say which and what that involved, in your own words; if none, or someone else coordinated, say so plainly and stay with the calendar you ran | F4 is the row, and the candidate-stated negative is its source |
| C4 | "You have spent four years at a puzzle-game studio. Why live operations on mobile, and why Saltmarsh?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Three short reasons in your own words: what pulls you, what specifically about Saltmarsh, why now. Your reasons are not in my material and this pack supplies none. Saltmarsh's published values and its shared-calendar plan are public things you may refer to | F1's thin bridge asked as motivation. EXP because it tests whether your story survives cross-examination |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you can about how each number was counted; name the assumption you would defend least; say what part was yours. Answer slot: if you defined or calculated them, say how, in your own words; if they were supplied to you, or you do not know how they were counted, say so plainly and stay with: you presented them to the studio head | F5 and F7 rest on this one sentence, so a prober starts here |
| D2 | "In a post-event review, which numbers would you report first, and which would you leave out?" | JD | [generic] "Presented the monthly retention numbers to the studio head." | Structure it: the question the review answers, the retention measures that answer it, what you cannot yet say and how you would say so. You have told me only that you presented the monthly retention numbers; do not describe a review you ran | JD content (post-event review and KPIs, F5), asked as a decision rather than a record |
| D3 | "What would tell you a weekly drop had worked?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what you would measure first and why. Answer slot: if you had a measure on your own drops, say what it was and who chose it; if you did not, say so plainly, and say what you would measure first | F2 and F3 are the calendar rows; the JD's KPI line raises the probe |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc, in order, each beat a clause from your own sentences: four years as an associate producer at a puzzle-game studio; two years running the weekly content-drop calendar for your main title; the release checklist your QA team still uses; the monthly retention numbers you presented to the studio head. Close with your own reason for Saltmarsh | The opener is scored. F1, F3, F5 and F6 are the rows the arc uses |
| E2 | "What are you actually playing in live ops these days?" | JD | [generic] | Name one live game you actually play and one thing its events do that you would copy and one you would not. If you do not play one, say so plainly and name one you have studied | A casual question about a hot JD topic, still scored |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you, over a producer who has run live events across two titles with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Never led a team, and never worked on a game with in-app purchases." | Pause and restate. Hold on what is yours at its own scope: you ran the weekly content-drop calendar for your main title, and you wrote the checklist your QA team still uses. Concede the rest plainly: "I haven't worked on a game with in-app purchases." Hold through two follow-ups; never claim two titles | F2 and F9 are where a pressure interviewer leans; the rival is hypothetical and carries no claim about you |
| F2 | "The checklist: how much of that was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Pause, restate, then hold at the quote: you wrote it, and your QA team still uses it. Say what part was yours, and if others shaped any part, say who and how; if you wrote it alone, say so plainly. Concede only what you can name specifically | An attribution probe aimed at F6, the row most likely to be tested |

## Values cheat sheet

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | None carried by your sentences: selection scaffold in B1, ending in its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | None carried by your sentences: selection scaffold in B2, ending in its honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F6: "Wrote the release checklist our QA team still uses." |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your GDC talk argues a live team is judged by how often its patch notes describe what actually shipped. How is that measured here, and what would I be accountable for on it?" | Ties to his own talk, and tells him you read it |
| R2 | "You came to live operations from QA. What did that change about how you run a release?" | Ties to his own path and invites the checklist conversation |
| R3 | "Project Larkspur moves two titles to one shared events calendar from February 2027. Is this role the one that plans it, and are the two titles in the JD those two?" | Turns a public announcement into a question about the role |
| R4 | "How is the post-event review used: who reads it, and what has changed because of one?" | Shows you think of the review as a decision input |
| R5 | "What do people who do well in their first ninety days here do differently?" | An ordinary strong closer that gets a concrete answer |
| R6 | "For someone coming from a puzzle title without in-app-purchase experience, what would you want them to learn first?" | Owns the gap from F9 before he raises it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led the design, art, engineering or community teams | Negative the candidate stated, F4 | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or owned monetization numbers | Negative the candidate stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran the live-events calendar for two titles | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says one title and content drops. C1 and F1 stay inside it |
| Owned the post-event review and its KPIs | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says presented, not owned. D1 stays inside it |
| Ran QA sign-off for each release | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says wrote and still uses. F2 stays inside it |

## Sources

Provided: the JD as pasted, and your background as stated in your message. No dossier was present.

Searches sent, with what came back:

- "Saltmarsh Games values": https://saltmarshgames.com/values
- "Saltmarsh Games interview process live operations producer": https://saltmarshgames.com/careers/interviewing
- "Saltmarsh Games mobile studio strategy news": https://saltmarshgames.com/news/project-larkspur (the search result's text only; the page was not fetched)
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": https://talks.gdconf.example/2026/patch-notes-are-a-promise (the search result's text only; the page was not fetched, and the QA-lead fact comes from that one result)

Fetches sent: https://saltmarshgames.com/values and https://saltmarshgames.com/careers/interviewing, both read in full.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet and the three VAL questions, by official name |
| 2. `Saltmarsh Games interview process, live operations` | yes | The loop: one 60-minute hiring-manager session, a tabletop then a values conversation; persona weights follow it |
| 3. `Saltmarsh Games strategy` / recent news | yes | A5 and R3, from the Project Larkspur announcement dated September 2026 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | The interviewer read, R1 and R2, and the theme of B2 |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias is your future manager → persona weights confirmed or rebuilt for a peer or skip-level round
- Anything the recruiter said about the tabletop (which title, who plays the other side, what is scored) → the Case bank moves from `[generic]` to `[grounded]`
- A fuller account of your calendar: whether the main title was updated continuously after launch, whether any drops were timed events, and which of design, art, engineering and community you worked with on a drop → F1, F2 and F4 move from `[inferred]` or a probe-prone slot to `[grounded]` answers
- How the retention numbers you presented were defined, and who chose them → F5, F7, D1 and D2
- The release checklist itself, or a sample week of your content calendar, as the inspectable artifacts in this field → F3 and F6 move from `medium` to `high`
- One more piece of your writing that others relied on → F8 moves from `low`
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → a grounding brief on Saltmarsh's strategy, Tobias's talks and writing in depth, loop reports for this role family, and recent org context
- A `tuesday-dossier.md` from an earlier fit analysis would add user-confirmed evidence, per-gap strategy and a vetted prohibited-claims list; this pack was built without one
