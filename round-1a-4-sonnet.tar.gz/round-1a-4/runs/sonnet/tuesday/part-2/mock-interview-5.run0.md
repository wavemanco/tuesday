Web search wasn't permitted, so the pack runs on your message alone. I'm writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-5-denied-86991b25/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It is built for the Tuesday panel, with Deepa as hiring manager and Ross pushing on commercials.

- **Market report:** I couldn't read it, because it wasn't attached in this session. The differentiation advice in the pack is a method, not content.
- **Web search:** the permission wasn't granted, so all five searches were refused. Nothing in the pack comes from the web, and most research-dependent rows are labeled generic.
- **Job description and CV:** I didn't have either, so the fit rows use the recruiter's words and the background you described.

- **Highest-ROI prep:** C2 is "You haven't sold into rail and you haven't carried a number. Why should we trust you with this?" It has three levels of follow-up rehearsed. B1 and B2, defending the £4M and which part was yours, come second.
- **The 15-minute POV:** section 4 has three thesis options, each with a concession, plus a minute-by-minute timing and the operator close the recruiter asked for. It also suggests stating your rail and quota limit once, early, in your own words.
- **Four-hour schedule:** section 2 sizes the prep blocks to your weekend time.

Say the word and I'll play Ross on C2, with follow-ups that react to what you say. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the job description, your CV and the market report's text, or tell me which to skip?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

Second-round panel, Tuesday, 60 minutes. Deepa, VP Partnerships (your future manager). Ross, Commercial Director. First 15 minutes: your POV on operator partnerships, no slides. Remaining 45: Q&A, with Ross pushing on commercials. Built from your message alone: no job description, no CV and no text of the market report were available, and web research was not permitted, so most research-dependent rows are labeled generic.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer of 90 to 120 seconds, not a script. An answer slot is an instruction for the interview, not a question for you now.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows the company's published values (none in this pack: no values-style round is detected) |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | The stated role: can you do the listed job, including its gaps |
| CO | Company and strategy knowledge, and thinking at the company's altitude |
| CASE | A live problem from the role, scored on structure and reasoning |

## 2. Prep triage (four hours, across the weekend)

| Block | Time | Do this | Section or IDs |
|---|---|---|---|
| 1 | 60 min | Build the 15-minute POV: pick two theses, one consensus item and one divergence from the report, one anti-pick, and write the operator close in your own words | Section 4 |
| 2 | 45 min | Say C2 aloud three times, with someone pushing on it twice. This is the highest-ROI prep in the pack | C1, C2 |
| 3 | 45 min | Defend the £4M aloud: how counted, what it is sensitive to, the assumption you would defend least, which part was yours | B1, B2 |
| 4 | 45 min | Reread the market report and fix your consensus item and divergence | A5, A2 |
| 5 | 30 min | Two timed pressure cases, then choose three reverse questions | A3, D2, section 8 |
| 6 | 15 min | One full spoken run of the POV against a timer | Section 4 |

Everything else in the pack is insurance.

## 3. Fit snapshot

No job description was supplied, so requirements come from the recruiter's own words, quoted, and from role-family prose labeled generic. No requirement here is a gate, as the evidence conventions define one; the job description would settle that.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company, not operator partnerships, and the words stay there: "I took it from 6 partners to 40." Answer slot: the POV ask makes a probe on what carries from channel partners to operators likely. Say in your own words which parts apply; if none do, say so plainly and stay with the channel you ran |
| F2 | "land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning, seen from the other side, and does not say train operating companies. The words stay at that scope: "I spent 5 years in transport consulting, in bus and light rail network planning." Answer slot: if you are asked how train operators differ from that work, say what you can see from it, in your own words; if you cannot say, say so plainly and say how you would find out |
| F3 | "Ross will push on commercials" — recruiter's email | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The figure keeps its words: roughly £4M of influenced revenue. Answer slot: expect probes on how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer each in your own words; where you do not know, say so plainly and stay with influenced |
| F4 | Direct ownership of a commercial number, and rail-specific selling (role-family requirement, generic) | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically, and I haven't carried a direct quota; my revenue was influenced revenue." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | Build and manage a portfolio of partners (role-family requirement, generic) | "last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe on what a partner was in that channel. Lead with the quote's own terms: you took it from 6 partners to 40 |

## 4. Graded deliverable: the 15-minute POV

The recruiter's own words: "First 15 minutes we'd like you to present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it." and "Please land on what it means for the operators themselves."

**Facts you may build on** (each from a fit-snapshot row, quoted exactly):

| Row | Sentence you may use |
|---|---|
| F1 | "took it from 6 partners to 40, roughly £4M of influenced revenue" |
| F2 | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" |
| F4 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue" |

**Thesis options.** These are positions to argue, not facts about Kelverton. Choose two after you have reread the report. Each carries a mandatory concession, spoken aloud.

| Thesis | The position | Mandatory concession | Provenance |
|---|---|---|---|
| T1 | Deepen before you widen: over 18 months, make a smaller set of operator partnerships clearly valuable to the operator before adding more | You have not seen Kelverton's own partnership numbers, and if the existing set is thin, breadth may have to come first | [generic] |
| T2 | Define every partnership by what changes for the operator, and let the commercial terms follow from that | This can sound like deferring commercials, so pair it with the test of how each partnership earns Kelverton revenue, and say you would agree the measure with Ross | [generic] |
| T3 | Make joining repeatable: one clear way for an operator to start, so each new partnership costs less to start | Operators differ, a standard path may fit some badly, and your bus and light rail work does not show it would fit train operators | [generic] |

**Differentiation.** The report is as available to Deepa, Ross and any other prepared candidate as it is to you, and I have not seen it. Bring one item from it that you agree with, in the report's own words, to prove you read it. Then give one thesis-driven divergence with your reasoning, and one anti-pick: something you would not do in the first 18 months. The role includes saying no, so the anti-pick is where judgment shows.

**Requested close: what it means for the operators.** Your last three minutes, in this order, each in your own words:

1. What an operator would notice in their day-to-day work.
2. What we would ask of them in return.
3. How they would know it had worked.

**Timing for 15 minutes.**

| Minutes | Content |
|---|---|
| 0 to 2 | Your position in one sentence, then the one limit said plainly: "I haven't sold into rail specifically, and I haven't carried a direct quota; my revenue was influenced revenue." Name it once, early, so Ross's push lands on a prepared answer |
| 2 to 4 | What you took from the report, and what you do not yet know |
| 4 to 10 | Your two theses, each with its concession |
| 10 to 12 | The anti-pick |
| 12 to 15 | The operator close |

## 5. Persona table

The loop is established by the recruiter's email: one 60-minute panel, 15 minutes of POV then Q&A. No archetype fallback is needed. No values-style round is detected, so the values cheat sheet is dropped. No public profile of either interviewer was available, so weights come from relationship priors and the recruiter's words only. Recalibrate if you know the reporting lines.

| Persona | How it shows up here | Likelihood, with reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Case / Strategist | Deepa, plus the POV itself: clarify, structure, test one premise | High. A future hiring manager prior, and the recruiter's ask is a strategy POV | Clarify, objective, approach, risks; think aloud; challenge one premise respectfully per case | A |
| Skeptic | Deepa probing the rail and quota gap in F4 | High. A hiring manager prior, and F4 is a gap you have stated | Rehearse the one predictable objection until it is boring: "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | C |
| Data-Driven Prober | Ross on the £4M | Medium to high. The recruiter says "Ross will push on commercials", and F3 is a figure | Know how each number was counted and say plainly when you do not | B |
| Pressure | Ross time-boxing a commercial case | Medium. An executive prior, inferred from the recruiter's words and not from any profile of Ross | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real | D |
| Peer Evaluator | Ross on the partnerships and commercial seam | Medium. Inferred from his title, and the reporting line is unknown to me | Reciprocity framing and seam principles, never a pretended map of the seam | E |
| Conversational | Opener and close from either interviewer | Low to medium. Second-round panels still open warmly, and it is still scored | A 90-second arc for the biography question | F |

## 6. Question banks

### A. Case / Strategist (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Before you commit to that plan, what do you need to know about our operators that you don't know yet?" | CASE | [generic] | Clarify aloud before you structure: what operators are being asked to change, what has already been tried with them, and what the market report leaves open. Close by naming the one unknown that would change your plan most. The question needs no claim about your past, so the guidance makes none | A hiring manager's likeliest first follow-up to a POV, and it scores clarify before structure. CASE because it is a live problem on the role |
| A2 | "Which of today's operator partnerships would you stop or shrink in your first 90 days?" | CASE | [generic] | The anti-pick, with the limit said first: you have not seen Kelverton's own numbers. Name the test you would apply instead of a partnership: what the operator gets, what Kelverton earns, what it costs to keep. Say what evidence you would ask for before cutting anything, and concede the answer may be that nothing should stop. Hold the test through one follow-up without naming a partnership you know nothing about | The recruiter's words say "our operator partnerships", and a role that includes saying no is probed on it. CASE because it asks about no past |
| A3 | "An operator's planning director tells you a joint rollout will slip a quarter and their board is asking whether to carry on. You have two minutes." | CASE | [generic] | Restate, then ask first what the slip is and whose it is. Say what you can commit to without Ross and what you cannot, what you would tell the operator today, and what you would record afterwards. Challenge one premise respectfully: whether the slip is the operator's or Kelverton's. Concede what you cannot judge without the contract terms. The question makes no claim about your past | Tests structure and composure on a partnership under strain, in front of the person who would manage you. CASE because it is hypothetical |
| A4 | "In 18 months, what is different for an operator because of your plan, and how would they notice?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | The close the recruiter asked for: "land on what it means for the operators themselves". Give one change an operator would notice, in their terms, and one thing you would ask of them. Where you draw on your past, keep to the quote: 5 years in transport consulting, in bus and light rail network planning. Answer slot: if you are probed on how train operators differ from that work, say what you can see from it, in your own words; if you cannot say, say so plainly and say how you would find out | The recruiter's own instruction, so near-certain. F2 is the evidence and shows its limit. CASE because it is a plan question |
| A5 | "Our strategy team's market report is one input to your plan. Which point would you build on, and which would you challenge?" | CO | [generic] | I have not seen the report, so the pack cannot say what is in it. Treat it as equally available to both interviewers: bring one item you agree with, named in the report's own words from your copy, then one divergence with your reasoning, and say what evidence would change your mind. Never recite its shortlist back as your plan | The differentiation rule for a shared artifact. CO because it tests homework at the company's altitude. Generic because the contents are unseen |

### B. Data-Driven Prober (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how you counted the £4M." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Say the figure as you gave it: the channel going from 6 partners to 40, and roughly £4M of influenced revenue. Then four things in your own words: how it was counted, what it is most sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you know how it was counted, say so; if you do not know, or the counting was not yours, say so plainly and stay with "roughly" and "influenced". Supply no method, baseline or denominator you did not give | F3 is the commercial claim Ross will go to first, and "Ross will push on commercials". EXP because it tests what you can stand behind |
| B2 | "Which part of that £4M would you not claim as yours?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold to the quote's own word: influenced. Answer slot: if you can separate what was yours, say which part and how you know, in your own words; if it cannot be separated, or none of it was yours alone, say so plainly and stay with influenced revenue. Naming what you would not claim before you are asked turns the probe into credibility. Offer no split you did not give | The attribution probe on F3. EXP because it tests what was actually you |
| B3 | "After twelve months, how would you tell whether an operator partnership is working commercially for us?" | JD | [generic] | Structure, not figures: what the operator would need to see to keep it, what Kelverton would need to see, and who owns each measure. Say you would agree the measures with Ross, because you have not seen Kelverton's commercial data. Concede that influenced and direct revenue are different measures, and say which you propose to report here. The question makes no claim about your past | Ross pushing on commercials will test how you think about them without a track record. JD because it scores the stated ask |
| B4 | "What target should a partnerships manager here be held to?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Ask it back first: how are partnership targets set here, and does the role carry a number, an influence goal or both. Then give a position, labeled as a position, with a measure you would accept being held to and one you would not, and why. If the target is a direct number, your words are: "I haven't carried a direct quota; my revenue was influenced revenue." Concede what you cannot judge without Ross's view | The commercial question that meets F4 head on. JD because it scores the stated role |

### C. Skeptic (Deepa)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | Say it plainly first, in the words you gave: "I haven't sold into rail specifically, and I haven't carried a direct quota; my revenue was influenced revenue." Then a ramp plan, said as a plan: who you would sit with first, what you would read, what you would ask for in the first 30 days, each a future action and none a past one. Concede that a plan is not evidence, and say how you would show progress | A persona stem, and F4 is the stated gap. JD because it asks about the listed job |
| C2 | "You haven't sold into rail and you haven't carried a number. Why should we trust you with this?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | The highest-ROI prep in this pack, because some form of this question will be asked. Level one: give the plain acknowledgment from C1, then one sentence kept to the quote: "I took it from 6 partners to 40, with roughly £4M of influenced revenue." Level two, when pushed that influenced is not owned: hold, because influenced is what you claim, and concede the difference between influenced and direct plainly. Level three, when asked what in your record shows you can close: return to the quote, name the limit before they do, then say how you would want to be measured here. Answer slot: if part of the figure was yours, say which part in your own words; if it cannot be separated, say so plainly and stay with influenced. Never move from influenced to closed or owned | F4 is the biggest gap, and the Skeptic is a hiring manager's partner persona. JD because it asks whether you can do the listed job |
| C3 | "You've been in consulting and in payments. Why rail, why us, why now?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "last 4 at a payments company running the ISV channel" | Motivation consistency, and the pack cannot supply your reason. Give three parts in your own words: why rail, why this company in a way you can source, such as a point you read in the report, and why now. If one part is thin, say so plainly and give the part that is true. Keep your history to the quotes: 5 years in transport consulting, and the last 4 years running the ISV channel at a payments company | The standard Skeptic motivation probe, sharpened by a two-sector history. EXP because it tests whether the story survives cross-examination |
| C4 | "Your background is on the consulting side of the operator world. What does that let you see here, and what does it hide?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Hold to the quote's own words: bus and light rail network planning, from the other side. What it lets you see: say in your own words. What it hides: the pack's observation is that your quote says bus and light rail and does not say train operating companies, so say that limit yourself. Answer slot: if you are asked how train operators differ, say what you can see from that work, in your own words; if you cannot say, say so plainly and say how you would find out. Do not describe yourself as having worked inside an operator | F2 is your best fit evidence and shows its limit, so a skeptical manager tests it. JD because it scores the role's operator side |

### D. Pressure (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you rather than someone who has sold into train operators?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Pause and restate the question. Hold on what the quote carries: "I took it from 6 partners to 40, with roughly £4M of influenced revenue." Concede the rail point in your own plain words from C1. Hold the position through two follow-ups and concede only the specific point, never the whole. Compare yourself to no one beyond what you have said | A persona stem, and F4 gives the pressure its edge. JD because it scores the stated job |
| D2 | "An operator says our price is why they won't commit to a joint rollout. You have two minutes." | CASE | [generic] | Ask what they are comparing the price against and what they are really asking for, then say what you can offer without Ross and what you cannot. Hold your structure when interrupted, concede what you cannot decide alone, and say what you would take back to Ross. The question makes no claim about your past | A time-boxed commercial case from the person who will push on commercials. CASE because it is hypothetical |
| D3 | "Name one thing from the payments channel that does not carry over to rail." | EXP | [grounded] "last 4 at a payments company running the ISV channel" | A selection scaffold: pick the one thing your own judgment says does not carry over, with the reason. If nothing comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would find out. Offer no differentiator you cannot defend | A pressure probe of honest self-assessment on F1. EXP because it tests what you actually did |

### E. Peer Evaluator (Ross)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between partnerships and commercial, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than pretending to know the seam: who owns the operator relationship, who owns price, how a disagreement is escalated. Add what you would give commercial in return. Concede that you have not seen how Kelverton splits it today. The question makes no claim about your past | A persona stem, and the seam is where a commercial director judges a partnerships hire. JD because it scores how the role works |
| E2 | "How do you handle credit when a partner deal spans our teams?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue" | A selection scaffold: pick a time credit for revenue had to be shared or split between teams, with a named stake and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is that your figures were "influenced revenue", or how you would handle it here | A persona stem that returns F3's attribution theme in collegial packaging. JD because it scores how the role works |
| E3 | "What do you need from commercial in your first 90 days to do this well?" | JD | [generic] | Reciprocity framing: two or three specific asks, and what you would give back. The question makes no claim about your past | A peer asks what the hire costs their team. JD because it scores how the role works |

### F. Conversational (either interviewer)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So — walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "took it from 6 partners to 40, roughly £4M of influenced revenue"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc in your own words, with only the beats the quotes state: 9 years in partnerships; the last 4 at a payments company running the ISV channel; 6 partners to 40, roughly £4M of influenced revenue; and before that 5 years in transport consulting, in bus and light rail network planning. End on your own reason for this role, which the pack cannot supply | The biography question opens most panels. EXP because it asks you to tell your own history |
| F2 | "What drew you to Kelverton?" | CO | [generic] | Your actual reason, in your own words. Where you can, tie it to a point you read in the market report, named in the report's own words from your copy, because the pack has not seen it. If your reason is more the role than the company, say so plainly and say why that role | A casual-register question that is still scored. CO because it tests homework depth |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1: POV on operator partnerships over 18 months | A1, A2, A3, A5, B3, D3, section 4 |
| F2: land on what it means for the operators | A4, A3, C4, D2 |
| F3: commercials, which Ross will push on | B1, B2, B3, B4, D1, D2, E1, E2 |
| F4: direct commercial ownership and rail-specific selling | B4, C1, C2, D1 |
| F5: build and manage a partner portfolio | F1, B1, C3, E3 |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To Deepa: "What would make you say, six months in, that I had landed this role well?" | It gets the success measure out in the open, which answers the commercial question before Ross asks it |
| R2 | To Deepa: "Where do you expect my biggest gap to show up first, and how would you want me to close it?" | It turns the F4 objection into coaching, and shows you can hear a hard point |
| R3 | To Ross: "What commercial evidence would persuade you a partnership is worth scaling?" | It shows you think in his terms, and tells you what B3 is really scored against |
| R4 | To Ross: "How do partnerships and commercial share credit today when a deal spans both?" | It is the seam from E1 and E2, asked from your side |
| R5 | To both: "Which part of the strategy team's report is most debated internally?" | It signals that you read the report and want the live view, not the circulated one |
| R6 | To Ross, reciprocity: "What could a new person do in their first month that would genuinely help your team?" | It answers the peer's question before it is asked |

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has sold into rail | A negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't sold into rail specifically." No slot |
| Has carried a quota, or owned or closed revenue | A negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't carried a direct quota; my revenue was influenced revenue." No slot |
| Generated, closed or owned £4M | Inflated form of F3 | F3's quote at its own scope: roughly £4M of influenced revenue. The limit is the pack's observation: the material says influenced, not owned. B2's slot stays inside the figure's own words |
| Built the ISV channel from nothing | Inflated form of F5 | F5's quote at its own scope: "took it from 6 partners to 40". The pack's observation is that the material shows a channel that already had 6 partners |
| Knows train operators from the inside | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning, seen from the other side. The pack's observation is that the quote does not say train operating companies |

## 9. Sources

Provided documents: your message, including the recruiter's email as you quoted it. The market report you mention was not available to me: it was not pasted and could not be read, so nothing in this pack is drawn from it.

Research tier: L1 — searches 5 of 6, fetches 0 of 2

Every search was refused (web search permission was not granted), so each returned nothing:

| Query | Outcome |
|---|---|
| Kelverton Rail values | refused |
| Kelverton Rail strategy news train operating companies scheduling software | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager rail technology train operating companies job description | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have fed VAL themes and the CO bank. No values section is built: no values-style round is detected either way |
| 2. Kelverton Rail interview process, partnerships | skipped | The recruiter's email fixes this session's loop (one 60-minute panel, 15 minutes of POV then Q&A), so persona weights and structure are set by it |
| 3. Kelverton Rail strategy and recent news | unavailable | Would have moved the CO bank (A5, F2) and made a grounding brief possible |
| 4. Deepa and Ross at Kelverton Rail | unavailable | Would have moved persona weights, an interviewer read and reverse questions tied to their paths |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have moved the fit-snapshot requirement rows, now the recruiter's words and role-family prose, and the JD-tagged questions |

## 10. Upgrade menu

- The market report's text, or its key pages: A5, F2, the POV's consensus item and divergence, and R5 become grounded, and a grounding brief becomes possible
- The job description: the generic requirement rows F4 and F5 become quoted and grounded, the coverage table is rebuilt, and any gates, such as location, travel or schedule, get checked
- Your CV: fit evidence beyond one message, so several scaffolds and answer slots can become story-mapped answers
- Your own answers to the slots in B1, B2, C2 and C3, such as which part of the £4M was yours or why rail, stated outside a drill: those rows regenerate as story-mapped answers
- Web search permission, or Kelverton's values page and anything public on Deepa and Ross pasted in: the interviewer read, values themes and reverse questions tied to their paths. A deeper pass of up to 6 more searches and 2 more fetches, taking several more minutes, is available once search is allowed
- What the recruiter means by "operator partnerships", in one email: A1, A2 and the POV theses get sharper
- A tuesday-dossier.md from a job-underwriter run: an evidence-derived objection, allowed strategies per weak area and checked prohibited claims, in place of the ones built locally here
