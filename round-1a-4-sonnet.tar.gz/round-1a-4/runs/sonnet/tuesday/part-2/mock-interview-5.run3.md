Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-5-denied-3bc88030/kelverton-rail_senior-partnerships-manager_interview_pack.md`. It's built for the panel exactly as the recruiter described it: 15 minutes of POV, then Q&A with Ross pushing on commercials.

All six web searches were refused. The pack rests only on your message and the recruiter's email, and the Sources section says so. There's no JD or interviewer research, and I couldn't see the market report's text, so nothing in the pack is drawn from it.

- **POV:** The build section has three bets to choose from, each with a concession you say aloud, and an anti-pick. It also has a minute-by-minute plan and a three-sentence close on what it means for the operators.
- **Highest-ROI rehearsal (C1):** "I don't see rail sales or a direct quota in your background." You've told me both gaps are real, so the pack gives you the plain acknowledgment, three follow-up levels and concession wording. It never claims a quota or rail sales.
- **Ross and commercials:** B1, B2 and D2 prepare you to defend "roughly £4M of influenced revenue" and "6 partners to 40". The pack keeps the word "influenced" and gives you "I don't know how that part was counted" as a legitimate answer.
- **The four hours:** The prep schedule splits them into five blocks, with a full timed run last.

Say the word and I'll play Deepa or Ross live on C1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Do you have the JD text (and your CV) to paste? Either would turn the recruiter-sourced rows into the posting's own requirements, and I'll proceed without them if not.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, one 60-minute panel session. Interviewers: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Shape, from the recruiter's email: a 15-minute POV from you, no slides, landing on what it means for the operators themselves; the rest is Q&A, with Ross pushing on commercials.

**Built on:** your message and the recruiter's email quoted in it. No JD, no CV file, no web research (every search was refused) and no text of the market report, so every row that would have rested on those is labeled accordingly.

## 2. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say it in your own words, and only what you actually did.

| Type tag | Meaning |
|---|---|
| VAL | Behavioral or values alignment (no values round was detected for this loop, so none is used as a main type here) |
| EXP | Work-experience deep-dive: does what you said survive scrutiny, and what was actually you |
| JD | Role-driven: the stated asks of the role, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem, reasoned aloud |

"Answer slot" means an instruction for the interview itself: say which branch is true, in your own words. It asks nothing of you here.

## 3. Prep triage (about four hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 75 min | Build the POV from the build section, then say it aloud against a timer twice. Aim for 11 to 12 minutes so interruptions do not cost you the close | Section 5; A1 to A5 |
| 2 | 45 min | Rehearse the likeliest objection until it is boring: the acknowledgment, the three follow-up levels and the concession wording | C1; D1 |
| 3 | 45 min | Write, in your own words, how each of your two headline figures was counted and what you do not know about it; practise saying "I don't know how that part was counted" where true | B1, B2, D2, F2 |
| 4 | 30 min | Commercial structure answers under time pressure | B3, B4, D3, F1 |
| 5 | 45 min | One full timed run: 15 minutes of POV, then questions out loud, recorded; ask for the drill to do this live | All |

Everything else is insurance.

## 4. Fit snapshot

Requirements come from the recruiter's own words, quoted from your message, because no JD was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | Your material says a payments channel and its growth, with nothing inspected behind it and nothing about operators or rail. The words stay at that scope: "For four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: a POV on operator partnerships invites a probe on which part of the 6-to-40 growth was yours. If any part was yours, say which and what you did, in your own words; if it was a team effort, or no part was yours, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves." — recruiter's email | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." — your message | medium | [grounded] | transferability | Your material says bus and light rail network planning. It does not say who the clients were or which side "the other side" was, so say only the first half: "I did five years of transport consulting, bus and light rail network planning." Answer slot: landing on operators invites a probe on whose networks that planning was for. If you know, say so in your own words; if you do not, or it was not your remit, say so plainly and stay with bus and light rail |
| F3 | "Ross will push on commercials." — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." — your message | medium | [grounded] | transferability | The quote's word is influenced, so the figure stays influenced: nothing in your material says it was booked, owed or targeted. Words: "roughly £4M of influenced revenue." Answer slot: expect the figure to be pressed on how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Answer each in your own words; where you do not know how it was counted, say so plainly |
| F4 | Direct commercial accountability for operator relationships, such as a revenue target (role-family expectation, no source supplied) [generic] | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never sold into rail specifically, and I've never carried a direct quota, only influenced revenue." Then how you would close it, said as a plan and never as a past. Never a claim to a quota or to rail sales, and nothing added to make the gap feel smaller |

## 5. Graded deliverable: the 15-minute POV

Declared by the recruiter: "present a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

**Grounded facts to build on** (your own sentences, as the fit rows carry them):

| Fact | Row | Your sentence |
|---|---|---|
| The channel experience the POV draws its shape from | F1 | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." |
| The operator-world sentence, at the scope it carries | F2 | "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." |
| The limit to say out loud before anyone asks | F4 | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." |

**Three bets, each with a concession you say aloud.** These are positions to defend, not findings about Kelverton. Pick the two or three that fit what you read in the report.

| Bet | Mandatory concession | Draws on | Provenance |
|---|---|---|---|
| Go deeper before wider: build around a small number of operators and one outcome each already tracks, rather than leading with partner count | Depth gives up reach, so the first 18 months show fewer partners, which hurts if growth is judged by count. Say that your own headline from the ISV years is a count: "took it from 6 partners to 40" | F1 | [generic] |
| Every pilot starts with an agreed commercial test of success, so pilots convert to contracts or end cleanly | It slows the start of each relationship and means saying no to free-form pilots. Say you would set the terms with the commercial team, not alone, because "I've never carried a direct quota" | F4 | [generic] |
| Grow through the suppliers operators already work alongside, rather than building Kelverton-only relationships one at a time | Quality control, support load and a diluted message come with it. Say plainly that your channel experience is payments and "I've never sold into rail specifically" | F1, F4 | [generic] |

**Differentiation against the report.** The report went to the interviewers' own strategy team, so reciting it scores as homework, not judgment. Bring one item from it, in your own words, to show you read it. Then give one divergence with its reason. A strong divergence challenges the one assumption in it that you would test first. If the report is last quarter's, flag anything that may have moved without correcting the panel.

**The anti-pick (where the role includes saying no).** Choose one thing you would decline in the first 18 months and say what it costs. A default that follows from the first bet: "I would not make partner count the headline measure", at the cost that count is the number you are most practised at reporting (F1).

**The close the recruiter asked for: what it means for the operators.** Three plain sentences, in your wording, for an operator:

| Sentence | What it holds |
|---|---|
| What changes for them in 18 months | One thing an operator can do that it cannot now. If you cannot say it from what you read, say what you would ask operators first |
| What they are asked to give | The time, data or commitment the bets need from them |
| How they would know it is working | One measure they would see themselves, not one Kelverton reports internally |

**Timing.**

| Minutes | Segment |
|---|---|
| 0 to 1 | The 18-month destination in one sentence, and the bets named |
| 1 to 3 | One item from the report, then your one divergence |
| 3 to 9 | The bets, about two minutes each, each ending in its concession |
| 9 to 11 | The anti-pick and its cost |
| 11 to 13 | The operator close |
| 13 to 15 | Reserve for interruptions; do not plan to fill it |

## 8. Persona table

Panel: the top two personas of each interviewer's relationship are blended (Deepa as future manager: Case/Strategist and Skeptic; Ross, whose stated focus is commercials: Data-Driven Prober and Pressure). The loop is established by the recruiter's email: one session, two interviewers, a 15-minute POV then Q&A.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Deepa interrupting the POV, testing a bet, asking what you would drop | High. The recruiter's email makes the POV a graded 15 minutes, and a future manager buys capability | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Ross taking your two figures apart | High. The recruiter says "Ross will push on commercials", and your headline numbers are the commercial evidence on the page | Know and say how each figure was counted, and say plainly where you do not know; name the weakest assumption before he does |
| Skeptic | Deepa returning to what your background does not show | Medium. You have stated two negatives, F4 | Rehearse the single likeliest objection (C1) until it is boring; bridge only from adjacent evidence; add a plan, not a past |
| Pressure | Ross time-boxing or challenging after a commercial answer | Medium. Prior for a commercial lead; inferred from his stated focus, not from anything he has published | Pause, restate, anchor in what you said, hold through two follow-ups, concede specifically |
| Conversational | The opener: "walk me through the journey" | Low. A panel often opens warmly, and casual questions are still scored | A 90-second arc from your own sentences |
| Peer Evaluator | Ross on where partnerships ends and his team starts | Low. Inferred from his title next to the role; no information on how the teams relate | Offer seam principles, not a claim to know the seam; say what you bring his team |

## 9. Question banks

### A. Case/Strategist (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Take us through where you would take our operator partnerships over the next 18 months." | JD | [grounded] | This is the POV itself, so build it from Section 5. Open with the destination in one sentence, then the bets and their concessions, then the anti-pick, then the operator close. Stop at 12 minutes if you can | The recruiter announced it, so it is certain; JD because it scores the stated ask, CASE in delivery |
| A2 | "Which of your bets do you drop first if six months in operators are not engaging?" | CASE | [generic] | Clarify first: what would engaging look like here, and who decides. Pick the bet that leans most on operators' time, name the signal that would make you drop it, and say what you would keep. Challenge the premise once, politely | Tests whether the bets were chosen or listed; a live problem, so it presupposes nothing about your past |
| A3 | "An operator tells us it likes what we offer but cannot take on another supplier relationship this year. What do you do?" | CASE | [generic] | Ask what is behind it before answering. Then give two options and the cost of each, and say what you would need from the commercial team before promising anything. Keep every figure and every claim about how operators decide out of it unless you can source it | A partnerships case with a commercial edge; F2 is why Deepa may expect a view from the operator side, and you should say only what you can stand behind |
| A4 | "What do you make of the market report our strategy team circulated, and what would you challenge in it?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Bring one item from the report, in your own words, to show you read it. Then name one assumption you would test first and why. Do not recite its shortlist, since the panel wrote or read it. If part of it may be stale, say what you would check, and do not correct them | The one question where the report decides the quality of the answer; CO because it scores homework depth. Contents are not in this conversation, so the pack supplies no item from it |
| A5 | "Say it from the operator's seat: what changes for them in 18 months?" | JD | [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | Use the three-sentence close in Section 5. Where you want to draw on your own history, say it at its own scope: "I did five years of transport consulting, bus and light rail network planning." Answer slot: if any of that work gave you a view of what operators weigh when a change is proposed, say what it was, in your own words; if it did not, or it was not your remit, say so plainly and say what you would ask operators first | The recruiter asked for exactly this close; F2 is the evidence, with its limit |

### B. Data-Driven Prober (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through the £4M. How was that counted?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Keep the word influenced and never swap it for booked or delivered. Answer slot: if you know how the figure was counted, say how, in your own words; what it is most sensitive to; the assumption behind it you would defend least; and which part was yours. If you do not know how part of it was counted, say so plainly and stay with the figure as you gave it | F3 is the headline commercial claim and Ross's stated focus; EXP because it tests attribution |
| B2 | "Six partners to forty. What counted as a partner, and which of that growth was yours?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Say what you counted as a partner, in your own words. Answer slot: if some of the growth was a team effort, or came before or without you, say so plainly and stay with the channel you ran for four years. Name the weakest assumption in the 6 and the 40 before he does | The second headline figure; F1 holds it, and a count is easy to inflate in conversation |
| B3 | "In an operator partnership, who pays for what, and where does the money come from?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | A structure, not a recollection: who benefits, who pays, what the operator gets for it, and which assumptions you cannot know from outside the company. Say what you would ask the commercial team first. If pressed for an answer you cannot source, concede: "I've never carried a direct quota, only influenced revenue, so I'd want to see your model before I put a number on it" | Ross's push on commercials arrives as a structure question first; F4 is the limit that has to be said before it is found |
| B4 | "Tell me about a time a partner's commercial terms were a sticking point." | JD | [generic] | An open prompt, so choose the instance. Pick one with a named stake, what you gave up and what you kept; it needs an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The commercial-push theme from the recruiter's email; a scaffold, because nothing in your sentences carries a story for it |

### C. Skeptic (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see rail sales or a direct quota in your background. How do you see that?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | **The highest-ROI prep in this pack.** Level one, your acknowledgment: "I've never sold into rail specifically, and I've never carried a direct quota, only influenced revenue." Then what your material carries, at its own scope: "For four years I ran the ISV channel at a payments company" and "I did five years of transport consulting, bus and light rail network planning." Then a plan, said as a plan: the two or three things you would learn first and from whom, your choices. Level two, "that is payments, bus and light rail, not heavy rail": agree with the facts and return to the quotes, adding nothing. Answer slot: if any part of how you worked with partners applied across sectors, say which part and why; if you cannot point to one, say so plainly and return to the channel you ran. Level three, "influenced is not owned": concede it in your own sentence, then say plainly whether, and on what terms, you would carry a number here, which is a decision about the future, not a claim about the past. Concession wording to rehearse: "That's right. I haven't done that yet; here is how I'd close it." Hold the quotes through all three levels and never widen them | Both negatives are yours, F4, and they sit exactly under Ross's stated focus, so some form of this arrives in every version of the panel; it gets the most follow-up levels and the exact concession wording |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Pick one honestly and say it plainly, with the plan for it: "I've never sold into rail specifically." Do not pick a weakness you would not want to be held to, and do not dress a strength as one. Close on how you would be useful before you are expert | Stem for the Skeptic; F4 supplies the honest weakness |
| C3 | "Why rail technology, and why now?" | EXP | [generic] | Answer slot: give your actual reason, in your own words, and rehearse it until it is boring. Keep it about what you want from the role. If your reason is still forming, say so plainly rather than invent one. If asked about the transport years, say what they were: "I did five years of transport consulting, bus and light rail network planning" | The motivation probe that follows any background mismatch; the reason is yours to give, since your material states none |

### D. Pressure (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds. Why you over someone who has sold into rail?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Pause and restate. Hold: "For four years I ran the ISV channel at a payments company, and took it from 6 partners to 40." Concede specifically: "I've never sold into rail specifically." Hold through two follow-ups by returning to those sentences, not by adding to them, and never fold the core of it to restore the mood | F4 is the pressure point; hold-then-concede is the type-specific bar |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Do not defend it as more than it is: "roughly £4M of influenced revenue." Answer slot: if you know which share was yours, say so in your own words; if the figure is influenced revenue that others also touched, say so plainly. Hold the position through two follow-ups by returning to the sentence, and concede the part you cannot size | The attribution probe from the persona stems, applied to F3 |
| D3 | "An operator wants half the price for twice the scope. You have two minutes." | CASE | [generic] | Pause. Restate it. Ask one clarifying question about what is driving the ask. Then give two options with the cost of each, and say what you would not commit to without the commercial team. Do not invent figures, and concede what you do not know in specific terms | Composure on a commercial problem; presupposes nothing about your past |

### E. Conversational (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." [grounded] "Before that, 5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)." | A 90-second arc, each fact said as its sentence says it: nine years in partnerships, the last four running the ISV channel at a payments company; before that, five years in transport consulting, bus and light rail network planning. Answer slot: say in your own words what led you from one to the other; if you do not have a clean reason, say so plainly and move on to why this role | The opening a panel often uses; casual, and still scored. F1 and F2 supply the facts |
| E2 | "What drew you to us in particular?" | CO | [grounded] "She also attached the market report their strategy team circulated internally last quarter, which I've read." | Answer from what you actually read in the report and the role, in your own words, and keep to what you can stand behind. Answer slot: if nothing in the report drew you, say what did | A rapport-style question scored on genuine interest and homework; A4 holds the report guidance |

### F. Peer Evaluator (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where is the seam between partnerships and my team, and what happens when we disagree?" | JD | [generic] | Propose seam principles, not a claim to know the seam: who owns the relationship, who owns the terms, how a disagreement gets escalated. Say what you bring his team as well as what you need. A disagreement answer shows spine and tact together; do not offer a disagreement story you cannot tell | A peer-style probe aimed at the commercial lead; inferred from his title next to the role |
| F2 | "How do you handle credit when a partner deal spans teams?" | EXP | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Your own word for it is influenced revenue, so credit was shared by definition: say what influenced meant in your own words. Answer slot: if you know how credit was divided, say so; if you do not, say so plainly. Never claim a deal as yours | Ties the "influenced, never carried a quota" limit to a collegial question |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" (F1) | A1, A2, A3, A4, A5 |
| "Please land on what it means for the operators themselves." (F2) | A5, A3, E1 |
| "Ross will push on commercials." (F3) | B1, B2, B3, B4, D2, D3, F1, F2 |
| Direct commercial accountability, role-family (F4) | C1, C2, D1, B3 |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "In 18 months, what would you need to see from operator partnerships for this to have worked?" | It asks for their scorecard, and it turns your POV into their criteria |
| 2 | "Which part of what I have laid out would you most want tested with an operator before committing?" | It invites them to co-own the POV, and shows you expect to be corrected by operators |
| 3 | "Where do you want the line between partnerships and the commercial team to sit?" | Reciprocity for Ross: it shows you are thinking about his team's load as well as your own |
| 4 | "What would you want me to have learned about the operators by day 90?" | It names the rail gap without apology and asks for Deepa's ramp expectations |
| 5 | "Which assumption in the strategy report has moved most since it was written?" | It shows you read it, and treats a report that is a quarter old as a living document without correcting anyone |
| 6 | "What would a good first operator conversation look like, from your side?" | It gets the working picture you need to rehearse the POV against |

## 13. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a revenue number or quota | Negative you stated, F4 | The plain acknowledgment: "I've never carried a direct quota, only influenced revenue." No slot |
| Sold into rail | Negative you stated, F4 | The plain acknowledgment: "I've never sold into rail specifically." No slot |
| Booked or closed £4M of revenue | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue." The limit is the pack's observation: the material says influenced, not booked |
| Worked for or with train operating companies | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning. The limit is the pack's observation: the material does not say who the clients were |

## 14. Sources

**Provided documents:** your message, including the recruiter's email quoted in it and your background. The market report is attached per your message, but its text was not in this conversation, so nothing here is drawn from it. No `tuesday-dossier.md` was present.

**Searches sent, each refused (nothing returned):**

| Query | Outcome |
|---|---|
| Kelverton Rail company values | refused |
| Kelverton Rail interview process partnerships manager | refused |
| Kelverton Rail strategy train operating companies scheduling software news | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager rail technology train operating companies job description | refused |

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have moved the VAL bank and a values sheet, had a values-style round been detected; none is detected from the recruiter's description of the loop |
| 2. Kelverton Rail interview process, partnerships | unavailable | Would have moved persona weights if reports differed from the recruiter's account; the loop here rests on that account |
| 3. Kelverton Rail strategy and recent news | unavailable | Would have moved A4 and E2, the CO bank and a grounding brief; the report you hold is not in this conversation, so it fixes nothing |
| 4. Deepa and Ross, Kelverton Rail | unavailable | Would have moved an interviewer read, the persona weights and a tailored reverse question; only their titles are known |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have moved the fit snapshot's requirements and the JD-tagged questions; they rest on the recruiter's words |

## 15. Upgrade menu

- The market report's text (paste the sections, or its headline priorities) → A4, A2 and E2 become `[grounded]`, a grounding brief is added, and the POV's divergence can be tested against what it says
- The JD text → the F rows' requirements become the JD's own, mid-list requirements get questions, and any gate (location, travel, clearance) is surfaced
- A short note from the recruiter on what "commercials" means → the Prober and Pressure banks tighten to what Ross will actually test
- Your answers to the answer slots on F1, F2 and F3 → those rows move from transferability toward evidence you can state
- A partner revenue report or deal sheet behind the "roughly £4M" → F3 could move from medium to high
- Ross's and Deepa's full names or profiles → an interviewer read and reverse questions tied to their own paths
- Search access → the five research targets above can run; a deeper pass would add up to 6 more searches and 2 more fetches, several more minutes
- A `tuesday-dossier.md` from an earlier fit check → verified evidence and prohibited claims arrive pre-checked; none was present
