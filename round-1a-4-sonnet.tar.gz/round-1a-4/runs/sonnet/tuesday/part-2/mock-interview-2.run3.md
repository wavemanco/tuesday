I'm writing the prep pack now. The web searches were refused, so it's built only from your JD and background, and the research accounting says so.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-2-denied-4db02b27/atlas-freight_operations-manager_interview_pack.md`. I built it for a hiring-manager round, since you didn't say who you're meeting. It has 21 questions, a fit snapshot against each line of the JD, and a section on claims not to make. It also has six questions for you to ask them.

The web searches on Atlas Freight were refused in this session. The pack therefore uses only your JD and background. It has no company values, no documented interview loop and no strategy questions. The persona weights are a generic pattern, not Atlas's actual process.

Say the word and I'll play the Skeptic on B1, the "three supervisors today, twelve here" question. That is the pack's highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is the person you're meeting your future manager, a peer, or someone from HR, and has the recruiter said anything about topics or a take-home? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Relationship and round type: not known, so the pack is built on one assumption, that you meet a hiring manager. If that is wrong, the persona weights below are the part to redo.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: where a line is in quotation marks it is your own sentence from your message, and nothing else is offered as something you did. Where the guidance says "answer slot", it is an instruction for the interview, not a question for you now.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values being probed |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and attribution |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth on strategy and recent moves; none in this pack, because research did not run |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

No loop source established Atlas Freight's rounds, so the persona weights rest on the Generic pattern (screen, hiring manager, panel), tilted by the hiring-manager assumption. They do not rest on a documented Atlas process.

## Prep triage

Done well, in this order, a week out:

1. B1, the highest-ROI prep in this pack: rehearse the three-to-twelve supervisors question until it is boring.
2. B2 and F5: say "I haven't used Power BI" calmly, then give your plan.
3. B3 and F6: settle the exact number of years you held a supervisory or management title, with titles, before you walk in.
4. C1 and C2: decide how much you can say about how the 40% was counted and which part was yours.
5. A1 to A5: say the case structure aloud twice each.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift manager's role and a site's surge plan, not terminals or four sites, and nothing was inspected behind it. The words stay at that scope: "I'm a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-sites line makes a probe on running more than one location likely. If any of your work reached beyond your own site, say what and where, in your own words; if none did, say so plainly and stay with the shift and the surge plan you ran |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Your material reports a mis-pick rate, not on-time performance or cost per shipment, and nothing was inspected behind the figure. The words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD's two measures make a probe on what else the redesign moved likely. If you know of other results and how they were measured, say so in your own words; if nothing else was measured, or it was not yours, say so plainly and stay with the mis-pick figure |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The same kind of work at a smaller number, and the number stays attached to what it counts: "I'm a senior shift manager over 3 supervisors." The pack's observation: the JD's twelve is four times that number, and your material does not cover the step between. Answer slot: a probe on the jump from three to twelve is likely. If any part of your current role already involved coordinating supervisors beyond those three, say what, in your own words; if none did, say so plainly and give a ramp plan for the first month, as a plan and not a past |
| F4 | "build reporting in Excel/Power BI" — JD, Excel side | "solid Excel" — your message | low | [inferred] | discovery | "Solid Excel" is a self-description and does not show reporting built. Answer slot: the JD's reporting line makes a probe on what you built likely. If you built reports or trackers in Excel, say what each showed and who used it, in your own words; if you did not build any, say so plainly and stay with "solid Excel" |
| F5 | "build reporting in Excel/Power BI" — JD, Power BI side | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to dashboard or BI work, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | low | [inferred] | discovery | The seven years are operations years, and your material does not say how many were leadership years; the words stay at "7 years in warehouse and distribution ops". Answer slot: expect the figure to be checked against the requirement as written. Say how many of those years you held a supervisory or management title, with the titles, in your own words; if the number is under five, say so plainly and stay with the seven operations years |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a claim with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: "I'm green belt certified." The pack's observation: your material does not name the awarding body or mention Lean separately. Answer slot: if you have applied green-belt methods on the job, say where and how, in your own words; if you have not, say so plainly and stay with "green belt certified" |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems on four-terminal running, on-time and cost | High. The hiring-manager assumption puts it first, and the JD's lines are about daily running, on-time and cost, which suit live problems. Round type is unconfirmed | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| Skeptic (B) | Quiet probing of the distance between the JD's numbers and your material | High. F1, F3, F5 and F6 are where the JD's numbers sit furthest from your quotes | Rehearse B1 until boring; build bridges only from your own quotes and say the limit plainly |
| Data-Driven Prober (C) | Line-by-line questions on the one headline figure and on what you track | Medium. F2 is the one quantified claim | Know what you can say about how the figure was counted; say plainly where you do not know |
| Values/Behavioral (D) | Scenario probes about leading supervisors and delivering hard truths | Medium. No values round is documented, but leading twelve supervisors makes behavioral questions plausible in any round | Choose stories where the hard truth landed; where none comes to mind, say so |
| Pressure (E) | Time-boxed "why you" and "how much was you" | Lower. A first hiring-manager round rarely leads with it, but the scale gap invites it | Pause, restate, hold on your quotes through two follow-ups, concede the scale exactly |
| Conversational (G) | Friendly openers such as "walk me through the journey" | Lower. It appears as an opener in almost any round, so it still gets a short arc | A 90-second arc built only from your own sentences |
| Peer Evaluator (H) | Four-site resource contention and credit-sharing | Lower. Nothing shows a peer in the room, but four sites sharing resources makes it plausible on a panel | Offer principles for the seam rather than pretending to know it; reciprocity framing |

## Question banks

### Bank A: Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two of your four terminals have been departing late every morning this week and nobody agrees why. What do you want to know first, and what do you do in the first 48 hours?" | CASE | [generic] | Clarify before you structure: late against what cut-off, since when, what changed at those two sites, what the other two do differently. Then the objective, a split of the delays by stage, the first actions, the numbers you would watch, the risks. Think aloud and challenge one premise politely, such as whether this is one problem or two. The question needs no claim about your past, so the guidance makes none | The on-time requirement in F2 asked as a live problem. CASE because it scores structure; `[generic]` because it is a pattern, not a fact about Atlas |
| A2 | "Cost per shipment is up at one site and flat at the other three. Where do you look first?" | CASE | [generic] | Same spine. Compare the site with the others before assuming a cause; separate what moved because volume moved from what moved because the unit cost did; say what you would ask finance for and what would prove you wrong. No claim about your past is made or needed | The cost requirement in F2 asked as a live problem. CASE because it scores structure and metrics |
| A3 | "Peak volume lands on all four terminals the same week and two supervisors are out. Walk me through your first morning." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Structure from first principles: what you need to know by when, who covers what, what you would stop doing, what you would escalate. If you want to anchor in your own experience, the sentence you have is "I ran the site's peak-season surge plan two years running." Answer slot: if parts of that plan would carry across four sites, say which and why, in your own words; if none would, or you cannot say, say so plainly and structure from principles | F1's surge-plan quote is the nearest evidence for running under pressure. CASE because it asks for a decision, not a history |
| A4 | "You have one week and four sites. How do you decide where you are on any given day?" | CASE | [generic] | A rhythm, not an itinerary: what you would want from each site each morning, which signals pull you to a site, how supervisors reach you, what you hand to a supervisor and what you keep. Say it as principles you would test, because you do not yet know these sites. No claim about your past is made | The four-sites line in F1 asked as a live problem. CASE because it scores how you structure attention |
| A5 | "You inherit a weekly report that supervisors say they do not trust. What do you do in the first two weeks?" | CASE | [grounded] "solid Excel"; "never used Power BI" | Clarify what is distrusted: accuracy, timing, or the definitions. Fix definitions and ownership before format; ask what decision the report supports. If the tool comes up, stay with your own words: "I have solid Excel and I haven't used Power BI." Then a plan for how you would learn it, said as a plan and never as a past | F4 and F5 are where the JD's reporting line meets your material. CASE because the answer is a method; the Power BI line is the honest limit, said once |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You manage three supervisors today and this role has twelve across four terminals. What changes, and what worries you?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI prep in this pack. The hold is only what the quote carries: "I'm a senior shift manager over 3 supervisors." Concede the scale exactly and early: three is your number today, and the jump to twelve is the part you would ramp deliberately. Answer slot: if any part of your current role already involved coordinating supervisors beyond your three, say what, in your own words; if none did, say so plainly and give a ramp plan for the first month, as a plan. Expect three follow-ups: the largest team you have led, how you would handle a supervisor you disagree with at a site you have not seen, and why you think it scales. Hold by returning to the quote, never by adding to it | F3 and F1 are where the JD sits furthest from your material, so this objection will arrive in some form. JD because it scores the stated requirement |
| B2 | "I don't see Power BI in your background. How would you handle the reporting side of this role?" | JD | [grounded] "never used Power BI"; "solid Excel" | Plain acknowledgment first, in your own words: "I haven't used Power BI." Then what you do have, at its own scope: "solid Excel". Then a plan for how and how fast you would learn the tool, said as a plan. Do not describe BI work you have not done. Answer slot: if you built reports in Excel, say what they showed, in your own words; if not, say so plainly and stay with the plan | F5 is a gap you stated, and F4 is thin. JD because it scores the stated requirement, delivered as a skeptic would |
| B3 | "The posting asks for five years of operations leadership. How many of your seven years were leading people?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Hold the quote at its own scope: "I have 7 years in warehouse and distribution ops, and I'm currently a senior shift manager over 3 supervisors." Answer slot: say how many years you held a supervisory or management title and what the titles were, in your own words, and do not round up; if the figure is under five, say so plainly and stay with the seven years of operations | F6's years requirement is likely screened literally. JD because it scores a stated requirement; the premise is only that some of the seven years were leadership years, and the slot lets that be false |
| B4 | "You've told me about a pick-path redesign and a surge plan. What would you have to relearn to do either across four terminals?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | Tell each at its own scope: "I cut mis-pick rate 40% by redesigning the pick path" and "I ran the site's peak-season surge plan two years running." Answer slot: if either was applied at more than one location, say where; if not, say so plainly. Then name, as a plan, what you would confirm first about each terminal before repeating anything | F1 and F2 are the evidence, and the question tests whether they travel. EXP because it probes the reach of your own claims |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Defend-the-number, in your own words, for each of the four slots. How it was counted; what it is sensitive to; the assumption behind it you would defend least, named before they ask; and which part was yours. This pack supplies no method, baseline or assumption. If you do not know how it was counted, say so plainly; that is an honest branch | F2 holds the only quantified claim, and quantified claims draw probes. EXP because it tests attribution and honesty about the figure |
| C2 | "What part of the pick-path redesign was yours?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: say what you did and what others did, in your own words. If you cannot separate them, or it was a team result, say so plainly and stay with what you can say you did. Keep the verb you actually own; do not upgrade it | F2 again, from the attribution side. EXP because it is the "how much was you" probe in a collegial form |
| C3 | "At the end of a shift, how do you know it went well?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Answer slot: the JD's on-time and cost lines make a probe on what you actually look at likely. Say which measures you check and where they come from, in your own words; if the measures were set by others, or you check few, say so plainly and stay with what you do check | F1 and F2 ask what you own day to day. EXP because it tests whether you run by measures |

### Bank D: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Your material carries no story for this, so none is supplied. Selection criteria: pick a time you told someone senior something they did not want to hear; it needs a named stake, what you said, how it landed, and whether the relationship held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Leading supervisors under a manager above makes this likely. VAL because it scores past behavior; `[generic]` because it is a persona stem, not an Atlas fact |
| D2 | "Tell me about a time you had to get a supervisor to change how they ran their shift." | VAL | [generic] | No quoted sentence of yours carries this, so it is a scaffold. Pick a time with a named change, what the supervisor resisted, what you did, and what held afterwards. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's supervisors line (F3) makes people-leadership probes likely. VAL because it scores behavior toward a team you lead |
| D3 | "When did you put a customer's delivery ahead of an internal target?" | VAL | [generic] | A scaffold, because nothing quoted carries it. Pick a time with the customer's need, the target you set aside, the cost, and how it was resolved. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | On-time performance (F2) is a customer-facing measure. VAL because it scores a trade-off, not a skill |

### Bank E: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run several terminals?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified"; "currently a senior shift manager over 3 supervisors" | Pause and restate the question. Hold on your own sentences: "I cut mis-pick rate 40% by redesigning the pick path, I ran the site's peak-season surge plan two years running, and I'm green belt certified." Hold through two follow-ups by returning to them. Concede the scale specifically and once: your current number is 3 supervisors. Do not fold on the quotes to restore harmony | F1 and F3 are where this challenge lands. JD because it scores fit to the stated role, delivered under pressure |
| E2 | "You ran the surge plan two years running. How much of it was actually you?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Hold the quote: "I ran the site's peak-season surge plan two years running." Answer slot: say which parts you set and which you were handed, in your own words; if you cannot separate them, say so plainly. Concede only what is true and specific, and do not add to the quote under the second follow-up | F1's surge-plan quote is the pressure point. EXP because it tests attribution under pressure |

### Bank G: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc built only from those sentences, in the order that suits you: the seven years, the current role, the pick-path result, the surge plan, the green belt. Answer slot: if asked why this role and why now, give your actual reason, in your own words; your material does not state one | The biography question is asked in some form in almost any round. EXP because it scores whether your story matches your CV |
| G2 | "What are you actually playing with in Lean or Six Sigma these days?" | JD | [grounded] "green belt certified" | Start with the quote: "I'm green belt certified." Answer slot: if you use green-belt methods in your current role, say how, in your own words; if you do not, say so plainly and stay with the certification. Do not describe a project you did not run | F7's plus-skill, asked casually. JD because it scores the posting's line in a relaxed register |

### Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our terminals share drivers and trailers. When two sites need the same resource on the same morning, who wins, and how do we settle it?" | CASE | [generic] | Offer principles for the seam rather than pretending to know it: agree the rules for contention in advance, who decides, which data decides, when it escalates. Add reciprocity: what you would bring their site, not just what you need. No claim about your past is made | Four sites sharing resources is the scenario the JD's four-site line (F1) implies. CASE because it asks for a decision rule |
| H2 | "How do you handle credit when a result spans teams?" | VAL | [generic] | A scaffold, because nothing quoted carries it. Pick a time with a shared result, who contributed what, how credit was named, and whether the relationship held. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Credit-sharing is the peer's persona stem. VAL because it scores behavior toward equals |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| "Own daily terminal operations across 4 sites" | A3, A4, B4, E2, H1 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, C3, D3 |
| "lead a team of 12 supervisors" | B1, D2, E1 |
| "build reporting in Excel/Power BI" | A5, B2 |
| "5+ years operations leadership required" | B3, G1 |
| "Lean/Six Sigma a plus" | G2, E1 |

Defend-the-number coverage: C1 for the one quantified claim.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does good on-time performance across the four sites look like six months in?" | It uses the JD's own measure and shows you think in targets, not activity |
| R2 | "Which site would you want me to spend my first month at, and why?" | It turns the four-site gap into a plan the interviewer shapes |
| R3 | "How are the supervisors' daily results reported today, and who reads them?" | The answer shows how much Power BI the role expects on day one, which you need to know (F5) |
| R4 | "Where do the twelve supervisors most need support from the person in this role?" | It points the conversation at the leadership scale, where your material is thinnest, on your terms (F3) |
| R5 | "What is the hardest part of owning four sites at once?" | It invites a candid answer and shows you are weighing the job, not only winning it |
| R6 | "What would you want a new person here to have learned by day 90?" | A concrete bar to rehearse against |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned terminal operations across several sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says a shift and a site, not four sites. A3's and B4's slots stay inside that scope |
| Led or managed a team of twelve supervisors | Inflated form of F3 | "I'm a senior shift manager over 3 supervisors." The limit is the pack's observation: the material says three. No slot names twelve as yours |
| The pick-path redesign cut cost per shipment or raised on-time performance | Inflated form of F2 | F2's quote at its own scope: the mis-pick rate. C1 and C2 stay inside it |
| Built the site's reporting | Inflated form of F4 | "Solid Excel", as written. B2's slot asks only what you built, with a branch for none |
| Has used Power BI | Negative you stated, F5 | The plain acknowledgment: "I haven't used Power BI." No slot |
| Five or more years of operations leadership | Inflated form of F6 | "7 years in warehouse and distribution ops", at its own scope. B3's slot asks for your own count of titled years |

## Sources

Provided documents: the JD text and your background, both as pasted in your message. No dossier was present.

Searches sent (all refused by the session, none returned anything): "Atlas Freight regional logistics company values"; "Atlas Freight interview process operations manager"; "Atlas Freight strategy recent news terminals". No page was fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have moved a values cheat sheet if a values round is documented; the pack has none |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have replaced the Generic pattern and flat weights with the documented rounds |
| 3. `Atlas Freight strategy` / recent news | unavailable | Every call was refused. It would have moved a CO question and a grounding brief; the pack has neither |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The round type and who you are meeting → reweights every bank, and replaces the hiring-manager assumption
- The interviewer's name and role → an interviewer read, persona weights from their public footprint, and a reverse question tied to their path
- The recruiter's prep email, if there is one → coverage of any stated focus areas or take-home
- Your CV with dates and titles → quote-level evidence for F1, F3, F4 and F6, and the exact years of titled leadership that B3 needs
- Your own answers to the answer slots in F1, F2, F4 and F6 → upgrades those rows and their questions from slots to your own words
- Permission to search the web for Atlas Freight → company values, the documented interview loop and recent strategy, which would replace the flat weights and add CO questions. A deeper pass would add up to 6 more searches and 2 more fetches and several more minutes
- A `tuesday-dossier.md` from a prior job-underwriter run, if you have one → verified evidence and prohibited claims that sharpen the guidance cells; the pack is complete without it
