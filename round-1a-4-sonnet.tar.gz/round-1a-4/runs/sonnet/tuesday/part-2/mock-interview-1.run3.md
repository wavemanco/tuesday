I'm building the prep pack now. Both web searches (Northwind's values and Dan's public footprint) were refused, so I'm working from what you gave me and will show that in the pack's sources.
Priya's prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-1-denied-7e996aad/northwind-data_senior-gtm-strategy-lead_interview_pack.md`. It has 21 questions across seven personas, tagged by type with answer guidance, provenance and rationale.

I built it for a single 60-minute conversation with Dan as a peer. The web searches for Northwind's values and Dan's public footprint were refused, so the pack runs on your message and research note only. That means there's no values cheat sheet, and the interviewer read comes only from your description of Dan.

- **Persona weights:** The Peer Evaluator is weighted highest, then the Data-Driven Prober, because Dan calls himself "relentlessly data-driven". Skeptic, Case/Strategist, Conversational, Pressure and Values/Behavioral follow in that order.
- **Highest-ROI prep (C1):** Priya's own stated gap, "No classic sales-ops or quota-setting experience", sits in Dan's own domain. The pack has her acknowledge it plainly, name what she did do at its real scope, and give a ramp plan. It never lets her call her volume targets quotas.
- **Number defense (B1, F2):** The ~$400M ARR figure gets its own questions. The pack coaches her to say she "proposed" the change, which is what your summary says, not that she drove the result.
- **Answer slots:** Where your summary doesn't show something, such as land/adopt/expand/renew work or what her AI use covers, the pack gives her an either-way slot instead of supplying an answer. Her real stories would replace those.
- **Pricing angle:** Two questions (D1 and D2) test the Compass go-to-market plan and add-on versus bundled pricing against the bundling threat, because Dan's career is pricing and monetization.

If you'd like a Word version, say so and I'll convert it. I can also run a live drill, by default as the Skeptic on C1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed.

1. Has the recruiter said anything about Dan's focus areas, or asked Priya for a deliverable such as a presentation or take-home?
2. Can you paste the full JD text and Priya's CV? I can proceed without them, but the fit rows would then rest on exact quotes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind-data_senior-gtm-strategy-lead_interview_pack.md -----
# Interview prep pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Interviewer:** Dan Kovac, Director of Sales Strategy — a peer (same VP). **Format:** one 60-minute conversation. **Candidate:** Priya.

Persona weights rest on your stated relationship and on Dan's self-description as you reported it. They do not rest on any documented Northwind loop or on a public-footprint search (both searches were refused; see Sources).

## 1. How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: say your own words, at the scope of what you actually did.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows published company values |
| EXP | Work-experience deep-dive | Whether the CV claims survive scrutiny and attribution |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether you can think at Northwind's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traces to your message or a quoted source, `[inferred]` is a named derivation, `[generic]` is a role-family pattern with no claim about Northwind or Priya.

## 2. Fit snapshot

Requirements are quoted from the JD highlights in your message (not the full JD). Evidence is Priya's own summary sentences as you gave them.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, your message | "set annual volume targets with cross-org consensus" — coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — coach's notes | medium | [grounded] | transferability | Your material shows targets set with consensus and a proposal, not GTM for a product line, so the words stay at those quotes: "I set annual volume targets with cross-org consensus." Answer slot: the JD's two-new-product-lines line makes a probe on what of a product line's launch was yours likely. If any piece was yours, say which and what you decided, in your own words; if none was, or it was not yours, say so plainly and stay with the targets and the proposal |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, your message | none given | none | [grounded] | discovery | Your material does not show lifecycle work. Answer slot: if you have worked on any stage of land, adopt, expand or renew, say which stage and what you did, in your own words; if you have not, say so plainly and say which stage's data you would pull first |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, your message | "skilled in SQL/Tableau" — coach's notes | medium | [grounded] | none | No gap on the tools, and a summary line with nothing inspected behind it, so expect a probe on "independent". Lead with the tools in the quote's own terms, then one analysis you ran yourself (B3 builds the selection) |
| F4 | "partner-motion design experience required" — JD highlights, your message | "built a partner-level revenue model used in carrier negotiations" — coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not a partner motion. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any of your partner work went beyond the model to how the partnership operates, say what and what part was yours; if the model was the work, say so plainly and say what you would design first |
| F5 | "strong cross-functional influence" — JD highlights, your message | "set annual volume targets with cross-org consensus" — coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Lead with the consensus, in its own words, and add nothing to it |
| F6 | "AI experience a plus" — JD highlights, your message | "uses AI tools daily" — coach's notes | medium | [grounded] | none | The quote carries daily use and nothing about what for. Answer slot: name a real use and what changed because of it, in your own words; if there is none beyond daily use, say so plainly |
| F7 | Familiarity with sales-ops and quota-setting practice, as a Sales Strategy peer would expect — role-family, no source | "No classic sales-ops or quota-setting experience." — coach's notes | none | [grounded] | capability | A gap wording cannot close, and it has been stated. Words: "I haven't had classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past |

No requirement in the highlights is a gate (authorization, licence, location, pay, schedule). Partner-motion experience is marked "required" but is a length-of-experience requirement, so it is graded like the others.

## 3. Prohibited claims (built before the banks)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or launched GTM for a product line | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation, not words for you: the material says targets and a proposal, not a product line |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F1 | "I proposed a store-surface change credited with a ~$400M ARR uplift." Say what you proposed; the quote does not say you built, launched or measured it |
| Designed a partner motion | Inflated form of F4 | F4's quote at its own scope. A5's slot stays inside the model |
| Led or ran the carrier negotiations | Inflated form of F4 | The model was "used in carrier negotiations"; the quote does not put you at the table |
| Has sales-ops or quota-setting experience, or that your targets were effectively quotas | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I haven't had classic sales-ops or quota-setting experience." No slot |

## 4. Reading the interviewer

Source for every row below is your research note on Dan, not a public-footprint search.

| Signal | What it suggests for the 60 minutes | Provenance |
|---|---|---|
| Self-described "relentlessly data-driven" | Every number you cite is probed to its inputs and assumptions; the Data-Driven Prober is weighted up (bank B) | [grounded] |
| Career spine in pricing and monetization roles | Case questions tilt to pricing, packaging and unit economics (D2); his native vocabulary is price, attach and discounting | [grounded] |
| One early-stage-startup chapter | Mild signal only: a possible probe on resourcing and pace at a ~3,000-person company. Your material shows no startup work, so no builder story is offered | [inferred] |
| Peer, reporting to the same VP | He is pricing what you cost and add to his work; lead with reciprocity and seam principles (bank A) | [grounded] |
| Mirror opportunity: monetization vocabulary | Pair his monetization spine with your quote "built a partner-level revenue model used in carrier negotiations" (F4), at its own scope. No shared career jump is offered: the material shows none | [grounded] |

## 5. Persona table

Loop: one 60-minute conversation with a peer, established by your own words, so no archetype is used and no values-style round is detected.

| Persona | How it shows up with Dan | Likelihood, with reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Peer Evaluator | Seam-splitting, "what would you need from me", credit across teams | High: peer relationship prior | Reciprocity framing; seam principles, not a made-up seam | A (5) |
| Data-Driven Prober | Line-by-line probing of the CV numbers | High: relationship prior plus "relentlessly data-driven" | Know how each number was counted and say plainly when you do not; name the weakest assumption first | B (4) |
| Skeptic | The sales-ops and quota gap, why leave, day-one weakness | Medium: the stated F7 gap is exactly what a Director of Sales Strategy owns | Rehearse the one predictable objection (C1) until it is boring | C (3) |
| Case / Strategist | Pricing and packaging cases on the two priorities in your note | Medium: his pricing spine tilts cases his way, though a peer is less likely to run a formal case | Clarify, objective, segmentation, approach, metrics, risks; say the structure aloud | D (3) |
| Conversational | Opening biography, casual AI question | Low-medium: every interview opens this way, and casual questions are still scored | A 90-second arc; treat the AI question as scored | E (2) |
| Pressure | Time-boxed "why you" and "how much was you" | Low: peers rarely run stress rounds, but the attribution probe arrives in collegial packaging | Hold through two follow-ups, then concede specifically | F (2) |
| Values / Behavioral | Scenario probes | Low: no values round is detected and Northwind's published values are not in hand | Selection scaffolds only | G (2) |

## 6. Question banks

**Highest-ROI prep: C1.** It will be asked in some form by the person who owns that competency.

### A. Peer Evaluator (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side — where's the seam between your role and mine, and what happens when we disagree?" | JD | [generic] | Offer seam principles rather than a map: whoever owns a customer number owns its definition; the two new lines' targets and the core targets are reconciled in one place; disagreements go to the shared data first, then to the VP together, never around each other. Say you would want Dan's view of where today's seam sits, and say what you bring his team. Nothing here claims a past | Peer persona's native question; JD because it scores the cross-functional requirement (F5), peer-delivered |
| A2 | "Tell me about a time you needed several teams to back a plan that wasn't theirs." | JD | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the annual volume targets and the cross-org consensus are the beats the quote states; tell them in your own words. Answer slot: the JD's cross-functional influence line makes a probe on how the teams came to agree likely. If there was a disagreement and you moved it, say how and what part was yours; if there was none, or others reached the agreement, say so plainly and return to the targets you set | F5 is the evidence for the influence requirement; JD because it scores that line, with EXP delivery because it tests what was actually yours |
| A3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the quote says: you proposed a store-surface change, and it was credited with the uplift. Name whose work it rested on, if any, in your own words. The quote does not say who built or measured it. If the work did not span teams, say so plainly and answer with how you handle credit going forward | Credit-sharing is the peer persona's attribution probe, and F1's proposal is the line it lands on; EXP because it tests attribution honesty |
| A4 | "What would you need from me and my team in your first month?" | JD | [generic] | Give and get. What you would ask for: the stage definitions behind land, adopt, expand and renew, access to pipeline and renewal data, and introductions to the people who maintain them. What you offer back: a shared view of the two new lines' targets and an early read on the partner motion. A plan, not a past | The peer asks what hiring you costs his team; JD because it scores the whitespace and cross-functional lines (F2, F5) |
| A5 | "Partner-motion design is a requirement for this seat. What does your partner work look like?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: the model, and its use in negotiations, as quoted, in your own words. Answer slot: the JD's partner-motion line makes a probe on whether the work went beyond the model likely. If it did, say what and what part was yours; if the model was the work, say so plainly and say what you would design first | F4 is the thinnest-attributed required line, so a peer will test it; JD because it scores a stated requirement |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have a ~$400M ARR uplift credited to a change you proposed. Walk me through how that number was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The four defend-the-number slots, each in your own words. How it was counted. What it is sensitive to. The assumption behind it you would defend least, named before Dan names it. Which part was yours. If you do not know how it was counted, say so plainly. Hold to the quote: you proposed the change, and the uplift was credited to it | The headline CV metric is the first thing a self-described data-driven interviewer probes (F1); EXP because it tests attribution |
| B2 | "Walk me through the revenue model you built for carrier negotiations, end to end." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: what the model was for and who used it, in your own words. Answer slot: the JD's independent-analysis line makes a probe on whose analysis it was likely. If you built the inputs and checks, say how; if others supplied or reviewed any, say which; if there was no check, say so plainly | F4's model is the one analysis artifact on the CV; EXP, with JD because it also scores F3 |
| B3 | "Tell me about an analysis you ran independently in SQL or Tableau." | JD | [grounded] "skilled in SQL/Tableau" | The quote carries a skill, not an analysis, so this is a scaffold. Pick one you wrote the query for yourself: the question it answered, what you found, the decision it fed, and the weakest assumption in it. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries or how you would approach one | Scores the JD's "independent" word (F3), which a data-driven peer will test with a live example; JD because it is a stated requirement |
| B4 | "Tell me about the annual volume targets you set." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5: the targets and the consensus, as quoted, in your own words. Answer slot: expect a probe on how the number was derived. If a method sat behind it, say what; if it was not derived that way, or the method was someone else's, say so plainly and return to the consensus. Never describe the targets as quotas (F7) | A sales-strategy peer will ask what is behind a target; EXP because it tests what the candidate actually did |

### C. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "I don't see quota-setting or classic sales-ops in your background — how would you handle that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience." | **Highest-ROI rehearsal.** Order: acknowledge, state what the quotes carry, give a plan. Acknowledge (your stated negative, F7): "I haven't had classic sales-ops or quota-setting experience." What you did, at its scope: "I set annual volume targets with cross-org consensus." Plan, as plan only: what you would learn first and from whom, for example how targets and quotas are built today and the last cycle's numbers. Follow-up 1, "targets aren't quotas": answer slot: if you know how the targets you set differ from how quotas are set, say so in your own words; if you do not, say so plainly and ask Dan how theirs are built. Follow-up 2, "so why you?": hold by returning to the consensus and the revenue model as quoted, and to the JD lines the quotes do reach (F4, F5). Never say your targets were effectively quotas. Concede the limit before it is asked for, because Dan owns this competency and a bluff fails on the first follow-up | F7 is the largest stated gap and sits in the interviewer's own domain; JD because it scores sales-ops familiarity as the role-family expectation, Skeptic because it probes a stated gap |
| C2 | "Which part of this JD would you be weakest at on day one?" | JD | [generic] | Choose from your own material, honestly. The pack's observation is that F2 has no evidence given. Answer slot: if you have worked on any stage of land, adopt, expand or renew, say what you did and what part was yours; if not, say so plainly and say how you would close it in the first month. Pick the weakness you can name with a plan | Persona stem; the JD's whitespace line (F2) is the likeliest answer, so the candidate should choose it rather than be caught on it |
| C3 | "Nine years at one consumer-tech company. Why leave, and why B2B data infrastructure, and why now?" | JD | [grounded] "then 9 at a large consumer-tech company in product strategy & ops" | A scaffold, because your actual reason is yours to state. It needs three things: specific to this company and product area, consistent with your opening biography (E1), and one of the three priorities in your note you can speak to. If no clear reason comes to mind, say so plainly and say what you are looking for. Do not supply a reason you would not repeat under a second question | Motivation consistency is the Skeptic's standing probe; JD with CO delivery |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Northwind is launching an AI copilot while a much larger platform vendor bundles competing capability. Sketch the go-to-market plan — what do you need to know first?" | CASE | [grounded] your research note: Compass launch; bundling by a much larger platform vendor as the main competitive threat | Say your structure aloud first. Clarify: whether Compass is one of the two lines, who the buyer is, existing base or net-new, standalone or included pricing, where the bundle overlaps. Then objective, segmentation, approach, metrics, risks. Challenge one premise respectfully, for example whether bundling is the threat in every segment. No claim about your past | The one CO and CASE question on current strategy; CASE because it is a live problem, CO because it uses the company's own priority and threat (F1) |
| D2 | "Compass: add-on or bundled into existing tiers? Which would you test first, and what would you measure?" | CASE | [grounded] your research note: AI copilot launch, reaching profitability, enterprise expansion | Take a stance and say what would change it. Name the measures you would pull in SQL: attach, adoption, expansion, discounting, cannibalization of existing revenue. Tie the choice to the profitability priority. No claim about your past | Dan's pricing and monetization spine tilts cases here; CASE with CO, and F3's tools are how the answer gets measured |
| D3 | "Take a brand-new product. Where would you look first for whitespace across land, adopt, expand and renew, and how would you size it?" | CASE | [generic] | State the clarifying questions first (what exists in the base, what data exists). Segment by lifecycle stage, then rank by size and reachability, then say which cuts you would pull yourself. Do not claim to have done this before | Covers F2 and F3 together; CASE because it is a live problem with the JD's own vocabulary |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc on the quote's beats: two years consulting, then nine at the consumer-tech company. Then three lines at their own scope: the revenue model, the targets with consensus, the proposal. End on your own reason for this role, which only you can supply | A warm opener that is still scored, and the arc C3 must agree with |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | The quote carries daily use, not purpose or result. Answer slot: name a real use and what changed because of it, in your own words; if there is none beyond daily use, say so plainly. Casual register, scored answer | Covers the JD's AI plus (F6); JD because it scores the stated plus, Conversational because of how it is asked |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has run sales ops and set quotas?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations"; "No classic sales-ops or quota-setting experience." | Pause, restate the question, then hold on the quotes: "I built a partner-level revenue model used in carrier negotiations, and I set annual volume targets with cross-org consensus." Concede once and specifically: "I haven't had classic sales-ops or quota-setting experience." Do not claim to be better; hold through two follow-ups by repeating what the quotes carry | The time-boxed form of C1; JD with EXP, because the gap and the strengths both come from F4, F5 and F7 |
| F2 | "That ~$400M figure — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change." Hold that through two follow-ups by returning to the proposal. Then concede specifically, in your own words, what you did not own. The quote does not say you built, launched or measured it | Persona stem on the headline number (F1); EXP because it probes attribution |

### G. Values / Behavioral

Northwind's published values are not in hand and no values-style round is detected, so these are scaffolds and no values cheat sheet is included.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A scaffold: pick a time with a named stake, a moment you did not fold, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Persona stem; lowest weight because no values round is detected |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A scaffold: pick a decision where the two actually conflicted, name the metric, and say what it cost. If none comes to mind, say so plainly and say how you would weigh it | Persona stem; lowest weight, kept so the style is never met for the first time live |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| own GTM strategy for two new product lines | D1, D2, E1 |
| identify whitespace across land/adopt/expand/renew | D3, C2, A4 |
| run independent analysis in SQL and Tableau | B3, B2, D3 |
| partner-motion design experience required | A5, B2 |
| strong cross-functional influence | A1, A2, A3 |
| AI experience a plus | E2 |
| sales-ops and quota-setting familiarity (role-family) | C1, F1, B4 |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent much of your career in pricing and monetization roles. What did that teach you that you now apply to sales strategy?" | Tied to Dan's own path; turns the interview into a peer conversation and shows you researched him |
| R2 | "You also spent a chapter at an early-stage startup. What carried over to a company this size, and what did not?" | Tied to his path; invites the one signal in his profile you have not used |
| R3 | "What could a new person in my seat do in their first month that would genuinely help your team?" | The reciprocity question for a peer: shows you reduce his load rather than add to it |
| R4 | "Where does the seam between sales strategy and the new-product GTM sit today, and where do you expect it to blur?" | Follows A1 and shows you think in seams, not turf |
| R5 | "With bundling by a larger vendor the main threat, how is that shaping the targets for the two new lines?" | Shows you read the strategy and puts a CO question to someone who sees the numbers |
| R6 | "What does reaching profitability change about how new-product bets get prioritized?" | Ties to a stated priority and to Dan's monetization spine; avoids a generic closer |

## 8. Sources

Provided in your message: the role and JD highlights; Priya's background summary; Dan's profile self-description and career spine; your research note (three priorities, the Compass launch, the bundling threat). The JD is highlights only, not full text.

Searches sent: "Northwind Data company values principles" — refused. "Dan Kovac Director of Sales Strategy Northwind Data" — refused.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Every call refused. Would have themed G1 and G2 on published values; the cheat sheet stays absent either way, because no values round is detected |
| 2. `Northwind Data interview process, sales strategy` | skipped | Your words fix the loop: one 60-minute conversation with a peer |
| 3. `Northwind Data strategy` / recent news | skipped | Your research note already supplies the priorities and the bundling threat |
| 4. `Dan Kovac Northwind Data` | unavailable | Every call refused. Would have added public talks and writing to section 4 and a tailored reverse question |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The supplied JD highlights fix the fit snapshot and the JD-tagged questions |

## 9. Upgrade menu

- Full JD text → the six highlight rows become exact quotes, and any mid-list requirement the highlights omit gets a question
- Priya's CV, or the artifacts behind it (the revenue-model workbook or deck, the target-setting memo, the store-surface proposal and its measured result) → F1, F3, F4 and F5 move from medium toward high, and the number-defense rows (B1, B2) get inspected inputs
- Priya's account of what she did on the F1, F2, F4 and F6 rows, stated outside a drill → A5, B2, C2 and E2 turn from answer slots into story-mapped guidance
- Dan's own talks, posts or profile text, or permission to run the refused searches → section 4 gains his public themes and R1 and R2 gain specifics; a deeper research pass would cost up to 6 more searches and 2 more fetches and several more minutes
- Northwind's published values page → G1 and G2 become mapped to named values
- The recruiter's stated focus areas, or any pre-declared deliverable → coverage of any graded assignment
- Prep time available → a prioritized prep triage
- A schedule, if later rounds are added → per-round mini-packs
- `tuesday-dossier.md` → verified evidence and risks would carry in and sharpen the highest-ROI objection
