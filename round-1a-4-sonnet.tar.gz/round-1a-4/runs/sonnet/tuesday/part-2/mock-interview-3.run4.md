I've read the playbook and I'm now running the research for your Stripe prep pack: Stripe's published values, its interview process for this role, and its recent strategy.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-3-denied-90778ddd/Stripe_product-operations-manager_interview_pack.md`. It has 20 questions across seven interviewer styles, plus reverse questions and a fit worksheet.

- **No Stripe research:** web search permission was refused, so the pack has no Stripe-specific facts. The values, the interview loop and the strategy questions are generic. Read Stripe's own pages before the interview.
- **Flat weights:** I didn't know who you're meeting or how the final round is structured, so the interviewer styles are weighted evenly.
- **Worksheet only:** with no job description or background, the fit snapshot is a worksheet. The pack gives you ways to choose your own stories and writes none of them for you.

Say the word and I'll play the Skeptic on B1, the "weakest on day one" question the pack flags as your highest-value prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposes, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who is the final round with (future manager, peer, skip-level or cross-functional), is it one conversation or several, and did the recruiter mention any focus areas or an assignment?
Can you paste the job description and your resume or a short summary of your background? I can proceed without them, but they would turn most of the generic rows into your own story maps.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe

**Round:** final round. Who you meet, and whether it is one conversation or several, is not established.
**Interviewer(s):** none named.
**Built on:** your note alone (company, role, final round). No job description, no background and no research were available, so everything below is labeled `[generic]` and no Stripe-specific fact appears. The upgrade menu at the end says what each missing input would change.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding for a spoken answer, not a script: every story has to come from your own experience, in your own words.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Fit snapshot

No background or job description was supplied, so this is the worksheet variant: the requirements are role-family patterns written as plain prose, not quotes, and every evidence cell is empty until you add your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinating work across several teams toward a shared launch or deadline (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is an occasion where several teams depended on you and you can say what you personally did. Selection scaffold: pick an occasion with a named stake, your own part in it, and how it ended. If no such occasion comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Designing or improving an operating process such as a planning cycle, review or launch checklist (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed, with what it replaced. Selection scaffold: pick one where you can say what was different afterwards and who used it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Using data to decide and to show whether something worked (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a figure you can explain end to end: how it was counted, what it is sensitive to, which assumption you would defend least. Selection scaffold: pick a figure you could survive two follow-ups on. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influencing people you do not manage (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a disagreement with a peer or senior person where you can name what you asked for and what happened. Selection scaffold: pick one with a real stake and an intact relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Prioritizing and communicating under ambiguity to senior stakeholders (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a moment you had to choose what not to do and tell someone senior. Selection scaffold: pick one where you can say what you dropped and how you said it. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Learning an unfamiliar product domain quickly (role-family pattern, no JD) | none given | none | [generic] | discovery | Strong evidence is a domain you entered cold and the first thing you did to learn it. Selection scaffold: pick one and be ready to say what you learned first and from whom. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

No requirement here is a gate (a licence, location, schedule, pay or work-authorization term), because no posting was supplied to state one. If the real posting states any, they are surfaced as gates, not bridged.

## Persona table

Weights are flat because the relationship and the round structure are unknown; they start from the blended priors for a hiring manager, a peer and a cross-functional interviewer, which is the mix a final round can contain. Recalibrate if you know who you are meeting.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems set in the role: plan this, diagnose that | Higher: a hiring manager is the most likely single interviewer and a role like this is easy to test with a live problem. Bank A, 4 questions | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of gaps, motivation and fit | Higher: a final round is where a hiring manager derisks the hire, and no background was shared to say where the gaps are. Bank B, 4 questions | Rehearse the most predictable objection until it is boring; calibrated candor over bluffing |
| Data-Driven Prober | Asks how a figure was counted | Middle: operations roles trade on numbers. Bank C, 3 questions | Know what you can and cannot say about how each figure was counted; name the weakest assumption first |
| Peer Evaluator | Where the seam is, what you would need from them | Middle: a peer or cross-functional partner is a likely final-round voice. Bank F, 3 questions | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Values / Behavioral | Scenario probes, STAR-shaped | Lower here: no loop source says there is a values round, so none is assumed. Bank D, 2 questions | Mapping stories to published values waits on research; for now, we for context and I for contribution |
| Conversational / Rapport | Friendly, unstructured, still scored | Lower: likely as an opener or closer. Bank E, 2 questions | A rehearsed 90-second arc; treat casual questions as scored |
| Pressure | Time-boxes, devil's advocate | Lower: possible with a skip-level; nothing here points to one. Bank G, 2 questions | Pause, restate, hold a position through two follow-ups, concede specifically |

## Question banks

Coverage of the role-family requirements above:

| Requirement | Questions | Note |
|---|---|---|
| F1 | A1, A3, F2 | |
| F2 | A1, C3 | |
| F3 | A2, C1, C2, C3 | |
| F4 | A3, B1, D1, F1, F2, F3 | |
| F5 | A3, D1, G1 | |
| F6 | A4, B1, B3 | |
| Stated JD requirements | none, and why | No JD was supplied; this table rechecks against the real posting once you send it |

Highest-ROI prep: B1. With no background shared, the likeliest objection is the general one every candidate meets, which part of the job you would be weakest at on day one, and a rehearsed non-defensive answer changes the interview. Send your background and this slot is replaced by the sharper objection it exposes.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch the plan for getting a cross-team product launch ready in three weeks. What do you need to know first?" | CASE | [generic] | Clarify before structuring: what launching means here, who has to sign off, what a failed launch looks like. Then objective, the groups involved, an approach with milestones, how you would measure readiness, the main risks. Think aloud and challenge one premise. The question needs no claim about your past, so the guidance makes none | F1 and F2 pressed as a live problem; CASE because it scores structure, not a past event |
| A2 | "A launch metric dropped 20 percent the week after release. Diagnose it." | CASE | [generic] | Ask what the metric measures and how it is counted, whether anything else changed that week, and who is affected. Split the drop (instrumentation, segment, product, external), say which you would check first and why, and what would change your mind. Say plainly what you could not tell without data | F3 as a live problem; this is a persona stem for the Case persona |
| A3 | "A product team and a go-to-market team disagree on whether a feature is ready, and you own the process, not the decision. What do you do?" | CASE | [generic] | Clarify what ready means to each side and who decides. Then the facts both sides would accept, a way to surface the risk without taking the decision, an escalation path, and what you would record. Show spine and tact together | F1, F4 and F5 in one scenario; the question assumes nothing about your history |
| A4 | "What do you see as the main priorities of Stripe's product organization right now, and how would this role serve them?" | CO | [generic] | This pack holds no researched Stripe strategy, so it supplies none. Before the interview read Stripe's own recent publications yourself, then bring one point everyone prepared would name, to prove grounding, and one thesis of your own with your reason. Say where each came from. If you have not read enough to answer, say what you do know and what you would want to learn first | F6 and the company-altitude test; `[generic]` because research could not run, which is the honest cost |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal. Choose the answer from your own honest self-assessment, say it plainly in one sentence, then give a concrete plan for your first weeks as a plan, never as a past achievement. Hold it through two follow-ups without adding claims. If no weakness comes to mind, say so plainly, then name what you would most want to learn from the team first | Persona stem for the Skeptic; F6 is where a new domain presses hardest |
| B2 | "Why this role, why here, and why now?" | EXP | [generic] | Three short parts, each in your own words, consistent with each other. The reason for here has to come from something you have read at Stripe yourself, not generic praise. If one part is still unclear to you, say what is clear and what you are still weighing | Skeptic's motivation-consistency check; EXP because it tests whether your story survives cross-examination |
| B3 | "What would you do in your first thirty days with us?" | JD | [generic] | Say it as a plan: who you would listen to first, what you would read, what you would not change yet, what you would ask for. A plan is not a claim about your past, so nothing here needs a quote. Name one thing you would check before acting | F6 as a ramp plan; JD because it tests the stated job |
| B4 | "What would make you hesitate about taking this role?" | JD | [generic] | Answer with a real, honest consideration and what would resolve it, stated calmly. Avoid a hidden compliment. If nothing is making you hesitate, say so plainly and say what you will want to confirm before accepting | Skeptic probe of fit and honesty |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick one number from your past work and walk me through how it was counted." | EXP | [generic] | Selection scaffold: choose a figure you can take through its inputs and how it was counted, the one assumption you would defend least, and exactly which part of the result was yours. Name the weakest assumption before they ask. If you do not know how a figure was counted, say so plainly and choose another, or say what you would want to check | F3; the pack supplies no method or baseline because none was provided |
| C2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | A follow-up to C1. Answer in your own words with the assumption and what it would change if wrong. If you cannot name one, say so plainly and say how you would test it | Follow-up depth of two levels, the prober's habit |
| C3 | "What would you measure to know whether a new operating process for product launches was working?" | CASE | [generic] | A live design question. Start from what the process is for, then a few measures with a reason each, what would count as success, and how you would avoid measuring only what is easy. The question presupposes nothing about your past | F2 and F3 together |

### D. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, what you said and to whom, and what happened. Choose one where the hard truth actually landed. Use we for context and I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 and F5; a Values persona stem, with no Stripe value mapped because the values page could not be fetched |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick an occasion where you can name the metric, the customer need and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Values persona stem; F4 |

### E. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc yourself from your own sentences: where you started, the turning points, why this role. The pack writes none of it because no background was shared. Rehearse aloud once with a timer | Rapport persona stem; casual questions are scored |
| E2 | "Before we wrap up, what questions do you have for us?" | JD | [generic] | Use the reverse questions below. Never answer that you think they have covered everything | Rapport interviewers weight this slot as a preparation signal |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our teams sit side by side. Where is the seam between product operations and product, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claiming to know the seam: who owns the decision, who owns the process, how a disagreement is surfaced early. Say what you would bring their team, not only what you would need | F4; Peer persona stem |
| F2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick an occasion where credit was shared and name how you handled it. Show spine and tact together. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1 and F4 |
| F3 | "What would you need from me in your first month?" | JD | [generic] | Reciprocity: name two or three specific things you would ask for, and one thing you would offer back. Keep it about the work, not the person | Peer persona stem; F6 |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate the question, then answer in what you can truthfully stand behind. Hold it through two follow-ups, then concede one specific uncertainty without folding on the core. Say only what you have told the interviewer | F5; the hold is only what your own account carries |
| G2 | "Take the result you chose for C1. How much of it was actually you?" | EXP | [generic] | Say plainly which part was yours, which was shared, and which was someone else's, in your own words. Precise attribution beats a bigger claim, and a probe exists to catch the bigger claim. If part was not yours, say so | F3 and F4; attribution honesty |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would tell you, at ninety days, that I was on track?" | Shows you think in outcomes and gives you a yardstick to hold them to |
| R2 | "Where do product operations and product management divide ownership of launch readiness today?" | Tests the seam directly and shows you know where role ambiguity bites |
| R3 | "Which cross-team handoff do you most want this role to improve?" | Surfaces the real problem behind the opening |
| R4 | "How does the team decide what to stop doing?" | A prioritization question that shows judgment |
| R5 | "What would make you hesitate about hiring me, and can I address it now?" | The Skeptic's question put to you, in a final round where you can still answer it |
| R6 | "What does the loop after this conversation look like?" | A process question with a preparation reason; it also tells you whether the later sessions change your prep |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your own experience, scope, figures or results | No background was supplied, so no candidate sentence exists to quote | Tell each story in your own words from your own material. The pack supplies selection scaffolds and answer instructions, never a past |
| Any statement of Stripe's strategy, values, products or loop as fact | Research could not run; nothing about Stripe is traceable to a source | Read Stripe's own pages yourself before the interview and cite what you read |

## Sources

Provided documents: none beyond your message (Stripe, Product Operations Manager, final round).

Searches sent, all refused for permission, so nothing came back and nothing from them is used:

- "Stripe operating principles values": refused
- "Stripe interview process Product Operations Manager": refused
- "Stripe strategy 2026 stablecoins agentic commerce annual letter": refused
- "Stripe Product Operations Manager job posting responsibilities": refused

Research tier: L1, searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have fixed the official value names for a values cheat sheet; the section is dropped and VAL questions stay generic |
| 2. Stripe interview process, product operations | unavailable | Would have named the loop's rounds; persona weights are flat and the structure of your final round is not asserted |
| 3. Stripe strategy and recent news | unavailable | Would have grounded A4 and the CO bank; both stay generic |
| 4. Interviewer name | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the fit-snapshot requirements from role-family prose into quoted, inferred ones |

## Upgrade menu

- The job description text → the six fit rows become quoted requirements, a coverage table keyed to its own list, and any gate (location, schedule, pay) is surfaced
- Your resume or a plain summary of your background → the evidence cells fill with your own sentences, scaffolds become story maps, B1 is replaced by your real likeliest objection, and C1 and G2 get your actual figures
- Who you are meeting and whether the final round is one conversation or several → persona weights re-tuned, and per-session mini-packs if you send the schedule
- Any guidance from the recruiter, including focus areas or an assignment → a build section for any pre-declared deliverable
- Web search permission → Stripe's published values, loop structure and current strategy replace the generic rows; a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, is available on request
- A tuesday-dossier.md from an earlier verification pass, if you have one → verified evidence, per-gap strategy and an absolute prohibited-claims list; never required
