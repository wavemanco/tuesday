Using Read directly instead.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-4-denied-0be7badb/quartzline_product-manager-platform-apis_interview_pack.md`. It has 19 questions and 5 reverse questions. It's built for the hiring-manager conversation, and your dossier supplied the requirements and your confirmed evidence.

The research searches on Quartzline were refused, so there's no values page, loop or strategy material in the pack. The case questions are generic and there's no company-knowledge bank. Pasting in anything you have on the company would fix that.

The pack names the objection from your dossier as the highest-ROI prep. A1 rehearses it: concede the PM title and roadmap plainly, bridge only from your three quoted evidence lines, and name the limit on the roadmap-input sessions before they probe it.

Say the word and I'll play the hiring manager on A1, with two follow-ups.
I can also save an updated `tuesday-dossier.md` recording what this prep exposed, for later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** one 45-minute conversation with the hiring manager, Thursday (your words). Interviewer name not given, so there is no interviewer read. Built from your underwriting dossier; Quartzline-specific research did not run (see Sources), so company-specific content is generic or absent.

## How to use this pack

Personas are how a question is asked; types are what it scores. Guidance is scaffolding for a spoken answer, not a script. Where a row says "answer slot", it is an instruction for the interview: fill it with what actually happened, in your own words, or take the honest second branch.

| Type | What it scores |
|---|---|
| VAL | Behavior against a company's published values (none read for Quartzline, so no VAL bank) |
| EXP | Whether your experience claims survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy (not covered: no research ran) |
| CASE | A live problem from the role, reasoned out loud |

## Prep triage

Two days, Tuesday to Thursday. Do these in order; everything else is insurance.

1. A1, the objection your dossier names. Say it aloud until it is boring, including both follow-ups.
2. A2, A4, C1, C2: the questions where your quoted material is thinnest or most likely to be probed.
3. B2 and B5: the case structure, practiced once each with the clarify-first opening.
4. Pick three reverse questions (R1 and R2 first) and know why you are asking each.

Everything else is insurance.

## Fit snapshot

Requirement lines are the dossier's `role_profile` text, standing as the JD. Evidence is quoted from the dossier's `verified_candidate_evidence`, word for word; the dossier's confidence notes are carried in the Confidence and bridge columns, not in the quotes. Confidence grades the quoted claim; the gap type carries how far it reaches.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [inferred] | transferability | Dossier strategy for this row is `bridge`: adjacent work, positioned as adjacent and never as product management experience. Words stay at the quotes' scope. The sessions line is confirmed with limited inspectable proof, so expect a probe and state its limit before it is extracted. Plain acknowledgment, sourced by `prohibited_claims: "Having held a product manager title or role"`: "I haven't held a product manager title." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile | none given | none | [grounded] | capability | Dossier strategy for this area is `acknowledge_gap`, and `prohibited_claims: "Having owned a product roadmap"` bars the claim. Words: "I haven't owned a product roadmap." Then how you would learn the roadmap, said as a plan and never as a past. No bridge and no answer slot on this row |
| F3 | "Shipped API or platform products" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [inferred] | transferability | The dossier lists no weak-area row for this requirement, so this grading is the pack's own reading. Your quote says you led integrations of the vendor's REST APIs, not that you built them, and the words stay there. The 30+ counts integrations. Inspectable proof exists (the playbook, per the dossier) |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile | "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote touches the requirement without showing whether the playbook covers docs or schemas. Answer slot: the requirement's wording makes a probe on your hands-on use likely. If you worked with API docs or schemas, say how, in your own words; if you did not, say so plainly and say how you would build the fluency |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | Customer-facing and product-facing work is carried by the quotes; your material does not show the engineering or sales sides. Answer slot: if you worked with either on those integrations, say who and how; if you did not, say so plainly and stay with the customer side |
| F6 | "Agile delivery experience" — dossier role_profile | none given | low | [grounded] | discovery | Dossier strategy is `clarify`, and no verified entry speaks to this requirement, so nothing about your past goes in. Answer slot in D3: the requirement's wording is the interviewer's likely probe; if you worked that way, say how; if you never did, say so plainly and say what you would want to confirm about how this team defines it |
| F7 | "Run discovery with integration partners" — dossier role_profile | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | transferability | The sessions line is adjacent to partner discovery and stops at feeding product. Confirmed with limited inspectable proof, so volunteer the limit: use the quote's own terms and add nothing about what happened next. A session agenda or notes would raise this band |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile | none given | low | [grounded] | discovery | Nothing quoted speaks to specs or to squads. Answer slot in B4 and D1: if you wrote specs or worked with an engineering squad, say what and how; if you did not, say so plainly and answer the case from structure |
| F9 | "Define and track adoption metrics" — dossier role_profile | none given | none | [grounded] | discovery | Nothing quoted speaks to adoption metrics, and you have not stated an absence. Answer slot in C3: if you tracked how integrations went, say what you tracked; if nothing was tracked, or it was not yours, say so plainly and say what you would measure first |

## Persona table

Relationship prior for a hiring-manager round: Case/Strategist and Skeptic dominate. Adjustments: the dossier names a specific objection, which raises the Skeptic; the dossier's unresolved question on authority versus the two squad leads raises the Peer Evaluator even in a manager round. No interviewer information, so no signal-based adjustment. Your own words establish one session, so no archetype fallback is used.

| Persona | Bank | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | A (5) | Quiet, persistent probing of the title and roadmap gap | Highest: hiring-manager prior, plus the dossier's named objection | Rehearse A1 until boring; bridges only from quoted adjacent work, limit named first, plus a ramp plan |
| Case/Strategist | B (5) | Live problems from the role: adoption, squads, specs | High: hiring-manager prior; they are buying capability on their own roadmap | Clarify first, then objective, approach, metrics, risks; challenge one premise respectfully |
| Data-Driven Prober | C (3) | Line-by-line on the 30+ and the playbook | Medium: the one headline number and the one inspectable artifact are magnet targets | Know what you can say about how the 30+ was counted; say plainly where you do not know |
| Peer Evaluator | D (3) | Seam with the two squad leads; disagreement style | Medium: the dossier flags authority versus the squad leads as unknown | Propose seam principles, not a seam you do not know; show spine and tact together |
| Conversational | E (3) | Biography opener, casual tooling and discovery questions | Medium: an opening biography question is likely and still scored | A 90-second arc built from your three quotes; treat casual questions as scored |
| Pressure | none | Time-boxed challenge | Low for this round; the hold-then-concede structure is rehearsed inside A1 and A2 | Hold through two follow-ups, concede specifically |
| Values/Behavioral | none | Scenario probes against published values | Low: no values round documented, no published values read | Not rehearsed here; see Upgrade menu |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; `prohibited_claims: "Having held a product manager title or role"`; `prohibited_claims: "Having owned a product roadmap"` | The highest-ROI prep in this pack, and the underwriter named it. Concede first, because it is true as asked: "I haven't held a product manager title, and I haven't owned a product roadmap." Then the adjacent work at its own scope, in those words: you led the integrations from scoping to go-live, you wrote the playbook, you ran quarterly roadmap-input sessions that fed client evidence to product. The sessions line is confirmed with limited inspectable proof, so name its limit before you are asked: your words stop at feeding product. Close on the ramp, said as a plan: learn which roadmap decisions sit with the PM and which with the squad leads, and how adoption is measured. Describe what you did and let them draw the inference. Follow-up 1, "What roadmap decision have you actually made?": hold by returning to the three quotes, concede again without adding. Follow-up 2, "So you've never set priorities for an engineering squad?": "I haven't set prioritization for an engineering squad," then back to the integrations at their scope | F1 and F2 are where the title requirement presses hardest; JD because it scores R1, with the dossier's allowed strategies (bridge, acknowledge_gap) binding every clause |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] `allowed_interview_strategy: acknowledge_gap` on the roadmap area; `prohibited_claims: "Having owned a product roadmap"` | Pick the true answer your dossier gives: owning the roadmap. "I haven't owned a product roadmap" is the plain acknowledgment, followed by the ramp as a plan: what you would learn first and from whom. Do not offer a bridge here; the underwriter looked and found none for roadmap ownership. Naming the weakness first scores as calibration, and the follow-up has nothing left to extract | F2 is the gap the dossier marks as capability; the Skeptic stem asks for it directly |
| A3 | "You led 30+ client integrations of the vendor's REST APIs — what makes that preparation for deciding what those APIs should do next?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer in the quote's own terms: the stages you led, scoping through go-live, and the 30+ counts integrations. Say what the work was and let the interviewer decide what it prepares you for; do not say it proves you can decide what APIs should do. The pack's own observation is that your quote says integrations of the vendor's REST APIs, not building them, so do not use "built", "shipped" or "designed" | F3 is where R2, a must-have, is contested; JD because it scores the stated requirement |
| A4 | "You ran quarterly roadmap-input sessions that fed client evidence to product. What happened to that evidence afterward?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The underwriter marked this claim medium: confirmed, little inspectable proof, so expect exactly this probe. Say what the sessions were in the quote's words. Answer slot: if you know what product did with the evidence, say so in your own words; if you do not know, or it was not yours to follow, say so plainly and return to what the sessions were. Do not claim the sessions changed what was built | F7 is the thinnest-evidenced claim in the pack; EXP because it tests what was actually yours |
| A5 | "Why move from integration work into product, and why here, and why now?" | EXP | [generic] | No sentence of yours states a motivation, so this is a selection scaffold: your actual reason, tied to something specific about the role, that is consistent with the story in E1. Quartzline specifics were not researched; use only what you know and say it as yours. If no clear reason comes to mind, say so plainly, then give the nearest true thing your material does carry, or how you would decide | The standard Skeptic motivation probe for a career change; EXP because it tests consistency of the story, scored in the interview |

### B. Case/Strategist

Every row here is a live problem: it asks about no past of yours, and the guidance makes no claim about it.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has flattened for two quarters. How would you work out why, and what do you need to know first?" | CASE | [generic] | Clarify first: what counts as adopted, for which partners, since when. Then segment (new versus existing partners, endpoints, integration stage), form two or three hypotheses, name the data each needs, and say how you would act on each. The first thing you need is how adoption is measured today, which is also reverse question R2 | The JD names adoption metrics as a responsibility (F9); CASE because it is a live diagnosis |
| B2 | "Two squads want different things next quarter and you have capacity for one. How do you decide, and who has to agree?" | CASE | [generic] | Ask who decides before you decide: which calls the PM makes alone and which belong to the squad leads. Then criteria (partner evidence, effort, dependencies, reversibility), how you would test it with each lead, and how you would record the decision. Saying the authority question aloud is the point; it matches R1 | The dossier's open question on authority versus the squad leads (F8); CASE because it is a live trade-off |
| B3 | "A partner's integration keeps failing UAT on the same endpoint. Is that docs, schema or product, and how do you tell?" | CASE | [generic] | Separate the three: reproduce the failure, check whether the docs and schema agree with actual behavior, check whether other partners hit it. Say what evidence moves you from one hypothesis to the next, and who you would pull in. Think aloud | The technical-fluency requirement (F4) as a live problem; CASE because it scores reasoning |
| B4 | "A v1 endpoint partners still use needs to be deprecated. What goes in the first page of the spec?" | CASE | [generic] | Problem and who is affected, goal, scope and what is out of scope, migration path and timeline questions, partner communication, success measure, open questions. Say which items you would need to learn from the squads before committing | JD line on writing specs (F8); CASE because it is a live artifact request. If you have written specs, the slot in F8 covers it |
| B5 | "Walk me through your first 90 days. What do you need to learn before you write a roadmap?" | CASE | [generic] | A plan, not a past: the decision map with the two squad leads, current adoption measures and baseline, partner conversations, the existing roadmap and its history, then a first proposal for review rather than a unilateral one. This is the ramp plan the dossier allows for the roadmap gap | F2 acknowledged gap, converted into a plan; CASE because it is a live planning prompt |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot, in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part of each integration was yours. If you do not know exactly how it was counted, say so plainly. The 30+ counts integrations, not clients or projects, and the pack supplies no method or definition | The one headline number; EXP because it tests whether the figure survives scrutiny |
| C2 | "Walk me through the integration playbook. Who uses it, and what does it cover?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | You wrote it and your team uses it; those are the beats the quote states. Answer slot: the technical-fluency line makes a probe on what it contains likely. Say what it covers in your own words; if you cannot describe its contents, or part of it was not yours, say so plainly and stay with the fact that you wrote it. The dossier marks it inspectable; offer to show it only where you are free to share it | F4 and the one inspectable artifact; EXP because it tests what was actually yours |
| C3 | "How did you know those integrations succeeded, and what did you track?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: the JD's adoption-metrics line makes a probe on what you tracked likely. If you tracked anything, say what and how, in your own words; if nothing was tracked, or it was not yours, say so plainly and say what you would measure first | F9 has no quoted evidence behind it; JD because it scores the adoption-metrics responsibility |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The two squad leads will be your closest partners. Where is the seam between your calls and theirs, and what happens when you disagree?" | JD | [generic] | Do not pretend to know the seam; the dossier lists it as unknown. Offer principles: who owns the problem and who owns the solution, how a disagreement gets escalated, and what you bring them (partner evidence, a clear problem statement). Then ask how the seam works today, which is reverse question R1. Answer slot: if you have worked beside an engineering lead on scope, say how; if you have not, say so plainly and answer from principles | The authority unknown (F8); JD because it scores the squad-delivery responsibility |
| D2 | "Tell me about a time you disagreed with an engineering lead about scope or timing." | JD | [generic] | A selection scaffold, since no quoted sentence carries one: pick a disagreement with a named stake, a position you held and where you moved, and a relationship still intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Stakeholder management across engineering (F5); JD because the requirement names engineering |
| D3 | "How does delivery get planned and run in the teams you have worked in?" | JD | [grounded] "Agile delivery experience" — dossier role_profile | Answer slot: the agile-delivery line is the interviewer's likely probe. If your teams worked that way, say how, in your own words; if you never worked that way, say so plainly, and say what you would want to confirm about how this team defines it. Nothing about your past is assumed here | F6 is a `clarify` area with no matching quote |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each a clause the quotes state: the integrations you led from scoping to go-live; the playbook you wrote; the quarterly sessions that fed client evidence to product, with its limit named. The quotes give no dates or order, so tell them in the order you actually lived them. End with your reason for this role, in your own words; if none comes to mind, say so plainly | The biography opener is near-certain in a manager round; EXP because it tests the story you tell about your own history |
| E2 | "What have you been working with lately in API docs or schemas?" | JD | [generic] | A selection scaffold: name one specific thing and what you did with it. If nothing comes to mind, say so plainly, and say what you would read or build first | A casual question on a requirement (F4); JD because the requirement names it. Casual-register questions are still scored |
| E3 | "How would you run a discovery conversation with a partner who says the API does not fit their use case?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | A hypothetical, so structure it: what they were trying to do, what they tried, what they would change, the need behind the request, and what you do with the evidence afterward. You may anchor on "scoping, requirements" in the quote's own words; add no incident | F7: the responsibility to run discovery with integration partners |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier's risk: authority versus the two squad leads is asserted in the JD but not evidenced. It reads as diligence, and you need the answer before accepting |
| R2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier's second risk: adoption metrics are a named responsibility with no baseline stated. It also tells you what B1 and C3 will be scored against |
| R3 | "Where does partner feedback reach the roadmap today, and who carries it?" | Connects to the roadmap-input sessions in your quoted material without claiming more than they say, and surfaces how your integration-side vantage would be used |
| R4 | "What would you want someone coming from the integration side to learn first?" | Invites the manager to name the ramp themselves, which turns the title objection into a plan they own |
| R5 | "What does a good first quarter look like in this role?" | Gives you a success definition to check against R2 and R1; works as a close for any persona |

## Prohibited claims

What this pack will not coach, with the basis and the honest form. Built before the banks, so every guidance cell above was written against it.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | Plain acknowledgment: "I haven't held a product manager title." Then F1's quotes at their own scope |
| Having owned a product roadmap | Dossier `prohibited_claims`; `acknowledge_gap` area F2 | Plain acknowledgment: "I haven't owned a product roadmap." Then the ramp as a plan. No bridge and no slot |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` | Plain acknowledgment: "I haven't set prioritization for an engineering squad." Then the integrations at their scope |
| Shipped an API or platform product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your quote says integrations of the vendor's REST APIs, not building them |
| Shaped the roadmap through the roadmap-input sessions | Inflated form of F7's quote | The quote at its own scope: sessions feeding client evidence to product. The limit is the pack's observation: your quote stops at feeding product. A4's slot asks only what you know happened next |

## Sources

Provided: `tuesday-dossier.md`, version 1.1, generated 2026-08-14 by job-underwriter. Consumed: `handoff_to_mock_interview` (verified evidence, weak areas with allowed strategies, objection, risks, employer questions, prohibited claims) and `role_profile` (requirements and responsibilities, standing as the JD). The dossier carries no `evidence_map`, `evidence_state` or `risk_register`, so rows F3, F5, F7, F8 and F9 are graded by this pack, labeled accordingly. The requirement lines are the dossier's copy of the JD, not a fresh read of the posting.

Searches sent, each refused (permission was not granted): "Quartzline company values", "Quartzline interview process product manager", "Quartzline API platform strategy news". Nothing was used from them.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Every call refused. Would have moved a values cheat sheet and VAL bank; both are absent |
| 2. Quartzline interview process, product manager | unavailable | Every call refused. Would have moved persona weights from a documented loop; weights rest on your own words plus the hiring-manager prior |
| 3. Quartzline strategy and recent news | unavailable | Every call refused. Would have moved CO questions and made the B bank company-specific; the B bank is generic |
| 4. Interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. Representative JD for the title | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Quartzline research (a values page, interview guide or strategy notes pasted here, or search permission granted) → a values cheat sheet if a values round exists, CO questions, and a B bank tied to their actual priorities. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) is available once, on your say-so
- The interviewer's name → a tailored reverse question and persona weights read from their public footprint
- Recruiter notes on format or focus areas → coverage of anything pre-declared for the conversation
- Your reason for moving into product and for this company, in your own words → A5 and E1 move from a scaffold to a mapped story
- A roadmap-input session agenda or notes (the inspectable proof for that claim) → F7's medium band can rise and A4's probe has something behind it
- Your answers to the slots in F4, F5, F8 and F9, or a statement that they do not apply → those rows move from `discovery` to a mapped story or a plain acknowledgment
- A fresh paste of the posting, since the dossier's JD text is from 2026-08-14 → confirms the requirement lines still match
