Searches for Atlas Freight were refused in this session, so the pack rests on your JD and your message only. I'm writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-2-denied-a37035ef/atlas-freight_operations-manager_interview_pack.md`. I built it for a hiring-manager round, since you don't know who's interviewing you. It has 20 questions across six interview styles, a table mapping each JD line to your evidence, and 7 reverse questions.

My web searches on Atlas Freight were refused in this session. The pack rests only on your JD and your message. It has no company values, loop structure or strategy questions, and the interviewer styles are weighted by a generic loop, not Atlas Freight's real process.

The most likely objection is the step from your 3 supervisors to the JD's 12 across four sites (B1). The pack names it as your highest-priority prep. The next two to rehearse are the Power BI gap (B3, B5) and the "how was the 40% counted" probe (C1, E2).

The pack won't coach you to claim what your sentences don't carry:
- **Leadership scale:** you led 12 supervisors.
- **Multi-site ownership:** you owned several sites.
- **Metrics:** you improved on-time performance or cost-per-shipment. Your result is on mis-picks.
- **Power BI:** you've used it.

Several rows hold a slot for you to fill in your own words, such as how many of your 7 years were leadership. If your answer is "that wasn't me" or "that didn't exist," the pack treats that as a valid answer.

Next steps:
- Say the word and I'll run a live mock drill, starting as the skeptic on B1.
- I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions.
- If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would reshape the pack:
1. Who is the interview with: your future manager, a peer site manager, a skip-level or a recruiter screen? Did the recruiter name any focus areas or ask you to prepare anything?
2. Can you paste your CV? I worked without it, and it could firm up the leadership-years and Excel rows.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas-freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Interviewer: not known. Relationship assumed: hiring-manager round, because your note did not say who you are meeting. Persona weights below rest on that assumption and on a generic loop (screen, hiring manager, panel), not on Atlas Freight's documented process.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for this chat. It has two branches: say what you did in your own words, or say plainly that it was not yours or did not exist, and return to what you can stand behind.

## Prep triage

Sized to a week out. Do these in order.

1. Rehearse B1, B3 and B5 aloud until they are boring. B1 is the highest-ROI prep in this pack: the step from your current supervisors to the JD's twelve across four sites will be raised in some form.
2. Rehearse C1 and E2 (the 40% figure), including the honest "I don't know how that was counted" branch if it applies.
3. Practice the case structure on A1 and A2 out loud, saying the framework before using it.
4. Settle your own answers to the slots in F1, F2, F3, F4, F5 and F7 below, then tell me them so the pack can use them.
5. Pick three reverse questions.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "7 years in warehouse and distribution ops" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says warehouse and distribution ops and a site's surge plan, not terminals and not four sites, and the words stay there: "I ran the site's peak-season surge plan two years running." Answer slot: the JD's four-site line makes a probe on breadth likely. If any of your work covered more than one site, say which and what part was yours; if it was one site, say so plainly and stay with that site |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate is a different measure from the two the JD names, and your material shows no result on either, so the words stay at: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked anything else that changed after the redesign, say what and how you know; if you did not track anything else, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material says three supervisors, not twelve, and the words stay there: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if any earlier role had more people reporting to you, say how many and when; if none did, say so plainly and stay with the three |
| F4 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message | low | [inferred] | discovery | Seven years in ops is what you stated; your material does not show how many of them were in a leadership role, so the pack counts none of them as leadership. Answer slot: say which years you held a role directing other people's work, and your title then, in your own words; if some years had no one reporting to you, say so plainly and give only the leadership years |
| F5 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [inferred] | discovery | Your material says solid Excel, not that you built reporting in it. Answer slot: if you built a report or workbook that others used, say what it showed and who used it; if you used Excel for your own analysis, or someone else built the reporting, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [inferred] | discovery | The quote does not say which program the belt is in, so the pack does not call it Six Sigma or Lean, and your material does not connect it to the pick-path redesign. Answer slot: name the program and body as on your certificate; if you applied it to a project, say which and what part was yours; if it was certification only, say so plainly and stay with "green belt certified" |

No JD line here is a gate (a licence, location or schedule term), so no hard-gate row appears. "5+ years" is graded as experience, not as a gate.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: diagnose on-time, plan across sites, design reporting | High. A hiring manager buying capability for an ops role tends to test it live; weight 5 questions | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise politely |
| Skeptic | Probes the scale step (three to twelve supervisors, one site to four), Power BI, the years of leadership | High. Your own message names the Power BI gap and a supervisor count below the JD's; weight 5 questions | Rehearse B1 until boring; hold what your sentences carry; concede specifically; give a ramp plan as a plan |
| Data-Driven Prober | Goes line by line on the 40% figure and on Excel reporting | Medium. You have one headline metric and the JD asks for reporting; weight 3 questions | Say how the figure was counted if you know, plainly say if you do not, and name the assumption you would defend least |
| Conversational/Rapport | Opens with "walk me through the journey"; casual questions about Lean | Medium. Most loops open this way; weight 3 questions | A 90-second arc built only from sentences you have stated; treat casual questions as scored |
| Pressure | Time-boxed "why you" and "how much was you" | Low to medium. Possible from a manager testing composure; weight 2 questions | Pause, restate, hold through two follow-ups, concede only what is true |
| Peer Evaluator | Seam-splitting between sites, credit across teams | Low to medium. Terminal managers at other sites may sit on a panel; weight 2 questions | Offer principles for seams rather than claiming to know the seam; reciprocity framing |
| Values/Behavioral | Scenario probes mapped to published values | Low. No values round is documented and the generic loop assumes none; no dedicated bank, with its stems folded into D and F | Selection scaffolds ending in an honest branch |

## Question banks

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You take over four terminals on Monday. What do you need to know in your first two weeks before you change anything?" | CASE | [generic] | Structure it: what you would ask for first (on-time and cost-per-shipment definitions and current levels by site, who the supervisors are, where the data lives), what you would watch on the floor, who you would meet, and what you would leave alone until you understand it. Say the framework aloud before using it. The question needs no claim about your past, so the guidance makes none | F1 is the thinnest row against the JD's four-site line, so the first question is a forward-looking plan. CASE because it scores structure, not history |
| A2 | "On-time performance at one terminal drops over a month. Diagnose it." | CASE | [generic] | Clarify first: how on-time is defined and whose clock it uses, what changed, which lanes, shifts or days. Then segment (inbound or outbound, labor, equipment, yard or dock, data quality), form two or three hypotheses, name the quickest test for each, and say which you would check first and why. Challenge one premise politely | The JD's on-time line is a headline requirement and F2 shows no on-time result, so a live diagnosis is the likeliest probe. CASE because it is delivered live |
| A3 | "Cost-per-shipment is rising at one site while volume is flat. Where do you look?" | CASE | [generic] | Define the numerator and denominator before anything else, then split cost by driver (labor, overtime, damages and claims, linehaul, rework), compare against the other sites, and say what you would check first. Close with how you would tell a real change from a reporting change | Covers the JD's second headline metric, which no sentence of yours reaches (F2). CASE because it is a live problem |
| A4 | "Tell me how you would plan a peak-season surge across four terminals at once." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Start from the sentence, at its scope: "I ran the site's peak-season surge plan two years running." Then answer the forward question as a structure, not a history: what you would need to know per site, what must be coordinated across them, what you would measure. Answer slot: the JD's four-site line makes a probe on breadth likely. If any part of that plan reached beyond one site, say which part; if not, say so plainly and say how you would adapt it | F1 holds your best sentence for daily operations under load; the slot keeps the multi-site step honest. CASE because it asks for a plan, EXP in how it starts |
| A5 | "We want a weekly operations report across the four sites. What goes on it and how do you build it?" | JD | [generic] | Start with who reads it and what decision each number drives, then define each metric once (the JD's on-time and cost-per-shipment first), name the sources, and say how you would check that sites compute numbers the same way. Say what you would build in Excel first. Power BI is B3's ground, so do not claim it here | The JD pairs reporting with Excel and Power BI (F5, F6). JD because it scores the stated requirement; CASE in delivery |

### B. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You're over three supervisors today. This role has twelve across four sites. What makes you ready for that step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." State the numbers as numbers: you are over 3 today and this role has 12. Answer slot: if any earlier role had more people reporting to you, say how many and when; if none did, say so plainly and stay with the three. Then a ramp plan as a plan, in your own words: how you would get to know each supervisor and site. Hold through two follow-ups by returning to the sentence, never by adding to it | F3 is the likeliest place to be probed, because the gap is a count the JD states and you have stated. JD because it scores the listed requirement |
| B2 | "The posting asks for five or more years of operations leadership. How does your background meet that?" | JD | [grounded] "7 years in warehouse and distribution ops" | Say what you stated: "I have 7 years in warehouse and distribution ops." Answer slot: say which of those years you held a role directing other people's work, and your title then, in your own words; if some years had no one reporting to you, say so plainly and give only the leadership years. Do not round up | F4 is `low` because your material shows years in ops but not years in leadership. JD because it scores the stated requirement |
| B3 | "This role builds reporting in Power BI. Have you used it?" | JD | [grounded] "never used Power BI" | Say it plainly: "I've never used Power BI." Then say, as a plan, how you would learn it and what you would build first, in your own words, without describing any practice as already done. Pair it only with what your material carries about Excel, at its scope: "solid Excel". Answer slot: if you have started learning Power BI since, say exactly what you have done; if not, say nothing that implies it | F6 is a gap you stated, so the honest answer is short and the plan is what the interviewer can credit. JD because the tool is named in the posting |
| B4 | "Why leave a senior shift manager role for this one, and why Atlas Freight, and why now?" | EXP | [generic] | Selection scaffold, not a story: give your own reason in your own words, tied to lines of the JD you can name, plus anything you have verified yourself about the company. Do not borrow another company's story. If a reason does not come easily, say so plainly and give the nearest true thing, such as what in the posting you would want to own | The skeptic stems for motivation consistency. No company research could run, so the company half cannot be mapped to published facts. EXP because it tests whether your story holds together |
| B5 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI", "currently a senior shift manager over 3 supervisors" | Pick one in plain words and do not hedge across several. Your own sentences name two candidates, the Power BI gap and the supervisor count. Name the one you judge larger, then give the ramp plan for it as a plan. Calibrated candor beats bluffing a competency the interviewer may own | The standard Skeptic opener; F6 and F3 are the two rows it will land on. JD because it scores fit against the posting |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You cut mis-pick rate 40%. Walk me through how that number was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | State it at its scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you know how it was counted, say it in your own words, including what it is sensitive to and which assumption you would defend least; if you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F2 holds your one headline metric, and metrics are where probers press. EXP because it tests what survives scrutiny |
| C2 | "When have you used Excel to report on operations performance?" | JD | [grounded] "solid Excel" | Selection scaffold: pick a time a spreadsheet you built informed a decision, with a named metric, an audience, and what changed. If none comes to mind, say so plainly, then give the nearest thing your material carries ("solid Excel") or how you would build the weekly report. Answer slot: if you built a report or workbook others used, say what it showed and who used it; if someone else built the reporting, say so plainly | F5 shows the tool but not the reporting. JD because the posting names it |
| C3 | "Tell me about your green belt: what is it in, and where have you used it?" | JD | [grounded] "green belt certified" | Say what you stated: "I'm green belt certified." Answer slot: name the program and body as on your certificate; if you applied it to a project, say which and what part was yours; if it was certification only, say so plainly. If the pick-path redesign was part of it, say how; if it was not, keep the two separate | F7 is the JD's plus. JD because it scores the stated requirement; the slot keeps the belt from being stretched into a practice |

### D. Conversational/Rapport Builder (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops", "currently a senior shift manager over 3 supervisors", "cut mis-pick rate 40% by redesigning the pick path", "ran the site's peak-season surge plan two years running" | A 90-second arc with only these facts at their own scope: the seven years in warehouse and distribution ops, where you are now, then the pick-path result and the surge plan as the two things you would lead with. Close with why this role, in your own words. Answer slot: add the steps between, in your own words, if they matter; if a step is not worth telling, leave it out | The biography question is scored even when it sounds casual. F1, F2 and F3 are the rows it draws on. EXP because it tests the story against the record |
| D2 | "Lean and Six Sigma are a plus here. What does continuous improvement look like for you on a working shift?" | JD | [generic] | Say what it means to you in your own words: how you decide what to fix first, how you involve supervisors, how you check a change worked. Answer slot: if an example from your own work fits, name it in your own words; if none does, speak to how you would do it | A casual question on a JD plus is still scored (F7). JD because it scores the stated plus |
| D3 | "What would you want your twelve supervisors to say about working for you in a year?" | JD | [generic] | Describe the standard you would hold, in your own words: clarity, follow-through, how you give feedback. The question asks about the future, so the guidance makes no claim about your past | The people-leadership side of the JD's twelve-supervisor line (F3), asked as an aspiration rather than a record. JD because it scores that requirement |

### E. Pressure/Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already run twelve supervisors?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path", "currently a senior shift manager over 3 supervisors" | Pause and restate the question. Hold on two facts at their own scope: "I cut mis-pick rate 40% by redesigning the pick path" and "I'm currently a senior shift manager over 3 supervisors." Say them, stop, and let the interviewer draw the inference. If pushed on scale, concede it as a number: you are over 3 today and the role has 12. Hold through two follow-ups by returning to those facts | The standard time-boxed challenge, aimed at F3. EXP because it tests composure over your own record |
| E2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: say what you personally did in the redesign, in your own words; if others contributed or it was a team effort, say so plainly and say which part was yours. Do not widen the sentence: "I cut mis-pick rate 40% by redesigning the pick path" is the whole claim | Attribution probes exist to catch inflation, so the rehearsal is precision about F2. EXP because it tests what was actually yours |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "If two terminal managers disagree about which site gets a scarce resource, how do you handle it?" | CASE | [generic] | Offer principles, not a claimed seam: agree the shared objective first, use the same definitions and data for both sites, escalate with a recommendation rather than a complaint. Frame it as what you would bring to the other site's team, not only what you need. No claim about your past | A peer on a panel prices what the hire adds to their own site. F1 is about running across sites, and this tests the working relationship rather than the history. CASE because it is a live scenario |
| F2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Selection scaffold: pick a time work spanned teams, with a named contribution of yours and an intact relationship at the end; use "we" for context and "I" for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | Collegial packaging of the attribution probe. No quoted sentence carries a cross-team story, so this is a scaffold. EXP because it tests candor about attribution |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A4, F1 |
| "drive on-time performance and cost-per-shipment down" | A2, A3 |
| "lead a team of 12 supervisors" | B1, D3, E1 |
| "build reporting in Excel/Power BI" | A5, B3, C2 |
| "5+ years operations leadership required" | B2 |
| "Lean/Six Sigma a plus" | C3, D2 |

There is no CO question. Company research could not run in this session, so a CO question would have been generic.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How is on-time performance defined here, and which of the four terminals is furthest from where you want it?" | It starts from the definition, the same move A2 rehearses, and shows you want the real baseline before promising anything |
| R2 | "What does cost-per-shipment include in your reporting today, and who owns the number?" | It asks about the numerator and the owner, which is the cost-per-shipment half of the JD (F2) |
| R3 | "What do the twelve supervisors need most from this role in the first ninety days?" | It turns the scale step (F3) into a question about their needs rather than your limits |
| R4 | "What does reporting look like today, what is in Excel and what is in Power BI, and what should change in my first six months?" | It addresses the Power BI gap (F6) openly, and the answer tells you what to learn first |
| R5 | "What would make you say in a year that this hire worked?" | It gets their success measure on the table and shows you are thinking about being measured |
| R6 | "How are the four sites different from each other, and where should a new manager spend the first weeks?" | It follows A1 in reverse and tells you where the real difficulty sits |
| R7 | "What are the next steps, and who else would I meet?" | It tells you the loop, which this pack could not research, and so which personas to expect next |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led or managed a team of twelve supervisors | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: your material says three supervisors, not twelve. B1's slot stays inside that sentence |
| Owned operations across multiple terminals or sites | Inflated form of F1 | F1's quotes at their own scope. A4's slot asks only whether any part of the surge plan reached beyond one site |
| Improved on-time performance or cost-per-shipment | Inflated form of F2 | F2's quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Mis-pick rate is a different measure |
| Built reporting or dashboards in Excel | Inflated form of F5 | "solid Excel" at its own scope. C2's slot asks only what you built, if anything |
| Has Power BI experience | Negative you stated, F6 | The plain acknowledgment: "I've never used Power BI." No slot |
| Holds a named Six Sigma or Lean certification | Inflated form of F7 | "green belt certified" at its own scope. C3's slot asks only for the program as on your certificate |
| Has five or more years of operations leadership | Inflated form of F4 | "7 years in warehouse and distribution ops" at its own scope. B2's slot asks only which years you directed others |

## Sources

Provided documents: the job description text and your message, which together supply every fit-snapshot quote. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have fed any values or VAL questions and a values cheat sheet if a values round turned up |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. It would have fixed the loop structure and the persona weights, which now rest on the generic fallback |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. It would have supplied a CO question and a company-grounded CASE question |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent:

- "Atlas Freight regional logistics company values" — refused
- "Atlas Freight interview process operations manager" — refused
- "Atlas Freight regional logistics terminals news strategy" — refused

## Upgrade menu

- The interviewer's name, title and relationship to the role (future manager, peer, skip-level, recruiter) → persona weights tuned to them, a reading of their public footprint, and a reverse question tied to their path
- The recruiter's note on focus areas or anything to prepare in advance → coverage of any pre-declared deliverable, and the loop becomes documented instead of assumed
- Your CV → the fit rows quote it alongside your message, and F4 and F5 may move off `low`
- A site scorecard or KPI report showing the mis-pick rate before and after the redesign → C1 and F2 can move from `medium` toward `high`
- Your green belt certificate → F7 can name the program and body instead of asking for them
- Your answers to the slots in F1, F2, F3, F4, F5 and F7, stated outside any drill → those rows become grounded story-maps instead of slots
- Atlas Freight's own values page, careers page or recent news, pasted here → CO questions, a values cheat sheet and a documented loop, none of which could be built without research; once searches are permitted, a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) adds a strategy brief
- A `tuesday-dossier.md` from an earlier check of this role → verified evidence and any absolute limits carried in, instead of rebuilt from your message
