Routing: interview coming → mock-interview. Reading its playbook.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-2-denied-01016ddf/Atlas-Freight_operations-manager_interview_pack.md`. It has 22 questions across seven interviewer styles. I built it for a hiring-manager round, since you didn't say who you're meeting.

- **Research was refused.** My three web searches (company values, interview process, strategy) were denied in this session. Nothing in the pack comes from outside research, and the case and values questions are labeled generic.
- **Top prep item:** question B1. The posting asks for four sites and 12 supervisors, and your material shows a shift and 3 supervisors. Rehearse naming that gap yourself, then giving a plan for closing it.
- **Open points in your material:** how many of your 7 years were leadership years (the JD says 5+ required), and what your Excel work produced. The pack gives you answer slots for these, not scripted answers.
- **Power BI:** you said you've never used it. The pack has you say that plainly and pair it with a plan, not hide it.

I'm offering these, none required:
- I can play one of the interviewer styles live, starting with B1.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
- I can convert the pack to a Word document.

Is the person you're meeting your future manager, a peer, or a recruiter, and has anyone told you what the round will focus on? The answer reweights the whole pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Atlas-Freight_operations-manager_interview_pack.md -----
# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager (regional logistics, 800 employees). Interviewer: not known. Round assumed: hiring-manager round, because the request did not say who you are meeting. Loop: not established, so persona weights rest on the generic pattern (screen, hiring manager, panel), not on Atlas Freight's own process.

## How to use this pack

Personas are how a question arrives; types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Question IDs run by persona (A, B, C and so on; there is no F, so it cannot be mistaken for a fit-snapshot row). Answer slots are instructions for the interview, not questions for you to answer here.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows values, not generic virtue |
| EXP | Whether the CV claims survive scrutiny; what was actually yours |
| JD | The stated responsibilities and requirements of this job, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "ran the site's peak-season surge plan two years running" — your message | medium | [grounded] | transferability | Your material says a shift and a site's surge plan, not terminals and not four sites, and the words stay there: "I'm a senior shift manager over 3 supervisors, and I ran the site's peak-season surge plan two years running." Answer slot: the JD's four sites make a probe on scope beyond one place likely. If any of your work spanned more than one location, or was terminal rather than warehouse and distribution work, say which part and what you did, in your own words; if none did, or it was not yours, say so plainly and stay with the shift and the surge plan |
| F2 | "drive on-time performance and cost-per-shipment down" — JD | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | The quote is about mis-pick rate, which is neither on-time performance nor cost-per-shipment, and the words stay at mis-pick rate: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD names on-time performance and cost-per-shipment, so expect a probe on whether you tracked either. If you did, say what was measured and what moved; if neither was tracked at your site, or neither was yours, say so plainly and stay with the mis-pick result |
| F3 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | Your material shows 3 supervisors where the JD says 12, and the words stay at 3: "I'm a senior shift manager over 3 supervisors." Answer slot: if you have had responsibility for more supervisors at any point, say how many and when; if not, say so plainly and describe the three you lead. Then a ramp plan, said as a plan and never as a past |
| F4 | "build reporting in Excel/Power BI" — JD (Excel half) | "solid Excel" — your message | low | [inferred] | discovery | Derived from the quote: it names a tool and shows nothing about what was built with it. Answer slot: the JD asks you to build reporting, so expect a probe on what. If you built reports, say what, for whom and how often; if your Excel use was something else, say so plainly and say what you would build first |
| F5 | "build reporting in Excel/Power BI" — JD (Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to Power BI exposure, and nothing added to make the gap feel smaller |
| F6 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The quotes show seven years of operations and a current leadership role, and do not show how many of the seven were leadership years. The JD marks the requirement as required, so expect the count to be asked directly. Answer slot: say which years were supervisory or management and what the role was, in your own words; if the leadership years are fewer than five, say the number plainly and describe the span you held |
| F7 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | No gap, but a statement with no certificate inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: "I'm green belt certified." Keep it separate from your other results unless you say the link was real, in your own words |

## Persona table

Weights: the hiring-manager prior puts Case/Strategist and Skeptic first. No loop source establishes Atlas Freight's loop, so the generic pattern applies and adds no tilt, and there is no interviewer profile to adjust from. If you are meeting someone else, tell me and the weights change.

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on four-site on-time performance, cost-per-shipment and peak load | high: hiring-manager prior, and the JD is built around operational outcomes | Clarify, objective, segment, approach, metrics, risks; think aloud; challenge one premise politely. Questions A1 to A5 |
| Skeptic | Probes the step from a team of three to twelve, warehouse to terminals, and the leadership-years count | high: hiring-manager prior, and F1, F3 and F6 are where the material is thinnest | Rehearse the top objection until it is boring; say the limit in your own words, then the plan. Questions B1 to B5 |
| Data-Driven Prober | Reads the 40% line for how it was counted and what was yours | medium: one headline figure invites it | Know how the figure was counted, and say plainly if you do not. Questions C1 to C3 |
| Conversational/Rapport | Friendly biography and tools questions that are still scored | medium: common in a first hiring-manager conversation | A 90-second arc built only from your own sentences. Questions D1 to D3 |
| Pressure/Stress | Time-boxed "why you" and attribution challenges | low: no signal this interviewer uses it | Pause, restate, hold through two follow-ups, concede specifically. Questions E1 and E2 |
| Peer Evaluator | Seam questions between sites and shifts | low: only if a site peer joins the loop | Reciprocity framing; propose seam principles rather than pretending to know the seam. Questions G1 and G2 |
| Values/Behavioral | Scenario probes on hard truths and customer-versus-metric trade-offs | low: no values-style round is established, and the company's values were not researched | Story selection with the honest branch. Questions H1 and H2 |

## Question banks

The highest-ROI prep in this pack is B1: the step from your current scope to the JD's twelve supervisors and four sites. It will be asked in some form.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You take over four terminals and on-time performance is slipping at one of them. What do you need to know first, and how do you diagnose it?" | CASE | [generic] | Structure it aloud: ask what counts as on time and since when, state the objective, split the problem by site, shift and lane, say how you would test each cut, name the metrics, then the risks. The question needs no claim about your past, so the guidance makes none | The JD's on-time performance line (F2's requirement) asked as a diagnosis; CASE with JD content |
| A2 | "Cost-per-shipment is up quarter on quarter. Where do you look?" | CASE | [generic] | Clarify how the figure is built before touching it, then break it into its parts, find which part moved, and say what you would check first and why. Think aloud and challenge one premise politely. No claim about your past is needed | The JD's cost-per-shipment line (F2's requirement) as a live problem; CASE with JD content |
| A3 | "Peak week: two of your four sites are well over plan on the same day, and you can cover one. What do you do?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Open with what you ran, in the quote's words: "I ran the site's peak-season surge plan two years running." Then structure the live problem: what you would ask first, how you would choose between sites, what you would tell each site, how you would check afterwards. Answer slot: the JD's four sites make a probe on balancing across sites likely. If your surge plan involved more than one location, say how, in your own words; if it did not, or that was not yours, say so plainly and stay with the plan you ran | F1 holds the surge-plan evidence; this tests whether it scales to the JD's multi-site scope. CASE with EXP content |
| A4 | "You are going from a handful of supervisors to twelve across four sites. What do your first thirty days look like?" | CASE | [generic] | A plan, not a history: what you would learn before changing anything, whom you would meet and in what order, what you would measure first and what you would leave alone. Say where your own learning curve is, as a plan | F3 is the scale gap and F5 the tooling gap; a ramp plan is the honest answer to both. CASE with JD content |
| A5 | "What would you put on a daily dashboard for four terminals, and what do you do when two sites' numbers disagree?" | CASE | [grounded] "never used Power BI"; "solid Excel" | Choose a short set of measures, define each one before comparing sites, and name one source of truth. On tools, stay with your own words: "I've never used Power BI," and "solid Excel" at its own scope, then a plan for what you would learn first. Answer slot: the JD asks you to build reporting, so expect a probe on what you have built. If you built reports, say what and for whom; if not, say so plainly | F4 and F5 are the reporting gaps; asking it as a design question lets you show judgment while the tool gap is stated plainly. CASE with JD content |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your background is warehouse and distribution, and a team of three supervisors. This role is four sites and twelve. What makes this the right next step?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "7 years in warehouse and distribution ops" | The highest-ROI rehearsal in this pack. Hold only what the quotes carry: "I'm a senior shift manager over 3 supervisors, after 7 years in warehouse and distribution ops." Say the difference in scale out loud before they do, then give the ramp plan as a plan. Answer slot: if you have led, covered or coordinated more than three supervisors, or worked across more than one location, say when and how many; if not, say so plainly and stay with the team of three. Hold through two follow-ups by returning to what you ran, never by adding to it. The honest branch is a limit, not a confession | F1 and F3 are where the JD's scope presses hardest on the material, so this objection arrives in some form; JD because it scores a stated requirement |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI" | Choose honestly. You can name Power BI because you said it plainly: "I've never used Power BI." Pair it with a plan for the first weeks, said as a plan. Do not use a strength dressed up as a weakness | F5 is the one gap you have stated yourself, so it is the safest honest answer. JD with Skeptic delivery |
| B3 | "The role asks for 5+ years of operations leadership. How many of your seven years were leadership?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot: say which of the seven years were supervisory or management, and what the role was called each time, in your own words; if fewer than five were, say the number plainly and describe the span you held. If asked whether the seven count, your own words were: "7 years in warehouse and distribution ops." | F6 is a discovery gap and the JD marks the requirement as required, so the count is likely to be asked literally. JD |
| B4 | "This role is terminal operations. What from your warehouse and distribution work carries over, and where would you be learning from scratch?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path" | Name what carries over only at its own scope: the seven years, and "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: the JD says terminal operations, so expect a probe on what in your experience resembles a terminal. If any of it does, say which part and what you did, in your own words; if none does, or it was not yours, say so plainly and name what you would learn first | F1 is a transferability row; this question asks you to draw the limit yourself. JD |
| B5 | "Why this role, and why now?" | EXP | [generic] | Nothing in your material states your reasons, so none are supplied. Answer slot: give your actual reasons for moving and for this company, in your own words; if you are not sure yet, say what you are weighing | The motivation probe every Skeptic runs; EXP because it tests whether your story holds together |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that 40% reduction in mis-pick rate was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say the claim at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Then the four slots a figure raises, each in your own words: how the rate was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F2's only quantified evidence, and the figure a Prober goes to first. EXP |
| C2 | "What did redesigning the pick path involve?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | The quote carries two beats: the pick path was redesigned, and mis-pick rate fell 40%. Tell those in your own words and add nothing the quote does not state | F2's evidence, asked as a walkthrough; the risk is supplying a middle to the story that the material does not carry. EXP |
| C3 | "Tell me about your green belt certification." | JD | [grounded] "green belt certified" | Say it as stated: "I'm green belt certified." Answer slot: the JD lists Lean/Six Sigma as a plus, so expect a probe on use. If you have used the training on a project, say which and how, in your own words; if you have not, say so plainly and say what you would apply first | F7 is a strong, uninspected row; bring the certificate if you can. JD |

### D. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running"; "green belt certified" | A 90-second arc with only the beats your sentences carry: seven years in warehouse and distribution, now a senior shift manager over 3 supervisors, the pick-path redesign with its 40%, two years of the surge plan, the green belt. Any roles or years in between are yours to add in your own words; the material shows only these. End on your own reason for this role | The biography question is scored in a friendly register; F1, F2, F3 and F7 supply the beats. EXP |
| D2 | "You mentioned solid Excel. What do you use it for?" | JD | [grounded] "solid Excel" | Answer slot: the JD asks you to build reporting, so say what you use it for, in your own words, with one concrete example if you have one; if the use is something other than reporting, say so plainly. Keep the claim at "solid Excel" | F4 is a discovery row; a casual tools question is where it gets tested. JD |
| D3 | "How would your supervisors describe working for you?" | EXP | [grounded] "currently a senior shift manager over 3 supervisors" | Answer slot: say what you know they would say, in their words if you remember any; if you do not know, say so plainly. Keep to the three supervisors you lead | F3's leadership evidence, asked in a friendly register; EXP with VAL delivery |

### E. Pressure/Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already runs a terminal?" | JD | [grounded] "ran the site's peak-season surge plan two years running"; "cut mis-pick rate 40% by redesigning the pick path"; "green belt certified" | Pause and restate. Hold only what the quotes carry: "I ran the site's peak-season surge plan two years running, I cut mis-pick rate 40% by redesigning the pick path, and I'm green belt certified." Hold through two follow-ups. Concede, in your own words, what you would be learning on the terminal side, and say what you would learn first | F1 is the transferability row this question presses on. JD |
| E2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which parts of the redesign were yours and who else worked on it; if it was shared, say so plainly. Hold through two follow-ups by returning to what you did, never by adding to it | F2's evidence under attribution pressure. EXP |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Suppose two sites need the same people on the same day and the site managers disagree. Where is the seam, and how do we settle it?" | JD | [generic] | Reciprocity first: what you bring the other site, not only what you need. Propose seam principles, such as who decides, on what information and by when, rather than pretending to know the current seam. No claim about your past is needed | The JD's four sites (F1's requirement) imply peers who share resources. JD with CASE delivery |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams or shifts. It needs a named stake, what you did, and credit shared. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; no quoted sentence carries a cross-team story, so this is the scaffold case. VAL |

### H. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the news was unwelcome and the person senior to you. It needs a named stake, a moment you did not soften it, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem; Atlas Freight's published values were not researched, so no value is named. VAL |
| H2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer's need and an internal target pulled apart. It needs the decision you made, what it cost and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A persona stem that sits close to on-time performance (F2's requirement). VAL |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | A1, A3, B1, B4, E1, G1 |
| "drive on-time performance and cost-per-shipment down" | A1, A2, A3, E1 |
| "lead a team of 12 supervisors" | A4, B1, D3, G2 |
| "build reporting in Excel/Power BI" | A5, B2, D2 |
| "5+ years operations leadership required" | B3, D1 |
| "Lean/Six Sigma a plus" | C3 |

The 40% figure, your one headline metric, is covered by C1, C2 and E2.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does on-time performance look like across the four sites today, and which site is furthest from where you want it?" | Shows you think site by site, and gives you the real baseline for the diagnosis in A1 |
| 2 | "How is cost-per-shipment calculated here, and who owns the inputs?" | Shows you ask for the definition before the number, the same instinct the defend-the-number questions test |
| 3 | "What is in the daily reporting today, and where does it live?" | Puts reporting tools on the table on your terms, and the answer tells you how steep the Power BI ramp is (F5) |
| 4 | "What would you want me to have learned or changed by the end of the first ninety days?" | Turns the ramp plan from A4 into the interviewer's own expectations |
| 5 | "Which decisions belong to the supervisors on shift, and which come to the Operations Manager?" | Probes the span of control behind the JD's twelve supervisors (F3) |
| 6 | "How does peak-season planning work across the sites, and who owns it today?" | Connects to your surge-plan evidence (F1) and shows you are thinking about multi-site peak |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or led terminal operations across multiple sites | Inflated form of F1 | F1's quotes at their own scope. The limit is the pack's observation: the material says a shift and a site's surge plan, not terminals or four sites. The slots in A3 and B4 stay inside what you ran |
| Led a team of 12 supervisors | Inflated form of F3 | F3's quote at its own scope: 3 supervisors. The slot in B1 asks only whether more were ever yours |
| Improved on-time performance or cost-per-shipment | Inflated form of F2 | F2's quote at its own scope: mis-pick rate. The limit is the pack's observation: mis-pick rate is neither of the JD's two measures |
| Held five or more years of operations leadership | Inflated form of F6 | F6's quotes at their own scope: seven years in operations, a current leadership role. B3's slot asks only which years were yours to lead |
| Built reporting in Excel | Inflated form of F4 | F4's quote at its own scope: "solid Excel". D2's slot asks only what it is used for |
| Has Power BI experience | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I've never used Power BI." No slot |
| Applied Lean/Six Sigma to a specific result | Inflated form of F7 | F7's quote at its own scope: "green belt certified". The two sentences are not linked unless you say the link was real. C3's slot asks only about use in general |

## Sources

Provided documents: the posting text pasted in your message, and the background summary in your message. No dossier was present, so the pack is built standalone.

Searches sent: "Atlas Freight regional logistics values" — refused; "Atlas Freight interview process operations manager" — refused; "Atlas Freight regional logistics news strategy 2026" — refused. No page fetches were sent. Nothing in this pack comes from outside research.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | Every call was refused. It would have moved the values cheat sheet and the VAL bank's themes; the VAL questions use persona stems instead |
| 2. `Atlas Freight interview process operations manager` | unavailable | Every call was refused. It would have moved loop structure and persona weights; the generic pattern stands in |
| 3. `Atlas Freight regional logistics news strategy 2026` | unavailable | Every call was refused. It would have moved a CO question grounded in current strategy; the CASE questions are labelled generic |
| 4. `{interviewer name} Atlas Freight` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Who you are meeting and in what round, plus any recruiter guidance on focus areas or deliverables → persona weights reworked for the real relationship, and coverage of anything pre-declared
- The interviewer's name → an interviewer read from their public footprint, and a reverse question tied to their own path
- Search access, so the L1 targets can run → Atlas Freight's published values, loop structure and strategy replace the generic pattern, and the CASE questions can be grounded; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and recent organisation context
- How many of your seven years were leadership years → F6 and B3 move from discovery to graded evidence
- What your Excel work produced, and for whom → F4, A5 and D2 become story-mapped instead of slots
- Whether on-time or cost figures were tracked at your site, and what they showed → F2 and A1 to A3 gain evidence beyond mis-pick rate
- How the 40% was counted and who else worked on the redesign → C1, C2 and E2 become quoted answers instead of slots
- Your green belt certificate and the mis-pick report → F7 and F2 can be raised in confidence, since they are inspectable
- A `tuesday-dossier.md` from earlier work on this role would add verified evidence and a named top objection
