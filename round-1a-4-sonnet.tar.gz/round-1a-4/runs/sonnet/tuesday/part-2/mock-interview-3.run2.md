The searches were declined, so I'm building the pack from your message alone. I'll mark everything unsourced as generic and save the pack as a file.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-3-denied-b9ea2602/stripe_product-operations-manager_interview_pack.md`.

The web searches were declined, so I couldn't look up Stripe's published values, loop structure or current strategy. I also had no job description or CV, so every row in the pack is labeled generic. The fit snapshot is a worksheet that says what strong evidence would look like for each requirement. I assumed a final round with an unknown interviewer, so persona weights are flat. It has 19 questions across seven personas, six reverse questions, and a coverage table. The highest-ROI prep is B1, "Which part of this role would you be weakest at on day one?"

Say the word and I'll run a live drill on B1, playing the Skeptic.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in this round (hiring manager, peer, skip-level, or a panel), and did the recruiter mention any focus areas or a deliverable? If you can paste the job description or your CV, the generic rows can become grounded ones. If you'd rather not, I'll keep going without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not given. Relationship: not given. Built as a blended final-round pack with flat persona weights, because no round structure or interviewer was supplied and no loop source was available.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral and values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually yours |
| JD | Role-driven: can you do the listed job, including its gaps |
| CO | Company and strategy knowledge: homework depth and altitude |
| CASE | Live problem: structure and reasoning on a problem from the role |

Every row below is labeled `[generic]` because there is no JD, no CV and no research behind it yet. Nothing here is a claim about you or about Stripe. Where guidance needs a story, it gives a selection scaffold that ends with an honest branch. The upgrade menu says what turns generic rows into grounded ones.

## Fit snapshot (worksheet)

No CV or background was provided, so this is the worksheet variant: evidence is `none given` everywhere, and each row says what strong evidence would look like. The requirements are role-family patterns, not quotes from a Stripe posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate product launches across engineering, go-to-market and support teams (role family) | none given | none | `[generic]` | discovery | Strong evidence is a launch you can name, with your own part separable from the team's. Selection scaffold: pick one launch where you can say what you personally owned and what others owned; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Run an operating cadence for product teams: planning, reviews, status, prioritization (role family) | none given | none | `[generic]` | discovery | Strong evidence is a recurring process you can describe from the inside, with what changed because of it. Selection scaffold: pick a recurring forum or process you set up or ran; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Define and track product health metrics and use them to decide (role family) | none given | none | `[generic]` | discovery | Strong evidence is a metric you can explain end to end: how it was counted, what it is sensitive to, what you decided from it. Selection scaffold: pick one metric you know how to defend; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influence outcomes across teams without direct authority (role family) | none given | none | `[generic]` | discovery | Strong evidence is a disagreement with a named stake and an intact working relationship afterward. Selection scaffold: pick a time you moved a decision without being the decider; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Structure ambiguous problems and design lightweight process that scales (role family) | none given | none | `[generic]` | discovery | Strong evidence is a process you built and later retired or simplified. Selection scaffold: pick a messy situation you gave structure to; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Turn user and field feedback into product decisions (role family) | none given | none | `[generic]` | discovery | Strong evidence is a feedback loop you operated, with a decision it changed. Selection scaffold: pick one piece of customer or field input that changed a plan; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

The loop structure is not established, so the weights rest on the generic archetype and are flat, said plainly. A final round at a company like this is often several sessions. If yours is, the schedule would let me build per-session packs.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems on launches, cadence, metrics | High: the role is an operating role and cases test it directly; no source narrows it further | Clarify, then objective, options, criteria, risks; think aloud; challenge one premise |
| Skeptic | Probing day-one weaknesses, motivation, role definition | High: a final round tends to test what remains uncertain, and with no material from you the gaps are unknown | Rehearse the most predictable objection until it is boring; candor over bluffing |
| Peer Evaluator | Seams with product and engineering counterparts | Medium: the role sits between teams, so collaboration probes are likely in some session | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Values/Behavioral | Stories mapped to company values | Medium: no loop source says a values round exists, and Stripe's values were not retrieved, so this is a hedge | Choose stories where the hard truth landed; if none, say so |
| Data-Driven Prober | Defend a number, assumptions | Medium-low: needs a CV figure to bite on; none given | Know how your figures were counted; say when you do not know |
| Pressure | Time-boxed challenge, devil's advocate | Low: composure test, present at flat weight only | Pause, restate, hold through two follow-ups, concede specifically |
| Conversational | Friendly opener, casual questions | Low-medium: usually the opening minutes of any session, still scored | Prepare a 90-second arc built only from facts you state |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two weeks before a launch, engineering says a feature will slip and go-to-market wants to hold the date. Sketch what you do. What do you need to know first?" | CASE | `[generic]` | Clarify first: what is slipping, who is affected, what is reversible, who decides. Then objective, options (hold, reduce scope, move the date), criteria, communication, risks. Think aloud and challenge one premise respectfully | Live problem set in the role's launch coordination (F1); CASE because it scores structure, not the answer |
| A2 | "Metric Y dropped 20 percent. Diagnose it." | CASE | `[generic]` | Define the metric, check measurement and instrumentation first, segment, look at what changed and when, separate seasonal or one-off causes, then name what you would look at next. Say what you would not conclude yet | Tests F3 under time pressure; CASE because it asks for reasoning on a live problem |
| A3 | "Sketch an operating cadence for a product org with several teams shipping at once. What do you need to know first?" | CASE | `[generic]` | Clarify what is broken or missing before designing anything; state principles (few forums, clear decision owners, written inputs); name what you would deliberately not build; say how you would know it works | Covers F2 and F5; the best answers resist over-process, which is the common failure |
| A4 | "What do you understand about who Stripe serves and where product operations fits in?" | CO | `[generic]` | Say only what you have actually read, and name where it came from. This pack could not research Stripe, so do twenty minutes on Stripe's own site and recent public announcements before the round. Do not recite; offer one view and one question | CO homework check; `[generic]` because no research ran, which is the honest cost |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | `[generic]` | Highest-ROI prep in this pack. Use the worksheet: the row with the thinnest honest evidence is your answer. Say it plainly in one sentence, then give a ramp plan as a plan, not a past: what you would learn first and from whom. Never bluff a competency the interviewer may own. If every row feels strong, say what you would verify in the first month | A final round probes whatever is least settled, so this arrives in some form; JD because it scores honest self-assessment against the role |
| B2 | "What is the nearest thing in your background to coordinating a launch across engineering, sales and support?" | EXP | `[generic]` | Selection scaffold: pick one instance where you can separate your part from the team's. Describe what you did in your own words. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Targets F1 without presupposing any launch; EXP because it tests attribution |
| B3 | "Why leave, why here, why now?" | EXP | `[generic]` | Give your actual reasons, in your own words, in under a minute. Make the why-here part specific to something you read yourself, not to a slogan. Keep the why-leave part forward-looking | Motivation consistency check, standard in a final round |
| B4 | "Product operations gets confused with project or program management. Where does it differ?" | JD | `[generic]` | Give your own working definition in two sentences, flag that definitions vary by company, and ask how the interviewer draws the line here. That converts a definitional trap into a conversation | Tests F2 and F5 understanding of the function itself |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | `[generic]` | Propose seam principles rather than pretending to know it: who decides what, how disagreements get escalated, what is written down. Ask what has worked or failed between these teams before | Covers F4; the role lives on this seam |
| C2 | "How do you handle credit when work spans teams?" | VAL | `[generic]` | Say how you actually behave, in your own words, with "we" for context and "I" for contribution. If you have no example ready, say so plainly and describe what you would do | Peer probe on partnership fit; VAL because it scores behavior, not a stated value |
| C3 | "What would you need from me in your first month?" | JD | `[generic]` | Reciprocity framing: name two or three concrete inputs you would ask for and one thing you would offer their team in return. Keep it about their load, not your comfort | Reduces the peer's perceived cost of the hire |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | `[generic]` | Selection scaffold: pick a time with a named stake, a moment you did not soften it, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Standard values probe; the honest branch matters more than a polished story |
| D2 | "When did you put a customer ahead of an internal metric?" | VAL | `[generic]` | Selection scaffold: pick a decision where the two conflicted and say what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Maps to F6; Stripe's published values were not retrieved, so this is a generic theme |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Pick a figure you would quote from your past work. How was it counted, and which assumption would you defend least?" | EXP | `[generic]` | Choose a figure you can actually defend. Say how it was counted, what it is sensitive to, and which part was yours. If you do not know how it was counted, say that plainly. If you have no such figure, say so and describe how you would measure the work | Defend-the-number rehearsal for F3; EXP because it tests attribution |
| E2 | "What would you instrument first to know whether a new process is working?" | CASE | `[generic]` | Start from the decision the process is meant to change, then one leading and one lagging signal, then how you would catch gaming or noise. Name what you would not measure | Tests F3 and F5 together without presupposing past work |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | `[generic]` | Pause and restate. Anchor in what you actually did and what you would do in the first ninety days. Hold through two follow-ups, then concede one specific uncertainty without folding on the core | Composure test; the position held must be one you can back |
| F2 | "Choose a result you will mention today. How much of it was actually you?" | EXP | `[generic]` | Separate your part from the team's in plain words. If most of it was shared, say so and say what you owned inside it. If no result comes to mind, say so plainly and describe the nearest work you have actually done | Attribution probe, the classic pressure form |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | `[generic]` | Build a 90-second arc from facts you state yourself: where you started, the turn that led to operations work, why this role now. This pack holds none of your history, so write it in your own words and rehearse it aloud | The opener in many sessions, and scored |
| G2 | "What are you actually working on or learning these days that bears on running launches or operating cadences?" | JD | `[generic]` | Name something real you are doing or reading, with one specific thing you took from it. If nothing comes to mind, say so plainly and name what you would start with | Casual questions on hot role topics are still scored |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| F1 Launch coordination | A1, B2 |
| F2 Operating cadence | A3, B4 |
| F3 Metrics | A2, E1, E2 |
| F4 Influence without authority | C1, C2, C3, D1 |
| F5 Ambiguity and process design | A3, B4, E2 |
| F6 User and field feedback | D2 — none beyond that: no source raised a feedback-loop question, so one row is the proportionate cover |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "How do you define product operations here, and where does it differ from program management?" | Shows you know the definitional trap and want their version, not yours |
| R2 | "What would a strong first ninety days look like, and what would make you say it went badly?" | Gets the scoring sheet in the open and signals ownership |
| R3 | "Which launch or process in the last year went best, and what made it work?" | Surfaces what good looks like in their own examples |
| R4 | "Where do product, engineering and go-to-market most often disagree, and how does product operations get pulled in?" | Shows seam awareness and asks for real texture |
| R5 | "What is the hardest thing about this role that a candidate would only learn on the inside?" | Invites candor and shows you expect trade-offs |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question, works especially well if the interviewer is a peer |

## Prohibited claims

There is no material from you in this pack, so nothing here inflates a quoted sentence of yours and no sourced entry exists. The list holds what the pack will not coach, so you can see it did not invent anything.

| Not coached | Basis | Honest form |
|---|---|---|
| Any past launch, metric, title, team size or outcome | None of these were stated by you | Say only what you did, in your own words; where a row has no quote the guidance is a selection scaffold with an honest branch |
| Any claim about how Stripe is run, its values or its strategy | No research ran, and model memory is not a source | Say what you read yourself and where you read it |

## Sources

Provided documents: your message only (company, role and round).

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Search refused. It would have fed the values cheat sheet and VAL questions; both are dropped or generic here |
| 2. Stripe interview process, product operations | unavailable | Search refused. It would have fed loop structure and persona weights; weights are flat and the archetype fallback is Generic |
| 3. Stripe strategy and recent news | unavailable | Search refused. It would have fed CO and CASE questions grounded in current strategy; A4 is generic instead |
| 4. Interviewer name and Stripe | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Search refused. It would have turned the F-rows from generic into inferred requirements |

Queries sent, every one refused: Stripe operating principles values; Stripe interview process Product Operations Manager final round; Stripe strategy 2026 news; Stripe Product Operations Manager job description responsibilities qualifications.

## Upgrade menu

- The job description text → the six generic requirement rows become grounded rows and every JD-tagged question gets a raising source
- Your CV or a few lines of your background → the worksheet becomes a real fit snapshot, guidance becomes story-mapped, and the highest-ROI objection is named from your actual gaps
- The round structure and the interviewer names or titles → persona weights reweighted, an interviewer read, and a reverse question tied to their path
- The recruiter's prep email → coverage of any pre-declared deliverable or focus area
- Permission to search the web → Stripe's published values, documented loop and current strategy, which unlock the values cheat sheet and CO questions
- If your final is several sessions, send the schedule → per-session mini-packs
- A `tuesday-dossier.md` from an earlier session, if you have one → verified evidence and prohibited claims carried in
