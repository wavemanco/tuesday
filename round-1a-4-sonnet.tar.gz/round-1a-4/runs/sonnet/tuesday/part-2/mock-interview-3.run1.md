Search permission was denied, so I'm building this pack from your message alone. Everything is labeled `[generic]`, with the research gaps accounted for in the file.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-3-denied-c974886a/Stripe_product-operations-manager_interview_pack.md`.

Search permission was denied, so I couldn't look up Stripe's values, interview loop or strategy. The pack is built only from what you told me and is labeled `[generic]` throughout. I assumed a final round with an unknown interviewer, so the persona weights are blended. The Sources section records the four refused searches. It has 21 questions across seven interviewer styles, six reverse questions and a list of claims it won't coach.

I can run a live drill on B1 ("Which part of this role would you be weakest at on day one?"). The pack names it as the highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Who are you meeting, and in what relationship (hiring manager, peer, skip-level or recruiter), and has the recruiter told you anything about focus areas or a deliverable? The answer reweights every question bank.
2. Can you paste the job description and your CV, or tell me to proceed without them? With them, the generic fit rows and scaffolds become quoted evidence and story maps.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final-round interview pack

Role: Product Operations Manager. Company: Stripe. Round: final round. Interviewer names and relationships: not known. Mode: session, with blended persona weights, because a final round can be several sessions and nothing here establishes how Stripe's is structured.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows good judgment and values, not generic virtue |
| EXP | Whether your experience claims survive scrutiny, and what was actually yours |
| JD | The role's responsibilities and qualifications, gaps included |
| CO | How well you know the company and can think at its altitude |
| CASE | Structure and reasoning on a live problem from the role |

This pack had no CV, no job description and no research, so every row below is `[generic]`. It is a rehearsal frame, not a fitted pack. The upgrade menu at the end says what each missing input would change.

## Fit snapshot (worksheet)

You supplied no CV and no background, so this is the worksheet variant. Requirements are role-family patterns written as plain prose, not quoted from a Stripe posting. In each row the bridge column says what strong evidence looks like. Then it gives a selection scaffold ending in its honest branch.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches or programs across several product teams (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a launch or program you can name, with the teams involved and your own part in it. Pick one such occasion; it needs a stake, a date, and a moment where coordination was hard. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would approach it |
| F2 | Design and run an operating cadence or process for a product organisation (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a process you set up or changed, and what happened afterwards. Pick one; it needs what it replaced and how you knew it worked. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would build one |
| F3 | Define and read product or adoption metrics (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a metric you can explain end to end: how it was counted, what it is sensitive to, and the assumption you would defend least. Pick one you know that well. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set one up |
| F4 | Influence peers and leadership without direct authority (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is an occasion where you moved a decision you did not own. Pick one; it needs who held the decision, what you did, and what the relationship looked like afterwards. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Product and customer judgment (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a call where customer need and an internal target pulled apart. Pick one; it needs both sides named and the choice you made. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Clear writing and live communication (role-family pattern) | none given | none | [generic] | discovery | Strong evidence is a document or briefing others acted on. Pick one you can describe by audience and outcome. If none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Persona table

No loop source establishes Stripe's loop, so the loop adjustment falls back to the Generic archetype: flat weights, said plainly. The weights below come from the relationship priors for a hiring manager, a peer and a cross-functional interviewer, blended because the relationship is unknown. Change them if you know better.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist | Live problems from the role: launches at risk, metric drops, process design | Highest. A hiring-manager prior, and the role is operational, so live problems are the natural test | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| B. Skeptic | Quiet probing of the weakest area, motivation, and why this role | High. Hiring-manager prior; every candidate has a thinnest area and a final round looks for it | Rehearse the single most predictable objection until it is boring. Use only adjacent evidence you actually have, and say the limit plainly |
| C. Data-Driven Prober | Asks how a number was counted and what it assumes | Medium. Product operations work is metric-heavy, so any figure you cite gets probed | Know how each figure you use was counted. Name your weakest assumption before they do, or say plainly you do not know |
| D. Peer Evaluator | Seam-splitting with adjacent teams, collaboration, credit | Medium. A peer prior, and this role sits between teams | Offer seam principles rather than pretending to know the seam. Say what you bring their team |
| E. Values / Behavioral | Scenario probes on judgment under pressure | Medium-low. No values-style round is established for Stripe, so this is a floor, not a forecast | Choose stories where the hard truth actually landed. Use we for context and I for contribution. Where no story fits, say so |
| F. Conversational | Friendly openers that are still scored | Medium-low. Present in most loops, easy to under-prepare | A 90-second arc for the biography question; treat casual questions as scored |
| G. Pressure | Time-boxed challenges, devil's advocate | Low. An executive prior, and nothing here suggests one | Pause, restate the question, hold a challenged position through two follow-ups before conceding anything real |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 launches across teams | A1, D1 |
| F2 operating cadence | A2, A4, B2 |
| F3 metrics | A3, C1, C2, C3 |
| F4 influence without authority | D1, D2, D3, E1, G2 |
| F5 product and customer judgment | E2, A5, F2 |
| F6 communication | F1, G1 |

## Question banks

The highest-ROI prep in this pack is B1. Every candidate gets some form of it, and a calm, specific answer changes the interview. It is built on no material about you yet, so it sharpens the moment you share your CV.

### A. Case / Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A launch involves four teams and the date is at risk two weeks out. Walk me through your first day." | CASE | [generic] | Clarify first: what is slipping, who owns each piece, what the date protects. Then separate what is blocked from what is merely late, decide what to cut or move, and say who you tell and how. Name one premise you would check before acting | A live problem from the role's core. CASE because it scores structure; it asks nothing about your past |
| A2 | "How would you design the operating rhythm for a product organisation with many teams, so launches stay coordinated without adding meetings?" | CASE | [generic] | State the goal and what you would measure. Propose the smallest set of recurring touchpoints and say what each replaces. Name the failure mode you would watch for and how you would retire a ritual that stopped earning its place | Tests F2 as design thinking. CASE with JD content |
| A3 | "An adoption metric for a recently launched feature dropped 20% week over week. Diagnose it." | CASE | [generic] | Clarify the definition and the data pipeline before the product. Segment by time, cohort, platform and channel. Separate measurement artifacts from real change, then say what you would check first and why | A standard metric-drop diagnosis, set in the role's world |
| A4 | "You can introduce one new process in your first 90 days. What do you pick, and what do you decide not to do?" | CASE | [generic] | Explain how you would choose: listen first, find the highest-friction handoff, pick something that removes work. Say what you would leave alone and why, and how you would know it worked | Tests prioritisation and restraint, F2 |
| A5 | "Why Stripe, and why product operations rather than product management?" | CO | [generic] | Answer in your own reasons: what draws you to this company, and what about operating the system appeals more than owning one product. Use only reasons you actually hold. If your reasons are still forming, say so plainly | Motivation is asked in some form in every final round. CO because it also tests how well you know the company, which this pack could not research |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick one real gap from F1 to F6, name it plainly, and say the concrete first steps you would take to close it. Concede it specifically; do not hedge, and do not turn it into a strength. Hold that position through two follow-ups | The most predictable objection. JD because it scores the role's own requirements. Highest-ROI prep |
| B2 | "Some people see product operations as overhead. How would you show the function earns its place?" | JD | [generic] | Say what you would measure before you start, name the cost of the work not being done, and say what you would stop doing if it did not help. Do not claim past results here unless a story from F2 is truly yours | Tests F2 and whether you can argue for the role honestly |
| B3 | "Why are you looking to leave your current role, and why now?" | EXP | [generic] | Give your own reason, stated plainly and without blaming anyone. Say what you are moving toward. Keep it short and true | A standard Skeptic motivation probe |
| B4 | "What would make you decide this role is not right for you in six months?" | JD | [generic] | Name the real conditions: the kind of work, the autonomy and the support you need. Make it specific enough to be believable. It shows you have thought about fit honestly | Tests honest self-assessment |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Pick a metric you have owned or reported on. Walk me through how it was counted, and which assumption behind it you would defend least." | EXP | [generic] | Choose a metric you know well. Say how it was counted, what it is sensitive to, and name your weakest assumption before they do. If you do not know how a figure was counted, say so plainly and say how you would find out. If no such metric comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would set one up | The defend-the-number rehearsal, F3 |
| C2 | "Which three metrics would you put on a launch-health view, and what would each fail to tell you?" | CASE | [generic] | Pick three that answer different questions, such as reach, quality and risk. For each, say what it hides, then say what you would pair it with. Show you can name a metric's limits | Tests F3 as judgment, not just recall |
| C3 | "Two teams report the same metric differently. How do you resolve it?" | CASE | [generic] | Establish the definitions and sources first. Separate a definitional difference from a data error. Then decide who owns the definition, document it, and say how you would stop it recurring | A common operations problem; tests F3 and F4 together |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Offer principles rather than pretending to know the seam: who decides, who informs, how disagreements escalate. Say what you bring their team. Show you would ask how it works here before proposing anything | Tests turf awareness and F1, F4 |
| D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say your actual practice in your own words: how you name contributions and how you share credit. Use a real occasion only if one comes to mind. If none does, say so plainly, then say how you would do it | A standard peer probe on collaboration style, F4 |
| D3 | "What would you need from me in your first month, and what could you do for my team?" | JD | [generic] | Split it in two: what you need in order to learn quickly, and what you would offer early. Keep the offer modest and concrete; do not promise outcomes | Reciprocity framing; tests partnership fit |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick one occasion where the hard message really landed. It needs the stake, what you said, and what happened afterwards. Use we for context and I for your contribution. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard values probe, F4 |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick one occasion with both sides named: the customer need and the target. Say what you chose and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Tests F5 |

### F. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc in your own words: where you started, the one or two turns that shaped what you do, and why this role is next. Every beat should be something you did | A casual biography question that is still scored, F6 |
| F2 | "What is a Stripe product or announcement you found interesting recently, and why?" | CO | [generic] | This pack could not research Stripe, so do that homework yourself on Stripe's own pages. Choose one item you can discuss honestly, say what it does and what you would want to understand better. Do not recite a headline | Rewards homework and curiosity; generic until research runs |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | VAL | [generic] | Pause and restate the question. Give two reasons you can stand behind, in your own words, and name what an internal candidate may know that you do not. Hold your position through the follow-ups; concede specifically, not broadly | A time-boxed composure test |
| G2 | "Pick the accomplishment you are proudest of. How much of it was actually you?" | EXP | [generic] | Say precisely what you did, what the team did and what others did. Precise attribution beats a bigger claim. If part of it was not yours, say so plainly. The follow-up will probe exactly that boundary | The attribution-honesty probe, F4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first 90 days look like in this role, and how would you know at day 90?" | Shows you think in outcomes, and gets the real success measure |
| R2 | "Where does this role's remit end and product management's begin here, and where is that line still being worked out?" | Shows you understand the seam, and surfaces ambiguity before you accept |
| R3 | "Which launch or program in the last year did the team feel went well, and what made it work?" | Invites a story and shows how the team defines good |
| R4 | "How is the impact of this role measured today?" | Signals you care about proof of value and shows how the role is judged |
| R5 | "What part of this role do people tend to underestimate?" | Gets the honest texture of the job, which rapport-style interviewers reward |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer interviewer; it shifts the conversation to what you bring |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Any claim about your own experience, scope, metrics, team sizes or outcomes | No material about you was supplied, so nothing here can stand behind such a claim | Every answer above is a selection scaffold or answer slot ending in an honest branch. Use only what you actually did, in your own words |
| Any claim about how Stripe is organised, what it values, or what this team's loop looks like | Research did not run, and none of it comes from your material | Verify on Stripe's own pages and with your recruiter before relying on it |

## Sources

Provided documents: your message only. No CV, job description, interviewer profile or recruiter notes were supplied. No dossier was present.

Searches sent, all refused because search permission was not granted: "Stripe operating principles values"; "Stripe interview process Product Operations Manager"; "Stripe strategy news 2026"; "Stripe Product Operations Manager job description". Nothing from them is used.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | The values cheat sheet would have named Stripe's published values; no section 10 appears |
| 2. `Stripe interview process Product Operations` | unavailable | Loop structure and persona weights would follow named rounds; weights rest on the Generic archetype instead |
| 3. `Stripe strategy` / recent news | unavailable | Current-strategy CO and CASE questions would have been grounded; A5 and F2 are generic instead |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative `Product Operations Manager` JD | unavailable | The fit snapshot's requirements would have been quoted and labeled inferred; they are plain role-family prose instead |

## Upgrade menu

- Search permission → Stripe's published values by name, its documented loop and current strategy; roughly six rows and two CO questions become `[grounded]` or `[inferred]`. A deeper pass would add up to 6 more searches and 2 more fetches and take several more minutes
- The job description text → the six `[generic]` fit rows become quoted requirements, and the banks gain JD-tagged questions
- Your CV or a short background note → the fit snapshot gets real evidence, B1 becomes your specific objection, and the scaffolds become story maps
- Who you are meeting and in which relationship (manager, peer, skip-level, recruiter) → the persona weights stop being blended
- Interviewer names → an interviewer read and a reverse question tied to their path
- Your recruiter's prep email → any pre-declared focus areas or deliverables, usually one email
- The schedule of the final's sessions, if it is several → per-session mini-packs
- A `tuesday-dossier.md`, if you have one → verified evidence and a prohibited-claims list that tighten the guidance
