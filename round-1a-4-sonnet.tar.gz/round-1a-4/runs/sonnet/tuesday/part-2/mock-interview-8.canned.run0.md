Presenting the saved pack, then I'll send the summary message.
Dara, your prep pack is saved as `ashgrove-credit-union_member-experience-lead_interview_pack.md`. It has a separate mini-pack for each of the three rounds on 3 December. I built it from what you pasted and sent no searches, because your pasted values, the recruiter's email, the strategy brief and the JD already covered everything a search would have fed. I didn't have a CV, so every quote about your experience comes from your message.

- **Round 1, recruiter (10 questions):** a 90-second walk-through of your background, plus pay, notice, location and reason for leaving. I haven't made up any figures for those, so each is a slot for your own words. It also covers the two screening checks that will come up: the contact centre and regulated complaints.
- **Round 2, Head of Member Services (11 questions):** mostly behavioural, plus two short cases on the digital shift and the move to five hubs.
- **Round 3, branch-manager panel (11 questions):** five questions on the four values, three case prompts for the 20-minute escalation case, and three questions on how your role fits with theirs. It also has a values cheat sheet, mapping each of the four values to your own words where they carry a story and to a "pick a time when…" scaffold where they don't.

Your most important rehearsal is R2B2: "You'd own the contact centre too, and you haven't worked in one. What would you do in your first weeks?" Your material shows two stated gaps, the contact centre and presenting above regional level. The pack coaches you to say them plainly in your own words, then give a plan, and not to stretch your branch experience to cover them.

- **Stretching claims:** the pack has a list of claims it won't coach. They include owning the process end to end, handling "regulated" complaints, coaching supervisors and advanced Excel. Each one is a wider version of what you actually said.
- **Answer slots:** where an interviewer is likely to probe past your sentences, the pack gives an answer slot instead of an answer. One example is whether your spreadsheet tracked resolution times.
- **Open items:** the upgrade menu lists what would sharpen the pack. The main ones are your CV, the interviewers' names, and whether the round 3 case scenario is given on the day or prepared in advance. The last is a one-line email to the recruiter.

I can run a live drill, playing the Head of Member Services on R2B2. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove-credit-union_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds on 3 December 2026, each with its own mini-pack. **Interviewers:** no names yet. Round 1 is the recruiter, round 2 is the Head of Member Services (your future manager), round 3 is a panel of two branch managers who also score the four values.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether your past behaviour shows Ashgrove's published values |
| EXP | Whether what you say about your experience survives follow-ups |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Ashgrove's level: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Three conventions you will see:

- **Answer slot.** An instruction for the interview, not a question for you now. It tells you what a likely probe is and gives two honest branches: say what you did, or say plainly that the step was not yours or did not exist.
- **Logistics slot.** The same idea for pay, notice, location and reason for leaving: your own facts, in your own words.
- **IDs.** R1A1 means round 1, persona A, question 1.

**The highest-ROI rehearsal in this pack is R2B2**, the contact-centre question in round 2. It will arrive in some form, and your own material says plainly where it is thin.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the JD you pasted. Evidence is your own words from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says a branch's formal complaints log, not an end-to-end process, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint after the log likely. If you followed any from first contact to resolution, say what and which part was yours, in your own words; if the log was where your part ended, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD, same line as F1 | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller, and no claim to contact-centre knowledge |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence says a monthly complaints spreadsheet that your regional manager uses. It does not say what the spreadsheet counted. Answer slot: if it counted volumes or resolution times, say which and how, in your own words; if it did not, say so plainly and describe what it did carry |
| F4 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | "Formal" is not "regulated", and the bridge is this pack's derivation from the JD. Answer slot: if the complaints in that log fell under a regulator's rules, say which rules and what they required of you, in your own words; if you cannot say they were regulated, say so plainly and stay with the formal log you handled |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on length, but a line with nothing inspected behind it. Lead with it in its own terms: six years in retail banking, the last three as a branch supervisor. Do not restate it as "customer operations" |
| F6 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated limit. Words: "I haven't presented to anyone above regional level." Then how you would prepare your first senior presentation, said as a plan. Never a claim to senior-level presenting |
| F7 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The sentence reaches the requirement in other words: a spreadsheet you built that someone senior relies on. Say it in those words. If asked which tool, name the tool it was built in. Add no features, formulas or techniques you did not tell me about |
| F8 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says tellers and the escalation script, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you ever guided supervisors or peers on an escalation, say what and how, in your own words; if you did not, say so plainly and stay with the tellers |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if any of your complaints work touched an app, a web form or another digital channel, say what and what part was yours; if none did, say so plainly and say what you would want to learn first |

## Grounding brief (shared)

The four facts below come from the July 2026 strategy brief as you relayed it. The recruiter sent you the brief, so assume the interviewers know it well. Say one item in your own words, then add one thought of your own.

| Item | Where it is used | Provenance |
|---|---|---|
| 40% of member service moves to digital channels by 2028 | R1A7, R2C1, R2B5 | [grounded] |
| Eight branches consolidate into five hubs over 2027 | R2C2, R3B3 | [grounded] |
| A small-business lending product launches in Q1 2027 | R1A7 | [grounded] |
| App-only banks are the main competitive pressure | R1A7, R3B1 | [grounded] |

---

## Round 1: Recruiter screen (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Conversational | Friendly, unstructured, with pay, notice, location and reason for leaving folded in | High. The recruiter screen prior is Conversational plus a light Skeptic, and the email gives this round no stated focus | Pre-script a 90-second arc from your own sentences. Treat every casual question as scored |
| B. Skeptic (light) | Knockout checks against the JD's requirements | Medium. F2 and F4 are where your material is thinnest, and a recruiter checks the JD against your profile | Say the limit plainly in your own words, then the plan. Do not bluff a competency |

### Persona A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in three beats, each a sentence you wrote: six years in retail banking, the last three as a branch supervisor; the formal complaints log you handled and the new tellers you trained on the escalation script; the monthly complaints spreadsheet your regional manager uses. Close on why this role, in your own words. Every clause stays inside those sentences | The biography question is the most common opener and is scored. F5, F1, F8 and F3 are the rows it draws on; EXP because it tests whether the summary matches the CV |
| R1A2 | "What are your salary expectations?" | JD | [generic] | Logistics slot, pay. Give your own number in your own words, or ask for the role's band first and answer once you have it. If asked what you earn now, you can decline politely and return to what you are looking for. Give no figure you have not decided | A recruiter screen always covers pay, and the only safe answer is yours. JD because it concerns the listed job's terms; you have given no figure, so none is supplied |
| R1A3 | "What is your notice period?" | JD | [generic] | Logistics slot, notice. Give your actual notice period, in your own words | Part of every screen. JD because it concerns the job's start; no figure was given, so none is supplied |
| R1A4 | "Where are you based, and where can you work?" | JD | [generic] | Logistics slot, location. Say where you can work and how often, in your own words | The JD gives no location, so this checks fit with the role's pattern. JD because it concerns the job's terms |
| R1A5 | "Why are you looking to move?" | EXP | [generic] | Logistics slot, reason for leaving. Give your real reason in a sentence or two, in your own words, and keep it true. Say it the same way in rounds 2 and 3 | Motivation consistency is scored across all three rounds. EXP because it tests whether your story holds together |
| R1A6 | "Tell me about the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F3 and F7: you built it, it is monthly, it is about complaints, and your regional manager uses it. Answer slot: the JD asks for monthly reporting on complaint volumes and resolution times, so expect a probe on what the spreadsheet counted. If it counted either, say which and how, in your own words; if it did not, say so plainly and describe what it did carry. If asked which tool it was built in, name it | F3 is the evidence for the reporting requirement and F7 for Excel. JD because it scores the stated requirement |
| R1A7 | "What do you know about where Ashgrove is heading?" | CO | [grounded] | No claim about your past. Pick one item from the July 2026 brief (40% of member service digital by 2028, eight branches into five hubs over 2027, a small-business lending product in Q1 2027, app-only banks as the main pressure), say it in your own words, then say what it would mean for complaints. Add your own thought rather than reciting the list | Homework is scored even in a screen. CO because it tests strategy knowledge; the facts come from the brief you were given |

### Persona B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1B1 | "You haven't worked in a contact centre, and this role covers one. How would you close that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Open with your own words: "I haven't worked in a contact centre." Then a plan, kept as a plan: what you would do in your first weeks to learn it, in your own words. Keep it short; round 2 goes deeper | F2 is a stated gap, so the recruiter's version is a knockout check. JD because it scores a stated requirement |
| R1B2 | "The role handles regulated complaints. Tell me about the formal complaints you handled." | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the sentence says: you handled the branch's formal complaints log. Answer slot: the JD asks for regulated complaints, so expect a probe on whether yours were. If they fell under a regulator's rules, say which and what they required of you, in your own words; if you cannot say they were regulated, say so plainly and stay with the formal log | F4 is the thinnest evidenced row after F2. The label is inferred because the link from "formal" to "regulated" is the JD's |
| R1B3 | "The role asks for four years in financial-services customer operations. How does your time fit?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | "I have six years in retail banking, the last three as a branch supervisor." Stop there unless asked. If asked what the work was, go back to your own sentences about the complaints log and the escalation script | F5 is a clean row, and a knockout screen checks it in one line. JD because it scores a stated requirement |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Who will I meet in rounds 2 and 3, and what do they most want to understand about me?" | Names and focus areas unlock a sharper pack, and the recruiter can usually say |
| 2 | "What does the 20-minute case in round 3 look like: a scenario you give me on the day, or something I prepare?" | The format changes how you rehearse the largest block of the loop |
| 3 | "How is the team that handles complaints organised today, across branches and the contact centre?" | Shows you are thinking about the contact-centre side from the start |
| 4 | "What would you say separates the candidates who do well in the panel round from the rest?" | Gets the recruiter's own view of how the values round is scored |
| 5 | "What are the next steps after 3 December, and when would you expect to decide?" | Practical, and closes the screen cleanly |

---

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Values / Behavioural | "Tell me about a time" questions mapped to the role and to Ashgrove's values | High. The recruiter's email calls this round mostly behavioural | Map a story to each question where your own sentences carry one; otherwise use the selection scaffold and its honest branch. "We" for context, "I" for what you did |
| B. Skeptic | Quiet, persistent probing of the gaps and of motivation | High. A hiring manager buys capability and derisks gaps, and F2, F6 and F9 are your widest | Rehearse the contact-centre answer until it is boring. State limits plainly, then the plan |
| C. Case / Strategist | A live problem from the role's roadmap | Medium. The hiring manager prior includes it, and the brief's digital and hub moves give them material | Clarify first, then objective, segments, approach, metrics, risks. Think aloud |

### Persona A: Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2A1 | "Tell me about a time you delivered an unpopular truth to someone more senior." | VAL | [generic] | Selection scaffold, no claim about your past. Pick a time with a named stake, a moment you said it anyway, and a working relationship still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem, and F6 makes upward communication a likely theme. VAL because it tests behaviour over virtue |
| R2A2 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F1: the formal complaints log, and that you handled it. Answer slot: Ashgrove's Own the Fix says whoever finds the problem keeps hold of it until it is solved, so expect a probe on one complaint from start to finish. If you kept hold of one, say what it was and what part was yours; if the log meant a complaint left your hands, or there was no such case, say so plainly and stay with the log you handled | Own the Fix is the value closest to the job, and F1 is where your evidence is. VAL because the question comes from a published value |
| R2A3 | "How did you train new tellers on the escalation script?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F8: new tellers, the escalation script, and that you trained them. Answer slot: the JD asks you to coach supervisors on escalations, so expect a probe on how the training worked and whether it reached supervisors. If you shaped how it was taught, say how, in your own words; if you taught the script as given, say so plainly. Stay with tellers | F8 is the evidence for the coaching requirement. JD because it scores a stated requirement |
| R2A4 | "When did you put a member ahead of an internal metric?" | VAL | [grounded] | Selection scaffold, no claim about your past. Pick a time with the member's interest, the metric or rule pulling the other way, what you decided, and what it cost. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Members First, Always is the first published value, and this is the standard stem for it |

### Persona B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name one of your two stated limits in plain words, then your plan for it. Calibrated candour beats a disguised strength. Choose the one you can say a concrete plan for | F2 and F6 are the widest rows. JD because it scores the whole listed job |
| R2B2 | "You'd own the process in the contact centre too, and you haven't worked in one. What would you do in your first weeks?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Highest-ROI rehearsal.** Opening, in your own words: "I haven't worked in a contact centre." Then the plan, kept a plan: name one thing you would do first to learn it. Follow-up one: "How do you know what you do in a branch carries over?" Stay with your sentences: you handled the branch's formal complaints log and trained tellers on the escalation script, and you do not claim the contact centre works the same. Follow-up two: "Why back you over someone who has done it?" Hold: six years in retail banking, the last three as a branch supervisor. Concede specifically: someone who has worked in a contact centre knows it from the inside and you do not, so you would rely on contact-centre colleagues for what you do not know. Do not add strengths you have not stated | The limit is yours and the JD's "across branches and the contact centre" line aims straight at it. F2 is the likeliest objection in the loop, so this row gets the most follow-up levels. JD because it scores a stated requirement; Skeptic is the delivery |
| R2B3 | "The role asks for confidence presenting to senior leaders. You haven't presented above regional level. How would you handle that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Open with your own words: "I haven't presented to anyone above regional level." Then a plan: how you would prepare a first senior presentation and who you would rehearse with. The complaints spreadsheet you built, "I built the monthly complaints spreadsheet our regional manager uses.", is the material you would present from; do not say you have presented it | F6 is a stated gap, and a manager checks it. JD because it scores a stated requirement |
| R2B4 | "Why this role, and why now?" | EXP | [generic] | Give your real reason, the same one you gave the recruiter in round 1. Consistency across rounds is part of what is scored. Keep it about the role | Motivation consistency is the Skeptic's standard probe. EXP because it tests whether the story holds up |
| R2B5 | "This role works with digital teams on self-service journeys. What have you had to do with digital channels?" | JD | [grounded] | Answer slot: the JD asks you to work with digital teams on self-service journeys, so expect a probe on your experience of it. If any of your complaints work touched an app, a web form or another digital channel, say what and what part was yours, in your own words; if none did, say so plainly and say what you would want to learn first | F9 has no evidence in your material, so the honest answer is the whole rehearsal. JD because it scores a stated requirement |

### Persona C: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2C1 | "We aim to move 40% of member service to digital channels by 2028. How would you decide which complaints belong in a self-service journey and which should always reach a person? What do you need to know first?" | CASE | [grounded] | No claim about your past. Clarify first: what counts as a complaint here, who is complaining, what is at stake. Then objective, segments, approach, metrics (resolution time and repeat complaints are the ones you would track), risks. Say the brief's 40% once, then bring your own point. Challenge one premise respectfully | The digital move is the brief's headline and the JD's self-service line. CASE because it is a live problem; CO because it uses the company's strategy |
| R2C2 | "Eight branches become five hubs over 2027. What happens to complaints during that change, and what would you want to know?" | CASE | [grounded] | No claim about your past. Clarify what changes for a member and when; who keeps hold of a complaint while a branch closes (Own the Fix); how members hear about it in plain words (Plain Words). Say what you do not know about the plan | Hub consolidation is a stated 2027 move. CASE because it is live; CO because it draws on the brief |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good first 90 days look like, and what would you want changed by the end of the third month?" | Lets the manager define success, which turns the contact-centre gap into a plan they own |
| 2 | "How does a complaint currently travel between a branch and the contact centre?" | Gets them to describe the process you would own |
| 3 | "Who reads the monthly complaints report today, and what do they do with it?" | Tests the reporting and senior-audience requirements without raising your gap |
| 4 | "How will the move from eight branches to five hubs change what you need from this role?" | Uses the brief and shows you think at Ashgrove's altitude |
| 5 | "What would make you say in six months that this hire was the right call?" | Surfaces their scoring sheet in their words |

---

## Round 3: Panel of two branch managers (60 minutes, including a 20-minute escalation case; values round)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Values / Behavioural | Scenario probes scored against the four published values | High. The recruiter says the panel scores against the four values | Map a story to each value where one of your sentences carries it, otherwise use the scaffold and its honest branch |
| B. Case / Strategist | The 20-minute complaint escalation case | High. The recruiter has named it as a fixed block of the round | Clarify, structure, think aloud, challenge one premise, and let the values show in how you decide |
| C. Peer Evaluator | Seam-splitting between your role and their branches | Medium. Branch managers are the people whose supervisors you would coach, so the seam is theirs | Propose principles for the seam rather than pretending to know it; say what you bring them, not only what you need |

### Persona A: Values / Behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3A1 | "We say we decide from the member's side of the counter. What does that mean to you, and when have you done it?" | VAL | [grounded] | Selection scaffold, no claim about your past. Say what it means in your own words, then pick a time with a member, a pull the other way, and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. R2A4 may use the same story | Members First, Always is the first published value. VAL because it scores behaviour against it |
| R3A2 | "If a member needs it explained twice, we wrote it wrong. When have you had to change how something was put so it landed the first time?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F8: new tellers, and the escalation script. Answer slot: Plain Words makes the wording itself the test, so expect a probe on whether tellers needed something explained twice. If you changed how the script was put or taught afterwards, say what and why, in your own words; if you did not, say so plainly and stay with the training | Plain Words is closest to your training evidence. VAL because it comes from a published value |
| R3A3 | "Every branch is part of its town. Tell us about a time you did something because of the community a branch served." | VAL | [grounded] | Selection scaffold, no claim about your past. Pick a time with a named community, what you did, and what it meant for a member. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Branch managers will hear any hub answer through this value | Neighbours, Not Numbers is the value most exposed to the hub plan, and the panel are branch managers. VAL because it scores the published value |
| R3A4 | "Tell me about a problem you found that wasn't yours to fix, and what you did with it." | VAL | [grounded] | Selection scaffold, no claim about your past. Pick a time with a named problem, who owned it, and what you did to keep hold of it until it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Own the Fix says whoever finds the problem keeps hold of it, and R2A2 covers your complaints log. This one tests the harder half. VAL because it comes from a published value |
| R3A5 | "Which of our four values will be hardest for you?" | VAL | [grounded] | No claim about your past. Choose one honestly and say what you would do to stretch on it. Do not say all four are equally strong. A plain, specific answer scores better than a polished one | Self-assessment is how a values round separates rehearsed answers from real ones. VAL because it scores honesty about the values |

### Values cheat sheet

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | No quoted sentence carries a story. Selection scaffold: pick a time with a member, a pull the other way, a decision and its cost; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording was wrong | F8: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Answer slot in R3A2 decides whether the script was ever reworded |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries a story. Selection scaffold as above, with the community named |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The log is the beat; whether any complaint was kept to resolution is the answer slot in R2A2 |

### Persona B: Case / Strategist

The 20-minute case: you do not yet know whether the scenario is given on the day or prepared. The three prompts below are rehearsal material, not a prediction of the actual case.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3B1 | "A member has complained three times about the same issue and has now said they will move to an app-only bank. Two branches gave them different answers. Walk us through what you do." | CASE | [generic] | No claim about your past. Clarify first: what the member actually wants, what has been said to them and by whom, whether it is a formal complaint and what rules or deadlines apply (ask, do not assume). Then who keeps hold of it from now on (Own the Fix), how you explain the outcome so it lands once (Plain Words), and how you stop a third complaint. Close on metrics: resolution time and repeat complaints. Say what you would decide from the member's side | A generic escalation case built from the JD's escalation line and the brief's app-only competition. CASE because it is live; generic because the real case is unknown |
| R3B2 | "A branch supervisor escalated a complaint late and the member is angry. You are coaching that supervisor. How do you open the conversation?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open by finding out what happened before judging. Agree the facts, ask what made it hard, ask what they would do differently, and look at whether the process helped or hindered. If asked whether you have done this, your own words were: "I handled the branch's formal complaints log and trained new tellers on our escalation script." The pack's observation is that your material shows tellers, not supervisors, so stay there | Tests the coaching requirement in F8 live. CASE because it is a role problem; the quote only supports what the sentence says |
| R3B3 | "Midway through: the member's branch is one of the eight being folded into a hub. How does your answer change?" | CO | [grounded] | No claim about your past. Challenge one premise respectfully: when does it close, and what does this member lose? Keep one named owner through the change (Own the Fix), speak to the town's concern (Neighbours, Not Numbers), and say plainly what you do not know about the hub plan | The panel is likely to bend the case toward the brief's hub move. CO because it draws on the strategy; the case frame is the delivery |

### Persona C: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3C1 | "When a complaint lands in my branch, where does your job start and mine end?" | JD | [generic] | No claim about your past. Offer seam principles rather than a map you do not have: the member always has one named owner, the branch keeps the relationship, you take what a branch cannot resolve. Ask where the seam sits today and what they would change | A peer-style question on the role's central seam. JD because it scores the coaching and ownership lines |
| R3C2 | "Tell me about a time a supervisor or manager disagreed with you about a complaint." | EXP | [generic] | Selection scaffold, no claim about your past. Pick a time with a named disagreement, what each side wanted, how it ended, and the working relationship afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Collegial packaging of the disagreement probe. The theme comes from the JD's coaching line. EXP because it tests what actually happened |
| R3C3 | "What do you need from branch managers, and what do we get from you?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Reciprocity framing. Say what you need in your own words, then what you bring, at the scope of your sentences: you handled a branch's formal complaints log and trained new tellers on an escalation script, and you built a monthly complaints spreadsheet your regional manager uses. Do not turn those into more | Peers price what the hire costs and contributes. F8 and F3 are the rows. JD because it scores the role's working relationships |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would you most want from the person coaching your supervisors on escalations?" | Reciprocity, and it gets the panel to define the coaching role |
| 2 | "Which kinds of escalation take most of your supervisors' time?" | Shows you are thinking about their problems, not just the process |
| 3 | "How do you want to hear about a complaint that has gone wrong in your branch?" | Sets up the seam from R3C1 in their words |
| 4 | "How do you expect the hub plan to change what your branch needs from this role?" | Connects the values round to the strategy brief |
| 5 | "What is one thing the new lead could do in the first month that would help you?" | Peer reciprocity, and a concrete first-month answer |

---

## Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1: own the process end to end | R1A1, R2A2, R3B1 | |
| F2: the contact centre | R1B1, R2B1, R2B2 | R2B2 is the deepest rehearsal |
| F3: monthly reporting on volumes and resolution times | R1A6 | R3C3 also draws on the quote |
| F4: regulated complaints | R1B2 | |
| F5: four years in the sector | R1B3, R1A1 | |
| F6: presenting to senior leaders | R2B3, R2B1 | |
| F7: Excel reporting | R1A6 | |
| F8: coaching supervisors on escalations | R2A3, R3B2, R3C3 | |
| F9: digital teams and self-service | R2B5, R2C1 | |

## Prohibited claims (shared)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: your material says a branch log, not an end-to-end process. The slot in F1 stays inside the log |
| Has contact-centre experience, or knows how a contact centre works | Negative you stated, F2 | "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders or executives | Negative you stated, F6 | "I haven't presented to anyone above regional level." No slot |
| Handled regulated complaints | Inflated form of F4 | F4's quote at its own scope: "I handled the branch's formal complaints log." The slot asks only whether those complaints fell under a regulator's rules |
| Reported on volumes and resolution times | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The slot asks only what the spreadsheet counted |
| Coached supervisors on escalations | Inflated form of F8 | F8's quote at its own scope: "I trained new tellers on our escalation script." The limit is the pack's observation: your material says tellers, not supervisors |
| Advanced Excel skills | Inflated form of F7 | F7's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." No feature or technique is named |

## Sources

**Provided documents:** the JD you pasted; the four values you copied on 24 November 2026; the recruiter's email on the three rounds; the 2026 strategy facts you relayed from the July 2026 brief; your background as you described it. No `tuesday-dossier.md` was present. No CV was provided; the evidence quotes come from your message.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values page fixes the values cheat sheet and the VAL questions; nothing a search could return would change them |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email names all three sessions and who runs each, so the loop and the values-round detection are fixed |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The July 2026 brief you relayed supplies current priorities and recent moves, so the CO and CASE questions are fixed |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name has been assigned, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV → the quotes in F1 to F9 come from your message, and CV lines could lift several rows from `medium` and add evidence for F9.
- What the branch's formal complaints log covered, and whether any of it fell under a regulator's rules → F1 and F4 become your own words rather than answer slots.
- Whether your monthly spreadsheet counted volumes or resolution times, and which tool it was built in → F3 and F7, and the R1A6 slot.
- Your pay figure, notice period, location pattern and reason for leaving → R1A2 to R1A5 become your own words quoted, and the consistency check on R2B4 can use them.
- The recruiter's guidance on the 20-minute case: whether the scenario is given on the day or prepared → R3B1 to R3B3 can match the real format. One email covers it.
- The names of the Head of Member Services and the two branch managers → an interviewer read, persona re-weighting, and a reverse question tied to each person's path.
- Deeper research (offered once): up to 6 more searches and 2 more fetches, several more minutes, covering the strategy brief in depth, interviewer public footprint once names exist, role-family loop reports and recent organisation context → the CO and CASE banks lose their generic labels and gain a fuller grounding brief.
- Prep time available → a prioritised schedule for the days before 3 December.
- A `tuesday-dossier.md`, if you have one from an earlier session → verified evidence and prohibited-claims rules, which would sharpen the guidance cells.
