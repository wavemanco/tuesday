Search permission was refused, so none of the four lookups ran. I'm building the pack from your JD and what you told me, and I'll record the refused searches in its Sources section.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-7-denied-be198922/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 20 questions across six personas and a requirement-coverage table for every line of the JD. It also has six reverse questions, a list of claims it won't coach, and a three-day prep order.

I built it for a hiring-manager round, since you didn't say how Tobias relates to the role.

**Research didn't run.** Search permission was refused on all four lookups: Saltmarsh's values, its interview process, its strategy, and Tobias's public footprint. The pack therefore has no company-specific material and no read of Tobias himself. The case questions are generic, and the pack names that limit in its Sources section.

- **Biggest prep item:** B1 covers your stated gap on in-app purchases. The pack has you say it plainly before they ask: "I haven't worked on a game with in-app purchases." Then you give your calendar and retention work at exactly the scope you described.
- **Second gap:** your stated "Never led a team" shows up in B2, and the JD asks you to coordinate those teams rather than manage them.
- **What the pack won't let you claim:** running live events, running two titles, or owning the review and its KPIs. Your material says a weekly content-drop calendar for one main title, a release checklist you wrote, and monthly retention numbers you presented.

Say the word and I'll play the Skeptic on B1, the question the pack names as your highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, or a skip-level or peer, and has the recruiter told you the format, focus areas or anything to prepare? The answer reweights the banks.
Would you like to paste your CV? Without it, the pack rests only on what you wrote in your message.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

Interviewer: Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager (you did not say). One 60-minute session on Friday 27 November. Candidate: Femi.

## How to use this pack

Personas are how a question arrives. Types are what it is scoring. Guidance is scaffolding, not a script: say the quoted sentences in your own words and add nothing they do not say. Question IDs skip the letter F so they never collide with the fit-snapshot rows.

Type key:

- VAL: whether past behavior shows the company's published values (none asked for in this pack; no published values were available)
- EXP: whether the claims on your background survive scrutiny, and what was actually yours
- JD: can you do the listed job, including its gaps
- CO: company and strategy knowledge (none in this pack; research did not run)
- CASE: a live problem from the role, delivered out loud

Provenance labels: `[grounded]` traces to your message or the JD you pasted; `[inferred]` is this pack's derivation, named; `[generic]` is a role-family pattern with no claim about you or Saltmarsh.

## Prep triage

Sized to the three working days before Friday. The few things done well, in order:

1. Say B1 aloud until it is boring. It is the highest-ROI prep in this pack.
2. Write your 90-second arc for D1 using only the four sentences it quotes, plus your own reason for the move.
3. Rehearse A1, A3 and A4 aloud, thinking out loud in the order the persona table gives.
4. Decide your honest branch for each answer slot in B2, B4, C1 and G2, and say each once aloud.
5. Find which two titles the role covers (the recruiter or the careers page will say) and play both, for D2.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material does not show live events or a second title, and the words stay at the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's live-events and two-titles lines make a probe on both likely. If any drops were timed events, or you planned for more than one title, say which and how, in your own words; if not, say so plainly and stay with the calendar you ran |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message; "Never led a team" — your message | low | [inferred] | discovery | Neither quote states coordination with those teams, and the JD asks you to coordinate, not to lead. The one stated limit gives you the words: "I haven't led a team." Answer slot: if you worked with design, art, engineering or community on updates, say which teams and what you did with each, in your own words; if some were not part of your work, or there was no such coordination, say so plainly and stay with the calendar you ran |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | transferability | Your material says presenting the numbers, not owning a review or its KPIs, and the words stay there: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's own-the-review line makes a probe likely. If you chose what was reported, or ran any review after a content drop, say what it covered and what was yours; if the numbers were produced elsewhere, or no such review existed, say so plainly and stay with presenting them |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that your QA team still uses it, not who ran it on each release, and the words stay there. Answer slot: if you ran it with QA on releases, say how, in your own words; if QA ran it, or it was used without you, say so plainly and stay with having written it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | The four years are stated and the two years of content drops are the part your material carries; it does not say how many of the four were on a live-service title. Answer slot: the JD's three-years line makes a probe on which years were live likely. Say which, in your own words; if only the content-drop years were, say so plainly rather than counting all four |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap in the words. Lead with the calendar in the quote's own terms: weekly, your main title, two years. A named cadence beats an adjective, and with nothing inspected behind the line, expect a probe on how the calendar worked |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap in the words, but a line with nothing inspected behind it. Lead with it in the quote's own terms, and expect a probe on how the numbers were counted, which C1 rehearses |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | The checklist is the one written work your material names, and its use by your QA team is all it shows about clarity. Answer slot: if there is other writing others relied on, say which; if there is none, say so plainly and offer the checklist itself |
| F9 | In-app purchase experience on a game (role-family expectation; the JD does not state it) | "never worked on a game with in-app purchases" — your message | none | [generic] | capability | A gap you stated, so the pack gives you the words back: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Nothing is added to make the gap feel smaller |

## Persona table

Weights are a shown judgment. Change them if you know something I do not.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: plan this, diagnose that | High. Hiring-manager prior (assumed). The JD is built from plans, reviews and KPIs, which suit cases | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the gaps | High. Hiring-manager prior. Two gaps are stated (F2, F9) and others sit at medium in the snapshot | Rehearse B1 until boring; bridges only from adjacent evidence you stated; calibrated candor |
| Data-Driven Prober | Line-by-line on the retention numbers and KPIs | Medium. The JD names retention metrics and KPI ownership | Know what you can and cannot say about how each number was counted; say plainly when you do not know |
| Conversational/Rapport | Friendly opener, casual questions that are still scored | Medium. Every interview opens this way | A pre-scripted 90-second arc (D1); treat casual questions as scored |
| Peer Evaluator | Seams between teams, credit, disagreement | Low. Tobias is likely your future manager, not a peer, but the JD is cross-team | Offer seam principles instead of pretending to know the seam; say what you bring them |
| Pressure | Time-boxed challenges, how much was you | Low. Possible in a hiring-manager round | Pause, restate, hold through two follow-ups, concede specifically |

Basis: the relationship prior for a hiring manager. No interviewer footprint was available (research refused) and no loop source beyond your own words: one 60-minute session with Tobias.

## Question banks

### A. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You take over the live-events calendar for two mobile titles next month. What do you need to know first, and how do you structure your first six weeks?" | CASE | [generic] | Clarify before structuring: how each title's cadence runs today, what each team's capacity is, which KPIs get reported now, who signs off a release. Then the objective, how you split the work (per title, per event type), your approach for the six weeks, how you would measure it, and the risks. Think aloud and challenge one premise politely, such as whether both titles should share one calendar view. The question asks about no past, so the guidance makes no claim about you | The JD's first line, set as a live problem; F1 is the row it tests. CASE because it scores structure over the right answer. `[generic]` because it is a pattern, not a fact about Saltmarsh |
| A2 | "An event is due Thursday. Art has delivered and community has announced the date, but engineering says a blocker runs to Friday. Walk me through your decisions." | CASE | [generic] | Establish what the blocker is and what is actually at risk. Lay out the options in order: hold the date, ship a reduced version, or move the date and tell players. Say how you would choose, who has to agree, and what community is told and when. Say that a release goes through QA's checklist, not around it. End with what you record afterward. No claim about your past | Tests F2 and F4 as a decision under pressure. CASE because it is a live scenario |
| A3 | "Retention in one title drops after an event ends. Diagnose it." | CASE | [generic] | Confirm the metric's definition and the baseline you compare against. Segment it: new versus returning players, platform, app version, region. Line the drop up against the event timeline, other releases and outages. Check data quality before cause. List hypotheses, say what you would look at first and what would change your mind, then your next step and who you tell. Ask the data team where your own data stops | F3 and F7 as a live problem; the JD names retention metrics and the post-event review. CASE with JD content |
| A4 | "Design the post-event review for a two-week event. What goes in it, and who reads it?" | JD | [generic] | Ask what the team reports today, then build the review in the order the work happens: the goal set before the event, the KPIs that match it, results against the goal, what you learned, the decisions it leads to, an owner for each. Keep it to one page that a busy reader can act on, since the JD asks for clear written communication. No claim about your past | F3 and F8: the JD says you own the review and what it reports. JD tagged, CASE delivery |
| A5 | "Design and community each say their event should have the week you have for one. How do you decide?" | CASE | [generic] | Name the criteria you would use before taking sides, what data you would look at, who has the final call, and when you escalate. Ask who owns that call. Say how you would tell the team that lost the week. The question asks about no past | F2: the JD asks you to coordinate across teams, and you stated you have not led one. CASE because it is a trade-off with no right answer |

### B. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked on a game with in-app purchases. What would you need to learn first to run live events here, and how would you learn it?" | JD | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack, because it rests on a gap you stated. Name the limit before it is asked for: "I haven't worked on a game with in-app purchases." Then the nearest work your material carries, at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years" and "I presented the monthly retention numbers to the studio head". Stop there; do not say what that work taught you about spending. Then a plan, never a past: the first things you would learn, from whom, and how fast, in your own words. Follow-ups to rehearse. One: what could you not do in week one; name it plainly. Two: why take that risk; hold on the two quotes, concede the limit once and exactly, and add no experience to win the point. Three: pressed on a tool or number, say you have not worked with it and ask what the team uses. Answer slot: if you have learned any of this outside a job, say what and how, in your own words; if not, say so plainly and return to the plan | F9 is a gap you stated outright, so the pack treats it as the most probable probe and gives it the most follow-up levels. JD because it scores whether you can do the listed job with that gap |
| B2 | "You haven't led a team, and this role coordinates design, art, engineering and community. How do you get a date to hold when you are not their manager?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years" | Name the limit first: "I haven't led a team." The JD asks you to coordinate those teams, not manage them, so answer what is asked. Answer slot: if you held a date across teams, say which teams, what you did and how the date held, in your own words; if you did not, or it was not yours, say so plainly and say how you would set it up: agree at the start who decides, keep one visible calendar, raise slips early | F2 holds the stated limit and the JD's coordinate line together. JD because it scores the listed responsibility, Skeptic because it goes straight at the gap |
| B3 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head"; "never worked on a game with in-app purchases" | Selection scaffold: pick one gap that is true for you, say it before they do, give the nearest quote at its own scope, and end with a first step stated as a plan. Your material gives two candidates: F3 (the material says presenting retention numbers, not owning the review or its KPIs) and F9 (the stated in-app purchase gap). If neither is the honest answer, say so plainly and name the nearest thing your material does carry | Persona stem for the Skeptic; F3 and F9 are where the material is thinnest. JD because the question scores the listed requirements |
| B4 | "You ran the calendar for your studio's main title. This role runs two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say the quote at its scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: if you planned for more than one title, or beyond the weekly drops, say what, in your own words; if not, say so plainly and stay with the calendar you ran. Then think aloud on what changes, as a plan: shared teams across two calendars, clashing dependencies, separate KPIs per title | F1 states one title and the JD states two. JD because it scores the stated requirement |
| B5 | "Why this move, and why now?" | EXP | [generic] | Your material says nothing about why you are leaving or what draws you here, so this pack writes no reason for you. Give one reason that is true, and one line of the JD you actually want to do, quoted: "Plan and run the live-events calendar for two of our mobile titles". Say nothing about Saltmarsh you have not verified. The test: you would give the same reason if asked again | Persona stem for the Skeptic; motivation consistency is scored in every hiring-manager round. `[generic]` because the answer is only yours to write |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head. How were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F3: presenting, monthly, to the studio head, which are the beats the quote states; tell them in your own words. Answer slot: say which retention measures you presented and how each was counted; say what each is sensitive to and the one assumption you would defend least; say which part was yours. If you produced the numbers, say how; if they came from elsewhere and you presented them, say so plainly. If you do not know how a figure was counted, say that | F3 and F7 are the likeliest place for a number probe. EXP because it tests what was actually yours |
| C2 | "Tell me about a time retention data changed what you shipped next." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: pick an instance where numbers led to a decision. It needs what the data showed, the decision, and what you would do differently. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I presented the monthly retention numbers to the studio head", or how you would use the numbers | The JD asks for retention metrics and the post-event review (F3, F7). EXP because it asks for a real instance |
| C3 | "Which KPIs would you put in a post-event review, and which would you refuse to report?" | JD | [generic] | Ask first which KPIs the team reports today. Then tie each KPI to the event's goal, define it and its denominator before the event, say what you compare it against, and name one measure you would leave out and why. No claim about your past | The JD says you own the KPIs the review reports (F3). JD because it scores the listed responsibility |

### D. Conversational/Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc in five beats, the first four being those four sentences in their own terms, told no bigger than they are. The fifth is why this role, which is your own sentence; the pack has no source for it. Under 90 seconds aloud | The opener is scored even when it feels casual. F5, F6, F4 and F3 supply the beats. EXP because it is your own history |
| D2 | "Which mobile live-service game do you follow closely, and what do they do well with events?" | JD | [generic] | Pick a game you actually play, and describe what you see in its events in your own observation. The pack states nothing about that game. If you do not follow one, say so plainly and say how you would study Saltmarsh's two titles | The JD is about live events on mobile titles; this is the casual-register probe on it. `[generic]` because it needs your own observations |
| D3 | "Tell me about a release that did not go as planned." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold: pick a release where something went off-plan. It needs what failed, your decision, and what changed afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "Wrote the release checklist our QA team still uses" | The JD's release-checklist line (F4). EXP because it asks for a real instance |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where does the producer's job end and a designer's begin on a live event, and what happens when you disagree?" | JD | [generic] | Offer principles instead of pretending to know the seam. Ask who has the final call on content. Say what you would need from design and what you would bring them: one calendar and one place to see dependencies. For a disagreement, say how you would raise it: early, with the options laid out. The question asks about no past | F2: the JD names design as one of the teams you coordinate. JD because it scores the listed responsibility |
| E2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold: pick a time work spanned teams, and say which part was yours; "we" for context, "I" for your contribution. Your material's cross-team sentence is the checklist: say it at its scope, that you wrote it and your QA team still uses it, and claim nothing of QA's work. If no such time comes to mind, say so plainly, then give that sentence, or how you would handle it | Persona stem for the Peer Evaluator; F4 is the one quoted cross-team sentence. VAL because it scores behavior, with no published values behind it |

### G. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who has run live events with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | Hold-then-concede. Pause and restate. Hold on the three work sentences, each at its scope. Concede once, exactly: "I haven't worked on a game with in-app purchases." Hold through two follow-ups by returning to the sentences, never by adding to them | Persona stem for the Pressure interviewer; F9 is what this question is built on. JD because it scores fit for the listed role |
| G2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold the quote: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: say which parts were yours, in your own words; if some of it came from design, engineering or someone above you, say so plainly and return to the calendar you ran. Hold through two follow-ups, and concede the specific part, not the whole | F1 and F6. Attribution probes exist to catch inflation, so the rehearsal is precise candor |

## Requirement coverage

| Requirement | Questions | Notes |
|---|---|---|
| Plan and run the live-events calendar for two titles (F1) | A1, A5, B4, G2 | |
| Coordinate design, art, engineering and community (F2) | A2, A5, B2, E1 | |
| Own the post-event review and its KPIs (F3) | A3, A4, C1, C2, C3 | |
| Manage the release checklist with QA (F4) | A2, D3, E2 | |
| 3+ years producing live-service games or apps (F5) | B3, D1, G1 | |
| Experience running a content calendar (F6) | A1, B4, D1, G2 | |
| Comfortable with player-retention metrics (F7) | A3, C1, C2, C3 | |
| Clear written communication (F8) | A4, D1 | |
| In-app purchase experience (F9; not stated in the JD) | B1, B3, G1 | |
| Company values and strategy | none | No published values or strategy material was available; research did not run |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would success look like at six months, and which KPIs would I be reporting from my first post-event review?" | The JD makes the review and its KPIs part of the job, so asking shows you read it that way |
| R2 | "Which two titles would I start on, and how different are their event cadences and teams?" | The JD says two titles; it shows you are thinking about the load before taking it |
| R3 | "Where do events usually get stuck between design, art, engineering and community, and what would you want me to fix first?" | It invites Tobias's own experience of the seams, which is the best way to learn the real ones |
| R4 | "What does the release checklist look like today, and who owns it with QA?" | The JD names the checklist; it lets you place the one you wrote against what exists |
| R5 | "What would you want me to learn first in my first thirty days?" | It turns a gap you may have named into a plan he can shape |
| R6 | "Can you tell me about a post-event review you thought was strong, and what made it so?" | It tells you what the review is for, in his terms, and signals you care about the review as a document |

No reverse question is tied to Tobias's own career path, because no interviewer footprint was available.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team or managed people | Negative you stated, F2 | The plain acknowledgment: "I haven't led a team." No slot |
| Worked on a game with in-app purchases, or on monetisation | Negative you stated, F9 | The plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot |
| Ran live events, or ran the calendar for two titles | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the weekly content-drop calendar for your main title. B4's slot stays inside it |
| Owned the post-event review or its KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says presenting the numbers. C1's slot asks only what was counted and which part was yours |
| Managed the release checklist on each release with QA | Inflated form of F4 | F4's quote at its own scope. The pack's observation: the material says you wrote it and your QA team still uses it |
| Four years producing live-service games, or a producer title | Inflated form of F5 | F5's quotes at their own scope: four years as an associate producer, and two years of the weekly calendar |

## Sources

Provided documents: the job description pasted in your message; your background as stated in the same message. No dossier was present.

Searches sent, all refused (search permission was not granted; nothing came back and nothing from any of them is used):

- Saltmarsh Games values: refused
- Saltmarsh Games interview process live operations producer: refused
- Saltmarsh Games mobile studio strategy news: refused
- Tobias Wrenfield Saltmarsh Games Head of Live Operations: refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Would have fed a values cheat sheet and VAL questions; both are absent, and E2 is unthemed |
| 2. Saltmarsh Games interview process, live operations producer | unavailable | Would have set the loop and persona weights; they rest on the hiring-manager prior and your own words (one 60-minute session) |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have grounded a CO or CASE question in current strategy; A1 to A5 are `[generic]` |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have fed an interviewer read and a reverse question tied to his path; both are absent |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search permission, or a pasted values page and careers page: unlocks a values cheat sheet, a documented loop, and one CO or CASE question grounded in Saltmarsh's current strategy (A1 to A5 become grounded in it)
- Your CV text: replaces the evidence cells taken from your message and may upgrade F5, F6 and F8
- The recruiter's note on format, focus areas or anything to prepare: sets persona weights from the real loop and covers any pre-declared deliverable
- Tobias's talks, posts or public profile: an interviewer read, persona weights tuned to his public footprint, and a reverse question tied to his career path
- Your answers to the slots, stated outside a drill (F1, F2, F3, F4, F5, F8 and the slots in C1 and G2): those rows are regenerated from your own words
- The artifact that would raise F3, F4, F6 and F7 from medium: the checklist itself, a content-calendar export, or one monthly retention deck
- A `tuesday-dossier.md`: would add verified evidence and a prohibited-claims list so the pack can lean on confirmed material
