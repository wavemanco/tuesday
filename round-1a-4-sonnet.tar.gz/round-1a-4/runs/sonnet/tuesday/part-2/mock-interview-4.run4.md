Search permission was declined, so the company research didn't run. I'm building the pack from your dossier and your own words, and I'll mark which questions are generic because of that.
Your prep pack is saved as `Quartzline_product-manager-platform-apis_interview_pack.md`. It's built for the 45-minute hiring-manager round, from your dossier and your own words. Company research didn't run because search permission wasn't granted. The values, loop and strategy lookups are marked unavailable in Sources, so the case questions are role-based, not Quartzline-specific.

- **Rehearse A1 first.** It's the objection the underwriter named: no PM title, no roadmap, so why you over a PM with three years. The answer opens with the concession, then states what you did using only your confirmed lines. It stays inside that limit through two follow-ups.
- **The bridge has limits.** Your integration, playbook and roadmap-input lines are framed as adjacent, never as PM experience. The pack lists the claims it won't coach: the PM title, roadmap ownership, and setting squad priorities.
- **Open spots.** Agile delivery, API docs and schemas, specs for squads, and adoption metrics have no evidence in the dossier. Those answers are slots you fill from your own experience or answer with a plain "no".
- **Reverse questions.** The first two come straight from the dossier's open risks: which decisions are yours versus the squad leads', and how adoption is measured today.

Say the word and I'll run a live drill, starting with the Skeptic on A1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview prep pack — Product Manager, Platform APIs at Quartzline

**Round:** one 45-minute conversation with the hiring manager, Thursday. Interviewer name not given, so there is no interviewer read. Built from your underwriting dossier and your own words. Company research did not run (see Sources), so company-specific content is limited to what the dossier carries.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether claims about your work survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Knowledge of the company and its strategy |
| CASE | A live problem set in the role |

## Prep triage

Two days to Thursday. In order:

1. A1, then P1 and P2. These are the one objection the underwriter named, said aloud until it is boring.
2. A2 and B2, which are where the roadmap and prioritization gap (F2) will be tested.
3. C1 and C2, which defend the 30+ figure and what was yours.
4. D1, the 90-second arc, and B1 and B4, the live cases.
5. The reverse questions, with at least the first two ready.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — JD (dossier role_profile R1) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | The underwriter's strategy for R1 is bridge, and its framing binds: adjacent work, never PM experience. Confidence low is the underwriter's grade for R1. Your words stay at the quote's scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." The limit, as the pack's observation: the material shows input into a roadmap, with limited inspectable proof behind it, not time in the PM role, so volunteer that limit before it is extracted. Plain acknowledgment, sourced to prohibited_claims: "Having held a product manager title or role": "I haven't held a product manager title." |
| F2 | "Own the roadmap for the partner-facing API platform" — JD (dossier role_profile responsibilities), with the underwriter's R1 sub-claim, "Owning a roadmap and prioritization authority" | none given | none | [grounded] | capability | The underwriter's strategy is acknowledge_gap, so there is no bridge. Words, sourced to prohibited_claims: "Having owned a product roadmap" and prohibited_claims: "Having set prioritization for an engineering squad": "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a plan, never a past: in the first weeks, sit with both squad leads, learn which decisions are the PM's and which are theirs, and learn how adoption is measured today |
| F3 | "Shipped API or platform products" — JD (dossier role_profile R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [grounded] | transferability | The handoff names R2 high-priority and does not grade it as a weak area; the gap type is this pack's own call. The quote says integrations of the vendor's REST APIs, not building or shipping them, and the words stay there: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: the JD's shipped-products line makes a probe on whether any of that work shaped the API itself likely. If any of it did, say what and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — JD (dossier role_profile R3) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quotes touch the requirement without showing whether they reach API documentation or schemas. Answer slot: the JD's API docs and schemas line makes a probe on that likely. If any of the work involved reading or writing API documentation or schemas, say which and what you did with them, in your own words; if it did not, or was not yours, say so plainly and stay with the architecture stage and the playbook you wrote |
| F5 | "Stakeholder management across engineering, sales, customers" — JD (dossier role_profile R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | discovery | The quotes name clients and product. They do not show engineering or sales as stakeholders. Answer slot: the JD names engineering, sales and customers, so expect a probe on each. If engineering or sales were people you worked with, say how, in your own words; if they were not, say so plainly and stay with clients and product |
| F6 | "Agile delivery experience" — JD (dossier role_profile R5) | none given | low | [grounded] | discovery | The underwriter's strategy is clarify and its grade is low. No verified entry speaks to this requirement, so nothing about your past is written here. Answer slot: expect the probe "Agile delivery experience". If you delivered inside sprints or a similar cadence, say how, in your own words; if you never worked that way, say so plainly. A line you can say either way: "Here's what I'd want to confirm about how you define agile delivery on these squads." |
| F7 | "Run discovery with integration partners" — JD (dossier role_profile responsibilities) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [grounded] | transferability | Your words stay at the quote's scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Answer slot: the JD's discovery line makes a probe on how partner evidence was gathered likely. If you gathered it yourself, say how, in your own words; if it came to you from others, or there was no such step, say so plainly and stay with the sessions you ran |
| F8 | "Write specs and drive delivery with two engineering squads" — JD (dossier role_profile responsibilities) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | low | [inferred] | discovery | The quote lists requirements and go-live as stages of the integrations and does not show specs written for squads. Answer slot: the JD's specs line makes a probe on that likely. If you wrote requirements that engineers built from, say what the document was and who built from it, in your own words; if you did not, say so plainly and stay with the stages in your quote. Nothing here touches who set a squad's priorities, which F2 covers |
| F9 | "Define and track adoption metrics" — JD (dossier role_profile responsibilities) | none given | none | [grounded] | discovery | Nothing in the material speaks to adoption measures. Answer slot: the JD's adoption-metrics line makes a probe on that likely. If you tracked any usage or adoption measure for the integrations you led, say what was counted; if you did not, say so plainly, and say what you would measure first |

## Prohibited claims

Built from the dossier's `prohibited_claims`, plus the stretched forms of your own quoted sentences.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | prohibited_claims item | "I haven't held a product manager title." Then the quotes at their own scope (F1) |
| Having owned a product roadmap | prohibited_claims item | "I haven't owned a product roadmap." Then the plan in F2, never a past |
| Having set prioritization for an engineering squad | prohibited_claims item | "I haven't set prioritization for an engineering squad." Then the plan in F2 |
| Shipped or built the API platform itself | Inflated form of F3 | F3's quote at its own scope: integrations of the vendor's REST APIs. The limit is the pack's observation, not words for you |
| Owned the roadmap, because you ran the roadmap-input sessions | Inflated form of F1 and F7 | The quote at its own scope: sessions feeding client evidence to product. The material says input, not ownership |
| Wrote the product's developer documentation | Inflated form of F4 | The quote at its own scope: an internal integration playbook your team uses. Answer slots stay inside that |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the title, roadmap and authority gaps | High. Hiring-manager round per your note, and the underwriter named a standing objection (A1) | Rehearse A1 until it is boring; bridge only from your quoted evidence and say the limit first |
| Case/Strategist | Live problems on the partner API platform: adoption, prioritization, discovery | High. Hiring-manager round per your note, and the JD's roadmap, discovery and metrics lines are all decision work | Clarify, then structure, then answer; say your assumptions aloud, including what you would confirm about decision rights |
| Data-Driven Prober | Goes line by line through the 30+ figure and what was yours | Medium. Your strongest evidence is a headline figure and an inspectable playbook | Know how the figure was counted, or say plainly you do not; name the assumption you would defend least |
| Conversational | Opening arc and a casual technical question | Medium. A 45-minute conversation opens with biography | A 90-second arc built from your three quotes; treat the casual technical question as scored |
| Peer Evaluator | The seam with the two squad leads, and what happens on disagreement | Low as a style and high as content: the JD asserts squad authority that the dossier says is not evidenced | Propose seam principles and ask where the seam sits; do not pretend to know it |
| Pressure | Time-boxed "why you" and "how much was you" | Low. Nothing in your inputs points to a stress style, but the A1 objection invites it | Hold the quote's scope through two follow-ups, then concede specifically |

**Highest-ROI rehearsal: A1.** The underwriter's dossier named this objection (`likely_interviewer_objections`), so it comes from what you confirmed and not from a cold read. It gets the most follow-up levels below.

## Question banks

### A. Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; prohibited_claims: "Having held a product manager title or role"; prohibited_claims: "Having owned a product roadmap" | Concede first, plainly, before the interviewer extracts it: "I haven't held a product manager title, and I haven't owned a product roadmap." Then what you did, at the quotes' scope: you led 30+ end-to-end client integrations, you wrote the integration playbook your team uses, and you ran quarterly roadmap-input sessions feeding client evidence to product. Name the limit yourself: the roadmap-input work is input, and there is limited inspectable proof behind it, so expect a probe. Offer the playbook as the thing they can inspect, after checking you may share an internal document. Do not argue you are better than a PM with the title. Follow-up 1, "Which of those sessions changed what product decided, if any". Answer slot: if one did, say which and what part was yours, in your own words; if none did, or you cannot trace one, say so plainly and stay with the sessions you ran. Follow-up 2, "So you would be learning roadmap ownership on our platform." Say yes, plainly, then the plan from F2, in the first weeks: sit with both squad leads, learn which decisions are the PM's, learn how adoption is measured today. Hold the quotes through both; concede the title and the roadmap each time they come back, without adding anything | F1 and F2 are the widest gaps against the role's own pitch, so this objection arrives in some form. JD because it scores the stated requirement; it is the underwriter's wording, kept whole because both negatives have a dossier source |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] prohibited_claims: "Having owned a product roadmap"; prohibited_claims: "Having set prioritization for an engineering squad" | Name roadmap ownership and squad prioritization, plainly: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then the plan, stated as a plan: first weeks with both squad leads, learning which decisions are the PM's and which are theirs, and how adoption is measured today. Do not name a weakness that is not on your list to seem balanced, and do not turn the plan into a claim about the past | F2 is the one gap with no bridge, so it is the honest answer to this stem. JD because it scores the role's stated requirements |
| A3 | "Tell me about a time you delivered work in an agile setting." | JD | [grounded] | The interviewer's probe is the JD's own wording, agile delivery experience. Answer slot: if you delivered inside sprints or a similar cadence, say how, in your own words; if you never worked that way, say so plainly. Then the line from F6 about how they define it on these squads. Do not describe ceremonies you did not run | F6 is a discovery gap: the evidence may exist and the material does not show it. JD because it scores the preferred requirement |
| A4 | "What have you shipped that was an API or a platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what you did in those words: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Answer slot: the JD's shipped-products line is the probe. If any of that work shaped the API itself, say what and what part was yours, in your own words; if none did, or it was not yours, say so plainly and stay with the integrations | F3 is a must-have with an adjacent bridge, so it gets asked directly. JD because it scores the stated requirement |
| A5 | "Why product management, and why now?" | JD | [generic] | Give your own reason in your own words; the pack supplies none. Build the answer from the three things your quotes carry, in the order of the arc in D1, and end on the reason you actually hold. If part of the reason is this platform, say what you know of it from the posting only. Do not claim research you have not done | F1's gap makes motivation the natural follow-on to A1. JD because it scores fit for the listed role |

### B. Case/Strategist (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partner API adoption has plateaued. Diagnose it." | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify first: what adoption means here and how it is measured today. Say that out loud as a question you would ask, because the posting does not say. Segment partners by where they are in a funnel; you can use the stages in your own quote as the funnel. Give two or three hypotheses, the data that would confirm each, and the first thing you would check. Name one premise you would challenge | F9 and F2 meet here: the metric is unknown and the decision rights are unknown. CASE because it is a live problem from the role's own metrics line |
| B2 | "Two squads, one quarter, three requests: a large partner wants a custom endpoint, sales wants a new SDK, engineering wants to pay down versioning debt. How do you decide?" | CASE | [generic] | Clarify what each request is worth and to whom, set criteria aloud, say what evidence you would gather from partners, and say who you would involve. State your assumption about decision rights and what you would confirm: which of these calls are the PM's alone and which belong to the squad leads. If it helps, say "I haven't set prioritization for a squad, so here is how I would reason" (prohibited_claims: "Having set prioritization for an engineering squad"). Make no claim about past decisions | F2 is where an interviewer will test reasoning because the gap has no past to probe. CASE because it is a live trade-off, with JD content from the roadmap line |
| B3 | "A partner's integration has been stalled in UAT for three weeks. What do you do, and what would you change in the platform so it does not recur?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Two parts: unblock the partner, then fix the cause in the product. For the first, diagnose where it is stuck among documentation, schema, sandbox and partner capacity, and agree the next step with the partner. For the second, turn the cause into a backlog item with evidence from the partner. UAT is a stage in your own quote, so you may speak from your own words about it; say only what you actually did, and make no claim about stalls you have not described | F4 and F7 sit here: technical fluency and partner evidence feeding the product. CASE because it is a live problem; the platform angle is JD |
| B4 | "How would you define and track adoption for a partner API?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Offer a small set of measures at different depths, from partners that have started through to partners with live use, and say which one you would watch first and why. Say what you would confirm about today's baseline. Answer slot: if you tracked any usage or adoption measure for the integrations you led, say what was counted; if you did not, say so plainly and answer from the problem | F9 is a responsibility with no evidence, and the dossier lists the baseline as unknown. JD because it scores a stated responsibility; CASE is the delivery |
| B5 | "How would you run discovery with a handful of integration partners over a month?" | CASE | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Plan it aloud: who you would pick and why, what you would ask, how you would record what you hear, and how it would reach the squads. The nearest real thing in your material, in your words: "I ran quarterly roadmap-input sessions feeding client evidence to product." Do not describe interview methods you used unless you say so in your own words | F7 is the discovery responsibility and F1's strongest bridge. CASE because it is a plan problem; JD content |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations figure was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: say how the 30+ was counted, what it is sensitive to, which assumption behind it you would defend least, and which part was yours, each in your own words. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do | F3 carries the pack's only headline figure, so a prober goes here first. EXP because it tests attribution |
| C2 | "Which of those integrations were end to end yours, and where did someone else own a stage?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Keep to the quote: you led them, and the stages are scoping, requirements, architecture, UAT and go-live. Answer slot: if any stage belonged to someone else, say which and who, in your own words; if every stage was yours, say so plainly. Use "we" for context and "I" for what you did | F3 and F8 depend on how much of the lifecycle was yours. EXP because it tests what was actually the candidate's |
| C3 | "Walk me through the integration playbook you wrote — what is in it and who uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Describe it in your own words: what it is for, how it is organised, who uses it. It is your most inspectable item, so offer to share it, after checking you may share an internal document, or describe it if you may not. Say only what is in it | F4 is partly carried by this artifact. EXP because it tests the one claim an interviewer can inspect |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with three beats, each one of the quotes in order: the integrations, the playbook, the roadmap-input sessions. Finish on your own reason for this role, in your own words. Say what you did at the quotes' scope and stop there | F1 is carried by these three quotes. EXP because it is the biography question, and the casual register is still scored |
| D2 | "What are you actually playing with in API tooling these days?" | JD | [grounded] | The JD's API docs and schemas line is the probe. Answer slot: if you use any API documentation or schema tooling, name it and what you do with it; if you do not, say so plainly and say what you would pick up first. Do not name a tool you have not used | F4 is a discovery gap, and a casual question is where it surfaces. JD because it scores technical fluency |
| D3 | "Tell me about a time you wrote requirements that engineers then built against." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Requirements is a stage in your own quote, so start there. Answer slot: if engineers built from something you wrote, say what the document was and who built from it, in your own words; if they did not, or it was not yours, say so plainly and stay with the stages in your quote | F8 is the specs responsibility. JD because it scores a stated responsibility |

### E. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Where is the seam between a PM and a squad lead, and what happens when we disagree?" | JD | [generic] | Offer seam principles and do not pretend to know this seam: the PM owns the problem and the evidence, the squad lead owns how it is built, and a disagreement goes to the data first. Say you would want to confirm where this team draws it. Then ask which decisions are the PM's alone. Make no claim about past disagreements | F2 and the dossier's authority risk meet here. JD because it scores the role's stated squad work |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work crossed teams, with a named contribution of yours and a named contribution of someone else's. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use "we" for context and "I" for what you did | F5 asks for work across engineering, sales and customers. VAL because it is a behavior probe |

### P. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over a PM who has done this job for three years?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; prohibited_claims: "Having held a product manager title or role" | The A1 answer, compressed: concede the title in one sentence ("I haven't held a product manager title"), then the two quotes at their scope, then stop. Pause before you start, and do not fill the sixty seconds | F1 is the gap this stem is aimed at. JD because it scores the requirement; the delivery is the time-box |
| P2 | "That roadmap-input work — how much of it was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold the quote's scope: "I ran quarterly roadmap-input sessions feeding client evidence to product." Volunteer the limit: confirmed, with limited inspectable proof, so say what you can show. Answer slot: if specific decisions followed, say which and what part was yours; if none can be traced, or others set the content, say so plainly and stay with the sessions you ran. Hold through two follow-ups, then concede specifically | F1 and F7 rest on this medium-confidence quote, so the probe goes here. EXP because it tests attribution |

## Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1 3+ years product management experience | A1, A2, A5, P1, P2 |
| R2 Shipped API or platform products | A4, C2 |
| R3 Technical fluency: API docs, schemas | B3, C3, D2 |
| R4 Stakeholder management across engineering, sales, customers | B2, E1, E2 |
| R5 Agile delivery experience | A3 |
| Own the roadmap | A1, A2, B2, E1 |
| Run discovery with integration partners | B5 |
| Write specs and drive delivery with two engineering squads | D3 |
| Define and track adoption metrics | B1, B4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier flags that decision authority against the two squad leads is asserted in the JD and not evidenced. This reads as diligence and answers what you need to know before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier flags that adoption metrics are named as a responsibility with no baseline stated. It shows you start from the measure |
| 3 | "How do the two squads divide the platform today, and how does the PM work with each?" | It shows you are thinking about the seam before you arrive |
| 4 | "What should be decided, or visibly in motion, by the end of a new PM's first quarter?" | It turns your ramp plan into a shared target |
| 5 | "Who talks to integration partners today, and what would you want that to look like?" | It ties to your roadmap-input sessions without claiming more than they were |
| 6 | "What is the thing partners complain about most right now?" | It gets a concrete problem to think about instead of a generic answer |

## Sources

Provided: `tuesday-dossier.md`, version 1.1, read and consumed. It supplied `role_profile` (requirements and responsibilities, treated as the JD's lines; `unknowns` used only as reverse-question seeds), `handoff_to_mock_interview` (all fields), and `decision` as context only. `evidence_map`, `risk_register` and `evidence_state` were not in the dossier. Your own words: a 45-minute hiring-manager conversation on Thursday; this establishes the single session the pack prepares for. No archetype fallback was used.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused (permission not granted): `Quartzline company values`; `Quartzline interview process product manager`; `Quartzline partner API platform strategy news`. Nothing from them is used.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | No values page was read. No values-style round is detected, so section 10 is absent either way; published values could still have themed VAL questions |
| 2. `Quartzline interview process product manager` | unavailable | Would have confirmed the round format. Persona weights rest on your stated relationship and the dossier |
| 3. `Quartzline strategy` / recent news | unavailable | Would have grounded a CO question. The CO and CASE questions are role-based and labeled accordingly |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's `role_profile` supplies the requirements, so the fit snapshot and JD-tagged questions are fixed without it |

## Upgrade menu

- Search permission, or a pasted values page and process notes → company-specific CO and CASE questions, a values check, and the round format. A deeper pass would add up to 6 further searches and 2 further fetches, several more minutes; this is offered once
- The interviewer's name → a read of their public professional footprint, reweighted personas, and a reverse question tied to their own path
- The recruiter's prep note → coverage of any focus areas or pre-declared exercise
- An agenda, notes or follow-up item from one roadmap-input session → raises the medium-confidence quote behind F1, F5, F7 and P2
- What the work involved, in your own words, for F3, F4, F5, F7, F8 and F9 → those rows move from answer slots to story-mapped guidance
