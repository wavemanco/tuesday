Searches were refused, so I'm building the pack from what you've told me and nothing else. I'm writing it now.
Your prep pack for all three rounds is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-6-denied-f547cd73/Larkfield-Systems_engineering-manager_interview_pack.md`. It has 29 questions: 10 for the Director, 10 for the panel and 9 for the VP, plus reverse questions for each round.

- **Research was refused.** My three searches on Larkfield (values, interview process, strategy) were declined, so nothing in the pack is company-specific. The case questions are generic and marked as such. There's no values cheat sheet for Monday, because that needs Larkfield's published values.
- **Built from your message only.** I had your role description and background but no full job description or CV. The quotes come from your own sentences.
- **The one to rehearse first is B1**, "Which part of this role would you be weakest at on day one?" It rests on your own words, "I've never owned a hardware-adjacent roadmap". It's built to be asked on Tuesday and again on Monday as J1.
- **Slots where your material is silent.** Growth of the people you lead, device-management work, and partnering with hardware or product are all things you didn't mention. The pack gives you answer slots there instead of stories. Each has a plain branch for "that wasn't mine" or "that didn't happen". Your reliability quarter and the 60% figure are used only as you stated them.

I can play the Skeptic on B1 with live follow-ups whenever you want. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word.

1. Can you paste the full job description and your CV? The pack works without them, but they would turn several slots into real answers.
2. Did the recruiter say anything about what the panel will cover, such as an exercise or a take-home?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield-Systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (three-round loop)

Loop mode. Round 1: hiring manager, a Director of Engineering and your would-be boss, 45 minutes, Tuesday. Round 2: panel of two staff engineers and a product manager, 60 minutes, the Thursday after. Round 3: the VP Engineering, 30 minutes, the following Monday, described by the recruiter as "values and leadership philosophy". No interviewer names were given.

## How to use this pack

- Personas are how a question is asked. Types are what it is scoring.
- Guidance is scaffolding, not a script. Every sentence about your past comes from your own words, quoted in the Provenance column. Where your material does not carry a step, the guidance is an answer slot: say what is true, in your own words, or say plainly that it was not yours or did not happen.
- Type key: VAL is behavioral or values alignment. EXP is a work-experience deep-dive. JD is role-driven. CO is company and strategy knowledge. CASE is a live hypothetical problem.
- Provenance key: `[grounded]` rests on your quoted words or a supplied document. `[inferred]` is a derivation, named. `[generic]` is a role-family pattern with no claim about you or about Larkfield.

## Prep triage

Sized to the order of the rounds. Do these, in this order, and treat the rest as insurance.

1. Before Tuesday: B1, the highest-ROI rehearsal in the whole loop. Then C1 and C2, because both of your headline numbers are in your own material and your would-be boss can probe them. Then D1, your opening arc.
2. Between Tuesday and Thursday: F1 and F2 (the reliability quarter, told to engineers), E1, and G1 (product partnership). Reuse what Tuesday showed you about how the Director probes.
3. Between Thursday and Monday: I2, I4 and J1. Monday is short, so these three carry it. J1 reuses B1's concession.
4. Everything else is insurance.

## Fit snapshot (shared by all three rounds)

Requirements are quoted from the role description in your message. The role description carries no location, pay, schedule or credential terms, so there is no gate row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads" — role description in your message | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says one team of six, and the words stay there: "Nine years in engineering, three as a team lead of six." The pack's observation: it does not show two squads or eleven engineers, and the role description does not say whether the squads have their own leads. Answer slot: the JD's two-squads line makes a probe on leading across more than one team likely. If you have led work across more than one team, say how, in your own words; if you have not, say so plainly and stay with the team of six |
| F2 | "own delivery" — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | The quote carries a reliability quarter you pushed through and a 60% fall in on-call burden, and the words stay there. It does not say what the roadmap pressure was, who applied it, or what you traded. Answer slot: the JD's delivery line makes a probe on how the quarter was weighed against the roadmap likely. If you made trade-offs, say what and how you decided; if the quarter was set by others, or there was no explicit trade-off, say so plainly and stay with the quarter and the result |
| F3 | "hiring" — from "own delivery, hiring and growth for 11 engineers" in your message | "I run our hiring loop for backend roles" — your message, "about 40 interviews last year" — your message | medium | [grounded] | none | No gap in the terms you used, but a self-report with nothing inspected behind it, so expect a probe. Lead with the loop and the figure in the quote's own terms: you run the loop for backend roles, and the 40 counts interviews. Answer slot: the JD says own hiring, which makes a probe on what running the loop covers beyond the interviews likely. If any stage of hiring beyond the interviews was yours, say which; if none was, or it was not yours, say so plainly and stay with the loop and the interviews |
| F4 | "growth" — from "own delivery, hiring and growth for 11 engineers" in your message | none given | none | [grounded] | discovery | Your material does not show this requirement either way. Answer slot: the JD's growth line makes a probe on developing the people you lead likely. If you have grown anyone, say who and how, in your own words; if you have not, or it was not yours, say so plainly and stay with the team of six |
| F5 | "partner with hardware" — from "partner with hardware and product on roadmap" in your message | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | Your stated negative is about owning, and the words stay there: "I've never owned a hardware-adjacent roadmap." The JD asks about partnering, and your material is silent on that. Answer slot: if you have worked alongside hardware or firmware teams in any form, say what, in your own words; if you have not, say so plainly, then give a plan said as a plan, never as a past |
| F6 | "product on roadmap" — from "partner with hardware and product on roadmap" in your message | "I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote is adjacent work at its own scope. It does not say who applied the pressure or whether product was part of it, so no claim about a product partner is made. Answer slot: if product was part of that exchange, say how it went and what you did; if the pressure came from elsewhere, or you did not deal with product, say so plainly and stay with the quarter |
| F7 | "building device-management services" — role description in your message | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the JD's device-management line makes a probe on your closest technical work likely. If any of your engineering touched devices, fleets or hardware-connected services, say what, in your own words; if none did, say so plainly and stay with the reliability quarter |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 Lead two squads | A1, B2, I1, K1 |
| F2 Own delivery | A1, A3, F1, F2 |
| F3 Hiring | C2, H2 |
| F4 Growth | I3 |
| F5 Partner with hardware | A2, B1, F3, J1 |
| F6 Product on roadmap | G1, H1, K2 |
| F7 Device-management services | A2, D2, F3, K2 |

## Round 1: Tuesday, hiring manager (Director of Engineering), 45 minutes

Persona weights. No interviewer profile was given, so the interviewer read is dropped and weights come from the relationship prior (hiring manager, who is also your would-be boss) and from the loop you described.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from the role: two squads, hardware dates, reliability against roadmap | High (3 questions). The hiring-manager prior puts it first | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic | Quiet probing of the gaps: hardware, scale, motivation | High (3 questions). The hiring-manager prior puts it second, and the gaps you named yourself sit here | Rehearse the single most predictable objection until it is boring; calibrated candor over bluffing |
| Data-Driven Prober | Asks how your two headline numbers were counted | Mid (2 questions). Each headline figure needs a defend-the-number question | Know what you can and cannot say about how each number was counted; say plainly when you do not know |
| Conversational | Opens with "walk me through the journey" | Low (2 questions). Casual questions are still scored | A pre-scripted 90-second arc |

Highest-ROI prep in the pack: B1. This question will be asked in some form, by this Director and again on Monday, and a rehearsed non-defensive answer changes the interview.

### Bank A: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads, one hardware date that just moved up six weeks, and a reliability backlog. How do you decide what the squads do first?" | CASE | [generic] | Clarify first: how firm the date is, what depends on it, what each squad owns, what the backlog items risk. Then the objective, how you would split the work, the approach, the metrics you would watch, the risks. Challenge one premise respectfully, for example whether the whole six weeks must come from the roadmap. The question needs no claim about your past, so the guidance makes none | A live problem built on the role's two-squads and delivery lines (F1, F2). `[generic]` because the scenario is a pattern, not a fact about Larkfield |
| A2 | "A device-management service pushes an update to a customer's fleet and a fraction of devices stop responding. Walk me through your first hour as the manager." | CASE | [generic] | Structure it: what you need to know first, what limits the damage, who must be on the call and why (the squad, hardware, product, whoever speaks to the customer), what you tell the customer and when, what you record for afterwards. Say which parts you would lean on engineers for rather than ruling on them yourself. The guidance makes no claim about your past | The role's device-management and hardware-partnership lines (F7, F5) turned into a live problem. `[generic]` for the same reason as A1 |
| A3 | "How do you decide when a squad holds the roadmap and when it takes a reliability quarter?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure", "My team's on-call burden dropped 60%" | Story-mapped on F2: a reliability quarter, pushed through against roadmap pressure, and a 60% fall in on-call burden. Those are the beats; tell them in your own words. Answer slot: the JD's delivery line makes a probe on how you weighed it against the roadmap likely. If you made trade-offs, say what and how you decided; if there was no explicit trade-off, or it was not yours, say so plainly and stay with the quarter and the result | F2 is your strongest delivery evidence and the likeliest place to be asked how you decide. JD because it scores the delivery requirement |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | Highest-ROI prep. Level 1: give the concession in your own stated words and stop: "I've never owned a hardware-adjacent roadmap." It stays at "owned"; the pack's observation is that your material is silent on partnering with hardware, so do not widen it into "no hardware exposure". Answer slot: the JD's partner-with-hardware line makes a probe on any contact with hardware teams likely. If you have worked alongside hardware or firmware teams in any form, say what; if you have not, say so plainly. Level 2, when they say "Isn't that the centre of this job?": agree the JD names it, return to the concession, then give a plan said as a plan: pick two things you would actually do in your first month to learn how hardware dates shape a roadmap, and who you would ask first. Level 3, when they say "What if the answer is slow to come?": name the limit again in the same words and the plan again; do not add experience. If none of it is true for you, say so | F5 and F7 are where the role and your stated negative meet, and you named them yourself. Skeptic because it scores honest self-assessment and whether your story survives cross-examination; deepest rehearsal because it will be asked |
| B2 | "You've led a team of six. This role has eleven engineers across two squads. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6", "I've never managed managers" | Hold only what the quote carries: "Nine years in engineering, three as a team lead of six." Answer slot: the JD's two-squads and eleven-engineers lines make a probe on leading more than one team likely. If you have led work across more than one team, say how; if you have not, say so plainly and stay with the team of six. If asked directly about leads, your own stated words are: "I've never managed managers." The pack makes no claim about how the squads are organised | F1 is the scale gap. Skeptic because it tests whether you can say the limit without apologising |
| B3 | "Payments is a long way from industrial devices. Why this role, and why now?" | JD | [grounded] "currently at a payments company" | Give your actual reason, in your own words, in two sentences, tied to something real in the role as you described it, such as leading two squads that build device-management services. The pack does not supply a reason or a motive. Do not criticise your current employer | F7 is the domain gap. Skeptic because motivation consistency is scored |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60%" | Four slots, each in your own words. How it was counted. What it is sensitive to. The assumption behind it you would defend least; name it before they do. Which part was yours. If you do not know how it was counted, say so plainly, which is an honest answer. The pack supplies no method, baseline or measure | F2's headline figure is the likeliest target for a prober. EXP because it tests attribution honesty |
| C2 | "You said about 40 interviews last year. What was that number counting?" | EXP | [grounded] "about 40 interviews last year", "I run our hiring loop for backend roles" | The figure counts interviews, so keep it attached to interviews. Four slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | F3's figure is the second headline number. EXP for the same reason as C1 |

### Bank D: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6", "I run our hiring loop for backend roles", "I pushed a reliability quarter through against roadmap pressure" | A 90-second arc with only these beats: nine years in engineering, three as a team lead of six; the backend hiring loop you run; the reliability quarter you pushed through against roadmap pressure. End on why this role, in your own words. Time it aloud. Nothing about titles, budgets or team changes beyond those sentences | The biography question is scored even when it feels casual. F1, F2 and F3 supply the beats |
| D2 | "What are you actually playing with in device management these days?" | JD | [generic] | If something real comes to mind, say what and what you took from it. If nothing does, say so plainly, then say what you would want to learn first. The guidance makes no claim about your past | F7's casual form. JD because device management is the role's stated domain |

### Round 1 reverse questions

| # | Question | Why it lands |
|---|---|---|
| RA1 | "What would a good first ninety days look like in this role, and what would you want decided or shipped by then?" | Shows you think in outcomes, and tells you what the Director is buying |
| RA2 | "How do the two squads currently divide their time between roadmap and reliability work, and who decides when the split moves?" | Goes straight at the delivery tension in F2 as a peer conversation |
| RA3 | "When a hardware date changes, how does that reach the squads today?" | Shows you are already thinking about the seam you said you have not owned |
| RA4 | "What is hardest about the seam between hardware, product and these squads?" | Invites candour about the role's real difficulty, and shows partnership thinking |
| RA5 | "How is the hiring plan for the eleven engineers set, and who owns decisions on levels and offers?" | Ties to F3 and tells you what owning hiring means here |

## Round 2: the Thursday after, panel (two staff engineers and a product manager), 60 minutes

Persona weights. Names are unknown, so per-member assignment is by role: the staff engineers are treated as peers and technical specialists, and the product manager as a cross-functional partner, with the panel blend taking the top two personas of each.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting between staff engineers and you; "what would you need from me" | High (3 questions). Peer relationship prior for the staff engineers, and the PM's partnership lens | Reciprocity framing; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober | Depth verification of your reliability story and your technical judgement | High (3 questions). The technical-specialist prior for the staff engineers | Know what you can and cannot say; separate your decisions from the team's |
| Values/Behavioral | Scenario probes about disagreement and partnership | Mid (2 questions). The cross-functional prior for the PM | One real story each, "we" for context and "I" for contribution; where none comes to mind, say so |
| Conversational | Friendly, unstructured, scored | Low (2 questions). The cross-functional prior's second persona | Never answer "I think you've covered everything" to the reverse-question slot |

### Bank E: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between a staff engineer and you, and what happens when we disagree?" | JD | [generic] | Propose principles, not a pretend map of the seam: who owns the technical call, who owns the delivery commitment, and how a disagreement is escalated. Then a selection scaffold for the disagreement story: pick a time you disagreed with a peer or an engineer on a decision; it needs a named stake, your actual part in it, and a working relationship intact afterwards; if no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The staff engineers will price what a manager adds to their work. The guidance makes no claim about your past, so `[generic]` |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned more than one team where credit was split; say what you did, in your own words, and what part was yours. If no such time comes to mind, say so plainly, then give the principle you would follow | A peer-evaluator stem, because credit-sharing is a partnership signal. `[generic]` because it makes no claim about you |
| E3 | "What would you need from a staff engineer in your first month, and what could we expect from you?" | JD | [generic] | Reciprocity first: what you would bring to their work, then what you would need. State your needs as asks, not as history, for example learning how decisions get made. Do not claim technical authority you have not shown | F1's seam question in peer form. The reciprocity framing is the counter-strategy for this persona |

### Bank F: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Walk me through the reliability quarter you pushed through." | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure", "My team's on-call burden dropped 60%" | The beats: a reliability quarter, pushed through against roadmap pressure, and a 60% fall in on-call burden. Tell them in your own words. Answer slot: engineers will probe what the quarter contained. If you chose the contents, say how you chose; if they were set by others, or you did not choose them, say so plainly and stay with what you pushed and the result. Name the assumption behind the 60% you would defend least | F2 told to a technical audience. EXP because it tests what was actually yours |
| F2 | "Which part of that result was your decision, and which part was the team's?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" | The part your quote carries as yours is pushing the quarter through. Say that in those words. Anything beyond it is an answer slot: if other decisions were yours, say which; if they were the team's, or someone else's, say so plainly. Credit the team in your own words without adding what they did | Attribution honesty is the likeliest probe for an engineer panel (F2) |
| F3 | "A device-management service has to behave when devices are offline, slow or flaky. What do you want to see in a design review from a squad?" | CASE | [generic] | Name the questions you would ask as a manager: what fails first, what happens to a device that misses an update, how a bad change is stopped and rolled back, how the squad knows early. Leave technical rulings to the staff engineers and say so. Make no claim about device protocols or firmware you have not worked on | F7 and F5 as a design-review problem. CASE delivery over JD content. `[generic]` because it makes no claim about you |

### Bank G: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you and a product partner disagreed on scope." | VAL | [generic] | Selection scaffold: pick a time scope was contested with product; it needs a named stake, your actual part, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Your reliability quarter may be the nearest thing, but only if product was part of that exchange; if it was not, do not tell it as a product story | F6 is where the PM will press. The theme comes from the JD's roadmap-partnership line |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision with a named stake where the customer's need and an internal measure pulled apart, and say what you chose. If no such time comes to mind, say so plainly, then give how you would decide. The pack does not suggest a story for you | A values stem for the PM. `[generic]` because no quote carries a story |

### Bank H: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "How do you like to work with product managers day to day?" | JD | [generic] | Say what you would want, as intent and not history: how you would want roadmap conversations to run, what you would bring (clear delivery signals, early warning) and what you would need from them. Mark it as how you intend to work | F6 in casual form, for the PM. `[generic]` because it makes no claim about your past |
| H2 | "You run hiring today. What would you look for in someone joining one of these squads?" | JD | [grounded] "I run our hiring loop for backend roles" | Give your own criteria in your own words. The pack supplies none. If you have not hired for device or hardware-adjacent work, say so plainly and say what you would ask about | F3 in a form engineers care about. JD because hiring is in the role's terms |

### Round 2 reverse questions

| # | Question | Why it lands |
|---|---|---|
| RB1 | "What could a new manager do in their first month that would genuinely help the staff engineers?" | Reciprocity for the peer evaluators |
| RB2 | "Where are technical decisions made today, and where should a manager stay out?" | Shows you are drawing the seam with them rather than around them |
| RB3 | "How does a roadmap commitment reach the squads from product and hardware today?" | Gives the PM an easy way to describe the current process |
| RB4 | "What does a good planning conversation between the squads and product look like when hardware dates move?" | Ties to F6 and F5 without claiming experience |
| RB5 | "What would the squads like done differently in how they are run?" | Invites candour, and signals you listen before you change |

## Round 3: the following Monday, VP Engineering, 30 minutes, "values and leadership philosophy"

Persona weights. A loop source documents a values-style round: the recruiter's own words, "values and leadership philosophy". The relationship prior (skip-level or executive) points to Case/Strategist and Pressure, so Values/Behavioral is moved up on the recruiter's description and Case/Strategist down. No published Larkfield values are in hand, so there is no values cheat sheet; the upgrade menu says what would add one.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Leadership philosophy, hard truths, how you grow people | High (4 questions). The recruiter's description | Story-mapped where a quote carries one; a scaffold with an honest branch where none does |
| Pressure | Time-boxed, challenging: why you, how much was you | Mid (3 questions). The executive prior | Pause, restate, anchor in what you actually said; hold through two follow-ups, then concede specifically |
| Case/Strategist | One or two strategy-altitude problems | Low (2 questions). Down-weighted for a 30-minute values conversation | Clarify, structure, think aloud |

### Bank I: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "What is your leadership philosophy, in your own words?" | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure", "I run our hiring loop for backend roles", "9 years engineering, 3 as a team lead of 6" | A philosophy is a belief, so state it as one in your own words; the pack does not write it. Then support it with only what the quotes carry: a team of six that you led, a backend hiring loop you run, a reliability quarter pushed through against roadmap pressure. Pick the one belief your actual behaviour in those shows; if none of them shows it, say the belief and say plainly that you are still testing it | The recruiter named this round's theme. F1, F2 and F3 are the only history to hang it on |
| I2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "against roadmap pressure" | The reliability quarter may carry it, but only if pushing it through meant telling someone senior something unwelcome. If it did, say what you said and what happened, in your own words; if it did not, choose another time or say plainly that none comes to mind. Choose a story where the truth landed and the relationship held; where your material shows none, say so rather than supplying an ending | The standard values stem, and F2's "against roadmap pressure" is the nearest quoted sentence. The pack cannot say whether it carries |
| I3 | "How do you grow the people you lead?" | JD | [generic] | Answer slot: the JD's growth line makes this likely. If you have grown anyone, say who and how, in your own words; if you have not, or it was not yours, say so plainly and stay with the team of six. Then say, as intent, how you would want to do it | F4 is a discovery gap and the VP will ask about it. `[generic]` because your material says nothing about it |
| I4 | "You haven't managed managers. How do you think about leading through other leaders?" | VAL | [grounded] "I've never managed managers" | Open with your own stated words: "I've never managed managers." Then your view as a belief or plan, for example what you would want to learn from the people who have, said as intent. Make no claim to leading leaders, informally or otherwise. If asked a follow-up, return to the same acknowledgment and the same plan | Your own stated negative, as the likeliest leadership-philosophy probe. The JD does not say whether the squads have leads, so the pack does not assume it |

### Bank J: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Sixty seconds: why you over a manager who has run hardware roadmaps?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure", "I run our hiring loop for backend roles", "never owned a hardware-adjacent roadmap" | Pause, restate the question, then hold only what the quotes carry: you pushed a reliability quarter through against roadmap pressure; you run the backend hiring loop. Concede in your stated words: "I've never owned a hardware-adjacent roadmap." Hold through two follow-ups by returning to those sentences, never by adding to them; concede the limit specifically and do not fold on the core. Do not claim hardware experience | B1's concession at executive altitude. F5 is where the comparison bites |
| J2 | "Is the reliability quarter the best evidence you have of how you lead?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure", "9 years engineering, 3 as a team lead of 6" | Answer slot: if there is another example, name it and say what part was yours; if the quarter is the clearest, say so plainly and tell it only as quoted. Do not stretch it | A pressure probe on how thin the evidence base is. EXP because it tests whether your story survives a second look |
| J3 | "Why leave a payments company where you already lead a team?" | EXP | [grounded] "currently at a payments company", "3 as a team lead of 6" | Your actual reason, in your own words, in two sentences. The pack supplies none. Say what draws you to this role and do not criticise your employer. Hold the answer through one follow-up without changing it | B3 at executive altitude, tested for consistency |

### Bank K: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "If you inherited these two squads tomorrow, what would you want to know before changing anything?" | CASE | [generic] | Clarify before structuring: what each squad owns, how work is decided and by whom, where the pain is, what hardware and product expect. Then say what you would not change in the first weeks. The guidance makes no claim about your past | F1 as a live problem. `[generic]` because no research on Larkfield was possible |
| K2 | "A large customer asks for a device-management feature only they need. Hardware says it needs firmware changes. Product wants it. What is your recommendation?" | CASE | [generic] | Clarify first: size of the customer, the cost and risk of the firmware change, who else benefits. Then options, a recommendation with its trade-off stated, and what you would put in front of the VP. Challenge one premise respectfully. The guidance makes no claim about your past | F6, F5 and F7 together. `[generic]` for the same reason as K1 |

### Round 3 reverse questions

| # | Question | Why it lands |
|---|---|---|
| RC1 | "What does leadership look like here when a manager's call goes against what the roadmap wants?" | Tests the company's actual values against the topic of the round |
| RC2 | "What do you expect of a new manager in how they develop the people they lead?" | Ties to F4 and shows you are listening for the standard |
| RC3 | "What separates managers who thrive at the seam between hardware and software from those who struggle?" | Honest curiosity about the gap you named |
| RC4 | "What does the company need from engineering leadership over the next year that it does not have today?" | A strategy-altitude question that costs nothing to ask |
| RC5 | "What would you want me to have learned by the end of my first quarter?" | Shows you are planning the ramp |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers or led leads | Negative the candidate stated, F1 | The plain acknowledgment your message gives: "I've never managed managers." No slot |
| Has owned a hardware-adjacent roadmap | Negative the candidate stated, F5 | The plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Partnering is silence, not a claim, and is an answer slot (B1) |
| Led two squads or eleven engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a team of six |
| Owned the roadmap against product or hardware | Inflated form of F6 | F6's quote at its own scope. The material says a reliability quarter pushed through against roadmap pressure, and nothing about who applied the pressure |
| Owned hiring end to end | Inflated form of F3 | F3's quote at its own scope: you run the hiring loop for backend roles, and the 40 counts interviews |

## Sources

Provided documents: your message, containing the role description, the three rounds, and your background. No CV and no full JD were supplied.

Searches sent, all refused: `Larkfield Systems values industrial IoT` refused; `Larkfield Systems interview process engineering manager` refused; `Larkfield Systems device management strategy news` refused. No page was fetched.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | All calls refused. Would have supplied the values cheat sheet for Round 3. That section is dropped |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | All calls refused. Would have checked the loop. Persona weights follow your own description of the rounds instead |
| 3. `Larkfield Systems strategy` / recent news | unavailable | All calls refused. Would have grounded a CO or CASE question in current strategy. A1, A2, F3, K1 and K2 are `[generic]` |
| 4. `{interviewer name} Larkfield Systems` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | skipped | The role description in your message fixes the fit snapshot rows and the JD-tagged questions |

## Upgrade menu

- The full JD text, and your CV → more fit-snapshot rows and more `[grounded]` bank rows, including any requirement that appears only once in the posting
- The recruiter's guidance on the panel (focus areas, any exercise or deliverable) → Round 2 coverage, and a build section if a deliverable was announced
- The panel members' names or titles → per-member persona weights and an interviewer read
- Larkfield's published values, pasted or searched once search is permitted → the Round 3 values cheat sheet with a mapped story per value
- A strategy brief or recent news on Larkfield → real CO and CASE questions in place of the `[generic]` ones
- Your answers to the slots in F1, F2, F3, F4, F5, F6 and F7 → those rows and the banks that draw on them upgrade from slots to story maps
- A `tuesday-dossier.md` from an earlier evaluation of this role → verified evidence, per-gap strategy constraints, and a sourced objection list in place of the locally built one
