Search access was declined, so I'm building the pack from your message alone. I'll label what research would have covered and save the file now.
Your prep pack for all three rounds is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-6-denied-366a4dd3/larkfield-systems_engineering-manager_interview_pack.md`.

It's built as a loop: one shared fit snapshot, then a separate question bank and reverse questions for each round. Round 1 has 9 questions, Round 2 has 10 and Round 3 has 9. It also has a requirement-coverage table and a prohibited-claims list.

- **No research ran.** Search permission was declined, so company values, strategy and interview details aren't in the pack. The loop rests on your description of the three rounds. Questions that depend on Larkfield facts are marked generic, and the values cheat sheet is left out.
- **Panel assumption.** I treated the two staff engineers as technical peers rather than people who would report to you. If they would report to you, the panel weights shift, and I'll rework that round.
- **Highest-priority prep.** This is question B1, "Which part of this role would you be weakest at on day one?", where you open with your own words "I've never owned a hardware-adjacent roadmap" and follow with a ramp plan. It returns in Round 3 as J1.
- **No growth or domain evidence yet.** Nothing you've told me shows growth work with engineers or device-management work. Those rows are written as answer slots to fill in your own words, not as stories.

Offers, none required:
- I can run a live drill, playing the Director's Skeptic on B1.
- I can save a `tuesday-dossier.md` of the gaps this prep exposed, for later sessions.
- I can convert the pack to a Word document.

Can you paste the full job description or your CV? Either one would replace the three-clause role summary the pack currently rests on.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (loop mode, three rounds)

Candidate: Yusuf. Rounds: Tuesday, 45 min, Director of Engineering (hiring manager, your would-be boss). The Thursday after, 60 min, panel of two staff engineers and a product manager. The following Monday, 30 min, VP Engineering, described by the recruiter as "values and leadership philosophy".

Highest-ROI prep: B1 (Round 1), the hardware-roadmap gap you named yourself. It returns in Round 3 as J1. If you only have an evening, rehearse B1 aloud until it is boring.

## How to use this pack

- Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words.
- Type key: VAL is values or behavioral alignment. EXP is a work-experience deep-dive. JD is role- or requirement-driven. CO is company and strategy knowledge. CASE is a live hypothetical.
- Provenance: `[grounded]` rests on your own quoted words or a provided document. `[inferred]` is a derivation, named. `[generic]` is a role-family pattern with no claim about Larkfield or about you.
- An answer slot is an instruction for the interview, not a question for this chat. Where it offers two branches, either one is a good answer if it is true.
- Round question IDs: Round 1 uses A to D, Round 2 uses E to H, Round 3 uses I to L.

## Fit snapshot (shared across all three rounds)

The requirements are the three clauses of the role description you pasted. No full JD or CV was supplied, so every evidence cell is a sentence from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (leadership and scale side) — role description in your message | "3 as a team lead of 6" — your message; "I've never managed managers" — your message | medium | [grounded] | transferability | Your words: "Three of my nine years in engineering have been as a team lead of six." Your material says team lead of 6, not that six reported to you, and not two squads. Plain acknowledgment, which you stated: "I've never managed managers." Answer slot: the posting's two-squad line makes a probe on scale likely. If any of your lead work meant setting direction for more than one group, say what, in your own words; if not, say so plainly and stay with the team of six |
| F2 | "own delivery, hiring and growth for 11 engineers" (delivery clause) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote is about reliability work and roadmap pressure, not about being accountable for a delivery commitment, and the words stay at its scope: "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." Answer slot: the delivery clause makes a probe on how dates were kept likely. If you were the one accountable for a delivery date on your team, say how you kept it, in your own words; if not, or there was no such date, say so plainly and stay with the reliability quarter |
| F3 | "own delivery, hiring and growth for 11 engineers" (hiring clause) — role description in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe on the figure. Lead with the loop in the quote's own terms: you run it, for backend roles. The 40 counts interviews, so it stays attached to that noun |
| F4 | "own delivery, hiring and growth for 11 engineers" (growth clause) — role description in your message | none given | none | [grounded] | discovery | Your material does not show growth work either way. Answer slot: the growth clause makes a probe likely. If you have supported an engineer's growth, say who (no name needed) and what you did, in your own words; if not, say so plainly and say what you would do first, as a plan |
| F5 | "partner with hardware and product on roadmap" (product side) — role description in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The quote says roadmap pressure, not that product applied it or that you partnered with product on a roadmap, and the words stay at its scope. Answer slot: if product was the source of that pressure, say how you worked it through, in your own words; if the pressure came from elsewhere, or there was no such partner, say so plainly and stay with the quarter |
| F6 | "partner with hardware and product on roadmap" (hardware side) — role description in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F7 | "Lead two squads building device-management services" (device-management domain side) — role description in your message | none given | none | [grounded] | discovery | Your material does not show device-management or industrial-IoT work either way. Answer slot: if any of your work at the payments company resembles device-management services, say what, in your own words; if none does, say so plainly and say how you would get up to speed |

## Round 1: Tuesday, 45 min, Director of Engineering

### Persona weights

The Director is your would-be boss. Assumption: no interviewer profile was given, so weights follow the hiring-manager prior (Case/Strategist and Skeptic) adjusted by what you told me. The bank is sized for 45 minutes, so the two top personas split the depth.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems about two squads, hardware dates and product pressure | Most likely. Hiring-manager prior: they are buying judgment on their own roadmap | Clarify, objective, options, risks; think aloud; challenge one premise respectfully |
| Skeptic | Probes the gaps: scale, managers, hardware | Most likely. You named two gaps yourself (F1, F6), and a boss-to-be will test them | Rehearse the one predictable objection; use your own stated negatives as the opening words |
| Data-Driven Prober | Goes line by line through your figures | Likely. The 60% and the about 40 interviews are numbers (F2, F3) | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Conversational | Opens with "walk me through the journey" | Possible. A 45-minute boss round usually opens warm, and the opener is still scored | A 90-second arc built only from your own sentences |

### Question bank

**A. Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads. One launch date is fixed on the hardware side, and the other squad's on-call load keeps pulling engineers off planned work. You can protect one of them this month. How do you decide?" | CASE | [generic] | Clarify first: what the fixed date commits, what the on-call load is costing and who feels it. Then state the objective, the options, the criteria you would weigh, and what you would tell each squad and each partner. Think aloud, and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | Tests the delivery clause (F2) and the hardware partnership clause (F6) as a decision. CASE with JD content. `[generic]` because it is a role-family problem, not a fact about this employer |
| A2 | "You inherit two squads and eleven engineers you did not hire. What do you do in your first month, and what do you deliberately leave alone?" | CASE | [generic] | A plan in the future tense, no past. Whom you would listen to first, what you would want to see about delivery and on-call before changing anything, what you would ask the Director for, and one thing you would leave alone and why | Tests scale (F1) and growth (F4) as a plan, which is where the material is thin. CASE with JD content |
| A3 | "Product asks you for a date on a feature that depends on a hardware revision you have not seen. What do you say?" | CASE | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | If you want to name the limit first, use words you already gave: "I've never owned a hardware-adjacent roadmap." Then the plan, said as a plan: ask what is fixed and what can move, ask who owns the revision's schedule, give product a conditional answer instead of a date, and say when you would come back with a firm one. Nothing here claims you have done this | The likeliest live version of the hardware gap (F6) crossed with product pressure (F5). CASE with JD content |

**B. Skeptic**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Name the gap before they do, in words you already gave: "I've never owned a hardware-adjacent roadmap." Then a ramp plan, said as a plan: who in hardware you would sit with in your first weeks, what you would read, what you would ask the Director to introduce. Answer slot: if you have worked alongside hardware or firmware engineers in any way, say how, in your own words; if you have not, say so plainly and stay with the plan. Rehearse until it is boring, and never pad it with past work it does not carry | F6 is the biggest gap against the clause that makes this role different from a software EM role, and you named it yourself, so this objection arrives in some form. JD because it scores the stated requirement; Skeptic because it asks you to cross-examine yourself |
| B2 | "You have not managed managers before. If one of the squads has a lead who has been here longer than you have, how do you earn their trust?" | JD | [grounded] "I've never managed managers" | The limit in your own words: "I've never managed managers." Then the plan: what you would ask that lead first, what you would not change in week one, how you would hear their view before setting yours. Do not claim to have led leads. The posting does not say whether the squads have leads, so Reverse question RQ1.3 asks it directly | F1. The question's premise is a hypothetical about the squads, not a fact about them. JD because it scores the leadership clause |
| B3 | "Tell me about a time you helped an engineer grow into something bigger." | JD | [generic] | A selection scaffold. Pick one person (no name needed), one stake, and what you personally did, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would go about it. Your material shows no growth work (F4), so do not stretch another story to fit | F4 is the clause with no evidence, so this is the probe that finds it. JD because the growth clause raises it; open prompt, so it supplies no event |

**C. Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 60% drop in on-call burden was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say the sentence at its own scope: the burden dropped 60% after you pushed the quarter through. Then four answer slots, each in your own words: what was counted; what the figure is sensitive to; the assumption you would defend least; which part was yours. If you do not know how it was counted, say so plainly. Do not offer a counting method you cannot repeat under a second question | F2 is the headline metric on your background, and defend-the-number is where probers start |
| C2 | "Tell me about the reliability quarter: what was the roadmap pressure, and how did you handle it?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on the beats the sentence states: a reliability quarter, roadmap pressure, you pushed it through, the burden dropped 60% after. Tell those in your own words. Answer slot: the role's product-partnership line makes a probe on who applied the pressure and what was agreed likely. If a person or a trade-off stands out, say who or what, and your part; if there was no such person or trade-off, or it was not yours, say so plainly and stay with the quarter | F2 and F5. EXP because it tests what was actually yours. Your strongest story, and the likeliest follow-up target |

**D. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Three beats, the ones the sentence states: nine years in engineering, three of them as a team lead of six, now at a payments company. About 90 seconds, then stop and let them choose where to go. Answer slot: your reason for moving to this role, in your own words; nothing is supplied here | A casual opener that is still scored, and the sentence F1 rests on |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1.1 | "How is the working relationship between the two squads and hardware set up today, and where does it strain?" | It goes straight at the clause you are weakest on (F6) and gets you the real picture instead of the brochure one |
| RQ1.2 | "What would make you say in six months that this hire was the right one?" | It turns your own ramp plan (B1) into something measurable against what your boss actually wants |
| RQ1.3 | "Do the two squads each have a tech lead today, and who do they report to?" | It resolves the managing-managers question (F1) from the role itself instead of by guessing |
| RQ1.4 | "Where has roadmap pressure outweighed engineering health recently, and who decided?" | It is the same tension as your reliability quarter (F2), asked as curiosity about their decisions rather than as a story about yours |
| RQ1.5 | "How many of the eleven engineers were hired in the last year, and is headcount open?" | It shows you read the hiring clause as yours (F3) and tells you what the first year of hiring would look like |

## Round 2: Thursday, 60 min, panel (two staff engineers and a product manager)

### Persona weights

Panel rule: blend the top two personas of each member's relationship. Names were not given, so there is no per-member assignment. Assumption: the staff engineers sit alongside you as technical peers rather than reporting to you, and the product manager is a cross-functional partner. If the staff engineers would report to you, the Peer weight drops and the Values weight rises.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam-splitting, "what would you need from me", credit and disagreement | Most likely. Two of three panelists are technical peers pricing what you add to their work | Reciprocity framing; propose seam principles instead of pretending to know the seam |
| Data-Driven Prober | Goes into your figures and your hiring part | Likely. Staff engineers read numbers closely (F2, F3) | Know what you can and cannot say about each count; name the weakest assumption first |
| Values/Behavioral | Scenario prompts about disagreement and decisions, often from the PM | Likely. The PM is outside engineering, and the role partners with product (F5) | Stories that stay at your own sentences' scope; "we" for context, "I" for contribution |
| Conversational | Why this role, what you are exploring | Possible. A 60-minute panel usually has a warm stretch, and it is still scored | Own reasons in own words; nothing borrowed from a brochure |

### Question bank

**E. Peer Evaluator**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between you and a staff engineer on a technical call, and what happens when you disagree?" | JD | [generic] | Offer seam principles, not a seam you claim to know: who decides what, who must be heard before it, how a stalemate is escalated. Reciprocity: say what you would bring them, not only what you need. For the disagreement story use a selection scaffold: one equal, a named stake, what you actually said, an intact relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F1. Two staff engineers will test whether an EM respects the technical seam. JD because it scores the leadership clause |
| E2 | "What would you need from a staff engineer to make delivery work, and what would they get from you?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say your needs in your own words and offer one concrete thing in return. If the thing you offer is your hiring loop, say it as you said it: "I run our hiring loop for backend roles." Offer nothing your sentences do not carry | F2 and F3. Reciprocity is what a peer evaluator scores. JD because it scores the delivery clause |
| E3 | "Product wants a customer-visible feature this quarter. Two staff engineers tell you the platform needs reliability work first, and you are in the room with all three. What happens next?" | CASE | [generic] | Ask each of them what they lose by waiting and by going first, say what data you would want before deciding, then decide and say who you would tell and how. The question asks about no past, so the guidance makes none | F5 and F2 asked live, with the people who would be in the room. CASE with JD content. `[generic]` because it is a role-family problem |

**F. Data-Driven Prober**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Which assumption behind the 60% would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Name the assumption yourself, in your own words, before they do. The pack does not name one for you. If you do not know how the figure was counted, say so plainly. Hold the sentence at its own scope: the burden dropped 60% after you pushed the quarter through | F2, a second angle on the same figure as C1. Rehearse C1 and F1 together: staff engineers will go two levels deeper than the Director |
| F2 | "Walk me through your part in the hiring loop for backend roles." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Start from the sentence: you run the hiring loop for backend roles, and about 40 interviews is the count. Answer slot: if any part of how the loop works was yours to set, say which, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the sentence. If asked how the 40 was counted, say what it counted, and say plainly if you do not know | F3. The figure counts interviews, not hires, so the guidance never says hires |
| F3 | "Which parts of your engineering work at a payments company would you say transfer to device-management services, and which do not?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | Answer slot: if any of your work at the payments company resembles device-management services, say what, in your own words; if none does, say so plainly and say how you would get up to speed. A transfer claim you cannot back is exactly the one a staff engineer tests | F7. JD because it scores the domain clause; the posting's wording is the raising source |

**G. Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you and a product partner disagreed about what to build next." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on the sentence: a reliability quarter, roadmap pressure, you pushed it through, the burden dropped 60% after. The sentence says roadmap pressure, not that product applied it. Answer slot: if product was involved, say how it was worked through and what was agreed; if the pressure came from elsewhere, or no one disagreed, say so plainly and stay with the quarter | F5. The PM is likely to ask this in some form. VAL because it scores partnership behavior |
| G2 | "Tell me about a time you delivered a decision your team did not like." | VAL | [generic] | A selection scaffold. One named decision, what you actually said to the team, and how the relationship stood afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Your material does not show an instance (F2's sentence is about a reliability quarter, not a team's reaction to a decision) | F1 and F4. Panels use this to see how an EM communicates a hard call |

**H. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "What are you actually playing with in IoT or device management these days?" | JD | [generic] | Say what you have actually looked at, however small, in your own words. If you have not looked at any of it, say so plainly and say what you would look at first and why. Do not name tools or standards you have not used; research could not run to verify what is current here | F7. A casual question about the role's core domain, still scored |
| H2 | "What draws you to industrial IoT?" | JD | [generic] | Your own reason, in your own words. The pack supplies none, because a borrowed reason is the one that collapses on the second question | F7. Motivation consistency across a panel is checked quietly |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ2.1 | To the staff engineers: "What does a staff engineer need from an engineering manager that most do not get?" | Reciprocity, which is what a peer panel scores (F1) |
| RQ2.2 | To the product manager: "Where do you and engineering disagree most about priorities today, and how does it get resolved?" | It tests F5 from the partner's side and shows you ask before assuming |
| RQ2.3 | To the product manager: "How does the roadmap get shaped around hardware's dates, and who brings the constraint to you, and when?" | It is learning the hardware seam (F6) from someone who lives in it |
| RQ2.4 | To the staff engineers: "What is the biggest operational pain in these services right now?" | It signals that reliability is where you look first (F2) without claiming anything about this team |
| RQ2.5 | To the staff engineers: "What would you want the manager to take off your plate in the first month?" | A reciprocity question for peers, and it gives your ramp plan (B1) a first concrete target |

## Round 3: Monday, 30 min, VP Engineering ("values and leadership philosophy")

### Persona weights

The recruiter's description is the loop source for this round: it documents a values-style round. Skip-level prior: Case/Strategist and Pressure. The recruiter's words push Values/Behavioral to the top. Thirty minutes means about five or six questions get asked: if time is short, prioritize I1, J1, I2 and J2, then the reverse questions.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Philosophy", values, scenarios about judgment | Most likely. The recruiter named it as the round's purpose | Map each story to one of your own sentences; "we" for context, "I" for contribution; do not claim what the story proves |
| Pressure | Short time-boxed challenges to your gaps and your numbers | Likely. Skip-level prior, and the gaps you named are the natural target (F1, F6) | Pause, restate, hold the position through two follow-ups, concede only what is true and specific |
| Case/Strategist | Altitude questions about the org you would build | Likely. Skip-level prior, strategy-heavy | Outcomes before methods; ask what the company needs instead of claiming to know |
| Conversational | A warm closer | Possible | Own words, short |

### Question bank

**I. Values/Behavioral**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "What is your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | State it in one or two sentences, in your own words. Then one story that shows it, from your own sentence: a reliability quarter, roadmap pressure, you pushed it through, the burden dropped 60% after. Describe what you did and let the VP draw the inference; do not tell them what the story proves about you. If the philosophy you stated is one your stories cannot show, trim it to one they can | The recruiter named this round as values and leadership philosophy. F2 is the only story your material gives for it, so say how much it can carry |
| I2 | "Tell me about a time you stood by a decision while people were pushing the other way." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on the sentence's beats only. Answer slot: where the story needs who pushed back or what it cost you, say what you actually remember, in your own words; if there was no such moment, or it was not yours, say so plainly and stay with the sentence | F2. A values round tests whether a decision story held up under pressure, which is the sentence's own subject |
| I3 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | A selection scaffold. A named stake, the moment you said it, and that it landed and the relationship stayed intact. Your material does not show whether the reliability quarter's case reached leadership, so do not assume it did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2. Persona stem for values rounds. The honest branch matters more than a borrowed ending |
| I4 | "What do you look for when you hire for a team you lead?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Begin with the sentence at its scope: you run the hiring loop for backend roles. What you look for is your own answer, in your own words; the pack supplies no criteria. Stay with the loop you run and do not describe hires you have not described | F3. The hiring clause, asked as a philosophy |

**J. Pressure**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "Sixty seconds: why you, given you have never managed managers or owned a hardware-adjacent roadmap?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Hold-then-concede. Concede first, in your own words: "I've never managed managers" and "I've never owned a hardware-adjacent roadmap." Hold only what your sentences carry: a team lead of six for three years, a hiring loop you run, a reliability quarter you pushed through. Through two follow-ups, return to those sentences and add nothing to them. Say the ramp plan from B1 as a plan | The same objection as B1 at VP altitude and under time pressure (F1, F6) |
| J2 | "That 60%: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold the sentence at its scope: the burden dropped 60% after you pushed the quarter through. Answer slot: which part was yours, in your own words; if others did the engineering, or the figure moved for other reasons too, say so plainly. Concede that specifically instead of folding on the whole claim | F2. Persona stem for attribution probes. The sentence says "after", not "because" |

**K. Case/Strategist**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "What would you want to be true of these two squads in eighteen months, and what is the first thing you would change to get there?" | CASE | [generic] | Outcomes first, then the one change, then the trade-off it costs. Ask what the company needs from these squads instead of claiming to know it: research on Larkfield could not run, so stay with questions and your own reasoning, and claim no company facts. Two or three outcomes are enough in a half-hour round | F1 and F2 at the altitude a VP scores. CASE with JD content. `[generic]` because it is a role-family pattern |
| K2 | "One engineer on a squad is excellent technically but is wearing the team down. What do you do?" | CASE | [generic] | Ask what you would find out first, who you would talk to and in what order, what you would say to the engineer, what you would do if it does not change, and what you would tell the squad. Plan only, no past | F4. A people-judgment case that tests the growth clause without asking for a story you may not have |

**L. Conversational**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "What do you want engineers on your squads to say about you in two years?" | VAL | [generic] | Your own words, short, and tied to something you do, not a trait you claim. The pack supplies none | A warm values question that doubles as leadership philosophy (I1) |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ3.1 | "What does good look like for an engineering manager here, and where do new managers most often struggle?" | It asks for the bar directly, which matters for an EM moving up from a team of six (F1) |
| RQ3.2 | "How do you think about the balance between delivery commitments to hardware and engineering health?" | It puts your reliability story (F2) on the table as a question, not a claim |
| RQ3.3 | "Which of the company's values do you see tested most in an EM's week, and what does it look like?" | Research on the published values could not run, so this lets you ask instead of guess |
| RQ3.4 | "How are engineering managers here expected to grow, and who looks after the managers?" | It shows how you would close the managing-managers gap (F1) |
| RQ3.5 | "What did you learn about leadership early in your own first management role?" | A peer-to-peer question that invites the VP's own story |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| Lead two squads (scale and leadership), F1 | A2, B2, E1, J1, K1 |
| Device-management domain, F7 | F3, H1, H2 |
| Delivery, F2 | A1, A2, C2, E2, E3, K1 |
| Hiring, F3 | E2, F2, I4 |
| Growth, F4 | A2, B3, G2, K2 |
| Partner with product, F5 | A3, C2, E3, G1 |
| Partner with hardware, F6 | A1, A3, B1, J1 |
| Headline figure: the 60%, defend-the-number | C1, F1, J2 |
| Figure: about 40 interviews, defend-the-number | F2 |

## Prohibited claims

Built from the fit snapshot before the banks. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed managers, or led an org of leads | Negative you stated, F1 | The plain acknowledgment you gave: "I've never managed managers." No slot |
| Owned or shaped a hardware-adjacent roadmap | Negative you stated, F6 | The plain acknowledgment you gave: "I've never owned a hardware-adjacent roadmap." No slot |
| Managed six direct reports, or was the manager of a team of six | Inflated form of F1 | F1's quote at its own scope: "3 as a team lead of 6". The limit is the pack's observation: the material says team lead of 6, not that six reported to you |
| Owned or set the product or hardware roadmap | Inflated form of F2 and F5 | F2's quote at its own scope. The limit is the pack's observation: the material says you pushed a reliability quarter through against roadmap pressure, not that you set the roadmap |
| Cut on-call burden by 60% through your own work, or led the reliability work | Inflated form of F2 | The quote's own sequence: the burden dropped 60% after you pushed the quarter through. The limit is the pack's observation: the material says "after", not "because", and not who did the engineering |
| Hired about 40 people, or owns hiring across engineering | Inflated form of F3 | F3's quote at its own scope: you run the hiring loop for backend roles, and the 40 counts interviews |

## Sources

Provided documents: your message (the role description, the three rounds and who runs each, and your background).

Searches sent, all refused (permission to search was not granted), so nothing came back from any of them:

- "Larkfield Systems industrial IoT company values" — refused
- "Larkfield Systems interview process engineering manager" — refused
- "Larkfield Systems industrial IoT device management strategy news" — refused
- "Engineering Manager job description industrial IoT device management platform two squads" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Would have moved the values cheat sheet (dropped) and Round 3's VAL themes, which now rest on the recruiter's description |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Would have checked case formats or a dedicated values round. The loop itself rests on your own words, which name each round and who runs it, so the persona weights stand |
| 3. `Larkfield Systems strategy` / recent news | unavailable | Would have moved the CO bank, which is absent, and made K1 company-specific. K1 is generic |
| 4. `interviewer name Larkfield Systems` | n/a | No interviewer name was given, only titles, so there was no query to form. The interviewer read is absent |
| 5. representative `Engineering Manager` JD | unavailable | Would have added inferred requirement rows beyond the three clauses you pasted; the fit snapshot rests on those three only |

## Upgrade menu

- Full job description text → the three clause-level rows widen to every stated requirement, and more questions become `[grounded]`
- Your CV → evidence cells for F4, F6 and F7 may fill, and the transferability rows (F1, F2, F5) may upgrade or close
- Answers to the answer slots on F1, F2, F4, F5 and F7, said or typed outside a drill → those rows regenerate with your own sentences as evidence
- Interviewer names or public profiles for the Director, the two staff engineers, the product manager and the VP → an interviewer read, per-member persona assignment for the panel, and reverse questions tied to each person's own path
- Larkfield's published values page, pasted → the values cheat sheet returns, mapped to your stories, for Round 3
- The recruiter's guidance on the panel's format and on what the VP means by values and leadership philosophy → coverage of any announced exercise, and tighter persona weights
- Search access for a research pass: up to 6 searches and 2 fetches at the default tier, and a deeper pass of up to 6 further searches and 2 further fetches that takes several more minutes → values, loop structure and strategy come from sources, a CO bank appears, and generic labels become grounded where the sources support them
- A `tuesday-dossier.md` from an earlier fit assessment of this role, if you have one → verified evidence and absolute prohibited claims arrive in place of the ones built here
