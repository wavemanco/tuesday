Web search was refused, so I'm building the pack from your JD and background alone. I'm writing it to a file now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-7-denied-a7e62166/saltmarsh-games_live-operations-producer_interview_pack.md`. I built it for a hiring-manager-level round, since you didn't say how Tobias relates to the role. Web search was refused in this session, so nothing in it comes from outside your JD and your message. That means no company research and no read on Tobias himself.

- **Biggest rehearsal target:** B1, the in-app-purchase gap you named. No wording closes it, so the prep is a calm, repeated honest answer plus a learning plan. B2 is the runner-up: the JD asks for 3+ years of live-service work and your material shows two years of the weekly calendar.
- **Strongest quote:** "Wrote the release checklist our QA team still uses" fits the JD's QA checklist line closely. The JD says "manage", though, so the pack keeps you to "wrote".
- **Gaps to check:** the post-event review and KPI ownership, coordinating the four teams, and a second title are open. Each has an answer slot for you to fill from your real experience, or to say plainly it wasn't yours.
- **What the pack won't coach:** claims like "four years of live-service" or "owned the KPIs", which go past what you told me. They're listed in the prohibited-claims section.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to if hired, or someone senior to the hiring manager? The answer reweights every bank.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. **Round:** 60 minutes, Friday. **Relationship:** assumed hiring-manager level (the person who owns the function the role sits in); your note did not confirm it. Studio: mobile games, about 350 people, per your message.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words. An answer slot is an instruction for the interview, not a question for me.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values (no rows here: no published values were available) |
| EXP | Whether your claims survive scrutiny, and what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem from the role |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says a weekly content-drop calendar for the main title, not events and not a second title, and the words stay there: "For the last two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD's "two of our mobile titles" and "live-events" make two probes likely. If you ran more than one calendar at a time, or any drop was a time-limited event, say which and how, in your own words; if not, say so plainly and stay with the main title's weekly calendar |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show this one either way. Answer slot: if you coordinated any of design, art, engineering or community on a drop, say which and what part was yours, in your own words; if the calendar did not involve coordinating them, or some of it was not yours, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | low | [inferred] | discovery | Presenting numbers is not owning a review or its KPIs, and the bridge should not be stretched: "I presented the monthly retention numbers to the studio head." Answer slot: if you reviewed any release after it shipped, or chose which figures were reported, say what and how, in your own words; if the numbers or reviews were not yours, say so plainly and stay with presenting |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Say it as written: "I wrote the release checklist our QA team still uses." Your material says wrote, not managed each release, so expect a probe on that and say no more than the quote does |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material says four years as an associate producer and two years of the weekly calendar; it does not say how many of the four were on a game in live service. Answer slot: the JD's "3+ years producing live-service games or apps" makes a count likely. Say which years were on a live game, in your own words; if only the last two were, say so plainly and describe those two |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: you ran it, weekly, for the main title, for two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Say it as written: "I presented the monthly retention numbers to the studio head." It names no figure and no method, so expect a probe on how the numbers were counted (C1) and say only what you know |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | A written document your QA team still uses touches the requirement without showing clarity. Answer slot: if you can point to anything else you wrote for readers, say which; if not, say so plainly and stay with the checklist |
| F9 | Not in the JD: working on games that sell in-app purchases (the gap you named) | "never worked on a game with in-app purchases" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked on a game with in-app purchases." Then how you would learn it, said as a plan and never as a past. Never a claim to purchase-related work, and nothing added to make the gap feel smaller |
| F10 | Not in the JD: leading a team (the gap you named) | "Never led a team" — your message | none | [grounded] | capability | The JD says "coordinate", not lead, but the gap is yours and stated. Words: "I haven't led a team." Then how you would get work moved without authority, said as a plan and never as a past |

## Persona table

Weights rest on a relationship prior (hiring-manager level, assumed) and the generic loop archetype. No loop source for Saltmarsh was available, so they do not reflect a documented process. The only interviewer signal is the title you gave me.

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems from the job: plan this, slip that, diagnose this number | Highest. The hiring-manager prior favors it, and the JD is mostly planning and running work | Clarify, objective, segments, approach, metrics, risks; think aloud; challenge one premise politely |
| B. Skeptic | Quiet probing of the gaps: scope, years, in-app purchases, team leadership | Highest. The hiring-manager prior favors it, and F5, F9 and F10 are open | Rehearse the top objection until it is boring; bridge only from what your quotes say; give a concrete ramp plan |
| C. Data-Driven Prober | Retention and KPI questions two levels deep | Medium. The JD names player-retention metrics and KPIs, but nothing signals this interviewer's style | Say how each number was counted, or say plainly you do not know; name the assumption you would defend least |
| D. Conversational | Biography, what you play, a casual writing question | Medium. Most interviews open this way and nothing in the material rules it out | A 90-second arc; treat casual questions about live-ops topics as scored |
| E. Peer Evaluator | Seam-splitting between disciplines, credit and disagreement | Low. A Head of Live Operations is not assumed to be a peer, but the JD is all cross-team coordination | Propose principles for the seam, not a pretended map of it; offer what you bring the other team |
| F. Pressure | Time-boxed, interrupting, "how much was you" | Low. Nothing in the material signals it | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

Highest-ROI prep in this pack: **B1**. It is the one gap you stated outright that no wording can close, so rehearsal is the only lever. B2 is the runner-up.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You take over the live-events calendar for two titles on Monday. What do you need to know first, and what do your first two weeks look like?" | CASE | [generic] | Clarify first: what each title's cadence is, how events are reviewed today, who signs off on a date. Then objective, what you would not change yet, and one metric you would watch. The question needs no claim about your past, so the guidance makes none | JD content, CASE delivery: the JD's first duty, asked as a decision. F1 is where the scope step-up sits |
| A2 | "An update is due Thursday. On Tuesday engineering says a feature slips two days; art and community have already committed. What do you do?" | CASE | [generic] | Structure it: what exactly slips and whether it can be cut; options (hold the date with less, move the date, ship the feature later); who decides and who is told; what community hears and when; where QA's checklist sits in the new plan. No claim about your past | Tests F2 and F4 as decisions, not records. CASE because it is a live problem |
| A3 | "The weekend event's day-7 retention came in well under what the team expected. How do you review it?" | CASE | [generic] | Clarify the definition and the comparison baseline; split new from returning players; ask whether it was the event or something else that week; compare with earlier events; say what you would report and what you would refuse to conclude yet. No claim about your past | JD content (F3, F7), CASE delivery. A review is the thing the role owns |
| A4 | "Which of our two titles have you played, and what did you notice about how their live events run?" | CO | [generic] | Say only what you actually saw. If you have played one or both, say what you noticed in the events, in your own words; if you have not, say so plainly and say what you would look at first in each. Do not correct anything they tell you | Homework check with no company research behind it, so `[generic]`: the pack knows neither title's name. The upgrade menu says what the names would add |
| A5 | "Walk me through how you ran the weekly content-drop calendar for your main title." | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Story-mapped on F1: the weekly calendar, the main title and the two years are the beats the quote states; tell them in your own words. Answer slot: the JD's "two of our mobile titles" and "live-events" make two probes likely. If you ran more than one calendar at once, or any drop was a time-limited event, say which and how; if not, say so plainly and stay with the weekly calendar for the main title | F1 and F6 are the evidence for the headline duty and the likeliest place to be probed. EXP because it tests what was actually yours |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see in-app purchases in your background. How would you approach live events on a mobile title that sells them?" | EXP | [grounded] "never worked on a game with in-app purchases" | The deepest rehearsal here. Hold: "I haven't worked on a game with in-app purchases." Then a plan, said as a plan: you would spend early weeks with whoever owns the offers and learn how events and offers connect; you would not describe anything as past. Follow-up 1, "so how would you start?": the plan again. Follow-up 2, "what would you do about it in the first month?": the same learning plan with one concrete first step. Follow-up 3, "would you own an event with purchase offers on day one?": say what you would want in place first. Concede only what the acknowledgment says; never offer a nearby experience to soften it | F9 is a stated capability gap, so wording cannot close it. This is the highest-ROI prep because no framing exists for it, only a calm, repeated honest answer. EXP because it tests candor about what was done |
| B2 | "This role asks for three or more years producing live-service games. How much of your four years was that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | Say the four years as the quote states them. Answer slot: the JD's "3+ years producing live-service games or apps" raises the count. Say which of the four years were on a game in live service; if only the last two were, say so plainly and describe those two. Hold through two follow-ups by returning to what the quotes carry, never by widening a year | F5 is the JD's own number against your material. JD because it scores the stated requirement. The runner-up objection |
| B3 | "You would own the post-event review and its KPIs. What part of a review have you owned yourself?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | The hold is only what the quote carries: "I presented the monthly retention numbers to the studio head." Answer slot: the JD's "own the post-event review and the KPIs it reports" raises the probe. If you reviewed any release after it shipped, or chose which figures were reported, say what and how, in your own words; if the numbers or reviews were not yours, say so plainly and describe how you presented them. Hold through two follow-ups by returning to the presenting, never by adding to it | F3 is where the JD's ownership language presses hardest on thin evidence |
| B4 | "I don't see leading a team in your background. This role coordinates design, art, engineering and community on each update. How would you get a senior engineer to move?" | EXP | [grounded] "Never led a team" | Hold: "I haven't led a team." Then the method, as a plan: agree the outcome, show what the date costs, name who decides, escalate early rather than late. Answer slot: the JD's "coordinate design, art, engineering and community teams on each update" raises the probe. If you have gotten colleagues in other disciplines to hit a date, say what the situation was and what part was yours, in your own words; if you have not, say so plainly and answer as a plan | F10 and F2: a stated gap meeting an open requirement. EXP because it tests what was actually yours |
| B5 | "Why this role, and why now?" | JD | [generic] | A selection scaffold, not a story: say in your own words what draws you to running live events; name one concrete thing from your own work that made you want it. If no such thing comes to mind, say so plainly, then say what you hope to learn in the role. Keep it short | Skeptic stem on motivation consistency. No quote carries a reason, so the pack supplies none |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot, four parts, each in your own words: how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours (collecting, calculating or presenting). If you do not know how it was counted, say so plainly and say what you would check. Never name a method you did not use | F7 and F3. The figure is where a prober starts, and the pack names no method because your quote names none |
| C2 | "A retention number drops week over week after a drop. What do you check before you tell anyone it was the content?" | CASE | [generic] | Definition or tracking changes; mix of new and returning players; day of week and season; a release problem; comparison with earlier drops. Then what you would say, with what confidence, and what you would refuse to claim yet. No claim about your past | JD content (F7) as a live problem. Gives the prober a case instead of a CV line |
| C3 | "Walk me through the release checklist you wrote for QA." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Story-mapped on F4: you wrote it, and your QA team still uses it; tell those beats in your own words. Answer slot: the JD's "manage the release checklist with QA" raises the probe. If you also ran each release through it with QA, or changed it after a release, say how; if QA ran it once you had written it, say so plainly and stay with the checklist you wrote | F4 is the pack's strongest quote, and the JD's wording ("manage") is wider than it |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey: how did you get to producing, and what has brought you to live ops?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | A 90-second arc with the beats the quotes state: four years as an associate producer at a puzzle-game studio; then the weekly calendar for the main title for two years. Answer slot for the last beat: say in your own words what draws you to live ops; if no specific reason comes to mind, say so plainly | F5 and F6 as a story. Conversational openers are scored, and an unplanned one rambles |
| D2 | "What are you actually playing and following in mobile live ops these days?" | CO | [generic] | Name only what you actually play or follow. If nothing comes to mind, say so plainly and say which two titles you will look at first. Do not invent a habit | Persona stem on a hot JD topic. `[generic]` because the pack has no research on this studio's titles |
| D3 | "The role asks for clear written communication. What makes a one-page update brief clear, and what have you written that shows it?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Say what you think makes a brief clear in your own method: who reads it, what they need to act on, the date, the owner, the risk. Answer slot: the JD's "clear written communication" raises a probe for something to point to. If you can show anything you wrote, say which; if not, say so plainly and stay with the checklist you wrote | F8 is the only row that rests on a document you wrote, and the JD's requirement has no other question |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time an update involved several disciplines and something went wrong. What was your part?" | EXP | [generic] | A selection scaffold: pick a drop where more than one discipline was involved and one thing did not go as planned. It needs a named stake, what you did and what you would change. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or say how you would handle it | Open prompt, themed by the JD's coordination line (F2). No quote carries a story for it, so the pack supplies none |
| E2 | "Design wants a bigger event, engineering says the calendar is too dense. Where is the seam, and who decides?" | CASE | [generic] | Propose principles for the seam, not a pretended map of it: who owns what, what data you would bring, the escalation path. Add what you offer the other team, such as a single view of the calendar and early notice of conflicts. No claim about your past | JD content (F2) as a live problem. Collegial packaging of a skeptic's objection |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a candidate who has already run live events on a title that sells in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "never worked on a game with in-app purchases" | Pause and restate. Hold on the three quotes at their own scope, in order. Concede specifically: "I haven't worked on a game with in-app purchases." Close on what you would do in the first month, said as a plan. Do not claim you learn faster or know the fit better | F9 against F1, F4 and F7. JD because it scores fit to the job. Practice for composure |
| F2 | "That retention presentation: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold: "I presented the monthly retention numbers to the studio head." Answer slot: say which of collecting, calculating and interpreting the numbers were yours; if any were not, say so plainly, and concede that specifically. Do not fold on the core claim just to restore harmony | F7 and F3. The attribution probe exists to catch inflation, so the rehearsal is candor |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A1, A4, A5 |
| "coordinate design, art, engineering and community teams on each update" | A2, B4, E1, E2 |
| "own the post-event review and the KPIs it reports" | A3, B3, C1, F2 |
| "manage the release checklist with QA" | A2, C3 |
| "3+ years producing live-service games or apps" | B2, D1, F1 |
| "experience running a content calendar" | A5, D1 |
| "comfortable with player-retention metrics" | A3, C1, C2 |
| "clear written communication" | D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Do the two titles share one live-events calendar, or two, and who settles a conflict between them?" | The JD puts two titles on one producer (F1); asking shows you are thinking about scope, not only content |
| R2 | "What does a good post-event review look like here, and which KPIs carry the most weight?" | The JD says the role owns the review and its KPIs (F3); the answer tells you what you would be measured on |
| R3 | "Where does the release process with QA run smoothly today, and where do updates still slip?" | Signals you care about the release path (F4), and surfaces the real pain point before you accept |
| R4 | "How do design, art, engineering and community each hear about an update's date, and who can move it?" | Tests how coordination works without a line manager (F2, F10) and is the question you would need answered to do the job |
| R5 | "How do events on each title connect to its in-app purchases, and who owns that link?" | Turns the gap you named (F9) into curiosity about how the studio works, and answers something you need to know before accepting |
| R6 | "What would you want the person in this role to have changed or improved by the end of six months?" | Moves the conversation to outcomes and gives you the success bar |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Four years producing live-service games | Inflated form of F5 | F5's quotes at their own scope. The limit is the pack's observation: your material says four years as an associate producer and two years of the weekly calendar, not that all four were live service. B2's slot stays inside the quotes |
| Managed the release process with QA | Inflated form of F4 | "I wrote the release checklist our QA team still uses." The material says wrote, not managed each release. C3's slot stays inside the checklist |
| Owned the post-event review and its KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." The material says presented, not owned. B3's slot stays inside the presenting |
| Ran the live-events calendar across two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title." The material says content drops for the main title, not events and not a second title. A5's slot stays inside the main title |
| Led a team | Negative you stated, F10: "Never led a team" — your message | The plain acknowledgment F10 gives: "I haven't led a team." No slot |
| Worked on a game with in-app purchases | Negative you stated, F9: "never worked on a game with in-app purchases" — your message | The plain acknowledgment F9 gives: "I haven't worked on a game with in-app purchases." No slot |

## Sources

Provided documents: the JD pasted in your message, and the background in your message. No dossier was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | Search refused by the host. Would have fed a values cheat sheet if a values round were documented; none is detected |
| 2. `Saltmarsh Games interview process live operations producer` | unavailable | Search refused. Would have replaced the generic archetype in the persona weights with a documented loop |
| 3. `Saltmarsh Games mobile studio news strategy` | unavailable | Search refused. Would have turned A4 and D2 from `[generic]` toward current strategy |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | Search refused. Would have supplied an interviewer read and a reverse question tied to his path |
| 5. representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

Queries sent, all refused: `Saltmarsh Games values`; `Saltmarsh Games interview process live operations producer`; `Saltmarsh Games mobile studio news strategy`; `Tobias Wrenfield Saltmarsh Games`.

## Upgrade menu

- Permission to run web search → the four targets above re-run: persona weights from a documented loop, an interviewer read and a reverse question tied to Tobias Wrenfield's path, and A4 and D2 moving from `[generic]` to current company context. A deeper pass (up to 6 more searches and 2 more fetches, several more minutes) would add a strategy brief and his public talks or writing
- Whether Tobias is your future manager or someone senior to the hiring manager → reweights every bank
- The recruiter's prep note (format, any pre-set exercise or deliverable) → a build section for any declared deliverable; usually one email
- The names of the two titles → A4 and D2 gain specifics you can check before Friday
- The lines on your CV → F1 to F8 would quote your CV's own sentences, not a single message
- Your own answers to the answer slots (F1, F2, F3, F5, F8) → those rows move from `discovery` or `transferability` toward `presentation`
- A `tuesday-dossier.md` → verified evidence and a named top objection, if you have one
