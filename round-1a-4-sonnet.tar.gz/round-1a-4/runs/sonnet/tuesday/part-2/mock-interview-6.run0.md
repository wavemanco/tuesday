Search wasn't permitted, so I'm building the three-round pack from your message alone and saving it.
Your prep pack for all three rounds is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-6-denied-a9d76678/larkfield-systems_engineering-manager_interview_pack.md`.

Web search was refused, so the pack has no company research. It rests on your message alone, which means:
- **No company facts:** the company questions (R3B1, R3A1) are generic, and there is no values cheat sheet for the Monday round.
- **No interviewer read:** I had no names.
- **Persona weights:** they come from each round's stated role and the recruiter's wording.

It holds one shared fit snapshot, then a question bank and reverse questions for each round (26 questions in all). It also has a list of claims it won't coach and a prep triage. The triage orders your prep by round.

The objection to rehearse most is R1B1, "Which part of this role would you be weakest at on day one?" You said you've never owned a hardware-adjacent roadmap. Expect that gap to come back in all three rounds, in the panel's Sixty-second question (R2F1) and the VP's planning question (R3A1).

Say the word and I'll run a live drill: I'd play the Director's Skeptic on R1B1. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two things would change the pack:
1. Can you paste the posting text and your CV? The rows currently rest on your message alone, and the posting would also settle whether the squads have leads.
2. Did the recruiter say anything about what the Director and the panel will cover, or ask you to prepare something in advance? That would reweight the banks.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Interview prep pack: Engineering Manager, Larkfield Systems (three-round loop)

Candidate: Yusuf. Mode: loop, three scheduled rounds, one shared fit snapshot, a mini-pack per round.

| Round | Who | Length | Relationship |
|---|---|---|---|
| 1. Tuesday | Director of Engineering | 45 min | Hiring manager, your would-be boss |
| 2. The Thursday after | Two staff engineers and a product manager | 60 min | Panel |
| 3. The following Monday | VP Engineering | 30 min | Skip-level, described by the recruiter as "values and leadership philosophy" |

Built on these assumptions: no posting text or CV was supplied, so the role comes from your message and the fit snapshot rests on your message alone. No names were given, so there is no interviewer read. Panel members are weighted by their stated roles only.

## How to use this pack

Personas are how a question arrives; types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did. Question IDs read round, persona letter, number (R1B1 is round 1, Skeptic, question 1).

Persona letters: A Case/Strategist, B Skeptic, C Data-Driven Prober, D Peer Evaluator, E Values/Behavioral, F Pressure, G Conversational.

Type key: VAL is values alignment, EXP is a deep-dive on your experience, JD is the role's stated responsibilities, CO is company and strategy knowledge, CASE is a live problem.

An answer slot is an instruction for the interview, not a question for you now.

## Prep triage

1. Before Tuesday: rehearse R1B1 until it is boring (the highest-ROI prep in this pack), then R1C1 and R1G1.
2. Then say R1A1 to R1A4 aloud once each, clarifying before structuring.
3. Before Thursday: R2F1, R2C1 and R2C2 (their answer slots), then R2D1.
4. Before Monday: R3E1, R3E2, R3F2 and R3B1. Use what the first two rounds taught you in R3B1.

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

The role text below is your own description of the role in your message, not a posting.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role as you described it | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says a team lead of six for three years; the role says two squads and "11 engineers". The words stay at the quote: nine years in engineering, three of them as a team lead of six. Answer slot: the two-squad scope makes a probe on scaling likely. If you have coordinated work across more than one team, say how and which part was yours, in your own words; if you have not, say so plainly and stay with the team of six |
| F2 | "own delivery" — role as you described it | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | transferability | The sentence says you pushed a reliability quarter through and that the burden dropped after it; it does not say you owned delivery across squads, and the words stay at that scope. Answer slots for the figure: how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly |
| F3 | "hiring" — role as you described it | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | No gap, but a message line with nothing inspected behind it, so expect a probe. Lead with the loop in the quote's own terms: you run it, for backend roles. The pack's observation: the sentence does not say whether the 40 interviews were yours or the loop's total, so R2C1 holds an answer slot on it |
| F4 | "growth for 11 engineers" — role as you described it | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the role names growth, so expect a probe. If you have helped anyone on a team grow, say who and what you did, in your own words; if you have not, or it was not yours, say so plainly and say how you would approach it |
| F5 | "partner with hardware and product on roadmap" — role as you described it | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | Your own words stand: "I have never owned a hardware-adjacent roadmap." The pack's observation: the role says partner, your sentence says owned, and your material is silent on whether you have worked alongside hardware at all. Answer slot: if you have worked with hardware or product on dates or scope, say what and which part was yours; if not, say so plainly and return to the sentence above. This is the objection the loop is most likely to press |
| F6 | "building device-management services" — role as you described it | "currently at a payments company" — your message | low | [grounded] | discovery | The quote shows your current sector and nothing about devices. Answer slot: if any of your work touched devices or the services that manage them, say what and which part was yours; if none did, say so plainly and stay with the payments company you are at now |

Requirement coverage, mapping each stated requirement to the questions that cover it:

| Requirement | Questions |
|---|---|
| F1 lead two squads | R1A3, R1B2, R3F2 |
| F2 own delivery | R1A1, R1C1, R2D4, R3A2, R3F1 |
| F3 hiring | R2C1 |
| F4 growth for 11 engineers | R3E2 |
| F5 partner with hardware and product | R1A4, R1B1, R2D1, R2D3, R2F1, R3A1 |
| F6 device-management services | R1A2, R1B3, R2G1 |
| "values and leadership philosophy" (the recruiter's words, round 3) | R2D2, R2E1, R3E1, R3E3 |
| Company knowledge (no research ran, so generic) | R3B1, R3A1 |

## Round 1: Tuesday, Director of Engineering (45 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems from the actual role: plan this, diagnose that | High. The hiring-manager row of the persona priors puts it first, and the role sits between hardware and product | Clarify first, then objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet probing of the gaps | High. F5 and F6 are open and the director is the person who has to cover them | Rehearse the single most predictable objection until it is boring; calibrated candor over bluffing |
| Data-Driven Prober (C) | Reads claims line by line | Medium. One headline figure in your material | Know what you can and cannot say about how the figure was counted; say plainly when you do not know |
| Conversational (G) | The opening biography question | Low to medium. A 45-minute round usually opens with one | A 90-second arc built only from what you have said, then your own reason |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never owned a hardware-adjacent roadmap" | The highest-ROI rehearsal in this pack. Three beats, each short. First, the plain acknowledgment in your own words: "I have never owned a hardware-adjacent roadmap." Second, answer slot: if anything in your work brought you alongside hardware or product on dates or scope, say what and which part was yours; if not, say so plainly and say nothing more about it. Third, a plan, said as a plan and never as a past: pick two or three first-month actions you would genuinely take, such as who you would sit with and what dates you would ask to see. Hold your tone through a follow-up; the honest limit is not a confession | F5 is the row the loop presses hardest, so this objection arrives in some form in all three rounds; JD because it scores the stated requirement, Skeptic because it asks you to price your own gap |
| R1B2 | "You have led a team of six. This role is two squads and eleven engineers. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" | Say the quote at its scope: three years as a team lead of six. Answer slot: if you can say what changes for you at eleven people across two squads, say it in your own words; if you have not thought it through, say so plainly and say what you would find out first. The pack supplies no list of what changes | F1 is the evidence and the scale step is the likeliest probe of it; JD because the numbers come from the role |
| R1B3 | "Why industrial IoT, and why leave payments?" | EXP | [grounded] "currently at a payments company" | Your reason is yours alone and the pack supplies none. Give your own reason for moving, and your own reason for this role, in one sentence each, true and not disparaging of where you are now. Answer slot: if your reason is partly about wanting to work closer to hardware, say that plainly, and let the interviewer see you know it is new to you | F6 is the motivation gap a hiring manager checks first; EXP for the reason for leaving, with the JD angle in the second half |
| R1A1 | "Hardware ships a new device generation in two quarters and your squads' services have to support it. Product wants two new features in the same window. How do you plan the quarter?" | CASE | [generic] | Clarify first: what is fixed on hardware's date and what is soft; what supporting the new generation means for the services; what the two features depend on. Then objective, segments (must ship for hardware, product asks, reliability), an approach, metrics and risks. Say the trade-off aloud and challenge one premise, that both land in the same window. The question needs no claim about your past | Tests the hardware-product-engineering seam that F5 and F2 turn on; CASE because it is a live problem. A pattern for the problem, not a fact about this employer |
| R1A2 | "A firmware update rolled out to a fleet of field devices leaves a fraction of them unreachable. What do you do in the first hour?" | CASE | [generic] | Clarify scope first: which devices, which versions, how many. Then stop the spread, check whether a rollback is possible, bring in hardware and support, and decide who communicates what. Say plainly which parts you would lean on others for. It needs no claim about your past, and bluffing domain depth is the failure here | Probes F6 without presupposing experience; CASE because it is a diagnose-and-act problem. A pattern, not a fact about this employer |
| R1A3 | "In your first month, how would you decide how to split the work between two squads of eleven engineers, and what would you need to know first?" | CASE | [generic] | Clarify what each squad owns today, what is in flight, and who currently holds technical direction. Then principles you actually hold, for example listening before reorganising; say they are your principles, not facts about Larkfield. Challenge one premise, that the split should change in the first month | F1 from the role's own scope; CASE because it asks for structure, not history |
| R1A4 | "What would you want to know about the hardware roadmap before committing your squads to a date?" | CASE | [generic] | Ask what hardware's dates are anchored on, which of them are fixed and which can move, and who decides when they move. Propose seam principles, such as one agreed calendar and a named owner for each interface, rather than pretending to know where the seam is. The question asks what you would need to know, which needs no claim about your past | F5 in a form that rewards honest curiosity; CASE because it asks for a method |
| R1C1 | "Your on-call burden dropped 60%. Walk me through how that number was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Defend the number at the quote's scope, in your own words. Answer slots: how it was counted; what it is sensitive to; the assumption behind it you would defend least, named before the interviewer does; which part was yours. If you do not know how it was counted, say so plainly. The pack's observation: the sentence says dropped after, and says pushed, so stay with those words unless you can show more | F2 is the evidence and the only figure in your material, so a prober goes to it; EXP because it tests attribution and the weakest-assumption move |
| R1G1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" "currently at a payments company" | A 90-second arc from those sentences only: nine years in engineering, three of them as a team lead of six, currently at a payments company. Then your own reason for this role, in your own words; the pack supplies none. Answer slot: if you want to add one thing you did, choose one and say it only as far as it was true | F1 and F6 as the spine of the opener; EXP because it is the biography question, and casual openers are still scored |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would success look like for these two squads at six months, and what would you want me to have changed by then?" | It converts the first months into agreed measures you can be held to |
| 2 | "Where does the squads' roadmap meet hardware's today, and where does it get argued?" | It turns F5 into curiosity about the real seam |
| 3 | "Of the eleven engineers, who is ready for more, and who needs support?" | It shows you take the growth part of the role seriously |
| 4 | "Is this a new role or a replacement, and what did that teach you about what the role needs?" | It tells you what problem you are being hired to solve |
| 5 | "How do you and the VP of Engineering describe the leadership bar for this role?" | It previews round 3 and shows you are thinking past this conversation |

## Round 2: the Thursday after, panel of two staff engineers and a product manager (60 min)

### Persona weights

Panel members are weighted by stated role only; no names or profiles were given. Staff engineers are assumed to be technical peers pricing what an EM costs and adds to their work; the product manager is assumed to be a cross-functional peer.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator (D) | Seam-splitting, credit, what you would need from them | High. The panel blends the top personas of each member, and peer is the common one | Reciprocity framing: what you bring them, not only what you need; propose seam principles rather than pretending to know the seam |
| Data-Driven Prober (C) | Reads claims for depth and checks how they were counted | Medium. Staff engineers are the likeliest to dig into a number or a hands-on claim | Know what you can and cannot say; say plainly when you do not know |
| Conversational (G) | A friendly question that is still scored | Low to medium. The PM is a likely source | Treat casual questions on hot topics as scored |
| Values/Behavioral (E) | A scenario question from outside engineering | Low to medium. A cross-functional member often asks one | Choose a story where the hard truth landed, or say none comes to mind |
| Pressure (F) | A time-boxed challenge | Low. One member may press | Hold your position through two follow-ups, then concede specifically |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2D1 | "Where is the seam between what a staff engineer decides and what the EM decides, and what happens when you disagree?" | JD | [generic] | Propose principles you actually hold rather than claiming to know this team's seam: for example who owns priorities and people, who owns technical direction, and how a disagreement is written down and resolved. Add what you bring them, not only what you want. The question needs no claim about your past | The core peer question for a manager joining senior engineers; JD because it scores the role's delivery ownership (F2). A pattern, not a fact about this team |
| R2D2 | "How do you handle credit when work spans teams?" | VAL | [generic] | State your own practice, truthfully. If you have an example, name the stake and how it ended in your own words; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer-collaboration probe, and the recruiter's words put values on this loop; VAL because it scores how you treat others' work |
| R2D3 | "What would you need from the staff engineers in your first month, and what could you do for them?" | JD | [generic] | Reciprocity first: name what you would take off their plate, then what you would ask of them. Be honest that you would lean on them for the hardware-adjacent seam, in your own words. No claim about your past is needed | F5 turned into a partnership; JD because it scores partnering |
| R2D4 | "The PM wants a date and the staff engineers say the estimate is soft. You are in the middle. Walk us through it." | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure it: clarify what is uncertain, make the uncertainty explicit, offer options such as date versus scope, name who decides. If you reach for your own example, the only sentence your material has near this is the quote, and it says roadmap pressure and nothing about who applied it or how it ended; tell it at that scope and answer follow-ups only from what happened | F2 is the nearest evidence for delivery under pressure; CASE because it is a live scenario |
| R2C1 | "You run the hiring loop for backend roles. What is your part in it, and how was the figure of 40 interviews counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Say the sentence at its scope: you run the loop, for backend roles. Answer slots: the pack's observation is that the sentence does not say whether the 40 were interviews you conducted or the loop's total, so say which, in your own words. Then how it was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. If you do not know how it was counted, say so plainly | F3 is evidence that reaches the requirement but has nothing inspected behind it; EXP because staff engineers will weigh who you would want on the squads |
| R2C2 | "What does your team build, and how hands-on are you?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6" | Answer slot: say what your team builds and how hands-on you are, in your own words; if you are not hands-on, say so plainly and say what you do instead. The pack supplies neither. Staff engineers are checking whether you can follow their reasoning, so be exact about where your technical depth is and is not | F1 is the only evidence for the leadership scope and depth is where staff engineers probe it; EXP because it tests what you actually do |
| R2G1 | "What are you actually looking into in device management or fleet operations these days?" | JD | [generic] | Answer only from what you have really read or tried. Answer slot: if there is something, say what and what you took from it; if there is nothing yet, say so plainly and say where you would start, in your own words | F6 as a casual question that is still scored; JD because the role names device-management services |
| R2E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pick a time with a named stake, a moment you did not fold, and a relationship intact at the end. One candidate from your material is the quote; whether it fits is yours to judge, because the sentence does not say who the pressure came from or how it ended. If it fits, tell those parts in your own words; if it does not, choose another. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values stem from the persona model, chosen because the recruiter's words put values on this loop; VAL because it scores behaviour, not a slogan |
| R2F1 | "Sixty seconds: why should these squads trust an EM who has never owned a hardware-adjacent roadmap?" | JD | [grounded] "never owned a hardware-adjacent roadmap" "9 years engineering, 3 as a team lead of 6" | Pause, restate, then answer. Concede the plain fact: "I have never owned a hardware-adjacent roadmap." Hold what your material carries: nine years in engineering, three as a team lead of six. Hold it through two follow-ups; do not widen it. Concede uncertainty specifically, for example that you would lean on the staff engineers for the hardware seam. Do not fold on the core by bluffing hardware experience | F5 under time pressure; JD because it scores the stated requirement, with the pressure format a panel may use |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would a good EM take off your plate?" | Reciprocity to peers: it shows you think about their load |
| 2 | "Where do hardware dependencies hurt the squads most today?" | It turns F5 into learning from the people closest to it |
| 3 | "How do you and the PM decide what slips when something has to?" | It reveals how trade-offs are really made before you join them |
| 4 | "What does ready mean when something ships to devices in the field?" | It shows you take the field-release difference seriously |
| 5 | "What would you want to be able to count on from me?" | It invites the panel to state expectations you can meet |

## Round 3: the following Monday, VP Engineering (30 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral (E) | Scenario probes on how you lead | High. The recruiter described the round as "values and leadership philosophy", which moves it above the skip-level prior | Where a quoted sentence carries a story, map it at its scope; where none does, a selection scaffold ending in the honest branch |
| Pressure (F) | Time-boxed challenges, motive questions | Medium to high. The skip-level and executive row of the persona priors names it | Pause, restate, hold through two follow-ups, then concede specifically |
| Case/Strategist (A) | Altitude questions about how functions plan together | Medium. The other half of the skip-level prior | Clarify first, say what you do not yet know, flag a hypothesis as a hypothesis |
| Skeptic (B) | Why this company, why now | Low to medium. A short round leaves room for one | Calibrated candor over bluffing |

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3E1 | "What is your leadership philosophy?" | VAL | [grounded] "9 years engineering, 3 as a team lead of 6" "I run our hiring loop for backend roles — about 40 interviews last year" "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | State two or three principles you genuinely hold. For each, either point to one of those three sentences at its own scope or say plainly that no example comes to mind. Do not claim a principle your sentences do not illustrate: the third sentence says you pushed and what followed, not why, so the reason is yours to say in your own words. Let the interviewer draw the inference | The recruiter named leadership philosophy as this round's subject, so it is the most likely question; VAL because it scores how you lead |
| R3E2 | "Tell me about a time you helped someone on your team grow." | VAL | [grounded] "9 years engineering, 3 as a team lead of 6" | Your material carries no growth story, so this is a selection scaffold. Pick a time with a named person, a specific thing you did, and a visible result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Do not borrow an example from a colleague | F4 is the open row, and the role names growth for the engineers; VAL because it scores people leadership |
| R3E3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | A selection scaffold: pick a time with a named stake, a decision you made and what it cost you. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack supplies no example | A Values stem from the persona model, relevant to a role serving customers' devices; VAL because it asks for a specific decision |
| R3F1 | "That reliability result: how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause and restate. Hold the sentence at its scope: you pushed a reliability quarter through, and the burden dropped after it. Hold through two follow-ups. Answer slot: which parts were yours and which were your team's, in your own words; if the technical work was theirs, say so plainly and stay with what you pushed. Do not fold on the core, and do not widen it | F2 is the one result in your material and a pressure interviewer tests attribution; EXP because it asks what was actually you |
| R3F2 | "You have led a team of six and never managed managers. Why are you ready for eleven engineers across two squads?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6" "I've never managed managers" | Concede first, plainly: "I have never managed managers." Hold what your material carries: three years as a team lead of six. The pack's observation: the role text you gave does not say whether the squads have leads, so a reverse question on that is worth asking. Answer slot: why you are ready is yours to say; if you cannot yet say, say so plainly and say what you would find out first | F1 and your own stated limit make this the leadership-level objection; JD because the numbers come from the role |
| R3A1 | "If you could change one thing about how engineering, hardware and product plan together here, what would it be and what would you need to know first?" | CASE | [generic] | You have limited information, so say that first. Then offer a hypothesis labelled as one, and the questions that would confirm or kill it, using what you learned in rounds 1 and 2. It needs no claim about your past | F5 at the altitude a VP scores; CASE because it asks for structured reasoning on the role's real seam. No company research ran, so this is a pattern |
| R3A2 | "How do you decide when reliability work beats roadmap work?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Give the criteria you would apply, in your own words; the pack supplies none. If you mention your own case, tell it at the quote's scope, and answer follow-ups only from what happened | F2 turned into judgement; CASE because it asks for a decision rule |
| R3B1 | "What do you know about Larkfield, and why do you want to work here?" | CO | [generic] | Say only what you actually know; no company research ran in this pack, so nothing here is specific. Use what the Director and the panel told you, and say where it came from. Your reason is yours alone | The company-knowledge question a skip-level round is most likely to ask; CO because it scores homework. Generic until the upgrade menu's research is done |

### Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What is a leadership decision here you were proud of, and what made it right?" | It opens the values conversation on the VP's terms |
| 2 | "How do managers here get feedback and grow?" | It matches your role's growth responsibility and signals you want the same |
| 3 | "What would the best EM you have worked with here have done in their first ninety days?" | It gives you a concrete bar to meet |
| 4 | "Do the squads have leads, and how do the two squads work together today?" | It settles the question R3F2's observation leaves open |
| 5 | "What do you wish more candidates asked you?" | It invites the VP to tell you what they care about |

## Prohibited claims

Not coached in any round, with the basis and the honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned or partnered on a hardware-adjacent roadmap | Negative you stated, F5 | The plain acknowledgment: "I have never owned a hardware-adjacent roadmap." R1B1 and R2F1 hold slots only on whether you worked alongside hardware |
| Managed managers | Negative you stated | The plain acknowledgment: "I have never managed managers." No slot |
| Led, designed or built the reliability work, or cut on-call burden by 60% | Inflated form of F2 | The quote at its own scope. The pack's observation: the sentence says pushed and dropped after, not led, built or caused |
| Ran or owned hiring across the organisation, or conducted all 40 interviews | Inflated form of F3 | The quote at its own scope. The pack's observation: the sentence says the loop, for backend roles, and not which interviews were yours |
| Led several teams or two squads | Inflated form of F1 | The quote at its own scope: a team lead of six for three years |

## Sources

Provided documents: your message, which holds the role description and your background. No tuesday-dossier.md was present.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

All four searches were sent and refused for lack of permission; nothing came back from any of them.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Larkfield Systems values` | unavailable | Query "Larkfield Systems industrial IoT company values" refused. Would have moved the values cheat sheet (dropped) and named values for the VAL bank |
| 2. `Larkfield Systems interview process engineering manager` | unavailable | Query "Larkfield Systems interview process engineering manager" refused. Would have checked the loop; the loop here comes from your own words and the recruiter's |
| 3. `Larkfield Systems strategy` | unavailable | Query "Larkfield Systems industrial IoT device management strategy news" refused. Would have grounded R3B1 and R3A1, which stay generic |
| 4. `{interviewer name} Larkfield Systems` | n/a | No names were given, so there was no query to form; the interviewer read is absent |
| 5. representative `Engineering Manager` JD | unavailable | Query "Engineering Manager device management IoT platform job description squads hardware product roadmap" refused. Would have turned some `none given` rows into `[inferred]` JD-derived rows |

## Upgrade menu

- The posting text → every requirement row gets the posting's own wording, and the roles' unstated parts (whether the squads have leads, on-call, location) get settled
- Your CV → the fit snapshot's evidence cells can quote more than your message, and F4 and F6 may stop being `none given`
- The on-call numbers before and after (a pager or incident report) → F2 can rise from `medium`, and R1C1 and R3F1 stop resting on a bare figure
- Your actual answers to the answer slots in F1, F4, F5 and F6 → those rows regenerate with your own words in them
- The Director's, panel members' and VP's names → an interviewer read, tuned persona weights and reverse questions tied to their own paths
- The recruiter's guidance on what each round covers, and any pre-declared deliverable → the persona weights stop resting on role priors
- Company research (values, strategy, recent news; the searches here were refused) → a values cheat sheet for round 3, and R3B1 and R3A1 become grounded; a deeper pass of up to 6 more searches and 2 more fetches would take several more minutes
- A tuesday-dossier.md from an earlier evaluation of this role → verified evidence and sharper limits for every guidance cell
