Searches were declined, so I'm building the pack from your message alone and labeling anything research-dependent as generic. Writing it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-2/rooms/case-7-denied-354340e9/saltmarsh-games_live-operations-producer_interview_pack.md`. It has 22 questions across 7 interviewer styles, built for a hiring-manager conversation with Tobias. That is an assumption, since you didn't say how he relates to the role.

My web searches were declined, so nothing in the pack comes from research on Saltmarsh or Tobias. The two questions about the company (A5, D3) are generic, and there is no interviewer profile.

The pack names B1 as your highest-value prep: "I don't see in-app purchases in your background." Your honest answer is the plain sentence, "I have never worked on a game with in-app purchases," followed by a learning plan. Don't bridge it with your calendar or retention work. The pack also expects probes on whether you've run more than one title's calendar, and on how you'd run a post-event review.

I can play Tobias as a skeptic on B1, with follow-ups, and give you feedback on how you held up.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, so you can carry them into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the person you'd report to, and did the recruiter mention any focus areas or an exercise for Friday? Either answer would reweight the pack.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh-games_live-operations-producer_interview_pack.md -----
# Interview pack: Live Operations Producer, Saltmarsh Games

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager, not confirmed.
**Format:** one 60-minute session, Friday. Built for Femi on Tuesday 24 November 2026.

## How to use this pack

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Behavioral or values alignment: whether past behavior shows what the question is after |
| EXP | Work-experience deep-dive: whether your background survives scrutiny, and what was actually you |
| JD | Role or JD-driven: whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge: homework depth |
| CASE | A live problem from the role, answered aloud |

Question IDs run by persona: A, B, C, D, E, G, H. The letter F is skipped so that F1 to F10 mean only fit-snapshot rows. Where a question carries two aims, the type shows the primary one and the rationale names the other.

## Prep triage

You have until Friday. In order:

1. Say B1 and H1 aloud until they are dull. They are the most likely hard moment, and the plain sentence is the whole answer.
2. Do A1 to A4 aloud once each, thinking out loud and stating your structure first.
3. Rehearse the 90-second path in D1 and the walkthrough in C1.
4. Pick three reverse questions from section 11 and know why you are asking each.
5. If you can find and play the two titles, do it for A5 and D3.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message; "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | discovery | Your material gives the years and the calendar, and does not say whether the title ran as a live service. Answer slot: the JD's live-service line makes a probe on that likely. If the title ran on a continuing schedule of updates, say how it worked, in your own words; if it did not, or you are unsure the term fits, say so plainly and stay with the calendar you ran |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap: the quote says what the JD asks, in the same terms. Lead with it as written. It is a CV-style line with nothing inspected behind it, so expect a probe on it |
| F3 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Your material says content drops for your main title, not events and not two titles, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-titles line makes a probe on running more than one calendar likely. If you ran or coordinated more than one at once, say how; if not, say so plainly and stay with the one you ran |
| F4 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not say who you worked with on a drop. Answer slot: the JD's four teams make a probe likely. If you coordinated any of design, art, engineering or community on your drops, say which and how, in your own words; if some were not involved, or it was not yours to coordinate, say so plainly |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head" — your message | low | [inferred] | discovery | The quote is a presentation of numbers, not a review of an event, and the words stay there: "I presented the monthly retention numbers to the studio head." Derivation: the monthly numbers touch the KPI side of the requirement. Answer slot: the JD's post-event review line makes a probe likely. If you wrote up how single drops performed, say what that covered; if no such review existed, or it was not yours, say so plainly and stay with the monthly presentation |
| F6 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | transferability | Your material says you wrote the checklist and that QA still uses it, not that you ran releases against it. Words: "I wrote the release checklist our QA team still uses." Answer slot: the JD's manage-with-QA line makes a probe on running a release likely. If you ran releases against it, say how; if someone else did, or you only wrote it, say so plainly and stay with the checklist |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | none | No gap on the requirement as worded: lead with the quote in its own terms, which are monthly, retention, to the studio head. Nothing is inspected behind it, so expect a probe on how the numbers were built (C1) |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | Derivation: a written checklist others still use touches the requirement without showing how clear it is. Answer slot: if asked for an example of your writing, offer the checklist in those words; if there is something else you wrote that others relied on, say what; if there is not, say so plainly |
| F9 | in-app purchase and monetization familiarity, a common mobile live-ops expectation; not in the JD — role-family pattern | "never worked on a game with in-app purchases" — your message | none | [generic] | capability | A gap you stated, and the words come only from it: "I have never worked on a game with in-app purchases." Nothing is stretched to cover it. Then how you would learn it, said as a plan and never as a past |
| F10 | leading people; not in the JD, which asks for coordination — role-family pattern | "Never led a team" — your message | none | [generic] | capability | A gap you stated: "I have never led a team." The JD asks you to coordinate teams, not to lead them, so the honest line is that sentence, then what you would do, as a plan |

No JD requirement is a hard gate: the 3+ years line is experience, not a licence or legal term.

## Graded deliverables

Not included: no deliverable was announced.

## Reading the interviewer

Not included: only a name and title were given, and no public profile could be read.

## Persona table

Weights start from the hiring-manager prior, then are adjusted by interviewer signals (none found) and by the loop (a single 60-minute session, which your own words establish). The relationship is assumed, so say if it is wrong and the table changes.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (A) | Live problems on calendar, release and retention | High: hiring managers buy capability through live problems, and the JD is a planning and coordination job | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (B) | Quiet probing of the gaps in F9, F10 and the two-title scope in F3 | High: the hiring-manager prior includes derisking gaps, and two are stated in your own words | Rehearse the single most predictable objection until it is boring; calibrated candor over bluffing |
| Data-Driven Prober (C) | Line-by-line questions on the retention numbers and the KPIs the role reports | Medium: retention and KPIs are two JD lines | Say plainly what you can and cannot say about how the numbers were built |
| Conversational (D) | Path walkthrough and motivation, casual but scored | Medium: openers appear in most conversations at this level | A scripted 90-second arc; treat casual questions on live ops as scored |
| Values/Behavioral (E) | Stories about unwelcome truths and team disagreement | Low: no loop source names a values round, so none is detected | A story only where your quoted sentences carry one, a scaffold with its honest branch where not |
| Peer Evaluator (G) | Seam-splitting with adjacent teams | Low: the JD has you coordinating four teams, but the interviewer is not one of them on the assumption made | Offer seam principles, not a pretended seam; reciprocity framing |
| Pressure (H) | Time-boxed "why you" and attribution probes | Low: it tends to follow a visible gap | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

### A. Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "We're planning a month of live events across two titles. What do you need to know first?" | CASE | [generic] | Clarify before structuring: each title's audience and event history, what the teams can absorb, what the calendar has to hit. Then objective, segmentation by title and player group, approach, how you would measure it, risks. State your hypothesis early and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's calendar line (F3) turned into a live problem, which a hiring manager can score without reading the CV; CASE because it asks for structure, not history |
| A2 | "Retention dropped 20% in the week after an event. Diagnose it." | CASE | [generic] | Clarify first: which players, which platform, whether anything else shipped or changed that week, how retention is counted. Then segment, list hypotheses by likelihood, say what you would check first and what would change your mind. Say the structure aloud. The question needs no claim about your past, so the guidance makes none | F7 and F5 name retention and KPIs as the role's ground; this is the standard diagnostic stem for them; CASE because it scores reasoning, not recall |
| A3 | "An event is two days from launch and QA has found a bug in the reward flow. Engineering says a fix needs three more days. Walk me through your call." | CASE | [generic] | Clarify severity, who owns the go or no-go, and what the reward flow does if it fails. Lay out options such as ship with a mitigation, delay, or ship in part; name the cost of each to players and teams; say who you would tell and when, and what you would record afterwards. Say what would change your call. The question needs no claim about your past, so the guidance makes none | F6's QA line as a decision under time pressure; CASE because it is a live trade-off, JD in content |
| A4 | "A weekly drop and a seasonal event both need the same engineering week. How do you decide which gets it?" | CASE | [generic] | State your criteria before you choose: what each is worth, what each risks, what each costs the teams. Say who you would consult and how you would tell the team that lost out. Think aloud and name the premise you would test first. The question needs no claim about your past, so the guidance makes none | F3 and F4 together: a calendar shared by several teams; CASE because it scores prioritization |
| A5 | "Which of our two titles have you spent time in, and what would you change about how its events run?" | CO | [generic] | Research on Saltmarsh did not run for this pack, so nothing here is known about the titles themselves. Spend time in what you can find of them, then name what you actually saw (timing, rewards, how an event was announced) and one change with your reason. If you have not played either, say so plainly, then say what you would look at first in your first week | The two titles come from the JD's own words (F3); CO because it scores homework, and `[generic]` because no company facts were researched |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see in-app purchases in your background. How would you handle that side of live events here?" | JD | [grounded] "never worked on a game with in-app purchases" | **Highest-ROI prep in this pack.** Say the limit first and plainly: "I have never worked on a game with in-app purchases." Your calendar and retention work are real but they are not monetization, so mention them only as what you bring, never as a step toward it. Then the plan, in the future tense: what you would learn first, from whom, and how you would check your understanding with Tobias's team before it shaped a decision. Two follow-ups: hold by returning to the same sentence and the plan, never by adding experience | F9 is the largest stated gap and a likely probe in some form for a mobile live-ops role. JD because it scores whether you can do the job as scoped, Skeptic because it is aimed at a gap |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never worked on a game with in-app purchases"; "I ran the weekly content-drop calendar for our main title for the last two years" | Pick one and say it plainly, then the first thing you would do about it. Your material points at one stated gap, "I have never worked on a game with in-app purchases", and at one scope limit worth naming: the JD has two titles and your quote says your main title. Answer slot: if another part of the JD is truly your weakest, name that one instead; if you do not see a weakness, say what you would ask Tobias to check in your first month. Do not name a weakness you do not believe is yours | Persona stem for the Skeptic; F9 and F3 are where the material is thin |
| B3 | "You ran the weekly content-drop calendar for your main title. This role runs events for two titles. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say what the quote says, at its scope: you ran the weekly content-drop calendar for your main title for the last two years. Answer slot: if you ran or coordinated more than one calendar at once, say how; if not, say so plainly and stay with the one you ran. Then what you would ask about the second title's cadence before changing anything | F3 is the transferability gap here; the JD's two-titles line raises it. JD because it scores the stated responsibility |
| B4 | "The JD has you coordinating design, art, engineering and community on each update. Tell me about a time you got several teams to one date." | JD | [generic] | Pick an update where more than one discipline had to land together. It needs a named stake, what you yourself did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack does not choose the story for you because your material does not name one | F4 has no quote behind it, so this is a scaffold, not a story map; theme from the JD's coordination line |
| B5 | "The JD has you coordinating design, art, engineering and community on each update. Have you led a team?" | EXP | [grounded] "Never led a team" | Answer the question asked: "I have never led a team." One sentence, no apology, and nothing else stretched into leadership. Answer slot: the JD asks for coordination, not for leading; if you have coordinated people from other teams to a shared date, say how, in your own words; if you have not, say so plainly and say what you would do in your first update cycle | F10 is a stated gap; EXP because it tests whether the background survives a plain question |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through the monthly retention numbers you presented to the studio head." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Story-mapped on F7: the numbers were monthly, they were retention, and the audience was the studio head; tell it in your own words. Answer slot: the JD's retention line makes a probe on which retention measures were in those numbers likely. If you chose or defined measures, say which; if they were set by someone else, or you only presented them, say so plainly and stay with presenting. If asked how a number was counted and you do not know, say so | F7 is the evidence for the retention requirement and the likeliest place to be probed; EXP because it tests what was actually yours |
| C2 | "What would you look at first the morning after an event, and what would make you distrust it?" | CASE | [generic] | Name the comparison you would make and against what baseline, the segments you would split by, and the confounders you would rule out first. Say what sample size or timing would make you hold back a conclusion. The question needs no claim about your past, so the guidance makes none | F5 and F7: the role reports KPIs, so the interviewer will test how you would read them |
| C3 | "What would you own in the post-event review, and which KPIs would it report?" | JD | [inferred] "Presented the monthly retention numbers to the studio head" | Describe what a review of an event should contain and why, as your design, not your history. For the past, stay at the quote's scope: "I presented the monthly retention numbers to the studio head." Answer slot: if you wrote up how single drops performed, say what that covered; if no such review existed, or it was not yours, say so plainly and stay with the monthly presentation | F5 is a low-confidence row, so the guidance stays a clarify-strategy note; JD because it scores the stated responsibility |

### D. Conversational (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through your path to this role." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | A 90-second arc using only those four beats, in your own words: the four years, the calendar, the checklist, the monthly numbers. Add no figures, team sizes or tools you did not state. Close on your own reason for wanting this role, in your words | F1 (years) through F8; JD content for the years line, conversational delivery. Casual openers are scored |
| D2 | "Why live operations, why here, and why now?" | JD | [generic] | Give your actual reasons in your own words, one sentence each. If one of the three does not have a real answer, say so and give the ones you do. The pack does not write them for you: a reason you did not give is one you cannot defend | The motivation probe every conversational interviewer asks; JD because it scores whether you want the listed job |
| D3 | "What are you actually playing with in live ops these days?" | CO | [generic] | Name one live event you have actually seen in a game you play, what it did with timing, rewards and communication, and what you would change. If you are not playing any, say so plainly and name what you will play before Friday | A casual question on the JD's central topic, which is scored; CO because it tests current awareness |

### E. Values/Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Selection scaffold: pick a time numbers or a call you brought to a senior person were unwelcome. It needs a named stake, what you yourself did, and an intact relationship at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the monthly presentation at its own scope | The persona stem for this round; F7 is the only row with a senior audience, and it does not show an unwelcome result |
| E2 | "Tell me about a time QA and the content team disagreed about a release date." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Selection scaffold: choose a real disagreement, say what each side wanted, what you did yourself, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is that you wrote the checklist QA still uses, or how you would handle it | Theme from the JD's QA line (F6); VAL because it scores behavior under disagreement |

### G. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Design, art and engineering each have their own roadmaps. Where is the seam between your calendar and theirs, and what happens when we disagree?" | CASE | [generic] | Propose seam principles, not a seam you cannot know: who sets the date, who can say no, how a conflict is escalated and recorded. Frame it as what you bring them, not only what you need. The question needs no claim about your past, so the guidance makes none | F4's coordination line as a collegial probe |
| G2 | "How do you handle credit when an update spans several teams?" | VAL | [generic] | Your principle in your own words: "we" for context and "I" for your own contribution. If an example from your drops comes to mind, tell it as it was; if none does, say so plainly and give the principle | Persona stem; VAL because it scores partnership behavior |

### H. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a candidate who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head"; "never worked on a game with in-app purchases" | Pause and restate the question. Hold on what the quotes carry, in order: you ran the weekly content-drop calendar for your main title for two years, you wrote the checklist QA still uses, you presented the monthly retention numbers. Describe what you did and let them draw the inference. Concede the one thing plainly: "I have never worked on a game with in-app purchases." Through two follow-ups, return to the same three sentences, never adding to them | F9 is where a pressure interviewer goes; the hold stays inside F2, F6 and F7 |
| H2 | "That calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold on the quote at its scope: you ran it, weekly, for your main title, for two years. Answer slot: if decisions on content or timing were shared with others, say which were yours and which were not; if the calendar was set by someone else and you ran it, say so plainly. Do not defend a larger share than you can walk through | F2 is the strongest row and the attribution probe tests it; EXP because it scores what was yours |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a good post-event review look like here, and which KPIs does it report on?" | The JD names this as the role's responsibility, so it shows you think about what happens after an event |
| 2 | "How are events split between the two titles, and how far ahead is the calendar already set?" | It asks for the working shape of the job you would be doing |
| 3 | "Where is the hardest handoff between design, art, engineering and community on an update today?" | It points at the coordination line and invites a real answer, not a pitch |
| 4 | "How does the release checklist work with QA today, and where does it hurt?" | It tests the JD's QA line and shows you would start from how it works now |
| 5 | "How does monetization shape how the team plans events, and who would I learn that from?" | It raises the gap in F9 yourself, as a plan to learn, instead of waiting to be asked |
| 6 | "What would you want me to have changed or learned by the end of my first 90 days?" | It turns the conversation to expectations you can plan against |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | Negative the candidate stated, F10 | The plain acknowledgment F10 gives: "I have never led a team." No slot |
| Has worked on a game with in-app purchases, or on monetization | Negative the candidate stated, F9 | The plain acknowledgment F9 gives: "I have never worked on a game with in-app purchases." No slot; then a plan, never a past |
| Ran live events across two titles | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says content drops for a main title, not events and not two titles. B3's slot stays inside the calendar |
| Owned the post-event review and the KPIs | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: the material says the monthly retention numbers were presented, not that reviews or KPIs were owned. C3's slot stays inside the presentation |
| Improved or drove retention | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says the numbers were presented, not that they moved |
| Managed releases with QA | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: the material says the checklist was written, not that each release was run against it |

## Sources

Provided documents: your message, with the pasted JD and your background. No `tuesday-dossier.md` was present.

Searches sent, each refused (no results returned):

- `Saltmarsh Games mobile studio values` — refused
- `Saltmarsh Games interview process Live Operations Producer` — refused
- `Saltmarsh Games mobile games news strategy` — refused
- `Tobias Wrenfield Saltmarsh Games Head of Live Operations` — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | The call was refused. It would have given the official value names for VAL questions; no values-style round is detected anyway, so no cheat sheet is built |
| 2. `{company} interview process {role family}` | unavailable | The call was refused. It would have checked the loop and moved the persona weights; your own words establish this one 60-minute session, and the relationship is assumed |
| 3. `{company} strategy` / recent news | unavailable | The call was refused. It would have grounded A5 and D3 in real company facts, so both stay generic |
| 4. `{interviewer name} {company}` | unavailable | The call was refused. It would have produced the interviewer read and a reverse question tied to his path, both absent |
| 5. representative `{role title}` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 3+ years producing live-service games or apps | D1, H1 |
| experience running a content calendar | B3, H2, A4 |
| Plan and run the live-events calendar for two of our mobile titles | A1, A4, A5, B3 |
| coordinate design, art, engineering and community teams on each update | B4, B5, E2, G1, G2 |
| own the post-event review and the KPIs it reports | C2, C3 |
| manage the release checklist with QA | A3, E2 |
| comfortable with player-retention metrics | A2, C1, C2 |
| clear written communication | none: it is judged in written exchanges and any exercise, not asked aloud; F8 holds the line to say if asked for an example |
| not in the JD: in-app purchase familiarity | B1, H1 |
| not in the JD: leading people | B5 |

No CV figure is quoted in your material, so no defend-the-number question is included.

## Upgrade menu

- Search permission granted, or the company's values page, careers or interview page and recent news pasted in → A5 and D3 rest on real company facts instead of `[generic]`, and the loop and persona weights are checked against the company's own process
- A paste of anything Tobias has published, or a link you want read → an interviewer read, reweighted personas and a reverse question tied to his path
- The recruiter's note on focus areas, or any exercise announced → coverage of a deliverable and tighter persona weights
- Your CV, or bullets with figures → defend-the-number questions, which are absent now because no figure was in your material
- Your own answers to the answer slots in F1, F3, F4, F5 and F6 → those rows can upgrade from discovery or transferability once stated outside a drill
- A writing sample, such as the release checklist → better evidence for F8
- A `tuesday-dossier.md`, if you have one → verified evidence and a prohibited-claims list from a prior check, optional and never required
