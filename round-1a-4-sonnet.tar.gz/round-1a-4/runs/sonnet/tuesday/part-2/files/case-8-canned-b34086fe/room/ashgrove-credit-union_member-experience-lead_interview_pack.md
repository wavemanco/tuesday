# Member Experience Lead — Ashgrove Credit Union — interview pack (three rounds, 3 December 2026)

Candidate: Dara. Built 24 November 2026, loop mode: one shared fit snapshot, then a mini-pack per round. Interviewer names are not yet assigned, so there is no interviewer read and no per-person persona weighting; weights follow each round's role and format.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour demonstrates Ashgrove's published values |
| EXP | Whether what you say about your own experience survives follow-up |
| JD | The posting's stated responsibilities and requirements, gaps included |
| CO | Whether you can think at Ashgrove's altitude: strategy, competition, recent moves |
| CASE | A live problem: structure and reasoning, not a "right" answer |

Two kinds of cell appear in the banks. An **answer slot** is an instruction for the interview, not a question for you now: it names the interviewer's likely probe, then gives two honest branches, one if you did the thing and one if you did not or it was not yours. A **logistics slot** (round 1) tells you to give your own fact in your own words; the pack supplies no figure.

## Prep triage (24 November to 2 December)

Everything is sized to nine days. Do these in order; everything else is insurance.

1. Days 1–2: rehearse D1, the highest-ROI question in this pack (the contact-centre objection), until the plain acknowledgment is boring to say. Then A1, your 90-second journey.
2. Days 3–5: choose four real stories, one per Ashgrove value, using the selection criteria in C1, C2, C4 and H1–H4. Your material has no story for any of them yet, so this is the biggest lift. The same four stories serve the manager round and the panel.
3. Days 6–7: run J1 and J2 aloud, timed to 20 minutes for the panel case. Then the two spreadsheet and log walk-throughs, G1 and G2.
4. Day 8: the logistics rows A3–A6 (write your own one-line answers), then the reverse questions for each round.
5. 2 December: one pass of D1 and A1 only.

All three rounds are on the same day, in the order the recruiter listed them.

## Fit snapshot (shared across all three rounds)

Requirements are quoted from the JD you supplied. Evidence is your own sentences, quoted exactly from your message. No requirement here is a gate: length of experience is graded like any other row.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says the branch's log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint after it left the log likely. If you followed any complaint beyond your branch, say how far and which part was yours, in your own words; if the log was where your part ended, say so plainly and stay with the log |
| F2 | "the contact centre" (from "across branches and the contact centre") — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you stated, so the words are yours: "I haven't worked in a contact centre." Then say how you would learn it, as a plan and never as a past. No contact-centre claim, and nothing that sounds like one |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote reaches a monthly complaints spreadsheet, and does not show whether it counted volumes or resolution times. Answer slot: the JD's two measures make a probe on what it counted likely. Say which of them it counted, in your own words; if it counted something else, say what; if it counted neither, say so plainly and stay with the spreadsheet |
| F4 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | presentation | The length is not in doubt against the posting's four. Say it in the quote's own terms: six years in retail banking, the last three as a branch supervisor. Do not relabel branch work as contact-centre or operations-leadership work |
| F5 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | The quote says formal complaints log. It does not show whether the log fell under a regulator's rules. Answer slot: the JD's word "regulated" makes a probe on that likely. If rules governed how complaints in the log had to be handled, say which and what you did to meet them, in your own words; if the log was an internal record, or you only recorded entries, say so plainly and stay with the log |
| F6 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you stated: "I haven't presented to anyone above regional level." Then a plan for how you would prepare to present, never a past. Your material does not say whether you have presented at regional level; B2 holds that as a slot |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The quote says you trained new tellers on the script, not that you coached supervisors. Words at that scope: "I trained new tellers on our escalation script." Answer slot: if you ever coached a supervisor or a peer on an escalation, say how; if not, say so plainly and stay with the tellers |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here, which is not an admission. Answer slot: if you have worked with a digital or product team, say on what and which part was yours; if not, say so plainly and say what you would ask the digital team first |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The quote says spreadsheet, not Excel, and does not say what was in it. Answer slot: if it was built in Excel, say what it did, in your own words; if it was another tool, say so and stay with what it did |

## What Ashgrove has published that you can use (grounding brief)

Source: the July 2026 strategy brief, as you summarised it; the brief itself was not pasted, so nothing below goes beyond your four points.

| Item | What it says | Provenance | Where it can surface |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | E1, F8 row (E3), reverse questions |
| Branch consolidation | Eight branches into five hubs over 2027 | [grounded] | J3, H3, panel reverse questions (the panel are branch managers) |
| New product | A small-business lending product in Q1 2027 | [grounded] | Reverse questions only; no bank question rests on it |
| Competitive pressure | App-only banks are the main pressure | [grounded] | E2 |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Own the complaints process end to end (F1) | A1, C1, D1, G2, J1 |
| The contact centre (F2) | B1, D1, D3 |
| Monthly reporting on volumes and resolution times (F3) | G1 |
| 4+ years financial-services customer operations (F4) | A1 |
| Regulated complaints (F5) | G2 |
| Presenting to senior leaders (F6) | B2, L1 |
| Coach branch supervisors on escalations (F7) | C3, J2 |
| Work with digital teams on self-service journeys (F8) | E3 |
| Excel reporting (F9) | G1 |

---

# Round 1 — Recruiter, 30 minutes

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, motivation, logistics | High. The recruiter row in the persona model leads with conversational. The risk is treating it as unscored | A rehearsed 90-second arc; answer logistics in your own words |
| Skeptic (light) | Knockout checks in a friendly register: contact centre, senior presenting | Medium-low. Both appear in the JD and in your own words | Plain acknowledgment, then a plan; no bluffing |

## Question bank

Conversational (and logistics)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F4, F1 and F3, using only the beats the sentences state: six years in retail banking; the last three as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Tell them in your own words in about 90 seconds and close on what draws you to this role, in your own words | F4 is the experience screen the recruiter must tick; EXP because the arc is your own account and will be probed |
| A2 | "Why Ashgrove, and why now?" | CO | [grounded] | Selection scaffold: pick one specific thing Ashgrove has published, a value by name or a point in the strategy brief, that you can speak to from your own work, and say why in your own words. If nothing comes to mind, say so plainly and say what draws you to a member-owned organisation | Motivation consistency is the recruiter's second job. CO because it tests homework on published material |
| A3 | "What are your salary expectations for this role?" | JD | [generic] | Logistics slot: give your own figure in your own words, or ask for the role's band first and give your figure once you have it. The figure is yours to state; the pack supplies none | Pay is a logistics check every recruiter screen includes |
| A4 | "What's your notice period, and when could you start?" | JD | [generic] | Logistics slot: give your actual notice period and earliest start date, in your own words | A logistics knockout; JD because it concerns the listed job's terms |
| A5 | "Is the location and working pattern of this role workable for you?" | JD | [generic] | Logistics slot: the posting you shared does not say where the role is based or what the on-site pattern is. Ask the recruiter, then give your own answer in your own words | A logistics knockout; the posting's silence is the reason to ask |
| A6 | "What's prompting you to look at a move now?" | EXP | [generic] | Logistics slot: give your actual reason in your own words, in one or two sentences, pointing toward what this role offers. Give no reason that is not yours | The reason for leaving is asked in every recruiter screen; EXP because it must stay consistent with everything else you say |

Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as branches. What's your experience there?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't worked in a contact centre." Then say how you would learn it, as a plan, in your own words. Do not reach for contact-centre-like experience | F2 is a stated gap and the recruiter will check it early; JD because it scores a stated responsibility |
| B2 | "This role presents to senior leaders. Have you presented to leaders before?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Answer slot: the JD's senior-leaders line makes a probe on what you have presented likely. If you have presented at regional level, say to whom and about what, in your own words; if you have not presented at all, say so plainly. Then say how you would prepare, as a plan | F6 is a stated gap; JD because the requirement is stated in the posting |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "How is the complaints process split between branches and the contact centre today, and where does it hand over?" | Shows you read the end-to-end line in the JD, and the answer tells you what you are being asked to own |
| R1-2 | "Is the role based in one place, or does it move between branches and the contact centre?" | Settles the location pattern the posting leaves open (A5) |
| R1-3 | "After the panel on 3 December, what are the next steps and when do you expect to decide?" | Standard, and closes the recruiter's process loop |

---

# Round 2 — Head of Member Services (your future manager), 45 minutes, mostly behavioural

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | "Tell me about a time" prompts | Highest. The recruiter described the round as mostly behavioural | Story chosen before you walk in, one per value; "we" for context, "I" for contribution |
| Skeptic | Probing the contact-centre and scope jump | Medium. A hiring manager prices gaps; F2 and F6 are stated | Plain acknowledgment, hold what your material carries, plan |
| Case/Strategist | Strategy and role problems | Medium. A manager buys capability on their own roadmap; the 2026 strategy puts digital front and centre | Clarify before structuring; think aloud |
| Data-Driven Prober | Reads your reporting and log claims line by line | Low-medium. Your material has two concrete artefacts to probe | Say what each counted and what was yours; say plainly if you do not know |

## Question bank

Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for "Own the Fix": pick an instance where you found the problem, stayed with it, and it was resolved. It needs a named member or colleague at stake, the part that was yours, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I handled the branch's formal complaints log", or how you would handle it | Own the Fix is one of the four published values, and F1 is where it presses hardest; VAL because it scores a value by name |
| C2 | "Tell me about a time a member, or a colleague, needed something explained twice." | VAL | [grounded] | Selection scaffold for "Plain Words": pick a time where the first explanation did not land and what you changed. It needs the original wording, what you changed, and what happened next. If no such time comes to mind, say so plainly and say how you would check that a member understood | "Plain Words" says needing it explained twice means it was written wrong, so this is a published-value probe; VAL |
| C3 | "Walk me through the escalation script you trained new tellers on." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Tell it at the quote's scope: you trained new tellers on the escalation script. Answer slot: the "Plain Words" value makes a probe on how the script's words were chosen likely. If you had a hand in the wording, say what and why, in your own words; if you taught it as written, or someone else set it, say so plainly and describe how you taught it | F7 is the only coaching-adjacent row; VAL because the probe is the Plain Words value, EXP in how it is asked |
| C4 | "Tell me about a time what the numbers said and what the member in front of you needed didn't match." | VAL | [grounded] | Selection scaffold for "Neighbours, Not Numbers": pick an instance where the count and the person pointed different ways. It needs the figure or target, the person, what you did, and how it ended. If no such time comes to mind, say so plainly, then say how you would weigh them | You built a monthly reporting spreadsheet (F3), which is the natural place the value will be tested; VAL |

Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns the process across branches and the contact centre, and you haven't worked in a contact centre. Why should we think you can own it?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **Highest-ROI prep in this pack.** This objection will arrive in some form. Step 1: plain acknowledgment, "I haven't worked in a contact centre." Step 2: hold only what your quotes carry, "I handled the branch's formal complaints log and trained new tellers on our escalation script." Follow-up 1 will likely press on scope, branch versus end to end. Return to the log at its own scope; answer slot: if you followed any complaint beyond your branch, say how far, and if the log was where your part ended, say so plainly. Follow-up 2 will likely ask what makes you think you can. Give a plan in your own words for how you would learn how the contact centre handles complaints. A concession wording you can use, pending your approval: "That's a real gap, and I'd learn how the calls are handled before I proposed any change." Do not add experience to close the gap | F1 and F2 together are the biggest gap between what the JD asks and what the material carries; JD because it scores the stated responsibility, Skeptic in delivery |
| D2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Choose one honestly, from the two you stated: the contact centre, or presenting above regional level. Say it plainly, then give your plan. Calibrated candour beats naming a trivial weakness | F2 and F6 are stated gaps; a manager asks this to test self-assessment |
| D3 | "Coming from a branch, how would you earn credibility with contact-centre colleagues?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Acknowledge: "I haven't worked in a contact centre." Then propose principles for how you would work with them, such as learning how they work before changing anything, rather than claiming to know the seam. This is a plan in your own words | F2 again, from the working-relationship side; JD |

Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "We're aiming to move 40% of member service to digital channels by 2028. What should that mean for how complaints are handled?" | CO | [grounded] | Structure aloud and clarify first: which complaints count towards the 40%, how a complaint raised on a digital channel reaches the log, and what a member should never have to explain twice. Then objective, approach, how you would measure it, risks. The question needs no claim about your past, so the guidance makes none | The strategy brief puts digital at the front; CO with a CASE delivery |
| E2 | "Our main competitive pressure is app-only banks. What does a member's complaint experience have to do to keep them with us?" | CO | [grounded] | Clarify first: which members, which complaints, what leaving looks like. Then structure your answer around the published values rather than generic claims. Challenge one premise respectfully. No claim about your past | The brief names app-only banks as the pressure; CO |
| E3 | "Tell me about a time you worked with a digital or product team." | JD | [grounded] | Answer slot: the JD's digital-teams line makes a probe on this likely. If you have worked with a digital or product team, say on what and which part was yours; if not, say so plainly and say what you would ask the digital team first | F8; JD because it tests a stated requirement your material is silent on |

Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Walk me through the monthly complaints spreadsheet you built for your regional manager." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Tell it at the quote's scope: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: the JD's volumes and resolution times make a probe on what it counted likely. Say which it counted, and whether it was built in Excel, in your own words; if it counted something else, or was another tool, say so plainly. Name the assumption in it you would defend least, in your own words, before they ask; if you do not know how a figure in it was counted, say that | F3 and F9; EXP because this is your own artefact and will be probed |
| G2 | "Walk me through how the branch's formal complaints log was handled." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Tell it at the quote's scope: you handled the branch's formal complaints log. Answer slot: the JD's word "regulated" makes a probe on the rules likely. If rules governed how complaints had to be handled, say which and what you did to meet them, in your own words; if the log was an internal record, or you only recorded entries, say so plainly | F5; JD because "regulated complaints" is a stated requirement |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would good look like in the monthly complaints report after the first quarter?" | Turns the reporting requirement into a shared target |
| R2-2 | "Which parts of the complaints process work well today, and which would you want fixed first?" | Shows you want to own what is broken, which is the "Own the Fix" value in action |
| R2-3 | "How does the 40% digital target change what the complaints process needs to do?" | Ties the role to the strategy brief |
| R2-4 | "How do branch and contact-centre colleagues work together on a complaint now?" | Gets the facts F2 is missing without claiming any |
| R2-5 | "Where would you expect me to need the most support in my first month?" | Converts a stated gap into a collaborative conversation |

---

# Round 3 — Panel of two branch managers, 60 minutes (includes a 20-minute escalation case; scored against the four values)

## Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario probes mapped to the four values | Highest. The recruiter said the panel scores against the four values | One story per value, chosen in advance |
| Case/Strategist | The 20-minute case | High. A third of the round is a live case | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| Peer Evaluator | "Where's the seam" with branch managers | Medium. You would coach their supervisors | Reciprocity framing; propose seam principles, do not pretend to know the seam |
| Skeptic/Pressure | Branch-to-network jump; presenting | Medium-low. Both are stated gaps | Hold then concede; plain acknowledgment |

Per-member personas cannot be assigned until names are known.

## Question bank

Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Selection scaffold for "Members First, Always": pick an instance where you chose what was right for the member over what was easier for the branch. It needs the decision, what it cost, and how it ended. If no such time comes to mind, say so plainly, then say how you would decide | A published value, scored by name; VAL |
| H2 | "When have you rewritten something so a member would only need it explained once?" | VAL | [grounded] | Selection scaffold for "Plain Words": pick a letter, script or explanation you changed. It needs what it said before, what you changed, and how you knew it worked. If no such time comes to mind, say so plainly, then say how you would test it. You can reuse the story from C2 | A published value, scored by name; VAL |
| H3 | "Tell me about a time what was right for a member didn't fit the way a branch was measured." | VAL | [grounded] | Selection scaffold for "Neighbours, Not Numbers": pick an instance where the person and the measure pulled apart. It needs the measure, the person, and what you did. If no such time comes to mind, say so plainly, then say how you would handle it. You can reuse the story from C4 | A published value; asked of branch managers who run branches against numbers; VAL |
| H4 | "Tell me about a time you found a problem that wasn't yours to fix and kept hold of it anyway." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold for "Own the Fix": the nearest thing your material carries is "I handled the branch's formal complaints log". Pick an instance where you found it, stayed with it, and it was resolved, with a named stake, the part that was yours and how it ended. If no such time comes to mind, say so plainly. You can reuse the story from C1 | A published value; VAL |

Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| J1 | "A member has complained at a branch twice, then phoned the contact centre. The branch says it's resolved and the member says it isn't. What do you do?" | CASE | [generic] | Structure it aloud. Clarify first: what the member is asking for, what has been recorded, what stage the complaint is at and which clock applies. Then objective, who owns it today, approach, how you will tell the member in plain words, how you will record it, and risks. Challenge one premise respectfully. Keep to member's side, plain words, own the fix. No claim about your past | The 20-minute escalation case; the exact scenario is theirs, so this is a pattern. CASE |
| J2 | "One supervisor escalates everything, and another sits on complaints too long. How would you coach each?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Structure: what you would ask each first, what each is protecting, what you would agree with each, and how you would know it worked. If asked about your own coaching: "I trained new tellers on our escalation script." Answer slot: if you ever coached a supervisor or a peer, say how; if not, say so plainly and stay with the tellers | F7; CASE because it is a live scenario from the JD's coaching line |
| J3 | "A member in a town where a branch is moving into a hub complains about the change. Walk us through it." | CASE | [grounded] | Clarify first: what they are asking for, what is decided versus still open, who owns the answer. Then plain words, what you can and cannot promise, and how it is recorded. The panel may be affected by the hub plan, so stay specific and avoid speculating about which branches change. No claim about your past | The strategy brief's consolidation is the live context for branch managers; CO delivered as CASE |

Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "Our supervisors report to us and you'd coach them on escalations. Where's the seam, and what happens when we disagree?" | JD | [generic] | Reciprocity framing: what you bring their branches, then what you need from them. Propose seam principles rather than pretending to know the seam. Agree in advance who decides what, and that a disagreement goes to the member's side. No claim about your past | F7's requirement from the branch managers' side; JD with a Peer delivery |
| K2 | "How do you handle credit when a complaint is fixed by people across a branch and the contact centre?" | JD | [generic] | Share credit by naming the work, not the people. Any story of your own comes from your chosen stories, not from this pack | A peer collaboration probe; JD |

Skeptic/Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| L1 | "You've told us you haven't presented above regional level. How would you present a month's complaints to leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment first: "I haven't presented to anyone above regional level." Then structure: lead with the one thing leaders must decide, then the figures that support it, in plain words. A plan, not a past | F6; JD |
| L2 | "Sixty seconds: why you over someone who has run a contact centre?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold then concede. Hold what the quote carries: six years in retail banking, the last three as a branch supervisor. Concede specifically: "I haven't worked in a contact centre." Do not fold on the core claim to restore harmony, and do not add claims to win the minute | The pressure form of D1; JD with a Pressure delivery |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What do your supervisors find hardest about escalations today?" | Peer-level curiosity about the coaching job, and a direct line to F7 |
| R3-2 | "When a complaint leaves your branch, what do you wish you saw that you don't now?" | Shows you will own the handover |
| R3-3 | "As the eight branches become five hubs, what do you most want members to experience when something goes wrong?" | Ties your role to what the panel care about without guessing which branches change |
| R3-4 | "What could a new person do in their first month that would genuinely help your branches?" | Reciprocity question for a peer panel |
| R3-5 | "Where do you expect the digital changes to land first in your branches?" | Links the 40% target to the people who will live with it |

---

## Values / principles cheat sheet (round 3, the values round)

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side, not the branch's | No quoted sentence carries a decision of this kind. Selection scaffold in H1; if none comes to mind, say so plainly, then say how you would decide |
| Plain Words | If a member needs it explained twice, the writing was wrong | F7 and "I handled the branch's formal complaints log and trained new tellers on our escalation script." The beat the sentence states is training tellers on the script. Answer slot: if you had a hand in the script's wording, say what and why; if you taught it as written, say so plainly |
| Neighbours, Not Numbers | Every branch is part of its town; people before counts | No quoted sentence carries a story. Selection scaffold in H3; if none comes to mind, say so plainly, then say how you would weigh them |
| Own the Fix | Whoever finds the problem keeps hold until it is solved | F1 and "I handled the branch's formal complaints log and trained new tellers on our escalation script." The beat the sentence states is handling the log. Anything beyond that is the answer slot in F1 |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope; the material says the branch's log, not the process |
| Handled regulated complaints | Inflated form of F5 | "I handled the branch's formal complaints log." The material does not say regulated |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope; the material says a monthly complaints spreadsheet |
| Built Excel reporting | Inflated form of F9 | F9's quote at its own scope; the material says spreadsheet |
| Coached supervisors on escalations | Inflated form of F7 | "I trained new tellers on our escalation script." |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F6 | The plain acknowledgment: "I haven't presented to anyone above regional level." No slot |

## Sources

Provided documents: the job description; the four published values, pasted from Ashgrove's values page; the recruiter's email on the three rounds; the July 2026 strategy brief as you summarised it in four points (the brief itself was not provided); your background as written in your message. No dossier was present.

Searches and fetches sent: none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values fix the four value names behind the cheat sheet |
| 2. `Ashgrove Credit Union interview process` | skipped | The recruiter's email fixes the three rounds, who runs each and what they hold; persona weights follow them |
| 3. `Ashgrove Credit Union strategy` | skipped | The 2026 brief, as summarised, fixes the CO and strategy questions |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names are assigned yet, so there is no query; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewer names, once assigned → an interviewer read, persona weights per panel member, and a reverse question tied to someone's own path
- Your own stories for the four values (C1, C2, C4, H1–H4) → each scaffold becomes a story map once you state the story outside this pack
- Your answers to the slots: what the spreadsheet counted and whether it was Excel (F3, F9, G1), whether rules governed the log (F5, G2), any coaching of supervisors (F7, C3, J2), any digital-team work (F8, E3) → those rows regenerate on your own words
- Your own pay, notice, location and reason-for-leaving answers (A3–A6) → quoted into the logistics rows
- The strategy brief itself → CO questions built on its wording rather than your four-point summary
- The recruiter's format for the 20-minute case, if there is one → one email, and the J-bank can be built to it
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → more on Ashgrove's strategy and loop, if you want it
- A `tuesday-dossier.md` from an earlier underwriting of this role, if you have one → verified evidence and prohibited-claims guardrails for this pack
