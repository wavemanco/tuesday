# Interview prep pack (loop mode): Engineering Manager, Larkfield Systems

For Yusuf. Three scheduled rounds, one shared fit snapshot, one mini-pack per round.

| Round | When | Who | Relationship | Format |
|---|---|---|---|---|
| 1 | Tuesday | Director of Engineering (the hiring manager, your would-be boss) | Hiring manager | 45 min |
| 2 | The Thursday after | Two staff engineers and a product manager (names not given) | Panel | 60 min |
| 3 | The following Monday | VP Engineering | Skip-level / executive | 30 min, described by the recruiter as "values and leadership philosophy" |

The loop is established by your own words (three rounds, who runs each), so persona weights follow those rounds and not an archetype. Company research was refused in this session (see Sources), so nothing here is company-specific beyond the role summary you pasted.

## How to use this pack

Personas are how a question is asked. Types are what it scores. Guidance is scaffolding for your own words, not a script.

| Tag | Name | What it tests |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the values and leadership approach asked about |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually yours |
| JD | Role / JD-driven | The stated responsibilities, gaps included |
| CO | Company and strategy knowledge | Thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

An answer slot is an instruction for the interview: say your own answer, from your own experience, or say plainly that the practice was not yours or did not exist, then return to what your own words carry.

**Highest-ROI prep in the pack: A1.** Your own sentence, "I've never managed managers and never owned a hardware-adjacent roadmap", is the objection every round will reach in some form (A1, F2, G3, H1). Rehearse it until it is boring.

## The fit snapshot (shared across all three rounds)

Requirements are quoted from the role summary in your message, or from the recruiter's description of round 3. Evidence is your own sentences only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role summary in your message | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material shows a team lead of 6, not two squads. Words, at that scope: "Three of my nine years in engineering were as a team lead of 6." Answer slot: the role says two squads, so expect a probe on spreading attention across two teams. If you have worked across more than one team, say how, in your own words; if not, say so plainly and stay with the team of 6 |
| F2 | "device-management services" and "industrial IoT" — role summary in your message | "currently at a payments company" — your message | low | [inferred] | discovery | Your material names your employer's sector, not the work. Answer slot: the role builds device-management services, so expect a probe on whether any of your services touched devices in the field. If any did, say which and what you did, in your own words; if none did, say so plainly and stay with your team's work |
| F3 | "own delivery" — role summary in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | presentation | The quote reaches delivery in other terms, and the words stay in it: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." The limit is the pack's observation: the material shows one quarter and one result, not delivery across two squads. Expect a probe on the 60% (C1, H2) |
| F4 | "hiring" (in "own delivery, hiring and growth for 11 engineers") — role summary in your message | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | The quote already speaks the requirement's language, with nothing inspected behind it. Lead with the loop in its own terms. Expect a probe on the count and on your part in the loop (E1, E2); the figure is "about 40", so keep it at that |
| F5 | "growth" (in "own delivery, hiring and growth for 11 engineers") — role summary in your message | none given | none | [grounded] | discovery | Your material says nothing about developing engineers. Answer slot: the role names growth for 11 engineers, so expect a probe. If you have helped anyone grow, say who and how, in your own words; if you have not, say so plainly and say what you would do first, as a plan and never as a past |
| F6 | "partner with hardware and product on roadmap" (the product half) — role summary in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | The quote touches roadmap tension but not who you worked with. Answer slot: if you worked with product on that quarter, say how; if the call was made without them, or product was not involved, say so plainly and stay with the quote |
| F7 | "partner with hardware and product on roadmap" (the hardware half) — role summary in your message | "I've never managed managers and never owned a hardware-adjacent roadmap" — your message | none | [grounded] | discovery | Your stated negative gives the words: "I've never owned a hardware-adjacent roadmap." Partnering is not owning, and your material says nothing either way about partnering with hardware. Answer slot: if you have worked alongside hardware or device teams in any way, say how; if not, say so plainly, then give what you would do in your first weeks, as a plan |
| F8 | "values and leadership philosophy" — the recruiter's description of round 3, in your message | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | low | [inferred] | discovery | Your material states no leadership philosophy. Answer slot: expect to be asked for yours; say it in your own words. If a story of yours illustrates it, tell it at the scope the quote gives and no wider |

No row is a gate: the role summary states no term such as location, pay or authorization, so none is surfaced here.

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 two squads | A3, B1, I1 |
| F2 device-management and industrial IoT | A2, B2, B3, I2 |
| F3 delivery | B1, B2, C1, C2 |
| F4 hiring | A4, E1, E2 |
| F5 growth | A4, G4 |
| F6 product roadmap | B1, D3 |
| F7 hardware roadmap | A1, B3, F2, I1 |
| F8 values and leadership philosophy | F1, G1, G2, G3 |

---

## Round 1: Director of Engineering, hiring manager (Tuesday, 45 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of what you have not done: hardware, scale, domain | High. The hiring-manager prior is Case/Strategist plus Skeptic, and your own two stated negatives (F7) are the obvious target | Say each limit once, plainly, then a plan; never bridge past what your sentences carry |
| Case/Strategist | Live problems from the role: planning across two squads, hardware dates | High. Same prior; the role is a planning role | Clarify, then objective, segments, approach, metrics, risks; think aloud |
| Data-Driven Prober | Reads your claims line by line, starts with the 60% | Medium. They are buying capability and will test your one headline number | Know how it was counted, or say plainly that you do not |

### Question bank

**Skeptic (A)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | The deepest rehearsal in the pack. Name the limit before it is extracted, in your own sentence: "I've never managed managers and never owned a hardware-adjacent roadmap." Then give your plan in your own words, what you would learn first and from whom, as a plan, not a past. Follow-up 1 likely: how would you close the hardware gap? Answer with the plan. Follow-up 2 likely: what if your first roadmap clash is hardware-driven? Say how you would decide with what you know and who you would lean on, and keep the hold at your quoted sentence; do not reach for adjacent claims. Concession wording: repeat the sentence, then the plan | F7 is the biggest stated gap and this question arrives in some form in every round; JD because it scores the stated roadmap-partnership line |
| A2 | "You're at a payments company today. Why industrial IoT, and why this role?" | JD | [grounded] "currently at a payments company" | Give your actual reason in your own words; the pack supplies none and your material states none. Keep it to what is true for you, and name one concrete thing about the role as the role summary describes it. If the pull is the hardware side, say so; if it is something else, say that | F2 is a discovery gap and motivation is the Skeptic's standard probe; JD because it tests fit with the stated domain |
| A3 | "You were a team lead of six. This is two squads and eleven engineers. What changes?" | JD | [grounded] "3 as a team lead of 6" | Say it at its scope: "Three of my nine years in engineering were as a team lead of 6." Answer slot: expect a probe on what changes with two squads. Say what you think changes, in your own words; if you have not worked across more than one team, say so plainly and stay with the team of 6 | F1 is the scale step the role asks for; JD because the numbers come from the role summary |
| A4 | "Delivery, hiring and growth for eleven engineers. Which of the three have you done least of?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Hiring is the one with a sentence behind it: "I run our hiring loop for backend roles." For growth your material has no sentence (F5), so the guidance is the F5 slot: if you have helped anyone grow, say who and how; if not, say so plainly and say what you would do first, as a plan. Name which of the three is thinnest for you, in your own words | F4 is closed and F5 is open, and a manager will ask which is which; JD because it scores the role's three verbs |

**Case/Strategist (B)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two squads, and a hardware release date that keeps moving. How do you plan the quarter?" | CASE | [generic] | Clarify first: what is fixed, what is the date's real cost, what product expects. Then objective, split between the squads, approach, metrics, risks. Challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | Built from the role's partner-with-hardware-and-product line (F6, F7) and the two-squad line (F1); `[generic]` because it is a pattern for the problem, not a fact about Larkfield |
| B2 | "A squad's device services keep paging people at night while product wants a new feature set. What do you do?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Structure it first: what the pages are, what the feature set is worth, what you would ask each side, and how you would decide. If they ask whether you have faced this, your words are the quote: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%." Do not add to it | F3 is your strongest sentence and this is where it is most likely to be tested; CASE because the interviewer asks it as a live decision |
| B3 | "What do you need to know before you commit to a roadmap with the hardware team?" | CASE | [generic] | Stem: what do you need to know first. Ask what is fixed on the hardware side, what slips and what cannot, who decides, and how product hears about it. The question makes no claim about your past | The hardware half of F7 is the gap, and asking good questions is the honest way to show approach without claiming experience |

**Data-Driven Prober (C)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 60% on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Answer in your own words on the four slots a figure raises. How it was counted. What it is sensitive to. The assumption behind it you would defend least. Which part was yours. If you do not know how it was counted, say so plainly. Keep the sentence's "after": do not turn it into "because of" | F3's headline number is the first thing a prober tests; EXP because it checks attribution |
| C2 | "Walk me through that reliability quarter: what was the pressure and what did you do?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Story-mapped on the beats the quote states: a reliability quarter, you pushed it through, against roadmap pressure, and the on-call burden dropped 60% afterwards. Answer slot: expect a probe on where the pressure came from and how it was resolved. Say it in your own words if you can; if a step was not yours, say so plainly and return to the quarter and its result | F3 is the one story with an outcome, so the interviewer will open it; EXP because it tests what was actually yours |

### Reverse questions for round 1

| Question | Why it lands |
|---|---|
| "What does a good first 90 days look like for someone coming into these two squads?" | Shows you plan around outcomes and gives you the success criteria you will be measured on |
| "Where do hardware and software roadmap commitments collide today, and who settles it?" | Goes straight at the gap in F7 as diligence, and shows you know the seam is where the role lives |
| "How do the two squads differ, and what is the hardest open decision on each?" | Signals you are already thinking about two teams, not one |
| "Where would you expect me to need the most support, given I haven't owned a hardware-adjacent roadmap?" | Volunteers your stated limit as a working question, which turns the Skeptic's probe into planning |
| "How do you and the VP split decisions about hiring into these squads?" | Maps who you answer to on the one requirement (F4) where you have real material |
| "What would make you say in a year that this hire was the right call?" | Gets the manager to state the scoring sheet |

---

## Round 2: Panel, two staff engineers and a product manager (the Thursday after, 60 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seams between your teams and theirs, credit, disagreement with equals | High. Staff engineers sit next to the squads, and the panel prior blends the top two personas of each member; names are not given, so no per-member split | Reciprocity: what you bring their work; seam principles, not a pretended seam |
| Data-Driven Prober | Technical depth on your claims, the hiring loop, the numbers | Medium. Staff engineers read claims for what stands behind them | Own your count and your part |
| Values/Behavioral | Scenario questions from the PM, who is outside engineering | Medium. A cross-functional member brings a behavioral register | Choose stories your sentences carry; otherwise a scaffold with the honest branch |

### Question bank

**Peer Evaluator (D)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our teams sit side by side. Where is the seam between you and us, and what happens when we disagree?" | VAL | [generic] | Propose seam principles, not a pretended seam: who decides what, how a disagreement gets named early, what you bring to their work. For the disagreement part, pick a real time you disagreed with a peer that needs a named stake and a relationship intact at the end; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The persona stem for the peer relationship; VAL because the scoring is collaboration behavior |
| D2 | "Tell me about a time you disagreed with a senior engineer about a technical call that affected delivery." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a position you held, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack supplies no story | Staff engineers weigh how a manager handles disagreement with senior technical people; no sentence of yours carries a story here, so it is a scaffold |
| D3 | "As the PM here, I will want features and you will want stability. How do we decide?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold only what the quote carries: "I pushed a reliability quarter through against roadmap pressure." Answer slot: if you worked it out with product, say how; if the call was made without them, or product was not part of it, say so plainly and stay with the quote. Then offer a principle for the decision and what you would need from the PM | F6 is a discovery gap and the PM is the one who will probe it; JD because it scores the role's partner-with-product line |
| D4 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a time work spanned teams and you shared credit, with a named person. If no such time comes to mind, say so plainly, then say how you would handle it, in principle | The persona stem for the peer relationship; no sentence of yours carries a story |

**Data-Driven Prober (E)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "You said about 40 interviews last year. How was that counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Answer in your own words on the four slots a figure raises. How it was counted: whether these were interviews you sat in or the loop's total. What it is sensitive to. The assumption behind it you would defend least. Which part was yours. If you do not know, say so plainly. Keep it at "about 40" | F4's number is the other figure on your record; EXP because it checks attribution |
| E2 | "Walk me through how you run the backend hiring loop." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Story-mapped on the beats the quote states: the loop, backend roles, about 40 interviews last year. Answer slot: the role says own hiring, so expect a probe on your part in it. Say what your part was, in your own words; if it was narrower than the loop, say so plainly and stay with the loop you run | F4 is closed but uninspected, so a staff engineer will open it; EXP because it tests what was actually yours |

**Values/Behavioral (F)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision with a named stake, a metric that pointed the other way, and a result you can describe. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The pack supplies no story | The persona stem for the values register; no sentence of yours carries a customer-versus-metric story |
| F2 | "When have you changed a roadmap because a customer or hardware constraint demanded it?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Your stated limit holds the hardware branch: "I've never owned a hardware-adjacent roadmap." Then, for the customer branch only, pick a real instance with a named stake. If no such time comes to mind, say so plainly, then give how you would handle it | The role's roadmap line (F7) makes this likely from the PM; VAL because it scores behavior under a constraint |

### Reverse questions for round 2

| Question | Why it lands |
|---|---|
| "What could a new manager do in their first month that would genuinely help your work?" | The reciprocity question for peers: it prices what you bring them |
| "Where does the squads' technical debt hurt you most?" | Shows you start from the engineers' pain |
| "How are trade-offs between hardware dates and software work made today, and where do you feel it?" | Goes at F7 as diligence, to the people who live in it |
| "When there is an on-call problem, how do product and the staff engineers agree what gives?" | Speaks to the PM and the engineers at once on the F3 theme |
| "What do you most want from the person in this role?" | Lets each panelist tell you what they would score |
| "How do the staff engineers fit into hiring for these squads?" | Ties to F4 and shows you see them as part of the loop |

---

## Round 3: VP Engineering, values and leadership philosophy (the following Monday, 30 min)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | Scenario and philosophy questions | High. The skip-level prior is Case plus Pressure, but the recruiter's own description, "values and leadership philosophy", moves Values to the top | Say your philosophy in your own words; map stories only where your sentences carry them |
| Pressure | Time-boxed, challenges motive and attribution | Medium. Executive prior; 30 minutes means short answers | Hold the position through two follow-ups, then concede specifically |
| Case/Strategist | One altitude-level problem | Medium. Executive prior, lowered by the values brief | Structure aloud; stay inside what you know |

The recruiter described this round as values-style, so a values round is detected. The values cheat sheet is not in this pack: it needs Larkfield's published values, which could not be fetched (see the upgrade menu).

### Question bank

**Values/Behavioral (G)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How would you describe your leadership philosophy?" | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Say your philosophy in your own words; the pack supplies none and your material states none. If a story of yours illustrates it, the only one the pack can map is your sentence: "I pushed a reliability quarter through against roadmap pressure." Use it only if it is true to what you believe, at that scope, and let the interviewer draw the inference | The recruiter's own description raises this question; F8 is a discovery gap |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a moment with a named stake, a truth you said plainly, and a relationship that held afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Your material does not show whether the hard truth landed anywhere, so the pack supplies no ending | The persona stem for the values register; no sentence of yours carries this story |
| G3 | "You haven't managed managers. What kind of manager do you want to become?" | VAL | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap" | Own the premise in your sentence: "I've never managed managers." Then say, in your own words, what you want to grow into and what you would do first, as a plan and never as a past. Hold the quote at its scope; do not reach for adjacent claims | F1 and F7 make this the VP's natural probe; VAL because it asks for a philosophy of growth, not a record |
| G4 | "How do you build a team people want to stay on?" | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" | Your material has a hiring sentence and nothing on retention or development (F5). Say what you believe in your own words. Answer slot: if you have helped anyone grow, say who and how; if you have not, say so plainly and say what you would do first, as a plan | The role names growth for 11 engineers (F5), so a VP on leadership philosophy will reach it |

**Pressure (H)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Sixty seconds: why you over a candidate who has run a hardware-adjacent roadmap?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Pause, restate, answer. Hold only what the quotes carry: "After I pushed a reliability quarter through against roadmap pressure, my team's on-call burden dropped 60%," and "I run our hiring loop for backend roles." Hold through two follow-ups by returning to those sentences, never by adding to them. Concede specifically and once: "I've never owned a hardware-adjacent roadmap." Never fold on the core claim to restore harmony | F7 is the obvious comparison a VP draws; JD because it tests fit against the stated roadmap line |
| H2 | "That 60%. How much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold your sentence, with its "after": you pushed the quarter through, and the drop followed. Answer slot: if the work was done by others, or the drop had other causes, say so plainly and say which part was yours, in your own words. Concede uncertainty explicitly and specifically; do not retreat from the quarter itself | Attribution is the Pressure stem; F3 is the figure it targets |

**Case/Strategist (I)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "You inherit two squads' roadmaps and a hardware team whose priorities you don't yet know. What are your first 30 days?" | CASE | [generic] | Clarify, then objective, listening plan, early decisions, metrics, risks. Name what you would not decide yet. The question needs no claim about your past, so the guidance makes none | Combines F1 and F7 at the VP's altitude; `[generic]` because it is a pattern for the problem |
| I2 | "Where should an industrial IoT device-management business put its engineering effort over the next year, reliability or features?" | CO | [generic] | Company research was refused, so nothing here is specific to Larkfield. Structure it: who the customers are, what a failure costs them, what the roadmap needs, how you would test the answer. Ask for the company's own view before offering yours | Strategy altitude is what a VP scores; `[generic]` until a strategy brief exists (see the upgrade menu) |

### Reverse questions for round 3

| Question | Why it lands |
|---|---|
| "What does the engineering org most need from this role in the first year?" | Asks the VP for the scoring sheet at their altitude |
| "How would you describe the leadership culture you are building across the company?" | Gets the VP's own philosophy to answer yours |
| "Where do hardware and software work best together today, and where worst?" | Frames F7 as diligence at the level that sets it |
| "How do you develop first-time managers here?" | Honest and relevant to your path; invites a development answer |
| "What would make this hire a clear success to you in twelve months?" | Closes the loop on the three rounds' expectations |
| "Which decision have you made recently that you would make differently?" | A peer-level question that signals you want candor from leadership |

---

## Prohibited claims (not coached)

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | Negative you stated, F7 | "I've never managed managers." Then a plan, as a plan |
| Has owned a hardware-adjacent roadmap | Negative you stated, F7 | "I've never owned a hardware-adjacent roadmap." Then a plan, as a plan |
| Has led two squads, or managed eleven engineers | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material shows a team lead of 6 |
| Owned delivery for two squads | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material shows one quarter and one result |
| Owned hiring outcomes for a team | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says the loop and the count, not who decides |

## Sources

Provided: the role summary, the three-round schedule and your background, all in your message.

Searches sent, all refused by the host (no result came back from any):

- `Larkfield Systems industrial IoT values` — refused
- `Larkfield Systems interview process engineering manager` — refused
- `Larkfield Systems industrial IoT device management strategy news` — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. It would have fed a values cheat sheet and named-value story mapping for round 3; neither is in this pack |
| 2. `{company} interview process {role family}` | unavailable | Every call was refused. It would have checked the loop; the persona weights rest on your own description of the three rounds |
| 3. `{company} strategy` / recent news | unavailable | Every call was refused. It would have grounded I2 and any strategy case; they are `[generic]` |
| 4. `{interviewer name} {company}` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `{role title}` JD | skipped | The role summary you pasted fixes the requirement rows and the JD-tagged questions |

No dossier was present.

## Upgrade menu

- The full job description text → rows F1 to F8 are quoted from a one-paragraph summary; the full text may add requirements (for example whether the role has leads reporting to it, which would change how A1 and G3 are asked) and would turn more rows from `[inferred]` to `[grounded]`
- Your CV → more of the fit snapshot quoted from your own sentences, and story maps for D2, D4, F1, G2 where there are only scaffolds now
- Answers to the answer slots, said outside a drill (for example how many of the "about 40 interviews" were yours, or whether any of your services touched devices) → rows F2, F4, F5, F6 regenerate with your own words
- Search access, or Larkfield's values page pasted in → a values cheat sheet for round 3, named values mapped to your stories
- A company strategy brief, or a deeper research pass → company-specific versions of I2 and B1
- The interviewers' names (the two staff engineers, the product manager, the Director, the VP) → an interviewer read per round, per-member persona weights for the panel, and reverse questions tied to their own paths
- The recruiter's guidance on what the panel will focus on, or any pre-declared prep task → coverage assumed from round-type priors would become real coverage; usually one email to the recruiter
- A `tuesday-dossier.md` from an earlier session → verified evidence and risks would sharpen the rehearsal; this pack does not need one
