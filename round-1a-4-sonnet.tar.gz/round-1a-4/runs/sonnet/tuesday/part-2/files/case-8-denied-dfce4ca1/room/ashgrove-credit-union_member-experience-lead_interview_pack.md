# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Loop mode: three scheduled rounds on 3 December 2026. Round 1 is the recruiter (30 minutes). Round 2 is the Head of Member Services, your future manager (45 minutes, mostly behavioural). Round 3 is a panel of two branch managers (60 minutes, including a 20-minute complaint-escalation case), which also scores against the four values. No interviewer has been named beyond role.

## How to use this pack

- Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.
- All proposed wording in this pack is pending your approval. Edit or drop anything you would not say.
- An answer slot is an instruction for the interview, not a question for you now. Meet it with either honest branch.
- Provenance labels: `[grounded]` rests on a document you supplied. `[inferred]` is derived, with the derivation named. `[generic]` is a pattern for the problem, with no claim about Ashgrove or about you.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the published values |
| EXP | Whether your own experience holds up under questions |
| JD | The stated responsibilities and requirements |
| CO | Knowledge of Ashgrove's strategy and competition |
| CASE | A live problem, structure and reasoning |

## Prep triage (24 November to 3 December)

| Order | Do this | Where |
|---|---|---|
| 1 | Rehearse aloud, with a timer, the contact-centre objection and the two stated gaps | B1, B2, B3 |
| 2 | Write your own answers to the logistics lines, in your own words | A3, A4, A5, A6 |
| 3 | Choose one story per value, or settle on saying plainly that none comes to mind | Values cheat sheet, C1 to C4 |
| 4 | Run the 20-minute case structure out loud twice | C5, C6 |
| 5 | Say the 90-second career arc until it is boring | A1 |

Everything else is insurance.

## Fit snapshot (shared across all three rounds; proposed wording pending your approval)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not the process across branches, and the words stay at that scope: "I handled the branch's formal complaints log." Answer slot: the JD's across-branches line makes a probe on what happened to a complaint after it was logged likely. If any later stage was yours, say which and what you did, in your own words; if the log was where your part ended, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "Never worked in a contact centre." Then how you would learn the centre, said as a plan and never as a past. Never a claim to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your material says you built the monthly spreadsheet and that your regional manager uses it, and does not show what it counted. Answer slot: the JD's reporting line makes a probe on what the sheet showed likely. Say what it showed, in your own words; if you do not know how a figure on it was counted, say so plainly |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your sentence is about new tellers and a script, and the words stay there: "I trained new tellers on our escalation script." Answer slot: if you have ever shown anyone beyond the new tellers how to handle an escalation, say who and what you did, in your own words; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent here, which is not an absence you have stated. Answer slot: if you have worked with a digital, app or online team on anything members do for themselves, say what and what part was yours, in your own words; if not, say so plainly and answer as a plan |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | No gap on length, but one line from you with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: six years in retail banking, the last three as a branch supervisor |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | discovery | Your sentence says formal, and does not say what governed the log; the pack does not assume it. Answer slot: the JD's complaints line makes a probe on what rules the complaints fell under likely. Say what governed the log, in your own words; if you do not know, or it was an internal practice only, say so plainly and stay with the log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would build the skill, said as a plan and never as a past. Whether Ashgrove counts regional level as senior is not in your material; reverse question R1.2 asks |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | presentation | Your sentence already reaches reporting in other terms. Say it in those terms: you built the monthly spreadsheet your regional manager uses. Name the tool only as it was; the sentence does not name one |

## Grounding brief (the strategy points you relayed from the July 2026 brief, plus the JD's own words)

| Item | Source | Where it is used | Provenance |
|---|---|---|---|
| Move 40% of member service to digital channels by 2028 | 2026 strategy brief, as you relayed it | B7, C10 | [grounded] |
| Consolidate eight branches into five hubs over 2027 | 2026 strategy brief, as you relayed it | C9, R3.3 | [grounded] |
| Launch a small-business lending product in Q1 2027 | 2026 strategy brief, as you relayed it | R1.4 | [grounded] |
| Main competitive pressure is app-only banks | 2026 strategy brief, as you relayed it | C10 | [grounded] |
| Member-owned, about 900 staff | JD | A2 | [grounded] |

The brief is four months old at today's date. Only these four points are in hand; nothing else about it is used.

## Round 1: recruiter screen (30 minutes)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly career walk-through, motivation, logistics | High: the recruiter's note gives 30 minutes with the recruiter, and a recruiter screen's prior is logistics and motivation | Pre-script the 90-second arc; treat casual questions as scored |
| Skeptic (light) | A knockout check on the contact-centre line and the complaints wording | Medium: F2 is a stated gap and the JD names the contact centre | Say the gap plainly first, then stop |

### Question bank (proposed wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your career so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Four beats, each from the sentences quoted: six years in retail banking; the last three as a branch supervisor; the branch's formal complaints log you handled; the monthly spreadsheet you built, and the new tellers you trained on the escalation script. Answer slot: your material shows nothing before the supervisor years; say what that stretch was, in your own words. Close on why this role, and stop inside 90 seconds | F6 answers the 4+ years line; EXP because the recruiter reads your account against the JD. Every later question is built on this arc |
| A2 | "Why Ashgrove, and why this role?" | CO | [grounded] | Your reasons are yours; the pack supplies none. Anchor in one published phrase, such as "Members First, Always" or "decide from the member's side of the counter", and in one line of the JD, which calls Ashgrove member-owned. Answer slot: say in your own words what drew you to a member-owned organisation, or to this role, and stop | The recruiter opens most screens on motivation; CO because it tests homework at Ashgrove's altitude |
| A3 | "What is your notice period?" | JD | [generic] | Give your actual notice period, in your own words | Logistics slot: a term of the job, so JD. You stated none, so none is supplied |
| A4 | "What salary are you looking for?" | JD | [generic] | Give your own number, or ask for the role's band first; the choice is yours. If the conversation turns to past pay, redirect to the role's band without giving a figure | Logistics slot, JD for the same reason. The pack supplies no figure |
| A5 | "Where are you based, and is the location workable?" | JD | [generic] | Give your actual location and what travel or commuting you can manage, in your own words | The JD scopes the role across branches and the contact centre, so location is a term of the job; JD |
| A6 | "Why are you looking to move?" | EXP | [generic] | Give your actual reason, in your own words, in two sentences. The pack supplies none | Logistics slot for the reason for leaving; EXP because it is about your own history. You stated no reason |
| A7 | "This role covers the contact centre as well as the branches. Where does your experience sit against that?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Say it plainly first, in your stated words: "Never worked in a contact centre." Then the adjacent fact at its own scope: the branch's formal complaints log you handled. Then a plan, never a past: learn how the centre receives and passes on complaints before proposing any change. Stop there; this is the same objection B1 rehearses in depth | F2 is the gap this question presses; JD because it scores a stated requirement, light Skeptic because it arrives as a knockout |
| A8 | "Tell me about the formal complaints log you handled." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1 and F7: the log, and that you handled it, which is all the quote states; tell it in your own words. Answer slot: the JD's complaints line makes a probe on what rules the complaints fell under likely. Say what governed the log; if you do not know, or it was an internal practice only, say so plainly and stay with the log | F1 and F7 are the evidence for the headline responsibility and the likeliest place to be probed; EXP because it tests what was yours |
| A9 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say it in the sentence's terms: you built the monthly complaints spreadsheet your regional manager uses. Answer slot: if the tool was Excel, say Excel and what you did in it, in your own words; if it was something else, say so plainly | F9 is a presentation row; F3 shares the same quote. JD because the requirement is stated, and a screen checks it in one line |

### Reverse questions for round 1 (proposed wording pending your approval)

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "What would you want the person in this role to have done by the end of their first three months" | Gives you the scoring frame for rounds 2 and 3 before they happen |
| R1.2 | "Who reads the monthly report, and at what level" | Settles whether F8's stated gap is a monthly duty or an occasional one |
| R1.3 | "Do the branches and the contact centre handle a complaint under one process today, or two" | Sizes F2 before you rehearse it |
| R1.4 | "Of the 2026 strategy moves, the 40% digital target, the eight-to-five branch hubs and the small-business lending launch in Q1 2027, which does this role touch first" | Shows you read the brief, and tells you which CO bank to weight |
| R1.5 | "Who is on the panel in round 3, and what will the case cover" | Interviewer names are unassigned; the answer can reweight the round 3 bank |

## Round 2: Head of Member Services, your future manager (45 minutes, mostly behavioural)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Probes the contact-centre and senior-presenting gaps | High: the hiring-manager prior is gap-derisking, and F2 and F8 are stated gaps | Rehearse the single predictable objection (B1) until it is boring |
| Values/Behavioral | Scenario and past-behaviour probes | High: the recruiter's email calls this round mostly behavioural | Map a story to a value only where a quoted sentence carries one; otherwise the honest branch |
| Case/Strategist | Live problems on coaching, reporting and digital | Medium: the hiring-manager prior, and the JD names coaching and digital journeys | Clarify, structure, answer; think aloud |
| Pressure (light) | A time-boxed challenge on why you | Low: no signal beyond the manager prior | Hold, then concede specifically |

### Question bank (proposed wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked in a contact centre, and this role owns it. Why should I take that risk?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | The highest-ROI prep in this pack. Concede first, in your stated words: "Never worked in a contact centre." Then hold the one position the quotes carry: you handled the branch's formal complaints log. Follow-up 1, how would you own what you have not seen: answer as a plan, not a past: learn how the centre receives, logs and passes on complaints before changing anything. Follow-up 2, that is learning on our time: concede specifically that you will be slower on the centre than on branches at first, and do not fold on the log. Follow-up 3, what if the centre's practice conflicts with the branches: return to the member's side of the counter. Limit, named before it is asked: your material shows one branch's log, not the centre; do not stretch the log to cover it | F2 is the biggest stated gap against a requirement the JD names; JD because it scores that requirement, and deepest rehearsal because it will be asked in some form |
| B2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Choose one of your two stated gaps and say it plainly, in those words, with its plan from B1 or B3. If neither is the weakest for you, say what is, in your own words; do not name a weakness you cannot back | F2 and F8 are the stated negatives; JD because it scores the requirements list, and a Skeptic stem |
| B3 | "Tell me about the most senior group you have presented to." | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Plain first, in your stated words: "I've never presented to anyone above regional level." The nearest your material carries is the spreadsheet your regional manager uses, which is a spreadsheet and not a presentation, so do not convert it. Answer slot: if you presented its findings to anyone in person, say to whom, in your own words; if it was sent and not presented, say so plainly. Then the plan: agree with this interviewer what the senior group needs from a monthly report, and keep the first one short and in plain words | F8 is a stated gap; open prompt on the JD's presenting line, so the honest branch is the main branch |
| B4 | "Tell me about a time you took a complaint all the way to a resolution." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt on the JD's end-to-end line and the published value "Own the Fix". The sentence carries only the log. Answer slot: if you followed any single complaint from logging to a settled outcome, tell it in your own words, what you did, what was yours, how it ended; if you handled the log but did not follow complaints through, say so plainly and describe how you handled the log. Selection test: a member, a point where it could have been left, and an end you can state | F1 is the evidence; VAL because Own the Fix is the value tested, EXP in delivery |
| B5 | "How would you coach a branch supervisor who is getting escalations wrong?" | CASE | [grounded] "trained new tellers on our escalation script" | A live problem, so no claim about your past. Structure: look at the actual cases first, then what the supervisor saw, then what you agree, then how you check later. Your own sentence stays at its scope: you trained new tellers on the escalation script. Answer slot as F4: if you have shown anyone beyond the tellers how to handle an escalation, say who and what you did; if not, say so plainly | F4 is the transferable row; CASE because the question sets a problem, JD because coaching is a stated duty |
| B6 | "What would the monthly complaints report you bring me contain?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | A design question: start from the JD's own two measures, volumes and resolution times, then one thing you would add and why, in your own words. Then your own sheet. Answer slot: say what it showed, in your own words; if you do not know how a figure on it was counted, say so plainly | F3 and F9 are the evidence; JD because the reporting line is stated, CASE in delivery |
| B7 | "Ashgrove wants 40% of member service on digital channels by 2028. How would you work with the digital team on complaints in self-service?" | CO | [grounded] | No claim about your past. Structure: what complaints show about where a journey fails, which complaints a member can settle alone and which need a person, how you hand the rest over without the member explaining twice. Answer slot as F5: if you have worked with a digital or online team, say what and what part was yours; if not, say so plainly and answer as a plan | F5 is silent in your material; CO because the 40% target is the brief's, JD because the line is stated |
| B8 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt from a persona stem. Selection test: a named stake, a moment you did not fold, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Your material carries no story for this question, so it is the scaffold case; VAL because it tests behaviour, not a requirement |
| B9 | "Sixty seconds: why you rather than someone who has run a contact centre?" | JD | [grounded] "I handled the branch's formal complaints log"; "I built the monthly complaints spreadsheet our regional manager uses"; "trained new tellers on our escalation script"; "Never worked in a contact centre" | Hold on the three quoted facts, each at its own scope, in that order. Concede the centre in your stated words: "Never worked in a contact centre." Hold through two follow-ups by returning to the three; never say what other candidates lack | Pressure stem on F2; the hold is only what F1, F3 and F4 carry |

### Reverse questions for round 2 (proposed wording pending your approval)

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "Which part of this role is the biggest gap in the team today" | Tells you what to lead with in the next two rounds |
| R2.2 | "Who would I present the monthly report to, and how often would they want me in the room" | Sizes F8 against a real calendar |
| R2.3 | "How do branches and the contact centre pass a complaint to each other now" | Sizes F2 and tests whether your B1 plan fits |
| R2.4 | "What support would I have on the contact-centre side in my first months" | Turns the stated gap into a plan you can check |
| R2.5 | "Who is the digital team's counterpart for self-service journeys, and how do they work with complaints today" | F5 is silent in your material; this gives you the starting point for B7 |

## Round 3: panel of two branch managers, including a 20-minute case (60 minutes; also scored against the four values)

### Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | One question per published value, scored against it | High: the recruiter says the panel scores against the four values | One story per value where a sentence carries one, the honest branch where none does |
| Case/Strategist | The 20-minute complaint-escalation case | High: stated in the recruiter's note | Clarify, objective, structure, action, measure, risks; think aloud |
| Peer Evaluator | Seam questions with the branches the role would coach | Medium: the panel are branch managers, and the JD has you coaching branch supervisors | Propose seam principles; never pretend to know the seam |
| Conversational | Rapport and "why a credit union" | Medium: two interviewers in a 60-minute panel | Pre-script the arc; treat casual questions as scored |
| Skeptic | Probes on the contact centre and presenting | Low: round 2 carries the weight, though the panel may repeat it | Reuse B1 and B3 |

### Question bank (proposed wording pending your approval)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] | Open prompt from the value "Members First, Always". No sentence of yours carries a story here, so use the test: a member whose position differed from the easier option, what you chose, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | VAL on the first published value; scaffold because none of your quoted sentences carries this |
| C2 | "Tell me about something you wrote or explained that someone needed to hear twice. What did you change?" | VAL | [grounded] | Open prompt from the value "Plain Words", whose test is that if a member needs it explained twice, we wrote it wrong. Use the test: the thing, who needed it twice, and the plain version you made instead. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | VAL on the second value; scaffold, as no quoted sentence carries it |
| C3 | "Tell me about the branch you worked in and how it fits its town." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | The sentence states only that you spent three years as a branch supervisor. Answer slot: if the town shaped how you handled any member's complaint, say how, in your own words; if it did not, say so plainly and stay with the branch you worked in. Do not add detail about the town you did not give | VAL on "Neighbours, Not Numbers"; F6 gives only the role and the length |
| C4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt from the value "Own the Fix". The sentence carries only the log you handled. Answer slot: if you followed any problem from the log to its end, tell it in your own words, what you did and what was yours; if you handled the log and did not follow problems through, say so plainly and describe how you handled the log | VAL on the fourth value; F1 is the nearest evidence, and B4 rehearses the same ground |
| C5 | "A member has complained three times about the same fee. The branch says it has answered, the contact centre says it was passed back, and the member says they will move to an app-only bank. You have 20 minutes: what do you do" | CASE | [generic] | A pattern for the problem, with no claim about your past. Clarify first: what the member asked for each time, what was said, which time limits apply. Objective: the member's side of the counter. Then one named owner, so nobody passes it again; a reply in plain words; the fix to whatever caused three contacts; and what you would measure. Challenge one premise respectfully. Rough clock: about 3 minutes to clarify, 3 to structure, 10 to recommend, 4 for risks | The recruiter's note says the case is a complaint escalation; `[generic]` because the real case is not known and this is only the shape of one |
| C6 | "The supervisor says the contact centre dropped it, and the contact centre says the branch did. Whose complaint is it" | CASE | [grounded] | Hold the published position, "whoever finds the problem keeps hold of it until it is solved", through two follow-ups. Concede specifically that you do not yet know what happened and would read the record before assigning blame. Never name a fault from a story you cannot back | Pressure on the case, tied to "Own the Fix"; CASE because it sets a live problem |
| C7 | "Where is the seam between your role and a branch manager's, and what happens when we disagree about an escalation" | JD | [generic] | Propose principles, not a seam you cannot know: one owner and one thread for the member, the branch keeps the relationship, the role keeps the process and the report. On disagreement: go back to the record and to what the member asked for. No claim about your past | Peer Evaluator stem; JD because coaching branch supervisors is stated |
| C8 | "A branch supervisor says your escalation process adds work to a short-staffed branch. What do you say" | CASE | [generic] | Acknowledge the load first, then ask what the process costs in time at the branch, and what you would change. No claim about your past | Peer pressure; a live problem on the JD's coaching line |
| C9 | "Eight branches are becoming five hubs over 2027. What does that mean for complaints, and for members in a town that loses its branch" | CO | [grounded] | No claim about your past. Clarify first what changes and when, without asserting facts the brief does not give. Then segment: members whose branch closes, supervisors whose routines change, the contact centre routing. Measure volumes and resolution times by area. Risk: a town reading the change as numbers over neighbours, which the value "Neighbours, Not Numbers" names | The consolidation is the brief's; CO because it tests altitude, CASE in delivery |
| C10 | "Why would a member stay with Ashgrove rather than an app-only bank" | CO | [grounded] | No claim about your past. The brief names app-only banks as the main competitive pressure and sets a 40% digital target by 2028, so a member who can leave in an app is the one a good complaint outcome keeps. Tie it to one value in its own words | CO on the brief's competition point; the panel are branch managers, so the branch-side answer matters |
| C11 | "Which of our four values would be hardest for you to live in this role" | VAL | [grounded] | Choose one honestly. Say what makes it hard and what you would do about it. Your material carries no story for Members First or Plain Words, so do not reach for one. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The Skeptic version of the values round: it tests self-assessment |

### Reverse questions for round 3 (proposed wording pending your approval)

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "Which escalations take your branch longest to settle today" | Shows what the coaching agenda would start with |
| R3.2 | "What would you most want a new person in this role to do for your branch in the first month" | Reciprocity: it puts what you bring ahead of what you need |
| R3.3 | "When branches merge into hubs, who decides how complaints are handled in the new hub" | Tied to the consolidation in the brief |
| R3.4 | "What do your supervisors say about the escalation script today" | Opens the one area your own sentence touches, without claiming more |
| R3.5 | "Which of the four values is tested hardest in your branch day to day" | Turns the values round into their stories, which you can then answer against |

## Values cheat sheet (round 3; proposed wording pending your approval)

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold: pick a time you chose what was right for a member over what was easier for the branch. It needs the member's position, the easier option, what you did and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Plain Words | If a member needs it explained twice, the wording was wrong | Selection scaffold: pick something you wrote or explained that needed saying twice, and the plain version you made. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it |
| Neighbours, Not Numbers | Every branch is part of its town | F6: "6 years in retail banking, the last 3 as a branch supervisor". Answer slot: if the town shaped how you handled any member's complaint, say how; if not, say so plainly and stay with the branch you worked in |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log". Answer slot: if you followed any problem from the log to its end, tell it; if you handled the log and did not follow problems through, say so plainly and describe how you handled the log |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches" | A8, B4, C4, C5, C6 |
| "across branches and the contact centre" | A7, B1, B2, B9 |
| "report monthly on complaint volumes and resolution times" | A9, B6 |
| "coach branch supervisors on escalations" | B5, C7, C8 |
| "work with digital teams on self-service journeys" | B7, C10 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | A8 |
| "confident presenting to senior leaders" | B2, B3 |
| "comfortable with Excel reporting" | A9, B6 |

## Prohibited claims (what this pack will not coach)

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says one branch's log, not the process across branches. The slots stay inside the log |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says new tellers and a script |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment: "Never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: your material says formal, and does not say what governed the log |
| Reported complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says you built the monthly spreadsheet, not what it showed |
| Built the reporting in Excel | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. The tool is named only if you name it |

## Sources

Provided documents: the JD; the Ashgrove values text you copied on 24 November 2026 from ashgrovecu.org/about/values; the recruiter's email on the process; the four points you relayed from the 2026 strategy brief (July 2026); your background message. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the cheat sheet: the values text pasted this morning already supplies the four names and their definitions |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email names all three sessions and who runs each, which fixes the loop and the persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO bank: the four points relayed from the July 2026 brief already supply the priorities and the competitive frame |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer beyond a role is assigned, so there was no name to query; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Interviewers' names, once assigned → an interviewer read, persona weights per panel member, and a reverse question tied to their own path
- A CV or dated list of roles → some F rows' evidence cells move from your message to your CV, and the A1 arc gains the years before the supervisor role
- Your own answers to the answer slots on F1, F3, F4, F5 and F7 → those rows move from `discovery` or `transferability` to `presentation` or `none`, and the banks gain story-mapped answers in place of slots
- The recruiter's focus areas for the 20-minute case → C5 and C6 move from `[generic]` to `[grounded]`
- The full strategy brief → CO rows beyond the four points you relayed
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes): role-family loop reports and recent organisation context → the case and the CO bank
- A `tuesday-dossier.md` from an earlier underwriting pass, if you have one → verified evidence and a named top objection in place of the ones inferred here
