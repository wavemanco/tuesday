# Interview prep pack: Product Operations Manager, Stripe

Round: final round. Interviewer(s): not given. Relationship to you: not given, so persona weights are flat (see section 5). Built from your message alone: no JD, no CV, no research (searches were refused, see section 9).

## 1. How to use this pack

Personas describe how a question is asked; types describe what is being scored. Guidance is scaffolding, not a script: where the pack has no sentence of yours to build on, it gives you selection criteria instead of an answer, and every scaffold ends with the honest branch (say so plainly if nothing comes to mind, then give the nearest thing your material does carry, or how you would handle it).

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows values, not generic virtue |
| EXP | Whether your experience claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge (none in this pack: see section 9) |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: `[grounded]` traceable to something you supplied or research cited in Sources; `[inferred]` derived from an adjacent source; `[generic]` a role-family pattern with no claim about Stripe or about you. Everything in this pack is `[generic]` because nothing about you or Stripe could be supplied or fetched yet.

## 2. Fit snapshot (worksheet version)

You gave no background, so this is a worksheet: the requirements are role-family patterns written without a posting, not Stripe's own words, and every evidence cell is empty until you fill it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinate launches and programs across several functions (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a program you coordinated, with the functions involved and your own part named. Selection scaffold: pick one program where you can say which pieces were yours and which were others; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Run or improve a planning and review cadence for product teams (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a recurring review or planning process you ran or changed, and what it replaced. Selection scaffold: pick a process you shaped rather than attended; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Use metrics to diagnose product and launch performance (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a metric you used to make a call, with how it was counted and its weakest assumption. Selection scaffold: pick a number you can explain end to end; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Judge which processes and tools help and which are overhead (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a mechanism you introduced or removed and what you saw change. Selection scaffold: pick one you added or cut; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Influence peers and partner teams without direct authority (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a disagreement with another team and how it resolved. Selection scaffold: pick one where your position and theirs were both real; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F6 | Communicate status and risk to senior leaders (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a message or review you gave to senior people and what it changed. Selection scaffold: pick one where the news was unwelcome; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Keep customer outcomes in view when internal metrics point elsewhere (role-family, no JD) | none given | none | [generic] | discovery | Strong evidence is a decision where you weighed a customer outcome against an internal number. Selection scaffold: pick one where the trade-off was real; if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

No gate rows (location, work authorization, schedule, pay) are listed, because no posting or message of yours states any. A posting would show whether there are any.

## 3. Requirement coverage

| Requirement | Questions covering it |
|---|---|
| F1 Cross-functional programs and launches | A1, B3, E1 |
| F2 Planning and review cadence | A3, A4 |
| F3 Metrics and diagnosis | A2, D1, D2, D3 |
| F4 Process and tooling judgment | A4 |
| F5 Influence without authority | C1, E1, E2, E3 |
| F6 Leadership communication | A1, C1, F1 |
| F7 Customer outcomes vs internal metrics | C2 |
| Motivation and biography (not a requirement) | B2, G1, G2 |

## 4. Highest-ROI prep

B3 is this pack's provisional highest-ROI question: it asks what part of a cross-team program was actually yours, the attribution probe that applies to any coordination role. It is provisional because no CV was supplied; with one, the pack names the objection your material itself exposes.

## 5. Persona table

Archetype fallback: Generic (screen, hiring manager, panel), because no loop source was read and the relationship to your interviewer(s) is unknown. Weights are flat, and that makes this pack noticeably weaker than one built with the round structure.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live problems set in the role: launch readiness, metric drops, planning design | Flat. The role family is operations-heavy, so cases are carried as the deepest bank | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| B. Skeptic | Quiet probing of gaps, motivation, and what was actually yours | Flat. Any final round can include it; depth set by B3 | Rehearse the most predictable objection until it is boring; say limits plainly |
| C. Values/Behavioral | Scenario probes: unpopular truths, customer vs metric | Flat. No published values were read, so themes come from standard prompts, not Stripe's own wording | Choose stories only you can stand behind; use I for contribution, we for context |
| D. Data-Driven Prober | Denominators, assumptions, how numbers were counted | Flat. Applies wherever a metric is mentioned | Know what you can and cannot say about how a number was counted; name the weakest assumption first |
| E. Peer Evaluator | Seam between product ops and product teams, credit, disagreement | Flat. Likelier if a peer sits in the loop; unknown | Reciprocity: what you bring their team; propose seam principles, not a claimed seam |
| F. Pressure | Time-boxed, devil's advocate | Flat. Lower depth since nothing suggests a stress format | Pause, restate, hold through two follow-ups, concede specifically |
| G. Conversational | Open chat that is still scored | Flat. Lower depth, but the biography question comes in any round | A 90-second arc, each sentence one you can defend |

## 6. Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product team is two weeks from launch and three functions disagree on whether it is ready. What do you need to know first, and how do you proceed?" | CASE | [generic] | Structure aloud: what readiness means and who decides; what each function is actually worried about; what evidence would settle it; options (ship, ship narrower, delay) with the cost of each; what you would tell leadership and when. Challenge one premise, for example whether all three disagree about the same thing. The question asks nothing about your past | Covers F1 and F6 as a live problem; CASE because it scores structure |
| A2 | "An adoption metric for a shipped feature dropped 20 percent week over week. Diagnose it." | CASE | [generic] | Check definition and instrumentation first, then segment (who, where, which cohort), then what shipped or changed around the date, then outside effects; say what you would rule out cheaply before escalating. State what you would not conclude from one week | Covers F3; the persona stem for the Case bank |
| A3 | "Sketch a quarterly planning process for several product teams that do not share a roadmap format. What do you need to know first?" | CASE | [generic] | Ask about the decisions planning must feed and who consumes it; propose the lightest common shape that serves those decisions; name what you would leave to each team; say how you would tell it is working after one cycle | Covers F2; tests whether you start from purpose rather than a template |
| A4 | "How would you decide which operating mechanisms a product org needs, such as reviews, dashboards or launch checklists, and which are overhead?" | JD | [generic] | A criteria answer: what decision does it serve, who reads it, what happens if it disappears, what does it cost the teams. Offer one test you would apply and how you would retire a mechanism. No claim about your past is needed | Covers F2 and F4; JD because it scores the role-family requirement |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Pick the F-row where your own material is thinnest, say that plainly, and give the first thirty days as a plan, said as a plan and never as a past. Scaffold: if no weakness comes to mind, say so, then name the area where you would ask the most questions first | Fixed objection for any candidate; sharpens once a CV exists |
| B2 | "Why product operations, why Stripe, why now?" | EXP | [generic] | Three reasons in your own words, each one you can support with something real and checkable. Anything uncertain, say it is uncertain. Do not use Stripe facts you have not read yourself | Motivation consistency is scored in any round; EXP because it tests your own story |
| B3 | "Pick a cross-team program you were part of. Which part was actually yours, and which part would the team say someone else owned?" | EXP | [generic] | Provisional highest-ROI. Choose a program where you can separate verbs: what you did, what you shaped with others, what others owned. Concede the last category specifically; do not enlarge your part. Hold through two follow-ups by returning to what you did. Scaffold: if no program fits, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Attribution probes exist for F1; this is the likeliest place a coordinator's story is tested |

### C. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Choose a time with a named stake, a moment you did not soften it, and a relationship intact afterwards. Beats: context, what you said, how it landed, what you would do again. Scaffold: if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F5 and F6; the standard stem for a values round |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Choose a decision where the trade-off was real and you can name the number and the customer outcome in your own words. Scaffold: if none comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Covers F7 |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick a metric you have used to run a program. Walk me through how that number was counted." | EXP | [generic] | Say the definition, the source, and the denominator in your own words. If you do not know how part of it was counted, say that plainly. Do not supply a method you cannot repeat under a second question | Covers F3; probers go two levels deeper than the answer |
| D2 | "Which assumption behind that number would you defend least?" | EXP | [generic] | Name it before they do, in your own words; say what would change if it were wrong. Scaffold: if you cannot name one, say so, then say how you would find out | Weakest-assumption move; covers F3 |
| D3 | "You are handed a dashboard of thirty product metrics. How do you decide which five go to leadership?" | CASE | [generic] | Start from the decisions leadership makes, then pick metrics that move those decisions, then say what you would drop and how you would show that you dropped it | Covers F3 as a live problem |

### E. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Where is the seam between product operations and product management, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claiming to know the seam: who owns the decision, who owns the mechanism, how disagreement escalates. Say what you would ask a peer in week one | Covers F1 and F5 |
| E2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Say how you describe shared work, we for context and I for your contribution. Scaffold: pick one example where the split mattered; if none comes to mind, say so plainly, then say how you would handle it | Covers F5 |
| E3 | "What would you need from me in your first month?" | JD | [generic] | A reciprocity answer: two or three things you need, and what you would bring in return. Keep it about working together, not about gaps | Covers F5 |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then two points you can support from your own material, never a claim about your past you cannot back. Hold through two follow-ups; concede what you do not yet know, specifically | Covers F6 delivery under time pressure |
| F2 | "Pick the result you are proudest of. How much of it was actually you?" | EXP | [generic] | Hold-then-concede: say what you did, concede others' parts specifically, and do not fold on what was yours. Scaffold: if no result comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Attribution under pressure; pairs with B3 |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: each step one sentence you can defend, ending on why this role. Do not add titles, scope or numbers you have not confirmed in your own CV | Asked in any round; casual but scored |
| G2 | "What have you been learning lately that you would bring here?" | JD | [generic] | One real thing, in your own words, with what you did with it. Scaffold: if nothing comes to mind, say so plainly, then name what you plan to learn first | Casual register, still scored |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | How does the team decide what product operations works on and what product teams do themselves? | Shows you are thinking about the seam |
| R2 | What would a strong first ninety days look like, and how would you tell at day ninety? | Turns the role into something concrete |
| R3 | Which operating mechanism here do people value most, and which would they drop if they could? | Shows you look for what helps, not what exists |
| R4 | Where do launches or planning cycles most often go sideways today? | Points at the real problem you would be hired for |
| R5 | How is the work of this role measured, and by whom? | Clarifies what success is |
| R6 | What has changed in how the team works in the last year, and what is still being figured out? | Invites a candid answer |

## 8. Prohibited claims

None listed. Nothing about your past was supplied, so there is no quoted sentence to stretch and no stated negative to protect. This pack coaches no claim about your experience: any claim you make in answer must be one you can stand behind.

## 9. Sources

Provided documents: none.

Searches sent: all refused, none returned a result.

| Query | Outcome |
|---|---|
| Stripe operating principles values | refused |
| Stripe interview process product operations manager | refused |
| Stripe strategy news 2026 | refused |
| Stripe Product Operations Manager job description | refused |

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Would have fixed value names and a values cheat sheet; none is included |
| 2. Stripe interview process, product operations | unavailable | Would have set persona weights and the loop; weights are flat instead |
| 3. Stripe strategy and recent news | unavailable | Would have grounded CO and CASE questions; none is Stripe-specific |
| 4. Interviewer name | n/a | No name was given |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the role-family requirements into quoted, inferred ones |

## 10. Upgrade menu

- The job description text → the seven `[generic]` requirement rows become `[grounded]`, JD questions get a scoring sheet, and any gates it states (location, work authorization, schedule) become visible
- Your CV or a short background → evidence cells fill, story scaffolds become story-mapped answers, and B3's objection is replaced by the one your material exposes
- The names and roles of who you meet, and whether the final is one conversation or several sessions → persona weights, an interviewer read, a reverse question tied to their path, and per-session mini-packs
- The recruiter's prep email → coverage of any announced focus areas or a deliverable
- Stripe's values page or loop description pasted in, or search access → values cheat sheet and loop-based persona weights
- A `tuesday-dossier.md`, if you have one → verified evidence and prohibited claims to build on
