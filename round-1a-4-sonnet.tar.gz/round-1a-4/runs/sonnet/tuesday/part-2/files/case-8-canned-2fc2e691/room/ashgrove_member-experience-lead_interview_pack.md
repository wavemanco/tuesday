# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop (three scheduled rounds, all on 3 December 2026; this pack was built on 24 November 2026).

| Round | Who | Length | What the recruiter's email says it holds |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Screen |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | "mostly behavioural" |
| 3 | A panel of two branch managers | 60 minutes | A 20-minute case on a complaint escalation; also the values round, scored against the four values |

No interviewer names are assigned yet, so there is no interviewer read. No assessment was provided, so there is no delivery-coaching section. No deliverable was announced, so there is no deliverable build; the Round 3 case is covered by bank G.

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your CV claims survive scrutiny, and what was actually you |
| JD | A stated responsibility or requirement in the job description |
| CO | Whether you understand the company's strategy and position |
| CASE | A live problem set in the role, scored on structure and reasoning |

An **answer slot** is an instruction for the interview, not a question for this chat. It gives two honest branches: say what you did, in your own words, or say plainly that the step was not yours or never existed, then return to what your sentences do say. Both branches count as a good answer.

Labels in the Provenance column: `[grounded]` traces to something you gave me; `[inferred]` is derived from an adjacent source; `[generic]` is a pattern for the role with no claim about you or Ashgrove.

## Prep triage

You have nine days. You gave me no hours, so this is an order, not a schedule.

| Priority | Do this | Why first | IDs |
|---|---|---|---|
| 1 | Say your two stated gaps aloud until they are boring: the contact centre and presenting above regional level. Say the plan after each | They come up in all three rounds, and the contact-centre one is the pack's highest-ROI rehearsal | B1, C1, C2, D3 |
| 2 | Practise the Round 3 case structure on all four example cases | It is 20 of the 60 minutes, in front of two people | G1 to G4 |
| 3 | Decide which real event, if any, fits each of the four values. Where none does, rehearse the honest branch | The panel scores against the values | F1 to F4, cheat sheet |
| 4 | Work out what your complaints log and your monthly spreadsheet actually held | Seven answer slots turn on those facts | A1, B2, B3, C3, C4 |
| 5 | Read the strategy facts once | Two of the case questions use them | D2, F3, G4 |

Everything else is insurance.

## Fit snapshot

Requirements are quoted from the job description you pasted. Evidence is your own sentences, quoted exactly. The JD states no pay, location, schedule, authorisation or credential term, so there are no gate rows. The experience requirement ("4+ years") is graded as ordinary evidence, not as a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process across branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what happened to a complaint beyond the log likely. If any complaint was yours to follow past the log, say which step and what part was yours, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." Then how you would learn it, said as a plan and never as a past. No bridge from branch work to contact-centre work, and nothing added to make the gap feel smaller |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence says a monthly complaints spreadsheet you built and your regional manager uses; it does not say what the sheet held. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD's reporting line makes a probe on what the sheet held likely. Say what it held, in your own words; if it held less than the JD's line describes, say so plainly and stay with what it held |
| F4 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and an escalation script, not supervisors, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's coaching line makes a probe on whether you have supported a supervisor through an escalation likely. If you did, say what happened and what part was yours, in your own words; if not, or it was not yours, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent, which is not an absence. Answer slot: the JD names this work, so expect a probe. If you have worked with a digital team on anything members do for themselves, say what it was and what part was yours, in your own words; if you have not, say so plainly, then say what you would ask a digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | Your sentence reaches the requirement in banking terms, not the JD's. Say it as written: "I have six years in retail banking, the last three as a branch supervisor." Whether that counts as customer operations is the interviewer's reading, not yours to assert |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | discovery | Your sentence says a formal log and says nothing about which rules applied. Words: "I handled the branch's formal complaints log." Answer slot: the JD's line makes a probe likely. If any rules or timelines applied to the complaints in that log, say which and what part of them was yours; if none did, or none were yours, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan. Your sentence does not say you presented at regional level, so do not claim it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | Your sentence says a spreadsheet you built, not which tool or what it did. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names a specific tool, so expect a probe. Name the tool it was built in, in your own words; if you are unsure, or it was a different tool, say so plainly and stay with the spreadsheet you built |

## Grounding brief

Your summary of the July 2026 strategy brief, plus the JD. This pack rests on your summary, not on the brief itself.

| Item | What it says, as you gave it to me | Provenance | Where it appears in this pack |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] | D2, reverse questions R2.3 |
| Branch hubs | "consolidate eight branches into five hubs over 2027" | [grounded] | F3, G4, reverse questions R1.1, R3.2 |
| Small-business lending | "launch a small-business lending product in Q1 2027" | [grounded] | Not used in a question; available as a CO topic if raised |
| Competition | "the main competitive pressure is app-only banks" | [grounded] | D2 |
| The institution | "member-owned, about 900 staff" — JD | [grounded] | A2 |

---

## Round 1: the recruiter, 30 minutes

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; logistics and motivation asked casually | Top. A recruiter screen starts from this persona, and the logistics here (pay, notice, location, reason for leaving) are asked in a friendly register but still scored | A pre-scripted 90-second arc built only from your own sentences; treat every casual question as scored |
| Skeptic (light) | A quiet knockout check on the JD's headline items | Light. Recruiters check the obvious gaps; yours are the contact centre and Excel, both visible on the JD | Say a stated gap plainly once, add the plan, stop talking |

Case, Pressure and Peer styles are unlikely in a 30-minute recruiter call, so this round has no bank for them.

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log"; "trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F6, F1, F4 and F3. A 90-second arc built only from those sentences, in order: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on the escalation script; you built the monthly complaints spreadsheet your regional manager uses. Keep each at its own verb: handled, trained, built. Put nothing between them that your sentences do not carry. Close on why this role, in your own words | The opening question of almost every screen, and the first place the F2 and F8 gaps can be heard in how you phrase things. EXP because it tests what you did; Conversational because it is asked casually and scored for economy |
| A2 | "What drew you to Ashgrove?" | CO | [grounded] | Makes no claim about your past. Pick the one published value you can speak to from your own work (Members First, Always; Plain Words; Neighbours, Not Numbers; Own the Fix) and say why in your own words, plus one line on being member-owned. Do not recite all four; a value you cannot tie to something you did is better left out | A motivation-consistency check. CO because it tests homework; the values page and the JD are the sources |
| A3 | "What's prompting a move now?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words. If part of it concerns the role you are leaving, say that part once and plainly, then say what draws you to this one | Reason for leaving is a standing recruiter question. EXP because it tests consistency of your story |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, as your contract states it | A standing recruiter question about the job's start terms; JD because it scores fit with the role's timing |
| A5 | "What are you looking for salary-wise?" | JD | [generic] | Logistics slot, a choice between two options, neither supplying a figure: give your own number, or ask for the role's band first and respond to it. If asked what you earn now, you may decline and redirect to what you are looking for in this role | A standing recruiter question about the job's pay |
| A6 | "Where are you based, and how do you feel about moving between sites?" | JD | [generic] | Logistics slot: state your actual location and any limits on getting to different sites, in your own words. The JD says the role works across branches and the contact centre; that is why site movement is likely to be asked | A standing recruiter question about location; JD because the posting spans several sites |

### Bank B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role covers the contact centre as well as the branches. What's your experience on that side?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment first, nothing before it: "I've never worked in a contact centre." Then a plan, said as a plan: what you would do in your first weeks to learn how the contact centre takes in a complaint and hands it on. No bridge from branch work; your material carries no contact-centre sentence, and a bridge invented live is the one that gets caught. Stop after the plan | F2 is a gap you stated, and a screen is where it is checked as a knockout. JD because it is the second half of the headline requirement |
| B2 | "The role handles regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F7 at its own scope: "I handled the branch's formal complaints log." Answer slot: if any rules or timelines applied to the complaints in that log, say which and what part of them was yours; if none did, or none were yours, say so plainly and stay with the log | F7 is where the JD's regulated-complaints line meets thin evidence. JD because it scores a stated requirement |
| B3 | "How comfortable are you with Excel reporting?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the spreadsheet is and who uses it, as quoted: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: name the tool it was built in, in your own words; if you are unsure, or it was a different tool, say so plainly and stay with the spreadsheet you built | F9 is a JD requirement with one sentence behind it. JD because it scores a stated requirement |

### Reverse questions: Round 1

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Where will this role sit day to day once the 2027 hub plan lands?" | Shows you read the strategy facts, and it settles the location question from your side (A6) |
| R1.2 | "Which complaint rules does the role's monthly reporting have to follow?" | Only the employer can answer it; it treats "regulated" as a real requirement and tells you whether the F7 answer matters |
| R1.3 | "What does the Head of Member Services most need from this hire in the first 90 days?" | Prepares Round 2 and gives you the manager's priorities before you meet them |
| R1.4 | "Is there anything in my background you would like me to address before I meet the Head of Member Services?" | Brings the contact-centre concern into the open early, where you can use the plain acknowledgment on your terms |

---

## Round 2: the Head of Member Services, 45 minutes

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of the contact-centre gap, end-to-end ownership and the spreadsheet | Top. A hiring manager is derisking gaps, and the two stated gaps are the obvious ones | Rehearse the single most predictable objection until it is boring; hold, then concede plainly |
| Values / Behavioral | "Tell me about a time" scenarios | High. The recruiter's email says this round is "mostly behavioural" | "We" for context, "I" for contribution; choose real stories; where none exists, use the honest branch |
| Case / Strategist | A live problem from the manager's own roadmap: reporting, digital shift | Mid. A manager who would own this hire's output will test how you think about it | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have spent the last three years as a branch supervisor and have not worked in a contact centre. How do you take on that side of the role?" | JD | [grounded] "Never worked in a contact centre"; "the last 3 as a branch supervisor"; "I handled the branch's formal complaints log" | **The highest-ROI prep in this pack.** Level 1: the plain words, nothing before them: "I've never worked in a contact centre." Level 2, likely follow-up "So why you?": return to what your sentences carry, at their own scope: "I handled the branch's formal complaints log." Level 3, likely follow-up "What would you do in month one?": your plan, as a plan: what you would ask to see, who you would sit with, what you would want to learn first about how the contact centre takes in and hands on a complaint. Hold through both follow-ups by returning to the log and the plan, never by adding to either; concede plainly that this is the part you would be learning | This objection will be asked in some form, here or in Round 3, and F2 is a stated gap. JD because it scores the requirement; Skeptic delivery because it probes the gap |
| C2 | "Which part of this job description would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Pick one of the two gaps you stated yourself and name it plainly: "I've never worked in a contact centre" or "I've never presented to anyone above regional level." Then say what you would do about it, as a plan. Do not answer with a strength dressed as a weakness | F2 and F8 are the two stated gaps; the interviewer asks this to see whether your self-assessment matches your material |
| C3 | "The role is to own the complaints process end to end. What have you owned?" | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F1 at its own scope: "I handled the branch's formal complaints log." Answer slot: if any complaint was yours to follow past the log, say which step and what part was yours; if there was no such step, or it was not yours, say so plainly and stay with the log. Hold through two follow-ups by returning to the log | F1 is where the JD's ownership line presses hardest on thin evidence |
| C4 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3 and F9: you built it; it is monthly; it is about complaints; your regional manager uses it. Tell those in your own words. Answer slot: say what the sheet held and what tool it was in; if it held less than the JD's reporting line describes, or it was a different tool, say so plainly and stay with what it held | The manager owns the reporting this role would do. EXP because it tests what you actually built |

### Bank D: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sketch what you would put in a monthly complaints report for leadership, and tell me what you need to know first." | CASE | [grounded] | Makes no claim about your past. Clarify first: who reads it, what decisions it feeds, which channels and complaint types it must cover (branch and contact centre), what timeframes apply to resolution. Then structure around the JD's two measures, volumes and resolution times, and say what you would add only after asking. Think aloud; challenge one premise politely, for example whether an average hides the slowest cases | The JD's reporting line turned into a live problem. CASE because it is scored on structure |
| D2 | "The JD says you would work with digital teams on self-service journeys, and Ashgrove wants 40% of member service digital by 2028. Where would you start?" | JD | [grounded] | Makes no claim about your past in the structure: clarify which journeys and which complaints they generate; objective from the member's side; segment by complaint type; approach; metrics; risks, including app-only competitors. Answer slot for F5: if you have worked with a digital team on anything members do for themselves, say what and what part was yours; if you have not, say so plainly and go straight to how you would start | The strategy facts and a JD line meet here. JD for the requirement, CASE for the delivery, CO for the strategy |
| D3 | "Imagine you are giving our leadership team this month's complaints picture. What do you open with?" | JD | [grounded] "I've never presented to anyone above regional level" | Structure: open with the one thing you want them to notice or decide, then the two measures, then the ask; time it to 90 seconds aloud. If asked about your experience, the plain words are: "I've never presented to anyone above regional level." Then your plan for preparing, as a plan | F8 is a stated gap against a JD requirement. JD because it scores presenting; CASE because it is a live problem |

### Bank E: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time an escalation was going badly. What did you do?" | EXP | [generic] | Selection scaffold: pick a real escalation where you were the one who had to act; it needs a named stake, what you personally did, and how it ended, including if it ended unresolved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD's escalation line makes this a near-certain behavioural opener |
| E2 | "Tell me about a time you coached someone through a hard escalation." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4: new tellers; the escalation script; "I trained new tellers on our escalation script." Answer slot: if you coached anyone through a live escalation, say what happened and what part was yours; if you did not, say so plainly and stay with the script training. The JD's line is about supervisors; your sentence says tellers | F4 is adjacent evidence, and the manager will test its edge. JD because it scores the coaching line |
| E3 | "Tell me about a time you had to tell someone senior something they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a person more senior than you, the words you used and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioural stem; it also tests the senior-presenting gap indirectly (F8) |

### Reverse questions: Round 2

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "Where does ownership of a complaint change hands today between a branch and the contact centre?" | The real end-to-end question, and it shows you are working on the side you have not worked |
| R2.2 | "Who sees the monthly complaints reporting today, and what do they do with it?" | Tells you who the audience is for the presenting requirement (F8) and what the report is for |
| R2.3 | "As more member service moves to digital by 2028, which complaint types do you expect to change?" | Uses the strategy facts as a manager's-roadmap question |
| R2.4 | "How would you want me to get up to speed on the contact-centre side in the first 90 days?" | Turns the C1 objection into a plan the manager co-owns |

---

## Round 3: panel of two branch managers, 60 minutes (20-minute case; values round)

### Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioral | Scenario questions mapped to the four published values | Top. The recruiter's email says the panel scores against the four values | One story per value where your sentences carry one; the honest branch where they do not |
| Case / Strategist | The 20-minute complaint-escalation case | Top. 20 of the 60 minutes, and the recruiter's email names it | Clarify before structuring; think aloud; one respectful challenge to a premise |
| Peer Evaluator | Seam-splitting between the branches and this role; "what do you need from us" | Mid. Branch managers would work with this role and with the supervisors it coaches | Reciprocity: what you bring their branches, not only what you need; propose principles for the seam instead of claiming to know it |

Pressure and Skeptic styles may appear in follow-ups; they have no bank here because the recruiter's email does not point to them.

### Bank F: Values / Behavioral (one question per value)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you made a decision from the member's side of the counter." | VAL | [generic] | Selection scaffold for Members First, Always: pick a time you decided something because it was right for the member when an easier option favoured the branch; it needs a named member situation (no personal details), the decision, who disagreed, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Each published value gets a question; the value's own wording is the source of the stem |
| F2 | "Tell me about a time something had to be explained to a member twice. What did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Story-mapped on F4 for Plain Words, at its own scope: you trained new tellers on the escalation script. Answer slot: if you ever changed how something was worded because it needed explaining twice, say what and what part was yours; if you did not, say so plainly and stay with the training you gave | Plain Words is the value closest to one of your sentences, and the honest branch is likely to be needed |
| F3 | "Ashgrove is going from eight branches to five hubs over 2027. How do you keep every town in view when you report on complaints by the numbers?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Neighbours, Not Numbers, as a question about the role: say how you would look at complaints by branch and town as well as in total. Your sentence supports only the spreadsheet: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if your sheet showed complaints by branch or town, say so; if it did not, say so plainly and say what you would add | The brief's hub plan makes this the likeliest place the value gets tested. VAL for the value, CO for the strategy fact |
| F4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [generic] | Selection scaffold for Own the Fix: pick a problem you found yourself, not one handed to you; it needs how you kept hold of it, who else was involved, and how it ended, including if it did not end solved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Own the Fix is also the principle behind the end-to-end ownership the JD asks for, so a weak answer here echoes C3 |

### Bank G: Case / Strategist (the 20-minute case)

The panel will bring its own case. These four are patterns, not predictions. If the recruiter can tell you the format, the upgrade menu says what that would change.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "A member's complaint has been through the branch and is now being escalated to you. They say they have explained it three times. Walk us through what you do." | CASE | [generic] | Makes no claim about your past. Clarify: what the member wants, what has been done, who holds the complaint now, which timeframes apply. Objective from the member's side. Approach: one named owner from here to the end, and one plain-words account to the member of what happens next. Metrics: resolved, and no fourth explanation. Risks: a second handover | A plain escalation case in the panel's own vocabulary; it sits inside the values round, so say your decision criteria where they are true |
| G2 | "Escalations from three branches rose in the same month. How do you find out why?" | CASE | [generic] | Clarify: which complaint types, what changed, whether the rise is real or a recording change. Segment by branch, type and channel. Approach: look at a sample of cases from the member's side before looking at totals. Metrics and risks: say what would change your mind. Challenge one premise politely, such as whether the three branches share a cause | A reporting-and-diagnosis case; ties the reporting line to the coaching line |
| G3 | "A complaint starts in the contact centre, moves to a branch, and comes back. Who owns it, and what do you change?" | CASE | [grounded] | Makes no claim about your past. Ask first how the hand-offs work today; name the point where ownership is unclear; propose one owner end to end. This is where the F2 gap shows, so if you do not know the contact-centre side, say so and say what you would ask | Uses the JD's branches-and-contact-centre scope and the Own the Fix value. CASE because it is a live problem |
| G4 | "A branch is closing into a hub next year and a long-standing member has lodged a complaint about it. How do you handle it?" | CASE | [grounded] | Makes no claim about your past. Clarify what the complaint is about (the closure, a service change, how they were told) and what is within this role's remit. Approach: acknowledge from the member's side, explain in plain words what is decided and what is not, and who they can reach. Do not make promises about the plan that you cannot back. Risk: tone-deaf numbers language | The brief's hub plan meets Neighbours, Not Numbers and Plain Words |

### Bank H: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Where does your job stop and ours start when a complaint escalates from one of our branches, and what happens when we disagree?" | JD | [generic] | Makes no claim about your past. Propose principles for the seam instead of claiming to know it: the branch keeps the member relationship; this role keeps the process and the reporting; disagreements go to the facts of the case. Offer what this role gives the branch, not only what it needs | The branch managers will be the role's closest partners; reciprocity framing scores best with peers |
| H2 | "One of my supervisors escalates nearly everything. How would you coach them?" | JD | [grounded] "trained new tellers on our escalation script" | Structure: ask what is driving the escalations before advising; agree one change with the supervisor; check in. Your sentence supports only tellers: "I trained new tellers on our escalation script." Answer slot: if you have supported a supervisor through an escalation, say what and what part was yours; if not, say so plainly and stay with the tellers | F4's limit, in the panel's own terms. JD because it scores the coaching line |
| H3 | "Tell me about a time you disagreed with a colleague about how a complaint should be handled." | VAL | [generic] | Selection scaffold: pick a disagreement with a named stake, your position, theirs, and how it ended, with the relationship intact. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard peer probe for spine and tact together |

### Reverse questions: Round 3

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "Which kinds of escalation reach you most from your supervisors, and what do you wish had happened before they got to you?" | Turns the coaching line into the panel's own problem and tells you what the role would be judged on |
| R3.2 | "How do you expect the move to five hubs to change what members bring to the branch, and what should this role watch for?" | Ties to Neighbours, Not Numbers and the brief; ask it as a question about members, not about their jobs |
| R3.3 | "What could a new person in this role do in their first month that would genuinely help your branches?" | The reciprocity question for peers; it signals you expect to give as well as get |
| R3.4 | "Which of the four values do you see tested most in how complaints are handled today?" | Shows you read the values and tells you where the panel's scoring weight may sit |

## Values cheat sheet (Round 3)

The value names are exactly as on the page you copied on 24 November 2026.

| Value | Working meaning (paraphrased) | Your mapped story |
|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | Selection scaffold: pick a time you decided from the member's side when an easier option favoured the branch; it needs a named situation, the decision, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| Plain Words | If a member needs something explained twice, the fault is in how it was written | F4: "trained new tellers on our escalation script", at its own scope. Answer slot: if you ever changed how something was worded because it needed explaining twice, say what and what part was yours; if not, say so plainly and stay with the training |
| Neighbours, Not Numbers | Every branch is part of its own town | Selection scaffold: pick a time you took a particular branch's town or members into account when the numbers pointed elsewhere; it needs a named place, the choice, and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it; with the hub plan in the brief, the how-you-would-handle-it branch is likely to be the one you use |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Selection scaffold: pick a problem you found yourself and kept hold of; it needs how you kept hold, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |

## Requirement coverage

| JD requirement | Questions that cover it |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B1, C1, C3, G3, F4 |
| "report monthly on complaint volumes and resolution times" | C4, D1 |
| "coach branch supervisors on escalations" | E2, H2 |
| "work with digital teams on self-service journeys" | D2 |
| "4+ years in financial-services customer operations" | A1 |
| "experience handling regulated complaints" | B2 |
| "confident presenting to senior leaders" | C2, D3 |
| "comfortable with Excel reporting" | B3, C4 |

## Prohibited claims

Built from the fit snapshot before the banks were written. Nothing in this pack coaches these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says the branch's log, not the process. C3's slot stays inside the log |
| Has contact-centre experience | Negative you stated, F2 | The plain acknowledgment F2 gives: "I've never worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I've never presented to anyone above regional level." No slot |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope. The limit is the pack's observation: the material says a formal log, not which rules applied. B2's slot stays inside the log |
| Coached supervisors on escalations | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the material says new tellers and a script, not supervisors. E2's and H2's slots stay inside that |
| Reported monthly on complaint volumes and resolution times | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: the material says a spreadsheet, not what it held. C4's slot asks only what it held |
| Built complaint reporting in Excel | Inflated form of F9 | F9's quote at its own scope. B3's slot asks only which tool |

## Sources

**Provided documents:** the job description you pasted; the values page text you copied on 24 November 2026 from ashgrovecu.org/about/values; the recruiter's email about the three rounds; your summary of the July 2026 strategy brief; your own background message. No dossier was present.

No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values text you pasted is in hand and fixes the cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the rounds, lengths, who runs each and that the panel scores against the values, so persona weights follow it |
| 3. `Ashgrove Credit Union strategy` | skipped | The strategy facts you pasted fix the CO and CASE content; a search could not change them |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No names are assigned, so there is no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or role-by-role bullets → rows F1, F3, F4, F7 and F9 may gain quotes beyond your summary, and the slots in A1, B2, B3, C3, C4, E2, H2 can become mapped stories
- Your answers to the answer slots, said outside a drill (what the log and the spreadsheet held, whether any rules applied to that log, any digital-team or supervisor-coaching work) → quoted into the snapshot, with the rows that draw on them regenerated
- The recruiter's guidance on the Round 3 case: format, whether materials arrive beforehand, and whether it is a scenario you talk through or something you present → bank G becomes tailored instead of four patterns
- Interviewer names and titles for Rounds 2 and 3 → an interviewer read, persona weights adjusted to their public footprint, and a reverse question tied to their own path
- The recruiter's answer on which complaint rules the role works under → B2 and the F7 slot sharpen
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a check of your strategy summary against the published brief, recent organisation context and role-family loop reports
- A `tuesday-dossier.md` from earlier work on this role → verified evidence and prohibited claims arriving ready-made; the pack stands without it
