# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Date of all three rounds:** 3 December 2026 (prepared 24 November 2026, nine days out). **Mode:** loop, because the recruiter's email gives the schedule.

| Round | Length | Who | Relationship | Named? |
|---|---|---|---|---|
| 1 | 30 minutes | The recruiter | Recruiter screen | Not named |
| 2 | 45 minutes | The Head of Member Services | Would be your manager; mostly behavioural | Not named |
| 3 | 60 minutes | A panel of two branch managers | Panel; includes a 20-minute case on a complaint escalation; also the values round, scored against the four values | Not named |

## How to use this pack

- **Personas are how a question is asked; types are what it scores.** Each question carries one persona (its bank) and one or more type tags.
- **Type key.** VAL: past behaviour against Ashgrove's published values. EXP: whether your own history survives follow-up. JD: a requirement the job description states. CO: knowledge of Ashgrove and its strategy. CASE: a live problem, reasoned aloud.
- **Guidance is scaffolding, not a script.** Say it in your own words.
- **An answer slot is an instruction for the interview, not a question for this chat.** It has two branches. Take whichever is true. The honest branch is never a confession, and it includes "that step did not exist" as well as "someone else did it".
- **Labels.** `[grounded]` traces to something you supplied. `[inferred]` is this pack's derivation, named. `[generic]` is a pattern with no claim about you or Ashgrove.
- **Where the pack cannot say what you did, it says so and leaves a slot.** Everything about your past is one of your own sentences, quoted, or a slot.

## Prep triage (nine days, hours per day not stated)

| When | Do this | Where |
|---|---|---|
| 24 to 26 November | Rehearse aloud, out loud, until it is boring: the contact-centre objection, then the senior-leaders objection, then the day-one-weakness question | B3 (highest-ROI), B4, B1 |
| 24 to 26 November | Settle, privately and truthfully, the slot answers for the rows the panel and the manager will press: what your log, spreadsheet, escalation script and any digital work actually covered | F1, F3, F4, F5, F7, F9 |
| 27 to 29 November | Map one true story, or one honest scaffold branch, to each of the four values, then rehearse the "numbers" question | C3 to C7, section 10 |
| 27 to 29 November | Practise the 20-minute case aloud against a clock, with the structure in D4 and D5 | D4, D5 |
| 30 November to 1 December | Strategy questions and reverse questions for rounds 2 and 3 | D2, D6, reverse questions |
| 2 December | Recruiter logistics in your own words, and one full run of round 2 | A2 to A5, round 2 |

Everything else is insurance.

## Fit snapshot (shared across all three rounds)

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD (the branches limb) | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not the process end to end and not other branches, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages a complaint goes through likely. If any stage beyond the log was yours to run, say which and how, in your own words; if the log was where your part sat, or the stages were not yours, say so plainly and stay with the log you handled |
| F2 | "Own the member complaints process end to end across branches and the contact centre" — JD (the contact-centre limb) | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. No claim to contact-centre experience, and no claim that the branch work is the same thing |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The sentence says a monthly complaints spreadsheet that a regional manager uses; your material does not show what it counted. The words stay: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet showed. If it showed either, say which, in your own words; if it showed something else, say what; if it showed neither, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message; "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | transferability | Your material says new tellers and an escalation script. The JD's audience is branch supervisors, a title your material says you held for three years; it does not say you coached any. Words: "I trained new tellers on our escalation script." Answer slot: if you have taken a fellow supervisor through an escalation, say what it was and what part was yours; if not, say so plainly and stay with the tellers |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | The material is silent, and silence is not an absence. Answer slot: if you have worked with a digital or product team on anything members used themselves, say what it was and what part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | none | A length requirement, not a gate, and the quote already reaches it in role-relevant terms. Lead with the quote's own terms: six years in retail banking, the last three as a branch supervisor. Expect a probe on it, since it is a self-reported line with nothing inspected behind it |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | discovery | The sentence says a formal complaints log; it does not say regulated, and no regulator is named anywhere in your material. Answer slot: if the log fell under a regulator's complaint rules, say which rules and what they asked of you, in your own words; if you do not know whether it did, or it did not, say so plainly and stay with the formal log you handled |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't presented to anyone above regional level." Then how you would prepare a first presentation, said as a plan and never as a past. Your material does not show what you have presented below that level, so nothing is claimed about it |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [grounded] | discovery | The JD says Excel; the sentence says spreadsheet. The words stay: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if you built it in Excel, say so and name one thing it did, in your own words; if it was another tool, say which and stay with the spreadsheet you built |

No requirement in the JD is a gate in the sense that matters here (a legal, credential, location, schedule or pay term), so no row is `hard_gate`. The 4+ years line is a length of experience, graded as F6.

## Grounding brief: the 2026 strategy

Built from your summary of the brief the recruiter sent (published July 2026), not from the document itself. By 3 December it will be about five months old.

| Item | What your summary says | Where it shows up in this pack | Provenance |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | D2, F5, C2, reverse questions in round 2 | [grounded] |
| Branch consolidation | Eight branches into five hubs over 2027 | D6, C5; the round 3 panel is two branch managers, so expect this to be on their minds | [inferred] |
| New product | A small-business lending product in Q1 2027 | Context only; no question in this pack depends on it | [grounded] |
| Competitive pressure | App-only banks are the main pressure | D2: the complaint route inside a digital journey is where an app-only competitor and Ashgrove would differ | [inferred] |

---

# Round 1: recruiter screen (30 minutes)

## Persona weights

| Persona | Weight | Reasoning | How it shows up | Counter-strategy |
|---|---|---|---|---|
| Conversational / Rapport Builder | High | A recruiter screen's prior is logistics and motivation in a friendly register; your note names no focus areas beyond the slot | The biography question, notice, location, pay, reason for leaving, why Ashgrove | Pre-script a 90-second arc from your own sentences; treat every casual question as scored |
| Skeptic | Low | The same prior adds light knock-out checks; the JD's regulated-complaints and day-one-weakness lines are the natural ones | A short check on regulated complaints and on your weakest area | Know your two stated limits in their own words, and a plan for each |

## Question bank

### Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc with the beats those sentences state, each at its own scope: six years in retail banking, the last three as a branch supervisor; you handled the branch's formal complaints log; you trained new tellers on the escalation script; you built the monthly complaints spreadsheet a regional manager uses. Tell them in your own words and add no further beat. End on why you want this role, in your own words, and leave it to the recruiter to draw what your history shows | The opener of nearly every recruiter screen, and the one place the story is told before anything else is asked. F1, F3, F4 and F6 all enter here, so a consistent arc protects them |
| A2 | "What is your notice period, and when could you start?" | JD | [generic] | Logistics slot: give your actual notice period and the earliest date you could actually start, in your own words. If you do not know either yet, say so and say when you will | A recruiter checks this on every screen, and the only safe answer is your own. JD because it concerns the terms of the listed job |
| A3 | "Where are you based, and does the location of the role work for you?" | JD | [generic] | Logistics slot: give your actual location and any actual limit on getting to the sites the role covers, in your own words. If you do not yet know which sites the role covers, ask the recruiter | The JD's across-branches line puts site coverage in play. JD because it concerns the terms of the listed job |
| A4 | "What are you looking for in terms of salary?" | JD | [generic] | Logistics slot: either give your own number, in your own words, or ask for the role's band first; this pack supplies no figure. If you are asked what you earn now, you can decline that and return to the band for this role | Pay is asked on nearly every screen, and the answer has to be yours. JD because it concerns the terms of the listed job |
| A5 | "What is prompting you to look at a move?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words, in a sentence or two. Say only what is true, and keep it about what you want rather than about anyone you worked with | The reason for leaving is scored for consistency with the rest of your story. EXP because it tests the story you tell about your own history |
| A6 | "What attracted you to Ashgrove?" | CO | [grounded] | Pick one published value by its exact name from section 10 and say what it means to you, in your own words. If you are asked what in your own work connects to it, answer from your own sentences; if nothing comes to mind, say so plainly and say why it appeals | A rapport-style question that tests homework and sincerity at once. The values page is the one source you were given for it |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name one limit your material states, in its own words, either "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level", then say how you would close it, as a plan for the first weeks and never as a past. Offer one, not both, unless asked for the second | F2 and F8 are the two limits you stated, and the stem makes you rank them. JD because it scores the stated requirements, with Skeptic delivery |
| B2 | "Have you handled regulated complaints before?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Say what the quote states, at its scope: you handled the branch's formal complaints log. Answer slot: if that log fell under a regulator's complaint rules, say which and what they asked of you; if you do not know whether it did, or it did not, say so plainly and stay with the formal log you handled | A knock-out check in a friendly register, and F7 is where your material stops short of the JD's word "regulated". JD because it scores a stated requirement |

## Reverse questions for round 1

| # | Question | Why it lands |
|---|---|---|
| R1-1 | "What happens after round 3, and when should I expect to hear?" | It shows you are planning around their process, and it is the one thing a recruiter can answer exactly |
| R1-2 | "Is there anything in my background you would want me to address with the Head of Member Services?" | It surfaces the objection before round 2 and lets you rehearse against what the recruiter actually says rather than what this pack infers |

---

# Round 2: Head of Member Services, your would-be manager (45 minutes, mostly behavioural)

## Persona weights

| Persona | Weight | Reasoning | How it shows up | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral | High | The recruiter calls this round mostly behavioural | "Tell me about a time" prompts drawn from the JD's coaching, digital and senior-leader lines | Map a story to a prompt only where one of your quoted sentences carries it; use the scaffold and its honest branch where none does |
| Skeptic | High | A would-be manager is pricing the gaps before hiring, and F2 and F8 are stated gaps | The contact-centre objection, the senior-leaders objection, the one-branch-to-all-branches objection | Rehearse the single most predictable objection (B3) until it is boring; hold a position through two follow-ups without adding to it |
| Case / Strategist | Mid | A manager buys capability on a live problem from the job; the recruiter's note does not rule it out | A diagnosis problem and a strategy problem | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise |
| Data-Driven Prober | Mid | The spreadsheet and the log are the only artifacts your material shows, and a manager who reads them will go line by line | What the spreadsheet showed; how the log ran | State what your sentences say, then take the slot honestly |

## Question bank

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you coached someone through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-mapped on F4: you trained new tellers on your escalation script, which is the beat the quote states; tell it in your own words. Answer slot: the JD's audience is branch supervisors, so expect a probe on whether you have coached a peer or a supervisor. If you have, say what the escalation was and what part was yours; if not, say so plainly and stay with the tellers | F4 is the JD's coaching line against a quote about tellers, so the probe on the audience is likely. JD because it scores a stated responsibility, with VAL delivery |
| C2 | "Tell me about a time you worked with a digital team on something members used themselves." | JD | [grounded] | Selection scaffold, because F5's evidence is none given: pick a time you worked with someone who builds or runs a member-facing digital service; it needs a named change, what you contributed and what members saw. If no such time comes to mind, say so plainly, then say how you would work with a digital team: what you would ask them first and what you would bring to the conversation | F5 is silence, not an absence, so the scaffold keeps the door open and the honest branch keeps it truthful. JD because it scores the self-service line |
| C8 | "Tell me about a time you had to give a senior person news they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not fold, and a working relationship that was intact afterwards; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Choose a story in which the hard truth actually landed | A persona stem for a would-be manager, and the nearest rehearsal for F8's senior-leaders requirement without claiming presenting experience. VAL because it scores behaviour, not a published value |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B3 | "You have not worked in a contact centre. How would you own complaints there?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | **The highest-ROI prep in this pack.** Beat 1, the limit, in your own words and without apology: "I haven't worked in a contact centre." Beat 2, the adjacent thing at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Say it is adjacent and not the same thing. Beat 3, a plan said as a plan: what you would learn first about how complaints reach and leave the contact centre, and from whom, before you changed anything. Follow-up 1 ("How would you earn that team's trust?"): return to beat 3. Follow-up 2 ("But you have not done it."): hold by restating beat 1 and beat 2 without adding to either, and concede exactly this: the contact-centre part is the part you have not done. Never claim an equivalence | F2 is a stated gap against the first line of the JD, so this objection arrives in some form. JD because it scores a stated requirement; the Skeptic and Pressure delivery are why it gets the most follow-up levels |
| B4 | "This role presents to senior leaders. What have you presented, and to whom?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | Start with the limit in its own words: "I haven't presented to anyone above regional level." Answer slot: your material says a regional manager uses your spreadsheet, not that you presented it. If you presented anything to the regional manager or a group, say what, to whom and how; if it was sent rather than presented, say so plainly. Then a plan, said as a plan: how you would prepare a first presentation to senior leaders, starting with what the audience has to decide | F8 is a stated gap against a headline requirement, so this is the second-highest-ROI rehearsal after B3. JD because it scores the stated requirement |
| B5 | "You have handled one branch's log. This role owns it across branches. What makes you think you can do that?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Hold the quote at its scope: "I handled the branch's formal complaints log." Do not claim anything across branches. Answer slot: if you have dealt with other branches' complaints or a view across branches, say what and how; if not, say so plainly and say how you would start across branches, as a plan. Hold through two follow-ups by returning to the quote, never by adding to it | F1's branches limb is transferability, and the inflated form ("owned the process across branches") is the sentence this question is built to extract. JD because it scores the stated scope |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Complaints at two branches have risen sharply in a month and resolution times are slipping. What do you look at first?" | CASE | [generic] | Clarify first: is the rise real or a change in how complaints are recorded; do the two branches share a cause; what do the resolution times measure and from when. Then objective, segmentation, approach, the numbers you would want, and risks. Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | A live problem built from the JD's monthly volumes-and-times line (F3's requirement) rather than from your history. CASE because it scores structure |
| D2 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that change for complaints, and what would you want to know first?" | CO | [grounded] | Structure it: what moves to digital, how a complaint raised in a digital channel reaches the same record as one raised at a branch, and what a member sees when something goes wrong. Bring one consensus point to show grounding, and one thesis-driven divergence with reasons: the complaint route is where a self-service journey is tested hardest, and Plain Words (section 10) is the measure. Name what you would not promise. The question asks about no past | The brief was sent to every candidate, so recite one point and then depart from it. CO because it scores strategy fluency, with a CASE delivery |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about the monthly complaints spreadsheet. What does it show?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F3: you built it, it is monthly, and a regional manager uses it, the beats the quote states. Answer slot: the JD names complaint volumes and resolution times, so expect a probe on whether the spreadsheet showed them. If it showed either, say which, in your own words; if it showed something else, say what; if it showed neither, say so plainly and stay with the spreadsheet you built. Second slot, for F9: if you built it in Excel, say so; if in another tool, say which | F3 and F9 both rest on one sentence, so a prober who reads the CV line by line starts here. EXP because it tests what you actually built |
| G2 | "Walk me through how the branch's formal complaints log worked, from a complaint arriving to its being closed." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-mapped on F1: you handled the branch's formal complaints log, the beat the quote states. Answer slot: the JD's end-to-end line makes a probe on the stages likely. If you ran or set any stage, say which and how, in your own words; if the log was where your part sat, or there was no such step, say so plainly and describe how you handled the log | The JD's end-to-end line against a log you handled is the gap F1 names. EXP because it tests which stages were yours |

## Reverse questions for round 2

| # | Question | Why it lands |
|---|---|---|
| R2-1 | "What would a good first quarter look like for someone in this role, and what would tell you it was going wrong?" | It asks your future manager for the scoring sheet, and it turns the gaps in F2 and F8 into a plan they have a say in |
| R2-2 | "As more service moves to digital channels, how do you want a complaint raised there to reach the same record as one raised at a branch?" | It ties to the digital-shift line of the brief and to F5, and it reads as a person already thinking about the job |
| R2-3 | "Where do you see the four values pulling against each other in complaints work?" | It shows you read the values as working principles, and it opens the conversation about hubs and digital without you asserting what will happen |

---

# Round 3: panel of two branch managers (60 minutes: values round, with a 20-minute case)

## Persona weights

| Persona | Weight | Reasoning | How it shows up | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral | High | The recruiter says the panel scores against the four values | One prompt per value, each asking for a specific decision | Name a story per value where a quoted sentence carries one; use the scaffold and its honest branch where none does; "we" for context, "I" for contribution |
| Case / Strategist | Mid | A 20-minute case on a complaint escalation is stated | The escalation case and a variant with a handover between branch and contact centre | Clarify first, ownership second, plain words to the member third; think aloud |
| Peer Evaluator | Low | The panel is branch managers, whose work sits beside the role's | Where the line falls between your role and theirs | Reciprocity first; propose principles for the seam rather than pretending to know it |

Names are not assigned, so the weights rest on relationship priors. A name or a public profile for either manager would reweight them.

## Question bank

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C3 | "Members First, Always: we decide from the member's side of the counter. Tell us about a time you decided something from the member's side." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Selection scaffold: pick a time when the member's view and the branch's convenience pulled apart and you sided with the member; it needs a named stake, the decision and what the member saw. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I handled the branch's formal complaints log", at that scope, or say how you would handle it | The value is a published one, and none of your sentences carries a decision from the member's side, so this is the scaffold case |
| C4 | "Plain Words: if a member needs it explained twice, we wrote it wrong. Tell us about a time you made something clearer for a member or a colleague." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-mapped thinly on F4: you trained new tellers on your escalation script, the beat the quote states. Answer slot: if you reworded the script, a letter or an explanation because someone needed it twice, say what you changed and how you knew; if the script was handed to you and you taught it, or there was no such rewording, say so plainly and stay with the training | The value is a published one, and a script is the only words your material touches. The slot's second branch allows that no rewording ever happened |
| C5 | "Neighbours, Not Numbers: every branch is part of its town. Tell us about a time you looked after a branch's place in its community, or put a person ahead of a figure." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Selection scaffold: pick a time a branch's locality or a customer's circumstances shaped a choice you made; it needs a named moment, what you decided and what changed for the people. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "the last 3 as a branch supervisor", at that scope, or say how you would handle it | The value is a published one, and the panel is two branch managers. Your material carries a role and a duration but not a moment, so this is the scaffold case |
| C6 | "Own the Fix: whoever finds the problem keeps hold of it until it is solved. Tell us about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-mapped on F1: you handled the branch's formal complaints log, the beat the quote states. Answer slot: if a particular complaint stayed with you from the moment it reached you until it was solved, say which, what you did and what part was yours; if the log meant passing complaints on, or someone else solved it, or there was no such complaint, say so plainly and stay with the log you handled | The value is a published one and is the nearest to the job itself, so expect this one to be pressed hardest. The slot's second branch allows that you kept the log but not the fix |
| C7 | "This job includes monthly numbers. How do you stop the numbers becoming the point?" | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Start with the sentence at its scope: "I built the monthly complaints spreadsheet our regional manager uses." Then a position said as a plan, not a past: how you would keep the member visible beside each figure. Answer slot: if you ever added anything other than counts to that spreadsheet, or changed how it was used, say what and why; if it held figures only, say so plainly and stay with the spreadsheet | Neighbours, Not Numbers meets the JD's monthly reporting line here, and a branch manager is likely to notice the tension. VAL because it scores the value against F3's requirement |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D4 | "A member's complaint has come back for the third time, and they say nobody has taken ownership. What do you do in the next hour, and what do you change afterwards?" | CASE | [generic] | A 20-minute case, so spend the first few minutes clarifying: what was promised and by whom, who holds it now, what time limits apply, what the member wants. Then the objective from the member's side, the next steps and who does them, what you tell the member in plain words, and what you change afterwards so it does not recur. Think aloud and challenge one premise, such as whether nobody has really owned it. The question asks about no past | The recruiter announced a 20-minute case on a complaint escalation, and this is the shape most likely. CASE because it scores structure, with Own the Fix and Plain Words as the lenses |
| D5 | "A complaint started in a branch, moved to the contact centre, and the member now says they have explained it three times. Who owns it, and what do you do?" | CASE | [grounded] "Never worked in a contact centre" | Same structure as D4. Name early, in one sentence, that you have not worked in a contact centre, and ask the contact-centre side what they can see before you decide. Make the member's side of it the objective: the member should not have to explain it a fourth time. Decide who keeps hold of it, say so in plain words, and name what you would change at the handover | A variant that puts the JD's branches-and-contact-centre line into a handover. F2 is the stated gap, so the honest one-sentence limit belongs inside the case rather than being found by it |
| D6 | "Eight branches are becoming five hubs over 2027. How would you keep a member in a town that loses its branch feeling heard when they complain?" | CO | [grounded] | Structure it from the member's side: what stays in the town, where a complaint goes, who they speak to, what they are told. Name the tension with Neighbours, Not Numbers openly. Bring one consensus point and one divergence, and say what you would not promise: that every town keeps everything it has. Do not speculate about the panel's own branches; ask what has been decided. The question asks about no past | The brief's consolidation line meets the panel's job and the values page's Neighbours line. CO because it scores strategy fluency, with a CASE delivery |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where is the line between your role and a branch manager's when a complaint escalates, and what happens when we disagree?" | JD | [generic] | Reciprocity first: what a branch manager needs from the role. Then propose seam principles rather than claiming to know the seam, for example that the branch keeps the relationship with the member while the role keeps the process, offered as a starting point to agree with them. For the disagreement half, a selection scaffold: pick a time you disagreed with a peer or a manager and the working relationship stayed intact; if no such time comes to mind, say so plainly, then say how you would handle it | The panel is branch managers, whose work sits beside this role's, and the JD's coaching line puts supervisors under them. JD because it scores the stated responsibility |
| F2 | "What would you need from a branch manager in your first month, and what could you offer back?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Say what you would ask for first, then offer what your material carries at its own scope, "I trained new tellers on our escalation script", as a question ("would a session on that be useful?") and never as an assertion that their teams lack one | The reciprocity question for a peer-style panel. F4's quote is the only thing the material offers back, so it stays at its scope |

## Values and principles cheat sheet

Ashgrove's four values, quoted from the page you pasted (copied on 24 November 2026 from ashgrovecu.org/about/values).

| Value (official name) | Working meaning (paraphrased) | Mapped story or scaffold |
|---|---|---|
| Members First, Always | Decide from how it looks to the member | Scaffold, C3, ending in its honest branch; F1's quote "I handled the branch's formal complaints log and trained new tellers on our escalation script" is the nearest thing at its own scope |
| Plain Words | If a member needs it explained twice, the wording is the problem | F4: "I handled the branch's formal complaints log and trained new tellers on our escalation script"; the beat is the training, and any rewording is an answer slot (C4) |
| Neighbours, Not Numbers | A branch belongs to its town | Scaffold, C5, ending in its honest branch; F6's quote "6 years in retail banking, the last 3 as a branch supervisor" is the nearest thing at its own scope, and C7 takes the numbers side |
| Own the Fix | The person who finds a problem keeps hold of it until it is solved | F1: "I handled the branch's formal complaints log and trained new tellers on our escalation script"; the beat is the log, and any complaint you kept hold of is an answer slot (C6) |

## Reverse questions for round 3

| # | Question | Why it lands |
|---|---|---|
| R3-1 | "What would you want a new complaints lead to do in their first month that would genuinely help your branch?" | The reciprocity question for a peer-style panel; it answers the "what do I get" question before they ask it |
| R3-2 | "From your branch, what makes a handover from the contact centre or a digital channel feel good or bad?" | It asks for the branch's side of D5 in their own words, and it signals the process matters more to you than the title |
| R3-3 | "As the changes to the branch network happen, what would you want from this role?" | It names the brief's consolidation line without asserting anything about their branches, and it hands them the floor |

---

## Prohibited claims

What this pack will not coach, with its basis and the honest form of each. Built from the fit snapshot before the banks.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation, not words for you: the material says one branch's formal complaints log, not the process end to end. B5 and G2 stay inside the log |
| Handled complaints across branches | Inflated form of F1 | F1's quote at its own scope; B5's slot asks only what other branches' complaints you dealt with, if any |
| Has contact-centre experience, or an equivalent | Negative the candidate stated, F2 | The plain acknowledgment F2 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders or executives | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |
| Coached branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: you trained new tellers on the escalation script. C1's slot asks only whether you coached a peer or a supervisor, and the second branch allows that you did not |
| Reported complaint volumes and resolution times each month | Inflated form of F3 | F3's quote at its own scope: you built the spreadsheet a regional manager uses. G1's slot asks only what it showed |
| Handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: a formal complaints log. The material does not say regulated; B2's slot asks only whether the log fell under a regulator's rules |
| Is expert in Excel | Inflated form of F9 | F9's quote at its own scope: a spreadsheet. G1's second slot asks only which tool |

## Sources

**Provided documents.** The job description, quoted in the fit snapshot. The values page text, pasted, with ashgrovecu.org/about/values named as where it was copied on 24 November 2026; not fetched. The recruiter's email on the three rounds, which establishes the loop and its values round. Your summary of the 2026 strategy brief (published July 2026); the brief itself was not read. Your background, quoted in the fit snapshot. No `tuesday-dossier.md` was present.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values page, copied today, fixes the four values and the cheat sheet |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the rounds, who runs them, their lengths and the values round, so it fixes loop mode and the persona weights |
| 3. `Ashgrove Credit Union strategy` | skipped | Your summary of the July 2026 brief fixes the CO and CASE questions D2 and D6; the document itself would add wording, not new targets |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No interviewer has been named, so there is no query to form; no interviewer read is built |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- **Interviewer names, or a public profile for either manager** → an interviewer read, persona weights per panel member, and a reverse question tied to their own path.
- **The strategy brief itself** → D2, D6 and the round 2 and 3 reverse questions rest on its wording instead of your four-line summary.
- **The recruiter's detail on the 20-minute case: its format, whether you get material in advance and whether it is a role-play** → D4 and D5 tuned to the actual format; one email.
- **Your answers to the slots, stated in a message and not in a drill** → F1, F3, F4, F5, F7 and F9 become quoted evidence, and the rows that draw on them (B2, B5, C1, C2, C4, C6, C7, G1, G2) regenerate, with `medium` confidence moving up where something inspectable backs it, such as an anonymised copy of the spreadsheet or the escalation script itself.
- **Your CV** → every evidence cell quotes it with titles and dates, and F6 and F7 are checked against it.
- **Your own notice period, location and reason for leaving** → A2, A3 and A5 quote you back whole.
- **A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes** → role-family loop reports and recent organisational context for the round 2 and round 3 banks. Offered once.
- **A `tuesday-dossier.md`** → would add verified evidence, objections and prohibited claims from an earlier review of this role; not needed for this pack.
