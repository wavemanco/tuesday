# Interview prep pack: Senior GTM Strategy Lead, Emerging Products — Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy. **Relationship:** peer; both report to the same VP. **Format:** one 60-minute conversation (all from the coach's notes).

**Built on this assumption:** a single peer conversation with no separately scored values round, because your notes describe one session and name none. Weights rest on that, not on a documented Northwind loop.

**Highest-ROI prep in this pack:** D1, with G1 as its time-boxed twin. A peer in Sales Strategy is the person most likely to press on the missing classic sales-ops and quota-setting experience, and a rehearsed, non-defensive answer changes how the rest of the hour reads.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. Bank letters skip F so they never collide with fit-snapshot rows (F1 to F8).

| Type | What it is scoring |
|---|---|
| VAL | Whether past behavior shows the company's published values (no VAL bank here: see persona table) |
| EXP | Whether the claims on your record survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at Northwind's altitude: strategy, competition, recent moves |
| CASE | Structure and reasoning on a live problem from the role |

Provenance labels: grounded means traceable to your notes; inferred means derived from them with the derivation named; generic means a role-family pattern that makes no claim about Priya or Northwind.

## Fit snapshot

Requirements are quoted from the JD highlights in the coach's message, since the full JD text was not supplied. Evidence is quoted exactly from the coach's notes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights, coach's message | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material shows strategy work and product strategy and ops, not ownership of a go-to-market, and the words stay there: "I spent two years in strategy consulting at a top firm, then nine in product strategy and ops at a large consumer-tech company." Answer slot: the JD's line makes a probe on go-to-market work likely. If any of that work set how a product reached its customers, say what and which part was yours, in your own words; if there was no such work, or it was not yours, say so plainly and stay with the strategy and ops work you did |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights, coach's message | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material shows a proposal and a credited uplift, and does not show work across land, adopt, expand or renew. The words: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's stage list makes a probe on how the opportunity was found likely. If you found it through analysis, say what you looked at; if it came another way, or the finding was not yours, say so plainly and stay with the proposal |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights, coach's message | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | No gap on the tools, but a statement of skill with nothing inspected behind it, and "independent" is where a data-driven peer will press. Lead with the tools in the quote's own terms, then expect a request for one concrete analysis (A3 rehearses it) |
| F4 | "partner-motion design experience required" — JD highlights, coach's message | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The quote shows a revenue model used in negotiations with partners, and does not show the design of a partner motion. The words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD marks this required, so a probe on whether any of that work shaped how the partnership operated, beyond the numbers, is likely. If any did, say what and your part; if none did, or it was not yours, say so plainly and stay with the model you built |
| F5 | "strong cross-functional influence" — JD highlights, coach's message | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | Lead with the quote in its own terms: "I set annual volume targets with cross-org consensus." A named record beats an adjective. The limit is the pack's observation: your material says annual volume targets, not quotas, and the words should stay there |
| F6 | "AI experience a plus" — JD highlights, coach's message | "uses AI tools daily" — the coach's notes | medium | [grounded] | presentation | The words: "I use AI tools daily." The limit is the pack's observation: your material says use of tools, not building or launching AI products, and the words stay at use |
| F7 | Classic sales-ops and quota-setting fluency — role-family, not in the JD highlights, and a peer in Sales Strategy is the likeliest person to test it | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and it was stated. The words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Never a claim to sales-ops or quota work, and nothing added to make the gap feel smaller |
| F8 | "enterprise expansion" — one of Northwind's three stated priorities, coach's research note | "a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material shows a consumer-tech setting, not enterprise customers. The words: "I worked in product strategy and ops at a large consumer-tech company." Why B2B and why now is yours to say; the pack supplies no reason (D3) |

No requirement in the JD highlights is a term the material fails to show met (location, schedule, pay and the like), because the highlights state none. The full JD may.

## Reading the interviewer

Source: the coach's notes on Dan's profile. His public talks and writing were not checked (search was refused).

| Signal | What the notes say | Implication | Provenance |
|---|---|---|---|
| Self-description | "relentlessly data-driven" | Prober up: expect every number you quote to be taken to its inputs and assumptions (A1, A2, A5, G2) | [grounded] |
| Career spine | "pricing and monetization roles" | Tilt cases to pricing, packaging and unit economics, his native language (C1, C2) | [grounded] |
| Early-stage chapter | "one early-stage-startup chapter" | Builder stories can land with him, and a scrappiness or big-company-pace probe is plausible; this pack has no quoted startup-style evidence for you, so it does not coach one (D3, R1) | [inferred] |
| Relationship | "he would be Priya's PEER, both reporting to the same VP" | Peer Evaluator weight: seam, credit, disagreement, and what you bring his team (B1 to B5) | [grounded] |

**Mirror opportunities.** The shared vocabulary is revenue and monetization, with no shared career jump claimed. Pair his pricing and monetization spine with your own words from F4, "built a partner-level revenue model used in carrier negotiations", and from F2, "proposed a store-surface change credited with a ~$400M ARR uplift", used at their own scope and never as proof of pricing expertise.

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Takes each figure to its inputs and assumptions | High (5 questions). Peer prior plus "relentlessly data-driven" pushes it up | Know what you can and cannot say about how each figure was counted, name the weakest assumption first, say plainly when you do not know |
| B. Peer Evaluator | Seam-splitting, credit, "what would you need from me" | High (5). Peer relationship prior | Reciprocity: what you bring his team, seam principles rather than a pretended seam, disagreement with spine and tact |
| C. Case / Strategist | Live GTM, packaging and whitespace problems | Medium (3). Not a hiring-manager round, but the JD is a strategy-ownership role and his pricing spine tilts cases | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| D. Skeptic | Probes the sales-ops, partner-motion and B2B gaps | Medium (3). F4, F7 and F8 are the gaps a peer pricing the hire will test | Rehearse the single likeliest objection until it is boring; bridges only from your own quoted words |
| E. Conversational | Warm opener, then casual AI and "journey" questions | Low (2). A 60-minute peer talk will open here, and casual questions are still scored | A 90-second arc built from your quoted words; treat the AI question as scored |
| G. Pressure | Time-boxed "why you" and number challenges | Low (2). Peer rather than executive, but a data-driven peer can challenge a number hard | Pause, restate, hold the position through two follow-ups, concede specifically |
| Values / Behavioral | Not included | No values-style round is detected: your notes name one session and no loop source documents one, and no values page was read. Credit and disagreement stories are covered in B3 and B5 | Not applicable |

## Question banks

Rationale cells refer to your history only by fit-snapshot row. Answer slots are instructions for the interview, not questions to you.

### Bank A — Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F2, with only the beats the quote states: you proposed the change, and the uplift was credited to it. Your words: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Weakest-assumption move: before Dan asks, name in your own words the assumption behind the figure you would defend least. Answer slot: how it was counted and what it is sensitive to. If you know, say so in your own words; if you do not know how it was counted, say that plainly | The headline figure is the likeliest target of a data-driven peer; F2 holds the evidence. EXP because it tests what the record can support |
| A2 | "How much of that uplift was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold, then concede. Hold on what the quote carries: you proposed the change, and it was credited with the uplift. Through two follow-ups return to that scope, and do not widen it. Answer slot: which stages after the proposal were yours. If any were, say which and how, in your own words; if none were, or they were not yours, say so plainly and return to the proposal | A2 is the attribution probe that follows A1 in a prober's two-level pattern. It is typed EXP because it scores attribution honesty, though it arrives in a pressure register (F2) |
| A3 | "Tell me about an analysis you ran yourself in SQL or Tableau, from question to output." | JD | [grounded] "skilled in SQL/Tableau" | An open prompt, so choose the instance. Selection criteria: an analysis that was yours end to end, with a stated question, the data you used, what you produced, what it changed, and what you would do differently. Open with the tools in your own words: "I'm skilled in SQL and Tableau." If no such analysis comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The JD puts independent analysis first in its list, and a self-described data-driven peer will test it (F3). JD because it scores the stated requirement |
| A4 | "A deck says expansion is up and hands you a renewal table to prove it. What do you check before you believe it?" | CASE | [generic] | Structure it aloud: how each metric is defined, which cohorts and denominators, the time window, who is missing from the table, and what result would change your conclusion. The question needs no claim about your past, so the guidance makes none | A live problem in the pack's own vocabulary of expansion and renewal, aimed at how the candidate treats numbers rather than at history (F2, F3). It is generic: a pattern, not a fact about Northwind |
| A5 | "Walk me through the partner-level revenue model you built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4, with the beats the quote states: you built it, it was partner-level, and it was used in carrier negotiations. Your words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: the JD's partner requirement and Dan's data focus make a probe on what drove the model's outputs likely. If you know, say it in your own words; if you did not build that part, or do not know, say so plainly and return to the model you built | F4 is the only partner-facing evidence and the likeliest place to be probed. EXP because it tests what was actually the candidate's |

### Bank B — Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [grounded] | Offer seam principles rather than pretending to know the seam: agree definitions and the metric first, say which decisions each side owns, and bring both views to the shared VP when a disagreement persists. Name what you bring his team, not only what you need. Your notes say the two roles report to the same VP, so that escalation path is real. The guidance makes no claim about your past | The peer prior makes seam-splitting near-certain, and the JD's influence requirement is where it lands (F5). It is grounded in the notes' reporting line |
| B2 | "You set annual volume targets with cross-org consensus. How did you get there?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Story-mapped on F5, with the beats the quote states: annual volume targets, set, with cross-org consensus. Your words: "I set annual volume targets with cross-org consensus." Expect Dan to ask if these were quotas. Keep your own term: annual volume targets. Answer slot: the JD's influence line makes a probe on where the orgs disagreed likely. If they did, say what and what moved; if they did not, or none of it was yours, say so plainly and stay with the targets | F5 is the strongest influence evidence and sits next to the sales-ops territory Dan owns (F5, F7). EXP because the premise is the candidate's own record |
| B3 | "How do you handle credit when work spans teams?" | JD | [generic] | A selection scaffold: pick an occasion where credit was shared across teams, with a named stake, what you did about it, and how the relationship held afterwards. If no such occasion comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Use "we" for the context and "I" for what you did | A persona stem for the peer relationship, scoring turf awareness and credit-sharing (F5). Generic because it asks for a pattern, not a claim |
| B4 | "What would you need from me in your first thirty days?" | JD | [grounded] "skilled in SQL/Tableau" | Reciprocity first. Ask for the definitions of land, adopt, expand and renew that the data uses and for access to the underlying data, then say what you can offer his team in your own words: "I'm skilled in SQL and Tableau." Offer working sessions, not deliverables you have not scoped | The reciprocity move converts a peer evaluator from assessor to collaborator and uses the JD's stage vocabulary (F2, F3) |
| B5 | "Suppose my team's data says an emerging product's expansion is weak and your read says otherwise. How do we settle it?" | CASE | [generic] | Structure it: agree on definitions and the time window, split the disagreement into what the data can and cannot show, decide in advance what result would change each of your minds, and if it stays open take both views to the shared VP. Disagree with spine and tact. The guidance makes no claim about your past | A disagreement-with-an-equal scenario tests collegial spine, the second pillar of the peer probe (F5) |

### Bank C — Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the go-to-market plan for Compass. What do you need to know first?" | CASE | [grounded] | Clarify first: who it is for, how it is sold (add-on or part of a package), what the launch is meant to prove. Then objective, segmentation, approach, metrics, risks. Your notes list the AI copilot launch ("Compass") among the three priorities, so use that vocabulary. Challenge one premise respectfully, and bring a pricing and packaging angle because that is Dan's native language. No claim about your past | The JD's go-to-market ownership and the notes' stated priority both point here (F1, F6). Typed CASE because it is delivered live |
| C2 | "A much larger platform vendor starts bundling a similar capability at no extra charge. How does that change how you package and price a new line, with profitability as a goal?" | CO | [grounded] | Clarify what is being bundled and for whom. Segment buyers by who values a standalone product and who accepts the bundle. Decide what you would measure: attach, displacement, and margin. Your notes name bundling by a much larger platform vendor as the main threat and profitability as a priority, so use those words, and say what you would want to learn before recommending. No claim about your past | A CO question grounded in the researched strategy, in Dan's pricing language (F1). CO because it scores whether the candidate thinks at Northwind's altitude |
| C3 | "How would you find whitespace across land, adopt, expand and renew for a brand-new product line?" | CASE | [generic] | Structure it: define each stage and how it is measured, set cohorts, find where customers drop or stall between stages, size the biggest gaps, and test the top one cheaply. State what you would need to confirm first. The guidance makes no claim about your past | Converts the JD's whitespace requirement into a live problem (F2). Generic: a method, not a fact about Northwind |

### Bank D — Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see classic sales-ops or quota-setting in your background. How would you handle that in a role that sits next to my team?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "set annual volume targets with cross-org consensus" and "built a partner-level revenue model used in carrier negotiations" | The highest-ROI rehearsal in the pack. Concede it plainly and do not apologise: "I don't have classic sales-ops or quota-setting experience." Then hold on what your quotes carry: "I set annual volume targets with cross-org consensus" and "I built a partner-level revenue model used in carrier negotiations." Do not call the targets quotas. Close with a ramp plan, said as a plan: what you would learn first, and what you would ask Dan to walk you through. Hold through two follow-ups by returning to those sentences, never by adding to them. The honest branch is a limit, not a confession | F7 is the stated gap and F5 and F4 the only adjacent evidence, and the question will arrive in some form from a peer in this function. JD because it scores the role's adjacency to sales ops |
| D2 | "Partner-motion design is required here. What have you designed?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Your words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if any of that work shaped how the partnership operated, beyond the numbers, say what and your part, in your own words; if none did, or it was not yours, say so plainly and stay with the model you built. Hold through two follow-ups by returning to the model | The JD marks it required, and F4 is adjacent rather than direct. JD because it scores a stated requirement and its gap |
| D3 | "You've spent nine years in consumer tech. Why B2B data infrastructure, and why now?" | EXP | [grounded] "a large consumer-tech company in product strategy & ops" | Give your actual reason, in your own words. The pack supplies none. Connect it to Northwind's priorities (enterprise expansion, the Compass launch) only if that connection is true for you. Start from your own words: "I worked in product strategy and ops at a large consumer-tech company." Then your reason, then what you would want to learn first. Where you have no reason you can stand behind, say so plainly and say what draws you to this role | The background-mismatch probe is the standard skeptic's motivation question (F8). EXP because the answer rests on the candidate's own history |

### Bank E — Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" and "built a partner-level revenue model used in carrier negotiations" and "proposed a store-surface change credited with a ~$400M ARR uplift" | A 90-second arc with three beats in your own words: "two years in strategy consulting at a top firm, then nine in product strategy and ops at a large consumer-tech company"; then the revenue model and the store-surface proposal at the scope your quotes carry; then why this role, which is yours to supply. End on the role, not on a recap | Rapport openers set the frame for the hour and are still scored (F1, F2, F4). EXP because it is the work-history walk-through |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Your words: "I use AI tools daily." Answer slot: the JD's plus and the Compass launch make a follow-up on what you use them for likely. Say which tools and for what, in your own words; if it goes no further than use of tools, say that plainly. Do not describe building or launching AI products | The JD flags AI as a plus, so a casual question about it is scored (F6) |

### Bank G — Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over someone who has done sales ops for years?" | JD | [grounded] "No classic sales-ops or quota-setting experience." and "built a partner-level revenue model used in carrier negotiations" and "set annual volume targets with cross-org consensus" | Pause, restate, then hold-then-concede. Concede first: "I don't have classic sales-ops or quota-setting experience." Then hold on the quotes: "I built a partner-level revenue model used in carrier negotiations" and "I set annual volume targets with cross-org consensus." Let Dan draw the inference; do not assert that this work proves you can do his. Do not fold on those two sentences, and do not add to them | The time-boxed twin of D1 for a pressure register (F7, F4, F5). Typed JD because it scores the requirement gap, whatever the delivery |
| G2 | "If finance told me that figure was half what you say, what would you say?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause, then hold on scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: if you know how that figure was counted, say so; if you do not, say that plainly and ask how finance counts it. Never defend a method you cannot repeat under a second question | A data-driven peer may test whether the headline number holds under challenge (F2). It follows A1 and A2 as the third level of the same probe |

## Requirement coverage

| JD requirement or stated priority | Questions |
|---|---|
| "own GTM strategy for two new product lines" | C1, C2, G1, E1 |
| "identify whitespace across land/adopt/expand/renew" | C3, A4, B4 |
| "run independent analysis in SQL and Tableau" | A3, A4, B4 |
| "partner-motion design experience required" | D2, A5 |
| "strong cross-functional influence" | B1, B2, B3, B5 |
| "AI experience a plus" | E2, C1 |
| "enterprise expansion" (priority) | D3 |
| the AI copilot launch ('Compass') (priority) | C1 |
| reaching profitability (priority) | C2 |
| bundling by a much larger platform vendor (threat) | C2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You've spent most of your career in pricing and monetization, with an early-stage chapter. How has that shaped how you approach sales strategy here?" | Tied to his own path, which turns an interrogation into a peer conversation and shows you looked at him, not only the company |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question for a peer: it shows you are thinking about his load, not only your own onboarding |
| R3 | "Where do you see the seam between Sales Strategy and the owner of the two new product lines, and where has it been unclear?" | Names the exact seam the interview is testing and invites him to describe it, rather than you asserting one |
| R4 | "How is the team thinking about packaging Compass against bundled offerings from larger platform vendors?" | Uses the competitive threat from your research note and gives a pricing-minded peer something to talk about |
| R5 | "Which definitions of land, adopt, expand and renew does the team use today, and where do they disagree?" | Uses the JD's vocabulary and signals that you would start with definitions before analysis, which a data-driven peer values |
| R6 | "What would a good first year look like in the numbers you would look at?" | Gives him a chance to state the scoreboard and tells you how the role is judged |

## Prohibited claims

Built from the fit snapshot before the banks. None of these appears in any guidance cell as something to say.

| Not coached | Basis | Honest form |
|---|---|---|
| Has classic sales-ops or quota-setting experience | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I don't have classic sales-ops or quota-setting experience." No slot |
| Calling the annual volume targets quotas, or having set quotas | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation: your material says annual volume targets, not quotas |
| Designed or owned a partner motion | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: your material says a revenue model used in carrier negotiations, not a partner motion. D2's slot stays inside the model |
| Drove, delivered or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote at its own scope: proposed, and credited with. The limit is the pack's observation |
| Owned go-to-market strategy for a product | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: your material says product strategy and ops |
| Built or launched AI products | Inflated form of F6 | F6's quote at its own scope: use of AI tools |
| Ran B2B enterprise land, adopt, expand or renew motions | Inflated form of F2 and F8 | The quotes at their own scope; the limit is the pack's observation: your material shows a consumer-tech setting |

## Sources

**Provided documents:** the coach's message: role and company, JD highlights, candidate summary, interviewer profile, and a research note on Northwind's three priorities and its main competitive threat. No CV, full JD, dossier or assessment was supplied.

**Searches sent (all refused, none returned results):**
- `Northwind Data company values B2B data infrastructure` — refused
- `Dan Kovac Director of Sales Strategy Northwind Data` — refused

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Both calls were refused. It would have supplied the official value names; with no values-style round detected it would have themed VAL questions, which this pack does not have |
| 2. `{company} interview process {role family}` | skipped | Your own words fix the loop: one 60-minute conversation with a peer. Persona weights follow that |
| 3. `{company} strategy` / recent news | skipped | The research note in hand supplies the three priorities and the competitive threat that feed the CO and CASE banks. Its age was not stated, which the upgrade menu notes |
| 4. `{interviewer name} {company}` | unavailable | The query was refused. It would have added public talks and writing to the interviewer read and a theme-based reverse question |
| 5. representative `{role title}` JD | skipped | The JD highlights you supplied fix the fit snapshot's requirements and JD-tagged questions; the full text is in the upgrade menu |

## Upgrade menu

- The full JD text → every requirement row quotes the JD itself, any mid-list requirement or term such as location, schedule or pay becomes visible, and the coverage table is rechecked against the real list
- Priya's CV text → the fit snapshot quotes her own document instead of the coach's notes, and rows F1, F2, F4 and F8 can move from scaffold toward story-mapped guidance
- Priya's own answers to the slots in F1, F2, F4 and A1 to A5 → rows regenerate from her words, and the pack states exactly what she can defend
- An inspectable artifact for F3, such as a Tableau workbook or a query she wrote, and for F2, the review or memo in which the uplift was credited → medium confidence can rise to high
- Dan's public talks, posts or profile text, and search permission → a fuller interviewer read and a theme-based reverse question
- Northwind's official values page, plus any recruiter note on round structure → a values cheat sheet if a values round exists
- A dated Northwind strategy source under six months old, or the age of the research note → CO and CASE banks confirmed current
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → an interviewer deep-dive and loop reports; offered once, and it needs search permitted in this session
- A `tuesday-dossier.md` from an earlier session, if one exists → verified evidence and prohibited claims would arrive pre-graded; the pack does not need it
