# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Mode:** loop, three rounds on 3 December 2026, built on the recruiter's email. **Interviewers:** no names yet. Round 1 is the recruiter (30 minutes), round 2 is the Head of Member Services, who would be your manager (45 minutes, mostly behavioural), round 3 is a panel of two branch managers (60 minutes, including a 20-minute case on a complaint escalation, and the round scored against the four values).

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: every claim about your past rests on a sentence you wrote, quoted next to it, and where your material is silent the guidance is an instruction for the interview, not a story.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the published values |
| EXP | Whether your experience survives questions about what was actually you |
| JD | The listed requirements, including the gaps |
| CO | Company and strategy knowledge |
| CASE | Structure and reasoning on a live problem |

An answer slot is an instruction for the interview. It names a probe the interviewer is likely to raise, then gives two honest branches: say it in your own words if it happened, or say plainly that it did not or was not yours, and return to what your own sentences do carry. Either branch is a good answer.

## Fit snapshot (shared by all three rounds)

No requirement in the JD is a term such as a licence, location or pay, so no row is a hard gate. Your evidence is quoted from your message; there is no CV in hand.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on length. Lead with your own terms: six years in retail banking, the last three as a branch supervisor. It is a self-reported line with nothing inspected behind it, so expect a probe on what the six years covered |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [inferred] | discovery | Your sentence says a formal complaints log, which does not show whether the complaints were regulated or which rules applied. Words stay at the quote: "I handled the branch's formal complaints log." Answer slot: the JD's word "regulated" makes a probe on the rules likely. If the formal complaints followed a regulatory process, say which and what handling steps were yours, in your own words; if the log was an internal process, or you do not know which rules governed it, say so plainly and stay with the log |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence says the branch's log, not the process, and one branch, not several. Words: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the stages likely. If any stage beyond the log was yours to set or run, say which and how, in your own words; if there was no such stage, or it was not yours, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never a claim to contact-centre work |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [inferred] | discovery | Your sentence says a monthly complaints spreadsheet your regional manager uses, and does not show what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if it counted volumes or resolution times, say how each was counted; if either was not in it, say so plainly and say what you would count first |
| F6 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your sentence says tellers, not supervisors. Words: "I trained new tellers on our escalation script." Answer slot: the JD says supervisors, so expect a probe on whether you have coached anyone at your own level or above on escalations. If you have, say who and how; if not, say so plainly and stay with the tellers |
| F7 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show work with digital teams or self-service. Answer slot: if you have worked with a digital or online team, or on any self-service channel, say what it was and which part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | You stated the limit. Words: "I haven't presented to anyone above regional level." The pack's observation: the JD does not say who counts as a senior leader, so whether regional level is close is a question for the recruiter (round 1 reverse question 1). Then how you would prepare, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Lead with the quote's own terms: you built it, it is monthly, your regional manager uses it. Your sentence says spreadsheet and does not name the tool, so say Excel only if Excel is what it was |

**Highest-ROI prep in the pack:** B5. The JD's first line asks for end-to-end ownership across branches and the contact centre, and your material carries one branch's log and a stated absence on the contact centre (F3, F4). Some form of that question will come in every round (A8, B5, C5, C7), and a rehearsed, specific, non-defensive answer changes the interview.

## Grounding brief (shared)

Your summary of the 2026 strategy brief Ashgrove published in July 2026. I have your four points, not the full document.

| Item | As you reported it | Provenance | Used in |
|---|---|---|---|
| Digital shift | "move 40% of member service to digital channels by 2028" | [grounded] | A2, B9 |
| Branch network | "consolidate eight branches into five hubs over 2027" | [grounded] | C3, C7 |
| New product | "launch a small-business lending product in Q1 2027" | [grounded] | A2 |
| Competition | "the main competitive pressure is app-only banks" | [grounded] | A2, B9 |

The brief is four months old. Anything that has moved since is a good question for round 1 (reverse question 3).

---

# Round 1: Recruiter, 30 minutes

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly, unstructured; biography, motivation, then pay, notice, location and reason for moving | Top. The recruiter row sets Conversational first, and the four logistics questions are required in every recruiter screen | Pre-script a 90-second arc; treat casual questions as scored |
| Skeptic (light) | Knockout checks on the JD's hard-looking lines | Light. The recruiter row adds a light Skeptic, and F2 and F4 are the lines a screen checks first | Rehearse the one predictable objection until it is boring |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background, and what draws you to this role." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in three beats, each a clause the quotes state: six years in retail banking, the last three as a branch supervisor; handled the branch's formal complaints log and trained new tellers on the escalation script; built the monthly complaints spreadsheet your regional manager uses. Then your reason for this role, in your own words: the pack does not supply it, and one or two true sentences beat a long one | Recruiters open with the biography and score economy and fit. F1, F2 and F5 are what the arc rests on. EXP because it tests what the CV line really covers; the years requirement is its secondary read |
| A2 | "What do you know about Ashgrove, and why us?" | CO | [grounded] your summary of the strategy brief, and the values page you pasted | Name one strategy point and one value in a sentence each, then say in your own words why each matters to you. Candidates tend to recite the whole brief; one point with your own reason scores higher than four without | The first homework check; the grounding brief and the values supply it. CO because it scores knowledge of the company |
| A3 | "What are your salary expectations?" | JD | [generic] | Pay is logistics and the answer is yours alone. Either give your own number, or ask for the role's band first and respond to it. If you are asked what you earn now, you can decline and steer back to what you are looking for in this role. The pack holds no figure for you | The recruiter row requires a pay question in every screen. JD because it concerns the job's terms |
| A4 | "What is your notice period, and when could you start?" | JD | [generic] | Give your actual notice period, in your own words, as your contract states it | Logistics slot; the recruiter needs it to plan. JD because it concerns the job's terms |
| A5 | "Where are you based, and could you work across more than one site?" | JD | [generic] | Give your actual location and any limit on travelling between sites, as it is. The JD says the role runs across branches and the contact centre, which is why the question is asked | Logistics slot; the JD's across-branches line makes site coverage a live point. JD because it concerns the job's terms |
| A6 | "What is prompting a move now?" | EXP | [generic] | Give your actual reason in one or two sentences, true and in your own words. If it is about what you want next, say that; if it is about what you are leaving, keep to facts and keep it short | Motivation-consistency is the recruiter's second check. EXP because it tests whether the story holds together |
| A7 | "The role needs experience handling regulated complaints. What have you handled?" | JD | [inferred] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say what the quote says, at its own scope: you handled the branch's formal complaints log. Answer slot: if the formal complaints followed a regulatory process, say which rules and what handling steps were yours, in your own words; if the log was an internal process, or you do not know which rules governed it, say so plainly and stay with the log | F2 is the likeliest knockout in a screen because the JD names it. JD because it scores a stated requirement |
| A8 | "This role covers the contact centre too, and I don't see contact-centre experience. How do you see that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Short and plain, which is the whole point of a screen answer: "I haven't worked in a contact centre." Then a plan, said as a plan: in the first weeks you would spend time with that team and learn how complaints reach it and how they pass to branches. Do not widen it into experience. Then stop and let the recruiter lead | F4 is the stated gap; a recruiter screen is where it is first priced. JD because it scores the stated requirement; the full-depth rehearsal is B5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1.1 | "Who are the senior leaders this role presents to, and how often?" | Sizes F8 for you, and shows you read the role's reporting line |
| R1.2 | "For the round-three case, is the escalation scenario given in advance or live, and does it involve role-play?" | Lets you rehearse the right format, and shows you are planning for the panel |
| R1.3 | "Has anything in the July strategy brief moved since it was published, especially the hub timeline?" | Shows you read the brief and checks it is current |
| R1.4 | "How does the team report on complaints today, and what tools does it use?" | Connects the Excel line to the real setup |
| R1.5 | "What would a strong first ninety days look like?" | A generic opener that recruiters answer in detail, which tells you what the role is judged on |

---

# Round 2: Head of Member Services, 45 minutes (your future manager)

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioural | Scenario probes, story-shaped answers | Top. The hiring-manager prior leans Case and Skeptic, and the recruiter's note that this round is mostly behavioural moves Values/Behavioural to the top | Map a story only where your sentences carry one; otherwise use a selection scaffold with its honest branch |
| Skeptic | Quiet, persistent probing of gaps | High. A manager is buying capability and derisking, and F3, F4 and F8 are where the risk sits | Rehearse the one objection (B5) through three follow-ups; hold then concede specifically |
| Case/Strategist | One or two live problems from the role | Low. Two questions only, because the round is described as mostly behavioural | Clarify, structure, answer; use Ashgrove's own vocabulary |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time you had to deliver an unpopular truth to someone senior." | VAL | [generic] | Selection criteria: a named stake, a message you did not soften, and a working relationship intact afterwards. Pick one where the hard truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard manager probe on candour with leadership; the role reports monthly to leaders. VAL because it scores behaviour, not the JD |
| B2 | "Tell me about a time you helped a colleague get an escalation right." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F6 and kept inside the quote: you trained new tellers on the escalation script. Answer slot: the JD says the role coaches branch supervisors, so expect a probe on whether you have coached anyone at your own level or above. If you have, say who and how, in your own words; if not, say so plainly and describe the training of the tellers | F6 is the direct evidence for the coaching line and the place it will be tested. EXP because it tests what the training really was |
| B3 | "Walk me through the monthly complaints spreadsheet you built." | EXP | [inferred] "I built the monthly complaints spreadsheet our regional manager uses." | Start with the quote: you built it, it is monthly, your regional manager uses it. Answer slot: the JD asks for reporting on volumes and resolution times, so expect a probe on what the spreadsheet counted. If it counted either, say how each was counted, what it is most sensitive to, and which assumption you would defend least; if neither was in it, say so plainly and say what you would count first. Excel: if it was built in Excel, say so; if it was another tool, say that | F5 and F9 are one row each in the JD and one sentence in your material, so both converge here. EXP because it tests attribution and method; JD is the secondary read |
| B4 | "Tell me about a time you worked with a team outside your branch to improve how members got something done." | JD | [grounded] the JD's "work with digital teams on self-service journeys" | No sentence of yours carries a story here, so use selection criteria: a named other team, a member-facing change, and what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7 has no evidence in your material, so this question will expose it; rehearse the honest branch. JD because it scores a stated requirement; VAL is the secondary read |
| B5 | "This role owns complaints end to end, across branches and the contact centre. You've handled one branch's complaints log and haven't worked in a contact centre. What makes you ready?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." "Never worked in a contact centre, and I've never presented to anyone above regional level." | **The highest-ROI rehearsal.** Say the limit first, before it is asked for: "I haven't worked in a contact centre, and what I've handled is the branch's formal complaints log." Then the hold, using only your sentences: you handled the log, you trained new tellers on the escalation script, you built the monthly spreadsheet your regional manager uses. Follow-up 1, "what did you own beyond the log?": answer slot. If any stage beyond the log was yours to set or run, say which and how; if none was, say so plainly and return to the log. Follow-up 2, "how would you learn the contact centre?": a plan, said as a plan, not a past: time with that team, how complaints reach it and where they pass to branches. Hold through two follow-ups by returning to your sentences, never by adding to them | The question the whole JD is built around, aimed at exactly where F3 and F4 are thin. Skeptic delivery, JD content |
| B6 | "How confident are you presenting to senior leaders, and who have you presented to?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment first: "I haven't presented to anyone above regional level." Answer slot: if you have presented to your regional manager or others at that level, say who and what, in your own words; if there was no such presentation, say so plainly. Then a plan: agree the one decision the audience needs from you before you start, and practise the monthly report aloud with someone first | F8 is a stated limit and the JD asks for confidence, so this will come. JD because it scores a stated requirement |
| B7 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Your material states two limits: the contact centre and presenting above regional level. Pick the one you honestly feel is bigger, say it as "I haven't...", then the plan from B5 or B6. A manager scores whether you know your own limits, so do not choose a trivial weakness | Honest self-assessment is what a manager is buying. JD because it maps to the stated requirements |
| B8 | "Sketch how you would report monthly on complaint volumes and resolution times to the senior team. What do you need to know first?" | CASE | [generic] | Clarify before you structure: what counts as a complaint, who reads the report and what they decide from it. Then objective, a split by branch and by channel, the measures, and the risks (definitions that differ between branches and the contact centre). Think aloud and challenge one premise respectfully. The question needs no claim about your past, so the guidance makes none | The JD's reporting line, asked as a live problem; this is the Case persona's one native question here. CASE because it scores structure |
| B9 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that mean for complaints?" | CO | [inferred] derived from the brief's 40% line and the JD's self-service line | Bring one consensus point to show you read the brief: more routine contact moves to digital channels. Then one position of your own, offered as a thesis to test: complaints may be the contacts that most need a person, so the digital move should be designed with escalation to a person built in. Concession, which is mandatory: you do not know Ashgrove's contact mix, and the thesis may be wrong. Your material has no digital work in it (F7), so argue from reasoning and say so | The brief is published, so any prepared candidate recites it; the differentiator is a reasoned divergence with a concession. CO because it scores strategy knowledge |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R2.1 | "What do you want the monthly complaints reporting to help you decide?" | Shows you think of a report as a decision tool |
| R2.2 | "How do complaints move between branches and the contact centre today, and where is that hardest?" | Concrete and role-specific; lets you hear the real problem |
| R2.3 | "What would success look like at six months?" | Gets you the scoring sheet for your first half-year |
| R2.4 | "How will self-service journeys be prioritised alongside complaints work, given the 40% digital target?" | Ties the role to the strategy, and shows F7 is a topic you are ready to learn |
| R2.5 | "What support would a new lead get to learn the contact-centre side?" | Signals a plan for F4 without hiding it |

---

# Round 3: Panel of two branch managers, 60 minutes (values round, with a 20-minute case)

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values/Behavioural | Scenario probes scored against the four values | Top. The recruiter says this panel is the values round and scores against the four values | One question per value (C1 to C4); map where your sentences carry a story |
| Case/Strategist | The 20-minute complaint escalation case | Mid. The recruiter announced the case, but its format is not known | Clarify, structure, answer; think aloud |
| Peer Evaluator | Seam-splitting, "what would you need from me" | Mid. The JD has the role coaching branch supervisors, so branch managers are plausible counterparties; their relationship to the role is an assumption, since the email does not state it | Reciprocity framing; propose principles for the seam, not a pretended knowledge of it |

## Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] the value "Members First, Always" from the page you pasted | Selection criteria: the member's position, the internal pressure you set against it (a rule, a target, a queue), and what you decided. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Every published value gets a question; this is the first. VAL because it scores the value by name |
| C2 | "Tell me about a time you made something clearer for a member, or for a colleague who had to explain it to one." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F6 at its scope: you trained new tellers on the escalation script. Answer slot: Plain Words says a member who needs it explained twice means the words were wrong, so expect a probe on whether the script read clearly. If you saw wording that needed explaining twice, say what you saw and what was done, in your own words; if not, or the script was not yours to change, say so plainly and stay with the training | The value "Plain Words" and F6 are the nearest pair in your material. VAL because it scores the value |
| C3 | "Tell me about a time you did something that took account of a particular branch and its town, not one process for everyone." | VAL | [grounded] the value "Neighbours, Not Numbers" from the page you pasted | No sentence of yours carries this story, so use selection criteria: the place, what the standard process would have done, and what you changed or chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The brief's hub consolidation (C7) sets this value against the strategy, so expect it to be sharp. VAL because it scores the value |
| C4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on one beat, at its scope: you handled the branch's formal complaints log. Answer slot: the value says whoever finds the problem keeps hold of it, so expect a probe on a case you carried. If there was one, say what the problem was, what you did, and how you knew it was solved; if cases passed to others once logged, or none was yours to carry, say so plainly and stay with the log | The value "Own the Fix" mirrors the JD's end-to-end line, so F3 is probed through it. VAL because it scores the value |
| C5 | "A member has complained twice at a branch and has now rung the contact centre. The branch says it is resolved; the member says it is not. A branch supervisor asks what to do. Walk us through it." | CASE | [generic] | Clarify first: what the complaint was, what was promised, where the record is, and whether any deadline or regulatory rule applies and who knows it. Objective: one named person holds the case until it is solved. Then the member: an explanation in plain words, once. Then the supervisor: what to do next time. Close with the follow-up and the record. The question needs no claim about your past, so the guidance makes none. The case format is unknown: ask the recruiter (R1.2) | The announced 20-minute case, built on the JD's escalation lines and the Own the Fix and Plain Words values. CASE because it scores structure and reasoning |
| C6 | "A branch supervisor sends nearly every complaint up to you rather than resolving it at the counter. How do you coach them?" | CASE | [generic] | Clarify why: what the supervisor is unsure of, such as authority, wording or fear. Agree what resolving at the counter means. Coach one case at a time, then check back. The question asks about no past. Your material says you trained tellers (F6), not supervisors, so do not describe coaching supervisors as something you have done | The JD's coaching line as a live problem. CASE because it scores how you would coach |
| C7 | "Over 2027 eight branches become five hubs. How should complaint handling change for members whose branch is consolidated?" | CO | [inferred] derived from the brief's hub line and the value "Neighbours, Not Numbers" | One consensus point: hubs mean fewer sites and more routing, so escalation paths need to be clear. One position of your own, offered as a thesis: members whose branch is consolidated should keep a named person for a complaint, so Neighbours, Not Numbers survives the change. Concession, mandatory: you do not know Ashgrove's hub design, and the thesis may not fit it | The strategy question most likely to be asked by branch managers; the brief is published, so differentiate by reasoning. CO because it scores strategy knowledge |
| C8 | "Our branches and your role sit side by side. Where is the seam, and what happens when we disagree about whether a complaint is resolved?" | CASE | [generic] | Propose principles, not facts about the seam: who decides that a complaint is resolved (the member's view counts), how a disagreement is escalated, and what is recorded. Reciprocity: say what you bring the branch, not only what you need | The Peer persona's native question, and the one most likely to come from branch managers. CASE because it asks for a live position |
| C9 | "Tell me about a time your work depended on another team or branch." | EXP | [grounded] the JD's "across branches and the contact centre" | No sentence of yours carries this story, so use selection criteria: the other team, what you needed from them, and how you handled a disagreement without losing the relationship. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A peer probe on collaboration and credit; the JD makes it a live question. EXP because it scores what you did |
| C10 | "What would you need from us as branch managers to make this role work?" | JD | [generic] | A reciprocity answer: clear access to case records, a named contact in each branch, and a say in how escalations are measured. Offer to hear what they need first. The question asks nothing about your past | The Peer persona asks it, and a bare list of needs reads as taking, so pair it with an offer. JD because it scores how you would work with branches |

## Values and principles cheat sheet

The values are from the page you pasted on 24 November 2026 (ashgrovecu.org/about/values).

| Value (official name) | Working meaning | Mapped story | Asked in |
|---|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold, ending in its honest branch: pick a decision where the member's position and an internal pressure pulled apart; if none comes to mind, say so plainly | C1 |
| Plain Words | If a member needs it explained twice, the wording was wrong | F6 "I handled the branch's formal complaints log and trained new tellers on our escalation script." — kept at its scope, with the answer slot in C2 | C2 |
| Neighbours, Not Numbers | Each branch is part of its town | Selection scaffold, ending in its honest branch: pick a time you took account of one branch's town; if none comes to mind, say so plainly | C3 |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F3 "I handled the branch's formal complaints log and trained new tellers on our escalation script." — kept at its scope, with the answer slot in C4 | C4 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R3.1 | "What do you most want from the complaints lead when something escalates from your branch?" | The peer question; it converts the panel into a conversation about their side |
| R3.2 | "As branches move towards hubs, what would you most want members' complaints experience to keep?" | Ties the strategy to the Neighbours value |
| R3.3 | "How do your supervisors handle escalations today, and what would you want coaching to change?" | Shows the coaching line is a real topic for you |
| R3.4 | "What does a good outcome from a complaint look like from your branch's side?" | Takes the member's-side-of-the-counter view into their own terms |
| R3.5 | "What is one thing a new person in this role could do in the first month that would genuinely help your branch?" | The reciprocity question for a peer panel |

---

## Requirement coverage

| JD requirement | Questions | Fit rows |
|---|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | A8, B5, C5, C7 | F3, F4 |
| "report monthly on complaint volumes and resolution times" | B3, B8 | F5 |
| "coach branch supervisors on escalations" | B2, C6 | F6 |
| "work with digital teams on self-service journeys" | B4, B9 | F7 |
| "4+ years in financial-services customer operations" | A1 | F1 |
| "experience handling regulated complaints" | A7 | F2 |
| "confident presenting to senior leaders" | B6, B7 | F8 |
| "comfortable with Excel reporting" | B3 | F9 |
| Values: Members First, Plain Words, Neighbours, Own the Fix | C1, C2, C3, C4 | cheat sheet |

A3 to A6 are the recruiter's logistics questions and map to no JD line.

## Prohibited claims

Built from the fit snapshot before the banks. Each entry is a claim this pack will not coach, with its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation, not words for you: your material says the log, not the process across branches. Slots in A7, B5 and C4 stay inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says a formal complaints log and does not say which rules applied. A7's slot asks only what the rules were, if any |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote at its own scope: "I trained new tellers on our escalation script." The quote names tellers, not supervisors |
| Reported monthly on volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." The quote names a spreadsheet, not its contents |
| Has contact-centre experience | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." B6's slot asks only about presentations at or below that level |

## Sources

Provided documents: the JD; the values text you pasted on 24 November 2026, which you said was copied from ashgrovecu.org/about/values; the recruiter's email on the process; your four-point summary of the July 2026 strategy brief (the brief itself was not pasted); your background paragraph (no CV). No searches or fetches were sent. No dossier was present.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The pasted values text fixes the cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member services` | skipped | The recruiter's email fixes the loop: three rounds, who runs each, the case and the values round, so persona weights follow it |
| 3. `Ashgrove Credit Union strategy` | skipped | The four brief points you gave fix the CO questions B9, C7 and the grounding brief |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name has been assigned, so there is no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The recruiter's answer on the round-three case (given in advance or live, role-play or not) → C5 and C6 become `[grounded]` on the real format, instead of `[generic]` patterns
- Interviewer names, once assigned → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to each one's own path
- Your CV → more evidence rows beyond the four sentences in your message, so more F rows can move from `discovery` toward `none`
- Your answers to the answer slots, said outside a drill (what the formal complaints followed, whether the spreadsheet counted volumes or resolution times, whether you have coached anyone above teller level, any digital or self-service work) → F2, F3, F5, F6 and F7 and the questions that draw on them become `[grounded]`
- The full strategy brief → deeper CO and CASE questions in B9 and C7, with more than four points to differentiate from
- Your pay figure, notice period, location and reason for moving, stated in your own words → A3 to A6 filled with your words, not instructions
- How many hours you have before 3 December → a prioritised prep schedule
- A deeper research pass, offered once — up to 6 more searches and 2 more fetches, several more minutes — which would add recent organisational context and any published interview reports for credit unions; it pays off most once interviewer names are known
- A `tuesday-dossier.md` from a job-underwriter run → verified evidence, a prohibited-claims list and a named top objection, which would replace the ones this pack inferred
