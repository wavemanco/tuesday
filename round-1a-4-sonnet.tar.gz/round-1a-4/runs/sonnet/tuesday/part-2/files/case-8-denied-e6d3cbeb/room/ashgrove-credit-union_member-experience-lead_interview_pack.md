# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Date of all three rounds:** 3 December 2026. **Mode:** loop, three scheduled rounds, because the recruiter's email says who runs each and what each holds.

| Round | Who | Length | What it holds |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Screen |
| 2 | Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | A 20-minute case on a complaint escalation; also the values round, scored against the four values |

No interviewer names are assigned yet, so there is no interviewer read and persona weights run on each person's role.

## How to use this pack

- **Personas are how a question arrives; types are what it scores.** Rehearse both.
- **Type key.** VAL: behavioural, whether past behaviour shows a published Ashgrove value. EXP: whether a claim about your work survives scrutiny. JD: a stated responsibility or requirement. CO: company and strategy knowledge. CASE: a live problem, scored on structure.
- **Guidance is scaffolding, not a script.** Every claim about your past rests on a sentence you wrote, quoted in the Provenance column.
- **An answer slot is an instruction for the interview, not a question for me.** Where your material is silent, the slot gives two honest branches: say how you did it in your own words, or say plainly that it did not happen or was not yours. Both are scored well; inventing is not.
- **Highest-ROI prep: D1**, the contact-centre question. It is the one question this pack expects in some form in rounds 1, 2 and 3. Rehearse it until it is boring.

## Fit snapshot

Gates: the JD you pasted names no authorisation, licence, location, schedule, pay or travel term, so there are no gate rows.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor" — your message | medium | [grounded] | presentation | A message line with nothing inspected behind it. Say it in its own terms: "I have 6 years in retail banking, the last 3 as a branch supervisor." The JD's phrase "customer operations" stays the interviewer's; let them map it, and if they ask whether your branch work counts, answer with what the job involved, from your other rows, adding nothing new |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [inferred] | discovery | A formal complaints log touches the requirement without showing whether the complaints were regulated. Words: "I handled the branch's formal complaints log." Answer slot: the JD's regulated-complaints line makes a probe on what governed the log likely. If any regulatory requirement governed it, say which and what it required of you, in your own words; if none did, or you do not know, say so plainly and stay with the log you handled |
| F3 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says one branch's log, not the process and not across branches, and the words stay at the log: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on what sat around the log likely. If you had any part in what happened before or after an entry reached it, say what and how, in your own words; if you did not, say so plainly and stay with the log |
| F4 | "across branches and the contact centre" — JD | "Never worked in a contact centre" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked in a contact centre." Then what you would do first to learn how complaints reach and move through it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | A monthly complaints spreadsheet touches the requirement without showing what it counted. Words: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: the JD names volumes and resolution times, so expect a probe on what the spreadsheet showed. If it counted either, say what and how you counted it, in your own words; if it showed neither, say so plainly and say what it did show |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses" — your message | medium | [inferred] | discovery | Your sentence says spreadsheet, not Excel, and the words stay as written. Answer slot: if it was built in Excel, say so; if it was another tool, name it and say plainly how you would work in Excel |
| F7 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script" — your message | medium | [grounded] | transferability | Your material says new tellers and a script: "I trained new tellers on our escalation script." Coaching supervisors is a wider step. Answer slot: if you ever walked a peer or a supervisor through an escalation, say who and how, in your own words; if the training reached only new tellers, say so plainly and stay there |
| F8 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level" — your message | none | [grounded] | capability | A gap you have stated. Words: "I haven't presented to anyone above regional level." Then how you would prepare for a first senior presentation, said as a plan and never as a past. Your material does not say what you presented at regional level, so describe none of it unless you can name it |
| F9 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing here. Answer slot: if you have worked with a digital, IT or head-office team on anything members used, say what and what part was yours, in your own words; if you have not, say so plainly and say what you would ask a digital team first |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation: your material says the branch's log, not the process. D3 and G4 stay inside the log |
| Handled regulated complaints | Inflated form of F2 | F2's quote at its own scope. The material says a formal complaints log, not which rules governed it. E1's slot asks only what governed the log |
| Coached branch supervisors on escalations | Inflated form of F7 | F7's quote at its own scope: new tellers and a script. C2 and I2 stay with the tellers |
| Wrote the escalation script | Inflated form of F7 | The quote says "our escalation script" and that you trained tellers on it. The material does not say who wrote it |
| Reported complaint volumes and resolution times | Inflated form of F5 | F5's quote at its own scope: a monthly complaints spreadsheet. The material does not say what it counted. E2's slot asks what it showed |
| Built the complaints reporting in Excel | Inflated form of F6 | F6's quote at its own scope: a spreadsheet. The material does not name the tool |
| Has contact-centre experience | Negative the candidate stated, F4 | The plain acknowledgment F4 gives: "I haven't worked in a contact centre." No slot |
| Has presented to senior leaders | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I haven't presented to anyone above regional level." No slot |

## What the strategy brief gives you to work with

Taken from the 2026 strategy brief Ashgrove published in July 2026, as you gave it to me. The full text was not in front of me, so this is those four points only.

| Brief item, as you gave it | Where it surfaces | Provenance |
|---|---|---|
| Move 40% of member service to digital channels by 2028 | F1, C3, reverse question 2.5 | [grounded] |
| Consolidate eight branches into five hubs over 2027 | H2, G3, reverse question 3.4 | [grounded] |
| Launch a small-business lending product in Q1 2027 | H3 | [grounded] |
| Main competitive pressure is app-only banks | F1, H1, H2 | [grounded] |

## Persona table and weights

Weights come from relationship priors, then the loop. No interviewer profile exists, so no signal adjustments were made. The loop is established by the recruiter's email, so no archetype fallback is used. The recruiter's email says round 3 is the values round, so a values-style round is detected there.

| Round | Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 | Conversational (A) | Friendly biography and logistics questions that are still scored | Top: a recruiter screen's logistics (pay, notice, location) arrive in a friendly register | A 90-second arc built from your quotes; each logistics answer is your own |
| 1 | Skeptic, light (B) | Knockout checks, "why leave", the gap questions | Mid: the recruiter is checking the JD's requirements against what you said | Plain acknowledgments, then a plan |
| 2 | Values/Behavioral (C) | Behavioural prompts, "tell me about a time" | Top: the recruiter says this round is mostly behavioural | Story where a quote carries one; a selection scaffold with the honest branch where none does |
| 2 | Skeptic (D) | Quiet probing of the contact-centre and senior-presenting gaps | Mid: this person would be your manager, so is pricing the risk of the hire | Concede the limit first, hold what your quotes carry, offer a plan |
| 2 | Data-Driven Prober (E) | Walk-throughs of the log and the spreadsheet | Low: the two artifacts you named are the only things to probe | Say what you know of how things were counted; say plainly where you do not |
| 2 | Case/Strategist (F) | Live problems on the strategy | Low: a behavioural round, but a manager buys capability for the road ahead | Clarify, structure, think aloud, challenge one premise respectfully |
| 3 | Values/Behavioral (G) | One scored question per value | Top: the panel scores against the four values | One story or scaffold per value; "I" for contribution, "we" for context |
| 3 | Case/Strategist (H) | The 20-minute escalation case, plus strategy questions | Mid: the recruiter says a 20-minute case on a complaint escalation sits inside this round | Clarify, objective, segmentation, approach, metrics, risks, aloud |
| 3 | Peer Evaluator (I) | "What would you need from us", the seam with branches | Mid: branch managers are the people whose supervisors you would coach | Reciprocity first; propose seam principles, not a pretend seam |

If the panel returns to the contact centre or to presenting above regional level, D1 and D2 are the rehearsal.

## Round 1: the recruiter (30 minutes)

### A. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor"; "I handled the branch's formal complaints log and trained new tellers on our escalation script"; "I built the monthly complaints spreadsheet our regional manager uses" | A 90-second arc, with beats only from those three quotes: 6 years in retail banking; the last 3 as a branch supervisor; the branch's formal complaints log, and training new tellers on the escalation script; the monthly complaints spreadsheet your regional manager uses. Tell them in your own words and stop at what they say. Close with why this role, in your own words. Say what you did and let the recruiter draw the inference | This opens every screen and is scored even though it feels casual. F1, F2, F5 and F7 are the evidence it draws on |
| A2 | "What draws you to Ashgrove, and to a member-owned credit union?" | CO | [grounded] | The question needs no claim about your past, so the guidance makes none. Pick one or two published specifics, such as the JD's "member-owned" or the value "Members First, Always: we decide from the member's side of the counter", and say in your own words why they matter to you. The reason must be yours; say it only if it is true | A recruiter checks motivation before the managers do. The JD and the values page are the raising sources |
| A3 | "What is your notice period?" | JD | [generic] | Give your actual notice period in your own words, exactly as it stands | A logistics slot every screen carries; a figure from you would fill it |
| A4 | "What salary are you looking for?" | JD | [generic] | Either give your own number or ask for the role's band first; both are normal and the choice is yours. If asked what you earn now, you can politely decline and return to the role's band | A logistics slot every screen carries |
| A5 | "Where would you be working from, and is moving between sites workable for you?" | JD | [grounded] | Give your actual location and travel constraints in your own words; if you have none, say so plainly. The JD's "across branches and the contact centre" and the brief's move from eight branches to five hubs are why this will come up | The role spans more than one site, so the recruiter checks it early |

### B. Skeptic, light

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role asks for 4+ years in financial-services customer operations. Where does your experience sit against that?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Say it in its own terms: "I have 6 years in retail banking, the last 3 as a branch supervisor." Let the recruiter map it to the JD's phrase; do not relabel your work in the JD's words. If they ask what the job involved, answer from your other quotes only | The first knockout check a recruiter runs; F1 |
| B2 | "What is prompting the move now?" | EXP | [generic] | Give your actual reason in your own words, true and short. Say only what you would repeat to the Head of Member Services in round 2, because the answers will be compared | The recruiter's "why leave, why here, why now". The reason has to match across rounds |
| B3 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" | "I haven't worked in a contact centre." Then stop, and give the plan: what you would do first to learn how complaints move through it. Do not claim phone, call-handling or contact-centre systems experience | A direct check on the JD's second site; F4. The full rehearsal is D1 |
| B4 | "Which part of this role would be weakest for you on day one?" | JD | [grounded] "Never worked in a contact centre"; "I've never presented to anyone above regional level" | Name a gap yourself before they do, with its plain acknowledgment: "I haven't worked in a contact centre" or "I haven't presented to anyone above regional level". Then a plan for that one, said as a plan. Pick one and do it well | A stem the Skeptic uses everywhere; F4 and F8 |

## Round 2: Head of Member Services (45 minutes, your future manager, mostly behavioural)

### C. Values and behavioural

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Pick a time you told someone senior something they did not want to hear. It needs a named stake, what you actually said, and a working relationship still intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The nearest your material carries is the spreadsheet your regional manager uses, which says you built a report, not that it carried a message anyone resisted; do not present it as one | Behavioural stem for a manager who would be presenting your reports upward; F8 and F5. VAL because it scores behaviour, not knowledge |
| C2 | "Tell me about a time you coached or trained someone through something difficult." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-mapped on F7, at its scope: you trained new tellers, on the escalation script. Tell that in your own words. Answer slot: the JD's coaching line makes a probe on how you coached, and on whether it ever went beyond new tellers, likely. If you coached anyone beyond new tellers, say who and how; if the training reached only new tellers, say so plainly and stay there. Do not describe a session format, a method or a result you did not give | The JD asks for coaching supervisors on escalations; F7 is the nearest evidence |
| C3 | "Tell me about a time you worked with a team outside your branch to get something fixed for members." | JD | [grounded] | The question needs no claim about your past, so the guidance makes none. Pick a time you took a member-facing problem to a team outside your branch, such as head office, IT or a digital team. It needs the problem, who you took it to, what you did and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it: say what you would ask a digital team first | The JD's digital-teams line and the brief's move to digital; F9 |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "This role owns complaints across the branches and the contact centre, and you've said you haven't worked in a contact centre. How would you own something you haven't worked in?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log and trained new tellers on our escalation script" | **The highest-ROI rehearsal in this pack.** Build it in three beats. One: concede first, plainly: "I haven't worked in a contact centre." Two: stay with what your quote carries: "I handled the branch's formal complaints log and trained new tellers on our escalation script", said as the branch's, never as a stand-in for the contact centre. Three: a plan said as a plan: what you would ask for or look at first to learn how complaints reach and move through the contact centre, in your own words. Follow-up one, "what do you think is different there?": say what you would find out; do not guess at its practices. Follow-up two, "why should we back you?": hold by returning to the quote, concede the limit again, and do not add to your history to restore comfort | F4 against the JD's headline duty (F3) is the objection this pack expects in some form in every round. The limit is named before it is asked for; the answer carries no more than the quotes |
| D2 | "You'd be presenting complaint reports to senior leaders, and you haven't presented above regional level. How do you take that on?" | JD | [grounded] "I've never presented to anyone above regional level"; "I built the monthly complaints spreadsheet our regional manager uses" | "I haven't presented to anyone above regional level." Then your plan for a first senior presentation, said as a plan. Answer slot: your material does not say what you presented at regional level; if you have presented there, say to whom and what, in your own words; if you have not presented at all, say so plainly. Return to the one thing your material shows: you built the report your regional manager uses | F8 against the JD's senior-leaders line; F5 is the report that would be presented |
| D3 | "Which parts of owning a complaints process end to end have you done yourself?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | The hold is only what the quote carries: "I handled the branch's formal complaints log." Answer slot: if you had any part in what happened before or after an entry reached the log, say what and how, in your own words; if you did not, say so plainly and describe how you handled the log. Hold through two follow-ups by returning to the log, never by adding to it | F3 is where the JD's end-to-end ownership presses hardest; the honest branch is a limit, not a confession |

### E. Data-driven prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through the branch's formal complaints log. What governed how complaints were handled in it?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Story-mapped on F2, at its scope: you handled the branch's formal complaints log. Answer slot: the JD's regulated-complaints line makes this probe likely. If any regulatory requirement governed the log, say which and what it required of you, in your own words; if none did, or you do not know, say so plainly and stay with the log | F2 is the JD's regulated-complaints requirement; EXP because it tests what you actually did |
| E2 | "Walk me through the monthly complaints spreadsheet you built. What did it show?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Story-mapped on F5, at its scope: you built it, it is monthly, your regional manager uses it. Answer slot: the JD names volumes, resolution times and Excel. If it counted either, say what and how you counted it, and the assumption behind a count you would defend least before they ask; if you do not know how something in it was counted, say so plainly. If it was Excel, say so; if another tool, name it. If it showed neither, say what it did show | F5 and F6 are the JD's reporting requirements; a prober reads a built artifact closely |

### F. Case and strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Ashgrove wants 40% of member service on digital channels by 2028. What does that mean for how we handle complaints?" | CASE | [grounded] | Clarify first: what counts as member service, and whether complaints sit inside the 40%. Then objective, segmentation (which complaints suit a digital route and which need a person), approach, metrics, risks. Use Ashgrove's own words: member service, digital channels, 2028. Name the app-only banks as the competitive frame. Challenge one premise respectfully. The question asks about no past, so the guidance claims none | The brief's central target; F9 is the JD line it touches. CASE because it scores structure |
| F2 | "In your first month I ask for the first monthly complaints report. What do you need to know before you build it?" | CASE | [grounded] | Questions, not answers: who reads it and what decision it serves; what counts as a complaint and when the clock starts and stops; whether branches and the contact centre count the same way; where the data lives. Volumes and resolution times are the JD's two measures. The risk to name aloud is that differing definitions across sites make the numbers incomparable. No claim about your past | The JD's monthly-reporting line; F5 |

## Round 3: panel of two branch managers (60 minutes, including a 20-minute escalation case, scored against the four values)

### G. Values and behavioural, one per value

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you decided something from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Value: Members First, Always. Pick a time you took a position for a member that cost you something inside the branch. It needs a named stake, what you actually decided, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The nearest your material carries is the formal complaints log, which says what you handled, not a decision; do not dress it as one | The recruiter says the panel scores each value; F2 |
| G2 | "Tell me about a time something you said or wrote had to be explained twice. What did you do?" | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Value: Plain Words. Pick a time you reworded something, such as a script, a letter, a report line or an explanation, after someone did not follow it the first time. It needs the thing, what was unclear, what you changed and whether it worked. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The nearest is training new tellers on the escalation script, which says training, not rewording. Short plain sentences in this answer cost nothing and match the value | F7; VAL because the panel scores it as behaviour |
| G3 | "Tell me about a time you did something because of the town your branch sits in." | VAL | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Value: Neighbours, Not Numbers. Pick a time you acted for the community around your branch rather than for a target. It needs a named place, what you did and what it meant to the people. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Your quote carries the branch role, not a story about its town. A plan fits here: how you would keep members in a town that loses its branch heard through the move to hubs | F1; the 2027 hub move makes this value live |
| G4 | "Tell me about a time you found a problem and kept hold of it until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | Value: Own the Fix. Pick a specific problem you found or took on. It needs what you did next, who else you had to bring in, and how you knew it was solved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. The log says you handled it, not a problem you followed to its end; stay inside that. The closest value to the JD's own wording, so expect the panel to press here | F2 and F3; the strongest overlap between a value and the JD |

### H. Case and strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "A member's complaint has bounced between a branch and the contact centre, and they are at the counter asking someone to take it. Walk us through what you would do, and what you would change so it doesn't happen again." | CASE | [generic] | A practice scenario I wrote, not Ashgrove's real case; practise the structure, not the content. Clarify first: what the member has been told, what they want, whether it is logged as formal, who holds it now. Then objective, segmentation (what kind of complaint, where it sits), approach (today, this week, the cause), metrics (volumes and resolution times), risks. Say your structure aloud. Name who holds the fix, word what you tell the member plainly, decide from the member's side, and think of the branch's own members; the panel scores those four values during the case. Challenge one premise respectfully. No claim about your past | The recruiter says a 20-minute escalation case sits in this round; F3 and F4 are the JD lines it exercises |
| H2 | "Eight branches become five hubs over 2027. What does that mean for complaints in the towns that lose a branch?" | CASE | [grounded] | Clarify first: which towns, and what changes for members. Segment the members who walk in from those who move to digital. Approach: a member is still heard when the counter goes; a complaint does not vanish in the move. Metrics, risks. Use the value's own words, Neighbours, Not Numbers. Ask rather than assert how Ashgrove handles this today | The brief's hub move, in front of two branch managers who may live inside it |
| H3 | "A small-business lending product launches in Q1 2027. What would you want in place for complaints before it does?" | CASE | [grounded] | Clarify first: who handles small-business members today and what differs from other products. Then who owns a small-business complaint, how it is logged, how it is reported monthly, how a supervisor is coached. Ask rather than assert how Ashgrove works today. No claim about your past | The brief's product launch; reporting and coaching are the JD lines it touches |

### I. Peer evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| I1 | "Our teams sit side by side. Where is the seam between a branch and the complaints lead, and what happens when we disagree?" | JD | [generic] | Propose principles, not a pretend seam: who holds a complaint while it is open, what the branch is told and when, who decides when the two disagree. Say you would ask the branch managers what they most need, which is more honest than inventing the seam. Your material gives no disagreement story, so tell one only if one is true; otherwise say how you would handle it | The role would sit between branches and the contact centre; the branch managers are the people it would work alongside |
| I2 | "A supervisor in my branch doesn't want to escalate something because it will look bad. How would you coach them?" | CASE | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script" | A live problem: what is at stake for the member, what escalating protects, what happens next, and how you stay accountable for the outcome. If they ask whether you have done this, answer from F7 only: you trained new tellers on the escalation script. Answer slot: if you have walked a peer or a supervisor through an escalation, say who and how; if not, say so plainly and stay with the tellers | The JD's coaching line; F7 |
| I3 | "How do you handle credit when a fix spans several teams?" | EXP | [generic] | Say how you would do it, in your own words: name each team's part specifically, say who held the fix, and never claim others' work. Answer slot: if a fix of yours spanned teams, say who did what; if none did, say so plainly and say how you would handle it | A peer stem; the role works across branches and the contact centre |

## Values and principles cheat sheet

The recruiter says round 3 scores against these four values, and the values are as you copied them on 24 November 2026.

| Value | Working meaning | Mapped story or selection scaffold | Asked in |
|---|---|---|---|
| Members First, Always | Decisions are made from the member's side of the counter | F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script" carries the log, not a decision. Scaffold: pick a time you took a position for a member that cost you something inside the branch; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | G1, H1 |
| Plain Words | If a member needs it explained twice, the wording is at fault | F7: "I handled the branch's formal complaints log and trained new tellers on our escalation script" carries training on a script, not rewording one. Scaffold: pick a time you reworded something someone did not follow; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | G2, H1 |
| Neighbours, Not Numbers | Every branch belongs to its town | F1: "6 years in retail banking, the last 3 as a branch supervisor" carries the branch role, not a story about its town. Scaffold: pick a time you acted for the community around your branch rather than a target; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | G3, H2 |
| Own the Fix | Whoever finds a problem keeps hold of it until it is solved | F3: "I handled the branch's formal complaints log and trained new tellers on our escalation script" carries the log, not a problem followed to its end. Scaffold: pick a problem you found or took on and say how you knew it was solved; if no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | G4, H1 |

## Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own the member complaints process end to end across branches and the contact centre" | B3, B4, D1, D3, H1, I1 |
| "report monthly on complaint volumes and resolution times" | E2, F2 |
| "coach branch supervisors on escalations" | C2, I2 |
| "work with digital teams on self-service journeys" | C3, F1 |
| "4+ years in financial-services customer operations" | B1 |
| "experience handling regulated complaints" | E1 |
| "confident presenting to senior leaders" | C1, D2 |
| "comfortable with Excel reporting" | E2, F2 |

## Reverse questions

### Round 1: the recruiter

| # | Question | Why it lands |
|---|---|---|
| 1.1 | "What does the Head of Member Services most need this hire to change in the first six months?" | Gets the brief for round 2 from the person who has heard it |
| 1.2 | "How is the complaints process split between the branches and the contact centre today?" | Gives you facts for D1 and shows you are already thinking about both sites |
| 1.3 | "For the 20-minute case, will there be materials in advance, and does the panel expect a structure or a recommendation?" | Converts the case from an unknown into a format you can rehearse |
| 1.4 | "Can you share the names of the people I will meet?" | Names unlock an interviewer read from public professional footprint |
| 1.5 | "How will the move to five hubs change where this role is based?" | Shows strategy fluency and answers the location question for yourself |

### Round 2: Head of Member Services

| # | Question | Why it lands |
|---|---|---|
| 2.1 | "What would a good first ninety days look like for whoever owns the complaints process?" | Asks the future manager to define the job in their own terms |
| 2.2 | "Where does the complaints process work least well today, from where you sit?" | Invites their view of the problem and keeps the conversation on the fix |
| 2.3 | "How do the contact centre and the branches each see complaints that come from the other?" | Meets the contact-centre gap head on and shows you will build both sides |
| 2.4 | "Which decisions would be mine on day one, and which would still sit with you?" | Clarifies what owning it means in practice |
| 2.5 | "How will the move of member service to digital channels change the complaints you expect this role to handle?" | Ties the role to the 2028 target |

### Round 3: the branch managers

| # | Question | Why it lands |
|---|---|---|
| 3.1 | "What do your supervisors find hardest about escalations today?" | Peer question that surfaces the coaching job from the people who live it |
| 3.2 | "When a complaint is raised in your branch, what do you most want to be told, and when?" | Reciprocity: asks what the branch needs from the role |
| 3.3 | "What could a new person do in their first month that would genuinely help your branch?" | The reciprocity question for a peer panel |
| 3.4 | "How are members in the affected towns hearing about the move to five hubs?" | Shows the Neighbours, Not Numbers value in a question |
| 3.5 | "Which of the four values is hardest to see in practice day to day, and what does it look like when it is done well?" | Hands the panel a chance to give their own examples in a round they score |

## Sources

Provided documents: the JD you pasted; the values page text you copied on 24 November 2026 from ashgrovecu.org/about/values (used as pasted, not fetched); the recruiter's email about the process; the four points you gave from the 2026 strategy brief Ashgrove published in July 2026 (the full brief was not in front of me); your background summary (not a CV). No dossier was present. No searches or fetches were sent.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | The values page you pasted fixes the cheat sheet and the VAL questions |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | The recruiter's email fixes the three rounds, who runs each and what each holds, and persona weights follow it |
| 3. `Ashgrove Credit Union strategy` / recent news | skipped | The four brief points you gave, from July 2026, already supply the CO and CASE questions |
| 4. `interviewer name Ashgrove Credit Union` | n/a | No interviewer is assigned, so there is no query to form; the upgrade menu says what names would unlock |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your full CV → the rows resting on one-line summaries (F2, F5, F6, F7) can quote specifics, and some `[inferred]` rows may become `[grounded]`
- Your answers to the answer slots, said in your own words in a message (what governed the log; what the spreadsheet showed and which tool it was built in; whether any coaching reached beyond new tellers; any work with a digital or head-office team) → F2, F5, F6, F7 and F9 regenerate from your own words
- A redacted copy of the monthly complaints spreadsheet, or a description of its columns → the inspectable artifact that could lift F5 and F6 from medium confidence
- The names of the Head of Member Services and the two branch managers → an interviewer read from public professional footprint, persona weights adjusted to them, and a reverse question tied to their own path
- The recruiter's answer on the 20-minute case (materials in advance, whether it is written or spoken, whether you present your answer to the panel) → H1 rebuilt around the real format
- The full text of the July 2026 strategy brief → CO and CASE questions in the brief's own wording, and a fuller grounding section
- Hours available before 3 December → a prioritised prep schedule sized to your time
- A deeper research pass, up to 6 more searches and 2 more fetches, several more minutes → Ashgrove strategy and recent organisation context, and loop reports for this kind of role; say the word and I will run it
- A `tuesday-dossier.md`, if you have one from earlier work → verified evidence and a prohibited-claims list that would tighten the guidance; none is needed
