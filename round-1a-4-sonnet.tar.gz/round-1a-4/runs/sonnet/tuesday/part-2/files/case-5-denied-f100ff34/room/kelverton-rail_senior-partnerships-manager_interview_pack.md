# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, Tuesday. A 60-minute panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). The first 15 minutes are your POV on operator partnerships over the next 18 months, no slides. The rest is Q&A, with Ross pushing on commercials.
**Built on:** your message only. No JD, no CV file, and the market report was not shared with me. Research was refused, so nothing here is drawn from outside sources.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether the claims in your background survive scrutiny and attribution |
| JD | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge, thinking at the company's altitude |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview, not a question for you now. Meet it with whichever branch is true.

## 2. Prep triage (about four hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 90 min | Build and rehearse the 15-minute POV aloud, timed, twice | Section 4 |
| 2 | 45 min | Say the stated-gap answer aloud until it is boring, then the numbers answers | A1, D1, A5, then B1 to B3 and D2 |
| 3 | 30 min | Re-read the market report. Mark one consensus item, one divergence, one thing you would say no to | Section 4, differentiation |
| 4 | 30 min | Rehearse the operator close and the commercial measures answer | C4, B4 |
| 5 | 15 min | Choose three reverse questions and run the opening arc | Section 10, E1 |
| 6 | 30 min | One full timed run: 15-minute POV, then six questions from the banks | Whole pack |

Everything else is insurance.

## 3. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email, in your message | none given | none | [grounded] | discovery | Your material does not yet show a view on this, and the build is Section 4. Answer slot: if you have set partner direction before, say what, in your own words; if you have not, say so plainly and present the POV as a proposal |
| F2 | "land on what it means for the operators themselves" — recruiter's email, in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The words stay at the quote's scope: five years in transport consulting, bus and light rail network planning. Your material says bus and light rail, not train operating companies, and nothing inspected sits behind it. Answer slot: if any of that planning work was with operators of the kind Kelverton works with, say which and how; if not, say so plainly and stay with bus and light rail |
| F3 | "Ross will push on commercials." — recruiter's email, in your message | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | presentation | Say it as the quote says it, and keep the word influenced, because it is both yours and your limit. Expect a probe on how the figure was counted, what it is sensitive to, the assumption you would defend least and which part was yours. Answer slot: if you know how it was counted, say so; if you do not, say so plainly and return to the quote |
| F4 | selling into rail operators — role-family requirement, no JD supplied | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't sold into rail specifically." Then how you would learn it, said as a plan and never as a past |
| F5 | carrying a direct commercial number — role-family requirement, no JD supplied | "Never sold into rail specifically and never carried a direct quota, only influenced revenue." — your message | medium | [grounded] | capability | Words: "I haven't carried a direct quota; my figure is influenced revenue." Nothing added to make the gap feel smaller |
| F6 | "where you'd take our operator partnerships" — recruiter's email, in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel", "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your quotes carry a payments ISV channel, not operator partnerships, and the words stay there: the last four of nine years in partnerships, running the ISV channel. Answer slot: the recruiter's word is operator partnerships, so expect a probe on what carries over. Say what you think carries and what does not, in your own words; if you do not think it carries, say so plainly and stay with the channel |

## 4. Graded deliverable: the 15-minute POV

This is the only part of the interview you fully control, and it is graded. The recruiter asked you to "land on what it means for the operators themselves".

**Facts to build on**

| Fact | Where it comes from | Provenance |
|---|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" and "no slides needed, just talk us through it" | recruiter's email | [grounded] |
| F6: "took it from 6 partners to 40, roughly £4M of influenced revenue" | your message | [grounded] |
| F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | your message | [grounded] |
| "Ross will push on commercials." So the POV needs its own commercial beat, with the limit in F5 said first | recruiter's email | [grounded] |

**Spoken shape, 15 minutes**

| Minutes | Beat | Job it does | Provenance |
|---|---|---|---|
| 0 to 1.5 | Frame: the one idea, stated before anything else | Lets a panel hold the rest | [generic] |
| 1.5 to 4 | Where partnerships stand today, from the report: one consensus item | Proves you read it, without reciting it | [generic] |
| 4 to 10 | Your thesis and what 18 months looks like in three stages | The graded core | [generic] |
| 10 to 13 | What it means for the operators themselves | The requested close | [generic] |
| 13 to 15 | The concession, the commercial measure and what you would need from Ross | Takes the sting out of the Q&A | [generic] |

**Thesis options** (pick one and carry it; do not present all three)

| Thesis | What it argues | What it means for operators | Mandatory concession | Draws on | Provenance |
|---|---|---|---|---|---|
| T1: operator as design partner | Concentrate on a small number of operators and shape partnerships around their outcomes | Operators have a say in what gets built or integrated | It concentrates dependence on few operators and scales slowly; and you have not sold into rail (F4), so lead it as a proposal | F2, F4 | [generic] |
| T2: ecosystem around the operator | Treat partners around the product as a channel, so operators get more from one relationship | Less integration effort and more capability around the core product | Operators benefit only if integration effort falls, and your channel proof is payments, not rail (F6) | F6 | [generic] |
| T3: partnerships measured in operators' own terms | Agree shared success measures with each operator and report against them | Operators can see whether the partnership is working in their terms | Ross will ask what the number is; yours is influenced revenue, not a quota (F5) | F3, F5 | [generic] |

My read: T2 or T3 uses your actual material at its own scope (F6, F3). T1 leans hardest on the operator-side knowledge you can least show (F2).

**Differentiating from the market report.** The panel's own strategy team wrote it, so reciting it scores as homework. I have not seen it, so these slots are yours to fill.

| Move | What it is | Your pick |
|---|---|---|
| Consensus item | One finding the report states, to prove grounding | Choose from the report |
| Divergence | One place your thesis departs from it, with your reason | Choose from the report |
| The thing you would say no to | A partner type, an operator segment or an initiative you would decline, with your reason | Your own judgment |

**The close.** For the last two minutes, say what an operator's team would notice in 18 months, in operator terms, not Kelverton's. Answer slot: name that one change in your own words; if you cannot name one, your thesis is not yet landing on operators, so revise the thesis rather than the close.

## 5. Persona table

The loop is established by the recruiter's words: one 60-minute panel, 15 minutes of POV, then Q&A. No values-style round is detected.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet, persistent probing of F4, F5 and F6: no rail sales, no quota, a payments channel | High. The gaps are stated in your own message, and Deepa as future manager is buying capability and weighing gaps | Rehearse the one predictable objection until it is boring; bridge only from what your quotes carry; give a ramp plan as a plan |
| Data-Driven Prober | Ross takes the £4M and the 6-to-40 apart | High. The recruiter said "Ross will push on commercials." | Know what you can and cannot say about how each number was counted; say plainly when you do not know; name your weakest assumption before he does |
| Case/Strategist | Deepa tests the POV live: what would you not do, which operator first | High. An 18-month POV from a future manager invites live challenge | Clarify, state the objective, segment, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Pressure | Ross time-boxes and tests the influenced-versus-sold line | Medium. Commercial pushing often arrives as pressure, but nothing in your material says so | Pause, restate, hold the position through two follow-ups, concede the specific limit and never fold on the core |
| Conversational | The opening and any informal question | Low to medium. The first minutes after the POV are usually easy, and still scored | A short arc from your own quotes; never answer "I think you've covered everything" to the reverse-question slot |

## 6. Question banks

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't sold into rail and you haven't carried a direct quota. What makes you the person to take our operator partnerships forward?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't sold into rail specifically, and I haven't carried a direct quota; my figure is influenced revenue." Then the quotes at their own scope: "9 years in partnerships, last 4 at a payments company running the ISV channel", and "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". Then your ramp plan, said as a plan. Hold through two follow-ups by returning to those lines, never by adding to them | F4 and F5 are the stated gaps, so this question arrives in some form; JD because it scores fit to the role |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Your own material states two candidates. Answer slot: say which one you would name as weakest, in your own words, and what you would do about it as a plan; if something else is weaker, name that instead | The persona stem for the Skeptic, aimed at F4 and F5; JD because it scores the role's demands |
| A3 | "You've never sold into rail specifically. What do you know about how operators buy?" | CO | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | This is a knowledge probe, not a claim about your past. Separate what you know from the report you read from what you would find out first. If you do not know how an operator buys, say so plainly and say what you would ask first | F4's gap, aimed at knowledge rather than experience; CO because it tests homework |
| A4 | "Why leave payments partnerships for rail-tech, and why now?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | The reason is yours and the pack does not supply one. Answer slot: give your actual reason in your own words; if it is more than one, give the one you would stand behind under a follow-up. Tie it only to what the quote states: nine years in partnerships, the last four running the ISV channel | The motivation-consistency probe the Skeptic always runs; F6 is the evidence row, EXP because it tests your story |
| A5 | "I don't see a direct quota in your background. How would you handle commercial accountability here?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Plain acknowledgment first: "I haven't carried a direct quota; my figure is influenced revenue." Answer slot: if you have been accountable for a commercial target in any form, say what it was; if influenced revenue is the nearest, say so and stay with it | The persona stem aimed at F5, and the recruiter's note about Ross makes it likely |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | The figure raises four slots and no more. Answer slot: how it was counted, if you know, in your own words; what it is sensitive to; the assumption you would defend least; which part was yours. If you do not know how it was counted, say so plainly and return to the quote. Keep the word influenced | F3 is the headline metric, so it gets a defend-the-number question |
| B2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Name it before Ross does, in your own words. Answer slot: if you know the assumption, say it; if you do not know of one, say so plainly. The pack names none for you | The weakest-assumption move, converting a gotcha into credibility; F3 |
| B3 | "How much of the move from 6 partners to 40 was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say which parts were yours and which were others', in your own words; if the quote's "took it" claims more than you would defend, say so plainly and give the smaller version. Resolve any ambiguity downward | The second headline figure on the CV-equivalent; F3 and F6 |
| B4 | "How would you measure whether an operator partnership is working?" | JD | [generic] | Structure it: what the operator would want to see, what Kelverton would want to see, and the measure that connects them. Answer slot: if you used measures in the ISV channel, name them, in your own words; if you did not track any, say so plainly and say what you would measure first | Ross will push on commercials, per the recruiter; this is the commercial question that needs no claim about your past |
| B5 | "Sketch how you would structure the commercials of an operator partnership. What do you need to know first?" | CASE | [generic] | Clarify first, then objective, segments, approach, measures, risks; think aloud and challenge one premise. The question needs no claim about your past, so the guidance makes none | A live commercial problem for Ross, who is the natural owner of it |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What would you say no to over the next 18 months?" | CASE | [grounded] | This is your anti-pick from Section 4. State your criterion for saying no before naming the thing. The guidance makes no claim about your past | The role's real job includes saying no, and the POV window is the recruiter's own 18 months |
| C2 | "Which operator would you go after first, and how would you choose?" | CASE | [generic] | Clarify what you would need to know, state your selection criteria, then give a choice and what would change your mind. No claim about your past | A live problem on the role's actual roadmap, from Deepa |
| C3 | "Operators are engaged but nothing is converting. Diagnose it." | CASE | [generic] | Clarify what converting means, segment the funnel, form two hypotheses, say how you would test each. No claim about your past | A diagnostic case, the second standard Strategist shape |
| C4 | "What does your POV mean for the operators themselves?" | CASE | [grounded] | The recruiter's own close. Answer in operator terms, not Kelverton's. Answer slot: name the one change an operator's team would notice, in your own words; if you cannot, revise the thesis | The recruiter asked for this close, so it is graded twice, in the POV and again here |

### D. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "Never sold into rail specifically and never carried a direct quota, only influenced revenue." | Hold, then concede. Concede the stated gap plainly: "I haven't sold into rail specifically." Hold on the quotes, "9 years in partnerships, last 4 at a payments company running the ISV channel", and do not add to them. Hold through two follow-ups by returning to them | The persona stem aimed at F4; JD because it scores fit |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say which parts were yours, in your own words; if you do not know how the credit was split, say so plainly and return to the quote. Do not fold on the quote and do not add to it | The attribution probe, aimed at F3 |
| D3 | "Influenced revenue and sold revenue are different things. Where does the line fall in your £4M?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: if you know where the line fell, say so in your own words; if the distinction was not tracked, say so plainly and keep the word influenced. Never move the figure toward sold | The sharpest version of the F3 and F5 limit, and the one Ross is likeliest to land |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel", "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc from the two quotes at their own scope. Answer slot: the reason you moved between them and the reason you are here are yours to give in your own words; if you do not have a clean reason, say what you do have | The opening biography question; F2 and F6 are the evidence rows |
| E2 | "What have you been looking at on the operator side recently?" | CO | [generic] | Treat it as scored. Answer slot: name what you actually read, including the report, and what you took from it in your own words; if there is nothing recent, say so plainly | A casual-register CO question that rewards homework |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" | Section 4, C1, C2, C3 |
| "land on what it means for the operators themselves" | Section 4 (the close), C4 |
| "Ross will push on commercials." | B1 to B5, D2, D3, A5 |
| Selling into rail operators (F4) | A1, A2, A3, D1 |
| Carrying a direct commercial number (F5) | A1, A2, A5, D3 |
| "where you'd take our operator partnerships" (F6) | A4, B3, E1 |
| Operator-world knowledge (F2) | A1, A3, E1, E2 |

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What would make the first 18 months of this role a clear success from where you sit?" | Turns your POV into a shared definition of success, and tells you what Deepa will actually measure |
| 2 | "How is this role measured, and how much of that is a number versus a set of outcomes?" | Gets the real commercial expectation on the table after you have stated your influenced-revenue limit |
| 3 | "How do you decide which operator conversations are partnerships and which are straightforward sales?" | A seam question for Ross that shows you are thinking about where your role ends and a quota-carrying one begins |
| 4 | "Which finding in the market report is most shaping where partnerships go next?" | Shows you read it and invites the strategy view behind it |
| 5 | "Where would you want the person in this role to push back on how partnerships work today?" | Signals judgment and gives Deepa room to say what she wants challenged |
| 6 | "Is there anything in what I've said that you would want me to expand on?" | A close that invites the objection while you can still answer it |

## 8. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Generated or closed £4M of revenue | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says influenced revenue, not generated or closed |
| Carried a quota | Negative you stated, F5 | The plain acknowledgment F5 gives: "I haven't carried a direct quota; my figure is influenced revenue." No slot |
| Sold into rail | Negative you stated, F4 | The plain acknowledgment F4 gives: "I haven't sold into rail specifically." No slot |
| Worked with train operating companies from the operator side | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: the material says bus and light rail network planning |
| Built the ISV channel from nothing | Inflated form of F6 | F6's quote at its own scope: the move was from 6 partners to 40. The limit is the pack's observation: the material says you took it from 6 |

## 9. Sources

**Provided:** your message, including the recruiter's email as you quoted it. **Not seen:** the market report, the JD and any CV file.

Searches sent, every one refused:

| Query | Result |
|---|---|
| Kelverton Rail values | refused |
| Kelverton Rail interview process partnerships | refused |
| Kelverton Rail strategy scheduling software train operating companies news | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager rail software train operating companies job description | refused |

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton Rail values | unavailable | Would have moved the VAL theming of questions; no values-style round is detected, so the cheat sheet is dropped either way |
| 2. Kelverton Rail interview process | unavailable | Would have checked the loop; persona weights stand on the recruiter's words instead |
| 3. Kelverton Rail strategy and recent news | unavailable | Would have moved the CO and CASE questions; C1 to C3 are labeled generic |
| 4. Deepa and Ross, with the company | unavailable | Would have moved the interviewer read and a tailored reverse question; both are absent |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have moved the F4 and F5 requirement rows from plain prose to quoted rows |

## 10. Upgrade menu

- The JD text → F4 and F5 move from generic prose to quoted requirements, JD-tagged questions are re-anchored, and any gate rows (location, travel, schedule) are surfaced
- The market report, pasted whole or as the passages you expect the panel to use → the consensus, divergence and anti-pick in Section 4 are built from it, and C1 to C3 and reverse question 4 become grounded
- Deepa's and Ross's public profiles, pasted → an interviewer read, persona weights tuned to each, and a reverse question tied to a career path
- Search access → the five research targets rerun; a deeper pass adds up to 6 more searches and 2 more fetches and takes several more minutes
- Your own answers to the answer slots in F1, F2, F3 and F6, and in B1 to B3, D2 and D3 → those rows move from slots to quoted material
- A tuesday-dossier.md from an earlier session, if you have one → verified evidence and prohibited claims arrive pre-graded
