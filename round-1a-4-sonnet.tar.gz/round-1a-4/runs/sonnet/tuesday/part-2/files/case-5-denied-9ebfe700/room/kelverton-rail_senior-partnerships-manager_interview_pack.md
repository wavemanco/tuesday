# Interview pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes. The first 15 minutes are a talked POV with no slides; the rest is Q&A, and Ross will push on commercials (recruiter's email, as you quoted it).
**Panel:** Deepa, VP Partnerships, your future manager. Ross, Commercial Director.
**Built on this assumption:** no JD and no CV text were supplied, so the requirements below are the recruiter's own words plus the sentences from your message. Web research was refused, so nothing here rests on a search.

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script.

| Tag | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether a claim about your work survives scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you can think at the company's altitude |
| CASE | A live problem, scored on structure |

Labels: `[grounded]` traces to something you or the recruiter wrote. `[inferred]` is derived from that, with the derivation named. `[generic]` is a pattern with no claim about this company or you. Where a cell says answer slot, it is an instruction for the interview, in your own words. It is not a question for you now.

## Prep triage (about four hours)

| Order | Time | Do this | Where |
|---|---|---|---|
| 1 | 90 min | Choose one thesis and build the 15-minute talk. Say it aloud against a timer three times, recording once | Graded deliverable below, A1 |
| 2 | 60 min | Rehearse the objection until it is boring: the two plain acknowledgments, then the hold | B1, D1, C3 |
| 3 | 45 min | Write your own answers to the four number slots (how counted, what it is sensitive to, weakest assumption, which part was yours) | C1, C2, D2 |
| 4 | 30 min | A two-sentence version of the landing on operators | A3, D3 |
| 5 | 15 min | Pick three reverse questions and say them aloud | Reverse questions |

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40" — your message | medium | [grounded] | transferability | Your material describes an ISV channel at a payments company. It does not say that any partner was a train operator. Words at that scope: "I took the ISV channel from 6 partners to 40." Answer slot: expect a probe on how an ISV channel carries over to operators. If you see a direct parallel, say it as your view; if there is none, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | The material says bus and light rail network planning, from the consulting side. It does not say train operating companies. Words at that scope: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: if any of that work gave you a view of what operators care about, say what, in your own words; if it did not carry over to train operating companies, say so plainly and stay with bus and light rail network planning |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | The figure is influenced revenue, and the word stays. Nothing behind it has been inspected, so expect a probe. Answer slots: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly |
| F4 | Being held to a revenue number — role-family requirement, no source supplied | "never carried a direct quota, only influenced revenue" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never carried a direct quota, only influenced revenue." Then what you would propose being measured on, said as a plan and never as a past |
| F5 | Selling or partnering into rail operators — role-family requirement, no source supplied | "Never sold into rail specifically" — your message | none | [grounded] | capability | A stated gap. Words: "I've never sold into rail specifically." Then how you would learn it, said as a plan: who you would ask and what you would look at first. Never a claim to rail work |
| F6 | Be current on the company's own market view, derived from the recruiter attaching the strategy team's report | "which I've read" — your message | low | [inferred] | discovery | The pack cannot see the report. Answer slot: expect a probe on what you took from it. Say what stood out, in your own words, and where you would depart from it; if nothing stood out, say so plainly |

No requirement stated so far is a gate such as location, schedule or pay. The JD may add some, and those rows would be added then.

## Graded deliverable: the 15-minute POV

The recruiter announced this one and asked for a close on what it means for the operators themselves, so it is graded. No slides are needed.

**What you can build on.** F1: "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40". F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)". Nothing else about your past goes in the talk.

**Shape of the 15 minutes.**

| Minutes | Beat |
|---|---|
| 0:00 to 1:30 | Frame: what you take "operator partnership" to mean, and the assumptions you are making, said aloud |
| 1:30 to 4:00 | Your thesis, one sentence, then why |
| 4:00 to 9:30 | The 18 months in three stages: months 0 to 6, 6 to 12 and 12 to 18. For each, what you would learn, decide and show |
| 9:30 to 11:30 | Concessions and what you do not yet know |
| 11:30 to 15:00 | Land on what it means for the operators themselves, last |

**Thesis options.** Choose one. Each has a concession you must say aloud. All are `[generic]` positions to argue, not facts about Kelverton.

| Thesis | Provenance | Mandatory concession | What it means for the operators |
|---|---|---|---|
| Go deeper with fewer operators before going broader | [generic] | Depth slows reach and raises dependence on a few operators, and the right number depends on data you have not seen | An operator commits team time to one joint outcome it chooses. Its cost is that time and a visible commitment |
| Anchor each partnership to an outcome the operator already tracks and can verify itself | [generic] | Operator-verified outcomes take longer to show, so fewer partnerships may be countable inside 18 months | The operator judges the partnership on its own terms and can walk away if it does not deliver |
| Stage every partnership: pilot, review gate, then scale | [generic] | Gates slow early momentum and can read as hedging | An operator commits less up front and gets a defined exit. Its cost is running the review with you |

**Differentiating from the report.** Your strategy team's report went to their own staff, so Deepa and Ross know it better than you do. Reciting it scores as homework. Bring one item from it to show you read it. Then give one thesis-driven departure from it, with your reasons. Where the role's real job includes saying no, give one anti-pick: something you would not pursue in the first 18 months, and why. This pack has not seen the report, so it cannot name the item. Pasting it would let the pack build this against its actual content.

**The close.** Say it in operator terms: what changes for an operator, what it has to do differently, and what it costs them. The concession in your chosen thesis is the third part.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The 15-minute POV itself, then "what would you need to know first" follow-ups | Highest. Deepa is your future manager (hiring-manager prior) and Ross is a senior executive; both priors lean Case. The POV is a live strategy task | Clarify, objective, segmentation, approach, metrics, risks. Think aloud and challenge one premise respectfully |
| Skeptic | Quiet probing of the move from payments partnerships and consulting into rail | Highest. Deepa is buying capability and derisking gaps, and F4 and F5 are gaps you have named | Rehearse the single most predictable objection (B1) until it is boring. Use only adjacent evidence you stated, with the limit said plainly |
| Data-Driven Prober | Ross working your £4M and 6 to 40 | High. The recruiter said Ross will push on commercials, and both figures are on your own list | Know what you can and cannot say about how each figure was counted. Say plainly when you do not know |
| Pressure | Ross time-boxing and testing whether you hold a position | Medium. Executive prior, plus the commercial push | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| Conversational | An opening "walk me through the journey" and a "why us" | Lower. Probably only the opening, but casual questions are still scored | A 90-second arc built from your own sentences |
| Values/Behavioral, Peer Evaluator | Not banked | Low. The recruiter described no values round, and nobody on the panel is a peer | Not needed. Add if the JD or interviewer profiles say otherwise |

These weights rest on your recruiter's description of this one session, not on any documented Kelverton process.

## Question banks

### A. Case/Strategist (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] | This is the 15-minute POV. Follow the shape and thesis options in the graded deliverable above. Open by stating what you take "operator partnership" to mean, since the role may define it differently | The recruiter named this as the deliverable and scored it first; CASE because it asks for structure on a live problem |
| A2 | "Which operators would you start with, and what would you need to know to choose?" | CASE | [generic] | Criteria first, then the choice, then what would change your mind. Say what you do not know about the operators' mix rather than assuming it | Follow-up a POV usually draws; CASE because it scores how you choose, not the answer |
| A3 | "What would make an operator say a partnership with us was worth their team's time?" | CASE | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer from the operator's seat: what they must do differently, what it costs them, what they get. The quote carries only bus and light rail network planning. Answer slot: if that work gave you a view of what operators weigh, say what in your own words; if it did not carry over to train operating companies, say so plainly and answer as a structured view | F2's requirement, asked as a decision; CASE because the live problem is the operator's side of the deal |
| A4 | "A partner programme's activity has been flat for two quarters. Diagnose it." | CASE | [generic] | Clarify what flat means and against what. Then segment: which partners, which stage. Then hypotheses and what data separates them. Say what you would check first | Standard diagnostic stem for a partnerships seat; `[generic]` because it carries no claim about Kelverton |
| A5 | "What would you deliberately not do in the first 18 months?" | CASE | [generic] | Name one thing, give the reason, and say what evidence would change your mind. This is the anti-pick from the deliverable section | The recruiter asked for a POV, and a POV with no "no" reads as a list. CASE because it scores judgment about priorities |

### B. Skeptic (weight: highest, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically", "never carried a direct quota, only influenced revenue", "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40", "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | **The highest-ROI rehearsal in this pack.** Name the limit before it is asked: "I've never sold into rail specifically, and I've never carried a direct quota, only influenced revenue." Concession wording: "That is a real gap, and I would rather name it than have you find it." Hold at the quotes' scope: the ISV channel, and bus and light rail network planning. Follow-up 1, why influence should become a number you carry: answer slot. Say what your influenced figure rested on, in your own words; if you do not know how it was counted, say so plainly, and return to "roughly £4M of influenced revenue". Follow-up 2, the first 90 days: say it as a plan only. Who you would ask, what you would look at first and by when are your own to fill; claim no rail work | F4 and F5 are stated gaps, so this objection will arrive in some form. JD because it scores the role's requirements against the gaps |
| B2 | "You worked in bus and light rail. What from that applies to train operating companies, and what doesn't?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Keep the quote's scope: bus and light rail network planning, from the consulting side. Answer slot: if some of it applies, say which part and why in your own words; if you cannot say what applies, say so plainly and say what you would learn first. Do not describe yourself as an operator | F2's transferability limit, asked directly; JD because it scores the stated fit |
| B3 | "Why this move, and why now?" | EXP | [generic] | Selection scaffold: give your actual reason in your own words, one reason you can defend under a follow-up, and what pulls you to this role in particular. If a reason is thin, say so plainly and give the nearest true one | The motivation check Skeptics run; EXP because the answer must survive cross-examination |
| B4 | "What from taking the channel from 6 to 40 wouldn't carry to operators?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | Answer slot: if something from that growth would not carry over, name it in your own words; if you cannot name one, say so plainly and say what you would ask Deepa first. Do not describe how the 40 partners were signed or managed beyond the quote | F1's transferability limit, rehearsed so the honest answer is ready; EXP because it probes what you took from your own experience |
| B5 | "What would you need from me in your first 90 days?" | JD | [generic] | A reciprocity answer. What you would want to learn, what you would bring, and how you would like to disagree with a manager. Make no claim about past managers | Deepa is your future manager; JD because it scores working fit |

### C. Data-Driven Prober (weight: high, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the £4M of influenced revenue was counted." | EXP | [grounded] "roughly £4M of influenced revenue" | Four slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Keep "roughly" and "influenced". "I don't know how it was counted" is an honest branch. Do not supply a method or a period | F3, a headline figure; EXP because the probe is attribution and counting |
| C2 | "How was the move from 6 partners to 40 counted, and how much of it was yours?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | Same four slots, applied to the partner count. Say what counted as a partner and over what time only if you know; if you do not, say so plainly. Do not name a method or a number the quote does not carry | F1's second headline figure; EXP for the same reason |
| C3 | "Influenced revenue isn't a number you carry. What would you be willing to be measured on here?" | JD | [grounded] "never carried a direct quota, only influenced revenue", "roughly £4M of influenced revenue" | First the acknowledgment: "I've never carried a direct quota, only influenced revenue." Answer slot: give your actual position on what you would be measured on, in your own words, and what you would want to know first; if you do not yet know what is measurable here, say so plainly and ask. Put no target or range in your own mouth that you did not choose | F4 is a stated gap and the recruiter says Ross will push on commercials; JD because it tests the role's commercial terms |
| C4 | "Pick one partnership type and tell me how it makes money for us and for the operator." | CASE | [generic] | Structure it: who pays, who gains, what you would need to size it. Supply no numbers and no claim about Kelverton's pricing. Say plainly what you would need to learn before putting figures on it | A commercial case in Ross's register; CASE because it scores reasoning, not the right answer |

### D. Pressure (weight: medium, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already sold into rail?" | JD | [grounded] "Never sold into rail specifically", "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | Hold only what the quotes carry. Concede first: "I've never sold into rail specifically." Hold through two follow-ups by returning to the channel quote, never by adding to it. Answer slot, if asked what an ISV channel has to do with selling to operators: if you see a direct parallel, say it as your view; if there is none, say so plainly and stay with the channel you ran | F5 is a stated gap and Ross is the likely asker; JD because it scores the requirement under pressure |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue", "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40" | Hold the word "influenced". Answer slot: your share, in your own words; if you cannot say how much, say so plainly. Concede only that specificity, and do not retreat on the figure itself | F3's attribution probe, in pressure form; EXP because it tests attribution honesty |
| D3 | "Forget our side. In two sentences, what changes for an operator?" | CASE | [generic] | Practise a two-sentence version of the close: what changes for the operator, and what it has to do differently. Say the same two sentences again if interrupted | The recruiter asked you to land on operators, and a time-box tests whether you can; CASE because it scores clarity under compression |

### E. Conversational (weight: lower, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40", "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc using only the beats the quotes state: transport consulting in bus and light rail network planning, and nine years in partnerships, the last four running the ISV channel. Answer slot: the order of those roles, and what you did in the partnership years before the payments company, are not in your material. Say them in your own words; if a move had no particular reason, say so plainly and say what draws you here now | Almost certain as an opener; EXP because the CV claims are what it checks |
| E2 | "What stood out to you in the strategy report?" | CO | [inferred] "which I've read" | Answer slot: say what stood out, in your own words. Bring one item to show you read it and one point where you would depart from it, with reasons; if nothing stood out, say so plainly. The pack has not seen the report, so it supplies no content from it | F6; CO because it tests homework depth, derived from the recruiter attaching the report |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 POV on operator partnerships over 18 months | A1, A2, A4, A5, B4, C2 |
| F2 land on what it means for operators | A3, B2, D3 |
| F3 commercials | C1, C2, D2, C4 |
| F4 a revenue number | B1, C3 |
| F5 rail experience | B1, B2, D1 |
| F6 the report | E2 |
| JD requirements beyond the recruiter's words | — none, and why: no JD was supplied, so none are known |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | To Deepa: "When these operator partnerships look like a success in 18 months, what has changed for an operator that isn't true today?" | It tests whether your landing on operators matches hers, and it hands you her definition |
| R2 | To Deepa: "In this role, does partnership mean the operators who buy, the operators we build with, or the other parties around them?" | It settles the definition your POV depends on, and answers F1's open question |
| R3 | To Ross: "How is this role measured in its first year: influenced revenue, a quota, or something else?" | It puts the commercial structure on the table openly and follows from F4 |
| R4 | To Ross: "Where do you see commercial risk in a partnerships-led approach that I should be designing around?" | It asks for his concerns in his own terms and shows a commercial lens |
| R5 | To Deepa: "What would you want to have seen from me by day 90 for this to feel like the right hire?" | It gets her success criteria stated, which you can then plan against |
| R6 | To both: "What is the biggest question mark you still have about my background?" | It surfaces the objection in the room, where you can answer it; the B1 rehearsal is the preparation |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Having sold into rail | Negative you stated, F5 | The acknowledgment F5 gives: "I've never sold into rail specifically." No slot |
| Carrying a quota, or owning the £4M | Negative you stated, F4 | The acknowledgment F4 gives: "I've never carried a direct quota, only influenced revenue." No slot |
| £4M of revenue, without the word influenced | Inflated form of F3 | F3's quote at its own scope: "roughly £4M of influenced revenue" |
| Personally signing or managing the 40 partners | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation: the material says you took the channel from 6 to 40 and not how |
| Having worked inside an operator, or in heavy rail | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning, from the consulting side |
| Having run partnerships with operators | Inflated form of F1 | F1's quote at its own scope. The material describes ISV partners, and B4's slot stays inside the channel |

## Sources

**Provided:** your message, including the recruiter's email as you quoted it. The market report she attached is not visible to this pack, so nothing here draws on its content.

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | The call was refused. It would have fed any VAL questions and the values cheat sheet if a values round exists |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | The call was refused. It would have shown whether other rounds follow. Persona weights rest on the recruiter's description |
| 3. `Kelverton Rail strategy` | unavailable | The call was refused. It would have fed CO questions, which are generic for now |
| 4. `Deepa VP Partnerships Kelverton Rail`, `Ross Commercial Director Kelverton Rail` | unavailable | Both calls were refused. The interviewer read is absent and the reverse questions are role-generic |
| 5. representative `Senior Partnerships Manager` JD | unavailable | The call was refused. No JD was supplied, so the JD-tagged questions rest on the recruiter's words |

Queries sent, all refused: `Kelverton Rail values`; `Kelverton Rail interview process partnerships manager`; `Kelverton Rail strategy scheduling software train operating companies news`; `Deepa VP Partnerships Kelverton Rail`; `Ross Commercial Director Kelverton Rail`; `Senior Partnerships Manager rail technology train operating companies job description`.

## Upgrade menu

- The JD text → the generic requirement rows F4 and F5 become quoted, mid-list requirements get their own questions, and any gates show up
- Your CV, or just the order and employers of your roles → E1's open slot closes and F1 to F3's evidence gets exact wording
- A partner-sourced pipeline or influenced-revenue report from the payments company, even a redacted export → F3 can move from `medium` to `high`
- The market report, pasted or summarised → a grounding brief and a differentiation bank built on its actual content, and E2 stops being generic
- Public profile text for Deepa and Ross → an interviewer read and a reverse question tied to each one's path
- Your answers to the slots in F1, F3 and B1 → those rows regenerate on your own words
- Web search allowed, or the values page and loop details pasted → the values, loop and strategy targets above stop being unavailable
- A `tuesday-dossier.md` from a prior job-underwriter run → the highest-ROI objection would be evidence-derived and the prohibited list would arrive from verified evidence
