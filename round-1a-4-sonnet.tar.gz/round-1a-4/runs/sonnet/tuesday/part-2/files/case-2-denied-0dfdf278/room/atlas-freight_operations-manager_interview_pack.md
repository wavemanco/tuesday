# Interview prep pack: Operations Manager, Atlas Freight

- **Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees, per the JD you pasted)
- **Interviewer and relationship:** not known. This pack is built for an unknown round with flat persona weights, which is noticeably weaker than a pack built for a known round. Telling me who you meet first reweights every bank.
- **Version:** first build

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding for a spoken answer of 90 to 120 seconds, not a script. Every sentence in quotation marks that describes your past is one you wrote to me. Anything past those sentences is an answer slot: an instruction for the interview, answered from your real experience, with an honest branch if the thing never happened or was not yours.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the behavior asked about, not generic virtue |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Homework depth on the company's strategy and moves |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

No CO questions appear in this pack: nothing about Atlas Freight beyond the JD could be researched (see Sources), and a CO question written from memory would be invented.

## Fit snapshot

The JD states no gate (no licence, location, pay, travel or schedule term), so no row is a hard gate. The experience-length line is graded as an ordinary requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" — JD | "currently a senior shift manager over 3 supervisors" — your message; "7 years in warehouse and distribution ops" — your message | medium | [grounded] | transferability | Your material says a senior shift manager role and seven years in warehouse and distribution ops. It does not show terminal operations or more than one site, and the words stay at the quote: "I'm currently a senior shift manager over 3 supervisors." Answer slot: the JD's 4 sites line makes a probe on multi-site responsibility likely. If any of your responsibility reached beyond your own shift or site, say what and how far, in your own words; if none did, say so plainly and stay with the shift you manage |
| F2 | "drive on-time performance and cost-per-shipment down" — JD (the on-time performance half) | "ran the site's peak-season surge plan two years running" — your message | low | [inferred] | discovery | Derived from the surge-plan quote to the JD's on-time term: the quote shows a plan you ran, not whether on-time performance was tracked or moved, and the bridge does not stretch it. Answer slot: if on-time performance was measured around the surge plan, say what was measured and what happened, in your own words; if it was not measured, or not yours to measure, say so plainly and stay with the plan you ran |
| F3 | "drive on-time performance and cost-per-shipment down" — JD (the cost-per-shipment half) | "cut mis-pick rate 40% by redesigning the pick path" — your message | medium | [grounded] | transferability | Mis-pick rate is adjacent work that the quote does not connect to cost, and the words stay there: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if any cost was counted alongside the mis-pick rate, say what was counted; if none was, say so plainly and stay with the rate |
| F4 | "lead a team of 12 supervisors" — JD | "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | transferability | The quote carries 3 supervisors, not 12, and the words stay at 3: "I'm currently a senior shift manager over 3 supervisors." Answer slot: expect a probe on the step from 3 to 12. Say how many you manage today, and describe how you would approach the larger team as a plan, never as a past |
| F5 | "build reporting in Excel/Power BI" — JD (the Excel half) | "solid Excel" — your message | low | [grounded] | discovery | The quote says solid Excel, not reporting built in it. Answer slot: if you built reports in Excel, say what one tracked and who used it; if you did not build reports, or what you built was not reporting, say so plainly and stay with "solid Excel" |
| F6 | "build reporting in Excel/Power BI" — JD (the Power BI half) | "never used Power BI" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. Never a claim to dashboard work, and nothing added to make the gap feel smaller |
| F7 | "5+ years operations leadership required" — JD | "7 years in warehouse and distribution ops" — your message; "currently a senior shift manager over 3 supervisors" — your message | medium | [grounded] | discovery | The first quote counts years in operations, not years leading people, so the count resolves downward until you say otherwise. Answer slot: the JD's five-year leadership line makes a probe on how many of the seven years were leading people likely. Say how many years and in which role, in your own words; if only some of the seven were leading, say which; if fewer than five, say so plainly and stay with "currently a senior shift manager over 3 supervisors" |
| F8 | "Lean/Six Sigma a plus" — JD | "green belt certified" — your message | medium | [grounded] | none | The certification quote already reaches the plus. It is a claim with nothing inspected behind it, so expect a probe on where it was applied (H3). Words: "I'm green belt certified," said the way your certificate names it |

## Persona table

The loop is not established by any source I could read, and your note does not say who you meet or in which round, so the fallback is the generic archetype (screen, hiring manager, panel) with flat weights. Each persona gets 3 questions.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Data-Driven Prober | Goes line by line through your numbers; follow-ups go two levels deeper | Even. Your material carries one headline figure (F3), which probers go to first | Know what you can and cannot say about how the 40% was counted; say plainly when you do not know; name your weakest assumption first |
| B. Pressure | Time-boxes, interrupts, plays devil's advocate | Even. Scale (F1, F4) and years (F7) are the natural pressure points | Pause, restate the question, hold your quoted position through two follow-ups, concede specifically |
| C. Values / Behavioral | Scenario probes; wants a story with a hard truth in it | Even. No published values and no values round could be confirmed, so these are generic behavioral probes | Pick stories where the hard truth landed; where your material shows none, say so plainly |
| D. Case / Strategist | Live problems from the role: diagnose, plan, size | Even. The JD names on-time performance, cost and surge-type pressure as the job | Clarify, objective, segmentation, approach, metrics, risks; think aloud |
| E. Skeptic | Quiet, persistent probing of the gaps | Even, but E2 is the most predictable question in the loop (F1, F4) | Rehearse the single most predictable objection until it is boring |
| H. Conversational | Friendly, unstructured; still scored | Even. Any first conversation opens here | A 90-second arc built only from your own sentences; treat casual questions as scored |
| G. Peer Evaluator | Seam-splitting, "what would you need from me" | Even. A site peer or adjacent function head may be in the loop | Reciprocity framing; propose seam principles, not a claimed seam |

## Question banks

**Highest-ROI prep in this pack: E2.** The jump from your current scope to four sites and twelve supervisors will be asked in some form. Rehearse it until it is boring.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Say it as you said it: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: in your own words, say how the figure was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours. Name that assumption before the interviewer does. If you do not know how it was counted, say so plainly; that is an honest answer | F3 is your headline figure, so it is the first line a prober tests. EXP because it tests attribution and counting |
| A2 | "Tell me about a report you built and who used it." | JD | [grounded] "solid Excel" | Selection scaffold: pick a report that had a named reader, a decision it fed, and a number you could explain line by line. If no such report comes to mind, say so plainly, then say what "solid Excel" actually covers in your work, or how you would build the first weekly report for four sites | F5 is a one-line claim, and the JD's reporting line makes this open prompt likely. JD because it scores a stated requirement |
| A3 | "How would you check that a terminal's on-time number can be trusted before you act on it?" | JD | [generic] | The question needs no claim about your past, so the guidance makes none. Structure it: what the number measures and from which timestamps, who records it, where it can be gamed or distorted, and what you would compare it against. Think aloud and state your first check | F2's requirement, asked as a live reasoning question. Generic because it is a pattern for the problem, not a fact about Atlas Freight |

### B. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: the posting asks for five years of operations leadership. Walk me through how your seven years meet that." | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Start with the quote: "I have 7 years in warehouse and distribution ops." Answer slot: say how many of those years were leading people and in which role, in your own words; if only some were, say which; if fewer than five, say so plainly and return to "currently a senior shift manager over 3 supervisors". Hold through two follow-ups by returning to the quotes, never by adding to them. Pause before answering and restate the question | F7 is the most literal line on the JD and the likeliest to be screened exactly. JD because it scores the stated requirement; Pressure because the 60-second box tests composure |
| B2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Return to your sentence: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: say which parts of the redesign were yours and which were other people's, in your own words; if it was shared, or you cannot split it, say so plainly. Hold through two follow-ups by restating what you did, and concede specifically what you do not know, without folding on the core claim | F3 again, under pressure rather than analysis. EXP because it tests attribution honesty |
| B3 | "This role has 12 supervisors and you lead 3 today. Why should we expect you to step up?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Hold only what the quote carries: "I'm currently a senior shift manager over 3 supervisors." Your concession, in these words: "The team is a different size than the one I lead now." Then a plan, said as a plan: what you would learn and do first with a larger team. Hold through two follow-ups; never argue the scales are equivalent | F4 is a numbers gap the interviewer can see on the page. JD because it scores the stated requirement; Pressure because it is delivered as a challenge |

### C. Values / Behavioral

No published values or values round could be confirmed, so these are behavioral probes from the persona stems and the JD's supervisor-leadership line, not company-specific mappings.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you said the hard thing plainly, and an intact working relationship afterward. Choose one where the truth actually landed. If no such time comes to mind, say so plainly, then give the nearest thing your own material carries, or how you would handle it | Standard behavioral probe for an operations role that reports upward. VAL because it scores past behavior |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the customer's outcome and an internal number pulled apart, name both, say what you chose and what it cost. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Freight is a service business and the JD's two headline measures are service and cost, which can pull apart. VAL because it scores the choice |
| C3 | "Tell me about a time you had to hold a supervisor accountable." | VAL | [generic] | Selection scaffold: pick a case with a specific behavior, what you said, what changed, and the relationship afterward. Use "I" for what you did and "we" only for context. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | The JD's supervisor-leadership line (F4) makes accountability the natural behavioral theme. VAL because it scores past behavior |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You take over four terminals and on-time performance is slipping at one of them. What do you need to know first, and how do you structure the diagnosis?" | CASE | [generic] | The question asks about no past, so the guidance makes no claim about yours. Clarify first (how on-time is defined, over what period, against what target), state the objective, segment (lane, shift, customer, dock), form an approach, name the metrics, name the risks. Challenge one premise respectfully | F1 and F2 requirements, delivered as a live problem. Generic because it is a pattern, not a fact about Atlas Freight |
| D2 | "Cost-per-shipment is above target across the network. Where do you look first?" | CASE | [generic] | No claim about your past. Structure: how cost-per-shipment is built (what goes in the numerator and denominator), which components move with volume and which do not, where variation between sites would show up first, and what you would test before changing anything. Say your first move out loud | The JD's cost-per-shipment line (F3), asked as reasoning. CASE because it scores structure over the right answer |
| D3 | "Peak season is coming and all four sites expect a surge. Sketch the plan, and tell me what you need to know first." | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Answer the case first, structurally. Your personal link is only this sentence: "I ran the site's peak-season surge plan two years running." Answer slot: if you are probed on how that plan was built or what changed between seasons, say what you know in your own words; if nothing changed, or it was not yours to set, say so plainly and return to the sentence | F2's evidence, used as the single grounded link into a case. CASE because it scores structure; the quote limits what you may claim about the plan |

### E. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "currently a senior shift manager over 3 supervisors" | Choose the one you will name first, and say why in your own words. If it is Power BI: "I haven't used Power BI," then the plan, said as a plan. If it is scale: "I'm currently a senior shift manager over 3 supervisors," then the plan. Calibrated candor beats bluffing a skill the interviewer may own | F6 and F4 are the two gaps your own message states. JD because it scores the listed job including its gaps |
| E2 | "We have four sites and twelve supervisors. What have you done at that scale, and how would you handle the jump?" | JD | [grounded] "currently a senior shift manager over 3 supervisors"; "ran the site's peak-season surge plan two years running" | The highest-ROI prep in this pack. Level 1: "I'm currently a senior shift manager over 3 supervisors," and "I ran the site's peak-season surge plan two years running." Level 2, if pressed on more than one site: answer slot: if any of your responsibility reached beyond your own shift or site, say what and how far, in your own words; if none did, say so plainly and return to the two sentences. Level 3: give the plan for the first 90 days, said as a plan, never as a past. Name the limit before it is asked for. Hold through each follow-up by returning to the quotes, never by adding to them | F1 and F4 together are the biggest gap the interviewer can read in the JD and your background. JD because it scores the headline requirement |
| E3 | "This role builds reporting in Power BI. What is your plan?" | JD | [grounded] "solid Excel, never used Power BI" | Open with the plain acknowledgment, which you stated: "I haven't used Power BI." Then a plan in your own words: what you would do in the first weeks, said as a plan and never as a past. Do not describe dashboard work. Answer slot: if you have built reports in Excel, say what one tracked and who used it; if not, say so plainly and stay with "solid Excel" | F6 is the one requirement your message says you do not meet, so the honest answer must be ready before the probe. JD because it scores a stated tool |

### H. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors"; "cut mis-pick rate 40% by redesigning the pick path"; "ran the site's peak-season surge plan two years running" | A 90-second arc with four beats, each one of these sentences: the 7 years in warehouse and distribution ops, the current senior shift manager role over 3 supervisors, the mis-pick result, the surge plan. Connect them in your own words and stop. Any detail beyond these sentences is yours to tell from your real experience, and none is supplied here | The biography question opens most conversations and is scored. EXP because it tests whether the story is consistent with what follows |
| H2 | "Why this role, and why now?" | JD | [generic] | Give your own actual reason, in your own words; no reason is supplied here and none should be borrowed. The reason that survives follow-ups is the true one, and it should connect to something in the JD you can name | Motivation consistency is a standing probe. JD because it ties your move to the role |
| H3 | "Tell me about a time you used your green belt training." | JD | [grounded] "green belt certified" | Say it as you said it: "I'm green belt certified." Answer slot: if the pick-path redesign used the method, say how, in your own words; if it did not, or you applied the training elsewhere, say where; if you have not applied it, say so plainly. Do not link the two unless you can stand behind the link | F8, the JD's plus. JD because it scores a listed preference; the slot keeps the link between certificate and redesign yours to make or decline |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [generic] | No claim about your past. Propose seam principles rather than pretending to know the seam: who owns the customer commitment, who owns the cost, how a disagreement gets raised before it gets escalated. Show spine and tact together | Peer rounds test partnership fit. JD because it scores the listed job's cross-team side |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a piece of cross-team work, say who did what, and say how credit was named. Use "we" for context and "I" for your contribution. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Credit-sharing is a standard peer probe. VAL because it scores past behavior |
| G3 | "What would you need from me in your first month?" | JD | [generic] | Lead with reciprocity: what you would bring to the peer's work first, then two specific needs, such as the reporting baseline and the site context. Keep needs concrete and few | A peer pricing what the hire costs in their own time. JD because it scores how you would start |

### Requirement coverage

| JD requirement | Questions |
|---|---|
| "Own daily terminal operations across 4 sites" | E2, D1, D3 |
| "drive on-time performance ... down" | A3, D1 |
| "cost-per-shipment down" | D2 |
| "lead a team of 12 supervisors" | B3, C3 |
| "build reporting in Excel/Power BI" | A2, E3 |
| "5+ years operations leadership required" | B1 |
| "Lean/Six Sigma a plus" | H3 |
| Headline figure: 40% mis-pick reduction | A1, B2 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What would the strongest first 90 days look like in this role across the four sites?" | It asks for the interviewer's own definition of success, and the answer tells you what to emphasize in follow-ups |
| R2 | "Which site is furthest from its on-time and cost targets today, and what has already been tried there?" | It uses the JD's own two measures, and the answer tells you where the real job starts |
| R3 | "How is reporting done today, what lives in Excel, what is meant to move to Power BI, and who owns the build?" | It surfaces the tool expectation directly, which tells you how much the Power BI gap (F6) will matter in practice |
| R4 | "How are the 12 supervisors spread across the sites, and where is the team strongest and thinnest?" | It shows you are already thinking about span of control, the step in F4 |
| R5 | "How would you measure success in this role at six months?" | The answer gives you the scoring sheet in the interviewer's own words |
| R6 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for a peer interviewer; it turns a probe into a working conversation |

## Prohibited claims

What this pack will not coach, and why. Banks above are written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Experience running operations across multiple sites or terminals | Inflated form of F1 | F1's quote at its own scope. The limit is the pack's observation, not words for you: the material says a senior shift manager over 3 supervisors, not multiple sites. E2's slot stays inside what you tell me |
| Leading a team of 12 supervisors | Inflated form of F4 | F4's quote at its own scope: 3 supervisors. B3's concession is about size only |
| Five or more years of operations leadership | Inflated form of F7 | F7's quote at its own scope. The material counts 7 years in operations, not 7 years of leading; B1's slot asks only how many were leading |
| Improved on-time performance or cost-per-shipment | Inflated form of F2 and F3 | F3's quote at its own scope: mis-pick rate. The material says mis-pick rate, not on-time or cost. A1 and D3 stay inside the quotes |
| Built reports or dashboards in Excel | Inflated form of F5 | F5's quote at its own scope: "solid Excel". A2's slot asks only what a report tracked, if one exists |
| Experience with Power BI | Negative you stated, F6 | The plain acknowledgment F6 gives: "I haven't used Power BI." E3 builds the plan from it |
| The pick-path redesign was a green belt project | Inflated form of F3 and F8 together | Each quote at its own scope. H3 leaves the link as your slot to make or decline |
| The surge plan covered more than your site | Inflated form of D3's quote | The quote says "the site's" plan. D3 and E2 stay at that scope |

## Sources

**Provided documents:** the JD text you pasted; your message describing your background. No CV was provided, so every evidence quote is your message's own words. No `tuesday-dossier.md` was present.

**Searches sent, all refused (no results returned):**

- `Atlas Freight regional logistics company values` — refused
- `Atlas Freight operations manager interview process` — refused
- `Atlas Freight regional logistics terminals news strategy` — refused

Nothing about Atlas Freight beyond your JD is used anywhere in this pack. Values, loop structure and strategy are therefore not established, and the pack does not fill them from memory.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight values` | unavailable | The search was refused. It would have supplied official value names for a cheat sheet and VAL questions mapped to them; the cheat sheet is dropped and bank C is generic |
| 2. `Atlas Freight interview process operations manager` | unavailable | The search was refused. It would have supplied the named rounds that persona weights follow; weights fall back to flat |
| 3. `Atlas Freight strategy` / recent news | unavailable | The search was refused. It would have supplied current priorities for CO questions; none are written |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Operations Manager` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The round type and who you meet first, with any recruiter notes on focus areas or things to prepare → persona weights computed from the real loop instead of flat, and any announced deliverable gets its own build section
- The interviewer's name and title → an interviewer read from their public professional footprint and a reverse question tied to their own path
- The Atlas Freight values or careers page pasted in, or search access allowed → a values cheat sheet, mapped stories in bank C, and CO questions grounded in current strategy
- Your CV → the evidence column can quote CV lines, which can upgrade F1 to F5 and F7 from the confidence they carry now
- The artifacts that carry the most weight in operations: the before and after mis-pick counts behind the 40%, the surge plan document, a sample weekly KPI or reporting sheet you built → F2, F3 and F5 can move from low or medium confidence toward high
- Your own answers, outside a drill, to the answer slots on F1, F2, F3, F4, F5 and F7 → each of those rows regenerates from your words and the matching bank rows become story-mapped
- How much prep time you have before next week → a prioritized schedule sized to it
- A `tuesday-dossier.md` → verified-evidence and prohibited-claims constraints that would sharpen the weak-area guidance
