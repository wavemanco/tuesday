# Interview prep pack: Product Manager, Platform APIs at Quartzline

- **Round:** 45-minute conversation with the hiring manager, Thursday. Interviewer unnamed, so there is no interviewer read.
- **Built from:** your `tuesday-dossier.md` (underwriting decision `conditional_go`, context only). Its two conditions shape the pack: the bridge is positioned as adjacent and never as PM experience, and the squad-authority question gets verified in the interview (reverse question 1).
- **Highest-ROI prep:** A1. The underwriter named that objection, and the pack uses it as written.

## 1. How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script. Every first-person sentence in it is proposed wording, pending your approval: change anything that is not how you would say it, and rehearse only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your experience claims survive scrutiny, and what was actually yours |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you did your homework on the company and its strategy |
| CASE | Structure and reasoning on a live problem from the role |

An answer slot is an instruction for the interview. It is not a question for you now. Each one has two honest branches, and the second always allows that the practice never existed or was not yours.

## 2. Prep triage (two days)

Do these in order. Everything else is insurance.

1. Say A1 out loud until the concession and the bridge come out in your own words and stay inside the three quoted sentences (F1).
2. One pass through the attribution trio: C1, C3 and F2. Each one is a limit you volunteer before it is extracted.
3. Say B1 and B3 aloud once each, in structure: clarify, objective, segments, approach, metrics, risks.
4. Write reverse questions 1 and 2 on a card. They are the dossier's two unresolved risks.
5. Everything else is insurance.

## 3. Fit snapshot

Requirements are quoted from the dossier's `role_profile`. Evidence is quoted from its `verified_candidate_evidence`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile R1 | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | low | [grounded] | transferability | The material shows work that fed product, not a PM seat. The dossier's condition is that this is positioned as adjacent and never as PM experience, with the limit said first. Words: "I ran quarterly roadmap-input sessions feeding client evidence to product." Plain acknowledgment, sourced from `prohibited_claims` in the dossier: "I haven't held the PM title." |
| F2 | "Own the roadmap for the partner-facing API platform" — dossier role_profile responsibilities | none given | none | [grounded] | capability | The dossier records this as an `acknowledge_gap` area under `uncertain_or_weak_areas`. Words, sourced from that field and from `prohibited_claims`: "I haven't owned a roadmap." Then a plan for how you would learn the decision rights, said as a plan and never as a past. No bridge and no slot |
| F3 | "Shipped API or platform products" — dossier role_profile R2 | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [inferred] | transferability | The quote says integrations of the vendor's REST APIs, not the API product itself, and the words stay there: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Answer slot: the JD's shipped-products line makes a probe on the product itself likely. If any decision that shaped the API product was yours, say which and how you made it, in your own words. If the integrations used the API as it was, or such decisions were not yours, say so plainly and stay with the integrations |
| F4 | "Technical fluency: API docs, schemas" — dossier role_profile R3 | "Wrote the internal integration playbook her team uses" — dossier verified_candidate_evidence; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | high | [inferred] | discovery | The quotes touch the requirement without showing API docs or schemas. Answer slot: the JD's docs-and-schemas line makes a probe likely. If reading or writing API docs or schemas was part of the integration work or the playbook, say what and how, in your own words. If it was not, say so plainly and stay with "I wrote the internal integration playbook my team uses." |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier role_profile R4 | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quotes reach clients and product. Engineering and sales are not shown. The sessions are confirmed with limited inspectable proof, so expect a probe. Answer slot: if you worked with engineering or sales in those integrations or sessions, say how, in your own words. If not, say so plainly and stay with the clients and product the quotes name |
| F6 | "Agile delivery experience" — dossier role_profile R5 | none given | low | [grounded] | discovery | The dossier's strategy here is `clarify`, and no quote speaks to this requirement. Answer slot: the JD's agile line makes a probe on how you have worked likely. If you worked in sprints or a similar cadence, say how, in your own words. If you never worked that way, say so plainly and say what you would want to confirm about how this team defines it |
| F7 | "Run discovery with integration partners" — dossier role_profile responsibilities | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier verified_candidate_evidence | medium | [inferred] | discovery | The quote shows sessions that fed product. It does not show whether partners were heard directly. Answer slot: if those sessions put you in direct conversation with clients about their problems, say how it ran, in your own words. If they were relays of what others gathered, say so plainly and stay with the sessions you ran |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | The material is silent. Answer slot: the JD's specs line makes a probe likely. If you wrote specs in any setting, say what they were and where, in your own words. If you did not, say so plainly and stay with the playbook you wrote. Nothing here touches squad prioritization, which is on the prohibited list |
| F9 | "Define and track adoption metrics" — dossier role_profile responsibilities | none given | none | [grounded] | discovery | The material is silent. Answer slot: if you counted or tracked anything about integrations, say what was counted and how, in your own words. If you did not, or it was not yours, say so plainly and say how you would start |

## 4. Prohibited claims (not coached anywhere in this pack)

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | Dossier `prohibited_claims` | F1's quote at its own scope, plus the plain acknowledgment sourced from that field: "I haven't held the PM title." |
| Owned a product roadmap | Dossier `prohibited_claims`, and the `acknowledge_gap` area for roadmap ownership | F1's quote at its own scope, plus the plain acknowledgment: "I haven't owned a roadmap." No slot |
| Set prioritization for an engineering squad | Dossier `prohibited_claims` | The plain acknowledgment sourced from that field: "I haven't set prioritization for an engineering squad." Then how you would decide, said as a plan. No slot |
| Shipped an API product | Inflated form of F3 | F3's quote at its own scope. The limit is the pack's observation, not words for you: the material says integrations of the vendor's REST APIs, not the product |
| Roadmap work, as a description of the quarterly sessions | Inflated form of F1 and F7's quote | The quote at its own scope: roadmap-input sessions feeding client evidence to product. The limit is the pack's observation: the material says input, not the roadmap |

## 5. Persona table

The weights rest on the hiring-manager round-type prior and the generic loop pattern. No loop source was read for Quartzline, so these are not documented facts about their process.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the title gap and the roadmap gap | High: the underwriter named the objection, and F1 and F2 are the largest gaps | Rehearse the one objection (A1) until it is boring. Bridge only from the three quotes, with the limit said first |
| Case/Strategist | A live problem on the partner API platform | High: hiring managers buy capability on their own roadmap, and the role's first duties are roadmap and prioritization | Clarify, objective, segments, approach, metrics, risks, aloud. Challenge one premise respectfully |
| Data-Driven Prober | Line-by-line questions on the confirmed claims | Medium: the claims include a count (30+) and a playbook | Say how each figure was counted, and say plainly where you do not know. Offer to walk through the playbook |
| Peer Evaluator | The seam between your calls and the two squad leads | Medium: decision authority versus the squad leads is unresolved in the dossier | Offer seam principles, not a pretended seam. Reciprocity: what you bring the squads |
| Conversational | The opener, the docs question and the closing reverse slot | Medium: casual openers are scored, and the reverse slot is weighted | A 90-second arc built from the quotes. Never answer "I think you've covered everything" |
| Pressure | Time-boxed "why you over someone with three years" | Low: a 45-minute manager conversation, though the objection can arrive hard | Hold two follow-ups, concede specifically, never fold on the core claim |
| Values/Behavioral | Unpopular-truth and customer-first stories | Low: no loop source was read, and the generic pattern has no values round | Selection scaffolds with their honest branch, because no quoted sentence carries these stories |

## 6. Question banks (proposed wording, pending your approval)

### A. Skeptic (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | The deepest rehearsal in the pack, in four moves. 1) Concede first, plainly, sourced from the dossier's `prohibited_claims` and its `acknowledge_gap` area: "I haven't held the PM title, and I haven't owned a roadmap." 2) Bridge, labelled adjacent, with its limit said before it is asked for: "What I have is adjacent. I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live. I wrote the internal integration playbook my team uses. I ran quarterly roadmap-input sessions feeding client evidence to product." Say the limit aloud: those sessions fed product, and the roadmap decisions were not yours. The playbook is the one you can hand over. For the sessions, say what you can show and what you cannot, because they are confirmed with limited inspectable proof and a prober will find the seam. 3) Ramp, said as a plan and never a past: what you would do first is find out which roadmap decisions are yours and which sit with the squad leads. 4) Hold, then concede. Hold the adjacent case through two follow-ups by returning to the three quoted sentences, never by adding to them. If pressed that a PM with three years has done the job and you have not, concede it specifically: "That is a real difference, and I won't dress it up." Then stay on what you offer. Follow-up (a), what did product do with the evidence? Answer slot: if you know what product did with it, say what and how you know. If you do not, or it never came back to you, say so plainly and stay with the sessions you ran. Follow-up (b), so who decided what made the roadmap? Words, sourced from the `acknowledge_gap` area: "The roadmap decisions weren't mine; I fed it evidence." Follow-up (c), why this move, and why now? Give your own reason in your own words. This pack has none from you and writes none | Named by the underwriter, so it arrives in some form (F1, F2). JD, because it scores R1 directly |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Owning a roadmap and prioritization authority (R1 sub-claim)" | Name it yourself before they do. Words, sourced from the dossier's `acknowledge_gap` area: "Owning a roadmap and prioritization authority is the part I haven't done." Follow with a plan, never a past: the first thing you would do is learn which decisions are yours and which sit with the squad leads. If they ask for a second weakness, agile delivery (A3) and adoption metrics (B4) are slots in those rows, so do not describe either as a strength or a gap here | The stem is a standard Skeptic probe and the dossier fixes the honest answer (F2). JD, because it tests honest self-assessment against the stated role |
| A3 | "The role asks for agile delivery experience — what does that look like in your background?" | JD | [grounded] | Answer slot, as a question-shaped answer: the interviewer's probe will use the JD's own words, agile delivery experience. If you worked in sprints or a similar cadence, say how it ran, in your own words. If you never worked that way, say so plainly, then say what you would want to confirm about how this team defines it. Nothing about your past goes in beyond what you say in the slot | F6 is a `clarify` area: evidence may exist but was not established. JD, because it scores R5 |
| A4 | "What's the closest you've come to shipping an API or platform product?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Story-mapped on F3, with beats the quote states and nothing more: "I led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." Name the limit yourself: these were integrations of the vendor's API, which is adjacent to the API product itself. Answer slot: if any decision that shaped the API product was yours, say which and how you made it. If the integrations used the API as it was, or such decisions were not yours, say so plainly and stay with the integrations | The R2 must-have is the second-highest-stakes requirement, and F3 is where the bridge is thinnest. JD, because it scores R2 |
| A5 | "Why this move, and why now?" | EXP | [generic] | Give your own reason in your own words. This pack has none from you, so it supplies none. Tie it to something you can say honestly about the role's stated work, such as partner discovery or adoption, and keep it consistent with A1's ramp. Do not claim an ambition or a prior attempt you cannot back | A standard Skeptic motivation probe. It sits in the pack because A1's follow-up (c) leads straight to it |

### B. Case/Strategist (highest weight)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You inherit the roadmap for a partner-facing API platform. What do you need to know in your first 30 days before you commit to anything?" | CASE | [generic] | Clarify first: which roadmap decisions the PM owns and which sit with the squad leads, and how adoption is measured today and its baseline. Those are the dossier's two open unknowns, so asking them here is the same move as reverse questions 1 and 2. Objective: what the platform is for. Segment partners by type or by integration stage. Approach: discovery with partners, then evidence into a sequenced plan with the squads. Metrics and risks last. Challenge one premise respectfully: you would not commit to anything until decision rights are known. This question asks about no past, so the guidance claims none | The role's first job is the roadmap (F2), so a hiring manager tests how you would start. CASE, because it is a live problem |
| B2 | "Partner adoption of a new API version has stalled. Diagnose it." | CASE | [inferred] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify what adoption means and its baseline before diagnosing. Segment by partner type and by where integrations stall, a cut the quote's own stage words suggest: scoping, requirements, architecture, UAT, go-live. Use those words only if they genuinely fit, and add no stages you did not state. Then hypotheses, the evidence that would separate them, and the first test. State that the baseline is unknown, because the dossier lists it as unresolved | Adoption metrics are a named responsibility (F9). The derivation is the stage cut. CASE, because it is a live diagnosis |
| B3 | "Two engineering squads, one roadmap: one squad wants to pay down API versioning debt, the other has a partner-committed feature due. How do you prioritize?" | CASE | [generic] | Clarify decision rights first, because they are unresolved in the JD. Then offer principles, not a verdict: partner commitments, reversibility, cost of delay, and what each squad says the work costs. Say how you would decide with both leads, and what you would bring them: the partner evidence. If a follow-up asks whether you have made this call before, the honest words are sourced from `prohibited_claims`: "I haven't set prioritization for an engineering squad." Then return to how you would decide. No slot here, and no past prioritization story | The squad-lead authority question (F8) turned into a decision. CASE, because it tests structure over the "right" answer |
| B4 | "How would you define and track adoption for the partner API platform?" | CASE | [generic] | Pick one primary adoption metric and say why, add leading and lagging signals, and name the baseline you would need before setting a target. Answer slot: the JD's adoption-metrics line makes a probe on your past likely. If you counted or tracked anything about integrations, say what was counted and how. If you did not, or it was not yours, say so plainly and say how you would start | Adoption is a stated responsibility with no baseline in the dossier (F9). CASE for the method, JD for the responsibility |
| B5 | "A large partner asks for a custom endpoint only they would use, and sales is pushing. What do you do?" | CASE | [generic] | Clarify what the partner actually needs and what is at stake for them and for sales. Separate the one-off from the platform pattern. Offer options: a general capability, an interim workaround, or a no with reasons. Say who you would bring in, the squad leads and sales, and when. Challenge one premise: whether the endpoint is the real problem. No claim about your past | R4 asks for stakeholder management across engineering, sales and customers (F5). CASE, because it tests judgment under cross-pressure |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Thirty-plus integrations — walk me through how that number was counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Four slots, each in your own words: how the 30+ was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Keep "30+" and "end-to-end" at the quote's scope. Do not turn 30+ into a precise number or a rate | A headline figure on the confirmed claims is a magnet for probers (F3) |
| C2 | "Tell me about the integration playbook you wrote — what's in it, and how do we know your team uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | Beats the quote states: you wrote it, and your team uses it. The dossier records it as inspectable, so offer to walk through it end to end. Answer slot: the JD's specs line makes a probe on how a reader uses a document like it likely. If you know how your team uses it, say how. If you only know that it is used, say that and stop | The most inspectable evidence you hold (F4), and the natural place a prober starts |
| C3 | "Walk me through one of those quarterly roadmap-input sessions." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Beats the quote states: quarterly, you ran them, and they fed client evidence to product. Volunteer the limit before it is extracted. This claim is confirmed with limited inspectable proof, so say what you can show and what you cannot. Answer slot: the JD's partner-discovery line makes a probe on what the evidence was and what product did with it likely. If you know, say what and how you know. If you do not, or it never came back to you, say so plainly and stay with the sessions you ran | The medium-confidence claim is where the dossier expects a probe (F7, F5) |

### D. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You'd work with two squad leads. Where's the seam between your calls and theirs, and what happens when we disagree?" | JD | [generic] | Offer seam principles, not a pretended seam: you do not yet know where it sits, and finding out is the first job. Reciprocity: what you bring the squads is the partner evidence and a clear ask. Disagreement: say how you would handle it, as a plan. Do not claim a past in which you settled such a disagreement | Decision authority versus the squad leads is asserted in the JD and unevidenced (F8). JD, because it scores the stated working relationship |
| D2 | "How do you handle credit and ownership when work spans engineering and product?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Use "we" for context and "I" for what you contributed. For the integrations, the quote's own verb is "led". Answer slot: if others' work was part of those integrations, say which parts were theirs and which yours. If the work was yours alone, say so plainly. Never extend "led" beyond the quote | Credit-sharing probes arrive collegially from a manager too (F5). EXP, because it tests attribution |
| D3 | "Tell me about a time you disagreed with an engineering lead about scope." | EXP | [generic] | Open prompt. Selection scaffold: pick a time where scope or sequencing was contested. It needs a named stake, your position, and the relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. No story is mapped, because none of your quoted sentences carries one | R4 and the two-squad structure make this a likely collegial probe (F5). EXP, because it is a past-behavior question |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc in three beats. Past: the three quoted sentences, in your own words, with their verbs unchanged. Pull: your own reason for the move, which this pack does not supply. Next: what you want to learn first in this role. Describe the sessions as feeding client evidence to product, not as roadmap work | The biography question opens most manager conversations (F1). EXP, because it is scored on economy and honesty |
| E2 | "What do you look at first when you open a new API's docs and schema?" | JD | [grounded] "Wrote the internal integration playbook her team uses"; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer in your own method, in plain words. Answer slot: the JD's docs-and-schemas line makes a probe on your own use likely. If you read or wrote API docs or schemas in the integration work or the playbook, say what and how. If you did not, say so plainly and say what you would look at first | R3 is an important requirement, and the casual register still scores it (F4). JD, because it tests the stated requirement |
| E3 | "What do you know about our partner API platform so far?" | CO | [generic] | This pack found nothing on Quartzline, because the web search was refused, and it writes nothing from memory. Read Quartzline's public developer or partner pages yourself and bring two specific observations you actually made. If you have not looked, say so plainly and ask the question back. Do not guess at their strategy | Homework depth is scored in a manager conversation. CO, because it tests company knowledge. The row is generic until you add research |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over a PM who has done this for three years?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product"; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses" | Pause, restate the question, then hold only what the three quotes carry, with the limit said first: it is adjacent. Hold through two follow-ups by returning to those quotes. Concede explicitly when pressed: a PM with three years has done the job, and you have not (sourced from `prohibited_claims`). Never fold on the quoted claims just to restore harmony | A time-boxed version of A1, in a different delivery (F1) |
| F2 | "That integration count — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Anchor in the quote's verb: "led". Answer slot: if some of the integrations or their stages were shared, say which were yours and which were others', in your own words. If all of it was yours, say so plainly. Hold your position through two follow-ups and concede only what is specific | An attribution probe that arrives under pressure (F3). EXP, because it scores what was actually yours |

### G. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt. Selection scaffold: pick a time where the truth was unwelcome, you said it anyway, and the relationship held. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it. No story is mapped | A stock manager-round question. VAL, but not tied to Quartzline's values, which are not established |
| G2 | "When did you put a customer's need ahead of an internal preference?" | VAL | [generic] | Open prompt. Selection scaffold: pick a time with a named customer need, a named internal preference, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries or how you would handle it | The role's sales and customer stakeholders (F5) make it plausible. VAL, as a customer-first probe |

## 7. Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1 3+ years product management experience | A1, A2, A5, F1 |
| R2 Shipped API or platform products | A4, C1 |
| R3 Technical fluency: API docs, schemas | C2, E2 |
| R4 Stakeholder management across engineering, sales, customers | B5, D1, D2, D3 |
| R5 Agile delivery experience | A3 |
| Own the roadmap for the partner-facing API platform | A1, A2, B1, B3 |
| Run discovery with integration partners | B1, C3 |
| Write specs and drive delivery with two engineering squads | B3, C2, D1 |
| Define and track adoption metrics | B2, B4 |

## 8. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The JD asserts decision authority and the dossier found no evidence for it. The answer settles the condition behind your `conditional_go`, and it reads as diligence |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier names adoption metrics as a responsibility with no stated baseline. A manager hears a candidate who wants to be measured fairly |
| 3 | "How do the two squads run delivery today — cadence, planning, who owns the backlog?" | Your agile row is a `clarify` area. The answer shows how this team defines it, so you can say honestly how you would fit |
| 4 | "How does partner feedback reach the squads today, and who owns that intake?" | It ties to the discovery responsibility and to your sessions without claiming more than they were |
| 5 | "What would a good first 90 days look like for this role?" | It converts the first-30-days case (B1) into their own expectation |
| 6 | "What does the rest of the process look like after today, and who will I meet?" | The pack's loop weights rest on a generic pattern, and this replaces the pattern with fact |

## 9. Sources

- **Provided:** `tuesday-dossier.md`, `dossier_version` 1.1 (within the 1.x this pack reads). Sections consumed: `role_profile` (requirement and responsibility text), `handoff_to_mock_interview` (verified evidence, weak-area strategies, the objection, risks, employer questions, prohibited claims), `decision` (context only). The file carries no `evidence_map`, `evidence_state` or `risk_register`, so none was used.
- **Searches sent, all refused:** `Quartzline company values`, `Quartzline interview process product manager`, `Quartzline partner API platform strategy news`. No fetches were sent. Nothing about Quartzline comes from memory.
- **Loop:** no loop source was read. The persona weights use the hiring-manager prior and the generic archetype, which assumes no values round.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Search refused. It would have moved a values cheat sheet and the VAL rows (G1, G2 stay generic) |
| 2. `Quartzline interview process product manager` | unavailable | Search refused. It would have moved the loop structure and the persona weights |
| 3. `Quartzline strategy` / recent news | unavailable | Search refused. It would have moved a CO question and the case framing in B1 and B2 |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there is no query to form |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD-tagged questions |

## 10. Upgrade menu

- The interviewer's name → a Reading the interviewer section, persona weights read from their public footprint, and a reverse question tied to their path
- The recruiter's prep note, or the loop details (who else you meet, how many sessions) → a documented loop in place of the generic fallback, and any pre-declared deliverable gets its own build section
- Quartzline's values page or strategy material, pasted, or permission to search → the VAL rows and E3 become `[grounded]`, and the case framing in B1 and B2 uses their vocabulary
- Your own words on the answer slots (F4 to F9) → those rows become quoted material and A3, B4, C2, E2 and D2 get story maps in place of slots
- A session agenda, notes, or a record of what product took up from the quarterly sessions → the medium-confidence sessions claim (F1, F5, F7) can be raised, and C3 loses its seam
- The raw CV behind the confirmed claims → more of your own sentences to quote, and a check on the three verbs
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on Quartzline's partner platform, strategy-based CO and CASE questions, and interviewer footprint if you get a name
