# Interview pack: Senior Partnerships Manager, Kelverton Rail

- Round: second round, Tuesday, 60 minutes, panel
- Interviewers: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director)
- Shape, from the recruiter's email: first 15 minutes a POV from you, then Q&A where "Ross will push on commercials"
- Built from: your message only. No JD, no CV, no outside research (see Sources)

## How to use this pack

Personas describe how a question arrives (who asks, in what style). Types describe what is being scored. Every question carries one type tag:

- VAL: whether past behaviour shows a company's published values. Not used here, because no published values were read
- EXP: whether a claim about your past survives scrutiny
- JD: the stated role or the recruiter's stated asks
- CO: company and strategy knowledge
- CASE: a live problem set in the role

Guidance is scaffolding, not a script. An answer slot is an instruction for the interview, not a question for you: say what you did in your own words, or say plainly that it was not yours or did not happen. Words proposed for you to say are pending your approval.

## Prep triage (about four hours, spread over the weekend)

| Order | Time | Do | Tied to |
|---|---|---|---|
| 1 | 90 min | Build the 15-minute POV: pick one thesis, write the three moves, say it aloud twice against a clock, finish the close on operators | Section: Build the POV; A1, A3 |
| 2 | 45 min | Rehearse the highest-ROI question aloud with its three follow-ups, until the two acknowledgments are boring to say | B1 |
| 3 | 45 min | Write down, in your own words, what you know and do not know about how the two figures were counted; practise the plain "I don't know" where it is true | C1, C2, D2 |
| 4 | 30 min | Re-read the recruiter's attached report for one item you can name and one place you would depart from it | A5, E2, Build the POV |
| 5 | 30 min | Choose three reverse questions and say each aloud | Reverse questions |

Everything else in the pack is insurance.

## Fit snapshot

No gate rows: nothing in your message or the recruiter's email states a term such as location, pay, work pattern or right to work, and no JD was supplied. Words for you to say in this section are pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter email, in your message | "9 years in partnerships, last 4 at a payments company running the ISV channel" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material says an ISV channel at a payments company and a count of partners, with nothing inspected behind it. It does not show a rail partnership, or what Kelverton means by operator partnerships. Words stay at that scope: "I spent the last four years at a payments company, running the ISV channel, and took it from 6 partners to 40." Answer slot: the POV ask makes a probe on what carries over from channel-building to operators likely. If part of how you ran that channel applies, say which part and why, in your own words; if none does, or it was not yours to decide, say so plainly and stay with the channel you ran |
| F2 | "Please land on what it means for the operators themselves" — recruiter email, in your message | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | transferability | Your material says consulting in bus and light rail network planning, seen "from the other side". It does not say train operating companies, and it does not say you worked inside an operator. Words stay at that scope: "I spent five years in transport consulting, in bus and light rail network planning." Answer slot: the close on operators makes a probe on what operators needed in that work likely. If you saw it, say what, at bus and light rail scope and in your own words; if you did not, or it was not part of your role, say so plainly and stay with the planning work |
| F3 | "Ross will push on commercials" — recruiter email, in your message | "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | medium | [grounded] | transferability | The figure stays at its scope, "roughly £4M of influenced revenue", and your own sentence limits it. Plain acknowledgment, from the negative you stated: "I haven't carried a direct quota; my figure is influenced revenue." Answer slot: a figure raises four probes. Say how it was counted, what it is sensitive to, the assumption behind it you would defend least, and which part was yours, each in your own words; where you do not know how it was counted, say so plainly |
| F4 | Experience selling into train operating companies (plain prose; inferred from your description of Kelverton's customers, not from a posting) | "Never sold into rail specifically" — your message | none | [inferred] | capability | A gap wording cannot close, and you stated it. Words: "I haven't sold into rail specifically." Then how you would learn the operators' buying world, said as a plan in the future tense and never as a past. Nothing added to make the gap feel smaller |

## Build the POV (recruiter-declared deliverable)

Words for you to say in this section are pending your approval.

What the recruiter asked for, quoted: "present a short POV on where you'd take our operator partnerships over the next 18 months"; "no slides needed, just talk us through it"; "Please land on what it means for the operators themselves".

Facts to build on, from the fit snapshot:

- F1: "took it from 6 partners to 40, roughly £4M of influenced revenue"
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F4, the limit to state early: "Never sold into rail specifically"

Three thesis options. Pick one; do not present all three. Each is a position to argue, so none states a fact about Kelverton. Check each against the report attached to the recruiter's email, which was not in this conversation.

| Thesis | Mandatory concession | What it means for operators (the close) | Provenance |
|---|---|---|---|
| Depth before breadth: make a small number of operator relationships visibly succeed before widening | Per F1, your quoted channel history counts partners, not operators, and per F4 it is not rail, so this thesis rests on reasoning, not rail experience. Say so | Name what an operator would see change in their own work by month 18, in their terms, not Kelverton's | [generic] |
| Operators define success: agree two or three outcomes with a few operators and measure partnerships against those | Per F2, your operator exposure is the consulting side of bus and light rail, so the outcomes must come from operators, not from you; say you would ask them first | The close is the outcomes themselves, said as what the operator can point to | [generic] |
| Fewer partner types, said no to on purpose: decide which kinds of partner Kelverton will and will not pursue | You cannot see the current partner landscape from outside. Say you would test the list in the first 60 days | What operators stop having to deal with, and what they get from the ones that remain | [generic] |

Differentiation: the report is the consensus source, and its authors are in the room. Bring one item it names, to show grounding; then one place your thesis departs from it, with reasons; then the anti-pick, one thing you would not do in 18 months. Reciting the report scores as homework; departing from it with reasons scores as judgment.

Timing scaffold (finish near 13 minutes, so panel interjections do not cost your close):

| Minutes | Beat |
|---|---|
| 0 to 1 | Say what you assume "operator partnerships" means, because your material does not define it, and ask to be corrected |
| 1 to 4 | What you would want to know first, and what you are assuming until you do |
| 4 to 10 | The thesis, three moves, sequenced across months 0 to 6, 6 to 12, 12 to 18 |
| 10 to 13 | What it means for the operators themselves |
| 13 to 15 | The one thing you would not do, and the first thing you would check |

## Persona table

| Persona | Carried by | Weight and reasoning | Counter-strategy (a method, not a claim) |
|---|---|---|---|
| A Case/Strategist | Deepa; the POV itself | High. The hiring-manager prior is Case/Strategist plus Skeptic, and the recruiter's words place Deepa as "your future manager". The POV is itself a live strategy problem | Clarify, objective, segments, approach, metrics, risks; think aloud; challenge one premise respectfully; say aloud what you assume operator partnerships means |
| B Skeptic | Deepa | High. Same prior, and your own message states two gaps (F3, F4) | Rehearse the single most predictable objection until it is boring; bridges only from what you stated; calibrated candour |
| C Data-Driven Prober | Ross | Mid. The recruiter's words: "Ross will push on commercials"; two headline figures sit in F1 and F3 | Know what you can and cannot say about how each figure was counted; say plainly when you do not know; name the weakest assumption before they do |
| D Pressure | Ross | Mid. Same words; Ross's relationship to the role is not stated, so this is a prior to reweigh once you know | Pause, restate, anchor in what you stated, hold through two follow-ups before conceding anything real |
| E Conversational | Either, early | Low. A prior only; a casual-register question is still scored | A short arc built from your own sentences; treat casual questions as scored |
| G Peer Evaluator | Ross, if he works alongside the role rather than above it | Low. Relationship not stated | Reciprocity framing; propose seam principles rather than pretend to know the seam |

No Values/Behavioral bank: the recruiter's email names no values-style round and no values source was read.

## Question banks

Highest-ROI prep in the pack: B1. It will be asked in some form, since F3 and F4 are the two gaps your own message states and Ross has been flagged to press on commercials. Words for you to say are pending your approval.

### A. Case/Strategist (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch where you'd take our operator partnerships over the next 18 months. What do you need to know first?" | JD | [grounded] | This is the POV: use the build section. Open by saying what you assume operator partnerships means and inviting correction, then objective, segments, three moves, how you would know it worked, risks. Think aloud | The recruiter named this as the first 15 minutes; JD because it is the stated ask, CASE in delivery |
| A2 | "If you could fund only two partnership moves in the first six months, which two, and what would you leave out?" | CASE | [generic] | Rank, defend the order, and name what you leave out and why. Challenge one premise of the question respectfully. Make no claim about your past; the answer is reasoning | Tests judgment under constraint, the anti-pick the build section asks for; no claim about the candidate |
| A3 | "What does that plan mean for an operator day to day? What changes for them?" | JD | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Answer in operators' terms, not Kelverton's. If you mention your consulting years, keep them at their scope: "five years in transport consulting, in bus and light rail network planning". Answer slot: if you saw what operators needed in that work, say what, in your own words; if you did not, say so plainly and say how you would find out | The recruiter asked you to land here; F2 is the only operator-side material |
| A4 | "A partner operator tells us something we promised is running late and asks to renegotiate scope. What do you do in the first week?" | CASE | [generic] | Structure: who to talk to first, what you need to learn before you answer, what you would not promise, what you would record, how you would bring Commercial in. A hypothetical, so no claim about your past | Probes how you operate when a relationship is under strain; generic because no research ran |
| A5 | "Where is our partnerships model weakest today, and what would you check before saying so?" | CO | [generic] | State any weakness as a hypothesis, then say what you would check. Use one item from the attached report to show grounding, then your departure. Do not correct the report's authors | CO is generic here because research did not run; the report is the substitute |

### B. Skeptic (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never carried a direct quota and you've never sold into rail. What makes you credible in a conversation about our commercials?" | EXP | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue"; "took it from 6 partners to 40, roughly £4M of influenced revenue" | Hold, then concede, in this order. Acknowledge both in your own stated words: "I haven't carried a direct quota, and I haven't sold into rail specifically." Then what the material carries: "I spent the last four years at a payments company, running the ISV channel, and took it from 6 partners to 40, roughly £4M of influenced revenue." Follow-up 1, likely: how influenced differs from direct. Use the F3 slot; if you do not know how it was counted, say so. Follow-up 2: what you would get wrong first. Name one specific limit, then a plan in the future tense. Follow-up 3: which gap worries you more. Pick one and say why, without adding any experience. Hold by returning to the quotes, never by adding to them | F3 and F4 are the gaps you stated, and Ross is flagged to press on commercials; EXP because it tests what was actually yours |
| B2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" | Choose the gap you stated, and say it plainly: "I haven't sold into rail specifically." Then a concrete ramp, as a plan: who you would learn from and what you would read first. Calibrated candour beats bluffing a market the interviewers know | F4 is the weakest point you have named yourself; JD because it scores fit to the job |
| B3 | "Why this move, into rail-tech, and why now?" | EXP | [generic] | Give your actual reason, in your own words. Nothing in your material states one, so none is supplied here. Keep it consistent with what you say in E1 | Motivation consistency is what a Skeptic scores; the answer must be yours |
| B4 | "You ran an ISV channel in payments. Why would that translate to operators?" | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel" | Say what you think is the same and what is different, at the quote's scope: "I spent the last four years at a payments company, running the ISV channel." Answer slot: if part of how you ran it applies to operators, say which and why; if none does, or it was not yours, say so plainly and say what you would test first | F1 is the evidence for the POV requirement and the likeliest place a sceptic presses |
| B5 | "Your consulting years were bus and light rail. How much of that carries over to train operating companies?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Keep the scope: bus and light rail network planning, from the consulting side. Answer slot: if some of it carries over, say what and why; if you do not know, say so plainly and say how you would find out. Do not say you worked inside an operator | F2 is the evidence for the operator-side requirement; the scope drift from bus and light rail to train operators is the risk |

### C. Data-Driven Prober (mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how that £4M was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Four slots, each in your own words: how it was counted, what it is sensitive to, the assumption behind it you would defend least (name it before they do), and which part was yours. If you do not know how it was counted, say so plainly. Keep the word influenced | F3 is the figure Ross is most likely to press; EXP because it tests attribution |
| C2 | "How was the growth from 6 partners to 40 counted, and which part of it was yours?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Same four slots, in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, which part was yours. If part of it was not yours, or you do not know how it was counted, say so plainly and return to the quote | The second headline figure in F1 needs its own defence |
| C3 | "If this role were measured on operator revenue in its first year, how would you set the number?" | CASE | [generic] | Structure, no figure: what you would need to know first, what you would ask Commercial, how you would separate what partnerships influence from what it directly closes. Your material has no rail sizing, so none is supplied | Tests commercial reasoning without needing a past; generic because no research ran |

### D. Pressure (mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a candidate who has sold into rail?" | JD | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue"; "Never sold into rail specifically" | Pause, restate. Hold on what the quote carries: "I took it from 6 partners to 40, roughly £4M of influenced revenue." Concede specifically: "I haven't sold into rail specifically." Hold through two follow-ups by returning to the quotes, never by adding to them | F3 and F4 set up this challenge; the structure is hold then concede |
| D2 | "That £4M. How much of it was actually you?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Answer slot: say which part was yours, in your own words; if you cannot separate it, or it was not yours, say so plainly and stay with influenced revenue. Do not upgrade influenced to anything else under pressure | Attribution probes exist to catch inflation; F3 |
| D3 | "I'm not convinced a payments channel playbook works with operators. Convince me in two minutes." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel"; "Never sold into rail specifically" | Anchor in what you stated: "I spent the last four years at a payments company, running the ISV channel." Concede what is untested: "I haven't sold into rail specifically." Say what you would test first. Do not claim the playbook transfers | A devil's-advocate version of B4; F1 and F4 |

### E. Conversational (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships, last 4 at a payments company running the ISV channel" | A 90-second arc in three beats: consulting years, in bus and light rail network planning; then partnerships, with the last four at a payments company, running the ISV channel; then why this role, which is your own reason, in your own words, since your material states none | F1 and F2 supply the beats; a casual question is still scored |
| E2 | "What have you been reading or thinking about lately that bears on rail partnerships?" | CO | [generic] | Name something you actually read or thought about. If it is from the attached report, say which part and where you would depart from it. If nothing comes to mind, say so plainly and say what you would read first. Do not recite | The rapport-style way of asking for homework; generic because no research ran |

### G. Peer Evaluator (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where's the seam between Partnerships and Commercial, and what happens when we disagree about a deal?" | CASE | [grounded] "never carried a direct quota, only influenced revenue" | Propose principles, not a map of a seam you cannot see: who owns the operator relationship, how a disagreement is escalated, what numbers you share. Do not claim deal experience; your own words are "never carried a direct quota, only influenced revenue". Offer what you would bring Commercial, not only what you need | If Ross works alongside the role, this is the seam question; F3 limits what you can claim |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Pick a real time credit was shared across teams, say what you did, and keep "we" for context and "I" for your part. If no such time comes to mind, say so plainly, then give the nearest thing your own experience does carry, or how you would handle it | A standard peer probe; no story in your material carries it, so this is a selection scaffold |

### Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| "present a short POV on where you'd take our operator partnerships over the next 18 months" — recruiter | A1, A2, A5, Build the POV |
| "Please land on what it means for the operators themselves" — recruiter | A3, B5, Build the POV |
| "no slides needed, just talk us through it" — recruiter | none, and why: a format instruction, covered by the timing scaffold in Build the POV |
| "Ross will push on commercials" — recruiter | B1, C1, C2, C3, D1, D2, G1 |
| Selling into train operating companies (inferred) | B1, B2, B4, B5, D1, D3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "When you say operator partnerships, which kinds of relationship count, and which do you most want more of?" | Your material cannot define the term from outside; asking shows you start from their definition |
| R2 | "What would an operator who is happy with Kelverton be doing differently 18 months from now?" | It is the operators-themselves lens the recruiter asked you to land on, handed back in their words |
| R3 | "How is success in this role measured in the first year, and who sets that?" | Ross is flagged to press on commercials; asking about the measure shows you want the number, not only the title |
| R4 | "Where do Partnerships and Commercial hand off today, and where does it creak?" | A seam question that invites both interviewers to answer from their own side |
| R5 | "What is the first thing you would want a new person to learn from operators directly, rather than from us?" | Signals operator-first thinking, which is the close the POV is asked to reach |
| R6 | "Which part of the strategy in the report is hardest to deliver through partners?" | Shows you read it and are thinking about delivery, not recitation |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Carried a quota, or was directly accountable for revenue | Negative you stated, F3 | The plain acknowledgment F3 gives: "I haven't carried a direct quota; my figure is influenced revenue." No slot |
| Sold, closed or sourced the £4M | Inflated form of F3 | F3's quote at its own scope: roughly £4M of influenced revenue. The pack's observation: the material says influenced, not sold, closed or sourced. C1 and D2 stay inside influenced revenue |
| Sold into rail, or has rail operator relationships | Negative you stated, F4 | "I haven't sold into rail specifically." No slot |
| Worked inside a train operating company, or knows train operators from the inside | Inflated form of F2 | F2's quote at its own scope: bus and light rail network planning, in consulting, "from the other side". The pack's observation: the material says the consulting side and bus and light rail, not train operating companies |
| Built or ran operator partnerships | Inflated form of F1 | F1's quote at its own scope: running the ISV channel at a payments company. The pack's observation: the material says partners in a payments channel, not operators |
| Designed the partner programme, or chose which partners to sign | Inflated form of F1 | F1's quote at its own scope. The pack's observation: the material says the count went from 6 to 40, not how. C2's slot asks only how it was counted and which part was yours |

## Sources

Provided documents: your message, which holds your background, your description of Kelverton, and the recruiter's email quoted in it. The market report: you said it was attached, and it did not arrive in this conversation, so nothing in this pack comes from it. No dossier was present.

Searches sent, all refused:

| Query | Outcome |
|---|---|
| Kelverton Rail values | refused |
| Kelverton Rail interview process partnerships manager | refused |
| Kelverton Rail strategy scheduling software train operating companies news | refused |
| Deepa VP Partnerships Kelverton Rail | refused |
| Ross Commercial Director Kelverton Rail | refused |
| Senior Partnerships Manager Kelverton Rail job description | refused |

Research tier: L1 — searches 6 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Kelverton Rail values` | unavailable | Would have fed a values cheat sheet and settled whether a values-style round exists; neither is in this pack |
| 2. `Kelverton Rail interview process partnerships manager` | unavailable | Would have checked for documented rounds; the recruiter's email already fixes this session's shape, so persona weights rest on it |
| 3. `Kelverton Rail strategy scheduling software train operating companies news` | unavailable | Would have grounded the CO bank; A5 and E2 are generic as a result |
| 4. `Deepa VP Partnerships Kelverton Rail` and `Ross Commercial Director Kelverton Rail` | unavailable | Would have supplied an interviewer read and a reverse question tied to a career path; both are absent |
| 5. `Senior Partnerships Manager Kelverton Rail job description` | unavailable | Would have supplied requirements for the fit snapshot; F4 is inferred and the other rows rest on the recruiter's words |

## Upgrade menu

- The JD text → F4's inferred requirement becomes a quoted one, the fit snapshot gains a row per stated requirement, and JD-tagged questions are added for each
- Your CV → more of your own sentences to quote, so story-mapped guidance replaces the selection scaffolds in B3, G2 and E2
- The report's text, pasted in sections → a grounding brief, and a concrete consensus item and departure for the POV and for A5
- How Ross relates to the role, in your reporting line or a separate function → reweights banks C, D and G
- A surname or profile link for Deepa or Ross → an interviewer read and a reverse question tied to their path
- The recruiter's answer on what "operator partnerships" covers → a sharper A1 and a POV opening that no longer rests on an assumption
- In your own words, said outside a drill, how the £4M and the 6-to-40 were counted → C1, C2 and D2 become story-mapped instead of answer slots
- Search access → values, strategy and loop research, and the target rows above move from unavailable
- A tuesday-dossier.md from an earlier fit check → verified evidence and prohibited-claims constraints replace the locally built ones
