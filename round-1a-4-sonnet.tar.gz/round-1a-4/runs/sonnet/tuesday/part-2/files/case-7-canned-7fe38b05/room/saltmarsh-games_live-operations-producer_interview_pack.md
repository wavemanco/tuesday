# Interview pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi. **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Round:** the Outage Hour, a 60-minute session with the hiring manager that Saltmarsh's interviewing page describes as a live-incident tabletop on a simulated outage during a live event, then a values conversation. Built on the assumption that Tobias is your hiring manager; if he is not, the persona weights change.

## How to use this pack

Personas are how a question arrives. Types are what it scores. Guidance is scaffolding for a spoken answer, not a script; every claim about your own past in it is one of your own sentences, quoted, or an answer slot for you to fill truthfully.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows Saltmarsh's published values |
| EXP | Whether your own experience claims survive scrutiny |
| JD | A stated responsibility or requirement of the role, including its gaps |
| CO | Whether you know the company and its current strategy |
| CASE | A live problem, scored on structure and reasoning |

## Prep triage

Friday is close, so do these in order. Everything else in the pack is insurance.

| Order | What | Where |
|---|---|---|
| 1 | Say the tabletop answers out loud, twice, until the first thirty minutes of an incident come out in order | A1 to A4 |
| 2 | Rehearse the in-app purchase objection until it is boring: the plain acknowledgment, then the plan | C1, P1 |
| 3 | For each of the three values, pick your story or settle on the honest branch | B1 to B3 |
| 4 | Read the values page, the Project Larkspur post and the abstract of Tobias's GDC talk, then choose three reverse questions | Reverse questions |

## Fit snapshot

The posting states no gate (no authorization, location, schedule, pay or credential term), so no row is a hard gate. Years of experience is not a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one main title's weekly content drops, not events across two titles, and the words stay at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD's two-title line makes a probe on running more than one calendar likely. If you planned or ran more than one title's calendar, say how, in your own words; if you ran one, say so plainly and stay with it |
| F2 | "coordinate design, art, engineering and community teams on each update" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | low | [inferred] | discovery | The quote touches the requirement without showing which teams you worked with. Answer slot: the JD names four functions, so expect a probe on who was in each update. Say which of them you worked with and what you did with them, in your own words; if some were not part of your updates, say so plainly |
| F3 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | transferability | Your material says you presented retention numbers monthly, which is adjacent to reporting KPIs; it does not show a review after each drop or ownership of the KPIs. Words stay at the quote: "Presented the monthly retention numbers to the studio head." Answer slot: the JD's post-event review line makes a probe likely. If you ran or sat in a review after a drop, say what it covered, in your own words; if there was none, or it was not yours, say so plainly and stay with the monthly presentation |
| F4 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | No gap on the words, but nothing inspected stands behind them, so expect a probe on how the checklist is used. Lead in the quote's own terms: you wrote it, and your QA team still uses it |
| F5 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | discovery | The quote gives four years as an associate producer; the material does not say whether the game was run as a live service. Answer slot: the JD's live-service wording makes a probe likely. If your main title was live, say what that meant week to week, in your own words; if it was not, say so plainly and stay with the four years and the weekly drops |
| F6 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | No gap on the words, though a CV line alone has nothing inspected behind it. Lead with it in its own terms: weekly, one main title, two years |
| F7 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Reword only that sentence: you presented the monthly retention numbers to the studio head. It claims no more than the presenting |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The quote already reaches the requirement in other terms: a written document that another team still relies on. Reword only that sentence, and let the interviewer draw the inference |

## Reading the interviewer

Public professional footprint only. Both rows come from search results; I did not fetch the talk page.

| Observation | Source | Provenance | What it means for you |
|---|---|---|---|
| GDC 2026 talk "Patch Notes Are a Promise": a live team is judged by how often its patch notes describe what actually shipped | talks.gdconf.example, search result | [grounded] | Expect questions about what you announce and when. It lines up with Saltmarsh's second value, so one honest answer serves both A3 and B2 |
| Described as Head of Live Operations at Saltmarsh, previously a QA lead at a console studio | same search result | [grounded] | Release discipline is native vocabulary for him. Mirror opportunity, F4: "Wrote the release checklist our QA team still uses." — your message |

## Persona table

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | The tabletop: an outage mid-event, your first thirty minutes, what you tell players | Top, 5 questions. Saltmarsh's interviewing page puts a live-incident tabletop in the hour, and a hiring manager's prior favours this persona | Clarify before structuring, think aloud, challenge one premise respectfully |
| Values / Behavioral (bank B) | Scenario probes on the three published values | Top, 5 questions. The same page says the second half is a values conversation | Where one of your sentences carries a story, use it; where none does, say so and give the nearest thing your material carries |
| Skeptic (bank C) | Quiet probing of the gaps you named: no in-app purchase experience, no team led | Mid, 3 questions. Hiring managers derisk gaps, and you stated two | Rehearse the single most predictable objection until it is boring; plain acknowledgment, then a plan |
| Data-Driven Prober (bank D) | Retention numbers and the release checklist, line by line | Mid, 3 questions. The JD asks for retention comfort; nothing public says Tobias is analytics-led, so no upward adjustment | Say what you can and cannot say about how each number was counted |
| Conversational (bank E) | Opening "walk me through" and what you know about us | Low, 2 questions. It opens most hours, but a 60-minute session with a fixed format leaves little room | Treat casual questions as scored |
| Pressure (bank P) | Time-boxed "why you" and attribution challenges | Low, 2 questions. The page does not say the tabletop is timed, so this is a prior, not a finding | Hold through two follow-ups, then concede exactly and specifically |

## Question banks

### Bank A: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "It is day two of a live event. Players report the event reward is not granting and support tickets are climbing. Walk me through your first thirty minutes." | CASE | [inferred] | Clarify first: what is broken, for whom, whether it is getting worse. Then who you pull in (the JD's design, art, engineering and community, and QA), what you decide to pause or keep running, and what you record. The question needs no claim about your past, so the guidance makes none | Derived from the interviewing page's description of the tabletop, not from a real Saltmarsh scenario; CASE because it scores structure. Covers F2's requirement as a live problem |
| A2 | "Engineering says the fix is two hours away, the event ends tonight, and tomorrow's drop is on the calendar. What do you do with the calendar?" | CASE | [inferred] | State the trade-off aloud: what you protect, what you move, who you ask. Saltmarsh's first value says that when the calendar and the players disagree, the players win, so say which side of that you are choosing and why. No claim about your past | Tests the first published value through a live decision; F1 and F6 are the calendar rows it draws on |
| A3 | "What do you tell players, and when? What do you not say yet?" | JD | [inferred] | Say what is known, what is not, and when the next update comes. Saltmarsh's second value is that it announces what is built, not what is hoped, so the line between known and hoped is the answer. No claim about your past | JD because F8 asks for clear written communication; CASE delivery. Tobias's published talk makes this the likeliest topic to land |
| A4 | "After the incident, what goes in the post-event review, and which KPIs does it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Structure: what happened, when, how players were affected, what changes. Name the measures you would pull and why, before you read the results. If asked what you have reported before, your words: "Presented the monthly retention numbers to the studio head." Answer slot: if you ran or sat in a review after a drop, say what it covered; if not, say so plainly and stay with the monthly presentation | F3 is the evidence for the review requirement and its likeliest probe |
| A5 | "From February 2027 Project Larkspur puts two titles on one shared events calendar and one live-ops group. What would you want to know before you planned the first shared calendar?" | CO | [grounded] | Ask before you plan: how collisions between titles are decided, how season-pass cadence fits event cadence, who owns coordination across functions, what the shared KPIs are. Challenge one premise respectfully. Use only what the announcement says; if you have not read it, read it first | The one question tied to current strategy; read from a search result for Saltmarsh's own news post, not the page itself |

### Bank B: Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Selection scaffold: pick a time when the schedule and what players needed pulled apart; it needs a named stake, what you decided, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I ran the weekly content-drop calendar for our main title for the last two years." | Saltmarsh's first value, Players Before Plans; F6 is the nearest evidence, and no quote carries a disagreement |
| B2 | "Tell me about a time you had to announce less than people hoped for." | VAL | [generic] | Selection scaffold: pick a time you told people what was built, not what was hoped; it needs the gap between the two, the words you chose, and how it landed. If no such time comes to mind, say so plainly, then say how you would draw that line | Saltmarsh's second value, Ship the Patch Not the Promise; no quote carries this, so it is a scaffold |
| B3 | "Tell me about a time a release taught you something that changed the checklist." | VAL | [grounded] "Wrote the release checklist our QA team still uses." | The sentence carries two beats: you wrote the checklist, and QA still uses it; tell them in your own words. Answer slot: the third value speaks of leaving the checklist better after every release, so expect a probe on whether it changed after releases. If you revised it, say what prompted it and who was involved; if it stayed as written, or the changes were not yours, say so plainly and stay with the sentence | Saltmarsh's third value, Leave the Build Greener; F4 is the evidence |
| B4 | "Tell me about a time you got a team you did not manage to deliver something." | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | The JD asks you to coordinate four functions, so this is the nearest probe. Your own words on the limit: "I haven't led a team." Selection scaffold: pick a time you needed other people's work without any authority over it; it needs what you asked for, what got in the way, and what shipped. If no such time comes to mind, say so plainly, then say how you would do it | F2 is the row it draws on, and the stated negative is why the plain acknowledgment is sourced |
| B5 | "Tell me about a time you gave bad news about a number to someone senior." | VAL | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time a number was bad and the person needed to hear it; it needs what the number was, how you said it, and that the hard truth landed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "Presented the monthly retention numbers to the studio head." | A persona stem for the Values interviewer; F3 is the nearest evidence, and no quote shows a bad number |

### Bank C: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You have never worked on a game with in-app purchases. How would you get up to speed on that?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." and "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." | The highest-ROI rehearsal in this pack. Concede first, in your own words: "I haven't worked on a game with in-app purchases." Then the plan, said as a plan and never as a past: what you would ask to see first, who you would learn from, when you expect to be useful. Hold through two follow-ups by restating what you did: "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." Never describe any monetization work | The most predictable objection to this candidate, aimed at a limit you stated; JD because it scores a role gap |
| C2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pick one real gap and say it before they do. The snapshot shows candidates: F1 (your material says one title, the JD says two), F2 (which of four functions you worked with is not shown) and F3 (the review is not shown). Name the one that is true for you, then the ramp. Never say none | A stem from the Skeptic persona; covers F1, F2, F3 and F5 together |
| C3 | "You have been an associate producer for four years. Why this role, and why now?" | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." | Your words: "4 years as an associate producer at a puzzle-game studio." Then give your own actual reason for the move, in your own words; this pack does not supply one. Optionally name which of Saltmarsh's three values you would most want to work under, only if it is true | Motivation consistency under the Skeptic persona; F5 is the quote it rests on |

### Bank D: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through the retention numbers you presented." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Your words: "Presented the monthly retention numbers to the studio head." Answer slot: the JD asks for comfort with retention metrics, so expect a probe on which measures and how they were counted. If you chose or defined them, say how; if the figures came from an analyst or a dashboard someone else built, say so plainly and describe what you did with them in the monthly presentation. Name the assumption behind them you would defend least, or say you do not know how they were counted | F7 is the evidence; the weakest-assumption move converts a probe into credibility |
| D2 | "Tell me about a time a number in the retention review changed what the team did." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Selection scaffold: pick a time a figure changed a decision; it needs the number, the decision, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "Presented the monthly retention numbers to the studio head." | Retention comfort is a JD requirement; no quote carries a decision |
| D3 | "Walk me through how the release checklist you wrote gets used." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Your words: "Wrote the release checklist our QA team still uses." Answer slot: the JD's QA line makes a probe on running it with QA likely. If you ran it with QA on a release, say how that went; if QA ran it without you, or you did not attend, say so plainly and stay with the sentence | F4 is the evidence; the JD asks you to manage the checklist, and the quote says you wrote it |

### Bank E: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Walk me through a typical week of the calendar you ran." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Build a 90-second arc from your own sentences: "4 years as an associate producer at a puzzle-game studio." then "I ran the weekly content-drop calendar for our main title for the last two years." then "Wrote the release checklist our QA team still uses." Tell the week in your own words; the pack supplies no steps. Answer slot: if a step was yours to set, say which; if it was set for you, say so plainly | Covers F5 and F6 as a casual opener, still scored |
| E2 | "What do you know about us so far?" | CO | [grounded] | Say what you have read: the three values by name (Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener), and that Project Larkspur moves two titles to a season-pass model with one shared calendar from February 2027. If you have not read them, read them before Friday | Homework check from the careers and news pages in Sources |

### Bank P: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why you over someone who has run live events with in-app purchases?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." and "Never led a team, and never worked on a game with in-app purchases." | Pause, restate the question, hold on what the quotes carry: "I ran the weekly content-drop calendar for our main title for the last two years." and "Wrote the release checklist our QA team still uses." Concede exactly: "I haven't worked on a game with in-app purchases." Never fold the core claim to restore harmony, and never claim monetization knowledge | The pressure version of C1; hold-then-concede |
| P2 | "That calendar you ran. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD says plan and run, so expect a probe on who set content and timing. If you set either, say which; if it was decided elsewhere and you scheduled it, say so plainly, then return to the sentence. Hold through two follow-ups before conceding anything real | The attribution probe the pack exists to rehearse; F6 and F1 are the rows |

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| F1 Plan and run the calendar for two titles | C2, A2, P2 |
| F2 Coordinate design, art, engineering and community | B4, A1 |
| F3 Own the post-event review and KPIs | A4, D2 |
| F4 Manage the release checklist with QA | D3, B3 |
| F5 3+ years live-service | E1, C2, C3 |
| F6 Running a content calendar | E1, P2, A2 |
| F7 Player-retention metrics | D1, D2, A4 |
| F8 Clear written communication | A3 |
| Your stated limits (no team led, no in-app purchases) | C1, P1, B4 |

## Values cheat sheet

Detected: Saltmarsh's interviewing page says the Outage Hour includes a values conversation. Values are named exactly as the values page gives them.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | F6 holds the nearest sentence: "I ran the weekly content-drop calendar for our main title for the last two years." No quote carries a disagreement. Pick a time the schedule and the players pulled apart; if none comes to mind, say so plainly and give that sentence |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | No quote carries this. Pick a time you announced only what existed; if none comes to mind, say so plainly, then give the nearest thing: F4, "Wrote the release checklist our QA team still uses." |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4: "Wrote the release checklist our QA team still uses." Whether it changed after releases is B3's answer slot |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Your GDC talk argues that patch notes are a promise. What does a patch note that kept the promise look like on your team, and what does a miss look like?" | Tied to the interviewer's own published work; shows you read him, not just the company |
| 2 | "You came to live ops from a QA lead role. What did that change about how you run a release?" | Tied to his path as the search result gives it; opens the checklist conversation, where F4 is your strongest row |
| 3 | "Project Larkspur retires per-title event teams in favour of one live-ops group. How does that change what this role owns in the first months?" | The JD describes two titles' calendars; the news describes a shared one. Asking shows you noticed |
| 4 | "What does a good first ninety days look like for someone who has not run a monetized live event before?" | Turns your stated gap into a ramp conversation, on your terms |
| 5 | "Which KPIs does the post-event review report today, and which one do you wish got more attention?" | The JD makes the review and its KPIs yours; shows ownership thinking |
| 6 | "When the calendar and a team's capacity disagree, how do you want that raised?" | Echoes the first value and F2's coordination work without claiming experience |

## Prohibited claims

Built before the banks and binding on every cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Has led a team | A negative you stated: "Never led a team" | "I haven't led a team." No slot |
| Has worked on in-app purchases or monetization | A negative you stated: "never worked on a game with in-app purchases" | "I haven't worked on a game with in-app purchases." Then the plan, as a plan |
| Planned and ran events for two titles | Inflated form of F1 | The quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is this pack's observation: the material says one main title |
| Owned the post-event review and its KPIs | Inflated form of F3 | The quote at its own scope: "Presented the monthly retention numbers to the studio head." The limit is this pack's observation: the material says presenting, not owning |

## Sources

Provided documents: the JD and your message.

Research tier: L1 — searches 4 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet and B1 to B3: three values by official name, from the fetched page |
| 2. Saltmarsh Games interview process | yes | Loop structure: one 60-minute session, a tabletop then a values conversation, no take-home; persona weights and the absence of a deliverables section follow |
| 3. Saltmarsh Games strategy / news | yes | A5, E2 and reverse question 3, from the search result for the Project Larkspur post; the page itself was not fetched, because both fetches went to targets 1 and 2 |
| 4. Interviewer name and company | yes | Reading the interviewer, A3 and reverse questions 1 and 2, from search results; the talk page was not fetched |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and JD-tagged questions |

Queries and what came back:

- "Saltmarsh Games values": https://saltmarshgames.com/values (fetched)
- "Saltmarsh Games interview process live operations producer": https://saltmarshgames.com/careers/interviewing (fetched)
- "Saltmarsh Games strategy news": https://saltmarshgames.com/news/project-larkspur
- "Tobias Wrenfield Saltmarsh Games": https://talks.gdconf.example/2026/patch-notes-are-a-promise

## Upgrade menu

- The recruiter's notes on the Outage Hour (incident type, whether the tabletop is timed) → a sharper bank A and a grounded Pressure weight
- Your answers to the answer slots in F1, F2, F3 and F5 → rows move from discovery or transferability toward grounded stories, and the guidance gets your own beats
- Whether Tobias is your direct manager → persona weights confirmed or reweighted
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → a strategy brief on Project Larkspur and Tobias's talk content, and a grounding section
- A tuesday-dossier.md from an earlier role check → sharper weak-area strategy, if you have one
