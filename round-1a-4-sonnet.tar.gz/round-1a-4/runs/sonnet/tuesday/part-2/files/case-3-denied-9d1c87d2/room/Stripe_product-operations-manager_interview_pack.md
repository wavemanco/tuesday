# Interview pack: Product Operations Manager, Stripe

Final round. Interviewer names and relationships unknown. Built on the assumption that the final is one or more conversations in mixed styles; persona weights are flat-to-blended, not read from a documented loop.

## How to use this pack

Personas describe how a question arrives; types describe what is scored. Guidance is scaffolding, not a script: every row below is a selection scaffold or a live problem, because no CV, JD or company research was available. Nothing in this pack states a fact about your past or about the company.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the company's published values |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and attribution |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Homework depth and thinking at the company's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

## Fit snapshot

This is the worksheet variant: no CV and no JD were supplied, so every evidence cell reads none given and each requirement is written as plain role-family prose, not quoted. Strong evidence for a product operations role is usually an artifact you can show or describe: a launch plan or readiness checklist, an operating-review deck, a metrics dashboard, a process document.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Coordinates cross-functional product launches and readiness (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a launch you coordinated, with the teams involved and the decision points. Selection scaffold: pick a launch or release that needed several teams to converge, with a named stake, a decision you or others made, and a result. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F2 | Designs and runs operating cadences and processes (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a recurring process you set up or changed, and what it replaced. Selection scaffold: pick a process or meeting rhythm you built or reshaped, with what it was meant to fix and whether it held. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F3 | Uses data and metrics to find problems and track outcomes (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a figure you can explain end to end. Selection scaffold: pick one figure from your work and be ready to say how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If no such figure comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F4 | Influences and communicates across teams and senior stakeholders without formal authority (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a disagreement resolved without line authority, including how you handled the people involved. Selection scaffold: pick a time you moved a group that did not report to you, with the stake, what you said, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F5 | Understands the product, its customers and the business it sits in (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is something you can say about the product and its customers that you verified yourself before the interview. Selection scaffold: pick what you have actually read or used and say only that. If you have not looked at it, say so plainly, then say what you would check first |
| F6 | Motivation fit and honest self-assessment of gaps (role-family pattern, no source) | none given | none | [generic] | discovery | Strong evidence is a consistent account of why this role and why now, plus an unforced view of your weakest area. Selection scaffold: pick the area where you have the least to show, and prepare to name it plainly. If no weak area comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it |
| F7 | Location, work-authorization and start-date terms of the posting (posting unseen) | none given | none | [generic] | hard_gate | Your material does not establish it |

## Persona table

No loop source establishes this company's rounds, so weights rest on a fallback pattern (Generic: flat weights), tilted by what a final round with an unknown interviewer most often means. If you know who you are meeting, tell me and every bank reweights.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy (a rehearsal method, not a claim) |
|---|---|---|---|
| Case/Strategist (bank A, 4 questions) | Live problems from the role: plan this, diagnose that | High. The role is judgement-and-process work, and a hiring-manager or skip-level session leans here; unknown relationship, so blended | Clarify, objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Skeptic (bank B, 4 questions) | Quiet probing of gaps, motivation and weakest area | High. Final rounds derisk; without a CV the gap itself is unknown, so the rehearsal is the generic weakest-area question | Rehearse the most predictable objection until it is boring; calibrated candor over bluffing |
| Peer Evaluator (bank C, 3 questions) | Seam-splitting between teams, collaboration, credit | Medium. A product operations hire works across teams, and a cross-functional or peer session is plausible; relationship unknown | Reciprocity framing; propose seam principles, not a claimed seam; disagreement with spine and tact |
| Data-Driven Prober (bank D, 3 questions) | Metrics probed to their assumptions | Medium. The role's work is measured; no CV figures exist yet to probe | Know how any figure was counted; say plainly when you do not know; name the weakest assumption first |
| Values/Behavioral (bank E, 2 questions) | Scenario probes against published values | Lower. No published values were read and no values-style round is established, so this bank is thin and uses persona stems only | Story per value once values are in hand; "we" for context, "I" for contribution |
| Pressure (bank F, 2 questions) | Interrupts, time-boxes, tests composure | Lower. Possible in a skip-level session, with nothing here that raises it | Pause, restate, hold a position through two follow-ups before conceding anything real |
| Conversational (bank G, 2 questions) | Friendly, unstructured, still scored | Medium. Openers like the biography question arrive in almost any final | A 90-second arc built from your own CV; treat casual questions as scored |

## Question banks

Every row is labelled `[generic]`: either a live problem that makes no claim about your past, or an open prompt whose guidance is a selection scaffold. Open-prompt themes come from the persona stems, not from a JD I have not seen. The most predictable objection for you cannot be named without your CV; B1 is the provisional highest-ROI rehearsal until it can.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A product launch is two weeks out and three teams disagree on whether it is ready. What do you need to know first, and what do you do?" | CASE | [generic] | Clarify first: what ready means, who decides, what is reversible. Then objective, a way to separate the disagreements, an approach, the metric that tells you it is safe, the risk you would flag. Say your structure aloud. The question needs no claim about your past, so the guidance makes none | F1 is the launch-coordination requirement; CASE because it is asked as a live problem |
| A2 | "A key metric for an existing product dropped 20 percent last week. Diagnose it." | CASE | [generic] | Clarify the definition and the time window, split the metric into its parts, check for data and instrumentation causes before product causes, then rank hypotheses and name the first check. Makes no claim about your past | F3 is the data-and-metrics requirement; this is the standard diagnosis shape for the role |
| A3 | "Design the operating rhythm for a product organisation that ships often and wants fewer ad hoc status meetings. What do you build and what do you remove?" | CASE | [generic] | State the problem the rhythm solves, who needs which information and how often, what you would remove first, and how you would tell in a month whether it worked. Makes no claim about your past | F2 is the process-design requirement; CASE because it asks for a design, not a history |
| A4 | "Where could product operations create the most value in a company that builds products for businesses, and how would you test that?" | CO | [generic] | Offer a hypothesis in your own words, say which parts rest on sources you read before the interview and which are your guess, and name the first thing you would ask the team. If you have not read up yet, say so plainly and say what you would look at first | F5 is the product-and-business requirement; CO because it asks for altitude, and it stays generic because no company research ran |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | The highest-ROI rehearsal in this pack until your CV shows a real gap. Name the area plainly in your own words, then a ramp plan stated as a plan, never as a past. If no weak area comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it. Hold through two follow-ups by returning to the plan | F6 is where this lands; JD because it scores the stated role including its gaps |
| B2 | "Why this company, why this role, why now?" | JD | [generic] | Give two or three reasons in your own words and keep them consistent with what you told earlier rounds. State a fact about the company only if you have read it from a source yourself. If a reason is thin, say so plainly instead of dressing it | F6; motivation consistency is scored in nearly every final, so it is JD-tagged as a role-fit question |
| B3 | "Tell me about the part of this role that is furthest from your own background, and how you would handle it." | JD | [generic] | Selection scaffold: choose the requirement where your material is thinnest, say plainly that it is, and give the nearest thing you actually have, or a concrete plan to learn it. If nothing is adjacent, say that and go to the plan | F6; same objection as B1 rehearsed from the other side, so a second answer exists |
| B4 | "You have capacity for one of three requests from three senior stakeholders, all marked urgent. How do you choose, and what do you say to the two you decline?" | CASE | [generic] | Clarify what is truly urgent and who owns the trade-off, state your criteria, say who you would take the decision to, and script the decline in a sentence that keeps the relationship. Makes no claim about your past | F4 is the influence-without-authority requirement; CASE because it is a live prioritisation problem |

### C. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | CASE | [generic] | Propose seam principles instead of pretending to know the seam: who owns the decision, who owns the follow-through, how a disagreement is escalated and recorded. Ask what the seam looks like today. Makes no claim about your past | F4; CASE because it is a live collaboration scenario |
| C2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold: pick a piece of shared work where credit was a live question, say what you did to make others' contribution visible, and what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4; VAL because it tests behaviour toward peers |
| C3 | "What would you need from my team in your first month, and what would you bring to it?" | JD | [generic] | Reciprocity framing: lead with what you would take off their plate or make clearer, then what you need. Keep both in terms you can stand behind; do not promise outcomes | F4 and F1; JD because it asks for the working relationship the role implies |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Pick one figure you would cite about your work. How was it counted, and which assumption behind it would you defend least?" | EXP | [generic] | Choose a figure you can actually explain. Cover how it was counted, what it is sensitive to, the assumption you would defend least, and exactly which part was yours, in your own words. If you do not know how it was counted, say so plainly. Do not supply a method you cannot repeat under a second question | F3; EXP because it tests attribution honesty, and the guidance supplies no figure |
| D2 | "If you had to pick one metric that tells you a launch went well, which would it be and what would it miss?" | CASE | [generic] | State the metric, what it measures, what it hides, and the second signal you would pair with it. Makes no claim about your past | F3; CASE because it is a live metric-design problem |
| D3 | "Two teams report different numbers for the same metric on a weekly dashboard. What do you do?" | CASE | [generic] | Establish the definitions and the source of each number, find where they diverge, agree one owner for the definition, and decide how the change is communicated. Makes no claim about your past | F2 and F3; CASE because it is a live process-and-data problem |

### E. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time with a named stake, a moment you did not soften the message, and a relationship that held at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4; VAL from the persona stem, because no company values were read |
| E2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a decision where the two pulled apart, say what you weighed and what you chose. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F5; VAL from the persona stem |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over an internal candidate?" | JD | [generic] | Pause, restate, then say what you bring in your own words and nothing you cannot defend. Hold through two follow-ups; concede explicitly what you do not know about the team, and never fold on the core claim to restore harmony | F6; JD because it scores the case for the role |
| F2 | "Pick a result you would claim. How much of it was actually you?" | EXP | [generic] | Say precisely which part was yours and which was the team's, using we for context and I for contribution. Hold your position through two follow-ups, concede uncertainty specifically, and do not enlarge your part to restore harmony | F3; EXP because attribution is what the question scores |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [generic] | Prepare a 90-second arc from your own CV: where you started, the one or two moves that led here, and why this role is the next one. Only facts from your own CV | F6; EXP because it opens the biography and is scored |
| G2 | "What have you been experimenting with lately in how teams ship and coordinate work?" | JD | [generic] | Name something real you tried, what you saw, and what you would do differently. If you have not tried anything lately, say so plainly and name what you would try first | F2; casual-register questions on a role's core theme are still scored |

## Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Cross-functional launches | A1, B4, C3 |
| F2 Operating cadences and processes | A3, D3, G2 |
| F3 Data and metrics | A2, D1, D2, D3, F2 |
| F4 Influence without authority | B4, C1, C2, C3, E1 |
| F5 Product, customers, business | A4, E2 |
| F6 Motivation and self-assessment | B1, B2, B3, F1, G1 |
| F7 Location, authorization, start terms | none, and why: it is a term you meet or do not, not a rehearsal item; the one question about it is asked in the message |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first ninety days look like in this role, and how would you tell?" | Shows you think in outcomes and gives you the success measure to hold the role to |
| R2 | "Where does product operations sit relative to product, engineering and the teams that launch with them, and where does that boundary strain?" | Asks for the seam instead of assuming it, which is the stance peer-style interviewers reward |
| R3 | "What is the recurring friction in how launches or releases get done today that this role is meant to ease?" | Shows diligence about the real job and tells you whether the role has a clear problem |
| R4 | "When teams disagree on a decision, how does it get settled, and what part does this role play?" | Surfaces decision rights, which any hire into a coordination role needs to know before accepting |
| R5 | "What distinguishes the people who do this job best here from the ones who struggle?" | Invites a concrete picture instead of a generic answer and tells you what the team will measure you on |
| R6 | "What changed in the team or the role over the last year, and what is still open?" | Signals you are checking fit both ways and surfaces risks you would want to know before accepting |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| No entry | No candidate sentences were supplied, so there is no stretched wording to list | Every story row is a selection scaffold ending in its honest branch; the pack asserts nothing about your past, and any claim you add should be one you can repeat under a second question |

## Sources

Provided documents: your message only (company, role, and that this is a final round). No JD, CV, interviewer profile or dossier was present.

Searches sent, all refused by the host: `Stripe operating principles values stripe.com jobs culture` (refused); `Stripe interview process product operations manager final round` (refused); `Stripe strategy 2026 stablecoins agentic commerce annual letter` (refused); `Stripe "Product Operations Manager" job description responsibilities requirements` (refused). Nothing returned, so nothing from outside your message is used, and no fact about the company's values, loop or strategy appears anywhere in this pack.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Every call was refused. Would have fed a values cheat sheet with the official value names; the sheet is dropped |
| 2. `Stripe interview process product operations` | unavailable | Every call was refused. Would have fixed loop structure and persona weights; weights fall back to the Generic archetype, said above |
| 3. `Stripe strategy` / recent news | unavailable | Every call was refused. Would have grounded the CO and CASE questions in current priorities; A4 stays generic |
| 4. `{interviewer name} Stripe` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Operations Manager` JD | unavailable | Every call was refused. Would have supplied inferred requirement rows; requirements stay unquoted role-family prose |

## Upgrade menu

- The JD text → requirement rows become quoted, JD-tagged questions move from generic to grounded, and the coverage table is keyed to the real list
- Your CV, or a few lines of it → selection scaffolds become story-mapped guidance, the fit snapshot's evidence cells fill in, the most predictable objection is named from your actual gaps, and the prohibited list is built from your real wording; a launch plan, an operating-review deck or a metrics dashboard would be the strongest proof to mention
- Who you meet and how they relate to the role (future manager, peer, skip-level, cross-functional), plus any recruiter note on focus areas or a deliverable → persona weights recomputed, an interviewer read from their public professional footprint, a tailored reverse question, and a build section for any declared presentation or take-home
- Stripe's published values page, loop notes or a strategy brief, pasted → a values cheat sheet, CO and CASE questions grounded in current strategy, and loop-based persona weights, since search was not available in this session
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes, run only if you ask
- If your final is several back-to-back sessions, the schedule → per-session mini-packs with their own persona weights
- A tuesday-dossier.md from earlier work on this role → verified evidence, per-gap strategy constraints and a named objection, in place of what this pack infers
