# Interview pack: Product Manager, Platform APIs at Quartzline

Hiring-manager round, 45 minutes, Thursday. Interviewer: the hiring manager, name not given. Built from your dossier (conditional_go) with no outside research, because the searches were refused.

## How to use this pack

- Personas are how a question arrives. Types are what is being scored.
- Types: VAL is behavioral and values alignment. EXP is a work-experience deep-dive. JD is role and requirement driven. CO is company and strategy knowledge. CASE is a live problem.
- Guidance is scaffolding, not a script. Where a row says "answer slot", it is an instruction for the interview: answer from your own experience, or say plainly that the practice was not yours.
- The three sentences this pack builds on are the only claims it makes about your past. They come from your dossier's verified evidence, quoted word for word in the fit snapshot.
- Every dossier-sourced claim comes from the underwriter's handoff. Your positioning is the underwriter's: adjacent, never PM experience.

## Prep triage

Sized to the two days before Thursday. Do these in order, out loud, not in your head.

| Order | Do | Where |
|---|---|---|
| 1 | Say the answer to the named objection five times, then take the three follow-ups. This is the highest-ROI prep in the pack: the underwriter named this objection from evidence you confirmed | A1, then E1 which has the same bones in sixty seconds |
| 2 | Say your day-one weakness once, plainly, with the plan. Then find what you can actually point to from the roadmap-input sessions, because that entry is confirmed with limited inspectable proof and will be probed | A2, A3, E2 |
| 3 | Settle your own answers to the three open slots a must-have or an important requirement raises: a released API or platform product, agile delivery, API docs or schemas | A4, A5, D3 |
| 4 | Say the 30+ number and its counting out loud, and run your 90-second arc | C1, D1 |
| 5 | Talk two cases aloud: prioritizing across two squads, and a flat-adoption diagnosis | B3, B2 |
| 6 | Choose your top three reverse questions | Reverse questions 1, 2 and 5 |

Everything else is insurance.

## Fit snapshot

Requirement text is quoted from the dossier's role_profile. Evidence is quoted from the dossier's handoff, and the confidence notes the underwriter appended are carried in the Confidence column and the bridge, not in the quote. The dossier carries no evidence_map, so rows F2, F3 and F8 are graded here from the quotes and labeled `[inferred]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier role_profile (R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff | low | [grounded] | transferability | The underwriter's strategy is bridge, and the limit stays attached: your material shows integration leadership and feeding client evidence to product, and does not show a product manager role. Words at the quotes' own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Plain acknowledgment, sourced to dossier field prohibited_claims: "I haven't held a product manager title or role." Never offered as PM experience |
| F2 | "Shipped API or platform products" — dossier role_profile (R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff | low | [inferred] | transferability | The quote shows integrations of the vendor's REST APIs, not a released API or platform product, and the dossier does not list R2 among its weak areas, so this grade is the pack's. Words stay at the quote. Answer slot: R2 is a must-have, so a probe on what you released is likely. If you worked on an API or platform product that reached release, say what it was and which part was yours; if the work was the integrations and no release was yours, say so plainly and stay with them |
| F3 | "Technical fluency: API docs, schemas" — dossier role_profile (R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff; "Wrote the internal integration playbook her team uses" — dossier handoff | low | [inferred] | discovery | The quotes show architecture work on REST API integrations and a written playbook; they do not show whether you read, wrote or reviewed API docs or schemas. Answer slot: R3 names docs and schemas, so expect a probe. If you worked with either in that work, say which and what part was yours; if not, or if it was someone else's, say so plainly and stay with the integrations and the playbook |
| F4 | "Stakeholder management across engineering, sales, customers" — dossier role_profile (R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff | medium | [grounded] | discovery | The quotes reach clients and product; they do not show engineering or sales as stakeholders. The sessions entry is confirmed with limited inspectable proof, so volunteer that limit before it is probed. Answer slot: R4 lists engineering, sales and customers, so expect a probe on each. For engineering and sales, say whom you worked with and on what, in your own words; if one side was not part of that work, say so plainly and stay with the clients and product |
| F5 | "Agile delivery experience" — dossier role_profile (R5, preferred) | none given | low | [grounded] | discovery | The underwriter's strategy is clarify, and no verified entry speaks to agile delivery, so nothing is quoted. Answer slot: the requirement's own wording is the probe. If you have worked in sprints or a similar cadence, say how it ran and what part was yours; if you never worked that way, say so plainly, then say what you would want to confirm about how these two squads define it |
| F6 | "Own the roadmap for the partner-facing API platform" — dossier role_profile (responsibility) | none given | none | [grounded] | capability | The underwriter's strategy is acknowledge_gap, so no bridge is built, and the sessions entry is not used as one here. Words, sourced to dossier fields acknowledge_gap and prohibited_claims: "I haven't owned a product roadmap." Then a ramp plan, said as a plan and never as a past: "In my first weeks I'd learn how roadmap and prioritization calls get made on this platform and which of them are the squad leads' to make." Nothing added to make the gap feel smaller |
| F7 | "Run discovery with integration partners" — dossier role_profile (responsibility) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier handoff | medium | [grounded] | transferability | Confirmed with limited inspectable proof, so expect a probe and volunteer the limit. The quote says clients, not partners, and the words keep your word: "I ran quarterly roadmap-input sessions that fed client evidence to product." Answer slot: expect a probe on how the evidence was gathered. If you asked clients about their use, needs or problems, say what and how; if there was no such step, or it was not yours, say so plainly and stay with running the sessions |
| F8 | "Write specs and drive delivery with two engineering squads" — dossier role_profile (responsibility) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier handoff; "Wrote the internal integration playbook her team uses" — dossier handoff | low | [inferred] | transferability | The quotes show requirements as a stage of the integrations and a written playbook; they do not show specs that squads built from, and a playbook is a different document. Answer slot: if engineers built from anything you wrote, say what it was and what they built; if there was no such document, or it was not yours, say so plainly and stay with the playbook |
| F9 | "Define and track adoption metrics" — dossier role_profile (responsibility) | none given | none | [grounded] | discovery | Nothing in your verified material speaks to a measure of use. Answer slot: if you tracked how the integrations or the playbook were used, say what was counted and by whom; if you did not, say so plainly, and say what baseline you would ask for first |

## Persona table

| Persona | How it shows up here | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | A quiet, persistent probe of the PM-title and roadmap gap, the one the underwriter named | Highest, 5 questions. The hiring-manager prior is Case and Skeptic; the Skeptic leads because the underwriter named your objection and R1 is a must-have graded low | Rehearse the one objection until it is boring; concede the limit before it is asked; the bridge uses only the quoted sentences |
| Case/Strategist | Live problems from the platform: partner friction, flat adoption, two squads and one quarter | Highest, 5 questions. Hiring-manager prior; the JD's responsibilities give the cases | Clarify, then objective, segmentation, approach, metrics, risks; think aloud; challenge one premise respectfully |
| Data-Driven Prober | Reads your lines for the number, the playbook and any measure of use | Medium, 3 questions. The 30+ figure is a headline number, and the JD names adoption metrics | Know what you can and cannot say about how the figure was counted; name the weakest assumption first; say plainly when you do not know |
| Conversational | The opener and the casual "why us" | Medium, 3 questions. The opening question is always asked, in a friendly register that is still scored | A 90-second arc built only from your three quoted sentences; treat casual questions as scored |
| Pressure | Time-boxed "why you over a PM with three years" | Low, 2 questions. Nothing signals a stress style, but the same objection can arrive that way | Pause, restate, hold the quoted claim through two follow-ups, concede the limit specifically |
| Peer Evaluator | The seam with the two squad leads, in the manager's words | Low, 2 questions. The squad leads are not in this round, but the JD's squads line makes the seam a likely collaboration probe | Offer seam principles, not a pretend seam; reciprocity |

## Question banks

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product". The two negatives in the question are sourced to dossier prohibited_claims "Having held a product manager title or role" and "Having owned a product roadmap", and to dossier acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" | The deepest rehearsal in the pack; the underwriter named this objection. Concede first, hold only the quotes, name the limit before it is asked. Say: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then: "I led 30+ end-to-end client integrations of the vendor's REST APIs, and I ran quarterly roadmap-input sessions feeding client evidence to product." Volunteer that the sessions are confirmed with limited inspectable proof. Answer slot: if any input from those sessions changed something product did, say what and what part was yours; if none did, or you cannot say, say so plainly and stay with running the sessions. Close on a plan, not a past: "In my first weeks I'd learn how roadmap and prioritization calls get made here and which are the squad leads'." Follow-up one, "What is different about day one for you?": the plan. Follow-up two, "Three years is a must-have, how do you square that?": do not argue the three years; say you are not claiming them, restate what you offer and its limit. Follow-up three, "What would make you wrong for this role?": the limit, roadmap ownership and prioritization you have not done, then ask which decisions the PM makes alone (reverse question 1). Describe what you did and let them draw the inference; do not tell them it proves PM readiness | F1 and F6 are where the must-have presses hardest, and the dossier named it, so it is not inferred; JD because it scores a stated requirement, Skeptic because it arrives as quiet derisking |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] dossier acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" | The honest answer is the one the underwriter recorded. Say it once, plainly: "I haven't owned a product roadmap or set prioritization for an engineering squad," sourced to dossier prohibited_claims. Then the plan as a plan: what you would learn first and from whom, the squad leads and how adoption is measured today. Do not add a second weakness to look balanced, and do not soften this one with a bridge | F6; a persona stem, JD because the answer is tested against the listed responsibilities |
| A3 | "Walk me through one of your quarterly roadmap-input sessions — what did you bring, and what happened to it afterwards?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | The beats are the quote's: the sessions were quarterly, you ran them, what you brought was client evidence, and it went to product. Tell those in your own words. This entry is confirmed with limited inspectable proof, so say plainly what you can point to from them and what you cannot. Answer slot on "what happened afterwards": if a piece of that evidence changed something product did, say what and what part was yours; if you do not know what happened to it, or nothing did, say so plainly and stay with what you brought. Anything written after a session, such as an agenda, notes or a product item that cites it, is the inspectable thing that would raise this entry; check what you are allowed to share first | F7; EXP because it tests what was actually yours, and a prober will find this seam |
| A4 | "Tell me about a time you took an API or platform product through to release." | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | R2 is a must-have, so this is likely. Selection scaffold: pick an instance where an API or platform product you worked on reached release, naming what it was and the part that was yours. Answer slot: if there is one, tell it in your own words at its true size; if no such time comes to mind, say so plainly, then give the nearest thing your quote carries at its own scope, "I led 30+ end-to-end client integrations of the vendor's REST APIs," as integration work and not as a release | F2; the open prompt asks you to choose an instance, so the pack supplies none |
| A5 | "The role calls for agile delivery experience. Tell me about a time you worked that way." | JD | [grounded] | The underwriter's strategy for this area is clarify, and no verified entry speaks to it, so nothing about your past is written here. Answer slot: "Agile delivery experience" is the probe, so expect "what has that meant for you". If you have worked in sprints or a similar cadence, say how it ran and what part was yours; if you never worked that way, say so plainly, then say what you would want to confirm about how these squads define it. The question back is the strength of this answer | F5; JD because R5 is a stated preference, asked here as the Skeptic's probe of a gap |

### B. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Partners tell you the API is hard to integrate with. What do you do in your first two weeks?" | CASE | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify first: which partners, which stage, what "hard" means, what data exists. Then objective, segmentation, approach, metrics, risks. The stages in your own quote, scoping, requirements, architecture, UAT and go-live, are a ready lens for segmenting where partners get stuck; use them as a lens, not as a claim about where partners did get stuck. Challenge one premise respectfully: whether "hard" is a docs, auth or support problem | F7; CASE because it is a live problem from the discovery line |
| B2 | "Adoption of a new partner endpoint is flat after a quarter. Diagnose it." | CASE | [generic] | Ask before you structure: how adoption is defined and measured, the baseline, which partners were targeted, the activation steps. Then segment partners by where they stopped, form hypotheses (discoverability, docs, fit, partner priorities), say what you would measure and what could mislead you. Say aloud that you do not know how Quartzline measures adoption today, which is reverse question 2. The question needs no claim about your past, so the guidance makes none | F9; CASE on a JD responsibility; `[generic]` because it is a pattern for the problem, not a fact about Quartzline |
| B3 | "Two squads, one quarter: a large partner wants a custom endpoint, the docs need an overhaul, and an old version needs deprecating. How do you decide, and who decides?" | CASE | [generic] | Say the criteria aloud: partner impact, cost, risk, reversibility, the evidence you would want. Give a recommendation with a confidence level and what would change your mind. Then the decision-rights step: you would bring the recommendation and the evidence to the squad leads and ask where the call sits. Treat it as a proposal and not a description of something you have done, because prioritization is a recorded gap | F6; CASE with a JD-driven edge, Skeptic-adjacent because "who decides" tests the gap |
| B4 | "A partner asks for a breaking change to a schema three other partners depend on. Walk me through it." | CASE | [generic] | Clarify urgency, severity, who depends on it, the versioning policy and any contract terms. Offer options, communicate to each party, say what you would measure, name the risks. If you have not handled versioning before, reason from first principles aloud and say so; this question rehearses R3 without asserting it | F3; CASE because R3 is probed by a problem, not a claim |
| B5 | "Sketch what you would put in a spec for a new webhook feature for partners, and what you would want from the engineers first." | CASE | [grounded] "Wrote the internal integration playbook her team uses" | Partner evidence and the problem first, then scope and non-goals, the contract and error behavior, rollout and versioning, success measures, open questions. Ask the engineers about constraints and feasibility before you commit to scope. Your quote says you wrote a playbook; a spec is a different document, so do not present one as the other | F8; CASE |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You led 30+ integrations. How was that number counted?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what the figure counts as the quote has it: integrations, with the plus kept, not clients or projects. Answer slots, each in your own words: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part of each integration was yours. If you do not know how it was counted, say so plainly. Name the weakest assumption before they do. "Led" stays "led" | F1 and F8; every headline number gets a defend-the-number question |
| C2 | "What did a successful go-live look like on those integrations, and how did you know?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Go-live is the last stage your quote names. Answer slot: "how did you know" raises measures. If you tracked any outcome after go-live, say what was counted and by whom; if you did not, say so plainly, and say what you would measure first | F9; EXP, with the adoption-metrics line as its raising source |
| C3 | "You wrote the integration playbook. How do you know your team uses it?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" | The beat is the quote's: "I wrote the internal integration playbook my team uses." Answer slot: if you have any sign of its use, say what and from whom; if you know only that it is used, say so plainly. The dossier records the playbook as inspectable; check what you are allowed to share, and be ready to describe it if you cannot show it | F3 and F9; the playbook is the one entry with an artifact behind it, so it is where a prober goes next |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | A 90-second arc with exactly three beats, each a quoted sentence: the integrations from scoping to go-live, the playbook, the sessions. Then why product, why now: answer slot, in your own words, since no reason of yours is on record and none is written here. Say it as a direction and not as a step up | F1; the opener is always asked and the casual register is still scored |
| D2 | "Why Quartzline, and why this role now?" | CO | [generic] | Only your own reasons. This pack holds no verified Quartzline facts, because research was refused, so it supplies none. Selection scaffold: two reasons you can back with something you have read or done, one about the platform and one about the work. If you have only the posting so far, say that, and use its own words: "Own the roadmap for the partner-facing API platform". Read their site and docs yourself before Thursday | F1; CO and `[generic]` for lack of research |
| D3 | "What are you actually playing with in API design or developer docs these days?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: R3 names API docs and schemas. If you read, write or review either in your own work, say what and how recently; if your work is the integrations and not docs or schemas, say so plainly and name what you would read first | F3; a casual question about a JD plus-skill, still scored |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over a PM who has done this job for three years?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product". Acknowledgment sourced to dossier prohibited_claims "Having held a product manager title or role" | Pause, restate the question, then take the time-box. Concede first: "I haven't held a product manager title or role." Hold the two quotes. If they push "that is not PM work", agree it is adjacent and not PM work, and return to what you did. Hold through two follow-ups; never fold on what the quotes carry, and never reach for more than they say. You are not claiming to be better, only to be a credible adjacent hire with a named limit | F1; the same objection as A1, in a time-boxed register |
| E2 | "How much of that roadmap-input work was actually you?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | "Ran" is the quote's verb; hold it as it stands. Answer slot: if others ran or joined the sessions, say who and what each did; if it was all yours, say so; if any part was not yours, say so plainly. Hold through two follow-ups by returning to the quote, not by adding to it, and concede specifically what you cannot show | F7; the attribution probe a pressure interviewer adds to a medium-confidence entry |

### F. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where is the seam between this PM and the two squad leads, and what happens when you disagree about priority?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product". Acknowledgment sourced to dossier acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" | Offer seam principles, not a pretend seam: who has the evidence, who carries the cost, who is accountable for the outcome, and that decisions are recorded. Reciprocity: what you bring the squad leads is client evidence, as your quote has it, "I ran quarterly roadmap-input sessions feeding client evidence to product." Then ask where the line sits today, which is reverse question 1. Do not describe a past disagreement you have not given | F6 and F8; JD because the JD asserts the squads line and the dossier records it as unevidenced |
| F2 | "Tell me about a time a salesperson and an engineering team wanted different things from the same client integration. What did you do?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Selection scaffold from R4: pick a time where sales and engineering pulled differently on a client integration; it needs a named stake, what you did, what you gave up, and a relationship intact at the end. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, the integrations at the quote's own scope, or how you would handle it | F4; JD because R4 lists engineering and sales |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1 "3+ years product management experience" | A1, A2, A3, E1, E2 |
| R2 "Shipped API or platform products" | A4 |
| R3 "Technical fluency: API docs, schemas" | B4, D3 |
| R4 "Stakeholder management across engineering, sales, customers" | F2, F1 |
| R5 "Agile delivery experience" | A5 |
| "Own the roadmap for the partner-facing API platform" | A1, A2, B3, F1 |
| "Run discovery with integration partners" | A3, B1 |
| "Write specs and drive delivery with two engineering squads" | B5, B3, F1 |
| "Define and track adoption metrics" | B2, C2, C3 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | The dossier flags decision authority as asserted in the JD and not evidenced. It reads as diligence, and the answer is what you most need to know before accepting |
| 2 | "How is partner API adoption measured today, and what is the current baseline?" | The dossier flags that adoption metrics are a named responsibility with no baseline stated. It shows you start from a baseline, and it tells you what you would inherit |
| 3 | "How do the two squads divide the platform, and where do their priorities collide today?" | It asks for the real seam before you propose principles for it, and it shows you are already thinking about the two squads' load |
| 4 | "How does partner feedback reach the roadmap today, and who runs that now?" | It is where your adjacent work sits, asked without claiming it, and it shows what you would step into |
| 5 | "What would you want a PM coming from the integration side to learn first, and from whom?" | It converts the biggest gap into a ramp plan the manager gets to write, so the objection from A1 becomes a conversation |
| 6 | "What does a good first ninety days look like for this role?" | It tells you what the manager will judge you on, and "any questions for me" is a scored slot |

## Prohibited claims

Built before the banks. The first three come from the dossier's prohibited_claims; the last two are built here from the quotes.

| Not coached | Basis | Honest form |
|---|---|---|
| "Having held a product manager title or role" | Dossier prohibited_claims | The quotes at their own scope, and the plain acknowledgment "I haven't held a product manager title or role." Positioned as adjacent, never as PM experience (A1, A2, E1) |
| "Having owned a product roadmap" | Dossier prohibited_claims, and acknowledge_gap area "Owning a roadmap and prioritization authority (R1 sub-claim)" | The plain acknowledgment "I haven't owned a product roadmap," and then the ramp plan as a plan. No bridge (A1, A2, B3) |
| "Having set prioritization for an engineering squad" | Dossier prohibited_claims | The plain acknowledgment "I haven't set prioritization for an engineering squad." B3 is a thinking exercise and never a description of past practice |
| Shaped or drove the product roadmap | Inflated form of "Ran quarterly roadmap-input sessions feeding client evidence to product" (F7) | The quote at its own scope. The limit is the pack's observation: the quote says the sessions fed evidence to product, not that product changed course. A3 and E2 stay inside the sessions |
| Directed engineers or a delivery team | Inflated form of "Led 30+ end-to-end client integrations of the vendor's REST APIs" (F1, F8) | The quote at its own scope. The limit is the pack's observation: the quote says the integrations were led, not who built them. B5 and F8 ask only what engineers built from |

## Sources

Provided: your message, which gave the round, the 45-minute length and the interviewer's role, and `tuesday-dossier.md`, dossier_version 1.1, generated 2026-08-14. The dossier was consumed. It supplied role_profile as the JD, and the handoff_to_mock_interview section: verified evidence, weak areas with their allowed strategies, the named objection, risks and employer questions, and prohibited claims. The decision was read as context only. The dossier carries no evidence_map, risk_register or evidence_state, so rows F2, F3 and F8 are graded here and labeled `[inferred]`.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused: "Quartzline values"; "Quartzline interview process product manager"; "Quartzline API platform strategy news".

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Every call was refused. It would have named published values for VAL themes; with no values source and no values-style round detected, there is no cheat sheet |
| 2. `Quartzline interview process product manager` | unavailable | Every call was refused. Your own words fix this session as one 45-minute hiring-manager conversation, so persona weights follow the hiring-manager prior; the rest of the loop is not established |
| 3. `Quartzline API platform strategy news` | unavailable | Every call was refused. It would have grounded a CO or CASE question in current strategy; B1 to B5 and D2 are `[generic]` or JD-driven in its place |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile supplies the requirement text and fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access in this session, or the Quartzline values, careers and strategy pages pasted in → a CO or CASE question grounded in current strategy, and the values themes if a values-style round is documented; one deeper research pass is also available, up to 6 more searches and 2 more fetches, several more minutes, offered once
- The interviewer's name → an interviewer read, persona weights adjusted from their public professional footprint, and a reverse question tied to their own path
- The underwriter's evidence_map → rows F2, F3 and F8 take its grading in place of the pack's
- An agenda, notes or a product item that cites one of the roadmap-input sessions → the sessions entry can move from medium toward high, which upgrades F4, F7, A3 and E2
- Your own answers to the slots on F2, F3, F5 and F9 → A4, D3, A5 and C2 become story-mapped instead of slots
- The recruiter's prep email, if one exists → focus areas and any pre-declared deliverable, which can restructure the banks
