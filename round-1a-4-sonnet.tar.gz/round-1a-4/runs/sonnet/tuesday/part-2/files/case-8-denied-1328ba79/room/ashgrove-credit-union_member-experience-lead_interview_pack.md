# Interview pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara. **Interview day:** 3 December 2026, three rounds, built in loop mode because the recruiter's email fixes all three sessions.

| Round | Who | Length | Shape, from the recruiter's email |
|---|---|---|---|
| 1 | The recruiter | 30 minutes | Screen |
| 2 | The Head of Member Services, who would be your manager | 45 minutes | Mostly behavioural |
| 3 | Panel of two branch managers | 60 minutes | Includes a 20-minute complaint-escalation case; also the values round, scored against the four values |

No interviewer names have been assigned, so there is no interviewer read. This is the first version; nothing has been regenerated.

## How to use this pack

- **Personas describe how a question is asked; types describe what is being scored.** Every question carries both.
- **Type key:** VAL = behavioural, tied to Ashgrove's published values. EXP = deep-dive on your own experience. JD = a stated responsibility or requirement in the job description. CO = knowledge of Ashgrove's strategy and position. CASE = a live problem, asked as a decision.
- **Guidance is scaffolding, not a script.** Any wording below that would be yours to say is proposed language, pending your approval: change it into your own words, and drop anything you could not stand behind under a second question.
- **An answer slot is an instruction for the interview, not a question for you now.** It has two honest branches: say what you did, in your own words, or say plainly that it was not yours or did not happen, and return to what you did say.
- **Provenance** is one label per row: `[grounded]` traces to something you or Ashgrove supplied, `[inferred]` is a derivation the row names, `[generic]` is a pattern with no claim about you or Ashgrove. Where guidance leans on your experience, the exact sentence it rests on sits beside the label.

**The highest-ROI rehearsal in this pack is D1**, in Round 2: owning complaints end to end across branches and the contact centre, from a background that includes one branch's log and no contact-centre work. It will be asked in some form in all three rounds (B1, E2, L1 are its other versions).

## Fit snapshot (shared across all three rounds)

Source of the requirements: the job description you pasted, quoted. Source of the evidence: your message, quoted; no CV was supplied, so every evidence cell is a sentence from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says one branch's formal complaints log, not the process end to end, and the words stay there: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on the steps around the log likely. If any step before or after the log was yours, say which and how, in your own words; if there was no such step, or it was not yours, say so plainly and stay with the log you handled |
| F2 | "across branches and the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked in a contact centre." The pack's own observation: your material shows your branch's log and nothing of other branches. Then how you would learn the contact centre, said as a plan and never as a past: your own first step, in your own words |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material says a monthly complaints spreadsheet your regional manager uses, and does not say what it counted. Answer slot: the JD names volumes and resolution times, so expect a probe on what yours showed. If it showed either, say which, as you built it; if it showed something else, or what it counted was not yours to choose, say so plainly and stay with the spreadsheet you built |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | The quote's scope is new tellers, and the words stay there: "I trained new tellers on our escalation script." Answer slot: the JD's line on supervisors makes a probe likely. If anything you taught on escalations reached beyond new tellers, say who and how; if it did not, say so plainly and stay with the tellers you trained |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you have worked with any digital or online-banking team on something members use, say what and which part was yours; if you have not, say so plainly, then say as a plan how you would start |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | No gap on the figure, but a sentence with nothing inspected behind it, so expect a probe on what the six years held. Lead with the figures as you stated them, six years and the last three as a branch supervisor. A years requirement is not a gate |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | low | [inferred] | discovery | The quote says a formal complaints log; it does not say whether outside rules governed that log. Answer slot: the JD's regulated-complaints line makes a probe likely. Say what handling the log involved, in your own words, and if you know which outside rules applied to it, say so; if you do not know, or those rules were someone else's concern, say so plainly and stay with the log |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated limit. Words: "I've never presented to anyone above regional level." The pack's own observation: your material does not say what you have presented at or below regional level. Then how you would prepare a first presentation to senior leaders, said as a plan and never as a past |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The quote says a spreadsheet, not which tool and not what reporting you did in it. Answer slot: if it was built in Excel, say so and say what the spreadsheet did; if it was another tool, say that; if any part was set by someone else, say so plainly and return to what you built |

No row is a gate: the JD states no authorisation, licence, location, pay or schedule term, so there is nothing for your material to be silent on.

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| Own the member complaints process end to end (F1) | D1, E1, J1, K2, L1 |
| Across branches and the contact centre (F2) | B1, D1, E2, K1, L1 |
| Report monthly on volumes and resolution times (F3) | G1, G2, J2, L2 |
| Coach branch supervisors on escalations (F4) | C1, J1 |
| Work with digital teams on self-service journeys (F5) | D3, E2, J3 |
| 4+ years in financial-services customer operations (F6) | A1, B4 |
| Experience handling regulated complaints (F7) | B3 |
| Confident presenting to senior leaders (F8) | B2, C3 |
| Comfortable with Excel reporting (F9) | G1 |

## Grounding brief: Ashgrove's 2026 strategy

You sent me four points from the July 2026 brief, not the brief itself. At 24 November 2026 it is about four and a half months old, inside the six-month freshness window; anything that has moved since is not in what I hold.

| Item | What it says, as you gave it | Provenance | Use it for |
|---|---|---|---|
| Digital shift | Move 40% of member service to digital channels by 2028 | [grounded] | E2, J3: which complaints a self-service journey can carry and which need a person |
| Branch network | Consolidate eight branches into five hubs over 2027 | [grounded] | E2, H3, K1: how a complaint stays owned and local when branches merge |
| New product | Launch a small-business lending product in Q1 2027 | [grounded] | Reverse questions: it will bring a new kind of member and complaint to the process |
| Competition | Main competitive pressure is app-only banks | [grounded] | E2, J1: the case member who threatens to leave is the pressure the brief names |

## Persona table

Weights start from the usual priors for a recruiter screen, a hiring manager and a panel, then are adjusted by the recruiter's own description of each round.

| Persona | How it shows up here | Likelihood by round, with the reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly biography and logistics, still scored | Round 1 high: a recruiter screen's prior. Rounds 2 and 3 low: neither is described as a chat | A 90-second arc; treat the pay, notice, location and leaving questions as scored |
| Skeptic | Quiet, persistent probing of the contact-centre and senior-presentation limits | Round 1 light: screen prior. Round 2 high: the hiring-manager prior is de-risking gaps, and you have named two. Round 3 low | Rehearse D1 until it is boring; say the limit before it is asked for |
| Values / Behavioral | Scenarios mapped to the four published values | Round 2 high: the recruiter calls it mostly behavioural. Round 3 high: the recruiter says the panel scores against the four values | One story per value from your own material; "we" for context, "I" for what you did |
| Case / Strategist | Live problems from the actual role | Round 2 medium: hiring-manager prior. Round 3 high: the recruiter says a 20-minute escalation case | Clarify, objective, segment, approach, metrics, risks; challenge one premise respectfully |
| Data-Driven Prober | Reads your material line by line; asks what the spreadsheet counted | Round 2 medium: a manager who will read the spreadsheet line closely. Round 3 low | Say how a figure was counted, or say plainly you do not know |
| Pressure / Stress | Time-boxed challenge on the contact-centre limit | Round 3 medium: a panel blends styles, and the case is time-boxed. Rounds 1 and 2 low | Pause, restate, hold through two follow-ups, then concede specifically |
| Peer Evaluator | Seam-splitting between your role and a branch manager's | Round 3 medium: the panel is two branch managers, and the role coaches branch supervisors. Rounds 1 and 2 low | Propose seam principles rather than pretend to know the seam; offer what you bring their branch |

## Round 1: the recruiter (30 minutes)

Persona weights: Conversational top, light Skeptic. Ten questions, because the screen carries four logistics rows by rule.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F6, F1 and F3: a 90-second arc in your own words using only what those sentences state: six years in retail banking, the last three as a branch supervisor; the branch's formal complaints log; training new tellers on the escalation script; the monthly complaints spreadsheet. Close on why this role, in your own reason, which this pack does not supply | A casual opener that is still scored, and the place F6's years get established. EXP content, Conversational delivery |
| A2 | "What are you looking for on salary?" | JD | [generic] | Logistics slot: give your own figure or range, in your own words, or ask for the role's band first; the JD you pasted gives no band. If asked what you earn now, you can decline or redirect without giving a figure | A recruiter screen asks pay in some form; the only safe answer is your own |
| A3 | "What's your notice period, and when could you start?" | JD | [generic] | Logistics slot: give your actual notice period and any start-date limit, in your own words | Notice is one of the four logistics every screen checks |
| A4 | "Where are you based, and is there anything we should know about getting to our sites?" | JD | [generic] | Logistics slot: give your actual location and any limit on where or how often you can work, in your own words | The role spans branches and a contact centre, so location is a live logistics row; the JD states no pattern |
| A5 | "Why are you looking to move from your current role?" | EXP | [generic] | Logistics slot: give your actual reason, in your own words | Motivation consistency is the recruiter's knockout check; the reason is yours alone to give |
| A6 | "What made you apply to Ashgrove?" | CO | [grounded] Ashgrove's published values and the strategy points you sent | Pick one specific thing from what Ashgrove published, a value by its name or one of the strategy moves, and say in your own words why it matters to you. The personal reason is yours to give; reciting the strategy back scores as homework | Company knowledge asked in a friendly register. CO content, Conversational delivery |
| B1 | "You haven't worked in a contact centre. How would you get up to speed?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The limit first, in your words: "I've never worked in a contact centre." Then a plan, said as a plan: your own first step, in your own words. Keep it short here; D1 is the full rehearsal | F2 is the biggest stated limit, so a screen checks it early. JD because it tests a stated part of the role |
| B2 | "This role presents to senior leaders. What's your experience of that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | The limit first, in your words: "I've never presented to anyone above regional level." Answer slot: name the most senior audience you have actually presented to, as it was; if there was none you can name, say so plainly. Then how you would prepare a first presentation to senior leaders, as a plan | F8 is a stated limit that the JD's presenting line presses on |
| B3 | "The role handles regulated complaints. What have you handled?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say it at its own scope: "I handled the branch's formal complaints log." Answer slot: say what handling the log involved, in your own words, and if you know which outside rules applied to it, say so; if you do not know, or those rules were someone else's concern, say so plainly and stay with the log | F7 is the requirement your material touches without showing, so the screen is where it gets found out |
| B4 | "Which part of your six years is closest to what this role does?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Choose from what you have stated: the last three years as a branch supervisor, the formal complaints log, the escalation script training. Say which and why in your own words, without describing the log or the training as anything more than the sentences say | F6 and F1 together: the recruiter is mapping your years onto the role |

### Round 1 reverse questions

| # | Ask | Why it lands |
|---|---|---|
| 1 | "What is the pay band and the working pattern for this role?" | The JD you pasted gives neither, and the recruiter is the one person who can answer before Rounds 2 and 3 |
| 2 | "What would Ashgrove most want the person in this role to have changed a year in?" | Surfaces the priority the later rounds will test, and hands you vocabulary for them |
| 3 | "How is the contact centre set up today, and how do complaints reach this role from it?" | Bears directly on F2, and shows you are sizing the step rather than avoiding it |
| 4 | "Is there anything about how the panel scores against the four values that I can prepare for?" | The panel is the values round; one question to the recruiter can sharpen Round 3 |
| 5 | "Who in the business works with the digital team on self-service journeys today?" | Bears on F5 and on the 40% digital target in the brief |

## Round 2: the Head of Member Services (45 minutes)

Persona weights: Values/Behavioral and Skeptic top, Case/Strategist and Prober mid. Ten questions.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you helped a colleague through an escalation." | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Story-mapped on F4: the beat the sentence states is training new tellers on the escalation script: "I trained new tellers on our escalation script." Answer slot: the JD's line on supervisors makes a probe on anything beyond that likely. If anything you taught on escalations reached beyond new tellers, say who and how, in your own words; if the training was the whole of it, say so plainly and stay with the tellers you trained | F4 is the JD's coaching line against a quote about tellers. JD content, behavioural delivery |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone more senior something they did not want to hear. It needs what the truth was, who heard it, and what the relationship looked like afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The stem from the Values persona; a mostly behavioural round tends to include it. A story is yours to choose, so this pack supplies none |
| C3 | "Tell me about a time you presented something to someone more senior than you." | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Selection scaffold, with your stated limit in view: pick the most senior audience you have actually presented to. It needs who they were, what you showed, and what they did with it. If it was regional level or below, say that plainly; if no such time comes to mind, say so, then how you would prepare a first presentation to senior leaders | F8 is a stated limit, and a behavioural round turns it into a story request |
| D1 | "Owning complaints end to end across branches and the contact centre is the heart of this role. You haven't worked in a contact centre. What do you do in your first weeks to close that?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | **The highest-ROI rehearsal in this pack.** Before they ask, say the limit: "I've never worked in a contact centre." Then what you have, at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Hold there through two follow-ups by returning to those words, never by adding to them. Follow-up one, likely: what do you know about how the contact centre handles complaints today? Answer slot: say only what you actually know, in your own words; if you do not know, say so plainly and say who you would ask first. Follow-up two, likely: which parts of end to end sit beyond your branch's log? Answer slot: name any step you have seen outside the log; if none, say so plainly. Concede specifically at the end: the contact centre is the part you would be learning from the start, and you finish that sentence with your own first step, said as a plan | F1 and F2 together are the headline of the role against the thinnest part of your material, so this question arrives in some form in every round. It has the most follow-up levels and the limit named before it is asked for |
| D2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Your material carries two stated limits, "I've never worked in a contact centre" and "I've never presented to anyone above regional level", and silence on digital teams. Choose the one that is true for you, say it first, and give a ramp plan in your own words. Do not pick a limit you do not have to look modest | Skeptic stem. It tests honest self-assessment, and F2, F5 and F8 are the candidates |
| D3 | "Tell me about working with digital teams on self-service journeys." | JD | [grounded] | Answer slot: if you have worked with any digital or online-banking team on something members use, say what it was and which part was yours; if you have not, or it was not yours, say so plainly, then say as a plan how you would start. Your material says nothing either way | F5 is silence, so the honest answer could be either branch, and both are rehearsed |
| E1 | "Your first 90 days: what do you want to find out before you change anything?" | CASE | [generic] | Structure it aloud: what you would ask, who you would listen to, what you would read before touching the process, and what you would hold off changing. It needs no claim about your past, so none is made | A live role problem that scores clarify-before-structure; F1 and F2 are what it is really about |
| E2 | "The strategy moves 40% of member service to digital by 2028 and consolidates eight branches into five hubs over 2027. What does that do to the complaints process you would own?" | CO | [grounded] The strategy points you sent | Everyone prepared will say digital for simple, people for hard: bring that once to show you did the reading, then one thesis of your own, with reasons, and the anti-pick, what you would not move to self-service. Structure: what gets harder when a member's branch becomes a hub, what gets easier, and who keeps hold of a complaint that crosses channels. No claim about your past | The brief is equally available to rival candidates, so recitation scores as homework and a reasoned departure scores as judgment. CO content, CASE delivery |
| G1 | "The role needs comfort with Excel reporting. Walk me through the monthly complaints spreadsheet you built." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Story-mapped on F9 and F3: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: say what tool it was built in and what it showed, in your own words; if it was not Excel, say what it was; if any part of it was set by someone else, say so plainly and return to what you built | F9 is the JD's Excel line against a quote that says spreadsheet. A manager who will read the reporting will ask |
| G2 | "What did it count, and how long did complaints take to resolve at your branch?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: give a figure only if you know how it was counted, and say how it was counted and what you would defend least about it, in your own words; if you did not track it, say so plainly and stay with the spreadsheet you built. Do not estimate a figure to fill the gap | F3 is where the JD's volumes and resolution times meet a quote that names neither. A prober asks for the number, then the assumption behind it |

### Round 2 reverse questions

| # | Ask | Why it lands |
|---|---|---|
| 1 | "What would you want the monthly complaints report to tell you that it does not today?" | Turns the reporting line into a working conversation with your future manager |
| 2 | "How do complaints move between branches and the contact centre now, and where is that handoff hardest?" | Bears on F2 and on Own the Fix: it asks where ownership gets lost |
| 3 | "How will the move to 40% digital and five hubs change what this role owns by 2028?" | Shows you read the brief for what it does to the job, not just what it says |
| 4 | "What would you want to be true of the complaints process at the end of my first 90 days?" | Pairs with E1 and gets the manager to state the first target |
| 5 | "How do you prefer to hear about a problem: early and rough, or when I have a recommendation?" | Working-style fit with the person you would report to |

## Round 3: the panel of two branch managers (60 minutes, including a 20-minute case)

Persona weights: Values/Behavioral top, Case/Strategist next, Peer Evaluator and Pressure mid. Eleven questions. The values cheat sheet sits here because the recruiter names this round as the values round.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Tell me about a time you decided from the member's side of the counter." | VAL | [grounded] Ashgrove's value "Members First, Always" as you pasted it | Selection scaffold: pick a decision where you took the member's side. It needs the member's situation, what you chose, what it cost or whom it cost, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would decide | The value is scored by name, and a story with a named stake beats the slogan |
| H2 | "Tell me about a time you changed how something was written or said so a member would not need it explained twice." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." Ashgrove's value "Plain Words" | Selection scaffold: pick a time you changed the wording of something a member read or heard. Your material has a script you trained tellers on; say only that, "I trained new tellers on our escalation script." Answer slot: if you ever changed how any of it was worded, say what and why; if you only taught it as it stood, say so plainly. If no such time comes to mind, say so, or how you would test wording on a member | The value's test is explaining something twice; the script is the nearest thing your material carries and carries no rewording |
| H3 | "Tell me about a time you treated a member as a neighbour, not a case number." | VAL | [grounded] Ashgrove's value "Neighbours, Not Numbers" | Selection scaffold: pick a time you dealt with a member as a person from your branch's town. It needs who they were, what you did that a number would not have prompted, and how it ended. If no such time comes to mind, say so plainly, then the nearest thing your material does carry, or how you would handle it | The panel is branch managers, and the value is about each branch's town; the recruiter says they score against it |
| H4 | "Tell me about a time you found a problem that was not yours to fix, and what you did next." | VAL | [grounded] Ashgrove's value "Own the Fix" | Selection scaffold: pick a time you found a problem outside your own remit. It needs what you found, what you did to keep hold of it, and how it was resolved. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Own the Fix says whoever finds a problem keeps hold of it; this tests whether you did |
| J1 | "A member emails the contact centre about a fee, hears nothing for two weeks, then walks into a branch and tells the supervisor they will move their savings to an app-only bank. The supervisor is not sure whether this is now a formal complaint. You have twenty minutes. What do you want to know first, and what do you do?" | CASE | [generic] | This is a practice shape; the real case will differ. Say your structure aloud: clarify first (what the original complaint was, what the member has been told, what Ashgrove's own rules and its regulator require on time limits and on what counts as formal: ask, do not assume), objective (the member heard and the problem fixed), segment (complaint or enquiry, handled by branch or contact centre), approach (name who keeps hold, what the member is told today in plain words, what is recorded), metrics (what the monthly report would show), risks. Challenge one premise respectfully. The guidance makes no claim about your past | The recruiter says the 20-minute case is a complaint escalation. The pressure of the member leaving is the competitive frame in the brief, and F1, F4 and F7 are the requirements it presses on |
| J2 | "Which two numbers would you put at the top of the monthly complaints report, and why?" | CASE | [grounded] The JD line "report monthly on complaint volumes and resolution times" | Structure it aloud: what decision each number lets a reader make, what each hides, and what you would add if the first two proved misleading. Make no claim about numbers you have reported; the question needs none | F3 is the JD's reporting line asked as a decision, a follow-up a case panel often adds |
| J3 | "40% of member service moves to digital by 2028. Which complaints should never be handled in a self-service journey, and which could?" | CASE | [grounded] The strategy points you sent | Clarify, then segment by what the member needs rather than by channel. Offer a principle you would defend and an example of what stays with a person; use Plain Words as your test: if a member needs the journey explained twice, it was written wrong. Make no claim about digital work you have done | F5 and the brief together; a thesis with a reason scores above a list |
| K1 | "Our branches sit alongside your role. Where is the seam between you and a branch manager on a complaint, and what happens when we disagree?" | JD | [generic] | Propose seam principles rather than claiming to know Ashgrove's: who the member sees, who decides, who keeps hold, how a disagreement is escalated. For the disagreement, selection scaffold: pick a time you disagreed with a peer. It needs the stake, what you did, and the relationship afterwards. If no such time comes to mind, say so plainly, then how you would handle it. Offer what you bring their branch, not only what you need | Peer Evaluator: two branch managers who would work alongside this role. F2 and F4 are where branches and the role meet |
| K2 | "When a complaint passes between a branch and the contact centre and goes wrong, whose is it?" | VAL | [grounded] Ashgrove's value "Own the Fix" | Answer with the value's own rule: whoever finds the problem keeps hold of it, so a handoff names an owner and nobody answers with blame. Say how you would make that visible in the process. No claim about your past is needed | F1 and F2 asked as a values question; the answer should sound like the value, not like process language |
| L1 | "Sixty seconds: why you, rather than someone who has run a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." "I handled the branch's formal complaints log and trained new tellers on our escalation script." "I built the monthly complaints spreadsheet our regional manager uses." | Pause, restate the question, then use only what you have said: the log and the script training, and the spreadsheet, in those words, with the limit named: "I've never worked in a contact centre." Hold through two follow-ups by returning to those sentences, then concede specifically and finish with your own first step as a plan. Do not claim you would outperform a candidate who has run a contact centre | The time-boxed Pressure version of D1, from a panel that blends styles |
| L2 | "That spreadsheet: how much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Hold: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: if anyone else shaped any part of it, say so plainly and say what was yours; if it was wholly yours, say that. Hold through two follow-ups by returning to the sentence, never by adding to it | Pressure stem, aimed at the one artifact you say you built |

### Values cheat sheet

Official names from the page you copied this morning from ashgrovecu.org/about/values. Working meanings are paraphrased from it. None of your sentences carries a story for a value, so each row is a selection scaffold ending in its honest branch.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Scaffold, H1: pick a decision where you took the member's side, with the stake and how it ended; if none comes to mind, say so plainly, then the nearest thing your material carries, or how you would decide |
| Plain Words | If a member needs it explained twice, the wording failed | Scaffold, H2: pick a time you changed wording for a member; if none, say so plainly, or how you would test wording on one |
| Neighbours, Not Numbers | Every branch is part of its town | Scaffold, H3: pick a time you dealt with a member as a person from your branch's town; if none, say so plainly, or how you would |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Scaffold, H4: pick a time you kept hold of a problem outside your remit; if none, say so plainly, or how you would |

### Round 3 reverse questions

| # | Ask | Why it lands |
|---|---|---|
| 1 | "What could a new person in this role do in the first month that would genuinely help your branch?" | Reciprocity for two branch managers who are peers in practice |
| 2 | "When a complaint goes wrong between your branch and the contact centre today, who keeps hold of it?" | Uses Own the Fix in their own terms and tests F2 from their side |
| 3 | "Which of the four values is hardest to hold on a difficult complaint, and why?" | Shows you took the values as working rules, not slogans |
| 4 | "Which complaint do you remember your branch handling well, and what made it work?" | A rapport question that gives you a real example to learn from |
| 5 | "What do your supervisors find hardest about escalations?" | Bears on F4: it tells you what coaching would have to fix |

## Prohibited claims

What this pack will not coach, and why. Silences are not listed: F5 and F9 are answer slots, because your material says nothing either way.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F1 | F1's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation: the material says one branch's log, not the process. D1's slots stay inside the log |
| Has handled regulated complaints | Inflated form of F7 | F7's quote at its own scope: "I handled the branch's formal complaints log." The limit is the pack's observation. B3's slot asks only what handling the log involved |
| Has worked in a contact centre | Negative you stated, F2 | The plain acknowledgment: "I've never worked in a contact centre." No slot |
| Coached or led branch supervisors on escalations | Inflated form of F4 | F4's quote at its own scope: "I trained new tellers on our escalation script." C1's slot asks only whether what you taught reached beyond new tellers |
| Reported complaint volumes and resolution times to leaders | Inflated form of F3 | F3's quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." G2's slot asks only what it counted |
| Has presented to senior leaders | Negative you stated, F8 | The plain acknowledgment: "I've never presented to anyone above regional level." No slot |

## Sources

**Provided documents:** the job description you pasted; Ashgrove's four values, copied this morning (24 November 2026) from ashgrovecu.org/about/values; the recruiter's email on the process; your summary of the July 2026 strategy brief the recruiter sent; your background message. No `tuesday-dossier.md` was present.

**Searches and fetches sent:** none.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Ashgrove Credit Union values` | skipped | Could not have moved the cheat sheet: the pasted values page, copied this morning, gives the four official names and their definitions |
| 2. `Ashgrove Credit Union interview process member experience` | skipped | Could not have moved the persona weights or round structure: the recruiter's email fixes the three sessions, who runs each and what each holds |
| 3. `Ashgrove Credit Union strategy` | skipped | Could not have moved the CO bank: the four strategy points you pasted from the July 2026 brief, under six months old, supply the priorities |
| 4. `{interviewer name} Ashgrove Credit Union` | n/a | No interviewer name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Member Experience Lead` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV as text → the evidence cells quote it instead of your message, and F1 to F9 are re-graded against more than four sentences
- Any figures behind the spreadsheet (monthly complaint counts, resolution times, anything it showed) → defend-the-number questions replace G2's slot, and F3 and F9 move off `discovery`
- One real story for each of the four values → H1 to H4 and the cheat sheet move from scaffolds to story-mapped answers
- Whether the formal complaints log sat under outside rules, and which → F7 and B3 move off `discovery`
- Any work with a digital or online-banking team → F5, D3 and J3 move off a bare slot
- The interviewers' names → persona weights read from their public footprint and tailored reverse questions; any recruiter detail on the 20-minute case's format reshapes J1
- The full text of the strategy brief → the grounding brief rests on the document instead of a four-point summary
- The pay band, working pattern and location for the role, which the JD does not give → ask the recruiter (Round 1 reverse question 1); your answers fill the logistics rows A2 to A5
- A deeper research pass, offered once: up to 6 more searches and 2 more fetches, several more minutes → role-family loop reports, recent organisation context and, once names exist, the interviewers' public footprint
- A `tuesday-dossier.md` from earlier work on this role → verified evidence and a named objection would replace the inferred ones here; nothing in this pack needs it
