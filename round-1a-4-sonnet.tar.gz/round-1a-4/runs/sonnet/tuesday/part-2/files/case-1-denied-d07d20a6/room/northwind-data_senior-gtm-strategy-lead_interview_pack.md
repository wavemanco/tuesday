# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya
**Interviewer:** Dan Kovac, Director of Sales Strategy, Northwind Data. Priya's peer: both would report to the same VP.
**Round:** one 60-minute conversation with Dan, as you described it. No recruiter guidance on focus areas or deliverables was supplied.
**Built on this assumption:** the conversation is a peer round, with no pre-declared deliverable. Dan's profile and Northwind's priorities are as you described them. Neither could be checked, because web searches were refused (see Sources).

## How to use this pack

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script. Where guidance says "answer slot", it is an instruction for the interview, not a question for you now. Fill it in your own words from what actually happened. Either honest branch is a good answer.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values. Not used in this pack: no values-style round is detected and no published values are in hand |
| EXP | Whether a claim on the CV survives scrutiny, and what was actually the candidate's |
| JD | The listed responsibilities and qualifications, gaps included |
| CO | Knowledge of the company's strategy, competition and recent moves |
| CASE | A live problem from the role, scored on structure and reasoning |

## Fit snapshot

Requirements are quoted from the JD highlights you supplied. Evidence is quoted from your notes on Priya.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, not go-to-market and not a launch, and the words stay there: "For nine years I worked in product strategy and ops at a large consumer-tech company." Answer slot: the JD's line makes a probe on go-to-market work likely. If any of that work was bringing a product to market, say what and which part was yours; if there was none, or it was not yours, say so plainly and stay with product strategy and ops |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | low | [inferred] | discovery | The quote shows a proposal and a credited uplift, and does not show how the opportunity was found. Words at its own scope: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's whitespace line makes a probe on how the opportunity was found likely. If you found it by looking across stages of use, say how and with what data; if it did not come that way, or the finding was not yours, say so plainly and stay with what you proposed |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | presentation | The quote already names both tools. Lead with it in its own terms: "I'm skilled in SQL and Tableau." Expect a probe on an analysis you ran yourself, because a skill line has nothing inspected behind it. Answer slot: if you ran an analysis end to end, say which and what was yours; if you did not, or it was a shared piece of work, say so plainly and stay with the tools |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | Your material says a revenue model used in negotiations, not the design of a partner motion, and the words stay there: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any stage of the negotiations the model fed was yours to set, say which and how you decided; if there was none, or it was not yours, say so plainly and describe the model and its use. This is the JD's one "required" line, so expect it to be pressed |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Say it as written: "I set annual volume targets with cross-org consensus." Answer slot: if reaching consensus meant reconciling positions that differed, say who differed and what you did; if it did not, or the steps were not yours, say so plainly and stay with the targets |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | transferability | The quote says use of AI tools, not building, launching or evaluating them. Words: "I use AI tools daily." Answer slot: which tools and for what, in your own words; if any of it went beyond using them, say what; if it did not, say so plainly |
| F7 | Sales-ops and quota-setting fluency: a role-family expectation, not in the JD highlights, and likely to come up with a Director of Sales Strategy | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I have no classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. F5's quote speaks of volume targets, not quotas, so the pack never treats one as the other |

## Reading the interviewer

Everything below is as you described Dan's profile. It is a public self-description, not a verified read. It rests on no pack searches, because they were refused. Shared background, language or region is never a strategy and none is used.

| Signal | Source | What it means for the conversation | Provenance |
|---|---|---|---|
| Self-describes as "relentlessly data-driven" | Dan's profile, as you described it | Expect every figure to be probed to its inputs and assumptions. The A bank is the first rehearsal | [inferred] |
| Career spine in pricing and monetization roles | Dan's profile, as you described it | Case questions tilt to pricing, packaging and unit economics, which is his native vocabulary (C2, C3). F4's quote speaks of a revenue model, not prices: use his vocabulary in analysis, never to describe your own past | [inferred] |
| One early-stage-startup chapter | Dan's profile, as you described it | Possible probes on pace and scrappiness. Your quotes carry no startup or zero-to-one story, so none is coached. R1 asks him about it instead | [inferred] |
| Peer, same VP | Your description of the round | He is pricing what you would cost and add to his own work: seam-splitting, credit, disagreement style (B bank) | [inferred] |

Mirror opportunity: F4's quote, "built a partner-level revenue model used in carrier negotiations", uses revenue-model language close to his monetization spine. Offer it at its own scope and let him ask. The quote does not say you set prices.

## Persona table

| Persona | Weight | How it shows up | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober (A) | High, 5 questions | Walks the CV line by line and asks how each number was counted | Relationship prior for a peer, raised by his "relentlessly data-driven" self-description | Know what you can and cannot say about how the figure was counted, and say plainly when you do not know |
| Peer Evaluator (B) | High, 5 questions | Seam-splitting, "what would you need from me", credit and disagreement | Relationship prior: he is your peer under the same VP | Reciprocity: lead with what you bring his team, and propose seam principles rather than pretending to know the seam |
| Case / Strategist (C) | Mid, 4 questions | Live problems on Northwind's priorities, tilted to pricing and packaging | His pricing and monetization spine plus the JD's strategy ownership. Below hiring-manager weight, because he is a peer | Clarify, then objective, segmentation, approach, metrics, risks, thinking aloud |
| Skeptic (D) | Mid, 3 questions | Quiet probing of the quota and sales-ops gap and the consumer-to-B2B jump | Your own note names the gap, so it will be tested | Rehearse the single most predictable objection until it is boring (D1) |
| Conversational (E) | Low, 2 questions | Biography opener and an AI chat | JD plus-skill and opening-question prior | Treat casual questions as scored |
| Pressure (F) | Low, 2 questions | Time-boxed "why you" and an attribution challenge | No signal that he is a stress interviewer, but attribution on the ~$400M is likely whatever his style | Pause, restate, hold through two follow-ups, concede specifically |
| Values / Behavioral | Not included | n/a | No values-style round is detected: the loop is the one conversation you described, and no published values are in hand | Add if you learn a values round exists |

## Question banks

Priority: D1 is the highest-ROI rehearsal in this pack. Do it first and most.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The ~$400M ARR uplift on your store-surface proposal: how was that number counted?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Story-mapped on F2, only to the beats the quote states: you proposed the change, and it was credited with the uplift. Answer slot: how the figure was counted, in your own words; if you do not know how it was counted, say so plainly and say what you do know. Answer slot: what the figure is most sensitive to, or say you do not know. Never describe a counting method you could not repeat under a second question | F2 holds the pack's only headline figure, and a Prober asks about counting first. EXP because it tests whether the CV claim survives scrutiny |
| A2 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | The weakest-assumption move: name, in your own words, the assumption you would defend least before he does. If you do not know the assumptions behind the figure, say so plainly and say what you would want to check. The pack names no assumption. Name only ones you can explain | Persona stem for the Prober; F2. EXP because it scores honesty about the number's limits |
| A3 | "Tell me about an analysis you ran yourself, from the raw data to a recommendation." | JD | [grounded] "skilled in SQL/Tableau" | No quoted sentence carries an analysis story, so this is a selection scaffold. Pick one where you wrote the queries or built the views yourself. It needs the question you were asking, the data, what was yours and not a teammate's, and what the result changed. If no such analysis comes to mind, say so plainly, then give the nearest thing your material carries: "I'm skilled in SQL and Tableau", or how you would approach one | F3 is the evidence for the independent-analysis requirement, and a skill line draws this probe. JD because it scores a stated requirement |
| A4 | "What was the partner-level revenue model used for, and what part of the carrier negotiations did it touch?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-mapped on F4: you built the model, and it was used in carrier negotiations. Those are the beats, so tell them in your own words. Answer slot: the JD's partner-motion line makes a probe on what sat around the model likely. If any stage of the negotiations the model fed was yours to set, say which and how you decided; if there was none, or it was not yours, say so plainly and describe the model and its use | F4 is the evidence nearest the JD's one "required" line. EXP because it separates what was built from what was designed |
| A5 | "A new product line has almost no usage history. How would you find whitespace across land, adopt, expand and renew, and what data would you pull first?" | JD | [generic] | A live problem, so no claim about your past. Clarify the product, who buys and who uses, and what "land" means here. Define one metric per stage. Name the data you would pull first and what would make you distrust it. Segment, state a hypothesis, and say how you would test it. Use the JD's own stage vocabulary | F2's requirement, delivered as a CASE with Prober follow-ups ("what makes you distrust the data"). Tagged JD because the requirement is the JD's. `[generic]` because it is a method, not a claim about Northwind |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your remit and mine, and what happens when we disagree?" | JD | [generic] | No claim about your past. Propose seam principles rather than a map you cannot know yet: who owns the question, who owns the data, and who decides. Say you would ask what his team owns today before drawing any line. For disagreement, agree the question and the data first, then escalate only the decision. Reciprocity: say what you would take off his plate | F5's requirement in the peer's own terms. Peer stem; JD because it scores cross-functional influence |
| B2 | "Tell me about a time you disagreed with a peer team on a plan or a target. How did it resolve?" | JD | [grounded] "set annual volume targets with cross-org consensus" | An open prompt, and the quote names no disagreement. Story-map only what it states: annual volume targets, set with cross-org consensus. Answer slot: if reaching consensus meant reconciling positions that differed, say who differed, what you did and what moved, in your own words; if it did not, or the steps were not yours, say so plainly and stay with the targets. Show spine and tact together | F5 is the nearest evidence to the JD's influence line. JD because it scores the requirement. The pack supplies no conflict |
| B3 | "How did you get cross-org consensus on the annual volume targets?" | JD | [grounded] "set annual volume targets with cross-org consensus" | Tell it as the quote does: "I set annual volume targets with cross-org consensus." Answer slot: the JD's cross-functional line makes a probe on how consensus came about likely. Say which orgs and what you did, in your own words; if it came without a particular step of yours, say so plainly and stay with the targets | F5, probed from the Peer's angle. Premised only on the quote's own words |
| B4 | "How do you handle credit when work spans teams?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift"; "set annual volume targets with cross-org consensus" | Use "we" for context and "I" for contribution, and keep each "I" to its quote: "I proposed a store-surface change" and "I set annual volume targets with cross-org consensus". Answer slot: how credit was shared on either, in your own words; if you do not know how it was divided, say so plainly | Peer stem. EXP because credit-sharing is an attribution probe. F2 and F5 |
| B5 | "In your first 90 days, what would you need from me, and what would my team get from you?" | JD | [grounded] "skilled in SQL/Tableau" | Lead with what you bring his team, at the quote's scope: "I'm skilled in SQL and Tableau". Then one or two specific needs, said as a plan about the future: how his planning cycle runs, and which measures his team already trusts. No claim about your past | The reciprocity move for a peer. JD because it scores the influence requirement. F3 |

### C. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Compass is the AI copilot launch. Sketch the go-to-market: what do you need to know first?" | CASE | [grounded] | Clarify first: who buys and who uses, what land means, and which of the two new lines Compass is, since you have not been told. Then objective, segmentation, approach, metrics, risks, thinking aloud. Challenge one premise respectfully. Use the stage vocabulary of land, adopt, expand, renew. No claim about your past | Compass is named as a stated priority in your research note. CASE because it is a live problem on the role. F1 and F6 are the requirements it touches |
| C2 | "A much larger platform vendor bundles a competing capability into its suite. How do you protect expansion and renewal on our new lines, and is pricing or packaging your first lever?" | CO | [grounded] | Structure: how bundling changes the customer's comparison, which segments are most exposed, and the levers (packaging, pricing, integration depth, proof of value). Name your first lever with a reason and the data that would change your mind. Bring the consensus answer to prove grounding, then one thesis-driven divergence, then the anti-pick: what you would not do. Reason in his vocabulary, but never claim pricing experience | Bundling by a much larger vendor is the competitive threat in your note, and pricing is Dan's native lane. CO because it tests altitude on Northwind's own situation |
| C3 | "We need to reach profitability while launching two new product lines. How do you decide where growth spend goes and what gets cut?" | CASE | [grounded] | Clarify what profitability means here and over what horizon. Set criteria for spend: stage of each line, unit economics, strategic dependence. Name one metric per line and the data you would want from Dan's team. State the trade-off aloud and the risk of each choice. No claim about your past | Profitability is one of the three priorities in your note. CASE because the trade-off is posed live. F1 |
| C4 | "You'd own GTM strategy for two new product lines. What would your first 90 days look like, and what do you need to know first?" | JD | [generic] | A plan, so about the future only. What you would learn first (the lines, buyers, current motions), what you would produce and for whom, and where you would align early with Dan's team and the VP. Ask which of the lines is further along, because the material does not say | F1's requirement, asked as a plan. JD because it is the JD's headline responsibility |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't done classic sales ops or quota-setting. How does that change what you can do in this seat?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus" | The deepest rehearsal in the pack. Beat 1, before he presses: the plain acknowledgment. "I have no classic sales-ops or quota-setting experience." Beat 2, at its own scope: "I set annual volume targets with cross-org consensus." Say targets, never quotas. If asked how a target differs from a quota, answer in your own words, or say you do not know. Beat 3, a plan and not a past: what you will ask Dan to walk you through first, and in what order you will learn it. Follow-up one, "So what don't you know?": restate the acknowledgment and name one specific thing you would ask. Follow-up two, "Why not hire someone who has?": hold, return to the quotes, and concede that they start ahead on this point. Follow-up three, "What if the VP expects you to own it?": concede the gap as real, state the ramp plan, and do not claim the capability | F7 is the biggest gap and the one your own notes name, so it will be asked in some form. JD because it scores a likely requirement. Highest-ROI prep: a calm acknowledgment changes the interview |
| D2 | "Northwind sells B2B data infrastructure. Which parts of your background transfer, and which don't?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus" | Say what the quotes carry: strategy consulting, then nine years in product strategy and ops at a consumer-tech company; a partner-level revenue model used in carrier negotiations; annual volume targets set with cross-org consensus. Let him judge what transfers. Answer slot: if any of that work faced business customers, say which and how; if none did, or it was not yours, say so plainly and say what you would need to learn first | F1 is the background mismatch an interviewer on the sales side will test. JD because it asks about fit to the listed job |
| D3 | "Partner-motion design is a requirement here. Where does your experience meet it, and where doesn't it?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the quote says: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if your work reached how the partner relationship was run beyond the model, say what and which part was yours; if it did not, say so plainly and stay with the model. Then a plan for the rest | F4, the JD's one required line. JD because it scores the requirement directly. Skeptic delivery because the question asks you to name the limit yourself |

### E. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with three beats. Two years in strategy consulting at a top firm. Then nine years in product strategy and ops at a large consumer-tech company. Third beat, answer slot: why this role and why now, in your own words, because the pack does not supply a motive. End on a forward line | Persona stem. EXP because it is the CV's spine. F1 |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Tell it as the quote does: "I use AI tools daily." Answer slot: which tools and what for, with only specifics you could repeat under a second question; if any of it went beyond using them, say what; if it did not, say so plainly. Treat it as scored even though it is casual | F6, the JD's plus-skill, asked in a casual register. JD because the plus-skill is the JD's |

### F. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "That ~$400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Pause and restate the question. Hold: "I proposed the change, and the ~$400M ARR uplift was credited to it." Hold through two follow-ups by returning to that sentence, never by adding to it. Concede specifically where you have to: answer slot, if you know how the credit was divided, say so; if you do not, say so plainly. Do not fold on the part the quote states, that the proposal was yours | Persona stem; F2. EXP because it is the attribution probe a Prober delivers under pressure |
| F2 | "Sixty seconds: why you over someone who has run quotas and sales ops?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "built a partner-level revenue model used in carrier negotiations"; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau" | Do not contest the gap: "I have no classic sales-ops or quota-setting experience." Then three quoted offers and nothing more: you built a partner-level revenue model used in carrier negotiations, you set annual volume targets with cross-org consensus, and you are skilled in SQL and Tableau. Close with the plan to close the gap. If he says that is a lot to learn, concede the learning curve explicitly and hold the three quotes | F7 with F4, F5 and F3. JD because it scores fit to the job. Pressure delivery because of the time box |

### Requirement coverage

| JD requirement | Question IDs |
|---|---|
| own GTM strategy for two new product lines | C4, C1, C2, C3 |
| identify whitespace across land/adopt/expand/renew | A5, C1, C2 |
| run independent analysis in SQL and Tableau | A3, A1, A2 |
| partner-motion design experience required | D3, A4 |
| strong cross-functional influence | B1, B2, B3, B4, B5 |
| AI experience a plus | E2, C1 |
| Not in the JD highlights: sales-ops and quota-setting fluency | D1, F2 |

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "Your path runs through pricing and monetization roles and an early-stage startup. What did the startup chapter change about how you plan sales strategy?" | Ties to his own path, which turns the exchange into a peer conversation and shows you looked at him, not only the company | [grounded] |
| R2 | "What could a new person on my side do in the first month that would genuinely help your team?" | The reciprocity question for a peer. It puts his load, not only your onboarding, at the center | [generic] |
| R3 | "Where does the seam between your planning and the new lines' go-to-market sit today, and where is it still unsettled?" | Follows B1: shows you would map the seam with him rather than assume it | [generic] |
| R4 | "What is the one question about the two new lines you would want me able to answer with data by day 60?" | Speaks to a data-driven peer in his own terms, and surfaces what he scores first | [generic] |
| R5 | "With bundling by a larger vendor a competitive concern, which renewal or expansion signals are you watching most closely?" | Connects to the threat in your research note and invites him to share his own analysis | [grounded] |
| R6 | "How are Compass and the other new line being weighed against the profitability priority in planning?" | Shows you read the priorities as a trade-off, not a list | [grounded] |

## Prohibited claims

Claims this pack will not coach. Each has its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has quota-setting or sales-ops experience, or that the volume targets were quotas | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I have no classic sales-ops or quota-setting experience." No answer slot |
| Designed partner motions | Inflated form of F4 | F4's quote at its own scope. The limit is the pack's observation: the quote says a revenue model used in negotiations, not partner-motion design. The A4 and D3 slots stay inside the model |
| Has pricing or monetization-model experience | Inflated form of F4 | F4's quote at its own scope. The quote says a revenue model, not prices |
| Drove or owned the ~$400M ARR uplift | Inflated form of F2 | F2's quote: proposed, and credited with. The A1, A2 and F1 slots stay inside it |
| Has run go-to-market for a product launch or a new product line | Inflated form of F1 | F1's quote at its own scope: product strategy and ops |
| Has built, launched or evaluated AI products | Inflated form of F6 | F6's quote at its own scope: use of AI tools |
| Ran independent analyses in SQL and Tableau | Inflated form of F3 | F3's quote at its own scope: skilled in SQL/Tableau. A3's slot allows that no such analysis exists |

## Sources

**Provided material:** your message, covering the role and company, the JD highlights, Priya's background in your words, Dan's profile as you described it, and your research note on Northwind's three priorities (enterprise expansion, the Compass AI copilot launch, reaching profitability) and the bundling threat. No full JD, no CV, no recruiter guidance, no dossier (`tuesday-dossier.md`) was present. Nothing in your note's age could be checked.

**Searches sent:**

- "Northwind Data company values principles": refused
- "Northwind Data interview process strategy GTM role": refused
- "Dan Kovac Northwind Data Director Sales Strategy": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The call was refused. It would have supplied official value names. No values-style round is detected, so no VAL bank or cheat sheet was built |
| 2. Northwind Data interview process | unavailable | The call was refused. It would have documented the loop. Persona weights rest on your description of one peer conversation |
| 3. Northwind Data strategy / recent news | skipped | Your research note already supplies the priorities and the competitive threat that feed C1 to C3 |
| 4. Dan Kovac, Northwind Data | unavailable | The call was refused. It would have checked Dan's public footprint. The interviewer read rests on your description of his profile |
| 5. Representative Senior GTM Strategy Lead JD | skipped | The JD highlights you supplied fix the fit snapshot rows and the JD-tagged questions |

## Upgrade menu

- The full JD text → mid-list requirements (named tools or methods) get their own rows and questions, and more rows become `[grounded]` instead of resting on highlights
- Priya's CV → the evidence cells quote the CV instead of your summary, and several rows can rise in confidence where an inspectable artifact exists: the revenue model file or its deck, the memo on the annual volume targets, the document behind the store-surface proposal, a Tableau workbook
- Recruiter guidance on focus areas, format or any pre-declared deliverable → focus-area coverage and a build section for any graded assignment (usually one email to the recruiter)
- Priya's own words on the answer slots (F1 to F6, A1, A2, A4, B3, D2, E2, F1) → those rows are rewritten from quotes instead of slots. Say them outside a drill, in her own words
- Dan's profile text or link → a sharper interviewer read and tailored reverse questions, since the footprint search was refused
- Search access and a deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → Northwind's published values by name, loop reports, a grounding brief on recent strategy, and a stronger CO and CASE bank. Offered once
- Prep time available → a prioritized schedule sized to it
- A `tuesday-dossier.md` from a prior job-underwriter run, if one exists → verified evidence and a named top objection, replacing the inferred ones here
