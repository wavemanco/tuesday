# Interview prep pack: Senior GTM Strategy Lead, Emerging Products at Northwind Data

**Candidate:** Priya. **Interviewer:** Dan Kovac, Director of Sales Strategy, her peer (both report to the same VP). **Format:** one 60-minute conversation.
**Built on:** the JD highlights, the candidate summary, the description of Dan's profile and your research note, all from your message. No web research ran (see Sources), and I did not have the full JD text.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

**Highest-ROI prep: D1.** Dan owns sales strategy, and your notes say "No classic sales-ops or quota-setting experience." Some version of D1 will be asked, so rehearse it until it is boring. Then rehearse B1 and B2, because Dan describes himself as data-driven and the ~$400M figure is the number he can probe.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Past behavior against the company's published values. No question carries this tag here: no values page was read and no values-style round is documented for this session |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny, and what was actually you |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether you can think at Northwind's altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

Each question has one primary tag. When a second tag applies, the rationale says so.

## Fit snapshot

The requirements are quoted from the JD highlights in your message. Every evidence quote is from your notes on Priya. No row is a hard gate, because none of the material states a legal, credential, location or pay term. The full JD might add one.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "9 at a large consumer-tech company in product strategy & ops" — the coach's notes; "proposed a store-surface change credited with a ~$400M ARR uplift" — the coach's notes | medium | [grounded] | transferability | Your material says product strategy and ops, and a proposed change with a credited result. It does not say go-to-market ownership. Words: "I proposed a store-surface change that was credited with a ~$400M ARR uplift." Answer slot: the JD's own-the-strategy line makes a probe on taking products to market likely. If any of your work took a product or line to market, say which and which part was yours. If none did, or it was not yours, say so plainly and stay with the strategy and ops work |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | none given | none | [grounded] | discovery | The material does not show this. Strong evidence would be an analysis of where customers started, grew, stalled or left, with what it found. Answer slot: the JD names four stages, so expect a probe on which you have worked. If any analysis of yours looked at one of them, say what it was and what it found. If none did, say so plainly and say how you would start in SQL on Northwind's data, as a plan and not a past |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — the coach's notes | medium | [grounded] | none | The tool claim is covered, but nothing inspected sits behind it, and "independent" is the JD's word. Expect Dan to test it live. Say it in the quote's terms: "I'm skilled in SQL and Tableau." Answer slot: if you have taken an analysis from question to conclusion yourself, name it and be ready to walk it end to end. If someone else did the querying, or you used the tools less than "independent" implies, say so plainly |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — the coach's notes | medium | [grounded] | transferability | The material shows the model and that it was used in negotiations. It does not show the design of a partner motion. Words: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: "required" makes a probe likely. If any part of how a partnership was structured or run was yours to design, say which part and how you decided. If none was, or it was not yours, say so plainly and stay with the model |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — the coach's notes | medium | [grounded] | none | The quote reaches the requirement. Lead with it in its own terms: you set annual volume targets, with consensus across orgs. Answer slot: expect a probe on how the consensus was reached. If there was disagreement, say what about and how it landed. If there was none, or part of the process was not yours, say so plainly |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — the coach's notes | medium | [grounded] | none | The quote reaches the plus at the level of use. Words: "I use AI tools daily." Answer slot: expect a probe on which tools and for what. Name them and what you do with them. The material shows use, not building or launching AI products, and the words stay at use |
| F7 | "Director of Sales Strategy" — Dan's title, your message (the peer's home territory, not a JD line) | "No classic sales-ops or quota-setting experience." — the coach's notes | none | [grounded] | capability | A gap wording cannot close, and your notes state it. Words: "I don't have classic sales-ops or quota-setting experience." Then how you would learn it, said as a plan and never as a past. Your notes keep volume targets and quota-setting apart, so F5's quote stays under its own name |

## Reading the interviewer

Built only from the description of Dan's profile in your message. I could not read the profile itself, his talks or his writing, because search was refused.

| Signal (your description) | What it implies | Where it shows up |
|---|---|---|
| Self-described "relentlessly data-driven" | Every figure gets probed to its assumptions, and he may ask you to work a number live | B1, B2, B3, B4, B5 |
| Career spine in pricing and monetization | Cases will tilt toward pricing, packaging and unit economics, which is his native language. Go in with a stated hypothesis and invite correction | C2, C3 |
| One early-stage-startup chapter | He may probe how you work with less structure. Your material has nothing on this yet, so a plain answer or a question back is safer than a bluff | Upgrade menu |
| Peer, same VP | He is pricing what you cost and add to his work: seam, reciprocity and disagreement style | A1 to A5 |

**Mirror opportunity.** Dan's vocabulary is pricing and monetization. F4's quote, "built a partner-level revenue model used in carrier negotiations", sits near it. This is the pack's own observation and `[inferred]`, so use his words when you ask about his work and do not claim pricing experience. No shared career jump is established, so none is offered.

## Persona table

Relationship prior: peer. Then adjusted by Dan's signals, then by the loop. Your words establish a single 60-minute session with one interviewer, so persona weights rest on that. No values-style round is documented.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Peer Evaluator | Seam-splitting, "what would you need from me", credit and disagreement | High (5 questions). Peer prior; he is judging what you add to or take from his team | Reciprocity framing. Propose seam principles instead of pretending to know the seam. Disagreement stories with spine and tact | A |
| Data-Driven Prober | Reads claims line by line and goes two levels deeper | High (5). Peer prior, raised by "relentlessly data-driven" | Know what you can and cannot say about how each number was counted. Name the weakest assumption first. Offer to walk through an analysis end to end | B |
| Case / Strategist | Live problems on the new lines, Compass, bundling and profitability | Medium (3). Not a hiring-manager round, but pricing and monetization tilt his cases | Clarify, objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise politely | C |
| Skeptic | Probes the gaps: sales ops, quotas, partner-motion design, consumer to B2B | Medium (3). Your notes state a gap in his territory | Rehearse the one predictable objection. Bridge only from stated adjacent evidence. Candor over bluffing | D |
| Conversational | Friendly opener, AI small talk | Low (2). Opens a 60-minute session, but not the dominant mode | A 90-second arc. Treat casual AI questions as scored | E |
| Pressure | Time-boxed "why you" and attribution challenges | Low (2). No peer or profile signal for a stress style | Pause, restate, hold through two follow-ups, concede specifically | F |
| Values / Behavioral | Scenario probes against published values | Low, no separate bank. No values source or values-style round was found. A3 and A4 cover the collaboration scenarios | Selection scaffolds in A3 and A4 | none |

## Question banks

Provenance holds the quotes the guidance rests on. A guidance clause about your past rests on those quotes and nothing else.

### A. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where's the seam between your GTM work on the new lines and what my team already does, and what happens when we disagree?" | JD | [grounded] | You can't know the seam yet, so offer principles. First, ask what his team owns today. Second, agree which team's definition governs any shared metric. Third, take a number you can't settle to the VP you both report to, with both sets of data on the table. Finish by saying what you would not do: decide the seam alone | Peer prior puts the seam question first. JD tag because it scores the cross-functional requirement (F5); the disagreement half is Peer Evaluator material |
| A2 | "What would you need from me in your first 90 days, and what would I get from you?" | JD | [grounded] "skilled in SQL/Tableau" | Give the ask first: his team's definitions of land, adopt, expand and renew, and access to the data behind them. Then the give: "I'm skilled in SQL and Tableau," used on the new lines' data. Keep the give to what the quote says, and ask him what would help most | Reciprocity is what a peer is pricing. JD tag for the own-the-strategy requirement (F1), with F3 as the give |
| A3 | "How do you handle credit when work spans teams?" | EXP | [grounded] "set annual volume targets with cross-org consensus"; "proposed a store-surface change credited with a ~$400M ARR uplift" | Use "we" for context and "I" for what you did. Your two quotes already hold the accurate verbs: you set the targets with consensus, and you proposed the change that was credited. Answer slot: if credit on either was ever contested, say what happened and what you did. If it was not, say so plainly and describe how you share credit in general | A standard collaboration probe from Persona 7. EXP because it tests attribution honesty on F1 and F5 |
| A4 | "Tell me about a time you and a peer team disagreed on a number or a plan and had to land it." | EXP | [grounded] "set annual volume targets with cross-org consensus" | Open prompt: pick the instance. If it is the volume-target work, say what the disagreement was, what position you held and where it ended. Your quote says consensus, not that anyone disagreed, so the disagreement is yours to supply or to say there was none. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Disagreement with an equal is the peer scoring item. EXP because it asks for a real instance; VAL is not used because no values source exists |
| A5 | "If a new line needs a motion that doesn't fit how we sell today, how do you make that case to me?" | CASE | [generic] | Clarify first: what "how we sell today" looks like for his team. State a hypothesis early, since he is data-driven. Propose a bounded pilot with one metric and a decision date. Concede what an exception costs his team. The question needs no claim about your past | A live seam problem that tests whether the hire adds to his load. CASE because there is no past to defend |

### B. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Your store-surface proposal was credited with a ~$400M ARR uplift. Walk me through how that figure was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Say what the quote says: "I proposed the change, and the uplift was credited to it." Four answer slots, each in your own words: how it was counted; what it is sensitive to; the assumption you would defend least; and which part was yours. For any of them, "I don't know how that part was counted" is an honest answer. Name the weakest assumption before he asks | The headline number is the magnet for a Prober. F1 is the evidence. EXP because it tests whether the figure survives |
| B2 | "How would you separate the effect of your change from everything else that was moving ARR at the time?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot: this is the level-two follow-up on B1. If you know how the credit was determined, say so in your own words. If someone else determined it, or you don't know, say so plainly and return to the quote: you proposed the change and the uplift was credited to it. Do not supply a method you cannot repeat under a third question | The second level of the same probe. EXP for the same reason as B1 |
| B3 | "Walk me through the partner-level revenue model you built." | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story-map only what the quote carries: you built it, it was partner-level, and it was used in carrier negotiations. Answer slot: the JD's partner-motion line and his data focus make a probe on what drove the model likely. If you know its key drivers, name them in your own words. If you did not build those parts, or don't remember, say so plainly. Offer to walk through it end to end | F4 is the only partner evidence. EXP because it asks you to defend a built artifact; JD is the second tag |
| B4 | "Tell me about an analysis you ran yourself in SQL or Tableau, start to finish." | JD | [grounded] "skilled in SQL/Tableau" | Open prompt: choose one you can walk end to end: the question, the data, the logic of the query, the conclusion and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I'm skilled in SQL and Tableau", or how you would approach one | The JD says "independent analysis". F3 is thin, so this is a free miss if unrehearsed. JD tag because it scores a stated requirement |
| B5 | "A new product's land numbers look healthy but expand is flat. What do you pull first?" | JD | [generic] | Clarify definitions of land and expand before cutting anything. Then segment (cohort, size, channel), decide what you would pull in SQL, name the metric tree, and say what would change your mind. Challenge one premise, for example whether "flat" is real or a lag in definition. The question needs no claim about your past | Covers the whitespace requirement (F2), which has no evidence. JD tag with CASE delivery |

### C. Case / Strategist

Company facts here come from your research note, which I could not verify.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the go-to-market for Compass. What do you need to know first?" | CASE | [grounded] | Ask first whether Compass is one of the two new lines; nothing here says it is. Then objective, segmentation (new versus existing customers, enterprise first, given your note on enterprise expansion), approach, metrics and risks. Raise how it is priced and packaged: add-on, tier or bundle. The question needs no claim about your past | Compass is one of the three stated priorities. CASE with CO as the second tag. Differentiator question for strategy fluency |
| C2 | "A much larger platform vendor starts bundling something that overlaps one of our new lines. What do you do in the first 30 days, and what do you refuse to do?" | CO | [grounded] | Bring the consensus item to show grounding: bundling is the stated competitive threat. Then one divergent thesis of your own and an anti-pick, the one thing you would decline, for example a reflex you think would cost margin. Treat price versus packaging versus partnering as the decision, and use his pricing vocabulary | Bundling is the named threat, and any prepared candidate can recite it, so the question rewards divergence. CO because it scores strategic fluency |
| C3 | "Profitability is a priority and a new line is losing money. Where do you look first: pricing, packaging or cost to serve, and how would you decide?" | CASE | [generic] | Clarify whether the loss is in the line or its mix. Then segment contribution by customer type and decide with a stated test. Go in with a hypothesis and invite correction, since pricing is his territory. Make no pricing-experience claim; the material has none | Profitability is a stated priority, and his career spine tilts cases here. CASE because it is a live problem |

### D. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "I don't see sales ops or quota-setting in your background. How would you handle that part of this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus" | **The highest-ROI rehearsal.** Level 1, acknowledge: "I don't have classic sales-ops or quota-setting experience." Level 2, adjacent at its own scope: "I set annual volume targets with cross-org consensus." If he presses on the difference, say what differs only in your own words. If you haven't worked with a number a seller carries, say so plainly. Level 3, the plan: pick two things you would actually do, such as sitting through one planning cycle with his team and asking for the documents. Hold the same position through every follow-up. Never blur targets into quotas | The one objection most likely to be asked. F7 is the stated negative. JD tag because it scores the sales-strategy half of the role in his territory. The Skeptic stem fits |
| D2 | "The JD asks for partner-motion design experience. What does yours look like?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Say what the quote says: "I built a partner-level revenue model that was used in carrier negotiations." Answer slot: if any part of how a partnership was structured or run was yours to design, say which and how you decided. If none was, or it was not yours, say so plainly and stay with the model. Never describe a design you didn't do | "Required" in the JD makes this likely. F4 is the evidence. JD tag; the second pass on B3 |
| D3 | "You've spent nine years in consumer tech. Why B2B data infrastructure, why Northwind, why now?" | CO | [grounded] "9 at a large consumer-tech company in product strategy & ops" | Three beats, each in your own words: what you want next, why this company, why now. The pack can't supply your reasons. For "why this company", pick one of the three stated priorities only if it genuinely pulls you. If the reasons are still forming, say that rather than inventing a through-line | The Skeptic's motivation check. CO because the "why here" half scores homework; EXP would also fit |

### E. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | A 90-second arc with three beats: the two consulting years, the nine years in product strategy and ops, and why this role, in your own words. End on analysis, since he is data-driven. Don't add roles, scope or titles beyond the quote | The opener is scored even though it is casual. EXP because it checks consistency of your own history |
| E2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" | Say what you use daily and what you do with it. That is the claim, and it stays at use. Answer slot: if he asks about building, say plainly whether you have and what your part was. If you haven't, say so and say what you would want from a copilot as a user. Do not stretch use into building or launching AI products | The persona stem for the JD's AI plus; Compass makes it live. F6 is the evidence |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you over someone who has run a sales-ops function?" | JD | [grounded] "No classic sales-ops or quota-setting experience."; "set annual volume targets with cross-org consensus"; "skilled in SQL/Tableau"; "built a partner-level revenue model used in carrier negotiations" | Hold, then concede. Pause and restate the question. Concede first: "I don't have classic sales-ops or quota-setting experience." Then hold on three quoted facts, no more: the volume targets set with cross-org consensus, SQL and Tableau skill, and the partner-level revenue model used in carrier negotiations. Hold through two follow-ups. Never claim to be better at what you haven't done | Persona 2's standard stem, aimed at the F7 gap. JD tag; the hold is only what the quotes carry |
| F2 | "That ~$400M ARR result — how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change, and the uplift was credited to it." Hold that through two follow-ups. Concede specifically: say which part was yours and which was not, in your own words. Never fold on the core claim to restore harmony, and never promote "proposed" into anything larger | The attribution probe on the one big number. EXP because it scores honest attribution |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity with a peer: it shows you are thinking about his load, and it surfaces his actual priority |
| R2 | "Your background is mostly pricing and monetization. How has that shaped how you'd want the new lines packaged and sold?" | Ties to his own career path, from your description of his profile. It moves the conversation from interrogation to shared craft |
| R3 | "What did you take from the early-stage-startup chapter that you still use here?" | Also tied to his path. It invites a story instead of an evaluation |
| R4 | "How does your team define and measure land, adopt, expand and renew, and where do you trust the numbers least?" | Speaks to a self-described data-driven interviewer, and fills the gap in your own F2 material |
| R5 | "Where do you see the seam between what I'd own on the two new lines and your team's work, and what's the one thing you'd want settled in my first 30 days?" | Takes A1 from his side and shows you are planning the working relationship |
| R6 | "Is bundling by the larger platform vendor showing up yet in how deals are priced or lost?" | Uses the stated competitive threat in his territory and asks for evidence, not opinion |
| R7 | "Of enterprise expansion, Compass and profitability, which pulls hardest on your team's time right now?" | Shows you know the stated priorities and asks where they bite |

## Prohibited claims

Built from the fit snapshot before the banks. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Has sales-ops or quota-setting experience, or that the volume targets were quotas | Negative the candidate stated, F7 | The plain acknowledgment: "I don't have classic sales-ops or quota-setting experience." No slot |
| Drove, generated or delivered the ~$400M ARR uplift | Inflated form of F1 | F1's quote at its own scope: you proposed the change, and the uplift was credited to it. The limit is the pack's observation: the material says "proposed" and "credited" |
| Negotiated or led the carrier negotiations | Inflated form of F4 | F4's quote at its own scope: the model was used in the negotiations. The limit is the pack's observation: the material says the model, not the negotiating |
| Has built or launched AI products | Inflated form of F6 | F6's quote at its own scope: you use AI tools daily. The limit is the pack's observation: the material says use |

## Sources

**Provided documents:** your message (JD highlights, the candidate summary, the description of Dan's profile, and your research note on Northwind's three priorities and the bundling threat). I could not verify the research note, and its company facts are marked `[grounded]` only to that note.

**Searches sent (all refused):**
- "Northwind Data company values": refused
- "Northwind Data interview process strategy lead": refused
- "Northwind Data strategy Compass AI copilot enterprise expansion profitability": refused
- "Dan Kovac Director of Sales Strategy Northwind Data": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Northwind Data values` | unavailable | Search refused. It would have supplied published value names for VAL questions and a values cheat sheet; none exists in this pack |
| 2. `Northwind Data interview process, strategy lead` | unavailable | Search refused. It would have confirmed loop structure and persona weights; they rest on your description of one 60-minute session instead |
| 3. `Northwind Data strategy / recent news` | unavailable | Search refused. It would have grounded CO and CASE questions in current facts; your research note stands in |
| 4. `Dan Kovac Northwind Data` | unavailable | Search refused. It would have enriched the interviewer read and reverse questions; both rest on your description of his profile |
| 5. representative `Senior GTM Strategy Lead` JD | skipped | The JD highlights you supplied fix the requirement rows and JD-tagged questions |

## Upgrade menu

- Allow web search, then the company's values page, loop structure, current strategy and Dan's public footprint → published value names (and a values cheat sheet if a values round turns up), verified Compass and bundling facts in place of the unverified research note, and an interviewer read from his talks and writing
- The full JD text → the requirement rows in the fit snapshot become full-text quotes, and any hard gate (location, authorization, pay) would be surfaced
- Your answers to the answer slots, as plain statements outside any drill, on F1 (taking a product to market), F2 (a lifecycle analysis), F3 (an analysis you ran yourself), F4 (partner design), F5 (how consensus was reached) → those rows become quoted evidence and the matching guidance becomes story-mapped
- Anything the recruiter said about focus areas or deliverables → graded-deliverable sections if a POV, presentation or take-home was announced
- Any story of working with less structure, such as the startup-pace probe → a bank row for the early-stage question Dan's profile suggests
- A `tuesday-dossier.md` from an earlier evaluation of this role → a pre-ranked objection and verified evidence in place of the inferred ones here
