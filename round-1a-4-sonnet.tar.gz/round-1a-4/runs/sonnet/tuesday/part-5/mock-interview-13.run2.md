Searches weren't permitted, so I'm building the pack from what you gave me and saving it now.
Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-5/rooms/case-13-denied-0e1a8c7f/quillmoor-diagnostics_operations-coordinator_interview_pack.md`.

I built it from your message alone, for a 30-minute recruiter screen. I had no CV, and my web searches were refused, so the Quillmoor-specific parts rest only on the advert. Searches were refused for the values page, strategy and news, and Hannah's public profile. I skipped the interview-process and sample-JD searches on purpose, because her message and your advert already cover them. The pack has 18 questions, a fit snapshot, a prohibited-claims list, 7 reverse questions and a sources table that shows what was refused.

- **Pay, hybrid and your reason for moving:** these are in your own words, whole. That means "I'm hoping for £42,000", two days is fine with three as your ceiling, and the Reading explanation. Nothing is added to them.
- **Most likely probe (B2):** "How close is coordinating production schedules between planning, the warehouse and QA to what you do now?" Your material says delivery scheduling and chasing suppliers, so B2 keeps you to that and doesn't stretch it.
- **SAP (B3):** the pack gives you "I haven't used SAP" and leaves a slot for whether you work in the in-house stock system.
- **Excel and weekly dispatch reporting (C2, C3):** your message doesn't say whether your spreadsheet is Excel or whether you produce dispatch reports. Both have answer slots for you to fill truthfully.

Say the word and I'll play Hannah on B2, the question the pack names as your highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to a Word document.

Two questions that would sharpen it:
1. What is your notice period? Your message doesn't give it, and she'll ask. Your answer goes into A4 in your own words.
2. Can you paste your CV, or just the lines for your current role? I built the pack without one, and it would firm up the Excel, reporting and ERP rows.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, a 30-minute phone call, Thursday at 2pm. Hannah Lowther, Talent Partner, rings the mobile number on your application.
**Her stated agenda** (from her LinkedIn message): your salary expectations, your notice period, how the hybrid pattern would work for you, and what is prompting a move. Then she tells you about the team and the next steps.
**Built on:** your message only, meaning the advert text, her message and your own summary. No CV was supplied and no web research ran (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows a company's published values |
| EXP | Whether your CV and message claims survive scrutiny |
| JD | Whether you can do the listed job, gaps included |
| CO | How much homework you have done on the company |
| CASE | How you structure a live problem from the role |

Question IDs run by persona (A1, A2, B1 and so on) so a drill can name them. Where guidance says answer slot, it is an instruction for the interview, not a question for you now.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: four years as a logistics coordinator at a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries and chasing suppliers, not production schedules, planning or QA, and the words stay there: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so a probe on production scheduling is likely. If any of your scheduling involved production, planning or QA, say which and how, in your own words; if none did, or it was not yours, say so plainly and stay with the deliveries and the chasing |
| F3 | "track supplier deliveries and chase late orders" — the advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | No gap in role-relevant terms: your sentence says you chase suppliers when orders slip. A named action beats an adjective, so lead with the chasing and the three depots as you said them |
| F4 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | No gap, but a figure with nothing inspected behind it, so expect the defend-the-number probe (C1). Say it as your sentence says it: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year |
| F5 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | Your sentence says a spreadsheet, and whether it is Excel, and what it does, is not in your material. Answer slot: if it is in Excel, say what it does, in your own words; if it is another tool, or lighter than the advert's word confident suggests, say so plainly and stay with the spreadsheet you rebuilt |
| F6 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system." — your message | low | [grounded] | transferability | You stated the SAP negative, so the words are yours: "I haven't used SAP." The in-house system is adjacent at its own scope: your sentence says the company runs it, not that you work in it or that it is an ERP. Answer slot: the advert says or similar, so expect what do you use. If you work in that system, say what for, in your own words; if you do not, or it is not an ERP, say so plainly. Any ramp plan is a plan, said as one, and only if true for you |
| F7 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material is silent on reporting. Answer slot: if you produce any regular report on deliveries or dispatch, say what it covers and how often, in your own words; if you do not, say so plainly and return to scheduling deliveries and chasing suppliers |
| F8 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | No gap, and the gate is shown met. Keep both halves of your own sentence: two days is fine, and three is your ceiling. The ceiling stays a ceiling, never a preference |
| F9 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | No gap against the band: the figure sits inside it, which is the pack's observation. Say it as you said it, with nothing added: no range, no floor, no room to move |
| F10 | "what's prompting a move" — Hannah Lowther's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | No gap. The sentence is the whole answer: say it whole and plainly, and if she presses, your own words were the sentence in the quotes |
| F11 | "your notice period" — Hannah Lowther's message | none given | none | [grounded] | hard_gate | Your material does not establish it. The pack cannot supply it, and A4 holds it as an instruction |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly opener, then her four stated topics in a casual register | Highest. The recruiter-screen prior is Conversational plus a light Skeptic, and her message sets an agenda of pay, notice, hybrid and the reason for the move, all in that register | A pre-scripted 90-second arc (A1), and each logistics answer in your own words |
| Skeptic | Quiet probing of the thin rows and the motive | Second. Above the light prior because her list includes what is prompting a move, and because F2, F6 and F7 carry the least in your material | Rehearse B2 until it is boring; every bridge is a quote at its own scope or an answer slot |
| Data-Driven Prober | A light check on the one figure you gave | Mid. One headline figure is on the table (F4); a closer probe is more likely from a hiring manager later | Know what you can and cannot say about how the figure was counted (C1) |
| Case / Strategist | A short what-would-you-do on a late delivery | Low. Nothing in her message points to it; two rows as insurance | Clarify, then objective, options, who you tell, what you record |
| Peer Evaluator | Seam questions about working with planning, the warehouse and QA | Low. No peer is on this call; the advert's three-team line makes it likely in a later round | Offer seam principles instead of pretending to know the seam |
| Pressure | A compressed why you | Low. Nothing in her message suggests it; two rows for the sixty-second version | Hold your quoted beats through two follow-ups, then concede exactly what the quotes show |

No values-style round is detected: her message names none, and no values page was read. VAL questions are not built.

## Question banks

### Bank A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So — walk me through the journey." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Story-mapped on three beats, each in the quote's own words: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for the three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Say fell, as your sentence does. Anything before the wholesaler is outside your material: say it only in your own words | F1, F3 and F4 supply the beats. EXP because the biography question tests the CV's claims in sequence, and a casual opener is still scored |
| A2 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your own words, whole and plain: that is the entire answer. If she presses, your own words were: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Nothing added | F10 is on her stated agenda. EXP because it checks that your motive and your story stay consistent |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000." | Your own words: "I'm hoping for £42,000." The advert's band is "£38,000–£44,000", so the figure is inside it. Nothing added: no range, floor or flexibility. If she asks what you earn now, you can decline to give it and steer back to this role's band and your figure for it; that is a line to prepare, with no figure in it | F9 is the first item on her list. JD because pay is a term of the listed job |
| A4 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, in your own words, and stop there. If you are unsure what it is, say you will confirm it rather than offering a figure | F11 is the one logistics term your message leaves open, so the pack cannot fill it. JD because notice is a term of the job |
| A5 | "How would two days a week at Avonmouth work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your own words, both halves: two days at Avonmouth is fine, and three is your ceiling. If she asks about a third day, your own words were: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." Keep the ceiling as a ceiling | F8 mirrors the advert's hybrid line. JD because the pattern is a term of the listed job |

### Bank B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What drew you to this role and to us?" | CO | [generic] "I schedule deliveries for our three depots and chase suppliers when orders slip." | A selection scaffold. Name one line of the advert that matches what you want to do, quoting it. Say what you have read about Quillmoor beyond the advert, and if it is only the advert, say so plainly. If no line comes to mind, say so plainly, then give the nearest thing your material carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." | The advert asks for the most where F2 and F6 are thin. CO because it tests homework depth, and with research unavailable the company side rests on the advert alone |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. How close is that to what you do now?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Answer slot: if any of your scheduling involved production, planning or QA, say which and how, in your own words; if none did, or it was not yours, say so plainly and describe the deliveries and the chasing. Hold through two follow-ups by returning to the deliveries, never by adding to them | F2 is the widest gap against the advert's first line, so this objection arrives in some form. JD because it scores that line |
| B3 | "Have you worked in SAP or a similar ERP?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Start with your own words: "I haven't used SAP." Answer slot: the advert says or similar, so expect what do you use. If you work in the in-house stock system, say what you use it for, in your own words; if you do not, or it is not an ERP, say so plainly. Any ramp plan is said as a plan, only if it is true for you | F6 is the advert's plus. JD because it scores the stated preference |
| B4 | "Which part of this advert would be your biggest learning curve?" | JD | [generic] | A selection scaffold. Read the advert's lines aloud to yourself and pick the one that is true for you; the pack's observation is that your material carries least for F2, F6 and F7. If nothing comes to mind, say so plainly, then say how you would find out. Name the line, then say what you would do first, as a plan | Recruiters ask the day-one weakness question to test candour. JD because it scores the advert's own list |

### Bank C: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You mention discrepancies fell by about a third. How was that counted?" | EXP, JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Say the figure as your sentence does. Four slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly | F4 is your one headline figure. EXP because it tests attribution, and JD because it maps to keeping stock records accurate |
| C2 | "How would you describe your Excel?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: the advert says confident with Excel, so expect a probe on what you do in it. If the spreadsheet you rebuilt is in Excel, say what it does, in your own words; if it is another tool, or lighter than the question assumes, say so plainly and stay with the spreadsheet you rebuilt. Say confident only if you are | F5 is low confidence, so this is a clarify note and not a claim. JD because it scores a stated requirement |
| C3 | "The role reports weekly on on-time dispatch. Is that something you've done?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Answer slot: if you produce any regular report on deliveries or dispatch, say what it covers and how often, in your own words; if you do not, or there is no regular report, say so plainly and return to scheduling deliveries and chasing suppliers | F7 is silence in your material. JD because it scores a stated responsibility |

### Bank D: Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you on Monday that a delivery the warehouse is waiting for will be three days late. What do you do?" | CASE, JD | [generic] | Structure it aloud: what you would ask first (what the delivery is for, who is waiting, whether anything else can cover it), what you would do to the schedule today, who you tell among planning, the warehouse and QA, and what you record. It needs no claim about your past, so the guidance makes none | A live problem from the advert's chase late orders line. CASE in delivery, JD in content |
| D2 | "Two orders slip in the same week and you can only chase one properly first. How do you decide?" | CASE | [generic] | Say your criteria aloud: what each order holds up, who is waiting, the cost of the delay, and what each supplier can commit to. Make the call, then say who you tell. Present it as how you would reason, not as a past choice | Tests prioritisation, which the advert's coordination work implies. CASE because it is a live decision |

### Bank E: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to get two teams to agree on a schedule." | EXP | [generic] "I schedule deliveries for our three depots and chase suppliers when orders slip." | A selection scaffold. Pick a time two teams wanted different things from a schedule; it needs a named stake, what each wanted, and what was agreed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." | The theme comes from the advert's line about coordinating between planning, the warehouse and QA. EXP because it asks you to choose a real instance |
| E2 | "Where would you expect the seam to be between your job and the warehouse team's, and what happens when you disagree?" | JD | [generic] | Offer principles, not a claimed seam: ask where schedule ownership sits, how changes get told to each side, and what a shared view of the schedule would look like. It needs no claim about your past | Peers price what the hire does to their own load. JD because the advert places the role between teams |

### Bank F: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "In sixty seconds: why you for this role?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." "Never used SAP — we run our own in-house stock system." | Hold: three beats, each in its quote's own words, in the order of A1. Hold through two follow-ups by returning to those beats, not by adding to them. Concede exactly what your own sentence says if SAP comes up: "I haven't used SAP." Do not tell her what the beats prove; let her draw it | F1, F3, F4 and F6 are the rows she will weigh. JD because it scores fit against the advert |
| F2 | "Why you over someone who already works in manufacturing?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." | Hold on what the quotes carry: four years as a logistics coordinator at a building-supplies wholesaler, and the scheduling and chasing. The concession is that same sentence at its own scope: your experience is at a building-supplies wholesaler. Do not claim manufacturing experience | F1 is the evidence, and the sector is where this question presses. JD because it scores the role-fit |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in operations or logistics coordination" | A1, F1, F2 |
| "Coordinate production schedules between planning, the warehouse and QA" | B2, B4, E1, E2 |
| "track supplier deliveries and chase late orders" | D1, D2 |
| "keep stock records accurate" | C1 |
| "confident with Excel" | C2 |
| "ERP experience (SAP or similar) a plus" | B3 |
| "report weekly on on-time dispatch" | C3 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A5 |
| "£38,000–£44,000" | A3 |

## Reverse questions

Ask only what she has not already covered; she has said she will tell you about the team and the next steps.

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work with day to day across planning, the warehouse and QA, and how is the team set up?" | The advert names those three teams, so it shows you read the role |
| R2 | "What system does the team use for stock and production records, and what would onboarding to it look like?" | Raises the ERP row as a question about the job, in your own voice, rather than as an apology |
| R3 | "How is on-time dispatch reported today, and who reads the weekly report?" | Shows interest in the reporting line of the advert and tells you what F7 would mean in practice |
| R4 | "Which two days at Avonmouth would the team expect, and who sets them?" | Makes the pattern concrete while your own ceiling stays yours |
| R5 | "What would a good first three months look like?" | Moves the call from screening toward the work |
| R6 | "What are the next steps, who would I meet, and when would you expect to know?" | Closes the call on a clear next move |
| R7 | "Is there anything about my background you would like me to expand on?" | Gives her the chance to surface a doubt about F2 or F6 while you can answer it |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP | A negative you stated, F6 | "Never used SAP — we run our own in-house stock system." The plain acknowledgment: "I haven't used SAP." No slot |
| The in-house stock system is an ERP you work in | Inflated form of F6 | F6's quote at its own scope. The limit is the pack's observation: your material says the company runs the system, not that you work in it or that it is an ERP. B3's slot stays inside that |
| Has scheduled production, or worked with planning and QA | Inflated form of F2 | "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation: your material says deliveries, not production. B2's slot stays inside the deliveries |
| Is confident with Excel | Inflated form of F5 | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The limit is the pack's observation: your material says a spreadsheet, not Excel. C2's slot stays inside the spreadsheet |
| The rebuild cut discrepancies by a third | Inflated form of F4 | The F4 quote at its own scope: discrepancies fell by about a third over a year, and you rebuilt the spreadsheet. The limit is the pack's observation: the sentence does not say the rebuild caused the fall |
| Is flexible on more than three days at Avonmouth | Contradicted by your quote, F8 | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |
| Would consider the Reading relocation | Contradicted by your quote, F10 | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." |

## Sources

Provided documents: your message, which holds the advert text, Hannah Lowther's LinkedIn message and your own summary. No CV was supplied. No dossier was present.

Searches sent, all refused:
- `Quillmoor Diagnostics values`: refused
- `Quillmoor Diagnostics Avonmouth news strategy`: refused
- `Hannah Lowther Quillmoor Diagnostics`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Would have fed B1 and a published-values check; no values-style round is detected, so no cheat sheet was due either way |
| 2. `Quillmoor Diagnostics interview process operations` | skipped | Her message fixes this session: one 30-minute call with a stated agenda, so persona weights follow it |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Would have grounded B1 and sharpened R1 to R7; the company side of the pack is generic |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Would have fed an interviewer read; that section is absent |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, or the lines for your current role → F2, F5 and F7 may move from discovery or transferability to quoted evidence, and A1 and F1 get sentences beyond your message
- Your notice period → A4 becomes your own quoted words, and F11 stops being an open gate
- Whether your stock-count spreadsheet is in Excel, and what you use the in-house system for → F5 and F6 rows get your quoted answers instead of slots
- Any regular delivery or dispatch report you produce → F7 gets evidence, and C3 becomes a story-mapped answer
- Web search permission → rows 1, 3 and 4 of the accounting move from unavailable, B1 becomes company-specific, and a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) becomes available
- Hannah Lowther's public professional profile, if you can paste it → an interviewer read and one reverse question tied to her path
- A `tuesday-dossier.md`, if you have one from an earlier role assessment → verified evidence and its prohibited claims, instead of this pack's locally built list
