I've run five searches on the district, its hiring process, its literacy plan and the principal. Next I'm opening the district's beliefs page and its hiring page in full.
Your prep pack is saved at `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-5/rooms/case-9-canned-8845d46e/halvering-elementary_fourth-grade-teacher_interview_pack.md`. It has 20 questions in six persona banks, six questions for you to ask the panel, and a fit table of your resume against the role.

I built it as one 45-minute panel with the principal and two fourth-grade teachers. The invite and the district's hiring page agree on that format. You didn't send a posting, so three of the nine rows rest on a sample fourth-grade posting I found, and the pack labels them inferred.

Your message included a Social Security number. Nothing here needs it, and I haven't used or repeated it. I also left your licence number out of the pack and out of every search. Checking your licence record is yours to do.

The prep that pays off most is A1: "You've taught third grade, and you haven't taught fourth." You said you've never taught fourth grade and never been a team lead, so expect both. A2 covers the team-lead question.

The district's literacy plan and its published beliefs shaped the case and values questions. Principal Vantongeren's background as a reading specialist shaped the reading ones. All of it is cited in the pack's Sources section.

Say the word and I'll play the skeptical panelist on A1 and give you feedback after.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Can you paste the full Halvering posting? It would turn the inferred rows into rows grounded in the real posting.
Did HR or the principal ask you to bring or prepare anything, such as a sample lesson or portfolio?
Do you want a deeper research pass, with up to 6 more searches and 2 more page fetches and several more minutes?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

## 1. Title block

- Role: Fourth Grade Teacher, Halvering Elementary School, Orrinsford Community School District
- Round: one 45-minute panel on Thursday
- Interviewers: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
- Built on: one session, panel mode. The invite and the district's hiring page agree on the format, so no archetype fallback was needed

## 2. How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Tag | Meaning |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your CV lines survive a close read; what was actually you |
| JD | The listed job's requirements, gaps included |
| CO | Whether you know the district and its current plans |
| CASE | A live problem from the actual job, answered aloud |

- Question IDs are letter-by-persona: A Skeptic, B Peer Evaluator, C Case/Strategist, D Values/Behavioral, E Conversational, G Data-Driven Prober. The letter F is skipped because F1 to F9 are fit-snapshot rows.
- Provenance: `[grounded]` traces to a document you gave or a page cited in Sources; `[inferred]` is derived from a representative posting or a reasonable extension; `[generic]` is a pattern with no claim about this district. Quotes beside a label are your own sentences, the only ones the guidance leans on.
- An answer slot is an instruction for the interview, not a question for you here. It has two branches, and the second always allows that the practice was not yours or never existed. Both branches are fine answers.
- The highest-ROI prep in this pack is A1, the fourth-grade question. It will be asked in some form. Rehearse it until it is boring.

## 4. Fit snapshot

Requirements come from the invite, the district's own pages, and one representative posting (labeled `[inferred]`, since you did not supply Halvering's posting).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "valid Illinois Professional Educator License with an elementary endorsement" — invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your CV line shows met, so it routes like any row. Nothing has been inspected behind the line; the licence record is the artifact that would raise it, and checking that record is yours to do. State it in the quote's own terms and no wider: licence, endorsement, grades 1–6, active through the date you gave |
| F2 | "reading instruction" — district hiring page | "I led our grade level's move to a new reading curriculum in 2024", "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | none | Both are CV lines with nothing inspected behind them, so expect a probe. Lead with them in their own terms: you led your grade level's move to a new reading curriculum in 2024, and you have run the after-school reading club for two years. The words stay at "move"; the quote does not say you chose or wrote the curriculum |
| F3 | "classroom routines" — district hiring page | "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [inferred] | discovery | The line shows six years of classroom work, not what the routines were. Answer slot: the panel's stated focus on classroom routines makes a probe on how the day ran likely. If routines in your room were yours to set, say which and why, in your own words; if someone else set them, or there were none beyond the school's, say so plainly and describe how the day ran |
| F4 | "how you work with families" — district hiring page | "I write a weekly email to families" — your CV | medium | [grounded] | none | Lead with the email in the quote's own terms: weekly, to families. A named, regular practice beats an adjective. It is a CV line with nothing inspected behind it, so expect a probe |
| F5 | "each teacher speaks with every family each term" — district Mission and Beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | The belief is about speaking with families; the quote is about writing to them, and the words stay there: "I write a weekly email to families." Answer slot: the belief makes a probe on conversations likely. If you also spoke with families, say when and how often, in your own words; if not, or not each term, say so plainly and stay with the weekly email |
| F6 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board representative posting | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | transferability | The quote gives the grade and the years, not the subjects, and the words stay there. Answer slot: the subject list makes a probe on which subjects were yours likely. Say which you taught, in your own words; if some were taught by others, or you did not teach them, say so plainly and name the ones you did |
| F7 | "work with the grade-level team" — K12 Jobs Board representative posting | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | none | Lead with the quote as written. Keep "led the move" from becoming "led the team" (see section 13) |
| F8 | "Fourth Grade Teacher" — invite | "I've never taught fourth grade" — your CV | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then how you would learn it, said as a plan and never as a past (A1). Third-grade work is its own row (F6) and stays at its own scope |
| F9 | "differentiate instruction using assessment data" — K12 Jobs Board representative posting | none given | none | [inferred] | discovery | Your material is silent here, so the words are an answer slot. If you used assessment results to change what you taught, say what you looked at and what you changed, in your own words; if you did not, or it was not yours, say so plainly and say what you would look at first |

Requirement coverage: where each row is rehearsed.

| Row | Requirement | Questions |
|---|---|---|
| F1 | licence and endorsement | E3 |
| F2 | reading instruction | C1, C2, D3, E2, G1, G2 |
| F3 | classroom routines | E1, C4 |
| F4 | how you work with families | B3, C3, D2 |
| F5 | speaking with every family each term | C3, D2 |
| F6 | five subjects | A3 |
| F7 | grade-level team | A2, B1, B2, B3, B4 |
| F8 | Fourth Grade Teacher | A1, A4 |
| F9 | differentiate using assessment data | D1 |

## 7. Reading the interviewer

Public professional footprint only. The two fourth-grade teachers have no names in your material, so there is no read for them.

| Observation | Source | Provenance | What to do with it |
|---|---|---|---|
| Principal of Halvering Elementary School since 2022 | ilprincipalsforum.example speaker page, Sources row 4 | [grounded] | She sets the building's expectations; expect the panel's questions to be framed for Halvering, not generically |
| Nine years as a reading specialist before that | same page | [grounded] | Reading instruction is her native ground. Answer from what you did, in your own words, and borrow no specialist vocabulary you do not use |
| 2025 forum talk, "Small Groups, Big Readers", on weekly reading conferences in grades 3 to 5 | same page | [grounded] | Expect a probe on small groups or reading conferences. Your material does not mention either, so treat any such question as an answer slot: say what you did, or say plainly that it was not part of your practice |
| Shared ground: reading in grades 3 to 5 | same page, and F2 | [grounded] | A mirror opportunity in shared vocabulary only, using your own sentence: "I've run the after-school reading club for the last two years." It is not offered as a shared career jump, since nothing in your material carries one |

## 8. Persona table

Weights start from the relationship priors (principal seat: Case/Strategist and Skeptic; peer seats: Peer Evaluator and Prober), then adjust for what you stated, what the district published, and the principal's footprint. Recalibrate if you know something this does not.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Skeptic | Quiet, persistent probing of fourth grade and leadership | Highest. The principal seat's prior includes it, and your own message states both gaps (F8 and the team-lead limit) | Rehearse A1 until it is boring; bridge only from the quotes in A1 and A2; give a plan, not a past | A (4) |
| Peer Evaluator | The two fourth-grade teachers asking how you would work beside them | High. Two of three seats are grade-level teachers, and the peer prior is this persona | Reciprocity: offer what your quotes carry (B3) and ask what the team needs; propose how you would work rather than pretending to know their seams | B (4) |
| Case/Strategist | Live problems: a struggling reader, a new curriculum, family contact | High. The principal's prior includes it, her background and talk are reading-centred, and the hiring page lists reading instruction and routines | Clarify first, then objective, approach, how you will know it works, risks; think aloud | C (4) |
| Values/Behavioral | Scenario prompts themed on the district's three published beliefs | Medium. The beliefs are published, but no source documents a values round, so this is themed questions inside the panel, not a separate round | Pick a real instance or use the scaffold's honest branch; "we" for context, "I" for what you did | D (3) |
| Conversational | Friendly openers: "walk us through your day", "tell us your story" | Medium. Panels often open this way, and the hiring page lists classroom routines, which arrive casually but are scored | A 90-second arc built only from your quotes (E2); treat casual routine questions as scored | E (3) |
| Data-Driven Prober | "How do you know it worked?" on your CV lines | Low. The peer prior includes it, but your CV lines carry durations, not performance figures | Say plainly what you know about how anything was counted, and what you do not | G (2) |
| Pressure | Interruptions, time-boxing | Low. Nothing in the invite or the hiring page points to a stress format, so no bank is written; if it appears, use A1's hold-then-concede structure | Pause, restate, hold through two follow-ups, concede specifically | none |

## 9. Question banks

### A. Skeptic (weight highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade, and you haven't taught fourth. How would you handle that in this job?" | JD | [grounded] "I've never taught fourth grade" "Six years teaching third grade at a public elementary school in Joliet" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I haven't taught fourth grade." Then the quote at its own scope: "Six years teaching third grade at a public elementary school in Joliet." Then a plan, said as a plan: what you would find out first and who on this team you would ask; the content is yours, the pack supplies none. Hold through two follow-ups by returning to the third-grade quote, never by adding to it. Follow-up one, what changes between third and fourth: answer slot, if you know from working beside fourth grade, say what and how you know; if you do not, say so plainly and say who you would ask. Follow-up two, why not stay in third grade: say your actual reason in your own words; the pack gives none. Concede the specific thing you do not yet know, and do not say third grade has prepared you; let them draw that | F8 is the stated gap and the likeliest objection, so it gets the deepest rehearsal: three follow-up levels and the exact concession wording. JD because the role title is the requirement |
| A2 | "You led your grade level's move to a new reading curriculum, and you haven't been a team lead. What did leading it involve?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead" | Acknowledge plainly: "I haven't been a team lead." Then the move at its own scope: "I led our grade level's move to a new reading curriculum in 2024." The beats the quote states are your grade level, a new reading curriculum, and 2024; tell them in your own words. Answer slot: if asked what leading the move involved, say what you did and decided; if parts were decided by others, say so plainly and return to the quote | F7 and the section 13 entry. EXP because it tests attribution; Skeptic because the limit is stated |
| A3 | "Which of reading, writing, math, science and social studies have you taught?" | JD | [inferred] "Six years teaching third grade at a public elementary school in Joliet" | Say what the quote carries: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: the subject list makes a probe on which subjects were yours likely. Say which you taught, in your own words; if some were taught by others, or you did not teach them, say so plainly and name the ones you did. The subject list is from a representative posting, not Halvering's | F6, `[inferred]` because the list is from a representative posting. JD because it scores a listed duty |
| A4 | "Why Halvering, and why now?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Your reason is yours; the pack supplies none. If it touches what the district has published, the Board adopted a three-year literacy plan in August 2026 that includes a new grades 3–5 reading curriculum from fall 2027 (Sources, row 3). If your own 2024 experience is part of your reason, say it in the quote's words and let them draw the connection. If no reason beyond the job comes to mind, say so plainly and name what in the district's published plan caught your attention | F8 and F2: the motivation probe sits next to the fourth-grade gap. CO because it tests homework on the district's current plan |

### B. Peer Evaluator (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "How do you like to work with the teachers on your grade level?" | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on the quote: your grade level, a new reading curriculum, 2024, told in your own words. Answer slot: if you worked alongside your grade level in a regular way, say how; if not, or it was not regular, say so plainly and return to the move | F7, `[inferred]` because the team requirement is from a representative posting |
| B2 | "Tell me about a time you disagreed with a colleague on your grade level." | JD | [generic] | Selection scaffold: pick a time with a named stake, what each side wanted, what you said, and how the working relationship stood afterward; "we" for context, "I" for what you said and did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle a disagreement with a teammate | F7. A peer persona's stock prompt, so the pack gives a scaffold and no story |
| B3 | "What would you bring to a fourth-grade team?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families" | Reciprocity: say what your quotes carry, in their words, for whichever the panel has pressed on (reading, routines, families). Then ask what the team would most like help with, and do not guess at its gaps | F2, F4 and F7. A peer weighs what the hire adds to their load, so the answer ends with a question to them |
| B4 | "Tell me about a time work spanned several teachers and credit had to be shared." | JD | [generic] | Selection scaffold: pick a time with a named piece of shared work, who did what, and how credit was named; "we" for the group, "I" only for what you did. If the 2024 move is the time that comes to mind, keep to the quote's beats: "I led our grade level's move to a new reading curriculum in 2024." If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7. Credit-sharing is the peer persona's stock probe |

### C. Case/Strategist (weight high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader arrives reading well below the rest of the class. Walk us through your first two weeks." | CASE | [generic] | Clarify first: what the student's reading history is, what has been tried, what the family and previous teacher say. Then the objective, your approach, how you will know it is working, and the risks. Think aloud and challenge one premise respectfully. The question asks for no past, so the guidance makes no claim about yours | F2. Reading is the hiring page's first listed topic and the principal's field; `[generic]` because it is a pattern for the problem |
| C2 | "The district's literacy plan brings a new grades 3–5 reading curriculum from fall 2027. What would you want to know, and what would you do first?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Clarify first: what the curriculum is, where fourth grade sits in the timeline, what the team is already doing. Then objective, approach, how you will know it is working, risks. You may say the quote once as context, "I led our grade level's move to a new reading curriculum in 2024", and stop there; do not say it prepared you | F2, and the plan in Sources row 3. CO because it needs the district's current direction |
| C3 | "Plan your communication with fourth-grade families for the first month." | CASE | [grounded] "I write a weekly email to families" | Structure it: what families need first, what channels, how you will know it is landing. Say what you already do in the quote's words, "I write a weekly email to families", then add conversations, since the district's published belief is "each teacher speaks with every family each term". Answer slot: if you have spoken with each family in a term, say so in your own words; if not, say so plainly and say how you would | F4 and F5. The belief is the raising source for the slot |
| C4 | "In week three, transitions are eating ten minutes of every lesson. What do you change?" | CASE | [generic] | Ask what the transition is and what students are doing during it, change one thing, and say how you will check it the next day. Think aloud. No claim about your past is made | F3. Routines are a listed panel topic; `[generic]` because it is a pattern |

### D. Values/Behavioral (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time assessment results changed what you taught next." | VAL | [grounded] | Selection scaffold, themed on the district's published belief that "assessments inform teaching and never replace it": pick a time with the result you saw, the decision you made, what you changed, and what happened. "I" only for what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would use assessment results to adjust teaching | F9, with the belief as raising source. VAL because it maps to a published belief |
| D2 | "Tell me about a time you worked with a family to help a student." | VAL | [grounded] "I write a weekly email to families" | The quote is a routine, not a story. The story needs a student (no names), what you told the family, what they told you, and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would. Themed on the published belief "Families Are Partners" | F4 and F5 |
| D3 | "Tell me about a time a student was behind in reading and what you did." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold, themed on the published belief "Every Child a Reader": pick a time, from the club or your classroom, with what you noticed, what you changed, and what happened next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F2, with the belief as raising source |

### E. Conversational (weight medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through a typical day in your third-grade classroom." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | The beats the quote states are third grade, six years, a public elementary school in Joliet; tell the day in your own words. Answer slot: the hiring page's focus on classroom routines makes a probe on how the day is structured likely. If you set the routines, say which and why; if someone else set them, or there were none beyond the school's, say so plainly and describe how the day ran | F3. Casual in register but scored on routines |
| E2 | "So, walk us through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet" "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families" | A 90-second arc in this order: third grade for six years; the 2024 move; the reading club; the weekly email, each in its quote's words. The last beat is your reason for fourth grade, yours to say; the pack supplies none. The arc names only what the quotes state | F2, F4, F6 and F7. The biography question is the one every panel asks |
| E3 | "Can you confirm your licence and endorsement for us?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the quote's own terms and no wider. If they ask for the number, give it from your own record; it is not in this pack | F1, the invite's stated condition. Short to answer, and worth answering without a pause |

### G. Data-Driven Prober (weight low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "How did you know the new reading curriculum was working for your grade level?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Start from the quote. Answer slot: the district's belief that assessments inform teaching makes a probe on evidence likely. If anything was measured or compared, say what, how it was counted and which part was yours; if nothing was, or it was not yours, say so plainly and stay with leading the move. "I don't know how it was counted" is an honest answer | F2 and F9. The probe lands on the one CV line that sounds like a result |
| G2 | "What happens in the reading club, and who comes?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Describe a session as you ran it, in your own words; "two years" is the quote's scope. Answer slot: if you know attendance or any other measure, say what it was and how it was counted; if you do not, say so plainly and stay with what the club does | F2. A named activity invites a "walk me through it" |

## 11. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Principal Vantongeren, what does a weekly reading conference look like in a fourth-grade day here?" | Ties to her public talk on weekly reading conferences in grades 3 to 5 and her path from reading specialist |
| R2 | "The literacy plan brings a new grades 3–5 reading curriculum from fall 2027. What is the fourth-grade team doing to get ready this year?" | Shows you read the district's current plan, and asks about what the role will actually face |
| R3 | "The district's belief is that each teacher speaks with every family each term. How does the fourth-grade team handle that in practice?" | Shows you read the beliefs and asks for the team's real routine |
| R4 | "What could a new person on the team do in their first month that would genuinely help you?" | Reciprocity for the two grade-level teachers: it prices what you add to their load |
| R5 | "What does a strong first semester look like for a teacher who is new to fourth grade?" | Turns the stated gap into a shared definition of success and signals you plan to ramp |
| R6 | "How does the fourth-grade team plan together, and who sets the pacing?" | Tests fit with the team's way of working and tells you what you would be joining |

## 13. Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade | A negative you stated, F8 | "I haven't taught fourth grade." Third-grade work stays at its own scope: "Six years teaching third grade at a public elementary school in Joliet." No equivalence claim, and no slot |
| Has been a team lead, or led the grade-level team | A negative you stated: "I've never been a team lead" | "I haven't been a team lead." The quote stays at its own scope: "I led our grade level's move to a new reading curriculum in 2024." A move, not the team |
| Chose, wrote or designed the new reading curriculum | Inflated form of F2 | The quote at its own scope. The limit is the pack's observation: your material says the move, not the curriculum's choice or design. G1's slot stays inside the move |
| Speaks with every family each term | Inflated form of F5 | "I write a weekly email to families." The limit is the pack's observation: the material says the email, not conversations |
| Taught reading, writing, math, science and social studies | Inflated form of F6 | The quote at its own scope. The limit is the pack's observation: the material says the grade and the years, not the subjects. A3's slot stays inside the third-grade quote |

## 14. Sources

Provided documents: the invite from the district's Human Resources; your CV, pasted into the conversation. No `tuesday-dossier.md` was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

Queries sent and what came back:

| Query or fetch | What came back |
|---|---|
| Search: `Orrinsford Community School District mission values` | https://orrinsfordschools.example/about/mission-and-beliefs |
| Search: `Orrinsford Community School District teacher hiring interview process` | https://orrinsfordschools.example/careers/how-we-hire-teachers |
| Search: `Orrinsford Community School District strategic plan news` | https://orrinsfordschools.example/news/board-adopts-literacy-plan |
| Search: `Dolores Vantongeren principal Halvering Elementary School` | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| Search: `fourth grade teacher job description Illinois elementary school` | https://k12jobsboard.example/listings/fourth-grade-teacher (snippet cut off mid-sentence at the qualifications; nothing from the cut part is used) |
| Fetch: the Mission and Beliefs page | The three beliefs and their definitions; nothing beyond the search snippet |
| Fetch: the How we hire teachers page | One 45-minute building panel, the principal and two grade-level teachers, topics and references; nothing beyond the search snippet |

Source notes: the literacy plan page is dated August 2026, inside the six-month freshness window. The hiring and beliefs pages carry no date. The loop is established by the hiring page and agrees with the invite. No values-style round is detected, because the hiring page names reading instruction, routines and families as panel topics and no round that assesses values, so no values cheat sheet is built; the beliefs still theme the D bank.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | The three beliefs by name: D bank themes, C3, R3 |
| 2. `Orrinsford Community School District interview process` | yes | Panel format and topics: persona weights, E1, no archetype fallback |
| 3. `Orrinsford Community School District strategy` / recent news | yes | The 2026–2029 literacy plan: C2, A4, R2 |
| 4. `Dolores Vantongeren Halvering Elementary School` | yes | The interviewer read, R1, and persona weights |
| 5. representative `Fourth Grade Teacher` posting | yes | F6, F7 and F9 as `[inferred]` rows, since no posting was supplied |

## 15. Upgrade menu

- The full Halvering posting → F6, F7 and F9 move from `[inferred]` to `[grounded]`, and any mid-list requirement gets its own question
- Anything HR or the principal asked you to bring or prepare (a sample lesson, a portfolio, writing) → a build section for that deliverable
- The two fourth-grade teachers' names → an interviewer read for each and persona weights per seat, from public professional footprint only
- Your own answers to the answer slots in A1, A3, E1 and G1, typed here → they enter the snapshot as quotes, and rows F3, F6 and F9 can move from `discovery`
- An inspected record of your licence, checked by you → F1's confidence can rise from `medium`
- How much prep time you have before Thursday → a prioritized schedule tied to question IDs
- A `tuesday-dossier.md` from an earlier evidence review, if you have one → verified evidence and limits on the strategies the pack may coach, never a prerequisite
