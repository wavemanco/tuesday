# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

- **Role and employer:** Fourth Grade Teacher, Halvering Elementary School, Orrinsford Community School District
- **Round:** one 45-minute panel on Thursday
- **Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
- **Built on:** the panel format your invite and the district's own hiring page describe; the job requirements come from a representative fourth-grade posting, not Halvering's own, so those rows are labeled `[inferred]`

## How to use this pack

Personas describe how a question is asked; types describe what it scores. Rehearse out loud. Guidance is scaffolding, not a script: it holds only what your own sentences say.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the district's published beliefs |
| EXP | Whether what you said about your work survives follow-up: what was actually you |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the district's current direction |
| CASE | A live classroom problem: structure and reasoning |

An **answer slot** is an instruction for the interview, not a question for you now. It names what an interviewer is likely to probe and gives two honest branches: say it in your own words if it happened, or say plainly that it did not or was not yours, and return to what your sentences do carry. Either branch is a good answer.

The highest-ROI prep in this pack is **A1**: the question about fourth grade. It will be asked in some form, and a calm, specific answer changes the interview.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A term the invite states, and your CV states it met. Nothing has been inspected behind that line, so confidence stays medium; the pack does not check the registration, and that check is yours. Your license number is not needed anywhere in this pack |
| F2 | "plan and teach reading, writing, math, science and social studies" — K12 Jobs Board fourth-grade listing, a representative posting and not this district's | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | discovery | Your material says third grade, not which subjects, and the words stay there: "Six years teaching third grade at a public elementary school in Joliet." Answer slot: a posting of this kind lists five subjects, so expect a probe on which of them you taught. If you taught some or all, say which, in your own words; if some were taught by others or were not part of your day, say so plainly and stay with what you taught |
| F3 | "experience in grades 3 to 5 preferred" — K12 Jobs Board listing | "Six years teaching third grade at a public elementary school in Joliet." — your CV | medium | [inferred] | none | Your quote already sits inside the grade band the listing names. Lead with it in its own terms: you have six years teaching third grade at a public elementary school in Joliet. The word "preferred" is the listing's wording, not this district's |
| F4 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade and I've never been a team lead." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't taught fourth grade." Then the nearest thing your material carries, at its own scope, F3's third-grade quote. Then a plan, said as a plan and never as a past: what you would ask the fourth-grade team to show you first. Nothing added to make the gap feel smaller |
| F5 | "work with the grade-level team" — K12 Jobs Board listing | "I led our grade level's move to a new reading curriculum in 2024" — your CV "I've never taught fourth grade and I've never been a team lead." — your message | medium | [inferred] | presentation | Lead with the quote in its own terms: "I led our grade level's move to a new reading curriculum in 2024." Your message also says you have not been a team lead, so expect a probe on what leading meant. Answer slot: say what part was yours and what the grade level did together, in your own words; if the choices were shared, or set by someone else, or there were no separate steps you took, say so plainly and stay with the move |
| F6 | "reading instruction" — Orrinsford "How we hire teachers" page | "I led our grade level's move to a new reading curriculum in 2024" — your CV "I've run the after-school reading club for the last two years." — your CV | medium | [grounded] | presentation | Lead with the two quotes at their own scope: the grade level's move to a new reading curriculum, and the after-school reading club you have run for two years. The pack's observation is that your material says the move and the club, not the daily teaching of reading, and the words stay there |
| F7 | "classroom routines" — Orrinsford "How we hire teachers" page | none given | none | [grounded] | discovery | Your material is silent on routines. Answer slot: the district's page names routines among the panel's topics, so expect a probe. If you set routines in your room, say which and why, in your own words; if the school or someone else set them, or there were none to set, say so plainly and describe how you would set them |
| F8 | "Families Are Partners: each teacher speaks with every family each term." — Orrinsford "Mission and Beliefs" page | "I write a weekly email to families." — your CV | medium | [grounded] | transferability | Your quote is regular written contact, and the words stay there: "I write a weekly email to families." The belief on the page is about speaking with each family. Answer slot: expect a probe on what other contact families have besides the email. Say what it is, in your own words; if the email is the whole of it, say so plainly and stay with the email |
| F9 | "differentiate instruction using assessment data" — K12 Jobs Board listing | none given | none | [inferred] | discovery | Your material is silent on assessment data. Answer slot: the listing names it, and the district's page says assessments inform teaching, so expect a probe. If you used results to change what you taught, say what changed and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly and say how you would start in a new class |

## Reading the interviewer

Public professional footprint only: one page returned for the principal; the two team members are unnamed, so there is no read for them.

| Item | What the source says | Provenance |
|---|---|---|
| Career pattern | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist (ilprincipalsforum.example, speaker page) | [grounded] |
| Published talk | A 2025 forum talk, "Small Groups, Big Readers," covered weekly reading conferences in grades 3 to 5 (same page) | [grounded] |
| Self-described style | Not established: the page gives career and talk summary only | [grounded] |
| Implication 1 | Reading questions from her are likely to go to specifics, so keep D1 and D3 to what your quotes carry | [inferred] |
| Implication 2 | Her talk's grade band, 3 to 5, includes the grade you teach now and the one you are applying for, which gives a natural way into reading | [inferred] |
| Implication 3 | "Small groups" and "reading conferences" are her words, and your material mentions neither. Use them to ask her questions (R5), never to describe your own past | [inferred] |
| Mirror opportunity | Shared vocabulary, reading. Pair it with the quote "I've run the after-school reading club for the last two years." (F6), said as it stands. No shared career jump is offered: your material does not carry your side of hers | [inferred] |

## Persona table

Weights follow the panel row of the persona model: the top two personas of each member's relationship, adjusted for the interviewer signals and the loop. The district's hiring page documents one 45-minute building panel of the principal and two grade-level teachers, asking about reading instruction, classroom routines and working with families. It names no values round, so there is no values cheat sheet; the three published beliefs still theme bank E.

| Persona (bank, questions) | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (A, 5) | Quiet, persistent probing of the fourth-grade gap and of "led" | High. You stated the gap yourself (F4), the role is fourth grade, and a principal hiring for it will test it. The team will ask it in friendlier packaging | Rehearse A1 until it is boring. Say the limit first, hold the adjacent quote at its own scope, then give a plan said as a plan |
| Case/Strategist (B, 4) | Live classroom problems: reading, routines, a week of planning, the district's literacy plan | High. The principal sits in the hiring-manager seat; the hiring page names reading instruction and routines; a new literacy plan gives a current-strategy question | Clarify first, then objective, approach, how you would know, who you would tell. Challenge one premise politely |
| Peer Evaluator (C, 4) | What a new teammate costs and adds; the seam between your plans and theirs | High. Two of the three panelists are on the fourth-grade team and the listing asks for working with the grade-level team (F5) | Reciprocity: what you would bring, not only what you would need. Propose principles for the seam instead of pretending to know it |
| Data-Driven Prober (D, 3) | Reading your lines closely and asking for the next level of detail | Medium. The principal's background is reading, which raises probing on reading; your lines carry no figures, so the probes are on what each sentence involved | Know what each sentence does and does not say. Say plainly when a part was not yours |
| Values/Behavioral (E, 3) | Stories tied to the three published beliefs | Medium. The district says three beliefs guide every hire, but no round for them is documented | Pick a time that fits each belief, or use the honest branch |
| Conversational (F, 2) | A friendly opener and a casual question about reading | Medium-low in weight but certain to occur: some opener always does | A 90-second arc from your own sentences. Treat casual questions as scored |
| Pressure (G, 2) | Time-boxed challenges and "how much was actually you" | Low. Nothing in the sources points to a stress style; kept for the attribution rehearsal | Pause, restate, hold through two follow-ups, concede specifically |

## Question banks

### A. The Skeptic (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. What do you expect to be different, and how would you handle your first weeks?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." "Six years teaching third grade at a public elementary school in Joliet." | The highest-ROI rehearsal in this pack. Say the limit first, in your own words: "I haven't taught fourth grade." Then the nearest thing your material carries, at its own scope: six years teaching third grade at a public elementary school in Joliet. Then a plan, said as a plan: the first things you would ask the fourth-grade team to show you, and what you would watch for in your own classroom. Follow-up 1, what carries over. Answer slot: name what from your third-grade work you expect to carry over, from your own experience; if you are not sure, say so plainly and say how you would find out. Follow-up 2, what worries you. Name one real worry and how you would address it; do not trade it for a reassurance you cannot back. Hold through both, concede what you do not know, and add no fourth-grade experience | F4 is the objection both the principal and the team will raise in some form, and F3 is the adjacent evidence. JD because it scores the role's grade; deepest rehearsal because it is the likeliest question to be asked |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never taught fourth grade and I've never been a team lead." | Pick one gap you can name specifically and have a plan for, and say it first. The pack's observation is that your material is thinnest on F4, F7 and F9. If the true answer is the one you stated, it is "I haven't taught fourth grade", followed by the plan from A1. If another gap is truer for you, say that one in your own words; do not choose a gap because it sounds safe | The Skeptic's standard stem, aimed at the rows with the thinnest evidence; JD because it scores the whole listing |
| A3 | "You led the move to a new reading curriculum, but you haven't been a team lead. What did leading it involve?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never taught fourth grade and I've never been a team lead." | Hold the two statements together, each at its own scope: "I led our grade level's move to a new reading curriculum in 2024", and "I haven't been a team lead." Answer slot: expect the follow-up on what leading meant. Say what was yours to do and what the grade level did together, in your own words; if the choices were shared, or set by someone else, or there were no separate steps you took, say so plainly and stay with the move | F5 holds the claim and its limit, and a probe on "led" is the likeliest attribution question. EXP because it tests what was actually the candidate's |
| A4 | "Why fourth grade, why Halvering, and why now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." | The reasons are yours, and the pack does not supply them. Give your actual reason for moving to fourth grade and your actual reason for this school, in your own words, and choose reasons you can repeat under a second "why". Start from the ground your sentence gives, six years teaching third grade, not from a list of things the school offers. If part of the honest reason is less tidy than the rest, say that part plainly instead of polishing it | F4: a teacher changing grades is asked why, and motivation consistency is what the Skeptic scores. EXP because it tests whether the story holds together |
| A5 | "Part of the job is differentiating instruction using assessment data. What have you done with assessment data?" | JD | [inferred] | Answer slot: the representative listing names it and the district's page says assessments inform teaching, so expect a probe on what you have done with results. If you used results to change what you taught, say what changed and how you decided, in your own words; if there was no such step, or it was not yours, say so plainly, then say how you would start with a new class | F9 has no quote behind it, so the answer is a slot rather than a story. JD because it scores a listed responsibility; the premise is the listing's, and the guidance does not adopt it |

### B. The Case/Strategist (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A fourth grader reads aloud smoothly but cannot say what the passage was about. What do you do over the next two weeks?" | CASE | [generic] | A live problem, so the guidance makes no claim about your past. Structure it aloud: clarify first (what you would listen for, how you would check understanding), then the objective, the approach, how you would know it is working, and who you would tell. Challenge one premise politely, such as whether the child's reading aloud and understanding were checked the same way | F6 and the principal's reading background tilt the case bank toward reading; CASE because it scores structure and reasoning, not the right answer |
| B2 | "It is the second week of school and moving between lessons is taking far too long. What do you put in place?" | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Clarify what is slow and where, state the goal, teach the routine explicitly, practise it, check it, adjust it. Say the structure out loud before the details | F7 is the row with no evidence, and the hiring page names routines; CASE delivery of a JD topic, `[generic]` because it is a pattern for the problem and not a fact about this school |
| B3 | "The board adopted a three-year literacy plan in August 2026, with a new grades 3–5 reading curriculum from fall 2027. What would you want to know about it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you read it: use the plan's own words, a new grades 3–5 reading curriculum from fall 2027. Mention your own move only at its quote, "I led our grade level's move to a new reading curriculum in 2024", and stop there unless they ask. Worth asking aloud: what is being replaced, how the fourth-grade team takes part, what support comes before fall 2027. Answer slot: if you are asked about your own move, say what you did and what the grade level did, in your own words; if you do not know how it turned out, say so plainly | The one question grounded in the district's current strategy; F5 is the only evidence of a curriculum change. CO because it scores homework depth |
| B4 | "Walk us through how you would plan a week of fourth grade across reading, writing, math, science and social studies." | CASE | [inferred] | A live problem built from the listing's subject list, so it asks for structure, not a past. Clarify first: what the team already plans together, what the standards ask, what your students need. Then the week's objectives, how the five subjects fit, how you would adjust midweek, how you would know the week worked. Answer slot: expect the follow-up on which subjects you taught in third grade; say which were yours, in your own words, and say plainly which were not | F2 in a role-shaped form; CASE delivery of JD content. `[inferred]` because the subject list comes from a representative listing |

### C. The Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "When you and a teammate disagree about how to teach something, what happens?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Offer principles, not a story you do not have: what you would do first (listen, find what each of you is trying to protect, look at the children's work, agree who decides). If a real disagreement from your own time teaching comes to mind, tell it with a named stake and an intact relationship; if none comes to mind, say so plainly, then give the nearest thing your material carries, the quote above, or how you would handle it | F5; the Peer persona's disagreement stem, scored for spine and tact together |
| C2 | "What would you need from us in your first month?" | JD | [grounded] "I've run the after-school reading club for the last two years." | Reciprocity: what you would ask for and what you would bring. Ask to see what the team already uses before you change anything; that is a request, not a claim. What you bring is only what your quote carries, that you have run an after-school reading club for two years; offer it as something to talk about, not as a promise to start one here unless you mean it | F4 and F5: a teammate prices what a newcomer costs. JD because it scores working with the grade-level team |
| C3 | "You write a weekly email to families. How would that fit with what the rest of the team does?" | JD | [grounded] "I write a weekly email to families." | Say the quote at its own scope: "I write a weekly email to families." Then do not pretend to know the seam: say you would ask what the team already sends and what families have asked for, and offer to fit in, not replace. Add nothing about how families have responded | F8; the peer seam question. JD because it scores communicating with families and working with the team |
| C4 | "How do you handle credit when work spans teams?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use "we" for what the grade level did and "I" only for what was yours. Your quote is the nearest story: "I led our grade level's move to a new reading curriculum in 2024". Answer slot: say which parts were yours and which the grade level's, in your own words; if the work was shared throughout, say so plainly. If no other example comes to mind, say so instead of reaching for one | F5; the Peer persona's credit stem |

### D. The Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk us through how your grade level moved to the new reading curriculum." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Tell only the beats the sentence states: your grade level, a move to a new reading curriculum, 2024, and that you led it, in your own words. Answer slot: the follow-ups will go a level deeper than the sentence. Say what you did and what the grade level did; where a part was not yours, or there was no such step, say so plainly and return to the move itself | F5 and F6; the Prober reads each line and asks what is behind it |
| D2 | "How would you know a new reading curriculum is working for a child?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Name the evidence you would look at and the assumption you would defend least, for example that one kind of check tells the whole story, before the interviewer does. The district's page says assessments inform teaching and never replace it, so show checks that lead to a teaching decision. Answer slot: if you tracked how the 2024 curriculum was working, say what, in your own words; if you did not, say so plainly and say what you would track first | F9 and F6; the district's third belief raises assessment. JD because it scores using data to teach |
| D3 | "Walk us through the after-school reading club." | EXP | [grounded] "I've run the after-school reading club for the last two years." | Beats from the sentence: after school, a reading club, run by you, two years. Answer slot: expect follow-ups on how a session runs and what you have noticed in the children; say what you do and notice, in your own words. If you have no measure of whether it helps, or part of it is run by someone else, say so plainly instead of offering a number | F6; the reading club is your clearest reading evidence and reading is the principal's background |

### E. The Values/Behavioral interviewer (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Every Child a Reader. Tell us about a time you helped a child who was struggling to read." | VAL | [grounded] "I've run the after-school reading club for the last two years." | A selection scaffold, because none of your sentences carries this story. Choose a time with a named stake (without identifying the child), what you noticed, what you changed and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I've run the after-school reading club for the last two years", or say how you would handle it | F6; the first published belief, by its name on the district's page |
| E2 | "Families Are Partners. How do you work with families?" | VAL | [grounded] "I write a weekly email to families." | Say the quote at its own scope: "I write a weekly email to families." Answer slot: expect a probe on what other contact families have besides the email. Say what it is, in your own words; if the email is the whole of it, say so plainly and stay with the email | F8; the second published belief, by its name |
| E3 | "Teach for Tomorrow, Not for the Test. Tell us about a time assessment results changed what you taught." | VAL | [grounded] | A selection scaffold that makes no claim about your past. Choose a time results changed your next lesson or plan: a named stake, what the results showed, what you changed, what happened. If no such time comes to mind, say so plainly and say how you would use results to decide what to teach next | F9; the third published belief, by its name |

### F. The Conversational interviewer (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, tell us where you are now and what brought you to us." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." | A 90-second arc in your own words, built only from your sentences: six years teaching third grade at a public elementary school in Joliet, then the grade level's move to a new reading curriculum you led in 2024, then the reading club you have run for two years. Close on your own reason for this school and for fourth grade, which is yours to give (see A4). Treat this friendly opener as scored | F3, F5 and F6 in one arc; the casual register is still scored |
| F2 | "What are you excited to be reading or teaching with right now?" | JD | [grounded] "I've run the after-school reading club for the last two years." | Name something real that you actually use or read; the pack will not supply a title. Answer slot: if what you name connects to the reading club, say how, in your own words; if it does not, say so plainly and stay with what you named | The reading plus-skill, asked casually; F6 |

### G. The Pressure interviewer (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years." "I write a weekly email to families." "I've never taught fourth grade and I've never been a team lead." | Pause and restate the question, then hold. Say what your quotes carry: six years teaching third grade in Joliet, the grade level's move to a new reading curriculum you led in 2024, the reading club you have run for two years, the weekly email to families. Concede the limit at once: "I haven't taught fourth grade." Do not claim you are better than another candidate; claim what you have done. If pushed twice, hold that and add nothing | F3 and F4; hold-then-concede on the question the whole pack turns on |
| G2 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never taught fourth grade and I've never been a team lead." | Hold on the quote through two follow-ups: "I led our grade level's move to a new reading curriculum in 2024." Concede specifically, not vaguely. Answer slot: say which parts were yours and which the grade level's, in your own words; if a part was not yours, say so plainly. Never fold on the quote itself, and never add to it | F5; the Pressure persona's attribution stem, with the limit stated first |

### Requirement coverage

| Requirement | Fit row | Questions |
|---|---|---|
| Valid Illinois PEL with elementary endorsement | F1 | none: a term the invite states, shown met by your CV; not a rehearsal item |
| Plan and teach five subjects | F2 | B4 |
| Experience in grades 3 to 5 | F3 | A1, F1, G1 |
| Fourth Grade Teacher position | F4 | A1, A2, A4, G1 |
| Work with the grade-level team | F5 | A3, C1, C2, C4, G2 |
| Reading instruction | F6 | B1, D1, D3, E1, F2 |
| Classroom routines | F7 | B2 |
| Families | F8 | C3, E2 |
| Differentiate using assessment data | F9 | A5, D2, E3 |
| Published beliefs: Every Child a Reader, Families Are Partners, Teach for Tomorrow Not for the Test | F6, F8, F9 | E1, E2, E3 |
| District literacy plan | none | B3 |

Your CV carries durations ("six years", "two years"), not metrics, so no defend-the-number question applies; A1 and D3 hold those durations at their quotes.

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| R1 | "You spent nine years as a reading specialist before becoming principal. What from that work shapes what you hope a fourth-grade teacher does with reading?" | Ties to her own path, and turns an interrogation into a conversation about her priorities | [grounded] |
| R2 | "Your forum talk on small groups and weekly reading conferences in grades 3 to 5: how does that show up in fourth-grade classrooms here?" | Shows you looked at her public work and asks, without claiming that practice as yours | [grounded] |
| R3 | "I read that the board adopted a three-year literacy plan with a new grades 3–5 reading curriculum from fall 2027. How will the fourth-grade team be involved?" | Shows homework on current direction and asks about the team's role | [grounded] |
| R4 | "What could a new fourth-grade teacher do in the first month that would genuinely help the team?" | Reciprocity for the two teammates: it asks what you can give before it asks what you need | [generic] |
| R5 | "What does a strong first term look like for a new teacher on this team?" | Turns the fourth-grade gap into a shared target and shows you are planning the ramp | [generic] |
| R6 | "What happens after the panel?" | Process, and it makes sense because the district's page says references are taken up after the panel | [grounded] |

## Prohibited claims

What this pack will not coach, and why:

| Not coached | Basis | Honest form |
|---|---|---|
| Served as a team lead | Negative you stated: "I've never taught fourth grade and I've never been a team lead." — your message | "I haven't been a team lead." Beside it, F5's quote at its own scope: "I led our grade level's move to a new reading curriculum in 2024." A3's slot stays inside the move |
| Has taught fourth grade | Negative you stated, F4 | "I haven't taught fourth grade." Beside it, F3's third-grade quote. No slot |
| Chose, designed or ran the new reading curriculum | Inflated form of F5 | F5's quote at its own scope. The limit is the pack's observation, not words for you: your material says the move, not how the curriculum came to be chosen or built. D1's slot stays inside the move |
| Speaks with every family each term | Inflated form of F8 | F8's quote at its own scope: "I write a weekly email to families." The limit is the pack's observation: your material says the email. E2's slot stays inside the email |

## Sources

Provided documents: your invite and your resume text, as pasted. A government ID number in your message was not used and is not needed for any part of this pack.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Orrinsford Community School District values` | yes | Fetched the Mission and Beliefs page: the three beliefs by name, themed bank E and fit rows F8 and F9. No values round is documented, so no cheat sheet |
| 2. `Orrinsford Community School District teacher interview process` | yes | One 45-minute building panel of the principal and two grade-level teachers, topics named; fixed the persona weights and the loop. The page's age was not shown |
| 3. `Halvering Elementary School Orrinsford district news improvement plan` | yes | The board's literacy plan: B3 and R3 |
| 4. `Dolores Vantongeren principal Halvering Elementary` | yes | The interviewer read, R1, R2 and the Case and Prober weights. The two team members are unnamed, so they have no read |
| 5. representative `fourth grade teacher` JD | yes | Fetched a K12 Jobs Board listing: F2, F3, F5, F9, B4 and A5, all `[inferred]` |

Searches sent, with what came back:

- `Orrinsford Community School District mission values` returned orrinsfordschools.example/about/mission-and-beliefs
- `Orrinsford Community School District teacher interview process` returned orrinsfordschools.example/careers/how-we-hire-teachers (search result text only; page not fetched)
- `Halvering Elementary School Orrinsford district news improvement plan` returned orrinsfordschools.example/news/board-adopts-literacy-plan (search result text only; page not fetched)
- `Dolores Vantongeren principal Halvering Elementary` returned ilprincipalsforum.example/speakers/dolores-vantongeren (search result text only; page not fetched)
- `fourth grade teacher job description Illinois elementary` returned k12jobsboard.example/listings/fourth-grade-teacher

Fetches: orrinsfordschools.example/about/mission-and-beliefs and k12jobsboard.example/listings/fourth-grade-teacher.

No dossier was present.

## Upgrade menu

- Halvering's own posting text → F2, F3, F5 and F9 move from `[inferred]` to `[grounded]`, and the JD-tagged questions rebuild on the district's real list
- Your answers to the answer slots in F2, F7, F8 and F9 → those rows get quoted evidence, and their guidance becomes story-mapped instead of slot-based
- The names of the two fourth-grade team members → a Peer persona read from their public footprint, and a reverse question for each
- A deeper research pass (L2: up to 6 more searches and 2 more fetches, several more minutes) → a grounding brief on the literacy plan and recent district context, plus loop reports for this role
- A note from the school about what the panel will cover, or any task it asks you to prepare → a build section for that task
- An artifact that shows the 2024 curriculum move, such as a rollout plan, training schedule or grade-level meeting notes you wrote → F5 and F6 can rise from medium toward high, and D1 can be story-mapped
- How many hours you have before Thursday → a prioritized rehearsal order
- A tuesday-dossier.md, if you have one → verified evidence and sharper limits on what the pack may say about you
