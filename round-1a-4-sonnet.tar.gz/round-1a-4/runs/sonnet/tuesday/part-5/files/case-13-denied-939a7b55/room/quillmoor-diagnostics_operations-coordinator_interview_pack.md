# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen with Hannah Lowther, Talent Partner. A 30-minute phone call, Thursday at 2pm; she rings the mobile number on your application. Her stated agenda: salary expectations, notice period, how the hybrid pattern would work for you, what's prompting a move, then the team and next steps.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Whether past behavior shows the company's published values. No question carries it here: no published values were in hand |
| EXP | Whether your account of your own work survives scrutiny; what was actually you |
| JD | The advert's stated duties, requirements and terms, gaps included |
| CO | What you know about the company and why it, and this role |
| CASE | A short live problem from the role, scored on structure |

An answer slot is an instruction for the interview, not a question for you now. Highest-ROI prep in this pack: B1.

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | No gap, but a self-stated line with nothing inspected behind it, so expect a probe on it. Say it in the quote's own terms: four years, as a logistics coordinator, at a building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says deliveries for three depots, not production schedules, and it names no other team. The words stay at the quote's scope: "I schedule deliveries for our three depots." Answer slot: the advert's coordination line makes a probe on who you worked with likely. If your scheduling for the three depots involved working with other teams, say which and what part was yours, in your own words; if it did not, or the arrangement was not yours, say so plainly and stay with the three depots |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | low | [inferred] | discovery | The quote touches this without showing it, and the bridge should not be stretched. Answer slot: the advert's tracking line makes a probe on how you knew an order had slipped likely. Say how you found out, in your own words; if it was not something you tracked, or someone else told you, say so plainly and stay with chasing suppliers when orders slip |
| F4 | "chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The quote already carries the action. Lead with your own verb and noun: "I chase suppliers when orders slip." Keep the advert's wording out of your own history; a named action beats an adjective |
| F5 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | presentation | The quote reaches stock accuracy in other terms: counts and discrepancies. Say it in those terms, with "about" and "over a year" kept on the figure, and do not call the spreadsheet your stock records. Expect a probe on how the figure was counted |
| F6 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: the advert's weekly line makes a probe on regular reporting likely. If you produced any regular figures on deliveries, say what and how often, in your own words; if you did not, or it was not yours, say so plainly and say how you would start |
| F7 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The quote says spreadsheet and does not say Excel. Answer slot: the advert's Excel line makes a probe on the tool likely. Say what the spreadsheet was built in and what you did in it, in your own words; if it was not Excel, say so plainly and say what it was |
| F8 | "ERP experience (SAP or similar) a plus" — advert, the SAP part | "Never used SAP — we run our own in-house stock system." — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. The advert lists it as a plus. Words: "I haven't used SAP." Then how you would learn it, said as a plan and never as a past. Nothing added to make the gap feel smaller |
| F9 | "ERP experience (SAP or similar) a plus" — advert, the "or similar" part | "we run our own in-house stock system" — your message | low | [inferred] | discovery | The quote says your company runs the system, not what you did in it. Answer slot: the advert's "or similar" makes a probe on the in-house system likely. If you used it, say what for, in your own words; if you did not, or it was not yours, say so plainly and stay with the stock-count spreadsheet |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | high | [grounded] | none | A term, and your own words cover it: "I'm hoping for £42,000." The figure sits inside the advert's band. It raises nothing else here |
| F11 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | A term, met on your own words, said whole and kept at their scope. If the days or the journey come up, return to the same words |
| F12 | "your notice period" — Hannah's message | none given | none | [grounded] | hard_gate | Your material does not establish this |
| F13 | "what's prompting a move" — Hannah's message | "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | Your own words cover it, whole. Say them as stated; if Reading comes up, return to the same sentence |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; the four logistics topics and "walk me through your background" | High. A recruiter screen's prior is Conversational plus a light Skeptic, and Hannah's own message sets a four-topic agenda in that register | Answer A1 to A4 in your own words only; a 90-second arc for A5; treat the casual questions as scored |
| Skeptic | Quiet probing of the gaps: day-one weaknesses, the move into a manufacturer, ERP | Medium. The light Skeptic is the second part of the recruiter prior, and the advert's coordination and ERP lines are where F2, F8 and F9 get probed | Rehearse B1 until it is boring; bridges only from your quoted sentences; where there is no sentence, say the limit plainly |
| Data-Driven Prober | Checks the one figure and the Excel line | Medium. Recruiters rarely probe numbers, but F5's figure and F7's Excel line are the two places a screen can check | Know what you can say about how the figure was counted and say plainly what you do not know |
| Case / Strategist | A short scenario from the duties | Low. The advert's duties are scenario-shaped, but a recruiter screen seldom runs cases | Clarify, then who needs to know, then options, then what you would record |
| Values / Behavioral | "Tell me about a time" | Low. Hannah's message names no values round and no published values were in hand | Pick one real instance, or say plainly that none comes to mind |
| Pressure | A time-boxed "why you" | Low. Recruiter screens rarely stress; two short items because "why you" often arrives against the clock | Pause, restate, hold what your sentence carries, concede the rest specifically |

No Peer Evaluator bank: Hannah is a recruiter and no peer round is named.

## Question banks

### A. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Logistics slot, your own words: "I'm hoping for £42,000." Say it once, plainly, and stop. If she asks again, repeat the same words. If she asks what you earn now, you can redirect to this role and say no figure for current pay | F10 is a term of the listed job and the first topic Hannah named; JD because it scores the advert's pay band |
| A2 | "What is your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, in your own words. Your material does not state it yet | F12 is the one agenda item your material leaves open; JD because it is a term of the listed job |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Logistics slot, your own words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on the days or the journey, your own words were those, and nothing is added | F11 is the advert's office pattern and the third topic Hannah named; JD because it scores a stated term |
| A4 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Logistics slot, your own words, whole: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Say it once and stop. If she asks about Reading, your own words were those | F13 is the fourth topic Hannah named; EXP because it tests whether your account of your own situation is consistent |
| A5 | "So — walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc on those three sentences, in that order, each told in your own words at its own scope: the four years in the role, the three depots and the suppliers, the stock-count spreadsheet and the fall in discrepancies. Stop and let her ask. Add no team, tool or system the sentences do not state | The biography question opens most screens; F1, F4 and F5 are the rows it draws on; EXP because it tests what was actually yours |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This role coordinates schedules across several teams in a manufacturer. What from your scheduling would carry over?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I schedule deliveries for our three depots and chase suppliers when orders slip." Follow-up one, which teams: answer slot, if your scheduling involved working with other teams, say which and what part was yours, in your own words; if it did not, or the arrangement was not yours, say so plainly and stay with the three depots. Follow-up two, it sounds like different work: concede only what the quote shows, "What I can speak to is scheduling deliveries for our three depots and chasing suppliers", and return to it rather than adding to it. Follow-up three, what you would learn first: answer as a plan, in your own words, never as a past | F2 is where the advert's coordination mandate presses hardest and your material is thinnest, so this objection arrives in some form; JD because it scores a stated duty | 
| B2 | "Which part of the advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Name the thinnest line yourself before she does. Your material carries nothing on weekly dispatch reporting (F6) and says you have not used SAP (F8). Words you can say from your own sentence: "I haven't used SAP." For any other line, answer slot: say which line, and what you would do first to close it; if you are unsure which, say so plainly | Skeptics ask this to test self-assessment; F6 and F8 are the rows it lands on; JD because it scores the advert's own list |
| B3 | "The advert mentions SAP or similar. What ERP experience do you have?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Start with your own sentence's first clause: "I haven't used SAP." Then answer slot: the advert's "or similar" makes a probe on your in-house system likely. If you used it, say what for, in your own words; if you did not, or it was not yours, say so plainly and stay with the stock-count spreadsheet. Then a plan for learning a new system, said as a plan | F8 is the stated gap and F9 the open part of the same advert line; the advert calls it a plus, so this is JD and a bridge, not a gate |
| B4 | "Why Quillmoor, and why this role?" | CO | [grounded] | Answer slot, in your own words: say what in the advert drew you. The advert's own facts are "diagnostic-test manufacturer, about 400 staff", and two days a week at the Avonmouth site in Bristol. If nothing in particular drew you yet, say so plainly and say what you would ask her about the team. No research on Quillmoor ran, so the pack supplies nothing about the company beyond the advert | Recruiters check that the move and the target agree; CO because it tests homework, and the label rests on the advert alone |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Four slots, each in your own words: how the discrepancies were counted, what the figure is sensitive to, the assumption behind it you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. Keep the quote's own terms on the figure: "about a third", "over a year" | F5's figure is the one magnet target on your material; EXP because it tests attribution and the weakest assumption |
| C2 | "How confident are you in Excel — what do you use it for?" | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: say what the stock-count spreadsheet was built in and what you did in it, in your own words; if it was not Excel, say so plainly and say what it was. Hold the quote's scope: you rebuilt the spreadsheet | F7 is the advert's "confident with Excel" line, and the quote says spreadsheet only; JD because it scores a stated requirement |
| C3 | "Tell me about reporting you've done on delivery performance." | JD | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Pick a regular figure you gave to someone about deliveries or stock: it needs a name for what it measured, how often, and who read it. If no such figure comes to mind, say so plainly, then give the nearest thing your material carries, "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year", or how you would start | F6 is the advert's weekly reporting line with nothing quoted behind it; JD because it scores a stated duty, asked as an open prompt |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you Thursday's order will now arrive next week, and the team planning around it is expecting it. What do you do?" | CASE | [generic] | Structure it: what you would ask the supplier first, who needs to know today, what the order feeds, your options, and what you would record. The question needs no claim about your past, so the guidance makes none | A live problem from the advert's supplier lines (F3, F4); CASE because it scores structure; generic because it is a pattern, not a fact about this employer |
| D2 | "On-time dispatch fell sharply this week. Where do you look first?" | CASE | [generic] | Clarify first: fell against what, and over how long. Then segment by site, product and cause, name the figure you would check before concluding, and say what you would report and to whom. The question needs no claim about your past | A live problem from the advert's dispatch reporting line (F6); generic for the same reason as D1 |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a supplier let you down." | EXP | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Story-mapped on the quote's own beats: an order slipped, and you chased the supplier. Answer slot: pick one instance and say what slipped and what you did, in your own words; if no single instance comes to mind, say so plainly and say how you chase suppliers when orders slip | F4 is the nearest quoted ground; EXP because it tests what was actually yours; asked as an open prompt from the advert's chasing line |
| E2 | "Tell me about a time you had to give someone news they didn't want." | EXP | [generic] | Pick a time with a named stake, a moment you said it anyway, and a working relationship intact afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | The Values persona's stem, included because a recruiter may ask it casually; generic because no published values were in hand |

### F. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you rather than someone who has worked in manufacturing?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Pause and restate the question. Hold only what the quote carries, "I schedule deliveries for our three depots and chase suppliers when orders slip", through two follow-ups. Concede specifically and keep it to the quote's scope: "What I can speak to is scheduling deliveries and chasing suppliers, and I would learn the rest." Never fold on the core sentence to restore harmony | F2 again, under time pressure; JD because it scores the same stated duty in a different delivery |
| F2 | "That drop in discrepancies — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The sentence gives one beat that is yours: "I rebuilt our stock-count spreadsheet." Whether the rebuild alone explains the fall is not stated. Answer slot: say which part of the fall you can attribute to the rebuild and which you cannot, in your own words; if you do not know, say so plainly. Hold the rebuild through two follow-ups and concede the rest specifically | F5's figure, tested for composure rather than counting; EXP because it scores attribution honesty |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in operations or logistics coordination" | A5 |
| "Coordinate production schedules between planning, the warehouse and QA" | B1, D1, F1 |
| "track supplier deliveries" | D1, E1 |
| "chase late orders" | D1, E1 |
| "keep stock records accurate" | A5, C1, F2 |
| "report weekly on on-time dispatch" | B2, C3, D2 |
| "confident with Excel" | C2 |
| "ERP experience (SAP or similar) a plus" | B2, B3 |
| "£38,000–£44,000" | A1 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A3 |
| "your notice period" | A2 |
| "what's prompting a move" | A4 |

B4 covers no requirement and tests the move against the target. E2 is the Values persona's stem and covers none, so it is generic.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Who would I work with day to day across planning, the warehouse and QA?" | It follows the advert's own coordination line and shows you read it, with no claim about your past |
| R2 | "How is on-time dispatch reported at the moment, and who reads it?" | It comes from the advert's weekly reporting line and tells you what to prepare for later rounds |
| R3 | "Which stock or ERP system does the team use, and how is training handled in the first weeks?" | It turns the SAP gap in F8 into a plan rather than a defence |
| R4 | "Why is the role open?" | It shows whether the team is growing or replacing, and recruiters answer it easily |
| R5 | "What would you want to see from a candidate at the next stage?" | It makes the next step concrete and shows you are thinking past this call |
| R6 | "What would a good first three months look like in this role?" | It shifts the conversation from your gaps to the work |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says deliveries for three depots, not production schedules. B1's slot stays inside the three depots |
| Tracked supplier deliveries | Inflated form of F3 | F3's quote at its own scope: "I chase suppliers when orders slip." The material says nothing of how slips were found |
| Kept the stock records accurate | Inflated form of F5 | F5's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The material says a spreadsheet and counts, not the records |
| Is confident or expert in Excel | Inflated form of F7 | F7's quote at its own scope: a stock-count spreadsheet. The material does not say what it was built in |
| Has SAP experience | Negative you stated, F8 | The plain acknowledgment F8 gives: "I haven't used SAP." No slot |
| Has used an ERP system | Inflated form of F9 | F9's quote at its own scope: "we run our own in-house stock system." The material says your company runs it, not what you did in it |

## Sources

Provided documents: the Operations Coordinator advert, Hannah Lowther's LinkedIn message, and your own description of your background and what you would tell her. No dossier was present.

Searches sent, each refused (the host did not grant search permission), so nothing came back:

- "Quillmoor Diagnostics values": refused
- "Quillmoor Diagnostics Avonmouth Bristol news strategy": refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics values` | unavailable | Every call was refused. It would have moved the CO and VAL wording in B4 and E2, and made a values cheat sheet possible only if a values round were documented |
| 2. `Quillmoor Diagnostics interview process operations coordinator` | skipped | Hannah's message fixes this session: a 30-minute phone call with her, so the persona weights follow a recruiter screen |
| 3. `Quillmoor Diagnostics strategy` / recent news | unavailable | Every call was refused. It would have moved B4 and the CASE bank to current company context |
| 4. `Hannah Lowther Quillmoor Diagnostics` | unavailable | Every call was refused. It would have added a reading of the interviewer and a reverse question tied to her own path |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period in your own words → F12 and A2 move from a bare instruction to your own words, quoted
- How you knew an order had slipped → F3 and E1 gain a quoted beat, and F3 moves off `discovery`
- Whether your scheduling involved working with other teams, and which → F2 and B1 gain a quoted beat for the deepest rehearsal in the pack
- Any regular figures you gave on deliveries or stock → F6 and C3 move from a scaffold to a story
- What your stock-count spreadsheet was built in, and what you did in it → F7 and C2 move off `discovery`
- What you did, if anything, in your company's in-house stock system → F9 and B3 move off `discovery`
- Web search permitted on this host → targets 1, 3 and 4 run: Quillmoor's published values, recent news, and Hannah's public footprint, which would add a CO bank grounded in current context and a reverse question tied to her path
- A deeper research pass (up to 6 further searches and 2 further fetches, several more minutes) → a strategy brief for the CO and CASE questions, offered once and run only on your say-so
- A `tuesday-dossier.md` from an earlier run → verified evidence and prohibited-claims constraints carried in, so the guidance rests on confirmed rows
