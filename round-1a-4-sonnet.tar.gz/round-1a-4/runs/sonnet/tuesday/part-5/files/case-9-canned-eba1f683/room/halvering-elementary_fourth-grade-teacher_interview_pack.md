# Interview pack: Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)

Round: 45-minute panel on Thursday. Principal Dolores Vantongeren plus two members of the fourth-grade team (names not given). Relationship: one hiring-manager seat and two peer seats.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the district's published beliefs |
| EXP | Whether your CV's claims survive scrutiny, and what was actually you |
| JD | The role's stated responsibilities and qualifications, gaps included |
| CO | Homework on the district and its current plans |
| CASE | A live problem from the role, scored on structure and reasoning |

Provenance labels: grounded means traceable to your material or a cited page; inferred means derived from a representative source, with the derivation named; generic means a role-family pattern with no claim about you or this employer. An answer slot is an instruction for the interview, not a question for you now. Bank IDs skip the letter F so they never collide with fit-snapshot rows F1 to F9.

## Fit snapshot

Requirements come from your invite, the district's own hiring page and beliefs page, and one representative fourth-grade posting from a job board (not this district's, so its rows are labeled inferred).

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement" — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your CV states as met: an Illinois PEL, Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029. Nothing was inspected here; the licence number is on your CV and no check of it was run. Checking that your record shows the same is yours, before Thursday. Lead with it as written if asked |
| F2 | "Panels ask about reading instruction" — district hiring page | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | transferability | Your material says a curriculum move you led and a club you run, not how you teach reading day to day. Words stay at that size: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: expect a probe on your own reading instruction. If anything about how you teach reading changed with that move, say what, in your own words; if nothing did, or it was not yours, say so plainly and stay with the move and the club |
| F3 | "Panels ask about … classroom routines" — district hiring page | none given | none | [grounded] | discovery | Nothing in your material speaks to routines. Answer slot: if you have routines you set for how a day or a block runs, say what students do and what you do, in your own words; if the school set them, or you have none to describe, say so plainly and say what you would put in place first |
| F4 | "communicate regularly with families" — representative posting, K12 Jobs Board | "I write a weekly email to families" — your CV | medium | [inferred] | none | No gap, but a CV line with nothing inspected behind it, so expect a probe on it. Lead with it in its own terms: you write it, and it goes weekly |
| F5 | "work with the grade-level team" — representative posting, K12 Jobs Board | "I led our grade level's move to a new reading curriculum in 2024" — your CV | medium | [inferred] | presentation | Your sentence already reaches team work in other terms: the move was your grade level's. The bridge rewords only that sentence: "I led our grade level's move to a new reading curriculum in 2024." It adds no stage, meeting or colleague you did not mention |
| F6 | "differentiate instruction using assessment data" — representative posting, K12 Jobs Board | none given | none | [inferred] | discovery | Nothing in your material speaks to using assessment data. Answer slot: if you group or adjust instruction from assessments, say what you look at and what you change, in your own words; if you do not, or it is set by someone else, say so plainly and say what you would look at first |
| F7 | "Fourth Grade Teacher position" — your invite | "I've never taught fourth grade" — your message; "Six years teaching third grade at a public elementary school in Joliet" — your CV | low | [grounded] | capability | A gap wording cannot close, and you stated it. Words: "I haven't taught fourth grade." Then the adjacent fact at its own size: "Six years teaching third grade at a public elementary school in Joliet." Then how you would learn it, said as a plan and never as a past. Never a claim to fourth-grade teaching |
| F8 | "each teacher speaks with every family each term" — district beliefs page | "I write a weekly email to families" — your CV | medium | [grounded] | transferability | The belief says speaks with; your sentence says writes to. Words stay at the email. Answer slot: if you also speak with families, say how and how often, in your own words; if you do not, say so plainly and say what you would do to meet the belief |
| F9 | "no student leaves third grade without a reading plan" — district beliefs page | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've run the after-school reading club for the last two years" — your CV | low | [grounded] | discovery | Your lines touch third-grade reading without showing a reading plan. Answer slot: if students in your room have reading plans, say what one holds and who writes it, in your own words; if there is no such document, or it is not yours, say so plainly and return to the club |

## Reading the interviewer

Only the principal is named. The two team members are unnamed, so no read of them exists. Public professional footprint only.

| Observation | Source | Provenance | What it means for you |
|---|---|---|---|
| Principal of Halvering Elementary since 2022, after nine years as a reading specialist | Illinois principals forum speaker page, via search result | [grounded] | Reading depth is likely to be probed by someone who spent nine years specializing in it: expect questions that go past the curriculum to how you teach (C1, D1, E1) |
| 2025 forum talk "Small Groups, Big Readers" on weekly reading conferences in grades 3 to 5 | Same page | [grounded] | Small-group and conference vocabulary may come up. Read the talk's page before Thursday. Use her words as vocabulary only; your material shows no conferences, so do not claim them |
| No career jump of hers is paralleled by a quoted sentence of yours | Fit snapshot F1 to F9 | [inferred] | No shared-jump mirror is offered. R1 asks about her talk instead |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Skeptic (weight 5) | Probes the fourth-grade gap, the move, and the team-lead line | Highest. The principal seat carries the hiring-manager prior (Case plus Skeptic), and you stated two negatives yourself, so this persona has the most material (F7) | Rehearse the A1 objection until it is boring: the plain acknowledgment from F7, the third-grade fact at its own size, a ramp stated as a plan |
| B Peer Evaluator (weight 4) | Two fourth-grade teachers asking what you would add to their team and how you share credit | High. Two of three seats are peers (peer prior: Peer plus Prober), and the posting lists the grade-level team | Reciprocity framing: what you bring, at the size of F5's sentence, and what you would ask for |
| C Case/Strategist (weight 3) | Live reading and assessment problems; the district's literacy plan | Medium. The district page says panels ask about reading instruction and routines, which suits live problems | Clarify, then objective, grouping, approach, check, next step; think aloud |
| D Values/Behavioral (weight 3) | Questions built on the district's three beliefs | Medium. The beliefs page says they guide every hire, but the hiring page names no values round, so none is detected | Map to a quoted sentence where one exists (F8, F9), a selection scaffold where none does |
| E Data-Driven Prober (weight 2) | Asks how you know the curriculum or club is working | Low to medium. Your CV has no figures, so there is little to probe beyond F2 | Know what you can and cannot say about how anything was checked; say plainly when you do not know |
| G Conversational (weight 2) | Friendly opener and routines question | Medium for the opener; still scored | A short arc built only from your quoted lines |
| Pressure | Time-boxed challenge | Low. Nothing in the district's panel description points to it, so it has no bank | None needed |

## Question banks

Highest-ROI prep in this pack: A1, the fourth-grade objection. It is the question most likely to arrive in some form, and it has the most follow-up levels.

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't taught fourth grade. Why should we trust you with it?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | Hold the plain acknowledgment first: "I haven't taught fourth grade." Then the adjacent fact at its own size: "I have six years teaching third grade at a public elementary school in Joliet." Follow-up one asks what you would do in your first weeks. Answer slot: say what you would do first, as a plan in your own words. Follow-up two presses on what you do not yet know; concede one thing specifically rather than claiming readiness. Answer slot: if you already know what changes between third and fourth grade, say what and how you know; if you do not yet, say so plainly | F7 is your stated gap and the likeliest probe, so this gets the deepest rehearsal; JD because it scores the role's grade level, with a hold-then-concede structure borrowed from the pressure bar |
| A2 | "You led your grade level's move to a new reading curriculum but have never been a team lead. What was your role?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Say the sentence you have: "I led our grade level's move to a new reading curriculum in 2024." If the panel sets it against your own statement, the plain acknowledgment is: "I've never been a team lead." Answer slot: if the move came with any formal role, say what it was; if you led it without one, say so plainly; if part of it was someone else's to lead, say whose part. Add no stage or result you did not mention | F2 and F5 are where attribution gets tested; EXP because it scores what was actually yours |
| A3 | "Why move from third grade in Joliet to fourth grade here?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Your material gives no reason for the move and the pack will not supply one. Pick a reason that is true, specific to this school or this grade, and checkable. The district's published beliefs are Every Child a Reader, Families Are Partners, and Teach for Tomorrow, Not for the Test; a true link to one of them is usable. If no reason beyond wanting a change comes to mind, say that plainly, then say what you want from the move | Motivation consistency is the Skeptic's core score; F7 is why the question has an edge |
| A4 | "Which part of this job do you expect to need the most help with from the team?" | JD | [generic] | The question needs no claim about your past, so the guidance makes none. Name one real area in your own words, what you would ask the team for, and what you would try first. Naming something unrelated to dodge F7 is a choice the panel can see | Honest self-assessment, asked collegially; ties to F7 and F5 |
| A5 | "What would a colleague say is hardest about working with you?" | EXP | [generic] | Pick a real tendency and give an example in your own words. If no example comes to mind, say so plainly, then say how you handle it today or how you would | Skeptic probe on self-awareness; no row carries it, so the guidance is a scaffold |

### B. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our fourth-grade team plans together. What would you bring us, and what would you need from us?" | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Reciprocity first. What you bring, at its own size: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if colleagues' input shaped that move, say how; if it did not, say so plainly. What you would need: "I haven't taught fourth grade" is true, so ask for what a new fourth-grade teacher would want, in your own words | F5 supplies the team-work requirement; the question comes from the posting's team line, so inferred |
| B2 | "How do you handle credit when a result belongs to a whole team?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Use we for context and I for your part. The sentence gives you: the move, your grade level, 2024. Answer slot: whose work was in it besides yours and how credit was shared; if no moment of shared credit comes to mind, say so plainly and say how you would share it | Peer personas test credit-sharing; F2 and F5 are the only team-scale evidence |
| B3 | "A teammate teaches reading very differently than you do. How do you work that out?" | CASE | [generic] | Structure it: ask what the teammate's students need, compare what each approach is doing for them, agree what to share and what stays individual, set a time to revisit. The question needs no claim about your past, so the guidance makes none | A live collaboration problem; no row needed |
| B4 | "Tell me about a time you disagreed with a colleague about what was best for students." | VAL | [generic] | Pick a time with a named disagreement, what you did, and the working relationship intact afterward. None of your CV lines carries one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | Peer disagreement stem; a selection scaffold because no quoted sentence holds a story |

### C. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk us through the first twenty minutes of a reading block with a class reading at very different levels." | CASE | [generic] | Clarify first: how many levels, what data you have. Then objective, grouping, what each group does, how you check understanding, what you would adjust next. Say aloud that assessments inform your teaching and never replace it, which is the district's own published line. No claim about your past | F2 and F6 requirements, asked as a live problem; the principal's reading background makes depth likely (Reading the interviewer) |
| C2 | "The Board's literacy plan includes a new grades 3–5 reading curriculum from fall 2027. How would you want to be part of that?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you know the plan in one sentence, then give your own view of what you would want to learn from the rollout. Your own side is the sentence at its own size: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if anything from that move would carry over, say what, in your own words; if nothing would, say so plainly and say what you would ask first | The plan was read in a search result, not fetched (Sources); F2 is the only curriculum evidence |
| C3 | "A family tells you their child's reading is fine and your assessments say otherwise. What do you do?" | CASE | [generic] | Structure it: listen first, show the child's work next to what the assessment shows, agree one next step, set a follow-up. The question needs no claim about your past | Live problem joining the families belief (F8) and the assessments belief (F6) |

### D. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Every Child a Reader means no student leaves third grade without a reading plan. You've spent six years in third grade. What does that look like in your room?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years" | Answer slot: if students in your room have reading plans, say what one holds and who writes it, in your own words; if there is no such document, or it is not yours, say so plainly and return to the club: "I've run the after-school reading club for the last two years." | F9 is thin; the belief is the district's own published words |
| D2 | "Families Are Partners means each teacher speaks with every family each term. How do you stay in touch with families?" | VAL | [grounded] "I write a weekly email to families" | Start at its size: "I write a weekly email to families." The belief says speaks with; an email is not a conversation, and a panel may say so. Answer slot: if you also speak with families, say how and how often; if you do not, say so plainly and say what you would do to meet the belief | F8 and F4 |
| D3 | "Teach for Tomorrow, Not for the Test means assessments inform teaching and never replace it. Tell me about a time an assessment changed what you did with a student or a group." | VAL | [generic] | Pick a time with a named assessment, what it showed, what you changed. None of your lines carries one. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6 is discovery; the theme comes from the district's published belief |

### E. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "How did your grade level check whether the new reading curriculum was helping students?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Hold to the sentence: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: if the grade level checked how it was going, say what it looked at and what part was yours; if nobody did, or it was not yours, say so plainly and say what you would look at now. Do not offer a number you cannot say how it was counted | F2; the question's premise comes from the district's assessments belief, so the second branch allows it never happened |
| E2 | "What do you track about the after-school reading club, and what has it shown?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | At its size: "I've run the after-school reading club for the last two years." Answer slot: if you track anything about it, say what and how it was counted; if you do not, say so plainly and say what you would look at if asked tomorrow | F2 and F9; no figure is on your CV, so the prober goes to the practice |

### G. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, tell us about your journey and where you are now." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I led our grade level's move to a new reading curriculum in 2024"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc with three beats your lines carry: six years teaching third grade at a public elementary school in Joliet; the curriculum move and the club; the weekly email to families. Answer slot: why you entered teaching and why this move are not in your material; say them in your own words or leave them out. End on why fourth grade here, as in A3 | The opener is scored; F2, F4, F7 |
| G2 | "Walk us through a normal morning in your room, from the bell to the first lesson." | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | The district page says panels ask about classroom routines. Answer slot: if you have routines you set for how the morning runs, say what students do and what you do, in your own words; if the school set them, or you have none to describe, say so plainly and describe your part | F3 is discovery; the question stays casual but is scored |

### Requirement coverage

| Requirement | Questions |
|---|---|
| Illinois PEL with elementary endorsement (F1) | none, and why: a gate your CV states as met; the district's panel description does not list it as a panel topic |
| Reading instruction (F2) | C1, C2, D1, E1, E2 |
| Classroom routines (F3) | G2 |
| Communicate with families (F4) | D2 |
| Work with the grade-level team (F5) | A2, B1, B2, B3, B4 |
| Differentiate using assessment data (F6) | C1, C3, D3 |
| Fourth grade role (F7) | A1, A3, A4 |
| Families Are Partners (F8) | D2, C3 |
| Every Child a Reader (F9) | D1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "I read about your talk on weekly reading conferences in grades 3 to 5. How do those show up in fourth grade here?" | Ties to the principal's own published work and shows you read it. Read the talk's page first |
| R2 | "What helps a teacher who is new to fourth grade get up to speed here?" | Names the F7 gap as a plan to be answered rather than a flaw to be found |
| R3 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity question for the two peers |
| R4 | "How is the new grades 3–5 reading curriculum, due from fall 2027, expected to reach fourth grade here?" | Shows you read the Board's literacy plan and asks about your own grade |
| R5 | "The district says each teacher speaks with every family each term. What does that look like in practice at Halvering?" | Turns the belief into a concrete picture and gives you something to compare to D2 |
| R6 | "What would you want to see from a new fourth-grade teacher by the end of the first term?" | Gets the panel's own bar and gives you a target |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Fourth-grade teaching experience | Negative you stated, F7 | The plain acknowledgment: "I haven't taught fourth grade." Then the third-grade sentence at its own size. No slot |
| Having been a team lead | Negative you stated: "I've never been a team lead" — your message | The plain acknowledgment: "I've never been a team lead." The move you led stays at its own size (F5) |
| Spoke with every family each term | Inflated form of F8 | F8's quote at its own scope. The limit is the pack's observation: your material says a weekly email, not conversations. D2's slot asks only about what you do beyond the email |
| Led the school's or district's reading change | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says your grade level's move. E1's slot stays inside that move |

## Sources

Provided documents: the invite text and your resume text, both in your message. No tuesday-dossier.md was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford values | yes | The beliefs page was fetched in full: D1 to D3, F8, F9. No values cheat sheet: the careers page names no round that assesses values, so none is detected |
| 2. Interview process | yes | The careers page was fetched in full: one 45-minute building panel, the principal plus two grade-level teachers, which matches your invite; persona weights follow it |
| 3. Strategy and recent news | yes | The Board's literacy plan, read in a search result and not fetched: C2, R4. Its adoption date and contents are as that result gave them |
| 4. Interviewer, Dolores Vantongeren | yes | Principal background and talk title from one search result, not fetched: Reading the interviewer, R1 |
| 5. Representative fourth-grade posting | yes | A job-board listing returned, not this district's: F4, F5, F6 requirement wording, labeled inferred. Its snippet was cut off, so nothing from its qualifications is quoted |

Queries and what came back:

- "Orrinsford Community School District mission values" returned https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District fourth grade teacher interview" returned https://orrinsfordschools.example/careers/how-we-hire-teachers
- "Orrinsford Community School District strategic plan news" returned https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren Halvering Elementary School principal" returned https://ilprincipalsforum.example/speakers/dolores-vantongeren
- "Fourth Grade Teacher job posting Halvering Elementary School Orrinsford" returned https://k12jobsboard.example/listings/fourth-grade-teacher
- Fetch of https://orrinsfordschools.example/about/mission-and-beliefs returned the page
- Fetch of https://orrinsfordschools.example/careers/how-we-hire-teachers returned the page

## Upgrade menu

- The full posting text → F4, F5 and F6 move from inferred to grounded, and any requirement the representative posting missed gets a row and a question
- Anything HR said to prepare, such as a sample lesson or a writing sample → a build section for it
- The two team members' names → an interviewer read for each and persona weights per seat
- Your answers to the answer slots in A1, A2, E1, E2, D1 and G2 → rows F2, F3 and F9 move from discovery or transferability toward grounded evidence, and the pack quotes your words
- The text of the principal's talk → a sharper R1 and a better read of her vocabulary
- A tuesday-dossier.md from an earlier fit review, if you have one → verified evidence quotes and a strategy per weak area
