# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

**Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
**Round:** 45-minute panel on Thursday: Principal Dolores Vantongeren and two members of the fourth-grade team (names not given)
**Built on:** your invite, your resume text, the district's published pages and a representative fourth-grade listing. No posting was supplied, so rows from the listing are labeled `[inferred]`.

## How to use this pack

- Personas are how a question arrives. Types are what it is scoring.
- Types: VAL is behavioral or values alignment, against the district's published beliefs. EXP is a work-experience deep-dive: do your claims survive scrutiny. JD is a role requirement. CO is company and strategy knowledge. CASE is a live problem from the role.
- Guidance is scaffolding, not a script. Every sentence about your past is one you wrote, quoted in the row. An answer slot is an instruction for the interview: answer it from your own experience, or say plainly that the practice was not yours or did not exist.
- Bank letters skip F so they do not collide with fit rows F1 to F7.
- The highest-ROI prep in this pack is A1, the fourth-grade question. It will be asked in some form.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — your invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | The gate is shown met by your own statement. Say it in those terms: the license, the Elementary Education endorsement, active through June 30, 2029. The pack's observation: the grade range in your quote, 1–6, includes grade 4. Nothing here has been checked against the issuing record, and that check is yours to make before Thursday |
| F2 | the Fourth Grade Teacher position at Halvering Elementary School — your invite | "Six years teaching third grade at a public elementary school in Joliet." — your CV; "I've never taught fourth grade" — your message | medium | [grounded] | transferability | Words: "I've never taught fourth grade." Then your third-grade sentence at its own scope, "Six years teaching third grade at a public elementary school in Joliet." The pack's observation: your material shows third grade, not fourth. Answer slot: the invite names fourth grade, so expect a probe on what changes. If you know what changes, say so in your own words; if you have not looked, say so plainly and say how you would find out |
| F3 | "Panels ask about reading instruction, classroom routines and how you work with families." — Orrinsford "How we hire teachers" (search excerpt), reading instruction | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | low | [inferred] | discovery | Your two sentences show a curriculum move you led and a club you run. They do not show what your own reading time looks like, and the words stay at those two quotes. Answer slot: the district names reading instruction as a panel topic, so expect a probe on your own reading block. If you can describe it, say what it looks like in your own words; if it was set by the curriculum or by someone else, say so plainly and return to the move you led and the club you run |
| F4 | same excerpt, classroom routines — Orrinsford "How we hire teachers" (search excerpt) | none given | none | [grounded] | discovery | Your material does not show this one. Strong evidence would be one or two routines you can name and describe how you teach. Answer slot: if you run routines of your own, name one or two and say how you teach them; if there are none of yours to name, or they were set for you, say so plainly and say what you would put in place first in a new grade |
| F5 | "Families Are Partners: each teacher speaks with every family each term." — Orrinsford "Mission and Beliefs" (fetched) | "I write a weekly email to families." — your CV | medium | [inferred] | discovery | Your sentence is an email, and the belief says speaks with. Words stay at "I write a weekly email to families." Answer slot: if you also speak with families directly, say how, in your own words; if the email is your main channel, say so plainly and stay with the email |
| F6 | "work with the grade-level team" — K12 Jobs Board listing "Fourth Grade Teacher" (search excerpt) | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | presentation | Words: "In 2024 I led our grade level's move to a new reading curriculum." The pack's observation: your material separates leading that move from holding a team-lead role, so keep led the move for the one, and for the other say "I've never been a team lead." |
| F7 | "differentiate instruction using assessment data" — K12 Jobs Board listing (search excerpt); "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it." — Orrinsford "Mission and Beliefs" (fetched) | none given | none | [inferred] | discovery | Your material does not show this one. Strong evidence would be one case where assessment results changed what you taught. Answer slot: if results have changed a lesson or a group for you, say one case in your own words; if they have not, or the curriculum decides, say so plainly and say how you would approach it |

## Reading the interviewer

| Public fact | Source | What it means for you | Provenance |
|---|---|---|---|
| "Dolores Vantongeren has been principal of Halvering Elementary School since 2022, after nine years as a reading specialist." | Illinois principals forum speaker page (search excerpt) | Reading is her professional ground, so expect the reading-instruction probe (F3) from her. Rehearse it first among the panel's topics | [inferred] |
| "Her 2025 forum talk, Small Groups, Big Readers, covered weekly reading conferences in grades 3 to 5." | same page | Her stated range includes grade 3, where your six years sit, and grade 4. Listen for small groups and conferences and ask her about them (RQ1). Do not claim either practice: nothing in your material says you do | [inferred] |
| "the principal and two grade-level teachers" | Orrinsford "How we hire teachers" (search excerpt) | The two teachers are unnamed, so they are weighted as peers. Their names would sharpen the weights | [inferred] |

No mirror opportunities are offered: no row's evidence carries a candidate side to a shared professional path.

## Persona table

Loop: one 45-minute panel, established by your invite and the district's hiring page, so no archetype fallback applies.

| Persona | How it shows up here | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | The principal probing the fourth-grade gap and motivation | high | A principal sits in the hiring-manager row, which weights Case/Strategist and Skeptic. F2 holds the pack's clearest gap | Rehearse the F2 objection until it is boring. Bridge only from sentences you wrote, and name the limit before it is asked |
| Peer Evaluator | The two teachers asking about fit with the team | high | Two of the three panelists are grade-level teachers, a peer row | Reciprocity: what you bring the team, not only what you need. Propose how to find the seams rather than pretending to know them |
| Case/Strategist | The principal setting live problems in reading and routines | medium | Hiring-manager row, plus the district's excerpt naming reading instruction and classroom routines as panel topics | Clarify, objective, approach, how you would check, risks. Think aloud |
| Data-Driven Prober | Peers asking how anything was checked | medium | Peer row. Your material gives no figures, so probes aim at how things were checked (F7), not at numbers | Say what was checked and what part was yours. Say plainly when nothing was |
| Values/Behavioral | Stories against the three published beliefs | medium | The district says its three beliefs guide every hire, but no source names a values round, so this is a lighter tilt, not a round | Map a story to a belief where one of your sentences carries it. Where none does, use the scaffold and its honest branch |
| Conversational | The opening and the license confirmation | low | The invite names no rapport stage, and the persona's stems fit an opener | Keep the opening to your own sentences. Treat casual questions as scored |
| Pressure | Not expected | low | No member's relationship row and no public source points to it, so no bank | none |

## Question banks

### A. Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've taught third grade. What do you expect to be hardest about fourth grade in your first month?" | JD | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I've never taught fourth grade" | The highest-ROI rehearsal in this pack. Say the limit first, in your words: "I've never taught fourth grade." Then your third-grade sentence as it stands. Answer slot: if you know what is hardest, say it in your own words; if you have not looked, say so plainly and say how you would find out. Follow-up one, "What makes you think third grade carries over?": name only what you can say you expect to carry over, in your own words; if you are not sure, say so plainly. Follow-up two, "And if it doesn't?": a plan, not a past: you would ask the two teachers on this team | F2 is the clearest gap and the likeliest first probe; JD because it scores the position's stated grade |
| A2 | "You led your grade level's move to a new reading curriculum, but you haven't been a team lead. How do you see the difference?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" "I've never been a team lead" | Hold both sentences as you wrote them. "I led our grade level's move to a new reading curriculum in 2024. I've never been a team lead." Do not turn either into the other. Answer slot: how the two differ is yours to say; if you have not thought about it, say so plainly and return to what you led | F6 holds both facts side by side; EXP because it tests what was actually yours |
| A3 | "What would you want to know about our fourth graders and our fourth-grade year before your first day?" | JD | [generic] | Bring two or three questions of your own. Candidates: where the class is in reading, how the team sets routines, how reading plans carry from third grade (the district's published belief names them). Asking well here is the answer; it makes no claim about your past | F2 again, from the angle of how you would learn the grade; no claim about your past |
| A4 | "Why fourth grade, and why now?" | JD | [generic] | Give one reason specific to fourth grade and one specific to Halvering, each something you can say and expand on. If you cannot name a reason specific to fourth grade, say so plainly, then say what draws you to this role | F2 motivation; a Skeptic scores consistency, not enthusiasm |
| A5 | "Why should we hire a teacher who is new to fourth grade?" | JD | [grounded] "I've never taught fourth grade" "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families." | Pick one or two of your sentences and say them as they stand; let the panel draw the inference. Hold through two follow-ups by returning to the sentences. If pushed that a club is not a classroom, concede the scope: the club is after school, and you have never taught fourth grade | F2 and F6 under pressure; the hold is only what your quotes carry |

### B. Peer Evaluator (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where do you see your work fitting alongside ours, and what happens when we disagree?" | JD | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Offer what you bring in one sentence of yours: "I led our grade level's move to a new reading curriculum in 2024." Say how you would find the seams rather than assuming them. Answer slot: if you have disagreed with a grade-level colleague, say what it was about and how it ended; if you have not, say so plainly and say how you would handle it | F6; two of the three panelists are peers, so collaboration is scored by equals |
| B2 | "You'd be new to our fourth-grade team. What would you need from us in your first month, and what could you offer?" | JD | [generic] | Ask for what you would need, as a short list of your own, and offer one thing. It makes no claim about your past | F6 and F2; the reciprocity question a peer asks |
| B3 | "Tell us what the 2024 reading-curriculum move was like for the other teachers on your grade level." | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | The sentence is the story: your grade level, a new reading curriculum, 2024, you led the move. Answer slot: if you worked with the other teachers during the move, say what you did with them in your own words; if the move did not involve you working with them directly, say so plainly and return to leading the move | F6; EXP because peers test credit and what was actually yours |
| B4 | "What has the after-school reading club shown you that could help in a fourth-grade classroom?" | EXP | [grounded] "I've run the after-school reading club for the last two years" | Start from the sentence: you have run the club for the last two years. Answer slot: if the club has shown you something, say what, in your own words; if it has not yet, say so plainly and describe the club | F3; a peer pricing what you would add to their work |

### C. Case/Strategist (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A fourth grader reads aloud smoothly but can't tell you what the passage said. What do you do in the first two weeks?" | CASE | [generic] | Structure it aloud: what you would ask first (what is known of this child's reading, what has been tried, what the family sees), the objective, your approach, how you would check it, who you would talk to. It needs no claim about your past, so the guidance makes none | F3; a live problem set in the role, aimed at a principal with a reading background |
| C2 | "It's the second week of school and your fourth graders aren't following your classroom routines. Walk us through it." | CASE | [generic] | Clarify which routine and which students, then the objective, the approach, how you would check, and one risk. The question asks about no past | F4; the district names classroom routines as a panel topic |
| C3 | "The board adopted a 2026–2029 literacy plan with a new grades 3–5 reading curriculum from fall 2027. As a fourth-grade teacher, what would you want to know about it?" | CO | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Show you read it: the new curriculum covers grades 3–5, so it reaches fourth grade. Your one nearby sentence is "I led our grade level's move to a new reading curriculum in 2024", and it shows a move you led, not that you know this one. Answer slot: if you can say what you would bring from that move, say it in your own words; if the choices in it were not yours, say so plainly, then say what you would want to learn about the new curriculum | F3 and F6; the strategy question most candidates cannot touch, grounded in the fetched board item |

### D. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How did your grade level know the new reading curriculum was working?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Stay inside the move you led. Answer slot: the district says assessments inform teaching, so expect this probe. If your grade level checked how it was going, say what was looked at, by whom, and what part was yours; if nothing was checked, or it was not yours, say so plainly and return to leading the move | F7; no figure on your CV, so the probe lands on how anything was checked |
| D2 | "Tell me about a time assessment results changed what you taught." | JD | [grounded] | Pick a time results changed a lesson, a group or a plan. It needs a named result, what you changed, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F7; the open prompt follows the district's published belief on assessments |
| D3 | "How do you decide what goes in your weekly family email, and how do you know families read it?" | EXP | [grounded] "I write a weekly email to families." | Start from the sentence as it stands. Answer slot: the belief on families and the listing's regular-communication line make this probe likely. If you have a way of deciding what goes in, say how; if you do not track whether families read it, say so plainly and stay with the email | F5; EXP because probers test how a habit is run |

### E. Values/Behavioral (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell us about a time you worked with a family to help a student." | VAL | [grounded] "I write a weekly email to families." | Selection scaffold: pick a time with a named student need (no names), what you and the family each did, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I write a weekly email to families.", or how you would handle it | F5; the published belief on families as partners |
| E2 | "Tell us about a time you helped a struggling reader." | VAL | [grounded] "I've run the after-school reading club for the last two years" | Selection scaffold: pick a reader, what was in the way, what you did, and what changed afterward. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I've run the after-school reading club for the last two years", or how you would handle it | F3; the published belief that every child is a reader |
| E3 | "Which of our three beliefs is closest to how you already teach, and which would stretch you?" | VAL | [grounded] "I write a weekly email to families." "I've run the after-school reading club for the last two years" | Choose from your own sentences: for families, "I write a weekly email to families."; for reading, "I've run the after-school reading club for the last two years". Say plainly which belief would stretch you, in your own words | F5 and F3; asks you to rank, which tests honesty more than any single story |

### G. Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk us through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet." "I led our grade level's move to a new reading curriculum in 2024" "I've run the after-school reading club for the last two years" "I write a weekly email to families." | A four-beat arc, one beat per sentence, in the tense that is true for you: six years teaching third grade at a public elementary school in Joliet; in 2024 you led your grade level's move to a new reading curriculum; you have run the after-school reading club for the last two years; you write a weekly email to families. Then why this role: that reason is yours to say, and the pack does not supply it | F2 and F6; a casual opener that is still scored |
| G2 | "Tell us about your license and endorsement." | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it as you wrote it: the Illinois Professional Educator License, the Elementary Education endorsement for grades 1–6, active through June 30, 2029. Add nothing | F1; the invite's one hard requirement, covered by a confirmation question |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 license | G2 |
| F2 fourth grade | A1, A3, A4, A5, G1 |
| F3 reading instruction | B4, C1, C3, E2, E3 |
| F4 classroom routines | C2 |
| F5 families | D3, E1, E3 |
| F6 grade-level team | A2, B1, B2, B3, C3 |
| F7 assessment | D1, D2 |

Your material states no figures, so there are no defend-the-number questions.

## Reverse questions

| # | Question | Why it lands | Provenance |
|---|---|---|---|
| RQ1 | "Before you became principal you spent nine years as a reading specialist. What from that work shapes how reading runs in fourth grade here?" | Ties to her own path and invites her to talk about what she cares about | [grounded] |
| RQ2 | "The literacy plan brings a new grades 3–5 reading curriculum from fall 2027. What would you hope a fourth-grade teacher is doing between now and then?" | Shows you read the plan and asks what the role is for | [grounded] |
| RQ3 | "What could a new person do in their first month that would genuinely help the fourth-grade team?" | The reciprocity question for the two peers | [generic] |
| RQ4 | "How does the fourth-grade team make decisions together, and how do new teachers usually join in?" | Signals you think about the team, which F6 needs | [generic] |
| RQ5 | "Each school holds a family reading night each term under the plan. How do fourth-grade teachers take part?" | Connects the family belief to a concrete event | [grounded] |
| RQ6 | "References are taken up after the panel. Is there anything I should have ready?" | Shows readiness and clarifies the next step | [grounded] |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or has fourth-grade experience | Negative the candidate stated, F2 | The plain acknowledgment "I've never taught fourth grade", beside "Six years teaching third grade at a public elementary school in Joliet." No slot |
| Has been a team lead or grade-level lead | Negative the candidate stated, F6 | The plain acknowledgment "I've never been a team lead", with "I led our grade level's move to a new reading curriculum in 2024" at its own scope. No slot |
| Chose or designed the new curriculum, or raised results with it | Inflated form of "I led our grade level's move to a new reading curriculum in 2024" | The quote at its own scope. The limit is the pack's observation: your sentence says you led the move, not who chose the curriculum or what it did. B3 and D1 stay inside the move |
| Runs a reading program for the school | Inflated form of "I've run the after-school reading club for the last two years" | The quote at its own scope. The limit is the pack's observation: your sentence says a club, after school. B4 stays inside the club |
| Speaks with every family | Inflated form of "I write a weekly email to families." | The quote at its own scope. The limit is the pack's observation: your sentence says an email, not conversations. D3 and E1 stay at the email |

## Sources

Provided: the invite and your resume text. No dossier was present.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | yes | Fetched the district's "Mission and Beliefs" page: three beliefs by name. They themed E1 to E3, F5 and F7. No values cheat sheet: no source names a values round |
| 2. `{company} interview process {role family}` | yes | The district's "How we hire teachers" excerpt: one 45-minute building panel, principal and two grade-level teachers, topics named. It set the loop, the persona weights, F3 and F4 |
| 3. `{company} strategy` / recent news | yes | Fetched the board's literacy-plan item: C3, RQ2 and RQ5 |
| 4. `{interviewer name} {company}` | yes | The speaker-page excerpt: the interviewer read and RQ1 |
| 5. representative `{role title}` JD | yes | The K12 Jobs Board excerpt, since no posting was supplied: F6 and F7 are `[inferred]` from it |

Queries and what came back:

- "Orrinsford Community School District mission values": https://orrinsfordschools.example/about/mission-and-beliefs
- "Orrinsford Community School District teacher interview process": https://orrinsfordschools.example/careers/how-we-hire-teachers (excerpt only; page not fetched)
- "Orrinsford Community School District strategic plan": https://orrinsfordschools.example/news/board-adopts-literacy-plan
- "Dolores Vantongeren principal Halvering Elementary School": https://ilprincipalsforum.example/speakers/dolores-vantongeren (excerpt only; page not fetched)
- "fourth grade teacher job description Illinois elementary school responsibilities qualifications": https://k12jobsboard.example/listings/fourth-grade-teacher (excerpt only; page not fetched)
- Fetched: the mission page and the literacy-plan item above.

No license number or personal identifier was used in any query.

## Upgrade menu

- The full posting for this role → the two `[inferred]` requirements (F6, F7) become `[grounded]` where the posting states them, and any requirement it adds gets a question
- The names of the two fourth-grade teachers → per-member persona weights and a reverse question tied to each one's public path
- The hours you have before Thursday → a prep triage sized to them
- Any note from HR on what the panel will focus on, or anything to bring → coverage of it
- Your own answers to the slots in F2 to F7, said as you would in the interview → those rows' guidance becomes story-mapped
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → loop reports for this district, a deeper interviewer footprint and recent district context
- A `tuesday-dossier.md` from earlier work on this role → verified evidence and prohibited claims that tighten every guidance cell, never required
