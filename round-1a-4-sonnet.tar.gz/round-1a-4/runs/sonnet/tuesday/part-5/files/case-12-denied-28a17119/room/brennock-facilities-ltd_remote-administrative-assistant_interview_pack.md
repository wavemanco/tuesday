# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

- **Role:** Remote Administrative Assistant
- **Company:** Brennock Facilities Ltd
- **Interviewer:** the office manager, name not given. Format from your note: a 30-minute video call.
- **Built on this assumption:** the office manager is the person who would assign your work, so the weights follow a hiring-manager round. If they are a colleague on the team instead, the weights change (see the upgrade menu).

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did. An answer slot is an instruction for the interview and asks nothing of you here.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the values an employer cares about, not generic virtue |
| EXP | Whether the claims in your background survive follow-up questions |
| JD | Whether you can do the listed job, gaps included |
| CO | How well you know the company and its strategy |
| CASE | How you structure a live problem from the actual role |

The single highest-ROI rehearsal in this pack is **A1**, the supplier-invoice question. It will be asked in some form, because it is where the ad's wording and your material sit furthest apart (F4).

## Fit snapshot

Requirements are quoted from your description of the ad. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | transferability | Your words stay at their scope: "I ran the appointment book for four physios." The quote does not show whether the book held anything beyond appointments. Answer slot: expect a probe on how that compares with scheduling colleagues' time. If you also kept any colleague's time that was not appointments, say what; if the book was appointments only, say so plainly and stay with the book |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material is silent on this. Answer slot: the ad's travel line makes a probe on arrangements for other people likely. If you have booked travel or accommodation for anyone, say what and for whom, in your own words; if you have not, say so plainly, then say how you would learn the process |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | discovery | The quote gives a level for each program, not the documents. Say it at that rating: good with Word, okay with Excel. Answer slot: if you have prepared particular kinds of documents or sheets, name them in your own words; if you cannot pin your level to a document, say so plainly and stay with the level |
| F4 | "processing supplier invoices" — the ad, as you described it | "I ran the appointment book for four physios and chased unpaid invoices" — your message | medium | [grounded] | transferability | Your words stay at their scope: "I chased unpaid invoices." The quote does not show whose invoices they were, so the supplier side is not in the words. Answer slot: the ad's supplier-invoice line makes a probe on that side likely. If any invoices you dealt with were ones the clinic owed to suppliers, say what you did with them, in your own words; if none were, or it was not yours, say so plainly and stay with the chasing |
| F5 | "Remote Administrative Assistant" — the invite's title, as you pasted it | none given | none | [grounded] | discovery | Your material is silent on working at a distance from colleagues. Answer slot: expect a probe on working without anyone in the room. If you have worked from home or on your own away from colleagues, say how it went, in your own words; if you have not, say so plainly and say how you would organise your first week |

## Persona table

The loop comes from your own words: one 30-minute video call with the office manager. No archetype fallback is used.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (bank A, 5 questions) | Quiet probing of the thin rows: supplier invoices, travel, Excel level | High. F2 has no evidence and F4 is adjacent only, so these are the likeliest probes. A hiring-manager prior also carries a Skeptic | Rehearse the F4 objection until it is boring. Hold your own words, concede only what the quotes do not carry, and give any plan as a plan |
| Case / Strategist (bank B, 5 questions) | Live problems built from the ad's four duties | High. The ad is a list of tasks, and a hiring-manager prior carries live problems from the actual job | Clarify first, then options, then recommendation. Think aloud. These questions need no claim about your past |
| Conversational (bank C, 4 questions) | Friendly opener, then casual questions about Word and Excel and a normal day | Medium-high. A 30-minute video call almost always opens with "walk me through" | Prepare a 90-second arc from your quoted sentences. Treat the casual questions as scored |
| Data-Driven Prober (bank D, 3 questions) | Follow-ups on "four physios", on chasing invoices and on spreadsheets | Medium. Your material has a figure and a self-rated Excel level, both easy to follow up | Know what you can and cannot say about each, and say plainly where you do not know |
| Values / Behavioral (bank E, 2 questions) | "Tell me about a time" prompts | Low-medium. No published values or values round are in hand, but behavioral prompts still turn up in short calls | Pick real occasions only. Where none comes to mind, say so, then give the nearest thing your material carries |
| Pressure | Interruptions, time-boxing | Low. Not banked: nothing in a 30-minute office-manager call points to it | Pause, restate the question, hold your answer |
| Peer Evaluator | Seam-splitting, "what would you need from me" | Low. Not banked unless the office manager turns out to be a colleague rather than your manager | Reciprocity framing; see the upgrade menu |

## Question banks

### Requirement coverage

| Requirement | Question IDs |
|---|---|
| "managing calendars" | B1, D1 |
| "booking travel" | A3, B2 |
| "preparing documents in Word and Excel" | A2, B5, C3, C4, D3 |
| "processing supplier invoices" | A1, B3, D2 |
| Remote working (F5) | A4, A5, B4 |

### A. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The job is processing supplier invoices, and you've chased unpaid ones. How close are those two things?" | JD | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" | **The highest-ROI rehearsal in this pack.** Hold your own words: "I chased unpaid invoices." Through two follow-ups, return to the chasing rather than adding to it. Answer slot: if any invoices you dealt with were ones the clinic owed to suppliers, say what you did with them; if none were, or it was not yours, say so plainly and stay with the chasing. Then say how you would learn the supplier side, as a plan and never as a past | F4 is where the ad's wording and your material are furthest apart, so this objection arrives in some form. JD because it scores a stated duty; Skeptic because it presses on the gap |
| A2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel" | Name the part in your own words and say it plainly. Your own words rate Word as good and Excel as okay, so Excel is one honest candidate; booking travel is another if you have no experience of it. Answer slot: if you have done real work in the part you name, say what; if not, say so plainly. Then say what you would do in your first fortnight to close it, as a plan | F3 and F2 are the thin rows. JD because it scores fit to the listed duties; the question is a standard Skeptic stem |
| A3 | "Tell me about a time you arranged travel or accommodation for someone else." | EXP | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" | Selection scaffold: pick an occasion with a named person, what they needed, what you checked and how it turned out. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, in your own words: "I ran the appointment book for four physios." Or say how you would handle it | F2 has no evidence, so an open prompt with an honest branch is the safe rehearsal. EXP because it tests what was actually yours; the theme comes from the ad's travel line |
| A4 | "Why this role, and why remote?" | EXP | [generic] | Give your own reasons in your own words, in two or three sentences. Answer slot: name one of the ad's four duties you would want to do more of, and say why; if none stands out, say so plainly. Do not borrow a reason that is not yours | The pack cannot know your motives, so the guidance is a slot. EXP because it tests consistency of your story; F5 is why the remote half is likely |
| A5 | "How do you keep on top of your work when nobody can see you doing it?" | JD | [generic] | Selection scaffold: pick one way you organise your own workload that you really use, what it covers, and how you notice when you are slipping. If none comes to mind, say so plainly, then say how you would set one up in your first week | F5 is silent on distance working. JD because the role title is remote; Skeptic because it probes a gap |

### B. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Three people each ask you for the same Thursday hour and each says theirs is the priority. What do you do?" | CASE | [generic] | Structure it: ask who sets priorities and whether any of the three can move; set out the options you see and say which you would pick and why; tell all three what was decided; record it. The question asks about no past, so the guidance makes none | A live problem from the ad's calendar line (F1's requirement). CASE because it scores structure, not history |
| B2 | "You're booking a two-day trip for a colleague and the only sensible flight lands after the first meeting starts. What do you do?" | CASE | [generic] | Clarify before choosing: what the trip is for, any cost or policy limits, who signs off. Lay out two options with the trade-off of each, recommend one, confirm before booking, and say what you would keep to hand afterwards. No claim about your past | F2 has no evidence, so reasoning aloud is the honest way to show how you think. CASE with a JD source in the ad's travel line |
| B3 | "An invoice arrives for a different amount from the order it relates to. What do you do?" | CASE | [generic] | Structure it: ask what exactly differs; hold the invoice back from payment until it is checked; find who owns the order; contact the supplier by the office's usual route; record what you found and the outcome. No claim about your past | F4's requirement made into a live problem, so the supplier side is rehearsed as reasoning rather than history |
| B4 | "It's your first Monday and nobody is in the same room as you. How do you organise your first week?" | CASE | [generic] | Clarify first: your priorities, what you need access to, who to check in with and how often. Then a simple order for the week and how you would show progress. No claim about your past | F5's requirement as a live problem. CASE because it scores clarifying before structuring |
| B5 | "How would you set up a spreadsheet to track supplier invoices and their due dates?" | CASE | [grounded] "I'm good with Word, okay with Excel" | Start with what the sheet must answer and who reads it, then say what goes in each column and how you would check it is right. Your own words were "okay with Excel": say where a feature is beyond you and that you would look it up rather than guess. Answer slot: if you have built or used a tracking sheet, say what it held; if not, say so plainly | F3's Excel level and F4's invoice line meet here. CASE because it is a live design problem |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios and chased unpaid invoices" | A 90-second arc in three beats. First: "two years as a receptionist at a physiotherapy clinic." Second: "I ran the appointment book for four physios and chased unpaid invoices." Third, answer slot: say in your own words why you are applying for this role | Near-certain opener. EXP because it tests the story as a whole; the third beat is yours, so it is a slot |
| C2 | "What did a normal day look like at the clinic?" | EXP | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" | Tell it from what your material states: the appointment book for four physios and the chasing of unpaid invoices. Answer slot: if any other task filled your day, say it in your own words; if the day was mostly those two, say so plainly | A casual question that is still scored. EXP because it checks that your account matches F1 and F4 |
| C3 | "What kinds of documents do you make in Word?" | JD | [grounded] "I'm good with Word, okay with Excel" | Your own words were "good with Word." Answer slot: name the kinds of documents you have actually made, in your own words; if your use has been narrower than the ad's wording suggests, say so plainly | F3 gives a level but no documents, and the ad names document preparation |
| C4 | "And Excel: where do you feel solid, and where do you hit the edge?" | JD | [grounded] "I'm good with Word, okay with Excel" | Your own words were "okay with Excel." Give your actual list, what you have done and what you have not. Saying where the edge is reads as credibility. Answer slot: name something you do in Excel; if you have mostly used sheets others built, say so plainly | F3's weaker half, asked in a friendly register |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. How did that work?" | EXP | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" | Defend the figure in your own words. Answer slot: say how many physios' appointments you handled at once and for how long, as best you remember, and say if it changed; say which decisions about the book were yours and which were the physios', and the part you would defend least; if you do not know how something was counted, say so plainly | "Four physios" is the headline figure in F1 |
| D2 | "Walk me through what you did after an invoice went unpaid." | EXP | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" | Answer slot: if you chose when and how to chase, say how, in your own words; if the steps were set for you, or there was no set process, say so plainly and describe what you did. Stay with the chasing | F4's evidence, probed for what was actually yours |
| D3 | "Tell me about a spreadsheet you built or used and what it showed." | EXP | [grounded] "I'm good with Word, okay with Excel" | Selection scaffold: pick one sheet you can describe end to end, with what went in, what it showed and who looked at it. If no such sheet comes to mind, say so plainly, then give the nearest thing your material does carry, in your own words: "I'm good with Word, okay with Excel." Or say how you would build one | F3 has a level and no artifact behind it, so expect a probe on a real sheet |

### E. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to tell someone something they didn't want to hear." | VAL | [grounded] "I ran the appointment book for four physios and chased unpaid invoices" | Selection scaffold: pick a time with a named stake, what you said, and how things stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, in your own words: "I chased unpaid invoices." Or say how you would handle it | A standard behavioral stem. VAL here is generic rather than tied to published values, which are not in hand |
| E2 | "Tell me about a time you put the person in front of you ahead of your own schedule." | VAL | [generic] | Selection scaffold: pick one occasion with what the person needed, what you set aside, and what happened. If none comes to mind, say so plainly, then say how you would weigh it | A standard behavioral stem, labelled generic because it needs no fact about you |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role, and what would you want finished by the end of it?" | It shows you work toward outcomes, and the answer tells you what to practise first |
| R2 | "Which tools do you use for calendars and for invoices, and how much would I be learning?" | It is an honest signal about the Word and Excel level you stated, and the answer shows you where to practise |
| R3 | "How are supplier invoices handled today, who approves them, and where would I fit in?" | It goes straight at F4 as a learner, and the answer shapes how you describe your own chasing |
| R4 | "How does the team stay in touch day to day with people working remotely?" | It shows you are thinking about F5 in practical terms |
| R5 | "What is the hardest part of this role for someone new to it?" | It invites candour and mirrors the honest self-assessment the Skeptic bank rehearses |
| R6 | "What happens after this call, and how soon will you decide?" | It asks about the process itself, and the answer lets you plan around any next step |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Processed supplier invoices | Inflated form of F4 | F4's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: the material says chasing, not the supplier side. A1's slot stays inside the chasing |
| Managed calendars | Inflated form of F1, borrowing the ad's wording | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: the material says an appointment book, not calendars generally |
| Strong or advanced Excel skills | Inflated form of F3 | F3's quote at its own scope: "okay with Excel." The limit is the pack's observation: the material rates Excel below Word |

## Sources

Provided documents: your message, which contained the invite text as pasted, your description of the ad's four duties, and your background. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused:

- "Brennock Facilities Ltd values" — refused
- "Brennock Facilities Ltd interview process administrative assistant" — refused
- "Brennock Facilities Ltd news" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Every call was refused. It would have fed a values-style bank. No loop source documents a values round, so it would have supplied question themes only |
| 2. `{company} interview process {role family}` | unavailable | Every call was refused. It would have added employer-specific loop detail. Your own words already establish one 30-minute video call with the office manager |
| 3. `{company} strategy` / recent news | unavailable | Every call was refused. It would have fed a CO question, and the pack has none |
| 4. `{interviewer name} {company}` | n/a | No name was given, so there was no query to form. There is no interviewer read |
| 5. representative `{role title}` JD | skipped | The ad's duties as you described them fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → the four requirement quotes become exact quotes, and any further requirements (tools, hours, reporting line) get their own rows and questions
- Whether the office manager would be your day-to-day manager or a colleague → reweights every bank, and adds a Peer bank if a colleague
- The office manager's name and role title → an interviewer read from their public professional footprint, persona weights tuned to it, and a reverse question tied to their own path
- Your answers to the slots in F1 to F5 → upgrade those rows from discovery or transferability, and replace slots in banks A to D with story maps from your own sentences
- Search access, since the three L1 searches were refused → company values, loop detail and recent news, with a CO question. A deeper pass is available once search works: up to 6 more searches and 2 more fetches, several more minutes
- Time available before the call → a prep triage sized to it
- A tuesday-dossier.md from an earlier session → verified evidence and a sourced prohibited-claims list in place of the one built here from the snapshot
