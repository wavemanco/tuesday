# Interview prep pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (name not given). Format, in the invite's words: "a text chat here with our support team lead". Relationship assumed to be a hiring manager, since the invite does not say whether the lead is your future manager.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

| Type | Meaning |
|---|---|
| VAL | Behavioral or values alignment: does past behavior show the company's published values |
| EXP | Work-experience deep-dive: do your claims survive scrutiny, and what was actually you |
| JD | Role or JD-driven: can you do the listed job, gaps included |
| CO | Company and strategy knowledge |
| CASE | A live problem from the role, delivered in the chat |

Question IDs run A to E and then G. Letter F is skipped so that a question ID is never mistaken for a fit-snapshot row (F1 to F6).

## Fit snapshot

The requirements below are the ones you listed from the job ad, quoted from your message. The ad's full text was not supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad, as you described it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap on length: your quote says three years against the ad's two. It is a stated claim with nothing inspected behind it, so expect a probe on the daily volume. Lead with the quote's own terms: three years as a customer service advisor at an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad, as you described it | "I use Freshdesk every day" — your message | medium | [grounded] | none | The ad's "or a similar ticketing tool" is met in the quote's terms: Freshdesk, used every day. Your material does not mention Zendesk, so the words stay on Freshdesk |
| F3 | "clear written communication" — the job ad, as you described it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Inferred from the emails in that quote, which says you answer emails and not whether the writing was reviewed or praised. The interview itself is a text chat, so a probe on your writing is likely. Answer slot: if any of your written replies were reviewed, scored or complimented, say what happened, in your own words; if none were, say so plainly and stay with the emails you answer each day |
| F4 | "confidence handling escalations" — the job ad, as you described it | none given | none | [grounded] | discovery | Your material does not mention escalations. Answer slot: if escalations reached you, say what kind and which part was yours; if none did, or they went to someone else, say so plainly and return to "answering around 60 calls and emails a day" |
| F5 | Support work at a software company: a role-family pattern, not in the ad as you described it | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I haven't worked for a software company." Then how you would learn the product, said as a plan in your own words and never as a past. Never a claim to software-company work, and nothing added to make the gap feel smaller |
| F6 | No requirement in the ad as you described it; recorded because this quote is the strongest teaching evidence your material holds | "I trained four new starters on our refunds process last year" — your message | medium | [inferred] | none | Inferred relevance only: the ad as described does not list training. Use the quote at its own scope: four new starters, your refunds process, last year. Expect a probe on which part was yours |

## Persona table

Loop source: the invite's own words, which describe one text chat with the support team lead. That establishes this session, so no archetype fallback is needed. No values-style round is documented, so there is no values cheat sheet.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| A. Case / Strategist (weight 5) | Live support scenarios in the chat, possibly a short written reply | Highest: the hiring-manager prior favors it, and the ad's ticketing and escalations lines convert directly into scenarios, with F4 the thinnest row | Ask one clarifying question first, state the aim, give the steps, say what you would record. Keep each chat message short |
| B. Skeptic (weight 4) | Quiet probing of the gap you named | High: F5 is a stated capability gap, F4 is silent, and the hiring-manager prior includes derisking | Rehearse the F5 objection until it is boring: plain acknowledgment, a plan, and a return to what your quotes carry |
| C. Data-Driven Prober (weight 3) | "How was that counted" on the two numbers | Medium: your material holds two figures (around 60 a day, four starters) and a chat interview makes a follow-up cheap | Know what you can and cannot say about each figure, and say plainly when you do not know |
| D. Conversational / Rapport Builder (weight 3) | Friendly opener, casual questions that are still scored | Medium: a chat opens conversationally, and F3 says the register itself may be scored | Have a short arc ready; treat casual questions about writing and the company as scored |
| E. Pressure (weight 2) | Time-boxed challenge on why you over a software-support candidate | Lower: not the hiring-manager prior, but an escalations role may test composure | Pause, restate, hold your position through two follow-ups, concede specifically |
| G. Values / Behavioral (weight 2) | "Tell me about a time" prompts | Lower: no loop source documents a values round, and no published values are in hand | Select a real instance, or say plainly that none comes to mind |

The Peer Evaluator is left out: nothing in the invite puts a peer in this session.

## Question banks

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same problem, and their last two tickets were closed. Walk me through what you do in the ticket tool and in your reply." | JD | [grounded] "I use Freshdesk every day" | Ask first what the earlier tickets said. Then give the order: read the history, acknowledge the repeat, say what you will do and by when, and record it so the customer is not asked again. Name the tool as Freshdesk, which is what your quote carries | F2 is the evidence for the ticketing requirement. JD because it scores that line, CASE in delivery |
| A2 | "A customer demands a manager and says they will cancel unless you fix it now. What do you do in the next ten minutes?" | CASE | [generic] | Structure it: listen and restate the problem, say what you can decide yourself and what needs handing up, tell the customer what happens next and when, and write the handover so they do not repeat themselves. The question asks about no past, so the guidance makes no claim about yours | The ad's escalations line (F4) as a live decision; CASE because it is a live problem, `[generic]` because it is a pattern and not a fact about this employer |
| A3 | "Tell me about a time a customer's problem went beyond what you could fix yourself." | EXP | [grounded] | Selection scaffold: pick a time the fix or the decision was not yours to give. A good one has what the customer needed, who you passed it to, and what the customer was told. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is silent, so this is the likeliest place the escalations line is probed. EXP because it tests what was actually yours |
| A4 | "This interview is a text chat, so let me ask about writing: what does a clear written reply look like to you?" | JD | [grounded] "answering around 60 calls and emails a day" | Say what clear means to you and what you aim for when you write, in your own words. Answer slot: if you re-read replies, or someone reviewed them, say how and what you changed; if you have no set way, say so plainly and stay with the emails you answer each day | F3 is thin and the format makes the answer visible live. JD because it scores the writing requirement |
| A5 | "Write the reply, here in the chat, to a customer who says they were charged twice and is angry." | CASE | [generic] | Treat it as a live writing sample. Open by owning the problem, say plainly what happens next and by when, keep it short and free of jargon. Where you do not know their policy, say what you would check instead of promising an outcome | F3 under real conditions; CASE because the answer is the sample, `[generic]` because the scenario is not from this employer |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked for a software company before. What makes you think you can get up to speed on our product?" | JD | [grounded] "I've never worked for a software company" | **Highest-ROI prep in this pack.** Hold only what the quotes carry. Open with the plain acknowledgment: "I haven't worked for a software company." Concede the specific limit, that you will not know the product on day one. Then give your plan for learning it, said as a plan in your own words. You may say what you did, at its scope: "I trained four new starters on our refunds process last year", and let the interviewer draw the inference. Across two follow-ups, return to the quotes and never add to them | F5 is a stated gap and this question arrives in some form; JD because it scores fit for a software role, Skeptic because it probes the gap |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Choose the honest answer from your own material. The pack's observation is that it is thinnest on escalations (F4) and software (F5). Name one plainly and say what you would do about it. If escalations are where you are thinnest, say that, and if they are not, name what is | A standard Skeptic stem, aimed at F4 and F5. JD because it scores the listed job |
| B3 | "Why move from energy to software support, and why now?" | EXP | [generic] | Give your actual reason in your own words; this pack has none from you and will not supply one. Say what you are moving toward as well as what you are leaving only if both are true | Motivation consistency is the Skeptic's core score and F5 makes it likely. EXP because it tests your own account |
| B4 | "What from your time at an energy supplier would carry over to supporting software customers?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | Story-mapped on F1, F2 and F6: three years as a customer service advisor, around 60 calls and emails a day, Freshdesk every day, four new starters trained. Tell those beats in your own words and let the interviewer draw the link | F5 makes this the follow-up to B1. EXP because it tests which of your claims carry |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You say around 60 calls and emails a day. How was that counted, and is it an average or a busy day?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Defend the number in your own words. Answer slot: say how the figure was arrived at; if you do not know how it was counted, say so plainly. Name the assumption you would defend least before they do, and say what the word around covers, whether a range or a typical day | F1's figure is the likeliest number to be probed. EXP because it tests attribution and counting |
| C2 | "You trained four new starters on your refunds process. What did that involve, and how much of it was you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell the beats the quote states: four new starters, your refunds process, last year. Answer slot: say which part was yours and which was not, in your own words; if you cannot split it, say so plainly | F6 is the strongest teaching evidence and carries a figure, so the which-part-was-yours probe applies. EXP |
| C3 | "Tell me how you use Freshdesk in a normal day." | JD | [grounded] "I use Freshdesk every day" | Describe your own day in it, in your own words. Answer slot: if you use it for more than replying, say what for; if you mostly reply and close, say so plainly and say what you have picked up. If asked about Zendesk, your own words were: "I use Freshdesk every day" | The ad's ticketing line (F2) raises this probe. JD because it scores that line |

### D. Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through your journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | Build a short arc from those quotes only: the three years and the calls and emails, Freshdesk every day, the four starters. Then say in your own words why this role. In a chat, keep it to a few short messages | The biography opener is near-certain in a conversational round. F1, F2 and F6 supply the beats |
| D2 | "How do you feel about doing support in writing all day?" | JD | [grounded] "answering around 60 calls and emails a day" | Give your honest preference. The quote says calls and emails, not which you prefer, so say your own answer plainly | Asked casually but scores F3. JD because it scores the writing requirement |
| D3 | "What do you know about Lumenvale, and what drew you to it?" | CO | [generic] | This pack could not look the company up, so it holds no company facts. Before the chat, read what the company publishes about itself on its own website, say only what you read there, and give what drew you in your own words. If you have not had time, say so plainly and ask them | Almost always asked. `[generic]` because no research ran |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has worked in software support?" | JD | [grounded] "I've never worked for a software company" | Hold, then concede. Concede the specific limit first: "I haven't worked for a software company." Hold on what the quotes carry, which is three years of customer service, Freshdesk every day and the four starters trained. Do not claim to be better at what you cannot back | F5 under time pressure. JD because it scores fit |
| E2 | "That training you ran: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold what the quote says and no more. Concede specifically where you do not know or where it was not yours. Do not fold on the core claim just to restore harmony | C2 under pressure delivery. EXP because it tests attribution honesty |

### G. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time you chose the customer's need over a target, with the decision you made and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Standard values stem. `[generic]` because Lumenvale's published values are not in hand |
| G2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you said something unwelcome to someone senior, with what you said and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it | Standard values stem, low weight. `[generic]` because no values page was read |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "2+ years in customer support" | B4, C1, D1 |
| "experience with Zendesk or a similar ticketing tool" | A1, C3 |
| "clear written communication" | A4, A5, D2 |
| "confidence handling escalations" | A2, A3 |
| Software-company background (not in the ad as you described it) | B1, B2, E1 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a strong first month look like in this role, and how is it measured?" | Shows you are thinking about delivering, and tells you what to aim for |
| R2 | "Which tickets reach you as escalations, and what do you need from the first-line person when they do?" | Turns the escalations line into a handover conversation and shows you think about the next person |
| R3 | "How do new starters learn the product in their first weeks?" | Raises your biggest gap yourself, as a question about learning and not as an apology |
| R4 | "Which channels does the team cover, and what does a typical day's mix look like?" | Your material is calls and emails, so the answer shows where it maps |
| R5 | "How is the quality of written replies reviewed on the team?" | Puts the writing requirement on the table and shows you expect feedback |
| R6 | "What happens after this chat, and is there a further conversation by call or video before any offer?" | Lets you plan what to prepare for a next stage and how much time to set aside |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day". The limit is the pack's observation: the material says Freshdesk, not Zendesk. C3's slot stays on Freshdesk |
| Has software-company or software-support experience | Negative the candidate stated, F5 | The plain acknowledgment F5 gives: "I haven't worked for a software company." Then a learning plan said as a plan |
| Owned or led the team's onboarding | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year". C2's slot asks only which part was yours |

## Sources

Provided documents: the invite message as you pasted it, and your own description of the job ad's requirements and of your background. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused for lack of permission:

- "Lumenvale Software company values" — refused
- "Lumenvale Software interview process customer support specialist" — refused
- "Lumenvale Software news strategy" — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The call was refused. It would have moved D3 and themed the G bank; both stay `[generic]` |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | The call was refused. It would have shown whether a later round exists; this session's shape comes from the invite's own words |
| 3. `Lumenvale Software news strategy` | unavailable | The call was refused. It would have moved D3 and any CO question |
| 4. `{interviewer name} Lumenvale Software` | n/a | The interviewer is unnamed, so there was no query to form; there is no interviewer read |
| 5. representative `Customer Support Specialist` JD | skipped | The requirements you listed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → F1 to F4 become word-for-word `[grounded]` rows, and any further requirement such as hours, location or languages gets its own row and question
- Your CV → rows built from your message can quote its own lines, and F3, F4 and F6 may gain evidence
- Your answers to the slots, outside any drill (whether escalations reached you, whether your written replies were reviewed, how the 60 a day was counted, which part of the training was yours) → F3, F4 and F6 move from `discovery` to quoted evidence and A3, A4, C1 and C2 get story maps
- The team lead's name, if you learn it → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their path
- Anything stated about focus areas or format → coverage beyond the round-type priors
- Search permission, or Lumenvale's own values page pasted in → D3 becomes `[grounded]` and the G bank can be themed on published values; a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, is available once searches are allowed
- A `tuesday-dossier.md` from an earlier session → verified evidence and standing prohibited claims; never needed
