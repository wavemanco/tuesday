# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday 2pm, 30-minute phone call. **Interviewer:** Hannah Lowther, Talent Partner. She will ring the mobile number on your application.

Built on one assumption: the call follows the agenda in her message, which is salary expectations, notice period, how the hybrid pattern would work for you and what is prompting a move, then the team and next steps.

## How to use this pack

Personas describe how a question arrives. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and only what you actually did.

Question IDs run by persona (A, B, C, D, E, G). The letter F is skipped so that a question ID never matches a fit-snapshot row such as F1.

| Type | What it scores |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your experience survives scrutiny, and what was actually you |
| JD | The advert's stated responsibilities and terms, including your gaps |
| CO | What you know about the company and why it |
| CASE | A live problem set in the role |

## The fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | transferability | Your material says delivery scheduling and supplier chasing, not production scheduling, and nothing about planning or QA. The words stay there: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so a probe on who you coordinated with is likely. If you worked with a planning or QA function, say how, in your own words; if there was no such function, or it was not yours, say so plainly and stay with the depot deliveries |
| F2 | "track supplier deliveries and chase late orders" — advert | "I schedule deliveries for our three depots and chase suppliers when orders slip." — your message | medium | [grounded] | none | The sentence already says you chase suppliers when orders slip. It is a message-only claim with nothing inspected behind it, so expect a probe. Lead with the sentence's own terms, and keep to chasing: the sentence does not say how deliveries are tracked |
| F3 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | medium | [grounded] | none | The sentence reaches the requirement, and it carries a figure, so expect a probe on how it was counted (C1). Keep "about a third" attached to discrepancies and "over a year" attached to the period. The sentence says you rebuilt the spreadsheet and that discrepancies fell, and it does not say the rebuild alone caused the fall |
| F4 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show this either way. Answer slot: if you produced any regular report on deliveries or dispatch, say what it covered and how often, in your own words; if you did not, or it was not yours, say so plainly, and say what you would track first |
| F5 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler." — your message | medium | [grounded] | none | The sentence already meets the ask in the advert's own terms. Say it as written |
| F6 | "confident with Excel" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." — your message | low | [inferred] | discovery | The sentence says spreadsheet, not Excel, and the pack does not close that step. Answer slot: if the spreadsheet was in Excel, say so and what you did in it, in your own words; if it was another tool, or someone else built parts of it, say so plainly |
| F7 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system." — your message | medium | [grounded] | transferability | You stated the SAP gap, so the words are yours: "Never used SAP — we run our own in-house stock system." Your material says the in-house system exists at your employer, not what you did in it. Answer slot: the advert's "or similar" makes a probe on that system likely. If you worked in it, say what you did, in your own words; if you did not, or it was not yours, say so plainly. Nothing is described as ERP |
| F8 | "£38,000–£44,000" — advert | "I'm hoping for £42,000." — your message | medium | [grounded] | none | Inside the advert's band. The words are yours, with nothing added: "I'm hoping for £42,000." |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol." — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." — your message | high | [grounded] | none | The advert's two days sits inside your own limit. Say the whole sentence, both halves together: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." |
| F10 | "your notice period" — Hannah Lowther's message | none given | none | [grounded] | hard_gate | Your material does not establish this term |
| F11 | "what's prompting a move" — Hannah Lowther's message | "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." — your message | medium | [grounded] | none | The words are the sentence's own terms: "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Nothing is added to it |

### Requirement coverage

| Requirement | Questions covering it |
|---|---|
| Coordinate production schedules between planning, the warehouse and QA | B2, D1, A5 |
| Track supplier deliveries and chase late orders | E1, D1 |
| Keep stock records accurate | C1, C2, G2 |
| Report weekly on on-time dispatch | B3, D2 |
| 2+ years in operations or logistics coordination | A5, G1 |
| Confident with Excel | C3 |
| ERP experience (SAP or similar) a plus | B1 |
| £38,000–£44,000 | A1 |
| Hybrid, two days a week at Avonmouth | A3 |
| Notice period (Hannah's agenda) | A2 |
| What is prompting a move (Hannah's agenda) | A4 |

## Persona table

Weights rest on the recruiter-screen starting weights and on the agenda in Hannah's own message. Your words and her message establish this one session, so no archetype fallback is used. The searches that could have shown later rounds were refused (see Sources), so nothing here describes Quillmoor's loop beyond this call.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder (A) | Friendly, unstructured; her four agenda items asked as chat | Highest. Her message lists pay, notice, hybrid and reason for moving, which are logistics asked in a friendly register. Friendly questions are still scored | Have your own words ready for each item, and treat the casual ones as scored |
| Skeptic (B) | Quiet, persistent probing of gaps and motive | High. The advert names planning, QA, weekly dispatch reporting and SAP, and F1, F4 and F7 are where your material is thinnest | Rehearse the most predictable objection (B2) until it is boring; stay inside what your sentences say |
| Data-Driven Prober (C) | Asks how your one figure was counted | Medium. You gave one figure, and any figure draws a probe even from a recruiter | Know what you can say about how it was counted; say plainly where you do not know |
| Case / Strategist (D) | A short live problem from the role | Low. A recruiter screen rarely runs cases, but the role is a coordination job and a quick scenario is cheap to rehearse | Clarify first, then structure, think aloud |
| Values / Behavioral (E) | "Tell me about a time" prompts | Low. No values-style round is established by your inputs, and the searches were refused | Choose a real occasion or say plainly that none comes to mind |
| Pressure / Stress (G) | Time-boxed or devil's-advocate questions | Low. A recruiter screen is not usually where this appears | Pause, restate, hold through two follow-ups, concede only what is true |

## Question banks

Highest-ROI prep in this pack: **B2**. It is the question most likely to be asked in some form, and it sits where F1 is thinnest.

### A. Conversational / Rapport Builder (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What salary are you looking for?" | JD | [grounded] "I'm hoping for £42,000." | Say your figure in your own words: "I'm hoping for £42,000." Then let her respond. If she comes back to it, your own words again, nothing added | F8 is the logistics slot for pay, and the advert gives a band, so the question arrives early. JD because it scores a term of the listed job |
| A2 | "What's your notice period?" | JD | [grounded] | Give your actual notice period, exactly as your contract states it. This pack has nothing from you to put here, so the slot is yours to fill in the call | F10 is a term Hannah named and your material does not establish. JD because it scores a term of the listed job |
| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." | Your own words, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If she follows up on the journey or the days, give the same words again, nothing added | F9 is the logistics slot for location. JD because it scores a term of the listed job |
| A4 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." | Your own words, in the sentence's terms: "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Keep to those terms and add no other label for it. If she follows up, the same words again | F11 is the logistics slot for the reason for leaving. EXP because it tests whether your account of your own history is consistent |
| A5 | "Walk me through your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | A 90-second arc with three beats, each a sentence you wrote: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell them in your own words. Answer slot: for why this role, say what draws you to it in your own words; this pack holds nothing from you on that | F5, F2 and F3 are the evidence rows, and the opener sets the frame for everything after. EXP because it tests whether the story hangs together |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this advert would you be weakest at on day one?" | JD | [grounded] "Never used SAP — we run our own in-house stock system." | Pick from your own material. The one you stated is SAP: "Never used SAP — we run our own in-house stock system." Answer slot: if you worked in the in-house system, say what you did; if you did not, or it was not yours, say so plainly. Then say how you would learn the new system, as a plan and never as a past | F7 is a stated gap on a requirement the advert marks as a plus, so a candid answer is cheap and a bluff is costly. JD because it scores the advert's own list |
| B2 | "The role coordinates production schedules between planning, the warehouse and QA. What have you coordinated that is closest to that?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | The highest-ROI rehearsal in this pack. Open with the scope as your own words: "I schedule deliveries for our three depots." The pack's observation, not words for you, is that your material says deliveries and suppliers, not production, planning or QA. Follow-up one: stay with the sentence and do not stretch it. Follow-up two, on planning or QA: answer slot. If you worked with a planning or QA function, say how, in your own words; if there was no such function, or it was not yours, say so plainly and stay with the depot deliveries. If she presses a third time, return to the sentence again rather than adding to it, and say how you would get up to speed, as a plan and never as a past | F1 is the advert's core duty and the row where your material is thinnest, so this objection arrives in some form. JD because it scores the stated responsibility |
| B3 | "The role reports weekly on on-time dispatch. What reporting have you done on deliveries or dispatch?" | EXP | [grounded] | No sentence of yours speaks to reporting, so this is an answer slot. If you produced any regular report on deliveries or dispatch, say what it covered and how often, in your own words; if you did not, or it was not yours, say so plainly, and say what you would track first | F4 is silent in your material, and the advert states the requirement. EXP because it tests what you actually did |
| B4 | "Why Quillmoor, and why this kind of role?" | CO | [grounded] | The advert describes Quillmoor as a "diagnostic-test manufacturer, about 400 staff". Research on the company was refused, so this pack holds nothing more about it. Answer slot: say in your own words what draws you to this company and this role; if nothing specific does yet, say so plainly and say what you would want to learn | The Skeptic tests motive, and A4 gives the reason for leaving but not the reason for this role. CO because it scores homework, which this pack could not deepen |

### C. Data-Driven Prober (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third. How was that measured?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | The figure has four slots, each in your own words. How it was counted; what it is sensitive to; the assumption behind it you would defend least, named before she does; which part was yours. "I don't know how it was counted" is an honest answer where that is true. Keep "about a third" and "over a year" exactly as you said them | F3 carries the pack's only figure, and a quantified claim draws a probe. EXP because it tests attribution |
| C2 | "Walk me through what you rebuilt in the stock-count spreadsheet." | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Start from the sentence: you rebuilt the stock-count spreadsheet. Answer slot: expect a probe on what the rebuild changed. Say what you changed, in your own words; if part of it was someone else's, or it was less than the word rebuilt suggests, say so plainly and stay with what you did | F3 is the evidence row, and "rebuilt" is the word a prober tests. EXP because it tests what was actually yours |
| C3 | "How confident are you in Excel, and what do you do in it day to day?" | JD | [inferred] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Answer slot: if the spreadsheet was in Excel, say so and what you did in it, in your own words; if it was another tool, or someone else built parts of it, say so plainly. Name no function or feature you did not use | F6 is a discovery gap, and the advert lists Excel as a requirement. JD because it scores the stated qualification |

### D. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you on Monday morning that a delivery will be a week late. Planning, the warehouse and QA are all waiting on it. What do you do?" | CASE | [generic] | Clarify first: what is late, what depends on it, whether part can ship sooner. Then state the objective, the options with their costs, who needs telling and in what order, and what you would record. Think aloud. The question needs no claim about your past, so the guidance makes none | The advert's late-orders and three-function coordination lines (F1, F2) turned into a decision. `[generic]` because it is a pattern for the problem, not a fact about this employer |
| D2 | "On-time dispatch has slipped for three weeks running. Where do you start?" | CASE | [generic] | Clarify what counts as on time and how it is measured. Then split the slip by product, customer, supplier lateness and warehouse stage, check what changed three weeks ago, and say what the weekly report should show. No claim about your past | The advert's weekly dispatch reporting line (F4) as a live problem. `[generic]` because it is a pattern for the problem |

### E. Values / Behavioral (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time a supplier let you down." | VAL | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip." | Your sentence carries the practice, not an occasion: you chase suppliers when orders slip. Choose one occasion and tell it in your own words: what was late, who you chased, how it ended, and what part was yours. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I schedule deliveries for our three depots and chase suppliers when orders slip." | The advert's late-orders line (F2) is the raising source for the theme. VAL because it tests behaviour under a supplier failure, not a published value, which this pack could not research |
| E2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Pick a time with a named stake, a moment you did not soften the message, and an intact working relationship afterwards. If no such time comes to mind, say so plainly, then say how you would handle it | A standard behavioural prompt, included so the style is not new on the day. `[generic]` because it supplies no fact about you or Quillmoor |

### G. Pressure / Stress (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Sixty seconds: why you over an internal candidate?" | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler." "I schedule deliveries for our three depots and chase suppliers when orders slip." "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." "Never used SAP — we run our own in-house stock system." | Pause and restate the question. Hold on your own sentences: the four years as a logistics coordinator, scheduling deliveries for three depots and chasing suppliers when orders slip, and the stock-count spreadsheet rebuild. Hold through two follow-ups by returning to those sentences, never by adding to them. If she presses on a gap, concede it specifically: "Never used SAP — we run our own in-house stock system." Do not fold on the sentences you did say | F5, F2 and F3 are the holds, and F7 is the concession a pressure interviewer finds first. EXP because it tests what you can stand behind |
| G2 | "That result: how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." | Hold on the sentence's own scope: you rebuilt the spreadsheet, and discrepancies fell by about a third over a year. Answer slot: say which part was yours; if other people or other changes contributed, say so plainly and stay with the rebuild. Concede that explicitly and specifically rather than defensively | F3's figure is the attribution probe, and C1 rehearses how it was counted while this rehearses who did what. EXP because it tests attribution under pressure |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What happens after this call, and who would I meet next?" | It asks for the process the call is part of, which she said she would cover, and lets you plan around it |
| R2 | "How is on-time dispatch measured today, and what does the weekly report look like?" | It ties to the advert's reporting line and shows you are thinking about the job rather than only the interview |
| R3 | "Which systems does the team use for stock and scheduling, and how is training handled?" | The advert marks ERP as a plus, so it asks about the system you would be working in |
| R4 | "Which teams does this role sit between day to day, and who does it report to?" | The advert names planning, the warehouse and QA, and the answer shows how the coordination actually runs |
| R5 | "How are the two days at Avonmouth usually set: fixed days, or agreed with the team?" | It asks about the pattern the advert states, so you learn how it works before an offer |
| R6 | "What would a good first three months look like for this role?" | It turns the call from a screen into a conversation about the job, and her answer shows what the team needs first |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Coordinated production schedules between planning, the warehouse and QA | Inflated form of F1 | F1's quote at its own scope: "I schedule deliveries for our three depots and chase suppliers when orders slip." The limit is the pack's observation, not words for you: the material says deliveries and suppliers, not production. B2's slot stays inside the depot deliveries |
| Has used SAP | Negative the candidate stated, F7 | Your own words: "Never used SAP — we run our own in-house stock system." No slot |
| Has ERP experience | Inflated form of F7 | F7's quote at its own scope, the in-house stock system at your employer. B1's slot asks only what you did in it |
| Cut stock discrepancies by a third | Inflated form of F3 | F3's quote at its own scope: "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year." The sentence says about a third, and says discrepancies fell, not that the rebuild alone caused it |
| £42,000 is a firm minimum | Inflated form of F8 | F8's quote at its own scope: "I'm hoping for £42,000." |
| The office closure was a redundancy | Inflated form of F11 | F11's quote at its own scope: "our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." |

## Sources

Provided documents: the advert for Operations Coordinator at Quillmoor Diagnostics, Hannah Lowther's LinkedIn message, and your own notes in this conversation. No CV and no `tuesday-dossier.md` were provided.

Research tier: L1 — searches 4 of 6, fetches 0 of 2

Every search sent was refused, so nothing in this pack comes from the web.

| Query | What came back |
|---|---|
| Quillmoor Diagnostics company values | refused |
| Quillmoor Diagnostics interview process operations coordinator | refused |
| Quillmoor Diagnostics Avonmouth Bristol news | refused |
| Hannah Lowther Talent Partner Quillmoor Diagnostics | refused |

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have moved the values cheat sheet, but only if a values-style round were established, and VAL questions themed on published values. Both are absent |
| 2. `{company} interview process {role family}` | unavailable | Would have moved persona weights and shown whether later rounds hold a values round. The weights rest on your account of this one call |
| 3. `{company} strategy` / recent news | unavailable | Would have moved B4 and any CO question, which are now limited to what the advert says |
| 4. `{interviewer name} {company}` | unavailable | Would have moved the interviewer read and a reverse question tied to her path. Both are absent |
| 5. representative `{role title}` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your notice period → A2's slot becomes your own words, and F10 stops being an open gate
- Search permission → the four unavailable targets can run, adding a values read, Quillmoor's recent news for B4, and Hannah's public professional footprint for the reverse questions; a deeper pass (up to 6 more searches and 2 more fetches, several more minutes) can be added once, on your say-so
- Your CV → the evidence cells become your exact CV lines rather than your summary, and F6 and F4 may move from discovery to a grounded row
- Your answers to the slots in F1, F4, F6 and F7 (planning or QA contact, any dispatch or delivery reporting, whether the spreadsheet was Excel, what you did in the in-house system) → those rows and B2, B3, C3 and B1 upgrade from slots to story-mapped answers
- A `tuesday-dossier.md` → verified evidence and a named top objection, which this pack inferred from the fit snapshot instead
