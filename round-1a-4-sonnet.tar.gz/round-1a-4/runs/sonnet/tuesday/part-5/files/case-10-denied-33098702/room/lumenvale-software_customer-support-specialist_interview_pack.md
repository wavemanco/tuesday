# Interview prep pack: Customer Support Specialist, Lumenvale Software

Interviewer: the support team lead (name not given). The invite came from Marcus Hale of the talent team, who is not the interviewer. Relationship assumed: hiring-manager round. Format as you described it: one typed text chat.

## How to use this pack

Personas describe how a question is asked. Types describe what is scored. Guidance is scaffolding, not a script: say only what you actually did, in your own words. An answer slot is an instruction for the interview, not a question for this conversation.

| Tag | Meaning |
|---|---|
| EXP | Whether your CV claims survive scrutiny and what was actually you |
| JD | The listed requirements, including where you are thin |
| CASE | A live problem set in the role, scored on structure |
| VAL | Past behavior against the company's published values |
| CO | Knowledge of the company and its strategy |

No VAL or CO questions appear: no values-style round is established by your description, and the company research did not run (see Sources). Proposed answer language below is pending your approval.

## Fit snapshot

Proposed bridge language, pending your approval.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the job ad as you listed it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap, but nothing inspected stands behind it, so expect a probe. Lead with the quote's own terms: three years, advisor, energy supplier, around 60 calls and emails a day |
| F2 | "experience with Zendesk or a similar ticketing tool" — the job ad as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | Say the tool by name and that it is daily: "I use Freshdesk every day." Your material names Freshdesk, not Zendesk, and says nothing about what you do in it, so the bridge adds nothing there |
| F3 | "clear written communication" — the job ad as you listed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails answered does not show how clear the writing was, and the bridge should not be stretched. Answer slot: the ad's written-communication line makes a probe on your writing likely. If you wrote replies to customers yourself, say what kinds and how you kept them clear, in your own words; if most replies were not yours to write, or there was no such step, say so plainly and stay with the emails you answered. This interview is itself typed, so the chat is a sample of your writing |
| F4 | "confidence handling escalations" — the job ad as you listed it | none given | none | [grounded] | discovery | Your material does not mention escalations either way. Answer slot: the ad's escalation line makes a probe likely. If you handed up or took over customer problems, say what and what part was yours, in your own words; if you did not, or it was not yours, say so plainly and say how you would handle one |
| F5 | support for a software product — role-family, not in the ad as you listed it | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn the product, said as a plan and never as a past |
| F6 | not in the ad as you listed it; kept as a possible strength | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Lead with it in its own terms: four new starters, the refunds process, last year. It says trained, not managed, and nothing about outcomes, so expect "how much was you" |

## Persona table

Weights rest on the hiring-manager prior for a round with a support team lead, plus your description of one typed chat. No loop source beyond your own words was available.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Short live support scenarios you answer in writing | Highest (5 questions). The round is with the team lead, and the ad lists escalations (F4) and written communication (F3) | Clarify, then structure, then reply; type the reply the way you would send it |
| B. Skeptic | Quiet probing of the gaps | Highest (5). F5 is stated, F2 names Freshdesk not Zendesk, and F4 is silent | Rehearse B1 until it is boring; return to your own sentences, never add to them |
| C. Conversational | Friendly openers about your path and day-to-day | Mid (3). A first chat usually opens this way, and the questions are still scored | A short arc built only from F1 and F2; treat casual questions as scored |
| D. Data-Driven Prober | Asks how your numbers were counted | Mid (3). F1 and F6 each carry a figure | Know what you can say about each figure and say plainly where you do not know |
| E. Pressure | Short-deadline cases, challenge to your motive | Lower (2). A typed chat has no interruptions, so pressure shows up as deadlines and "why you" | Pause, restate, hold your position through two follow-ups, concede specifically |

## Question banks

### A. Case/Strategist

Proposed answer language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem and says they will cancel. Type me your first reply." | CASE | [generic] | The question needs no claim about your past, so the guidance makes none. Structure the reply: acknowledge the repeat plainly, say what you will do next and by when only if that is in your control, and say what you would check first. Then say what you would note for the next person who opens it | A live problem on the ad's written-communication line (F3), asked in the typed medium the interview itself uses. CASE because it scores structure, not past experience |
| A2 | "Ten messages arrive in an hour about a fault you have never seen. What do you do first, and who do you tell?" | CASE | [generic] | No claim about your past. Structure: confirm it is the same fault, send a holding reply that promises only what you can back, tell the team lead early with what you have seen, and record the pattern so the messages are not treated as ten separate cases | A team-level escalation scenario touching F4 and the unfamiliar-product worry of F5. CASE because it scores sequence and judgment |
| A3 | "An angry customer demands a manager. How do you decide whether to escalate, and what do you hand over?" | CASE | [generic] | No claim about your past. Structure: what you would try yourself first, what puts it beyond you, and what the handover note says so the customer does not have to repeat themselves | The ad's escalation line (F4) turned into a decision. JD content, CASE delivery |
| A4 | "A customer asks how a feature works that you have not used, and the help article is unclear. What do you reply?" | CASE | [generic] | No claim about your past. Structure: do not guess, say what you know, say you will confirm the rest, check, then follow up | The F5 gap rehearsed as behavior, so the honest answer to an unfamiliar product is ready |
| A5 | "Rewrite this for a customer: 'Your request cannot be actioned as the account is in a suspended state pending verification.'" | CASE | [generic] | No claim about your past. Plain version: what happened, what the customer needs to do, what you will do. Short sentences, no internal wording | Scores F3 directly, since the answer is itself a writing sample |

### B. Skeptic

Proposed answer language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have not worked for a software company. What would be hardest for you in the first weeks?" | JD | [grounded] "I've never worked for a software company" "I use Freshdesk every day" | The highest-ROI rehearsal in this pack. Open with the plain acknowledgment: "I've never worked for a software company." Then the adjacent fact at its own scope: "I use Freshdesk every day." Then how you would learn the product, said as a plan and never as something you have done. Hold through two follow-ups by returning to these sentences; concede specifically that you do not yet know the product | F5 is the most predictable objection, so it will arrive in some form. JD because it scores the listed job against your background |
| B2 | "The ad says Zendesk or a similar tool. Where does your Freshdesk experience stop?" | JD | [grounded] "I use Freshdesk every day" | Say it as stated: "I use Freshdesk every day." Answer slot: if you have used Zendesk, say where and how; if you have not, say so plainly and stay with Freshdesk. Name nothing about Freshdesk features you did not use | F2's evidence names a tool but not the ad's tool. JD because it scores a stated requirement |
| B3 | "You trained four new starters on refunds. How much of that was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold what the sentence carries: "I trained four new starters on our refunds process last year." Answer slot: which part was yours, in your own words; if the training was shared, or you cannot say how it was counted, say so plainly. Name the part of it you would defend least before they do | F6 holds a figure, which raises the attribution probe. EXP because it tests what was actually yours |
| B4 | "The ad wants 2+ years in support. Yours was calls and emails at an energy supplier. How does that carry over?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I've never worked for a software company" | Hold the quote at its own scope: three years, advisor, energy supplier, around 60 calls and emails a day. Concede the limit with your own sentence: "I've never worked for a software company." Let the interviewer draw the inference; do not assert what the work proves | F1 is solid on length, and the probe is on the setting (F5). JD because it scores the stated years |
| B5 | "Tell me about a time you handed a customer problem up, or took one over. What happened?" | JD | [generic] | An open prompt from the ad's escalation line (F4). Pick a case where you were the one handing up or taking over, then name what you passed on or received, and what you did next. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F4 is silent in your material, so this is the likeliest place to be caught without a story. JD because the ad names it |

### C. Conversational

Proposed answer language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey and what you do day to day." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" "I use Freshdesk every day" | Build the arc from those two sentences and no more: the three years, the setting, the daily volume, the daily tool. Answer slot: why a software company, in your own words; this pack supplies no reason | The biography question is scored for economy (F1, F2). EXP because it tests the CV against your telling |
| C2 | "What do you use Freshdesk for in a normal day?" | JD | [grounded] "I use Freshdesk every day" | Start from the sentence: "I use Freshdesk every day." Answer slot: name what you actually do in it, in your own words; if some of it is done by someone else, or you do not use a feature, say so plainly and leave it out | F2's evidence says daily use and nothing about what you do, so this question is where it gets filled. JD because it scores the tool requirement |
| C3 | "What makes a written reply to a customer good, in your view?" | JD | [generic] | An opinion, not a past event, so the guidance makes no claim about you. Pick two or three qualities and show them in one short reply you write on the spot. Do not describe a past reply you cannot back | Covers F3's written-communication line in a friendly register |

### D. Data-Driven Prober

Proposed answer language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the word around. Answer slot: how the figure was counted, what it moves with, the assumption you would defend least, and which part of that volume was yours; if you do not know how it was counted, say so plainly | F1's figure is the magnet for a prober. EXP because it tests the number |
| D2 | "Four new starters on refunds. What did the training consist of?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Tell it with only what the sentence states: four new starters, the refunds process, last year. Add only what you actually did, in your own words, and say plainly where you do not remember | F6 carries a figure and a process, so the follow-up goes to content. EXP because it tests what you did |
| D3 | "When have you had to explain something complicated to a customer in writing?" | JD | [grounded] "answering around 60 calls and emails a day" | An open prompt from the ad's written-communication line (F3). Pick a real instance, name what was complicated and what you wrote, in your own words. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: the emails you answered | F3 is the thinnest evidence on a stated requirement. JD because the ad names it |

### E. Pressure

Proposed answer language, pending your approval.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has already worked in software support?" | JD | [grounded] "I use Freshdesk every day" "I've never worked for a software company" | Hold what the sentences carry: "I use Freshdesk every day." Concede plainly: "I've never worked for a software company." Hold through two follow-ups by returning to your quotes; never claim to be better, only say what you have and what you would learn | F5 under time pressure. JD because it scores fit against the listed job |
| E2 | "A customer is rude in chat and wants an answer now, and you do not have one. You have thirty seconds. What do you type?" | CASE | [generic] | No claim about your past. Pause, restate the problem in one line, say what you can do now and what you will confirm, and give a time only if it is in your control | Composure in the typed medium. CASE because it scores a live reply |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 "2+ years in customer support" | B4, C1, D1 |
| F2 "experience with Zendesk or a similar ticketing tool" | B2, C2, E1 |
| F3 "clear written communication" | A1, A5, C3, D3 |
| F4 "confidence handling escalations" | A2, A3, B5 |
| F5 support for a software product | A4, B1, B4, E1 |
| F6 possible strength | B3, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first month look like for someone new on the support team?" | Shows you are thinking about being useful early, and tells you what the team scores |
| R2 | "Which kinds of tickets does the team escalate most, and who picks them up?" | Ties to the escalation line (F4) and shows you want the team's version, not your own |
| R3 | "Which ticketing tool does the team use, and how do new starters get up to speed on it and the product?" | Addresses F2 and F5 openly, and the answer shows how much ramp support to expect |
| R4 | "How does the team keep written replies clear and consistent?" | Ties to F3 and signals that quality of writing matters to you |
| R5 | "Is there another stage after this chat, such as a call or video conversation, and who would it be with?" | Lets you prepare for the next stage and its format |
| R6 | "What is the team finding hardest to get right for customers at the moment?" | Moves the chat from interrogation to a working conversation |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experienced with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation: your material names Freshdesk, not Zendesk |
| Handled 60 tickets a day in a ticketing tool | Inflated form of F1 | F1's quote at its own scope: "answering around 60 calls and emails a day." The quote names calls and emails, not tickets or a tool |
| Led or managed a team, or ran a training programme | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year" |
| Worked in software or SaaS support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |

## Sources

Provided: the invite text, your description of the job ad's four requirements, and your description of your background, all from your message. No dossier was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused:

- `Lumenvale Software values` — refused
- `Lumenvale Software interview process customer support specialist` — refused
- `Lumenvale Software company news` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | Would have fed a values cheat sheet, which is not built here anyway because no values-style round is established |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | Would have fed loop structure and persona weights. Weights rest on your description of one typed chat with the support team lead |
| 3. `Lumenvale Software` strategy and recent news | unavailable | Would have fed CO questions and the CASE bank. Both are generic here |
| 4. interviewer name and company | n/a | No name was given for the support team lead, so there was no query to form |
| 5. representative `Customer Support Specialist` JD | skipped | The four requirements you listed fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full job ad text → the four requirement quotes become verbatim and any further requirements get rows
- Your CV → evidence cells quote more of your own sentences, and F3 and F4 may move from discovery to a story map
- Your answers to the slots in F3, F4 and B5 → those rows get your own words instead of an instruction
- The support team lead's name → an interviewer read and a reverse question tied to their path
- Anything the talent contact said about format, length or focus areas → the case bank and persona weights get retuned
- Company research, if searches are permitted → a deeper pass of up to 6 more searches and 2 more fetches, several more minutes, would feed CO questions and the CASE bank
- A tuesday-dossier.md from an earlier session → verified evidence and prohibited claims arrive ready-made
