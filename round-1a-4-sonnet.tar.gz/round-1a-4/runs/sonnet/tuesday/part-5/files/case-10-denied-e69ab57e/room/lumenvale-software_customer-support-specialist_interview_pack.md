# Interview prep pack: Customer Support Specialist (remote), Lumenvale Software

Interviewer: the support team lead (name not given). Relationship assumed: hiring manager, since the person who leads the support team is most likely the person you would report to. Format, per your invite: one text chat on Telegram. Built for typed answers, so every answer is also a writing sample.

## How to use this pack

- Personas describe how a question is asked. Types describe what it scores.
- Type key:
  - VAL: whether past behaviour shows the company's published values. None appear below, because no published values could be read.
  - EXP: whether what you say about your work holds up under follow-ups.
  - JD: whether you can do the listed job, gaps included.
  - CO: company and strategy knowledge. None appear below, because no company research could run.
  - CASE: a live problem, scored on structure and reasoning.
- Guidance is scaffolding, not a script. Where it quotes you, those are your own words from your message: say them in your own words and stop where they stop.
- An answer slot is an instruction for the interview, not a question for you now. Fill it truthfully from your own experience, or take the honest second branch.
- Highest-ROI prep in this pack: B1, the software-company question. It will be asked in some form.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — job ad as you listed it | "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" — your message | medium | [grounded] | none | No gap, but a self-reported line with nothing inspected behind it, so expect a probe. Lead in the quote's own terms: the three years, the title you held, the energy supplier, and "around 60" as one figure for calls and emails together. Say "customer service advisor", the title you gave, not a different one |
| F2 | "experience with Zendesk or a similar ticketing tool" — job ad as you listed it | "I use Freshdesk every day" — your message | medium | [grounded] | presentation | The quote names a different tool from the one the ad names, and the ad's "or a similar ticketing tool" is the opening for it. Say it as you said it: "I use Freshdesk every day." Answer slot: the ad names Zendesk, so expect a probe on it. If you have used Zendesk, say where and how, in your own words; if you have not, say so plainly and stay with Freshdesk |
| F3 | "clear written communication" — job ad as you listed it | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | Emails are written, but the quote does not show whether anything about those replies was structured, checked or reviewed, and the pack will not supply it. Answer slot: the ad's line makes a probe on how you keep a written reply clear likely. If you do anything particular, say what, in your own words; if nothing in particular, say so plainly and stay with the emails you answered |
| F4 | "confidence handling escalations" — job ad as you listed it | none given | none | [grounded] | discovery | Your material does not show escalations either way. Answer slot: the ad's line makes a probe likely. If you handled any, say what one looked like and which part was yours, in your own words; if escalations went elsewhere or were not part of your role, say so plainly and stay with the calls and emails you answered |
| F5 | Working inside a software company: not a line in the ad as you listed it, raised by your own message | "I've never worked for a software company" — your message | none | [grounded] | capability | The absence is yours and you stated it, so the words are yours: "I've never worked for a software company." Then a plan said as a plan, never as a past: how you would learn their product. Never a claim to software-company experience, and nothing added to make the gap feel smaller |
| F6 | Offered by you, not an ad line | "I trained four new starters on our refunds process last year" — your message | medium | [grounded] | none | Nothing in the ad's list asks for it, so there is no gap to bridge. It is the one quote in your material about teaching others. Say it at its own scope: four starters, the refunds process, last year. The figure "four" raises the defend-the-number slots in E2 |

## Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| 2+ years in customer support (F1) | C1, D1, D2, E1 |
| Zendesk or a similar ticketing tool (F2) | B2, C1 |
| Clear written communication (F3) | A4, B4 |
| Confidence handling escalations (F4) | A1, A2, A5, B3 |
| Software-company background (F5) | A3, B1, B5, E1 |
| Offered training evidence (F6) | C3, D3, E2 |
| Company and strategy knowledge | None, and why: no company research could run, so no CO question would be anything but generic |
| Published values | None, and why: no values page was read and no values round is established |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A. Case/Strategist | Live customer scenarios typed into the chat: an angry repeat contact, a hand-off, a queue to triage | high: a team lead hiring for a support role tests judgment on live problems, and your invite says the whole interview is a text chat, so scenarios arrive as typed prompts | Clarify first, then structure, then answer; think aloud in short lines; name one assumption. Questions A1 to A5 |
| B. Skeptic | Quiet, persistent probing of what your material does not show: the software gap, Zendesk, escalations | high: the requirements you listed meet your own message at F2, F4 and F5, and a lead reads those gaps first | Rehearse the single most predictable objection (B1) until it is boring; bridge only from what you said; give a plan for the rest. Questions B1 to B5 |
| C. Conversational | Friendly openers such as the journey so far or why you applied | medium: chat interviews often open this way, but the invite gives no sign of a separate rapport round | Pre-script a 90-second arc from your own sentences; treat casual questions as scored. Questions C1 to C3 |
| D. Data-Driven Prober | Follow-ups on any number you mention: how it was counted, what was yours | medium: your message gives two figures, around 60 and four, and both invite a denominator question | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know. Questions D1 to D3 |
| E. Pressure | Fast follow-ups, a time limit, "how much of that was you" | low: nothing in the invite signals a stress format, though a typed chat can feel rushed | Pause, restate, hold a position through two follow-ups, then concede specifically. Questions E1 to E2 |
| P. Peer Evaluator | Collaboration scenarios with colleagues | low: the interviewer is assumed to lead the team, not sit beside you in it | Principles over claims: ask, check shared guidance, raise it with the lead if customers are affected. Questions P1 to P2 |

Loop basis: your invite establishes one session, a text chat with the support team lead, so no archetype fallback was needed. It names no round that assesses values, so no values-style round is detected and no values cheat sheet is included.

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same problem and is clearly angry. What do you do first?" | CASE | [generic] | Structure it in short typed lines: acknowledge the repeat in one sentence, read the earlier contacts before replying, say what you will do and by when, ask for anything missing in one go, and decide whether it needs someone else. Name one assumption you are making. The question needs no claim about your past, so the guidance makes none | A live problem on the ad's escalation line (F4's requirement), asked as a decision. Generic because it is a pattern for the problem, not a fact about this employer |
| A2 | "A customer's issue is beyond what you can fix and needs another team. What do you tell the customer, and what do you pass on?" | CASE | [generic] | Two halves. To the customer: what is happening, what happens next, when they will hear. To the other team: everything needed so the customer never has to repeat themselves. Say you stay the customer's contact until the hand-over is confirmed. No claim about your past | Tests the escalation line (F4) as a procedure. Generic because it carries a pattern, and you have no quoted material on escalations yet |
| A3 | "A customer asks a product question you cannot answer. What do you say?" | CASE | [generic] | Say plainly that you will find out, and by when; never guess. Then the plan, said as a plan: who you would ask and what you would check. It is honest about the software gap in F5 without claiming anything about your past | The likeliest day-one situation for someone new to software support (F5). CASE because it is a live problem, JD because it scores the role's reality |
| A4 | "Here is a customer message: 'Your latest update has broken my reports and I need them for a meeting in an hour.' Write me your first reply, now." | JD | [generic] | Type it in the chat. First line: acknowledge the deadline. Then what you are doing or need, asked for once. Short, plain, no jargon, a clear next step. Nothing in it claims past experience | The ad's written-communication line (F3), tested live in the one format this interview uses. JD because it scores a stated requirement, CASE in delivery |
| A5 | "Your queue has forty open tickets and the oldest is two days old. How do you decide what to answer first?" | CASE | [generic] | Clarify first: are there response targets, and are any contacts flagged urgent. Then sort by urgency and customer impact before age; say what you would tell the people waiting longest; say what you would flag to the lead. No claim about your past | Tests prioritisation, which sits under the escalation line (F4). Generic because it is a pattern for the problem |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You haven't worked for a software company before. What would be hardest for you in the first month?" | JD | [grounded] "I've never worked for a software company" | The highest-ROI rehearsal in this pack. Hold only what the quote carries, and say it first yourself, in these words: "I've never worked for a software company." Then the plan, said as a plan: what you would learn about their product first and who you would ask. Answer slot: if you have looked at their product, say what you saw; if you have not, say so plainly and say how you would start. Follow-up level 1: "Isn't a software product a different world from an energy bill?" Hold the same words and return to the plan. Level 2: "What if a customer asks something technical you can't answer?" Return to A3's structure. Level 3: "Why would you ramp up quickly?" Do not claim speed you cannot back; answer from the plan. Concession wording, exact: "I've never worked for a software company. Here is how I would learn yours" | F5 is the single most predictable objection, so it gets the deepest rehearsal, with the limit named before it is asked. JD because it scores fit for the listed job, gap included |
| B2 | "The ad says Zendesk or a similar tool. You mentioned Freshdesk. How much of that carries over?" | JD | [grounded] "I use Freshdesk every day" | Say it as quoted: "I use Freshdesk every day." Describe only what you actually do in it, in your own words. Answer slot: if you have used Zendesk, say where and how; if you have not, say so plainly and stay with Freshdesk. Do not claim that features match unless you know they do | F2 is the ad's most specific tool requirement and the quote names a different tool. JD because it scores a stated requirement |
| B3 | "Tell me about a time you handled an escalation." | JD | [grounded] | The ad's line raises this, and your material does not yet carry a story for it (F4). Pick a time a contact needed to go beyond you, or became heated. It needs a named stake, what you did, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing you did, or how you would handle it | F4 has no evidence behind it, so the honest scaffold is rehearsed in advance. JD because the requirement is stated in the ad |
| B4 | "How do you keep your written replies clear?" | JD | [grounded] "answering around 60 calls and emails a day" | Start from the quote: "answering around 60 calls and emails a day." Answer slot: if you do anything particular, such as a way you structure or check a reply, say what it is, in your own words; if you do nothing in particular, or have not thought of it that way, say so plainly and stay with the emails you answered | F3's requirement asked directly. The question presupposes a practice, so the second branch lets the premise be false |
| B5 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I've never worked for a software company" | Choose the one you honestly think is weakest and say how you would close it. Your own words on one candidate: "I've never worked for a software company." If none comes to mind, say so plainly, then say who you would ask for help first. No need to name a weakness you do not believe in | Two rows are likeliest here (F4, F5). Skeptic stem, JD because it scores self-assessment against the role |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A 90-second arc with three beats, each only what its sentence says: the three years as a customer service advisor at an energy supplier; Freshdesk every day; training four new starters on the refunds process last year. Say them in your own words. Close with one honest reason for this role. If none comes to mind, say so plainly, then say what you would like to learn here | The biography question is where casual scoring happens. It draws on F1, F2 and F6 and no other row |
| C2 | "What made you apply for this role?" | EXP | [generic] | The reason has to be yours, and the pack cannot supply it. Choose one thing from the ad as you read it that matches what you want, and one from the company's own site once you have read it, because no company research could run here. If no reason beyond the job itself comes to mind, say so plainly | Casual motivation questions are scored. Generic because the pack holds no source for your reasons |
| C3 | "You trained new starters last year. Tell me about that." | EXP | [grounded] "I trained four new starters on our refunds process last year" | The story has only the beats the sentence states: four new starters, the refunds process, last year. Tell it at that scope. If asked for more, answer from what you remember doing, and say plainly where you do not remember | F6 is the one quote about teaching others, so a lead is likely to open it. No raising source in the ad asks for more, so there is no slot beyond the sentence |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that figure counted?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day" | Keep "around": it is your figure. Four slots, each in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part of the work was yours. Name the weakest assumption yourself before they do. If you do not know how it was counted, say so plainly. The pack supplies no method or baseline | F1's only figure, and a quantified claim is where a prober starts. EXP because it tests attribution and counting |
| D2 | "How many of those were calls and how many were emails?" | EXP | [grounded] "answering around 60 calls and emails a day" | Your sentence gives one combined figure and no split. If you know the split, give it in your own words; if you do not, say so plainly and say what you do know. Do not invent a ratio | A prober splits a combined figure. The number stays with the noun it came from, calls and emails together, so any split is yours to give or to decline (F1, F3) |
| D3 | "Walk me through the refunds process you trained people on." | EXP | [grounded] "I trained four new starters on our refunds process last year" | This is your own knowledge of the process, so explain it as you would teach it, step by step, in your own words. The pack supplies no steps. If you cannot recall a step, say so plainly | F6 names the process, so a prober will ask for it. It tests whether you know what you taught |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we hire you over someone who already works in software support?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier, answering around 60 calls and emails a day"; "I use Freshdesk every day"; "I've never worked for a software company" | Pause, restate the question, then hold. Hold only what the first two quotes carry. Through two follow-ups, return to them without adding to them. Then concede one thing specifically, in your own words: "I've never worked for a software company." Do not claim you would outperform anyone | The stem the Skeptic persona turns into a time limit. It draws on F1, F2 and F5 |
| E2 | "That training you gave: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold the sentence as it stands: "I trained four new starters on our refunds process last year." Answer slot: say which part was yours. If the process, the materials or the sessions were shared, or someone else's, say so plainly and return to the training you gave. The figure "four" raises the slots: how it was counted, what it is sensitive to, the assumption you would defend least | Attribution probes exist to catch inflation, and F6 is the claim most open to one. Hold then concede, specifically |

### P. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "A colleague answers a customer differently from how you would. What do you do?" | CASE | [generic] | Principles, not claims: check the team's shared guidance first, ask the colleague how they decided, and raise it with the lead only if customers are affected. Say what you would bring to the team, not only what you would need. No claim about your past | A collegial scenario with no past premised. Generic because it is a pattern for the problem |
| P2 | "How would you handle credit and thanks when a colleague helps you with a difficult contact?" | CASE | [generic] | Say who you would thank and how, and that you would say who helped when the contact is discussed. No claim about your past | Peer-style credit probe, asked as a hypothetical. Generic because no published value or quote backs it |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| 1 | "What does a good first month look like for someone coming from outside software?" | Opens the ramp-plan conversation on your terms, and answers B1's follow-ups before they arrive (F5) |
| 2 | "Which tool does the team work in day to day, and how are new people trained on it?" | Shows you are thinking about being productive quickly, and tells you what carries over from Freshdesk (F2) |
| 3 | "How does the team handle escalations: what stays with the person who took the contact, and what goes to whom?" | Lets you hear their model before you describe yours (F4) |
| 4 | "How are written replies reviewed or coached on the team?" | A team that coaches writing tells you what it values, and signals you care about the line in F3 |
| 5 | "What happens after this chat? Is there a further stage, such as a call or video, and what would it involve?" | A process question: it lets you prepare for the next stage in the right format |
| 6 | "What is the hardest part of this job for the people on your team right now?" | Invites the lead to describe real work, and gives you a concrete follow-up to ask |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Experienced with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is the pack's observation, not words for you: the material says Freshdesk, not Zendesk. B2's slot stays inside that scope |
| Software-company or software-industry support experience | Negative you stated, F5 | The plain acknowledgment: "I've never worked for a software company." No slot |
| Resolved or handled around 60 tickets a day | Inflated form of F1 | F1's quote at its own scope: "answering around 60 calls and emails a day". The figure belongs to calls and emails together, as you wrote it |
| Led or ran the new-starter training programme | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year". E2's slot asks only which part was yours |

## Sources

Provided documents: your message, which carried the invite text, the four ad requirements as you listed them, and your background. No dossier was present.

Searches sent, with what came back:

- "Lumenvale Software values": refused
- "Lumenvale Software interview process customer support": refused
- "Lumenvale Software company news": refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Lumenvale Software values | unavailable | Every call was refused. It would have moved a values cheat sheet and any VAL questions, so none are included |
| 2. Lumenvale Software interview process, support role | unavailable | Every call was refused. It would have checked loop structure and persona weights. Your invite alone establishes one text chat with the support team lead, so the loop is not guessed |
| 3. Lumenvale Software strategy and recent news | unavailable | Every call was refused. It would have fed CO and company-grounded CASE questions, so none are included |
| 4. Interviewer name and company | n/a | No interviewer name was given, only the support team lead's title, so there was no query to form. The interviewer read is absent |
| 5. Representative Customer Support Specialist JD | skipped | The four requirements you listed fix every fit-snapshot row and JD-tagged question. The full ad text is in the upgrade menu |

## Upgrade menu

- The full text of the ad: any `[inferred]` or `[generic]` question that the ad's own wording would sharpen becomes `[grounded]`, and unlisted requirements get rows
- The support team lead's name: an interviewer read, persona weights read from their public footprint, and a reverse question tied to their own path
- Whether the support team lead would be your manager or a peer: reweights every bank
- Any recruiter guidance on what the chat will cover: coverage assumed from the hiring-manager prior is replaced by theirs
- Your answers to the slots in F2, F3 and F4, and to D1: each moves a row from discovery toward a quoted story
- Text from Lumenvale Software's own careers or values page, pasted in: a values cheat sheet and company-grounded CO questions, since search could not run here
- A deeper research pass, if your setup allows search: up to 6 more searches and 2 more fetches, several more minutes
- How much prep time you have: a prioritised schedule sized to it
- A `tuesday-dossier.md` from an earlier check: verified evidence and a prohibited-claims list that would replace the ones built here
