# Interview prep pack: Operations Coordinator, Quillmoor Diagnostics

**Round:** recruiter screen, Thursday at 2pm, a 30-minute phone call. Hannah Lowther (Talent Partner) will ring the mobile number on your application.
**Her stated agenda:** salary expectations, notice period, how the hybrid pattern would work for you, and what is prompting a move. Then she tells you about the team and the next steps.
**Built from:** the advert, your background notes, and Hannah's LinkedIn message. No company research ran (see Sources), so nothing here describes Quillmoor beyond its advert.

## How to use this pack

- **Personas** are how a question arrives (friendly, sceptical, probing). **Types** are what it scores. Every question carries both a persona (its bank) and a type tag.
- Type key:
  - **VAL**: past behaviour that shows values, not generic virtue.
  - **EXP**: whether your own account of your work holds up.
  - **JD**: whether you meet a stated responsibility or term of the advert.
  - **CO**: knowledge of the company and its strategy.
  - **CASE**: a live problem, structured aloud.
- Guidance is scaffolding, not a script. Where a cell says "answer slot", it is an instruction for the interview, not a question for me: answer it truthfully from your own experience, and either branch is a good answer.
- Provenance labels: `[grounded]` rests on your words or the advert, quoted in the row. `[inferred]` is derived from them. `[generic]` is a pattern with no claim about you or Quillmoor.
- The single highest-ROI rehearsal is **B1**. Do that one aloud first.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — the advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap on length: your line says four years against the advert's 2+. It is your own line with nothing inspected behind it, so expect a probe on what the four years held. Use the quote's own terms: logistics coordinator, building-supplies wholesaler |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — the advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Adjacent work, and the words stay at its scope: "I schedule deliveries for our three depots." Your material says deliveries for three depots at a wholesaler; it does not say production schedules, or work with planning or QA. Answer slot: the advert's line makes a probe on that likely. If any of your scheduling involved teams like those, say which and how, in your own words; if none did, or it was not production, say so plainly and stay with delivery scheduling for three depots |
| F3 | "chase late orders" (from "track supplier deliveries and chase late orders") — the advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | The quote already reaches this in role-relevant terms. A CV-style line with nothing inspected behind it, so expect a probe. Use it as you said it: you chase suppliers when orders slip |
| F4 | "track supplier deliveries" (from "track supplier deliveries and chase late orders") — the advert | "chase suppliers when orders slip" — your message | low | [inferred] | discovery | Chasing a slipped order touches tracking but does not show how deliveries are tracked. Answer slot: if you keep any record of when supplier deliveries are due or arrive, say how, in your own words; if there is no such record, or it is not yours, say so plainly and stay with chasing suppliers when orders slip |
| F5 | "keep stock records accurate" — the advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | The quote reaches the requirement in role-relevant terms. It is a headline figure with nothing inspected behind it, so it is a magnet for probes (C1, F2 in the Pressure bank). Keep it at its own wording: "about a third", "over a year" |
| F6 | "confident with Excel" — the advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | The quote says spreadsheet, not Excel, and does not show what was built in it. Answer slot: see C2. If it was Excel, say what you built, in your own words; if it was another tool, or part of it was not yours, say so plainly and stay with the rebuild |
| F7 | "report weekly on on-time dispatch" — the advert | none given | none | [grounded] | discovery | Your material says nothing either way, so this is a gap in what I can see, not a finding about you. Answer slot: see C3. If you produce any regular report on deliveries, say what and how often; if you do not, say so plainly and say what you would look at first |
| F8 | "ERP experience (SAP or similar) a plus" — the advert | "Never used SAP — we run our own in-house stock system" — your message | medium | [grounded] | transferability | You stated the SAP absence, so the plain words are yours: "I've never used SAP." The in-house system stays at its own scope: "we run our own in-house stock system." Your material does not say what that system does. Answer slot: see B2. Then, as a plan and never a past, how you would go about learning SAP |
| F9 | "£38,000–£44,000" — the advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your figure sits inside the advertised band, so there is no gap. Your own words, whole: "I'm hoping for £42,000." Nothing further is asked of this row |
| F10 | "Hybrid: two days a week at our Avonmouth site in Bristol" — the advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | The advert's two days is inside what you said. The two halves of your sentence stay together: two days is fine, and more than three is not wanted. Nothing further is asked of this row |

Proposed wording in the Gap and bridge column, pending your approval.

## Persona table

The loop is one session, established by Hannah's own message as you relayed it: a 30-minute call with her, covering four logistics items before she describes the team and next steps. Nothing you have shared says what follows the screen, so the pack does not guess at later rounds.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Bank |
|---|---|---|---|---|
| Conversational / Rapport Builder | Friendly, unstructured; the four agenda items arrive as chat, not an interview | Highest. The recruiter-screen prior is Conversational plus a light Skeptic, and Hannah's message lists four items that map one-to-one to A2 to A5. The risk is treating a friendly call as unscored | A short, spoken arc for the background question; treat each casual logistics question as scored; for pay, notice and place, say your own answer and stop | A (5) |
| Skeptic | Quiet, persistent probing of gaps: why leave, why here, the wholesaler-to-manufacturer step, the SAP line | Mid. A light Skeptic is the screen prior; the advert's production-scheduling duty and its SAP line sit against the background in F2 and F8, so these two objections are the likeliest | Rehearse the single most predictable objection (B1) until it is boring; say plainly what your material does not show; give a plan for the rest | B (3) |
| Data-Driven Prober | Reads the application line by line; asks how a number was counted | Mid. The advert's accuracy and weekly-reporting duties make numbers central, and your material has one figure (F5). A recruiter may ask once; a hiring manager will ask more | Know how the figure was counted and say plainly where you do not; name the assumption you would defend least before they do | C (3) |
| Case / Strategist | A live problem from the actual role | Low for Thursday: a recruiter screen rarely runs cases. Included so the style is not new later, since nothing says what follows | Clarify, then who is affected, then options, then what you would record; think aloud | D (2) |
| Peer Evaluator | Seam-splitting between planning, warehouse and QA | Low for Thursday. Included for any later conversation with the team | Offer seam principles rather than pretending to know the seam; reciprocity framing | E (2) |
| Pressure / Stress | Time-boxed challenge | Low. Unlikely from a friendly screen; included as insurance | Pause, restate, anchor in what you actually said; hold through two follow-ups, then concede specifically | F (2) |
| Values / Behavioural | Scenario probes | Low. No published Quillmoor values were read and nothing establishes a values round, so these are generic | Where one of your quoted lines carries a story, map it; otherwise select by criteria and use the honest branch | G (2) |

## Question banks

### A. Conversational (weight: highest)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your background and how you got to where you are." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | A 90-second arc with the three beats those quotes state: the four years as a logistics coordinator at a building-supplies wholesaler; scheduling deliveries for three depots and chasing suppliers when orders slip; rebuilding the stock-count spreadsheet, with discrepancies falling by about a third over a year. Tell them in your own words and at those scopes; add no titles, tools or team sizes. Stop there and let her choose what to dig into | F1, F3 and F5 are the evidence she can see on the application, so the opener checks your account against it. EXP because it tests whether your telling matches the page |
| A2 | "What's prompting a move?" | EXP | [grounded] "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot, filled with your own words: "I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." Say it in that order and stop. A follow-up on it gets the same words again, with nothing added | Hannah named it as an agenda item. EXP because it concerns your own history; Conversational because it arrives as a friendly aside that is still scored |
| A3 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot, filled with your own words: "I'm hoping for £42,000." Say it and stop; a follow-up on it gets the same words again. If asked about your current pay, you can decline to give a figure and bring the conversation back to the figure you gave | F9. Hannah named it as an agenda item. JD because the advert's band is the listed job's terms |
| A4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period, as your contract states it. Your material does not give it, so nothing else goes in this answer | Hannah named it as an agenda item. JD because it concerns the job's terms; `[generic]` because it makes no claim about you |
| A5 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot, filled with your own words: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." Keep both halves together. A follow-up on the days or the journey gets the same words again, with nothing added | F10. Hannah named it as an agenda item. JD because the office pattern is the listed job's terms |

Proposed wording, pending your approval.

### B. Skeptic (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "This job coordinates production schedules between planning, the warehouse and QA, and your background is at a wholesaler. What have you done that's close to that?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots"; "chase suppliers when orders slip" | **Highest-ROI prep in this pack.** Hold only what the quotes carry: "I schedule deliveries for our three depots." Limit, named before it is asked for: your material says deliveries for three depots, not production schedules and not work with planning or QA. Answer slot: the advert's "Coordinate production schedules between planning, the warehouse and QA" makes a probe likely on whether any of your scheduling involved teams like those. If any did, say which and how, in your own words; if none did, or it was not production, say so plainly and stay with delivery scheduling. Follow-up ladder: (1) "Close how?" return to the delivery quote. (2) "What would you need to learn?" give a plan in the future tense, in your own words, with nothing about a past you have not stated. (3) "So what do you bring on day one?" return to "I schedule deliveries for our three depots" and "chase suppliers when orders slip", and add nothing | F2 is where the advert's headline duty presses hardest on this background, so some form of this objection is likely, from Hannah or later. JD because it scores a stated responsibility; Skeptic because it arrives as quiet probing of the gap |
| B2 | "ERP experience, SAP or similar, is a plus. Where are you with that?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Plain acknowledgment, sourced to your own line: "I've never used SAP." Then the second half at its scope: "we run our own in-house stock system." Answer slot: the advert's "SAP or similar" makes a probe likely on what the in-house system does. Say what you use it for, in your own words; if it does little, or you use only part of it, say so plainly. Then a plan, not a past: how you would go about learning SAP, in your own words | F8. It is a plus, not a requirement, so the honest short answer is enough. JD because it scores the stated plus |
| B3 | "What's drawn you to this role and to Quillmoor?" | JD | [generic] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Selection scaffold: pick a line of the advert that matches work you do or want to do, and say why in your own words. Keep it separate from A2, since why you are leaving and why you want this job are different questions. If nothing about Quillmoor itself comes to mind beyond the advert, say plainly that the advert is what you have read so far, then give the nearest thing your material carries: "I schedule deliveries for our three depots and chase suppliers when orders slip" | Why-here is a standard screen question. No company research ran, so this is a scaffold and not a story map; JD because it scores motivation for the listed job |

Proposed wording, pending your approval.

### C. Data-Driven Prober (weight: mid)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You mentioned discrepancies fell by about a third over a year. How was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Defend the number in your own words, four slots: how it was counted; what it is sensitive to; the assumption behind it you would defend least, named before they do; which part was yours. Where you do not know how it was counted, say so plainly. Keep the figure at its own wording, "about a third" and "over a year", and do not tighten it into a percentage | F5 is the one figure in your material, and quantified claims are what probers go to first. EXP because it tests attribution and counting |
| C2 | "How confident are you with Excel — what have you done in it?" | JD | [grounded] "I rebuilt our stock-count spreadsheet" | Quote: "I rebuilt our stock-count spreadsheet." Answer slot: the advert's "confident with Excel" makes a probe likely on whether the spreadsheet was in Excel and what you built into it. If it was Excel, say what you built, in your own words; if it was another tool, or part of it was not yours, say so plainly and stay with the rebuild. Let the description carry it rather than a self-rating | F6. JD because it scores a stated requirement |
| C3 | "Weekly on-time dispatch reporting is part of this job. Where do you stand on that?" | JD | [generic] | Answer slot: the advert's "report weekly on on-time dispatch" makes a probe likely. If you produce any regular report on deliveries, say what it covers and how often, in your own words; if you do not, say so plainly and say what you would look at first. Your material says nothing either way, so no claim goes in this answer | F7. JD because it scores a stated responsibility |

Proposed wording, pending your approval.

### D. Case / Strategist (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A supplier tells you a delivery that QA is waiting on will be a week late. What do you do?" | JD | [generic] | Structure it aloud: clarify first (what is affected, how firm the new date is), then who needs to know (planning, the warehouse, QA), then your options, then what you would record. It is a live problem and needs no claim about your past, so the guidance makes none | The advert's "track supplier deliveries and chase late orders" (F3, F4), asked as a decision. JD content, CASE delivery |
| D2 | "The stock record and the shelf disagree on an item the line needs tomorrow. What do you do?" | JD | [generic] | Structure it aloud: clarify which is likely right and what is at stake tomorrow, who needs to know, how you would settle the count, and what you would record so it does not recur. No claim about your past goes in | The advert's "keep stock records accurate" (F5), asked as a decision. JD content, CASE delivery |

Proposed wording, pending your approval.

### E. Peer Evaluator (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Our teams sit side by side. Planning wants stock by Friday and the warehouse can't pick it until Monday. Where's the seam, and what happens when we disagree?" | CASE | [generic] | Offer seam principles rather than pretending to know this company's seam: ask what drives each date, say what you would need from each side, and say what you would bring the other team in return. No claim about your past goes in | F2's requirement, set between the three teams the advert names. CASE because it is a live problem; Peer because it tests partnership fit |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] "I schedule deliveries for our three depots" | Selection scaffold: pick a time work crossed teams or sites that needs a named result, your own part kept distinct from others', and a relationship that stayed intact. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I schedule deliveries for our three depots" | A standard peer probe. VAL because it scores behaviour with colleagues; no published values were read |

Proposed wording, pending your approval.

### F. Pressure (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Sixty seconds: why you for this role?" | JD | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold what the quotes carry: the four years, the deliveries and chasing, the spreadsheet rebuild and its figure. Hold through two follow-ups by returning to those lines and adding nothing. Concede specifically: SAP with B2's plain acknowledgment, and production scheduling with B1's slot. Do not fold on the quotes just to end the pressure | F1 is the stated length requirement. JD because it scores the fit for the listed job; Pressure because it is time-boxed |
| F2 | "That result — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold: "I rebuilt our stock-count spreadsheet" is your sentence, and the fall in discrepancies is stated alongside it. Answer slot: if anything besides the rebuild contributed to the fall, or you do not know how much was the rebuild, say so plainly, then return to the rebuild. Hold through two follow-ups; concede only what you actually do not know | F5. EXP because it tests attribution; Pressure because the interviewer challenges the figure's ownership |

Proposed wording, pending your approval.

### G. Values / Behavioural (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] "chase suppliers when orders slip" | Selection scaffold: pick a time that needs a named stake, a moment you did not fold, and a working relationship that survived. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "chase suppliers when orders slip", or say how you would handle it | A standard values-round stem. No Quillmoor values were read, so it is generic |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] "I schedule deliveries for our three depots" | Selection scaffold: pick a time with a named customer need, a metric you set aside, and an outcome you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: "I schedule deliveries for our three depots", or say how you would handle it | A standard values-round stem; generic for the same reason as G1 |

Proposed wording, pending your approval.

### Requirement coverage

| Requirement | Covered by |
|---|---|
| "2+ years in operations or logistics coordination" | A1, F1 |
| "Coordinate production schedules between planning, the warehouse and QA" | B1, E1 |
| "track supplier deliveries and chase late orders" | D1, A1 |
| "keep stock records accurate" | D2, C1, F2 |
| "report weekly on on-time dispatch" | C3 |
| "confident with Excel" | C2 |
| "ERP experience (SAP or similar) a plus" | B2 |
| "£38,000–£44,000" | A3 |
| "Hybrid: two days a week at our Avonmouth site in Bristol" | A5 |
| Hannah's agenda: notice period, what is prompting a move | A4, A2 |
| Why this role | B3 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "How does a typical week split between planning, the warehouse and QA, and who would I report to?" | It uses the advert's own three teams, so it reads as having read the role; the answer shows what day one is. Hannah may pass this to the hiring manager, which is itself useful to hear |
| R2 | "How is the weekly on-time dispatch report used today, and what does it look like?" | It ties to the advert's reporting line and tells you whether you inherit a report or build one |
| R3 | "Which two days do the team usually share at Avonmouth, and is the pattern fixed?" | Practical, and it follows from the hybrid item she raised, so it continues her thread rather than opening a new one |
| R4 | "Which ERP does the team run, and how does a new starter get trained on it?" | It addresses the SAP line directly and signals a plan to learn, with nothing claimed about the past |
| R5 | "What would you want a new coordinator to have sorted by the end of their first month?" | It is tied to the advert's duties (supplier deliveries, stock records) and shows you think about starting well |
| R6 | "How do planning, the warehouse and QA currently pass information to each other?" | It goes to the seam the advert names, and the answer tells you whether the role is a fix or a continuation |

Proposed wording, pending your approval.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Scheduled production, or coordinated planning and QA | Inflated form of F2 | F2's quote at its own scope: "I schedule deliveries for our three depots." The limit is the pack's observation: the material says deliveries for three depots, not production schedules. B1's slot stays inside delivery scheduling |
| Used SAP, or an ERP like it | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I've never used SAP." No slot |
| Treating the in-house stock system as the equivalent of SAP | Inflated form of F8 | F8's quote at its own scope: "we run our own in-house stock system." The limit is the pack's observation: the material does not say what that system does |
| Cutting discrepancies by exactly a third, or by a stated percentage | Inflated form of F5 | F5's quote at its own scope: "about a third over a year." C1's slots ask only how it was counted and what part was yours |
| Advanced or expert Excel skills | Inflated form of F6 | F6's quote at its own scope: "I rebuilt our stock-count spreadsheet." C2's slot asks only what was built |
| Being open to more than three days at Avonmouth | Contradicted by F10's quote | F10's quote, whole: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" |

## Sources

Provided documents: the Operations Coordinator advert; your background notes and what you plan to tell Hannah; Hannah Lowther's LinkedIn message as you pasted it. No `tuesday-dossier.md` was present, so the pack was built from raw inputs.

Searches sent (each one refused: the search permission was not granted in this session):

- "Quillmoor Diagnostics company values": refused
- "Quillmoor Diagnostics interview process operations coordinator": refused
- "Quillmoor Diagnostics Avonmouth Bristol news": refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics": refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quillmoor Diagnostics` values | unavailable | Every call was refused. It would have moved B3, G1 and G2 (company-specific values) and a values cheat sheet if a values round were documented. Nothing about Quillmoor's values is established |
| 2. `Quillmoor Diagnostics` interview process, operations coordinator | unavailable | Every call was refused. The loop rests on Hannah's own message (one 30-minute call); nothing is established about later rounds, so the persona weights for D to G are priors, not documented |
| 3. `Quillmoor Diagnostics` strategy / recent news | unavailable | Every call was refused. It would have moved a company-strategy question; none is in the pack, since model memory is not a source for it |
| 4. `Hannah Lowther` at `Quillmoor Diagnostics` | unavailable | Every call was refused. The interviewer read is absent and R1 to R6 are role-generic |
| 5. representative `Operations Coordinator` JD | skipped | The advert you supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Search access, or a pasted Quillmoor values or "about us" page → B3, G1 and G2 become company-specific, and a company-strategy question becomes possible
- Your notice period, in your own words → A4 becomes a quoted answer instead of an instruction
- Your answers to the slots in B1, B2, C1, C2 and C3 (outside a drill) → rows F2, F4, F6, F7 and F8 are regenerated from what you actually did
- Your CV text → more quoted evidence for F1 to F8
- Anything Hannah or the recruiter's emails say about the next rounds → a documented loop and reweighted personas
- A `tuesday-dossier.md` from an earlier job-underwriter run, if you have one → verified evidence for the fit snapshot and a named top objection in place of an inferred one
