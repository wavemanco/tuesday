# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager. Format: a 30-minute video call. Relationship assumed: the person you would work for day to day, so the pack treats this as a hiring-manager round. Built from your message only, with no company research (see Sources).

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether your past behavior shows the values the employer cares about, not generic virtue |
| EXP | Whether what you say about your experience survives follow-up, and exactly what was yours |
| JD | Whether you can do the listed job, gaps included |
| CO | What you know about the company and its strategy (none in this pack: no company research was possible) |
| CASE | How you structure a live problem from the job |

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it in your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | The ad's word is calendars and your word is appointment book. Say it in your own term and let the interviewer make the link: "I ran the appointment book for four physios." Your material says the book and the four physios, with nothing inspected behind it, so expect a probe on what running it involved |
| F2 | "booking travel" — the ad, as you described it in your message | none given | none | [grounded] | discovery | Your material does not show travel booking. Answer slot: the ad's "booking travel" makes a probe on it likely. If you have booked travel for anyone, say what and for whom, in your own words; if you have not, say so plainly and return to F1's appointment book |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it in your message | "I'm good with Word" — your message | medium | [grounded] | presentation | Keep it at its own scope: "I'm good with Word." It states a skill level, with nothing inspected behind it, and does not say which documents you prepared. C2 carries the probe on it |
| F4 | "preparing documents in Word and Excel" — the ad, as you described it in your message | "okay with Excel" — your message | medium | [grounded] | discovery | Hold your own rating: "okay with Excel", never upgraded to good under pressure. Answer slot: the ad's "preparing documents in Word and Excel" makes a probe on what you do in Excel likely. If you have built or edited spreadsheets, say what, in your own words; if you have not, say so plainly and stay with "okay with Excel" |
| F5 | "processing supplier invoices" — the ad, as you described it in your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, not processing supplier invoices, and does not say whose invoices they were. Say it at its own scope: "I chased unpaid invoices." Answer slot: the ad's "processing supplier invoices" makes a probe likely. If any invoices you handled were from suppliers, say what you did with them, in your own words; if none were, say so plainly and stay with the chasing |

## Persona table

The weights rest on the hiring-manager prior for the round, adjusted by what the ad lists. No source established this company's real loop, so the generic archetype applies and adds no tilt of its own.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live mini-tasks taken from the duties: a clash, a booking, a mismatched invoice | High: the hiring-manager prior favors it, and the ad lists four concrete duties that each turn into a live task | Clarify first, then structure, then say what you would confirm before acting; think aloud |
| Skeptic | Quiet probing of the thinnest rows | High: F2 and F5 are the thinnest rows, so the likeliest objection is aimed there | Rehearse the single most predictable objection (B1) until it is boring; use only what your quotes carry; give a concrete plan for the rest |
| Conversational/Rapport | Friendly biography and preference questions | Medium: a 30-minute video call with an office manager invites a conversational register, and it is still scored | A 90-second arc for the biography question; treat casual questions about the listed duties as scored |
| Data-Driven Prober | Pressing on how you did what you say | Medium: the invoice and Excel claims are the parts that can be checked | Know what you can and cannot say about each claim, and say plainly when you do not know |
| Values/Behavioral | Scenario questions about past behavior | Low: no published values were read, and no source documents a values round | Pick a real instance, or say plainly that none comes to mind |
| Pressure/Stress | Interruptions, time-boxing | Low: nothing in what you shared points to it; not banked, though B1's hold-then-concede structure covers the core | Pause, restate, hold a position through two follow-ups |
| Peer Evaluator | Seam-splitting between teams | Low: the office manager is treated as a manager, not a peer; not banked, and it moves up if you learn otherwise | Reciprocity framing |

## Question banks

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two people ask you for the same hour on the same calendar and they cannot both have it. What do you do?" | CASE | [generic] | Structure it aloud: what you would ask first (what each request is for, and who decides priority), what you would offer each person, how you would confirm the outcome in writing to both, and what you would record. The question needs no claim about your past, so the guidance makes none | Live version of the calendar duty in F1's requirement; CASE because it is asked as a decision, and `[generic]` because it is a pattern, not a fact about this employer |
| A2 | "A manager asks you to book a trip for next week: a return flight and two nights in a hotel. What do you need to know before you book anything?" | CASE | [generic] | Clarify before acting: dates and times, traveller details, budget and approval, preferences, how it is paid for and confirmed. Then confirm back before you buy and keep a record. Answer slot: if the interviewer then asks whether you have done this, answer from your own experience; if you have booked travel, say what and for whom; if you have not, say so plainly and say how you would handle the first booking | Travel booking is F2, the row with no evidence, so this question is the likeliest place the gap is tested; CASE because it scores clarifying before acting |
| A3 | "A supplier invoice arrives and the amount does not match what was ordered. What happens next?" | CASE | [generic] | Do not pay or pass it on yet. Check it against the order, ask the supplier or whoever ordered, record what you found, and tell whoever approves payment. No claim about your past is made | The invoice duty from F5's requirement as a live problem; CASE because it scores sequence and escalation |
| A4 | "You are given a spreadsheet of this month's supplier invoices and asked which are overdue. Talk me through how you would start." | CASE | [grounded] "okay with Excel" | Clarify what the columns hold and what today's date should be measured against, then sort or filter on the due date and check for blanks and duplicates. Answer slot: name the Excel features you would reach for, only ones you have used; if you would look one up, say so plainly. Keep to what "okay with Excel" covers | F4 is where the Excel claim meets a live task; CASE because the answer is scored on method, not on knowing a feature name |
| A5 | "It is nine in the morning and you have three requests: a calendar change for tomorrow, a query on an invoice, and a document needed by noon. How do you order them?" | CASE | [generic] | State your ordering rule before applying it (deadline and consequence), say what you would tell each requester, and name what you would check before starting. No claim about your past is made | A remote admin role is mostly prioritization across duties; CASE because it scores the rule, not the particular order |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "okay with Excel", "chased unpaid invoices" | The highest-ROI prep in this pack, so rehearse it most. Choose honestly from the rows your material does not fully show (travel booking, supplier invoices, Excel) and say which is truly weakest for you. Hold what your own words carry: "okay with Excel", "chased unpaid invoices". Follow-up one will ask how you would close it in your first month: answer with a plan, in future tense. Follow-up two will ask what if that is not enough: concede plainly that it would take longer, and do not claim a skill you did not state. Answer slot: if you have done any of the weak part, say what, in your own words; if you have not, say so plainly | F2 and F5 are the rows an interviewer reading the ad against your background reaches first, so some form of this question is very likely; JD because it scores the listed duties, gaps included |
| B2 | "You chased unpaid invoices. How is that different from processing supplier invoices?" | JD | [grounded] "chased unpaid invoices" | Hold the quote at its own scope: "I chased unpaid invoices." Do not claim the supplier side. Answer slot: if any invoices you handled were from suppliers, say what you did with them, in your own words; if none were, say so plainly and stay with the chasing. Hold through two follow-ups by returning to the chasing, never by adding to it | F5's gap, asked directly; JD because it scores the invoice requirement |
| B3 | "I do not see booking travel in your background. How would you handle that part of the role?" | JD | [grounded] | The question states what the interviewer sees, not what you did. Answer slot: if you have booked travel for anyone, say what and for whom; if you have not, say so plainly. Then give a plan in future tense: what you would confirm before each booking and what you would ask about the tools used | F2 has no evidence, so this probe is the likeliest after B1; JD because it scores a listed duty |
| B4 | "Why are you applying for this role, and why now?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Give your actual reason in one sentence, in your own words; the pack supplies none. Then connect it only to what you stated: two years as a receptionist at a physiotherapy clinic. Never state a reason you do not hold | The motivation probe a skeptic asks of anyone changing setting; EXP because it tests the consistency of your account |
| B5 | "Tell me about a time you had to work something out without anyone to ask." | JD | [grounded] "I ran the appointment book for four physios" | The title names a remote role, so expect this. Pick a real time: it needs the problem, what you did, and who you told afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I ran the appointment book for four physios", or how you would handle it | Remote work is the title's own word, so independence is likely probed; JD because it scores a condition of the role |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your background." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices" | A 90-second arc with only the beats your words state: two years as a receptionist at a physiotherapy clinic, the appointment book for four physios, the chasing of unpaid invoices. End on your own reason for this role. Add no detail you did not give | The opening question of almost any conversational round; EXP because it is where your account is first set |
| C2 | "What are you actually playing with in Word and Excel these days?" | JD | [grounded] "I'm good with Word", "okay with Excel" | Casual, but scored against F3 and F4. Answer slot: if you use either regularly, say for what, in your own words; if you do not, say so plainly and say which you would practise first before starting | The ad names both tools, so a casual probe on them is likely; JD because it scores the requirement |
| C3 | "What is the part of an admin job you would be happiest doing all day?" | JD | [generic] | Give your honest answer, and tie it to the ad's duties (calendars, travel, documents, invoices) only where it is true. The question needs no claim about your past, so the guidance makes none | Rapport interviewers use preference questions to test genuine interest; JD because the honest answer reveals fit with the listed duties |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. What exactly was yours to do?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold the quote: "I ran the appointment book for four physios." Answer slot: say which parts of running the book were yours, in your own words; if some were not, say so plainly. Weakest-assumption slot: name the part of your account you would defend least, or say plainly that you do not know how something was set up | F1 is the one calendar row, and "four physios" is the figure a prober presses on; EXP because it tests attribution |
| D2 | "Who were the unpaid invoices you chased owed to, and what did chasing involve?" | EXP | [grounded] "chased unpaid invoices" | Say who owed whom and what you did, in your own words, only as far as you know. If you do not know a detail, say so plainly rather than filling it in. Do not turn the chasing into processing | F5 does not say whose invoices they were, and that is the first thing a prober asks; EXP because it tests what the work actually was |
| D3 | "You describe yourself as okay with Excel. What does okay cover?" | JD | [grounded] "okay with Excel" | Say in your own words what you can do. Answer slot: if there are tasks you are comfortable with, name them; if you are not sure where your skill ends, say so plainly. Hold "okay" under pressure, and do not upgrade it to good to look stronger | F4 holds only your own rating, so the interviewer will ask what it means; JD because it scores a listed tool |

### E. Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to give unwelcome news to someone senior." | VAL | [generic] | Pick a real time: it needs a named stake, what you said, and how the relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A standard behavioral probe; no published values were read, so the theme comes from the persona's usual stem, and it is `[generic]` |
| E2 | "When did you put a customer ahead of an internal target?" | VAL | [generic] | Pick a real time: it needs the two pulls, what you chose and why. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | A second behavioral probe from the same stem family; VAL because it scores a decision, and `[generic]` because it is a pattern, not a fact about this employer |

## Requirement coverage

| Requirement | Covered by |
|---|---|
| "managing calendars" | A1, A5, D1 |
| "booking travel" | A2, B3 |
| "preparing documents in Word and Excel" | A4, C2, D3 |
| "processing supplier invoices" | A3, B2, D2 |
| "Remote" in the title, the one condition of the role | B5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like in this role?" | It shows you are planning how to ramp, which answers the concern B1 raises before it is asked |
| R2 | "Whose calendars would I manage, and who decides when two requests clash?" | It shows you have thought about authority, not just scheduling, and it previews A1 |
| R3 | "How do supplier invoices reach this role, and who approves them?" | It separates processing from approving, and tells you how far the duty goes |
| R4 | "Which tools do you use for calendars, travel booking and shared documents?" | It shows you will prepare for the tools, and it tells you what to practise |
| R5 | "How does the working day run remotely: core hours, check-ins, how work is handed over?" | It shows you take the remote condition seriously |
| R6 | "What happens after this call, and is there a further stage?" | A process question: it lets you plan your preparation and signals interest |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: your material says the appointment book, not calendar management as the ad words it |
| Prepared documents in Word | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word." Your material states a skill level, not documents prepared |
| Is skilled or advanced in Excel | Inflated form of F4 | F4's quote at its own scope: "okay with Excel" |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices." Your material says the chasing, not the processing, and not whose invoices they were |

## Sources

Provided documents: your message, which held the invite text, your description of the ad, and your background.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | The search was refused. It would have fed a values cheat sheet, which this pack does not have |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | The search was refused. It would have fixed the loop structure, so persona weights rest on the hiring-manager prior and the generic archetype |
| 3. `Brennock Facilities Ltd news strategy` | unavailable | The search was refused. It would have fed company-knowledge questions, so the pack has no CO questions |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative `Remote Administrative Assistant` JD | skipped | Your description of the ad fixes the fit snapshot and the JD-tagged questions |

Queries sent, all refused: "Brennock Facilities Ltd values"; "Brennock Facilities Ltd interview process administrative assistant"; "Brennock Facilities Ltd news strategy".

## Upgrade menu

- The ad's full text → the four requirement rows become the ad's own words, and any requirement you did not mention gets its own row and question
- Your CV → the evidence cells can quote it, and the rows that rest on one sentence of your message can be checked against it
- Your answers to the answer slots in F2, F4 and F5 (whether you booked travel, what you do in Excel, whose invoices you chased) → those rows move from slots to your own words, and B1, B3 and D2 sharpen
- The interviewer's name → a reading of their public professional background, persona weights adjusted to it, and a reverse question tied to their path
- Permission for web search, with an optional deeper pass of up to 6 more searches and 2 more fetches, which takes several more minutes → published values, the real interview structure and current company context, which would add company-knowledge questions
- A `tuesday-dossier.md` → verified evidence, a strategy for each weak area, and a named highest-ROI objection, which would sharpen B1
