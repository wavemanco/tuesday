No dossier is present. I'll read the required references.
Your prep pack is saved as `quillmoor-diagnostics_operations-coordinator_interview_pack.md` in the working directory. It's built for a recruiter screen with Hannah Lowther and has 19 questions. My web searches on Quillmoor and Hannah were refused, so nothing in it comes from outside research. It uses only your message and the advert, and the Sources section lists each refused search.

- **B1 is the most important one to rehearse.** It asks where your experience comes closest to coordinating production schedules between planning, the warehouse and QA. Your material says you schedule deliveries for three depots, so the pack keeps your answer to those words and gives a "how I'd get up to speed" plan.
- **Hannah's four topics get your own words.** Pay, hybrid and your reason for leaving use your sentences exactly as you gave them. I added nothing about flexibility, a floor, or being made redundant.
- **Notice period is the gap.** You didn't tell me yours, so A3 just says to give your actual notice period.
- **SAP.** The pack has you say "I haven't used SAP", then mention your in-house stock system at its real scope. The advert calls SAP a plus, not a requirement.
- **Your stock-count sentence stays whole.** You wrote that you rebuilt the spreadsheet "and" discrepancies fell by about a third. The pack keeps it that way and doesn't say the rebuild caused the fall unless you can back that up.

Questions for you:
- Can you paste your CV? The pack currently quotes your message, and your CV's own lines would be more reliable. If you'd rather not, nothing changes.

Say the word and I'll run a mock call, starting with Hannah on B1. I can also save a `tuesday-dossier.md` recording the gaps this prep turned up, for later sessions, or convert the pack to a Word document.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quillmoor-diagnostics_operations-coordinator_interview_pack.md -----
# Interview pack: Operations Coordinator, Quillmoor Diagnostics

Recruiter screen with Hannah Lowther (Talent Partner), Thursday 2pm, 30-minute phone call. She will ring the mobile number on your application. Built from your message and the advert only: the web research I tried was refused, so nothing here rests on outside facts about the company.

## 1. How to use this pack

Personas describe how a question is asked. Types describe what it is scoring. Guidance is scaffolding, not a script: say it in your own words, and rehearse only what you actually did.

| Type | What it scores |
|---|---|
| VAL | Whether past behavior shows the company's published values |
| EXP | Whether your experience holds up when probed |
| JD | Whether you can do the listed job, gaps included |
| CO | How much you know about the company |
| CASE | How you structure a live problem |

Labels: [grounded] traces to something you gave me or the advert, [inferred] is derived from it, [generic] is a pattern with no claim about you or Quillmoor.

Highest-ROI prep in this pack: B1. The advert's first duty is coordinating production schedules between planning, the warehouse and QA, and your material is closest to it through delivery scheduling for depots. Expect that question in some form.

Answer slots (instructions that end without a question mark) are for the call itself. You do not need to reply to them here.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in operations or logistics coordination" — advert | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | medium | [grounded] | none | No gap, but a line with nothing inspected behind it, so expect a probe on it. Lead with it in your own terms: the role, the years, the employer's type |
| F2 | "Coordinate production schedules between planning, the warehouse and QA" — advert | "I schedule deliveries for our three depots" — your message | medium | [grounded] | transferability | Your material says deliveries and depots, not production, planning or QA. Words: "I schedule deliveries for our three depots." Answer slot: the advert names planning, the warehouse and QA, so expect a probe on who you coordinated with. If any depot scheduling involved a planning or quality function, say which and what you did with them; if it did not, say so plainly and stay with the deliveries you schedule |
| F3 | "track supplier deliveries" — advert | "I schedule deliveries for our three depots" — your message | low | [inferred] | discovery | Scheduling deliveries to depots touches the requirement without showing it reaches tracking what suppliers send. Answer slot: if you follow supplier deliveries from order to arrival, say how, in your own words; if you do not, or it was not yours, say so plainly and return to the depots |
| F4 | "chase late orders" — advert | "chase suppliers when orders slip" — your message | medium | [grounded] | none | A quote that already reaches the requirement in role-relevant terms. Use your words: "I chase suppliers when orders slip" |
| F5 | "keep stock records accurate" — advert | "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" — your message | medium | [grounded] | none | Keep the sentence whole, including its "and": it says you rebuilt the spreadsheet and that discrepancies fell, not that the rebuild caused the fall. The figure raises the defend-the-number slots in C1 |
| F6 | "report weekly on on-time dispatch" — advert | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you report on anything like on-time dispatch, say what, how often and to whom; if you do not, or it was not yours, say so plainly and name what you would want to learn first |
| F7 | "Confident with Excel" — advert | "I rebuilt our stock-count spreadsheet" — your message | low | [inferred] | discovery | A spreadsheet is named, not the tool. Answer slot: if it was built in Excel, say what you did in it, in your own words; if it was another tool, say so plainly |
| F8 | "ERP experience (SAP or similar) a plus" — advert | "Never used SAP — we run our own in-house stock system" — your message | none | [grounded] | capability | The advert calls this a plus, not a requirement. Words: "I haven't used SAP." The in-house system stays at your scope: "we run our own in-house stock system." Whether that counts as similar is the interviewer's call, not a claim to make. Then how you would learn a new system, said as a plan and not as a past |
| F9 | "Hybrid: two days a week at our Avonmouth site in Bristol" — advert | "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" — your message | high | [grounded] | none | Your statement is the strongest evidence for a constraint. The advert's two days sit inside your own limit. Keep both halves of your sentence together |
| F10 | "£38,000–£44,000" — advert | "I'm hoping for £42,000" — your message | high | [grounded] | none | Your figure sits inside the advertised band. Keep it as you said it: "hoping for", nothing firmer or softer |

Notice period and reason for leaving are not advert requirements, so they are not rows. They are handled in A3 and A5.

## 3. Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational | Friendly walk-through, then her four stated topics: pay, notice, hybrid, what is prompting a move | Highest. Recruiter-screen prior, raised further by her own message listing exactly those four topics | Short arcs built from your own sentences; treat the casual questions as scored |
| Skeptic | Quiet probing of the match between wholesale delivery work and a manufacturing role, SAP, and why here | High. The recruiter row's light Skeptic, and F2 and F8 are the thinnest rows | Rehearse B1 until it is boring; calibrated candor over bluffing |
| Data-Driven Prober | Reads the stock figure line by line | Medium. A recruiter may skim it, but it is your one headline number | Know how the figure was counted, say plainly what you do not know |
| Case/Strategist | A small live scenario about supply, stock or dispatch | Low to medium. Unusual in a screen, likely later with a hiring manager | Clarify first, then structure, think aloud |
| Pressure | A short sharp challenge on fit or attribution | Low. Possible as a quick test of how you hold a position | Pause, anchor in your own sentences, hold through two follow-ups |
| Peer Evaluator | Cross-team seam questions | Low. A recruiter is not a peer, but the role sits between three teams | Principles for working across teams, not claims about a seam you have not seen |
| Values/Behavioral | Not included | No values-style round is established: your message describes one phone call, and no loop source was available | n/a |

## 4. Question banks

### A. Conversational (weight: top, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Give me the two-minute version of your background." | EXP | [grounded] "4 years as a logistics coordinator at a building-supplies wholesaler"; "I schedule deliveries for our three depots and chase suppliers when orders slip"; "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Three beats, each a sentence you have already given: the role and the 4 years; scheduling deliveries for three depots and chasing suppliers when orders slip; the stock-count spreadsheet and the fall in discrepancies, kept as one sentence with its "and". Tell them in your own words and stop there. Answer slot: if you want to say what in the advert caught your eye, say it in your own words and keep it to what the advert says | The opener nearly every screen has; F1, F4 and F5 are the rows it draws on |
| A2 | "What are your salary expectations?" | JD | [grounded] "I'm hoping for £42,000" | Logistics slot: say your own words, as you gave them: "I'm hoping for £42,000." The advert's band is £38,000–£44,000 and your figure sits inside it. If she asks about your current pay, you can decline or redirect without giving a figure | F10; one of the four topics Hannah named, and the only safe answer is your own |
| A3 | "What's your notice period?" | JD | [grounded] | Logistics slot: give your actual notice period, as it stands today. You have not told me it, so this pack does not supply one | One of the four topics Hannah named; nothing in your material states it |
| A4 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three" | Logistics slot: your own words, both halves together: "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three." If asked about the commute, your own words were exactly those | F9; the advert states the pattern, and Hannah named it as a topic |
| A5 | "What's prompting a move?" | EXP | [grounded] "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want" | Logistics slot: your own words, whole: "Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want." If she follows up, return to those words | One of the four topics Hannah named; a reason for leaving is scored for consistency |

### B. Skeptic (weight: top, 4 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role coordinates production schedules between planning, the warehouse and QA. Where does your experience come closest?" | JD | [grounded] "I schedule deliveries for our three depots" | The highest-ROI rehearsal in this pack. Hold only what the quote carries: "I schedule deliveries for our three depots." Level 1 follow-up, "that isn't production scheduling": return to the quote, without adding to it. Level 2, "who did you coordinate with": answer slot: if any depot scheduling involved a planning or quality function, say who and what you did; if it did not, say so plainly and stay with the depots. Level 3, "so how would you get up to speed": say it as a plan, in the conditional: what you would ask planning, the warehouse and QA in your first weeks. Never describe it as something you have done | F2 is the first duty in the advert and the likeliest place to be pressed; JD because it scores a stated requirement |
| B2 | "The advert mentions SAP or similar as a plus. What's your experience with ERP systems?" | JD | [grounded] "Never used SAP — we run our own in-house stock system" | Plain acknowledgment, then your scope: "I haven't used SAP. We run our own in-house stock system." Then a plan: how you would learn a new system. Answer slot: if the in-house system did more than hold stock figures, say what; if it did not, say so plainly and stay with the stock system | F8; the advert says "a plus", so a short honest answer closes it |
| B3 | "Tell me about a time you reported on whether deliveries went out on time." | JD | [grounded] | Selection scaffold: pick an occasion with a named audience, a time period and what the report showed. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | F6; the advert's weekly on-time dispatch report has no sentence of yours behind it, so this is a scaffold |
| B4 | "Why this role, and why Quillmoor?" | CO | [grounded] "Operations Coordinator — Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff)" | Research was refused, so this uses only the advert's own words: a diagnostic-test manufacturer of about 400 staff, and the duties it lists. Answer slot: say in your own words what in the advert draws you; if little does, say so plainly and name what the role would let you do. Do not claim knowledge of Quillmoor's products or news | The "why here, why now" probe; CO because it scores homework, and the pack can only supply the advert |

### C. Data-Driven Prober (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You said discrepancies fell by about a third — how was that counted?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Defend-the-number, in your own words. Answer slot, four parts: how the figure was counted; what it is sensitive to; the assumption behind it you would defend least; which part was yours. Where you do not know any of them, say so plainly. Keep the sentence as you gave it: it says you rebuilt the spreadsheet and that discrepancies fell, so do not say the rebuild caused the fall unless you can back it | F5; every headline figure gets a defend-the-number question |
| C2 | "Walk me through the stock-count spreadsheet you rebuilt." | EXP | [grounded] "I rebuilt our stock-count spreadsheet" | Beats the quote states: you rebuilt it, and it is the stock-count spreadsheet. Answer slot: the advert asks for confidence with Excel, so expect a probe on the tool. Say what it was built in and what you changed, in your own words; if it was not Excel, say so plainly and say what it was | F5 and F7; EXP because it checks what was actually yours, JD because it tests the Excel line |
| C3 | "When a supplier order slips, what do you do?" | EXP | [grounded] "chase suppliers when orders slip" | Say what your sentence says: when orders slip, you chase suppliers. Answer slot: the advert says track supplier deliveries and chase late orders. If the chasing had more steps that were yours, say them in your own words; if it was just the chasing, say so | F4 and F3; the likeliest probe on the stronger of your two supplier rows |

### D. Pressure (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why should we consider someone from wholesale for a manufacturing operations job?" | JD | [grounded] "I schedule deliveries for our three depots and chase suppliers when orders slip" | Pause and restate the question. Describe what you do and let the interviewer draw the inference: "I schedule deliveries for our three depots and chase suppliers when orders slip." Hold through two follow-ups by returning to that sentence. The pack's observation, not words for you: your material shows delivery scheduling and supplier chasing, not production scheduling. Answer slot: if you have worked alongside production planning or QA, say how; if you have not, say so plainly and return to the depots | F1 and F2; a composure test aimed at the biggest difference between your background and the role |
| D2 | "That stock result — how much of it was actually you?" | EXP | [grounded] "I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year" | Hold what the sentence says: you rebuilt the spreadsheet. Answer slot: if you want to say what else contributed to the fall, say it in your own words; if you do not know, say so plainly. Concede specifically and keep the claim to the rebuild | F5; the stem every probe on a number returns to |

### E. Case/Strategist (weight: mid, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "A supplier tells you a key delivery will be a week late. The warehouse has orders waiting on it, planning wants to reschedule production and QA has a batch to release. What do you do first?" | CASE | [generic] | Structure it aloud: what you need to know first (what is affected, by when), who needs to hear today, the options, who decides, and what you record. The question asks about no past, so the guidance makes no claim about yours | Live problem from the advert's coordination duty (F2, F4); generic because it is a pattern, not a fact about Quillmoor |
| E2 | "A stock count comes back well off the records. How do you work out why?" | CASE | [generic] | Clarify scope first (which items, which count), then segment the possible causes, say what you would check first and what you would record. Think aloud; no claim about your past | From the advert's stock-records line (F5) |
| E3 | "On-time dispatch dropped last week. How would you find out why and report it?" | CASE | [generic] | Clarify what counts as on time and what changed, then structure causes by team, say what you would check first and how you would report. No claim about your past | From the advert's weekly on-time dispatch line (F6) |

### G. Peer Evaluator (weight: low, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Planning wants a run brought forward and the warehouse can't take it. How do you handle that?" | CASE | [generic] | Principles, not a claimed seam: get both sides' constraints on the table, find what is actually fixed, escalate the decision to whoever owns it, and say what you would record. No claim about your past | The role sits between planning, the warehouse and QA (F2) |
| G2 | "How do you handle credit when work spans teams?" | JD | [generic] | Say how you approach it in general terms: be specific about who did what, name others' parts, keep your own claim to what you did. No story is mapped because none of your sentences carries one | Standard collaboration probe; the role works across three teams |

## 5. Requirement coverage

| Requirement | Questions |
|---|---|
| 2+ years in operations or logistics coordination | A1, D1 |
| Coordinate production schedules between planning, the warehouse and QA | B1, D1, E1, G1 |
| Track supplier deliveries | C3, E1 |
| Chase late orders | C3, E1 |
| Keep stock records accurate | C1, C2, D2, E2 |
| Report weekly on on-time dispatch | B3, E3 |
| Confident with Excel | C2 |
| ERP experience (SAP or similar) a plus | B2 |
| Hybrid: two days a week at Avonmouth | A4 |
| £38,000–£44,000 | A2 |

## 6. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Roughly how does the week split between coordinating production schedules and chasing suppliers?" | Tells you which of your rows to lead with in later rounds |
| R2 | "What systems does the team use for stock and supplier tracking?" | Lets you place your in-house system honestly against what they use |
| R3 | "What does the weekly on-time dispatch report look like today, and who reads it?" | Shows you are thinking about the reporting duty, and shows how far you would be starting from |
| R4 | "Who would I work most closely with across planning, the warehouse and QA?" | Shows you see the role as the link between three teams |
| R5 | "What would a good first three months look like?" | A standard question that signals you are planning to contribute |

## 7. Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has used SAP or another ERP | Negative you stated, F8 | "I haven't used SAP." The in-house system stays at "we run our own in-house stock system". No slot |
| Has coordinated production schedules with planning and QA | Inflated form of F2 | F2's quote at its own scope. The limit is the pack's observation: your material says deliveries and depots |
| Your rebuild cut discrepancies by a third | Inflated form of F5 | F5's sentence whole, with its "and". The limit is the pack's observation: the sentence does not say the rebuild caused the fall |
| Built an Excel model or is an advanced Excel user | Inflated form of F7 | "I rebuilt our stock-count spreadsheet" at its scope. The tool is not named in your sentence |
| Flexible on the office days, or willing to take less than £42,000 | Inflated form of F9 and F10 | Your own words: "two days at Avonmouth is fine, but I wouldn't want more than three" and "I'm hoping for £42,000". Nothing firmer or softer |
| Was made redundant | Inflated form of A5's reason | Your own words: the office is closing and the only offer is relocating to Reading |

## 8. Sources

Provided: your message (your background, pay, hybrid and reason for leaving), the Quillmoor advert you pasted, and Hannah Lowther's LinkedIn message.

Searches sent, none returned anything:

- "Quillmoor Diagnostics values" — refused
- "Quillmoor Diagnostics interview process operations coordinator" — refused
- "Quillmoor Diagnostics Avonmouth news" — refused
- "Hannah Lowther Talent Partner Quillmoor Diagnostics" — refused

Research tier: L1 — searches 4 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quillmoor Diagnostics values | unavailable | Search refused. Would have supplied published value names for B4; nothing in the pack uses a value |
| 2. Quillmoor Diagnostics interview process, operations role | unavailable | Search refused. Would have shown the loop and moved persona weights; weights rest on the recruiter-screen prior and your message |
| 3. Quillmoor Diagnostics strategy and recent news | unavailable | Search refused. Would have grounded B4 beyond the advert |
| 4. Hannah Lowther, Quillmoor Diagnostics | unavailable | Search refused. Would have supported an interviewer read and a tailored reverse question |
| 5. Representative Operations Coordinator advert | skipped | The advert you pasted fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Your CV, pasted → F1 to F5 would quote your CV's lines instead of your message, and C1 and C2 could be sharpened
- Your actual notice period → A3 would hold your own words instead of an instruction
- Web search allowed → B4 gets grounded in Quillmoor's own published material, persona weights follow their documented process, and a short interviewer read of Hannah becomes possible
- Hannah's own guidance on the call, if she sends any → coverage matches what she says she will ask
- A `tuesday-dossier.md`, if you have one → prohibited claims and the sharpest objection would arrive evidence-derived, not inferred
