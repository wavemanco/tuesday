Running three company searches (values, interview process, recent news) before I build the pack.
Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and says "you deposit the cheque and send the balance on to the vendor". A fee, your passport and bank details, and a cheque you deposit and partly pass on, all before any offer, are a known scam pattern. Those requests are very likely a scam. Hold all of them until you've checked the invite with the employer. Use contact details you find yourself on its own website or careers page, not the reply address or any number in the invite. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-5/rooms/case-12-denied-92101a42/brennock-facilities-ltd_remote-administrative-assistant_interview_pack.md`. It has 18 practice questions, a fit table built from your own words, six questions for you to ask, and a list of claims it won't coach. I built it for a hiring-manager-style round, since the invite only says you're meeting the office manager. The company searches were refused, so nothing in it comes from outside your message.

What to expect:
- **Practical scenarios.** Expect clashing diary requests, a cancelled flight, a mismatched supplier invoice, and a messy spreadsheet.
- **The invoice question.** The likeliest hard question is how chasing unpaid invoices compares with processing supplier invoices (B1). Say only what you did, then say how you'd learn the rest.
- **Excel and travel.** Describe Excel as "okay with Excel" and stop there. For travel booking, say plainly whether you've done it, and if not, how you'd learn.
- **Remote working.** They'll probably ask why you're moving from reception and how you'd work from home. Use your real reasons and your real plan.

Say the word and I'll play the Skeptic on B1, the question the pack names as its highest-ROI prep. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the office manager someone you'd report to, or a peer on the team? The answer reweights the question banks. Can you paste the full ad text? It would let me replace my summary of the four duties with the ad's own wording.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities-ltd_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

**Interviewer:** the office manager (name not given). **Format:** a 30-minute video call, in your invite's words "a 30-minute video call with our office manager". **Built on this assumption:** a hiring-manager-style round, since your note does not say whether the office manager would be your manager or a peer.

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it is scoring |
|---|---|
| VAL | Whether past behaviour shows the company's published values. None is used here, because no values were established |
| EXP | Whether your own experience holds up when probed, and what was actually you |
| JD | Whether you can do the listed duties, gaps included |
| CO | Company and strategy knowledge. None is used here, because the company research did not run |
| CASE | How you structure a live problem from the job |

An answer slot is an instruction for the interview, not a question for you now. Where it offers two branches, either branch is a good answer if it is true.

## Fit snapshot

The duties come from the ad as you described it, and the role title from the invite. The evidence column holds only your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, via your message | "I ran the appointment book for four physios" — your message | medium | [grounded] | transferability | Your material says the appointment book for four physios, not other people's calendars, and the words stay there: "I ran the appointment book for four physios." Answer slot: the ad's calendars line makes a probe on how the book was kept likely. If any part of how it was kept was yours to set, say which and how you decided, in your own words; if there was no such part, or it was not yours, say so plainly and describe how you ran the book |
| F2 | "booking travel" — the ad, via your message | none given | none | [grounded] | discovery | Your material does not show travel booking either way, so there are no words to give. Answer slot: the ad names travel, so expect a probe on it. If you have booked travel for anyone, say what and for whom, in your own words; if you have not, say so plainly and say how you would learn the booking process in your first weeks |
| F3 | "preparing documents in Word and Excel" — the ad, via your message | "I'm good with Word" — your message | low | [inferred] | discovery | A self-rating with nothing inspected behind it that does not say which documents, so it stays a self-rating: "I'm good with Word." Derived from your own sentence and no wider. Answer slot: the ad's documents line makes a probe on what you have prepared likely. If you have prepared documents that others used, say what kind, in your own words; if you have not, say so plainly and stay with the self-rating |
| F4 | "preparing documents in Word and Excel" — the ad, via your message | "okay with Excel" — your message | low | [inferred] | discovery | Your own rating is modest and the words stay modest: "okay with Excel." Derived from your own sentence and no wider. Answer slot: if you have used Excel for something specific, say what, in your own words; if you have not, say so plainly and say the first thing you would practise |
| F5 | "processing supplier invoices" — the ad, via your message | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices and does not say whose invoices they were, so the words stay at "chased unpaid invoices." Answer slot: the ad's supplier-invoices line makes a probe on the invoice side likely. If your work on those invoices went beyond chasing, say what, in your own words; if it did not, say so plainly and stay with the chasing |
| F6 | "Remote Administrative Assistant" — the invite, via your message | "two years as a receptionist at a physiotherapy clinic" — your message | medium | [grounded] | transferability | Your material says two years as a receptionist at a physiotherapy clinic, and it does not show whether any of that work was done remotely or without someone beside you. The words stay there: "two years as a receptionist at a physiotherapy clinic." Answer slot: the role title makes a probe on working remotely likely. If any of your work was done on your own or away from the clinic, say how, in your own words; if not, say so plainly and say how you would structure your day at home |

## Persona table

The invite describes one 30-minute video call with the office manager, which is the one session this pack prepares for. No values round is documented, so there is no values sheet. Weights start from the hiring-manager prior and rest on the assumption above, not on anything known about this employer.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Small live problems from the four duties: a clash in a diary, a changed trip, a mismatched invoice, a messy list | High. The hiring-manager prior puts practical problems first, and four of your six rows are duties rather than history. 5 questions | Clarify first, then structure, then say what you would check, and think aloud |
| Skeptic | Quiet probing of the duties your material does not reach: supplier invoices, travel, remote working, why the move | High. F2 and F5 are the thinnest rows and the ad names both. 4 questions, one of them the highest-ROI rehearsal in the pack (B1) | Say plainly what your material carries, hold it through two follow-ups, and describe how you would learn the rest as a plan, never as a past |
| Data-Driven Prober | Line-by-line probing of what you did with the appointment book and how good your Excel is | Medium. Your background is short, so each line gets looked at closely. 4 questions | Know what was yours, and say plainly where you do not know |
| Conversational | A friendly opening about your journey and why this role | Medium. A video call usually opens this way, and casual questions are still scored. 3 questions | A 90-second arc built only from your own sentences |
| Pressure | A time-boxed challenge on why you over someone more experienced | Low. Nothing in the invite suggests a stress style. 2 questions | Pause, restate, hold your position through two follow-ups, concede only what is true |

## Question banks

Provenance comes before the guidance: it carries the sentences the guidance rests on.

### A. Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A manager asks you to fit a meeting for five people into Thursday afternoon, and two of them are already booked then. What do you do?" | CASE | [generic] | Clarify first: how fixed Thursday is, who is essential, who could move. Then offer two alternative slots, say whom you would check with before moving anything, and confirm the outcome in writing. Say your thinking aloud; one clarifying question is a strength. The question needs no claim about your past, so the guidance makes none | A live problem from the ad's calendars line, the requirement behind F1, asked as a decision rather than a history. CASE because it scores structure |
| A2 | "A manager's flight is cancelled the evening before a client meeting, and you handle their travel. Walk me through the next hour." | CASE | [generic] | Clarify what matters: the arrive-by time, any cost limits, who else is affected. Then find options, put two forward with their trade-offs, confirm, and tell everyone who needs to know. The guidance makes no claim about your past | The ad's travel line, the requirement behind F2, which has no evidence; a case lets you show structure without claiming experience |
| A3 | "A supplier invoice arrives for more than the amount on the order. What do you do before anything is paid?" | CASE | [generic] | Clarify what you would compare it against and who raised the order. Check, query the supplier or the person who ordered, hold the invoice until the difference is explained, and record what was decided. The guidance makes no claim about your past | The ad's supplier-invoices line, the requirement behind F5, as a decision rather than a history |
| A4 | "I'll send you a messy list of supplier names and amounts and I need a tidy summary by end of day. How would you go about it?" | CASE | [generic] | Clarify what the summary is for and how it should look. Check the data first, build it, check the totals, and say where you would look something up rather than guess. Name only the Excel steps you would do yourself. The guidance makes no claim about your past | The ad's Word and Excel line, the requirement behind F3 and F4; the case lets you show care without claiming skill you have not stated |
| A5 | "Two people each tell you their request is urgent and you can only do one this morning. How do you decide?" | CASE | [generic] | Clarify the deadlines and what happens if each waits, ask each person, say who you would check priorities with, and tell the person who waits when to expect theirs. The guidance makes no claim about your past | A pattern for a remote admin role that serves more than one person; CASE because it scores how you decide |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You chased unpaid invoices at the clinic. How does that compare with processing supplier invoices?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI rehearsal in this pack, and the hold is only what the quote carries: "I chased unpaid invoices." Answer slot: if your work on those invoices went beyond chasing, say what, in your own words; if it did not, say so plainly and stay with the chasing. Hold through two follow-ups by returning to the chasing, never by adding to it, and concede only that this is what your material shows, then say how you would learn the rest as a plan | F5 is where the ad's invoice duty presses hardest on your material, so this objection arrives in some form. JD because it scores a stated requirement |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] "okay with Excel" | Choose from your own material and say it first, before they find it. Describe Excel as "okay with Excel" and name the first thing you would practise. Answer slot: the ad names travel booking and F2 has no evidence for it. If you have booked travel, say so and say what; if you have not, say so plainly and say how you would learn the booking process | The likeliest place for a skeptic to start is where F2 and F4 are thin. JD because it tests the listed duties, including their gaps |
| B3 | "Why move from a reception desk to a remote admin role?" | EXP | [generic] | Give your actual reason, in your own words, in one or two sentences; the pack does not write it for you. What you are moving toward is a stronger answer than what you are leaving. Answer slot: if there was no single reason, say so plainly and say what you are looking for now | A motivation-consistency probe tied to F6. EXP because it tests whether your story holds together |
| B4 | "This is a remote role. What would make working from home work for you?" | JD | [generic] | Describe your real plan: where you would work, how you would structure the day, how you would stay in touch. Answer slot: if you have worked on your own before, say how, in your own words; if you have not, say so plainly and describe the plan instead | The role title is the raising source, and F6 shows nothing either way. JD because remote working is part of the stated job |

### C. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how you ran the appointment book for four physios." | EXP | [grounded] "I ran the appointment book for four physios" | Story-mapped on F1: the book, and the four physios, which are the beats the quote states; tell them in your own words. Answer slot: the ad's calendars line makes a probe on how the book was kept likely. If any part of how it was kept was yours to set, say which and how you decided; if there was no such part, or it was not yours, say so plainly and describe how you ran the book | F1 is your main evidence for the calendars duty and the likeliest line to be probed. EXP because it tests what was actually yours |
| C2 | "How comfortable are you in Excel?" | JD | [inferred] "okay with Excel" | Say "okay with Excel" in your own words and stop; a modest, exact answer scores better than a stretched one. Answer slot: if you have used Excel for something specific, say what; if you have not, say so plainly and say the first thing you would practise | F4 is a low-confidence self-rating, so the probe is likely. JD because it scores a listed tool |
| C3 | "For those four physios, which part of the appointment book was actually yours to run?" | EXP | [grounded] "I ran the appointment book for four physios" | Answer slot: if the book was shared with anyone or someone else did part of it, say which part was yours; if all of it was yours, say so plainly. The number four is a headcount: if you know whether it changed while you ran the book, say so, and if you do not know, say so plainly | F1 contains a figure, which a prober defends to its edges: how it was counted, what it depends on, and which part was yours. EXP because it tests attribution |
| C4 | "Tell me about a time you prepared a document in Word that someone else relied on." | JD | [inferred] "I'm good with Word" | Selection scaffold: pick a document where you can say what it was for, who used it and what you made. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, "I'm good with Word", or how you would approach it | The ad's documents line is the raising source; F3 says only a self-rating, so the pack supplies no document for you |

### D. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey: how did you get to where you are?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" "I ran the appointment book for four physios" "chased unpaid invoices" | A 90-second arc with only the beats your sentences state: two years as a receptionist at a physiotherapy clinic, running the appointment book for four physios, and chasing unpaid invoices, each in your own words. Answer slot: say what drew you toward admin and this role; if there was no single reason, say so plainly and say what you are looking for now | The usual opener of a conversational round, built from F1, F5 and F6. EXP because it tests whether your account holds together |
| D2 | "What attracted you to this role?" | JD | [generic] | Pick one or two of the ad's four duties that you honestly want to do more of and say why, in your own words; the pack does not pick them for you. Say nothing you could not stand behind in a follow-up | A casual question that is still scored for genuine interest; JD because the answer should connect to the listed duties |
| D3 | "How do you keep track of a lot of small tasks at once?" | EXP | [generic] | Describe the method you actually use, in your own words. Answer slot: if you do not have a set method, say so plainly and describe how you would set one up | A question about working style that a remote role weights, with no claim about your past supplied |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, rather than someone who has done this exact job before?" | JD | [grounded] "I ran the appointment book for four physios" "chased unpaid invoices" | Pause and restate the question. Anchor on your two sentences: "I ran the appointment book for four physios" and "chased unpaid invoices." Hold that through two follow-ups, then concede specifically: name the duty on the ad that your material does not show and say how you would learn it, as a plan | The pressure persona tests composure, anchored on F1 and F5. JD because it scores fit against the stated role |
| E2 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Hold on "I ran the appointment book for four physios." Answer slot: if anyone else set up or shared parts of it, say which; if no one did, say so plainly. Do not add anything the sentence does not say, and concede only what is true | A direct attribution probe on F1, the line a pressure interviewer reaches for. EXP because it tests what was yours |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" (F1) | A1, A5, C1, C3, E2 |
| "booking travel" (F2) | A2, B2 |
| "preparing documents in Word and Excel" (F3, F4) | A4, C2, C4, B2 |
| "processing supplier invoices" (F5) | A3, B1 |
| "Remote Administrative Assistant" (F6) | B3, B4, D1, D2 |

## Reverse questions

| # | Question to ask | Why it lands |
|---|---|---|
| R1 | "Of the calendar, travel, documents and invoice work, which takes up most of the week for this role?" | It shows you read the four duties, and the answer tells you where to concentrate in your first weeks |
| R2 | "Which tools would I be using for diaries, travel booking, spreadsheets and invoices, and is there any training on them?" | It turns your thinnest rows into a practical question about onboarding, which reads as preparation rather than weakness |
| R3 | "How would we stay in touch through the day when I'm working remotely?" | It answers the remote-working probe from the other side and shows you are thinking about how the work runs |
| R4 | "What would a strong first month look like?" | It gives you a concrete target and signals that you plan to be useful early |
| R5 | "Who would I be supporting day to day, and how do requests reach me?" | It connects to the prioritising question in A5 and shows you are thinking about the people behind the work |
| R6 | "After this call, what are the next steps, and when should I expect to hear?" | It is a question about the process, and the answer lets you plan your own follow-up and your preparation for any further round |

## Prohibited claims

What this pack will not coach, and why.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars for managers or a team | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation, not words for you: the material says the appointment book, not other people's calendars. C1's slot stays inside how the book was kept |
| Processed supplier invoices | Inflated form of F5 | F5's quote at its own scope: "chased unpaid invoices." The limit is the pack's observation: the material says chasing, and does not say whose invoices they were. B1's slot stays inside the chasing |
| Prepared documents in Word for the business | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word." The limit is the pack's observation: the material says a self-rating and does not say which documents |
| Advanced Excel skills | Inflated form of F4 | F4's quote at its own scope: "okay with Excel." The limit is the pack's observation: the material says okay, and nothing wider |

## Sources

**Provided documents:** your message, which holds the invite text, your description of the ad's duties, and your background. No `tuesday-dossier.md` was present, and no interviewer profile, full ad text or recruiter guidance was given.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

**Searches sent** (the query, then what came back):

- `Brennock Facilities Ltd values` — refused
- `Brennock Facilities Ltd interview process administrative assistant` — refused
- `Brennock Facilities Ltd Ireland news` — refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | Every call was refused. It would have fed a values cheat sheet, section 10, and VAL questions; none is built, and no published value is quoted anywhere in this pack |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | Every call was refused. It would have checked loop structure; the loop here rests on your own words about one 30-minute video call with the office manager, with persona weights from the hiring-manager prior |
| 3. `Brennock Facilities Ltd Ireland news` | unavailable | Every call was refused. It would have fed CO questions on current strategy; there are none, so the banks hold no CO question |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; the interviewer read is absent |
| 5. representative `Administrative Assistant` JD | skipped | The duties you described fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The office manager's name → an interviewer read, persona weights adjusted from their public footprint, and a reverse question tied to their path
- The full ad text → F2 to F5 are built from your summary of the ad's four duties; the full wording could add duties and make more rows `[grounded]` on quoted lines
- Your answers to the answer slots, said once in your own words → F1, F2, F3, F4, F5 and F6 would take your stated evidence, and the matching banks would be rewritten to map your stories rather than ask for them
- The recruiter's prep email, if one exists → any focus areas or pre-declared task, which this pack would otherwise have to assume
- How long you have to prepare → a prioritised prep schedule sized to your time
- A deeper research pass: up to 6 more searches and 2 more fetches, several more minutes, and it needs search to be permitted → a strategy brief and recent context for CO questions, offered once
- A `tuesday-dossier.md`, if you ever build one → verified evidence and sharper constraints on which claims this pack may coach
