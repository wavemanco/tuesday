I've run five searches (values, hiring process, strategy, principal, a sample JD). Next I'll fetch the two official district pages, so the values wording and panel format come from the source.
Your prep pack is saved as `halvering-elementary_fourth-grade-teacher_interview_pack.md`. It has 21 questions across seven interviewer styles, a fit snapshot against your resume, reverse questions for the panel, and a list of claims it won't coach. I built it for the 45-minute panel the invite describes (Principal Vantongeren plus two fourth-grade teachers). I had no posting text and no notes from HR.

- **Social Security number:** I don't need it for any of this, so I haven't used or repeated it. I'd keep it out of anything you paste for job prep. I also left your licence number out of the pack and out of every search.
- **Panel format:** the district's hiring page describes one 45-minute panel covering reading instruction, classroom routines and families. It also says references are taken up after the panel.
- **Highest-ROI prep:** the likeliest objection is that you haven't taught fourth grade. Question B1 gets the deepest rehearsal: say plainly "I've never taught fourth grade", then hold on your six years of third grade and offer a plan. Don't suggest the two grades are alike.
- **Team lead:** your resume says you led your grade level's move to a new reading curriculum, and you've never been a team lead. The pack keeps those two statements separate.
- **District reading plan:** the board's August 2026 plan brings a new grades 3–5 reading curriculum from fall 2027. Your curriculum-move experience is relevant, and question C1 and reverse question R4 build on it.
- **Answer slots:** where your material is silent (how you teach reading day to day, classroom routines, using assessments), the pack gives no story. It gives an instruction to answer in your own words, or to say plainly that you didn't do it.

Say the word and I'll play the Skeptic on B1 as a live drill.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full posting, if you have it? Several rows are built from a typical fourth-grade listing and would be rebuilt from the real requirements.
2. Did HR mention any focus areas, or ask you to prepare something like a sample lesson? A requested deliverable would get its own section.
3. Is "Thursday" this week (Nov 26) or next? That sets how much prep time to plan around.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: halvering-elementary_fourth-grade-teacher_interview_pack.md -----
# Interview prep pack: Fourth Grade Teacher, Halvering Elementary School

- **Role:** Fourth Grade Teacher, Halvering Elementary School (Orrinsford Community School District)
- **Round:** one 45-minute panel, on a Thursday
- **Panel:** Principal Dolores Vantongeren and two members of the fourth-grade team (their names were not given)
- **Built on:** the invite and your resume text, with no posting text and no notes from HR

## How to use this pack

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you did.

| Tag | Name | What it is really testing |
|---|---|---|
| VAL | Behavioral / values alignment | Whether past behavior shows the district's published beliefs |
| EXP | Work-experience deep-dive | Whether your resume lines hold up, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy knowledge | Whether you know the district's current direction |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the actual role |

An **answer slot** is an instruction for the interview, not a question for you now. It gives two honest branches: say what you did in your own words, or say plainly that there was no such step or it was not yours, then return to a sentence you did write. Labels: `[grounded]` rests on your words or on a source in section 14; `[inferred]` is derived, with the derivation named; `[generic]` is a role-family pattern with no claim about you or the district.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Candidates must hold a valid Illinois Professional Educator License with an elementary endorsement." — the invite | "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" — your CV | medium | [grounded] | none | A gate your material shows met, so it routes by its evidence. Nothing here has been inspected by this pack. The licence number is yours to check against the public record, and the pack does not use it. As you wrote it, the endorsement spans grades 1–6, which includes fourth grade. Say it in the quote's own terms: kind, endorsement and expiry |
| F2 | "reading instruction" — the district's hiring page, which says "Panels ask about reading instruction, classroom routines and how you work with families." | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've run the after-school reading club for the last two years" — your CV | medium | [grounded] | discovery | The quotes say a curriculum move and a club. They do not say how you teach reading day to day, so the words stay at those scopes: "I led our grade level's move to a new reading curriculum in 2024." Answer slot: the panel is documented to ask about reading instruction, so expect a probe on your own reading teaching. If you can say what it looked like in your room, say so in your own words; if there was no such routine of your own, or the move or the club is the better answer, say so plainly and stay with those |
| F3 | "classroom routines" — the district's hiring page | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if any routine from your own classroom is worth describing, say what it was in your own words; if there was none to describe, say so plainly and describe how you would set routines in a new room, as a plan and never as a past |
| F4 | "how you work with families" — the district's hiring page | "I write a weekly email to families" — your CV | medium | [grounded] | none | No gap, but a resume line with nothing inspected behind it, so expect a probe on it. Lead with it in the quote's own terms: you write it, weekly, to families |
| F5 | "each teacher speaks with every family each term" — the district's published belief, Families Are Partners | "I write a weekly email to families" — your CV | medium | [grounded] | discovery | Your material says a written email, not speaking with each family each term. Answer slot: if you also spoke with families beyond the email, say how and when, in your own words; if the email was the channel, or there were no such conversations, say so plainly and stay with the weekly email |
| F6 | "assessments inform teaching and never replace it" — the district's published belief, Teach for Tomorrow, Not for the Test; "differentiate instruction using assessment data" — a representative listing's search snippet | none given | none | [inferred] | discovery | Your material does not show this. Answer slot: if what an assessment showed ever changed what you taught, say what, in your own words; if it did not, or that was not yours to decide, say so plainly and say how you would want assessment to inform your teaching, as a plan |
| F7 | "work with the grade-level team" — a representative listing's search snippet | "I led our grade level's move to a new reading curriculum in 2024" — your CV; "I've never been a team lead" — your message | medium | [inferred] | transferability | Your words are the move at its own scope and the limit you stated: "I led our grade level's move to a new reading curriculum in 2024" and "I've never been a team lead." The move is not a team-lead role, and the pack does not blur them. Any step wider is an answer slot inside the move: what part was yours to set, in your own words; if others set it, say so plainly |
| F8 | "Fourth Grade Teacher" — the invite | "Six years teaching third grade at a public elementary school in Joliet" — your CV; "I've never taught fourth grade" — your message | medium | [grounded] | transferability | Words you can say: "I've never taught fourth grade." Then: "For six years I taught third grade at a public elementary school in Joliet." The pack makes no claim that the two grades are alike. Answer slot: if any of your work touched fourth-grade students or content, say what, in your own words; if none did, say so plainly and give a plan for learning it, as a plan and never as a past |
| F9 | "plan and teach reading, writing, math, science and social studies" — a representative listing's search snippet | "Six years teaching third grade at a public elementary school in Joliet" — your CV | medium | [inferred] | discovery | The quote does not say which subjects you taught. Answer slot: say which subjects you taught, in your own words; if some were taught by others or not by you, say so plainly and return to what you did teach |

## Reading the interviewer

Only the principal has public information. The two team members are unnamed, so nothing is assumed about them.

| Item | What the public footprint shows | What it means for you | Provenance |
|---|---|---|---|
| Career path | Principal of Halvering Elementary School since 2022, after nine years as a reading specialist | Reading questions from her will likely be precise. Answer in what you actually did, not in reading-specialist vocabulary | [grounded] |
| Talk | A 2025 forum talk, Small Groups, Big Readers, on weekly reading conferences in grades 3 to 5 | Expect depth on reading instruction (F2). Read the talk or its summary yourself before citing it; the pack holds only a one-line summary. Do not describe your own teaching in her talk's terms unless that is what you did | [grounded] |
| Mirror opportunity | Reading is her professional domain | Your own sentences are the bridge, at their own scope: "I've run the after-school reading club for the last two years" and "I led our grade level's move to a new reading curriculum in 2024" (F2). They are not a shared career jump, and the pack does not offer one | [grounded] |

## Persona table

| Persona | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Two grade-level teachers asking what you would need from them, how you split work and credit, and how you handle disagreement | High. The hiring page and the invite put two teachers on the panel, and the peer relationship leads to this persona. Four questions | Reciprocity: say what you would bring the team, in sentences you did write. Offer principles for the seam, not a pretended knowledge of it |
| Skeptic | The title says fourth grade and your material says third. Expect "why this move" and "what would you be weakest at" | High. The principal's relationship leads to Skeptic and Case, and F8 is the gap the panel can see from the title. Four questions, with the deepest rehearsal on B1 | Rehearse the one objection until it is boring: concede the stated limit, hold on what the quotes carry, offer a plan, never a past |
| Case / Strategist | Live problems from the district's reading plan, which brings a new grades 3–5 reading curriculum from fall 2027 | Medium. The principal leads this one, and the research found a current plan to build cases on. Three questions | Clarify first, then objective, approach, how you would tell it works, risks. Think aloud |
| Values / Behavioral | Scenarios drawn from the three published beliefs | Medium. The hiring page names no values round, but the mission page says three beliefs guide every hire, so they will theme questions. Three questions | Where one of your sentences carries a story, map it. Where none does, use the selection scaffold and its honest branch |
| Conversational / Rapport Builder | The opener, the licence confirmation, and a casual question about reading | Medium. Panels usually open this way, and the casual questions are still scored. Three questions | A 90-second arc built only from your quotes, then your own reasons for the move |
| Data-Driven Prober | Reading both resume lines closely: the club and the weekly email | Low. No headline figure on the resume gives it a target. Two questions | Know what you can and cannot say about each line, and say plainly where you do not know |
| Pressure / Stress | A time-boxed "why you" and a challenge on attribution | Low. Nothing in the sources suggests a stress format, but F7 and F8 are where it would land. Two questions | Pause, restate, hold the position through two follow-ups, concede only what is true |

## Question banks

### A. Peer Evaluator (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Fourth-grade teams plan together. Tell me about a time you disagreed with a grade-level colleague and how it ended." | JD | [inferred] "I led our grade level's move to a new reading curriculum in 2024" | Selection scaffold: pick a time you disagreed with a grade-level colleague. It needs the disagreement stated plainly, what you said, and how the working relationship stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the move as you wrote it, at that scope, or how you would handle a disagreement on a team. Say "we" for context and "I" for your own part | F7 is the evidence for the team requirement and carries no disagreement, so this is a scaffold, not a story map. JD because it scores the working-with-the-team line; the open prompt follows the Peer Evaluator's disagreement stem |
| A2 | "What would you need from us in your first month, and what could you offer a team that is new to you?" | JD | [grounded] "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Two halves. What you need is yours to say in your own words; the pack does not supply it. What you offer stays at your quotes' scope: "For the last two years I've run the after-school reading club" and "I write a weekly email to families." Offer principles for how you would fit the team's routines, not claims about how the team works, which you do not yet know | F7 and F4 are the evidence the offer draws on. JD because it scores team fit; the question follows the Peer Evaluator's "what would you need from me" stem |
| A3 | "The district's plan puts a family reading night at every school each term. How would you work with the other fourth-grade teachers to make it work for families?" | CO | [grounded] "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A plan, so make no claim about a past event. Say what you would ask first, such as who runs it now and what families have said, then what you would offer from sentences you did write, then how you would split the work with the team, then how you would tell families came. Keep your offer at the quotes' scope | F4 and F2 are the evidence for the offer. CO because the question rests on the district's current literacy plan, with CASE delivery since it asks for a plan |
| A4 | "How do you share credit when a result comes from the whole grade level?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Say "we" for the context and "I" for your contribution. The move is the example only at its own scope. Answer slot: say what part of it was yours and what part was shared, in your own words; if you cannot separate them, say that plainly | F7 is the evidence and the attribution probe's target. EXP because it tests what was actually yours; it follows the Peer Evaluator's credit stem |

### B. Skeptic (weight: high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "I don't see fourth grade in your background yet. How would you handle that in this role?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet" | **The highest-ROI prep in this pack: this question will come in some form.** Open with the concession: "I've never taught fourth grade." Then hold on what the quote carries: "For six years I taught third grade at a public elementary school in Joliet." Do not say the two grades are alike. Then a plan, said as a plan: what you would look at first and whom you would ask, in your own words. Follow-up one, on the area you would be weakest in on day one: answer slot. Name one area in your own words; if you do not yet know, say so plainly and say how you would find out. Follow-up two, on why the panel should take the risk: hold by returning to the sentences you have, never by adding to them, and concede that a candidate who has taught fourth grade has something you do not. The limit, as the pack's observation: your material says third grade and does not say how fourth differs | F8 is the one gap visible from the job title, so the Skeptic arrives here first. JD because it scores the role as titled; the stem follows the Skeptic's "I don't see X" form |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [inferred] derived from the Skeptic's stem and a representative listing's requirements | Answer slot: name the one area in your own words. The pack's observation is that your material shows nothing for F3 and F6, so an honest answer is most likely to come from there; if you choose another, say why. Then close it as a plan: the first step you would take. Name no weakness you do not believe you have | F3, F6 and F9 are the rows where the material is silent. JD because it scores the listed responsibilities, including where you are thin |
| B3 | "You taught third grade for six years. Why fourth grade, why Halvering, and why now?" | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years" | Three parts, each yours: why fourth, why here, why now. Your material gives none of the three reasons, so give your own in your own words; the pack supplies none. If one of them is the district's reading beliefs, say so only if it is true for you, and tie it to what you wrote: "I've run the after-school reading club for the last two years." Keep it under 90 seconds and consistent with E1 | F8 is the move being asked about. EXP because it tests motivation consistency against your history; this is the Skeptic's "why leave, why here, why now" |
| B4 | "Tell us about the curriculum move you led. What would you do differently now?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Story-mapped on the beats the quote states: you led, it was your grade level's move, it was to a new reading curriculum, in 2024. Answer slot: expect a probe on what "led" meant and how the move went. Say what you did and what part was yours, in your own words; if anything went differently than planned, say what and what you did about it; if nothing did, or the direction was set by others, say so plainly and return to the move as you wrote it | F7 and F2 carry this line, and it is the strongest sentence the panel will probe. EXP because it tests attribution; hindsight questions reward candor |

### C. Case / Strategist (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A new grades 3–5 reading curriculum arrives in fall 2027. Walk us through how you would approach your first two months with it." | CASE | [grounded] "I led our grade level's move to a new reading curriculum in 2024" | Think aloud: what you need to know first (what it asks of fourth grade, what the team has already agreed, what students bring from third grade), the objective, your approach, how you would tell it is working, the main risk. The pack knows only that a new curriculum is planned, so ask rather than assume its content. You may add one sentence at its own scope: "I led our grade level's move to a new reading curriculum in 2024", without saying it is the same job | F2 is the closest evidence. CASE with a CO base: the question comes from the board's August 2026 literacy plan in section 14 |
| C2 | "A student arrives in your fourth-grade room with no reading plan. What do you do in the first week?" | CASE | [inferred] derived from the published belief Every Child a Reader | Structure aloud: what you would ask first, who you would ask, what you would do in that week, and how you would tell it is working. The question needs no claim about your past, so the guidance makes none | F2 is the area it tests. CASE because it is a live problem; derived from the belief that no student leaves third grade without a reading plan |
| C3 | "Sketch a typical week in your fourth-grade room: reading instruction and the routines around it." | JD | [grounded] source: the district's hiring page topics | Structure it by day or by block, in your own design. Answer slot: if a routine from your own classroom carries over, say which, in your own words; if you would build it new, say so plainly and say why | F2 and F3 are the rows it covers. JD because the panel is documented to ask about both reading instruction and routines |

### D. Values / Behavioral (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Our belief is Every Child a Reader: no student leaves third grade without a reading plan. You taught third grade for six years. What would you want a fourth-grade teacher to do with that plan?" | VAL | [grounded] "Six years teaching third grade at a public elementary school in Joliet" | Answer as a view: what you would want a receiving teacher to do. Answer slot: if you wrote or used reading plans in third grade, say how, in your own words; if your school had none or they were not yours, say so plainly and say what you would want to receive | F8 is the evidence for the third-grade side. VAL because it maps to a published belief by name |
| D2 | "Families Are Partners: each teacher speaks with every family each term. Tell me about a time you worked closely with a family." | VAL | [grounded] "I write a weekly email to families" | Selection scaffold: pick a time that has a child's need (no names), what you and the family each did, and where it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry: "I write a weekly email to families." Answer slot: if you spoke with families beyond the email, say how and when, in your own words; if the email was the channel, say so plainly | F4 and F5 are the evidence. VAL because it maps to a published belief; the open prompt supplies no event |
| D3 | "Teach for Tomorrow, Not for the Test: assessments inform teaching and never replace it. When have you used what an assessment showed you to change what you taught?" | VAL | [grounded] source: the district's published belief | Selection scaffold: pick a time an assessment result changed a plan. It needs the result stated plainly, the change you made, and what you saw afterwards. If no such time comes to mind, say so plainly, then say how you would want assessment to inform your teaching, as a plan | F6 is the row, and your material shows nothing for it, so there is no story to map. VAL because it maps to a published belief |

### E. Conversational / Rapport Builder (weight: medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk us through your journey." | EXP | [grounded] "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | A 90-second arc from your own sentences: where you teach now and for how long ("Six years teaching third grade at a public elementary school in Joliet"), then two things you do, then where you are heading. Why you became a teacher is not in your material, so say it in your own words | F8, F2 and F4 supply the beats. EXP because it opens with your history; the Conversational stem |
| E2 | "Can you confirm your licensure and endorsement for us?" | JD | [grounded] "Illinois Professional Educator License (PEL), Elementary Education (grades 1–6) endorsement, registered and active through June 30, 2029" | Say it in the quote's own terms: the Illinois Professional Educator License, the elementary endorsement, the status and the expiry. Keep your own record of the licence number at hand in case it is asked for; the pack does not carry it. Say nothing about verification, which is theirs | F1 is the gate, shown met. JD because it scores the invite's stated requirement |
| E3 | "What are you reading, or teaching with, these days that you are excited about?" | JD | [grounded] "I've run the after-school reading club for the last two years" | Name something you actually use, in your own words. Do not borrow vocabulary from the principal's talk. If nothing comes to mind, say so plainly and say what you would like to explore. The club is the sentence you can stand on, at its own scope | F2 is the evidence. JD because the casual question is on the panel's documented topic of reading; the Conversational stem |

### F. Data-Driven Prober (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about the reading club you run after school." | EXP | [grounded] "I've run the after-school reading club for the last two years" | Story-mapped on the beats the quote states: after school, a reading club, you run it, the last two years. Answer slot: expect a probe on who the club is for and how you could tell it was working. If you tracked anything, say what, in your own words; if you did not, say so plainly and say what you noticed | F2 carries this line. EXP because it tests what you actually did |
| F2 | "Your weekly email to families: walk us through how it works." | EXP | [grounded] "I write a weekly email to families" | Story-mapped on the beats the quote states: you write it, it is weekly, it goes to families. Answer slot: if families respond or you change it, say how, in your own words; if it is one-way, say so plainly | F4 carries this line. EXP because probers read the resume line by line |

### G. Pressure / Stress (weight: low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "That curriculum move: how much of it was actually you?" | EXP | [grounded] "I led our grade level's move to a new reading curriculum in 2024"; "I've never been a team lead" | Pause, restate, then hold: "I led our grade level's move to a new reading curriculum in 2024." Hold through two follow-ups by returning to it, never by adding to it. The concession is the limit you stated: "I've never been a team lead," meaning the move was not a team-lead role. Answer slot: say what part was yours, in your own words; if others set the direction or part of it was not yours, say so plainly | F7 is the row, and attribution is where the pressure persona aims. EXP because it tests ownership; the Pressure stem |
| G2 | "Sixty seconds: why you over a candidate who has already taught fourth grade?" | JD | [grounded] "I've never taught fourth grade"; "Six years teaching third grade at a public elementary school in Joliet"; "I've run the after-school reading club for the last two years"; "I write a weekly email to families" | Three sentences. Concede first: "I've never taught fourth grade." Then hold on what you have, at each sentence's scope: six years teaching third grade, the club you run, the weekly email. Do not argue you are better. Hold through two follow-ups by returning to those sentences | F8 is the gap and the time-box is the Pressure format. JD because it scores the role as titled |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 licence | E2 |
| F2 reading instruction | B4, C1, C2, C3, E3, F1 |
| F3 classroom routines | C3 |
| F4 how you work with families | A2, A3, F2 |
| F5 speaks with every family each term | D2 |
| F6 assessments inform teaching | B2, D3 |
| F7 work with the grade-level team | A1, A2, A4, B4, G1 |
| F8 fourth grade | B1, B3, D1, E1, G2 |
| F9 plan and teach the subjects | B2 — none beyond it: the district's documented panel topics are reading, routines and families, so writing, math, science and social studies get no dedicated question |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "You were a reading specialist for nine years before becoming principal. How does that shape what you look for when students arrive in fourth grade?" | Ties to her public path, which shows you looked at her and not only the school |
| R2 | "Your talk on weekly reading conferences in grades 3 to 5 is public. What does that look like in a fourth-grade room at Halvering today?" | Ties to her published theme. Read the talk yourself first, and ask rather than claim any practice of your own |
| R3 | "What could a new person on the fourth-grade team do in their first month that would genuinely help you?" | Reciprocity for the two teachers: it asks what helps them, not what you need |
| R4 | "The board's plan brings a new grades 3–5 reading curriculum in fall 2027. What part does the fourth-grade team play in getting ready?" | Shows you read the district's current direction, and it turns the panel to your team's role |
| R5 | "What part do fourth-grade teachers usually play in the family reading night each term?" | Connects to the published belief about families and the plan's reading night |
| R6 | "References are taken up after the panel. What happens from here, and when?" | A real process question that leaves you knowing what follows; the hiring page names the references step |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has taught fourth grade, or is as ready as someone who has | Negative the candidate stated, F8 | The plain acknowledgment F8 gives: "I've never taught fourth grade." Then the third-grade sentence at its own scope |
| Has been a team lead | Negative the candidate stated, F7 | The plain acknowledgment F7 gives: "I've never been a team lead." The move stays "our grade level's move" |
| Led a school-wide or district-wide curriculum adoption | Inflated form of F7 and F2 | The quote at its own scope. The limit is the pack's observation: your material says your grade level's move, not a wider adoption. G1's slot stays inside the move |
| Speaks with every family each term | Inflated form of F4 and F5 | The quote at its own scope. The limit is the pack's observation: your material says a weekly email, not conversations. D2's slot asks only what else you did |

## Sources

Provided documents: the invite text, and the resume text you pasted. Nothing was fetched from a link you gave.

Research tier: L1 — searches 5 of 6, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Orrinsford Community School District values | yes | The mission page was fetched and gave the three beliefs by name, which theme D1 to D3 and F5, F6 |
| 2. Orrinsford Community School District interview process | yes | The hiring page was fetched. It describes one 45-minute building panel of the principal and two grade-level teachers, asking about reading instruction, classroom routines and families, so the loop is established and persona weights follow it. It names no values round |
| 3. Orrinsford Community School District strategy and recent news | yes | The board's August 2026 literacy plan: structured phonics from kindergarten to second grade, a new grades 3–5 reading curriculum from fall 2027, and a family reading night at every school each term. It moved C1, A3, R4 and R5 |
| 4. Interviewer: Dolores Vantongeren, Halvering Elementary School | yes | One result, read as a snippet and not fetched. It gave the principal's path and talk in the interviewer read and R1, R2. The two team members were not named, so nothing more was formed |
| 5. Representative fourth grade teacher posting | yes | No posting was supplied, so one search ran. Its snippet, not a fetched listing, supports F6, F7 and F9 as `[inferred]` and is typical for the role, not this team's practice |

| Query | Returned |
|---|---|
| Orrinsford Community School District mission values | https://orrinsfordschools.example/about/mission-and-beliefs |
| Orrinsford Community School District teacher interview process panel | https://orrinsfordschools.example/careers/how-we-hire-teachers |
| Orrinsford Community School District strategic plan news | https://orrinsfordschools.example/news/board-adopts-literacy-plan |
| Dolores Vantongeren Halvering Elementary School principal | https://ilprincipalsforum.example/speakers/dolores-vantongeren |
| fourth grade teacher job description Illinois elementary school | https://k12jobsboard.example/listings/fourth-grade-teacher |

Fetches: https://orrinsfordschools.example/about/mission-and-beliefs and https://orrinsfordschools.example/careers/how-we-hire-teachers

## Upgrade menu

- The posting text → F6, F7 and F9 become `[grounded]` where it says what they say, and any requirement this pack has not seen gets a question
- Any note from HR on focus areas, or a sample lesson or demo they asked for → coverage of that deliverable, which would get its own build section
- The two team members' names → persona weights per panelist and a reverse question tied to each one's path
- Your own answers to the answer slots, said outside a drill (what your reading teaching looked like, your routines, whether you spoke with families beyond the email, how assessment changed what you taught) → quoted into the snapshot, regenerating F2, F3, F5 and F6
- One copy of your weekly family email → the inspectable artifact for F4, which raises its confidence from medium
- Your licence's public record entry, once you have checked it yourself → F1 from medium
- A deeper research pass (up to 6 more searches and 2 more fetches, several more minutes) → the principal's talks in full and recent district context
- A `tuesday-dossier.md` from an earlier session → verified evidence and the objection worth deepest rehearsal, though this pack stands without one
