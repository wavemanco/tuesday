Searches were refused, so I'm building the pack from your message alone. I'm writing it to a file now.
Before the prep, one thing in the invite. It asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and says "you deposit the cheque and send the balance on to the vendor". A fee up front, a cheque you deposit and then pay on from, and passport and bank details before any offer are a known scam pattern. The fee, the cheque and the request for your passport and bank details are very likely a scam. Please don't pay, deposit the cheque or send your passport or bank details until you've checked the invite with the employer. Use contact details you find yourself on its own website or careers page, not the email, number or answers from whoever sent it. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you'd like the invite weighed properly, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-5/rooms/case-12-denied-a066270d/Brennock_remote-administrative-assistant_interview_pack.md`. I built it for a hiring-manager round, assuming the office manager would be your manager.

- **Expect:** a 30-minute video call. You'll probably get a friendly opener about your background. After that come scenario questions on the diary, travel, invoices and Word and Excel, plus probing of the gaps.
- **Your strongest ground:** "I ran the appointment book for four physios" and "I'm good with Word". Say them in those words and don't stretch them.
- **Your widest gaps:** travel booking, which you haven't mentioned at all, and invoice processing. You said you chased unpaid invoices, and the ad wants supplier invoices processed. The pack's highest-priority drill is A2, the invoice question.
- **Excel:** expect a probe. "Okay with Excel" said plainly is better than a bluff.
- **Research:** my web searches were refused, so nothing about the company is researched. The pack's company-knowledge question is generic. The Sources section lists the refused queries.

I can run a live Skeptic drill on A2, the highest-ROI question. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or turn the pack into a Word document. Just say which you want.

Two questions would reshape the pack:
1. Is the office manager your future manager, or a peer on the team? The answer reweights every question bank.
2. Can you paste the ad's full text? I'm going on your summary of it, and I can proceed without it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Brennock_remote-administrative-assistant_interview_pack.md -----
# Interview pack: Remote Administrative Assistant, Brennock Facilities Ltd

Interviewer: the office manager (no name given). Format: a 30-minute video call, as the invite states. Built on one assumption: the office manager would be your manager, so the weights below follow a hiring-manager round.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script, and each cell is meant to fit in 90 to 120 seconds.

| Type | Meaning |
|---|---|
| VAL | Whether past behaviour shows the company's published values |
| EXP | Whether your own account of your work survives follow-up |
| JD | Whether you can do the listed job, gaps included |
| CO | Whether you know the company |
| CASE | A live problem from the role, scored on structure |

An answer slot is an instruction for the interview, not a question for you now. Where one appears, answer from your own experience or say plainly that it wasn't yours.

## Fit snapshot

Requirements come from the ad as you described it to me, so they are your message's wording, not the ad's own text.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — the ad, as you described it | "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | A CV-style line with nothing inspected behind it. Lead with your own terms: "I ran the appointment book for four physios." Keep "appointment book" as your word and add nothing about how it was run |
| F2 | "booking travel" — the ad, as you described it | none given | none | [grounded] | discovery | Your material does not show any travel booking. Answer slot: if you have arranged travel for anyone, say who for and what you handled, in your own words; if you have not, say so plainly and stay with the appointment book |
| F3 | "preparing documents in Word and Excel" — the ad, as you described it | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | none | The quote already reaches the requirement, with its own limit on Excel. Say it exactly: "I'm good with Word, okay with Excel." Expect a probe on Excel, and keep the answer at that scope |
| F4 | "processing supplier invoices" — the ad, as you described it | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your material says chasing unpaid invoices, not processing supplier invoices, and does not say whose invoices they were. Answer slot: if any invoices you handled were ones the clinic had to pay or check, say what you did with them; if not, say so plainly and stay with the chasing |

## Persona table

| Persona | How it shows up | Likelihood, with the reasoning | Counter-strategy |
|---|---|---|---|
| The Skeptic | Quiet, persistent probing of the gaps: travel, invoice processing, Excel, why leave a clinic | High: a hiring-manager round buys capability and checks gaps, and F2 and F4 are your widest gaps | Rehearse the invoice question until it is boring; say the limit at the scope of your own words, then give a plan |
| The Case / Strategist | Live admin problems: a diary clash, a trip to arrange, a mismatched invoice | High: the ad lists four concrete tasks, and a 30-minute call has room for two or three scenarios | Clarify first, then structure, then answer; think aloud |
| The Conversational / Rapport Builder | Friendly opener about your background, then the same topics in a casual register | Medium-high: short video calls usually open this way, and casual questions are still scored | A 90-second arc from your own sentences; treat casual questions about Word and Excel as scored |
| The Data-Driven Prober | Line-by-line questions on what you did and how much was yours | Medium: you have two short, checkable claims, and a manager hiring for invoices may check them closely | Say what was yours using your own attribution, and say plainly what you do not know |

## Question banks

### A. The Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel" | Give the limit at its own scope: "I'm good with Word, okay with Excel." Answer slot: the ad lists booking travel and supplier invoices, so name the part you have done least, plainly. Then give a plan for learning it, said as a plan and not a past. If you have in fact done it, say what you did | F2 and F4 are the widest gaps, so this arrives in some form; JD because it scores the listed job |
| A2 | "You mention chasing unpaid invoices, and this role processes supplier invoices. What have you handled on the processing side?" | JD | [grounded] "chased unpaid invoices" | The highest-ROI prep in this pack. Hold what the quote carries: "chased unpaid invoices." Answer slot: if you have handled invoices coming in, say what you did with them; if the invoices you dealt with were only ones you chased, or none of it was processing, say so plainly and stay with the chasing. Hold through two follow-ups by returning to the chasing, never by adding to it | F4 is where the role presses hardest and the material is thinnest, so expect this in some form; JD because it scores the stated requirement |
| A3 | "Tell me about a time you arranged travel for someone." | JD | [grounded] "I ran the appointment book for four physios" | Selection scaffold: pick an occasion with a named person, constraints you had to fit and a result you can state. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I ran the appointment book for four physios", or say how you would go about it | F2 has no evidence, so this is a scaffold rather than a story map; the theme comes from the ad's own list |
| A4 | "The role involves Excel. How comfortable are you with it, honestly?" | JD | [grounded] "I'm good with Word, okay with Excel" | Say it at its scope: "okay with Excel." Answer slot: if there is something you have done in Excel, say what and how, in your own words; if you have used it only lightly, say so plainly. Then say what you would build up first, as a plan | F3 carries your own limit on Excel, and a manager hiring for invoice work will test it |
| A5 | "Why this role, and why move on from the clinic?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Give your actual reason in your own words, short and looking forward. If part of it is that the role is remote, say so only if it is true. This pack supplies no reason for you | A motivation-consistency probe sits in nearly every first round; EXP because it tests whether your story holds together |

### B. The Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two people ask for the same slot in the manager's calendar. What do you do?" | CASE | [grounded] "I ran the appointment book for four physios" | Structure: ask who has priority and what is flexible, check what else could move, offer alternatives, confirm in writing, record the outcome. Answer slot: if a clash like this came up in the appointment book, say how it went; if not, say so plainly and walk through how you would handle it | Covers the "managing calendars" line in F1 as a live decision |
| B2 | "The manager needs a three-day trip to a client next month, with two meetings. What do you ask first?" | CASE | [generic] | Clarify before structuring: dates and times, who travels, budget and any travel policy, preferences, who approves, meeting locations, and how the itinerary gets shared. The question needs no claim about your past, so the guidance makes none | F2 is your widest gap, and a good clarifying structure is the honest way to show readiness |
| B3 | "A supplier invoice arrives and does not match what was ordered. What do you do?" | CASE | [generic] | Structure: check it against the order, hold it rather than pay, query the supplier or the person who ordered, log the query, follow up and record the outcome. No claim about your past | Covers the "processing supplier invoices" line in F4 as a live decision |
| B4 | "How would you set up a simple Excel sheet to track supplier invoices due this month?" | CASE | [grounded] "I'm good with Word, okay with Excel" | Think aloud: ask what the manager needs to see, then what columns that implies, then how you would keep it current. Say which steps you would do from memory and which you would look up, consistent with "okay with Excel" | Joins F3 and F4 in one scenario, which is how a small office tests both at once |
| B5 | "It is 4pm, the manager's flight tomorrow is cancelled and there is a 9am meeting. Go." | CASE | [generic] | Clarify what matters most, which is the meeting or the outcome, then list options, pick one and confirm it back. Keep to the order: ask, options, decide, confirm. No claim about your past | A time-pressured case that combines calendars and travel, the two tasks the ad lists first |

### C. The Conversational / Rapport Builder

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices" | A 90-second arc whose beats are the three quoted sentences: two years as a receptionist at a physiotherapy clinic, running the appointment book for four physios, chasing unpaid invoices. Then your reason for this role, in your own words. Say each in your own words and add nothing the quotes do not state | The biography question opens most calls like this; EXP because it is where the CV claims first get stated aloud |
| C2 | "This is a remote role. How do you stay organised and in touch?" | JD | [generic] | Selection scaffold: pick the routines you actually use, such as how you plan your day, how you keep a task list and how you update people. If you have not worked remotely, say so plainly, then say how you would set up your day | The role title names remote work; a casual question that is still scored |
| C3 | "Tell me what you use Word for." | JD | [grounded] "I'm good with Word, okay with Excel" | Start from your own words: "I'm good with Word." Answer slot: name the kinds of documents you have made in it, if any; if your use has been light, say so plainly | F3 is the one requirement your own sentence already reaches, so make it concrete in your own terms |
| C4 | "What do you know about us?" | CO | [generic] | Say only what you have read yourself on pages you found for the company; name one specific thing and why it interested you. If you have read nothing yet, say so plainly rather than bluff, and ask what the company would want you to know | No research ran in this pack, so this stays generic; CO because it tests homework |

### D. The Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. Walk me through what that involved." | EXP | [grounded] "I ran the appointment book for four physios" | Beats the quote states: the appointment book, and four physios. Tell them in your own words. Answer slot: if you are asked whether it was four throughout the two years, answer from what you know, or say plainly that you do not. If any part of running the book was shared or set by someone else, say which; if not, say so and stay with the book | F1 is your best evidence, so it gets probed hardest on attribution; EXP because it tests what was yours |
| D2 | "Tell me about the unpaid invoices you chased." | EXP | [grounded] "chased unpaid invoices" | Say what you chased and from whom, in those words. Answer slot: if you followed a set routine, say what it was and whether it was yours or the clinic's; if there was no routine, say so plainly. Stay with the chasing | F4's quote is short, so any follow-up goes to detail; the guidance stays inside it |
| D3 | "How much of that was actually you?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices" | Use the attribution your own sentences carry: "I ran the appointment book for four physios", "chased unpaid invoices". For anything else the clinic did, say what was someone else's, plainly. Do not widen the claims to fit the question | The standard attribution probe; EXP because it checks whether your account holds up in a team |
| D4 | "When have you worked out how to do something new in Word or Excel on your own?" | EXP | [grounded] "I'm good with Word, okay with Excel" | Selection scaffold: pick a task you really learned, with a named problem, how you found out and the result. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, "I'm good with Word, okay with Excel", or say how you would go about learning it | Tests whether the Excel limit in F3 comes with an ability to learn |

### Requirement coverage

| Requirement | Questions |
|---|---|
| "managing calendars" | B1, B5, D1 |
| "booking travel" | A3, B2, B5 |
| "preparing documents in Word and Excel" | A4, B4, C3, D4 |
| "processing supplier invoices" | A2, B3, B4, D2 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which of calendars, travel, documents and invoices takes most of the week in this role?" | Shows you have read the ad's four tasks and want to prioritise |
| R2 | "Which tools does the team use for calendars and for invoices, and would I be trained on them?" | Raises the Excel and invoice learning plan as a practical point rather than a confession |
| R3 | "What would a good first month look like?" | Turns the interview towards the work and gives you something to aim at |
| R4 | "How does the team stay in touch day to day while working remotely?" | Follows up your answer on remote working and shows you think about it |
| R5 | "What are the next steps after this call, and is there another conversation?" | Lets you plan around the process and shows you are serious |
| R6 | "Who would I work with most day to day?" | Signals interest in the team and helps you picture the role |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Has processed supplier invoices | Inflated form of F4 | F4's quote at its own scope: "chased unpaid invoices." The limit is the pack's observation: your material says chasing, not processing. A2's slot stays inside the chasing |
| Strong or advanced Excel skills | Inflated form of F3 | F3's quote at its own scope: "okay with Excel." A4's slot asks only what you have done in it |
| Managed calendars at scale, or for senior staff | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." B1's slot stays inside the appointment book |

## Sources

Provided: your message, containing the invite, the ad as you described it, and your background. No tuesday-dossier.md was present.

Research tier: L1 — searches 3 of 6, fetches 0 of 2

Searches sent, all refused by the host before returning anything:

- "Brennock Facilities Ltd values": refused
- "Brennock Facilities Ltd interview process remote administrative assistant": refused
- "Brennock Facilities Ltd strategy news": refused

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. company values | unavailable | The search was refused. It would have moved the VAL themes; no values round is documented, so there is no cheat sheet |
| 2. interview process | unavailable | The search was refused. It would have moved persona weights; they rest on your invite's one 30-minute call with the office manager |
| 3. strategy and recent news | unavailable | The search was refused. It would have moved the CO bank; C4 is generic |
| 4. interviewer name and company | n/a | No name was given, so there was no query to form; there is no interviewer read |
| 5. representative role JD | skipped | The ad as you described it fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The ad's full text → F1 to F4 and the JD-tagged questions would quote the ad's own words instead of your description of it
- The interviewer's name → an interviewer read, persona weights from their public footprint, and a tailored reverse question
- Anything you read yourself on the company's own pages → C4 and the CO bank become grounded in what you found
- Your answers to the slots in F2 and F4 → those rows and A2, A3 and B2 would be rebuilt on what you actually did
- A tuesday-dossier.md → verified evidence and risks carried from an earlier check into this pack, never required
