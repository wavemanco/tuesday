Company research was refused, so I'm building the pack from what you've told me and labelling the company-specific parts as generic. Saving it now.
Before the prep, one thing in the invite: it says the hiring process is "carried out entirely on Telegram" and that "your offer and onboarding will be completed in this chat as well". The invite asks for no money or documents. The sign is that the whole process, interview, offer and onboarding, runs in one chat. A chat alone doesn't show who you're dealing with, and a hiring process run wholly by chat is a known scam pattern. Until you've checked, send no money, documents or bank details through it. To check, use contact details you find yourself on the company's own website or careers page, not the chat, and not any email or number the sender gives. The invite may not come from who it names. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you'd like the invite weighed properly, job-underwriter can check it as a separate request.

Your prep pack is saved as `Lumenvale-Software_customer-support-specialist_interview_pack.md`. I built it for a single text-chat round with the support team lead, assuming they'd be your future manager. The company searches were refused this session, so the company-specific parts are generic and labelled that way. The four requirements are matched to your own lines, and your Freshdesk line is kept at Freshdesk, not Zendesk. The biggest prep item is B1, the "you haven't worked for a software company" question. The pack builds it from your own words: a plain concession, what you've actually done, then a plan.

Say the word and I'll play the Skeptic on B1, then run its follow-ups B2 and B3. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Is the support team lead the person you'd report to, or a peer on the team? The answer reweights the banks. Can you paste the full text of the ad? I'll proceed without it, but your four listed requirements would become exact quotes.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Lumenvale-Software_customer-support-specialist_interview_pack.md -----
# Interview pack: Customer Support Specialist (remote), Lumenvale Software

**Interviewer:** the support team lead, name not given. Per the invite: "your interview will be a text chat here with our support team lead".
**Round assumed:** one text-chat session with someone who is probably your future manager. This is an assumption, so the persona weights are built on the hiring-manager pattern and the pack says where a different relationship would change them.
**Format note:** the whole interview will be written. Rehearse by typing your answers, not by saying them aloud.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it is really testing |
|---|---|
| VAL | Whether your past behaviour shows the values a company holds, not generic virtue |
| EXP | Whether the claims you make about your work survive follow-up questions |
| JD | Whether you can do the listed job, including the parts where your evidence is thin |
| CO | Whether you did your homework on the company |
| CASE | How you structure a live problem from the role |

An "answer slot" in a guidance cell is an instruction for the interview, not a question for you now. Fill it only with what is true. Both branches are fine, including "that was not mine" or "that did not happen".

## Fit snapshot

The requirements are the four items you listed from the ad. The evidence column holds your own sentences and nothing else.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "2+ years in customer support" — the ad, as you listed it in your message | "3 years as a customer service advisor at an energy supplier" — your message | medium | [grounded] | none | No gap, but a stated line with nothing inspected behind it, so expect a probe. Lead with it in the quote's own terms: three years as a customer service advisor at an energy supplier |
| F2 | "experience with Zendesk or a similar ticketing tool" — the ad, as you listed it in your message | "I use Freshdesk every day" — your message | medium | [inferred] | presentation | The ad's "or a similar ticketing tool" wording is what lets Freshdesk count, and that match is this pack's reading. Say it as you wrote it: "I use Freshdesk every day." Your material says Freshdesk, not Zendesk, and the words stay at Freshdesk |
| F3 | "clear written communication" — the ad, as you listed it in your message | "answering around 60 calls and emails a day" — your message | low | [inferred] | discovery | The quote shows emails answered, not how clear they were, and the ad's line makes a probe on your writing likely. Answer slot: if anything shows how your written replies were judged, say what it was, in your own words; if nothing does, say so plainly and stay with "answering around 60 calls and emails a day" |
| F4 | "confidence handling escalations" — the ad, as you listed it in your message | none given | none | [grounded] | discovery | Your material does not show escalation handling either way, and the ad's line makes a probe likely. Answer slot: if any contacts were escalated to you or by you, say what happened and what your part was, in your own words; if you did not handle escalations, or none came up, say so plainly and describe the contacts you did handle in your own words |
| F5 | Support for a software product. Plain prose, not from the ad as you listed it: the employer is a software company, and the listed requirements do not ask for software experience | "I've never worked for a software company" — your message | none | [grounded] | capability | A gap wording cannot close, and you have said so. Words: "I've never worked for a software company." Then how you would learn it, said as a plan and never as a past. Never a claim to software-support work, and nothing added to make the gap feel smaller |
| F6 | Helping new colleagues get up to speed. Plain prose, a role-family pattern, not from the ad as you listed it | "I trained four new starters on our refunds process last year" — your message | medium | [generic] | none | No gap against a pattern, but a stated line with nothing inspected behind it. Lead with it in the quote's own terms: last year you trained four new starters on your refunds process. The quote does not say how the training went or whether it was formal, and the words stay there |

## Persona table

The weights below show their reasoning so you can correct them if you know something this pack does not. Peer Evaluator is not weighted because nothing says the lead is a peer; if they turn out to be one, that bank is the one to add.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist (bank A) | Live ticket scenarios: an angry customer, two urgent contacts, a feature you have not used | High. The hiring-manager pattern weights this persona, and a typed chat makes a scenario easy to run live. The ad's escalations and written-communication lines (F3, F4) are the natural scenario material | Clarify first, then structure, then write the reply. Challenge one premise politely per case. Type each rehearsal answer out |
| Skeptic (bank B) | Quiet, persistent probing of the software gap, the missing escalation evidence and why this move | High. The hiring-manager pattern weights it, F5 is a gap you stated yourself, and F4 is silent | Rehearse B1 until it is boring. Bridges are built only from your own quoted lines: the plain acknowledgment, the nearest quote, then a plan said as a plan |
| Data-Driven Prober (bank D) | Line-by-line probing of "around 60 calls and emails a day", "four new starters" and the daily Freshdesk use | Medium. Your material holds two figures and one named tool, which are the things a prober reads closely. Nothing says this lead is data-driven | Know what you can and cannot say about how each figure was counted, and say plainly when you do not know |
| Conversational / Rapport Builder (bank C) | An open "tell me about yourself" and friendly questions that are still scored | Medium. Interviews often open this way, and a chat opening has no cue to treat it as unscored | A 90-second arc built only from your own quoted lines. Treat casual questions about the company as scored |
| Pressure (bank E) | Time-boxed, devil's-advocate questions | Low. Nothing in the material signals a stress interviewer | Pause, restate, anchor in what you said, and hold your position through two follow-ups before conceding anything real |
| Values / Behavioral (bank V) | "Tell me about a time" questions on customer-first judgment | Low. No published values were in hand, because research was refused, and the invite names one session with no values round | Choose stories where the hard truth landed; if none comes to mind, say so plainly |

**Highest-ROI prep in this pack: B1, then its follow-ups B2 and B3, then E1.** The question "you have not worked for a software company" will be asked in some form, and a calm, rehearsed answer changes the interview.

## Question banks

Question IDs run by persona. Provenance carries every sentence the guidance rests on.

### Bank A: Case / Strategist (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A customer writes in for the third time about the same unresolved problem and asks for a manager. What do you write next?" | JD | [generic] | Ask first what the team's escalation route is, since you cannot know it. Then structure the reply: acknowledge the third contact without excuses, show you read the problem by restating it in one line, say what you will do and when they will hear back, say who else you are bringing in and why, and say what you will record on the ticket. Type it out in under 120 seconds | F4 is the ad's escalation line, and a scenario is how a hiring lead tests it when nothing in your material shows it. JD content, CASE delivery |
| A2 | "Write me your first reply to a customer whose refund has not arrived and whose ticket shows nothing for six days." | JD | [generic] | Rehearse this one typed, because the chat itself is a writing sample. Lead with the answer or the ownership, give one next step with a time, use plain words, and keep each message short. Name the delay without excuses and say what you will check. Do not invent a policy: say what you would look up | F3 is the ad's written-communication line, and in a text interview the writing is scored as it appears. JD content, CASE delivery |
| A3 | "Two customers write in at once: one with a billing question, one who cannot log in at all. Who do you answer first, and what do you tell the other?" | CASE | [generic] | Clarify first: what is each customer blocked on, and does the team have priority rules. If you do not know the rules, say your reasoning aloud, such as the customer who is fully blocked going first. Tell the other customer when you will be back and keep to it | A live problem from the support role itself, asked as a decision. It presupposes nothing about your past, so the guidance makes no claim about it |
| A4 | "Which ticketing tools have you used, and how quickly could you pick up ours?" | JD | [grounded] "I use Freshdesk every day" | Say it as you wrote it: "I use Freshdesk every day." Answer slot: if the interviewer asks what you do in it, say which parts you actually use, in your own words, and if you use only some parts, say so plainly. If asked about other tools, say plainly which you have used yourself, and if Freshdesk is the only one, say so. Then give a plan for learning theirs, said as a plan | F2 is the ad's ticketing-tool line, and the question is the one a lead asks when the named tool differs from yours |
| A5 | "A customer says a feature does not work the way our help page says, and you have never used that feature. What do you do?" | CASE | [generic] | Clarify what the customer is trying to do and what they see. Check what the team already documents. Ask a colleague rather than guess. Tell the customer honestly when they will hear back, and record what you learned on the ticket. The answer shows how you handle a product you do not know yet | Tests F5 through a scenario instead of an admission, so you can show method without claiming software experience |

### Bank B: Skeptic (high)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have not worked for a software company before. Which part of this job would be hardest on day one?" | JD | [grounded] "I've never worked for a software company" | The highest-ROI rehearsal in this pack. Concede plainly and once: "I've never worked for a software company." Then hold on what your own lines carry, at their own scope: "3 years as a customer service advisor at an energy supplier" and "I use Freshdesk every day". Then say the hardest part you honestly expect, in your own words, and how you would learn it as a plan: for example using the product yourself, reading the help material the team already has, and asking which questions come in most. Pick only what you would really do. Hold through two follow-ups by returning to those lines, never by adding to them | F5 is a gap you stated yourself and the likeliest place to be pressed. JD because it scores the listed job, Skeptic because it tests how the answer survives follow-up |
| B2 | "What do you think is different about supporting a software product from what you have done?" | EXP | [grounded] "3 years as a customer service advisor at an energy supplier" | First follow-up to B1. Answer slot: name the difference you actually see, in your own words; if you do not know what supporting software involves, say so plainly and say what you would ask the team to find out. Do not describe software support as you imagine it | F5 again, one level deeper. EXP because it tests whether your picture of the new work is honest |
| B3 | "Why software support, and why now?" | EXP | [generic] | Your material gives no reason for the move, so this pack supplies none. Say your actual reason in your own words, in two sentences, and end on what you want to do in this role. If you are still working out the reason, say that plainly rather than reaching for a polished one | A motivation probe that follows any career change, and the second follow-up to B1. Generic because it carries no claim about your past |
| B4 | "You spent three years as a customer service advisor at an energy supplier. What did a normal day look like?" | JD | [grounded] "3 years as a customer service advisor at an energy supplier"; "answering around 60 calls and emails a day" | Tell it in those terms: the three years, the role, and "answering around 60 calls and emails a day". Add nothing the lines do not say. Answer slot: if asked what the contacts were about, say what you actually handled, in your own words | F1 is the ad's years requirement, and the question checks that the years were real support work. JD content, EXP delivery |
| B5 | "Tell me about a time a customer's problem was escalated, either by you or to you." | EXP | [inferred] "3 years as a customer service advisor at an energy supplier" | Pick a time with a named situation, what you did, and how it ended. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, which is the three years in the quote, or say how you would handle one | F4 is the ad's escalation line and your material is silent on it, so the honest branch is rehearsed ahead of the probe. Inferred because the theme comes from the ad's line |

### Bank C: Conversational (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through your journey so far." | EXP | [grounded] "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | A 90-second arc with three beats, each only what its line says: the three years at an energy supplier, using Freshdesk every day, and training four new starters on your refunds process last year. End on why this role, in your own words, because your material gives no reason | The biography question is scored even when it feels casual. F1, F2 and F6 are the lines to build the arc from |
| C2 | "What drew you to Lumenvale?" | CO | [generic] | Nothing in your material or this pack's research establishes what Lumenvale makes or who its customers are, so the pack supplies none. Before the chat, read what the company itself publishes on its own site and bring one thing you actually read. If you did not get to it, say so plainly and say what you want to learn | Research was refused this session, so this stays generic. A company question in a friendly register is still scored |
| C3 | "Tell me about training the four new starters on the refunds process." | EXP | [grounded] "I trained four new starters on our refunds process last year" | Story-mapped only on what the sentence states: last year, four new starters, your refunds process, and that you trained them. Tell those beats in your own words and stop there | F6 is the only line in your material about helping colleagues. It carries no further beats, so the guidance adds none |

### Bank D: Data-Driven Prober (medium)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You said around 60 calls and emails a day. How was that counted?" | EXP | [grounded] "answering around 60 calls and emails a day" | Keep the figure at its own scope: around, calls and emails together, a day. Answer slot: say how the figure was counted, whether from a system report or your own estimate; if you do not know how it was counted, say so plainly. Name, in your own words, the assumption behind it you would defend least; if none comes to mind, say that. Say which part of the figure was your own work and which was the team's | F3 holds the only headline figure in your material, and probers go to figures first |
| D2 | "How do you use Freshdesk in a normal day?" | EXP | [grounded] "I use Freshdesk every day" | Answer slot: say the parts of it you actually use, in your own words, and no more. If you use only some parts, say so plainly. Do not name features you do not use | F2 is a tool claim with nothing inspected behind it, so the probe is on depth. Your line says daily use and nothing more, so the guidance supplies no features |
| D3 | "What share of your day was calls and what share email?" | EXP | [grounded] "answering around 60 calls and emails a day" | Answer slot: say the split only if you know it, in your own words. If you do not know it, say so plainly and stay with "answering around 60 calls and emails a day". Never round it into a cleaner number | F3 combines two channels into one figure, and the ad's written-communication line makes the email share the part that matters |

### Bank E: Pressure (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who already works in software support?" | EXP | [grounded] "I've never worked for a software company"; "3 years as a customer service advisor at an energy supplier"; "I use Freshdesk every day"; "I trained four new starters on our refunds process last year" | Hold-then-concede. Pause, restate the question, then hold on your own lines at their own scope: three years as a customer service advisor at an energy supplier, using Freshdesk every day, and training four new starters on your refunds process last year. Concede specifically and once: "I've never worked for a software company." Hold through two follow-ups by returning to those lines, never by adding to them and never by folding on them | The pressure version of B1, taken from the stem about an internal candidate. F5 is where it presses |
| E2 | "That training: how much of it was actually you?" | EXP | [grounded] "I trained four new starters on our refunds process last year" | Hold: "I trained four new starters on our refunds process last year." Answer slot: if part of it was shared, say plainly which part was yours and which was not; if all of it was yours, say so and add nothing. Do not explain how it was run | "Four" is a figure, so the which-part-was-yours probe applies to F6. The guidance holds only what the sentence carries |

### Bank V: Values / Behavioral (low)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a time with a named stake, a choice you made, and what happened. If no such time comes to mind, say so plainly, then say how you would handle one. Do not build the story to fit the question | A common behavioural stem for support roles. Generic because no published values were in hand and your material carries no such story |
| V2 | "Tell me about a time you had to deliver an unpopular truth to someone more senior." | VAL | [generic] | Pick a time with a named stake, a moment you did not fold, and a relationship that was intact at the end. If no such time comes to mind, say so plainly, then say how you would handle one | A persona stem for values rounds. Included at low weight so the style is not new on the day |

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 "2+ years in customer support" | B4, C1, E1 |
| F2 "experience with Zendesk or a similar ticketing tool" | A4, D2 |
| F3 "clear written communication" | A2, D1, D3 |
| F4 "confidence handling escalations" | A1, A3, B5 |
| F5 software-product support | B1, B2, B3, A5, E1 |
| F6 helping new colleagues get up to speed | C3, E2 |
| Company knowledge | C2 only, generic, none from research — none beyond it, because research was refused |
| Published values | V1, V2 from persona stems only — none from the company, because no values page was in hand |

## Reverse questions

Your closing questions are scored, so do not answer "I think you've covered everything".

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a normal day look like on the support team, and which tools does the team use?" | Lets you place your Freshdesk line (F2) against their set-up instead of guessing |
| R2 | "What would a good first month look like for someone new to supporting a software product?" | Turns F5 from a gap into a plan the lead describes in their own terms |
| R3 | "How does the team handle escalations: who picks them up and how are they handed over?" | Ties to F4, and shows you think about handovers before you are asked to do one |
| R4 | "How do new starters get trained on the product?" | Connects to F6, so you can talk about training from the side you have seen |
| R5 | "Which kinds of contact come in most, and how are they split between chat, email and calls?" | Shows how much of your daily mix (F1, F3) maps to theirs |
| R6 | "What does the rest of the process look like after this chat, and who would I speak to next?" | A practical question that tells you what to prepare for next |

## Prohibited claims

What this pack will not coach, and why. Present in every pack, including when nothing was refused.

| Not coached | Basis | Honest form |
|---|---|---|
| Experience with Zendesk | Inflated form of F2 | F2's quote at its own scope: "I use Freshdesk every day." The limit is this pack's observation: your material says Freshdesk, not Zendesk. A4's slot stays with the tool you use daily |
| Has worked in software or tech support | Negative you stated, F5 | The plain acknowledgment F5 gives: "I've never worked for a software company." No slot |
| Ran or designed the refunds training | Inflated form of F6 | F6's quote at its own scope: "I trained four new starters on our refunds process last year." The limit is this pack's observation: the material says you trained four people on one process, not that you built the training. C3 asks only for the beats the sentence states |
| Answered about 60 emails a day | Inflated form of F3: the figure moved to one noun | F3's quote at its own scope: "answering around 60 calls and emails a day". The limit is this pack's observation: the quote combines calls and emails and says around |
| Answering this many contacts proves clear writing | Inflated form of F3 | The same quote at its own scope. The limit is this pack's observation: the quote shows volume, not clarity. F3's slot asks only how your replies were judged |

## Sources

Provided documents: the invite text you pasted, and your message with the ad's requirements as you listed them and your background. No `tuesday-dossier.md` was present.

Searches sent, all three refused by the host, so nothing returned:

- "Lumenvale Software company values" — refused
- "Lumenvale Software interview process customer support specialist" — refused
- "Lumenvale Software news strategy" — refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Lumenvale Software values` | unavailable | The call was refused. It would have fed a values cheat sheet and the VAL bank with the company's own value names |
| 2. `Lumenvale Software interview process customer support specialist` | unavailable | The call was refused. It would have checked the loop and moved the persona weights; the weights rest on the invite's own words and the hiring-manager pattern instead |
| 3. `Lumenvale Software strategy` / recent news | unavailable | The call was refused. It would have grounded the CO and CASE banks in current company context, which are generic here |
| 4. `{interviewer name} Lumenvale Software` | n/a | The interviewer is described only as the support team lead, with no name, so there was no query to form. The interviewer read is absent |
| 5. representative `Customer Support Specialist` JD | skipped | The ad requirements you listed already fix the fit snapshot and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → F1 to F4 become verbatim quotes, and any requirement beyond the four you listed gets a JD-tagged question
- Anything the recruiter said about focus areas or format, such as scenario questions → coverage stops resting on round-type priors
- Your own answers to the slots (how the 60 was counted, any escalations you handled, how your written replies were judged) → F3 and F4 become story-mapped rows instead of answer slots
- The relationship to the interviewer, whether they would be your manager or a peer → persona weights are recomputed
- The company's published values and its own account of its product, pasted in → a values cheat sheet and a company-grounded CO bank, replacing the generic C2
- Search permission → the three refused targets, plus one deeper pass offered once: up to 6 more searches and 2 more fetches, several more minutes
- How much prep time you have → a triage schedule of the few things to do first
- `tuesday-dossier.md` from an earlier evaluation → verified evidence and a prepared objection list, so the pack does not infer them
