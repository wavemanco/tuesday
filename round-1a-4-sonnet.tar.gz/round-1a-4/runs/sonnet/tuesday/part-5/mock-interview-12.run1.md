Before the prep, one thing in the invite: it asks you to "transfer the €95 equipment registration fee to our supplier's account, IBAN ...", to "reply with a photo of your passport and your bank details before the interview", and says successful candidates get a cheque for €1,850 where "you deposit the cheque and send the balance on to the vendor". A fee before an interview, passport and bank details before any offer, and a cheque you deposit and then send money from are a known scam pattern. These requests, and the invite as a whole, are very likely a scam. Hold all three (paying, depositing the cheque, and sending your passport or bank details) until you've checked the invite with the employer. Use contact details you find yourself on its own website or careers page, not the email address, number or answers in the invite. My prep needs neither your passport nor your bank details. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call. If you want the invite's requests weighed, job-underwriter can check it as a separate request.

Your prep pack is saved as `/var/tmp/tuesday-measure/1a4/runs/sonnet/tuesday/part-5/rooms/case-12-denied-a4f302db/brennock-facilities_remote-administrative-assistant_interview_pack.md`.

I built it for one 30-minute video call, assuming the office manager is the person you'd work for day to day. It has 18 practice questions, a fit table of the ad's four duties against what you told me, six questions for you to ask them, and a list of claims not to make. The strongest prep is question B1. You chased unpaid invoices, and the job is processing supplier invoices, so expect them to probe that gap. Say your own words, say the limit plainly, then give a plan for getting up to speed.

The company searches were refused in this session, so the pack has no company facts. It rests only on what you gave me.

Say the word and I'll play the sceptical interviewer on B1 as a live drill. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, or convert the pack to Word.

Two questions would restructure it:
- Is the office manager your future manager or a colleague? The answer reweights every question bank.
- Can you paste the ad's full text and add any detail on travel you've arranged, what you've used Word or Excel for, or what you did with invoices beyond chasing? That would turn the answer slots into proper stories.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: brennock-facilities_remote-administrative-assistant_interview_pack.md -----
# Interview prep pack: Remote Administrative Assistant, Brennock Facilities Ltd

- **Role:** Remote Administrative Assistant
- **Company:** Brennock Facilities Ltd
- **Round:** one 30-minute video call with the office manager (name not given)
- **Relationship, assumed:** the office manager is the person you would work for day to day, so the pack is weighted like a hiring-manager round

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and say only what you actually did.

| Type | What it tests |
|---|---|
| VAL | Whether past behaviour shows how you deal with people and situations |
| EXP | Whether what you say about your experience holds up under follow-up |
| JD | Whether you can do the listed duties, gaps included |
| CO | What you know about the company and its recent moves |
| CASE | How you structure a live problem from the job |

There are no CO questions in this pack, because no company research was available (see Sources).

Answer slots in the guidance are instructions for the interview, not questions for you. Each gives two honest branches: say what you did in your own words, or say plainly that it was not yours or did not happen.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "managing calendars" — your message, the ad's duties as you listed them | "two years as a receptionist at a physiotherapy clinic" — your message; "I ran the appointment book for four physios" — your message | medium | [grounded] | presentation | Your quote already reaches the requirement in other terms, so the words stay in the quote's terms: "I ran the appointment book for four physios." Say it that way and let the interviewer make the link to calendars. Your material gives an appointment book for four physios with nothing inspected behind it, so expect a probe on it and keep to what the sentence carries |
| F2 | "booking travel" — your message, the ad's duties as you listed them | none given | none | [grounded] | discovery | Your material does not speak to this, and the pack does not fill the gap. Answer slot: the ad's travel line makes a probe on travel you have arranged likely. If you have arranged travel for anyone, say what and for whom, in your own words; if you have not, say so plainly and say how you would go about it, in A2's order of questions |
| F3 | "preparing documents in Word and Excel" — your message, the ad's duties as you listed them | "I'm good with Word, okay with Excel" — your message | medium | [grounded] | discovery | Your quote is a rating of your skill and the words stay at that rating: "I'm good with Word, okay with Excel." Answer slot: the ad's Word-and-Excel line makes a probe on what you have used them for likely. If you have used either for work you can describe, say what, in your own words; if not, say so plainly and stay with your own rating |
| F4 | "processing supplier invoices" — your message, the ad's duties as you listed them | "chased unpaid invoices" — your message | medium | [grounded] | transferability | Your quote is adjacent work and the words stay at its scope: "I chased unpaid invoices." Your material says chasing, and does not show whose invoices they were or what else you did with invoices. Answer slot: the ad's supplier-invoice line makes a probe on your invoice work likely. If any of it went beyond chasing, say what it was and what part was yours, in your own words; if it did not, say so plainly and stay with chasing |

### Requirement coverage

| Requirement | Questions that cover it |
|---|---|
| F1 managing calendars | A1, D1, E1 |
| F2 booking travel | A2, C3 |
| F3 preparing documents in Word and Excel | A4, B2, B4, D2 |
| F4 processing supplier invoices | A3, B1, B2, D3 |
| Remote working (the role's title in the invite; no fit row, because your material says nothing on it) | A5, B5 |

## Persona table

The loop is the one session you described: one 30-minute video call with the office manager. The weights start from the hiring-manager prior and are adjusted for a short call on four hands-on duties. Recalibrate them if you know something the pack does not.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Provenance |
|---|---|---|---|---|
| A. Case / Strategist (top weight, 5 questions) | Small live problems from the four duties: a diary clash, a trip to plan, an invoice that does not match, a spreadsheet to summarise | High. The hiring-manager prior puts Case first, and four practical duties in 30 minutes leave little room for abstract questions | Clarify first, then objective, approach, who you tell, how you record it; think aloud and make no claim about your past | [inferred] |
| B. Skeptic (top weight, 5 questions) | Quiet probing of where your background is furthest from the ad: invoices, Excel, the move from clinic reception | High. The hiring-manager prior puts the Skeptic second, and F3 and F4 are the rows where your quotes sit thinnest against the ad | Rehearse B1 until it is boring: say the quote's own words, say the limit plainly, then give a plan. B1's arc is built from F4's quote | [inferred] |
| C. Conversational (3 questions) | An easy opener about your journey, a values-style question asked casually, an open question about travel | Medium. A video call with an office manager often opens friendly, and casual questions are still scored | A 90-second arc of three beats, each one of your quoted sentences (C1: F1 and F4), then your own reason for the role | [inferred] |
| D. Data-Driven Prober (3 questions) | Pulls on the one figure you gave, the four physios, and on what the Word and Excel rating covers | Medium. Any figure you have given is a magnet for a prober, and the ad names both tools | Know what you can and cannot say about the figure, and say plainly when you do not know | [inferred] |
| E. Pressure (low weight, 2 questions) | A time-boxed challenge: sixty seconds on why you, or how much of the appointment book was you | Low. Nothing in a 30-minute admin call points to a stress interviewer, but one challenge is cheap to rehearse | Pause, restate, hold the quoted position through two follow-ups, concede only what is true and specific | [inferred] |

## Question banks

The highest-ROI prep in this pack is B1: the distance between chasing unpaid invoices and the ad's supplier-invoice duty is the objection most likely to arrive, in some form.

### A. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Imagine two people each need the same hour on the same morning, and you are the one keeping the diary. What do you do?" | CASE | [generic] | Think aloud in order: what you would ask first (who needs the hour, how fixed it is, whether either can move), what you would offer each of them, who you would tell if neither can move, and how you would record the outcome so the diary shows it. The question asks for no past, so the guidance makes no claim about yours | F1's requirement turned into a live problem, scored on structure rather than a record. The label is generic because it is a pattern for the problem, not a fact about this employer |
| A2 | "A colleague needs to be in another city for a meeting next week and back the same day. What do you ask before you book anything?" | JD | [generic] | Ask before choosing: when the meeting starts and ends, how they prefer to travel, whether a budget or approval is needed, and who else is going. Then say you would send the plan back for a yes before booking, and where you would keep the booking details. If there is a booking tool you have not used, say how you would learn it and do not name one you have not used | F2 has no evidence in your material, so a clean method answer is the safest rehearsal. JD because it scores the ad's travel line, with CASE delivery |
| A3 | "A supplier invoice arrives for more than the order said. What do you do before it goes any further?" | CASE | [generic] | Speak as a plan, in "I would" terms: what you would compare it against first, who you would ask, who you would tell, what you would hold back until it is settled, and how you would note what happened. The question asks for no past, so the guidance makes no claim about yours | F4's requirement as a live problem, so the invoice duty is rehearsed as judgment and not only as experience. CASE because it scores order of thinking |
| A4 | "Your manager wants a one-page summary from a spreadsheet of last month's supplier costs by tomorrow morning. What do you ask, and how do you go about it?" | CASE | [grounded] "I'm good with Word, okay with Excel" | Ask first who it is for, what period it covers, and what they will decide from it. Then say the steps you are sure of and, for any step you are not, say you would look it up or ask, since your own rating is "okay with Excel". Close by saying you would check the totals and read the page through before sending | F3 is a self-rating with nothing inspected behind it, so the honest edge of it is rehearsed here. CASE because the scoring is structure and candour about limits |
| A5 | "This role is remote. How would you organise your working day so the office manager knows where things stand?" | JD | [generic] | Cover how you would start the day with what is due, how you would raise a problem early rather than late, how you would show finished work, and how you would handle a request that arrives mid-task. Say it as a plan; your material mentions no remote work, so make no claim about any | The title names the role as remote and no fit row carries remote work, so the guidance stays a plan. JD because it scores a stated feature of the role |

### B. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have chased unpaid invoices. This job is processing supplier invoices. What, if any, of your invoice work carries across?" | JD | [grounded] "chased unpaid invoices" | The deepest rehearsal in this pack. Hold on the quote's own words: "I chased unpaid invoices", and stop. Answer slot: if any of your invoice work went beyond chasing, say what it was and what part was yours, in your own words; if it did not, say so plainly and stay with chasing. Follow-up one, likely: "Chasing is not the same as processing, so how would you get up to speed?" Concede the difference in your own words and give a plan: what you would ask on day one, who you would ask, what you would check twice. Follow-up two: "Would you be comfortable with these invoices from day one?" Answer from how you actually feel; if the honest answer is "not yet", say "not yet" and give the plan again. Never stretch the quote to cover the work the ad names | F4 is the evidence for the invoice requirement and the widest gap between a quote and a requirement, so this objection will arrive in some form: the highest-ROI prep here. JD because it scores a stated duty, with Skeptic delivery |
| B2 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "I'm good with Word, okay with Excel"; "chased unpaid invoices" | Pick the weak spot yourself and say it before they do. Your material gives two honest candidates: your own rating, "okay with Excel", and "chased unpaid invoices" set against the invoice duty. Name the one you believe, say what you would do in the first weeks to close it, and stop. Do not name a weakness you do not have in order to sound modest | F3 and F4 are the rows where your quotes sit thinnest against the ad, so the answer comes from them. JD because it asks about the listed duties; the Skeptic scores honest self-assessment |
| B3 | "You have spent two years as a receptionist at a physiotherapy clinic. Why move into remote admin?" | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic" | Start from the quote's own words: two years as a receptionist at a physiotherapy clinic. Your reason for moving is yours to give and the pack has none from you, so say it in your own words in two sentences and tie it to the ad's duties only where that is true for you. If the reason is simply that you want this kind of work, say that plainly | F1's context is the only background the pack has, so motivation is the probe it can rehearse safely. EXP because it tests whether your story survives cross-examination |
| B4 | "How would you describe your Excel, and what could you do with it in your first week?" | JD | [grounded] "I'm good with Word, okay with Excel" | Give your own rating in the words you used: "okay with Excel". Answer slot: if you have used Excel for work you can describe, say what, in your own words; if not, say so plainly and stay with your rating. Then say what you would learn first and how. Do not round "okay" up | F3 splits into a Word rating and an Excel rating, and the Excel one is the lower, so this is the likelier probe. JD because it scores the ad's tool line |
| B5 | "In a remote role nobody is beside you. What in your background tells me you can work without that?" | EXP | [grounded] "I ran the appointment book for four physios" | Offer only what the sentence carries: "I ran the appointment book for four physios." Answer slot: if you made calls on your own while running it, say one, in your own words; if you were never on your own with it, say so plainly and describe how you ran the book. Then say, as a plan, how you would keep the office manager informed in a remote role | The role's remote title raises this, and F1 is the only row that speaks to working on your own. EXP because it tests what was actually yours |

### C. Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey: what you have been doing and why this role." | EXP | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios"; "chased unpaid invoices" | A 90-second arc of three beats, each a quote: "two years as a receptionist at a physiotherapy clinic", "I ran the appointment book for four physios", "chased unpaid invoices". Then your own reason for this role, in one or two sentences. Tell the beats as stated, with no figures, tools or outcomes beyond them, and end on the role rather than on the past | The opener is scored even when it feels casual, and F1 and F4 hold the whole of the background the pack can use. EXP because it tests that the story matches your record |
| C2 | "Tell me about a time you delivered an unpopular truth to a colleague or a boss." | VAL | [generic] | Pick an occasion where something unwelcome had to be said and was said; it needs the situation, what you said, and how things stood afterwards. If no such time comes to mind, say so plainly, then give the nearest thing your material does carry, or how you would handle it | No fit row supplies a story for this theme, so the guidance is a selection scaffold. VAL because it scores behaviour with people, asked in a friendly register |
| C3 | "Tell me about a time you arranged travel for someone else." | JD | [generic] | Pick a trip you arranged for another person; it needs who it was for, what had to be fitted around, and how it turned out. If no such time comes to mind, say so plainly, then say how you would go about it, in A2's order of questions | F2 has nothing behind it in your material, so this is a scaffold with an honest second branch. JD because it scores the ad's travel line asked casually |

### D. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You ran the appointment book for four physios. Which part of it was yours?" | EXP | [grounded] "I ran the appointment book for four physios" | Start with the quote, word for word. The "four" is a count of physios; say what you know about it and nothing more. Answer slot: if other people also had a hand in the book, or some parts were not yours, say so plainly and return to the quote; if all of it was yours, say that and stop. If asked how the figure of four was arrived at, or what would change it, answer from what you actually know and say plainly when you do not | The one figure in your material gets a defend-the-number rehearsal. EXP because it tests attribution |
| D2 | "You are good with Word. What is the most involved document you have prepared with it?" | JD | [grounded] "I'm good with Word, okay with Excel" | Say your rating as you gave it: "I'm good with Word". Answer slot: if you have prepared documents in Word, say what kind and what made it involved, in your own words; if you did not, say so plainly and stay with your rating. Then stop; a long answer here invites a longer follow-up | F3 gives a rating and no document, so the probe goes to what stands behind the rating. JD because it scores the ad's document line |
| D3 | "How would you keep a record of invoices received, so any one of them could be found later?" | CASE | [generic] | Speak as a plan: what you would note for each one, where you would keep it, and how you would show whether it had been dealt with. Say that you would ask how the office already does it before changing anything. The question asks for no past, so the guidance makes no claim about yours | F4's requirement as a method question; a prober tests whether you think about being checked. CASE because it scores a plan, not a record |

### E. Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That appointment book: how much of it was actually you?" | EXP | [grounded] "I ran the appointment book for four physios" | Pause, restate the question, then hold on the quote: "I ran the appointment book for four physios." Hold through two follow-ups by returning to those words. Concede only what is true and specific: if parts were not yours, name the part, say so plainly, and return to the quote. Do not add duties, and do not shrink what you did | F1's quote is the likeliest to be tested on attribution. EXP because it tests what was actually yours; the pressure is in the delivery |
| E2 | "Sixty seconds: why should we choose you for this job?" | JD | [grounded] "two years as a receptionist at a physiotherapy clinic"; "I ran the appointment book for four physios" | Two quoted beats, then your own reason for wanting this work. If pushed on invoices, return to B1's words: "chased unpaid invoices". Do not compare yourself with other candidates; you do not know them | A time-boxed question is the usual pressure test, and F1 holds the strongest sentence the pack has. JD because it scores fit for the listed job |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first month look like for the person in this role?" | It shows you think in outcomes, and the answer tells you what to practise before day one |
| R2 | "Which calendars and trips would be mine from the start, and what do you use for them?" | It ties to the ad's calendar and travel lines and shows you are planning how to be useful quickly |
| R3 | "How do supplier invoices reach this role, and what happens to them after I have dealt with them?" | It shows you think about what happens after your step, which is the part an invoice duty depends on |
| R4 | "How do you like work to be checked and handed over when everyone is in different places?" | It speaks to the remote setup and signals you want the office manager to know where things stand |
| R5 | "Which Excel jobs come up most, and are there templates I would work from?" | It is an honest question for someone who rates their Excel as okay, and it shows you are preparing |
| R6 | "What happens after today's call, and when would you expect to be in touch?" | It closes the call cleanly and gives you a timeline to plan around |

## Prohibited claims

Claims this pack will not coach. Each is the stretched wording of a sentence you did say, so the honest form is the quote at its own scope. The limit is the pack's own observation, not words for you.

| Not coached | Basis | Honest form |
|---|---|---|
| Managed calendars | Inflated form of F1 | F1's quote at its own scope: "I ran the appointment book for four physios." The limit is the pack's observation: the material gives an appointment book for four physios, not other kinds of calendar |
| Processed supplier invoices | Inflated form of F4 | F4's quote at its own scope: "I chased unpaid invoices." The limit is the pack's observation: the material says chasing, not what was done with invoices beyond that |
| Strong Excel skills, or prepared documents and spreadsheets in Word and Excel | Inflated form of F3 | F3's quote at its own scope: "I'm good with Word, okay with Excel." The limit is the pack's observation: the material gives a rating, not work done with either tool |

## Sources

Provided documents: the interview invitation as you pasted it (role, company, format, interviewer's job title), the ad's duties as you listed them, and your background as you described it. No dossier was consumed.

Searches sent, all refused:

- `Brennock Facilities Ltd values`: refused
- `Brennock Facilities Ltd interview process administrative assistant`: refused
- `Brennock Facilities Ltd news`: refused

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Brennock Facilities Ltd values` | unavailable | The search was refused. It would have fed the values cheat sheet and VAL guidance; no values-style round is detected, so section 10 is absent |
| 2. `Brennock Facilities Ltd interview process administrative assistant` | unavailable | The search was refused. It would have checked the loop; persona weights rest on the one session you described |
| 3. `Brennock Facilities Ltd news` | unavailable | The search was refused. It would have fed CO questions and a grounding brief; the pack has neither |
| 4. `{interviewer name} Brennock Facilities Ltd` | n/a | Only a job title was given, so there was no name to search; the interviewer read is absent |
| 5. representative `Remote Administrative Assistant` JD | skipped | The ad's duties you listed fix the four fit rows and the JD-tagged questions |

## Upgrade menu

- The full text of the ad → F1 to F4 become quoted requirements instead of your summary, and mid-list duties may gain rows and questions
- Any detail on travel you have arranged, what you used Word or Excel for, or what you did with invoices beyond chasing → F2, F3 and F4 move from answer slots to story maps, and B1, B2 and B4 sharpen
- The office manager's name → an interviewer read, adjusted persona weights and a reverse question tied to their path
- Whether the office manager is your future manager or a colleague → reweights every bank
- Company research, which was refused this session → CO questions and a grounding brief
- A tuesday-dossier.md → verified evidence and prohibited claims carried in from an earlier session; never needed to use this pack
