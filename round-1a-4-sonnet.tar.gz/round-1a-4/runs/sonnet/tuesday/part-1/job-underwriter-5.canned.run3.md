I've read the underwriting playbook and its reference files. Next I'll check that the posting and the company page you pasted are live and match, then write the assessment.
# Job underwriting: Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Yes, worth applying. The must-haves R3, R4, R5, R6, R8 and R9 are all `direct`, and the two gates, location and pay, are only unconfirmed. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R8, R9
- `important` — adjacent: R7 (BigQuery); unclear: R10 (ingestion from app and CRM), R11 (data contracts)

R7 (`medium`) — a Snowflake-to-BigQuery bridge, its limit named; R10 — payroll sources are not shown to match an app and a CRM; R11 — no contract work stated.

**Opportunity ledger.** The employer matches its own pages (RR5), and the stated pay sits at or above the market median you supplied (RR1). The open items are scope (RR3), the unnamed manager (RR2) and the equity terms (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1 and R2 against your own location, authorization and pay floor; (2) BigQuery is presented as adjacent to your Snowflake work, never as experience you have (R7); (3) the scope in RR3 verifies as one defined remit, not the whole data function.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C of $52M in February 2026 | `[grounded]` company About page, fetched |
| Mandate | Build and run reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` posting, fetched |
| Requirements | 5+ years data engineering; SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` posting |
| Pay and location | $148,000–$166,000 plus equity; Remote (US) or Denver office | `[grounded]` posting |
| Seniority read | Your 6 years sits inside the 5–8 years the report calls typical for "Senior" | `[grounded]` the Datawright report you supplied, against your stated 6 years |
| Scope read | Ingestion, warehouse and contracts together are broader than the "one domain's pipelines, no direct reports" the report calls typical. The posting names no reports, so the gap is breadth, not management | `[inferred]` from the posting's three duties against the report's typical scope |
| Market calibration | Series B–D senior base: median $151,000, interquartile range $139,000–$163,500, n=2,310. The posting's range runs from $3,000 below the median to $2,500 above the 75th percentile. This is a market band, not this employer's offer | `[grounded]` report you supplied; `[grounded]` posting figures |
| Unknowns | Hiring manager; team size; which pipelines already exist; equity terms; whether the pay band applies to remote hires; first-year outcomes | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the About page | `[grounded]` both fetched |

## Evidence map

Your background was given in prose, which counts as a self-reported lead (`medium` at most) until there is a CV or an artifact to inspect.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | "Remote (US) or our Denver office" | hard_gate | unclear | none | hard_gate | You have not stated your location, work authorization or office-days limit, so the terms are not settled either way | `[grounded]` posting terms; no constraint supplied | Question Q1 |
| R2 | "$148,000–$166,000 plus equity" | hard_gate | unclear | none | hard_gate | No pay floor given. Equity terms are unstated, so total pay cannot be compared | `[grounded]` posting; no floor supplied | Question Q1 |
| R3 | "5+ years data engineering" | must_have | direct | medium | none | 6 years stated, in a payroll company's data engineering. Confirmed but not yet inspectable | `[grounded]` your intake message | Share a CV to confirm the dates |
| R4 | "strong SQL and Python" | must_have | direct | medium | none | Both used daily, per your message. "Strong" is judged on what you built, which the dbt and Airflow rows show | `[grounded]` your intake message | CV bullets that show SQL and Python depth |
| R5 | "dbt" | must_have | direct | medium | none | You built the dbt project, about 180 models. Limited inspectable proof so far | `[grounded]` your intake message | A sanitized lineage or docs screenshot would raise to `high` |
| R6 | "a cloud warehouse" | must_have | direct | medium | none | The posting's wording is generic, and you have run Snowflake in production. The posting's BigQuery is R7 | `[grounded]` your intake message; `[grounded]` posting wording | none |
| R7 | BigQuery as the posting's warehouse | important | adjacent | medium | transferability | The posting names BigQuery in its duties, not in the requirements list, which is why this row is `important`. Your dbt modelling and warehouse SQL carry over from Snowflake. Not exercised: BigQuery-specific cost, partitioning and clustering behaviour, which differs by platform | `[grounded]` your Snowflake claim and the posting; `[generic]` platform-specific tuning differs between warehouses | Gap G1: a small BigQuery sandbox project would narrow the limit |
| R8 | "orchestration with Airflow or similar" | must_have | direct | medium | none | Airflow is named in your background | `[grounded]` your intake message | none |
| R9 | "experience with data quality testing" | must_have | direct | medium | none | You set up the Great Expectations suite, which is hands-on ownership. The posting's dbt context may also expect dbt-native tests, which you have not mentioned | `[grounded]` your intake message; `[inferred]` posting's dbt context | A description of what the suite checks, sanitized, would raise to `high` |
| R10 | "ingestion from our app and CRM" | important | unclear | low | discovery | A payroll company's sources may be product databases, vendor files or APIs. Nothing says you ingested app events or CRM data | `[grounded]` your message silent on sources | Question Q2 |
| R11 | "the data contracts our analysts depend on" | important | unclear | low | discovery | Nothing stated about formal contracts or schema agreements with analysts, though the Great Expectations suite may be adjacent | `[grounded]` your message silent on contracts | Question Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | Strong Snowflake and dbt work; no BigQuery use stated | It is the platform named in the duties, so it will likely come up in screens | A personal or sandbox BigQuery project; a migration or evaluation you took part in | A short repo or write-up of a dbt-on-BigQuery build | `[inferred]` bridge from the Snowflake claim; `[generic]` that screens probe the named platform |
| G2 | App and CRM ingestion (R10, important) | discovery | Sources at your company are not described | The posting lists ingestion first among its duties, so the answer shapes what you lead with | Syncing a product database or a CRM into the warehouse; webhook, API or file-drop pipelines; handling late or changing source data | An architecture diagram or an Airflow DAG description, sanitized | `[grounded]` background silent on sources; `[inferred]` that it matters because the posting lists ingestion first |
| G3 | Data contracts (R11, important) | discovery | No schema agreement or contract work stated | The posting names contracts as something analysts depend on | Agreeing column definitions with analysts; failing a pipeline on a schema change; versioned model interfaces | A contract doc, a test config, or a changelog | `[grounded]` background silent on contracts |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and at or above market median | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Transparent pay in a band consistent with the senior market | `[grounded]` posting against the report you supplied | Does the band apply equally to remote and Denver hires? | noted |
| RR2 | Hiring manager and team not named | unknown | — | "The posting names no hiring manager" (your note) | You cannot yet see who you would report to or who the analysts are | `[grounded]` posting silent | Who would I report to, and how large is the data and analytics team today? | unresolved |
| RR3 | Breadth of remit | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | The role may cover ingestion, modelling and contracts alone, which is broader than the typical one-domain remit. Rated `low` because the posting may simply describe a small team's stack | `[inferred]` from three duties against the report's typical scope | Which of ingestion, modelling and contracts already exist, and which would I build? What does success look like after a year? | unresolved |
| RR4 | Equity and location terms unstated | unknown | — | "plus equity" | Equity amount, vesting and strike terms are not given, and the band may differ by location | `[grounded]` posting silent | What is the equity grant for this level, and how does pay vary between remote and Denver? | unresolved |
| RR5 | Employer matches its own pages | positive_signal | — | "Series C ($52M, February 2026)" | The employer exists as described and the posting is live. The funding figure is the company's own statement, not independently confirmed | `[grounded]` both pages fetched and match what you pasted | none needed | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the dbt project (about 180 models), the Airflow orchestration and the Great Expectations suite, matching the posting's order | see R5, R8, R9 | `[grounded]` your intake message | pending your approval |
| E2 | State the Snowflake work plainly, and where BigQuery comes up say you have not used it, with the transferable parts named | see R7 | `[grounded]` your intake message | pending your approval |
| Q1 | Ask the questions in RR2, RR3 and RR4 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Check R1 and R2 against your own limits before spending effort on the loop | see R1, R2 | `[grounded]` unconfirmed gate rows | pending your approval |

## Evidence status

Verified: none yet. Every claim about you is from your intake message and unprobed.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer) and "About Pellucid Learning" (pellucidlearning.com/about). These checked your pasted copies: the posting is live and both match, which gave RR5 and the contradictions row |
| 2. Role-family sweep | skipped | The Datawright report you supplied fixes the market calibration and the seniority read, so a search would not change them |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

I'm offering a deeper research pass on the company, up to 5 more searches and 2 more fetches, in the upgrade menu below.

I can write all of this up as a `tuesday-dossier.md` if you want one for later steps.

## Upgrade menu

- A CV, so R3 to R6, R8 and R9 are checked against dated bullets and can move from `medium` toward `high`.
- A sanitized description of the Great Expectations suite or a dbt lineage screenshot, to raise R9 or R5 to `high`.
- A BigQuery sandbox project or write-up, to narrow R7's limit.
- Your location, work authorization, pay floor and any office-days limit, which settle R1 and R2.
- The hiring manager's name, once known, for role reality's scope read and positioning.
- A deeper research pass on Pellucid (funding news, hiring patterns, employee and candidate reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

Q1 (R1, R2) — Where are you based, and are you authorized to work in the US without sponsorship? Is $148,000 the bottom of what you would accept, and would you work from the Denver office if asked?
Q2 (R10) — Which data sources did you ingest at the payroll company, and did any come from a product app or a CRM? What did you own?
Q3 (R11) — Did you agree schemas, column meanings or quality guarantees with the analysts who used your models, and how was that enforced?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.