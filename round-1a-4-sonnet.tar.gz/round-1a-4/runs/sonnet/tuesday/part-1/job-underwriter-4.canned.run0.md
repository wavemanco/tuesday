Checking the careers page itself. The search snippet says "Leeds office four days a week", but your JD says fully remote.
**Probably yes on fit, but don't apply yet. The JD says fully remote (UK) and Brindlemoor's own careers page says "Leeds office four days a week" (R1). Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6a, R7, R8a · adjacent: R10 (Pet-insurance domain knowledge) · unclear: R6b (Monitor rating models), R8b (Recommendations for product)
- `preferred`: direct: R9

R4, R7 — the core method, with direct evidence; R10 — a credible bridge, its limit named; R1 — the one row that can flip the answer.

**Opportunity ledger.** The role is clearly scoped and reports to a named Director of Pricing (RR3). Working pattern is contradicted between the posting and the careers page (RR1), and pay is withheld (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** it waits on where you can work and which version of the working pattern is true (R1, RR1). If four days in Leeds is impossible for you, it becomes `no_go`. If remote is confirmed, it becomes `conditional_go` or `go`, with pay (RR2) still to check.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech selling pet insurance. No independent coverage of the company turned up. The careers page and the manager's profile both name it | `[grounded]` careers page; the company and product search returned nothing |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, give recommendations to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing, Odile Varga | `[grounded]` careers page, JD |
| Working pattern | JD: fully remote (UK). Careers page: Leeds office four days a week | `[grounded]` both sources, in conflict |
| People management | Not stated as a requirement or a duty, so "never managed anyone" does not map to any stated requirement | `[grounded]` JD silent |
| Scope read | A single-product pricing analyst post at senior level, with one named director above it | `[inferred]` from the JD's one-product scope and the careers page's reporting line |
| Market calibration | Senior pricing analyst at UK insurers and insurtechs: median base £58,400, interquartile range £52,100 to £64,900. The posting withholds pay, so this is a band, never Brindlemoor's offer | `[generic]` Pricewell 2026 pay survey (n=612); `[grounded]` JD silent on pay |
| Hiring manager | Odile Varga spoke at the 2025 Insurance Pricing Forum ("Small Books, Loud Errors", on monitoring rating models in small books). Previously head of pricing analytics at Calloway Re for six years | `[grounded]` her profile page, from the search result only; the page was not fetched |
| Unknowns | Salary; whether the post is remote or Leeds-based; how product-facing it is | — |
| Contradictions | Remote (JD) against Leeds four days (careers page) | `[grounded]` fetched careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | Your own constraint was not stated, so there is nothing to grade. The two sources disagree, so the role's terms do not settle it | `[grounded]` JD and careers page in conflict | G1; ask the employer which is true |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years' pricing analytics at a UK motor insurer, self-reported with no inspectable artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use, self-reported | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Self-reported, no artifact yet | `[grounded]` your background | A sanitized model-spec summary would raise to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6a | Build rating models | important | direct | medium | none | Same evidence as R4 | `[grounded]` your background | none |
| R6b | Monitor rating models | important | unclear | low | discovery | "Maintained" is stated, but monitoring practice (metrics, cadence, drift response) is not. Resolved downward. | `[grounded]` your background silent on monitoring; `[inferred]` that maintenance may include it | G2 |
| R7 | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with underwriting. Whether you designed them or only ran and read them is not stated | `[grounded]` your background | A sanitized test readout would raise to high |
| R8a | Recommendations for underwriting | important | direct | medium | none | Tests were run with the underwriting team and you present their quarterly review. Which decisions your results drove is not stated | `[grounded]` your background | none |
| R8b | Recommendations for product | important | unclear | low | discovery | Nothing in your background mentions a product or proposition team | `[grounded]` your background silent | G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain knowledge (implied by the product) | important | adjacent | medium | transferability | Motor rating carries over: personal lines, GLM, rating factors. Limit: no pet-specific exposure, such as breed, age or vet-cost drivers | `[inferred]` the JD never lists pet knowledge; `[generic]` that pet and motor books differ in their rating drivers | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Remote or Leeds four days (R1, hard_gate) | hard_gate | JD and careers page disagree. Your location and constraints are not known | It decides whether this is worth any effort | Not applicable; this asks whether the gate is met | The employer's written confirmation of the working pattern | `[grounded]` the conflicting sources |
| G2 | Monitoring of rating models (R6b, important) | discovery | "Maintained" the GLM, but no monitoring detail | The hiring manager's published talk is on monitoring rating models in small books | Actual-versus-expected tracking, drift or lift checks, refit triggers, dashboards others used | A sanitized monitoring pack or dashboard screenshot | `[grounded]` your background silent; `[inferred]` the talk makes this the likeliest probe |
| G3 | Recommendations to product (R8b, important) | discovery | Underwriting is covered, with no product audience mentioned | The JD names product as a recipient | Taking a test result to a product, proposition or distribution team | A sanitized readout or an email chain | `[grounded]` your background silent |
| G4 | Pet-insurance bridge (R10, important) | transferability | Motor GLM and price-test work carries over. No pet exposure | Likely objection to a motor-to-pet move | Bridge: the rating and testing method is the same. Limit: pet-specific rating drivers were not exercised. Strengthener: a short note on how you would approach them, as a work sample | A brief, clearly labelled as your own thinking | `[inferred]` from the JD and your motor background; `[generic]` that rating drivers differ by line |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicted | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The JD may be stale or the careers page wrong. The post may have changed, or it may be hybrid in practice | `[inferred]` from two sources in conflict | Is this role fully remote, or office-based in Leeds four days a week? | unresolved |
| RR2 | Pay withheld | unknown | — | JD gives no salary | Pay may sit anywhere in or outside the market band | `[inferred]` from the posting's silence, against the `[generic]` band | What is the salary range for this post? | unresolved |
| RR3 | Clear scope and named reporting line | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The mandate is concrete, with one accountable manager | `[grounded]` careers page | What does success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Email the recruiter or Odile Varga to confirm the working pattern before applying | R1, RR1 | `[grounded]` register | pending your approval |
| A2 | If it goes ahead, lead with the 14 price tests run with underwriting and the young-driver GLM you built and maintained. Both sit directly on stated requirements | R4, R7 | `[grounded]` your background | pending your approval |
| A3 | Be ready to say plainly that your experience is motor, not pet, and to explain how the method carries over | R10 | `[grounded]` R10 row | pending your approval |
| A4 | Prepare a clear account of how you monitored your model, since the hiring manager has spoken publicly on that topic | G2 | `[inferred]` from her published talk | pending your approval |
| A5 | Ask RR2's pay question early in the process | RR2 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech", which returned nothing, and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The posting is live and shows the working-pattern contradiction (R1, RR1). Company size and product could not be corroborated |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). It set the market band in role reality and the pay question (RR2) |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Read from the search result only. It fed the hiring-manager row and A4 |

I can save this as a dossier (`tuesday-dossier.md`) if you'd like to keep or reuse it.

**Upgrade menu**
- Your location and whether you need remote work → settles R1, RR1 and the decision.
- The employer's written answer on the working pattern → closes RR1.
- A sanitized model-monitoring pack → raises R6b and R4.
- A sanitized price-test readout → raises R7 and R8a.
- Your salary floor → lets RR2 be checked against the market band.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Where are you based, and could you work from a Leeds office four days a week, or is fully remote a requirement for you?

G2 — How did you monitor the young-driver GLM after launch? Which metrics did you track, how often, and what did you do if something looked off?

G3 — Have you taken price-test results to a product or proposition team, as well as underwriting? What did you own, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.