**Is this worth applying to? Yes, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts analysts depend on)

R8 (`medium`) — a Snowflake bridge, its limit named; R9 (`none`) — you haven't described ingestion work; R10 (`none`) — contracts work not yet described.

**Opportunity ledger.** The posting is sound on what it states. Pay is disclosed and sits in line with the report you pasted (RR2), and the scope is concrete (RR5). Open items are the unverified employer and live posting (RR1), no named hiring manager (RR3), and what "run" involves (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 clear your own location and pay constraints; (2) the employer and live posting verify (RR1); (3) your BigQuery gap is framed honestly as adjacent (R8), and ingestion and contract ownership are confirmed (R9, R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the about text you pasted; not checked against the live site |
| Mandate | Build and run reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, data contracts for analysts | `[grounded]` JD |
| Work arrangement | Remote (US) or Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 salary plus equity; equity terms not stated | `[grounded]` JD |
| Scope read | One domain's pipelines (reporting), with no direct reports mentioned | `[inferred]` from the JD's mandate list and its silence on reports |
| Market calibration | Datawright, Senior DE at Series B–D, n=2,310: base median $151,000, IQR $139,000–$163,500; "Senior" typically 5–8 years, one domain's pipelines, no direct reports. The posting's low end is $3,000 under that median and its top is $2,500 over the IQR's upper bound, so the range reads at or above market. Pellucid is Series C, inside the report's band. That is the market's pattern, not this employer's offer | `[grounded]` the report as your recruiter supplied it and the JD; `[inferred]` that the posting's salary is base pay. Not independently checked |
| Hiring manager | Not named | `[grounded]` JD |
| Unknowns | Team size, on-call duties, equity structure, reporting line, your location and pay floor | `[grounded]` JD silence |
| Contradictions | None between the JD and the about text you pasted | `[grounded]` both pasted texts; neither checked live |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you are based or your location constraints, so the gate is not established | `[grounded]` JD; your constraints not given | Question Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The pay is stated, but your floor isn't, so I can't tell whether it clears. Equity is unvalued | `[grounded]` JD; your floor not given | Question Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You describe 6 years at a payroll company. That is confirmed in prose with no artifact seen, so `medium` | `[grounded]` your stated background | Offer: a CV or LinkedIn history would raise it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You say you use both daily. Stated, but nothing inspectable | `[grounded]` your stated background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project (about 180 models) on Snowflake. The JD asks for "a cloud warehouse", and Snowflake is one | `[grounded]` your stated background | Offer: a dbt docs or lineage view would raise it |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | You say Airflow is your orchestrator. No scale or ownership detail yet | `[grounded]` your stated background | Offer: a sanitized DAG listing |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. Coverage and outcomes aren't stated | `[grounded]` your stated background | Offer: a suite config excerpt |
| R8 | BigQuery-based warehouse | important | adjacent | medium | transferability | The JD names BigQuery in the mandate, not the requirements list. Snowflake dbt work is adjacent. Limit: you have not used BigQuery. Dbt projects are usually portable SQL, but warehouse-specific behaviour differs | `[grounded]` your stated Snowflake work and "never used BigQuery"; `[generic]` the portability pattern | See G1 |
| R9 | Ingestion from app and CRM | important | unclear | none | discovery | Nothing you've told me covers ingesting from product or CRM sources | `[grounded]` silence in your background | Question Q2 |
| R10 | Data contracts analysts depend on | important | unclear | none | discovery | Testing suggests adjacency, but you haven't described contracts or analyst-facing guarantees | `[grounded]` silence; `[inferred]` testing as a possible thread | Question Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake and dbt work, no BigQuery use | Interviewers on a BigQuery shop will probe the warehouse itself. Saying plainly that it's adjacent is safer | A small dbt project run on BigQuery; any past move between warehouses or a migration | A repo or write-up of that small project, done before you claim it | `[grounded]` your statement; `[generic]` that interviews probe the named warehouse |
| G2 | Ingestion (R9, important) | discovery | Nothing on how data got in | Ingestion is the first item in the mandate | Loading from product databases, event streams, SaaS or CRM exports; managed connectors or custom code | A sanitized pipeline diagram or DAG listing | `[grounded]` silence |
| G3 | Data contracts (R10, important) | discovery | Great Expectations suite, but no consumer-facing agreements | The JD says analysts depend on the contracts | Agreed schemas or freshness guarantees with analysts; schema-change rules; test failures routed to owners | A contract doc, schema tests, or a changelog | `[grounded]` silence; `[inferred]` testing as a possible thread |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified | risk_signal | medium | "Founded 2016, Denver. 264 employees. Series C ($52M, February 2026)." | The company may be as described, the posting may be stale, or a check may simply not have been possible. None ranked as likely | `[generic]` pattern for any employer not yet checked, not a claim about this one | Can you point me at this role on your careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay disclosed and in line with the pasted report | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent and at or above the report's median. Equity terms are unknown | `[grounded]` JD and the pasted report | Is the range base salary only, and what are the equity type, vesting and strike? | noted |
| RR3 | No hiring manager named | unknown | — | "The posting names no hiring manager" | Reporting line and team shape are unknown | `[grounded]` JD | Who would this role report to, and who else is on the data team? | unresolved |
| RR4 | What "run" involves | unknown | — | "Build and run the pipelines" | "Run" may include on-call or incident duty. Not stated | `[inferred]` from the JD wording | Is there an on-call or incident rotation for pipelines, and how often? | unresolved |
| RR5 | Concrete scope and stack | positive_signal | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | Scope and tools are specific, not vague | `[grounded]` JD | Who owns ingestion, modelling and contracts today, and is that split changing? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on Pellucid's own careers page and ask the recruiter who the hiring manager is | RR1, RR3 | `[grounded]` register | pending your approval |
| E1 | `resume_edits_pending_approval`: lead with the dbt project (about 180 models, Snowflake), the Great Expectations suite you set up, and Airflow orchestration, in your own words | R3, R5, R6, R7 | `[grounded]` your stated background | pending your approval |
| A2 | Say plainly that you have run Snowflake and have not used BigQuery. Make no BigQuery claim until you have done a project | R8, G1 | `[grounded]` your statement | pending your approval |
| Q-plan | Ask the register's questions verbatim in the loop: RR2, RR3, RR4, RR5 | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Every row here, prose included, is a proposal. Nothing is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Pellucid Learning online tutoring K-12 Denver Series C" and "Pellucid Learning careers Senior Data Engineer". Both were refused for lack of search permission. It would have confirmed the employer and live posting and fed RR1 |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market calibration and the pay comparison in RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

I'll offer the dossier file whenever you want a copy to keep or share.

## Upgrade menu

- Your location and pay floor → R1 and R2 close, and the gates are settled.
- A CV, plus a dbt docs or lineage view, a Great Expectations config excerpt, or a sanitized DAG listing → R3–R7 move from `medium` toward `high`.
- Search permission → target 1 runs and RR1 can close.
- Your answers on ingestion and contracts → R9 and R10 resolve.
- A small BigQuery project you build → narrows R8's limit.
- The hiring manager's name → targets 3 and RR3 run.

**Questions**

Q1 (R1, R2) — Does a US-remote or Denver-based role at $148,000–$166,000 fit your location and pay constraints?

Q2 (G2) — Have you ingested data from product databases, events, or SaaS and CRM sources? What did you own and how did it run?

Q3 (G3) — Have you agreed schemas, freshness or quality guarantees with analysts, and what happened when a test failed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.