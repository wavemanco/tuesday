**Yes, worth applying to, on conditions (R1, RR1, RR2). Status: `conditional_go`.**

I tried three web searches for the company, the pay band and Odile Varga, and all three were refused. So this is built from your JD and your message only, and the employer is unchecked.

# Job Underwriting: Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R7
- `important` — direct: R8a · unclear: R8b (Recommendations for product)
- `preferred` — direct: R6 · adjacent: R9 (Pet-insurance domain)

R4 (`medium`) — the GLM build you described matches the core of the role; R7 (`medium`) — "ran" does not settle whether you designed the tests; R9 — a bridge from motor, its limit named.

**Opportunity ledger.** The role is plausible but unverified: the employer is not established (RR1), pay is not stated in the text you pasted (RR2), and who decides rate changes and whether the post has reports is open (RR3). The duties are concrete and sit close to your work (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm UK location and right to work (R1); (2) the employer and live posting verify (RR1); (3) pay and reporting line are acceptable once stated (RR2, RR3).

Never having managed anyone is not a gap on this map: the JD as pasted asks for no line management. Whether the post has reports is RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: rating models, price tests, recommendations to underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote (UK) | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` JD; public footprint not researched |
| First-year outcomes | Not stated. Likely a live, monitored pet rating model and a running price-test programme | `[inferred]` from the responsibilities list |
| Scope read | Single-product ownership at senior level | `[inferred]` from "own" and "for our pet-insurance product" |
| Market calibration | Not set: the role-family search did not run (Evidence status, row 2) | `[grounded]` |
| Unknowns | Salary; team size and reports; contract type; whether the role decides or recommends rate changes | `[grounded]` JD silent on each |
| Contradictions | None inside the JD; there is no second source to compare it with | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | The JD says fully remote (UK). Your UK insurer suggests you are UK-based, but location and right to work were not stated | `[grounded]` JD quote; `[inferred]` from your UK employer | G1 question |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years of pricing analytics is specific, but self-reported with nothing inspectable yet | `[grounded]` your message | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. "Strong" is your own level, so expect a probe | `[grounded]` your message | none |
| R4 | Build and monitor rating models; GLM experience | must_have | direct | medium | none | You built and maintained a GLM rating model for the young-driver book. Monitoring practice (drift, loss-ratio tracking) is not described, so claim only what you stated | `[grounded]` your message | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Actuarial leads are not mentioned, but the JD says "or" | `[grounded]` your message | none |
| R6 | Insurance experience a plus | preferred | direct | medium | none | Motor insurer, five years | `[grounded]` your message | none |
| R7 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 price tests last year with underwriting. "Ran" does not say whether you designed them (control, sample, duration) or read the results; taken at the lower reading until you say | `[grounded]` your message | Not asked this turn (G3) |
| R8a | Recommendations for underwriting | important | direct | medium | none | The tests were run with underwriting and you present their quarterly review. What your recommendations changed is not stated, so expect a probe | `[grounded]` your message | none |
| R8b | Recommendations for product | important | unclear | low | discovery | The JD pairs "underwriting and product"; you named only underwriting | `[grounded]` JD quote and your message | G2 question |
| R9 | Pet-insurance domain (inferred from "our pet-insurance product") | preferred | adjacent | medium | transferability | Motor GLM and price testing carry over. Limit: you have not priced pet, and pet rating factors (breed, age, pre-existing conditions, vet-fee inflation) are new ground. The JD asks only for insurance experience | `[grounded]` your statement; `[generic]` pet rating factors | G4; work-sample offer below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK location and right to work (R1, hard_gate) | hard_gate | Nothing states where you are based or your work authorization | A gate the inputs do not settle stays open | Not an experience question: it is a yes/no on the term | None needed | `[grounded]` inputs silent |
| G2 | Pricing recommendations to a product team (R8b, important) | discovery | Underwriting work is clear; no product-side work is mentioned | The JD names product as an audience; this is the one important row below `direct` | A test result that shaped a product feature or bundle; a rating-factor change agreed with a product owner; a pricing paper for a product review | A sanitised readout or deck | `[grounded]` your message silent on product; `[generic]` that senior posts like this usually face both audiences |
| G3 | Test design versus execution (R7, must_have) | discovery | Fourteen tests run; your role in design is not stated | A must-have; an interviewer is likely to ask what was yours | Setting control and test cells; sizing a test; agreeing stop rules; the final read-out | A sanitised test plan or readout | `[grounded]` your message; `[generic]` on interviewer probing. Not asked this turn (question budget) |
| G4 | Pet-insurance domain (R9, preferred) | transferability | Adjacent motor evidence; no pet exposure | Preferred, but it is the role's whole product | Pricing any new line, such as a first-time-buyer or a niche segment; learning a new rating-factor set quickly | A short work sample on how you would structure pet rating factors | `[grounded]` your statement; `[inferred]` bridge from motor GLM work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay not stated | unknown | — | No figure appears in the JD as pasted | The figure may sit anywhere against your floor; posts may simply not publish pay | `[grounded]` JD silent; `[inferred]` that the pay is worth a question | What salary range is budgeted for this post? | unresolved |
| RR3 | Ownership without stated authority or team | unknown | — | "Own pricing analytics for our pet-insurance product" | The role may be the only pricing analyst on the product, and may recommend rather than decide rate changes | `[inferred]` from "own" against the JD's silence on team and decision rights | Who else is on the pricing team, and which rate changes does this role decide versus recommend? | unresolved |
| RR4 | Concrete, coherent duties | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | Scope looks defined, and a named Director of Pricing is the hiring manager | `[grounded]` JD | What would success look like in the first year? | noted |

## Application plan

Every row is proposed. Nothing here is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the young-driver GLM rating model you built and maintained, and the 14 price tests run with underwriting | See R4, R7 | `[grounded]` your message | pending your approval |
| A2 | On pet, say plainly that your GLM and price-testing work is motor, and that pet rating factors are new to you. Claim no pet knowledge | See R9 | `[grounded]` your statement | pending your approval |
| A3 | Find the role on Brindlemoor's own careers site before investing effort | See RR1 | `[grounded]` RR1 | pending your approval |
| A4 | Ask RR2 and RR3 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | If management comes up, state that you have none. Ask RR3 to learn whether the post has reports | The JD as pasted does not ask for it | `[grounded]` JD silent | pending your approval |

No resume was supplied, so I propose no resume edits.

Offer beyond the spec: a one-page sketch of how you would structure pet rating factors, as a work sample for R9. I would build it on your approval, since the JD makes pet-specific experience no more than a bonus.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech careers"; the call was refused. It would have moved RR1 and role reality's organization row |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst pet insurance UK salary remote"; the call was refused. It would have moved the market calibration row and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; the call was refused. It would have moved the scope read and A1's positioning |

I can offer a `tuesday-dossier.md` of this assessment to carry into later steps; say so if you want it.

## Upgrade menu

- Your UK location and right to work → R1 closes.
- A CV with dated roles, plus any sanitised model specification, rating-factor relativity table, test readout or quarterly review deck → R2–R5 and R7 can rise from `medium` toward `high`.
- Your pay floor, and the budgeted range once Brindlemoor states it → RR2 closes.
- Permission for web search → targets 1–3 rerun: the company, the market band, Odile Varga's public professional footprint.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) → fuller RR1 and the register. It needs search permission, and I'll run it if you say the word.

G1 — Are you based in the UK with the right to work there, and is fully remote from the UK workable for you?

G2 — Have you taken pricing results to a product team or product owner, not only underwriting? What did you present, and did anything change as a result?

RR2 — What pay floor would you need for a move, and is there any other term you would not flex, such as days in an office, hours or contract type?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.