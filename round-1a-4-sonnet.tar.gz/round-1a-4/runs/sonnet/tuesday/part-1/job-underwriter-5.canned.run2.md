I fetched the live posting and checked the company page against what you pasted. Here is the full read.

## Decision snapshot

**Yes, worth applying to. The six must-have rows R3, R4, R5, R6, R8 and R9 each land `direct`, and the one named gap is BigQuery at R7 (`adjacent`). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R8, R9
- `important`: adjacent: R7 (BigQuery warehouse) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R7: a credible bridge from Snowflake, its limit named; R10, R11: waiting on your answers.

**Opportunity ledger.** Sound on what the posting states. The employer and posting match the company's own pages (RR1), and pay is disclosed inside the market band (RR2). Team shape (RR3) and equity terms (RR4) are unknown.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you can work remote from the US or from Denver (R1); (2) the base pay clears your floor (R2); (3) BigQuery is framed as adjacent and never as experience (R7); (4) the team and ownership scope verify in interviews (RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` the company's own about page, found by search. The funding figure has no second source. |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` posting, fetched |
| First-year outcomes | Not stated | `[grounded]` posting silent |
| Working pattern | Remote (US) or the Denver office | `[grounded]` posting |
| Scope read | One reporting domain's pipelines, with no direct reports mentioned. This looks like a normally scoped senior post. | `[inferred]` from the posting's mandate and its silence on reports, set against the pay report's "ownership of one domain's pipelines with no direct reports" |
| Market calibration | The report (Series B–D, Senior Data Engineer) gives a base median of $151,000, an interquartile range of $139,000–$163,500, and 5–8 years as typical. The posting's $148,000–$166,000 starts $3,000 below the median and ends $2,500 above the upper quartile, with a $157,000 midpoint. The posting says "Salary" and doesn't say it means base. | `[grounded]` the report you supplied (n=2,310) and the posting's figures; `[inferred]` that the posted salary is a base figure |
| Unknowns | Team size and reporting line; equity terms; whether the salary is base; hiring manager (not named) | `[grounded]` posting silent |
| Contradictions | None. Your pasted text matches the live careers page, which shows "Accepting applications". | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you are or what you'd accept. Confidence grades your statement of the constraint, and there isn't one yet. | `[grounded]` posting terms; your location not given | Q G1 |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | No pay floor was given, so I can't say whether the range clears it. | `[grounded]` posting figure; your floor not given | Q G1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It is self-reported with nothing inspectable yet, so `medium`. | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" rests on your word alone, so `medium`. | `[grounded]` your stated background | none |
| R5 | dbt | must_have | direct | medium | none | You built the company's dbt project, about 180 models, on Snowflake. It is specific and confirmed, with no inspectable artifact yet. | `[grounded]` your stated background | A sanitized dbt docs lineage graph or model list would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, which is what the requirement text asks for. The BigQuery question is in R7. | `[grounded]` your stated background | none |
| R7 | BigQuery as the warehouse (implied by the mandate) | important | adjacent | medium | transferability | The dbt layer and Snowflake warehouse work carry over. The limit is that you have not used BigQuery, so platform-specific tuning is untested. | `[inferred]` requirement derived from the mandate wording; `[grounded]` your "never used BigQuery"; `[generic]` that warehouse-specific tuning differs by platform | Name the gap openly; see E2 |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in the requirement, and you used it to orchestrate. | `[grounded]` your stated background | A sanitized DAG screenshot would raise it to `high` |
| R9 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. It is specific and confirmed, with no artifact yet. | `[grounded]` your stated background | A sanitized expectation-suite listing would raise it to `high` |
| R10 | Ingestion from app and CRM sources | important | unclear | low | discovery | Your payroll pipelines imply ingestion work, but the sources and who owned the ingestion aren't stated. | `[inferred]` from Airflow use; `[grounded]` background silent on sources | Q G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Your test suite is indirect context. Nothing says whether you agreed schemas or SLAs with downstream consumers. | `[inferred]` from Great Expectations work; `[grounded]` background silent on contracts | Q G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2) | hard_gate | The posting states both terms. Your location and pay floor aren't given. | The posting's wording on both terms can't be fixed by wording. One of them could end the application. | Where you live, whether Denver is an option, your minimum base | Nothing to attach | `[grounded]` posting terms; `[generic]` that unconfirmed terms are the cheapest thing to settle before applying |
| G2 | Ingestion from app and CRM sources (R10, important) | discovery | The CV-level background names orchestration but not what was ingested | Two of the three pillars in the mandate are ingestion and contracts. This is the likeliest probe. | Event or API pulls, a CRM export or sync, a vendor feed you loaded and monitored | An Airflow DAG screenshot or an ingestion runbook | `[grounded]` background silence; `[inferred]` that this is a likely interview probe |
| G3 | Data contracts (R11, important) | discovery | Great Expectations tests exist, but no consumer-facing agreement is stated | Contracts are named in the mandate, and your tests could count as part of them | Schema or freshness agreements with analysts; breaking-change notices; ownership of a shared model | A contract doc, or a test config mapped to a consumer | `[grounded]` background silence; `[inferred]` that tests may partly count |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting match its own site | positive_signal | — | "Accepting applications" | The posting is live and the company's description matches what you pasted | `[grounded]` careers page fetched, about page found | Which team would I join, and who would I report to? | noted |
| RR2 | Pay disclosed and inside the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is transparent and reaches past the report's upper quartile | `[grounded]` posting figure against the report you supplied | Is the figure base salary, and where in the range would my level land? | noted |
| RR3 | Team shape and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the only data engineer, owning ingestion, warehouse and contracts together | `[inferred]` from the mandate's breadth and the posting's silence on team | How many data engineers are on the team, and which of ingestion, modelling and contracts would I own? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | The grant may be thin or its terms unfavourable, or it may simply not be published | `[grounded]` posting silent | What is the equity grant, its vesting and its type? | unresolved |

## Application plan

Every row below, and the advice in this plan, is a proposal pending your approval. Nothing is final until you say so.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the dbt project (about 180 models) and the Great Expectations suite you set up, in your own numbers | R5, R9 | `[grounded]` your stated background | pending your approval |
| E2 | Name BigQuery plainly as the platform you haven't used, and describe Snowflake as the adjacent warehouse. Don't write BigQuery experience anywhere. | R7 | `[grounded]` your "never used BigQuery" | pending your approval |
| Q1 | Ask the verification questions of RR3 and RR4 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Settle G1 first. If both terms hold, apply. | R1, R2 | `[grounded]` rows R1, R2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning Series C $52M tutoring Denver", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Role reality's organization and contradictions rows: the posting is live and matches your paste, so no failed-attribution entry is needed. |
| 2. Role-family sweep | skipped | The report you supplied is in hand and already fixes the market calibration line and the pay comparison in RR2. |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form. |

If you'd like, I can write all of this into a `tuesday-dossier.md`, whenever it suits you.

## Upgrade menu

- Your location and base-pay floor → R1 and R2 close, and the decision likely simplifies to `go` or `no_go`.
- An answer on ingestion (G2) → R10 firms up.
- An answer on data contracts (G3) → R11 firms up.
- A sanitized dbt docs lineage graph, an Airflow DAG screenshot, or an expectation-suite listing → R5, R8 and R9 to `high`.
- The hiring manager's name, if one emerges → role reality's scope read, and which story the plan leads with for that reader.
- A deeper research pass on Pellucid Learning (funding, leadership changes, public employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

G1 — Where are you based (US remote, or would you take Denver), and is $148,000 base at or above your floor?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you personally owned loading data from an application or a CRM into your warehouse? What did you own, and how did you know it worked?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — Have you set expectations with the people who consume your models, such as schemas, freshness or breaking-change notice? What happened when one broke?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.