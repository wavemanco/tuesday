Search permission was declined, so nothing below uses outside research. It rests on the posting and what you told me.

## Decision snapshot

**No, this isn't worth pursuing as posted. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (Base $70–85k), R2 (On-site Austin, five days a week)
- `must_have`: direct: R3a, R4, R5 · unclear: R3b (Leadership within 8+ years), R6 (SEO and content)
- `important`: unclear: R7 (Brand and PR), R8 (Partnerships), R9 (Sales ops), R10 (Team of one)

R3a, R4, R5 — your stated background matches; R3b, R6, R7, R8, R9, R10 — unconfirmed, not shown absent.

**Opportunity ledger.** The posted terms collide with your two constraints (RR1, RR2). The posting's own shape also raises signals: seven functions bundled under one title (RR3), pay set against the seniority asked (RR4), always-on hours (RR5) and success measures left undefined (RR6). Authority and budget are unstated (RR7) and the employer is unverified (RR8). One entry runs the other way: the pay and location terms are stated up front (RR9).

- **Hard gates:** failed: R1 (Base $70–85k), R2 (On-site Austin, five days a week).
- **Severe red flags:** none found.
- **What would change this:** a base at or above your $150k floor (R1) and an arrangement that lets you work remotely from Portland (R2). The employer sets both terms, and no application wording moves either.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one". The profitability claim is unchecked | `[grounded]` JD header; not verified, research did not run |
| Mandate | Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team and resources | "A team of one to start"; budget not stated | `[grounded]` JD |
| Reporting | CEO, dotted line to the board | `[grounded]` JD |
| Working pattern | On-site in Austin 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` JD |
| Compensation | $70–85k base plus "meaningful equity upside" (terms unstated). The top of the band is $65k under your floor, and the bottom is $80k under | `[grounded]` JD and your stated floor |
| Success metrics | Not defined: "will evolve as we learn" | `[grounded]` JD |
| Scope read | A head-of-function mandate across seven functions with no team is broader than a single-channel growth lead | `[inferred]` from the JD's function list against "team of one" |
| Market calibration | Not established. The pay-band search was refused, so I won't give a market figure | `[grounded]` the posted figure only; no band available |
| Unknowns | Budget, hiring plan, equity terms, first-year targets, who the CEO is | `[grounded]` JD silence |
| Contradictions | A "Head of" scope and 8+ years required, set beside a solo seat and a $70–85k base | `[inferred]` from the JD's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base $70–85k plus equity (your floor: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your floor, which is your own, specific and stated. The fit fails because the posted top, $85k, is under it | `[grounded]` JD and your stated constraint | Surface in snapshot; only changed terms or a changed floor resolve it |
| R2 | On-site Austin 5 days a week, "no exceptions" (you: remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint. The fit fails because the posting rules out remote work in plain words | `[grounded]` JD and your stated constraint | Surface in snapshot; only changed terms or a changed constraint resolve it |
| R3a | 8+ years in growth | must_have | direct | medium | none | You state 9 years in growth; confirmed in conversation, no inspectable artifact yet, so expect a probe | `[grounded]` your statement | none |
| R3b | Those years being growth *leadership* | must_have | unclear | low | discovery | You name growth lead then Head of Growth and teams of 3–7, but not how many of the 9 years sat in those roles. Read down to what is stated | `[grounded]` your statement, silent on years per title | none needed to decide |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid. Your $8M to $40M ARR growth over three years with a budget you controlled is for one company and isn't attributed to paid alone | `[grounded]` your statement | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze; confirmed, not yet inspectable | `[grounded]` your statement | none |
| R6 | SEO and content | must_have | unclear | none | discovery | Your summary doesn't mention it. Silence in a short summary isn't absence | `[grounded]` your summary's silence | see G1 |
| R7 | Brand and PR | important | unclear | none | discovery | Not mentioned in your summary | `[grounded]` your summary's silence | see G3 |
| R8 | Partnerships | important | unclear | none | discovery | Not mentioned in your summary | `[grounded]` your summary's silence | see G3 |
| R9 | Sales ops | important | unclear | none | discovery | Not mentioned in your summary | `[grounded]` your summary's silence | see G3 |
| R10 | Running growth as a team of one at first | important | unclear | low | discovery | You built and managed teams of 3–7; whether you've run growth without any team isn't stated | `[grounded]` your statement, silent on solo work | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content (R6, must_have) | discovery | Your summary names paid, lifecycle and experimentation, and not organic | Would not change the status while R1 and R2 stand | Owning a content calendar or organic-traffic targets; briefing writers or an agency; owning a GA4 organic-landing-page report | An organic traffic and revenue export, a content brief, a channel report | `[grounded]` summary silence; `[inferred]` that it cannot move the status |
| G2 | Leadership years (R3b, must_have) | discovery | 9 years in growth with lead and Head titles, and no split by title | A direct match on the posting's 8+ years is unconfirmed | Dates and titles at each company; when you started line-managing | Dated titles on a CV or profile | `[grounded]` your statement; `[inferred]` limited decision impact |
| G3 | Brand, PR, partnerships, sales ops (R7, R8, R9, important) | discovery | Nothing stated on any of the four | Four of the seven functions in the mandate are unevidenced | Co-marketing or integration partnerships you set up; press or launch work you owned; CRM-to-sales handoff or lead-routing work | A partner deal summary, a launch plan, a routing spec | `[grounded]` summary silence; `[inferred]` limited decision impact |
| G4 | Solo operation (R10, important) | discovery | Team-building evidence only | The role starts with no bench | Early-stage stints where you ran channels yourself | A dated role description | `[grounded]` your statement; `[inferred]` limited decision impact |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay below your floor (R1) | red_flag | medium | "$70–85k base plus meaningful equity upside" | Incompatible with your stated floor. Severity is medium because the incompatibility is carried by gate R1, not by the posting's quality | `[grounded]` JD figure against your constraint | What are the equity terms (share, vesting, strike) behind "meaningful equity upside"? | confirmed |
| RR2 | On-site five days (R2) | red_flag | medium | "On-site in our Austin office 5 days a week — no exceptions." | Incompatible with your remote-only constraint; carried by gate R2 | `[grounded]` JD against your constraint | How many people sit in the Austin office today, and who would I work beside? | confirmed |
| RR3 | Bundled specializations | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops" | Several roles may be folded into one title with no team | `[inferred]` from the function list against "team of one" | Which of these functions would you staff first, and with what budget? | unresolved |
| RR4 | Pay against seniority asked | risk_signal | medium | "8+ years growth leadership required" beside "$70–85k base" | The pay may sit below what this seniority and mandate command. Not confirmed, because the band check did not run | `[inferred]` from the posting's own terms | How was the band for this role set? | unresolved |
| RR5 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine rather than exceptional | `[inferred]` from "just who we are" | How often last quarter did the team work evenings or weekends, and why? | unresolved |
| RR6 | Success measures undefined on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be accountable for all revenue growth without a fixed yardstick | `[inferred]` from the JD's silence on targets | What revenue or growth targets will the CEO hold this role to in year one? | unresolved |
| RR7 | Authority and resources unstated | unknown | — | "You will be a team of one to start"; "dotted line to the board" | Budget, hiring plan and decision rights may be unsettled | `[inferred]` from silence | What budget and headcount are committed for this role? | unresolved |
| RR8 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would interview with? | unresolved |
| RR9 | Pay and location stated up front | positive_signal | — | "Compensation: $70–85k base… On-site in our Austin office 5 days a week" | The conflict shows before you invest effort | `[grounded]` JD | Is the posted band the full cash range, bonus included? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't spend application effort on this posting as written | see R1, R2 | `[grounded]` map rows | proposed, pending your approval |
| P2 | Point your search at roles that post a base at or above $150k and allow remote work from Portland | see R1, R2 | `[grounded]` your constraints | proposed, pending your approval |
| P3 | If you proceed anyway, ask RR3, RR4, RR5, RR6 and RR7 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | proposed, pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused at the permission prompt. It would have moved role reality's organization and contradictions rows and RR8 |
| 2. Role-family sweep | unavailable | The search was refused at the permission prompt. It would have moved role reality's market calibration and RR4 |
| 3. Hiring manager's public footprint | n/a | The posting names no one, only "the CEO" |

Dossier offer: if you'd like this saved as a `tuesday-dossier.md` to carry forward, say so and I'll write it.

## Upgrade menu

- Search permission: the employer check (RR8, organization row) and the pay-band check (RR4, market calibration) would run.
- A link to the live posting or Novaline's own careers page: closes or sharpens RR8.
- Dates and titles for each company: settles R3b.
- Any SEO or content, brand or PR, partnership, sales-ops, or solo-operator work: updates R6, R7, R8, R9 and R10 respectively.
- A sanitized channel P&L, the board-level growth model behind the $8M to $40M ARR, or a Braze program export: raises R4, R5 and R3a toward `high`.
- The CEO's name: sharpens the scope read.

Questions: none this turn. Nothing you could answer would move the decision, which rests on R1 and R2.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.