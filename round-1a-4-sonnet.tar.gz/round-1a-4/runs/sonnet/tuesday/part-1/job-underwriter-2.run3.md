Working from your resume and the JD only. The web searches were declined, so nothing here is checked against Quartzline itself.

# Job Underwriting Assessment: Product Manager, Platform APIs at Quartzline

## Decision snapshot

**No, the pivot isn't a waste of your time, but this posting is a stretch, not a fit. R1a (3+ years titled PM experience) is absent and R1b (PM-function work) is adjacent. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — adjacent: R1b (PM-function work) · absent: R1a (3+ years titled PM experience)
- `important` — direct: R3, R4a, R6 · adjacent: R2 (Shipped API or platform products), R7a (Write specs), R7b (Own the roadmap), R9 (Coordinate launches) · unclear: R4b (Stakeholder work with sales), R5 (Agile delivery), R8 (Adoption metrics)

R1a — titled years absent, which wording cannot close; R1b (`medium`) — real PM-function work, its limit named; R8 — waiting on the G1 answer.

**Opportunity ledger.** The scope is concrete and sits close to your integration background (RR4). The employer is unverified because research was refused (RR1), and pay (RR2) and level and reporting line (RR3) are unstated.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Quartzline confirms the 3+ years bar accepts equivalent product work (R1a, R1b). (2) The role and employer verify as live and real (RR1). (3) Your G1 answer shows product ownership, which would firm up R2, R8 and R1b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header; not independently checked |
| Mandate | Own the roadmap for the partner-facing API platform; run discovery with integration partners; write specs and drive delivery with two engineering squads; define and track adoption metrics; coordinate launches with sales and support | `[grounded]` JD |
| Stated bar | Only "3+ years product management experience" is marked must-have; the other requirements are listed without a tier | `[grounded]` JD |
| First-year outcomes | Not stated; "adoption metrics" are named as a task with no target | `[inferred]` from the JD listing the task and giving no target |
| Scope read | One platform and two squads is a bounded remit | `[inferred]` from the stated squad count |
| Market calibration | Not done: the role-family sweep did not run, so no pay or scope band is stated | `[grounded]` the search was refused |
| Unknowns | Level, reporting line, pay, location or remote policy, how adoption is defined | `[grounded]` JD silence |
| Contradictions | None found within the JD and your resume; the title gap is a fit matter (R1a) | `[grounded]` both documents |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, as titled PM years | must_have | absent | none | capability | You say you have never held a PM title, so titled years are zero. How literally Quartzline reads the bar is unknown | `[grounded]` your statement of no PM title; `[generic]` that some screens read titles literally | Ask how the bar reads for equivalent work (A1); carry as a material risk |
| R1b | Same requirement, PM-function work | must_have | adjacent | medium | transferability | Roadmap-input sessions and requirements documents, alongside PMs on custom builds, are product-adjacent. Limit: you gathered input and coordinated; you did not decide priorities | `[inferred]` adjacency from those two activities in your resume prose | G1; record any formal PM duties it turns up |
| R2 | Shipped API or platform products | important | adjacent | medium | transferability | You led 30+ client integrations of your company's REST APIs and wrote the team's integration playbook. That is delivering on an API, not releasing one. Limit: no stated part in shipping the API or platform | `[inferred]` adjacency from the integrations and playbook | G1; a sanitised copy of the playbook is an inspectable artifact |
| R3 | Technical fluency: API docs and schemas | important | direct | medium | none | Postman, SQL, reading OpenAPI specs and 30+ end-to-end integrations. Confirmed in prose only, so expect a probe | `[grounded]` resume prose | A sanitised integration architecture diagram would raise this to `high` |
| R4a | Stakeholder management across engineering and customers | important | direct | medium | none | You coordinated your own engineers, client engineers and PMs, and ran scoping workshops | `[grounded]` resume prose | none |
| R4b | Stakeholder management with sales | important | unclear | low | discovery | The resume says nothing about working with sales | `[grounded]` resume silence | G3 |
| R5 | Agile delivery | important | unclear | low | discovery | The resume does not say how delivery was run, whether sprints, a backlog or another method | `[grounded]` resume silence | G2 |
| R6 | Run discovery with integration partners | important | direct | medium | none | Scoping workshops and quarterly roadmap-input sessions are discovery. The one difference is that your counterparts were clients rather than integration partners | `[grounded]` resume prose | none |
| R7a | Write specs | important | adjacent | medium | transferability | You wrote requirements documents for client integrations. Limit: those were client-specific, not a product spec for squads to build from | `[inferred]` adjacency from the requirements documents | G1 |
| R7b | Own the roadmap and drive delivery with two squads | important | adjacent | medium | transferability | `medium` grades the stated roadmap-input sessions. Limit: you do not claim roadmap ownership or squad delivery | `[inferred]` adjacency from the roadmap-input sessions | G1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | You list SQL but no adoption tracking. A recalled lead exists and is not evidence until you confirm it (G1) | `[grounded]` resume silence | G1 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | You ran UAT and go-lives for client integrations. Limit: those are per-client launches; coordinating a product launch with sales and support is not stated | `[inferred]` adjacency from the go-live work | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owned a product or tool, with adoption (R2, R8, R1b) | discovery | No tool or product of yours that others adopted appears in the resume | Answers here could move R2, R8 and R1b, the best chance of narrowing R1a's weight | An internal tool you scoped, built or configured that colleagues adopted; usage you measured in SQL; a call on what went into a release | Usage numbers, a one-page brief, a release note, a dashboard screenshot | `[grounded]` resume silence; `[inferred]` that answers here could move those rows |
| G2 | Agile delivery (R5) | discovery | Delivery method is not stated | An `important` row that a short answer could settle | Sprints or a backlog with the engineering team on a custom build; a planning or review ceremony you ran or attended | A board export or sprint notes | `[grounded]` resume silence |
| G3 | Sales and support launch work (R4b, R9) | discovery | Go-lives are stated; sales and support involvement is not | Two rows currently unclear or adjacent | Joint client calls with account executives; handing a go-live to support; enablement notes for support | A handoff checklist or runbook | `[grounded]` resume silence |
| G4 | Titled PM years (R1a) | capability | No PM title held | The only `must_have` row at `absent`; no recall prompt changes it | A formal product-owner or acting-PM period would be discovery; otherwise none | A written statement from the employer that equivalent work counts | `[grounded]` your statement of no PM title |

G4 carries no question. Its closure path is an internal move or a role that counts product work, and meanwhile it stays a material risk.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The searches were refused, so nothing was checked | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay unstated | unknown | — | The posting as provided states no pay | The range may sit above or below your expectation; no band was checked | `[grounded]` JD silence | What range is budgeted for this role? | unresolved |
| RR3 | Level and reporting line unstated | unknown | — | "Own the roadmap for our partner-facing API platform" | "3+ years" may be a floor for a mid-level post or a target for a senior one | `[inferred]` from the JD's silence on level | What level is this role, who does it report to, and how much of the roadmap does it decide versus the squad leads? | unresolved |
| RR4 | Concrete, bounded scope | positive_signal | — | "run discovery with integration partners; … drive delivery with two engineering squads; define and track adoption metrics" | Scope is specific, and it overlaps your integration work | `[grounded]` JD scope; `[inferred]` the overlap with your resume | How is adoption measured today, and what is the first-year target? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lift the roadmap-input sessions, requirements documents and playbook higher in the resume, keeping your own verbs ("collected client feedback for product", "wrote requirements documents"). Do not write "owned the roadmap" or claim PM experience | R1b, R2, R7a | `[grounded]` your resume prose | pending your approval (`resume_edits_pending_approval`) |
| A1 | Before investing in a full application, ask the recruiter whether "3+ years" accepts equivalent product work in place of a PM title | R1a | `[grounded]` R1a | pending your approval |
| A2 | Seek an introduction or referral, so a person reads your history before a title filter does | R1a | `[generic]` how hiring often works, not a fact about Quartzline | pending your approval |
| Q1 | Ask RR1 to RR4's questions verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

If you decide to apply, resume-tailor can turn E1 into an approve-first edit ledger.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (Quartzline's business, and its careers page for this role) were refused because search permission was not granted. They would have fed role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | One search (pay and scope for this kind of role) was refused for the same reason. It would have fed market calibration and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

**Offer beyond this assessment:** a short comparison of this stretch role against role shapes that read your background more directly, since R1a decides this one. Say yes and I'll build it.

I can save this as `tuesday-dossier.md` if you want other modules to build on it.

**Upgrade menu**
- Allowing web search would let the employer and posting check run (RR1) and add a pay and scope band (RR2).
- An answer to G1, plus a usage number or one-page brief, would firm up R2, R8 and R1b.
- An answer to G2 would settle R5, and an answer to G3 would settle R4b and R9.
- A sanitised copy of your integration playbook or an architecture diagram would raise R3 to `high`.
- The recruiter's answer on the 3+ years bar (A1) would settle how much weight R1a carries.
- The hiring manager's name would feed role reality and the plan's positioning.

**Questions**

G1 — My notes suggest you may once have built an internal request-triage tool that support agents adopted. I can't treat that as fact until you confirm it. Is that right? If so, what was yours versus the team's, did it reach real users, and how did you know it was used? If not, have you scoped or built any tool that others adopted?

G2 — On any custom build, did you work from a backlog or in sprints with an engineering team, and what was your part?

O1 — What are your non-negotiables on location or remote work, and on pay floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.