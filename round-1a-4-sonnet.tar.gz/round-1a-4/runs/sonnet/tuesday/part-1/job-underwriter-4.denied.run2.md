Web search was refused in this session, so I ran this on what you pasted. The three research targets show as unavailable below.

## Decision snapshot

**Yes, go for it: apply once the employer and posting verify. Status: `conditional_go`.** R2, R3, R4, R5a, R6 and R7 are `direct`, and R5b is still open.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5a, R6, R7 · unclear: R5b (Monitor rating models)
- `important`: unclear: R8 (Recommendations to product)
- `preferred`: direct: R9 · adjacent: R10 (Pet-insurance domain)

R5b: "maintained" is stated and monitoring is not; R10: a credible bridge with its limit named; R1: assumed from a UK employer history, never stated.

**Opportunity ledger.** The duties are clearly written and a hiring manager is named (RR4). The employer could not be checked (RR1), the salary is not stated (RR2), and team scope is unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and the live posting verify on Brindlemoor's own careers page (RR1); (2) R1 is confirmed; (3) the pet-insurance bridge is framed as adjacent, never as pet expertise (R10).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; its existence as described is not established | `[grounded]` JD header; not checked |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` your message |
| Scope read | The JD covers the whole analytics loop for one product. Whether this is a solo seat or a team lead is not stated | `[inferred]` from the duties listed against silence on reports |
| Market calibration | Not run, because search was refused. No band is offered | `[grounded]` search refused |
| First-year outcomes | Not stated in the JD | `[grounded]` JD silence |
| Unknowns | Salary, direct reports, who decides on pricing recommendations, contract type | `[grounded]` JD silence |
| Contradictions | None inside the JD; JD against careers page not checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (your location is not stated) | hard_gate | unclear | low | hard_gate | You have worked at a UK insurer, but residence and right to work were never stated. Nothing settles the gate | `[grounded]` JD; your background says nothing on location | Question G3 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You stated 5 years of pricing analytics, the last 2 as senior analyst. No document inspected | `[grounded]` your background | Dated CV or LinkedIn would raise it |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. Strength is not shown by any artifact | `[grounded]` your background | A sanitized query or notebook would raise it |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. No inspectable artifact | `[grounded]` your background | A model-documentation excerpt would raise it |
| R5a | Build rating models | must_have | direct | medium | none | The same young-driver GLM, stated as built by you. The scope of your ownership within the team is not stated | `[grounded]` your background | Same as R4 |
| R5b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained", and no monitoring practice is stated. I won't assume one | `[grounded]` your background | Question G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | 14 price tests last year, run with the underwriting team. Your own part in design versus analysis is not split out | `[grounded]` your background | A sanitized test write-up would raise it |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD says "or", so one audience meets it | `[grounded]` your background | A review deck excerpt would raise it |
| R8 | Turn results into recommendations for product | important | unclear | low | discovery | Underwriting-facing work is stated. Product-facing work is not | `[grounded]` your background silent on product | Question G2 |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R10 | Pet-insurance domain (inferred from "for our pet-insurance product") | preferred | adjacent | medium | transferability | You confirmed you have never worked on pet insurance. The carry-over is GLM pricing and test work in another line. Limit: no pet-specific rating factors exercised | `[grounded]` your statement; `[generic]` that pet pricing uses its own rating factors | Name the bridge and its limit in the application |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Monitoring rating models (R5b, must_have) | discovery | "Maintained" the GLM, with no stated tracking of its performance over time | It is a must-have row and the first duty in the JD, so an answer could close it | Actual-versus-expected tracking, drift or stability checks, recalibration triggers, a monitoring dashboard, a refit after a performance dip | A sanitized monitoring pack or dashboard screenshot | `[grounded]` your background silent on monitoring; `[inferred]` that an answer closes the row |
| G2 | Recommendations to product (R8, important) | discovery | Underwriting-facing recommendations only | The JD names product as a recommendation audience | A pricing proposal taken to a product or commercial team, a test result that changed a product feature or tier | A recommendation memo or deck excerpt | `[grounded]` your background silent on product |
| G3 | UK-based and eligible to work remotely there (R1, hard_gate) | hard_gate | The JD says fully remote (UK), and your location is not stated | It is a gate row, so it stays visible until settled | None. This asks whether the gate is met | None needed | `[grounded]` JD; your background |
| G4 | Pet-insurance domain (R10, preferred) | transferability | Motor pricing only | It is the likeliest objection to your application | Any rating or test work on a line with its own risk factors, such as young-driver age and vehicle factors | A short note mapping your rating factors to pet factors, which you would write | `[inferred]` bridge from motor to pet; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The check could not run here | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would interview with? | unresolved |
| RR2 | Salary not stated | unknown | — | no pay figure in the JD | The figure may sit anywhere against what you would accept | `[grounded]` JD silence; no band available, as search was refused | What salary range is budgeted for this post? | unresolved |
| RR3 | Reports and decision rights unstated | unknown | — | "Own pricing analytics" | The seat may be a solo analyst or may lead others. It is also unclear who decides on your recommendations | `[inferred]` from "own" and "recommendations" against silence on reports and authority | Does this role have direct reports, and who decides on its pricing recommendations? | unresolved |
| RR4 | Duties and manager are explicit | positive_signal | — | "build and monitor rating models, design and read price tests" | The scope is defined, and a named Director of Pricing owns it | `[grounded]` JD and your message | Who owns the first pricing priorities for this product? | noted |

Hold any application effort beyond the first submission until you have found the role on Brindlemoor's own careers site, using contact details from that site.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the GLM rating model you built and maintained for the young-driver book, then the 14 price tests run with underwriting last year | see R4, R5a, R6; both lines are your own sentences | `[grounded]` your background | pending your approval |
| A2 | Say plainly: "I haven't worked on pet insurance. I built and maintained the GLM rating model for a young-driver motor book." | see R10: adjacent, limit named | `[grounded]` your statements | pending your approval |
| A3 | Confirm the role on Brindlemoor's own careers page before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| A4 | Ask RR2 and RR3 verbatim in the first conversation | the register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | If asked about managing people, say you haven't. The JD lists no management requirement | see RR3; no row asks for it | `[grounded]` JD and your statement | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Brindlemoor pet insurance insurtech careers" was refused. It would have moved RR1 and role reality's organization row |
| 2. Role-family sweep | unavailable | The search "senior pricing analyst insurance UK salary remote" was refused. It would have moved market calibration and RR2 |
| 3. Hiring manager's public footprint | unavailable | The search "Odile Varga Director of Pricing Brindlemoor" was refused. It would have moved the scope read and A1's positioning |

Unverified leads: none. Rejected inferences: none.

I can write this assessment to `tuesday-dossier.md` if you want a record to carry forward.

## Upgrade menu

- Allowing web search lets the three research targets run. That would settle RR1 and could close RR2.
- An answer to G1 moves R5b.
- An answer to G2 moves R8.
- A sanitized SQL or Python sample, a GLM documentation excerpt, or a test write-up raises R3, R4 and R6 toward `high`.
- Your pay floor and location would turn R1 into a checked gate and let RR2 be compared against it.

**Questions**

G3: Are you based in the UK and able to work there remotely?

G1: Did you track the young-driver GLM's performance after launch, for example actual versus expected, drift, or refit triggers? What was yours to do, and what did it lead to?

G2: Have you taken test results or pricing proposals to a product or commercial team, not only to underwriting? What did you own, and what changed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.