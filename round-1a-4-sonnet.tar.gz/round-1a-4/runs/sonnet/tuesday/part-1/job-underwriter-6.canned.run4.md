I've read the posting and run three searches. I'm making one last check of Quillfield's own careers page, then I'll write the assessment.
## Decision snapshot

**Yes, go for it, with conditions. Status: `conditional_go`.** You have a direct fit on the core operator skills (R3, R4, R5). Your two real gaps are forecast ownership (R6) and billing data (R7b), and the posting makes both central to the job.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3, R4, R5 · adjacent: R6 (Owning a forecast) · unclear: R7a (Working with finance on revenue data) · absent: R7b (Billing data)
- `important` — direct: R8

R6 — a credible bridge, its limit named; R7b — no billing evidence, so a closure path rather than a framing fix; R1 and R2 — waiting on your constraints.

**Opportunity ledger.** The role is priced inside the market band (RR3) at an employer that exists as posted (RR6). The unknowns are who owns the forecast number (RR1), whether the posting appears on Quillfield's own site (RR4) and the share-option terms (RR5). The scope is wide for one seat (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 meet your own constraints; (2) you present R6 as adjacent and R7b as a gap you are closing, never as owned experience; (3) RR1 verifies in the early conversations: you need to know whether you or the Head of Revenue Operations carry the forecast number.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. It was founded in 2018 in Bristol, has 96 employees, and closed a £11M Series A in April 2025 | `[grounded]` "About Quillfield" page |
| Mandate | Own CRM and billing data, build the pipeline and renewal reporting that sales and finance run on, and run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week. £61,500–£67,000 plus share options | `[grounded]` posting |
| Reporting line | Your recruiter names Tamsin Achebe as hiring manager. Her public profile reads Head of Revenue Operations at Quillfield, so this seat probably reports to her | `[grounded]` your recruiter and the profile page; `[inferred]` the reporting line, since the posting states none |
| Scope read | CRM, billing data, two reporting suites and a CFO-facing forecast sit under one "Lead" title, with no team size or first-year outcomes stated | `[inferred]` from the posting's list against its silence on team and outcomes |
| Market calibration | Ledgerline's 2026 UK guide gives a median base of £64,200 for revenue operations lead roles in B2B software (n=438), with an interquartile range of £57,800–£70,400. The posting's £61,500–£67,000 sits inside that range, so the pay looks market-normal rather than low. This is a national band and not Bristol-specific, and I read only the search snippet | `[generic]` Ledgerline snippet; `[grounded]` the posting's own figure |
| Unknowns | Who owns the forecast number; team size; first-year outcomes; option terms | — |
| Contradictions | None found, but I could not check the posting against Quillfield's careers page (RR4) | `[grounded]` the careers fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You have given no location or office-day constraint, so no claim exists. Fit stays `unclear` until you answer | `[grounded]` posting; no candidate statement | Ask whether this works (closing question) |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | You have given no pay floor. The band is in the posting; whether it meets your floor is unknown | `[grounded]` posting; no candidate statement | Ask (same closing question) |
| R3 | 4+ years in revenue operations, sales operations or similar at a B2B software company | must_have | direct | medium | none | You describe 5 years in sales operations, the last 2 running revenue operations for the UK team. That is self-reported with nothing inspected. You called your employer a B2B payments company; whether its product is software is not stated, so expect that to be asked | `[grounded]` your intake message, as self-report | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | You hold the Salesforce admin certification. It is stated but not inspected | `[grounded]` your intake message | The certificate or a credential link would raise this to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly and Excel daily is specific. "Strong" and "modelling" are not shown by anything you described yet, so expect a probe | `[grounded]` your intake message | A sanitized model or query you wrote would raise this |
| R6 | Experience owning a forecast; run the quarterly revenue forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which is close to forecast inputs. Limit: you have never owned the company forecast, because finance did that, so the CFO-facing part is untested | `[grounded]` your intake message; the limit is your own statement | G1 |
| R7a | Experience working with finance on revenue data (the posting says "billing or revenue") | must_have | unclear | low | discovery | You rebuilt renewal dashboards, which are revenue data. You did not say whether finance used them or worked with you on them | `[grounded]` your intake message; the finance link is not established | G2 |
| R7b | Billing data: "own our CRM and billing data" | must_have | absent | none | capability | You said you have never worked on billing data. The posting's "billing or revenue" wording may let R7a carry part of this, but the ownership line in the mandate is stricter | `[grounded]` your statement and the posting's wording | G3 |
| R8 | Build the pipeline and renewal reporting that sales and finance run on | important | direct | medium | none | You rebuilt your pipeline and renewal dashboards. How widely finance used them is not stated (see R7a) | `[grounded]` your intake message | A sanitized dashboard screenshot would raise this to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R6, must_have) | transferability | You run the monthly pipeline review, but finance produced the forecast | The posting makes the forecast a headline duty with the CFO, so this is the objection most likely to come up | Calling commit or best-case numbers into the pipeline review; building the pipeline-to-forecast roll-up finance used; flagging a quarter's slippage ahead of finance | A sanitized pipeline-review deck or roll-up sheet | `[grounded]` your statement that finance owned it; `[generic]` that a forecast-owner requirement is probed hard |
| G2 | Working with finance on revenue data (R7a, must_have) | discovery | Renewal dashboards exist, but finance's involvement is unknown | Resolving it could lift R7a, and it would back your answer on R7b | Reconciling renewals to invoices or contract values with finance; a shared definition of ARR or renewal rate; finance reviewing your dashboards | A definitions doc, a reconciliation sheet or a dashboard screenshot | `[grounded]` your intake message is silent on finance |
| G3 | Billing data (R7b, must_have) | capability | No billing evidence and none adjacent beyond G2 | It is a `must_have` row and part of the mandate | Only G2's work could bridge it. Otherwise this is carried as a risk, with a closure path such as learning how the billing system's exports, invoices and credit notes reach the CRM | n/a | `[grounded]` your statement that you have never worked on billing data |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The Head of Revenue Operations may also own or share the forecast, so this seat could be support or full ownership | `[inferred]` from the posting's duty against the hiring manager's title | Who owns the forecast number, this role or the Head of Revenue Operations, and how is it split with the CFO? | unresolved |
| RR2 | Wide scope for one seat | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting… run the quarterly revenue forecast" | Five duties under one title, with no team size stated, may mean more than one person's work. I put it at `low` because the posting may simply describe a small team | `[inferred]` from the posting's duty list against its silence on team | What does the team around this role look like, and who handles billing data day to day? | unresolved |
| RR3 | Pay stated and inside the band | positive_signal | — | "£61,500–£67,000" | The range sits inside the market interquartile range, so it is not a mismatch with the title | `[grounded]` the posting's figure; `[generic]` Ledgerline's band | Where in the range does this role usually hire? | noted |
| RR4 | Posting not found on Quillfield's own site | unknown | — | Tallyboard listing 2291 | The careers page I tried returned nothing. The role may be listed at another address, or the listing may be a copy | `[grounded]` the careers page returned no page; the reasons stay side by side, none likely | Can you point me at this role on Quillfield's own careers site? | unresolved |
| RR5 | Share options unspecified | unknown | — | "plus share options" | The size, vesting and strike terms are not stated | `[grounded]` the posting is silent | What is the option grant, the vesting schedule and the strike price? | unresolved |
| RR6 | Employer exists as posted | positive_signal | — | "invoicing software company" | Quillfield's own page matches the product, city and a Series A in April 2025 | `[grounded]` "About Quillfield" page | Who would I work with day to day? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Tell the pipeline and renewal dashboard rebuild and the monthly pipeline review you run, in your own words and with the numbers you can stand behind | These are R8 and the nearest evidence for R6 | `[grounded]` R6, R8 | pending your approval |
| A2 | Say plainly in any screen that finance has owned the forecast and that you have not worked on billing data, then offer the adjacent work | A precise limit reads stronger than an overstated claim, and the posting makes both duties central | `[grounded]` R6, R7b | pending your approval |
| A3 | Ask RR1 and RR2 verbatim in the first conversation | They decide how much of the forecast is yours | `[grounded]` register | pending your approval |
| A4 | Ask the recruiter for the live careers-site link (RR4) before you invest in a tailored application | It closes one unknown cheaply | `[grounded]` RR4 | pending your approval |
| A5 | With Tamsin Achebe, expect operator-level detail on your dashboards. Her public profile shows a path through sales operations at a payments company and then revenue operations | Her background makes dashboard detail a conversation she can follow. I am not guessing what she wants | `[grounded]` her profile page; `[inferred]` the reading | pending your approval |

Extra, offered and not built unless you approve: a one-page note setting out what you would say on R6 and R7b, audited line by line against your own sentences, since those are where an interviewer is most likely to press.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers and got no page. Role reality's organization row and RR6 are established. RR4 is unresolved because the posting could not be matched to an official listing |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary Bristol UK B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example). I used the snippet only. Role reality's market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Role reality's reporting-line row, RR1 and A5 |

I can turn this into a `tuesday-dossier.md` if you want to carry it into interview prep later.

## Upgrade menu

- Your CV, which would confirm R3, R4, R5 and R8 against the page and let me propose edits.
- A sanitized dashboard screenshot or pipeline-review deck, which would raise R8 and R5 toward `high`.
- Your answers to G1 and G2, which could move R6 and R7a.
- Your location and pay floor, which would settle R1 and R2.
- The recruiter's answers on reporting line and the live careers link, which would close RR1 and RR4.
- A deeper research pass on Quillfield (funding and leadership changes, recent news, public employee reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

1. R1 and R2 — Do two office days a week in Bristol and a £61,500–£67,000 range both work for you?
2. G1 — Have you ever produced or called forecast numbers, even as an input to finance's forecast? What did you own, who used it, and how did it compare with the outcome?
3. G2 — Has finance worked with you or used your renewal dashboards, for example on renewal values or invoice reconciliation? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.