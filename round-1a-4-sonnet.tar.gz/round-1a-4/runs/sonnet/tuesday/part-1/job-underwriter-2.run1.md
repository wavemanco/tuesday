**Decision snapshot**

**It isn't a waste of your time to explore this pivot, but this role is a stretch. R1a (3+ years of titled PM experience) is absent and R2b (shipped product) is unclear. Status: `hold_pending_answers`.**

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1b (PM-adjacent work), R2a (API-side work), R4 (stakeholders incl. sales) · unclear: R2b (shipped product), R5 (agile delivery) · absent: R1a (3+ years titled PM)
- `important` — direct: R6 · adjacent: R7 (roadmap, specs, delivery), R9 (launches with sales and support) · unclear: R8 (adoption metrics)

R1a — absent, with R1b as the nearest bridge; R2b — waiting on your answer.

**Opportunity ledger.** The employer is unverified because research was refused (RR1). Whether the years requirement is firm is unknown (RR2), and pay is unstated (RR3). One entry runs the other way: the responsibilities are concretely listed (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a confirmed, specific answer to G1 or G2 would move R2b or R7 toward `adjacent` or `direct`, which would likely lift this to `conditional_go`. If neither holds, you can still apply, but expect R1a to be the screening risk. `no_go` isn't warranted, because no gate fails and the years requirement is graded as a requirement, not a gate.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B. Not verified (see Evidence status) | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; partner discovery; specs; delivery with two squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Scope read | One product surface, two squads and a single PM owner: a real ownership role, not a coordination-only one | `[inferred]` from the JD's "own the roadmap" against its two-squad scope |
| Compensation | Not stated | `[grounded]` JD silent; no band researched, so nothing to calibrate against |
| Unknowns | How firm "3+ years" is; decision rights versus sales and leadership; pay; success metrics for year one | `[grounded]` JD silent on each |
| Contradictions | None inside the JD | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience (titled) | must_have | absent | none | capability | You say you have never held a PM title. A years requirement is graded as a requirement, not a gate. `[generic]` Screens often read titled years literally | `[grounded]` your statement; `[generic]` screening pattern | Name the closure path openly (see A5); no claim of PM years |
| R1b | PM-adjacent work counted toward the same requirement | must_have | adjacent | medium | transferability | Roadmap-input sessions, requirements documents and coordinating PMs on custom builds are real adjacency. Limit: the resume shows no owned prioritisation, roadmap or product outcome | `[grounded]` CV claims; confirmed in prose, no artifact | G2 |
| R2a | Shipped API or platform products: API-side | must_have | adjacent | medium | transferability | 30+ end-to-end integrations of your company's REST APIs plus the playbook show deep consumer-side knowledge. Limit: integrating an API is not shipping one | `[grounded]` CV | Offer the playbook as an inspectable artifact |
| R2b | Shipped API or platform products: a product others adopted | must_have | unclear | low | discovery | Nothing confirmed. A memory lead suggests an internal triage tool adopted by support agents; it is a lead, never evidence | `[inferred]` from an unconfirmed memory lead | G1 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading, with 30+ integrations behind them. Medium because no artifact has been inspected | `[grounded]` CV | Offer the playbook (sanitized) to raise to high |
| R4 | Stakeholder management across engineering, sales and customers | must_have | adjacent | medium | discovery | Engineers, client engineers, clients and PMs are covered. Sales and support are not mentioned in your resume | `[grounded]` CV; silence on sales | Ask later whether sales or support were ever in your loop |
| R5 | Agile delivery | must_have | unclear | low | discovery | Resume is silent on sprints, backlogs or squads | `[grounded]` CV silence | Not asked this turn (see G4) |
| R6 | Run discovery with integration partners | important | direct | medium | presentation | Scoping workshops and quarterly client feedback sessions are discovery work. The partner-discovery framing can lead your resume | `[grounded]` CV | A1 |
| R7 | Own roadmap, write specs, drive delivery with squads | important | adjacent | medium | transferability | Requirements documents and engineer coordination carry over. Limit: you fed the roadmap and did not own its priorities | `[grounded]` CV | G2 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | SQL skill is stated; no metric you defined or tracked is | `[grounded]` CV | G3 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Client go-lives are launches of a kind. Limit: they are per-client rollouts, not product launches | `[inferred]` from the go-live work described | Ask later |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product others adopted (R2b, must_have) | discovery | An unconfirmed lead about an internal request-triage tool; nothing on its scope, ownership or adoption | It is the only thread toward "shipped a product", and it could move a must-have | A tool or process you designed that support, ops or clients used; a template or playbook with measurable uptake; an internal feature you specified that engineers built | Usage figures, a screenshot, a short write-up, or the spec | `[inferred]` from a memory lead; `[generic]` that adoption evidence matters for this requirement |
| G2 | Ownership of prioritisation (R7, R1b) | transferability | Roadmap input gathered; nothing showing a decision about what got built | Separates "worked with PMs" from "did the PM's job" | Ranking client requests that reached engineering; scoping a custom build's must-haves versus later; a spec you owned that shipped | A requirements document (sanitized), a backlog or ticket thread | `[grounded]` CV; `[generic]` that this is the usual line interviewers probe |
| G3 | Adoption metrics (R8, important) | discovery | SQL stated; no metric defined or tracked | A named metric you tracked would answer an explicit responsibility | Time-to-go-live, integration success rate, repeat-issue counts, playbook usage | A query, dashboard screenshot, or a before-and-after figure | `[grounded]` CV silence |
| G4 | Agile delivery (R5, must_have) | discovery | Resume is silent | A must-have with no evidence either way | Sprint ceremonies you joined, backlog grooming with squads, release cadence | A ticket board screenshot or sprint notes | `[grounded]` CV silence. No question this turn: the budget goes to higher-impact rows |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The company may be too new or small for a footprint, the posting may be stale, or it may not represent a live hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who I would interview with? | unresolved |
| RR2 | Firmness of the years requirement unknown | unknown | — | "3+ years product management experience (must-have)" | The requirement may be flexible for strong adjacent work, or may be a literal screen | `[generic]` hiring patterns differ by company; `[grounded]` JD wording | Would adjacent experience owning API integrations and product feedback count toward the 3+ years? | unresolved |
| RR3 | Compensation unstated | unknown | — | no figure in the JD | Pay is withheld or was omitted from what you pasted | `[grounded]` JD silent | What is the budgeted range for this role? | unresolved |
| RR4 | Responsibilities concretely listed | positive_signal | — | "Own the roadmap for our partner-facing API platform … two engineering squads" | Scope and ownership are clear | `[grounded]` JD | Who sets roadmap priority when partner requests conflict with sales commitments? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reorder the resume to lead with partner discovery, the roadmap-input sessions and the integration playbook; keep your real title visible. `resume-tailor` can draft the wording once you decide | R6, R7, R1b | `[grounded]` CV | pending your approval |
| A2 | Say in your note that you have not held a PM title and describe the work as you did it: coordinating product managers on custom builds and feeding product roadmap input | R1a, R1b | `[grounded]` your statements | pending your approval |
| A3 | Ask RR2's question of the recruiter before investing in the full loop | RR2 | `[grounded]` register | pending your approval |
| A4 | Seek an introduction or a short conversation with someone on the platform team before applying cold | Referrals often help borrowed-experience candidates | `[generic]` role-family pattern | pending your approval |
| A5 | If G1 and G2 don't strengthen your case, treat this as a stretch application and also target PM roles that don't require titled years | R1a is `capability`; closing it takes a titled role | `[generic]` role-family pattern | pending your approval |

Beyond the spec, I can offer a short work sample: a one-page roadmap and spec for a hypothetical partner-API feature built from your integration experience. It would add inspectable evidence for R7 and R3. I'll build it only if you approve.

## Evidence status

Verified: none yet. An earlier-conversation lead about an internal triage tool is unconfirmed and prompts G1 only.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Quartzline logistics technology Series B partner API platform" was refused (permission not granted). It would have confirmed the company exists as described and the posting is live (RR1, role reality) |
| 2. Role-family sweep | unavailable | The search on PM platform-API roles and pay was refused. It would have supplied a market-calibration line and a pay band against RR3 |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

## Upgrade menu

- Your answer on the triage tool (G1) → R2b could move from `unclear` toward `adjacent` or `direct`.
- A sanitized requirements document or the integration playbook → R3 and R2a rise toward `high`, and G2 gains inspectable proof.
- A metric you tracked (G3) → R8 closes.
- The recruiter's answer on the years requirement → RR2 closes, which could settle the decision.
- Granting search permission, or pasting the company's careers page → RR1 and the market band for RR3 can be checked. A deeper pass (up to 5 more searches and 2 more fetches) is available on request.
- The hiring manager's name → positioning for that reader.

If you'd like, I can save all this as a `tuesday-dossier.md` you can carry forward.

G1 — Did you build or run a tool or process that people outside your team adopted? (An earlier conversation hinted at a request-triage tool for support agents; that's unconfirmed.) What did you own, who used it, and how did you know it worked?

G2 — On custom builds, did you ever decide what was in or out of scope or what engineering did first, or did you only pass the client's requests along? Give one example if you can.

G3 — Did you ever track a number about your integrations, such as time to go-live or repeat issues? What was it, and what did it change?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.