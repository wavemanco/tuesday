The careers-page check was refused, so this assessment rests on what you pasted. Here it is.

## Decision snapshot

**Yes, it's worth applying to, on the conditions below. Status: `conditional_go`.** R1, R2, R3, R5 and R6, the `must_have` rows, are all `direct`. R9 and R10, the pay and location gates, are still unconfirmed because I don't have your non-negotiables.

**Fit ledger.**

- `hard_gate` — unclear: R9 (Pay $148,000–$166,000 plus equity), R10 (Remote US or Denver office)
- `must_have` — direct: R1, R2, R3, R5, R6
- `important` — adjacent: R4 (BigQuery warehouse) · unclear: R7 (Ingestion from app and CRM), R8 (Data contracts analysts depend on)

R4 — a credible bridge, its limit named; R7 and R8 — your background is silent, so they wait on answers.

**Opportunity ledger.** The stated terms are sound: a pay band is posted (RR4), and the stage and funding are stated (RR5). The open items are who you'd report to and how big the team is (RR1, RR2), the equity terms (RR3), and that I couldn't check the posting live (RR5).

- **Hard gates:** none failed; unconfirmed: R9 (Pay $148,000–$166,000 plus equity), R10 (Remote US or Denver office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay and location terms fit your non-negotiables (R9, R10); (2) the posting shows as live on the company's own careers page (RR5); (3) BigQuery is framed as adjacent, never as experience, and the team shape comes out in the screen (R4, RR1, RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` About-page text you pasted; not checked live |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Stack named | dbt, BigQuery, Airflow or similar, data-quality testing, Python, SQL | `[grounded]` JD |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Pay | $148,000–$166,000 plus equity; equity amount and type not stated | `[grounded]` JD |
| Scope read | Ingestion, warehouse modelling and contracts together read as broader than one domain's pipelines. The JD names no team, reports or manager | `[inferred]` from the JD's scope list against the report's "one domain, no direct reports" norm |
| Market calibration | The posted low end is $3,000 below the report's $151,000 base median, and the top is $2,500 above its $163,500 upper quartile. The midpoint, $157,000, sits above the median. That makes the pay upper-half, not a mismatch. It is the band, never a promise of this employer's offer | `[grounded]` Datawright 2026 report (n=2,310, Senior Data Engineer at Series B–D); `[inferred]` the comparison |
| Unknowns | Hiring manager; team size; equity terms; whether the figure is base; first-year outcomes | `[grounded]` JD silent on each |
| Contradictions | None between the JD and the About text you pasted; neither was checked against the live site | `[grounded]` pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. It is self-reported with no inspectable artifact yet, so `medium`. The report's usual Senior range is 5–8 years, and six sits inside it | `[grounded]` your background; `[grounded]` pay report | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | "Python and SQL daily" is confirmed but gives no level, so `medium`. Interviews for this title commonly test both live | `[grounded]` your background; `[generic]` on testing | none |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | You built the dbt project on Snowflake, about 180 models. Snowflake is a cloud warehouse, so this row is met. The role's BigQuery is R4 | `[grounded]` your background | A sanitized dbt lineage or docs page would raise it to `high` |
| R4 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | The dbt modelling carries over. Limit: you have never used BigQuery, so its platform specifics are unexercised. State it as adjacent | `[grounded]` your background; `[generic]` that warehouses differ on cost and layout | See G1 |
| R5 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow is named in your background. The JD takes it or similar | `[grounded]` your background | A sanitized DAG listing would raise it to `high` |
| R6 | Data-quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. Scope and ownership beyond that are unstated | `[grounded]` your background | A sanitized expectation-suite file would raise it to `high` |
| R7 | Ingestion from the app and the CRM | important | unclear | low | discovery | Python and Airflow are confirmed, but what you ingested and from where is not stated | `[grounded]` background silent on sources | See G2 |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is nearby, but an agreed contract with analysts is not stated | `[grounded]` background silent | See G3 |
| R9 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so there is no constraint to grade. Fit is `unclear`, not failed | `[grounded]` JD; no candidate statement | Q1 |
| R10 | Remote (US) or the Denver office | hard_gate | unclear | none | hard_gate | Your location and authorization are not stated, so the gate is unestablished | `[grounded]` JD; no candidate statement | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R4, important) | transferability | About 180 dbt models on Snowflake; no BigQuery use | The JD names it as the platform. A stated limit reads better than a discovered one | Any BigQuery use as a source or export at your employer; a personal dbt-bigquery project on a free sandbox | A small repo or lineage screenshot | `[grounded]` you've never used it; `[generic]` that it is the likeliest probe |
| G2 | Ingestion from app and CRM (R7, important) | discovery | Python and Airflow confirmed; sources unnamed | It is the first named responsibility, so which answer is true decides the positioning | Extractors for product-event data or a CRM; managed connectors versus custom code; loading app data into the warehouse | A sanitized DAG list or architecture diagram | `[grounded]` background silent |
| G3 | Data contracts (R8, important) | discovery | The Great Expectations suite is related; analyst-facing agreements aren't stated | The JD names contracts as something analysts depend on | Schema or freshness agreements with analysts; dbt tests the analysts relied on; a change-notice process | A sanitized schema or SLA doc | `[grounded]` background silent. I'm holding its question for a later turn |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Hiring manager and team unnamed | unknown | — | "The posting names no hiring manager" (your note) | You may be joining a team or may be one of very few data engineers | `[inferred]` from the JD naming no team | Who would I report to, and how many data engineers are on the team today? | unresolved |
| RR2 | Scope breadth against the report's one-domain norm | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | The post may own the whole path from ingestion to contracts | `[inferred]` from the JD's scope list against the report's norm | Which of ingestion, modelling and contracts would I own on day one, and who owns the rest? | unresolved |
| RR3 | Equity unspecified | unknown | — | "plus equity" | Grant size, vesting and type may be unstated or small | `[inferred]` from the JD giving no figure | What is the equity grant for this level, and how does it vest? | unresolved |
| RR4 | Pay posted and upper-half against the report | positive_signal | — | "$148,000–$166,000 plus equity" | The band is stated and sits at or above the report's median | `[grounded]` JD; `[inferred]` the comparison | Is the figure base salary, and where in the band would you place six years of experience? | noted |
| RR5 | Employer and posting not checked live | unknown | — | "Series C ($52M, February 2026)" | The pasted text is unchecked. The live posting may differ | `[grounded]` the check was refused; `[generic]` that postings can go stale | Can you confirm this role is open on your careers page? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on the company's own careers page before applying | See RR5 | `[grounded]` RR5 | pending your approval |
| A2 | Ask RR1, RR2 and RR3's questions verbatim in the recruiter screen | The register doubles as screen preparation | `[grounded]` register | pending your approval |
| E1 | Positioning line: "Built the dbt project on Snowflake, about 180 models. I haven't used BigQuery." Add: "Set up our Great Expectations suite." | Both clauses are yours, and the limit stays visible (R3, R4, R6) | `[grounded]` your sentences | pending your approval |

If you go ahead, resume-tailor can turn E1 into resume edits.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The fetch of the Senior Data Engineer careers page was refused. It would have checked that the posting is live and matches your paste (RR5, the contradictions row) |
| 2. Role-family sweep | skipped | The recruiter's pay report is in hand. It fixes the market calibration and the pay comparison this target feeds |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer and upgrade menu

I can save this as `tuesday-dossier.md` for later rounds if you want it.

- Your pay floor and location → R9 and R10 resolve, and the decision likely moves to `go` or `no_go`.
- A sanitized dbt lineage page, DAG list or Great Expectations suite file → R3, R5 and R6 can rise to `high`.
- A small dbt project on BigQuery → R4's bridge strengthens.
- The hiring manager's name → the scope read, and which story to lead with.
- A link you can open to the live posting, or approval for the fetch → RR5 closes.
- A deeper research pass (up to 5 more searches and 2 more fetches: funding, leadership changes, candidate reports, recent news) → say the word and it runs.

## Questions

Q1 (R9, R10) — Do the posted pay band and the Remote (US) or Denver terms fit your non-negotiables?

Q2 (G1, R4) — Have you touched BigQuery at all, even as a source or in a side project?

Q3 (G2, R7) — What sources did you ingest from at the payroll company, and was it custom Python or managed connectors?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.