Search was denied, so this runs on your JD and background only.

## Decision snapshot

**Yes, apply. You're a fit on the core of the role. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5
- `important`: direct: R7a · adjacent: R7b (Partnering with clinicians) · unclear: R6 (Define and maintain the metrics layer), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9 (Healthcare data experience, HIPAA)

R9 is a bridge with its limit named; R6 is confirmed tooling with definition ownership unconfirmed; R8 has no evidence yet.

**Opportunity ledger.** The scope is concrete and the deliverables are named (RR3). The employer is unverified because research didn't run (RR1), pay is withheld (RR2), and how much traffic the experiments get is unknown (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting and employer verify as live and real (RR1); (2) you confirm you owned metric definitions, not just dashboards (R6, G1); (3) pay and location or remote terms clear your own limits (RR2, C1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, care-navigation app | `[grounded]` JD header; not checked externally |
| Mandate | Own product analytics: metrics layer, A/B tests, self-serve Looker dashboards, roadmap partnership with PMs and clinicians, mentoring two juniors | `[grounded]` JD |
| Scope read | A senior individual-contributor post with light people leadership (two juniors), not a team-lead post | `[inferred]` from "mentor two junior analysts" with no mention of reports or hiring |
| Market calibration | Not done. The role-family sweep didn't run, so there is no pay or scope band | `[grounded]` search call refused |
| Unknowns | Pay, location or remote terms, user base and test traffic, who the clinician partners are, whether a metrics layer exists or must be built | `[grounded]` JD silent on each |
| Contradictions | None inside the JD. It wasn't compared against a careers page | `[grounded]` JD only |

## Evidence map

Your background is typed self-report, so it is capped at `medium` until you share something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years of product analytics stated, against five required. Self-report with nothing to inspect yet | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake. "Expert" is a level, and the daily use is what you stated | `[grounded]` your background | A query or model you can sanitize would raise this to high |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, an owned program, and a pricing test behind an 11% retention lift, on about 2M subscribers. Whether the 11% is relative or in points isn't stated, so carry it as you said it | `[grounded]` your background; `[generic]` that this role will probe the scale of the audience (RR4) | A sanitized experiment readout would raise this to high |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | Built the Looker instance from scratch with 40+ governed dashboards | `[grounded]` your background | Dashboard screenshots or a LookML sample would raise this to high |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team, plus a monthly presentation to the VP Product | `[grounded]` your background | A sanitized memo would raise this to high |
| R6 | Define and maintain the metrics layer | important | unclear | low | discovery | You describe governed dashboards. Defining shared metrics (LookML or a semantic layer) isn't stated, so a lead exists and nothing is confirmed | `[grounded]` background silent on definition ownership; `[inferred]` that governed dashboards usually involve some metric definitions | See G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | direct | medium | none | Monthly VP Product presentations and the pricing test that drove a decision. Whether roadmap changes followed is not stated | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | adjacent | low | transferability | Carries over: working with domain experts to interpret data. Limit: no clinical stakeholders mentioned, and clinical outcomes are a different kind of metric from subscriber retention | `[inferred]` from your stakeholder work; `[generic]` that clinician partnership changes how metrics are defined | See the plan row P2 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring or managing | `[grounded]` background silent | See G2 |
| R9 | Healthcare data experience (HIPAA), a plus | preferred | adjacent | medium | transferability | Carries over: GDPR/CCPA consumer PII handling and a consent-state model in the warehouse. Limit: no PHI, no HIPAA rules, no clinical data standards | `[grounded]` your background; `[generic]` that regulated-data experience is read as an adjacent signal | A short written bridge, see P3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer ownership (R6, important) | discovery | A Looker build with governed dashboards, but not who defined the metrics or how they were governed | The JD lists it first among the responsibilities, so it is the likeliest probe | Writing LookML measures others reuse; a metric dictionary; resolving a disagreement over a definition such as "active subscriber" or "churn" | A metric dictionary, a LookML excerpt, a definitions doc (sanitized) | `[grounded]` background silent; `[inferred]` that it's probed first, from its position in the JD |
| G2 | Mentoring (R8, important) | discovery | Nothing on mentoring or coaching | A named duty; an honest "none" shapes how to position, a real example closes the gap | Onboarding an analyst, reviewing others' queries or tests, a training session on the experimentation program, informal coaching | A brief, a review checklist, an onboarding doc | `[grounded]` background silent |
| G3 | Healthcare data (R9, preferred) | transferability | The consent-state model and GDPR/CCPA handling | Preferred only, so a minor risk, but you will be asked about it | Access controls, de-identification, retention rules, audits you supported | A sanitized description of the consent model | `[grounded]` background; `[generic]` that this is the usual adjacent bridge |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The company may be real and the posting live, but the check didn't run. It may also be too new or small to have a footprint, or the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Pay and location terms not stated | unknown | — | no compensation or location in the JD | The figure may sit anywhere in the role-family band, or the company may share it at first call | `[inferred]` from the JD's silence | What is the budgeted pay band and the location or remote policy for this post? | unresolved |
| RR3 | Concrete responsibilities and named deliverables | positive_signal | — | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker" | The role is defined as work, not as vague ownership | `[grounded]` JD | Which of these is the first priority in the first 90 days? | noted |
| RR4 | Experiment traffic unknown | unknown | — | "experiment design at scale" | A care-navigation app may have far fewer users than 2M subscribers, which changes how many tests can reach significance | `[inferred]` from the product type against your audience size | How many monthly active users does the app have, and how many tests run per quarter? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Resume lead line from your own words: "Designed and ran the experimentation program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift" | R3, the strongest direct match | `[grounded]` your background | pending your approval |
| E2 | Look for room in the resume to say that you built the Looker instance with 40+ governed dashboards, and keep "governed" only if you can say what the governance was | R4, R6 | `[grounded]` your background | pending your approval |
| P2 | On clinician partnership, say that you work with domain experts, not that you have worked with clinicians | R7b | `[grounded]` background | pending your approval |
| P3 | On healthcare, say: "I've handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse; I haven't worked with health data or under HIPAA" | R9; states the limit up front | `[grounded]` your background | pending your approval |
| A1 | Check the posting on the company's own careers page before applying | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have fed role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | The search was refused. It would have fed the market calibration row and RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I can add a dossier file of this assessment if you want one to carry forward.

## Upgrade menu

- Search access → targets 1 and 2 run, which can clear or confirm RR1 and set pay against a market band.
- A sanitized experiment readout, memo, SQL sample or LookML excerpt → R2, R3, R4 or R5 moves to `high`.
- Your answer to G1 → R6 resolves, the likeliest probe in the interview.
- Your answer to G2 → R8 resolves.
- The hiring manager's name → role reality's scope read and which verified story to lead with.

## Questions

G1 — Did you define the shared metrics behind your Looker dashboards (LookML measures, a metric dictionary), and who signed off on definitions like "active subscriber" or "churn"?

G2 — Have you ever onboarded, coached or reviewed the work of another analyst? What did you own?

C1 — What are your non-negotiables on pay floor, location or remote, and work authorization? The JD states none, so I can't check any gate against you yet.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.