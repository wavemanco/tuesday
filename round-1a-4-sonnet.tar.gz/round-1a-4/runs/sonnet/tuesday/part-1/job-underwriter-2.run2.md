**Decision snapshot**

**No, you're not wasting your time, but treat this as a stretch application, not a fit. Status: `conditional_go`.** R1a (3+ years in a titled PM role) is `absent`. R3, R4 and R7 are `direct`.

**Fit ledger.**

- `must_have` — direct: R3, R4 · adjacent: R1b (PM-type work itself), R2 (shipped API or platform products) · unclear: R5 (agile delivery) · absent: R1a (3+ years titled PM)
- `important` — direct: R7 · adjacent: R6 (own the roadmap), R8 (specs, drive two squads), R10 (launches with sales and support) · unclear: R9 (adoption metrics)

R1a — a titled-years requirement, not a gate, and the row that can sink the application; R2 — a credible bridge, its limit named; R3, R4, R7 — carry the case.

**Opportunity ledger.** The mandate is clearly scoped (RR4). The employer could not be established from here (RR1), the titled-years bar may be applied literally (RR2), and pay and location are unstated (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (RR1); (2) the employer accepts product work done under a solutions or implementation title in place of titled years (R1a, RR2); (3) your answer to G1 confirms you owned something real that others adopted (R2, R1b, R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; discovery with integration partners; specs and delivery with two squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Experience bar | "3+ years product management experience (must-have)" | `[grounded]` JD quote |
| How the bar may be applied | Years requirements are often checked against titles in early screens, so a missing PM title can cost you before your substance is read | `[generic]` role-family pattern, not a claim about Quartzline |
| Scope read | One platform, two squads, partner-facing: a focused remit, not a bundle of roles | `[inferred]` from the JD's single-product, two-squad scope |
| Market calibration | Not available: the role-family sweep did not run | `[grounded]` see Evidence status |
| Unknowns | Pay; location or remote policy; reporting line; whether the years bar is flexible; which adoption metrics exist today | `[grounded]` JD silence |
| Contradictions | None found in the material provided; no careers page was checked | `[grounded]` provided JD only |

## Evidence map

Your resume was given as prose, so it counts as CV-equivalent self-report. That caps most bands at `medium` until you give me something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years in a titled PM role | must_have | absent | none | capability | You confirmed you have never held a PM title, so the titled years don't exist. Years of experience is not a gate, so it is graded like any other requirement. Closure is the employer's flexibility or a role that counts the work, not a wording fix | `[grounded]` your statement; `[generic]` that a literal title check is common | Ask the employer (RR2); see A2 |
| R1b | The product-management work itself, over 3+ years | must_have | adjacent | medium | transferability | Roadmap-input sessions feeding product, requirements documents, and coordinating engineers and product managers on custom builds are PM-adjacent. Limit: you fed product decisions and did not make them, and the CV doesn't show you owning a backlog or a prioritisation call | `[grounded]` CV claims, medium for want of an inspectable artifact; `[inferred]` adjacency | G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ integrations of your employer's REST APIs and wrote the integration playbook, which is deep consumer-side knowledge of an API product. Limit: nothing says you built, owned or launched one. The triage tool is an unconfirmed lead, not evidence | `[grounded]` CV; `[inferred]` bridge; memory lead excluded | G1; offer: a sanitized playbook excerpt would raise this |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs and integration architecture across 30+ clients is specific and on point. `medium` because nothing has been inspected yet | `[grounded]` CV | offer: a sanitized Postman collection or architecture diagram would raise to high |
| R4 | Stakeholder management across engineering, sales and customers | must_have | direct | medium | none | You coordinated your engineers, client engineers and product managers, and ran client workshops and UAT. Limit: sales is not named in what you gave me | `[grounded]` CV | none |
| R5 | Agile delivery | must_have | unclear | low | discovery | You coordinated custom builds, but the sprints, ceremonies or backlog you worked in aren't stated | `[grounded]` CV silence | G2 |
| R6 | Own the partner API roadmap | important | adjacent | medium | transferability | You collected client feedback for product each quarter. Limit: collecting input is not deciding what gets built | `[grounded]` CV | G1 |
| R7 | Discovery with integration partners | important | direct | medium | none | Scoping workshops and quarterly feedback sessions with clients who integrate your APIs are close to this | `[grounded]` CV | none |
| R8 | Write specs, drive delivery with two squads | important | adjacent | medium | transferability | You wrote requirements documents and coordinated engineers. Limit: these were client-specific builds, not a standing squad's roadmap | `[grounded]` CV | G1 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | Nothing stated about measuring adoption. The triage tool, if confirmed, may be evidence | `[grounded]` CV silence; memory lead excluded | Folded into G1 |
| R10 | Coordinate launches with sales and support | important | adjacent | medium | transferability | You ran client go-lives. Limit: client go-lives are not a product launch with sales and support enablement | `[grounded]` CV | none this turn |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owned, shipped product work (R2 and R1b, must_have; R9 and R6, important) | discovery | Strong integration and feedback work. Nothing confirms you owned something built and adopted by others | It decides whether the case reads as "PM work under another title" or "close, but never owned anything" | An internal tool, template, process or API change that others adopted; deciding what went into a release; defining success and checking whether people used it; writing the spec for something engineers built | A spec, a one-pager, a usage screenshot, an adoption message, the playbook (sanitized) | `[grounded]` CV silence on ownership; `[generic]` that PM interviews probe ownership |
| G2 | Agile delivery (R5, must_have) | discovery | Coordination of custom builds, but no stated delivery cadence | A must-have the posting names, currently unclear | Sprint planning or grooming with engineers; releases against a backlog; standups, retros or Jira boards you used day to day | A Jira board export, a release plan, a sprint note | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who I would be interviewing with? | unresolved |
| RR2 | Titled-years bar may be applied literally | risk_signal | medium | "3+ years product management experience (must-have)" | A literal title check could end the application before your integration work is read | `[generic]` role-family pattern, not a claim about Quartzline | Would you consider a candidate whose product work was done under a solutions or implementation title? | unresolved |
| RR3 | Pay and location unstated | unknown | — | JD gives neither | Either may conflict with your constraints, which I haven't been given | `[grounded]` JD silence | What is the salary band and the location or remote policy for this post? | unresolved |
| RR4 | Clearly scoped mandate | positive_signal | — | "Own the roadmap for our partner-facing API platform … two engineering squads" | Scope and reporting structure are concrete enough to evaluate | `[grounded]` JD | Who does this role report to, and who owns the roadmap today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with integration ownership and the roadmap-input sessions. Keep each claim in your own scope ("client integrations", "feedback collected for product") and never write "PM", "owned the roadmap" or "launched API products" | See R1b, R2, R6 | `[grounded]` your CV claims; audited clause by clause | pending your approval |
| A1 | Confirm the employer and live posting on Quartzline's own careers page before investing effort | See RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the RR2 question of a recruiter or hiring contact early, so the titled-years answer comes before you spend a full application on it | See R1a, RR2 | `[grounded]` RR2 | pending your approval |
| A3 | Say plainly in any cover note that you have not held a PM title, and point to the specific adjacent work. Don't try to hide the gap | Titled-years reads can't be fixed by wording; candour keeps interviews clean | `[grounded]` R1a | pending your approval |
| A4 | Beyond this posting: roles that explicitly accept solutions or implementation backgrounds (technical PM, product ops, API or integrations product) tend to weigh titled years less than a posting like this | Wider pivot targeting | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a prior-context mention that you built an internal request-triage tool that support agents adopted. It is unconfirmed, used here only as the basis for G1, and counted as evidence nowhere.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | A search for Quartzline's site and careers page was sent and refused, so nothing was read. It would have shown whether the employer exists as described and the posting is live. RR1 stands as the standing entry |
| 2. Role-family sweep | unavailable | A search for platform API PM scope and salary was sent and refused, so no market calibration ran. It would have set the stated scope and the missing pay against a band (RR3) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

I can save this as a `tuesday-dossier.md` if you want to carry it forward.

## Upgrade menu

- Your answer to G1, or the integration playbook or a spec (sanitized) → R2, R1b, R8 and R9 can move up, and RR2's weight shifts.
- Your answer to G2, or a Jira board export or release plan → R5 resolves.
- A Postman collection or architecture diagram → R3 toward `high`.
- Your pay floor, location limits and other non-negotiables → the hard-gates line stops reading "checks unknown".
- A link to the live posting or Quartzline's careers page → RR1 can close.
- Permission to run search, then optionally a deeper pass on the employer (up to 5 more searches and 2 more fetches) → it runs only on your word.

## Questions

G1 — Is there something you built or changed that other people adopted, such as a request-triage tool, a template or a process? What did you own, who used it, and how did you know it worked?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — What did your day-to-day delivery cadence with engineers look like on custom builds: sprints, a backlog, releases? What was your part in it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Hard gates (RR3) — What are your non-negotiables on pay floor, location or remote, and travel?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.