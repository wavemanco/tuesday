Search was denied, so I'm running this from what you gave me, with no outside research. Here's the full assessment.

## Decision snapshot

**Yes, apply. R1, R2, R3, R4 and R5 are `must_have` rows at `direct`, and R6 is `adjacent`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important` — adjacent: R7a (Partner with product managers) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R6 (`low`) — governed Looker work points toward it, but owning metric definitions is not confirmed; R8 — you haven't mentioned managing or mentoring anyone; R9 (`medium`) — a credible bridge with its limit named.

**Opportunity ledger.** There is nothing alarming, but the employer cannot yet be confirmed from here (RR1) and the posting is silent on pay, location and level (RR2). The data stack and who else defines metrics are unspecified (RR4), while the duties themselves are concrete (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify, per RR1; (2) pay and location are acceptable to you, per RR2 and your answer to the constraints question below; (3) you can truthfully describe your metric-definition work, per R6, and your mentoring history, per R8.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people at Series C, building a care-navigation app. Not independently confirmed | `[grounded]` JD header |
| Mandate | Own product analytics for the app: metrics layer, A/B tests, self-serve Looker dashboards, analysis turned into roadmap decisions with PMs and clinicians, and mentoring two junior analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor role with a small mentoring remit, not a people-management role | `[inferred]` from "mentor two junior analysts" with no mention of reports or hiring |
| Pay, location, work pattern, first-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not done. The role-family sweep was refused, so there is no pay band here and nothing to compare the title or scope against | `[grounded]` search refused |
| Unknowns | Pay; remote or onsite; analytics stack beyond Looker; whether a semantic layer already exists; who the clinicians are and how they engage | `[grounded]` JD silent |
| Contradictions | None within the JD. It has not been checked against a careers page | `[grounded]` JD only |

## Evidence map

Your background was typed in, so it counts as self-report. That caps the bands at `medium` until you share an artifact.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a ~2M-subscriber consumer company, which clears the stated minimum. Self-reported, nothing inspectable yet | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | You use SQL daily on Snowflake. "Expert" is the JD's word, not yours, so the claim stays at what you said | `[grounded]` your background | A sanitized complex query or model (cohorts, windowing) would raise it to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. The JD doesn't define "at scale"; ~2M subscribers is a large base | `[grounded]` your background | A sanitized test design doc or readout would raise it to `high` |
| R4 | Looker or similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your background | Sanitized screenshots or a LookML sample would raise it to `high` |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads, and present to the VP Product monthly | `[grounded]` your background | A sanitized memo would raise it to `high` |
| R6 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | Governed dashboards suggest metric definitions were controlled, but you haven't said you wrote or owned the definitions, or what tooling held them. Lower band taken because the link is my derivation, not your claim | `[inferred]` from "governed" dashboards; not stated by you | See G1 |
| R7a | Partner with product managers to turn analysis into roadmap decisions | important | adjacent | medium | discovery | Monthly presentations to the VP Product and a pricing test that moved retention are close, but day-to-day work with PMs, and who made the roadmap call, isn't stated | `[grounded]` your background; `[generic]` that roadmap influence is usually probed in interviews | See G2 |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing in what you've shared involves clinicians or clinical stakeholders | `[grounded]` background silent | See G4 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in what you've shared covers mentoring or managing | `[grounded]` background silent | See G3 |
| R9 | Healthcare data experience, HIPAA (a plus) | preferred | adjacent | medium | transferability | You handled GDPR/CCPA consumer PII and built the consent-state model for the warehouse. Limit: no health data, no HIPAA, and no clinical data standards. It's a bridge, not equivalence | `[grounded]` your background; limit `[inferred]` from the absence of any health-data work in it | See G5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed Looker dashboards; no stated ownership of metric definitions or the tooling behind them | The only `must_have` row below `direct`, and the JD's first listed duty | Writing LookML measures or explores others reused; a metric dictionary; a certified-metrics or definition-review process; retiring conflicting definitions | A metric glossary excerpt, a LookML sample, a governance doc (sanitized) | `[grounded]` background silent on definitions; `[generic]` that this role family probes definition ownership |
| G2 | PM partnership (R7a, important) | discovery | VP Product presentations and a pricing test that moved retention | Roadmap influence is the JD's stated purpose for the analysis | A test result that changed a launch or pricing decision; a standing PM sync; a roadmap review you fed | A decision memo or readout that names the outcome | `[grounded]` background; `[inferred]` from the JD's wording that the decision link matters |
| G3 | Mentoring (R8, important) | discovery | Silent | A named duty, and a senior title implies it | Onboarding an analyst; reviewing others' queries or dashboards; coaching on test design | A mentoring plan or onboarding guide, if one exists | `[grounded]` background silent |
| G4 | Clinician partnership (R7b, important) | discovery | Silent | A healthcare-specific stakeholder you haven't worked with | Working with domain specialists such as nutrition, food-safety or customer-care experts who shaped what you measured | A project where a domain expert changed your analysis | `[grounded]` background silent |
| G5 | Healthcare data (R9, preferred) | transferability | Consent-state model and GDPR/CCPA handling | A plus, not a requirement, so a bridge is enough. Overstating it as HIPAA experience would be the risk | Access controls, de-identification, retention, or audit work on personal data | A sanitized consent-model design doc | `[grounded]` background; `[inferred]` bridge derived from the consent work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Pay, location and level unstated | unknown | — | JD gives none | The figure or arrangement may not fit your needs, or the company may simply not publish it. No band is available to compare against | `[inferred]` from the JD's silence | What is the salary range and location policy for this role? | unresolved |
| RR3 | Duties and team scope stated concretely | positive_signal | — | "mentor two junior analysts" | The remit looks defined, with named duties and a named team size | `[grounded]` JD | Who do the two analysts report to today, and what does the metrics layer look like now? | noted |
| RR4 | Metrics-layer ownership and data stack unspecified | unknown | — | "define and maintain the metrics layer" | The role may mean building the layer from nothing, or maintaining one that exists, and the tooling isn't named | `[inferred]` from the JD naming Looker but no warehouse or modeling tool | Is there an existing semantic layer, and who defines metrics today? | unresolved |

RR1 caps the decision at `conditional_go` until the employer and posting verify.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the experimentation program ("designed and ran … 30+ A/B tests a year, including the pricing test behind an 11% retention lift"), then the Looker build ("built … 40+ governed dashboards"). Reuse your own wording; add nothing about metric definitions or mentoring | R3 and R4 are your strongest rows, and each clause traces to your sentences | `[grounded]` your background | pending your approval |
| E2 | Describe the consent-state model as consumer-data governance work (GDPR/CCPA), never as HIPAA or health-data experience | Keeps R9 at its honest limit | `[grounded]` your background | pending your approval |
| A1 | Check the careers page and the live posting before investing in the application | See RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the RR1–RR4 verification questions verbatim during the process | The register doubles as interview prep | `[grounded]` register | pending your approval |

These are all `resume_edits_pending_approval`, and nothing is final until you approve it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers"; the call was refused. It would have settled whether the employer exists as described and whether the posting is live (RR1, and role reality's contradictions row) |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary experimentation Looker"; the call was refused. It would have given the market calibration line and a pay band for RR2 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- Permission to search → targets 1 and 2 run: RR1 may close and a pay band replaces the blank in role reality.
- Your pay floor, location and work-authorization constraints → hard gates can be checked and the snapshot's flag clears.
- A sanitized query, test readout, Looker sample or metrics memo → R2, R3, R4 and R5 can rise from `medium` to `high`.
- A metric dictionary or LookML sample → R6 can reach `direct` or stay `adjacent`.
- The hiring manager's name → the plan can lead with the story that suits that reader.

If you'd like, I can write this up as `tuesday-dossier.md` to carry forward. It's optional.

Three questions, all optional:

**Constraints** — What's your pay floor, your location or remote requirement, and your work authorization for where this role sits? Any of those can fail the role on its own.

**G1** — Did you write or own the definitions of key metrics (retention, activation and so on) at your company? If so, where did they live (LookML, dbt, a doc) and who else used them?

**G3** — Have you ever onboarded, coached or reviewed the work of other analysts? Describe it however informal it was.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.