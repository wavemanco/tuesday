**Yes, this one is worth applying to once R1 (UK-based, eligible to work) and RR1 (the employer and posting checking out) clear. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote (UK))
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — direct: R8a · unclear: R8b (Recommendations for product)
- `preferred` — direct: R9 · adjacent: R10 (Pet-insurance product knowledge)

R4: GLM work on a motor young-driver book, the nearest match to the JD's GLM line; R7 (`medium`): tests run, design ownership unconfirmed; R10: a credible bridge, its limit named.

**Opportunity ledger.** The duties are specific (RR3), but the employer is unverified (RR1), the salary is withheld (RR2), and team scope is unstated (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm you're UK-based and eligible to work there, see R1; (2) Brindlemoor and the posting verify on the company's own site, see RR1; (3) your motor-to-pet move is framed as adjacent, never as pet-pricing experience, see R10 and G4.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech, with a pet-insurance product. Its existence was not checked | `[grounded]` JD header |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | Odile Varga, Director of Pricing | `[grounded]` as you stated it |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| People management | The JD lists no line-management duty and no reports. Your not having managed anyone is therefore not measured against any stated requirement. Whether the role has reports is unstated (RR4) | `[grounded]` JD silence; `[inferred]` for the reading of your gap |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not possible, so no salary band is given | `[grounded]` the search for it was refused (see Evidence status) |
| Unknowns | Salary; team size and reports; sign-off rights on rate changes; success measures | — |
| Contradictions | None between the JD and your message. The JD was not checked against a careers page | `[grounded]` the two inputs |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You work at a UK insurer, but your location and right to work are not stated, so this is not established. Confidence is low because there is only indirect context | `[inferred]` from UK employer, nothing stated | G1: confirm UK-based and eligible |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You gave 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. It's self-reported with no document yet. This is experience length, not a gate | `[grounded]` your message | none; a dated CV would firm it up |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" has no artifact behind it. Technical exercises are common in analyst hiring | `[grounded]` your message; `[generic]` for the exercise pattern | a sanitised notebook or query sample would raise it to high |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. It's one book, which is the limit | `[grounded]` your message | sanitised model documentation or a validation summary would raise it to high |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which the "or" in the JD covers. No actuarial audience is stated | `[grounded]` your message | none |
| R6 | Build and monitor rating models | must_have | direct | medium | none | You built and maintained the model. Monitoring is not described separately, so ask about it in interview prep | `[grounded]` your message | none |
| R7 | Design and read price tests | must_have | direct | medium | discovery | You ran 14 tests last year with the underwriting team. Who designed them (hypothesis, segmentation, read-out) is not stated, so I take the lower reading | `[grounded]` your message | G2 |
| R8a | Recommendations for underwriting | important | direct | medium | none | The tests were run with the underwriting team and you present the quarterly review to the head of underwriting | `[grounded]` your message | none |
| R8b | Recommendations for product | important | unclear | none | discovery | Nothing in what you gave involves a product audience | `[grounded]` silence in your message | G3 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your message | none |
| R10 | Pet-insurance product knowledge | preferred | adjacent | medium | transferability | The JD states no pet-knowledge requirement. I include it because you flagged it. You have never worked on pet insurance, but GLM rating on a motor book carries over. The limit: pet pricing usually turns on different rating factors, such as species, breed and age | `[inferred]` from the product named in the JD; `[generic]` for pet rating factors | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | UK location and eligibility (R1) | hard_gate | The JD says fully remote (UK). Your location and right to work are not stated | A gate the inputs don't settle stays open and can change the status | Not applicable; it's a yes or no | Your own statement | `[grounded]` JD term, your silence |
| G2 | Test design ownership (R7, must_have) | discovery | You ran 14 tests; design ownership is not described | The JD asks you to design tests, and the split between designing and running is the likely probe | Setting the hypothesis, choosing segments or sample size, deciding the read-out metric, choosing when to stop a test | A test read-out deck or test plan, sanitised | `[grounded]` your message; `[generic]` that interviews probe this split |
| G3 | Product audience (R8b, important) | discovery | Your recommendations went to underwriting; no product or commercial audience appears | The JD names product as a recipient | Any pricing proposal that went to a product, commercial or finance group | A sanitised recommendation paper | `[grounded]` your message |
| G4 | Pet-insurance knowledge (R10, preferred) | transferability | Motor GLM work, no pet exposure | A credible bridge but not direct experience | Rating factors you modelled, such as age and claims history, that have a pet counterpart | A sanitised model factor list | `[inferred]` bridge from your motor GLM work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified | risk_signal | medium | "Brindlemoor (insurtech)" | The company may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not be a live hiring employer. The check was refused, so nothing was found either way. Nothing in the posting asks you for money or personal details | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | The posting gives a title, requirements and "Fully remote (UK)", with no pay figure | The figure may sit below what you need, or may simply not be published | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| RR3 | Duties stated concretely | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations for underwriting and product" | The scope is concrete and matches your record | `[grounded]` JD | What does success look like in the first year? | noted |
| RR4 | Team scope and authority unstated | unknown | — | "Own pricing analytics for our pet-insurance product" | "Own" may mean a sole analyst with unclear sign-off rights, or a role inside a team | `[inferred]` from "Own" against silence on team, reports and sign-off | Is this a sole-owner role or part of a team, does it have direct reports, and who signs off rate changes? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the role on Brindlemoor's own careers page, and reach the company through contact details listed there, before investing in an application | see RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead your CV and any cover note with: built and maintained the GLM rating model for the young-driver book; ran 14 price tests last year with the underwriting team; present the quarterly pricing review to the head of underwriting | see R4, R6, R7, R5 | `[grounded]` your own sentences, unchanged in scope | pending your approval |
| E2 | State the pet gap plainly: your GLM rating work has been on a motor young-driver book, not pet insurance. Don't claim pet-pricing experience | see R10 | `[grounded]` your message | pending your approval |
| Q1 | Ask RR2 and RR4 verbatim at the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor pet insurance insurtech" and "Brindlemoor careers Senior Pricing Analyst"; both were refused and returned nothing. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst insurance UK remote salary"; refused. It would have moved market calibration and RR2 |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing Brindlemoor"; refused. It would have moved the scope read and which story the plan leads with for Odile |

If you'd like this saved for reuse, I can write it out as a `tuesday-dossier.md`.

**Upgrade menu**

- Permission to run the three searches above → RR1 resolves or firms up, role reality gets a salary band, and RR2 can be set against your floor.
- Your pay floor and any other non-negotiables → the hard-gates line checks the role against them.
- A dated CV → R2 firms up.
- A sanitised model document, notebook or test read-out deck → R4, R6 and R7 can rise toward `high`.
- The employer's answer on team scope → RR4 closes.

**Questions**

G1 — Are you based in the UK with the right to work there?

G2 and G3 — On the 14 price tests, what did you personally design versus run, and did any recommendation go to a product or commercial team rather than only underwriting?

RR2 — Do you have a pay floor or any other non-negotiable, such as notice period or travel, that would rule this role out?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.