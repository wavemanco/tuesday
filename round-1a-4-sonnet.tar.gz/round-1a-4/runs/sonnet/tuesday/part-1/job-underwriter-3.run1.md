**No, this posting isn't worth pursuing as written.** I'll say first that my web searches were refused, so nothing about Novaline was checked and the employer and the market pay band are both unverified.

## Decision snapshot

**No, not worth pursuing as posted. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin, five days), R2 ($70–85k base)
- `must_have`: direct: R3, R4, R5
- `important`: unclear: R6 (SEO and content), R7 (Brand and PR), R8 (Partnerships and sales ops), R9 (A team of one, owning growth end to end)

R3, R4, R5: your paper match, on your own account; R6, R7, R8, R9: the breadth the posting bundles into one title, which your inputs don't cover.

**Opportunity ledger.** Several full roles are folded into one title with no team (RR2). The pay is thin for that mandate (RR1), the hours are open-ended (RR3), and success is undefined (RR4). The CEO reporting line is a positive signal (RR5). The employer itself isn't yet attributed (RR6). This is the "off" feeling you described.

- **Hard gates:** failed: R1 (On-site in Austin, five days), R2 ($70–85k base)
- **Severe red flags:** none found.
- **What would change this:**
  - R1: the employer drops the five-day on-site term for a Portland-based hire, or you change your remote-only constraint.
  - R2: the base is $150k or above. The top of the posted range sits $65k under your floor.
  - Wording can't solve either, and I'm not suggesting a workaround.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup. The posting says Series A and "profitable since day one"; that is the posting's own claim and I couldn't verify it | `[grounded]` JD, unverified |
| Mandate | "Own all revenue growth end to end": paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` JD |
| Team | "A team of one to start" | `[grounded]` JD |
| Reporting | CEO, with a dotted line to the board | `[grounded]` JD |
| Location | Austin office, 5 days a week, "no exceptions" | `[grounded]` JD |
| Pay | $70–85k base, plus "meaningful equity upside" with no percentage, vesting or valuation given | `[grounded]` JD |
| Hours | "Evenings and weekends when it matters is just who we are" | `[grounded]` JD |
| Success metrics | "Will evolve as we learn"; no first-90-day or first-year outcomes stated | `[grounded]` JD |
| Scope read | Seven functions with no staff reads as several roles under one title, priced below the title's usual range | `[inferred]` from the function count, the team of one and the stated base |
| Market calibration | Not run, because the role-family search was refused. I won't offer a band from memory. | `[grounded]` search refused |
| Unknowns | Equity terms; hiring budget; whether any of the seven functions has tooling or spend committed; who the board contact is | `[grounded]` JD silence |
| Contradictions | "Head of" with 8+ years of leadership required, yet no one to lead; the CEO and board access sits beside a one-person team | `[inferred]` from the JD's own terms |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, "no exceptions" (your constraint: remote-only, Portland, not relocating) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated limit, which is specific, confirmed and your own. The fit fails because the posting rules out remote work in terms. | `[grounded]` JD quote and your message | Surface; only changed terms resolve it |
| R2 | $70–85k base (your constraint: at least $150k base) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your floor, which is specific and confirmed. The fit fails because the posted maximum is $65k below it. | `[grounded]` JD figure and your message | Surface; only changed terms resolve it |
| R3 | 8+ years of growth leadership | must_have | direct | medium | none | You state 9 years, as growth lead and then Head of Growth at two B2C subscription companies. That is self-reported with nothing inspectable yet. A length-of-experience requirement is graded as fit, not as a gate. | `[grounded]` your message | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You state you owned paid, and that you scaled one company from $8M to $40M ARR over three years with a budget you controlled. I haven't attributed that ARR growth to paid specifically. The posting doesn't say whether the buyer is consumer or business, so that overlap is unknown. | `[grounded]` your message | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle, and you name Braze, SQL and GA4. Self-reported, with no artifact inspected. | `[grounded]` your message | none |
| R6 | SEO and content | important | unclear | none | discovery | Your inputs are silent on SEO and content. | `[grounded]` your message's silence | See G1 |
| R7 | Brand and PR | important | unclear | none | discovery | Your inputs are silent. | `[grounded]` your message's silence | See G2 |
| R8 | Partnerships and sales ops | important | unclear | none | discovery | Your inputs are silent. | `[grounded]` your message's silence | See G2 |
| R9 | Running growth end to end with a team of one | important | unclear | low | discovery | You have led teams of 3–7, which is management and not solo execution. Your SQL, GA4 and Braze depth suggests hands-on work, but I haven't confirmed you've run growth alone. | `[grounded]` your message; `[inferred]` hands-on work from your tools | See G3 |

I tiered the first three growth functions as `must_have` and the rest as `important` myself. The posting doesn't rank them.

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content (R6, important) | discovery | Nothing on organic or content work | It doesn't move `no_go`; it would matter only if R1 and R2 changed | Owning organic landing pages for a subscription product; briefing writers or an SEO agency; a content calendar you ran | A Search Console or GA4 organic report, a content calendar | `[grounded]` silence; `[inferred]` that it can't move the decision |
| G2 | Brand, PR, partnerships, sales ops (R7, R8, important) | discovery | Nothing on these areas | Same as G1 | Launch announcements or press coverage; affiliate or co-marketing deals; lead routing or pipeline reporting | A partner agreement, a press clipping, a pipeline dashboard | `[grounded]` silence; `[inferred]` that it can't move the decision |
| G3 | Solo operation (R9, important) | discovery | Team leadership is shown; running growth alone is not | Same as G1 | A stretch as the first or only growth hire; a period with no direct reports | A dated org chart or an early-stage ops summary | `[grounded]` CV-level claims; `[inferred]` that it can't move the decision |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay thin for the mandate | risk_signal | medium | "$70–85k base plus meaningful equity upside" | Base may sit below what a Head-level post with this scope usually pays, and the equity is unquantified. I took the lower severity because the market search didn't run. | `[generic]` pattern for bundled-scope startup roles; no band was searched | What does the equity grant amount to (percentage, vesting, strike price, latest valuation), and how was the base range set for this mandate? | unresolved |
| RR2 | Responsibility without resources, and bundled specializations | risk_signal | medium | "Own all revenue growth end to end… team of one to start" | Seven functions may fall to one person with no committed budget or help | `[inferred]` from the function count against the JD's silence on budget and hiring | Which of these functions have budget and tooling committed today, and when is the first hire planned? | unresolved |
| RR3 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine and not occasional | `[inferred]` from the framing as identity, not exception | In a typical month, how many evenings or weekends did the last person in this role work? | unresolved |
| RR4 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be held accountable for targets nobody has defined | `[inferred]` from the JD's silence on outcomes | What would success look like at 90 days and at one year, and who sets the metrics? | unresolved |
| RR5 | CEO reporting line with board visibility | positive_signal | — | "Report to the CEO with a dotted line to the board" | Access to decision-makers is real, which is worth something | `[grounded]` JD states it | Which board member is the dotted line, and how often do you meet? | noted |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |

## Application plan

I'm proposing no resume or outreach language.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Don't spend application effort while R1 and R2 stand | Two failed gates | `[grounded]` R1, R2 | proposed |
| P2 | If you proceed anyway, ask RR1, RR2, RR3, RR4 and RR6 verbatim, and get RR1's equity terms before anything else | The register travels with you against a `no_go` | `[grounded]` register | pending your approval |
| P3 | Put effort into openings that already state remote work and a base at or above $150k | Your constraints are met up front | `[grounded]` your stated constraints | proposed |

## Evidence status

Verified: your two stated constraints behind R1 and R2, which are your own words. The experience claims behind R3, R4 and R5 are self-reported and unverified. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Austin Series A Head of Growth". The search permission was refused, so no page was read. RR6 stands, and role reality rests on the posting alone. |
| 2. Role-family sweep | unavailable | Searched "Head of Growth startup Series A salary range base 2026". Refused. The market calibration row is empty, and RR1 is a pattern with no band behind it. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

I can write `tuesday-dossier.md` for this posting if you want a record of it.

**Upgrade menu**

- Search permission, or a link to the live posting or the company's careers page → RR6 resolves, and RR1 gets a market band.
- Equity terms from the employer → RR1.
- A hiring manager or CEO name → role reality's scope read.
- A sanitized channel-level report, board-deck excerpt or ARR bridge → R3, R4 and R5 can reach `high`.
- Answers on SEO, brand and PR, partnerships, and solo operation → R6 through R9.
- A deeper pass on Novaline, covering funding, leadership churn, hiring patterns and recent news (up to 5 more searches and 2 more fetches). Say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.