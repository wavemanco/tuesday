Checking that the posting is live on Pellucid's own careers page, then I'll write the assessment.
**Yes, it's worth applying, with two things to confirm first (R1 and R2).** The status is `conditional_go`. It isn't a plain `go` because the posting's location and pay terms are unchecked against your own constraints, which I don't have.

## Decision snapshot

**Worth applying to. R3, R4, R5, R6, R8 and R9, the `must_have` rows, land `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R8, R9
- `important` — adjacent: R7 (BigQuery warehouse); unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R7 (`medium`) — a Snowflake-to-BigQuery bridge, its limit named; R10, R11 — your background is silent, asked in G3 and G4.

**Opportunity ledger.** Sound on its face: the pay is posted (RR3) and the posting is live and matches the company page (RR4). Open items are team structure and on-call expectations (RR1) and the equity terms (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 confirmed against your location, work authorization and pay floor; (2) the BigQuery bridge is framed as adjacent, never as BigQuery experience (R7); (3) the team and on-call picture is acceptable (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the company's about page, returned by search |
| Mandate | Build and run the pipelines behind tutoring-platform reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD, matched against the live careers page |
| Stack named | dbt, BigQuery, Airflow "or similar", data quality testing | `[grounded]` JD |
| Scope read | One reporting domain's pipelines, with no direct reports stated | `[inferred]` from the JD's single-domain mandate and its silence on reports |
| Market calibration | Your Datawright report puts Senior Data Engineers at Series B–D companies at a $151,000 median base (interquartile range $139,000–$163,500), typically 5–8 years' experience and one domain's pipelines. The posted $148,000 sits $3,000 below that median and $166,000 sits $2,500 above the range's upper bound. The report covers base pay, so the equity is outside this comparison, and the band is not this employer's offer. | `[generic]` role-family pattern from your provided report; `[grounded]` JD for the posted range |
| Unknowns | Hiring manager (the posting names none); team size and reporting line; on-call expectations; equity terms | — |
| Contradictions | None between your pasted posting and the live careers page, or between the company description and the about page | `[grounded]` both pages read |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | The posting states the term. Your location and US work authorization weren't given, so nothing settles it. | `[grounded]` JD; candidate constraints not given | G1 question |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The posting states the range. Your pay floor wasn't given, so I can't say whether the range clears it. | `[grounded]` JD; candidate constraints not given | G1 question |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. That is specific and confirmed but has no inspectable artifact yet. | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is your own report, with no artifact inspected. | `[grounded]` your stated background | none |
| R5 | dbt | must_have | direct | medium | none | You built your company's dbt project, about 180 models, on Snowflake. Confirmed and specific, with no artifact inspected. | `[grounded]` your stated background | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. The requirement says "a cloud warehouse", and BigQuery is carried separately in R7. | `[grounded]` your stated background and the JD wording | none |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | You use Airflow for orchestration. Confirmed, with no artifact inspected. | `[grounded]` your stated background | none |
| R9 | Experience with data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite. "Set up" is the claim, and I carry nothing wider. | `[grounded]` your stated background | none |
| R7 | A dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | Same dbt-on-cloud-warehouse pattern as your Snowflake work. Limit: you have never used BigQuery. `[generic]` BigQuery's cost and table-design model differs from Snowflake's, so that is the likeliest probe. | `[grounded]` your stated absence of BigQuery; `[generic]` the likely probe | G2 bridge; optional small project |
| R10 | Ingestion from the app and CRM | important | unclear | low | discovery | You described orchestration and testing but not which source systems fed your pipelines. | `[grounded]` background silence | G3 question |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing in your background mentions agreed schemas or expectations with downstream analysts. Your Great Expectations work may be adjacent, but that is unconfirmed. | `[grounded]` background silence | G4 question |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location, work authorization and pay floor against the posting (R1, R2, hard_gate) | hard_gate | The posting gives Remote (US) or Denver and a pay range; your constraints weren't given | A failed gate would make this `no_go` however strong the fit | — | Nothing to attach; your own statement settles it | `[grounded]` JD terms; constraints not given |
| G2 | BigQuery (R7, important) | transferability | Snowflake plus dbt at scale (about 180 models); no BigQuery use | The role names BigQuery in its mandate, so this is the visible gap in your profile | Snowflake performance or cost tuning; partitioning-style table design; any exposure to Google Cloud data tools | A small dbt project run against BigQuery | `[grounded]` your stated absence; `[generic]` that the mandate names it |
| G3 | Ingestion from product and CRM sources (R10, important) | discovery | Pipelines and Airflow are confirmed; the source systems are not | The mandate lists app and CRM ingestion first | Loading product event data, syncing a CRM, API or file-based loads, handling late or changed source records | A pipeline diagram or DAG screenshot, sanitised | `[grounded]` background silence |
| G4 | Data contracts (R11, important) | discovery | Great Expectations tests are confirmed; agreements with consumers are not | The posting says the analysts "depend on" these contracts | Agreed schemas, freshness expectations or change notices with analysts; tests that gated a release | A sanitised contract doc, test config or changelog | `[grounded]` background silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team structure and on-call not stated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You could be the only data engineer, and "run" may include out-of-hours support | `[inferred]` from the build-and-run wording against the JD's silence on team and on-call | Who is on the data team today, who does this role report to, and what does running the pipelines involve outside working hours? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "Salary $148,000–$166,000 plus equity" | Equity may be material or token, since type, size and vesting aren't given | `[inferred]` from the posting naming equity with no terms | What form does the equity take, roughly how much at this level, and what is the vesting schedule? | unresolved |
| RR3 | Pay posted, in market range | positive_signal | — | "Salary $148,000–$166,000" | The range straddles your report's $151,000 median, so it shows no seniority-pay mismatch | `[grounded]` JD range against your provided report | Does the range apply equally to remote and Denver hires? | noted |
| RR4 | Posting live and consistent with the company page | positive_signal | — | "Accepting applications" | The employer exists as described and the role is open | `[grounded]` careers page fetched; about page returned by search | What does the interview process look like, and who would I meet? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the dbt project (about 180 models, on Snowflake), Airflow, and the Great Expectations suite you set up; claim no BigQuery use | see R5, R8, R9 | `[grounded]` your stated background | pending your approval |
| E2 | State up front that BigQuery is new to you and that the dbt-on-cloud-warehouse pattern is the same | see R7 | `[grounded]` your stated absence of BigQuery | pending your approval |
| W1 | Optional: a small dbt project on BigQuery, to narrow R7's limit | see G2 | `[grounded]` R7 row | pending your approval |
| Q1 | Ask RR1 to RR4's questions verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Both checked your pasted text and matched it; the careers page reads "Accepting applications". Moved role reality's contradictions row and RR4. |
| 2. Role-family sweep | skipped | Your Datawright report is in hand and fixes the market calibration line and the pay check (R2, RR3). |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there was no query to form. |

## Closing

If you'd like, I can write this up as `tuesday-dossier.md` for later use.

**Upgrade menu**

- Your location, work authorization and pay floor → R1 and R2 resolve, and the status likely becomes `go` or `no_go`.
- Answers to G3 and G4 → R10 and R11 move from `unclear` to a confirmed fit.
- A sanitised DAG or test-config screenshot → R9 or R8 could rise to `high`.
- A hiring manager's name, from the recruiter → role reality's scope read and which story to lead with.
- A deeper research pass on Pellucid (funding, leadership changes, public employee reports; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

G1 — Where will you be working from, are you authorised to work in the US, and does a $148,000–$166,000 base clear your floor?

G3 — What source systems fed the pipelines you built (product or app data, a CRM, third-party APIs), and which parts of that ingestion did you own?

G4 — Did you agree schemas, freshness or quality expectations with analysts or other consumers of your dbt models, and what was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.