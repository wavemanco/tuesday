Web search was denied, so this runs only on what you pasted. Here is the full assessment.

## Decision snapshot

**Yes, worth applying to, on conditions. R3, R4, R5, R6, R8 and R9 (the `must_have` rows) are `direct`, and R7 (BigQuery) is an `adjacent` bridge. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000)
- `must_have`: direct: R3, R4, R5, R6, R8, R9
- `important`: adjacent: R7 (BigQuery warehouse) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R7 — a credible bridge from Snowflake, limit named; R10, R11 — not yet evidenced in what you've told me.

**Opportunity ledger.** The mandate and pay look sound: a stated range sits inside the market band (RR4), and the stack matches yours. Three things are open: the employer and live posting are unverified because search was refused (RR1), no hiring manager is named (RR2), and team size and equity terms are unstated (RR3, RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed live on the company's own careers page, RR1; (2) R1 and R2 are confirmed against your location, work eligibility and pay floor; (3) the BigQuery bridge is framed as adjacent Snowflake experience, never as BigQuery experience, R7.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` your pasted About text; not independently re-checked |
| Mandate | Build and run the pipelines behind the tutoring platform's reporting: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Stack | dbt, BigQuery, Airflow or similar, data quality testing, Python and SQL | `[grounded]` JD |
| Scope read | A single-domain senior post with no reports named, though ingestion, warehouse and contracts together are a wide remit for one person | `[inferred]` from the JD's three named areas against its silence on team size |
| Market calibration | The report's Series B–D senior median base is $151,000, with an interquartile range of $139,000–$163,500. The posting's $148,000 floor sits $3,000 under the median, and its $166,000 top sits $2,500 over the range's upper edge. "Senior" typically means 5–8 years with one domain's pipelines and no reports, and your 6 years fall inside that. Pellucid's Series C is inside the report's B–D scope | `[grounded]` the Datawright 2026 report you supplied (n=2,310) and the JD's own figures; `[inferred]` that the posting reads as at or slightly above market |
| Unknowns | Hiring manager, team size, equity terms, start timing, first-90-day outcomes, whether the posting is still live | `[grounded]` absent from the pasted JD |
| Contradictions | None between the pasted JD and the pasted About text | `[grounded]` both pasted; neither re-fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You have not said where you are or whether you can work from the US. Confidence grades your statement of a constraint, and none was given | `[grounded]` JD term; no constraint stated | Q1 below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor was given, so whether the range clears it is not established | `[grounded]` JD figure; no floor stated | Q1 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. Self-reported and unprobed, so `medium` | `[grounded]` your message | CV with dates would raise it |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. Strength is self-described, with no artifact | `[grounded]` your message | A repo or code sample would raise it |
| R5 | dbt | must_have | direct | medium | none | You state building the dbt project, about 180 models, on Snowflake. Specific, with no artifact inspected | `[grounded]` your message | Sanitized project structure or docs would raise it |
| R6 | Cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and you state it as your dbt target | `[grounded]` your message | none |
| R7 | BigQuery as the modelled warehouse | important | adjacent | medium | transferability | Snowflake and dbt carry over: SQL modelling, warehouse design and dbt workflow. Limit: you have never used BigQuery, so its specifics are unexercised | `[grounded]` your stated Snowflake and dbt work and no BigQuery use; `[generic]` that warehouses differ in cost and partitioning mechanics | Closure path in the plan, A2 |
| R8 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow orchestration, which is the named tool | `[grounded]` your message | none |
| R9 | Data quality testing | must_have | direct | medium | none | You state setting up the Great Expectations test suite, so it is specific and confirmed, with no artifact | `[grounded]` your message | A test-suite overview would raise it |
| R10 | Ingestion from app and CRM | important | unclear | low | discovery | Airflow work at a payroll company suggests ingestion pipelines, but you named no sources, so the app and CRM match is a lead only | `[inferred]` from Airflow use at a payroll company; no sources stated | G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing stated about contracts or analyst-facing guarantees. Your test suite is adjacent context, not evidence | `[inferred]` from the Great Expectations suite; no contract work stated | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R7, important) | transferability | Strong Snowflake and dbt work; no BigQuery use | The JD names BigQuery in its first sentence, so it is the most likely probe | A dbt project run against BigQuery's free tier; a migration or cost-tuning exercise on any warehouse | A small public or private repo with a dbt BigQuery profile and a short README | `[grounded]` you have not used BigQuery; `[generic]` that a named warehouse is a common probe |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Airflow work is stated, but sources are not | The JD's first responsibility is ingestion from two named kinds of source | Pulling from a product database or event stream; syncing a CRM or HRIS via API or a connector; handling schema drift or backfills | A DAG diagram or a pipeline README | `[grounded]` sources not stated; `[generic]` that ingestion is an early-interview topic |
| G3 | Data contracts (R11, important) | discovery | A test suite exists; contracts are not mentioned | The JD says analysts depend on the contracts, so ownership of them matters | Agreeing column definitions or freshness guarantees with analysts; versioning or deprecating a model; enforcing schema expectations in tests | A contract doc, a dbt `schema.yml` example or a freshness policy | `[grounded]` contracts not mentioned |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | Search was refused, so the entity and the live posting were not checked. The pasted pages agree with each other. The employer may be fine and simply unchecked, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers site, and say who I'd be interviewing with? | unresolved |
| RR2 | No hiring manager named | unknown | — | "The posting names no hiring manager" | Reporting line and decision rights are unknown | `[grounded]` posting silent | Who does this role report to, and which data decisions does it make alone? | unresolved |
| RR3 | Team size and support unstated against a wide remit | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | One person may own ingestion, warehouse and contracts. It may also be a team that you'd join | `[inferred]` from the three named areas against silence on team size | How many data engineers and analysts are there, and who owns ingestion today? | unresolved |
| RR4 | Pay stated and in line with market | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range is stated and spans the report's median and upper quartile edge | `[grounded]` JD figures against the Datawright report you supplied | Where in the range would someone with my background land? | noted |
| RR5 | Equity terms not stated | unknown | — | "plus equity" | Grant size, vesting and valuation are unknown, so the equity's worth cannot be assessed | `[grounded]` posting names equity with no terms | What is the equity grant for this level, and on what vesting and strike terms? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting is live on the company's careers page (the URL you gave) and note the posting date | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Run a small dbt project against BigQuery's free tier and keep the repo | see R7, G1; turns an adjacent claim into an inspectable one | `[generic]` closure path, not a claim about this employer | pending your approval |
| A3 | Lead with your dbt project (about 180 models on Snowflake) and the Great Expectations suite you set up. Describe the warehouse as "Snowflake, with BigQuery new to me" and avoid wording that implies BigQuery use or owning data contracts | see R5, R9, R7; every clause traces to your own sentences | `[grounded]` your message | pending your approval |
| A4 | Ask RR2, RR3 and RR5 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | One search was sent ("Pellucid Learning senior data engineer careers Denver online tutoring") and refused. Nothing was checked about the company or whether the posting is live, so RR1 stands. The upgrade menu offers it |
| 2. Role-family sweep | skipped | Your pasted Datawright report already fixes the market calibration line and the pay comparison in RR4, so no search was sent |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there is no query to form |

I can save this as `tuesday-dossier.md` if you want a record to carry into interview prep.

## Upgrade menu

- Permission to search (up to 5 searches and 2 fetches) → RR1 closes or sharpens. It checks whether the posting is live and the company matches its description.
- Your CV or a link to your repo → R3, R4, R5, R9 can move toward `high`, and I can run the bullet-level audit.
- A sanitized DAG, `schema.yml` or test-suite overview → R10, R11 and R9.
- The hiring manager's name → the scope read and which story to lead with.
- A deeper research pass (up to 5 more searches and 2 more fetches) on funding and leadership news, once search is allowed. Say the word and it runs.

Questions:

R1, R2 — Are you in the US and able to work for a US employer, and does $148,000–$166,000 clear your pay floor, with Remote (US) or Denver both acceptable to you?
G2 (R10) — Which sources did your Airflow pipelines ingest from (product database, events, CRM or HRIS APIs), and what did you personally own?
G3 (R11) — Have you agreed definitions or freshness guarantees with analysts, or versioned a model they relied on? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.