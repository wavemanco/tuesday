Checking that the Pellucid posting and company page are live and match what you pasted, then I'll build the assessment.
**Yes, it's worth applying to, with conditions. Status: `conditional_go`.** Your experience lines up with the stack. What's still open is whether your location and pay floor fit (R1, R2) and how much of the pipeline you'd own (RR1).

I fetched the careers page and ran one search for the company. The live posting matches what you pasted, and the about page matches the company description you pasted.

## Decision snapshot

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery); unclear: R10 (Data contracts), R11 (Ingestion from app and CRM)

R9 — a credible bridge, its limit named; R10, R11 — the CV is silent, the experience may exist.

**Opportunity ledger.** The stated pay sits inside the Datawright band (RR3), and the employer and posting check out (RR5). The open items are the team and ownership boundaries (RR1), the reporting line and first-year outcomes (RR2), and the equity terms (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) your location and pay floor fit R1 and R2; (2) the interviews show a workable ownership scope, see RR1; (3) BigQuery is framed honestly as adjacent to your Snowflake work, never as experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company about page, as returned by search; funding is the company's own statement |
| Mandate | Build and run the pipelines behind the platform's reporting: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` careers page, fetched |
| Stack | dbt, BigQuery, Airflow "or similar", data quality testing | `[grounded]` careers page |
| Working pattern | Remote (US) or Denver office | `[grounded]` careers page |
| First-year outcomes | Not stated | `[grounded]` careers page is silent |
| Scope read | Three named areas (ingestion, warehouse models, contracts) and no mention of a team or direct reports | `[inferred]` from the JD's list against its silence on team |
| Market calibration | The report's Series B–D "Senior Data Engineer" base median is $151,000, with an interquartile range of $139,000–$163,500. The posting's $148,000 floor is $3,000 under that median, and its $166,000 top is $2,500 above the range's upper edge. "5+ years" sits inside the report's typical 5–8 for "Senior". Pellucid is Series C, so it falls in the report's company-stage band | `[grounded]` Datawright 2026 report (n=2,310) and the posting; whether the range is base salary is `[inferred]`, since the posting says only "Salary" |
| Scope vs typical | The report's typical scope is one domain's pipelines with no direct reports. This posting names several areas, which could be wider than typical | `[grounded]` report; `[inferred]` that the posting is wider |
| Unknowns | Team size, who owns what, hiring manager, equity terms, first-year outcomes | — |
| Contradictions | None between your pasted JD and the fetched careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't stated where you live or any location constraint, so nothing settles this term | `[grounded]` posting terms; no candidate statement given | Ask whether the terms work (G1) |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor. The range sits within the market band (RR3), but that doesn't tell us whether it meets your floor | `[grounded]` posting and your message | Ask whether the range works (G1) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. Confirmed and specific, but self-reported and nothing inspectable yet, so expect a probe | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" rests on that and has no artifact behind it | `[grounded]` your stated background | none |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models. The qualifier "about" travels with the claim | `[grounded]` your stated background | none |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, so the stated requirement is met. BigQuery specifically is R9 | `[grounded]` your stated background | none |
| R7 | Airflow or similar orchestration | must_have | direct | medium | none | You used Airflow for orchestration. Nothing here shows how many DAGs, how complex, or who owned them | `[grounded]` your stated background | none |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations test suite. That is ownership of the setup, with no outcome stated | `[grounded]` your stated background | none |
| R9 | BigQuery warehouse | important | adjacent | medium | transferability | Your Snowflake and dbt work is the credible bridge. The limit is that you have never used BigQuery, so whatever differs between the two is unexercised in your history | `[grounded]` your statement; `[generic]` that warehouse skills carry across platforms in part | Frame as adjacent (E3); a small hands-on BigQuery project would narrow the limit |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Nothing you've told me mentions contracts or schema agreements with analysts. Related work may exist, e.g. your test suite or model conventions | `[grounded]` silence in your background | Ask G2 |
| R11 | Ingestion from the app and CRM | important | unclear | low | discovery | You haven't described what your pipelines ingested from, whether application databases, CRM or other sources | `[grounded]` silence in your background | Ask G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2, hard_gate) | hard_gate | Neither your location nor your pay floor has been stated | Gates the whole decision; a failed gate caps the status | Not applicable, since these are terms and not experience | Nothing to attach; your own statement settles it | `[grounded]` the posting's terms and the absence of your constraints |
| G2 | Data contracts (R10, important) | discovery | The map has no sign of agreements with analysts about table shape or freshness | The posting names contracts in its mandate sentence, so interviewers will likely ask | Schema or freshness expectations agreed with analysts; tests that fail a build when a model's shape changes; documented model owners | A model-conventions doc, a dbt schema file with tests (sanitized), or a Great Expectations suite description | `[grounded]` background silence; `[inferred]` that interviewers will ask |
| G3 | App and CRM ingestion (R11, important) | discovery | You've said nothing about your source systems | Ingestion is the first item in the posting's mandate | Loading from product databases, event streams, or a CRM; handling schema changes or API limits | A pipeline diagram or a sanitized DAG | `[grounded]` background silence; `[inferred]` from the JD's mandate order |
| G4 | BigQuery (R9, important) | transferability | Snowflake and dbt are the bridge; no BigQuery use | The one stack difference on the posting | A small project loading and modelling public data on BigQuery's free tier | A public repo or short write-up | `[grounded]` your statement; `[generic]` that a hands-on sample narrows this kind of limit |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team and ownership not stated | unknown | — | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | The post may own all three areas, wider than the report's typical one-domain scope, or may sit in a larger team | `[inferred]` from the JD's three areas against its silence on team; `[grounded]` the report's typical scope | How many data engineers are on the team today, and which of ingestion, warehouse models and contracts would I own? | unresolved |
| RR2 | No hiring manager or first-year outcomes | unknown | — | The posting names no hiring manager and states no outcomes | The reporting line and what success looks like are unknown | `[grounded]` posting is silent | Who would I report to, and what would a good first year look like? | unresolved |
| RR3 | Pay stated and in market range | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range sits within the report's band for this seniority and stage, with no seniority-pay mismatch | `[grounded]` posting and the Datawright report; whether the range is base salary is `[inferred]` | Is the range base salary, and where in it would my experience land? | noted |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Type, size and vesting are unknown, so its value can't be compared | `[grounded]` posting is silent | What is the equity grant: type, size and vesting? | unresolved |
| RR5 | Employer and posting check out | positive_signal | — | "Series C ($52M, February 2026)" | The employer exists as described and the posting is live and consistent. The funding figure is the company's own statement | `[grounded]` careers page fetched, about page as returned by search | What is the runway, and how is the data team expected to grow? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead a bullet with your own words: "Built our dbt project on Snowflake — about 180 models" | R5, R6 | `[grounded]` your sentence | resume_edits_pending_approval |
| E2 | Add: "Set up our Great Expectations test suite", and name Airflow for orchestration | R7, R8 | `[grounded]` your sentences | resume_edits_pending_approval |
| E3 | If asked, say: "I haven't used BigQuery; my warehouse work is on Snowflake" | R9; keeps the bridge honest | `[grounded]` your statement | pending your approval |
| Q1 | Ask the register's verification questions (RR1, RR2, RR4) in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A1 | Settle R1 and R2 against your own location and floor before investing in the process | Hard gates | `[grounded]` R1, R2 | pending your approval |
| A2 | Optional: a small BigQuery project | Narrows R9's limit | `[generic]` pattern | pending your approval |

I left "data contracts" and "ingestion from CRM" out of every proposed line, because nothing you've told me covers them yet. The resume-tailor module can turn E1–E2 into a full edit ledger once you decide to apply.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about); fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Role reality: the posting is live and matches your paste, so no employer-not-established entry; RR5 |
| 2. Role-family sweep | skipped | The Datawright report you supplied already fixes market calibration and the pay mismatch check (RR3) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can run deeper company diligence next: funding and leadership changes, hiring patterns, and public employee reports.

If you'd like, I can save this as a `tuesday-dossier.md` for reuse.

**Upgrade menu**

- Your location and pay floor → R1 and R2 resolve, and the decision likely simplifies to `go` or `no_go`.
- Answers to G2 and G3 → R10 and R11 firm up.
- A sanitized dbt schema file or Great Expectations suite description → R5 and R8 can reach `high`.
- The hiring manager's name → the scope read and which of your stories to lead with.
- Deeper diligence on Pellucid (up to 5 more searches and 2 more fetches) → RR5 firms up. Say the word and it runs.

**Questions**

G1 — Do the location terms (Remote US or Denver) and the $148,000–$166,000 range both work for you?

G2 — Have you set up agreements with analysts about what your tables look like or how fresh they are, or tests that enforce them? What did you own?

G3 — What sources did your pipelines ingest from, such as product databases, event data or a CRM, and what was yours to build?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.