Search permission was denied, so I'm going on the JD and your background alone. Here's the underwriting.

## Decision snapshot

**Yes, apply, and yes, you're a fit: R1, R2, R3, R4 and R5 are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5 · unclear: R6 (Define and maintain the metrics layer)
- `important` — direct: R7a · adjacent: R7b (Partner with clinicians) · unclear: R8 (Mentor two junior analysts)
- `preferred` — adjacent: R9 (Healthcare data experience, HIPAA)

R9 (`medium`) — a credible bridge, its limit named; R6, R8 — the background you gave is silent either way.

**Opportunity ledger.** The role is clearly scoped, with named tools and named mentees (RR4), but I couldn't verify the employer from here (RR1), and pay and work arrangement are unstated (RR2, RR3). Metrics layer, experimentation, dashboards, mentoring and clinician partnership all sit in one post (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting verify (RR1); (2) pay and work arrangement are acceptable to you (RR2, RR3); (3) metrics-layer ownership is something you've done or can credibly take on (R6, RR5); (4) healthcare is framed as an adjacent bridge, never as HIPAA experience (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C | `[grounded]` JD header; not independently checked |
| Mandate | Product analytics for the care-navigation app: metrics layer, A/B tests, Looker self-serve, roadmap partnership, mentoring two juniors | `[grounded]` JD |
| Success outcomes | None stated | `[grounded]` JD silent |
| Scope read | The tool stack and the two named mentees are concrete; the metrics-layer ownership is not (is there an analytics engineer?) | `[inferred]` from the JD's responsibility list against its silence on team structure |
| Market calibration | Not run: the search was refused | — |
| Unknowns | Pay, location or remote policy, reporting line, who owns data transformation, how much clinician contact the role has | `[grounded]` JD silent on each |
| Contradictions | None found within the JD; no second source was read | `[grounded]` JD only |

## Evidence map

Your background was typed in, so it counts as self-report: leads, not proof. That's why `medium` is the ceiling here.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years of product analytics at a meal-kit subscription company. Confirmed in prose, no inspectable artifact | `[grounded]` your background | none |
| R2 | Expert SQL | must_have | direct | medium | none | "SQL daily on a Snowflake warehouse" supports daily, hands-on use. "Expert" is a level the interview will probe | `[grounded]` your background; `[generic]` that SQL level is usually tested live | Be ready for a live SQL exercise |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program: 30+ A/B tests a year, including the pricing test behind an 11% retention lift. What "at scale" means here (traffic, concurrency) isn't stated | `[grounded]` your background | Pin down what the 11% measures (see Q2 in the plan) |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the company's Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your background | none |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly metrics memo the exec team reads and present to the VP Product monthly | `[grounded]` your background | A sanitized memo would raise it to `high` |
| R6 | Define and maintain the metrics layer | must_have | unclear | low | discovery | "Governed dashboards" hints at shared definitions, but you didn't mention a semantic layer, LookML models, a dbt layer or a metric dictionary | `[grounded]` your background is silent on definitions; `[generic]` that "governed" in Looker often means modeled definitions | G1 |
| R7a | Partner with product managers | important | direct | medium | none | Monthly presentations to the VP Product. Day-to-day PM partnership isn't described | `[grounded]` your background | none |
| R7b | Partner with clinicians | important | adjacent | low | transferability | You work with non-technical stakeholders, but no clinical or domain-expert partners are mentioned. Limit: it hasn't been exercised with clinicians | `[inferred]` from your exec and VP communication work | G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in your background mentions mentoring or managing | `[grounded]` your background is silent | G2 |
| R9 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | You've handled GDPR/CCPA consumer PII and built the consent-state model for the warehouse. That's regulated personal-data work. Limit: no health data, no PHI, no HIPAA | `[grounded]` your background; `[generic]` that employers often treat regulated-data discipline as a partial substitute | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | Governed dashboards, but no named definitions layer | It's the JD's first responsibility, and a `must_have` at `unclear` is what holds the decision at `conditional_go` | A LookML model others built on; a metric dictionary or KPI definitions doc; reconciling conflicting definitions of churn or retention across teams | A metric-definition doc, LookML project structure (sanitized), a retention-definition RFC | `[grounded]` background silent; `[generic]` that roles like this usually ask who owns definitions |
| G2 | Mentoring (R8, important) | discovery | Nothing stated | The role names two juniors; a "no" shapes how you pitch it | Onboarding a new analyst; reviewing others' queries or dashboards; running an analytics office hour | Nothing formal needed; a short example is enough | `[grounded]` background silent |
| G3 | Clinician partnership (R7b, important) | transferability | Stakeholder work, no clinical contact | It's the role's distinctive collaboration | Working with any domain experts (ops, culinary or nutrition teams, medical advisors) to turn analysis into decisions | An example where a domain expert changed or accepted a result | `[inferred]` bridge from stakeholder work |
| G4 | Healthcare data (R9, preferred) | transferability | Consent-state model, GDPR/CCPA, no PHI | It's the preferred item; a stronger bridge narrows the obvious objection | Access controls, de-identification or audit work in the consent model; DPIAs or privacy reviews you contributed to | The consent-state model's design doc (sanitized) | `[inferred]` bridge; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | unknown | — | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | I couldn't check the employer or the live posting because search was refused. Nothing negative is implied | `[generic]` pattern for any posting not yet checked, not a claim about this one | Can you point me to this role on your own careers site, and who I would interview with? | unresolved |
| RR2 | Compensation not stated | unknown | — | no pay figure in the JD | The band may or may not fit your target, and a withheld figure is itself worth asking about | `[inferred]` from the JD's silence | What is the salary range for this post? | unresolved |
| RR3 | Location or work arrangement not stated | unknown | — | no location in the JD | It may be remote, hybrid or onsite, which matters for your constraints | `[inferred]` from the JD's silence | Where is this role based, and what is the in-office expectation? | unresolved |
| RR4 | Clearly scoped responsibilities and tooling | positive_signal | — | "build self-serve dashboards in Looker … mentor two junior analysts" | The scope reads concrete, with a named tool and a defined team | `[grounded]` JD | Who are the two analysts, and how long have they been in role? | noted |
| RR5 | Several specializations in one post | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards … mentor" | You may be doing the work of an analytics engineer plus an experimentation lead plus a team lead | `[inferred]` from the breadth of the responsibility list; `[generic]` that this breadth often means a stretched role | Is there an analytics engineer or data platform team who owns the transformation layer, or does this role? | unresolved |

Nothing here is a request made of you, so nothing needs a hold beyond RR1's check.

## Application plan

All proposed, nothing applied. If you decide to apply, resume-tailor can turn these into a resume edit ledger.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the experimentation program and the Looker build, since these cover R3 and R4, and the pricing test is the strongest single item. Draft framing: "Designed and ran an A/B testing program of 30+ tests a year, including the pricing test behind an 11% retention lift." | R3, R4. Each clause traces to your sentence; the 11% stays attached to the retention lift, and I haven't said what it measures | `[grounded]` your background | pending your approval |
| E2 | Frame the consent-state model as regulated personal-data work: "Built the warehouse's consent-state model under GDPR and CCPA." Don't write "healthcare data" or "HIPAA-compliant" | R9: the limit is that it's consumer PII, not PHI | `[grounded]` your background | pending your approval |
| E3 | Add a sanitized memo or metrics-definition example as a work sample | R5, R6 | `[grounded]` rows R5, R6 | pending your approval |
| Q1 | Ask the verification questions of RR1, RR2, RR3 and RR5 verbatim in the loop | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A1 | Say plainly in the interview that healthcare is new to you and you've worked with regulated personal data | Candor holds up under probing | `[generic]` role-family pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers"; the call was refused. It would have confirmed the employer exists as described and the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range experimentation Looker"; the call was refused. It would have set a market band for the role (RR2) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can offer a one-line extra: a short talk-track for the "why healthcare, and what's your HIPAA story" question, since R9 is the likeliest objection. Say the word and I'll build it.

## Dossier offer

If you'd like, I can save this as a `tuesday-dossier.md` so it carries into any later step.

## Upgrade menu

- Search access (or the careers page link) → RR1 closes, and a market band lets me check pay against your floor (RR2).
- A metric-definition doc, LookML structure, or a sentence on who owned definitions → R6 moves toward `direct`, and the decision likely simplifies to `go`.
- A note on mentoring or onboarding anyone → R8 closes.
- A sanitized memo or the pricing-test writeup → R5 and R3 toward `high`.
- Your pay floor and location needs → hard-gate checks run instead of showing unknown.

## Questions

G1 — Have you defined or maintained shared metric definitions (LookML, dbt, a metric dictionary) that other teams relied on? What did you own, and who used them?

G2 — Have you mentored, onboarded or reviewed the work of other analysts, formally or not?

C1 — What's your pay floor and your location or remote needs, so I can check them against this role?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.