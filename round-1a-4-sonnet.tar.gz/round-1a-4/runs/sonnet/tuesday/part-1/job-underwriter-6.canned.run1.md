## Decision snapshot

**Probably yes, as a stretch, but I can't call it yet. Status: `hold_pending_answers`.** R1 and R2, both hard gates, can't be cleared until I know your location and pay floor. R6 and R9, both must-haves, are absent.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, two office days), R2 (Pay £61,500–£67,000 plus options)
- `must_have`: direct: R3, R4, R5a, R7 · adjacent: R5b (Spreadsheet modelling) · unclear: R8 (Finance on billing or revenue data) · absent: R6 (Owning a forecast), R9 (Owning billing data)

R6, R9: confirmed by you, the sharpest gaps; R8 (`low`): a revenue-data bridge may exist, waiting on your answer; R1, R2: can't be cleared until your constraints are known.

**Opportunity ledger.** The employer, the pay band and the hiring manager's public path all line up with the posting (RR1, RR3, RR6). The posting isn't yet located on Quillfield's own careers page (RR2). Option terms and team support are unstated (RR4), and four mandates sit in one post (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, two office days), R2 (Pay £61,500–£67,000 plus options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** your answer on G1 (R1, R2) and G2 (R8), plus the recruiter's answers to RR2, RR4 and RR5. If both gates clear, I'd expect `conditional_go`, with R6 and R9 carried as material risks. If either gate fails, `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` "About Quillfield" page |
| Role and location | Revenue Operations Lead, Bristol, hybrid, two days a week in the office | `[grounded]` JD |
| Pay | £61,500–£67,000 plus share options; option terms not stated | `[grounded]` JD |
| Mandate | Own CRM and billing data; build the pipeline and renewal reporting sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Hiring manager | Tamsin Achebe, per the recruiter via you. Public profile: Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` your statement; `[grounded]` profile search result |
| First-year outcomes | Not stated in the posting | `[grounded]` JD silence |
| Scope read | One lead post carrying four mandates, with team size unstated. The forecast is run "with the CFO", so it is shared rather than solely owned | `[inferred]` from the JD wording |
| Market calibration | The Ledgerline 2026 survey of UK B2B software revenue operations leads (n=438) gives a median base of £64,200 and an interquartile range of £57,800–£70,400. The posted band sits inside it. This is the market band, not this employer's offer | `[generic]` survey; `[grounded]` JD figure |
| Unknowns | Team or analyst support; option terms; which mandates are solely owned versus shared with finance; billing system | `[grounded]` JD silence |
| Contradictions | None between the posting and the company page. The posting isn't located on Quillfield's own careers page (the address I tried returned no page, RR2) | `[grounded]` page and fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | The JD states the term. You haven't given your location or whether two office days works, so it can't be settled | `[grounded]` JD; your constraint not stated | G1 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | none | hard_gate | The term is stated. Your pay floor isn't given. The band sits inside the survey's interquartile range, but that says nothing about your floor | `[grounded]` JD; `[generic]` survey band | G1 |
| R3 | 4+ years in revenue operations, sales operations or similar at a B2B software company | must_have | direct | medium | none | 5 years in sales operations, the last 2 running revenue operations for the UK team, clears the years. You described the employer as a B2B payments company; whether its product counts as software wasn't stated | `[grounded]` your background | Describe the employer's product as it actually is; the recruiter call will settle it |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified is your statement. No certificate has been inspected | `[grounded]` your background | Your Salesforce credential record would raise this to `high` |
| R5a | Strong SQL | must_have | direct | medium | none | SQL weekly states frequency, not strength. "Strong" is the posting's word and is unprobed | `[grounded]` your background | A sanitized query you wrote would raise it |
| R5b | Spreadsheet modelling | must_have | adjacent | medium | discovery | Excel daily and rebuilt dashboards are stated. Building forward-looking models isn't, and that is the limit of the bridge | `[grounded]` your background | G4 |
| R6 | Experience owning a forecast | must_have | absent | none | capability | You confirmed you've never owned the company forecast, as finance did. Running the monthly pipeline review is adjacent but isn't forecast ownership. The JD pairs this with running the quarterly forecast with the CFO | `[grounded]` your statement and JD | Closure path: A5, a small forecast work sample. Otherwise carry as a material risk |
| R7 | Build pipeline and renewal reporting that sales and finance run on | must_have | direct | medium | none | You rebuilt the pipeline and renewal dashboards. Whether finance used them wasn't stated | `[grounded]` your background | Confirm finance's use if it comes up |
| R8 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | You've never worked on billing data. The "or revenue data" half might be met by the renewal dashboards, but no work with finance is stated | `[inferred]` from the renewal dashboards against the JD's "or" | G2 |
| R9 | Own the billing data | must_have | absent | none | capability | You confirmed you've never worked on billing data. This is the JD's responsibility side of the billing requirement | `[grounded]` your statement and JD | Carry as a material risk; no honest bridge on current evidence |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2, hard_gate) | hard_gate | The posting states both terms. Your constraints aren't given | A failed gate means `no_go` however strong the fit elsewhere | n/a: this asks whether the gate is met, never for a workaround | None needed beyond your own statement | `[grounded]` JD terms; your constraints not given |
| G2 | Working with finance on billing or revenue data (R8, must_have) | discovery | The renewal dashboards touch revenue, but no joint work with finance is stated | This could move R8 from `unclear` to `adjacent` and soften the biggest objection | Reconciling renewals or bookings with finance; supplying pipeline numbers to finance's forecast; agreeing a revenue definition with finance | A renewal report finance used; a reconciliation sheet; a definitions doc | `[grounded]` your background silence; `[generic]` that revenue-operations roles usually involve finance on revenue definitions |
| G3 | Owning a forecast (R6, must_have) | capability | You've never owned one. The pipeline review is adjacent only | The JD lists it as a requirement and as a duty with the CFO | none stated | A small forecast model you build (A5) | `[grounded]` your statement; `[inferred]` the work sample as the closure path |
| G4 | Spreadsheet modelling (R5b, must_have) | discovery | Daily Excel is stated, forward-looking models aren't | Separates "uses spreadsheets" from "models in them" | A pipeline-coverage model; a renewal forecast; a commission or capacity model | A sanitized workbook or screenshot | `[grounded]` your background; `[generic]` that this is the usual reading of "modelling" |
| G5 | Owning billing data (R9, must_have) | capability | You've never worked on billing data | It's one of the four mandates in the post | none stated | none | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting | positive_signal | — | "Revenue Operations Lead, Quillfield. Bristol, hybrid" | Quillfield exists as a Bristol-founded invoicing and payments software firm, consistent with the posting | `[grounded]` "About Quillfield" page | Which team does this role sit in, and who does it report to? | noted |
| RR2 | Posting not located on the company's own careers page | unknown | — | "Revenue Operations Lead, Quillfield" | The address I tried returned no page. The role may sit at another address or be listed only via the board and the recruiter | `[inferred]` from one fetch returning no page | Can you point me to this role on Quillfield's own careers page? | unresolved |
| RR3 | Stated pay sits inside the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The range falls inside the survey's interquartile range of £57,800–£70,400 and around its median of £64,200 | `[grounded]` JD figure; `[generic]` survey band, not this employer's offer | Does the range flex with experience? | noted |
| RR4 | Option terms and team support unstated | unknown | — | "plus share options" | Vesting, strike price and share count aren't given, and the posting says nothing of reports or analyst support | `[grounded]` JD silence | What are the option terms, and does the role have reports or analyst support? | unresolved |
| RR5 | Four mandates in one post | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting our sales and finance teams run on, and run the quarterly revenue forecast with the CFO" | CRM data, billing data, reporting and forecasting may be folded into one post. Severity stays low because "with the CFO" suggests the forecast is shared | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` JD wording | Which of these does the role own end to end, and which does finance share? | unresolved |
| RR6 | Hiring manager's public path runs through sales operations | positive_signal | — | "the hiring manager is Tamsin Achebe" (your recruiter, via you) | Tamsin Achebe is Head of Revenue Operations, previously sales operations manager at a payments company for four years. That she manages this role rests on the recruiter's word | `[grounded]` profile search result; recruiter's statement via you | How is work divided between this role and the Head of Revenue Operations? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle your location and pay floor (G1) before investing application effort | R1, R2 | `[grounded]` map | pending your approval |
| A2 | Ask the recruiter RR2, RR4 and RR5 verbatim | The register doubles as call prep | `[grounded]` register | pending your approval |
| A3 | Lead with the pipeline and renewal dashboards you rebuilt and the monthly pipeline review you run with your sales director | R7. This is the closest shared ground with Tamsin Achebe's public sales-operations path | `[inferred]` from the profile and R7 | pending your approval |
| A4 | Say plainly that finance owned the company forecast and you haven't owned one, and that you haven't worked on billing data. Then describe what you did own | R6, R9. These are the points a hiring call is likely to probe | `[generic]` hiring pattern; `[grounded]` R6, R9 | pending your approval |
| A5 | Optional work sample: a small forecast model built on sanitized pipeline data | Narrows the limit on R6 and R5b without claiming ownership | `[inferred]` from the gaps | pending your approval |

## Evidence status

Verified: none yet. Your background was typed in conversation, so it is self-report and stays at `medium` at most.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers" and got "About Quillfield" (quillfield.co.uk/about). Fetched quillfield.co.uk/careers, which returned no page. This moved the organization row and RR1 and RR2 |
| 2. Role-family sweep | yes | Searched "revenue operations lead B2B SaaS UK salary Bristol" and got "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). This moved the market calibration row, R2's reasoning and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield" and got "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe), read as a search snippet only. This moved RR6 and A3 |

I can save this as a `tuesday-dossier.md` whenever you want one.

**Upgrade menu**

- Your location against two office days, and your pay floor → R1 and R2 settle, and either could flip the status to `no_go`.
- An answer on finance and revenue data → R8 moves, which could soften the biggest objection.
- A sanitized query, workbook, or your Salesforce credential record → R5a, R5b and R4 can rise toward `high`.
- The recruiter's answers on RR2, RR4 and RR5 → the register entries close.
- A deeper research pass on Quillfield (funding and leadership changes, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Where would you be based against two Bristol office days a week, and what's the lowest salary you'd accept for this role?

G2 — Have you worked with finance on revenue numbers, for example reconciling renewals or bookings, or feeding your pipeline figures into their forecast? What did you own, and who used the result?

G4 — Which spreadsheet models have you built yourself that projected pipeline, renewals or revenue forward, and who relied on them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.