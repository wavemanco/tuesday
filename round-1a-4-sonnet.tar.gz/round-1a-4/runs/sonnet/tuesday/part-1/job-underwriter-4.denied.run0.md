Search permission wasn't granted, so I'm assessing from your JD and background alone.

# Job Underwriting Assessment — Senior Pricing Analyst at Brindlemoor

## Decision snapshot

**Yes, apply, on conditions. Status: `conditional_go`.** Neither worry is a requirement in the posting as you pasted it. R8 asks for insurance experience as "a plus", not pet insurance. No row asks for line-management experience, and RR3 asks whether the role has reports at all.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote UK)
- `must_have` — direct: R2, R3, R4, R5, R6
- `important` — adjacent: R7 (Own pricing analytics for the product)
- `preferred` — direct: R8

R7 — your GLM ownership was one book, and the pet product's scope is unstated; R1 — location and right to work not yet stated by you.

**Opportunity ledger.** Plausible but unchecked. The employer is unverified because no search ran (RR1), the salary is not stated (RR2), and whether the role has reports or only recommends is not stated (RR3). One entry runs the other way: the responsibilities are specific (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and a live posting verify, see RR1; (2) you confirm you are UK-based with the right to work, see R1; (3) the salary and the team and reporting scope suit you, see RR2 and RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; existence not yet checked | `[grounded]` JD header; no search ran |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing; reporting line not stated | `[grounded]` your message |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Management scope | No direct reports or team are mentioned in the posting as pasted | `[grounded]` JD silence |
| Market calibration | Not established. The role-family sweep did not run, so no salary band is given | `[grounded]` the sweep was unavailable (see Evidence status) |
| Hiring manager's footprint | Not established; the search did not run | `[grounded]` see Evidence status |
| Unknowns | Salary, team size, contract type, tooling, first-year outcomes, decision rights over price changes | `[grounded]` absent from the JD |
| Contradictions | None inside the pasted JD; not compared with a careers page | `[grounded]` JD only |

## Evidence map

Your background is typed prose, which counts as CV-equivalent self-report. Nothing here rises above `medium` until you attach something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | low | hard_gate | You have not stated where you live or your right to work. You work at a UK insurer, which suggests but does not settle it. Confidence grades your statement of the constraint, and you have not made one | `[grounded]` JD term; `[inferred]` from your UK employer | Question 1 below |
| R2 | "4+ years pricing or actuarial analytics" | must_have | direct | medium | none | You stated 5 years of pricing analytics at a UK motor insurer, 2 as senior analyst. Specific and plausible, with no artifact inspected | `[grounded]` your background | Offer: a CV or LinkedIn date range would let me check the periods |
| R3 | "strong SQL and Python" | must_have | direct | medium | none | You stated daily use of both. "Strong" is self-assessed, and no repository or sample has been inspected | `[grounded]` your background | Offer: a sanitized query or notebook would raise it |
| R4 | "GLM experience" | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. That is GLM experience on motor, and the JD does not require the pet product | `[grounded]` your background | Offer: a model-documentation excerpt would raise it |
| R5 | "design and read price tests" | must_have | direct | medium | none | You stated 14 price tests last year, run with the underwriting team. Whether you designed or only read each one is not stated, so I take the lower reading | `[grounded]` your background | Offer: one sanitized test write-up |
| R6 | "presenting to underwriting or actuarial leads" and turning results into recommendations | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting, which matches the audience the JD names | `[grounded]` your background | Offer: a sanitized review deck |
| R7 | "Own pricing analytics for our pet-insurance product" | important | adjacent | low | discovery | You owned one model for one book. The JD says "own" for a whole product, and it is not stated whether your scope was end to end. Pet rating will differ from motor, and I have not researched how | `[grounded]` your background; `[generic]` that a new product line usually means new rating factors | G1, and question 2 below |
| R8 | "insurance experience a plus" | preferred | direct | medium | none | Five years at a motor insurer meets a general insurance preference. The JD does not ask for pet experience | `[grounded]` JD and your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-to-end ownership of pricing analytics (R7, important) | discovery | You built and maintained the young-driver GLM and ran tests and reviews. Whether you also owned the data pipeline, the monitoring and the final recommendation is not stated | It shapes how credibly you can say "owned" for the pet product, and whether R7 reads `direct` | Owning model monitoring (drift, actual-versus-expected); writing the recommendation that went to underwriting; deciding which tests to run; changing a rating factor after a test result | A monitoring dashboard screenshot, a model-change log, a pricing-review deck | `[grounded]` background silence on scope; `[generic]` that "own" in a senior pricing title usually implies the full loop |
| G2 | UK location and right to work (R1, hard_gate) | hard_gate | Not stated | A gate the inputs do not settle stays open until you answer | none; this is a fact, not experience | none needed | `[grounded]` your message is silent |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources (no search ran, so unchecked rather than failed) | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Compensation not stated | unknown | — | (no salary or band appears in the posting as pasted) | The figure may sit anywhere relative to market, or may have been left off the pasted copy | `[inferred]` from the pasted JD's silence | What salary band is budgeted for this post? | unresolved |
| RR3 | Team structure and decision rights unstated | unknown | — | "turn the results into recommendations for underwriting and product" | You may be the only pricing analyst on the product, or part of a team. Recommendations go to two functions, and who decides on price changes is not stated | `[inferred]` from "recommendations" and the silence on reports and authority | Does this role have direct reports or sit in a team, and who decides on pricing changes? | unresolved |
| RR4 | Responsibilities are specific | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The mandate is concrete and maps to named work | `[grounded]` JD | What does success look like in this role's first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead your CV and cover note with the young-driver GLM you built and maintained, the 14 price tests run with underwriting last year, and the quarterly pricing review you present to the head of underwriting. Keep the wording to your own sentences: "built and maintained", not "owned" | see R4, R5, R6 | `[grounded]` your background | pending your approval |
| P2 | Say plainly that your experience is motor, not pet. The JD lists insurance as a plus and never names pet | see R8 | `[grounded]` JD | pending your approval |
| P3 | If management comes up, say you haven't managed anyone. The posting as pasted asks for none, and RR3 is how you find out if this role has reports | see RR3 | `[grounded]` JD and your background | pending your approval |
| P4 | Check the role on Brindlemoor's own careers page before investing effort | see RR1 | `[grounded]` register | pending your approval |
| P5 | Ask RR2, RR3 and RR4's questions verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (the company name with its product; the company name with the job title) were refused because search permission was not granted. It would have settled RR1 and the contradictions row |
| 2. Role-family sweep | unavailable | One search (senior pricing analyst, pet insurance, UK) was refused. It would have given the market calibration line and the RR2 comparison |
| 3. Hiring manager's public footprint | unavailable | One search on the name you gave was refused. It would have moved role reality's scope read and which story the plan leads with |

## Upgrade menu

- Permission to search runs the three targets above and settles RR1, the market calibration for RR2, and the scope read.
- A CV or LinkedIn date range moves R2 toward `high`; a sanitized model write-up, query or test summary does the same for R3, R4 and R5, and a pricing-review deck for R6.
- A monitoring dashboard or model-change log would close G1 and move R7 toward `direct`.
- The salary band and the answer on reports close RR2 and RR3, and the decision likely simplifies to `go`.

I can save this as a `tuesday-dossier.md` if you'd like to keep or reuse it.

**Questions**

1. R1 — Are you UK-based with the right to work in the UK, and is fully remote what you want?
2. G1 — On the young-driver book, did you own the whole loop (monitoring, deciding which tests to run, writing the recommendation), or part of it alongside others?
3. RR2 — Do you have a minimum salary or any other hard limit that would end this for you, given the posting names no pay?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.