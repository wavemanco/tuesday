# Job Underwriting Assessment: Senior Data Engineer, Pellucid Learning

## Decision snapshot

**Yes, this is worth applying to, with conditions: your fit is strong, but R1 and R2, your location and pay terms, haven't been checked against you. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Remote in the US, or Denver office), R2 (Pay $148,000–$166,000 plus equity)
- `must_have`: direct: R3, R4, R5, R6, R7, R8
- `important`: adjacent: R9 (BigQuery as the role's warehouse); unclear: R10 (Ingestion from the app and CRM), R11 (Data contracts analysts depend on)

R9: a credible Snowflake-to-BigQuery bridge, its limit named; R10: ingestion work unconfirmed; R11: contracts work unconfirmed.

**Opportunity ledger.** The pay is stated and sits inside your recruiter's report's range (RR3). The team and reporting line (RR1) and the equity terms (RR2) are unstated. The posting itself went unchecked because my fetches were refused (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote in the US, or Denver office), R2 (Pay $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 confirmed as meeting your terms; (2) RR1's answer on team shape and reporting line is acceptable; (3) the BigQuery gap (R9) is stated plainly and never presented as experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the about text you pasted; not checked against the live page |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on | `[grounded]` JD |
| Requirements stated | 5+ years data engineering; strong SQL and Python; dbt and a cloud warehouse; Airflow or similar; data quality testing | `[grounded]` JD |
| Pay and location | $148,000–$166,000 plus equity (no equity terms); Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Four duties are named (ingestion, warehouse, contracts, running the pipelines) with no team, manager or direct reports mentioned. That reads as the whole reporting data stack, a little broader than the one-domain scope the Datawright report calls typical. How broad depends on whether you would be the only data engineer | `[inferred]` from the JD's four duties against its silence on team, set against the report's "ownership of one domain's pipelines with no direct reports" |
| Market calibration | The report gives, for Senior Data Engineer at Series B–D companies, a base median of $151,000 and an interquartile range of $139,000–$163,500, and says "Senior" typically means 5–8 years. The posting's floor is $3,000 under that median and its ceiling is $2,500 over the upper quartile. Your 6 years sit inside the 5–8 range. This is the cohort's pattern, never this employer's offer | `[grounded]` posting and the report you sent; `[generic]` as a cohort pattern |
| Unknowns | Hiring manager and team size; equity grant; on-call expectations; whether the posting is still live | `[grounded]` JD silence |
| Contradictions | None between the JD and the about text as you pasted them; neither page could be fetched to compare | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote in the US, or Denver office | hard_gate | unclear | none | hard_gate | The posting offers two arrangements. You haven't said where you are or what you will accept, so met or failed can't be called | `[grounded]` JD; no constraint stated by you | Question Q1 |
| R2 | Pay $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | The range is stated, but your floor isn't, and equity terms are unstated (RR2) | `[grounded]` JD; no floor stated by you | Question Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years of data engineering at a B2B payroll company. It is a length-of-experience requirement, not a gate. Confirmed prose, nothing inspectable yet | `[grounded]` your statement | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You state both daily. "Strong" is unprobed. Roles like this commonly test SQL and Python live | `[grounded]` your statement; `[generic]` on live testing | Offer: a sanitized code sample would raise to high |
| R5 | dbt | must_have | direct | medium | none | You built your company's dbt project on Snowflake, about 180 models. Specific and plausible, no artifact inspected | `[grounded]` your statement | Offer: dbt docs site or manifest excerpt would raise to high |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and you ran dbt on it | `[grounded]` your statement | none |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | You state Airflow for orchestration. Your ownership of the DAGs isn't specified, so expect a probe | `[grounded]` your statement | Offer: a sanitized DAG listing would raise to high |
| R8 | Data quality testing | must_have | direct | medium | none | You set up your company's Great Expectations test suite. Specific, nothing inspected | `[grounded]` your statement | Offer: suite config or Data Docs output would raise to high |
| R9 | BigQuery as the role's warehouse | important | adjacent | medium | transferability | Posting names BigQuery in its description of the work, not in its requirements list, which says "a cloud warehouse". You have never used BigQuery. The bridge is the dbt-on-Snowflake work. The limit is that no BigQuery-specific work is yours | `[grounded]` JD and your statement; inferred requirement from the JD's responsibilities line | See G1 |
| R10 | Ingestion from the app and the CRM | important | unclear | low | discovery | Posting makes it core work. You described pipelines in Airflow but not which sources fed them | `[grounded]` JD; your silence on sources | Question G2 |
| R11 | Data contracts analysts depend on | important | unclear | low | discovery | The Great Expectations suite is nearby, but nothing you've said covers agreed schemas or freshness commitments to analysts | `[grounded]` JD; your silence on contracts | Question G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R9, important) | transferability | Adjacent: about 180 dbt models on Snowflake. Limit: no BigQuery work of your own. Strengthener: a small dbt project run against BigQuery | The posting's own description of the work names BigQuery, so it is the first warehouse question to expect | Any BigQuery use through an analyst tool or a side project; running the dbt BigQuery adapter; a migration you scoped or reviewed | A repo or short write-up of a small BigQuery project | `[grounded]` JD and your statement; `[generic]` that screens often probe the named warehouse |
| G2 | Ingestion from app and CRM (R10, important) | discovery | Pipelines in Airflow, but no sources named | Ingestion is the first duty the posting lists; an answer could move R10 to direct | Loading from a product database or event stream; pulling from a CRM or other SaaS APIs; building or maintaining connectors; handling API limits or schema changes | A sanitized DAG listing, an architecture sketch, a runbook | `[grounded]` JD and your silence; `[inferred]` that this decides how R10 reads |
| G3 | Data contracts (R11, important) | discovery | A test suite you set up, nothing about agreed interfaces with analysts | The posting names contracts as something analysts depend on | Agreed schema or freshness expectations on tables analysts used; tests that blocked a bad load; communicating breaking changes | Great Expectations Data Docs output, a schema-change process note | `[grounded]` JD and your silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Team shape and reporting line unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | You may be the only data engineer owning ingestion, warehouse and contracts end to end, or one of a team. The posting names no manager | `[inferred]` from the JD's four duties against its silence on team and manager | Who would I report to, how many data engineers and analysts are there today, and who is on call for the pipelines? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus equity" | Grant size, type and vesting aren't given, so the cash range may be the only figure to compare | `[inferred]` from the posting's omission | What is the equity grant for this level, and what are its type, vesting schedule and valuation basis? | unresolved |
| RR3 | Pay stated and within the pasted report's range | positive_signal | — | "$148,000–$166,000 plus equity" | The range is transparent and consistent with the cohort figures: $3,000 under the median at the floor, $2,500 over the upper quartile at the ceiling | `[grounded]` posting and the Datawright report you sent; `[generic]` cohort pattern, not this employer's offer | Where in this range would my background place me, and is the range fixed for the level? | noted |
| RR4 | Posting and company details not checked against the company's own pages | unknown | — | "Series C ($52M, February 2026)" | Liveness of the posting and the funding claim rest on your paste alone, because my fetches were refused | `[grounded]` fetch refusal in Evidence status | Is this role still open, and who is the hiring manager? | unresolved |

## Application plan

E1–E3 are `resume_edits_pending_approval`; nothing here is applied or sent until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the data-engineering bullets with "Built the dbt project on Snowflake (about 180 models)" | R5, R6; these are your words, in front | `[grounded]` your statement | pending your approval |
| E2 | Add "Set up the Great Expectations test suite". Don't write "data contracts" or "data quality program" until G3 is answered | R8; contracts work isn't yet confirmed | `[grounded]` your statement | pending your approval |
| E3 | Add "Used Airflow for orchestration; Python and SQL daily" | R4, R7 | `[grounded]` your statement | pending your approval |
| P1 | Say it plainly if asked: "I've built dbt on Snowflake and haven't used BigQuery." Don't list BigQuery on the resume | R9; says exactly what you told me, no more | `[grounded]` your statement | pending your approval |
| W1 | Optional: a small dbt project run against BigQuery, shared as a link | G1; narrows the limit on R9, doesn't erase it | `[inferred]` from the gap | pending your approval |
| A1 | Ask RR1 and RR2's questions verbatim in the first screen | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A2 | Check the role on the company's own careers page before investing effort | RR4 | `[grounded]` RR4 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Fetches of pellucidlearning.com/careers/senior-data-engineer and pellucidlearning.com/about were both refused (permission not granted), so nothing was read. It would have confirmed the posting is live and the company details, feeding role reality's contradictions row and RR4 |
| 2. Role-family sweep | skipped | The Datawright report you sent is in hand and fixes the market calibration row and RR3, so a search could change nothing |
| 3. Hiring manager's public footprint | n/a | The posting names no hiring manager, so there is no query to form |

## Dossier and upgrade menu

I can save this as a `tuesday-dossier.md` if you'd like to carry it into later steps.

- Your location, work authorization and pay floor → R1 and R2 resolve to met or failed, and the decision becomes `go` or `no_go`.
- Answers to G2 and G3 → R10 and R11 move toward `direct`.
- Inspectable artifacts for data engineering: a dbt docs site or manifest excerpt, Great Expectations Data Docs output or suite config, a sanitized Airflow DAG listing → R5, R7 and R8 can rise to `high`.
- Checking the careers page yourself, or allowing a fetch → RR4 closes.
- The hiring manager's name → the scope read and which story to lead with.
- The equity terms → RR2 closes.
- A deeper research pass on Pellucid Learning (funding, leadership churn, public reports; up to 5 more searches and 2 more fetches) would need the fetch permission that was declined; say the word if you want it.

**Questions**

- Q1 (R1, R2): Can you work from within the US on the posting's terms, and does $148,000–$166,000 clear your pay floor?
- G2: Which sources fed your pipelines at the payroll company (a product database or event stream, a CRM or other SaaS APIs)? What did you own, and what happened?
- G3: Did analysts depend on tables you were responsible for, with agreed schemas or freshness expectations? What did you own, and how were they enforced?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.