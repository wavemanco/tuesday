Working from your JD and background only, since the web lookups were declined. Here is the assessment.

## Decision snapshot

**Yes, apply. You're a strong fit on the core of the job (R1, R2, R3, R4 and R5 are `direct`), and healthcare is the gap. Status: `conditional_go`.**

**Fit ledger.**

- `must_have`: direct: R1, R2, R3, R4, R5 · adjacent: R6 (Define and maintain the metrics layer)
- `important`: adjacent: R7a (Partner with PMs on roadmap decisions) · unclear: R7b (Partner with clinicians), R8 (Mentor two junior analysts)
- `preferred`: adjacent: R9b (HIPAA or regulated-data handling) · absent: R9a (Healthcare data experience)

R6 — adjacent, your Looker build implies definitions work but doesn't state it; R7b and R8 — unclear, nothing either way yet; R9a, R9b — healthcare domain absent, privacy-data work adjacent.

**Opportunity ledger.** The responsibilities are concrete (RR5), but the employer is not yet verified (RR1), and pay and location are unstated (RR2). The remit is wide for one role (RR3), and no success measures are stated (RR4).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting verify as described — RR1; (2) pay and location turn out acceptable to you — RR2; (3) your metrics-layer and privacy work are framed as adjacent unless you confirm more — R6, R9b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C, care-navigation app | `[grounded]` JD header; not independently verified |
| Mandate | Own product analytics: metrics layer, A/B tests, Looker self-serve dashboards, PM and clinician partnership, mentoring | `[grounded]` JD |
| Metrics layer | The JD says "define and maintain", so it's unclear whether a layer exists or must be built | `[grounded]` JD wording; `[inferred]` ambiguity |
| Level | Reads as a senior individual contributor with informal leadership: "mentor", not "manage", and no stated reports | `[inferred]` from JD verbs |
| First-year outcomes | Not stated | `[grounded]` JD silent |
| Market calibration | Not run, so no pay band or title-norm comparison here | — |
| Unknowns | Pay, location or remote policy, reporting line, data-pipeline ownership under the metrics layer, how clinicians take part | `[grounded]` absent from the pasted JD |
| Contradictions | None inside the JD; JD against careers page not checked | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | You state 6 years. It's self-report, so `medium` until a CV corroborates | `[grounded]` your background | CV (upgrade menu) would corroborate |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, stated. "Expert" is a level no artifact shows yet. Roles like this commonly test SQL live | `[grounded]` your background; `[generic]` live SQL testing | none |
| R3 | Experiment design at scale | must_have | direct | medium | none | You designed and ran the program, 30+ tests a year, including the pricing test behind an 11% retention lift. "At scale" is read as test volume, since per-test traffic isn't stated | `[grounded]` your background | A sanitized readout of the pricing test would raise it to `high`; say whether 11% is relative or points, and over what period |
| R4 | Looker or similar BI, self-serve dashboards | must_have | direct | medium | none | Built the Looker instance from scratch, 40+ governed dashboards. Whether non-analysts used them self-serve isn't stated | `[grounded]` your background | Dashboard or model screenshots would raise it to `high` |
| R5 | Written communication with non-technical stakeholders | must_have | direct | medium | none | A monthly metrics memo the exec team reads, and a monthly presentation to the VP Product | `[grounded]` your background | A sanitized memo sample would raise it to `high` |
| R6 | Define and maintain the metrics layer | must_have | adjacent | low | discovery | "Governed dashboards" suggests definition work, but you haven't said you owned a metrics-definition layer. Taking the lower band | `[grounded]` your background is silent on definitions; `[inferred]` that a Looker build may include them | See G1 |
| R7a | Partner with PMs to turn analysis into roadmap decisions | important | adjacent | low | discovery | You present to the VP Product monthly, but no roadmap decision your analysis changed is stated | `[grounded]` your background | A decision your analysis changed would close it; held for later |
| R7b | Partner with clinicians | important | unclear | none | discovery | Nothing stated about working with domain specialists | `[grounded]` your background is silent | See G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | No mentoring is mentioned | `[grounded]` your background is silent | See G2 |
| R9a | Healthcare data experience | preferred | absent | none | capability | You said you've never worked in healthcare. Preferred tier, so a minor risk. A realistic closure path is a short healthcare-data primer on claims, EHR and PHI basics | `[grounded]` your statement; `[generic]` the closure path | Carry as minor risk |
| R9b | HIPAA or regulated-data handling | preferred | adjacent | medium | transferability | Real overlap: GDPR/CCPA consumer PII and a consent-state model in the warehouse. Limit: that is consumer-privacy law on subscriber data, not health information, and the regimes differ in scope and obligations | `[grounded]` your background; `[generic]` regime difference | Frame as adjacent only (A3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, must_have) | discovery | A Looker build with 40+ governed dashboards, but no stated ownership of metric definitions | A `must_have` row at `adjacent`; confirming ownership likely moves it to `direct` | Authoring LookML views or models; a metric dictionary or certified-metrics list; settling conflicting definitions of churn or active subscriber between teams | Dictionary excerpt, model-structure screenshot, a governance doc | `[grounded]` background silent on definitions; `[inferred]` that this resolves R6 |
| G2 | Mentoring (R8, important) | discovery | No mentoring or onboarding mentioned | The JD names two juniors, so it's an explicit duty | Onboarding a new analyst; reviewing others' SQL or test designs; writing a team playbook; informal pairing | An onboarding doc or review checklist | `[grounded]` background silent; `[grounded]` JD names the duty |
| G3 | Clinician partnership (R7b, important) | discovery | Nothing on working with domain specialists | Clinicians are named as partners in the JD | Co-designing a test or metric with a specialist team, such as nutrition, food safety or operations | A test brief naming the specialist input | `[grounded]` background silent; `[inferred]` a comparable kind of partnership may exist |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "digital-health scale-up, ~400 people, Series C" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your careers site, and who would I be working with? | unresolved |
| RR2 | Pay and location not stated | unknown | — | (the pasted posting has no pay or location line) | The pasted text may be an excerpt, or the figures may be withheld | `[inferred]` from the pasted text's silence | What is the salary range, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Wide remit for one role | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker, partner with … clinicians … and mentor two junior analysts" | Several functions sit in one title, possibly with one senior analyst underneath a product area | `[inferred]` from the number of distinct duties against the stated team | Who do I report to, and who owns the data pipelines beneath the metrics layer? | unresolved |
| RR4 | No stated success measures | unknown | — | (the JD states no 90-day or first-year outcomes) | Success may be undefined, or just not written in the posting | `[grounded]` JD silence | What would success look like at 90 days and at one year? | unresolved |
| RR5 | Concrete responsibilities, named tool and team | positive_signal | — | "build self-serve dashboards in Looker … mentor two junior analysts" | The scope is specific and fits your tooling | `[grounded]` JD | Which Looker setup and warehouse are in place today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the experimentation program and the Looker build | See R3, R4 | `[grounded]` your background | pending your approval |
| A2 | Say "governed dashboards", not "metrics layer", until G1 is confirmed | See R6 | `[grounded]` your wording | pending your approval |
| A3 | Describe the privacy work as "handled GDPR/CCPA consumer PII and built the consent-state model for our warehouse", and don't call it HIPAA experience | See R9b | `[grounded]` your sentence | pending your approval |
| A4 | When you quote the 11% lift, state whether it's relative or points and over what period | See R3 | `[grounded]` your figure | pending your approval |
| A5 | Ask the verification questions in RR1 to RR4 in the first conversation, before investing in the full loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; refused. It would have moved the organization and contradictions rows in role reality and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range experimentation Looker"; refused. It would have moved the market calibration row and RR2's pay comparison |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as `tuesday-dossier.md` whenever you want a portable record of it.

## Upgrade menu

- Your CV → I'd rebuild R1 to R9b from documents instead of your summary, and look for buried evidence.
- A sanitized metric dictionary or a model screenshot → R6 to `direct`.
- The pricing-test readout, dashboard screenshots, or a sample memo → R3, R4 and R5 can reach `high`.
- Pay range, location and remote policy → RR2 closes, and the hard-gate checks run.
- The live careers-page link → RR1 clears or stays open.
- The hiring manager's name → role reality's scope read, and which story to lead with.
- Search access → targets 1 and 2 re-run, and a deeper research pass (funding, leadership churn, public candidate reports; up to 5 more searches and 2 more fetches) becomes possible.

C — Do you have non-negotiables for this move, such as a pay floor, a location or remote requirement, or work authorization, that I should check the role against?

G1 — Did you own the definitions of core metrics like churn, retention or active subscriber, in a Looker model, a dictionary or a signed-off list? Who agreed to them?

G2 — Have you mentored or onboarded analysts, formally or informally? What did you do, and what happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.