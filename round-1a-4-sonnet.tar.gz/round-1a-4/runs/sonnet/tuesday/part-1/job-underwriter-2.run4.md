I've read the playbook and I'm running the two research searches it calls for: Quartzline's own site, and market norms for this kind of role. After that I'll write the assessment.
**No, you're not wasting your time applying. But you'd be applying without the "3+ years product management experience" the posting marks as must-have (R1b, never held a PM title), so treat this as a stretch application. Status: `conditional_go`.**

I assumed your stage is evaluating. My two research searches were refused, so nothing below is checked against outside sources.

## Decision snapshot

**Fit ledger.**

- `must_have` — direct: R3 · adjacent: R1a (PM-type work), R2 (Shipped API or platform products), R4 (Stakeholder management incl. sales) · absent: R1b (3+ years as a titled PM)
- `important` — adjacent: R6 (Discovery with partners, specs), R7 (Own roadmap, prioritisation) · unclear: R5 (Agile delivery), R8 (Adoption metrics)

R1b — no titled PM years, carried as the main risk; R2 — a credible bridge, its limit named; R3 (`medium`) — self-reported, waiting on an artifact.

**Opportunity ledger.** The role's scope is clearly stated (RR4). Pay, location and work pattern are unstated (RR2), the PM-years bar sits against your history (RR1), and the employer itself was not checked (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer accepts adjacent evidence in place of titled PM years, which RR1's question tests; (2) the R2 bridge is framed as adjacent integration work, never as shipping a product; (3) RR3 verifies, meaning the posting is live and the company matches its description.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B (not independently checked) | `[grounded]` JD header |
| Mandate | Own the roadmap for the partner-facing API platform; partner discovery; specs; delivery with two engineering squads; adoption metrics; launches with sales and support | `[grounded]` JD |
| Scope read | One platform, two squads and named responsibilities, which is a defined scope rather than a bundle of roles | `[inferred]` from the JD's responsibility list |
| Market calibration | Not run, so no pay band or title norm is offered | — |
| Unknowns | Pay, location or remote policy, reporting line, what counts as qualifying PM experience, what success looks like | `[grounded]` JD silent on each |
| Contradictions | None visible within the JD alone | `[grounded]` JD |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience: PM-type work | must_have | adjacent | medium | transferability | You ran quarterly roadmap-input sessions collecting client feedback for product, and coordinated with PMs on custom builds. Limit: you fed product decisions and did not make them | `[grounded]` resume; `[generic]` that hiring teams differ on what they count as PM experience | G1 |
| R1b | 3+ years PM experience: as a titled PM | must_have | absent | none | capability | You confirm you have never held a PM title. A length-of-experience requirement is not a gate, so it is graded like any must-have | `[grounded]` your statement | Ask RR1's question; carry as main risk; closure path in plan A3 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs end to end. Limit: you integrated and delivered on an API product; the resume does not say you owned or shipped one | `[grounded]` resume | G2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL and OpenAPI reading plus integration architecture work. Self-reported, with no artifact inspected | `[grounded]` resume | Offer: a sanitized excerpt of the integration playbook would raise this to `high` |
| R4 | Stakeholder management: engineering, sales, customers | must_have | adjacent | medium | discovery | You coordinated your engineers, client engineers and PMs. Nothing on the resume covers working with sales or support on a launch | `[grounded]` resume, silent on sales and support | G3 |
| R5 | Agile delivery | important | unclear | low | discovery | The resume says nothing about sprints, backlog or squad cadence | `[grounded]` resume silence | G3 |
| R6 | Partner discovery; writing specs | important | adjacent | medium | transferability | Scoping workshops and requirements documents with clients. Limit: this was implementation scoping for a customer, not product discovery | `[grounded]` resume | G1 |
| R7 | Own roadmap and prioritisation | important | adjacent | low | transferability | Your roadmap work was input to product. Nothing shows you decided priorities | `[grounded]` resume | G1 |
| R8 | Define and track adoption metrics | important | unclear | low | discovery | Nothing confirmed on the resume. An earlier conversation hints at an internal triage tool that support agents adopted, which is unconfirmed | `[grounded]` resume silence; memory lead | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Decisions you made or shaped (R1a, R6, R7; must_have and important) | transferability | Feedback sessions and requirements documents, but no stated prioritisation, trade-off or outcome | This is the nearest thing to PM experience you hold, so how far it goes decides how strong the bridge is | A client request you argued into or out of a release; a feature that shipped because of your roadmap input; a trade-off you recommended and product adopted | A roadmap-input summary, a requirements document, a release note naming the change | `[grounded]` resume says what you collected, not what changed; `[generic]` that hiring teams probe this line first |
| G2 | Something you built that others adopted (R2, R8) | discovery | Integrations you delivered; a possible internal tool, unconfirmed | One confirmed built-and-adopted example would be the closest match to "shipped" and "adoption metrics" | A tool, template or workflow others adopted; usage or time-saved figures; who asked for it | A usage screenshot, a short write-up, the playbook | `[grounded]` the lead is unconfirmed |
| G3 | Working with sales, support and agile squads (R4, R5) | discovery | Engineering and client-side coordination only | Two of the posting's named working relationships are untouched on your resume | Joint go-lives with account teams; handing over to support; sprint ceremonies you took part in | A go-live checklist, a handover document | `[grounded]` resume silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | PM-years bar against a no-title history (R1b) | risk_signal | medium | "3+ years product management experience (must-have)" | The bar may be applied to titles only, or may allow equivalent work | `[generic]` hiring teams differ on this | Would you consider hands-on partner-API integration and roadmap input as equivalent to PM years, and what had your best recent hire done before? | unresolved |
| RR2 | Pay, location and work pattern unstated | unknown | — | none in the posting as provided | Terms may conflict with constraints you have not yet given | `[grounded]` JD silent | What is the pay range, and is the role remote, hybrid or on-site? | unresolved |
| RR3 | Employer not verified (research not run) | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Unchecked rather than failed: a small company may simply have a thin footprint, or the posting may be stale | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your careers site, and say who I would interview with? | unresolved |
| RR4 | Responsibilities and scope named | positive_signal | — | "Own the roadmap for our partner-facing API platform" | Scope looks defined, with a platform, two squads and metrics | `[grounded]` JD | Who decides priorities between the two squads when partner requests conflict? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with your own two lines: "Led 30+ client integrations of our REST APIs end to end" and "Wrote the internal integration playbook the whole team uses" | See R2, R3 | `[grounded]` resume | pending your approval |
| A2 | Describe the roadmap sessions as input collected for product, and the integrations as delivered work, never as owning a roadmap or shipping a product | See R2, R7 | `[grounded]` resume | pending your approval |
| A3 | Put RR1's question to the recruiter before heavy investment. If the answer is no, target roles titled associate, technical or integration-focused PM, which this role's bar suggests exist | See R1b, RR1 | `[inferred]` from the JD; `[generic]` that such titles exist | pending your approval |
| A4 | Seek a referral or direct hiring-manager contact rather than applying cold | Hiring bars on years are often easier to pass through a person than a screen | `[generic]` role-family pattern | pending your approval |
| A5 | Use the triage tool as a story only after you confirm it (G2) | See R8 | `[grounded]` lead is unconfirmed | pending your approval |
| A6 | If you approve this direction, resume-tailor can draft line-by-line edits | Language changes need your sign-off | `[grounded]` this plan | pending your approval |

## Evidence status

Verified: none yet. Unverified lead: a possible internal request-triage tool, which prompts a question and is not treated as evidence. Stage is assumed to be evaluating.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused, so nothing was checked. It would have moved role reality's organization row and RR3 |
| 2. Role-family sweep | unavailable | The search was refused. It would have moved the market calibration row and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given |

I'd offer the dossier as a record to carry into prep or tailoring, and I can emit `tuesday-dossier.md` if you want it.

**Upgrade menu**

- A sanitized excerpt of the integration playbook → R3 to `high`.
- Your pay floor, location and schedule limits → hard-gate rows are created and checked against the role.
- Search permission → RR3 and the market calibration row close.
- A hiring manager's name → role reality's scope read, and which story to lead with for that reader.
- An answer to G1, G2 or G3 → rows R1a, R6, R7, R2, R8, R4 and R5 move.

**Questions**

- G1 — Is there a case where your feedback or recommendation changed what product built or prioritised? What did you own, what shipped, and what happened?
- G2 — I have an unconfirmed note from an earlier conversation that you built an internal request-triage tool that support agents adopted. Is that right? If so, what did you own, how many people used it, and how did you know it worked?
- G3 — Have you worked with sales or support on a go-live, and have you worked inside sprints or a backlog? What was your part?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.