I've read the underwriting playbook. Next I'm loading the web search tools to check Brindlemoor and the posting, then I'll write the assessment.
**Yes, apply, but confirm the work pattern first (R1). Status: `conditional_go`.** Your background lines up well with what the post asks for. Never managing anyone is not a gap here, because the posting asks for no line management.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote (UK))
- `must_have`: direct: R2, R3, R4, R5, R6a, R7 · unclear: R6b (Monitor rating models)
- `important`: adjacent: R9 (Pet-insurance pricing)
- `preferred`: direct: R8

R1 — the posting and the careers page disagree on work pattern; R6b (`low`) — monitoring not yet evidenced; R9 — a motor-to-pet bridge, its limit named.

**Opportunity ledger.** The employer's own careers page contradicts the "fully remote" in your JD (RR1), and the salary is withheld (RR2). The role is live and reports to the Director of Pricing (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote (UK)); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the work pattern is confirmed as one you can accept: R1, RR1; (2) your model-monitoring work is confirmed with specifics before it's used as a selling point: R6b; (3) the motor-to-pet bridge is framed as adjacent, never as pet-insurance experience: R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product; the role is live on its careers site | `[grounded]` JD header; careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reports to | The Director of Pricing | `[grounded]` careers page |
| Working pattern | The JD says fully remote (UK). The careers page says "Leeds office four days a week" | `[grounded]` JD against careers page |
| People management | The posting lists no line-management duty or requirement | `[grounded]` JD silence |
| Hiring manager | Odile Varga, Director of Pricing. She gave a 2025 Insurance Pricing Forum talk, "Small Books, Loud Errors", on monitoring rating models in small books. Before that she was head of pricing analytics at Calloway Re for six years | `[grounded]` search-result profile snippet, not fetched |
| Market calibration | A UK senior pricing analyst at insurers and insurtechs has a median base of £58,400, interquartile range £52,100 to £64,900. This is the band to expect, never Brindlemoor's offer (RR2) | `[generic]` one survey result (n=612), snippet only; `[grounded]` JD for the withheld figure |
| Unknowns | Salary; which work pattern is correct; how big the pet book is; team size around the role | — |
| Contradictions | The JD's "fully remote" against the careers page's four office days a week | `[grounded]` careers page fetched |

## Evidence map

Your background was typed into the chat, so it counts as self-report. That caps every row at `medium` until you give me something inspectable.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You haven't stated your location or any non-negotiables, so there's no constraint to grade. Fit is `unclear` because the two employer sources disagree | `[grounded]` JD and careers page; `[grounded]` your silence on constraints | G1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years at a UK motor insurer, 2 as senior analyst. Specific, but typed rather than inspected. This is an experience requirement, not a gate | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | "Daily" use is stated. No artifact inspected | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Confirmed and specific, with no inspectable artifact yet | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The role names underwriting leads | `[grounded]` your background and JD | none |
| R6a | Build rating models | must_have | direct | medium | none | Same GLM build as R4. Limit: a young-driver motor model, not pet | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | "Maintained" suggests monitoring but doesn't say what you ran (drift checks, actual-versus-expected, alerts). This is the hiring manager's public topic, so detail will matter | `[grounded]` the thin wording; `[inferred]` that monitoring is probed given her talk | G2 |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 tests last year with underwriting. Specific, with no artifact inspected | `[grounded]` your background | none |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |
| R9 | Pricing a pet-insurance book (inferred from the mandate) | important | adjacent | medium | transferability | The rating, testing and underwriting-liaison work carries over. Limit: you haven't priced pet risks (breed, age, vet-cost inflation, claims patterns) | `[inferred]` from the mandate against your motor-only history | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Work pattern and your constraints (R1, hard_gate) | hard_gate | The JD says remote and the careers page says four office days in Leeds. Your location and limits aren't stated | If four days in Leeds doesn't work for you, this role fails on the gate whatever your fit | Not experience: where you're based, whether Leeds four days is workable, any pay floor | The recruiter's or Odile Varga's written confirmation of the pattern | `[grounded]` the two sources; `[inferred]` that it could decide the outcome |
| G2 | Model monitoring (R6b, must_have) | discovery | The CV-level wording says "maintained" and nothing about monitoring | A must-have the hiring manager has spoken on publicly | Drift or stability checks, actual-versus-expected tracking, a monitoring pack, or alert thresholds you set, and what you changed after an error | A sanitized monitoring report, dashboard screenshot or review note | `[grounded]` wording; `[generic]` that pricing leaders probe monitoring |
| G3 | Pet-risk exposure (R9, important) | transferability | Motor only. Nothing on pets, other personal-lines products or small books | The most likely objection to your application | A low-volume or volatile segment you priced, a new-product launch, claims-inflation analysis, or any pet or health-adjacent work | A short sanitized note on the small-book approach | `[inferred]` bridge; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Work pattern contradicts across sources | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | One source may be out of date, or the policy may be changing. The two readings sit side by side | `[inferred]` from the two sources disagreeing | Is this role fully remote, or four days a week in Leeds, and which will it be on my start date? | unresolved |
| RR2 | Salary withheld | unknown | — | No figure in the JD or careers page | May sit within the band or below it. Or it may not be published | `[inferred]` from the missing figure against the `[generic]` band | What salary range is budgeted for this post? | unresolved |
| RR3 | Role confirmed live with a named reporting line | positive_signal | — | "Accepting applications ... reports to the Director of Pricing" | The role exists as posted and has a senior owner | `[grounded]` careers page | Who in underwriting and product will use my recommendations day to day? | noted |

## Application plan

I'm going only on what you've shared, and the posting and careers page could both be wrong. Every row below is a proposal that only goes ahead with your approval, and that covers the advice in the notes too.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the work pattern in writing with the recruiter or Odile Varga before investing in the application | See R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV with the 14 price tests run with underwriting and the quarterly review you present to the head of underwriting. Both are already in your background; nothing new is added | See R5, R7 | `[grounded]` your background | pending your approval |
| E2 | Describe the young-driver GLM as exactly that. Don't imply any pet-insurance experience | See R9 | `[grounded]` your background | pending your approval |
| P1 | Lead with your monitoring story only after G2 confirms specifics. Her public talk is about monitoring rating models in small books | See R6b | `[grounded]` search-result snippet | pending your approval |
| Q1 | Ask RR1, RR2 and RR3's questions verbatim when you speak to her | The register doubles as interview preparation | `[grounded]` register | pending your approval |

**Evidence status.** Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers Senior Pricing Analyst" and fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the posting is live and surfaced the work-pattern contradiction (R1, RR1) |
| 2. Role-family sweep | yes | Searched "Senior pricing analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Moved the market calibration and RR2's hypothesis |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Moved the hiring manager row, R6b's reasoning and P1 |

I can save this as `tuesday-dossier.md` if you want a record to carry into later steps.

**Upgrade menu**

- Your location and any non-negotiables (pay floor, office days) → R1 resolves to met or failed, and the status firms up.
- The recruiter's written answer on the work pattern → RR1 and R1 close.
- A sanitized monitoring report or dashboard → R6b rises toward `high` and P1 can be used.
- The budgeted salary → RR2 closes against the band.
- A short note on any small-book or new-product pricing → R9's bridge narrows.
- A deeper pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

**Questions**

G1 — Where are you based, would four days a week in Leeds work for you, and do you have a pay floor or other must-haves?
G2 — What monitoring did you personally run on the young-driver model, how did you spot it going wrong, and what did you change as a result?
G3 — Have you priced any small, low-volume or volatile segment, or worked on anything pet or health-adjacent?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.