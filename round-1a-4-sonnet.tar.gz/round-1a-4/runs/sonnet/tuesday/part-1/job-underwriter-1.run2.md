# Job Underwriting — Senior Product Analyst, Harborlight Health

## Decision snapshot

**Yes, apply, and you're a fit for what the role asks: R1, R2, R3, R4 and R5, all `must_have` rows, are `direct`. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R5
- `important` — adjacent: R6 (metrics layer), R7 (partner with PMs and clinicians) · unclear: R8 (mentor two junior analysts)
- `preferred` — adjacent: R9b (HIPAA-type data handling) · absent: R9a (healthcare data experience)

R6 — governed dashboards imply governed definitions, which you haven't said directly; R8 — nothing on mentoring yet; R9a, R9b — the "plus" is your thinnest area, partly bridged by the consent-state work.

**Opportunity ledger.** The posting and employer are unchecked (RR1) and pay is not stated (RR2). The scope bundles several jobs into one title (RR3), but the duties are concrete (RR4). How the role touches patient data is unknown (RR5).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is live on the employer's own careers page and the company is as described — RR1; (2) the pay clears your floor — RR2, R-rows can't test this until you share the floor.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, about 400 people, Series C | `[grounded]` JD header; not independently checked (RR1) |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, self-serve Looker dashboards, roadmap partnership with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| Scope read | A senior individual-contributor post with light lead duty, not a manager role, though it also carries metrics-definition work | `[inferred]` from the JD's verbs ("own", "define", "mentor") and its two named juniors |
| First-90-days and first-year outcomes | Not stated in the posting | `[grounded]` JD silence |
| Market calibration | Not calibrated: the role-family search was refused, and the posting states no pay | `[grounded]` research status, JD |
| Unknowns | Pay; reporting line; who owns the data models upstream of Looker; what patient-data access the role has | `[grounded]` JD silence |
| Contradictions | None visible inside the JD text; the careers page was not checked | `[grounded]` JD as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years in product analytics at a meal-kit company, stated by you; nothing inspectable yet | `[grounded]` your message | none |
| R2 | Expert SQL | must_have | direct | medium | none | SQL daily on Snowflake, stated; "expert" is your own grading and the work sample is not inspected | `[grounded]` your message | offer: a sanitized query or model that shows your level would raise to `high` |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year, plus the pricing test behind an 11% retention lift, at about 2M subscribers; the clause is "behind", so what you owned in that test needs stating. The domain is consumer subscription, not clinical. | `[grounded]` your message | a test write-up or readout would raise to `high` |
| R4 | Looker or a similar BI tool | must_have | direct | medium | none | You built the Looker instance from scratch, with 40+ governed dashboards | `[grounded]` your message | a dashboard screenshot or LookML sample would raise to `high` |
| R5 | Strong written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team; monthly presentation to the VP Product | `[grounded]` your message | a redacted memo would raise to `high` |
| R6 | Define and maintain the metrics layer | important | adjacent | low | discovery | "Governed dashboards" and the metrics memo suggest shared definitions, but a metrics or semantic layer is not stated. Low, because the link is my inference. | `[inferred]` from governed dashboards and the memo; `[generic]` that metrics-layer ownership usually means maintaining definitions in code | G1 |
| R7 | Partner with PMs and clinicians to turn analysis into roadmap decisions | important | adjacent | medium | transferability | Monthly VP Product partnership is stated. Limit: nothing stated about working with clinicians or other domain experts. | `[grounded]` your message; the limit is `[grounded]` silence | G3 |
| R8 | Mentor two junior analysts | important | unclear | none | discovery | Nothing in what you wrote touches mentoring or leading analysts | `[grounded]` silence in your message | G2 |
| R9a | Healthcare data experience | preferred | absent | none | capability | Stated outright: you have never worked in healthcare | `[grounded]` your message | G5 |
| R9b | HIPAA-type data handling | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII handling and a consent-state model for the warehouse are stated. Limit: HIPAA and PHI rules were not exercised. | `[grounded]` your message; the limit is `[grounded]` | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Metrics layer (R6, important) | discovery | Governed dashboards and a metrics memo, but no stated central definitions layer | Roles like this usually put the metrics layer first among duties, so the answer sets how R6 is positioned | Standard definitions for retention, churn or activation that dashboards and tests all used; a metrics dictionary; LookML or dbt models you wrote or reviewed; settling a disputed metric | A metrics dictionary page, a LookML excerpt, a definitions doc | `[grounded]` your message is silent on it; `[generic]` that this duty leads such roles |
| G2 | Mentoring (R8, important) | discovery | Nothing on teaching, reviewing or leading analysts | The role names two juniors, so a bare "no" is a known gap an interviewer will probe | Reviewing a junior's analysis; onboarding an analyst; running a SQL or experiment-review session; informal coaching | A review checklist, an onboarding doc, a mentee's name for a reference | `[grounded]` JD names two juniors; `[generic]` that interviewers probe this |
| G3 | Clinician partnership (R7, important) | transferability | Strong VP Product partnership; no domain-expert stakeholders stated | The role names clinicians as partners, so the bridge needs its limit stated | Working with ops, nutrition or culinary specialists on product questions; any subject-matter expert whose judgement shaped a metric | A decision memo that shows the exchange | `[inferred]` bridge from your VP Product work; the limit is `[grounded]` |
| G4 | HIPAA-type data handling (R9b, preferred) | transferability | GDPR/CCPA PII handling and a consent-state model | Bridge: privacy-law data handling carries over. Limit: HIPAA and PHI rules were not exercised. Strengthener: a one-page note on the consent model | Access controls, retention or deletion rules, consent logic | A consent-model diagram or design doc, sanitized | `[inferred]` bridge; the limit is `[grounded]` |
| G5 | Healthcare data experience (R9a, preferred) | capability | None, as you said | No credible direct or adjacent evidence exists. It is a preferred item, so a minor risk, not a blocker. Closure path: a short HIPAA basics course or an open health-data project, and nothing more | — | — | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not yet verified | unknown | — | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | Nothing is known either way, because the searches did not run | `[grounded]` research refused this session | Can you point me at this role on your careers site, and who would I interview with? | unresolved |
| RR2 | Pay not stated | unknown | — | no figure appears in the JD as pasted | I can't compare it to your floor, which you haven't given; withheld pay is itself worth a question | `[grounded]` JD as pasted | What salary band is budgeted for this post? | unresolved |
| RR3 | Several jobs in one title | risk_signal | low | "define and maintain the metrics layer, design and analyze A/B tests, build self-serve dashboards in Looker, partner with product managers and clinicians … and mentor two junior analysts" | One person may carry data modelling, experimentation, BI, stakeholder work and mentoring. Kept at low: the list is a normal senior spread, and nothing says the team is thin. | `[inferred]` from the JD's list | Which of these is the priority in the first 90 days, and who owns the data models upstream of Looker? | unresolved |
| RR4 | Concrete, named duties | positive_signal | — | "build self-serve dashboards in Looker" | The work is defined in tools and outputs you already use | `[grounded]` JD | What does a good first year look like for this role? | noted |
| RR5 | Patient-data access unknown | unknown | — | "healthcare data experience (HIPAA) a plus" | Tooling and access may be constrained by health-data rules, which can change how self-serve work runs | `[generic]` pattern for health-data employers, not a claim about this one | What data governance applies to patient data in the warehouse, and would I work with identified data? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the experimentation program and the Looker build; for the pricing test, state your own part in "the pricing test behind an 11% retention lift" rather than claiming the lift | see R3, R4 | `[grounded]` your message | pending your approval |
| P2 | Present the consent-state model and GDPR/CCPA handling as your privacy-law data work, and say plainly you have not worked with HIPAA or in healthcare | see R9a, R9b | `[grounded]` your message | pending your approval |
| P3 | Ask RR1 to RR5's verification questions in the loop, in your own words | the register doubles as interview preparation | `[grounded]` register | pending your approval |
| P4 | Confirm the posting is live on the company's own careers page before you invest effort | see RR1 | `[grounded]` RR1 | pending your approval |
| P5 | Add mentoring or metrics-layer lines only after G1 and G2 are answered; none is proposed now | see R6, R8 | `[grounded]` queue | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Harborlight Health care navigation app careers Senior Product Analyst"; the call was refused. It would have fed role reality's contradictions row and RR1 |
| 2. Role-family sweep | unavailable | Searched "senior product analyst digital health salary range Series C"; the call was refused. It would have fed market calibration and RR2's comparison |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

No market figure or company fact above comes from memory.

If you'd like the dossier of this assessment as `tuesday-dossier.md`, say so and I'll write it.

**Upgrade menu**

- Permission to search, which runs targets 1 and 2 and closes RR1 and RR2's band comparison.
- Your pay floor, location or remote needs and any other non-negotiables, which become hard-gate rows checked against the posting.
- A metrics dictionary page or LookML excerpt, which raises R6.
- A redacted memo, a test readout or a dashboard screenshot, which raises R3, R4 or R5 toward `high`.
- A hiring manager's name, which unlocks role reality's scope read.
- A deeper pass on Harborlight (funding, leadership churn, recent news; up to 5 more searches and 2 more fetches), run only if you say so.

**Questions**

G1 — Is there a place where you set or standardized a metric (retention, churn, activation) that dashboards and tests then used, and what did you own about it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you reviewed, onboarded or coached other analysts, formally or not, and what did that look like?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.