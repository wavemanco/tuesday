Quick status: I've read the posting and run three searches (the company, the pay band, and the hiring manager). I'm now checking Quillfield's own careers page to see whether the role is listed there.
**Yes, apply. Status: `conditional_go`.** The role matches your pipeline and CRM work (R3, R4, R9). It stretches you on forecast ownership (R6) and billing data (R8). Your location and pay fit are unchecked (R1, R2).

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol, hybrid two days in office), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3, R4, R9 · adjacent: R5 (Strong SQL and spreadsheet modelling), R6 (Experience owning a forecast) · unclear: R7 (Working with finance on billing or revenue data) · absent: R8 (Own billing data)

R6 is a credible bridge with its limit named; R8 has no billing evidence, a capability gap; R5 (`medium`) is confirmed on usage, not depth.

**Opportunity ledger.** The pay is stated and sits inside the market band (RR3). The role bundles several jobs under one title (RR2). The forecast expectation is unstated (RR4). The posting isn't confirmed on Quillfield's own site (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol, hybrid two days in office), R2 (Salary £61,500–£67,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol hybrid and the pay range fit your constraints (R1, R2). (2) The forecast and billing duties turn out to be "learn with finance", not "arrive owning them" (R6, R8; RR2, RR4). (3) The role is confirmed on Quillfield's own site (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol, 96 employees, Series A (£11M) closed April 2025 | `[grounded]` search result for the "About Quillfield" page |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, listed publicly as Head of Revenue Operations at Quillfield; earlier, four years as a sales operations manager at Corvane Payments | `[grounded]` your recruiter's statement; public profile snippet |
| Scope read | A hands-on revenue-ops seat with a finance-facing remit. The posting doesn't say who reports to the role | `[inferred]` from the title and the responsibilities list |
| Market calibration | Median base £64,200, interquartile range £57,800–£70,400 for UK B2B software revenue operations leads. The posted range brackets the median. The band isn't Bristol-specific and isn't Quillfield's offer | `[generic]` Ledgerline 2026 pay guide, n=438 |
| Unknowns | Team size and reporting line; who owns the forecast and billing data today; billing system; option terms; your location and pay floor | — |
| Contradictions | None between the posting and the company page. The company's own careers page wasn't found (RR1) | `[grounded]` fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days | hard_gate | unclear | none | hard_gate | You haven't stated where you're based or what you'll commute. Nothing settles it | `[grounded]` posting; constraints not given | G0 question |
| R2 | Salary £61,500–£67,000 plus options | hard_gate | unclear | none | hard_gate | The posting states pay. Your floor is unknown, so it can't be matched | `[grounded]` posting; floor not given | G0 question |
| R3 | 4+ years in revenue ops, sales ops or similar at a B2B software company | must_have | direct | medium | none | Your 5 years in sales ops, the last 2 in revenue ops, clear the length. This is a length requirement, not a gate. It rests on your prose, with no artifact inspected. Whether a payments company counts as "B2B software" is unconfirmed | `[grounded]` your background | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, stated. No credential record seen | `[grounded]` your background | the certification record would raise this to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | "SQL weekly, Excel daily" states how often you use them, not depth or modelling. The reading resolves downward | `[grounded]` your wording | see G1 |
| R6 | Experience owning a forecast (the role runs the quarterly forecast with the CFO) | must_have | adjacent | medium | transferability | Bridge: you run the monthly pipeline review with your sales director. Limit: finance owned the forecast, so you haven't owned one | `[grounded]` your statements | see G2 |
| R7 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | You've never worked on billing data. Your renewal dashboards may count as revenue data, but whether finance was a partner is unstated | `[grounded]` your statement; `[inferred]` the renewal link | see G3 |
| R8 | Own billing data ("own our CRM and billing data") | must_have | absent | none | capability | You said you've never worked on billing data. No adjacent evidence is in hand | `[grounded]` your statement | closure path in G4 |
| R9 | Build pipeline and renewal reporting for sales and finance | must_have | direct | medium | none | You rebuilt your pipeline and renewal dashboards. Who relied on them is unconfirmed, and no artifact has been seen | `[grounded]` your background | a sanitized dashboard screenshot would raise this to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SQL and modelling depth (R5, must_have) | discovery | Frequency of use only | "Strong" and "modelling" are the posting's words, and a screen will probe them | Joins across CRM and billing tables; a pipeline-to-revenue bridge in Excel; a renewal-rate model | A query sample or a model workbook, sanitized | `[grounded]` your wording; `[generic]` that these roles probe depth |
| G2 | Forecast ownership (R6, must_have) | transferability | Monthly pipeline review with the sales director; forecast owned by finance | The posting has the role running the forecast with the CFO. This is the largest gap on a must-have row | A commit call or weighted pipeline view you produced; a renewal forecast you maintained; a number you defended in a review | A pipeline-review deck or forecast sheet, sanitized | `[grounded]` your statements; `[inferred]` the weight |
| G3 | Finance partnership on revenue data (R7, must_have) | discovery | Renewal dashboards exist; finance's role in them is unknown | The posting's "billing or revenue data" wording may let revenue-data work count | Reconciling dashboard figures to finance's numbers; agreeing metric definitions with finance | A definitions doc or reconciliation note | `[grounded]` your statements; `[inferred]` that the wording is satisfiable |
| G4 | Billing data (R8, must_have) | capability | No evidence | The posting names it as core | A realistic path: learn the billing-to-CRM data model before interview; frame it as the thing you'd learn first | None to attach now | `[grounded]` your statement; `[inferred]` the path |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on the employer's own site | unknown | — | the posting at jobs.tallyboard.example | The role may sit at a different careers address, or the board listing may be stale | `[generic]` pattern; `[grounded]` the one careers address tried returned no page | Can you point me at this role on your own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | Bundled scope: CRM, billing data, reporting and forecast under one title | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting…, and run the quarterly revenue forecast" | Several jobs may be folded into one seat, though a Head of Revenue Operations in post suggests there is a team around it | `[inferred]` from the responsibilities list and the hiring manager's title | What does the team around this role look like, and who owns billing data today? | unresolved |
| RR3 | Pay stated and inside the market band | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The range is not withheld and sits inside the pay guide's interquartile range | `[grounded]` posting; `[generic]` band | How are the share options structured: vesting and strike? | noted |
| RR4 | Forecast expectation unstated | unknown | — | "run the quarterly revenue forecast with the CFO" | It may be expected from day one, or built up with finance over time | `[inferred]` from the posting's silence on ramp | Is the forecast this role's from the first quarter, or built with finance over the first few? | unresolved |

## Application plan

Each row is proposed and finalized only on your approval.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm Bristol hybrid and the pay range against your own constraints before investing effort | see R1, R2 | `[grounded]` posting | pending your approval |
| A2 | Lead with the pipeline and renewal dashboard rebuild and your Salesforce admin certification; then the monthly pipeline review with your sales director as your forecast-adjacent work | see R9, R4, R6 | `[grounded]` your statements | pending your approval |
| A3 | State the limit yourself, in your own words: "Finance owned the company forecast; I run the monthly pipeline review with our sales director, and I haven't worked on billing data." Every clause traces to your sentences | see R6, R8 | `[grounded]` your statements | pending your approval |
| A4 | Ask RR1, RR2 and RR4 verbatim in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers Revenue Operations Lead Bristol", which returned "About Quillfield" (quillfield.co.uk/about), matching the described product and city. Fetched quillfield.co.uk/careers; no page there. Moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved market calibration and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Moved the scope read and the plan's lead story |

If you want, I can write up the full evidence as a `tuesday-dossier.md` that other Tuesday tools can read.

**Upgrade menu**

- Your location and pay floor → R1 and R2 settle, and the status firms up or flips.
- A sanitized pipeline-review deck or forecast sheet → R6 firms up.
- A query sample or model workbook → R5 can reach `high`.
- A dashboard screenshot, or your certification record → R9 and R4 can reach `high`.
- A link to the role on Quillfield's own site → RR1 closes.
- A deeper research pass on Quillfield (funding follow-ups, leadership changes, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

1. R1, R2: Can you work from Bristol with two office days a week, and does £61,500–£67,000 clear your pay floor?
2. G2 (R6): Have you ever produced a number that predicted the quarter's or year's revenue, such as a commit call, a weighted pipeline view or a renewal forecast, and what part of it was yours?
3. G3 (R7): Did your renewal or pipeline reporting involve finance, for example reconciling to their figures or agreeing metric definitions, and what did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.