Checking that the Pellucid posting is live and matches what you pasted, then I'll write the assessment.
## Decision snapshot

**Yes, this looks worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7, R8
- `important` — adjacent: R9 (BigQuery as the named warehouse) · unclear: R10 (Ingestion from app and CRM), R11 (Data contracts for analysts)

R9 — a credible bridge, its limit named; R10, R11 — not yet evidenced, waiting on your answer.

**Opportunity ledger.** The stated pay is set against the report's band (RR1). Team shape and equity terms are unstated (RR2, RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you are US-based and authorized to work there, so R1 is met; (2) your pay floor sits inside the posted range, so R2 is met; (3) BigQuery is presented as adjacent to your Snowflake experience and never as experience you have (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states, founded 2016, Denver, 264 employees, Series C ($52M, February 2026) | `[grounded]` company About page, fetched. The funding is the company's own statement, not independently confirmed |
| Mandate | Build and run the reporting pipelines: ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` live posting |
| Location | Remote (US) or the Denver office | `[grounded]` live posting |
| Pay | $148,000–$166,000 plus equity (type and amount not stated) | `[grounded]` live posting |
| Scope read | Wider than one domain's pipelines: it covers ingestion, warehouse modelling and the contracts layer, and no team or reports are mentioned | `[inferred]` from the posting's three named areas against the report's typical scope of one domain and no direct reports |
| Market calibration | The report's median base for Senior Data Engineer at Series B–D is $151,000, with an interquartile range of $139,000–$163,500 (n=2,310). The posted range starts $3,000 under that median and ends $2,500 above the top of the range. "Senior" typically means 5–8 years, and your 6 sits inside that | `[grounded]` the Datawright 2026 report your recruiter sent, against the posting's figures. This is a market band, not this employer's offer |
| Hiring manager | Not named in the posting | `[grounded]` posting |
| Unknowns | Team size and reporting line; equity terms; where in the range offers land; how the CRM and app sources are set up today | `[grounded]` posting silence |
| Contradictions | None. The live careers page matches the text you pasted and shows "Accepting applications" | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location and work authorization weren't given, so this gate is neither met nor failed. Confidence is `none` because there's no statement of yours to grade | `[grounded]` posting text; nothing from you yet | Question G3 (R1) |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No pay floor was given, so the gate can't be checked. The range sits near the report's median (see role reality) | `[grounded]` posting figure; no floor from you | Question G3 (R2) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | You state 6 years at a B2B payroll company. A typed background is self-report, so `medium` until an artifact is seen. This is a length-of-experience requirement, so it isn't a gate | `[grounded]` your statement; the report puts senior at 5–8 years | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is your own word here, with no artifact behind it. Whether your CV already shows this is unassessed, since it wasn't shared | `[grounded]` your statement | Offer: a sanitized code sample or repo would raise it to `high` |
| R5 | dbt | must_have | direct | medium | none | You built the dbt project, about 180 models, on Snowflake. Confirmed and specific, with no inspectable artifact yet. Expect a probe on how you structured and tested it | `[grounded]` your statement | Offer: dbt docs or a lineage graph, sanitized, would raise it to `high` |
| R6 | A cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse, and the posting asks for "a cloud warehouse", not a specific one | `[grounded]` your statement against the posting's wording | none |
| R7 | Airflow or similar orchestration | must_have | direct | medium | none | You use Airflow for orchestration. No detail yet on scale or what you owned | `[grounded]` your statement | Offer: a sanitized DAG or a description of your orchestration scale |
| R8 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite, so ownership is yours. Coverage and results aren't stated yet | `[grounded]` your statement | Offer: suite structure or checks that caught real issues, sanitized |
| R9 | BigQuery as the warehouse (named in the role description, not the requirements list) | important | adjacent | medium | transferability | Snowflake plus dbt carries over: the modelling and testing approach is the same. Limit: you haven't used BigQuery. Platform specifics such as cost model and table design are part of the learning curve | `[grounded]` your statement; `[generic]` that dbt work ports across warehouses with platform-specific tuning | See G2 |
| R10 | Ingestion from the app and CRM | important | unclear | none | discovery | Nothing in your background says what your sources were, and the CRM and app-event ingestion in this role is specific. No claim yet, so `none` | `[grounded]` your background silent on source types | Question G1 |
| R11 | Data contracts analysts depend on | important | unclear | none | discovery | Your background doesn't mention data contracts. You may have had schema agreements or tests with analyst consumers under another name | `[grounded]` your background silent | Question G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion and data contracts (R10, R11, important) | discovery | A 6-year pipeline background, but no stated source systems and no stated agreements with downstream analysts | These two rows are the part of the mandate your stack evidence doesn't yet cover. Answering them could lift the whole `important` tier | Loading product events or a SaaS CRM into the warehouse; agreeing schemas, freshness or column definitions with analysts; tests that gate a model change; versioned or documented model interfaces | A model spec, a README, a schema-change process doc, sanitized | `[grounded]` background silent on both; `[inferred]` that this is the likeliest probe area |
| G2 | BigQuery (R9, important) | transferability | Snowflake, dbt and Airflow at scale; no BigQuery | The posting names BigQuery as the platform, so expect the question | Bridge: dbt modelling and warehouse design. Limit: BigQuery's own cost and table design. Strengthener: a small BigQuery exercise of your own | A sandbox project or a short note on how you'd port a model | `[grounded]` your Snowflake experience; `[generic]` that interviewers ask about the named platform |
| G3 | Location and pay gates (R1, R2, hard_gate) | hard_gate | Neither a location, authorization nor a pay floor given | A gate that fails ends the decision whatever the fit is | — | — | `[grounded]` inputs lack both |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay stated and in line with the report | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The range straddles the report's $151,000 median, with the top above the $163,500 interquartile ceiling, so there's no seniority-pay mismatch. Where an offer lands inside it is open | `[grounded]` posting and report figures | Where in the range would you place someone with six years and this stack? | noted |
| RR2 | Team shape and ownership unstated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | The role may be the main owner across ingestion, warehouse and contracts, wider than the report's typical one-domain scope | `[inferred]` from the posting's three areas against the report's typical scope | How many data engineers and analysts are there today, who owns the warehouse now, and who would I report to? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus equity" | Value could differ widely: type, amount and vesting aren't given | `[grounded]` posting gives none | What is the equity: type, amount or range, vesting, and strike price if options? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with your dbt project (about 180 models), your Airflow orchestration and the Great Expectations suite you set up | These are your direct must-haves (R5, R7, R8) | `[grounded]` your statements | pending your approval |
| A2 | Name Snowflake as your warehouse and BigQuery as not yet used; claim no BigQuery experience | Keeps R9 honest at `adjacent` | `[grounded]` R9 row | pending your approval |
| A3 | Consider a small BigQuery sandbox exercise that ports one dbt model and notes what changed, before interviews | Narrows R9's stated limit (G2) | `[generic]` common way to close a platform gap | pending your approval |
| A4 | Ask the RR1, RR2 and RR3 questions verbatim with the recruiter or in the first loop | Settles pay placement, team shape and equity before you invest further | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 1 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Pellucid Learning Series C $52M tutoring Denver", which returned "About Pellucid Learning" (pellucidlearning.com/about). Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer). Role reality: the organization and contradictions rows. The employer exists as described, the posting is live and matches your paste, so no employer-not-established entry |
| 2. Role-family sweep | skipped | The Datawright report you pasted already fixes market calibration (pay, seniority, scope), which this target feeds |
| 3. Hiring manager's public footprint | n/a | The posting names no one |

## Upgrade menu

- Your location, work authorization and pay floor → R1 and R2 close, and the decision moves to `go` or `no_go`.
- An answer on ingestion sources and analyst-facing agreements → R10 and R11 close or sharpen.
- A sanitized dbt docs or lineage graph, a DAG, or the Great Expectations suite structure → R5, R7 and R8 can reach `high`.
- The recruiter's answers on team shape and equity → RR2 and RR3 close.
- A hiring manager's name → scope read and which story to lead with.
- A deeper pass on Pellucid (funding and leadership churn, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you'd like, I can write this up as `tuesday-dossier.md` for later use.

Questions:

G3 (R1) — Are you US-based and authorized to work in the US without sponsorship, and are you fine either fully remote or in Denver?
G3 (R2) — What is the lowest base salary you would accept?
G1 — Have you loaded product-app events or CRM data into a warehouse, and have you agreed schemas, freshness or definitions with the analysts who use your models? What did you own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.