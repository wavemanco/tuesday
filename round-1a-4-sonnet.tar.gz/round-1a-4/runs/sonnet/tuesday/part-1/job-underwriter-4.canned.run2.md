I've read the job-underwriter playbook and its evidence rules. I'm now loading the research tools and the research-tier rules. Then I'll check Brindlemoor and the posting, and write up the verdict.
# Job underwriting: Senior Pricing Analyst, Brindlemoor

## Decision snapshot

**Should you go for it? Probably yes, once one thing is settled. R1, where the job is done, is unresolved because the JD and the company's careers page disagree. Status: `hold_pending_answers`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R9 (Pet-insurance product knowledge)
- `preferred`: direct: R8

R9 — a credible bridge from motor, its limit named; R1 — the JD says remote and the careers page says Leeds, so the gate is open.

**Opportunity ledger.** Sound, with one contradiction on location (RR1) and pay not stated (RR2). The reporting line and scope are clearly stated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** to `conditional_go` or `go` if Brindlemoor confirms a working pattern you can accept (R1, RR1). To `no_go` if the role is Leeds four days a week and you can't do that.

Never having managed anyone isn't a row, because the posting asks for no line management (see Role reality).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a live careers page for this role | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet-insurance product: build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product | `[grounded]` JD and careers page agree |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page; JD names the hiring manager |
| Working pattern | JD says fully remote (UK); the careers page says Leeds office four days a week | `[grounded]` both sources quoted; they contradict, and I haven't resolved it |
| Line management | Not mentioned in the JD, and none of its requirements asks for people management | `[grounded]` JD silence |
| Pay | Not stated in the JD you pasted or on the careers page | `[grounded]` both sources |
| Market calibration | Median base £58,400 for senior pricing analysts at UK insurers and insurtechs, interquartile range £52,100 to £64,900 (n=612). This is a market band, not Brindlemoor's offer. | `[generic]` Pricewell 2026 survey snippet from search; I did not open the full survey |
| Hiring manager | Odile Varga spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. She was previously head of pricing analytics at Calloway Re for six years. | `[grounded]` her public profile, fetched |
| Scope read | The emphasis on monitoring suggests a smaller book, where the pricing work is judging noisy results. That is a plausible reading, not a fact about the book. | `[inferred]` from her talk title and the JD's "monitor rating models" |
| Contradictions | Remote versus Leeds four days (RR1) | `[grounded]` as above |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | The JD says fully remote and the careers page says Leeds four days a week, so the role's terms are unsettled. You haven't stated a location or schedule constraint, so there is no claim to grade. | `[grounded]` both sources; your message is silent on location | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You state 5 years of pricing analytics at a UK motor insurer, the last 2 as senior analyst. Specific and plausible, but self-reported with no artifact yet. | `[grounded]` your stated background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You state daily use of both. The depth isn't evidenced beyond that, so expect a technical probe. | `[grounded]` your stated background | none |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintain the GLM rating model for your young-driver book. That is the JD's core method, applied in motor. | `[grounded]` your stated background | none |
| R5 | Build and monitor rating models | must_have | direct | medium | none | Build is covered by R4. The monitoring half is not stated separately, though "maintained" implies some. | `[grounded]` your stated background; `[inferred]` that maintenance included monitoring | offer: one line on how you monitored the model would firm this up |
| R6 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. This is strong and specific. | `[grounded]` your stated background | none |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. | `[grounded]` your stated background | none |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer. | `[grounded]` your stated background | none |
| R9 | Pet-insurance product knowledge (implied by the role, not stated as a requirement) | important | adjacent | low | transferability | Motor pricing carries over in method. Limit: you have no pet-specific rating factors such as breed, age or pre-existing conditions. Funders... not relevant; the JD doesn't list this as required, so it's a differentiator, not a gate. | `[inferred]` from the product named in the JD against your motor-only background | see G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Where the work is done (R1, hard_gate) | hard_gate | The JD says fully remote and the careers page says Leeds four days a week. You haven't given a location or schedule constraint. | It decides whether this is `no_go` for you, so it is the one open item that could flip the status. | A recruiter email or the offer terms stating the working pattern | The employer's own written statement | `[grounded]` the two sources disagree; `[inferred]` that the answer could flip the status |
| G2 | Pet-insurance product knowledge (R9, important) | transferability | Motor rating method carries over, but nothing in your background touches pet-specific rating | A bridge with its limit named reads better in interview than a claim of fit | Work on a low-volume or sparse segment where credibility mattered; rating a product with unusual risk factors; any personal or side work on pet data | A short note or analysis from such a segment | `[inferred]` bridge from your motor work; `[generic]` that hiring managers probe domain gaps for this seniority |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts across sources | risk_signal | medium | JD: "Fully remote (UK)"; careers page: "Leeds office four days a week" | The careers page may be out of date, or the JD may be, or the role may be hybrid with remote exceptions | `[inferred]` from the two sources disagreeing | Is this role fully remote, or is it Leeds four days a week? | unresolved |
| RR2 | Pay not stated | unknown | — | JD and careers page state no figure | Brindlemoor may simply not publish pay. The figure could sit above or below the market band. | `[generic]` pattern for postings that withhold pay | What is the budgeted salary range for this role? | unresolved |
| RR3 | Scope and reporting line are clear | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The mandate is defined and the manager is a pricing specialist | `[grounded]` careers page and JD | What does success look like in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the working-pattern question (RR1) before investing in the application | See R1 | `[grounded]` RR1 | pending your approval |
| E1 | Lead the CV with the young-driver GLM, the 14 price tests and the quarterly review, in that order. Don't claim pet-insurance experience. | See R4, R6, R7 | `[grounded]` your stated background | pending your approval |
| E2 | Say plainly that your experience is motor and name the bridge: the same GLM and test method, applied to a different product | See R9 | `[grounded]` your stated background | pending your approval |
| A2 | Read Odile Varga's "Small Books, Loud Errors" talk if it is available, and prepare one example of how you monitored a model | Her public work centres on monitoring, and the JD's role includes it | `[inferred]` from her talk title and the JD | pending your approval |
| Q1 | Ask RR1 to RR3 verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Your background is self-reported, so I treat it as CV-equivalent and cap it at `medium`.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers Senior Pricing Analyst"; fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the posting is live and surfaced the remote versus Leeds contradiction (RR1). |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). I used its search snippet for the market calibration. |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing"; fetched "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). It fed the scope read and plan row A2. |

I can also run two more targets (deeper company diligence and a recent-news sweep): up to 5 more searches and 2 more fetches. Say the word if you want them.

## Dossier offer

I can save this as a `tuesday-dossier.md` for later steps if you want it.

## Upgrade menu

- A recruiter email or written terms stating the working pattern → closes R1.
- Your location and any pay floor → lets me check R1 and pay against your limits instead of leaving them unknown.
- A sanitised model-monitoring report, or a price-test write-up → R5 and R6 toward `high`.
- Any sparse-segment or unusual-risk-factor work → narrows the R9 bridge.

## Questions

- **G1 (R1)** — Can you work from Leeds four days a week, or do you need this to be fully remote? Please give your location and any other fixed limits on schedule or pay.
- **G2 (R9)** — Have you ever priced a low-volume segment or a product with unusual risk factors, where sparse data shaped your modelling choices? What was your part in it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.