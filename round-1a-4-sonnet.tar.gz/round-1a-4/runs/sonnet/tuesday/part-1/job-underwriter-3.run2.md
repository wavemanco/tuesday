Web search was denied, so this assessment rests only on your posting and your message.

# Job Underwriting — Head of Growth at Novaline

## Decision snapshot

**No — R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site Austin office 5 days a week), R2 ($70–85k base)
- `must_have` — direct: R3, R4, R5
- `important` — adjacent: R9 (Team of one); unclear: R6 (SEO/content), R7 (Brand, PR, partnerships), R8 (Sales ops)

R3 (`medium`) — the 9 years you stated, no document inspected; R9 — leading teams of 3–7 is adjacent to working as a team of one, not the same; R6, R7, R8 — your background says nothing either way.

**Opportunity ledger.** The role stacks seven functions on one person with no stated resources (RR2, RR5). It pairs a Head-level title with a base that may not match it (RR1), always-on language (RR3) and undefined success metrics (RR4). The employer is unverified (RR6). One entry runs the other way: the CEO reporting line (RR7).

- **Hard gates:** failed: R1 (On-site Austin office 5 days a week), R2 ($70–85k base).
- **Severe red flags:** none found.
- **What would change this:** Novaline would have to offer a Portland-compatible remote arrangement and a base of at least $150k. The posting says "no exceptions" on location and states a top of $85k, so nothing in it points that way.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement startup, Series A, "profitable since day one"; not independently confirmed | `[grounded]` posting header; employer lookup refused |
| Mandate | "Own all revenue growth end to end": paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Resources | "A team of one to start"; no budget, tooling or hiring plan stated | `[grounded]` posting silence |
| Reporting line | CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | On-site Austin 5 days, plus "evenings and weekends when it matters" | `[grounded]` posting |
| Scope read | Reads as several roles folded into one title | `[inferred]` from the seven listed functions against "team of one" |
| Market calibration | Not run, because the role-family search was refused. The posting's $70–85k is set only against your floor (R2), not against a market band | `[grounded]` posting figure; band unavailable |
| Unknowns | Budget; what success means; equity terms and valuation; whether location or pay has any flexibility | — |
| Contradictions | Cannot be checked: no second source (careers page) was reached | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own statement: remote-only, living in Portland, not relocating. The gate fails because the posting rules out remote work | `[grounded]` posting quote and your message | Only Novaline changing terms, or you revising a non-negotiable, resolves it |
| R2 | Base of $70–85k (your floor: at least $150k) | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The top of the range sits $65k under it | `[grounded]` posting figure and your message | Same as R1 |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | 9 years, as Growth lead then Head of Growth, is specific and confirmed. It is intake prose with no document inspected, so `medium` is the ceiling | `[grounded]` your message | none |
| R4 | Paid acquisition | must_have | direct | medium | none | You said you owned paid and controlled a budget while scaling one company from $8M to $40M ARR over three years. Confirmed and specific, with no artifact inspected | `[grounded]` your message | none |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | You owned lifecycle and are deep in Braze. Confirmed and specific, with no artifact inspected | `[grounded]` your message | none |
| R6 | SEO/content | important | unclear | none | discovery | You gave no claim either way | `[grounded]` silence in your message | Recall prompt in G2, not asked this turn |
| R7 | Brand, PR, partnerships | important | unclear | none | discovery | No claim in your message | `[grounded]` silence in your message | Same |
| R8 | Sales ops | important | unclear | none | discovery | No claim in your message | `[grounded]` silence in your message | Same |
| R9 | Operating as a team of one across all functions | important | adjacent | medium | transferability | You built and managed teams of 3–7. Limit: nothing stated about executing every function alone | `[grounded]` your message; `[inferred]` adjacency | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Solo execution (R9, important) | transferability | Team leadership and budget control, no solo-operator period stated | Moves no status while R1 and R2 stand | A stretch with no reports, or a founding-hire stint | An org chart or role description from that period | `[grounded]` your message |
| G2 | SEO/content (R6, important) | discovery | No claim stated | Same | Owning organic acquisition or content programs, even inside a broader remit | A traffic or organic-revenue dashboard export | `[grounded]` silence |
| G3 | Brand, PR, partnerships (R7, important) | discovery | No claim stated | Same | Partner or affiliate programs, press launches, brand campaigns | A partner-program summary or a campaign brief | `[grounded]` silence |
| G4 | Sales ops (R8, important) | discovery | No claim stated | Same | CRM and pipeline reporting, lead routing, SQL-built funnel reports | A pipeline-report sample, sanitized | `[grounded]` silence |

No closing question goes with these rows. R1 and R2 fix the status whatever the answers would show.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Seniority and pay may not match | risk_signal | medium | "8+ years growth leadership required" … "$70–85k base plus meaningful equity upside" | The base may sit below what a Head-level mandate usually carries; the band was not checked | `[inferred]` from the posting's years and scope against its base; `[generic]` that titles of this kind are often priced higher | What is the full compensation package, and how is the equity valued and vested? | unresolved |
| RR2 | Bundled specializations | risk_signal | medium | "Own all revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops. You will be a team of one to start" | Several full roles may be folded into one | `[inferred]` from the seven functions against "team of one"; `[generic]` that these are often separate roles | Which of these functions are expected in the first year, and what hires or agencies are planned? | unresolved |
| RR3 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be routine rather than occasional | `[inferred]` from the phrase "just who we are" | In the last quarter, how often did this role work evenings or weekends? | unresolved |
| RR4 | No success metrics on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | Accountability may be wide with no defined target | `[inferred]` from the posting's silence on targets | What would a good first 90 days and first year look like, and who judges it? | unresolved |
| RR5 | Resources unstated | unknown | — | "You will be a team of one to start" | Budget, tools and hiring plan are not given | `[grounded]` posting silence | What budget and tooling come with the role? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Senior reporting line | positive_signal | — | "Report to the CEO with a dotted line to the board" | The role has direct executive access | `[grounded]` posting | What decisions does the board line cover? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted, and don't tailor a resume for it | see R1, R2 | `[grounded]` R1, R2 rows | pending your approval |
| A2 | Only if you want to test flexibility: ask Novaline, through contacts on its own site, whether the role can be remote and what the base budget is. A reply that is vague or evasive settles it | see R1, R2, RR1 | `[grounded]` register | pending your approval |

## Evidence status

Verified: R1 and R2, your stated constraints. Your growth background is intake prose, so its rows (R3, R4, R5, R9) are unverified leads. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Novaline e-commerce enablement startup Austin Series A" was refused. It would have fed role reality's organization and contradictions rows and RR6 |
| 2. Role-family sweep | unavailable | Search "Head of Growth salary Series A startup Austin base salary range" was refused. It would have fed market calibration and RR1 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I can save this as `tuesday-dossier.md` if you want it for later.

## Upgrade menu

- Permission for web searches, or a link to Novaline's careers page → RR6 and role reality's organization and contradictions rows resolve, and RR1 gets a market band.
- Novaline's written answer on remote work and base pay → R1 and R2 could change; nothing short of changed terms moves the status.
- A growth dashboard export, a board-deck ARR slide, or an experiment log → R3, R4 and R5 can reach `high`.
- Answers on SEO, brand/PR/partnerships and sales ops (G2–G4) → R6, R7 and R8 firm up. This matters only if the terms change.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.