**No, this isn't worth pursuing. R1 and R2, both hard gates, fail. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (On-site in Austin, five days a week), R2 (Base $70–85k)
- `must_have` — direct: R4, R5, R6 · unclear: R7 (SEO/content)
- `important` — unclear: R8 (Brand, PR, partnerships, sales ops), R9 (Operating as a team of one)

R1 and R2 — failed gates that no wording can fix; R4, R5 and R6 — direct on your stated history; R7, R8 and R9 — not established either way.

**Opportunity ledger.** The scope and terms don't line up. Seven functions go to one person with no stated bench or budget (RR3), at a base far below your floor (RR1). On top of that come always-on expectations (RR4), success metrics left undefined (RR5), equity left vague (RR6), and company claims I couldn't check (RR7). The role is also on-site five days with no exceptions (RR2).

- **Hard gates:** failed: R1 (On-site in our Austin office 5 days a week); R2 (Compensation: $70–85k base).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`).
- **What would change this:** Novaline would have to allow fully remote work from Portland (R1) and offer a base of at least $150k (R2). Even then, RR3, RR4 and RR5 would still need clean answers.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup in Austin, described as Series A and profitable since day one | `[grounded]` posting header; the claims themselves are unchecked (RR7) |
| Mandate | Own revenue growth end to end: paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Team | A team of one to start, with no stated hiring plan or budget | `[grounded]` posting |
| Working pattern | On-site in Austin five days a week; evenings and weekends "when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside" with no figure | `[grounded]` posting |
| Scope read | Several full specializations in one title at a single-person scale; reads as a founder-adjacent generalist role, not a Head of Growth who leads a function | `[inferred]` from the function list against "team of one" and "no bench" |
| Market calibration | Not established. The role-family search was refused, so no band is stated; model memory isn't a source for market pay | — |
| Stage | Assumed "evaluating", since you gave none | `[inferred]` |
| Unknowns | Budget, equity terms, hiring plan, success metrics, whether the posting is live on Novaline's own site | — |
| Contradictions | None found, but only the posting was available to compare | `[grounded]` one source provided |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | "On-site in our Austin office 5 days a week — no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your own stated limit (remote-only, Portland, not relocating). The fit fails because the posting rules out any exception. | `[grounded]` your statement and the posting | Only the employer changing terms resolves it; see RR2 |
| R2 | "$70–85k base" against your $150k minimum base | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated floor. The posted top of range is below it. | `[grounded]` your statement and the posting | Only a changed offer resolves it; see RR1 |
| R4 | "8+ years growth leadership" | must_have | direct | medium | none | You state 9 years in growth, as growth lead then Head of Growth. Self-reported, with no artifact inspected. If the screen is literal, the leadership portion of the nine years is what gets counted. | `[grounded]` your summary; `[generic]` that a literal years screen is possible | None unless terms change |
| R5 | Paid acquisition | must_have | direct | medium | none | You say you owned paid, with a budget you controlled. Your summary doesn't say which channels or what share of the ARR growth paid drove, so the claim stays at "owned paid". | `[grounded]` your summary | None unless terms change |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You say you owned lifecycle and are deep in Braze. Your summary names no program results. | `[grounded]` your summary | None unless terms change |
| R7 | SEO/content | must_have | unclear | none | discovery | Your summary names paid, lifecycle, experimentation, SQL, GA4 and Braze, but not SEO or content. | `[grounded]` the summary's silence | See G1 |
| R8 | Brand, PR, partnerships and sales ops | important | unclear | none | discovery | Nothing in your summary touches these four. | `[grounded]` the summary's silence | See G2 |
| R9 | Operating as a team of one | important | unclear | none | discovery | You built and managed teams of 3–7. Running a function solo isn't mentioned either way. | `[grounded]` your summary | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO and content (R7, must_have) | discovery | Your summary never mentions SEO or content | A must_have row at `unclear`; it only matters if R1 and R2 change | Organic landing pages you tested through experimentation; content programs you commissioned or measured; an SEO agency or freelancer you directed | An organic-revenue dashboard, a content calendar with results | `[grounded]` the summary's silence on SEO |
| G2 | Brand, PR, partnerships, sales ops (R8, important) | discovery | Nothing in your summary touches them | These add width to the role without changing the gate failures | Launch PR you ran or briefed; a channel or affiliate deal you negotiated; CRM or pipeline reporting you built for a sales team | A partnership agreement, a press clipping list, a pipeline dashboard | `[grounded]` the summary's silence |
| G3 | Team of one (R9, important) | discovery | You have led teams but never said you worked solo | A solo operator's first months differ from a leader's with a bench, so it would show whether the format suits you | A stretch before you hired when you ran growth alone; the first 90 days at a company before the team existed | An early-stage plan or a first-quarter report | `[grounded]` your summary; `[generic]` that solo operation differs from leading a team |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base far below your floor (R2) | red_flag | high | "$70–85k base plus meaningful equity upside" | The posted top of range is below your $150k floor. Whether it also sits below the norm for 8+ years of leadership across seven functions isn't established, because the salary search was refused. | `[grounded]` posting figure against your stated floor | What is the budgeted base for this role, and is it flexible for this seniority? | confirmed |
| RR2 | On-site rule against remote-only (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The role cannot be done from Portland on the posting's own terms. | `[grounded]` posting against your stated constraint | Is any remote or hybrid arrangement possible for this role? | confirmed |
| RR3 | Several full roles in one title with no bench | risk_signal | medium | "paid acquisition, SEO/content, lifecycle/CRM, brand, PR, partnerships, and sales ops"; "a team of one to start" | You may be accountable for seven functions without the people, budget or authority to run them. | `[inferred]` from the function list against "players who don't need a bench" | What budget, tooling and hiring plan come with the role, and when does the team grow? | unresolved |
| RR4 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Extra hours may be the norm and not the exception. | `[inferred]` from the culture language | How many evenings or weekends did the current team work last quarter, and how is that recognized? | unresolved |
| RR5 | No definition of success on a demanding mandate | risk_signal | medium | "success metrics will evolve as we learn" | You could be held to targets that move after you accept. | `[inferred]` from the JD's wording | What revenue outcome would this role be judged on at 90 days and at twelve months? | unresolved |
| RR6 | Equity unspecified | unknown | — | "meaningful equity upside" | The size and terms of the equity are unknown, so it can't offset the base. | `[inferred]` from the missing figures | What percentage, vesting schedule and latest valuation does the equity grant carry? | unresolved |
| RR7 | Company claims unchecked | unknown | — | "Series A, profitable since day one" | The claims come from the posting alone, and the research that could check them didn't run. | `[grounded]` posting; research unavailable | Can you point me at this role on your careers site, and say who I would report to? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted; put the effort into openings that meet remote work and a base of at least $150k | see R1, R2 | `[grounded]` R1, R2 | pending your approval |
| A2 | Optional: ask Novaline, through contact details on its own website, whether the base and the on-site rule are fixed, and go further only if both change | see RR1, RR2 | `[grounded]` register | pending your approval |
| A3 | If the terms do move, resolve RR3, RR4 and RR5 and the G1–G3 gaps before investing in a loop | see the queue and register | `[grounded]` queue and register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Novaline e-commerce enablement startup Series A Austin Head of Growth"; the call was refused for lack of search permission. It would have moved role reality's organization and contradictions rows and checked RR7. |
| 2. Role-family sweep | unavailable | Searched "Head of Growth salary startup Series A base salary range 2026"; refused for the same reason. It would have set the posted base against a market band in role reality and RR1. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

The decision doesn't depend on the missing searches, because R1 and R2 fail from your constraints and the posting alone.

I can save this as a `tuesday-dossier.md` if you'd like a copy.

## Upgrade menu

- Search permission, so targets 1 and 2 can run. That would fill the organization and market-calibration rows, test the company claims (RR7) and set the base against a band (RR1).
- Novaline's budgeted base and remote policy, in writing. These are the only inputs that could move R1 and R2, and so the status.
- Answers to G1, G2 and G3. They firm up R7, R8 and R9, but they matter only if the terms change.
- A sanitized channel dashboard or budget summary from your past roles. This would raise R4, R5 and R6 toward `high`.
- The hiring manager's name, if you get one. It would add a read on scope and on which story to lead with.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.