# Job Underwriting Assessment: Revenue Operations Lead at Quillfield

## Decision snapshot

**Yes, apply, but as a stretch and on conditions. R6 (forecast ownership) and R7a (billing data) are real gaps, and R1 and R2 can't be checked until you confirm your constraints. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week), R2 (Salary £61,500–£67,000)
- `must_have`: direct: R3a, R4 · adjacent: R5 (SQL and spreadsheet modelling), R6 (Owning a forecast) · unclear: R3b (at a B2B software company), R7b (Working with finance on revenue data) · absent: R7a (Working with finance on billing data)
- `important`: direct: R8

R6 — a credible bridge, its limit named; R7a — a stated absence in a role that owns billing data; R4 (`medium`) — certification stated, nothing inspected.

**Opportunity ledger.** The employer matches the posting's description (RR4), and the pay sits inside the market band (RR2). The role's scope is under-specified: team and reporting line aren't stated (RR3). I also couldn't find the role on Quillfield's own site (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol two days a week and the pay range both meet your constraints (R1, R2); (2) the posting is confirmed live with Quillfield (RR1); (3) you say plainly in the application that you haven't owned a forecast or worked on billing data (R6, R7a), and the hiring side signals those are trainable rather than disqualifying.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield: invoicing and payments software for UK builders' merchants, founded 2018 in Bristol, 96 employees, £11M Series A closed April 2025 | `[grounded]` "About Quillfield" page (quillfield.co.uk/about) |
| Mandate | Own the CRM and billing data; build the pipeline and renewal reporting that sales and finance run on; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern and pay | Bristol, hybrid, two office days a week; £61,500–£67,000 plus share options | `[grounded]` posting |
| Hiring manager | Tamsin Achebe, Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years. This matches what the recruiter told you | `[grounded]` search result for her profile (linkedin.example/in/tamsin-achebe); the profile page itself was not opened |
| Scope read | "Lead" carries no stated team. With a Head of Revenue Operations in place, this post likely reports into her, and the forecast work is shared with the CFO | `[inferred]` from the posting's silence on reports against Tamsin's title |
| Market calibration | UK B2B software revenue operations leads: median base £64,200, interquartile range £57,800–£70,400 (n=438, 2026 survey). It is national, not Bristol-specific, and it is not Quillfield's offer | `[generic]` Ledgerline 2026 pay guide |
| Unknowns | Which CRM they run (HubSpot or Salesforce); which billing system; team size; how the forecast is built today; share option terms | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the About page. The one careers address I tried returned no page (RR1) | `[grounded]` fetch result |

## Evidence map

I haven't seen a CV, so every candidate claim below comes from your message and counts as self-report.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two office days a week | hard_gate | unclear | none | hard_gate | You haven't stated your location or constraints, so whether the term is met is open | `[grounded]` posting term; no candidate statement | Closing question on R1 and R2 |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | The posting states the pay; your floor wasn't given | `[grounded]` posting term; no candidate statement | Closing question on R1 and R2 |
| R3a | "4+ years in revenue operations, sales operations or a similar analytics role" | must_have | direct | medium | none | You describe five years in sales operations, the last two running revenue operations for the UK team. Confirmed and specific, with no inspectable artifact yet | `[grounded]` your message | Offer: CV with dates would raise this |
| R3b | That experience at "a B2B software company" | must_have | unclear | low | discovery | You describe a B2B payments company. Whether it was a software business isn't established | `[grounded]` your message says payments, not software | Held for a later turn |
| R4 | "HubSpot or Salesforce administration" | must_have | direct | medium | none | Salesforce admin certified is specific. Which CRM Quillfield runs is unknown, so HubSpot-only is a possible limit | `[grounded]` your message; `[generic]` that either CRM satisfies the posting's "or" | Credential or Trailhead record would raise to high |
| R5 | "Strong SQL and spreadsheet modelling" | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show use. They don't show modelling or strength, so one example is needed | `[grounded]` your message | Held for a later turn |
| R6 | "Experience owning a forecast" | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director, which is credible adjacent work. Limit: you haven't owned the company forecast, and finance did | `[grounded]` your message | Closing question G1 |
| R7a | Working with finance on billing data | must_have | absent | none | capability | You say you've never worked on billing data. The role is also to own it, so the gap sits in the job itself | `[grounded]` your statement; `[inferred]` that the job's duties make it central | Name a closure path; carry as a material risk |
| R7b | Working with finance on revenue data | must_have | unclear | low | discovery | The posting says "billing or revenue data". Your renewal dashboards touch revenue, but whether you worked with finance on that data is not stated | `[grounded]` your message is silent on finance | Closing question G2 |
| R8 | "Build the pipeline and renewal reporting our sales and finance teams run on" | important | direct | medium | none | You rebuilt your team's pipeline and renewal dashboards. Whether finance used them is unknown | `[grounded]` your message | A sanitized screenshot would raise to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning a forecast (R6, must_have) | transferability | You run the monthly pipeline review but finance owned the forecast | The posting makes the CFO forecast a core duty, so this is the gap most likely to be probed | Supplying pipeline or commit numbers finance used; explaining variances between pipeline and what closed; building a scenario or coverage model, whoever owned the final number | A sanitized forecast-input sheet, or a pipeline-review deck | `[generic]` that forecast ownership is the duty most probed in roles like this; `[grounded]` your own limit |
| G2 | Billing and revenue data with finance (R7a and R7b, must_have) | discovery | Renewal dashboards, but no stated finance partnership. Billing data is a stated absence | R7a stays absent unless the revenue side (R7b) counts, and the posting's "or" may allow that | Sourcing renewal or ARR figures from a finance system or reconciling them with finance; building renewal reports from invoices or contract data; fixing mismatches between CRM and finance numbers | A dashboard screenshot showing its data sources, or a reconciliation sheet | `[grounded]` posting wording; `[inferred]` that resolving R7b could narrow the gap |
| G3 | B2B software employer (R3b, must_have) | discovery | "B2B payments company" | The posting's requirement names software | Whether your product was a platform customers used as software | Company product page | `[grounded]` your message; no question this turn, budget spent on higher-impact gaps |
| G4 | Strong modelling (R5, must_have) | discovery | Usage frequency only | "Strong" and "modelling" need an example | One model or query you built and who relied on it | A sanitized query or workbook | `[grounded]` your message; no question this turn |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on the employer's own site | unknown | — | Posting hosted at jobs.tallyboard.example | The role may be listed elsewhere on Quillfield's site, or listed only through the job board and recruiter | `[grounded]` one careers address tried returned no page; `[generic]` that companies of this size often route hiring through boards and recruiters | Can you point me at this role on your careers site, and confirm Tamsin Achebe is the hiring manager? | unresolved |
| RR2 | Pay within the market band | positive_signal | — | "£61,500–£67,000 plus share options" | The range sits inside the survey's interquartile range, so the pay looks fairly set | `[grounded]` posting figure; `[generic]` survey band, national | What are the share option terms (vesting, strike price, share count)? | noted |
| RR3 | Scope and authority under-specified | unknown | — | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | "Lead" may mean leading a team or leading a function alone; authority over the forecast against the CFO is unstated | `[inferred]` from the posting's silence on reports against the "Lead" title | Does this role manage anyone, and who owns the forecast number: this role or the CFO? | unresolved |
| RR4 | Employer established | positive_signal | — | "Quillfield, the invoicing software company" | The company exists as described: Bristol, invoicing software, 96 employees | `[grounded]` About Quillfield page | What is the current size and structure of the revenue operations team? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the application with what you've said: the monthly pipeline review you run with your sales director, and the pipeline and renewal dashboards you rebuilt. Draft wording only after you approve this direction | R6, R8 | `[grounded]` your message | pending your approval |
| E2 | State the limits in your own words: "finance owned the company forecast" and "I haven't worked on billing data". Don't phrase either as owning or approximating it | R6, R7a | `[grounded]` your message | pending your approval |
| W1 | A sanitized dashboard or query you can show, with its data sources visible | R5, R7b, R8 | `[grounded]` rows named | pending your approval |
| A1 | Confirm location and pay against your own limits before investing effort | R1, R2 | `[grounded]` rows named | pending your approval |
| A2 | Ask the recruiter RR1's and RR3's questions verbatim before the screen | RR1, RR3 | `[grounded]` register | pending your approval |
| A3 | Tamsin Achebe's public profile shows a sales operations background; where you can truthfully say your pipeline work lines up with that, lead with it | Positioning for this reader | `[grounded]` search result on her profile | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company careers", which returned "About Quillfield" (quillfield.co.uk/about); fetched quillfield.co.uk/careers, which returned no page. Role reality's organization row (the employer exists as described) and RR1, RR4 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK Bristol B2B software", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Market calibration `[generic]` and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe). Role reality's hiring-manager row and application row A3; the profile page was not opened |

I can save this as `tuesday-dossier.md` if you'd like to carry it into later steps.

## Upgrade menu

- Your CV with dates, or a Salesforce credential record → R3a and R4 toward `high`.
- A sanitized dashboard, query or forecast-input sheet → R5, R6, R8 toward `high`.
- Your location and pay floor → R1 and R2 settle, and the snapshot's hard-gates line loses its "constraints not given" flag.
- Answers from the recruiter on team, CRM, billing system and share options → RR3 and the role-reality unknowns close.
- A link to the role on Quillfield's own careers page → RR1 closes.
- A deeper research pass on Quillfield: funding, leadership changes, public employee reports, recent news (up to 5 more searches and 2 more fetches). Say the word and it runs.

R1, R2 — Do two office days a week in Bristol and £61,500–£67,000 both work for you, or does either break a non-negotiable?

G1 — Has any forecast, quota or coverage number you produced fed into finance's company forecast, and what exactly was your part in it?

G2 — Where did the revenue figures behind your renewal dashboards come from, and did you work with finance on them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.