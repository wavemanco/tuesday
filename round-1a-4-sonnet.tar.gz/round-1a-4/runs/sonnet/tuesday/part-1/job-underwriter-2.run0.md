Web search was denied, so this runs on the JD and your resume alone. Anything about Quartzline or the market is unverified.

## Decision snapshot

**No, you're not wasting your time. The pivot is plausible on your evidence, and this role is worth one application, but only with a way past the "3+ years PM" line. R1a, the one row below that line that wording can't fix, is absent. Status: `conditional_go`.**

**Fit ledger.**

- `must_have` — direct: R3, R4a · adjacent: R1b (3+ years product management experience, work done without the title), R2 (shipped API or platform products) · unclear: R4b (stakeholder management … sales), R5 (experience with agile delivery) · absent: R1a (3+ years product management experience, held under the title)
- `important` — direct: R7 · adjacent: R6 (own the roadmap), R8 (write specs and drive delivery with two engineering squads) · unclear: R9 (define and track adoption metrics), R10 (coordinate launches with sales and support)

R1a — absent, and wording cannot close it; R2, R8 — credible bridges with their limits named; R4b, R5, R9, R10 — your resume is silent, and one answer each could move them.

**Opportunity ledger.** The mandate is stated concretely (RR4). Three things are open: the employer is not verified from here (RR1), the posting may apply the titled-years line literally (RR2), and compensation is not stated (RR3).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) a route that puts a human in front of your integration and roadmap-input work before a years-of-title screen (R1a, RR2); (2) R2 strengthened by a confirmed shipped internal product (G1); (3) Quartzline and the live posting verified (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, about 150 people, Series B | `[grounded]` JD header, not independently checked |
| Mandate | Own the roadmap of the partner-facing API platform, run partner discovery, write specs, drive two squads, track adoption, coordinate launches | `[grounded]` JD |
| Level | Title is "Product Manager" with 3+ years required, not senior or lead | `[grounded]` JD; `[generic]` that this is a mid-level band for the title |
| Scope read | A single product surface, two squads and one partner audience, so a bounded remit | `[inferred]` from the squad count and the single platform named |
| Market calibration | Not run; no salary band to set against | the search was refused (see Evidence status) |
| Unknowns | Salary, reporting line, how strictly "3+ years" is applied, partner count, what the squads currently ship | `[grounded]` JD silent on each |
| Contradictions | None inside the JD | `[grounded]` JD read in full; no second source was available |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years product management experience, held under the title | must_have | absent | none | capability | You state you have never held a PM title, so no titled years exist. The JD marks the line must-have, and a length-of-experience line is not a legal gate. Wording cannot close it. | `[grounded]` your statement and the JD; `[generic]` that postings with this line are often screened on titles | Closure path in G4; no question |
| R1b | 3+ years product management experience, as work done without the title | must_have | adjacent | medium | transferability | Resume: requirements documents, scoping workshops, quarterly roadmap-input sessions for product, coordination with PMs on custom builds. That is PM-adjacent work. Limit: the roadmap sessions fed product's decisions and are not stated as your own prioritisation calls. | `[grounded]` resume prose, confirmed in your message, nothing inspected | Name which decisions were yours (G4) |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | You led 30+ client integrations of your employer's REST APIs and wrote the integration playbook the team uses. Limit: this is delivering and adopting an API, not stating that you shipped one as its owner. | `[grounded]` resume prose; the playbook is an inspectable artifact if shareable | G1 |
| R3 | Technical fluency: reading API docs, discussing schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI specs, integration architecture across 30+ builds. Confirmed and specific; nothing inspected. | `[grounded]` resume prose | A sanitised integration design doc would raise this to high |
| R4a | Stakeholder management across engineering and customers | must_have | direct | medium | none | You coordinated your own engineers, clients' engineers and PMs, and ran client workshops. This covers engineering and customers only. | `[grounded]` resume prose | none |
| R4b | Stakeholder management with sales | must_have | unclear | low | discovery | The resume says nothing about sales. Solutions roles often sit near sales, but that is a pattern, not your history. | `[grounded]` resume silence; `[generic]` the role-family pattern | G2 |
| R5 | Experience with agile delivery | must_have | unclear | low | discovery | The resume names no sprint, backlog or squad process. Working with engineers on custom builds is indirect context. | `[grounded]` resume silence | G3 |
| R6 | Own the roadmap | important | adjacent | medium | transferability | You ran quarterly roadmap-input sessions that collected client feedback for product. Limit: collecting input is not owning the roadmap or its trade-offs. | `[grounded]` resume prose | Name any prioritisation decision you made (G4) |
| R7 | Run discovery with integration partners | important | direct | medium | none | Scoping workshops and feedback sessions with clients who integrate your APIs; the closest match to the JD's own audience. Limit: they were customers of your employer, not partners of a platform you owned. | `[grounded]` resume prose | none |
| R8 | Write specs and drive delivery with two engineering squads | important | adjacent | medium | transferability | Requirements documents and integration architecture; you coordinated engineers on custom builds. Limit: no stated ownership of a squad's delivery or backlog. | `[grounded]` resume prose | G3 |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | The resume gives no adoption figures or tracking. | `[grounded]` resume silence | G1, G3 |
| R10 | Coordinate launches with sales and support | important | unclear | low | discovery | Go-live work is client-side. No launch with sales or support is stated. | `[grounded]` resume prose and its silence | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Shipped product with adoption (R2, R9) | transferability | 30+ integrations delivered and a team playbook. An earlier conversation suggested an internal request-triage tool that support agents adopted, but that is unconfirmed and treated only as a lead. | R2 is a must-have at `adjacent`, and this is where a real shipped product would move it. | An internal tool, workflow or playbook others adopted; a process you designed, rolled out and measured; a client-facing template or SDK you drove from idea to use | Usage numbers, a one-page description or screenshot of the tool, the playbook's table of contents | `[grounded]` resume; `[inferred]` that a confirmed shipped tool would lift R2 |
| G2 | Sales and support working relationships (R4b, R10) | discovery | Client-facing delivery only; sales and support are not mentioned. | R4b is a must-have and R10 a named responsibility; both are unestablished. | Joint calls with sales on scope or pricing; handoffs from sales to you; launch comms or enablement you ran for support | A handoff doc, an enablement deck, a launch checklist | `[grounded]` resume silence |
| G3 | Agile delivery and specs in a squad (R5, R8, R9) | discovery | Works with engineers on builds; no sprint, backlog or metric ownership stated. | R5 is a must-have; R8's limit sits here. | Writing tickets or acceptance criteria for engineers; joining sprint planning; tracking integration completion or time-to-go-live as a metric | Ticket samples, a delivery dashboard, a go-live tracker | `[grounded]` resume silence |
| G4 | Titled PM years and PM-type ownership (R1a, R1b, R6) | capability | No titled PM years; PM-type work without the title. | R1a is the row most likely to decide the outcome at this posting. | Decisions you made on what was built or in what order; features your input shaped | A roadmap-input summary and what product did with it | `[grounded]` your statement and resume; `[generic]` closure routes below |

G4 closure path: R1a cannot be recovered by wording. The routes are a referral or direct contact so a person weighs your work first, a PM-adjacent title within your current employer, and roles that ask for fewer titled years (technical or platform PM, or associate PM). `[generic]` These are role-family patterns, not claims about Quartzline.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from here | unknown | — | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The search was refused, so I could not check the company or the live posting. | `[generic]` pattern for any employer I could not check, not a claim about this one | Can you point me to this role on your careers site, and who the hiring manager is? | unresolved |
| RR2 | Titled-years requirement may be screened literally | risk_signal | medium | "3+ years product management experience (must-have)" | The posting calls this line must-have, so a screen on titles could end an application with a non-PM title before anyone reads your integration work. | `[generic]` how must-have experience lines are often applied | How does the team treat PM-equivalent experience gained in solutions or implementation roles? | unresolved |
| RR3 | Compensation not stated | unknown | — | the posting carries no salary or band | The figure may be below your floor or the company may not publish it. | `[grounded]` JD silence | What is the salary band for this role? | unresolved |
| RR4 | Mandate and success are stated concretely | positive_signal | — | "Own the roadmap for our partner-facing API platform … define and track adoption metrics" | Scope, audience and measure of success are named, and they sit close to your integration background. | `[grounded]` JD | What adoption metrics does the platform track today? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Reach a person at Quartzline (a referral, or the hiring manager) before or alongside applying, and lead with the integration-and-roadmap work | see R1a, RR2 | `[generic]` how roles with a titled-years line are often decided | pending your approval |
| E1 | Move the roadmap-input sessions, the playbook and the 30+ integrations above any tools list. Wording to follow once you approve and answer G1 to G3. | see R1b, R2, R6 | `[grounded]` resume | `resume_edits_pending_approval` |
| A2 | Describe your experience as PM-adjacent work, never as PM experience, in any note or answer | see R1a, R1b | `[grounded]` your statement | pending your approval |
| Q1 | Ask RR1 to RR4's verification questions in the loop | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: a request-triage tool that support agents adopted, from agent memory in an earlier conversation. It prompts G1 and nothing else.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have moved role reality's organization and contradictions rows and RR1. |
| 2. Role-family sweep | unavailable | The search was refused. It would have given the market calibration line and a band to set against RR3. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

## Dossier offer

I can save this as a `tuesday-dossier.md` for later steps whenever you want it.

## Upgrade menu

- Your answer to G1, with usage numbers or the playbook outline → R2 and R9 firm up, and R2 could move toward `direct`.
- Sales and support examples (G2) → R4b and R10 close.
- Ticket or delivery-tracking samples (G3) → R5 and R8 firm up.
- Permission to run web search → Quartzline and the posting verified (RR1), plus a salary band for RR3.
- The hiring manager's name → role reality's scope read, and which story the plan leads with.
- Your constraints (pay floor, location or remote, travel) → the hard-gates line stops reading "unknown".

## Questions

- **G1** — Have you built or driven anything that others adopted, such as an internal tool, a process or the playbook? What did you own, who used it, and how did you know it worked?
- **G2** — Have you worked with sales or support on a launch, a handoff or an enablement effort? What was your part, and what happened?
- **Constraints** — Do you have non-negotiables on pay floor, location or remote work, or travel?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.