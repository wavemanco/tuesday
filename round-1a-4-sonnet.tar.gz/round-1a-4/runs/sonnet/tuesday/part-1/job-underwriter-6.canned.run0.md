## Decision snapshot

**Yes, apply, but as a stretch you'd be open about, not a clean match. Status: `conditional_go`.** R6, R7 and R8 (the forecast and billing-data rows) are where you fall short of the posting. R1 and R2, the two hard gates, can't be checked yet because I don't have your location or pay floor.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Bristol hybrid, two office days), R2 (Salary £61,500–£67,000)
- `must_have` — direct: R3, R4 · adjacent: R5 (strong SQL and spreadsheet modelling), R6 (experience owning a forecast) · unclear: R7 (working with finance on billing or revenue data)
- `important` — direct: R9 · absent: R8 (owning billing data)

R6 (`medium`) — the CFO forecast is the stretch; R7 (`low`) — waiting on your answer; R8 — billing data is new to you.

**Opportunity ledger.** The employer is established and discloses its pay (RR1). The role's scope and equity terms are open (RR3, RR4, RR5), and I couldn't find the posting on Quillfield's own site (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two days a week in the office), R2 (Salary £61,500–£67,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Bristol with two office days and the pay band both work for you, which settles R1 and R2; (2) the interview makes clear what you'd own on the forecast versus support, per RR3 and R6; (3) you're comfortable learning billing data on the job, per R7, R8 and RR5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield makes invoicing and payments software for UK builders' merchants. Founded 2018 in Bristol; 96 employees; Series A (£11M) closed April 2025 | `[grounded]` search result, quillfield.co.uk/about |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two days a week in the office | `[grounded]` posting |
| Compensation | £61,500–£67,000 plus share options; options terms not stated | `[grounded]` posting |
| Market calibration | UK revenue operations lead in B2B software: median base £64,200, interquartile range £57,800–£70,400 (n=438). The posting's midpoint is £64,250. The figure is a pattern, not Quillfield's offer, and comes from a search snippet, not the full guide | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide; `[grounded]` posting figures |
| Hiring manager | Tamsin Achebe is listed as Head of Revenue Operations at Quillfield, previously sales operations manager at Corvane Payments for four years | `[grounded]` search result, linkedin.example/in/tamsin-achebe (snippet only) |
| Scope read | A hands-on lead post, probably sitting under her function rather than above it | `[inferred]` from her title against the posting's "Lead" |
| Unknowns | Team size and reporting line; who owns the forecast number; billing system and CRM in use; option terms; first-year outcomes (not stated) | — |
| Contradictions | None found. The posting could not be matched to a listing on Quillfield's own site (see RR2) | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid, two days a week in the office | hard_gate | unclear | none | hard_gate | You haven't stated a location constraint, and a UK team doesn't tell me where you live | `[grounded]` posting; no candidate statement | Closing question G1 |
| R2 | Salary £61,500–£67,000 | hard_gate | unclear | none | hard_gate | The posting states pay, but I have no pay floor from you | `[grounded]` posting; no candidate statement | Closing question G1 |
| R3 | 4+ years in revenue operations, sales operations or a similar analytics role at a B2B software company | must_have | direct | medium | none | Five years in sales operations, the last two running revenue operations; self-reported, nothing inspected. The posting says B2B software and you said B2B payments company, so sector fit is theirs to read | `[grounded]` your background | none |
| R4 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified, per your account; the certificate itself was not inspected | `[grounded]` your background | A certification record would raise it to `high` |
| R5 | Strong SQL and spreadsheet modelling | must_have | adjacent | medium | discovery | SQL weekly and Excel daily show use, not depth, and modelling isn't described. I read it downward | `[grounded]` your background | G4 |
| R6 | Experience owning a forecast; run the quarterly forecast with the CFO | must_have | adjacent | medium | transferability | You run the monthly pipeline review with your sales director and rebuilt the pipeline dashboards, but finance owned the forecast. Limit: you've never owned the company forecast | `[grounded]` your account; `[inferred]` that the pipeline work is a bridge to forecasting | G2 |
| R7 | Experience working with finance on billing or revenue data | must_have | unclear | low | discovery | You've never worked on billing data. Whether the renewal dashboards used finance's revenue figures isn't established | `[grounded]` your account; the renewal-data link is unconfirmed | G3 |
| R8 | Own the company's billing data | important | absent | none | capability | You said you've never worked on billing data, so there is no direct or adjacent evidence | `[grounded]` your account | G5 |
| R9 | Build pipeline and renewal reporting for sales and finance | important | direct | medium | none | You rebuilt the pipeline and renewal dashboards | `[grounded]` your account | A redacted dashboard screenshot would raise it to `high` |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Location and pay terms (R1, R2) | hard_gate | The posting states both; I don't know your limits | A failed gate would end this regardless of fit | Not applicable; this is a yes or no on the terms | None needed | `[grounded]` constraints not given |
| G2 | Owning a forecast (R6, must_have) | transferability | Monthly pipeline review and dashboard rebuild; the forecast sat with finance | R6 is a `must_have` row at `adjacent`, and the posting names the CFO forecast as a responsibility | Producing a pipeline coverage or commit view that finance used; a pipeline-to-revenue projection you built or maintained; a forecast-accuracy review | A redacted pipeline or forecast sheet | `[grounded]` posting and your account; `[inferred]` that this is the biggest stretch |
| G3 | Finance, billing or revenue data (R7, must_have) | discovery | Renewal dashboards exist; where their numbers came from isn't stated | R7 is a `must_have` row and the posting pairs it with owning billing data | Renewal figures reconciled with finance; shared reporting on contract values; revenue reports built from billing exports | A redacted renewal report | `[grounded]` your account; `[inferred]` that this may close part of the gap |
| G4 | SQL and spreadsheet modelling depth (R5, must_have) | discovery | Usage frequency only | The posting says "strong" | Revenue or churn queries; multi-sheet models others relied on | A sample query or workbook | `[grounded]` your account; asked next turn if useful |
| G5 | Billing data ownership (R8, important) | capability | No direct or adjacent evidence, by your account | The role owns this data | A realistic closure path: learn how invoice, credit note and payment-status data is structured, then ask the interview team what system and data you'd inherit. This closes it only partly | None yet | `[grounded]` your account; `[generic]` closure path |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Pay disclosed and mid-market | positive_signal | — | "Salary £61,500–£67,000 plus share options" | The range is transparent and its midpoint sits at the role-family median | `[grounded]` posting; `[generic]` Ledgerline median £64,200 | Is that the full range, and where would this role start? | noted |
| RR2 | Posting not seen on the employer's own careers page | unknown | — | "Revenue Operations Lead, Quillfield" | The role may be listed only through the job board and recruiter, or my guessed address was wrong | `[inferred]` from one empty careers search and one fetch of quillfield.co.uk/careers that returned no page | Can you point me to this role on Quillfield's own site? | unresolved |
| RR3 | Forecast ownership and reporting line unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The forecast number may be owned by the CFO or the Head of Revenue Operations, with this role supporting | `[inferred]` from the posting against the hiring manager's public title | Who owns the forecast number today, and what would I own versus support in the first two quarters? | unresolved |
| RR4 | Share option terms absent | unknown | — | "plus share options" | The equity's value can't be judged without grant size, vesting and strike price | `[grounded]` the posting's silence | What are the grant size, vesting schedule and strike price? | unresolved |
| RR5 | Several jobs under one title | risk_signal | low | "own our CRM and billing data, build the pipeline and renewal reporting … and run the quarterly revenue forecast" | CRM, billing data, reporting and forecasting may be several functions for one person at a firm of this size | `[inferred]` from the posting's scope list; `[generic]` pattern for firms of about 100 people | Who else supports the CRM and billing data, and is there an analyst or a finance systems owner? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Settle Bristol, hybrid and the pay band against your own limits before investing in an application | see R1, R2 | `[grounded]` the two gate rows | pending your approval |
| A2 | Lead with the Salesforce-certified admin work, the pipeline and renewal dashboards you rebuilt, and the monthly pipeline review you run with your sales director | see R3, R4, R9, R6 | `[grounded]` your account | pending your approval |
| A3 | Say plainly that finance owned the forecast at your current company, and that you've never worked on billing data | Keeps every claim within your own words; see R6, R8 | `[grounded]` your account | pending your approval |
| A4 | Ask the questions in RR2 to RR5 verbatim in the loop | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A5 | For Tamsin Achebe's round, put the pipeline-review and dashboard story first. Her listed earlier role was at a payments company, and you also come from payments | see R9 | `[grounded]` her public title and your sector; `[inferred]` the relevance | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company", which returned "About Quillfield" (quillfield.co.uk/about; snippet only). Searched "Quillfield careers Revenue Operations Lead Bristol", which returned no results. Fetched quillfield.co.uk/careers, which returned no page. Moved role reality's organization row and RR2 |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software Bristol", which returned "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide; snippet only). Moved the market calibration row and RR1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned "Tamsin Achebe — Head of Revenue Operations, Quillfield" (linkedin.example/in/tamsin-achebe; snippet only). Moved role reality's hiring manager and scope rows, RR3 and A5 |

## Dossier offer, then upgrade menu

I can save this as `tuesday-dossier.md` if you'd like to carry it into later steps.

- Your location and pay floor → R1 and R2 move from unconfirmed to met or failed.
- A redacted pipeline or forecast sheet, or an answer to G2 → R6's bridge strengthens.
- A redacted renewal report showing where the figures came from → R7 resolves.
- A sample query or workbook → R5 can rise to `high`.
- The certification record for your Salesforce admin credential → R4 can rise to `high`.
- A link to the role on Quillfield's own site → RR2 closes.
- Your CV as a document → rows can be checked against its text.
- A deeper research pass on Quillfield (funding and leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

G1 (R1, R2) — Are Bristol with two office days a week and £61,500–£67,000 both workable for you, or is either a hard limit?

G2 (R6) — Have you ever built a forecast or pipeline-to-revenue projection that went to finance or a CFO, and what was your part in it?

G3 (R7) — Did your renewal dashboards use revenue or billing figures from finance, and did you ever reconcile them with finance?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.