Still loading the playbook's reference files. Next up are the research-tier rules and the evidence vocabulary, then I'll write the assessment.
## Decision snapshot

**Yes, this one is worth applying to, on conditions. Status: `conditional_go`.** I assumed you're at the evaluating stage.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (BigQuery warehouse); unclear: R9 (Ingestion from app and CRM), R10 (Data contracts analysts depend on)

R8 — a credible bridge, its limit named; R9 and R10 — your background as given doesn't establish them yet.

**Opportunity ledger.** The pay range and seniority sit inside the market figures you supplied (RR3). The scope may be broader than one domain (RR4). I couldn't verify the employer or the live posting from here (RR1). The hiring manager and the equity terms are unstated (RR2, RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 are confirmed against your own location and pay floor; (2) RR1 clears, meaning the posting and company details check out on Pellucid's own pages; (3) R8 is framed as adjacent Snowflake experience, never as BigQuery experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the About text you pasted; I could not fetch the page to confirm it is current |
| Mandate | Build and run the reporting pipelines: ingestion from app and CRM, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD as pasted |
| Location and pay | Remote (US) or Denver; $148,000–$166,000 plus equity | `[grounded]` JD as pasted |
| Seniority and scope read | 5+ years and a single-owner pipeline scope fit the Datawright description of the title (5–8 years, one domain, no reports). The JD names no direct reports | `[grounded]` JD and the Datawright report as supplied |
| Market calibration | Base median $151,000, interquartile range $139,000–$163,500 (n=2,310, Series B–D). The posted floor is $3,000 under the median and the ceiling $2,500 over the 75th percentile. This is the report's cohort, not Pellucid's offer | `[grounded]` Datawright report as supplied, not independently checked |
| First-year outcomes | Not stated in the posting | `[grounded]` JD silence |
| Unknowns | Hiring manager, team size, equity terms, on-call expectations, who owns ingestion today | — |
| Contradictions | None between the JD and the About text as pasted. I could not compare either with the live pages | `[grounded]` the two pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | You haven't said where you're based or whether US work is open to you. Confidence is `none` because there's no statement to grade | `[grounded]` JD terms; no candidate statement | One question, below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor isn't given. The range itself sits inside the supplied market figures (RR3) | `[grounded]` JD figure; no candidate floor | Same question as R1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | 6 years of data engineering at a B2B payroll company. Prose self-report, so the intake ceiling applies. A titled-years requirement is a risk to name, not a gate | `[grounded]` your background as typed | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use in the same role. Depth isn't shown by anything inspectable | `[grounded]` your background as typed | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | Built the dbt project, about 180 models, on Snowflake, which is a cloud warehouse | `[grounded]` your background as typed | A sanitized project structure would raise it to `high` |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named directly | `[grounded]` your background as typed | none |
| R7 | Data quality testing | must_have | direct | medium | none | You set up the Great Expectations suite. That is a setup claim, not a coverage or outcome claim | `[grounded]` your background as typed | A suite summary or a sanitized config would raise it to `high` |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt modelling on Snowflake carries over. Not exercised: BigQuery's own dialect, its cost model and its table design. Nothing in the JD makes BigQuery a stated requirement; the requirements line says "a cloud warehouse" | `[grounded]` your Snowflake work and the JD wording; `[generic]` that these differences are what a warehouse switch usually turns on | Bridge case in G1 |
| R9 | Ingestion from the app and CRM | important | unclear | low | discovery | Pipelines are implied by your role, but which sources you ingested isn't stated | `[grounded]` background silent on sources | G2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | A test suite is adjacent to contracts, but nothing says you defined or enforced agreements with consumers | `[grounded]` background silent on consumer agreements | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Carries over: dbt modelling and warehouse design on Snowflake. Limit: no BigQuery use stated. Strengthener: a small dbt project run on BigQuery | The warehouse is named in the mandate, so an interviewer will likely ask | Any BigQuery exposure at all: a side project, a migration discussion, a cross-cloud query | A public repo of a dbt project on a BigQuery public dataset | `[grounded]` your Snowflake and dbt claims; `[inferred]` that this is the likeliest probe |
| G2 | Ingestion from app and CRM (R9, important) | discovery | Pipelines are implied, but sources and your ownership aren't stated | Ingestion is the first item in the mandate | Loading from a product database or event stream; syncing a CRM or SaaS API; handling schema drift or late data | A pipeline diagram or a DAG list, sanitized | `[grounded]` background silent on sources |
| G3 | Data contracts (R10, important) | discovery | A Great Expectations suite exists. Whether it was an agreement with downstream users isn't stated | The JD says analysts depend on these contracts | Agreeing a schema or freshness guarantee with analysts; blocking a bad load; a changelog for model changes | A sanitized contract doc or test config | `[grounded]` background silent on consumer agreements |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified from here | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | My page fetches were refused, so this records what I couldn't check, not anything found wrong. The posting may be stale or the figures may have changed | `[generic]` pattern for any unchecked posting, not a claim about this company | Can you point me at this role on your own careers site, and who I'd be interviewing with? | unresolved |
| RR2 | No hiring manager named | unknown | — | "Senior Data Engineer — Pellucid Learning" (no manager named) | Reporting line and team shape are unknown | `[grounded]` posting names no one | Who would this role report to, and who is on the data team today? | unresolved |
| RR3 | Pay and seniority consistent with the supplied market figures | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The posted range brackets the report's median ($151,000) and runs to just past its 75th percentile ($163,500) | `[grounded]` JD figure against the Datawright report as supplied | How is the range set, and where do offers for this level usually land? | noted |
| RR4 | Scope may span more than one domain | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts our analysts depend on" | Ingestion, modelling and contracts together exceed the report's typical one-domain scope. With a small team, one person could own all of it | `[inferred]` from the JD's three areas against the report's typical scope | How many data engineers are on the team, and who owns ingestion, modelling and contracts today? | unresolved |
| RR5 | Equity terms unstated | unknown | — | "plus equity" | The grant type, vesting and size are unknown, so total pay can't be compared yet | `[grounded]` JD gives no terms | What is the equity grant, and how does it vest? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the resume with the dbt project (about 180 models, Snowflake) and the Great Expectations suite you set up | see R5, R7 | `[grounded]` your background as typed | pending your approval |
| E2 | Name Snowflake plainly and say BigQuery is new to you. Don't imply BigQuery use | see R8 | `[grounded]` R8 row | pending your approval |
| W1 | A small public dbt project on a BigQuery public dataset | see R8, G1 | `[inferred]` from the limit named in R8 | pending your approval |
| A1 | Check the posting and the About text on Pellucid's own site before applying | see RR1 | `[grounded]` RR1 | pending your approval |
| Q1 | Ask the verification questions from RR2, RR4 and RR5 in the screen | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 0 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Fetches of the careers page and the About page were both refused, so the pasted posting and About text are unchecked. It would have moved RR1 and role reality's Organization and Contradictions rows |
| 2. Role-family sweep | skipped | The Datawright report you pasted fixes the market calibration row and RR3, which is all this target feeds |
| 3. Hiring manager's public footprint | n/a | The posting names no one, so there was no query to form |

## Dossier offer

If you'd like a saved copy of this assessment to carry into later steps, say so and I'll write it up as `tuesday-dossier.md`.

## Upgrade menu

- Your location and pay floor → R1 and R2 close, and the decision likely simplifies to `go`.
- Answers to G2 and G3 → R9 and R10 move off `unclear`.
- A repo or sanitized structure for your dbt project or the Great Expectations suite → R5 and R7 can reach `high`.
- A public dbt-on-BigQuery project → G1 narrows R8's limit.
- The live careers page text, or fetch access → RR1 can close.
- The hiring manager's name → role reality's scope read and which story the plan leads with.
- A deeper research pass on Pellucid Learning (funding, leadership changes, hiring patterns, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

R1, R2 — Do the posting's location options and its pay range both work for you?

G2 — Which sources did you ingest into your warehouse, such as a product database, event stream, CRM or SaaS APIs, and what did you personally own?

G3 — Did analysts depend on tables you published, and did you define or enforce any agreed schema or freshness guarantees with them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.