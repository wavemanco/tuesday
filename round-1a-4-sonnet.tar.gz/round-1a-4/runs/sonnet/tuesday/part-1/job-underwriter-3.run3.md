Search permission was declined, so I'm working from your posting and your message only. Here is the assessment.

## Decision snapshot

**Is it worth pursuing? No. R1 and R2, both hard gates, fail on your location and pay terms. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: hard_gate_fail: R1 (On-site in Austin, 5 days a week), R2 (Base $70–85k)
- `must_have`: direct: R5, R6 · unclear: R4 (8+ years growth leadership), R7 (SEO/content)
- `important`: unclear: R8 (Brand and PR), R9 (Partnerships and sales ops), R10 (Operating as a team of one)

R1, R2: terms that no wording can fix; R5 (`medium`), R6 (`medium`): confirmed in your message, no inspectable artifact yet; R7, R8, R9: your message is silent on them.

**Opportunity ledger.** RR1 and RR2 confirm the posting's terms conflict with your two constraints. RR3 to RR6 are risk signals from the posting's own wording: seven functions with no team, pay that looks low for the scope, always-on expectations, and undefined success measures. That is most of what feels off to you. RR7 notes that the employer is unverified. RR8 is the only positive signal.

- **Hard gates:** failed: R1 (On-site in Austin, 5 days a week), R2 (Base $70–85k)
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`)
- **What would change this:** the employer would have to offer remote work and a base of at least $150k (R1, R2), or you would have to revise either constraint.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, an e-commerce enablement startup, Series A, "profitable since day one" | `[grounded]` posting's own description, not independently verified |
| Mandate | "Own all revenue growth end to end": paid, SEO/content, lifecycle/CRM, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Team and reporting | "A team of one to start"; reports to the CEO, dotted line to the board | `[grounded]` posting |
| Working pattern | Austin office 5 days a week, "no exceptions"; "evenings and weekends when it matters" | `[grounded]` posting |
| Compensation | $70–85k base plus "meaningful equity upside"; no equity terms stated | `[grounded]` posting |
| Success measures | "Success metrics will evolve as we learn"; no first-year outcomes stated | `[grounded]` posting |
| Scope read | A head-of-function title carrying seven functions with no staff or stated budget | `[inferred]` from the function count against "team of one" |
| Market calibration | Not established. The role-family sweep did not run, so no band is given | `[grounded]` the sweep was unavailable |
| Unknowns | Equity terms, marketing budget, decision rights, what "Head" means with no reports | `[grounded]` posting silent |
| Contradictions | "8+ years growth leadership" and "head" beside "team of one" | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | On-site in Austin, 5 days a week, "no exceptions" | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your stated constraint (remote-only, living in Portland, not relocating), which is specific and confirmed. The fit fails because the posting rules out remote work. | `[grounded]` posting quote and your message | Only the employer changing terms, or you revising the constraint, resolves it |
| R2 | Base $70–85k | hard_gate | hard_gate_fail | high | hard_gate | Confidence grades your $150k floor, which is yours and confirmed. The fit fails because the top of the posted range is $65k below it. | `[grounded]` posting quote and your message | Same as R1 |
| R4 | 8+ years growth leadership | must_have | unclear | medium | discovery | You state 9 years in growth, then growth lead, then Head of Growth. The years spent in lead or head titles are not stated, so the 8+ figure is not yet checkable. | `[grounded]` your message | Confirm how many of the 9 years were lead or head roles |
| R5 | Paid acquisition | must_have | direct | medium | none | You state you owned paid with a budget you controlled, within the $8M to $40M ARR scale-up. This is specific and confirmed, with no inspectable artifact yet, so expect a probe. | `[grounded]` your message | A channel P&L or spend summary would raise it to `high` |
| R6 | Lifecycle/CRM | must_have | direct | medium | none | You state you owned lifecycle and are deep in Braze. The caveat is the same as R5. | `[grounded]` your message | A sanitized lifecycle map or results deck would raise it to `high` |
| R7 | SEO/content | must_have | unclear | low | discovery | Your message does not mention SEO or content. | `[grounded]` your message silent | Recall prompt G1 |
| R8 | Brand and PR | important | unclear | low | discovery | Your message does not mention brand or PR. | `[grounded]` your message silent | Recall prompt G2 |
| R9 | Partnerships and sales ops | important | unclear | low | discovery | Your message does not mention either. | `[grounded]` your message silent | Recall prompt G3 |
| R10 | Operating as a team of one | important | unclear | low | discovery | You managed teams of 3 to 7. Solo execution across functions is not evidenced. | `[grounded]` your message | Recall prompt G4 |

## Gap recovery queue

These rows only matter if R1 and R2 move.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R7, must_have) | discovery | No SEO or content work mentioned | The only `must_have` row with no evidence | Owning organic traffic targets, a content calendar or an SEO agency relationship | Organic traffic dashboard, content brief | `[grounded]` your message silent |
| G2 | Brand and PR (R8, important) | discovery | Nothing mentioned | The posting folds brand and PR into one mandate | Launch announcements, press coverage you drove, brand campaigns | Press clippings, campaign brief | `[grounded]` your message silent |
| G3 | Partnerships and sales ops (R9, important) | discovery | Nothing mentioned | The posting adds both to growth | Affiliate or channel deals, CRM or pipeline ownership | Partner agreement, pipeline report | `[grounded]` your message silent |
| G4 | Solo operation (R10, important) | discovery | You led teams of 3 to 7 | The role starts with no team | Periods you executed hands-on across channels before hiring | Early-stage role history | `[grounded]` your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Base pay below your floor (R2) | red_flag | high | "$70–85k base" | The range conflicts with your $150k non-negotiable | `[grounded]` posting quote and your message | Is the base range flexible, and what is the ceiling? | confirmed |
| RR2 | On-site requirement against remote-only (R1) | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The role cannot be done from Portland | `[grounded]` posting quote and your message | Is any remote arrangement possible for this role? | confirmed |
| RR3 | Seven functions, no team or stated budget | risk_signal | medium | "You will be a team of one to start" | You may be accountable for every channel with no resources or decision rights | `[inferred]` from the function list against "team of one" | What budget and hiring plan are committed for this role? | unresolved |
| RR4 | Pay against seniority and scope | risk_signal | medium | "8+ years growth leadership required" beside "$70–85k base" | The range may sit below what this mandate usually pays, which a market search would settle | `[inferred]` from the posting alone, since no sweep ran | What is the equity grant, and how is "meaningful" defined? | unresolved |
| RR5 | Always-on expectations | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Out-of-hours work may be routine rather than occasional | `[inferred]` from the posting's wording | How often did the last person in a similar role work evenings and weekends? | unresolved |
| RR6 | Success measures undefined | risk_signal | medium | "success metrics will evolve as we learn" | You could be held accountable for outcomes no one has defined | `[inferred]` from the posting's wording | What does success look like at 90 days and at 12 months? | unresolved |
| RR7 | Employer not established from attributable sources | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A, profitable since day one)" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I report to? | unresolved |
| RR8 | Reporting line and profitability stated | positive_signal | — | "Report to the CEO"; "profitable since day one" | The employer states a senior reporting line and a profitable business | `[grounded]` posting states both, unverified | Which board member holds the dotted line, and how often do you meet? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply as posted | R1 and R2 fail, so effort here has no path to an offer | `[grounded]` R1, R2 | pending your approval |
| A2 | If you want to test the terms first, send one note to the employer through contact details on their own website, asking about remote work and the base ceiling, before any other effort | RR1, RR2 | `[grounded]` register | pending your approval |
| A3 | If the terms move, ask RR3 to RR6 verbatim in the first conversation | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was not permitted. It would have moved role reality's organization row and RR7 |
| 2. Role-family sweep | unavailable | The search was not permitted. It would have supplied the market calibration line and settled RR4 |
| 3. Hiring manager's public footprint | n/a | The posting names no person, so there is no query to form |

I can write this up as `tuesday-dossier.md` if you want to keep it or reuse it later.

## Upgrade menu

- Permission to search, or a link to the live posting → RR7 resolves, and market calibration and RR4 get a band.
- How many of your 9 years were lead or head roles → R4 resolves.
- Any SEO, content, brand, PR or partnerships work → R7, R8 and R9 move up from unclear.
- A channel P&L or lifecycle results deck → R5 and R6 to `high`.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.