Checking Brindlemoor's own careers page, because its listing says "Leeds office four days a week" and your JD says fully remote.
## Decision snapshot

**Yes, this is worth applying to once the working pattern is confirmed (R1, RR1). Status: `conditional_go`.** Your two worries are R9 (pet insurance, `adjacent`) and RR3 (management, unstated). Neither is a must-have.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6a, R7 · adjacent: R8 (Recommendations to product) · unclear: R6b (Monitor rating models)
- `important` — adjacent: R9 (Pet-insurance product knowledge)
- `preferred` — direct: R10

R6b — the monitoring half of the model work, one question away; R9 — a credible bridge from motor, its limit named.

**Opportunity ledger.** The role is live and clearly scoped (RR5), but the posting contradicts itself on working pattern (RR1), states no pay (RR2) and says nothing about management (RR3). It also states no first-year outcomes (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed as one you can do — R1, RR1; (2) the pay, once disclosed, is acceptable to you — RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product. Its own careers page lists this role as "Accepting applications". Stage and size are not stated anywhere I read | `[grounded]` careers page fetched |
| Mandate | Own pricing analytics for the pet product: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` your JD |
| Reporting line | The Director of Pricing, Odile Varga | `[grounded]` JD and careers page |
| Working pattern | The JD says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` both quoted |
| Hiring manager | Director of Pricing at Brindlemoor. Previously head of pricing analytics at Calloway Re for six years. Spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books | `[grounded]` profile page, read from the search result only |
| Scope read | An individual-contributor shape: no direct reports or management duty appear in the JD or the careers page | `[inferred]` from their silence |
| Compensation | Not stated. A 2026 UK survey of senior pricing analysts at insurers and insurtechs gives a median base of £58,400, with an interquartile range of £52,100 to £64,900. That is the market band, never this employer's offer | `[generic]` survey result, read from the search snippet only |
| Market calibration | Pay band only. I did not research title or scope norms | `[generic]` one salary search |
| First-year outcomes | Not stated | `[grounded]` JD silence |
| Unknowns | Working pattern, pay, direct reports, how product teams take recommendations, team size | — |
| Contradictions | JD "fully remote" against careers page "Leeds office four days a week" | `[grounded]` both pages |

## Evidence map

I built this from your typed background, which has the same standing as a CV at intake. That caps the rows at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK | hard_gate | unclear | none | hard_gate | You haven't stated a location or working-pattern constraint, so there is nothing to grade. Fit is `unclear` because the JD and the careers page disagree | `[grounded]` JD against careers page | Q1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years of pricing analytics at a UK motor insurer, the last two as senior analyst. Confirmed and specific, but no inspectable artifact | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is your own word, and nothing inspectable backs it yet | `[grounded]` your background | an artifact would raise it, see the upgrade menu |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for the young-driver book. Motor is not pet, but the technique is the same | `[grounded]` your background | an artifact would raise it |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. Underwriting is covered; no actuarial audience is stated | `[grounded]` your background | none |
| R6a | Build rating models | must_have | direct | medium | none | Same evidence as R4 | `[grounded]` your background | none |
| R6b | Monitor rating models | must_have | unclear | low | discovery | You said "maintained", which doesn't establish monitoring, so I took the lower reading. Monitoring is usually part of maintaining a model | `[grounded]` your wording; `[generic]` the usual scope of maintenance | Q2 below |
| R7 | Design and read price tests | must_have | direct | medium | none | You ran 14 price tests last year with the underwriting team. Expect a probe on how much of the design and read-out was yours, since "ran" doesn't say | `[grounded]` your background | none |
| R8 | Turn results into recommendations for underwriting and product | must_have | adjacent | medium | discovery | The underwriting side is covered by R5 and R7. Nothing you said involves a product team, so the product side is a limit | `[grounded]` your background; the product gap is `[inferred]` from silence | G3 in the queue |
| R9 | Pet-insurance product knowledge (not asked for in the JD) | important | adjacent | medium | transferability | Inferred from the role being the pet product. Your motor pricing carries over as rating-model and test work. The limit is that you have not priced pet claims or customers | `[inferred]` from "our pet-insurance product"; `[generic]` that motor and pet both rest on GLM-style pricing | G4 in the queue |
| R10 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The JD says fully remote and the careers page says Leeds four days a week. Your constraints aren't stated | Whether you can do the role as it is really set up could change the status | Where you live and whether four days in Leeds is workable | Brindlemoor's answer, or any recruiter email | `[grounded]` both pages |
| G2 | Monitoring rating models (R6b, must_have) | discovery | "Maintained" is the only word on monitoring | A must-have. The hiring manager's published talk is about monitoring rating models in small books, so this is the row it touches | Tracking actual against expected, checking for drift, refitting on a schedule, reporting model performance to underwriting | A sanitized monitoring pack or a model-performance report | `[grounded]` your wording and her talk topic; `[inferred]` that this row is the likeliest to be probed |
| G3 | Recommendations to product (R8, must_have) | discovery | Your recommendations go to underwriting. Product isn't mentioned | The role feeds both teams | Taking a test result to a product, pricing-strategy or commercial group, or shaping a product change from rating output | A sanitized recommendation paper or readout | `[grounded]` your background; `[inferred]` the gap |
| G4 | Pet-insurance knowledge (R9, important) | transferability | Motor GLM and price-testing work. The bridge is the model and test craft. The limit is that you haven't worked on pet claims or customers. The strengthener is naming how you'd learn the pet rating factors | A fair bridge reads weaker on paper and stronger in interview | — | A short note on what you would check first in a pet book | `[inferred]` bridge; `[generic]` that rating factors differ by product |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern contradicts itself (R1) | risk_signal | medium | JD: "Fully remote (UK)". Careers page: "Leeds office four days a week" | One page may be out of date, or the role may allow remote work by exception. Which governs is not established | `[grounded]` both quoted; `[inferred]` the hypothesis | Is this role fully remote, or four days a week in the Leeds office? | unresolved |
| RR2 | Pay not stated | unknown | — | No figure in the JD as you pasted it | Pay may sit anywhere in the market band, or they may not publish it | `[inferred]` from the silence, set against the `[generic]` survey band | What salary range is budgeted for this post? | unresolved |
| RR3 | Management expectations unstated | unknown | — | "reports to the Director of Pricing" | The post reads as individual-contributor, but whether it has or will gain direct reports isn't stated | `[inferred]` from the silence | Does this post have direct reports today, or is that planned? | unresolved |
| RR4 | No first-year outcomes for a broad mandate | unknown | — | "Own pricing analytics for our pet-insurance product" | Scope could be wide with no stated definition of success | `[inferred]` from the posting's wording | What would a good first year look like, and what state are the rating model and test programme in? | unresolved |
| RR5 | Role live and consistent on the employer's own page | positive_signal | — | "Accepting applications. Senior Pricing Analyst … reports to the Director of Pricing" | The employer is hiring for this role, with title, product and reporting line matching your JD | `[grounded]` careers page fetched | Who else works on pricing for the pet product? | noted |

## Application plan

Everything here is proposed, and nothing is final until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the working pattern with Brindlemoor before investing in the application | see R1, RR1 | `[grounded]` RR1 | pending your approval |
| E1 | CV lines using your own words only: "Built and maintained the GLM rating model for the young-driver book", "Ran 14 price tests with the underwriting team last year", "Present the quarterly pricing review to the head of underwriting" | see R4, R6a, R7, R5. Every clause traces to a sentence you wrote. I've added no ownership, scope or outcome | `[grounded]` your background | resume_edits_pending_approval |
| A2 | Framing for the interview: say plainly that you haven't worked on pet insurance and haven't managed anyone. Then name the transferable work, which is the GLM build and the price tests | see R9, RR3. The JD has no management requirement. The limit stays visible | `[grounded]` your background and the JD | pending your approval |
| A3 | Prepare a real monitoring example only if G2 turns up one. Her published talk is on monitoring rating models in small books | see R6b. I can't tell you what she is looking for, only what she has published | `[grounded]` her talk topic | pending your approval |
| Q-plan | Ask RR1, RR2, RR3 and RR4's questions verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech careers". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). The page is thin and repeats its search snippet. It moved role reality's organization and contradictions rows, RR1 and RR5 |
| 2. Role-family sweep | yes | Searched "senior pricing analyst pet insurance UK salary remote", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). Read from the snippet, not fetched. It moved the compensation row, market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). Read from the snippet, not fetched. It moved role reality's hiring manager row, G2 and A3 |

I can write this up as `tuesday-dossier.md` whenever you want it saved.

## Upgrade menu

- Your location and working constraints would settle R1. The decision would then simplify to `go` or `no_go`.
- Your pay floor would let RR2 be set against the survey band.
- A sanitized monitoring pack or model-performance report would settle R6b. It would also raise R4 and R3 toward `high`.
- A sanitized price-test readout or your quarterly pricing review deck would raise R7 and R5 toward `high`.
- Your CV would show whether any of this is buried, which could turn rows into `presentation` gaps with edits to propose.
- Brindlemoor's answer on the working pattern would close RR1.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

**Questions**

Q1 (G1) — Do you need this to be fully remote, or is four days a week in Leeds workable for you? Does your location rule it in or out?
Q2 (G2) — Have you personally monitored the young-driver model after launch? What did you track, how often, and did you ever act on what you found?
Q3 (RR2) — What is your minimum acceptable base salary?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.