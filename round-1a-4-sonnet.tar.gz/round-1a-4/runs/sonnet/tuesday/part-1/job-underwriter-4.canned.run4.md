Searches are done on the company, the pay band and the hiring manager. The company search came back empty, so I'm making one more attempt to confirm Brindlemoor exists.
**Yes, apply, on the conditions below. Status: `conditional_go`.** R1 (working pattern) isn't settled. Your fit on R2, R3, R4 and R5 reads `direct`, but the posting and the company's careers page give different working patterns.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6, R7
- `preferred`: direct: R8

R1 — the posting and the careers page disagree on working pattern; R4 (`medium`) — a built-and-maintained GLM, confirmed in your words only.

**Opportunity ledger.** The scope is concrete and the reporting line is named (RR3). The posting and the careers page disagree on working pattern (RR1), and no salary is stated (RR2).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the working pattern is confirmed as one you can do (R1, RR1). If it is Leeds four days a week and you can't, R1 becomes `hard_gate_fail` and the status `no_go`. (2) The salary range is acceptable to you (RR2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, with this posting live on brindlemoor.co.uk/careers | `[grounded]` careers page fetched |
| Mandate | Build and monitor rating models, design and read price tests, and turn results into recommendations for underwriting and product, for the pet-insurance product | `[grounded]` JD |
| Working pattern | The posting says "Fully remote (UK)". The careers page says "Leeds office four days a week" | `[grounded]` both sources, contradicting each other |
| Reporting line | The Director of Pricing, Odile Varga | `[grounded]` JD and careers page |
| Hiring manager | Director of Pricing at Brindlemoor. She spoke at the 2025 Insurance Pricing Forum on "Small Books, Loud Errors", about monitoring rating models in small books. She was previously head of pricing analytics at Calloway Re for six years | `[grounded]` search result for her public profile (snippet only, page not opened) |
| Pet insurance | Not required. The JD lists insurance experience as "a plus" and does not mention pet-specific experience | `[grounded]` JD |
| People management | The JD asks for no managerial experience | `[grounded]` JD silence |
| Market calibration | Pricewell's 2026 survey gives a median base of £58,400 for senior pricing analysts at UK insurers and insurtechs, with an interquartile range of £52,100 to £64,900. The posting states no pay, so this band is what to expect, not Brindlemoor's offer | `[generic]` survey search result (snippet only); `[grounded]` posting silent on pay |
| Unknowns | Salary, the real working pattern, team size | `[grounded]` JD and careers page silent |
| Contradictions | Working pattern, as above | `[grounded]` JD against careers page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote (UK) | hard_gate | unclear | none | hard_gate | You haven't stated a location or working-pattern constraint, so there is nothing to grade. Fit is `unclear` because the posting and the careers page disagree | `[grounded]` JD, careers page, no stated constraint | Question G1; RR1's question to the employer |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | You describe 5 years of pricing analytics at a UK motor insurer. Self-reported, with no inspectable artifact yet. A years requirement is not a gate | `[grounded]` your stated background | Offer: your CV with dates |
| R3 | Strong SQL and Python | must_have | direct | medium | none | You use both daily. "Strong" is a depth claim that nothing inspectable yet shows | `[grounded]` your stated background | Offer: a sanitized query or notebook would raise to `high` |
| R4 | GLM experience | must_have | direct | medium | none | You built and maintained the GLM rating model for a young-driver book. Limit: it is a motor book, not pet | `[grounded]` your stated background | Offer: a model specification or factor-review document, sanitized |
| R5 | Experience presenting to underwriting or actuarial leads | must_have | direct | medium | none | You present the quarterly pricing review to the head of underwriting. The JD says "or", so one audience covers it. Actuarial audiences are not stated | `[grounded]` your stated background and JD wording | Offer: a sanitized review deck |
| R6 | Build and monitor rating models | important | direct | medium | discovery | "Built and maintained" covers building. How you tracked the model after launch isn't described | `[grounded]` your stated background | Question G2 |
| R7 | Design and read price tests, and turn results into recommendations | important | direct | medium | none | You ran 14 price tests last year with the underwriting team. Whether you made the recommendations is not stated | `[grounded]` your stated background | Offer: a sanitized test readout |
| R8 | Insurance experience (a plus) | preferred | direct | medium | none | Motor insurance is insurance experience. Pet-specific knowledge is not asked for | `[grounded]` JD wording and your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working pattern (R1, hard_gate) | hard_gate | The posting says remote and the careers page says Leeds four days a week. Your location and constraints are not stated | A gate. A Leeds four-day answer you can't meet turns R1 into `hard_gate_fail` and the status into `no_go` | Not experience. It is your location and the working pattern you can do | The employer's written confirmation of the working pattern | `[grounded]` the two sources; `[inferred]` that the answer flips the status |
| G2 | Model monitoring (R6, important) | discovery | "Built and maintained" doesn't say how model performance was tracked after launch | The role is to "build and monitor rating models". The hiring manager's published talk is about monitoring rating models | Tracking actual against expected on the young-driver model; a refit or drift review you ran; a monitoring report others used | A sanitized monitoring pack or refit note | `[grounded]` JD and her talk topic; `[inferred]` that this is the likeliest probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Working pattern differs between the posting and the careers page | risk_signal | medium | "Fully remote (UK)" in the posting you pasted; "Leeds office four days a week" on the careers page | One source may be stale, or the terms may differ by hire. Neither is ranked as likely | `[grounded]` both quotes; `[inferred]` the hypotheses | Is this role fully remote, or based in the Leeds office four days a week? | unresolved |
| RR2 | No salary stated | unknown | — | (no pay line in the posting) | The pay may sit anywhere in the market band, or the company may simply not publish it | `[inferred]` from the posting's silence, set against the `[generic]` survey band | What is the salary range for this post? | unresolved |
| RR3 | Clear scope and a named reporting line | positive_signal | — | "Own pricing analytics for our pet-insurance product; reports to the Director of Pricing" | The role's scope is stated, and the hiring manager has a public pricing-monitoring background | `[grounded]` careers page and profile search result | How will success in this role be measured in the first year? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask the working-pattern question of the employer through contact details on brindlemoor.co.uk, before investing in the loop | See RR1, R1 | `[grounded]` RR1 | pending your approval |
| A2 | Lead with your young-driver GLM build and the 14 price tests, using your own wording and keeping `medium` caveats in mind | See R4, R7 | `[grounded]` your stated background | pending your approval |
| A3 | Cite the quarterly pricing review to the head of underwriting as your presenting evidence | See R5 | `[grounded]` your stated background | pending your approval |
| A4 | If asked about people management, say plainly that you haven't managed anyone. The JD doesn't ask for it | See role reality | `[grounded]` your statement and JD silence | pending your approval |
| A5 | Be ready to describe, in your own words, how you tracked the young-driver model after launch, if you did | See G2 | `[grounded]` JD and her talk topic | pending your approval |
| A6 | Ask RR1, RR2 and RR3's questions verbatim in the process | The register doubles as interview preparation | `[grounded]` register | pending your approval |

Beyond the spec, as an offer: I can draft short, honest answers to "you haven't worked on pet insurance" and "you haven't managed anyone", checked clause by clause against your own words. It would be built only on your approval.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor pet insurance insurtech" (no results) and "Brindlemoor careers pricing analyst". Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). It confirmed the posting is live and moved role reality's working-pattern contradiction (RR1). The first search found no other presence for the company |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK remote salary", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example/2026-uk-pricing-analytics-pay-survey). It moved the market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned "Odile Varga — Director of Pricing, Brindlemoor" (linkedin.example/in/odile-varga). It moved role reality's hiring-manager row and G2 and A5 |

I can write this up as a `tuesday-dossier.md` if you'd like to carry it into later stages.

**Upgrade menu**

- Your location and any working-pattern or pay constraints → R1 settles, and the status moves to `go` or `no_go`.
- The employer's answer on working pattern → R1 and RR1 close.
- The salary range → RR2 closes against the survey band.
- Your CV, or a sanitized artifact such as a model specification, a price-test readout or a monitoring pack → R2 to R7 can move toward `high`.
- A deeper research pass on Brindlemoor (funding, leadership changes, recent news, candidate and employee reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

G1 — Where are you based, and could you work from the Leeds office four days a week, or is remote-only a firm requirement?

G2 — After the young-driver GLM went live, how did you track whether it was performing, and what did you personally do when it drifted?

RR2 — Do you have a pay floor for this move?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.