Web search wasn't permitted in this session, so this assessment runs only on what you pasted.

## Decision snapshot

**Yes, worth applying to, but I can't say Fernquay is legit yet. Status: `conditional_go`.** Neither the posting nor Ronan's message asks you for money, a deposit or ID. I couldn't look the company up, so it stays unconfirmed (RR1).

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 against your floor)
- `must_have` — direct: R3, R4, R5 · adjacent: R6 (Own the booking flow end to end)
- `important` — direct: R7 · adjacent: R8 (First designer, no design peers)

R6 — your checkout redesign is a credible bridge, its limit named; R8 — squad experience, never the sole designer; R2 — waiting on your pay floor.

**Opportunity ledger.** The posting is concrete: the scope is specific, the pay band is stated and a named contact appears (RR4). Against that, the employer is not established from here (RR1), the equity terms are open (RR2) and the "messy real project" expectation is undefined (RR5).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a live employer on its own site — RR1; (2) your pay floor clears the band and the equity terms are explained — R2, RR2; (3) any work sample is bounded and paid — RR5.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Reporting | Works most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity; vesting and instrument not stated | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Scope read | A coherent first-designer remit at a small company, where research, design and shipping fall to one person | `[inferred]` from the posting's mandate list against its team size |
| Market calibration | Not run, because search was refused, so there is no salary band to set the offer against | `[generic]` no band stated rather than recalled from memory |
| Unknowns | Equity terms; who reviews design work; what the work-sample expectation is; whether the role is live on a careers page | — |
| Contradictions | None between the posting and the message: both name Ronan as co-founder, and Saoirse as CTO is consistent with a six-person team. Neither was checked against a careers page | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days fit. Stated in prose, not inspectable | `[grounded]` your background note | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so whether the band meets it is not established | `[grounded]` posting states the band, your floor not given | G3 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Stated, with no document inspected | `[grounded]` your background note | portfolio link would raise to high |
| R4 | Strong Figma | must_have | direct | medium | none | Figma daily over four years. A Figma file or case study would be the inspectable proof for this field | `[grounded]` your background note | share the checkout case study |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. The posting's research calls with school owners are likelier to be discovery interviews than usability testing, a difference you should name | `[grounded]` your background note; `[generic]` that usability testing and discovery interviews are different methods | name the difference honestly on the call |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a checkout flow, which is one stage of a booking flow. The limit is the stages before and after checkout, and "end to end" is not something you've stated you owned | `[grounded]` your background note; `[inferred]` that the posting's "end to end" spans more than checkout | G1 |
| R7 | Happy working directly with engineers | important | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background note | none |
| R8 | First designer with no design peers | important | adjacent | medium | transferability | Four years in a squad is related experience. You've never been the only designer, so no peer review or design-lead cover is the real change | `[grounded]` your background note | G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole booking flow (R6, must_have) | transferability | A checkout redesign, but not what came before or after it | A `must_have` at `adjacent`; the strongest bridge is how much of the redesign you owned from research to ship | Discovery or search screens you touched; research that fed the redesign; post-purchase or confirmation screens; handoff to engineers | Your checkout case study, a Figma file, a research readout | `[grounded]` your note is silent on scope beyond checkout |
| G2 | Working as the sole designer (R8, important) | transferability | Squad work, no solo-designer stretch | A first-designer role has no one to review your work, so a smaller solo stretch would help | A feature, side project or freelance job where you made the design decisions alone | A small shipped project, even an informal one | `[grounded]` you've never been the only designer |
| G3 | Pay floor (R2, hard_gate) | hard_gate | No stated floor, so the band can't be checked | The gate is only settled once you state your floor | Not applicable; this is a term you set | Your own floor | `[grounded]` constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | Fernquay may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. Search was refused here, so this rests on your report that little is findable | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers page, and tell me who is on the team? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The percentage may be options or shares, with a vesting schedule and dilution not described | `[inferred]` from the posting giving a figure without terms | Is the equity options or shares, what is the vesting schedule and cliff, and what is the current share count basis? | unresolved |
| RR3 | Design review and authority not described | unknown | — | "own the booking flow end to end" | As first designer you may carry the outcomes while decisions sit with the co-founder | `[inferred]` from the mandate wording against silence on decision rights | Who reviews design decisions, and which ones are mine to make alone? | unresolved |
| RR4 | Pay band and concrete scope stated | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | The posting states pay and a specific mandate rather than withholding them | `[grounded]` posting | How was the band set, and is it fixed? | noted |
| RR5 | Work-sample expectation undefined | unknown | — | "we would rather see one messy real project than a polished deck" | This may mean a casual portfolio chat, or a request for unpaid project work | `[inferred]` from the sentence being open-ended | Is any work sample expected, how long should it take, and is it paid? | unresolved |

Scheduling a video call through WhatsApp, with the invite emailed, is a routine step, so it takes no register entry. Neither text asks you to pay, deposit or hand over bank, tax or ID details.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the emailed invite came from an address on Fernquay's own website domain. Reply to the invite there rather than relying on the WhatsApp thread alone | see RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask RR1, RR2, RR3 and RR5 on the call, using the verification questions as written | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Lead with "I redesigned our checkout flow" and "I ran monthly usability sessions with customers", in your own words, and say plainly that you've worked in a squad, not as the only designer | see R5, R6, R8 | `[grounded]` your background note | pending your approval |
| A4 | Before accepting, state your salary floor to yourself and check it against the band | see R2 | `[grounded]` R2 | pending your approval |

If you go ahead, mock-interview can prepare you for the call with Ronan and Saoirse.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Fernquay booking software sea kayak surf schools Galway" was refused. It would have settled whether the company and the role exist as described (RR1, role reality's organization row) |
| 2. Role-family sweep | unavailable | The search for first-product-designer pay in Ireland was refused. It would have given the market calibration line and a check on the band (R2, role reality) |
| 3. Hiring manager's public footprint | unavailable | Ronan Kehoe was named, so a query could be formed, and the search was refused. It would have informed the scope read and which story to lead with (A3) |

## Dossier offer and upgrade menu

I can save this as a `tuesday-dossier.md` if you'd like to carry it forward.

- Permission to run web search, and I'll run the L1 pass, which settles RR1 and the pay band.
- Your checkout case study link → R3, R4 and R6 can rise to `high`.
- A copy of the emailed invite's sender address → I can check it against the company's own domain.
- The recruiter's answer on equity and the work sample → RR2 and RR5 close.

G1 — How much of the checkout redesign did you personally own, from research through shipping, and did it touch any screens before or after checkout? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G2 — Have you ever made design decisions alone on a feature, side project or freelance job, even a small one? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G3 — What is the lowest salary you'd accept, and does €52,000–€60,000 clear it? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.