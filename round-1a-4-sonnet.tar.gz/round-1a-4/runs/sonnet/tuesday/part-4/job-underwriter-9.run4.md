I'm working from your documents only, because the web searches were refused.

## Decision snapshot

**Yes, this is routine. A written offer that names the role and pay can ask for bank details, a PPS number and passport proof, and nothing in it asks for them before you accept. My status on accepting is `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R10 (Salary €38,000–€42,000), R11 (Hybrid, two days Limerick)
- `must_have` — direct: R1, R3, R4, R5 · unclear: R2 (Irish PAYE, PRSI and USC)
- `important` — direct: R6 · adjacent: R9 (240 staff, monthly cycle) · unclear: R8 (staff payroll queries) · absent: R7 (pension changes)

R2 — the must-have your material doesn't settle; R7 — a gap you've named, with a closure path.

**Opportunity ledger.** The employer can't be established from here because search was refused (RR1). Against that, in-person interviews, an offer from the firm's own email domain and pay inside the posted band all point the right way (RR2). The offer carries no contract terms yet (RR3).

- **Hard gates:** none failed; unconfirmed: R10 (Salary €38,000–€42,000), R11 (Hybrid, two days Limerick); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the written contract arrives and its terms are acceptable before you resign (RR3); (2) the employer checks out on its own website (RR1); (3) you confirm the pay and hybrid terms suit you (R10, R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` your ad and offer |
| Mandate | Monthly payroll for 240 staff, starters, leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` ad |
| Offer | Permanent, €40,000, hybrid with two office days, reporting to Declan Garvagh, Finance Manager, start after your notice | `[grounded]` offer email |
| Process | Two in-person interviews at their office | `[grounded]` your account |
| Onboarding asks | Bank details, PPS number and a passport scan through a portal after you accept; original passport on day one | `[grounded]` offer email |
| Market calibration | Not run. €40,000 sits inside the ad's own band, and no outside band was fetched | `[grounded]` ad band; no `[generic]` band used |
| Unknowns | Contract terms, pension scheme, probation, notice, leave, and how pension changes are handled | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff, stated by you. Nothing inspectable yet, so expect a probe | `[grounded]` your background | none |
| R2 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your certificate and hotel payroll are described without saying where or under which tax system. I won't assume either | `[grounded]` silence in your background | Question G1 |
| R3 | Strong Excel | must_have | direct | medium | none | Daily use, with pivot tables and XLOOKUP, by your account | `[grounded]` your background | none |
| R4 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024, stated by you | `[grounded]` your background | A certificate copy would raise this to `high` |
| R5 | Reconcile payroll to the general ledger monthly | must_have | direct | medium | none | You do the monthly reconciliation now | `[grounded]` your background | none |
| R6 | Process starters and leavers | important | direct | medium | none | Stated in your hotel role | `[grounded]` your background | none |
| R7 | Process pension changes | important | absent | none | capability | You haven't done these; your manager did. Closure path: ask for onboarding on the scheme in week one | `[grounded]` your statement | Plan row A3 |
| R8 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention handling queries | `[grounded]` silence in your background | Question G3 |
| R9 | Run payroll for 240 staff, monthly | important | adjacent | medium | transferability | You've run 90 staff on a fortnightly cycle. Limit: you haven't run a monthly cycle at about 2.7 times the headcount | `[inferred]` from your 90 staff against their 240 | none |
| R10 | Salary €38,000–€42,000 | hard_gate | unclear | none | hard_gate | The offer of €40,000 is inside the band. You haven't stated a floor, so I can't say whether it meets your need | `[grounded]` offer email; no constraint given | Question C1 |
| R11 | Hybrid, two office days in Limerick | hard_gate | unclear | none | hard_gate | The terms are clear. You haven't said whether the commute and days work for you | `[grounded]` offer email; no constraint given | Question C1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory payroll (R2, must_have) | discovery | Your certificate and hotel payroll don't say which tax system | A must-have, and the one that could change this from a good fit to a stretch | Filing Revenue submissions, applying PAYE tax credits and USC bands, PRSI classes, year-end returns | Certificate syllabus, a payslip format, a Revenue-facing task list | `[grounded]` silence; `[inferred]` that this is the most decision-relevant open row |
| G2 | Pension changes (R7, important) | capability | You've said you haven't done them | You'll be doing them alone, and your own manager handled them before | Processing pension deductions or contribution changes under instruction, even without owning the decision | An onboarding plan from Declan Garvagh | `[grounded]` your statement |
| G3 | Staff payroll queries (R8, important) | discovery | Nothing about dealing with staff directly | An everyday part of the role | Resolving payslip queries, explaining deductions, correcting errors | Examples you recall | `[grounded]` silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "a housing association in Limerick" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. Here the search was refused, so this says nothing against Marrowgate | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me to this role on your own careers page and confirm who I'd report to? | unresolved |
| RR2 | Offer matches the ad and your experience of the process | positive_signal | — | "€40,000 a year ... two days a week in our Limerick office" | Two in-person interviews, a role, pay and hybrid terms that match the ad, and an offer from marrowgatehousing.ie | `[grounded]` your account and the offer email | Who else sits in the finance team? | noted |
| RR3 | No contract terms in the offer | unknown | — | "starting on a date we agree once your notice period ends" | Probation, pension scheme, leave and notice may only arrive after you accept | `[generic]` pattern for offer emails | Can you send the draft contract, covering probation, notice, pension scheme and leave, before my five working days are up? | unresolved |

The onboarding asks (bank, PPS, passport) have no register entry, because they follow a written offer that names the role and pay.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask for the written contract and ask for the pension scheme details before you accept or hand in notice | see RR3 | `[grounded]` RR3 | pending your approval |
| A2 | Enter bank, PPS and passport details only in the portal at the address given on marrowgatehousing.ie. If a link arrives, check its domain matches the offer email's. Check by phone, using a number from their website, if unsure. Employers need the bank details to pay you, the PPS number for Revenue and the passport to check right to work, and none of it is needed before an offer | Practical check, not a doubt about the offer | `[generic]` standard onboarding practice | pending your approval |
| A3 | In week one, ask Declan Garvagh to walk you through a pension change | see R7 | `[grounded]` R7 | pending your approval |
| A4 | Reply within the five working days. If A1 isn't answered by then, ask for a short extension in writing | Offer's own deadline | `[grounded]` offer email | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Marrowgate Housing Limerick housing association" and "Marrowgate Housing careers Payroll Administrator Limerick" were refused. It would have fed role reality and RR1 |
| 2. Role-family sweep | unavailable | Search "payroll administrator salary Ireland Limerick 2026" was refused. It would have fed market calibration |
| 3. Hiring manager's public footprint | unavailable | No search was sent, because search was refused. Declan Garvagh is named, so a query was possible. It would have fed the scope read and the plan |

## Upgrade menu

- A link to Marrowgate's own careers page, or permission to search → RR1 closes and market calibration runs.
- A deeper research pass (up to 5 more searches and 2 more fetches), if you want it.
- The draft contract → RR3 closes.
- Your pay floor and commute limits → R10 and R11 resolve.
- Your certificate copy or syllabus → R4 goes up to `high`, and R2 likely resolves.

## Questions

G1 — Was your payroll and certificate work under the Irish tax system (PAYE, PRSI, USC, Revenue submissions)? What did you do on your own?

C1 (R10, R11) — Is €40,000 acceptable to you, and is the Limerick two-days-a-week commute workable?

G3 — Have you handled staff payroll queries yourself?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.