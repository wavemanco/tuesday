# Is this job legit? Remote Order Processing Coordinator

## Decision snapshot

**No, don't go ahead. RR1, RR2, RR3 and RR4 are each confirmed severe red flags. This request is very likely a scam, and I can't establish the firm from here, so pay and send nothing yet. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Pay of at least €30,000 a year)
- `must_have` — direct: R2, R3 · adjacent: R4 (Strong attention to detail)
- `important` — unclear: R5 (A quiet place to work)

R1 — "up to" sets a ceiling, not a rate; R4 — near the work, its limit named.

**Opportunity ledger.** These are the requests that decide it. The messages ask you to pay for equipment (RR1), lodge a cheque and pass most of it on (RR2), and hand over bank, tax and ID details before any offer (RR3). They also say the hiring runs wholly in chat (RR4). The employer is not established (RR5), the reply address shows no company domain (RR6), and the pay is open-ended (RR7). Your background and this role's requirements are a separate matter from these requests, and a strong fit cannot offset them.

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would have to differ for this to change:** the employer confirmed independently through its own website; the equipment payment, the cheque and the pre-offer ID and bank requests withdrawn; and a real interview held outside chat, followed by a written offer from the employer's own domain.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", as the posting names it. A search on the name returned no results, so the employer is not established | `[grounded]` posting; `[grounded]` search returned nothing |
| Mandate | Remote order processing, with training provided and no experience needed | `[grounded]` posting |
| Working pattern | Own hours, 15–30 a week | `[grounded]` posting |
| Pay as posted | "up to €26 an hour plus commission"; the commission terms are not stated | `[grounded]` posting |
| Annual pay at the posted ceiling | €26 × 15 hours × 52 weeks is about €20,280; at 30 hours about €40,560. Your €30,000 floor needs roughly 22 hours a week even if the top rate is paid and commission is ignored | `[inferred]` arithmetic from the posting's figures and your floor |
| Market calibration | A salaried Irish pay survey puts order-processing and customer-operations coordinators at a median base of €31,200 (interquartile range €28,400 to €34,100). That is a salaried band and leaves out commission-only and freelance work, so it is not comparable to an hourly part-time post and is not this employer's offer | `[generic]` Pennoral 2026 pay guide, found in the role-family search |
| Process | Hiring wholly on Telegram, with "no calls or video interviews" | `[grounded]` posting |
| Contradictions | The posting mentions no purchase, but the chat added a €349 equipment payment. The posting also says "full training provided" while the "work kit" is charged to you | `[grounded]` posting set against your messages |
| Unknowns | Who the employer is, who is messaging you, the guaranteed hourly rate, the contract type | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your non-negotiable), against "up to €26 an hour" and 15–30 hours a week | hard_gate | unclear | high | hard_gate | Confidence grades your own statement of the floor. Fit is unclear because "up to" is a ceiling and the hours are a range; the floor is reached only at about 22 hours or more a week at the top rate | `[grounded]` your floor and the posting's figures; `[inferred]` the annual arithmetic | Moot while RR1 to RR4 stand. If the employer is ever verified, get the guaranteed rate and hours in writing |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Stated in your message with nothing inspected, so medium: expect a probe | `[grounded]` your message | none |
| R3 | Good written English | must_have | direct | medium | none | About 60 Zendesk tickets a day is written work. Stated, not inspected | `[grounded]` your message | none |
| R4 | Strong attention to detail | must_have | adjacent | low | transferability | Tracker upkeep and high ticket volume are near the work. Limit: you gave no accuracy measure such as an error rate or QA score | `[grounded]` your message; `[inferred]` adjacency | A QA score or error rate, if you have one |
| R5 | A quiet place to work | important | unclear | none | discovery | Your message says nothing about it. It is a fact about your home, not about your experience | `[grounded]` your message is silent | none, your call |

## Gap recovery queue

No question is asked on these rows, because the decision is stable.

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R1, hard_gate) | hard_gate | The posting gives a ceiling and a range, and no guaranteed rate | The gate stays unsettled whatever else happens | None applies; this is a term of the role | A written contract naming the hourly rate and hours, from the employer's own domain | `[grounded]` posting wording |
| G2 | Attention to detail (R4, must_have) | transferability | Tracker and ticket work, with no accuracy figure | Matters for any coordinator role you apply to later | Error rates, QA scores, tracker audits | A QA summary or manager feedback | `[inferred]` from your described work |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | This request is very likely a scam. It asks you to pay before you have earned anything, and who sent it is unresolved | `[generic]` known pattern for requests of this kind; `[grounded]` the quote | Does your company ask new hires to pay for equipment, and can you confirm that in writing from an address on your own website? | confirmed |
| RR2 | Cheque to lodge, with most of it to be passed on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | This request is very likely a scam. A lodged cheque can show as available funds and be returned later, after your own money has gone out | `[generic]` known pattern; `[grounded]` the quote | See RR1 | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up." | Payroll details are routine after a credible written offer, not before an interview | `[generic]` normal onboarding order; `[grounded]` the quote | See RR1 | confirmed |
| RR4 | Hiring run wholly in chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | No verdict is drawn from this alone. It means the sender cannot be checked by seeing or hearing them | `[grounded]` posting | See RR1 | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one; `[grounded]` a search on the name returned nothing | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | Reply address shows no company domain | risk_signal | medium | "email velloway.hr@postmail.example" | The message may not come from who it names; this can't be checked from here | `[inferred]` from the address against the employer's name | Can you confirm this role and these messages from an address on your own website's domain? | unresolved |
| RR7 | Pay stated as a ceiling with undefined commission | unknown | — | "Earn up to €26 an hour plus commission on every order you process." | The guaranteed rate may sit well below €26, and commission may be small or conditional | `[inferred]` from "up to" and the undefined commission, set against the `[generic]` salaried band in role reality | What is the guaranteed hourly rate, and how is commission calculated? | unresolved |

Hold each of these until you have checked it with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send your IBAN, PPS number or passport photo, and don't pay the €349. If the cheque arrives, don't lodge it. I haven't used your IBAN and don't need it | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| A2 | Look for the employer independently, by searching your own way for a company website and its registration, and contact it only through details found there | see RR5, RR6 | `[generic]` ordinary verification practice | pending your approval |
| A3 | Report the Telegram chat and the posting to the platform and jobs site, so they can check it | see RR4 | `[generic]` platforms have report routes | pending your approval |
| A4 | If you shared other personal details in the chat, such as address or date of birth, watch your accounts for misuse. Tell me if you did and I'll fold it in | see RR3 | `[generic]` | pending your approval |
| A5 | Put your effort into other openings on employers' own careers pages. Your courier support work, Zendesk volume and Excel tracker fit order-processing and customer-operations roles | see R2, R3, R4 | `[inferred]` from your described background | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics"; no results and no page to read. Employer not established; this fed RR5 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator job salary Ireland", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). Market calibration in role reality and RR7 |
| 3. Hiring manager's public footprint | n/a | Only a chat handle was given, not a name, so there was no query to form |

I can save this assessment as a `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**

- The employer's own website address or registration details → RR5 and RR6 can close or harden.
- A written offer from the employer's own domain, with the hourly rate → R1 and RR7 settle.
- A hiring manager's real name → role reality's scope read.
- A deeper research pass on this employer (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.