I've run four searches so far. Now I'll fetch the employer's careers page to check that this posting is live and matches the advert.
**Yes, this one is worth applying for, on the conditions below. Status: `conditional_go`.**

## Decision snapshot

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R7a, R8 · adjacent: R5 (Care of housebound adults at home), R6 (Wound and leg-ulcer care) · unclear: R4 (Clear, timely written records), R7b (Continence care), R9 (End-of-life visits)
- `important` — adjacent: R10 (Own small caseload)
- `preferred` — absent: R11 (Doppler assessment)

R5, R6 — credible bridges, limits named; R10 — caseload untested, support promised; R4, R7b, R9 — CV silent, so questions rather than gaps; R11 — preferred, absent.

**Opportunity ledger.** The employer matches its own website (RR1), the pay sits among survey figures (RR2), and a named lead invites a chat (RR5). Whether the posting is live (RR1), what induction a first-time community nurse gets (RR3) and the rota (RR4) are open.

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the posting is confirmed on Calderbrook's own careers page (RR1); (2) supervised induction for someone new to a community caseload is confirmed in the chat (RR3, R10); (3) your answers show end-of-life, leg-ulcer and records experience, or they become named learning needs to raise openly (R9, R6, R4); (4) your registration and licence check out as stated (R1, R2).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff in four locality hubs | `[grounded]` the employer's About page, fetched |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin and care planning, on an electronic patient record | `[grounded]` advert |
| Caseload and support | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Pay and travel | £31,050–£37,800 plus mileage; pool cars provided | `[grounded]` advert |
| Market calibration | A 2026 England-wide survey of community staff nurses at Band 5 (n=1,240) gives a median of £34,300 and a middle half of £32,400–£36,600. The advert's range brackets that median and runs above the middle half at the top. This is the market, never this employer's offer. | `[generic]` Wardround 2026 pay guide; `[inferred]` the bracketing comparison |
| Scope read | An ordinary Band 5 community post with named support, not a stretched one | `[inferred]` from the duties list against the stated supervision |
| Hiring lead | Rhiannon Mabbott is listed as Team Lead of the Halifax district nursing team at Calderbrook, after eleven years as a district nurse. In 2025 she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` forum speaker page, seen as a search result and not fetched |
| Unknowns | Hours and rota, induction length, caseload size, where new starters sit on the range | — |
| Contradictions | None between the advert and the About page. The careers address I tried returned no page, so the posting itself is not yet seen on the employer's site. | `[grounded]` pages as fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | CV states active registration, revalidation due March 2028. Stated, not checked; the check is your own NMC register entry | `[grounded]` CV | Look at your own register entry |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | CV states a full UK licence, category B. Stated, not checked; your driving record is the check | `[grounded]` CV and advert | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. CV only, not yet probed | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV is silent on documentation and electronic records, so no claim is made | `[grounded]` CV silence | G3 |
| R5 | Care of housebound adults in their own homes | must_have | adjacent | medium | transferability | 18 months seconded to a discharge-to-assess team, visiting patients at home in their first week after discharge. Limit: short post-discharge episodes, not ongoing care of long-term housebound patients | `[grounded]` CV; `[inferred]` the limit, from "first week after discharge" | Bridge case, G5 |
| R6 | Wound and leg-ulcer care | must_have | adjacent | medium | transferability | Wound care including pressure ulcers and surgical wounds. Leg-ulcer care is not stated | `[grounded]` CV | G2 |
| R7a | Catheter care | must_have | direct | medium | none | CV states catheter care without detail; expect a probe | `[grounded]` CV | none |
| R7b | Continence care | must_have | unclear | low | discovery | CV mentions catheters only, nothing wider on continence | `[grounded]` CV silence | G4 |
| R8 | Insulin administration | must_have | direct | medium | none | CV states insulin administration. Care planning around it is not stated | `[grounded]` CV | none |
| R9 | End-of-life visits | must_have | unclear | low | discovery | CV is silent. An acute medical ward may have included this, but nothing is stated, so no claim is made | `[grounded]` CV silence | G1 |
| R10 | A small caseload of your own, supported by a senior community nurse | important | adjacent | low | transferability | You have not held a caseload. Home visits on the discharge team are adjacent. Limit: not owning a list of patients over time | `[grounded]` your statement and CV | G5 |
| R11 | Doppler assessment for leg ulcers (desirable) | preferred | absent | none | capability | You have not done one. The team lead has spoken on Doppler training for staff new to community work, which hints at a training route, but whether this employer provides it is unconfirmed | `[grounded]` your statement; `[inferred]` training route | Ask in the chat (RR3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | End-of-life visits (R9, must_have) | discovery | CV silent on palliative or end-of-life care | A must-have duty that could move the decision from conditional to plain `go` | Caring for dying patients on the ward; family conversations; anticipatory medication or symptom control you gave or escalated; discharge-home-to-die arrangements | A competency sign-off, a reference, or a service description | `[grounded]` CV silence; `[inferred]` that an answer could upgrade the status |
| G2 | Leg-ulcer care (R6, must_have) | transferability | Pressure-ulcer and surgical wound care stated; leg ulcers and compression are not | Leg-ulcer care is named in the duties, and the team lead has spoken on leg-ulcer clinics | Dressing venous leg ulcers on the ward; applying or reviewing compression; tissue-viability referrals | A wound-care competency record or training certificate | `[grounded]` advert and CV; `[inferred]` the weight, from the lead's talk |
| G3 | Written records (R4, must_have) | discovery | No mention of record systems or documentation habits | The advert lists clear, timely records as essential | Documenting on an electronic record during or straight after a visit; audited notes; handover documentation | A reference mentioning your records, or an audit result | `[grounded]` CV silence |
| G4 | Continence care (R7b, must_have) | discovery | Catheters stated; nothing on wider continence | Named beside catheter care in the duties | Bladder and bowel care plans; containment products; catheter troubleshooting | A competency record | `[grounded]` CV silence |
| G5 | Own caseload (R10, important) | transferability | Home visiting is evidenced; owning a list is not | The role gives you a caseload from the start, with named support | Planning your own visit list on the discharge team; follow-up decisions you made | A line from your senior on the discharge team | `[grounded]` CV and your statement |

The gap queue holds no questions. Three are asked at the end: G1, G2, G3. G4 and G5 wait on your answers or the chat.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not yet seen on the employer's own careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The employer is real, but the advert may sit on a careers page I could not reach, or it may be stale | `[grounded]` the About page says vacancies are on a careers page; `[inferred]` the rest, from one address returning no page | Can you point me to this role on your own careers page? | unresolved |
| RR2 | Pay among survey figures | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range brackets the survey median, so a pay mismatch is unlikely; your own floor is unknown | `[grounded]` advert; `[generic]` England-wide survey, not this employer | Where on the range would a nurse new to community work start? | noted |
| RR3 | Induction for a first-time community nurse is unstated | unknown | — | "You will hold a small caseload of your own, supported by a senior community nurse." | Support may be informal, and the date you take a full caseload may not be set | `[grounded]` advert wording; `[inferred]` from its silence on induction against your history | What supervised visits, competency sign-off and Doppler training does a new community nurse get, and when do they take their own caseload? | unresolved |
| RR4 | Hours and rota unstated | unknown | — | "end-of-life visits" | Weekend, evening or lone-working duties may apply, and the advert doesn't say | `[generic]` pattern: district nursing often runs beyond weekday daytime | What are the hours, the weekend and bank-holiday rota, and the lone-working arrangements for this post? | unresolved |
| RR5 | Named lead invites an informal chat | positive_signal | — | "contact Rhiannon Mabbott, Community Nursing Team Lead" | A reachable, experienced lead is a good place to settle RR3 and RR4 | `[grounded]` advert; `[grounded]` forum speaker page | What does a good first three months look like for a new community nurse on your team? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the role on Calderbrook's own website and apply there | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Take up the informal chat, reaching Rhiannon Mabbott through contact details on Calderbrook's own site or the advert, and ask the RR3 and RR4 questions | The advert invites it, and both questions affect the decision | `[grounded]` advert, RR3, RR4 | pending your approval |
| A3 | In the chat and application, say plainly what you told me: you have not held your own caseload and have not done a Doppler assessment. Then ask what supervision and training come with the post | Matches your own words and invites the answer to RR3 | `[grounded]` your statement | pending your approval |

CV edits, `resume_edits_pending_approval`. Each is a reorder of your own words; none adds a claim:

| # | Edit | Source | Status |
|---|---|---|---|
| E1 | Move "seconded to its discharge-to-assess team, visiting patients at home in their first week after discharge" to the top of your experience, wording unchanged | CV | `resume_edits_pending_approval` |
| E2 | Put wound care (pressure ulcers and surgical wounds), catheter care and insulin administration directly beneath it, wording unchanged. Leg ulcers are not added | CV | `resume_edits_pending_approval` |
| E3 | State "Full UK driving licence, category B" in your opening lines | CV | `resume_edits_pending_approval` |

Nothing in this plan or the edit table is applied until you approve it. The approval covers the A-rows and the E-rows alike.

## Evidence status

Verified: none yet. You included your National Insurance number; it isn't needed here, and I haven't used or repeated it.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Community Staff Nurse Band 5 district nursing Calderbrook Community Health CIC Halifax vacancy"; fetched "About Calderbrook Community Health" (calderbrookhealth.example/about) and tried calderbrookhealth.example/careers, which returned no page. Role reality: the organization row (the employer exists as described) and RR1 (the posting is not yet seen live) |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing Calderdale salary Agenda for Change 2026 pay scale", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Role reality: the market calibration row, and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott), read as a search result. Role reality: the hiring lead row, and RR3, RR5 |

If you'd like, I can save all this as a `tuesday-dossier.md` to carry forward.

**Upgrade menu**

- The link to this role on Calderbrook's own careers page → RR1 closes.
- Your answers to G1, G2 and G3 → R9, R6 and R4 move off `unclear` or `adjacent`, and the status may become a plain `go`.
- Your pay floor, hours and travel limits → the hard-gates line can be checked against them.
- Rhiannon Mabbott's answers on induction, rota and starting point on the range → RR3, RR4 and RR2 close.
- Inspectable proof for your clinical rows → a wound-care or tissue-viability competency sign-off, a leg-ulcer training certificate, or a reference from your discharge-team lead would raise R6, R7a and R8 toward `high`. Your NMC register entry is yours to check for R1.
- A deeper pass on Calderbrook (staffing and leadership changes, recent news; up to 5 more searches and 2 more fetches) → say the word and it runs.

G1 — Have you personally cared for patients at the end of life, on the ward or on discharge-team visits? What was your part, and what happened?
G2 — Have you dressed or managed leg ulcers, including compression bandaging, on the ward or at home visits? What did you own?
G3 — How did you record your ward and home-visit care: which electronic system, written during or after the visit, and did anyone audit your notes?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.