I've run four searches and got hits on the company, the live posting, the salary band and Ronan. Now I'm fetching the careers page and the about page to check them against what you were given.
# Job Underwriting: Product Designer at Fernquay

## Decision snapshot

**Yes, it looks worth pursuing. The checks I could run support Fernquay as a real small employer (RR5). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6
- `important`: adjacent: R7 (Own the booking flow end to end), R8 (Research calls with school owners), R9 (You would be our first designer)

R9, never the sole designer, its limit named; R8, customer sessions rather than operator sessions; R7 (`medium`), checkout confirmed, wider flow ownership open; R2, waiting on your pay floor.

**Opportunity ledger.** Transparent so far: the pay range sits inside the survey band (RR3) and the posting matches the company's own pages (RR5). Still open are the support a first designer gets (RR1), the equity terms (RR2) and the runway of a customer-funded company (RR4).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor sits at or below the range, which closes R2; (2) RR1 is answered concretely on the call; (3) the equity percentage, vesting and cliff arrive in writing, which closes RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It has six people in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is funded by its customers | `[grounded]` About page, fetched |
| Mandate | Own the booking flow end to end, run research calls with school owners, and ship alongside two engineers | `[grounded]` your pasted posting; the careers page confirms "first design hire" |
| Working pattern and pay | Hybrid, two days a week in Galway, €52,000–€60,000 plus equity. The careers page says "plus equity" and gives no percentage | `[grounded]` posting and careers page, fetched |
| Market calibration | Ireland-wide, product designers with 3 to 5 years have a median base of €57,000 (interquartile range €51,500 to €62,000, n=520). The range falls inside that band. The survey doesn't cover Galway or start-ups specifically, so this is what to expect and not Fernquay's offer | `[generic]` Tillerby 2026 Ireland Design Salary Report |
| Hiring manager | Ronan Kehoe is co-founder and CEO of Fernquay. Before that he was product lead at a Galway travel-software company for five years | `[grounded]` search result for his public profile (snippet only, page not opened) |
| Scope read | A sole-designer remit with a short list of named duties, ordinary for a first design hire at a six-person company | `[inferred]` from the posting's "first designer" and its three stated duties |
| Unknowns | Who sets design priorities, the equity terms, the company's runway, and Saoirse's title (your message calls her CTO, and the About page names her as a founder without a title) | `[grounded]` About page and posting silent on these |
| Contradictions | None on role, location or pay between the posting and the careers page. The 0.5–1% equity figure is in your posting and not in the careers page text I fetched | `[grounded]` both pages fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You live in Galway, so the location term is met. You stated no office-days constraint, which is why this is not `high` | `[grounded]` your statement that you moved back to Galway last year | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You haven't stated a pay floor, so I can't say whether the range clears it | `[grounded]` posting figure; your floor not given | G4's question |
| R3 | 3+ years of product design | must_have | direct | medium | none | You describe 4 years as a product designer. Years of experience is a requirement, not a gate. It is self-reported with nothing inspected | `[grounded]` your background summary | none |
| R4 | Strong Figma | must_have | direct | medium | none | You say you use Figma daily. Ronan's message says they liked your checkout case study, which suggests they have seen your work, but I haven't | `[grounded]` your summary and Ronan's message | offer the case study or a Figma file to raise it to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You describe monthly usability sessions with customers. That is confirmed and specific, with no inspectable artifact yet | `[grounded]` your summary | a sanitized research readout would raise it |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You describe working in a squad with four engineers | `[grounded]` your summary | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | discovery | You redesigned a travel company's checkout flow, which is one part of a booking flow. Whether you owned more of it isn't stated | `[grounded]` your summary; `[inferred]` that checkout is one stage of a booking flow | G2 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with customers of a travel-booking company. The posting's calls are with business owners running schools. The bridge is usability research. The limit is that it didn't cover operator-side needs | `[grounded]` your summary; `[inferred]` that school owners are operators and not end customers | G3 |
| R9 | You would be our first designer | important | adjacent | medium | transferability | You have always worked in a squad and never as the only designer. The bridge is shipping with engineers. The limit is that you haven't set up design process or priorities without peers | `[grounded]` your statement | G1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Working as the only designer (R9, important) | transferability | Squad work with four engineers. Nothing on setting design process or priorities without design peers | This is the plainest difference between your history and the role, so it is the part most likely to be probed | Building a shared Figma library others used; covering design for a launch alone; running research without a researcher; making a product call when no design lead was available | A Figma library, a research readout, or a decision note | `[grounded]` your statement of never being the only designer; `[generic]` that first-designer roles are probed on this |
| G2 | Ownership beyond checkout (R7, important) | discovery | The checkout redesign is confirmed, and ownership of anything wider is not | The posting says "end to end" | Shaping search or availability, confirmations, changes and cancellations, or a back-office view, and what you owned in each | The checkout case study with before and after numbers | `[grounded]` the summary names checkout only |
| G3 | Research with business owners (R8, important) | transferability | Customer usability sessions. No evidence of sessions with operators or other business users | The posting names school-owner calls as a duty | Sessions with partner suppliers or tour operators, hotel or ops staff using a booking back office, or support staff who relay operator problems | A sanitized interview guide or synthesis | `[grounded]` your summary; `[inferred]` that operator research differs from consumer research |
| G4 | Pay floor (R2, hard_gate) | hard_gate | The range is known and your floor is not | It decides whether the gate is met | Not applicable | Not applicable | `[grounded]` posting figure; your floor not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Support and decision rights for a first designer not described | unknown | — | "You would be our first designer: own the booking flow end to end" | With no other designer, you may carry the whole flow without a design lead to review the work, and priorities may sit with the founders | `[inferred]` from "first designer" and "work most closely with our co-founder" against the posting's silence on who sets priorities | Who decides what design works on first, and what happens when design and engineering disagree on scope? | unresolved |
| RR2 | Equity terms beyond the percentage | unknown | — | "0.5–1% equity" | The percentage alone doesn't show vesting, cliff, share class or value. The careers page says "plus equity" with no figure | `[grounded]` careers page has no percentage; `[generic]` that a percentage leaves these terms open | Will the percentage, vesting schedule and cliff be in the offer letter? | unresolved |
| RR3 | Pay range inside the survey band | positive_signal | — | "€52,000–€60,000" | The posting states its pay and the range falls inside the Ireland-wide band. Galway and start-up pay are not covered | `[generic]` Tillerby survey band; `[grounded]` posting | Where in the range would my experience place me? | noted |
| RR4 | Runway of a customer-funded company | unknown | — | "funded by its customers" (About page) | With no outside investor, runway follows customer revenue, and the number of paying schools isn't published | `[grounded]` About page says customer-funded; `[generic]` that a six-person firm's runway tracks its revenue | How many schools pay for Kelproster today, and how many months of costs does the company hold? | unresolved |
| RR5 | Posting matches the company's own pages and asks for real work | positive_signal | — | "we would rather see one messy real project than a polished deck" | Role, place, pay and "first design hire" appear on both the posting and the careers page, and the application address is on the company's own domain | `[grounded]` careers page fetched | What does the process look like after this call, and who would I meet? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Take the call. Before it, check that the calendar invite came by email from a fernquay.example address, the domain the careers page uses for jobs@fernquay.example. Confirming the time by email as well as WhatsApp is a simple extra step | Scheduling a video call over WhatsApp is routine at a team this small, so this is housekeeping and not a concern | `[generic]` for the routine point; `[grounded]` careers page for the domain | pending your approval |
| P2 | Lead with the checkout redesign and the monthly usability sessions (R7, R5). Say plainly what was yours and what was the squad's | These are the two things you told me, and Ronan has already seen the case study | `[grounded]` your summary and Ronan's message | pending your approval |
| P3 | Be direct that you have not been the only designer (R9). Bring a view of how you would run your first weeks, framed as a plan and not as something you have done | Honest framing reads stronger in an interview than a claim that gets tested | `[grounded]` your statement; `[generic]` on how interviews probe | pending your approval |
| P4 | Ask the questions in RR1, RR2 and RR4 on the call, word for word | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P5 | If an offer comes, ask for the equity percentage, vesting and cliff in writing (RR2), and ask where in the range you'd sit (RR3) | The posting and the careers page differ on whether a percentage is given | `[grounded]` RR2, RR3 | pending your approval |

## Evidence status

Verified: none yet. Stage, read from Ronan's message: you have applied and a first call is pending.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | I searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer Galway careers". I fetched "About Fernquay" (fernquay.example/about) and "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Both match the posting, so role reality's organization and contradictions rows are filled and no employer-not-established entry was needed |
| 2. Role-family sweep | yes | I searched "product designer salary Ireland Galway startup 3+ years", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). It supplied the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | I searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). I read the snippet only. It supplied the hiring-manager row |

If you'd like, I can save this as `tuesday-dossier.md` so it carries forward.

**Upgrade menu**

- Your checkout case study or a Figma file with the before and after numbers would move R4 and R7 toward `high`.
- Your pay floor closes R2.
- Ronan and Saoirse's answers on RR1, RR2 and RR4 close the conditions for go.
- A deeper research pass on Fernquay covers customer and company reports and recent news. It would use up to 5 more searches and 2 more fetches, and runs if you say the word.
- Interview prep for the 45-minute call is a separate job (mock-interview) that I can do next.

G4 — What is the lowest base salary you would accept for this role?
G1 — Is there a time you made design decisions with no other designer to check them, and what did you decide and own?
G3 — Have you spoken to business users, such as operators, partners or ops staff, and not only end customers, and what came out of it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.