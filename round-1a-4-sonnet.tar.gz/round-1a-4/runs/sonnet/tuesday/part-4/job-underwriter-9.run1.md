Web search was refused, so this runs only on what you pasted.

## Decision snapshot

**Yes, this is normal. Payroll details, PPS number and passport scan, asked for after a written offer that names the role and pay, are routine onboarding, and nothing in the decision rests on them. Status: `conditional_go`. The conditions are R1, R2, R4, R10, RR1 and RR3, below.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Two days a week in the Limerick office), R2 (Salary €38,000–€42,000)
- `must_have` — direct: R3, R5, R6, R8 · adjacent: R7 (Run monthly payroll for 240 staff) · unclear: R4 (Irish PAYE, PRSI and USC)
- `important` — direct: R9 · absent: R10 (Process pension changes)

R7 — a credible bridge, its limit named; R4 (`low`) — the hotel group's tax jurisdiction isn't stated; R10 — a real gap, with a closure path.

**Opportunity ledger.** A specific written offer with pay stated and a named reporting line (RR2), reached after two in-person interviews (RR4). One standing entry is that I couldn't check the employer's own site (RR1). One unknown is how pension changes are handed over to you (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Two days a week in the Limerick office), R2 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Limerick office days and €40,000 suit you (R1, R2); (2) your hotel payroll was run under Irish PAYE, PRSI and USC (R4); (3) a pension-change handover or training is agreed (R10, RR3); (4) you check the employer's website yourself (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` your posting and offer; not checked against its own site |
| Mandate | Monthly payroll for 240 staff, starters, leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` posting |
| Pay and terms | €40,000, permanent, inside the advertised €38,000–€42,000; hybrid, two days in Limerick; reporting to Declan Garvagh, Finance Manager | `[grounded]` offer and posting agree |
| Onboarding requests | Bank details, PPS number and a passport scan through a portal after you accept, and the original passport on day one | `[grounded]` offer text |
| Why these requests are routine | Salary needs bank details, and Revenue reporting needs a PPS number. Employers commonly check identity and right to work from a passport. The "never hand these over" rule is about requests before any offer, or from a sender you can't place. | `[generic]` |
| Scope read | The post is the same kind of work you've done, at more than double the headcount you ran | `[inferred]` from your 90 staff against the 240 |
| Market calibration | Not done; the role-family search was refused | — |
| Unknowns | Start date, pension scheme and handover, portal address, contract wording | `[grounded]` offer is silent on each |
| Contradictions | None between the ad and the offer on title, pay band, hybrid pattern or location | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | Posting and offer agree on the term. You haven't stated a constraint, so confidence is `none` | `[grounded]` posting and offer; no constraint given | G4 |
| R2 | Salary €38,000–€42,000 (offer €40,000) | hard_gate | unclear | none | hard_gate | The offer sits inside the band. Your pay floor hasn't been stated | `[grounded]` posting and offer; no constraint given | G4 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | You describe 3 years of fortnightly payroll for 90 staff. Confirmed and specific, but nothing inspected | `[grounded]` your account | An employer reference would raise it to `high` |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You haven't said which country's tax rules the hotel group payroll used. The certificate's content isn't stated either | `[grounded]` your silence on jurisdiction | G1 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables, XLOOKUP. No workbook inspected | `[grounded]` your account | A sanitized workbook would raise it to `high` |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. Certificate not inspected | `[grounded]` your account | A copy of the certificate would raise it to `high` |
| R7 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | You ran fortnightly payroll for 90 staff. Limit: you haven't run a monthly cycle end to end, nor at this headcount | `[grounded]` your account | G2 |
| R8 | Reconcile payroll to the general ledger each month | must_have | direct | medium | none | You did the monthly payroll-to-ledger reconciliation at the hotel group | `[grounded]` your account | A sanitized reconciliation would raise it to `high` |
| R9 | Process starters and leavers | important | direct | medium | none | Stated as part of your hotel group role | `[grounded]` your account | none |
| R10 | Process pension changes | important | absent | none | capability | You've said you have not done pension changes and your manager did them. No adjacent work stated | `[grounded]` your account | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish PAYE, PRSI and USC (R4, must_have) | discovery | Payroll Technician certificate and 3 years of payroll, with no mention of which tax system | A must-have, and these three are Irish-specific rules | Applying tax credits and cut-offs from Revenue notifications; handling PRSI classes and USC rates; filing payroll returns to Revenue | The certificate's module list, or a sanitized payslip layout | `[grounded]` your account is silent on jurisdiction; `[generic]` that these rules are Irish-specific |
| G2 | Monthly cycle at 240 staff (R7, must_have) | transferability | Fortnightly payroll for 90 staff, plus the monthly reconciliation | The post's main duty is at a different frequency and size | Month-end closes you ran; any monthly-paid group, such as salaried managers | A sanitized reconciliation workbook | `[grounded]` your account |
| G3 | Pension changes (R10, important) | capability | Never done; your manager handled them | A named duty with no evidence behind it. Closure path: ask for the handover in RR3, and learn the scheme's rules before or during your first weeks | Any pension paperwork you prepared or checked, even where your manager made the change | None needed | `[grounded]` your account |
| G4 | Gates (R1, R2, hard_gate) | hard_gate | Terms stated by the employer; yours not stated | A gate is met, unconfirmed or failed, and this one is unconfirmed | n/a | None needed | `[grounded]` no constraint given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | I couldn't check it because search was refused. Possible reasons for any unconfirmed employer are a small footprint, a stale posting, or a firm that isn't hiring as described | `[generic]` pattern for employers of this kind, not a claim about this one | Can you confirm the address of the onboarding portal and that it is linked from your own website? | unresolved |
| RR2 | Pay and terms stated clearly | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year" | Terms are specific and match the ad | `[grounded]` offer and ad | Is the contract available in writing before I give notice? | noted |
| RR3 | Pension-change duty with no stated handover | unknown | — | "process starters, leavers and pension changes" | You may be expected to do this from day one with no one to learn it from | `[inferred]` from the duty list against your stated gap | How are pension changes handled today, and what handover or training will I have? | unresolved |
| RR4 | Process followed a normal pattern | positive_signal | — | "two interviews in person at their office" | Two in-person interviews and a written offer from the employer's own domain suggest a real hiring process | `[grounded]` your account | Who else will I be working with day to day? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Type Marrowgate's website address into your browser yourself, check the portal link is on that site, and enter your details only there. Don't send them by email or reply | see RR1 | `[generic]` standard onboarding hygiene | pending your approval |
| A2 | Bring the original passport on day one as asked | see R1, offer text | `[grounded]` offer | pending your approval |
| A3 | Ask for the written contract before you give notice at your current job | see RR2 | `[generic]` common practice when changing jobs | pending your approval |
| A4 | Ask Declan Garvagh the RR3 question before or just after accepting, and say plainly that you haven't done pension changes | see R10, RR3 | `[grounded]` your account | pending your approval |
| A5 | Reply to accept within the five working days the offer gives | see offer | `[grounded]` offer | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Marrowgate Housing Limerick housing association"; refused. It would have confirmed the employer in role reality and could have cleared RR1 |
| 2. Role-family sweep | unavailable | Searched "payroll administrator Ireland salary €38,000 €42,000 PAYE PRSI USC"; refused. It would have given the market calibration line |
| 3. Hiring manager's public footprint | unavailable | Searched "Declan Garvagh Finance Manager Marrowgate Housing"; refused. It would have informed role reality's scope read |

I can write this up as a `tuesday-dossier.md` if you want one to keep.

**Upgrade menu**

- Permission to run web search → RR1 can close, and role reality gets a market calibration.
- A sanitized reconciliation workbook, your certificate, or an employer reference → R3, R5, R6 and R8 move to `high`.
- Your hotel group's payroll jurisdiction → R4 resolves.
- Your answer on the office days and pay → R1 and R2 move to met or failed.

**Questions**

G1 — Was the hotel group's payroll run under Irish PAYE, PRSI and USC, and did you apply those rules yourself?

G4 — Do the two Limerick office days a week and €40,000 both suit you?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.