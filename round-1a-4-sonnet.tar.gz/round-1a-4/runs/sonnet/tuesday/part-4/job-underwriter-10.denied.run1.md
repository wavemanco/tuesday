The web searches were declined, so I'm working only from what you pasted.

## Decision snapshot

**Yes, it's worth a call, but I can't confirm the company is real from here. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R6 (Two days a week at the Galway office), R7 (Salary €52,000–€60,000)
- `must_have`: direct: R1, R2, R3, R4
- `important`: adjacent: R5 (Own the booking flow as first designer)

R3 (`medium`): usability sessions are confirmed, calls with school owners are not; R5: a credible bridge, its limit named.

**Opportunity ledger.** The posting is concrete: it gives a pay band, equity and named people (RR4). The employer is unverified (RR1), the first-designer remit has no stated support (RR2), and the equity terms are open (RR3, RR5). Nothing in the posting or the WhatsApp message asks you for money, bank details or ID.

- **Hard gates:** none failed; unconfirmed: R6 (Two days a week at the Galway office), R7 (Salary €52,000–€60,000); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer verifies, per RR1; (2) your pay floor and office-day limits fit R6 and R7; (3) the sole-designer step is framed honestly as a bridge, never as experience you don't have (R5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting |
| Mandate | First designer; own the booking flow end to end, run research calls with school owners, ship with two engineers | `[grounded]` posting |
| Reporting line | Works most closely with co-founder Ronan Kehoe | `[grounded]` posting |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity; no vesting, strike price or valuation given | `[grounded]` posting |
| Working pattern | Hybrid, two office days in Galway | `[grounded]` posting |
| Scope read | The role mixes a design lead's autonomy with a mid-level title and requirement of 3+ years | `[inferred]` from "first designer" and "own end to end" against "3+ years" |
| Market calibration | Not run: the salary search was refused, so the band is not set against role-family norms | `[generic]` no sweep, nothing asserted |
| Unknowns | Funding and runway; decision rights over the flow; equity terms; whether anyone senior reviews design | — |
| Contradictions | None between the posting and the message. The company's own site was not checked | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | You describe 4 years as a product designer in Dublin; self-reported, nothing inspected yet | `[grounded]` your background | none |
| R2 | Strong Figma | must_have | direct | medium | none | "Figma daily" is specific and confirmed, but no file or portfolio has been inspected | `[grounded]` your background | Have the checkout case study ready to share |
| R3 | Has run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. That is research you ran yourself; the posting's calls with school owners are discovery interviews, a related but different format | `[grounded]` your background; `[inferred]` that the formats differ | Be ready to say what you changed because of a session |
| R4 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers; the posting has two | `[grounded]` your background | none |
| R5 | Own the booking flow end to end as the first designer | important | adjacent | medium | transferability | You redesigned a travel-booking checkout, which is close in domain. The limit is that you have never been the only designer, so setting direction and process with no peer review is untested | `[grounded]` your background; `[inferred]` from your statement that you were never the only designer | See G1 |
| R6 | Two days a week at the Galway office | hard_gate | unclear | none | hard_gate | You live in Galway, but you haven't stated whether two fixed office days work for you. Confidence grades your own stated constraint, and none was given | `[grounded]` posting; no constraint stated | See G2 |
| R7 | Salary €52,000–€60,000 plus equity | hard_gate | unclear | none | hard_gate | The posting states the band, but your pay floor is unstated, so this can't be checked | `[grounded]` posting; no constraint stated | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Sole-designer ownership (R5, important) | transferability | A checkout redesign in a squad, but no stated stretch of working without a design peer or lead | This is the likeliest objection to your candidacy, and it decides how to position R5 | Owning a flow end to end while the design lead was away; setting up a design-QA habit with engineers; a project where you were the design voice for a whole release | The checkout case study, with a note on which decisions were yours | `[inferred]` bridge from the checkout work; `[generic]` that first-designer roles probe this |
| G2 | Office-days fit (R6) | hard_gate | Galway-based, but your limits on office days are not stated | A failed or unconfirmed gate caps the decision whatever your fit | Fixed days vs. flexible days; commute; caring or other commitments | Your own statement | `[grounded]` posting term; your limits unstated |
| G3 | Pay floor against the band (R7) | hard_gate | The band is stated, but your floor is not | A band below your floor would end the application, however good the fit | Your current salary and the minimum you would accept | Your own statement | `[grounded]` posting band; your floor unstated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer; none of these is ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one; you report finding little online | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Responsibility without stated support | unknown | — | "You would be our first designer: own the booking flow end to end" | The role may carry accountability for the flow without decision rights, a design mentor or research budget | `[inferred]` from the posting's scope language against its silence on authority | Which product decisions does the designer make alone, and who reviews design work? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "0.5–1% equity" | The grant may be small or heavily conditioned, and its value depends on terms not given | `[inferred]` from the missing vesting, strike price and valuation | What are the vesting schedule, strike price and latest valuation or share count for this grant? | unresolved |
| RR4 | Concrete pay band, named people and a realistic work-sample ask | positive_signal | — | "Salary €52,000–€60,000" and "we would rather see one messy real project than a polished deck" | The posting is transparent about pay and does not ask for large unpaid work | `[grounded]` posting | What would a first-quarter success look like for the person in this role? | noted |
| RR5 | Funding and runway not stated | unknown | — | "We are small and informal" | A six-person company paying this salary may or may not have funding to cover it | `[inferred]` from the posting's silence on funding | How long is the current runway, and how is the team funded? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Treat the WhatsApp message as ordinary scheduling. Before the call, find the company's own website and check that the emailed invite comes from an address on that domain. If it doesn't, ask for the invite from a company address | RR1; scheduling by chat for a call held elsewhere is routine, and the check is advice | `[grounded]` your message and the register | pending your approval |
| A2 | Ask the RR1, RR2, RR3 and RR5 questions verbatim on the call, and ask them of the employer, not of the person who messaged you | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| E1 | Lead the checkout case study with the decisions that were yours, and say plainly where the squad shared them | R5, G1 | `[grounded]` your background | pending your approval |
| A3 | Don't describe the role as one you have already done. Say you have owned a flow inside a squad and are ready to own it without one | Keeps the bridge honest (R5) | `[grounded]` your statement that you were never the only designer | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | I searched "Fernquay booking software sea kayak surf schools Galway", and the call was refused. It would have fed role reality's organization row and RR1 |
| 2. Role-family sweep | unavailable | I searched "product designer salary Galway Ireland 2026 startup", and the call was refused. It would have fed the market calibration row and the check on R7 |
| 3. Hiring manager's public footprint | unavailable | I searched "Ronan Kehoe Fernquay co-founder", and the call was refused. It would have fed the scope read and which story you lead with |

## Dossier offer

If you'd like, I can save this as a `tuesday-dossier.md` to carry into later steps.

## Upgrade menu

- Your pay floor and office-day limits would settle R6 and R7, and the status could move to `go` or `no_go`.
- Allowing the three searches, or pasting the company's site and careers text, would settle RR1 and calibrate the band for R7. You can also paste Ronan's public profile text.
- A link to the checkout case study would raise R2 and R5 toward `high`.
- The employer's answers on equity terms and runway would close RR3 and RR5.
- Preparing for the call with Ronan and Saoirse is mock-interview's job, which I can run if you want it.

## Questions

G2, G3: What is your minimum acceptable salary, and are two fixed office days a week workable for you?

G1: Have you ever owned a design decision from start to finish with no other designer reviewing it? What did you decide, and how did you know it worked?

RR1: Does the calendar invite come from an address on a company domain with its own website, and does a live posting for this role exist on that site?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.