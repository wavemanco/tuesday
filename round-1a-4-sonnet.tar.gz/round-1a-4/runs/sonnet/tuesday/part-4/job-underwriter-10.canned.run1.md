I've confirmed Fernquay exists and checked pay and Ronan's background. Next I'll fetch their own site to see whether the posting is listed there.
# Job Underwriting: Product Designer at Fernquay

## Decision snapshot

**Yes, it's worth continuing, and the WhatsApp scheduling is a routine step. Nothing in the posting or the message asks anything of you beyond a video call. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6
- `important` — adjacent: R7 (Own the booking flow end to end), R8 (Be the first designer)

R7 — a credible bridge, its limit named; R8 — adjacent, its limit named; R2 — waiting on your pay floor.

**Opportunity ledger.** Fernquay is attributable and the posting's terms are specific (RR4, RR5). The open items are where the role is advertised (RR1), the equity terms (RR2) and who supports a first designer (RR3).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay range clears your floor (R2); (2) the role is confirmed through Fernquay's own channels (RR1); (3) equity terms and first-designer support get concrete answers (RR2, RR3); (4) your case for R7 and R8 is framed as adjacent, never as sole ownership.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. It has six people, is based in Galway, was founded in 2023 by Ronan Kehoe and Saoirse Doyle, and is funded by its customers | `[grounded]` fernquay.example/about |
| Mandate | First designer. Own the booking flow end to end, run research calls with school owners, and ship alongside two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week at the Galway office | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity. The equity terms are not stated | `[grounded]` posting |
| Hiring manager | Ronan Kehoe, co-founder and CEO. A public profile lists five years as product lead at a Galway travel-software company before Fernquay | `[grounded]` profile search result |
| Scope read | Design, research and shipping in one seat, with no design colleague mentioned | `[inferred]` from the mandate wording and the posting's silence on other designers |
| Market calibration | A survey of 520 Irish product designers with 3–5 years' experience gives a median base of €57,000 (interquartile range €51,500–€62,000). The posted range sits inside that band. This is the band to expect, not Fernquay's offer | `[generic]` Tillerby 2026 survey, read from its search snippet only |
| Unknowns | Where the role is advertised (RR1), the equity terms (RR2), the design support structure (RR3), your pay floor (R2) | — |
| Contradictions | None between the posting and the about page: both say six people and Galway. The one address I tried for a careers page returned no page | `[grounded]` about page fetched; careers address returned nothing |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week at the Galway office | hard_gate | direct | medium | none | You say you moved back to Galway last year. That is prose, not a stated constraint, so it stays at the intake ceiling | `[grounded]` your message | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | You haven't given a pay floor, so there is no statement to grade and the posting can't be checked against it | `[grounded]` posting figure; no floor supplied | Answer G1 below |
| R3 | 3+ years of product design | must_have | direct | medium | none | You state 4 years at a Dublin travel-booking company. This is self-report with nothing inspected yet | `[grounded]` your message | Share the case study link to read |
| R4 | Strong Figma | must_have | direct | medium | none | You say you use Figma daily. A shared Figma file or prototype would be the inspectable proof for a designer | `[grounded]` your message | Optional: a Figma file or prototype link |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. The limit: the role describes research calls with school owners, which are interviews, and usability sessions are a different method | `[grounded]` your message; `[inferred]` that the methods differ | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your message | none |
| R7 | Own the booking flow end to end | important | adjacent | medium | transferability | You redesigned a checkout flow, which is one stage of a booking flow. The limit: nothing stated about the steps before checkout, or about owning the flow from research to ship | `[grounded]` your message; `[inferred]` that checkout is part of a wider flow | See G2 |
| R8 | Be the first designer | important | adjacent | low | transferability | You say you've never been the only designer, and the checkout redesign is the nearest evidence. The limit: you have always had design peers around, so setting direction alone is untested | `[grounded]` your message | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor against the range (R2, hard_gate) | hard_gate | The posting gives a range, and I have no minimum from you | A gate I can't check keeps the decision conditional | Your actual minimum, and whether equity counts toward it | None needed; this is your own statement | `[grounded]` posting figure; no floor supplied |
| G2 | End-to-end flow ownership (R7, important) | transferability | The checkout redesign is confirmed. How far upstream or downstream your ownership went is not | The posting says "end to end", so this is where the call will probe | Owning the flow from research to ship; steps before checkout such as search or availability; payment or confirmation steps | The case study they already saw, or a flow diagram | `[grounded]` your message; `[generic]` that "end to end" invites an ownership probe |
| G3 | Working as the only designer (R8, important) | transferability | You have always had design peers. Any solo direction-setting is unconfirmed | A first designer sets direction alone, and the answer decides how you frame R8 | Setting standards or a component library; a freelance or side project run alone; leading a project while the design lead was away | A project write-up or a file you can share | `[grounded]` your message; `[generic]` that first-designer roles lean on solo judgement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Role not found on the employer's own site | unknown | — | "Product Designer — Fernquay" | The role may be advertised only on a jobs board, or the careers page may live at an address I did not try | `[grounded]` one guessed address returned no page; `[generic]` that small teams often advertise only on boards | Where is this role listed on your own site or channels? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | Vesting, share class and the basis for the percentage are not given, so the value is unclear | `[inferred]` from the posting's silence | What vesting schedule and share class apply to the 0.5–1%? | unresolved |
| RR3 | A first designer with no named design support | risk_signal | low | "You would be our first designer: own the booking flow end to end" | You may be accountable for the whole flow without a design mentor or reviewer. I take `low` because the posting also offers close work with a co-founder and engineers | `[inferred]` from the scope wording against its silence on design support | Who reviews design work today, and what does success look like at six months? | unresolved |
| RR4 | Pay and working pattern stated plainly | positive_signal | — | "Salary €52,000–€60,000", "two days a week at our Galway office" | Compensation and location are transparent, and the range sits inside the market band | `[grounded]` posting; `[generic]` survey band | Is there flexibility within the range? | noted |
| RR5 | Employer matches the posting | positive_signal | — | "six people in Galway" | Size, location and co-founders match Fernquay's own about page. Saoirse Doyle is a named co-founder, though the page gives no title. A thin footprint is common for a company this young and customer-funded, so little online is not itself a signal | `[grounded]` about page; `[generic]` on thin footprints | What is Saoirse's role in the interview? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take the call. Join from the emailed invite, and check that it came from an address on Fernquay's own domain and matches how Ronan has contacted you | A message that only schedules a video call is routine, and the check costs a minute | `[generic]` ordinary diligence | pending your approval |
| A2 | Ask RR1, RR2 and RR3's questions verbatim on the call, and get pay and equity confirmed in writing before accepting | See RR1–RR3 and R2 | `[grounded]` register | pending your approval |
| A3 | Lead with the checkout redesign and the monthly usability sessions (R5, R7), and say plainly what was yours and what the squad's | The posting says they prefer one real, messy project, and they have already seen the case study | `[grounded]` posting and your message | pending your approval |
| A4 | Frame R8 as adjacent: you have worked in a team and have not been the only designer, so say that rather than imply solo ownership | Candour about the limit reads stronger in the interview | `[grounded]` your message | pending your approval |

When you want to rehearse the call, mock-interview can do that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about). Fetched that page, then fetched fernquay.example/careers, which returned no page. Moved: organization, contradictions, RR1, RR5 |
| 2. Role-family sweep | yes | Searched "product designer salary Galway Ireland 3+ years startup", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). I read the search snippet only, not the full page. Moved: market calibration, RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). I read the snippet only. Moved: the hiring-manager row and A3 |

I'd like to send you `tuesday-dossier.md` to keep, if you want it.

## Upgrade menu

- Your minimum salary → R2 and G1 close.
- A link to the checkout case study, or a Figma file → R3, R4 and R7 can move toward `high`.
- An answer on solo work → R8 strengthens or stays adjacent.
- Written equity terms from Fernquay → RR2 closes.
- Where Fernquay advertises the role → RR1 closes.
- A deeper research pass on Fernquay (customer reviews, funding or leadership history, recent news; up to 5 more searches and 2 more fetches). Say the word and it runs.

Questions:

1. G1 (R2) — What is the lowest salary you would accept, and would equity change that?
2. G2 (R7) — In the checkout redesign, what did you own from first research to ship, and did you touch any steps before checkout, such as search or availability?
3. G3 (R8) — Have you ever set design direction with no design peer or lead around you, such as a freelance or side project, and what exactly was yours?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.