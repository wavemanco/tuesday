Working from your posting and messages only, because web search wasn't permitted.

## Decision snapshot

**Yes, take the call. You fit the must-haves in R3, R4, R5 and R7, and R6 is adjacent. I can't establish Fernquay itself from here. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000 plus equity)
- `must_have`: direct: R3, R4, R5, R7 · adjacent: R6 (Own the booking flow end to end)
- `important`: adjacent: R8 (First designer, no design peers)

R6 — checkout redesign is a credible bridge, its limit named; R8 — adjacent, no sole-designer role in your history.

**Opportunity ledger.** Fernquay isn't established from attributable sources (RR1), so the status is capped at `conditional_go`. Equity terms and design support are unstated (RR2, RR3). The posting is specific about scope and pay (RR4). Nothing in the posting or the WhatsApp message asks you for money, bank, tax or ID details. Arranging a call by WhatsApp with an emailed invite is a routine step.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 plus equity); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay verifies as a live employer with this role (RR1); (2) the pay clears your floor (R2); (3) you learn what design support exists around a first designer (R8, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, six people in Galway, booking software for sea-kayak and surf schools. This is the posting's own description and is not independently checked | `[grounded]` posting |
| Mandate | Own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Works with | Co-founder Ronan Kehoe. The WhatsApp sender gives the same name | `[grounded]` posting and message |
| Working pattern | Hybrid: two days a week at the Galway office | `[grounded]` posting |
| Compensation | €52,000–€60,000 plus 0.5–1% equity. No market band was calibrated because the search was refused | `[grounded]` posting figures |
| Scope read | Three duties for one hire with no design lead named. That is broad, though plausible for a first design hire | `[inferred]` from the duty list against a six-person team |
| Unknowns | Equity terms, who reviews design work, who sets priorities, company age and funding | `[grounded]` posting silent |
| Contradictions | None between the posting and the WhatsApp message. Neither could be checked against Fernquay's own site | `[grounded]` the two texts you pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You say you moved back to Galway last year. That is self-reported, so `medium`. No constraint of yours was stated | `[grounded]` your message and the posting | none |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | The posting states the terms. You have given no floor, so whether it clears your floor is unsettled | `[grounded]` posting figures; floor not given | Ask: your floor (question below) |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer in Dublin. This is a length-of-experience requirement, not a gate | `[grounded]` your background, CV-equivalent prose | Link your portfolio to raise to `high` |
| R4 | Strong Figma | must_have | direct | medium | none | "Figma daily" is stated with no artifact yet | `[grounded]` your background | A case study file or prototype link would raise it |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. The role's research is calls with school owners, which is a different kind from usability testing, so expect a probe on that | `[grounded]` your background; `[inferred]` that the two kinds differ | Say plainly on the call what the sessions were |
| R6 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow at a travel-booking company. Limit: checkout is one stage of a booking flow, and how much of it you owned versus the squad is not stated | `[grounded]` your checkout redesign; `[inferred]` that it is one stage | See G1 |
| R7 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R8 | First and only designer, no design peers | important | adjacent | medium | transferability | The posting says "first designer". You have not been the only designer anywhere, so the closest evidence is squad work with engineers | `[grounded]` posting and your statement | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow ownership (R6, must_have) | transferability | A checkout redesign is confirmed. Which stages, decisions and outcomes were yours is not | R6 is a `must_have` at `adjacent`, and the posting names end-to-end ownership | Deciding the flow's steps, not only the screens; owning a metric such as conversion or drop-off; handoff and follow-up after launch | The checkout case study they already read; a before-and-after flow | `[grounded]` your one-line description; `[generic]` that end-to-end claims get probed |
| G2 | Working without design peers (R8, important) | transferability | Squad experience with four engineers. No stated case of setting direction without a design lead | A first designer sets standards and defends decisions alone | Small projects, internal tools or freelance work where you set design direction; running critique without designers present | A project write-up or the decisions you made on it | `[grounded]` your statement; `[inferred]` from the posting's "first designer" |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer. No search ran, so this rests on the thin footprint you found | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The percentage may be of fully diluted shares, may vest over years, or may carry conditions the posting does not mention | `[inferred]` from the posting giving a range and no terms | Is the 0.5–1% of fully diluted shares, and what are the vesting schedule and cliff? | unresolved |
| RR3 | Design support and decision rights unstated | unknown | — | "own the booking flow end to end" / "work most closely with our co-founder" | As the first designer you may be accountable for the flow while priorities and sign-off sit with the founders | `[inferred]` from the scope language against silence on review and authority | Who reviews your design decisions, and which product calls are yours alone? | unresolved |
| RR4 | Scope, pay and process stated plainly | positive_signal | — | "we would rather see one messy real project than a polished deck" | The role looks defined, and a proportionate application process fits that | `[grounded]` posting | What would success on the booking flow look like at six months? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's own website and careers page. Check the role is listed there and that the calendar invite came from an address on that site's domain. Join only through the emailed invite. | RR1. This is advice on a routine step, not a condition | `[grounded]` RR1 | pending your approval |
| A2 | Ask RR1–RR4's questions verbatim, with RR2 and RR3 as priorities | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A3 | Describe the checkout work in your own words: you "redesigned our checkout flow" and "ran monthly usability sessions with customers". Say plainly which decisions were yours and which the squad's. | R5, R6. Interviewers probe ownership | `[grounded]` your sentences | pending your approval |
| A4 | Say openly that you have not been the only designer, and ask what support exists | R8, RR3 | `[grounded]` your statement | pending your approval |
| A5 | Decide your pay floor and how much weight you give equity before the call | R2 | `[grounded]` R2 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Fernquay booking software sea kayak surf schools Galway" was refused. It would have fed the contradictions row and RR1, so RR1 stands at `medium` |
| 2. Role-family sweep | unavailable | The search on product designer salary in Ireland was refused. It would have given a market band for R2 and the scope read, so none is stated |
| 3. Hiring manager's public footprint | unavailable | The search on Ronan Kehoe and Fernquay was refused. It would have fed the scope read and which story A3 leads with |

I haven't retried the refused searches.

I can save all of this as a `tuesday-dossier.md` if you'd like to keep it.

**Upgrade menu**

- Allow web search, and the three targets above run. That settles RR1 as far as public sources go and adds a salary band and Ronan's public professional background.
- Fernquay's careers-page link or website, which closes RR1 without any search.
- A link to the checkout case study, which can raise R3, R4, R5 and R6 toward `high`.
- Your pay floor and your view on equity, which close R2.
- If you take the call, mock-interview can prepare you for it.

**Questions**

- R2 — What's the lowest salary you'd accept, and does the equity change that number?
- G1 — In the checkout redesign, which decisions were yours alone (flow steps, what to test, what shipped), and what happened to conversion or drop-off afterwards?
- G2 — Have you ever set design direction with no other designer to review it, even on a small or side project? What was it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.