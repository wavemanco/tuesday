I've confirmed the employer exists. Next I'm checking whether this posting is live on their careers page.
# Job Underwriting: Community Staff Nurse, Band 5, Calderbrook Community Health CIC

## Decision snapshot

**Yes, worth applying, on the conditions below. Status: `conditional_go`.** R1 and R2, the hard gates, are `direct` on your own statement. R3 is `direct`. R4, a must-have, is `unclear`, so the status is conditional.

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3 · unclear: R4 (clear, timely written records)
- `important` — direct: R6a, R7 · adjacent: R5 (wound and leg-ulcer care), R9 (care of housebound adults at home) · unclear: R6b (continence care), R8 (end-of-life visits) · absent: R10 (own caseload)
- `preferred` — absent: R11 (Doppler assessment)

R10 — a real gap, though the advert says the caseload is supported; R5 — a bridge from pressure and surgical wounds, leg-ulcer work not shown; R4 (`low`) — records are plausibly routine but your CV is silent.

**Opportunity ledger.** The advert offers a named contact for a chat and a senior nurse's support (RR3), and it states the pay (RR2). Still open: whether the post is live (RR1) and whether Doppler training is provided (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post confirmed live and open (RR1); (2) R4 confirmed by your answer to G1; (3) the application states plainly that you have no caseload of your own and no Doppler experience (R10, R11).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015; 410 staff, four locality hubs | `[grounded]` About page, fetched |
| Role | Band 5 staff nurse in the district nursing team, caring for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, electronic patient record | `[grounded]` advert |
| Caseload | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Pay | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` advert |
| Contact | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. In 2025 she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page |
| Scope read | Looks built for a nurse new to community work: Doppler is desirable and not essential, and the caseload is supported | `[inferred]` from the advert's wording and the contact's published talk topics |
| Market calibration | Not established: the role-family search returned nothing | `[generic]` none available |
| Unknowns | Shift pattern, weekend and on-call duty, contract type, closing date, which record system is used | — |
| Contradictions | None between the advert and the About page; the careers page was not reached | `[grounded]` fetches |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active registration, Adult field, revalidation due March 2028. Stated, not checked | `[grounded]` CV | Check your own NMC register entry shows what you state |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full category B licence, and pool cars are provided. Stated, not checked | `[grounded]` CV and advert | Check your driving record is current |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, per your CV. Limited inspectable proof | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | CV silent on records and any electronic patient record. Ward nursing and discharge visits make it plausible | `[grounded]` CV silence; `[inferred]` plausibility | G1 |
| R5 | Wound and leg-ulcer care | important | adjacent | medium | transferability | You state pressure-ulcer and surgical-wound care. Leg-ulcer care and compression are not stated, and that is the limit | `[grounded]` CV | G3 |
| R6a | Catheter care | important | direct | medium | none | Stated on your CV | `[grounded]` CV | none |
| R6b | Continence care | important | unclear | low | discovery | CV silent; catheter care is related and does not cover it | `[grounded]` CV silence | G4 |
| R7 | Insulin administration | important | direct | medium | none | Stated on your CV | `[grounded]` CV | none |
| R8 | End-of-life visits | important | unclear | low | discovery | CV silent. An acute ward plausibly includes it, but that is not a claim you made | `[grounded]` CV silence; `[inferred]` plausibility | G2 |
| R9 | Care of housebound adults in their own homes | important | adjacent | medium | transferability | 18 months of home visits in discharge-to-assess, in the first week after discharge. Limit: short post-discharge visits, not ongoing care of housebound patients | `[grounded]` CV | Lead with it, limit stated |
| R10 | A small caseload of your own | important | absent | none | capability | You have never held one. The advert says a senior nurse supports it | `[grounded]` your statement and the advert | G5 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | Never done one. It is desirable, not essential | `[grounded]` your statement and the advert | G6 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | No mention of records or a record system | It is the one must-have not yet met, and it decides `conditional_go` | Recording discharge-to-assess visits; care plans you wrote; electronic notes on the ward | Your revalidation portfolio entries, or a reference from the discharge-to-assess lead | `[grounded]` CV silence |
| G2 | End-of-life visits (R8) | discovery | Nothing stated | Named in the advert's duty list | Caring for dying patients on the ward; symptom review; talking with families; referrals to palliative teams | A reference or practice-feedback entry | `[grounded]` CV silence |
| G3 | Leg-ulcer care (R5) | transferability | Pressure ulcers and surgical wounds only | The advert names leg ulcers, and the contact has spoken on them | Dressing or assessing leg wounds; compression bandaging; venous-ulcer patients on the ward | A compression or wound-care training certificate | `[grounded]` CV; `[inferred]` bridge |
| G4 | Continence care (R6b) | discovery | Catheter care only | Part of the duty list | Bladder and bowel care plans; continence assessments | A training record | `[grounded]` CV silence |
| G5 | Own caseload (R10) | capability | Confirmed none | An important duty, with support stated | Closure path: ask how supervision works at the start | None; this is a question for the employer (RR3) | `[grounded]` your statement |
| G6 | Doppler (R11) | capability | Confirmed none | Desirable only | Closure path: ask whether training is provided (RR4) | A Doppler training record, once you have one | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The careers page was not reached at the address I tried, so the post may be open at another address or may have closed | `[grounded]` fetch returned no page | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Pay set against an unstated floor | unknown | — | "£31,050–£37,800 a year plus mileage" | Where an applicant lands in the range is not stated, and your pay floor was not given | `[grounded]` advert figure | Where in the range would someone with five years' post-registration experience be placed? | unresolved |
| RR3 | Senior support and a named contact | positive_signal | — | "supported by a senior community nurse"; "informal chat… Rhiannon Mabbott" | Support exists and the team lead is reachable before you apply | `[grounded]` advert | How much accompanied visiting is there before you carry the caseload alone, and for how long? | noted |
| RR4 | Doppler training provision not stated | unknown | — | "Desirable: Doppler assessment for leg ulcers" | The team lead has spoken publicly on Doppler training for staff new to community work, so training may be offered | `[inferred]` from the forum speaker page | Is Doppler training provided, and how soon after starting? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the 18 months of discharge-to-assess home visits near the top of your CV, in your own words: "seconded to the discharge-to-assess team, visiting patients at home in their first week after discharge". Add no word that suggests an ongoing caseload | R9 | `[grounded]` CV | pending your approval |
| E2 | Name wound care (pressure ulcers and surgical wounds), catheter care and insulin administration as you wrote them. Do not write leg-ulcer care | R5, R6a, R7 | `[grounded]` CV | pending your approval |
| Q1 | Take up the informal chat with Rhiannon Mabbott before applying. Say plainly that you have no caseload and no Doppler experience, then ask the RR3 and RR4 questions verbatim | R10, R11, RR3, RR4 | `[grounded]` advert invitation | pending your approval |
| A1 | Check your NMC register entry and your driving record match what you stated | R1, R2 | `[grounded]` your statements | pending your approval |
| A2 | Ask in that chat or in writing whether the post is open and when it closes | RR1 | `[grounded]` RR1 | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this assessment, and I haven't used it.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and "Calderbrook Community Health CIC community staff nurse district nursing Halifax vacancy". Fetched "About Calderbrook Community Health" (calderbrookhealth.example/about). A fetch of calderbrookhealth.example/careers returned no page. Moved role reality's organization row and RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing caseload Doppler training requirements"; no results, so not established. No market calibration is given; the upgrade menu offers it |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook"; found "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved role reality's contact and scope rows, Q1 and RR4 |

If you'd like to keep this analysis, I can emit it as a `tuesday-dossier.md`.

## Upgrade menu

- A link to the live posting or the careers page, with its closing date → RR1 closes, and the second condition for go is met.
- A short answer on how you record visits, or a reference from your discharge-to-assess lead → R4 can reach `medium`, and the must-have settles.
- Your revalidation portfolio entries (practice feedback, CPD log) or a wound-care or compression training certificate → R5, R8 and R6b rest on something inspectable.
- Your pay floor → RR2 can be checked against the stated range.
- A deeper research pass on Calderbrook (staffing, inspection reports, recent news; up to 5 more searches and 2 more fetches) — say the word and it runs. It would also retry the pay and role-family sweep.

G1 (R4) — Which electronic patient record system(s) have you written in, and how soon after a home visit in discharge-to-assess did you complete your notes?

G2 (R8) — Have you cared for patients at the end of their life, on the ward or on discharge-to-assess visits? What was your part: symptom review, anticipatory medicines, talking with families, referrals?

G3 (R5) — Have you assessed or dressed leg wounds or applied compression bandaging, and did you have training for it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.