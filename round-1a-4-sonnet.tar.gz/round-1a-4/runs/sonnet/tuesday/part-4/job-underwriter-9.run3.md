Search permission was declined, so everything below rests on what you pasted.

## Decision snapshot

**Yes, asking for these is routine here. Bank details, PPS number and passport come after a written offer that names your role and pay, and after two in-person interviews. Accepting is worth it on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, two days in Limerick office), R2 (Pay €38,000–€42,000)
- `must_have` — direct: R3, R5, R6 · unclear: R4 (Irish PAYE, PRSI and USC)
- `important` — direct: R7, R8 · adjacent: R9 (Monthly payroll for 240 staff) · unclear: R11 (Staff payroll queries) · absent: R10 (Pension changes)

R10 — a gap, closure path in the plan; R9 — a bridge, its limit named; R4 (`low`) — one confirmation from you.

**Opportunity ledger.** The offer matches the posting (RR2). RR1 and RR3 are open: the employer hasn't been checked against public sources, and the contract terms aren't in writing yet.

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days in Limerick office), R2 (Pay €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the office days and €40,000 meet your own limits — R1, R2; (2) the written contract arrives before you resign — RR3; (3) you get a pension-change handover — R10.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff | `[grounded]` posting |
| Mandate | Run monthly payroll, process starters, leavers and pension changes, reconcile payroll to the ledger, answer staff queries | `[grounded]` posting |
| Offer terms | Permanent, €40,000, reporting to Declan Garvagh (Finance Manager), hybrid with two office days, start after your notice | `[grounded]` offer email |
| Contradictions | None between the posting and the offer: title, hybrid pattern and salary (inside the posted band) agree | `[grounded]` posting against offer |
| Stage | Offer, five working days to reply | `[grounded]` offer email |
| Market calibration | Not run, because search was declined. €40,000 sits inside the posting's own band, but how that band compares with market pay is unchecked | `[grounded]` posting; comparison unavailable |
| Unknowns | Whether you'd be the only payroll operator; pension scheme terms; probation; hours | `[grounded]` offer silent on these |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Limerick office | hard_gate | unclear | none | hard_gate | Role terms are stated and the offer repeats them. Your own limits on commute and days weren't given | `[grounded]` posting and offer; constraints not given | Closing question R1 and R2 |
| R2 | Pay €38,000–€42,000 (offer €40,000) | hard_gate | unclear | none | hard_gate | Offer is inside the band. Your minimum wasn't given | `[grounded]` posting and offer; constraints not given | Closing question R1 and R2 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff. Self-reported, nothing inspected yet | `[grounded]` your background | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | You ran payroll, but your background doesn't say which country's tax rules you applied | `[grounded]` background silent on jurisdiction | Closing question G1 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables, XLOOKUP. Self-reported | `[grounded]` your background | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. The certificate itself would raise this to `high` | `[grounded]` your background | none |
| R7 | Process starters and leavers | important | direct | medium | none | Done at the hotel group, self-reported | `[grounded]` your background | none |
| R8 | Payroll-to-ledger reconciliation each month | important | direct | medium | none | You did this monthly. Self-reported | `[grounded]` your background | none |
| R9 | Run monthly payroll for 240 staff | important | adjacent | medium | transferability | Carries over: full payroll runs. Limit: you ran fortnightly cycles for 90 staff, so a larger headcount and a monthly cycle are new. Strengthener: any peak-volume run, such as seasonal hiring | `[grounded]` background; the limit is `[inferred]` from the two headcounts | none |
| R10 | Process pension changes | important | absent | none | capability | You've told me your manager handled these and you haven't done them. No adjacent work stated | `[grounded]` your statement | Handover request, plan row A4 |
| R11 | Answer staff payroll queries | important | unclear | low | discovery | Your background doesn't mention staff queries | `[grounded]` background silent | none this turn; be ready to describe how you handled them |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish payroll tax knowledge (R4, must_have) | discovery | Payroll experience is clear, but not which tax regime you applied | A must-have; confirming it moves R4 to `direct` | Applying employees' tax credits and USC rates from Revenue's payroll notifications; reconciling PAYE, PRSI and USC to your monthly Revenue payments; handling Revenue year-end returns | A sanitized payroll checklist or a redacted Revenue return summary | `[grounded]` background silent on jurisdiction; `[generic]` that Irish employers work from Revenue notifications |
| G2 | Pension changes (R10, important) | capability | Handled by your manager, not by you | A listed duty you haven't done. Closable by a handover, so it reads as a ramp-up item, not a blocker | Any time you prepared figures for, or checked, your manager's pension changes | None to request | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not checked against public sources | unknown | — | "Marrowgate Housing, a housing association in Limerick" | The organisation looks real from your two in-person interviews at its office. Its public footprint is unchecked because search was declined | `[grounded]` your two interviews; `[inferred]` that nothing else has been checked | Can you send me your website address and confirm this role is on your careers page? | unresolved |
| RR2 | Written offer matches the posting | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager, hybrid" | Title, pay band and hybrid pattern agree with the posting, and a named line manager is given | `[grounded]` posting and offer text | Who can walk me through pension changes in my first weeks? | noted |
| RR3 | Contract terms not in the offer email | unknown | — | "starting on a date we agree once your notice period ends" | Probation, hours and pension terms aren't stated, and the five-working-day deadline falls before any start date | `[grounded]` email silent on these terms; `[inferred]` that a contract follows | Will the full written contract, with probation, hours and pension scheme terms, reach me before my five working days are up? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Ask for the written contract before you accept, and hold your resignation until you have it | see RR3 | `[generic]` general practice on offers that start after a notice period | pending your approval |
| A2 | Enter bank, PPS and passport details only in the employer's own onboarding portal. Check the portal address against the web address on their own website, found by searching for it yourself, and don't send these details by email or message | The portal link comes after you accept, and the address is the one thing worth checking | `[generic]` | pending your approval |
| A3 | Don't be put off by the "never hand these over" rule. That advice fits requests before any offer, or from a sender you can't place. Yours came after two in-person interviews, names the role and pay, and uses the employer's own domain | Payroll needs a PPS number and bank details, and a right-to-work check needs ID | `[generic]` for what payroll and right-to-work checks need; `[grounded]` for your own offer details | advice |
| A4 | At or before the start, say plainly: "At the hotel group my manager handled pension changes, so I haven't processed them myself; I'd like to be walked through your scheme in my first weeks." | see R10 | `[grounded]` your own statement, clause by clause | pending your approval |
| A5 | Bring the original passport on day one, as the offer asks | Stated in the offer | `[grounded]` offer email | advice |

Extra, on your approval: a short acceptance reply that asks for the contract (A1), built only from what you've told me.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search "Marrowgate Housing Limerick housing association" was refused and returned nothing. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Search "payroll administrator salary Limerick Ireland €38,000 €42,000" was refused and returned nothing. It would have moved the market calibration row |
| 3. Hiring manager's public footprint | unavailable | The name Declan Garvagh was given, but search permission was declined, so no query was sent. It would have moved the plan's positioning |

I'd save this as a `tuesday-dossier.md` if you want a record to come back to.

## Upgrade menu

- Search permission (up to 5 searches and 2 fetches) → RR1 and the contradictions row get checked, R2's pay gets a market band, and the plan gets a read on Declan Garvagh's public professional background.
- Your answer on Irish PAYE, PRSI and USC (G1) → R4 resolves.
- Your own limits on pay and office days → R1 and R2 resolve.
- The written contract → RR3 closes and the pension scheme terms appear.
- Your Payroll Technician certificate, or a sanitized payroll or reconciliation checklist → R3 and R6 rise to `high`.

G1 — At the hotel group, were you applying Irish PAYE, PRSI and USC yourself, and how (for example tax credits, Revenue notifications, or monthly Revenue payments)?

R1 and R2 — Do two office days a week in Limerick and €40,000 meet your own limits on commute and minimum pay?

RR3 — Has anyone said when the written contract will arrive, compared with your five-working-day deadline and your notice period?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.