## Decision snapshot

**No, I wouldn't go ahead. This job is very likely a scam, so don't deposit the cheque or send the €349, and don't send your IBAN, PPS number or passport photo. RR1, RR2, RR3 and RR4 are severe red flags. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Earn at least €30,000 a year)
- `must_have` — direct: R2, R3

R1 — the posting gives a pay ceiling, not a figure; R2 (`medium`) — a weekly Excel tracker, no sample seen; R3 (`medium`) — about 60 tickets a day in Zendesk.

**Opportunity ledger.** The messages ask you to pay for equipment (RR1), to deposit a cheque and send most of it on (RR2), and to hand over bank, tax and ID details before any offer (RR3). The posting says hiring happens wholly on Telegram (RR4). The one contact address given is a free-mail-style one (RR5), and I couldn't find the firm itself (RR6).

- **Hard gates:** none failed; unconfirmed: R1 (Earn at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** you would need an employer confirmed independently through its own website, live interviews, and no payment, cheque or ID request before a written offer. The pay would also need to be a stated guaranteed figure (R1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics". A search for it plus the role title returned no results, so the firm is not established from here | `[grounded]` posting; `[grounded]` search returned nothing |
| Mandate | Remote order processing, 15–30 hours a week, set your own hours, "no experience needed, full training provided" | `[grounded]` posting |
| Pay as stated | "Up to €26 an hour plus commission". At that ceiling, 15 to 30 hours over 52 weeks is about €20,300 to €40,600 a year. Reaching €30,000 needs about 22 hours every week at the ceiling rate | `[grounded]` posting; `[inferred]` arithmetic, assuming 52 paid weeks |
| Market calibration | One 2026 Irish pay guide puts order processing and customer operations coordinators at a median base of €31,200 (middle range €28,400–€34,100). It covers salaried roles only and excludes commission-only and freelance work, so it is a band, not this employer's offer | `[generic]` role-family sweep, one guide |
| Hiring process | Telegram only, "no calls or video interviews" | `[grounded]` posting |
| Contradictions | The posting says nothing about buying equipment, but the chat then asks for €349 for a laptop and headset. The cheque (€2,850) is also far larger than that kit cost | `[grounded]` posting against the chat messages |
| Unknowns | Employee or contractor status, guaranteed hours, commission rate, who "payroll" and the "equipment partner" are | `[grounded]` none of these are stated in the material |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Earn at least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because the posting gives only a ceiling rate and a variable 15–30 hours | `[grounded]` your statement and the posting; `[inferred]` arithmetic | Needs a written guaranteed rate and hours from a verified employer (G1) |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. This is intake prose with nothing inspectable, so `medium` | `[grounded]` your background | none |
| R3 | Good written English | must_have | direct | medium | none | Ticket handling at about 60 a day is written work, and this conversation shows your written English. No sample reviewed | `[inferred]` ticket work is written; `[grounded]` your messages | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R1, hard_gate) | hard_gate | A ceiling of "up to €26 an hour" and a 15–30 hour range. The low end of that range falls well under €30,000 a year | The floor can't be checked against pay that isn't stated | Not applicable, since a pay term is not experience | A written guaranteed hourly rate and weekly hours from the employer, obtained through contacts found on its own website | `[grounded]` posting wording; `[inferred]` the low-end arithmetic |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | The job asks you to pay out before you earn anything | `[generic]` requests to pay for the job or kit are a recognised sign to stop | Do your employees ever buy their own equipment, and who is the "equipment partner"? | confirmed |
| RR2 | Cheque deposit, then transfer onward | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can be credited and later returned, while a transfer you send out is gone. You could be left covering the difference | `[generic]` known pattern for cheque-then-transfer requests | Does your payroll ever send cheques to new starters, and why is any part of it sent on to a third party? See RR1 | confirmed |
| RR3 | Bank, tax and ID details before an offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These were requested at the screening stage, before any written offer naming the role and pay | `[grounded]` the request came before the interview and before any offer | At what stage do you collect bank, PPS and ID details, and through which portal? See RR1 | confirmed |
| RR4 | Hiring wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | Interview and offer happen only in chat, so there is nobody you can check against | `[grounded]` posting wording | Will there be a live call or video interview with a named person before any offer? See RR1 | confirmed |
| RR5 | Contact off a verifiable employer domain | risk_signal | medium | "Any problems, email velloway.hr@postmail.example." | The address is on a mail service, not on a company website. The message may not come from who it names | `[inferred]` from the address against the firm name | Is this address one the company uses, and what is your own website's HR contact? | unresolved |
| RR6 | Employer not established | risk_signal | medium | "Velloway Logistics" | The firm may be too new or small to have a web presence, the posting may be stale, or it may not represent a real hiring employer. Sender identity is unresolved | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |

Hold each of these until you have checked it with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from. Who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send your IBAN, PPS number or passport photo. Real payroll details come after a written offer that names the role and pay, and go only into the employer's own portal | see RR3 | `[grounded]` RR3 | pending your approval |
| A2 | Don't pay the €349 | see RR1 | `[grounded]` RR1 | pending your approval |
| A3 | If the cheque arrives, don't lodge it and don't transfer anything | see RR2 | `[grounded]` RR2 | pending your approval |
| A4 | If you want to test this, find the firm's own website yourself and use contact details there. Don't use the Telegram handle or the postmail address | see RR5, RR6 | `[grounded]` RR5, RR6 | pending your approval |
| A5 | Put your effort into salaried customer-operations or order-processing roles. Your courier customer-service years, Zendesk volume, Excel tracker and training of two new starters fit them, and the surveyed salaried band overlaps your €30,000 floor | see R1, R2, R3 | `[generic]` one pay guide's band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers remote order processing coordinator"; no results, so the firm is not established. This feeds role reality's organization row and RR6 |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator salary Ireland hourly rate", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). This feeds the market calibration row and R1's comparison |
| 3. Hiring manager's public footprint | n/a | No named person was given, only a chat handle |

I've held your IBAN, PPS number and passport out of this analysis entirely, and I don't need any of them.

If you'd like, I can save this as a `tuesday-dossier.md` to carry into later steps.

## Upgrade menu

- The jobs site name and a link to the live posting → RR6 can be checked against what the site shows.
- The firm's own website and careers page, found independently → RR5 and RR6 can close.
- A written guaranteed rate and weekly hours from a verified employer → G1 and R1 close.
- A deeper research pass on the firm (up to 5 more searches and 2 more fetches) — say the word and it runs.

RR6 — Which jobs site was the posting on, and can you paste its link?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.