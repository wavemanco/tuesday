I've run three searches (the employer, the pay band and the team lead). Next I'll fetch Calderbrook's careers page to check that the posting is live, then write the assessment.
## Decision snapshot

**Yes, this is worth applying for. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1, R2
- `must_have` — direct: R3, R6a, R7, R8a · adjacent: R5 (care of housebound adults at home), R6b (leg-ulcer care) · unclear: R4 (clear, timely written records)
- `important` — adjacent: R10 (a small caseload of your own) · unclear: R8b (care planning), R9 (end-of-life visits)
- `preferred` — absent: R11 (Doppler assessment)

R5, R6b, R10 — credible bridges, limits named; R4, R8b, R9 — your CV is silent, answerable; R11 (`none`) — you've never done one, and the advert lists it as desirable only.

**Opportunity ledger.** The employer is established from its own page (see Role reality). The pay range and mileage are stated (RR2), and the team lead has spoken publicly on Doppler training for staff new to community work (RR4). Open: whether the post is live on the employer's own site (RR1), and caseload size and supervision (RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed open on Calderbrook's own site — RR1; (2) caseload size and supervision turn out workable for someone who has never held a caseload — R10, RR3; (3) you present the leg-ulcer and home-care experience as adjacent, never as district nursing experience — R5, R6b.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract. Founded 2015, 410 staff, four locality hubs | `[grounded]` "About Calderbrook Community Health" page |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration and care planning, on an electronic patient record | `[grounded]` advert |
| Supervision | "A small caseload of your own, supported by a senior community nurse" | `[grounded]` advert quote. How small, and how much support, is not stated |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team after eleven years as a district nurse. In 2025 she spoke at a community nursing forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page, seen as a search result and not fetched |
| Pay | £31,050–£37,800 plus mileage. A 2026 survey of England community staff nurses at Band 5 (n=1,240) gives median basic pay of £34,300, interquartile range £32,400–£36,600. 61% of respondents were paid mileage and 24% had a pool or lease car; pool cars here are provided, which is on the better side of that pattern | `[grounded]` advert figures; `[generic]` survey pattern, from one search result I did not open |
| Unknowns | Caseload size, rota and weekend working, contract type, start date, which record system is used | `[grounded]` the advert is silent on each |
| Contradictions | None between the advert and the About page. The careers page was not found (RR1) | `[grounded]` About page and the failed fetch |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active registration, revalidation due March 2028. Stated, not checked; the NMC register entry is the inspectable artifact | `[grounded]` CV | You check your own register entry shows Adult field and active |
| R2 | Full UK driving licence (pool cars provided) | hard_gate | direct | medium | none | You state a full category B licence. Stated, not checked; your driving record is the inspectable artifact | `[grounded]` CV | You check your licence status and endorsements before applying |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, as written on your CV. Limited inspectable proof | `[grounded]` CV | none |
| R4 | Clear, timely written records on an electronic patient record | must_have | unclear | low | discovery | Your CV is silent on records and on any record system | `[grounded]` CV silence | G3 |
| R5 | Caring for housebound adults in their own homes | must_have | adjacent | medium | transferability | Your 18-month discharge-to-assess secondment, visiting patients at home in their first week after discharge, is the closest match. Limit: nothing says you cared for people long term at home | `[grounded]` CV; `[inferred]` the limit, from the CV's silence on longer-term home care | Lead with the secondment (A2) |
| R6a | Wound care | must_have | direct | medium | none | Your CV states wound care including pressure ulcers and surgical wounds | `[grounded]` CV | none |
| R6b | Leg-ulcer care | must_have | adjacent | low | transferability | Wound care is adjacent. Nothing on leg ulcers or compression is stated | `[inferred]` from wound care to leg ulcers; `[grounded]` CV silence on leg ulcers | G1 |
| R7 | Catheter care (the advert pairs it with continence care) | must_have | direct | medium | none | Catheter care is stated. Continence care beyond catheters is not mentioned | `[grounded]` CV | Mention continence in G3 if relevant |
| R8a | Insulin administration | must_have | direct | medium | none | Insulin administration is stated | `[grounded]` CV | none |
| R8b | Care planning | important | unclear | low | discovery | The CV is silent on writing care plans | `[grounded]` CV silence | G3 |
| R9 | End-of-life visits | important | unclear | low | discovery | The CV is silent on end-of-life care | `[grounded]` CV silence | G2 |
| R10 | Holding a small caseload of your own, with senior support | important | adjacent | medium | transferability | You say you have never held your own caseload. The secondment's home visits are adjacent. Limit: the support the advert describes is what the role expects to cover this | `[grounded]` your statement and the advert | Say plainly you have not held one (A3) |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you have never done one. The advert lists it as desirable. The team lead's public talk on Doppler training for staff new to community work suggests training may be available (RR4) | `[grounded]` your statement and the advert; `[inferred]` the training from the talk | Ask whether training is provided (A1) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Leg-ulcer care (R6b, must_have) | transferability | Wound care is stated. Leg ulcers, compression bandaging and any vascular or tissue viability link are not | Leg-ulcer work is named in the advert and the team lead has spoken on leg-ulcer clinics, so the bridge is likely to be tested | Dressing leg wounds on the ward; applying or seeing compression bandaging; working with tissue viability | A competency record or a training certificate | `[grounded]` CV and advert; `[inferred]` that it will be tested, from the advert and the talk |
| G2 | End-of-life care (R9, important) | discovery | The CV says nothing on it | The advert names end-of-life visits as part of the role | Caring for patients in their last days; family conversations; care after death | A training record or a reflective account | `[grounded]` CV silence |
| G3 | Records and care planning (R4, must_have; R8b, important) | discovery | The CV names no record system and no care planning | The advert names timely records as essential | Charting on a ward system; writing discharge or care plans on your secondment | A competency record, or a description of the system | `[grounded]` CV silence |
| G4 | Own caseload (R10, important) | transferability | You say you have never held a caseload | The advert says the post holds one, with senior support | Visits you planned yourself on the secondment | A secondment job description | `[grounded]` your statement; `[inferred]` the secondment as the bridge |
| G5 | Doppler assessment (R11, preferred) | capability | You have not done one | Desirable only, so a minor risk | A route is training, if the employer offers it | The employer's training offer | `[grounded]` your statement and the advert |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not found on the employer's careers page | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The page I tried returned nothing. The advert may sit at a different address, may have come via a job board, or may have closed; none is ranked as likely | `[grounded]` fetch of calderbrookhealth.example/careers returned no page | Can you confirm this post is open and point me to it on your own careers page? | unresolved |
| RR2 | Pay range stated, with mileage and pool cars | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The stated range spans the survey's median and interquartile range | `[grounded]` advert; `[generic]` survey pattern | Where in the range would my experience place me? | noted |
| RR3 | Caseload size and supervision unspecified | unknown | — | "a small caseload of your own, supported by a senior community nurse" | "Small" and "supported" may mean very different things in practice | `[grounded]` advert wording; `[inferred]` from its silence on numbers | How many patients would I carry, and what supervision and induction come before I carry them alone? | unresolved |
| RR4 | Team lead has spoken on Doppler training for staff new to community work | positive_signal | — | Advert: "Desirable: Doppler assessment for leg ulcers" | Training for newcomers may be offered in this team | `[grounded]` forum speaker page; `[inferred]` that it applies here | Is Doppler training provided to new starters, and over what period? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Take up the advert's offer of an informal chat with Rhiannon Mabbott. Use it for RR1, RR3 and RR4, and to ask about Doppler training | The advert invites it | `[grounded]` advert | pending your approval |
| A2 | CV edit, `resume_edits_pending_approval`: put the secondment first, in your own words. "Seconded to the discharge-to-assess team for 18 months, visiting patients at home in their first week after discharge" | See R5. Every clause traces to your sentence | `[grounded]` CV | pending your approval |
| A3 | If asked, say plainly that you have not held your own caseload or done a Doppler assessment, and name the secondment as your nearest experience | See R10, R11. Candour is what an interviewer can check | `[grounded]` your statements | pending your approval |
| A4 | Check your NMC register entry and driving licence status yourself before you submit | See R1, R2 | `[grounded]` the two rows | pending your approval |

## Evidence status

Verified: none yet. Your National Insurance number isn't needed for this assessment, so I haven't used it. You may want to remove it from anything you share.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). That established the employer. Fetched calderbrookhealth.example/careers and got no page, so the posting is unconfirmed. Moved role reality's organization and contradictions rows, and RR1 |
| 2. Role-family sweep | yes | Searched "community staff nurse Band 5 district nursing Halifax salary Agenda for Change 2026", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Moved the pay row and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the team lead row, RR4 and A1 |

I can write this up as a `tuesday-dossier.md` to carry forward if you'd like.

## Upgrade menu

- A copy of your NMC register entry or confirmation of Adult field → R1 to `high`.
- Your driving record status → R2 to `high`.
- Competency records or training certificates (compression, end-of-life, record systems) → R4, R6b, R9 firm up.
- The secondment's job description → R5 and R10 firm up.
- The hiring process details from the chat → RR1 and RR3 close.
- A deeper research pass on Calderbrook (contract history, staff and service reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — Have you dressed leg ulcers, applied or seen compression bandaging, or worked with a tissue viability or vascular service? What did you do yourself?

G2 — On the ward or on the secondment, have you cared for patients in their last days? What was yours to do, such as family conversations, symptom control or care after death, and what was someone else's?

G3 — Which electronic record system did you chart in on the ward and on the secondment? Have you written care plans or discharge plans yourself, and what was yours to write?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.