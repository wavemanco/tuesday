Web search was denied, so nothing below is looked up. It rests only on what you pasted.

## Decision snapshot

**Yes, this is normal. Bank details, a PPS number and a passport check after a written offer that names the role and pay are routine onboarding. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, two days a week in Limerick), R2 (Salary €38,000–€42,000)
- `must_have` — direct: R3, R5, R6, R10 · adjacent: R7 (Monthly payroll for 240 staff) · unclear: R4 (Irish PAYE, PRSI and USC)
- `important` — direct: R8 · absent: R9 (Pension changes)

R9 — no hands-on evidence, your manager handled these; R4 (`low`) — not yet stated in your background; R7 — a credible bridge, its limit named.

**Opportunity ledger.** The offer matches the ad on role, pay and hybrid pattern (RR2). Two things are open: the employer could not be checked from here (RR1), and the offer leaves its terms unstated (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, two days a week in Limerick), R2 (Salary €38,000–€42,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the written terms arrive before you give notice — RR3; (2) you confirm Marrowgate through its own website — RR1; (3) the pension-changes gap is stated plainly, never as experience you have — R9.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick | `[grounded]` ad and offer |
| Mandate | Monthly payroll for 240 staff, starters, leavers, pension changes, payroll-to-ledger reconciliation, staff queries | `[grounded]` ad |
| Offer | Permanent, €40,000, reporting to Declan Garvagh (Finance Manager), hybrid with two office days | `[grounded]` offer email |
| Ad against offer | Role, pay (inside €38,000–€42,000) and hybrid pattern agree | `[grounded]` ad against offer |
| Process | Two in-person interviews at their office, then a written offer from the employer's own `.ie` address | `[grounded]` your account |
| Scope read | Team size is not stated; the ad reads as a single-owner payroll post | `[inferred]` from the ad naming one role and no team |
| Market calibration | Not run, because search was denied; I won't give a salary band from memory | — |
| Unknowns | Probation, pension scheme, leave, notice terms, payroll software, team size | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Limerick | hard_gate | unclear | none | hard_gate | The ad and offer state it. You gave no limit on commuting or office days, so I can't tell whether it meets one | `[grounded]` ad and offer; constraint not given | Closing question, R1 and R2 |
| R2 | Salary €38,000–€42,000 (offer €40,000) | hard_gate | unclear | none | hard_gate | The offer sits mid-band. Your pay floor was not given | `[grounded]` offer; floor not given | Closing question, R1 and R2 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff, stated and specific. No artifact has been inspected, so expect a probe | `[grounded]` your stated background | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say the hotel group's payroll ran under Irish rules, or who issued the certificate | `[grounded]` background silent on jurisdiction | Closing question, G1 |
| R5 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, stated and specific. A worked file would raise it | `[grounded]` your stated background | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024. The certificate itself would be the inspectable artifact | `[grounded]` your stated background | Keep the certificate to hand |
| R7 | Run monthly payroll for 240 staff | must_have | adjacent | medium | transferability | You have run payroll end to end for 90 staff. The limit is that your cycle was fortnightly and about a third of the headcount | `[grounded]` your stated background; `[inferred]` scale limit | Bridge case, see G3 |
| R8 | Process starters and leavers | important | direct | medium | none | Stated as part of your 3 years | `[grounded]` your stated background | none |
| R9 | Process pension changes | important | absent | none | discovery | You have never done them, as you said. Whether you handled the deductions inside a run, or prepared them for your manager, is unknown | `[grounded]` your statement | Closing question, G2 |
| R10 | Monthly payroll-to-ledger reconciliation | must_have | direct | medium | none | Stated, the same duty the ad names | `[grounded]` your stated background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory knowledge (R4, must_have) | discovery | Payroll experience is stated, but not the tax jurisdiction it ran under | It is a must-have, and one line from you would likely close it | Filing Revenue payroll returns, applying tax credits and cut-offs, processing PRSI classes and USC, year-end and P60 work | The certificate syllabus, or a sanitized payslip layout | `[grounded]` background silent; `[inferred]` that one answer closes it |
| G2 | Pension changes (R9, important) | discovery | None done personally; your manager handled them | It is a named duty of the post and the only one where you have no hands-on record | Processing pension deductions in the run, preparing joiner or leaver pension data, reconciling pension contributions | A pension reconciliation you prepared, even as part of a run | `[grounded]` your statement; `[inferred]` that adjacent steps may exist |
| G3 | Scale step to 240 staff, monthly (R7, must_have) | transferability | Same end-to-end ownership at 90 staff on a fortnightly cycle | A credible bridge, but the limit should be named | Month-end close, larger starter and leaver volumes, multi-site or multi-department pay | Run calendar or checklist you built | `[inferred]` bridge from your account |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from here | risk_signal | medium | "Marrowgate Housing, a housing association in Limerick" | The research that would check the employer did not run, so nothing here confirms or doubts it. A small organisation may also simply have a thin web footprint | `[generic]` pattern for organisations of this size, not a claim about this one | Can you point me to this role on your own careers page? | unresolved |
| RR2 | Offer matches the ad | positive_signal | — | "permanent post of Payroll Administrator at €40,000 a year ... hybrid with two days a week" | The role, pay and pattern you were interviewed for are the ones offered | `[grounded]` ad against offer | Who else will be on the payroll team? | noted |
| RR3 | Offer silent on probation, pension, leave and notice | unknown | — | "starting on a date we agree once your notice period ends" | The offer email may not be the full contract | `[inferred]` from what the email omits | Can you send the written terms, including probation, pension scheme and leave, before I give notice? | unresolved |

The request for bank, PPS and passport details after a written offer is a routine step. It has no register entry and nothing in the decision rests on it.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Enter the bank, PPS and passport details only in Marrowgate's own onboarding portal, reached from the address on its own website or confirmed with the People Team on a number you find there. Don't send them as email attachments | Routine step; this is the one check that matters | `[generic]` standard onboarding practice | pending your approval |
| P2 | Within your five working days, ask the People Team for the written terms, then give notice | RR3 | `[grounded]` offer deadline | pending your approval |
| P3 | Confirm Marrowgate on its own website, and on the register of approved housing bodies if the regulator keeps one | RR1 | `[generic]` how housing associations are usually checked | pending your approval |
| P4 | Tell Declan Garvagh plainly that pension changes will be new to you and ask how they are handled. Don't present them as experience you have | R9, truthfulness | `[grounded]` R9 row | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search "Marrowgate Housing Limerick housing association careers" was refused. It would have confirmed the employer and the live role (RR1, contradictions row) |
| 2. Role-family sweep | unavailable | The search "payroll administrator Ireland salary housing association Limerick" was refused. It would have given a market calibration for the pay |
| 3. Hiring manager's public footprint | unavailable | Declan Garvagh was named, but no query was sent after both searches were refused. It would have shaped the scope read and how to position your story for him |

## Dossier offer

If you'd like it, I can save all of this as a `tuesday-dossier.md` you can keep.

## Upgrade menu

- Search access: it would settle RR1, give a market band against the €40,000 offer, and read Declan Garvagh's public professional footprint.
- Your certificate's issuer and syllabus: it would settle R4 and raise R6 to `high`.
- Any pension-related step you did inside a run: it would move R9 from `absent` toward `adjacent`.
- The written terms: they would close RR3.
- Deeper research (up to 5 more searches and 2 more fetches): it only runs if you say so and search is allowed.

## Questions

G1 (R4) — Did the hotel group's payroll run under Irish PAYE, PRSI and USC, and did you do the Revenue filings yourself?

G2 (R9) — Did you ever process pension deductions inside a run, or prepare pension data for your manager, even if the setup was his?

R1, R2 — Are two office days a week in Limerick and €40,000 both fine for you, or is either a limit?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.