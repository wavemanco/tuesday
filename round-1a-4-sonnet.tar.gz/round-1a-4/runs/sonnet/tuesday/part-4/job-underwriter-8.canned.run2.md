Searches are done, so I'm writing up the full assessment now.

# Job underwriting: Remote Order Processing Coordinator, Velloway Logistics

## Decision snapshot

**No, don't go ahead. RR1, RR2, RR3 and RR4 are severe red flags, and this job is very likely a scam. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Pay of at least €30,000 a year)
- `must_have`: direct: R2, R3 · adjacent: R4 (Attention to detail)
- `important`: adjacent: R5 (Order processing work)

R1: the posting's "up to" does not settle your pay floor. R4 (`medium`): adjacent, with accuracy not yet evidenced.

**Opportunity ledger.** The messages ask for a payment (RR1), a cheque deposit with onward transfer (RR2), bank, tax and ID details before any offer (RR3), and a hiring process run wholly by chat (RR4). The contact address is not on a company domain I can place (RR5). The employer could not be established (RR6). The pay is only stated as "up to" (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Pay of at least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the status would only move if the employer were verified independently, through its own website. The employer would then also have to give a written offer from a company address, with a stated guaranteed rate and hours, and ask for no payment, no cheque deposit and no bank, tax or ID details before that offer.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics", a logistics firm hiring remote staff. A search for the name returned nothing | `[grounded]` posting; `[grounded]` search returned no results, so the employer is not established (RR6) |
| Mandate | Process orders from home, 15–30 hours a week, "set your own hours", "no experience needed, full training provided" | `[grounded]` posting |
| Pay as stated | "up to €26 an hour plus commission on every order you process"; no guaranteed rate, no commission terms | `[grounded]` posting |
| Pay arithmetic | €26 an hour reaches €30,000 a year only at about 22 hours a week or more at the top rate. At 15 hours it is about €20,300 a year. At 30 hours it is about €40,600, and only at the top rate | `[inferred]` from the posting's figures |
| Process | Applying, screening, "interview" and the "offer" all happened on Telegram, with no calls or video | `[grounded]` posting and messages |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median base €31,200 a year, interquartile range €28,400 to €34,100. The guide leaves out commission-only and freelance work, so it is a band to expect, never this employer's offer | `[generic]` role-family search, one pay guide |
| Unknowns | Guaranteed hourly rate; commission terms; employee or contractor status; who the "equipment partner" is; the company's registered details | `[grounded]` posting and messages are silent on each |
| Contradictions | None between the posting and the messages. I have not seen the posting live | `[grounded]` the material provided |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your hard constraint) against "up to €26 an hour", 15–30 hours | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because "up to" and a variable hours range do not settle it, and commission terms are absent | `[grounded]` your stated floor and the posting; `[inferred]` arithmetic in role reality | Employer's written terms (RR7); not worth pursuing before RR6 clears |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Confirmed in your message, with no inspectable artifact yet | `[grounded]` your background as stated | none |
| R3 | Good written English | must_have | direct | medium | none | Written Zendesk tickets, about 60 a day. Stated, not inspected | `[grounded]` your background as stated | none |
| R4 | Strong attention to detail | must_have | adjacent | medium | discovery | 60 tickets a day and a maintained tracker are adjacent evidence. You gave no accuracy or error measure | `[grounded]` your background as stated | Optional, only once the employer verifies: any accuracy or quality-check figure |
| R5 | Order processing work (inferred from the title) | important | adjacent | medium | transferability | Parcel-courier ticket handling carries over. Limit: you did not describe entering or processing orders | `[inferred]` from the job title against your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay meeting your floor (R1, hard_gate) | hard_gate | "Up to €26 an hour plus commission", 15–30 hours, no guaranteed figure | It decides whether the role could ever meet your €30,000 floor. The check goes to the employer through its own site, not to you | Not applicable; this is the employer's term to state | A written offer from a verifiable employer giving the hourly rate, minimum weekly hours and employment status | `[grounded]` posting wording |
| G2 | Attention to detail (R4, must_have) | discovery | A busy ticket queue and a tracker, with no accuracy measure | A must-have row, but it would not move the status while RR1 to RR4 stand | Quality or accuracy checks you were scored on; errors you caught in the tracker; reconciling counts between systems | A sanitized tracker sample or a QA score | `[grounded]` your background as stated |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner and we will refund it with your first wages." | A real hire is paid for work, not charged to start. This request is very likely a scam. Don't pay it | `[grounded]` quote; `[generic]` pattern of up-front payment requests | Do you ask new hires to pay for equipment before starting, and who is the "equipment partner"? Ask through contact details on the employer's own website, not the chat | confirmed |
| RR2 | Cheque deposit with onward transfer | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque can show in an account before it has cleared. If it later fails, the money sent on is the account holder's loss. This request is very likely a scam. Don't deposit the cheque | `[grounded]` quote; `[generic]` how cheque clearing works | Do you issue cheques to new hires and ask for part to be sent on? See RR1 for the route | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up" | These came before the "chat interview" and before any written offer. The sender's identity is unresolved. Send none of them | `[grounded]` quote and order of messages; `[generic]` that payroll details follow a credible written offer | At what stage do you collect IBAN, PPS number and ID, and through which portal? See RR1 for the route | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | Interview and offer both happened only in chat, so nothing places who is on the other end | `[grounded]` posting and messages; `[generic]` that real hiring usually includes a verifiable employer contact | Can I speak to a named person at the company by phone or video, using details from your own website? See RR1 for the route | confirmed |
| RR5 | Contact off a company domain | risk_signal | medium | "Any problems, email velloway.hr@postmail.example." | The address is not on a company domain I can identify, so it does not tie the messages to a named employer | `[grounded]` quote; `[inferred]` from the address against my failure to find the employer | What is your company's official website and HR contact address? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The firm may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for employers with no footprint, not a claim about this one | Can you point me at this role on your own careers site, and who I would be interviewing with? | unresolved |
| RR7 | Pay stated as "up to" with undefined commission | unknown | — | "Earn up to €26 an hour plus commission on every order you process" | The guaranteed rate and commission terms are unknown. The top rate sits well above the salaried band's equivalent hourly figure for a "no experience" role | `[inferred]` from the posting against the `[generic]` pay band in role reality | What is the guaranteed hourly rate, the minimum weekly hours and the commission scheme, in writing? | unresolved |

Hold each of these until you have checked it with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from. Who sent them is not yet confirmed. I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send nothing: no IBAN, no PPS number, no passport photo, no €349 | See RR1 and RR3 | `[grounded]` register | pending your approval |
| A2 | If a cheque arrives anyway, don't lodge it and don't send any part on | See RR2 | `[grounded]` register | pending your approval |
| A3 | Look up the company yourself and use only contact details from its own site. If you can't find any, treat the employer as unestablished | See RR6 | `[grounded]` register | pending your approval |
| A4 | Report the posting to the jobs site. If you've shared anything beyond your interview answers, tell your bank | Reporting a posting alerts other job seekers, and a bank can act on shared account details | `[generic]` common practice | pending your approval |
| A5 | Put your effort into openings with a verifiable employer, a written offer from a company address and a stated salary or fixed hourly rate. Your support-desk, tracker and training background fits that kind of work | See R2 to R5 | `[inferred]` from the map's fit rows | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics" and got no results, so the employer is not established (RR6). Role reality's organization row |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland salary hourly rate", which returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide). It gave the market calibration `[generic]` and the pay comparison in RR7 |
| 3. Hiring manager's public footprint | n/a | No name was given, only a chat handle, so there was no query to form |

I can also write this up as a saved `tuesday-dossier.md` if you want a record.

## Upgrade menu

- The link to the original posting and the name of the jobs site → RR6 and RR5 can be checked against the live listing.
- A written offer from a verifiable employer, stating rate, hours and employment status → R1 and RR7 close.
- A named hiring contact → role reality's scope read, and a name to verify.
- A deeper research pass on this employer (up to 5 more searches and 2 more fetches) → RR6 might resolve. Say the word and it runs.

## Questions

1. (RR6) Do you still have the link to the original posting, or the name of the jobs site? Does it show a company website or address?
2. (RR3) Beyond your answers to their interview questions, have you given them any other personal details or documents, such as your address, phone number or a photo?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.