Searches are done, so here is the full assessment.

**No, don't go ahead, and send nothing yet. RR1, RR2, RR3 and RR4, all four `severity: high`, are requests in these messages. Status: `no_go`.**

This job is very likely a scam. Don't deposit the cheque, and don't send your IBAN, PPS number or passport photo. I can't establish the firm from here (RR5). The details you already have ready aren't needed at this stage, so don't paste them anywhere, and I won't repeat them here.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Earn up to €26 an hour)
- `must_have` — direct: R3 · adjacent: R2 (Strong attention to detail), R4 (Good written English)
- `important` — unclear: R5 (A quiet place to work)

R1 — the posting does not settle your pay floor; R3 (`medium`) — confirmed, no artifact yet; R2, R4 — adjacent, limits named in the map.

**Opportunity ledger.** The role asks for bank, tax and ID details before any written offer (RR1), for you to pay for equipment (RR2) and to deposit a cheque and pass money on (RR3). It also runs the whole hiring process in chat (RR4). On top of that, the employer is not established (RR5), the HR contact is on a mail-service domain (RR6) and the pay is "up to" with no floor (RR7).

- **Hard gates:** none failed; unconfirmed: R1 (Earn up to €26 an hour).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:**
  - No payment, deposit or ID or bank details requested before a written offer.
  - A live interview with an identifiable person.
  - The role live on the employer's own careers site.
  - The pay floor stated in writing.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | "Velloway Logistics"; no website or careers page found | `[grounded]` search returned no results |
| Mandate | Process orders remotely, 15–30 hours a week, set your own hours | `[grounded]` posting |
| Pay as posted | "up to €26 an hour plus commission"; no floor and no commission terms | `[grounded]` posting |
| Hiring process | Telegram only, no calls or video | `[grounded]` posting and messages |
| Market calibration | Salaried order-processing and customer-operations coordinators in Ireland: median €31,200 a year, interquartile range €28,400 to €34,100. The guide excludes commission-only and freelance work, so it is a pattern and not this employer's offer. | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide, from the search snippet |
| Unknowns | Employer's legal identity and address, contract type, commission terms, who would interview you | — |
| Contradictions | No careers page exists to compare the posting against | `[grounded]` search returned no results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your floor) against "up to €26 an hour", 15–30 hours | hard_gate | unclear | high | hard_gate | Confidence grades your own stated floor. Fit is `unclear` because "up to" gives no guaranteed rate. At €26 an hour, 15 hours a week comes to about €20,300 a year and 30 hours to about €40,600. Reaching €30,000 at the top rate needs roughly 22 hours a week every week. | `[grounded]` your floor and the posting's figures | Moot while RR1 to RR4 stand. |
| R2 | Strong attention to detail | must_have | adjacent | medium | transferability | You handle about 60 Zendesk tickets a day, which shows volume. You haven't stated accuracy outcomes, so the limit is that volume isn't precision. | `[grounded]` your stated background, prose only | None needed now. |
| R3 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. This is confirmed but has no artifact yet. | `[grounded]` your stated background | None needed now. |
| R4 | Good written English | must_have | adjacent | medium | transferability | Ticket handling is the closest evidence, and written replies aren't stated. The limit is that I haven't seen what you wrote. | `[grounded]` your stated background | None needed now. |
| R5 | A quiet place to work | important | unclear | low | discovery | You haven't said either way. | `[grounded]` silence in your message | None; it doesn't affect the decision. |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Guaranteed pay against your €30,000 floor (R1, hard_gate) | hard_gate | The posting gives only a ceiling rate and a range of hours | It decides whether the pay gate is met, though RR1 to RR4 decide the status first | Not applicable; this is a term of the role | A written offer from the employer's own domain stating rate and guaranteed hours | `[grounded]` posting wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Identity and bank details requested before any offer | red_flag | high | "please send your IBAN, your PPS number and a clear photo of your passport" | These details are asked for ahead of any written offer, and the sender's identity is unresolved. | `[grounded]` the quoted message | Do you ask applicants for bank, tax or passport details before a written offer, and did you post this role through this Telegram account? | confirmed |
| RR2 | Payment demanded for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | You are asked to pay for work equipment. | `[grounded]` the quoted message | Does your company ask new hires to pay for equipment, and who is the equipment partner? See RR1 for the route. | confirmed |
| RR3 | Cheque to deposit, with funds passed on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | You are asked to deposit a cheque and send most of it on to a third party. | `[grounded]` the quoted message | Did your company issue this cheque, and why would a new hire forward part of it? See RR1 for the route. | confirmed |
| RR4 | Hiring run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews." | No live interview takes place, so nothing places who is hiring. | `[grounded]` the posting | Can you arrange a live interview, and tell me who would conduct it? See RR1 for the route. | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR6 | HR contact on a mail-service domain | risk_signal | medium | "Any problems, email velloway.hr@postmail.example" | The contact sits outside any employer domain I could find, so the messages may not come from who they name. | `[inferred]` from the address against the absence of any employer site | Can you confirm this HR address from an address on your own company domain? | unresolved |
| RR7 | Pay stated only as a ceiling | unknown | — | "Earn up to €26 an hour plus commission on every order you process" | Rate, guaranteed hours and commission terms are all unstated. | `[inferred]` from the posting's wording against the `[generic]` band in role reality | What is the guaranteed hourly rate and the weekly hours, and how is commission calculated? | unresolved |

Hold each of these until you have checked it with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from; who sent them is not yet confirmed.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Send no IBAN, PPS number or passport photo, pay nothing, and don't lodge the cheque. | See RR1, RR2 and RR3. | `[grounded]` register | pending your approval |
| A2 | If you want to check, find the company's own website yourself, use contact details from it, and ask the RR1 question. | See RR1 to RR5. | `[grounded]` register | pending your approval |
| A3 | Keep screenshots of the posting and chat in case you decide to report them. | Records help if you report. | `[generic]` common practice | pending your approval |
| A4 | If you have already sent anything beyond what you've told me, contact your bank promptly. | Limits harm after any disclosure. | `[generic]` common practice | pending your approval |
| A5 | Put your effort into openings that state a salary at or above €30,000. Your Zendesk volume (R2, R4) and Excel tracker (R3) are the evidence to lead with. | Your floor against the market band (R1). | `[grounded]` your background; `[generic]` band | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics careers Order Processing Coordinator" and got no results, so the employer is not established. This feeds RR5. |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator Ireland salary typical hourly rate". It returned "Pennoral 2026 Ireland Customer Operations Pay Guide" (pennoral.example/2026-ireland-customer-operations-pay-guide), which I read as a snippet and didn't fetch. This feeds the market calibration and RR7. |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. |

Extra, on your approval: I can draft a short message declining to continue, for you to send or not. It would add a clean exit, and it is useful here because the chat is still open.

If you want, I can save this as `tuesday-dossier.md` so you can reuse it later.

**Upgrade menu**

- A link to the company's own site or careers page: it could close RR5, and it would tell us whether the posting is live.
- A written offer on letterhead, from an address on the company's own domain: it could close RR6, RR7 and G1.
- Your CV: it would raise R2 to R4 beyond prose-only confidence, though that doesn't matter for this role.
- A deeper research pass (up to 5 more searches and 2 more fetches): say the word and it runs.

No questions this turn, since the decision is stable.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.