I've run four searches and they cover the company, the live posting, the salary band and Ronan. Next I'll fetch the careers page to compare it with the posting you pasted.
# Job Underwriting Assessment: Product Designer at Fernquay

## Decision snapshot

**Yes to both on what I could check. Fernquay and this posting match the company's own pages (role reality; RR3, RR4). The fit is real, with R7, R8 and R9 adjacent. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Salary €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (Research calls with school owners), R9 (Be the first designer)

R7 — checkout is one stage, limit named; R8 — usability sessions are not owner calls; R2 — your pay floor is not yet given.

**Opportunity ledger.** The employer, the posting and the pay band line up (RR3, RR4). Three things stay open: the equity terms (RR1), whether a customer-funded team of six has room for a first design hire (RR2), and who reviews design work (RR5). The WhatsApp scheduling is routine and takes no register entry (role reality, Contact channel).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay meets your floor (R2); (2) the equity terms and runway are answered on the call (RR1, RR2); (3) R7, R8 and R9 are framed as adjacent, never as end-to-end ownership, owner discovery research or lone-designer experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway. It makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Founded 2023 by Ronan Kehoe and Saoirse Doyle, and funded by its customers | `[grounded]` search result for the company's About page (snippet only) |
| Posting is live | The careers page lists this role as "our first design hire", hybrid two days a week in Galway, €52,000–€60,000 plus equity, applying with one real project | `[grounded]` careers page fetched |
| Contradictions | None on pay, work pattern or first-hire status between your pasted posting and the careers page. That page is shorter, so the requirements list and the 0.5–1% equity are not confirmed by it | `[grounded]` fetched page against your pasted text |
| Hiring contact | Ronan Kehoe is named as co-founder on both your posting and the About snippet. A profile snippet says he is co-founder and CEO and was previously a product lead at a Galway travel-software company for five years. The About snippet does not state Saoirse's title, so "CTO" rests on his message alone | `[grounded]` search snippets; one snippet each, I did not verify that the profile is his |
| Contact channel | The message asks for a 45-minute video call and nothing else: no payment, no documents, no personal or bank details. Scheduling by chat with the invite sent by email is ordinary for a small team | `[grounded]` your message; `[generic]` that small teams often schedule by chat |
| Scope read | A broad first-designer remit: the booking flow, research calls and shipping with two engineers, with no design peer | `[inferred]` from the posting's three duties and "first designer" |
| Market calibration | Product designers with 3–5 years in Ireland: median €57,000, interquartile range €51,500–€62,000 (n=520, 2026). The posted €52,000–€60,000 sits inside that range. The band is Ireland-wide, not Galway-specific, and the equity is on top and unvalued | `[generic]` one salary-report result; `[grounded]` the posting's figure |
| Unknowns | Equity terms; runway; who reviews design work; your own pay floor | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days fit. You have stated no constraint of your own on this | `[grounded]` your background | none |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | none | hard_gate | The posting states the pay. You have not given a floor, so whether it meets your need is not established | `[grounded]` posting; no floor stated | G1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | You state 4 years as a product designer at a Dublin travel-booking company. It is confirmed and specific, with nothing inspectable yet | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | You state daily use. A portfolio or case study would be the inspectable proof in design | `[grounded]` your background | offer: share the checkout case study for `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You state monthly usability sessions with customers. The kind of research is usability testing, which is what you stated and no more | `[grounded]` your background | offer: a research readout would raise it |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers; the posting has two | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned your company's checkout flow. Limit: checkout is one part of a booking flow, and ownership of the stages around it is not stated | `[grounded]` your checkout sentence; `[generic]` that a booking flow spans more than checkout | G2 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Usability sessions are credible adjacent work. Limit: they are not discovery calls, and it is not stated whether your participants were business customers | `[grounded]` your sessions; `[inferred]` the discovery-versus-usability difference | G3 |
| R9 | Work as the first designer, with no design peer (inferred requirement) | important | adjacent | medium | transferability | You have always worked in a squad and have never been the only designer. That is adjacent, and the limit is no evidence of setting direction without design peers | `[grounded]` your statement; basis: the posting's "first designer" | positioning line in A3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay floor (R2, hard_gate) | hard_gate | The posting states €52,000–€60,000. Your floor is unknown, so the gate is open | A hard gate: the decision cannot move to `go` until it is answered | A minimum base, with or without the equity counted | None needed; your own word | `[grounded]` no floor given |
| G2 | End-to-end booking flow (R7, must_have) | transferability | You redesigned the checkout flow. Stages before and after checkout are not described | Ownership of the whole flow is the posting's first duty, so a stronger bridge narrows the likeliest objection | Availability or selection screens, confirmation or change-booking flows, or the admin side of a booking tool | The checkout case study with its before and after | `[grounded]` your sentence; `[generic]` that the objection is likely |
| G3 | Owner research calls (R8, important) | transferability | Monthly usability sessions with customers, with the participants and method unstated | The role runs research calls with school owners, who are business customers | Interviews with business customers, calls where findings changed a design, or a research summary others used | A research readout or session guide | `[grounded]` your background; `[inferred]` that this is the gap |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Equity terms not stated | unknown | — | "0.5–1% equity" | The percentage's value depends on vesting, strike price and share class, none of which the posting gives | `[inferred]` from a percentage range with no terms | What are the vesting schedule, cliff and strike price for the 0.5–1%, and where in the range would this role sit? | unresolved |
| RR2 | Runway for a first design hire | unknown | — | "funded by its customers" | A seventh salaried hire comes from customer revenue, and its runway is not stated | `[inferred]` from the About page's funding line | How is this hire funded, and how many months of runway does the team have at current revenue? | unresolved |
| RR3 | Pay stated and inside the market band | positive_signal | — | "€52,000–€60,000" | The band sits inside the Ireland-wide range for 3–5 years | `[grounded]` posting figure; `[generic]` one salary-report band | Is the band fixed, and where would my experience place me in it? | noted |
| RR4 | Posting matches the company's own careers page | positive_signal | — | "Open now: Product Designer, our first design hire." | The role is live and described the same way in both places | `[grounded]` careers page fetched | What does the process after this call look like, and who would I meet? | noted |
| RR5 | Design review and priorities unclear | unknown | — | "You will work most closely with our co-founder, Ronan Kehoe." | As the first designer you may have no one who reviews design work | `[inferred]` from "first designer" and the single named collaborator | Who reviews design work, and who decides priority when design and engineering disagree? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before clicking the video link, check that the emailed invite comes from a fernquay.example address, the domain on the careers page's jobs address | A routine check on a routine step | `[grounded]` careers page address | pending your approval |
| A2 | On the call, ask the RR1, RR2 and RR5 questions verbatim, and ask for the pay and equity terms in writing afterwards | The register doubles as call preparation | `[grounded]` register | pending your approval |
| A3 | Proposed lines, each traced to your own sentences: "I redesigned the checkout flow at a Dublin travel-booking company." "I ran monthly usability sessions with customers." "I have always worked in a squad with four engineers; this would be my first time as the only designer." | They state R7, R8 and R9 at their true strength | `[grounded]` your background | pending your approval |
| A4 | Lead with the checkout redesign when talking to Ronan | He is described as a former product lead at a travel-software company | `[inferred]` from one profile snippet | pending your approval |
| A5 | If your employer allows it, bring one sanitized usability-session artifact alongside the case study | The careers page asks for "one real project" and your posting prefers a messy real one to a polished deck | `[grounded]` careers page and posting | pending your approval |

Interview rehearsal for the video call is a separate module, mock-interview, if you want it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway", which returned "About Fernquay" (fernquay.example/about), and "Fernquay product designer Galway careers"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). It moved role reality's organization, posting-is-live and contradictions rows. The employer was established, so no standing risk entry was made |
| 2. Role-family sweep | yes | Searched "product designer salary Galway Ireland startup mid-level", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). It moved the market calibration row and RR3 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). It moved role reality's hiring-contact row and A4 |

I can produce `tuesday-dossier.md` of this assessment whenever you want to keep it.

## Upgrade menu

- Your pay floor and any other terms you won't bend on (office days, start date) → R2 and G1 close, and the hard-gates line stops flagging unknown constraints.
- The checkout case study or a portfolio link → R4, R5 and R7 can move toward `high`.
- A research readout or session guide → R5 and R8 firm up.
- Fernquay's answers on equity and runway → RR1 and RR2 close, and the decision likely simplifies to `go`.
- A deeper research pass on Fernquay (funding, customers, leadership history; up to 5 more searches and 2 more fetches) — say the word and it runs.

G1 — What base salary would you need for this to work, and would the equity change that?

G2 — In your checkout redesign, which parts of the booking journey before or after checkout did you personally own or influence?

G3 — In your usability sessions, who were the participants, and did any session change a design decision?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.