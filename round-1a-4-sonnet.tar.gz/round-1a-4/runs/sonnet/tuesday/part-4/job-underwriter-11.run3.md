Web search was denied, so I'm working only from your pasted postings and background. Here is each role assessed on its own.

# Role A: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

## Decision snapshot

**Yes, this one is worth your time. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: A1 (Hybrid, three days in Rotterdam office)
- `must_have`: direct: A2, A3, A4
- `important`: direct: A5, A7 · adjacent: A6 (Temperature compliance tracking)
- `preferred`: adjacent: A8 (Dutch a plus)

A6: on-time tracking carries over, temperature compliance is unexercised; A8: conversational Dutch, level unconfirmed.

**Opportunity ledger.** The scope is concrete (AR3), but the employer could not be checked from here (AR1) and the posting gives no pay (AR2).

- **Hard gates:** none failed; unconfirmed: A1 (Hybrid, three days in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and live posting verify (AR1); (2) three office days in Rotterdam work for you (A1); (3) you present the temperature-compliance gap as adjacent and never as direct experience (A6).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, a refrigerated-fleet operator. Not verified | `[grounded]` posting header |
| Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| Scope read | An analyst post that feeds depot managers' decisions, with no sign of line management or budget ownership | `[inferred]` from the responsibilities list and the absence of any people or budget language |
| Market calibration | Not established. The salary search was refused | `[generic]` no band available |
| Unknowns | Salary, team size, who the analyst reports to, the temperature-data source systems | `[grounded]` none stated in the posting |
| Contradictions | None found within the posting. No second source was checked | `[grounded]` posting only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You are in Amsterdam and have stated no limit on location or office days, so the gate is open. Confidence grades your statement of a constraint, and none was given | `[grounded]` posting term; no candidate constraint supplied | Ask whether the commute works (closing question) |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as an operations analyst at a parcel carrier, which is logistics. This is typed self-report with no inspectable artifact yet | `[grounded]` your background, prose | none |
| A3 | Strong SQL | must_have | direct | medium | none | You use SQL daily. "Strong" is a level nobody has probed, so confidence stays at the intake ceiling | `[grounded]` your background, prose | A sanitized query or schema walk-through would raise it to high |
| A4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard your depot managers use | `[grounded]` your background, prose | A dashboard screenshot with figures removed would raise it to high |
| A5 | Track on-time delivery | important | direct | medium | none | You built the on-time delivery dashboard. This is the same metric the posting names, with no cold-chain context | `[grounded]` your background, prose | none |
| A6 | Track temperature compliance across a refrigerated fleet | important | adjacent | low | transferability | Compliance-style metric tracking carries over. Nothing you have said touches temperature or cold-chain data, so the limit is that this metric is unexercised. Taking the lower band because the bridge is inference | `[inferred]` from your on-time work; `[generic]` that temperature logs are a different data shape from delivery scans | Closing question on any quality or SLA metrics you have tracked |
| A7 | Work with depot managers on route changes | important | direct | medium | none | Depot managers use your dashboard and you ran the weekly route-performance review | `[grounded]` your background, prose | none |
| A8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch, short of fluent. The posting calls it a plus, not a requirement | `[grounded]` your statement; `[grounded]` posting wording | Closing question on what you can do in Dutch |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Temperature compliance (A6, important) | transferability | On-time delivery and route reviews are confirmed. Nothing on temperature or cold-chain data | It is the one responsibility in the posting your background does not touch | Tracking parcels with handling conditions (fragile, perishable, pharma or food); service-level breach reports; exception or audit reporting | A sanitized exception dashboard or breach report | `[grounded]` background silent on temperature; `[inferred]` that a bridge exists through compliance-style metrics |
| GA2 | Office days (A1, hard_gate) | hard_gate | No statement of your location or schedule limits | A failed gate would end this role whatever your fit | None applicable. Only your own constraint settles it | None | `[grounded]` no constraint given |
| GA3 | Dutch level (A8, preferred) | transferability | "Conversational" only | A plus, so it will not decide the role. It could matter for depot-manager conversations | Reading ops reports in Dutch; talking route changes with Dutch-speaking staff | None | `[grounded]` your wording |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| AR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The check could not run because search was denied | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be working with? | unresolved |
| AR2 | Pay not stated | unknown | — | Posting contains no salary figure | The figure may sit anywhere relative to what you need, and its absence leaves that unknown | `[grounded]` posting is silent | What salary range is budgeted for this post? | unresolved |
| AR3 | Concrete outcomes and tools named | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | The scope is specific and matches tools you already use | `[grounded]` posting | Who consumes the weekly dashboards, and what decisions do they drive? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your resume with the on-time delivery dashboard and the weekly route-performance review, in your own wording | see A4, A5, A7 | `[grounded]` your background | resume_edits_pending_approval |
| Q1 | Ask the questions in AR1, AR2 and AR3 verbatim at the first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Check the posting on Duinvaart's own careers page before sending anything | see AR1 | `[grounded]` AR1 | pending your approval |
| A2 | Be ready to say plainly that temperature compliance is new to you and on-time tracking is the nearest work | see A6 | `[grounded]` A6 row | pending your approval |

# Role B: Supply Planner, Kroonhaven Foods (Utrecht)

## Decision snapshot

**No, this one is not worth your time as it stands. B2, B4 and B6, all must-haves, have no evidence behind them. Status: `no_go`.**

**Fit ledger.**

- `hard_gate`: unclear: B1 (On-site in Utrecht)
- `must_have`: adjacent: B5 (Fluent Dutch) · unclear: B3 (Advanced Excel) · absent: B2 (3+ years planning in FMCG), B4 (SAP IBP or similar planning system), B6 (Own the 13-week supply plan)
- `important`: adjacent: B7 (Run the weekly S&OP meeting)

B2, B4, B6: no planning evidence; B7: the weekly review you ran is a bridge with a named limit.

**Opportunity ledger.** The employer could not be checked from here (BR1) and the posting gives no pay (BR2).

- **Hard gates:** none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** documented supply or demand planning work in FMCG (B2, B6), hands-on use of a planning system (B4), and Dutch you can work in at fluent level (B5). Without those the status stays `no_go`.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, chilled ready-meals. Not verified | `[grounded]` posting header |
| Mandate | Own the 13-week supply plan, balance capacity against forecast, run the weekly S&OP meeting | `[grounded]` posting |
| Working pattern | On-site in Utrecht | `[grounded]` posting |
| Scope read | An ownership role, not a support one. The planner holds the plan and chairs the cross-functional meeting | `[inferred]` from "own" and "run" in the responsibilities |
| Market calibration | Not established. Search was refused | `[generic]` no band available |
| Unknowns | Salary, team, planning-system version, commute arrangement | `[grounded]` none stated |
| Contradictions | None found within the posting | `[grounded]` posting only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No statement of your location or commute limits, so the gate is open | `[grounded]` posting term; no candidate constraint supplied | none, since the decision does not turn on it |
| B2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You have said you have never worked in planning. Four years of analytics is related work, not planning. The posting's own "FMCG" framing also differs from parcel logistics | `[grounded]` your statement; `[inferred]` that parcel analytics is not FMCG planning | Closure path: planning-adjacent role first, or a demand-planning course plus a worked forecast |
| B3 | Advanced Excel | must_have | unclear | low | discovery | Excel is not mentioned in your background, though SQL and Power BI work usually involves it | `[grounded]` background silent; `[generic]` that analysts typically use Excel | A model or workbook sample would settle it |
| B4 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are reporting tools, not planning systems | `[grounded]` your background | Closure path: vendor training or sandbox exposure |
| B5 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational Dutch is confirmed. Fluency is a different level, and the posting makes it a requirement | `[grounded]` your statement and posting | The level you could reach, and by when, is yours to judge |
| B6 | Own the 13-week supply plan, balancing capacity against forecast | must_have | absent | none | capability | No planning ownership in your history | `[grounded]` your statement | Closure path as B2 |
| B7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: it did not cover forecast against capacity, or sales, production and finance in one forum | `[grounded]` your background; `[inferred]` the S&OP content difference from the posting's wording | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GB1 | Planning ownership and systems (B2, B4, B6, must_have) | capability | No planning role, no planning-system use | Three must-haves with no evidence decide the status | A recognised closure path would be a planning-adjacent role, or training in a planning system | A completed planning course or a worked 13-week forecast | `[grounded]` your statement that you have never worked in planning |
| GB2 | Fluent Dutch (B5, must_have) | transferability | Conversational level | A requirement, not a plus | Meetings or reports you handle in Dutch | None | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| BR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. The check could not run because search was denied | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be working with? | unresolved |
| BR2 | Pay not stated | unknown | — | Posting contains no salary figure | The figure is unknown, so pay cannot be checked against your needs | `[grounded]` posting is silent | What salary range is budgeted for this post? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Put your effort into other openings. If you apply anyway, ask the BR1 and BR2 questions first | see B2, B4, B6 | `[grounded]` map rows | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht"; both were refused and returned nothing. It would have moved role reality's organization and contradictions rows and the employer entries AR1 and BR1 |
| 2. Role-family sweep | unavailable | Searched "operations analyst salary Rotterdam logistics Power BI SQL"; refused, nothing returned. It would have moved the market calibration rows and the pay entries AR2 and BR2 |
| 3. Hiring manager's public footprint | n/a | No hiring-manager name was given, so there was no query to form |

## Upgrade menu

- Allow web search (up to 5 searches and 2 fetches) → AR1 and BR1 can close, and the market band fills AR2, BR2 and the calibration rows.
- A sanitized SQL sample or dashboard screenshot → A3 and A4 reach `high`.
- Any quality, SLA or exception metric you have tracked → A6 moves from `low`.
- A hiring-manager name for either role → the scope read and the lead story in the plan.

I can also save this as `tuesday-dossier.md` if you want it for later.

Questions (the id in each is the gap row it comes from):

GA2: Is three days a week in Rotterdam from Amsterdam workable for you, or do you have a limit on commute or office days?

GA1: Have you tracked any quality, service-level or handling-condition metrics, such as perishable or temperature-sensitive parcels, in your dashboards or reviews?

GA3: What can you do in Dutch at work today, for example read an ops report or talk through a route change with depot staff?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.