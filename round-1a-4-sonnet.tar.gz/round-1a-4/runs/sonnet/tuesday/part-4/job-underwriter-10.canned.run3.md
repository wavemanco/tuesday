I'm running the employer check and a salary sweep now, then I'll write up the assessment.
## Decision snapshot

**Yes, worth applying and taking the call. Fernquay's own pages match the posting (RR1) and the contact route asks for nothing risky. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52,000–€60,000)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (First designer, no design peers)

R7 — checkout is one part of a booking flow, limit named; R8 (`medium`) — adjacent only, you have never been the sole designer.

**Opportunity ledger.** The employer exists as described and the pay sits inside a market band (RR1, RR2). Equity terms, runway and who decides on design are all unanswered (RR3, RR4, RR5). The WhatsApp message asks only for a call time, a routine step, so it takes no register entry.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay range clears your own floor, which I haven't been given (R2); (2) the equity terms are explained (RR3); (3) you're comfortable being the only designer, with a co-founder as your closest partner (R8, RR5).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland. Six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers | `[grounded]` fernquay.example/about |
| Mandate | First design hire: own the booking flow, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting and careers page |
| Pay | €52,000–€60,000 plus 0.5–1% equity; the equity terms are not stated | `[grounded]` posting |
| Scope read | Wide for one person: design, research and delivery with no design peer or lead | `[inferred]` from "first designer" against the responsibilities listed |
| Market calibration | A 2026 Irish survey (n=520) puts designers with 3 to 5 years at a median base of €57,000, interquartile range €51,500–€62,000. The posted range sits inside it. The survey is national, not Galway-specific, and is a band to expect, not this employer's offer | `[generic]` Tillerby 2026 salary report; `[grounded]` posting for the range |
| Hiring manager | Ronan Kehoe is co-founder and CEO, and was previously a product lead at a Galway travel-software company for five years | `[grounded]` public profile |
| Unknowns | Equity terms; runway; who has the final say on design; who else is on the call | — |
| Contradictions | None between the posting, the careers page and the about page | `[grounded]` pages fetched or returned by search |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You said you moved back to Galway last year, so the office days fit. Self-reported, nothing to inspect | `[grounded]` your message | none |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | You haven't told me a floor, so whether the pay meets it can't be settled. The range itself is in the survey band | `[grounded]` posting; no floor given | Ask for your floor (closing question G3) |
| R3 | 3+ years of product design | must_have | direct | medium | none | You describe 4 years at a Dublin travel-booking company. Years of experience is a requirement, not a gate. No CV or portfolio read yet, so `medium` | `[grounded]` your background summary | A portfolio or CV link would raise it |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use stated. Nothing inspectable yet | `[grounded]` your summary | A Figma file or case study |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. The posting's calls are with school owners, a business audience. If your customers were consumers, that is a difference in audience, not in method | `[grounded]` your summary; `[inferred]` the audience difference | Say who the customers were |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers. The posting has two | `[grounded]` your summary | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow. That is credible but it is one part of a booking journey, and I don't know how much of it you owned beyond the redesign. Limit: no stated work on discovery, scheduling or availability | `[grounded]` checkout redesign; `[inferred]` that checkout is one step of a booking flow | See G1 |
| R8 | Work as the only designer | important | adjacent | medium | transferability | You have never been the only designer. The adjacent evidence is your own research sessions and a flow redesign inside a squad. Limit: you haven't set direction or run design alone | `[grounded]` your statement; the requirement is `[inferred]` from "first designer" | See G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Owning the booking flow end to end (R7, must_have) | transferability | A checkout redesign and monthly usability sessions; nothing on the steps before checkout | R7 is a `must_have` row at `adjacent`, and "own end to end" is the posting's headline responsibility | Deciding what to build next in a flow; changing search, availability or booking-confirmation screens; working with engineers on a flow beyond one screen | A before-and-after of the whole journey, or a flow map | `[grounded]` your summary; `[inferred]` that the posting's headline duty is the likeliest probe |
| G2 | Working as the only designer (R8, important) | transferability | Squad work only | Moving from a design-peer environment to none changes the job | Setting design standards; running a research programme yourself; deciding design questions without review | A project where you led design decisions | `[grounded]` your statement |
| G3 | Pay against your own floor (R2, hard_gate) | hard_gate | The posting's range; no floor from you | Only you can say if the range works | — | Your salary and your floor | `[grounded]` no floor given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer matches the posting | positive_signal | — | "six people, based in Galway ... founded 2023 by Ronan Kehoe and Saoirse Doyle" | The company exists as the posting describes. Both pages are the firm's own, so they confirm consistency, not independent standing | `[grounded]` about and careers pages | Who besides you and Saoirse will be on the call? | noted |
| RR2 | Pay inside the market band | positive_signal | — | "€52,000–€60,000 plus equity" | The range is stated up front and sits within the survey's interquartile range | `[grounded]` posting; `[generic]` survey band | Where in the range would my experience place me? | noted |
| RR3 | Equity terms not stated | unknown | — | "0.5–1% equity" | Vesting, share class, dilution and any exercise cost are all unstated, so the equity can't be valued | `[inferred]` from the posting's silence | What are the vesting schedule, share class and exercise terms behind the 0.5–1%? | unresolved |
| RR4 | Runway of a customer-funded firm | unknown | — | "funded by its customers" | Salary and equity both rest on customer revenue, and runway isn't stated | `[inferred]` from the about page and silence on runway | How many months of runway does current revenue give, with this hire included? | unresolved |
| RR5 | Final say on design unclear | unknown | — | "own the booking flow end to end ... work most closely with our co-founder" | It is unclear who decides when you and the co-founder disagree, and who reviews your work | `[inferred]` from "first designer" and no design lead stated | When you and Ronan disagree on a design decision, who makes the call? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the calendar invite came from a fernquay.example address and matches the jobs@ contact on the careers page. If it doesn't, ask them on that address | Your check, and a cheap one; the WhatsApp scheduling itself is routine | `[generic]` small firms often schedule informally; `[grounded]` careers page contact | pending your approval |
| A2 | Ask RR3, RR4 and RR5 verbatim on the call, and RR2 if the range isn't discussed | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Describe the checkout redesign and the research sessions in your own terms, saying what was yours and what was the squad's. Don't present them as owning a whole booking journey or as a sole-designer record | R7 and R8 are `adjacent`, and a probe will test the limit | `[grounded]` your summary | pending your approval |
| A4 | Expect your travel-booking background to land with Ronan, who comes from travel software | His public profile | `[inferred]` from the profile | pending your approval |

If you want to prepare for the 45-minute call with Ronan and Saoirse, the mock-interview module can do that.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers"; fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer) and read "About Fernquay" (fernquay.example/about) in the results. Moved role reality's organization row and RR1: they match the posting |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland startup 3-5 years experience Galway", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved market calibration and RR2 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved role reality's hiring-manager row and A4 |

## Upgrade menu

- Your CV or portfolio link would take R3, R4 and R5 toward `high` and show how much of the checkout flow you owned (R7).
- Your salary floor would settle R2.
- Fernquay's answers on equity, runway and design authority would close RR3, RR4 and RR5.
- A deeper research pass on Fernquay (news, public customer reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you want, I can write this up as a `tuesday-dossier.md` you can carry into interview prep.

Questions:

G3 — What is the lowest salary you'd accept, and does €52,000–€60,000 plus equity clear it?

G1 — In the checkout redesign, which parts of the booking journey did you own, and what did you decide yourself versus with the squad?

G2 — Has there been a project where you made design decisions without a design peer reviewing them? What happened?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.