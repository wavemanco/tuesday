Search permission wasn't granted, so none of this comes from outside research. It rests only on what you pasted.

## Decision snapshot

**Yes, it's normal. Asking for these details after a written offer is routine, and the role is worth accepting on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Two days a week in Limerick office), R2 (Salary €38,000–€42,000), R3 (Right-to-work check)
- `must_have`: direct: R4, R6, R7 · unclear: R5 (Irish PAYE, PRSI and USC)
- `important`: direct: R9, R10 · adjacent: R8 (Monthly payroll for 240 staff) · unclear: R12 (Staff payroll queries) · absent: R11 (Pension changes)

R5: your payroll's tax jurisdiction isn't stated; R8: a credible bridge, limit named (fortnightly, 90 staff); R11: never done, so it needs a handover.

**Opportunity ledger.** The offer is concrete and repeats the advertised role, band and hybrid terms (RR1). Two things are still unwritten: who handles pension changes (RR2) and the terms beyond pay (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Two days a week in Limerick office), R2 (Salary €38,000–€42,000), R3 (Right-to-work check); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R1, R2 and R3 work for you; (2) your hotel payroll ran under Irish PAYE, PRSI and USC (R5); (3) a handover for pension changes is agreed (R11, RR2). The onboarding steps are not a condition.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick, 240 staff. I haven't checked the employer online. | `[grounded]` JD; you interviewed twice at their office |
| Mandate | Monthly payroll, starters, leavers, pension changes, monthly ledger reconciliation, staff queries | `[grounded]` JD |
| Terms | Permanent, €40,000, hybrid two days in Limerick. The pay is the middle of the advertised €38,000–€42,000 band. The offer matches the JD on title, pay band and hybrid terms. | `[grounded]` JD and offer email |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer email |
| Onboarding steps | The offer asks for nothing yet. After you accept, a portal link collects bank details (salary), PPS number (Revenue) and a passport scan (right-to-work), with the original passport on day one. | `[grounded]` offer email; `[generic]` these are normal onboarding items for an Irish employer, requested after an offer. The requests to refuse are the ones made before any offer, or for fees or payment. |
| Scope read | Monthly cycle and roughly 2.7 times your headcount (240 against 90) | `[inferred]` from your 90-staff fortnightly figure against the JD |
| Market calibration | Not done, because search was refused. €40,000 is not compared against a market band. | none |
| Unknowns | Probation, notice, hours, leave, pension scheme, payroll software, whether payroll is a team or a sole role | `[grounded]` offer and JD silent |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in the Limerick office | hard_gate | unclear | none | hard_gate | The JD and offer state the term. You haven't said whether it works for you, and confidence grades your own statement. | `[grounded]` JD and offer | G1 question |
| R2 | Salary €38,000–€42,000 (offered €40,000) | hard_gate | unclear | none | hard_gate | The offer is inside the band. Your pay floor wasn't stated. | `[grounded]` JD and offer | G1 question |
| R3 | Right-to-work check (passport scan, original on day one) | hard_gate | unclear | none | hard_gate | The offer makes it a step of starting. Your status wasn't stated. | `[grounded]` offer | G1 question |
| R4 | 2+ years running payroll | must_have | direct | medium | none | 3 years of fortnightly payroll for 90 staff, from your own account with nothing inspected | `[grounded]` your background | none |
| R5 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Your background doesn't say which country's tax rules the hotel payroll ran under | `[grounded]` background silent | G2 question |
| R6 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables and XLOOKUP, from your own account. A sanitised reconciliation workbook would raise it to `high`. | `[grounded]` your background | none |
| R7 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024, as stated. A copy of the certificate would raise it to `high`. | `[grounded]` your background | none |
| R8 | Run monthly payroll for 240 staff | important | adjacent | medium | transferability | The same end-to-end running. The limit is fortnightly cycles and 90 staff, so the monthly cycle and the larger headcount are new. | `[grounded]` background; `[inferred]` scale ratio | G3 |
| R9 | Process starters and leavers | important | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R10 | Monthly payroll-to-ledger reconciliation | important | direct | medium | none | Stated directly | `[grounded]` your background | none |
| R11 | Process pension changes | important | absent | none | capability | You confirmed you haven't done these; your manager did | `[grounded]` your statement | G4 |
| R12 | Answer staff payroll queries | important | unclear | low | discovery | Your background is silent on it | `[grounded]` background silent | none; mention it in your reply if you have examples |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Terms you haven't confirmed (R1, R2, R3) | hard_gate | The role's terms are stated and your side isn't | A failed gate would end the decision however strong the fit | n/a | None needed beyond your answer | `[grounded]` constraints not given |
| G2 | Irish tax rules (R5, must_have) | discovery | Years of payroll are stated, but not the jurisdiction | A must-have that is unclear and could move the status | Applying tax credits and cut-offs, PRSI classes and USC, or filing payroll returns to Revenue | A payslip layout or a return reference with the figures removed | `[grounded]` background silent; `[generic]` examples of Irish payroll work |
| G3 | Monthly cycle at 240 staff (R8, important) | transferability | Fortnightly payroll for 90 staff | The first monthly close is where the new scale shows | Month-end closes you supported; any larger payroll you covered | A description of your reconciliation steps | `[inferred]` bridge from your fortnightly work |
| G4 | Pension changes (R11, important) | capability | Never done; your manager handled them | A listed duty you'd start without experience | Pension enrolment or contribution changes you prepared for your manager | None | `[grounded]` your statement |

Closure path for G4: ask for a handover and the scheme rules before you rely on it (RR2).

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Offer follows two interviews and names role, pay and manager | positive_signal | — | "we are delighted to offer you the permanent post of Payroll Administrator at €40,000 a year, reporting to Declan Garvagh, Finance Manager" | The role and terms are concrete and match the advertisement | `[grounded]` JD and offer | Is payroll a team, or will I be the one person running it? | noted |
| RR2 | Pension changes may land on you without a handover | unknown | — | "process starters, leavers and pension changes" | You may be doing pension changes from day one with no one to learn from | `[inferred]` from the JD duty against your stated lack of experience | Who handles pension changes now, and what handover or training is planned for the first months? | unresolved |
| RR3 | Terms beyond salary are unstated | unknown | — | "Please reply to accept within five working days." | Probation, notice, hours, leave and the pension scheme may not yet be in writing | `[grounded]` offer silent on them; `[generic]` a written contract commonly accompanies or follows an offer | Can you send the contract, with probation, notice period, hours, leave and the pension scheme, before the five days run out? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | When the portal link arrives, check that its address matches the web address on Marrowgate's own website, and enter bank, PPS and passport details only there | Routine onboarding; this is the one check that matters | `[generic]` practice | pending your approval |
| A2 | Before accepting, ask RR3's and RR2's questions in your reply | They close the two open register rows | `[grounded]` register | pending your approval |
| A3 | For R11, say plainly: "I haven't processed pension changes myself; at the hotel group my manager handled them. What handover would there be?" | It uses only your own statement and asks for the handover | `[grounded]` R11 | pending your approval |
| A4 | Confirm R1, R2 and R3 on your side, then accept inside the five working days | They are the gate rows | `[grounded]` R1–R3 | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search was refused. It would have checked the employer, the live posting and the website address for A1. |
| 2. Role-family sweep | unavailable | The search was refused. It would have given a market band to compare with €40,000. |
| 3. Hiring manager's public footprint | unavailable | No search was sent, because research wasn't permitted. It would have sharpened the scope read for Declan Garvagh. |

If you'd like it, I can write this up as a `tuesday-dossier.md` you can keep.

## Upgrade menu

- Search permission would let me check the employer and the live posting and compare €40,000 with a market band.
- Your answer on R1–R3 closes the hard-gate rows.
- Your answer on R5 closes the main must-have uncertainty.
- The written contract closes RR3, and Marrowgate's reply closes RR2.
- A sanitised reconciliation workbook or your certificate would raise R6 and R7 to `high`.

**Questions.**

G1 — Do all three terms work for you: two Limerick office days a week, €40,000, and the right-to-work check?

G2 — Did your hotel group payroll run under Irish PAYE, PRSI and USC?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.