I've run two searches, and I'm now fetching the Calderbrook careers page to check that the posting is live.
## Decision snapshot

**Yes, this one is worth applying for. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5a, R6a, R7 · adjacent: R5b (Leg-ulcer care) · unclear: R4 (Clear, timely written records), R6b (Continence care), R8 (End-of-life visits)
- `important`: adjacent: R9 (Home care for housebound adults) · absent: R10 (Own small caseload)
- `preferred`: absent: R11 (Doppler assessment)

R5b and R9 — credible bridges, limits named; R4, R6b and R8 — your CV is silent, so they are worth asking about; R10 and R11 — not held, and the advert's own wording provides for both (RR2, RR3).

**Opportunity ledger.** The post is clearly specified, with pay and pool cars stated and a named lead (RR5, RR6). It has one verification gap, because I couldn't confirm the posting is live (RR1). Three terms are unstated: Doppler training (RR2), how the caseload builds (RR3) and hours and rota (RR4).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed open, see RR1; (2) the informal chat settles RR2, RR3 and RR4 to your satisfaction; (3) the end-of-life, continence and records rows (R8, R6b, R4) are evidenced before any claim goes on your CV.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` the company's own About page |
| Role | Band 5 community staff nurse in the district nursing team, caring for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin, care planning, on an electronic patient record | `[grounded]` advert |
| Support | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Pay | £31,050–£37,800 a year plus mileage; pool cars provided | `[grounded]` advert |
| Posting status | Not confirmed live: the careers page I tried to read returned no page | `[grounded]` fetch result; the cause is not established |
| Contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. She spoke at a 2025 forum on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work | `[grounded]` forum speaker page, public professional footprint only |
| Scope read | A supervised entry step into community nursing: a one-year experience floor, a senior alongside, Doppler only desirable | `[inferred]` from the advert's essential and desirable lists and its support line |
| Market calibration | Pay sits around the middle of the market for this title: median £34,300, interquartile range £32,400–£36,600, 61% paid mileage, 24% with a pool or lease car. That is the market, not this employer's offer | `[generic]` one pay survey (Wardround 2026, community Band 5, England, n=1,240) |
| Unknowns | Doppler training, caseload build-up, hours, weekend and on-call expectations, full-time or part-time | — |
| Contradictions | None visible, but the careers page could not be read to compare | `[grounded]` fetch result |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active Adult registration, revalidation due March 2028. This is specific but stated, not checked: the NMC register entry is yours to check | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. Stated, not checked: your driving record is yours to check | `[grounded]` CV | none |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward, specific but unproven by any document | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV is silent on record-keeping and on electronic patient records. Five ward years suggest daily charting, but that is an inference, not your claim | `[grounded]` CV silence; `[inferred]` from ward practice | see G1 |
| R5a | Wound care | must_have | direct | medium | presentation | Pressure ulcers and surgical wounds are stated, but the CV doesn't lead with them in the role's terms | `[grounded]` CV | E2 pending approval |
| R5b | Leg-ulcer care | must_have | adjacent | medium | transferability | Pressure-ulcer and surgical-wound care carry over. Limit: leg-ulcer care, compression and venous or arterial assessment are not stated | `[grounded]` CV; `[generic]` leg ulcers need their own assessment skills | see G2 |
| R6a | Catheter care | must_have | direct | medium | presentation | Stated on the CV, but not positioned for community work | `[grounded]` CV | E2 pending approval |
| R6b | Continence care | must_have | unclear | low | discovery | The CV says catheter care only; continence care more widely is not mentioned | `[grounded]` CV silence | see G3 |
| R7 | Insulin administration | must_have | direct | medium | presentation | Stated on the CV. The advert also lists care planning, which the CV doesn't mention | `[grounded]` CV | E2 pending approval |
| R8 | End-of-life visits | must_have | unclear | low | discovery | The CV is silent. A medical ward may involve dying patients, but nothing you wrote says so | `[grounded]` CV silence; `[generic]` acute wards often care for dying patients | see G4 |
| R9 | Caring for housebound adults in their own homes | important | adjacent | medium | transferability | Eighteen months in the discharge-to-assess team visiting patients at home in their first week after discharge. Limit: short-term post-discharge visits, not ongoing care of long-term housebound patients | `[grounded]` CV | E1 pending approval |
| R10 | Holding a small caseload of your own | important | absent | none | transferability | You have never held your own caseload. The advert supports this with a senior nurse; the home-visiting secondment is the nearest evidence (R9) | `[grounded]` your statement and the advert | see G5 |
| R11 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You have never done one. It is desirable, not essential, and the closure path is employer training (RR2) | `[grounded]` your statement and the advert | ask RR2; carry as minor |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records (R4, must_have) | discovery | No mention of records or electronic systems | A must-have where fit is `unclear`; a line or two on the record systems you used would close it | Electronic observations, care plans, discharge or handover documentation; D2A visit records | Name of the system, an audit result, a documentation sign-off | `[grounded]` CV silence |
| G2 | Leg-ulcer care (R5b, must_have) | transferability | Pressure ulcers and surgical wounds only | The advert's lead clinical task; narrowing the limit helps | Compression bandaging, venous leg ulcers on the ward or on D2A visits, tissue viability input | A competency record, training certificate | `[grounded]` CV; `[generic]` leg-ulcer care is a core district nursing task |
| G3 | Continence care (R6b, must_have) | discovery | Catheter care only | A must-have listed alongside catheters | Bladder and bowel care plans, continence assessments, catheter changes | A competency sign-off | `[grounded]` CV silence |
| G4 | End-of-life care (R8, must_have) | discovery | Nothing on the CV | Visits are in the advert's own list; a specific example would move R8 | Syringe-driver or anticipatory medicine involvement, family conversations, a death at home arranged through D2A | A reference line or a palliative training record | `[grounded]` CV silence |
| G5 | Independent caseload working (R10, important) | transferability | Home visits are stated; who set the plan and who you escalated to are not | The step up the advert describes; showing you already make decisions alone narrows the limit | Planning your own visit list, adjusting care without a senior present, escalating to GP or district nurse | A secondment description from your manager | `[grounded]` CV; `[inferred]` that this is the likeliest probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live | unknown | — | "Community Staff Nurse, Band 5 — Calderbrook Community Health CIC, Halifax" | The careers page could not be read, so I can't tell whether the post is open. Possible reasons sit side by side: a moved page, a closed post, a stale copy | `[grounded]` the fetch returned no page; cause not established | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Doppler training unstated | unknown | — | "Desirable: Doppler assessment for leg ulcers." | Training may be offered after starting. Your contact has spoken publicly on Doppler training for staff new to community work | `[grounded]` forum page; `[inferred]` that Calderbrook offers it | Is Doppler training provided for new starters, and how soon after joining? | unresolved |
| RR3 | Caseload build-up unstated | unknown | — | "You will hold a small caseload of your own, supported by a senior community nurse." | How quickly the caseload grows and how much senior time you get isn't stated | `[inferred]` from the advert's silence | How does a new nurse's caseload build over the first months, and how often is the senior nurse alongside? | unresolved |
| RR4 | Hours and rota unstated | unknown | — | "£31,050–£37,800 a year plus mileage" | Hours, weekends and on-call are not stated. Teams that give end-of-life care at home often run rotas covering evenings or weekends | `[generic]` pattern for district nursing teams, not a claim about this one | What are the working hours, and what are the weekend and on-call expectations? | unresolved |
| RR5 | Pay stated and near the market median | positive_signal | — | "£31,050–£37,800 a year plus mileage" | Pay is transparent, and the range spans the survey's interquartile range, so no seniority-pay mismatch shows | `[grounded]` advert; `[generic]` survey band | Where in the range would someone with five years' experience start? | noted |
| RR6 | Pool cars, named contact and informal chat offered | positive_signal | — | "pool cars are provided"; "contact Rhiannon Mabbott" | Terms and a named lead suggest an open, supported hiring route | `[grounded]` advert | Are pool cars available for every visit? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Move the secondment to the top of your experience, in your own words: "seconded for 18 months to the discharge-to-assess team, visiting patients at home in their first week after discharge" | see R9 | `[grounded]` CV | `resume_edits_pending_approval` |
| E2 | Lead your clinical lines with wound care (pressure ulcers and surgical wounds), catheter care and insulin administration. This reorders existing claims and adds none | see R5a, R6a, R7 | `[grounded]` CV | `resume_edits_pending_approval` |
| E3 | Add end-of-life, continence, leg-ulcer and records lines only after you give me specifics. Nothing is added until then | see R4, R6b, R8 | `[grounded]` gap queue | `resume_edits_pending_approval` |
| P1 | In your supporting statement, say plainly that you haven't held your own caseload and haven't done Doppler assessment, and that you are looking for the supported step the advert describes. Every part of that traces to your own sentences | see R10, R11 | `[grounded]` your statements | pending your approval |
| Q1 | Take up the informal chat with Rhiannon Mabbott before applying, and ask RR1–RR4 verbatim | The register doubles as your question list | `[grounded]` register | pending your approval |
| A1 | Check your own NMC register entry and driving record before applying | see R1, R2, stated and not checked | `[grounded]` map | pending your approval |

You included a National Insurance number. It isn't needed for this assessment and I haven't used it. Keep it out of applications until after a written offer.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse district nursing", which returned "About Calderbrook Community Health" (calderbrookhealth.example/about). Fetched calderbrookhealth.example/careers, which returned no page. Role reality: organization row; posting status → RR1 |
| 2. Role-family sweep | yes | Searched "community staff nurse Band 5 district nursing Agenda for Change salary 2026 Doppler training newly recruited", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Market calibration `[generic]`; RR5 |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead Calderbrook", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). Scope read; RR2; Q1 |

I can draft a `tuesday-dossier.md` of this assessment whenever you want one.

## Upgrade menu

- A link to the live posting or the careers page → RR1 closes.
- Competency records, training certificates or a manager's description of the secondment → R5b, R6b and R9 move toward `high`, and R10's limit narrows.
- Your answers to G1–G4 → R4, R6b and R8 move off `unclear`, and the E3 CV lines can be written.
- Your non-negotiables (pay floor, hours, weekends) → the hard-gates line can be checked against them.
- A deeper research pass on Calderbrook (staff reports, news, hiring patterns; up to 5 more searches and 2 more fetches) — say the word and it runs.
- If you decide to apply, resume-tailor can turn E1–E3 into a full CV pass.

Questions, in order of how much they could move the decision:

G4 — Have you cared for dying patients on the ward or on D2A visits? What was your part (for example syringe drivers, anticipatory medicines, family conversations, a death at home)?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

G5 — On the D2A visits, did you plan your own visit list and make care decisions without a senior present? Who did you escalate to?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

Hard-gates line — Do you have a pay floor, hours, weekend or on-call limits, or other non-negotiables I should check this role against?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.