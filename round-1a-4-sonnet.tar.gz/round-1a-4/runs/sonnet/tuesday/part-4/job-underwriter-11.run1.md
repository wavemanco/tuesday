**Duinvaart (Operations Analyst): yes, apply. Status: `conditional_go`. Kroonhaven (Supply Planner): no. Status: `no_go`, because B2, B5 and B6 are absent and B2 and B5 are must-haves.**

I couldn't run any web research. Every search was refused, so nothing here is checked against either employer's own pages.

## Decision snapshot

**Duinvaart Cold Chain, Operations Analyst — `conditional_go`**

**Fit ledger.**

- `hard_gate` — unclear: A1 (Hybrid, three days Rotterdam)
- `must_have` — direct: A2, A3, A4
- `important` — direct: A5a, A6 · unclear: A5b (Temperature compliance tracking)
- `preferred` — adjacent: A7 (Dutch a plus)

A5b — temperature compliance not yet evidenced; A3 (`medium`) — daily use confirmed, level uninspected.

**Opportunity ledger.** The duties name their metrics and tool (RRA3). The employer could not be checked (RRA1) and the pay is unstated (RRA2).

- **Hard gates:** none failed; unconfirmed: A1 (Hybrid, three days a week in the Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) three Rotterdam days a week work for you (A1, GA2); (2) the employer and live posting verify (RRA1); (3) the temperature-compliance side (A5b) is either evidenced or presented as the part you would be learning.

**Kroonhaven Foods, Supply Planner — `no_go`**

**Fit ledger.**

- `hard_gate` — unclear: B1 (On-site in Utrecht)
- `must_have` — adjacent: B3 (Fluent Dutch) · unclear: B4 (Advanced Excel) · absent: B2 (3+ years planning in FMCG), B5 (SAP IBP or similar)
- `important` — adjacent: B7 (Run weekly S&OP) · absent: B6 (13-week supply plan)

B2, B5, B6 — planning work you haven't done; B7 — a real bridge, its limit named.

**Opportunity ledger.** The employer could not be checked (RRB1) and the pay is unstated (RRB2).

- **Hard gates:** none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** inspectable planning work that closes B2, B5 and B6, and Dutch you can run a weekly meeting in (B3). Neither is a CV edit.

## Role reality

| Role | Element | What it is | Provenance |
|---|---|---|---|
| Duinvaart | Mandate | Track on-time delivery and temperature compliance for a refrigerated fleet, weekly Power BI dashboards, route changes with depot managers | `[grounded]` JD |
| Duinvaart | Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Duinvaart | Scope read | An analyst role that reports on and advises the fleet, with no stated ownership of decisions | `[inferred]` from the JD's verbs (track, build, work with) |
| Duinvaart | Market calibration | Not established: the role-family search was refused, so there is no pay band | — |
| Duinvaart | Unknowns | Pay; which days are in the office; who consumes the dashboards; how temperature data is captured | `[grounded]` JD silent |
| Kroonhaven | Mandate | Own a 13-week supply plan for chilled ready-meals, balance capacity against forecast, run weekly S&OP | `[grounded]` JD |
| Kroonhaven | Working pattern | On-site in Utrecht, with no hybrid mentioned | `[grounded]` JD |
| Kroonhaven | Scope read | A hands-on planning ownership role, not an analyst role | `[inferred]` from "own", "balance" and "run" |
| Kroonhaven | Market calibration | Not established, for the same reason | — |
| Kroonhaven | Unknowns | Pay; the meeting language; team size | `[grounded]` JD silent |
| Both | Contradictions | None between the provided material, but neither posting could be checked against its employer's site | `[grounded]` research refused |

## Evidence map

Your background is typed prose, so it counts like a CV: self-report, which caps confidence at `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You gave no location or schedule constraints, so nothing settles it | `[grounded]` JD term; no candidate statement | GA2 |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | 4 years as an operations analyst at a parcel carrier, stated by you. Not a gate, since it is an experience length | `[grounded]` your background | none |
| A3 | Strong SQL | must_have | direct | medium | none | SQL daily, confirmed. "Strong" is uninspected | `[grounded]` your background | offer: a sanitized sample query would raise to `high` |
| A4 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the dashboard depot managers use | `[grounded]` your background | offer: a sanitized dashboard screenshot would raise to `high` |
| A5a | Track on-time delivery | important | direct | medium | none | You built the on-time delivery dashboard | `[grounded]` your background | none |
| A5b | Track temperature compliance on refrigerated fleet | important | unclear | low | discovery | Nothing you gave touches temperature-controlled work. A parcel carrier may or may not have handled chilled freight | `[grounded]` silence in your background; `[generic]` that parcel networks vary on chilled handling | GA1 |
| A6 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review, and depot managers use your dashboard | `[grounded]` your background | none |
| A7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is real but short of fluent; the posting asks only for a plus | `[grounded]` your statement | state "conversational", nothing stronger |
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No location or schedule constraints given | `[grounded]` JD term; no candidate statement | ask only if you pursue it |
| B2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You have never worked in planning. This is an experience length, not a gate | `[grounded]` your statement | closure path in GB2 |
| B3 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational, not fluent. Running a weekly meeting in Dutch needs more | `[grounded]` your statement; `[generic]` that running a meeting is harder than conversing | GB1 |
| B4 | Advanced Excel | must_have | unclear | none | discovery | Excel is not mentioned in your background | `[grounded]` silence | none, since the decision does not turn on it |
| B5 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning-system use stated | `[grounded]` your statement | closure path in GB2 |
| B6 | Own the 13-week supply plan, balancing capacity against forecast | important | absent | none | capability | Planning ownership is the work you have not done | `[grounded]` your statement | closure path in GB2 |
| B7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. Limit: S&OP reconciles supply plans with demand forecasts, which your review did not | `[grounded]` your background; `[generic]` what S&OP covers | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Temperature compliance (A5b, important) | discovery | Nothing in your background touches chilled or temperature-controlled freight | It is half of the posting's headline duty, so it is the likeliest probe | Reporting on pharma, food or other temperature-sensitive parcels; monitoring service-level breaches against a threshold; exception reports on delayed or damaged consignments | A sanitized exception report or dashboard page | `[grounded]` silence; `[generic]` that this is the likeliest probe |
| GA2 | Three Rotterdam days a week (A1, hard_gate) | hard_gate | You gave no commute or location constraint | A gate that is unsettled is carried visibly, and it decides whether you apply | — | Your own statement | `[grounded]` JD term |
| GB1 | Fluent Dutch (B3, must_have) | transferability | Conversational Dutch | It fails the posting's own word, "fluent" | Meetings you have held in Dutch | A Dutch-language reference | `[grounded]` your statement |
| GB2 | Planning (B2, B5, B6) | capability | No credible planning evidence | Three rows hang on it, and no CV wording can close it | Closure path: a scoped-down target such as a planning-analyst or junior planner role | A course or certification in planning | `[inferred]` closure path from the gap |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RRA1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RRA2 | Pay not stated | unknown | — | The posting gives no figure | The figure may sit anywhere in the role-family band, which I could not look up | `[grounded]` posting silent; no band available | What salary is budgeted for this post? | unresolved |
| RRA3 | Duties name their metrics and tool | positive_signal | — | "Track on-time delivery and temperature compliance… weekly dashboards in Power BI" | The role has measurable outputs | `[grounded]` JD | Who consumes the weekly dashboards, and what decisions do they drive? | noted |
| RRB1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same possibilities as RRA1, none ranked as likely | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RRB2 | Pay not stated | unknown | — | The posting gives no figure | The figure is unknown and no band was available | `[grounded]` posting silent | What salary is budgeted for this post? | unresolved |

RRA1 and RRB1 cap any `go` at `conditional_go` until the employer and posting verify.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | For Duinvaart, lead with the on-time delivery dashboard that depot managers use and the weekly route-performance review you ran, ahead of tool lists | see A4, A5a, A6 | `[grounded]` your background | pending your approval |
| E2 | Describe your Dutch as conversational and claim nothing stronger | see A7, B3 | `[grounded]` your statement | pending your approval |
| Q1 | Ask the questions in RRA1, RRA2 and RRA3 verbatim in the first call | The register doubles as interview prep | `[grounded]` register | pending your approval |
| A1 | Confirm how the three Rotterdam days are set before investing in the loop | see A1 | `[grounded]` JD term | pending your approval |
| A2 | Put Kroonhaven aside unless you can show planning work; spend that time on analyst roles | see B2, B5, B6 | `[inferred]` from the gaps in those rows | pending your approval |

If you go ahead on Duinvaart, resume-tailor can turn E1 into approved resume wording.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Duinvaart Cold Chain Rotterdam refrigerated transport careers" and "Kroonhaven Foods Utrecht chilled ready meals careers"; both were refused. It would have moved RRA1 and RRB1 and the contradictions row |
| 2. Role-family sweep | unavailable | Searched "operations analyst logistics salary Netherlands Power BI SQL" and "supply planner FMCG salary Netherlands S&OP SAP IBP"; both were refused. It would have moved the market calibration rows and RRA2 and RRB2 |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- **Search permission:** it confirms both employers and live postings (RRA1, RRB1) and gives the pay bands for the market calibration rows.
- **Your location, commute limit and pay floor:** A1 and B1 become met or failed, and the hard-gates lines stop reading "constraints not given".
- **A sanitized sample query or dashboard screenshot:** A3, A4 and A5a go from `medium` to `high`.
- **Any temperature-sensitive or chilled work:** A5b closes, which is the main open item on Duinvaart.

If you'd like a saved record of this analysis, I can write it to `tuesday-dossier.md`.

GA2 — Can you work three days a week in Rotterdam? Where do you live, and is there a commute or schedule limit?
GA1 — Have you reported on or handled temperature-sensitive or chilled parcels, or monitored deliveries against a compliance threshold? What did you own, and what happened?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.