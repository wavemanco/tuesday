Web search was declined, so I worked from your message alone. The Evidence status section says what that cost.

## Decision snapshot

**A: Duinvaart Operations Analyst. Worth your time: D2, D3, D4 and D5 land `direct`, and D1 (a gate) is still open. Status: `conditional_go`.**

**Fit ledger (A).**

- `hard_gate` — unclear: D1 (Hybrid, three days a week in Rotterdam)
- `must_have` — direct: D2, D3, D4, D5
- `important` — adjacent: D7 (Working with depot managers on route changes) · unclear: D6 (Temperature compliance tracking)
- `preferred` — adjacent: D8 (Dutch a plus)

D6 — the one real domain gap, closable by a question; D7 — your route-performance review is close, but the posting asks for route changes.

**Opportunity ledger (A).** The employer could not be checked from here (DRR1) and the pay is not stated (DRR2). The duties are clearly written (DRR3).

- **Hard gates:** none failed; unconfirmed: D1 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam three days work for you, D1; (2) the employer and posting verify, DRR1; (3) the temperature-compliance gap D6 is answered honestly as adjacent, not claimed.

**B: Kroonhaven Supply Planner. Not worth your time: K2, K3 and K6, three `must_have` rows, are `absent`, and you've told me you haven't worked in planning. Status: `no_go`.**

**Fit ledger (B).**

- `hard_gate` — unclear: K1 (On-site in Utrecht)
- `must_have` — adjacent: K4 (Run the weekly S&OP meeting), K7 (Fluent Dutch) · unclear: K5 (Advanced Excel) · absent: K2 (3+ years planning in FMCG), K3 (Own the 13-week supply plan), K6 (SAP IBP or similar)
- `important` and `preferred` — no rows

K2, K3, K6 — absent, and you said you've never worked in planning; K4 — a bridge with its limit named; K7 (`medium`) — conversational against fluent.

**Opportunity ledger (B).** The employer could not be checked from here (KRR1) and the pay is not stated (KRR2). The mandate is clearly written (KRR3). Nothing here changes the fit result.

- **Hard gates:** none failed; unconfirmed: K1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** you would need planning experience that isn't in what you've told me (K2, K3, K6), or the employer would have to loosen the requirements. The user decides; if you apply anyway, apply second.

## Role reality

| Role | Element | What it is | Provenance |
|---|---|---|---|
| A | Organization | Duinvaart Cold Chain, Rotterdam, running a refrigerated fleet | `[grounded]` posting |
| A | Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| A | Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| A | Scope read | An analyst post that reports on operations and recommends changes; it does not own a planning process | `[inferred]` from the duties named against the absence of any ownership language |
| A | Unknowns | Pay, fleet and depot count, which systems feed the data | `[grounded]` posting is silent |
| B | Organization | Kroonhaven Foods, Utrecht, a chilled ready-meals range | `[grounded]` posting |
| B | Mandate | Own the 13-week supply plan, balance capacity against the forecast, run the weekly S&OP meeting | `[grounded]` posting |
| B | Working pattern | On-site in Utrecht | `[grounded]` posting |
| B | Scope read | A full-ownership planning post: "own" and "run" put the plan and the meeting on this person | `[inferred]` from the posting's verbs |
| B | Unknowns | Pay, team size, which planning system is in use ("SAP IBP or a similar planning system") | `[grounded]` posting is silent |
| A, B | Market calibration | Not available: the role-family sweep did not run, so no pay band and no title norm | — |
| A, B | Contradictions | None inside either posting's text | `[grounded]` the two postings as pasted |

## Evidence map

Your background came in as prose, so everything from it sits at `medium` or below. I treat it as CV-equivalent until you show something I can inspect.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You gave no constraints and no home location, so the gate is not settled either way | `[grounded]` posting term; no candidate statement | G1 |
| D2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You stated four years as an operations analyst at a parcel carrier; stated, nothing inspectable yet | `[grounded]` your message | none |
| D3 | Strong SQL | must_have | direct | medium | none | You use SQL daily; "strong" is the posting's word and your level has not been probed | `[grounded]` your message | none |
| D4 | Power BI or Tableau | must_have | direct | medium | none | You use Power BI daily and named the on-time delivery dashboard | `[grounded]` your message | none |
| D5 | Track on-time delivery; build weekly dashboards | must_have | direct | medium | none | The on-time delivery dashboard is the closest match; whether you built it or maintained it is not stated, so I read it as the lesser claim | `[grounded]` your message; ownership read downward | G3 |
| D6 | Track temperature compliance on a refrigerated fleet | important | unclear | low | discovery | Nothing in your background mentions temperature or quality compliance, but delivery-exception or quality metrics from your parcel work could count | `[grounded]` silence in your message; `[generic]` that analysts in parcel carriers often hold such metrics | G2 |
| D7 | Work with depot managers on route changes | important | adjacent | medium | discovery | You ran a weekly route-performance review and depot managers use your dashboard; the posting asks for route changes, and it is unstated whether the review led to any | `[grounded]` your message | G3 |
| D8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch is a bridge; the limit is that it falls short of working proficiency | `[grounded]` your message | CV says "conversational", nothing stronger |
| K1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No constraints or location given, so the commute is unknown | `[grounded]` posting term; no candidate statement | G4 |
| K2 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You said you have never worked in planning; the parcel-carrier work is not FMCG | `[grounded]` your statement | G5 |
| K3 | Own the 13-week supply plan; balance capacity against the forecast | must_have | absent | none | capability | A planning process you have not run | `[grounded]` your statement | G5 |
| K4 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly route-performance review; limit: it is a different forum, with no stated demand-versus-supply trade-offs | `[grounded]` your message | bridge framed as adjacent |
| K5 | Advanced Excel | must_have | unclear | low | discovery | Excel is not mentioned; four years of analyst work make heavy use likely | `[grounded]` silence; `[generic]` that analyst roles usually involve Excel | G6 |
| K6 | SAP IBP or a similar planning system | must_have | absent | none | capability | SQL and Power BI are reporting tools, not planning systems; no planning-system use stated | `[grounded]` your message | G5 |
| K7 | Fluent Dutch | must_have | adjacent | medium | transferability | You are conversational, not fluent; the bridge is real and its limit is the requirement's own word | `[grounded]` your message | state "conversational", never "fluent" |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Rotterdam three days a week (D1, hard_gate) | hard_gate | No home location or constraints given | A gate, so it can cap the decision | Not an experience question: it is a term you meet or do not | None | `[grounded]` posting term; your message is silent |
| G2 | Temperature compliance (D6, important) | discovery | Delivery-time work is clear; nothing on temperature or quality metrics | This is the one duty with no match in your background, and a refrigerated fleet is the employer's whole business | Delivery-exception or damage-claim tracking; time-window or SLA compliance reports; any sensor or telematics data you reported on | A sanitized dashboard screenshot or KPI definitions | `[grounded]` your message is silent; `[generic]` that cold-chain analysts report on such data |
| G3 | Dashboard ownership and route changes (D5, D7) | discovery | The sentence names a dashboard depot managers use; it does not say who built it or whether reviews changed routes | Settles whether your bullets say "built" or "maintained", and how close D7 really is | A route that changed because of the review; a metric you added to the dashboard | A sanitized screenshot; a review agenda | `[grounded]` your message |
| G4 | Utrecht on-site (K1, hard_gate) | hard_gate | No home location or constraints given | Same gate logic as G1 | Not an experience question | None | `[grounded]` posting term; your message is silent |
| G5 | Planning, FMCG, planning system (K2, K3, K6) | capability | You said you have not worked in planning | Three must-haves with no match, and none of them is a wording problem | None found; any planning exposure you remember would reopen this as discovery | A forecast, capacity plan or S&OP pack you contributed to | `[grounded]` your statement; `[generic]` that planners are usually screened on titled years |
| G6 | Advanced Excel (K5) | discovery | Excel not mentioned | A must-have that a short answer can close | Pivot-heavy reporting, lookups across large sheets, models you built | A sanitized workbook | `[grounded]` silence in your message |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| DRR1 | Employer not established from attributable sources | risk_signal | medium | "Duinvaart Cold Chain, Rotterdam" | The entity may be too new or small for a footprint, the posting may be stale, or it may not represent a real hiring employer; no search ran, so nothing is established either way | `[generic]` pattern for companies of this kind, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| DRR2 | Pay not stated | unknown | — | (no figure in the posting) | The band may sit above or below your floor; unknowable without it | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| DRR3 | Duties and deliverables stated | positive_signal | — | "build weekly dashboards in Power BI, and work with depot managers on route changes" | The duties are concrete and measurable | `[grounded]` posting | Which depots and routes would I cover first? | noted |
| KRR1 | Employer not established from attributable sources | risk_signal | medium | "Kroonhaven Foods, Utrecht" | Same three possibilities as DRR1; no search ran | `[generic]` pattern for companies of this kind, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| KRR2 | Pay not stated | unknown | — | (no figure in the posting) | The band could not be compared with your floor | `[inferred]` from the posting's silence | What salary range is budgeted for this post? | unresolved |
| KRR3 | Mandate and cadence stated | positive_signal | — | "Own the 13-week supply plan ... run the weekly S&OP meeting" | The post has defined ownership and a fixed rhythm | `[grounded]` posting | Who sits in the S&OP meeting, and who decides when demand and capacity disagree? | noted |

Neither posting asks for money, ID or a chat-only process, so no entry carries a warning.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Put your time into Duinvaart; treat Kroonhaven as low priority | D2, D3, D4, D5 against K2, K3, K6 | `[grounded]` the two maps | pending your approval |
| E1 | Lead the resume with: "Use SQL and Power BI daily, including the on-time delivery dashboard used by depot managers", and your own words for the weekly route-performance review | Mirrors your sentences and claims no ownership you haven't confirmed (D4, D5, G3) | `[grounded]` your message | pending your approval |
| E2 | Write "conversational Dutch" and nothing stronger | D8, K7 | `[grounded]` your message | pending your approval |
| Q1 | Ask DRR1 to DRR3 verbatim in a first call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A2 | If you apply to Kroonhaven anyway, frame K4 as adjacent and never call it planning | K4, K2 | `[grounded]` K4 row | pending your approval |

Once you choose which to apply to, resume-tailor can turn E1 into a full edit ledger.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page, Duinvaart | unavailable | Search "Duinvaart Cold Chain Rotterdam" was refused. It would have moved DRR1 (employer exists, posting live) |
| 1. Official site and careers page, Kroonhaven | unavailable | Search "Kroonhaven Foods Utrecht chilled ready meals" was refused. It would have moved KRR1 |
| 2. Role-family sweep, Duinvaart | unavailable | Search "operations analyst logistics Netherlands salary Power BI SQL" was refused. It would have moved market calibration and DRR2 |
| 2. Role-family sweep, Kroonhaven | unavailable | Search "supply planner FMCG Netherlands salary SAP IBP S&OP" was refused. It would have moved market calibration and KRR2 |
| 3. Hiring manager's public footprint | n/a | No name was given in either posting |

## Dossier offer

If you want a record to carry into later steps, I can write both assessments into `tuesday-dossier.md`.

## Upgrade menu

- Your resume or CV: lets me check the D-rows and K-rows against its wording instead of your summary.
- Your pay floor and where you live: D1 and K1 close, and the hard-gates lines stop flagging unknown constraints.
- A sanitized dashboard screenshot or KPI definitions: D4 and D5 can reach `high`.
- Links to both live postings: DRR1 and KRR1 get a quick liveness check.
- Search permission: the four refused calls above would run, which verifies both employers and gives pay bands. A deeper pass after that would be up to 5 more searches and 2 more fetches, run only if you say so.

## Questions

- G1 and G4: Where are you based, and are three days a week in Rotterdam (Duinvaart) or five on site in Utrecht (Kroonhaven) workable for you?
- G2 and G3: Did you build the on-time delivery dashboard or maintain it, and have you tracked any delivery-quality or exception metrics, such as damage claims or time-window breaches? Did your weekly review ever lead to a route change?
- G5: Have you ever contributed to forecasts, capacity plans or S&OP inputs, even as one input among several?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.