Web searches were denied, so this assessment rests only on what you pasted.

## Decision snapshot

**Is it worth it, and is it legit? Worth taking the call, on conditions. Nothing in the posting or the WhatsApp message asks you for money, payment details or ID, but I couldn't check Fernquay itself from here, so verify it before you invest more. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: direct: R1 · unclear: R2 (Pay €52,000–€60,000)
- `must_have`: direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important`: adjacent: R8 (Research calls with school owners), R9 (Work as first designer)

R7 (`medium`) — checkout redesign is a credible bridge, limit named; R9 (`low`) — never the only designer; R2 — your floor is not yet known.

**Opportunity ledger.** The scope, pay range and named co-founder are concrete on the page (RR4). Decision rights (RR2), equity terms and funding (RR3) are unknown, and the firm could not be checked from here (RR1).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52,000–€60,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) Fernquay checks out through its own site and the invite's sender domain (RR1); (2) the pay clears your floor (R2); (3) decision rights, equity terms and funding are concrete on the call (RR2, RR3); (4) you present R7 and R9 as adjacent, not as full matches.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay, a six-person Galway team making booking software for sea-kayak and surf schools. Not independently confirmed | `[grounded]` posting |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Working with | Co-founder Ronan Kehoe, named in the posting and as the sender of the message | `[grounded]` posting and message agree |
| Pattern | Hybrid, two days a week in the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity. Market calibration was not run (no search), so no market band is given | `[grounded]` posting |
| Scope read | First-designer posts of this kind usually bundle design, research and process-setting with no design peer | `[generic]` role-family pattern |
| Unknowns | Decision rights, equity terms (vesting, share class), funding or runway, contract type | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the message (role, case study, names). Careers page not checked | `[grounded]` posting against message |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid: two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year. You haven't said you can do two office days, so `medium` | `[grounded]` your background; posting | none |
| R2 | Pay €52,000–€60,000 plus 0.5–1% equity | hard_gate | unclear | none | hard_gate | No floor given, so I can't check it. Confidence is `none` because no constraint is stated | `[grounded]` posting; floor not given | G1 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company. Self-reported, nothing inspected | `[grounded]` your background | none |
| R4 | Strong Figma | must_have | direct | medium | none | Daily Figma use stated. "Strong" would be shown by a file or portfolio | `[grounded]` your background | A Figma file or prototype link would raise this to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. That is usability testing, so call it that | `[grounded]` your background | none |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | Worked in a squad with four engineers. Practice is evidence; "happy" is a disposition | `[grounded]` your background | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a checkout flow, which is one stage of a booking flow. Limit: nothing stated on the other stages or on who decided | `[grounded]` your background; `[inferred]` that checkout is one stage of a wider flow | G2 |
| R8 | Run research calls with school owners | important | adjacent | medium | transferability | Your sessions were with customers. These calls are with business owners about how they run things, which is different participants and usually a different method | `[grounded]` your background; `[generic]` how owner interviews usually differ | G3 |
| R9 | Work as the first designer, with no design peer | important | adjacent | low | transferability | You have never been the only designer. Adjacent: you ran your own monthly sessions and owned a flow inside a squad | `[grounded]` your statement; `[generic]` first-designer roles carry decisions without a peer to review them | G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R2, hard_gate) | hard_gate | €52,000–€60,000 posted; your floor not given | An unconfirmed gate decides whether the call is worth taking | Not experience: your floor as a number | None needed | `[grounded]` posting; floor absent |
| G2 | Booking flow beyond checkout (R7, must_have) | transferability | Checkout redesign confirmed; no other stage stated | A must-have at `adjacent`; closing it narrows the likeliest objection | Search or availability screens; changes and cancellations; the operator or admin side; a flow-wide redesign | A case study or flow diagram showing the wider journey | `[grounded]` your background; `[generic]` that this is the likeliest probe |
| G3 | Research with business owners (R8, important) | transferability | Customer usability sessions only | The role's research is with owners, not end customers | Onboarding calls with operators; discovery or sales-support conversations; stakeholder interviews | A research readout or interview guide | `[grounded]` your background |
| G4 | Working as the only designer (R9, important) | transferability | Stated as never done; no question, per your own statement | Reads as the largest stretch, to name honestly | Setting up a Figma library alone; running a design decision with no reviewer | None | `[grounded]` your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. My searches were refused, so nothing was checked either way | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Decision rights unstated for "own the booking flow" | unknown | — | "own the booking flow end to end" | The designer may own outcomes while decisions sit with the co-founder or engineers | `[inferred]` from the posting's scope language against its silence on authority | Who makes the final call on booking-flow design decisions: the designer, Ronan, or engineering? | unresolved |
| RR3 | Equity terms and funding unstated | unknown | — | "0.5–1% equity" | Vesting, share class and the runway behind the salary are not given | `[inferred]` from the posting's silence | What is the vesting schedule, and how many months of runway does the current funding cover? | unresolved |
| RR4 | Concrete scope, pay range and named co-founder | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity" | The role is specified and the pay is disclosed | `[grounded]` posting | What does the first quarter's work on the booking flow look like? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, find Fernquay's own website and product pages yourself, and check they match the posting | See RR1, which I could not check | `[grounded]` RR1 | pending your approval |
| A2 | Join the call from the calendar invite emailed to you, and check its sender address uses the same domain as the company's own site. Scheduling an interview by WhatsApp with the invite emailed is a routine step | Your sense that WhatsApp felt odd is understandable, and this check settles it | `[generic]` common hiring practice | pending your approval |
| A3 | Open with: "I redesigned the checkout flow at a Dublin travel-booking company and ran monthly usability sessions with customers." Each clause is yours | See R5, R7 | `[grounded]` your background | pending your approval |
| A4 | Say plainly: "I haven't been the only designer; I've owned a flow and run my own sessions inside a squad." Each clause is yours | See R9 | `[grounded]` your statement | pending your approval |
| A5 | Ask RR2 and RR3's questions verbatim on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A6 | Rehearsing the call itself is mock-interview's job, not this one | Sibling noted | `[grounded]` your invite | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches "Fernquay booking software Galway sea kayak surf schools" and "Fernquay product designer careers Galway" were refused. It would have moved role reality's organization and contradictions rows and RR1 |
| 2. Role-family sweep | unavailable | Search "product designer Ireland salary Galway startup first designer" was refused. It would have moved market calibration and the R2 check |
| 3. Hiring manager's public footprint | unavailable | A name was given, but search "Ronan Kehoe Fernquay co-founder" was refused. It would have moved role reality's scope read and A3 and A4's positioning |

If you'd like, I can save this as a `tuesday-dossier.md` for reuse.

## Upgrade menu

- A link to or paste of Fernquay's own website or careers page → RR1 and role reality's organization row, which I can read without search.
- Your salary floor and any other must-haves, such as notice period or right to work → R2 and any further gates.
- A link to your checkout case study or a Figma file → R3 to R7 from `medium` toward `high`.
- Ronan's and Saoirse's answers on decision rights, equity and runway → RR2 and RR3.
- Search access → the three targets above, which would run.

G1 — What is the lowest salary you would accept, and is €52,000 above it?
G2 — Beyond checkout, did you design any other stage of the booking journey (search or availability, changes or cancellations, the operator side), and what was yours versus the squad's?
G3 — Have you spoken with business owners or operators, not end customers, about how they work, and what did you do with it?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.