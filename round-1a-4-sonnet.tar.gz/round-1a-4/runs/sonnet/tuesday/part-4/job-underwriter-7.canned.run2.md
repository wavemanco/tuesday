# Job underwriting: Community Staff Nurse, Band 5, Calderbrook Community Health CIC

## Decision snapshot

**Yes, this is worth applying for, with conditions. Status: `conditional_go`.** None of the three hard gates you can already be checked against fail: R1, R2 and R3 are met on your word, and R4 (pay) is unconfirmed.

**Fit ledger.**

- `hard_gate` — direct: R1, R2, R3 · unclear: R4 (Pay £31,050–£37,800 plus mileage)
- `must_have` — direct: R5 · unclear: R6 (Clear, timely written records)
- `important` — direct: R7a, R8a, R10a · adjacent: R7b (leg-ulcer care), R11 (own small caseload) · unclear: R8b (continence care), R9 (end-of-life visits), R10b (care planning)
- `preferred` — absent: R12 (Doppler assessment)

R7b and R11 — bridges, limits named; R6, R8b, R9 and R10b — your CV is silent; R12 — absent, desirable tier only.

**Opportunity ledger.** A plainly scoped post with stated pay, mileage, pool cars and a supported caseload (RR2, RR4). Two things are open: I could not confirm the posting is live on the employer's own site (RR1), and the working pattern is unstated (RR3).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`, R3 `direct`); unconfirmed: R4 (Pay £31,050–£37,800 plus mileage); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the pay range suits you — R4; (2) the posting is confirmed open — RR1; (3) your NMC registration and licence are as you've stated — R1, R2, which are yours to check.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing, therapy and rehabilitation across Calderdale under an NHS contract; founded 2015, 410 staff, four locality hubs | `[grounded]` its About page, read as a search result, not fetched |
| Mandate | District nursing for housebound adults at home: wound and leg-ulcer care, catheter and continence care, end-of-life visits, insulin administration, care planning, recorded on an electronic patient record | `[grounded]` advert |
| Scope | A small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Essentials | NMC Adult Nurse registration; full UK driving licence (pool cars provided); one year's post-registration experience; clear, timely written records | `[grounded]` advert |
| Desirable | Doppler assessment for leg ulcers | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage | `[grounded]` advert |
| Market calibration | A community staff nurse, Band 5, in England has a survey median of £34,300 and an interquartile range of £32,400–£36,600 (n=1,240). 61% were paid mileage and 24% had a pool or lease car. The posted range spans that interquartile range. This is a survey pattern, never this employer's offer. Scope norms for the title did not come back from search. | `[generic]` Wardround 2026 pay guide, read as a search result |
| Hiring contact | Rhiannon Mabbott leads the Halifax district nursing team, after eleven years as a district nurse. At a 2025 community nursing forum she spoke on nurse-led leg-ulcer clinics and on Doppler training for staff new to community work. | `[grounded]` the forum's speaker page, read as a search result |
| Working pattern | Hours, weekends and on-call are not stated | `[grounded]` advert silent |
| Contradictions | None visible between the advert and the About page; the careers page did not load, so that comparison could not be made | `[grounded]` fetch returned no page |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state registration as an Adult Nurse is active, with revalidation due March 2028. That is stated, not checked, and a CV line is not an inspectable artifact | `[grounded]` your CV | Check your own NMC register entry before applying |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | You state a full UK licence, category B. The advert provides pool cars. Stated, not checked | `[grounded]` your CV and the advert | Check your own driving record if asked to evidence it |
| R3 | Location: Halifax | hard_gate | direct | medium | none | You live in Halifax and the post is Halifax-based. The caseload's travel radius is not stated | `[grounded]` your CV and the advert | Ask the radius in the informal chat (RR3) |
| R4 | Pay £31,050–£37,800 plus mileage | hard_gate | unclear | none | hard_gate | You gave no pay floor, so there is nothing to grade; fit is unclear because I can't tell whether the range meets it. Confidence grades your statement of a floor, never the range | `[grounded]` advert; no constraint stated | Answer the pay question below |
| R5 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. A length-of-experience requirement is not a gate | `[grounded]` your CV | none |
| R6 | Clear, timely written records on the electronic patient record | must_have | unclear | low | discovery | Your CV says nothing about records or electronic systems, so there is no evidence either way | `[grounded]` CV silence | Answer G1 below |
| R7a | Wound care | important | direct | medium | none | You list pressure ulcers and surgical wounds | `[grounded]` your CV | none |
| R7b | Leg-ulcer care | important | adjacent | medium | transferability | Pressure-ulcer and surgical-wound care carries over. Limit: you describe no leg-ulcer work | `[inferred]` adjacency derived from the wound care you listed | See G3 |
| R8a | Catheter care | important | direct | medium | none | You list catheter care | `[grounded]` your CV | none |
| R8b | Continence care | important | unclear | low | discovery | The CV does not mention continence care | `[grounded]` CV silence | G5, not asked this turn |
| R9 | End-of-life visits | important | unclear | low | discovery | The CV does not mention end-of-life care | `[grounded]` CV silence | Answer G2 below |
| R10a | Insulin administration | important | direct | medium | none | You list insulin administration | `[grounded]` your CV | none |
| R10b | Care planning | important | unclear | low | discovery | The CV does not mention care planning | `[grounded]` CV silence | G5, not asked this turn |
| R11 | Own small caseload, supported by a senior community nurse | important | adjacent | medium | transferability | Eighteen months on a discharge-to-assess team visiting patients at home in their first week after discharge. Limit: you have never held your own caseload, and a first-week visit is not ongoing caseload management | `[grounded]` your CV and your statement; `[inferred]` that the bridge is credible | Frame it honestly as home visiting, not a caseload (E1) |
| R12 | Doppler assessment for leg ulcers | preferred | absent | none | capability | You say you have never done one. The employer lists it as desirable, not essential | `[grounded]` your statement and the advert | Closure path: ask in the informal chat what Doppler training the post offers (RR2) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Records on an electronic system (R6, must_have) | discovery | Nothing in the CV on documentation | An essential, and it could move R6 from `unclear` | Writing visit or discharge records on an electronic system; audits of your records; records others relied on after your discharge-to-assess visits | A record-keeping audit result, a competency sign-off, a manager's comment | `[grounded]` CV silence; `[inferred]` that answering would close the row |
| G2 | End-of-life care (R9, important) | discovery | Nothing in the CV | End-of-life visits are one of the post's named duties | End-of-life or palliative patients on the ward; contributing to a care plan for a dying patient; support to families | A training record or a reflective account for revalidation | `[grounded]` CV silence and the advert's duty list |
| G3 | Leg-ulcer care (R7b, important) | transferability | Pressure-ulcer and surgical-wound care carry over; no leg-ulcer work is described. Strengthener: any compression or leg-ulcer dressing experience | The employer's contact has spoken publicly on leg-ulcer clinics | Dressing or compression for venous leg ulcers; a leg-ulcer pathway on the ward or at home | A wound-care competency sign-off | `[grounded]` advert and forum speaker page; `[inferred]` the bridge |
| G4 | Doppler assessment (R12, preferred) | capability | You say you have never done one | The employer lists it as desirable | None to ask for. Closure path: training after joining, if offered | The training offer, in writing | `[grounded]` your statement and the advert |
| G5 | Continence care and care planning (R8b, R10b, important) | discovery | The CV does not mention either | Both are named duties, but they rank below the three questions asked this turn | Continence assessments, bladder or bowel care plans, writing or reviewing care plans on the ward or in discharge-to-assess | A care-plan example with patient details removed | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed live on the employer's site | unknown | — | "Join our district nursing team" | The careers address I tried returned no page. That may be a wrong address, a moved page, or a listing held elsewhere | `[grounded]` fetch returned no page; `[generic]` that careers pages move | Is this post still open, and what is the closing date? | unresolved |
| RR2 | Supported caseload | positive_signal | — | "supported by a senior community nurse" | A starting caseload is scoped and mentored | `[grounded]` advert | How large is a starting caseload, what supervision do new community nurses get in the first months, and is Doppler training offered? | noted |
| RR3 | Working pattern and travel radius unstated | unknown | — | "caring for housebound adults in their own homes" | Hours, weekend or on-call work, and the visiting radius are not stated in the advert | `[grounded]` advert silent; `[generic]` that community nursing rotas often include weekends | What are the working hours, does the rota include weekends, evenings or on-call, and how far does the caseload range? | unresolved |
| RR4 | Pay stated and in line with a survey | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The pay is transparent, and the posted range spans the survey's interquartile range | `[grounded]` advert; `[generic]` survey pattern | Where in the range would someone with five years' acute experience start, and how is mileage paid? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the discharge-to-assess secondment, described as home visits in the first week after discharge and not as a caseload | See R11 | `[grounded]` your CV | pending your approval |
| E2 | Bring wound care, catheter care and insulin administration forward on your CV, using only the wording you already have | See R7a, R8a, R10a | `[grounded]` your CV | pending your approval |
| E3 | Add a records line only after you answer G1 | See R6 | `[grounded]` R6 | pending your approval |
| E4 | Say plainly that you have not done Doppler assessment; the advert lists it as desirable | See R12 | `[grounded]` your statement and the advert | pending your approval |
| E5 | Use the informal chat the advert offers with Rhiannon Mabbott to ask RR1, RR2 and RR3 verbatim | The register doubles as interview preparation | `[grounded]` register and advert | pending your approval |

## Evidence status

Verified: none yet. I haven't used your National Insurance number, which isn't needed for this, and I haven't looked up your registration.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax". The result "About Calderbrook Community Health" (calderbrookhealth.example/about) matched the employer. Fetched calderbrookhealth.example/careers and got no page. It moved role reality's organization row and RR1 |
| 2. Role-family sweep | yes | Searched "Band 5 community staff nurse district nursing person specification Doppler preceptorship caseload", which returned no results. Searched "NHS Agenda for Change Band 5 pay scale 2026/27 community nurse", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). It moved the market calibration row and RR4. Scope norms were not established |
| 3. Hiring manager's public footprint | yes | Searched "Rhiannon Mabbott Community Nursing Team Lead", which returned "Rhiannon Mabbott — Community Nursing Team Lead, Calderbrook Community Health" (communitynursingforum.example/speakers/rhiannon-mabbott). It moved role reality's hiring-contact row and E5 |

If you'd like this saved as a `tuesday-dossier.md` to carry into later steps, say so and I'll produce it.

## Upgrade menu

- Your pay floor → R4 resolves, and the decision likely moves to `go`.
- An answer to G1 → R6 resolves, or stays `unclear` with a named limit.
- An answer to G2 → R9 resolves.
- A competency sign-off or practice-assessment record for wound care, catheter care or insulin administration → R7a, R8a and R10a move toward `high`.
- A link to the live posting or the closing date → RR1 closes.
- A deeper research pass on Calderbrook Community Health (recent news, contract and leadership changes, staff and candidate reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

R4 — What is the lowest salary you would accept for this post, and is mileage pay something you need in writing?

G1 — Have you written patient records on an electronic system, in the ward or the discharge-to-assess team? What did you record, and was it ever audited or relied on by someone else?

G2 — Have you cared for dying patients on the ward or during discharge-to-assess visits? What did you personally do, and who else was involved?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.