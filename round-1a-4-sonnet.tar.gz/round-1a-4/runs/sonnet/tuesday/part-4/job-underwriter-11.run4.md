I read both postings against your background. The web searches were declined, so no outside checks ran. I've kept that gap visible in the tables.

## Role 1: Operations Analyst, Duinvaart Cold Chain (Rotterdam)

### Decision snapshot

**Yes, worth your time. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Hybrid, three days a week in Rotterdam)
- `must_have` — direct: R2, R3, R4, R5a · adjacent: R5b (Temperature compliance tracking)
- `important` — direct: R6
- `preferred` — adjacent: R7 (Dutch a plus)

R5b — a credible bridge, its limit named; R1 — nothing yet says whether the commute works.

**Opportunity ledger.** The post has concrete deliverables (RR3). The employer is untested (RR1), the salary is not stated (RR2), and it is unclear whether you would decide route changes or only advise on them (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Hybrid, three days a week in Rotterdam); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the Rotterdam commute works for you (R1); (2) the posting is live on the employer's own site (RR1); (3) the salary clears your floor (RR2); (4) temperature compliance is framed as adjacent, never as cold-chain experience (R5b).

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Duinvaart Cold Chain, Rotterdam, operating a refrigerated fleet. Its existence and the posting's liveness are untested | `[grounded]` JD |
| Mandate | Track on-time delivery and temperature compliance; weekly Power BI dashboards; work with depot managers on route changes | `[grounded]` JD |
| Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` JD |
| Scope read | An individual-contributor analyst post: the JD has no management, hiring or budget language | `[inferred]` from the JD's verbs and what it leaves out |
| Market calibration | Not established. The role-family search was refused, so no pay band or scope norm is stated | — |
| Unknowns | Salary, contract type, team size, reporting line, authority over route changes | `[grounded]` absent from the JD |
| Contradictions | None inside the posting. The employer's careers page was not checked | `[grounded]` JD |

### Evidence map

Your background was typed in, so it counts as self-report. The ceiling at intake is `medium`.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, three days a week in the Rotterdam office | hard_gate | unclear | none | hard_gate | You are not a stated commuter or mover, and you gave no constraint. The posting's term is clear. Whether you meet it is not | `[grounded]` JD; nothing stated by you | Q1 below |
| R2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You state 4 years as an operations analyst at a parcel carrier in Amsterdam. That is self-report with no inspectable artifact yet | `[grounded]` your background | none |
| R3 | Strong SQL | must_have | direct | medium | none | You state SQL daily. "Strong" is a level your statement implies and does not show | `[grounded]` your background | A sanitized query or schema description would raise it |
| R4 | Power BI or Tableau | must_have | direct | medium | none | You state Power BI daily | `[grounded]` your background | A dashboard screenshot would raise it |
| R5a | Track on-time delivery | must_have | direct | medium | none | You state the on-time delivery dashboard your depot managers use | `[grounded]` your background | Say whether you built, maintained or used it (A1) |
| R5b | Track temperature compliance on a refrigerated fleet | must_have | adjacent | low | transferability | The bridge is threshold-versus-actual monitoring. The limit is that nothing you stated involves temperature or refrigerated freight | `[inferred]` bridge from your delivery tracking; limit `[grounded]` no cold-chain mention | G2 |
| R6 | Work with depot managers on route changes | important | direct | medium | none | You state a depot-manager audience and a weekly route-performance review you ran. You did not say changes resulted | `[grounded]` your background | Confirm what changed after reviews (A3) |
| R7 | Dutch a plus | preferred | adjacent | medium | presentation | You state conversational Dutch. The posting names no level | `[grounded]` your statement and the JD | State the level plainly on the CV |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Rotterdam office days (R1, hard_gate) | hard_gate | The term is stated and nothing says whether it works for you | An unmet gate caps the status at `hold_pending_answers` or lower | — | — | `[grounded]` JD term; nothing stated by you |
| G2 | Temperature compliance (R5b, must_have) | transferability | On-time tracking is evidenced. Temperature or refrigerated freight is not | It is half of the role's named tracking duty | Delivery-window breach reports; exception or damage-rate monitoring; any SLA threshold you tracked against a target | A sanitized exception report or dashboard screenshot | `[inferred]` that exception-style tracking would count; `[generic]` that this is the likeliest probe |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting untested | unknown | — | "Duinvaart Cold Chain — Rotterdam" | The searches were refused, so whether the employer and posting match what was pasted is untested | `[grounded]` searches refused | Is this role listed on your careers page, and who would it report to? | unresolved |
| RR2 | Salary not stated | unknown | — | no pay in the pasted posting | The figure may or may not clear your floor. No band was established | `[grounded]` posting silent; no band without a search | What salary range is budgeted for this post? | unresolved |
| RR3 | Concrete deliverables | positive_signal | — | "build weekly dashboards in Power BI" | The work is defined and its tools match your daily ones | `[grounded]` JD | Which dashboards exist today, and who reads them? | noted |
| RR4 | Authority over route changes unclear | unknown | — | "work with depot managers on route changes" | The role may advise on changes while managers decide | `[inferred]` from "work with" against silence on decision rights | Does this role propose route changes, or decide them? | unresolved |

### Application plan

Everything here is proposed, and I have changed nothing.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the summary with: 4 years as an operations analyst at a parcel carrier; SQL and Power BI daily; the on-time delivery dashboard depot managers use; ran the weekly route-performance review | see R2 to R6 | `[grounded]` your own sentences | `resume_edits_pending_approval` |
| A1 | Decide whether you built, maintained or used the dashboard before any line says which. Until then it says "used by depot managers" | see R5a | `[grounded]` your wording | pending your approval |
| A2 | Put Dutch on the CV as conversational | see R7 | `[grounded]` your statement | pending your approval |
| A3 | Ask RR1, RR2 and RR4 verbatim at the recruiter stage | the register doubles as interview preparation | `[grounded]` register | pending your approval |

## Role 2: Supply Planner, Kroonhaven Foods (Utrecht)

### Decision snapshot

**No, this one is not worth your time as written. R9, R11 and R13 are must-have requirements with no planning evidence, which you confirmed. R12 falls short of the posting's level. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R8 (On-site in Utrecht)
- `must_have` — adjacent: R12 (Fluent Dutch) · unclear: R10 (Advanced Excel) · absent: R9 (3+ years supply or demand planning in FMCG), R11 (SAP IBP or similar planning system), R13 (Own the 13-week supply plan)
- `important` — adjacent: R14 (Run the weekly S&OP meeting)

R9, R11, R13 — no planning evidence, confirmed by you; R12 (`medium`) — conversational, the posting asks fluent; R14 — a bridge through your weekly review, its limit named.

**Opportunity ledger.** The role is clearly defined (RR7). The employer is untested (RR5) and the salary is not stated (RR6).

- **Hard gates:** none failed; unconfirmed: R8 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** a version of the post that accepts an analyst background, or a recruiter who tells you planning experience is negotiable. Nothing in the posting suggests either.

### Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Kroonhaven Foods, Utrecht, with a chilled ready-meals range. Its existence and the posting's liveness are untested | `[grounded]` JD |
| Mandate | Own the 13-week supply plan; balance production capacity against forecast; run the weekly S&OP meeting | `[grounded]` JD |
| Working pattern | On-site in Utrecht | `[grounded]` JD |
| Scope read | A role that owns a planning cycle, which is an operating post and not an analyst post | `[inferred]` from "own" and "run" in the JD |
| Language of work | Fluent Dutch is required, so meetings are probably in Dutch | `[inferred]` from the JD's requirement |
| Market calibration | Not established. The search was refused | — |
| Unknowns | Salary, contract type, team size, which planning system is in use | `[grounded]` absent from the JD |

### Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R8 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Same as R1: the term is clear and you gave no constraint | `[grounded]` JD; nothing stated by you | Q1 below |
| R9 | 3+ years of supply or demand planning in FMCG | must_have | absent | none | capability | You told me you have never worked in planning. Parcel operations analysis is not FMCG planning | `[grounded]` your statement | closure path in G4 |
| R10 | Advanced Excel | must_have | unclear | none | discovery | You did not mention Excel either way | `[grounded]` silence | none, since the decision does not turn on it |
| R11 | SAP IBP or a similar planning system | must_have | absent | none | capability | You said you have no planning background, and your tools are SQL and Power BI, which are not planning systems | `[grounded]` your statement | closure path in G4 |
| R12 | Fluent Dutch | must_have | adjacent | medium | transferability | You state conversational, not fluent. The limit is that running a meeting in Dutch needs the higher level | `[grounded]` your statement and the JD | G3 |
| R13 | Own the 13-week supply plan | must_have | absent | none | capability | No planning work in your history | `[grounded]` your statement | closure path in G4 |
| R14 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. The limit is that nothing says it was cross-functional or tied to a plan | `[grounded]` your background; limit `[grounded]` silence | G3 |

### Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G3 | Dutch level and meeting facilitation (R12, R14) | transferability | Conversational Dutch and a weekly review you ran | Meetings run in Dutch are central to this role | A CEFR-level result or course certificate; a meeting you ran with other departments | A certificate or an agenda | `[inferred]` from your statement; `[generic]` that fluency is checked in the interview |
| G4 | Planning experience and tools (R9, R11, R13) | capability | None stated, and you confirmed it | Three must-haves are absent | A realistic path is a planning-adjacent role first, or an analyst post that feeds a planning team | A planning course or certification would start a path | `[grounded]` your statement; `[inferred]` path |

### Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR5 | Employer and posting untested | unknown | — | "Kroonhaven Foods — Utrecht" | The searches were refused, so nothing about the employer is checked | `[grounded]` searches refused | Is this role listed on your careers page, and who would it report to? | unresolved |
| RR6 | Salary not stated | unknown | — | no pay in the pasted posting | No figure and no band | `[grounded]` posting silent; no band without a search | What salary range is budgeted for this post? | unresolved |
| RR7 | Clearly defined ownership | positive_signal | — | "Own the 13-week supply plan" | The role has clear authority and cadence | `[grounded]` JD | What does the plan accuracy target look like? | noted |

### Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A4 | If you apply anyway, treat RR5 and RR6 as essential questions, and describe R14's bridge as adjacent only | the user decides; the register travels with you | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht" were refused. They would have moved role reality's organization rows and RR1 and RR5 |
| 2. Role-family sweep | unavailable | Searches for operations analyst pay in Rotterdam and supply planner pay in FMCG were refused. They would have moved the market calibration rows and RR2 and RR6 |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

I'll offer to save this as `tuesday-dossier.md` once you've seen it.

## Upgrade menu

- Your current resume text would confirm the claims above and could lift R2 to R5a toward `high`.
- A sanitized dashboard screenshot or sample query would raise R3, R4 and R5a.
- A recruiter's answer on salary and contract closes RR2 and RR6.
- Search permission would let the official-site and pay-band checks run on the budget left (one search and two fetches).

## Questions

Q1 (G1, R1 and R8): What is the longest commute or the number of office days you can take, and would you relocate? Rotterdam is three days a week and Utrecht is five.
Q2 (G2, R5b): Have you tracked any breach, exception or damage-rate data against a threshold? What did you own?
Q3 (RR2 and RR6): What is your pay floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.