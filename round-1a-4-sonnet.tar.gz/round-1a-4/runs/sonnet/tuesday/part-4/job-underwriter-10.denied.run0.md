I'm running the job-underwriter on this. The web searches I tried were refused, so what follows rests only on your posting and messages.

## Decision snapshot

**Yes, worth pursuing, on conditions: the employer has to verify (RR1) and the pay has to clear your floor (R2). Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Salary €52,000–€60,000 against your pay floor)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R8 (Run research calls with school owners), R9 (First designer, no design peer)

R7 — checkout is a bridge, its limit named; R8 — adjacent, discovery open; R2 — waiting on your floor.

**Opportunity ledger.** The posting is specific and open about its terms (RR4), but the employer is not established from here (RR1), and equity terms and funding are unstated (RR2, RR3). On whether it is legit: I can't establish Fernquay from here and no search ran. Nothing you've shared asks you for money, bank details or ID (Role reality, Contact channel).

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000 against your pay floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer verifies as a live hiring employer, see RR1; (2) the band clears your floor, see R2; (3) the equity terms are stated, see RR2.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting; no outside page corroborates it |
| Mandate | First designer: own the booking flow end to end, run research calls with school owners, ship alongside two engineers | `[grounded]` posting |
| Working partner | "Work most closely with our co-founder, Ronan Kehoe" | `[grounded]` posting |
| Pay and equity | €52,000–€60,000 plus 0.5–1% equity; equity terms not stated | `[grounded]` posting |
| Working pattern | Hybrid: two days a week in the Galway office, the rest from wherever suits | `[grounded]` posting |
| Contact channel | Ronan messaged you on WhatsApp to schedule a 45-minute video call with the CTO, Saoirse, and emailed an invite with the link. The message asks for no payment, bank details or ID. Scheduling by chat for an interview held on video is routine, so it gets no register entry. | `[grounded]` your message quoted; `[generic]` that chat scheduling for a video interview is routine |
| Scope read | A tightly defined first-designer post: one flow, one research audience, two engineers. No first-90-day outcomes stated. | `[inferred]` from the posting's scope list and its silence on outcomes |
| Market calibration | Not established. The salary search was refused, so there is no band to set the posting's figure against. | `[grounded]` posting for the figure; nothing else |
| Unknowns | Registered employer identity, funding and runway, equity terms, contract basis (permanent or fixed-term), what has shipped, who decides product direction | `[grounded]` posting silent on each |
| Contradictions | None between the posting and the WhatsApp message. The CTO appears only in the message. No outside page was read to compare. | `[grounded]` both texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Two days a week at the Galway office | hard_gate | direct | medium | none | You moved back to Galway last year, so the office days are reachable. Your tolerance for two fixed days isn't stated. | `[grounded]` your message, posting | none |
| R2 | Salary €52,000–€60,000 plus equity | hard_gate | unclear | none | hard_gate | The posting states the band. You haven't given a floor, so whether it clears is not established. Confidence is `none` because there is no statement of yours to grade. | `[grounded]` posting; your floor absent | Closing question R2 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer at a Dublin travel-booking company, stated by you. No CV or portfolio inspected. | `[grounded]` your message | none |
| R4 | Strong Figma | must_have | direct | medium | none | Figma daily. "Strong" also rests on the checkout case study Ronan's message says they liked, which I haven't seen. | `[grounded]` your message, Ronan's message | The case study link or a Figma file would raise this to `high` |
| R5 | You have run your own user research | must_have | direct | medium | none | You ran monthly usability sessions with customers. Whether you planned, recruited and synthesised them yourself isn't stated. | `[grounded]` your message | A sanitised research plan or session synthesis would raise this to `high` |
| R6 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers. | `[grounded]` your message | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned a checkout flow at a travel-booking company, which is a bridge. Limit: checkout is one stage of a booking flow, and who made decisions beyond your own work isn't stated. | `[grounded]` your message; `[generic]` that booking flows span more than checkout | G1 |
| R8 | Run research calls with school owners | important | adjacent | medium | discovery | Your sessions were usability sessions with customers. Calls with school owners are conversations with the business buying the software, which is a different kind of work. Whether you've done those isn't known. | `[grounded]` your message; `[inferred]` the buyer-side difference | G2 |
| R9 | First designer, no design peer | important | adjacent | medium | transferability | You have never been the only designer. The adjacent evidence is four years of squad work and monthly research. Limit: no experience of setting design direction or standards without other designers is stated. | `[grounded]` your message | G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Whole-flow ownership (R7, must_have) | transferability | A confirmed checkout redesign. Nothing on the stages around it or on who made the final calls. | R7 is a `must_have` at `adjacent`. Narrowing the limit decides how honestly you can frame the case study. | Owning availability-to-confirmation; redesigning an amend or cancel path; agreeing scope with product and engineering | The case study, a before/after flow diagram, a Figma file | `[grounded]` your message; `[generic]` that booking flows span more than checkout |
| G2 | Research with business owners (R8, important) | discovery | Usability sessions with customers only | Research calls with school owners is a named duty, and the buyer side may be new to you | Calls with partner or supplier users; interviews with support or ops teams about owner-side pain; sales-call observation | An interview guide or synthesis notes | `[grounded]` your message silent on this |
| G3 | First-designer practice (R9, important) | transferability | Squad work with peers around you | Fernquay has no design peers, so judgment without a design lead is the limit | A project where you set the standards; a component library; critique you ran with engineers; a solo side project | A shipped project where you were the only designer, a design-principles doc | `[grounded]` your message |

G2 and G3 are not asked this turn. They rank below the three questions in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software for sea-kayak and surf schools." | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer. You also found little online. | `[generic]` pattern for companies of this size, not a claim about this one | Could you point me to this role on Fernquay's own website, and say which registered company would be my employer? | unresolved |
| RR2 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The equity may be options or shares with vesting, a cliff and a price the posting doesn't give, and its worth depends on those terms. | `[grounded]` posting silent on terms; `[generic]` that worth depends on terms | Is the 0.5–1% options or shares, what are the vesting schedule and cliff, and what share count is it measured against? | unresolved |
| RR3 | Funding and runway unstated | unknown | — | "We are six people in Galway" | The team may be funded by revenue, investment or both; the posting doesn't say. | `[inferred]` from the posting's silence | How is the team funded, and how many months of runway does that give? | unresolved |
| RR4 | Pay, scope and working partner stated | positive_signal | — | "Salary €52,000–€60,000 plus 0.5–1% equity"; "own the booking flow end to end" | The band and scope are concrete enough to test against your floor before you invest time. | `[grounded]` posting states both | How was the band set, and is there room within it? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Before the call, check that the invite email came from an address on the same domain as Fernquay's own website. Join only through the link in that email, and pay or send nothing. | see RR1; Ronan's message says an invite was emailed | `[grounded]` your message | pending your approval |
| A2 | Settle your pay floor before the call, so R2 can close in the conversation. | see R2 | `[grounded]` posting band | pending your approval |
| A3 | Put RR1, RR2 and RR3's questions to Ronan and Saoirse, RR1's first. | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A4 | Positioning: bring the checkout case study, since the posting says they "would rather see one messy real project than a polished deck". Say only what you wrote: you redesigned the checkout flow, ran monthly usability sessions with customers, worked in a squad with four engineers, and have not been the only designer. | see R5, R7, R9 | `[grounded]` posting quote, your sentences | pending your approval |

Rehearsing the call itself is the mock-interview module's job. Say the word and I'll switch.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused ("Fernquay booking software sea kayak surf schools Galway" and "Fernquay product designer careers Galway"). They would have moved Role reality's organization and contradictions rows and RR1. |
| 2. Role-family sweep | unavailable | One search was refused ("product designer salary Ireland startup first designer equity"). It would have moved Role reality's market calibration and R2. |
| 3. Hiring manager's public footprint | unavailable | One search was refused ("Ronan Kehoe Fernquay co-founder"). It would have moved the scope read and A4's positioning. |

I can offer a one-sentence dossier: I can write this up as a `tuesday-dossier.md` for you to keep, if you want it.

## Upgrade menu

- A link to the posting on Fernquay's own site, plus the registered company name → RR1 closes and the cap on `conditional_go` lifts.
- Your pay floor → R2 closes.
- The checkout case study or a Figma file → R4 to `high`, and G1 can be answered from it.
- A sanitised research plan or synthesis → R5 to `high`.
- Permission to run web search → targets 1–3 above run. A deeper pass on Fernquay (funding, news, public reports; up to 5 more searches and 2 more fetches) is offered here once.

## Questions

R2 — What is the lowest salary you would accept for this role, and does the €52,000–€60,000 band clear it?

RR1 — Where did you apply, on a page of Fernquay's own website or on a job board, and can you send me that link?

G1 — On the checkout redesign, which stages of the booking journey did you personally own, and who made the final design decisions?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.