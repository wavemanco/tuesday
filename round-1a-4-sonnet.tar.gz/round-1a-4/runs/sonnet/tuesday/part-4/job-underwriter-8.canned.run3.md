I searched twice and both came back empty. Here is the assessment.

## Decision snapshot

**No, don't go ahead: RR1, RR2, RR3 and RR4 are confirmed severe red flags. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Earn up to €26 an hour, 15–30 hours a week)
- `must_have` — direct: R2, R3
- `important` — adjacent: R4 (strong attention to detail)
- `preferred` — unclear: R5 (a quiet place to work)

R1 — pay is a ceiling and hours are a range, so your €30,000 floor is not settled; R4 — a credible bridge, its limit named.

**Opportunity ledger.** The role fails on its own terms. The messages ask for money (RR1), a cheque deposit (RR2), and bank, tax and ID details before any offer (RR3), and the hiring is wholly by chat (RR4). The offer's contact address is not clearly the employer's (RR5), and the employer could not be established (RR6). Your background fits what the posting asks for. That does not offset the opportunity side.

- **Hard gates:** none failed; unconfirmed: R1 (Earn up to €26 an hour, 15–30 hours a week).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would change this:** the employer confirmed independently through its own website. The payment, cheque and pre-offer ID requests withdrawn. An interview by call or video and a written offer. R1's pay confirmed at or above your floor.

I can't establish the firm from here. Please don't paste your IBAN anywhere. Nothing here needs your IBAN, PPS number or passport, and I haven't repeated any of them.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Velloway Logistics; two searches returned no results, which establishes nothing either way | `[grounded]` search results, JD header |
| Role | Remote Order Processing Coordinator, 15–30 hours a week, "set your own hours" | `[grounded]` JD |
| Pay | "up to €26 an hour plus commission"; the commission terms are not stated | `[grounded]` JD |
| Hiring process | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | `[grounded]` JD |
| Market calibration | Not calibrated: the role-family search returned nothing, so there is no band to set the pay against | `[grounded]` search results |
| Unknowns | Employer identity, hourly rate, commission basis, contract type | — |
| Contradictions | None found, since nothing independent was available to compare against | `[grounded]` search results |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pay of at least €30,000 a year (your floor) against "up to €26 an hour", 15–30 hours | hard_gate | unclear | high | hard_gate | Confidence grades your own floor, which is specific and confirmed. Fit is unclear because the posting gives a ceiling rate and a range of hours. At €26 for 52 weeks, €30,000 needs about 22 hours a week | `[grounded]` your stated floor, the JD's figures and the arithmetic | Only the employer's written rate and hours could settle it; moot while RR1 to RR4 stand |
| R2 | Confident with spreadsheets | must_have | direct | medium | none | You keep your team's weekly tracker in Excel. Confirmed and specific, no inspectable artifact yet | `[grounded]` your account | none |
| R3 | Good written English | must_have | direct | medium | none | Zendesk ticket work is written contact, and you train new starters. The written nature of the tickets is my reading | `[grounded]` your account; `[inferred]` tickets are written replies | none |
| R4 | Strong attention to detail | important | adjacent | medium | discovery | Tracker upkeep and ticket volume are nearby evidence. Neither measures accuracy, which is the limit | `[grounded]` your account | none: the decision does not turn on it; an accuracy figure for the tracker would raise it |
| R5 | A quiet place to work | preferred | unclear | none | discovery | You haven't said, and no question is spent on it | `[grounded]` silence in your message | none: yours to judge |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pay against your floor (R1, hard_gate) | hard_gate | A ceiling rate, a range of hours, and commission with no terms | A rate below your floor would fail this gate even if the rest held | Not applicable: this is a term, not experience | The employer's written rate and hours, found on its own website | `[grounded]` JD wording against your floor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Payment for equipment demanded | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | You would pay before any wage, with repayment promised later. The sender's identity is unresolved | `[generic]` pay-first, refund-later is a known pattern, not a claim about any named party | Does your company ask new hires to pay for equipment, and where do your own hiring pages say so? Ask through contact details you find yourself on the employer's own site | confirmed |
| RR2 | Cheque deposit, part to be sent on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the rest to our equipment partner." | A cheque credited to an account may later be reversed, leaving any money you sent on as your loss | `[generic]` banking pattern, not a claim about any named party | Does your company pay new hires by sending cheques to deposit and pass on? Same route as RR1 | confirmed |
| RR3 | Bank, tax and ID details requested before any offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport" | These details would be held by someone not yet shown to be the employer | `[generic]` pattern for pre-offer requests | Does your company collect bank, tax and ID details before a written offer? Same route as RR1 | confirmed |
| RR4 | Hiring wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | No call, video or in-person step means who is hiring cannot be checked | `[inferred]` from the JD's own wording | Can I interview by call or video with someone named on your website? Same route as RR1 | confirmed |
| RR5 | Offer and contact not clearly from the employer | risk_signal | medium | "Any problems, email velloway.hr@postmail.example" | The offer closed a chat-only process and gives a mail address I can't compare to an employer domain | `[inferred]` from the offer's wording against the lack of any employer site | Which email address does your HR team publish on your own website? | unresolved |
| RR6 | Employer not established from attributable sources | risk_signal | medium | "Remote Order Processing Coordinator — Velloway Logistics" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR7 | Pay terms vague | unknown | — | "up to €26 an hour plus commission on every order you process" | The top rate may be a ceiling that few roles reach, and the commission basis is not stated | `[inferred]` from "up to" and the missing commission terms | What is the starting hourly rate, and how is commission calculated? | unresolved |

Hold each of these until you have checked it with the employer, through contact details on the employer's own website rather than the chat or the address these messages came from. Who sent them is not yet confirmed. This job is very likely a scam. Don't pay anything, and don't deposit the cheque.

I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't send your IBAN, PPS number or passport photo | Asked before any offer; see RR3 | `[grounded]` the messages | advice, your call |
| A2 | Don't pay the €349 | See RR1 | `[grounded]` the messages | advice, your call |
| A3 | If the cheque arrives, don't lodge it or transfer any of it | See RR2 | `[grounded]` the messages | advice, your call |
| A4 | Stop replying until you've confirmed who sent these messages. Look for the company on its own website, and consider reporting the posting to the jobs site | See RR4, RR5, RR6 | `[generic]` standard verification step | advice, your call |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Velloway Logistics"; no results, so the employer is not established (RR6) and role reality's organization row stays open |
| 2. Role-family sweep | yes | Searched "remote order processing coordinator no experience Telegram cheque equipment fee job scam warning"; no results. It moved nothing, and the pay band stays uncalibrated |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

Say yes if you'd like this saved as `tuesday-dossier.md`.

- A link to the role on a company website or careers page → RR6 and RR5 can close or confirm.
- The employer's written hourly rate, commission terms and hours → R1 and RR7 close.
- A hiring manager's name → role reality's scope read.
- A deeper research pass (up to 5 more searches and 2 more fetches) — say the word and it runs.

**Question**

RR3 — In your Telegram interview answers, did you give anything beyond work history, such as your address, date of birth, phone number or any financial detail?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.