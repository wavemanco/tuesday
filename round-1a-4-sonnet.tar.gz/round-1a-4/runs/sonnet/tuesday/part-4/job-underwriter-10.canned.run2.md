Four searches done and the company checks out. I'm fetching its careers page to compare it with the posting you were sent, then I'll write up the assessment.
# Job Underwriting — Product Designer at Fernquay

## Decision snapshot

**Yes, it's worth pursuing, and the company and posting check out on what I could find (RR1). Status: `conditional_go`.** Because you've already applied, this is about whether to take the call and see it through.

**Fit ledger.**

- `hard_gate` — unclear: R7 (Hybrid, two days in Galway), R8 (Pay of €52,000–€60,000 against your floor)
- `must_have` — direct: R1, R2, R3, R4 · adjacent: R5 (Own booking flow end to end)
- `important` — adjacent: R6 (First designer, no design peers)

R5 — a credible bridge, its limit named; R6 — squad experience, not solo ownership.

**Opportunity ledger.** The employer and the posting are consistent with each other (RR1), and the pay is stated and falls inside the salary band I found (RR4). Support for a sole designer (RR2), the equity terms (RR3) and how long the company can fund itself (RR5) are open.

- **Hard gates:** none failed; unconfirmed: R7 (Hybrid, two days in Galway), R8 (Pay of €52,000–€60,000 against your floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) you confirm R7 and R8 work for you; (2) the equity terms come in writing — RR3; (3) you learn what design support exists around a first designer — RR2; (4) the R5 and R6 bridges are framed as adjacent, never as sole ownership.

**On the WhatsApp message:** arranging a video call by chat is a routine step. It asks you for nothing: no money, no documents, no personal details. The two people named on the call are both listed on the company's own about page (RR1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle, funded by its customers. It makes Kelproster, booking software for sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` "About Fernquay" (search result) |
| Mandate | First design hire: own the booking flow, run research calls with school owners, ship with two engineers, work closely with Ronan Kehoe | `[grounded]` posting |
| Working pattern and pay | Hybrid, two days a week in Galway, €52,000–€60,000 plus equity | `[grounded]` posting and careers page, which agree |
| Hiring manager | Ronan Kehoe is listed as co-founder and CEO, and earlier spent five years as a product lead at a Galway travel-software company | `[grounded]` search-result profile, not opened in full |
| Scope read | Broad but coherent for a six-person company: one flow, research and shipping. There is no stated design lead or peer | `[inferred]` from the posting's "first designer" and the team size |
| Market calibration | For product designers with 3 to 5 years in Ireland, a 2026 survey (n=520) gives a median base of €57,000 and an interquartile range of €51,500–€62,000. The posted range sits inside it. This is a market band, not this employer's offer | `[generic]` one salary report, read as a search snippet |
| Unknowns | Equity terms; who you would report to day to day; runway; how research access to school owners works | — |
| Contradictions | None between the posting and the careers page. The page gives no equity percentage, and "apply with one real project" matches the posting's "one messy real project" | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 3+ years of product design | must_have | direct | medium | none | Four years at a Dublin travel-booking company. This is self-reported, so there is no inspectable artifact yet | `[grounded]` your background | none |
| R2 | Strong Figma | must_have | direct | medium | none | You use Figma daily. Self-reported, with no artifact inspected | `[grounded]` your background | none |
| R3 | You have run your own user research | must_have | direct | medium | none | Monthly usability sessions with customers. Limit: that is evaluative testing, and the role adds discovery calls with school owners | `[grounded]` your background | none |
| R4 | Happy working directly with engineers | must_have | direct | medium | none | You worked in a squad with four engineers | `[grounded]` your background | none |
| R5 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned the checkout flow, which is one part of a booking flow. Limit: nothing stated covers the rest of the journey | `[grounded]` your background; `[inferred]` that checkout is only part of a booking flow | See G1 |
| R6 | Be the first designer, with no design peers (implied by "our first designer") | important | adjacent | medium | transferability | Four years in a squad, but you have never been the only designer anywhere | `[grounded]` your background and posting wording | See G2 |
| R7 | Hybrid, two days a week at the Galway office | hard_gate | unclear | none | hard_gate | You live in Galway, but you haven't said whether two office days fit. Confidence is `none` because no constraint was given | `[grounded]` posting and your move back to Galway | See G3 |
| R8 | Pay of €52,000–€60,000 plus equity | hard_gate | unclear | none | hard_gate | The posting states the pay. Your floor wasn't given, so this can't be checked against it | `[grounded]` posting; your floor not given | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Booking flow beyond checkout (R5, must_have) | transferability | A checkout redesign, but nothing about search, availability, selection or confirmation | The role is built around the whole booking flow, so the gap between one stage and the journey is where an interview will probe | Work on earlier booking steps, such as picking dates, options or group sizes; handoffs between checkout and the screens before it; changes you made to the journey after the redesign shipped | The checkout case study you already sent, plus any before-and-after flow | `[grounded]` your stated scope; `[generic]` that a first designer is expected to cover the whole journey |
| G2 | Working as the only designer (R6, important) | transferability | Four years in a squad, with no stated stretch of working without design peers | A sole designer sets their own standards and has no one to review the work, which is what the role needs | A project you drove without a design review; setting up a component library or design conventions; choosing research methods yourself | A short example of design decisions you made on your own | `[grounded]` your stated background; `[generic]` that first-designer roles rely on self-direction |
| G3 | Two office days and the pay floor (R7 and R8, hard_gate) | hard_gate | Whether two office days a week and the pay range fit your constraints is not established | These are terms you either meet or don't, and no amount of wording changes that | — | — | `[grounded]` constraints not given |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting consistent | positive_signal | — | "We are six people in Galway making booking software for sea-kayak and surf schools" | The company exists as described and the posting is live. The evidence is the company's own pages and one profile; no independent customer or press coverage appeared in the searches run | `[grounded]` about page, careers page and profile found | Who are two or three school customers you could name? | noted |
| RR2 | Support for a sole designer unknown | unknown | — | "You would be our first designer" | There may be no design mentorship or review beyond the two founders | `[inferred]` from "first designer" and the team size | Who gives feedback on design work, and what do the founders expect to decide themselves? | unresolved |
| RR3 | Equity terms unstated | unknown | — | "plus 0.5–1% equity" | The percentage is stated but not the vesting, the type of shares or the current share count | `[inferred]` from the posting giving a percentage with no terms | What are the vesting schedule, the share class and the fully diluted share count? | unresolved |
| RR4 | Pay stated and within the sampled band | positive_signal | — | "€52,000–€60,000" | The posted range falls inside the interquartile range of one salary report | `[grounded]` posting; `[generic]` the survey band | Is the range fixed, or does it depend on experience? | noted |
| RR5 | Runway unknown | unknown | — | "funded by its customers" | With no outside funding, how long the company can pay salaries depends on revenue I can't see | `[grounded]` about page for the funding source; `[inferred]` that runway is therefore unstated | How many months of runway does the company have at its current revenue and headcount? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | In the call, lead with your travel-booking checkout redesign and the monthly usability sessions, stated as what they were: one stage of the flow, and testing with customers. Don't describe either as owning the whole journey or running discovery with owners | See R3, R5. Ronan Kehoe previously led product at a travel-software company, so booking-flow work may be familiar to him | `[grounded]` your own sentences; `[inferred]` the relevance from his profile | pending your approval |
| Q1 | Ask the verification questions from RR2, RR3 and RR5 aloud on the call | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A1 | Before the call, check that the calendar invite came from an address at the company's own domain. The careers page gives jobs@fernquay.example, so that is the domain to match | Joining a call from an invite you can match to the company is a cheap check | `[grounded]` careers page | pending your approval |

You have a 45-minute call coming up, and the mock-interview module can build a prep pack for it.

## Evidence status

Verified: none yet.

Research tier: L1 — searches 4 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay booking software sea kayak surf schools Galway" and "Fernquay Product Designer Galway careers". Read the search result "About Fernquay" (fernquay.example/about) and fetched "Product Designer — Fernquay careers" (fernquay.example/careers/product-designer). Moved the organization and contradictions rows, RR1 and the funding detail in RR5 |
| 2. Role-family sweep | yes | Searched "product designer salary Ireland Galway mid-level 2026", which returned "Tillerby 2026 Ireland Design Salary Report" (tillerby.example/2026-ireland-design-salary-report). Moved the market calibration row and RR4 |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe Fernquay co-founder", which returned "Ronan Kehoe — Co-founder, Fernquay" (linkedin.example/in/ronan-kehoe). Moved the hiring-manager row and E1 |

I'd happily save this as a `tuesday-dossier.md` if you want to carry it into later steps.

## Upgrade menu

- Your pay floor and whether two office days a week work for you → R7 and R8 move to `direct`, or to a failed gate.
- A link to the checkout case study you submitted → R1 to R5 can rise to `high`, and G1 narrows.
- Any example of working without design review → G2 narrows.
- Answers from the call on equity, runway and support → RR2, RR3 and RR5 close.
- A deeper research pass on Fernquay (customers, founders' history, any press; up to 5 more searches and 2 more fetches) — say the word and it runs.

**Questions**

- R8 — What is your minimum acceptable salary, and does equity at 0.5–1% matter to you or not?
- R7 — Are two days a week at the Galway office fine for you?
- G1 — Which parts of the booking journey beyond checkout have you worked on, and what was yours rather than the squad's?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.