**Worth your time?** **Duinvaart (Operations Analyst): yes, as `conditional_go`. Kroonhaven (Supply Planner): no, as `no_go`.** Kroonhaven's answer rests on B2, B4 and B6, three must-have rows that are `absent`.

Both postings were assessed on the facts you gave me and the posting text only. My web searches on both companies were declined, so I could not check either employer. Every judgement about the employers or the market below is labelled accordingly.

## Decision snapshot

### A. Operations Analyst, Duinvaart Cold Chain, Rotterdam: `conditional_go`

**Fit ledger.**
- `hard_gate` — unclear: A1 (Hybrid, three office days in Rotterdam)
- `must_have` — direct: A2, A3, A4, A5a
- `important` — adjacent: A5b (Temperature compliance across refrigerated fleet), A6 (Work with depot managers on route changes)
- `preferred` — adjacent: A7 (Dutch a plus)

A1 — the one gate left open, waiting on your answer; A5b — a credible bridge, its limit named; A6 — confirmed review work, the link to route changes not yet.

**Opportunity ledger.** The duties are concrete and measurable (RA3). The employer is unchecked (RA1) and the pay is withheld (RA2).

- **Hard gates:** none failed; unconfirmed: A1 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) three office days in Rotterdam works for you (A1); (2) the posting is live on Duinvaart's own careers page (RA1); (3) the pay is acceptable once stated (RA2).

### B. Supply Planner, Kroonhaven Foods, Utrecht: `no_go`

**Fit ledger.**
- `hard_gate` — unclear: B1 (On-site in Utrecht)
- `must_have` — adjacent: B5 (Fluent Dutch) · unclear: B3 (Advanced Excel) · absent: B2 (3+ years supply or demand planning in FMCG), B4 (SAP IBP or similar planning system), B6 (Own the 13-week supply plan)
- `important` — adjacent: B7 (Run the weekly S&OP meeting)

B2, B4 and B6 — no planning evidence; B5 — a credible bridge, its limit named; B3 — waiting on an answer.

**Opportunity ledger.** The employer is unchecked (RB1), the pay is withheld (RB2), and the posting gives no success measures for the plan it asks you to own (RB3).

- **Hard gates:** none failed; unconfirmed: B1 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** the status is `no_go` because B2, B4 and B6 are capability gaps with no near-term closure path. It would move only if you hold planning-system or forecasting work you haven't mentioned. Your note that you've never worked in planning is why I haven't assumed any.

## Role reality

| Role | Element | What it is | Provenance |
|---|---|---|---|
| A | Organization | Duinvaart Cold Chain, Rotterdam, with a refrigerated fleet | `[grounded]` posting header |
| A | Mandate | Track on-time delivery and temperature compliance, build weekly Power BI dashboards, work with depot managers on route changes | `[grounded]` posting |
| A | Working pattern | Hybrid, three days a week in the Rotterdam office | `[grounded]` posting |
| A | Scope read | An analyst post that reports on the fleet and does not own the plan. Your dashboard and route-review work is the same kind of work | `[inferred]` from the posting's verbs ("track", "build", "work with") against your background |
| A | Market calibration | Not calibrated: the role-family search was declined, and the posting withholds pay | `[grounded]` posting silent; research unavailable |
| A | Unknowns | Pay; whether temperature data sits in a system you would query; who the hiring manager is | `[grounded]` posting silent |
| B | Organization | Kroonhaven Foods, Utrecht, with a chilled ready-meals range | `[grounded]` posting header |
| B | Mandate | Own the 13-week supply plan, balance production capacity against the forecast, run the weekly S&OP meeting | `[grounded]` posting |
| B | Working pattern | On-site in Utrecht | `[grounded]` posting |
| B | Scope read | An owner post for a perishable range, where the plan itself is the job | `[inferred]` from "own" and the 13-week horizon |
| B | Market calibration | Not calibrated: research was declined, and the posting withholds pay | `[grounded]` posting silent; research unavailable |
| B | Unknowns | Pay; authority over production decisions; how success is measured | `[grounded]` posting silent |

## Evidence map

The candidate-side evidence comes from your typed background, which I treat as a CV-equivalent self-report. That is why no row sits above `medium` except where noted.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| A1 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | You have not stated a constraint, so there is no statement to grade and the posting's term is unsettled | `[grounded]` posting; constraints not given | Q1 below |
| A2 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | You describe 4 years as an operations analyst at a parcel carrier, which meets the stated minimum. Self-reported, nothing inspectable yet | `[grounded]` your background | none |
| A3 | Strong SQL | must_have | direct | medium | none | You say you use SQL daily. "Strong" is a depth claim no one has probed, so it stays `medium` | `[grounded]` your background; `[generic]` that analyst loops often test SQL live | Be ready for a SQL exercise |
| A4 | Power BI or Tableau | must_have | direct | medium | none | You use Power BI daily and built the on-time delivery dashboard your depot managers use | `[grounded]` your background | A sanitized screenshot of that dashboard would raise it to `high` |
| A5a | Track on-time delivery | must_have | direct | medium | none | The same dashboard is on-time delivery tracking for a parcel carrier | `[grounded]` your background | none |
| A5b | Temperature compliance across a refrigerated fleet | important | adjacent | low | transferability | Nothing you stated touches temperature or condition data. The adjacency is KPI-compliance tracking, and the limit is that the data and thresholds differ | `[inferred]` from your on-time work as the nearest adjacent duty | GA2 |
| A6 | Work with depot managers on route changes | important | adjacent | medium | discovery | Depot managers use your dashboard and you ran the weekly route-performance review. Whether those reviews led to route changes is not stated, so I read it downward | `[grounded]` your background | Q3 below |
| A7 | Dutch a plus | preferred | adjacent | medium | transferability | Your Dutch is conversational, which is partial against "a plus". It meets the bar only as far as your level goes | `[grounded]` your statement | State your level plainly as "conversational" |
| B1 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | No constraint stated, so the term is unsettled | `[grounded]` posting; constraints not given | Fold into Q1's answer if travel matters |
| B2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | You have never worked in planning, and a parcel carrier is not FMCG. This is not a gate, since a years requirement is graded like any other row | `[grounded]` your statement | closure path in GB1 |
| B3 | Advanced Excel | must_have | unclear | low | discovery | You mention SQL and Power BI, not Excel. Analytics work suggests spreadsheet skill, but nothing states it | `[inferred]` from your tooling | GB3 |
| B4 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning-system use stated, and Power BI is a reporting tool | `[grounded]` your statement | closure path in GB1 |
| B5 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational is partial against fluent, and the limit is named | `[grounded]` your statement | GB2 |
| B6 | Own the 13-week supply plan and balance capacity against forecast | must_have | absent | none | capability | No planning ownership in your background | `[grounded]` your statement | closure path in GB1 |
| B7 | Run the weekly S&OP meeting | important | adjacent | medium | transferability | You ran a weekly route-performance review. The limit: S&OP is a forward-looking, cross-functional planning meeting, while a route review looks back at performance | `[grounded]` your background; `[generic]` on what S&OP involves | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| GA1 | Three office days in Rotterdam (A1, hard_gate) | hard_gate | The posting states the term; your constraints are not given | A gate the inputs do not settle stays open | — | — | `[grounded]` posting |
| GA2 | Temperature compliance (A5b, important) | transferability | Strong on-time KPI tracking. Nothing stated on condition data. The bridge is compliance-style reporting. The limit is that thresholds and sensor data are new | The posting names temperature compliance next to on-time delivery | Any SLA-breach or exception reporting; a view built on time-stamped condition or scan data; alerting you set up for missed targets | A sanitized dashboard page showing breach tracking | `[inferred]` bridge from your on-time work |
| GA3 | Route changes with depot managers (A6, important) | discovery | You ran the route-performance review. The CV-style summary does not say what changed | It is the posting's collaboration duty | A review that led a depot to change a route, cut-off or loading order; a recurring action list you tracked | A review deck, a minuted action list, a before-and-after metric | `[grounded]` your summary's silence on outcomes |
| GB1 | Planning ownership (B2, B4, B6, must_have) | capability | No planning evidence after intake. This is a statement about the evidence, not about you | These three rows decide Kroonhaven's status | — | — | `[grounded]` your statement; `[generic]` that planner-track roles at lower levels exist as a stepping stone |
| GB2 | Dutch level (B5, must_have) | transferability | Conversational versus fluent. A credible bridge, but the limit is real | Planners run meetings in Dutch | Workplace Dutch you already use; a formal level certificate | A language certificate | `[grounded]` your statement |
| GB3 | Advanced Excel (B3, must_have) | discovery | Silent on Excel | Does not move B's status | Models, pivots or lookups you built for planning-like work | A sanitized workbook | `[inferred]` |

For GB1, the realistic closure path is a planning-adjacent entry role (forecast or demand analyst, or junior planner) that does not ask for 3+ years of FMCG planning. That is a direction, not something these postings offer.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | Employer not verified (Duinvaart) | unknown | — | "Duinvaart Cold Chain, Rotterdam" | Research was declined, so I cannot say whether the posting is live on the company's own site | `[grounded]` research unavailable | Can you point me at this role on your own careers page, and say who I would be working with? | unresolved |
| RA2 | Pay withheld | unknown | — | no figure stated | The figure may sit anywhere in the band, or the employer may not publish pay | `[inferred]` from the posting's silence | What is the budgeted salary range for this post? | unresolved |
| RA3 | Concrete, measurable duties | positive_signal | — | "Track on-time delivery and temperature compliance … build weekly dashboards in Power BI" | Scope is defined and success can be seen | `[grounded]` posting | What would a strong first quarter look like in this role? | noted |
| RB1 | Employer not verified (Kroonhaven) | unknown | — | "Kroonhaven Foods, Utrecht" | Research was declined, so the posting is unchecked | `[grounded]` research unavailable | Can you point me at this role on your own careers page? | unresolved |
| RB2 | Pay withheld | unknown | — | no figure stated | As RA2 | `[inferred]` from the posting's silence | What is the budgeted salary range? | unresolved |
| RB3 | Ownership of a plan with no stated success measure | unknown | — | "Own the 13-week supply plan" | Accountability may sit without defined measures or decision rights | `[inferred]` from the posting's scope against its silence | Which numbers is this role judged on, and which production decisions does it make alone? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | For Duinvaart, lead with your own words: the "on-time delivery dashboard our depot managers use" and "ran our weekly route-performance review", alongside "SQL and Power BI daily" and "4 years as an operations analyst at a parcel carrier". Add no figure or outcome you haven't told me | see A2, A3, A4, A5a, A6 | `[grounded]` your background | pending your approval |
| P2 | Say your Dutch is conversational, in your own word. Do not call it professional or working fluency | see A7 | `[grounded]` your statement | pending your approval |
| P3 | Check Duinvaart's own careers page for the posting before investing time | see RA1 | `[grounded]` register | pending your approval |
| P4 | In the loop, ask RA2's and RA3's questions verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| P5 | For Kroonhaven, do not apply on this posting. Look for planning-adjacent roles that do not ask for 3+ years of FMCG planning | see B2, B4, B6 | `[generic]` role-family pattern | pending your approval |

If you decide to go for Duinvaart, tailoring your CV to it is resume-tailor's job.

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for "Duinvaart Cold Chain Rotterdam" and "Kroonhaven Foods Utrecht chilled ready meals" were both refused. It would have settled RA1 and RB1 |
| 2. Role-family sweep | unavailable | Searches for operations analyst and supply planner pay were both refused. They would have filled the market calibration rows and tested RA2 and RB2 |
| 3. Hiring manager's public footprint | n/a | No name was given in either posting, so no query could be formed |

## Upgrade menu

- A link to each company's own careers page, which I can read as your link without charging the research budget, would close RA1 and RB1.
- A sanitized screenshot of your on-time delivery dashboard would raise A4 to `high`.
- Any breach or exception reporting you have built would narrow A5b's limit.
- A minuted action list from your route reviews would settle A6.
- A hiring manager's name for either role would sharpen the plan's positioning.
- Your Excel level would settle B3, though it would not change Kroonhaven's status.

I can also write all of this up as a `tuesday-dossier.md` if you want one to keep.

**Questions**

Q1 (A1): Is three office days a week in Rotterdam something you can commit to, given where you live?

Q2 (A6): Did any of your weekly route-performance reviews lead a depot to change a route, cut-off or loading order, and what was your part in it?

Q3 (A5b): Have you ever built reporting on temperature, condition data or service-breach exceptions?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.