#!/bin/bash
# run_step.sh <model> <step> [--owner-go "<the owner's words>"] [--plan] [--recovery]
#
#   run_step.sh haiku quality        step 5: Haiku (start at <= 80%)
#   run_step.sh sonnet quality       step 6: Sonnet (start at <= 74.54%)
#   run_step.sh all explicit --owner-go "..."    step 7: the explicit panel, three models in parallel (<= 80%,
#                                    not on a weekday the frozen suite names); not started without the owner
#   run_step.sh opus quality --owner-go "..."    step 8: Opus (<= 72.5%); not started without the owner
#
# One measured step exactly as the manifest prices it (sections 8, 9, 14 and 18). A quality step runs, per
# model, both install arms together (module alone: --via skill --layout plugin; through Tuesday: --via
# tuesday), each arm its four candidate parts in order (existing job-underwriter rooms, new ones, existing
# mock-interview rooms, new ones) from the candidate worktree, then the seven E23 replays from the baseline
# worktree with the module alone; five runs per cell, --retry-runs 0, two Sonnet graders, --expect on every
# call. Stop rule: the meter, time and CLI are read and logged before and after; the step starts only at a
# reading <= its threshold with reading + high estimate <= 90%; a guard reads the meter every 20 minutes and
# stops the step's process group at 95%. Everything goes to the run log, $M/logs/run-log.txt.
#
#   --plan      offline: every command line of the step through the pinned runner's own main() with its
#               first session stubbed (lib/dry_runner.py), claude off PATH, outputs in a scratch folder;
#               checks the runner accepts each argument list and --expect file and plans the priced runs.
#   --recovery  print the killed-run and grade-gap commands for every part of the step (manifest section 14).
set -u
SELF=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")
source "$(dirname "$SELF")/kit.env"
MODEL=${1:-}; STEP=${2:-}; shift 2 2>/dev/null || true
PLAN=0; RECOVERY=0; OWNER_GO=""; DRIVER=0
while [ $# -gt 0 ]; do
  case $1 in
    --plan) PLAN=1;; --recovery) RECOVERY=1;; --owner-go) OWNER_GO=${2:-}; shift;;
    --driver) DRIVER=1;;
    *) echo "unknown option $1"; exit 2;;
  esac; shift
done
case "$MODEL/$STEP" in
  haiku/quality|sonnet/quality|opus/quality) RULE=$MODEL; MODELS=("$MODEL");;
  all/explicit) RULE=explicit; MODELS=(haiku sonnet opus);;
  *) sed -n '2,10p' "$SELF"; exit 2;;
esac
LABEL="$MODEL-$STEP"; ST="$STATUS_DIR/$LABEL.status"
now() { date -u +%Y-%m-%dT%H:%M:%SZ; }
log() { echo "$(now) $LABEL: $*" >> "$LOG"; echo "$*"; }
status() { echo "$(date -u +%H:%M:%S) $*" >> "$ST"; }
cli() { if [ -n "${CLI_VERSION:-}" ]; then echo "$CLI_VERSION"; else claude --version 2>/dev/null | head -1; fi; }
noclaude_path() { local out="" d; IFS=: read -ra parts <<< "$PATH"
  for d in "${parts[@]}"; do [ -n "$d" ] && [ ! -x "$d/claude" ] && out="${out:+$out:}$d"; done; echo "$out"; }
case "${DRY_LAUNCH:-}" in
  "") LAUNCH=("$PY");;
  1) LAUNCH=("$PY" -I -B "$KIT/lib/dry_runner.py");;
  sleep:*) LAUNCH=(bash -c "sleep ${DRY_LAUNCH#sleep:}" --);;
  crash) LAUNCH=("$PY" -I -c 'raise RuntimeError("simulated crash of the runner")');;
  *) echo "DRY_LAUNCH is 1, sleep:<seconds> or crash"; exit 2;;
esac
[ $PLAN = 1 ] && LAUNCH=("$PY" -I -B "$KIT/lib/dry_runner.py")

# ---- the step's command lines, one function per part, used by the driver, --plan and --recovery -------------
evals_flags() { local e; for e in ${PART_EVALS[$1]}; do printf -- '--eval\n%s\n' "$e"; done; }
part_argv() {  # part_argv <m> <arm> <part> -> ARGV, WT, OUT, WANT
  local m=$1 arm=$2 part=$3 skill=${PART_SKILL[$3]}
  mapfile -t ev < <(evals_flags "$part")
  OUT="$RUNS/$m/$arm/${PART_FOLDER[$part]}"; WT=$WT_CAND; WANT=${PART_RUNS[$part]}
  ARGV=(evals/run_fixtures.py --skill "$skill" "${ev[@]}" --model "${MODEL_ID[$m]}" ${ARM_FLAGS[$arm]} "${SHARED_FLAGS[@]}"
        --expect "$M/frozen/expect/$m/$arm/$part.json" --out "$OUT")
}
e23_argv() {   # e23_argv <m> <module-id>
  local m=$1 e=$2
  OUT="$RUNS/$m/${E23_FOLDER[$e]}"; WT=$WT_BASE; WANT=$E23_RUNS
  ARGV=(evals/run_fixtures.py --skill "${e%-*}" --cases "$M/frozen/e23/e23-$e.json" --model "${MODEL_ID[$m]}"
        --via skill --layout plugin "${SHARED_FLAGS[@]}" --expect "$M/frozen/expect/$m/e23/$e.json" --out "$OUT")
}
explicit_argv() {
  local m=$1
  OUT="$RUNS/$m/explicit.json"; WT=$WT_CAND; WANT=20
  ARGV=(evals/run_routing.py --arm tuesday --layout plugin --cases "$M/frozen/suite-explicit.json" --runs 5
        --model "${MODEL_ID[$m]}" --workers 3 --json-out "$OUT")
}
all_commands() {  # prints "<kind> <m> <arm|-> <part>" lines in run order
  local m arm part e
  for m in "${MODELS[@]}"; do
    if [ "$STEP" = explicit ]; then echo "explicit $m - explicit"; continue; fi
    for arm in "${ARMS[@]}"; do for part in "${PARTS[@]}"; do echo "part $m $arm $part"; done; done
    for e in "${E23[@]}"; do echo "e23 $m - $e"; done
  done
}
set_cmd() { case $1 in part) part_argv "$2" "$3" "$4";; e23) e23_argv "$2" "$4";; explicit) explicit_argv "$2";; esac; }

# ---- --recovery ---------------------------------------------------------------------------------------------
if [ $RECOVERY = 1 ]; then
  echo "# Recovery commands for $LABEL (manifest section 14). Run each from the worktree named, wrapped in"
  echo "# $KIT/tools/logged.sh, under the stop rule and the guard, as the step ran: never over files that exist."
  while read -r kind m arm part; do
    set_cmd "$kind" "$m" "$arm" "$part"
    if [ "$kind" = explicit ]; then
      echo; echo "## $m explicit: re-run killed runs into a new results file, then merge (the runner's tested merge)"
      echo "cd $WT && python3 evals/run_routing.py --arm tuesday --layout plugin --cases $M/frozen/suite-explicit.json --model ${MODEL_ID[$m]} --workers 3 --case <id> --runs <n> --json-out ${OUT%.json}.rerun-1.json"
      echo "cd $WT && python3 evals/run_routing.py --merge $OUT --rerun ${OUT%.json}.rerun-1.json --json-out ${OUT%.json}.merged.json"
      continue
    fi
    sel=("${ARGV[@]:1}"); n=${#sel[@]}
    keep=(); i=0
    while [ $i -lt $n ]; do case ${sel[$i]} in
      --skill|--eval|--cases) keep+=("${sel[$i]}" "${sel[$((i+1))]}"); i=$((i+2));; *) i=$((i+1));; esac; done
    echo; echo "## $m $arm $part ($WT)"
    echo "cd $WT && python3 evals/run_fixtures.py ${keep[*]} --runs 5 --out $OUT --killed --move"
    echo "cd $WT && python3 evals/run_fixtures.py ${ARGV[*]:1} --stems $OUT/killed/rerun-<UTC time>.txt"
    echo "cd $WT && python3 evals/run_fixtures.py --out $OUT --graders 2 --grade-gaps --move   # add --accept-partial on the owner's word"
    echo "cd $WT && python3 evals/run_fixtures.py ${ARGV[*]:1} --stems <the grade-gap stems file> --skip-execute"
  done < <(all_commands)
  exit 0
fi

# ---- --plan: every command line through the stubbed runner, claude off PATH --------------------------------
if [ $PLAN = 1 ]; then
  P="${PLAN_DIR:-$M/logs/plan/$LABEL-$(date -u +%Y%m%dT%H%M%SZ)}"; mkdir -p "$P"
  NP=$(noclaude_path); bad=0; count=0; CLI_PLAN=$(cli)
  echo "plan of $LABEL: every command through the pinned runner's main(), first session stubbed; claude off PATH"
  echo "  outputs under $P (the step's own folders are not touched)"
  while read -r kind m arm part; do
    RUNS_REAL=$RUNS; RUNS="$P/runs"; set_cmd "$kind" "$m" "$arm" "$part"; RUNS=$RUNS_REAL
    [ -d "$WT" ] || { echo "  FAIL $m $arm $part: no worktree at $WT"; bad=$((bad+1)); continue; }
    res=$(cd "$WT" && PATH="$NP" DRY_EXPECT_RUNS=$WANT DRY_CLI_VERSION="$CLI_PLAN" "${LAUNCH[@]}" "${ARGV[@]}" 2>&1); code=$?
    count=$((count+1))
    summary=$(echo "$res" | sed -n 's/^DRY-RUN-SUMMARY //p' | tail -1)
    if [ $code -eq 0 ]; then echo "  ok   $m $arm $part: accepted, $summary"
    else bad=$((bad+1)); echo "  FAIL $m $arm $part: exit $code, ${summary:-$(echo "$res" | tail -3 | tr '\n' ' ')}"; fi
    echo "       ${ARGV[*]}" | sed "s|$P/runs|\$RUNS|g"
  done < <(all_commands)
  find "$WT_BASE" "$WT_CAND" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null
  echo "plan of $LABEL: $((count-bad)) of $count command lines accepted with the priced plan"
  [ $bad -eq 0 ]; exit $?
fi

# ---- the driver: runs in its own process group, which the guard stops ------------------------------------
if [ $DRIVER = 1 ]; then
  REFUSED="$ST.refused"
  run_one() {  # run_one <label> -> runs ARGV in WT, output beside OUT
    if [ -e "$REFUSED" ]; then status "$1 not started: an earlier command was refused"; return; fi
    mkdir -p "$(dirname "$OUT")"
    (cd "$WT" && "$KIT/tools/logged.sh" "$1" "${LAUNCH[@]}" "${ARGV[@]}" > "${OUT%.json}.log" 2>&1); local code=$?
    if grep -q '^Refused before any call\|^refused:' "${OUT%.json}.log" 2>/dev/null; then
      status "$1 REFUSED by the runner (exit $code): see ${OUT%.json}.log"; : > "$REFUSED"
    elif grep -q '^Traceback (most recent call last)' "${OUT%.json}.log" 2>/dev/null; then
      # A crash exits 1 like a pass that found failures: told apart here, so it is never read as a normal end.
      status "$1 CRASHED (exit $code): see ${OUT%.json}.log"
    else
      status "$1 exit $code"
    fi
  }
  arm() { local m=$1 a=$2 part; for part in "${PARTS[@]}"; do part_argv "$m" "$a" "$part"; run_one "$m-$a-$part"; done; }
  status "start $LABEL (${MODELS[*]})"
  if [ "$STEP" = explicit ]; then
    for m in "${MODELS[@]}"; do (explicit_argv "$m"; run_one "explicit-$m") & done; wait
  else
    m=${MODELS[0]}
    arm "$m" alone & arm "$m" tuesday & wait
    for e in "${E23[@]}"; do e23_argv "$m" "$e"; run_one "$m-e23-$e"; done
  fi
  status "done"
  exit 0
fi

# ---- the step -------------------------------------------------------------------------------------------------
mkdir -p "$STATUS_DIR" "$M/logs"
refuse() { log "NOT STARTED: $*"; exit 1; }
[ -d "$M/frozen" ] || refuse "no freeze at $M/frozen: run freeze.sh first"
want_listing=$(cat "$M/logs/frozen.listing.sha256" 2>/dev/null)
got_listing=$(cd "$M/frozen" && find . -type f | sed 's|^\./||' | LC_ALL=C sort | while read -r f; do
  echo "$f $(sha256sum "$f" | cut -c1-64)"; done | sha256sum | cut -c1-64)
[ -n "$want_listing" ] && [ "$got_listing" = "$want_listing" ] || refuse "$M/frozen changed since the freeze (listing $got_listing, frozen $want_listing)"
read -r FBASE FCAND FMODE < <(python3 -I -B -c 'import json,sys; f=json.load(open(sys.argv[1]))["facts"]
print(f["baseline_sha"].split()[0], f["candidate_sha"].split()[0], f["mode"])' "$M/frozen/freeze.json")
if [ "$FMODE" = git ]; then
  for pair in "$WT_BASE $FBASE" "$WT_CAND $FCAND"; do set -- $pair
    [ "$(git -C "$1" rev-parse HEAD 2>/dev/null)" = "$2" ] || refuse "$1 is not at the frozen pin $2"
    [ -z "$(git -C "$1" status --porcelain 2>/dev/null)" ] || refuse "$1 is not clean"
  done
fi
CLI_NOW=$(cli)
OK=$(preflight_ok_file "$CLI_NOW")
[ -n "${DRY_LAUNCH:-}" ] && [ ! -f "$OK" ] && [ -f "${OK%.json}.offline.json" ] && OK="${OK%.json}.offline.json" \
  && log "dry launch: the offline preflight record is accepted (a measured step never accepts it)"
[ -f "$OK" ] || refuse "no passing preflight for CLI '${CLI_NOW:-none}' ($OK): run preflight.sh (a new CLI needs the save probe and layout checks again)"
if [ "$RULE" = explicit ] || [ "$RULE" = opus ]; then
  [ -n "$OWNER_GO" ] || refuse "the $RULE step is ready but is not started without the owner: pass --owner-go \"<the owner's words>\""
  log "owner's go: $OWNER_GO"
fi
if [ "$RULE" = explicit ]; then
  for d in $EXPLICIT_BLOCKED_DAYS; do
    [ "$(date -u +%A)" = "$d" ] || [ "$(date +%A)" = "$d" ] && refuse "today is $d, which the frozen explicit suite names"
  done
fi
while read -r kind m arm part; do set_cmd "$kind" "$m" "$arm" "$part"
  if [ -e "$OUT" ] && [ -n "$(ls -A "$OUT" 2>/dev/null)" ]; then refuse "$OUT exists: a step never writes over runs (recovery is --recovery)"; fi
done < <(all_commands)
TUESDAY_SCAN_ACCOUNT_EMAIL=$(python3 -I -B "$KIT/lib/account_email.py")
[ -n "$TUESDAY_SCAN_ACCOUNT_EMAIL" ] || refuse "the CLI's signed-in account email is missing from ~/.claude.json: the account-email scan needs it"
export TUESDAY_SCAN_ACCOUNT_EMAIL

line=$($METER "before-$LABEL" 2>&1 | tail -1)
u=$(echo "$line" | sed -n 's/.*seven-day \([0-9.]*\).*/\1/p')
log "before: $(now), CLI ${CLI_NOW:-none}, meter: $line"
[ -n "$u" ] || refuse "no meter reading, so the stop rule cannot be applied"
rule=$(python3 -I -B "$KIT/lib/stop_rule.py" start "$RULE" "$u"); rc=$?
log "$rule"
[ $rc -eq 0 ] || refuse "the stop rule bars the step at this reading"

: > "$ST"; rm -f "$ST.refused"
start=$(date -u +%s)
setsid bash "$SELF" "$MODEL" "$STEP" --driver > "$ST.driver.log" 2>&1 < /dev/null &
DRV=$!
sleep 1
PG=$(ps -o pgid= -p "$DRV" 2>/dev/null | tr -d ' ')
[ -n "$PG" ] || PG=$DRV
log "started: driver $DRV, process group $PG; guard every ${GUARD_INTERVAL}s, stop at $GUARD_STOP; status in $ST"
"$KIT/tools/guard.sh" "$LABEL" "$PG" "$ST" > /dev/null 2>&1 &
GUARD=$!
wait "$DRV"; dcode=$?
# The driver's last line is "done". Without it, the guard may be stopping the step: let it finish (TERM, the
# grace period, KILL, "stopped"); otherwise the guard is only sleeping, and is stopped here.
if ! grep -q ' done$' "$ST" && grep -q 'stopping the step' "$ST"; then
  wait "$GUARD" 2>/dev/null
else
  pkill -P "$GUARD" 2>/dev/null; kill "$GUARD" 2>/dev/null; wait "$GUARD" 2>/dev/null
fi
secs=$(( $(date -u +%s) - start ))
line=$($METER "after-$LABEL" 2>&1 | tail -1)
log "after: $(now), $((secs/3600))h$(( (secs%3600)/60 ))m, CLI $(cli), meter: $line"
grep -E ' exit [0-9]+$| REFUSED | CRASHED | not started' "$ST" | sed "s/^/  /" | tee -a "$LOG"
if grep -q ' stopped$' "$ST"; then
  log "STOPPED BY THE GUARD: unfinished runs are killed runs; recover after the reset ($SELF $MODEL $STEP --recovery)"
  exit 4
fi
if [ -e "$ST.refused" ]; then log "A COMMAND WAS REFUSED BY THE RUNNER: stop for the owner (see $ST)"; exit 3; fi
bad=$(( $(grep -E ' exit [0-9]+$' "$ST" | grep -vE ' exit (0|1|3)$' | wc -l) + $(grep -c ' CRASHED ' "$ST") ))
[ "$dcode" -eq 0 ] && [ "$bad" -eq 0 ] || { log "the driver ended with exit $dcode and $bad command(s) outside exit 0, 1 or 3: see $ST"; exit 5; }
if [ "$STEP" = explicit ] && [ -z "${DRY_LAUNCH:-}" ]; then
  python3 -I -B - "$M/frozen/expect/explicit.json" "${MODELS[@]/#/$RUNS/}" > "$ST.explicit-check" <<'PY'
import json, sys
want = json.load(open(sys.argv[1])); bad = 0
for d in sys.argv[2:]:
    try:
        got = json.load(open(d + "/explicit.json"))
    except (OSError, ValueError) as exc:
        print(f"  explicit {d}: no results file ({exc})"); bad += 1; continue
    diff = [k for k in ("arm", "layout", "runs_per_case", "hub_sha256", "tuesday_sha256", "cases_sha256") if got.get(k) != want[k]]
    print(f"  explicit {d}: {'matches the frozen digests and case hash' if not diff else 'DIFFERS in ' + ', '.join(diff)}")
    bad += bool(diff)
sys.exit(1 if bad else 0)
PY
  ec=$?; tee -a "$LOG" < "$ST.explicit-check"
  [ $ec -eq 0 ] || { log "an explicit results file does not match the freeze: stop for the owner"; exit 6; }
fi
# Seal: a read-only copy of the step's outputs, its listing hash in the run log.
SEAL="$M/sealed/$LABEL-$(date -u +%Y%m%dT%H%M%SZ)"; mkdir -p "$SEAL"
for m in "${MODELS[@]}"; do
  if [ "$STEP" = explicit ]; then
    mkdir -p "$SEAL/$m"; cp -a "$RUNS/$m"/explicit* "$RUNS/$m/streams" "$SEAL/$m/" 2>/dev/null
  else
    mkdir -p "$SEAL/$m"
    while read -r kind mm arm part; do [ "$mm" = "$m" ] || continue; set_cmd "$kind" "$mm" "$arm" "$part"
      mkdir -p "$SEAL/${OUT#$RUNS/}"; cp -a "$OUT/." "$SEAL/${OUT#$RUNS/}/"; cp -a "$OUT.log" "$SEAL/${OUT#$RUNS/}.log" 2>/dev/null
    done < <(all_commands)
  fi
done
cp -a "$ST" "$SEAL/"; chmod -R a-w "$SEAL"
sl=$(cd "$SEAL" && find . -type f | sed 's|^\./||' | LC_ALL=C sort | while read -r f; do
  echo "$f $(sha256sum "$f" | cut -c1-64)"; done | sha256sum | cut -c1-64)
log "sealed: $SEAL ($(find "$SEAL" -type f | wc -l) files, listing sha256 $sl)"
log "step done"
