#!/bin/bash
# preflight.sh [--offline]
#   Round 1a's preflight (manifest sections 6, 7, 18 and 21, "Preflight"), after freeze.sh and before Haiku.
#   Offline first: the freeze unchanged, the worktrees at their pins and clean, the CLI version, host, UID and
#   scratchpad root, user settings free of any Tuesday plugin or synced skill, the sentinel declarations of
#   every frozen case file, the account-email scan set up from the CLI's signed-in account (never printed), and every step's
#   command lines through the pinned runners with claude off PATH. Then the meter (R0) under the stop rule
#   (start at <= 80%), the save probe in both plugin installs and the layout checks, and the meter again.
#   Writes a passing record for this CLI version, which run_step.sh requires.
#   --offline: the dry run. No session is started: the meter, save probe and layout sessions are replaced
#   by the save probe's self-test and synthetic layout files, and the record is marked offline, which a
#   measured step never accepts.
set -u
source "$(dirname "${BASH_SOURCE[0]}")/kit.env"
OFFLINE=0; [ "${1:-}" = --offline ] && OFFLINE=1
P="$M/logs/preflight"; mkdir -p "$P"
STAMP=$(date -u +%Y%m%dT%H%M%SZ); OUT="$P/preflight-$STAMP.txt"
fails=0
log() { echo "$*" | tee -a "$OUT"; }
step() { log ""; log "== $*"; }
mark() { if [ "$1" -eq 0 ]; then log "  PASS $2"; else log "  FAIL $2"; fails=$((fails+1)); fi; }
runlog() { echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) preflight: $*" >> "$LOG"; }
cli() { if [ -n "${CLI_VERSION:-}" ]; then echo "$CLI_VERSION"; else claude --version 2>/dev/null | head -1; fi; }
log "preflight $(date -u +%Y-%m-%dT%H:%M:%SZ)$([ $OFFLINE = 1 ] && echo ' (offline dry run: no session)')"
runlog "start$([ $OFFLINE = 1 ] && echo ' (offline)')"

step "1. Freeze and pins"
want=$(cat "$M/logs/frozen.listing.sha256" 2>/dev/null)
got=$(cd "$M/frozen" 2>/dev/null && find . -type f | sed 's|^\./||' | LC_ALL=C sort | while read -r f; do
  echo "$f $(sha256sum "$f" | cut -c1-64)"; done | sha256sum | cut -c1-64)
[ -n "$want" ] && [ "$got" = "$want" ]; mark $? "the frozen folder's listing is the freeze's ($got)"
read -r FBASE FCAND FMODE < <(python3 -I -B -c 'import json,sys; f=json.load(open(sys.argv[1]))["facts"]
print(f["baseline_sha"].split()[0], f["candidate_sha"].split()[0], f["mode"])' "$M/frozen/freeze.json" 2>/dev/null)
if [ "${FMODE:-}" = git ]; then
  for pair in "$WT_BASE $FBASE" "$WT_CAND $FCAND"; do set -- $pair
    [ "$(git -C "$1" rev-parse HEAD 2>/dev/null)" = "$2" ] && [ -z "$(git -C "$1" status --porcelain 2>/dev/null)" ]
    mark $? "$1 at $2 and clean"
  done
else
  log "  note: the freeze was made from stand-in folders (${FMODE:-none}): no git pins to check"
fi
python3 -I -B - "$M/frozen" <<'PYK' | tee -a "$OUT"; mark "${PIPESTATUS[0]}" "the frozen kit files are the ones the freeze hashed"
import hashlib, json, sys
from pathlib import Path
f = Path(sys.argv[1]); rec = json.load(open(f / "freeze.json"))
bad = [rel for rel, h in rec["kit_sha256"].items() if hashlib.sha256((f / "kit" / rel).read_bytes()).hexdigest() != h]
print(f"  {len(rec['kit_sha256'])} kit files; differing: {bad or 'none'}"); sys.exit(1 if bad else 0)
PYK

step "2. CLI, host, UID and scratchpad"
CLI_NOW=$(cli)
[ -n "$CLI_NOW" ]; mark $? "CLI version: ${CLI_NOW:-none found}"
FROZEN_CLI=$(python3 -I -B -c 'import json,sys; print(json.load(open(sys.argv[1]))["facts"].get("cli_version") or "")' "$M/frozen/freeze.json")
[ "$CLI_NOW" = "$FROZEN_CLI" ] && log "  note: the same CLI as at the freeze, which the expect files list under preflight" \
  || log "  note: the CLI was '$FROZEN_CLI' at the freeze; the runner will note the change (recorded, never refused)"
log "  host $(hostname); uid $(id -u); kernel $(uname -r)"
[ "$(id -u)" = 0 ]; mark $? "target UID 0: run_fixtures.sidecar_dirs reads session scratchpads under /tmp/claude-0"
[ -d /tmp/claude-0 ] && log "  scratchpad root /tmp/claude-0 exists" || log "  note: /tmp/claude-0 does not exist yet (the CLI makes it at the first session)"
CFG=${CLAUDE_CONFIG_DIR:-$HOME/.claude}
found=$(python3 -I -B - "$CFG" <<'PYS'
import json, sys
from pathlib import Path
cfg = Path(sys.argv[1]); names = ("tuesday", "job-underwriter", "mock-interview", "resume-tailor"); hits = []
for f in ("settings.json", "settings.local.json"):
    try:
        d = json.loads((cfg / f).read_text())
    except (OSError, ValueError):
        continue
    hits += [f"{f}: enabledPlugins {k}" for k in (d.get("enabledPlugins") or {}) if "tuesday" in k.lower()]
notes = []
for sub in ("skills", "plugins"):
    root = cfg / sub
    if root.is_dir():
        for p in root.rglob("*"):
            if p.is_dir() and p.name.lower() in names:
                rel = p.relative_to(root)
                # The account's synced catalog (skills/synced/<bucket>/) holds its own mock-interview, which
                # child_env keeps out of every measured session by dropping CLAUDE_CODE_SYNC_SKILLS; the
                # init-list checks below prove it per install. Any other copy is a hard stop.
                (notes if sub == "skills" and rel.parts[0] == "synced" else hits).append(f"{sub}/{rel}")
print("; ".join(hits) + "\t" + "; ".join(notes))
PYS
)
synced=${found#*$'\t'}; found=${found%%$'\t'*}
[ -z "$found" ]; mark $? "user settings in $CFG hold no Tuesday plugin or personal Tuesday skill${found:+: $found}"
[ -z "$synced" ] || log "  note: the account's synced catalog holds a skill of a module's name ($synced); child_env drops CLAUDE_CODE_SYNC_SKILLS for every measured session, and the init-list checks (step 7) show what each session loads"
[ -z "${CLAUDE_CODE_SYNC_SKILLS:-}" ] || log "  note: CLAUDE_CODE_SYNC_SKILLS is set here; child_env drops it for every measured session"

step "3. Sentinel declarations"
(cd "$WT_CAND" && python3 -I -B "$KIT/lib/preflight_checks.py" sentinels "$M/frozen") | tee -a "$OUT"
mark "${PIPESTATUS[0]}" "every frozen sentinel list keeps the freezing rules and matches the manifest"
(cd "$WT_CAND" && python3 -I -B ci/check_skills.py --only fixtures) > "$P/check-fixtures-$STAMP.txt" 2>&1
mark $? "ci/check_skills.py --only fixtures on the candidate (no planted spelling in shipped text): $(tail -1 "$P/check-fixtures-$STAMP.txt")"

step "4. Account-email scan setup"
TUESDAY_SCAN_ACCOUNT_EMAIL=$(python3 -I -B "$KIT/lib/account_email.py")
export TUESDAY_SCAN_ACCOUNT_EMAIL
(cd "$WT_CAND" && python3 -I -B "$KIT/lib/preflight_checks.py" email "$M/frozen" "$WT_BASE" "$WT_CAND") | tee -a "$OUT"
mark "${PIPESTATUS[0]}" "TUESDAY_SCAN_ACCOUNT_EMAIL read from the CLI's signed-in account at run time (value never printed)"
unset TUESDAY_SCAN_ACCOUNT_EMAIL

step "5. Every step's command lines, claude off PATH"
for s in "haiku quality" "sonnet quality" "all explicit" "opus quality"; do
  set -- $s
  PLAN_DIR="$P/plan-$STAMP/$1-$2" bash "$KIT/run_step.sh" "$1" "$2" --plan > "$P/plan-$STAMP-$1-$2.txt" 2>&1
  mark $? "$(tail -1 "$P/plan-$STAMP-$1-$2.txt")"
done
LP=(evals/run_routing.py --arm tuesday --layout plugin --cases "$M/frozen/probe/suite-routing.json" --case 1 --runs 1
    --model claude-haiku-5-5)
NP=$(python3 -I -B -c 'import os,sys; print(":".join(d for d in os.environ["PATH"].split(":") if d and not os.access(os.path.join(d, "claude"), os.X_OK)))')
(cd "$WT_CAND" && PATH="$NP" DRY_EXPECT_RUNS=1 DRY_CLI_VERSION="$CLI_NOW" "$PY" -I -B "$KIT/lib/dry_runner.py" "${LP[@]}" --json-out "$P/plan-$STAMP/layout-plugin.json") > "$P/plan-$STAMP-layout.txt" 2>&1
mark $? "the layout probe's command line: $(sed -n 's/^DRY-RUN-SUMMARY //p' "$P/plan-$STAMP-layout.txt")"
find "$WT_BASE" "$WT_CAND" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null

R0=""; RESETS=""
if [ $OFFLINE = 0 ]; then
  if [ $fails -ne 0 ]; then
    log ""; log "PREFLIGHT STOPPED before any session: $fails offline check(s) failed. Stop for the owner."
    runlog "stopped before any session: $fails offline check(s) failed"; exit 1
  fi
  step "6. Meter (R0) and the stop rule"
  line=$($METER preflight-R0 2>&1 | tail -1); log "  $line"
  R0=$(echo "$line" | sed -n 's/.*seven-day \([0-9.]*\).*/\1/p'); RESETS=$(echo "$line" | sed -n 's/.*resets \([^ ;]*\).*/\1/p')
  [ -n "$R0" ] || { mark 1 "a meter reading"; exit 1; }
  python3 -I -B "$KIT/lib/stop_rule.py" start preflight "$R0" | tee -a "$OUT"
  if [ "${PIPESTATUS[0]}" -ne 0 ]; then log "PREFLIGHT NOT STARTED: the stop rule bars it"; runlog "not started: stop rule at $R0"; exit 1; fi
  python3 -I -B "$KIT/lib/stop_rule.py" chain "$R0" | sed 's/^/  /' | tee -a "$OUT"
  log "  next reset of the seven-day window: ${RESETS:-not reported} (the plan's schedule: Thursday 06:00 UTC)"

  step "7. Save probe (both plugin installs) and layout checks, on Haiku"
  SP="$P/save-probe-$(echo "$CLI_NOW" | tr -c 'A-Za-z0-9.\n' '_')-$STAMP"; LJ="$P/layout-plugin-$STAMP.json"
  "$KIT/tools/logged.sh" save-probe python3 -I -B "$KIT/tools/save_probe.py" "$SP" > "$P/save-probe-$STAMP.log" 2>&1 &
  SPID=$!
  (cd "$WT_CAND" && "$KIT/tools/logged.sh" layout-plugin python3 "${LP[@]}" --json-out "$LJ") > "$P/layout-plugin-$STAMP.log" 2>&1 &
  LPID=$!
  wait $SPID; sp=$?; wait $LPID; lp=$?
  sed 's/^/  /' "$P/save-probe-$STAMP.log" | tee -a "$OUT"; mark $sp "save probe"
  tail -4 "$P/layout-plugin-$STAMP.log" | sed 's/^/  /' | tee -a "$OUT"
  [ -f "$LJ" ] && [ -f "$SP/result.json" ] && python3 -I -B "$KIT/tools/layout_check.py" "$LJ" "$SP/result.json" | tee -a "$OUT"
  mark "${PIPESTATUS[0]}" "init-list checks: the plugin layout through Tuesday, and both plugin installs of the fixture runner"
  [ -d /tmp/claude-0 ]; mark $? "the scratchpad root /tmp/claude-0 exists after the probe sessions"
  line=$($METER after-preflight 2>&1 | tail -1); log "  after: $line"
else
  step "6-7 (offline). Stop rule, save probe and layout check logic, no session"
  python3 -I -B "$KIT/lib/stop_rule.py" self-test > "$P/stop-rule-self-test-$STAMP.txt" 2>&1
  mark $? "stop rule self-test: $(tail -1 "$P/stop-rule-self-test-$STAMP.txt")"
  python3 -I -B "$KIT/tools/save_probe.py" --self-test > "$P/save-probe-self-test-$STAMP.txt" 2>&1
  mark $? "save probe self-test (stubbed sessions): $(tail -1 "$P/save-probe-self-test-$STAMP.txt")"
  (cd "$WT_CAND" && python3 -I -B "$KIT/lib/preflight_checks.py" synth-layout "$P/synthetic-$STAMP") > /dev/null
  python3 -I -B "$KIT/tools/layout_check.py" "$P/synthetic-$STAMP/layout-plugin.synthetic.json" \
    "$P/synthetic-$STAMP/save-probe.synthetic.json" | tee -a "$OUT"
  mark "${PIPESTATUS[0]}" "layout checks on synthetic files built from a real plugin install of the candidate"
fi
find "$WT_BASE" "$WT_CAND" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null

log ""
if [ $fails -eq 0 ]; then
  OKF=$(preflight_ok_file "$CLI_NOW"); [ $OFFLINE = 1 ] && OKF="${OKF%.json}.offline.json"
  python3 -I -B - "$OKF" "$CLI_NOW" "$R0" "$RESETS" "$OFFLINE" "$OUT" <<'PYW'
import json, os, socket, sys, datetime
f, cli, r0, resets, offline, out = sys.argv[1:7]
json.dump({"cli_version": cli, "host": socket.gethostname(), "uid": os.getuid(), "scratchpad_root": "/tmp/claude-0",
           "R0": r0 or None, "resets": resets or None, "offline": offline == "1", "report": out,
           "time": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}, open(f, "w"), indent=1)
PYW
  log "PREFLIGHT PASSED$([ $OFFLINE = 1 ] && echo ' (offline: no measured step accepts this record)'). Record: $OKF"
  runlog "passed; CLI ${CLI_NOW:-none}; R0 ${R0:-none}; resets ${RESETS:-none}; record $OKF"
  exit 0
fi
log "PREFLIGHT FAILED: $fails check(s). Stop for the owner; nothing measured starts. Report: $OUT"
runlog "failed: $fails check(s); report $OUT"
exit 1
