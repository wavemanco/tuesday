#!/bin/bash
# freeze.sh <candidate SHA> <expected.json>
#   Round 1a's freeze (manifest sections 3, 17 and 21): checks the pins, creates the two pinned worktrees
#   outside the checkout (baseline = 7b56c17, candidate = the SHA given, one commit on a parent whose tree equals
#   the baseline's: the pushable branch's merge-back commit 5696742), computes every digest, dependency
#   hash and case hash from each pinned tree with its own harness and holds them to <expected.json>
#   (make_expected.py writes it from the offline build), regenerates the seven E23 replay files, writes one
#   --expect file per runner invocation, and copies every frozen input into $M/frozen (read-only), the
#   baseline subsets into $M/baseline and the re-checked checks into $M/checkrun. Any mismatch stops it
#   before anything is copied. No model is called; the only CLI call is `claude --version`.
# freeze.sh --dirs <baseline folder> <candidate folder> <expected.json>
#   The stand-in dry run: the two folders stand in for the worktrees, the path list is read by comparing
#   them, and no git command runs.
set -u
SRC=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$SRC/kit.env"
mode=git
if [ "${1:-}" = --dirs ]; then
  [ $# -eq 4 ] || { echo "usage: freeze.sh --dirs <baseline folder> <candidate folder> <expected.json>"; exit 2; }
  mode=dirs; WT_BASE=$(cd "$2" && pwd); WT_CAND=$(cd "$3" && pwd); EXP=$4
else
  [ $# -eq 2 ] || { echo "usage: freeze.sh <candidate SHA> <expected.json>"; exit 2; }
  CAND_ARG=$1; EXP=$2
fi
EXP=$(cd "$(dirname "$EXP")" && pwd)/$(basename "$EXP")
mkdir -p "$M/logs" "$STATUS_DIR"
say() { echo "$*"; echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) freeze: $*" >> "$LOG"; }
fail() { say "STOPPED: $*"; echo "FREEZE STOPPED. Nothing was copied into $M/frozen. Stop for the owner."; exit 1; }
[ -f "$EXP" ] || fail "no expected-values file at $EXP"
[ -e "$M/frozen" ] && fail "$M/frozen exists: a freeze is never redone over another (move it aside with the owner's word)"
for d in baseline checkrun; do [ -e "$M/$d" ] && fail "$M/$d exists: the baseline copies are written once"; done
say "start ($mode mode), host $(hostname), uid $(id -u), expected values $EXP (sha256 $(sha256sum "$EXP" | cut -c1-64))"

FACTS=$(mktemp "$M/logs/.facts.XXXXXX")
trap 'rm -f "$FACTS" "$FACTS".*' EXIT
CLI_VERSION=${CLI_VERSION:-$(claude --version 2>/dev/null | head -1)}
if [ $mode = git ]; then
  G() { git -C "$REPO" "$@"; }
  BASE=$(G rev-parse --verify --quiet "$BASE_SHA^{commit}") || fail "the baseline pin $BASE_SHA is not in $REPO"
  CAND=$(G rev-parse --verify --quiet "$CAND_ARG^{commit}") || fail "the candidate $CAND_ARG is not a commit in $REPO"
  # The candidate is one commit on a parent whose TREE equals the baseline's: the only pushable branch's HEAD is a
  # merge-back commit (5696742) whose tree equals 7b56c17's, and the branch is never force-pushed, so the candidate
  # cannot sit directly on 7b56c17. The path list below is still taken from the baseline itself.
  [ "$(G rev-list --parents -n 1 "$CAND" | wc -w)" -eq 2 ] \
    || fail "the candidate $CAND is not one commit on one parent (it has no parent, or it is a merge)"
  PARENT=$(G rev-parse --verify --quiet "$CAND^") || fail "the candidate $CAND has no parent"
  PARENT_TREE=$(G rev-parse "$CAND^^{tree}"); BASE_TREE=$(G rev-parse "$BASE^{tree}")
  [ "$PARENT_TREE" = "$BASE_TREE" ] \
    || fail "the candidate $CAND's parent $PARENT has tree $PARENT_TREE, not the baseline $BASE's tree $BASE_TREE"
  say "candidate $CAND: one commit on $PARENT, whose tree $PARENT_TREE equals the baseline $BASE's"
  G merge-base --is-ancestor "$BASE" "$(G rev-parse --verify --quiet origin/main || echo "$BASE")" \
    || fail "the baseline $BASE is not on origin/main"
  for sha in "$BASE" "$CAND"; do
    if [ -z "$(G branch -r --contains "$sha" 2>/dev/null)" ]; then
      [ "${FREEZE_ALLOW_UNPUSHED:-}" = 1 ] && say "note: $sha is on no remote branch (allowed for a dry run only)" \
        || fail "$sha is on no remote branch: both pins are pushed before the freeze (manifest section 21)"
    fi
  done
  G diff --name-status "$BASE" "$CAND" > "$FACTS.ns" || fail "git diff failed"
  if G cat-file -e "$HARNESS_PARENT_SHA^{commit}" 2>/dev/null; then
    G diff --name-status "$HARNESS_PARENT_SHA" "$BASE" > "$FACTS.hns"
  else
    say "note: $HARNESS_PARENT_SHA is not in $REPO, so the baseline's harness list is not compared"; : > "$FACTS.hns.none"
  fi
  G diff "$BASE" "$CAND" -- 'evals/*.py' ci/sync.py ci/package.py conventions/ skills/resume-tailor/ > "$FACTS.untouched"
  mkdir -p "$PINS"
  for pair in "$WT_BASE $BASE" "$WT_CAND $CAND"; do
    set -- $pair
    if [ -e "$1" ]; then
      [ "$(git -C "$1" rev-parse HEAD 2>/dev/null)" = "$2" ] || fail "$1 exists and is not a worktree at $2"
      [ -z "$(git -C "$1" status --porcelain)" ] || fail "$1 is not clean"
      say "worktree $1 already at $2, clean"
    else
      G worktree add --detach "$1" "$2" > /dev/null 2>&1 || fail "git worktree add $1 $2 failed"
      say "worktree $1 created, detached at $2"
    fi
  done
else
  BASE="(stand-in) $WT_BASE"; CAND="(stand-in) $WT_CAND"; PARENT=""; PARENT_TREE=""; BASE_TREE=""
  python3 -I -B - "$WT_BASE" "$WT_CAND" "$FACTS" <<'PY'
import sys, filecmp
from pathlib import Path
b, c, out = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
def files(r): return {p.relative_to(r).as_posix(): p for p in r.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
fb, fc = files(b), files(c)
ns = [f"A\t{p}" for p in sorted(set(fc) - set(fb))] + [f"D\t{p}" for p in sorted(set(fb) - set(fc))]
ns += [f"M\t{p}" for p in sorted(set(fb) & set(fc)) if fb[p].read_bytes() != fc[p].read_bytes()]
open(out + ".ns", "w").write("".join(x + "\n" for x in sorted(ns, key=lambda s: s.split("\t")[1])))
keep = ("ci/sync.py", "ci/package.py", "conventions/", "skills/resume-tailor/")
touched = [x for x in ns if (x.split("\t")[1].startswith("evals/") and x.endswith(".py") and "/" not in x.split("\t")[1][6:])
           or x.split("\t")[1].startswith(keep)]
open(out + ".untouched", "w").write("".join(x + "\n" for x in touched))
PY
  : > "$FACTS.hns.none"
fi

python3 -I -B - "$FACTS" "$BASE" "$CAND" "$mode" "$CLI_VERSION" "$PARENT" "$PARENT_TREE" "$BASE_TREE" <<'PY'
import json, os, socket, sys
from pathlib import Path
f, base, cand, mode, cli, parent, parent_tree, base_tree = sys.argv[1:9]
lines = lambda p: [l for l in Path(p).read_text().splitlines() if l.strip()]
facts = {"mode": mode, "baseline_sha": base, "candidate_sha": cand,
         "candidate_parent_sha": parent or None, "candidate_parent_tree": parent_tree or None,
         "baseline_tree": base_tree or None, "name_status": lines(f + ".ns"),
         "harness_name_status": None if os.path.exists(f + ".hns.none") else lines(f + ".hns"),
         "untouched_diff": Path(f + ".untouched").read_text(), "cli_version": cli or None,
         "host": socket.gethostname(), "uid": os.getuid()}
Path(f).write_text(json.dumps(facts, indent=1))
PY

say "baseline $BASE; candidate $CAND; CLI ${CLI_VERSION:-unknown}"
STAGE="$M/frozen.staging"
rm -rf "$STAGE" "$M/baseline-staging" "$M/checkrun-staging"
python3 -I -B "$SRC/lib/freeze.py" "$EXP" "$WT_BASE" "$WT_CAND" "$STAGE" "$FACTS" | tee -a "$M/logs/freeze-output.txt"
code=${PIPESTATUS[0]}
if [ "$code" -ne 0 ]; then
  rm -rf "$STAGE" "$M/baseline-staging" "$M/checkrun-staging"
  fail "freeze.py found mismatches (exit $code); the checks are in $M/logs/freeze-output.txt"
fi
mv "$STAGE" "$M/frozen" && mv "$M/baseline-staging" "$M/baseline" && mv "$M/checkrun-staging" "$M/checkrun" \
  || fail "could not move the staged folders into place"
chmod -R a-w "$M/frozen" "$M/baseline" "$M/checkrun"
listing() { (cd "$1" && find . -type f | sed 's|^\./||' | LC_ALL=C sort | while read -r f; do
  echo "$f $(sha256sum "$f" | cut -c1-64)"; done | sha256sum | cut -c1-64); }
FL=$(listing "$M/frozen"); echo "$FL" > "$M/logs/frozen.listing.sha256"
say "done: $M/frozen written and made read-only, listing sha256 $FL ($(find "$M/frozen" -type f | wc -l) files)"
say "baseline copies: $M/baseline listing $(listing "$M/baseline"), $M/checkrun listing $(listing "$M/checkrun")"
[ -f "$M/frozen/manifest.md" ] && say "manifest sha256 $(sha256sum "$M/frozen/manifest.md" | cut -c1-64)"
say "run the frozen kit from here on: $M/frozen/kit/preflight.sh, then $M/frozen/kit/run_step.sh <model> quality"
