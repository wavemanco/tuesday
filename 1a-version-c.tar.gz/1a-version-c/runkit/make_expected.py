"""make_expected.py: write the expected-values file freeze.sh checks the pins against, from an offline build.

    python3 -I -B make_expected.py --build <build dir> --variant <name> --out <expected.json>
        [--manifest <manifest.md>] [--inputs <manifest-inputs dir>] [--score-item <score_item.py>]
        [--harness-name-status <H.name-status>]

<build dir> holds tree/ (the candidate), tree-harness/ (the baseline), e23/ and patches/*.name-status (the
candidate's path list, the one file there that is not H's). The values are computed from the build's trees
with their own harness (lib/pin_values.py, the code freeze.py runs on the pinned worktrees), so the freeze
holds the pins to the build byte for byte and value for value. The baseline evidence copies (section 15)
and the scorer do not depend on the variant: they default to variant A's build.

The cross-check printed at the end looks up every value in the manifest the round runs under (--manifest):
each must appear there verbatim before the freeze, or the manifest and the build disagree.

For the stand-in dry run: --candidate-tree, --baseline-tree, --e23-dir, --name-status (a path, or 'none'
for an empty list) and --no-build-compare replace --build.
"""
import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
KIT = Path(__file__).resolve().parent
SCRATCH = KIT.parent.parent
BUILD_A = SCRATCH / "l1a" / "build"
INPUTS = BUILD_A / "manifest-inputs"
SCORE_ITEM = SCRATCH / "l1a" / "design" / "opus-ledger-sentence" / "scripts" / "score_item.py"
# Frozen by the manifest (sections 5 and 15); the same for every variant.
COPIES = {"baseline": ("recheck/baseline", "401a1636aa18713c0b81eb2c48be751cab69c2750a80aceff4dd183e038ef4cf", 3241),
          "checkrun": ("recheck/checkrun", "96e31915d8830f7858b0330e1c865f0bbb665f561b00225984f659c1a58cb2f1", 1220),
          "subsets": ("recheck/subsets.json", "74d7c75b5224a946a0547345c89a12a6f9577f2fdcd7444187acb30a3e0df986"),
          "recheck_report": ("recheck/recheck-report.json",
                             "58c849732f7604c53a9e0a5d4b2eed1497eb3f06691ce91ad566a0cb2edf21f8")}
SCORE_ITEM_SHA = "1f8d8cf4b149597151680ff467bdfbf290993fdfae4da48b09db80b0c4910ce2"


def pin_values(tree: Path) -> dict:
    p = subprocess.run([sys.executable, "-I", "-B", str(KIT / "lib" / "pin_values.py"), str(tree)],
                       capture_output=True, text=True, timeout=600)
    if p.returncode:
        raise SystemExit(f"pin_values failed on {tree}:\n{p.stderr[-2000:]}")
    return json.loads(p.stdout)


def name_status(path: str | None) -> list[str]:
    if path in (None, "none"):
        return []
    return [line for line in Path(path).read_text().splitlines() if line.strip()]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--build", type=Path)
    ap.add_argument("--variant", required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--manifest", type=Path, default=BUILD_A / "manifest.md")
    ap.add_argument("--inputs", type=Path, default=INPUTS)
    ap.add_argument("--score-item", type=Path, default=SCORE_ITEM)
    ap.add_argument("--harness-name-status", default=str(BUILD_A / "patches" / "H.name-status"))
    ap.add_argument("--candidate-tree", type=Path)
    ap.add_argument("--baseline-tree", type=Path)
    ap.add_argument("--e23-dir", type=Path)
    ap.add_argument("--name-status")
    ap.add_argument("--no-build-compare", action="store_true")
    a = ap.parse_args()
    if a.build:
        cand, base, e23 = a.build / "tree", a.build / "tree-harness", a.build / "e23"
        lists = [p for p in sorted((a.build / "patches").glob("*.name-status")) if p.name != "H.name-status"]
        if len(lists) != 1:
            raise SystemExit(f"{a.build}/patches holds {len(lists)} candidate path lists, not one: {lists}")
        ns = str(lists[0])
    else:
        cand, base, e23, ns = a.candidate_tree, a.baseline_tree, a.e23_dir, a.name_status
        if not (cand and base):
            ap.error("give --build, or --candidate-tree and --baseline-tree")
    vb, vc = pin_values(base), pin_values(cand)
    if vb["deps"] != vc["deps"] or vb["inventory"] != vc["inventory"]:
        raise SystemExit("the build's two trees differ in the harness: the round's harness is below both pins")
    e23_values = {}
    if e23 and e23.is_dir():
        for n, v in sorted(vc["e23"].items()):
            f = e23 / n
            if v is None or not f.is_file():
                raise SystemExit(f"{f}: the build's replay file is missing, or its case is not in the candidate")
            h = hashlib.sha256(f.read_bytes()).hexdigest()
            if h != v["sha256"] or not v["identical"]:
                raise SystemExit(f"{f}: the build's file ({h[:12]}) is not what the candidate regenerates "
                                 f"({v['sha256'][:12]}), or its expectations differ from the treatment's")
            e23_values[n] = h
    copies = {name: ({"from": str(a.inputs / spec[0]), "listing_sha256": spec[1], "files": spec[2]} if len(spec) == 3
                     else {"from": str(a.inputs / spec[0]), "sha256": spec[1]}) for name, spec in COPIES.items()}
    copies["score_item"] = {"from": str(a.score_item), "sha256": SCORE_ITEM_SHA}
    copies["manifest"] = {"from": str(a.manifest)}
    expected = {
        "variant": a.variant,
        "made_by": "make_expected.py",
        "baseline_sha": "7b56c174218e6288bf5f8b8a08a90cf38633b4e8",
        "name_status": {"candidate": name_status(ns), "harness": name_status(a.harness_name_status)},
        "digests": {"baseline": vb["tuesday_digests"], "candidate": vc["tuesday_digests"]},
        "payload": {"baseline": vb["payload"], "candidate": vc["payload"]},
        "measured": vb["measured"],
        "deps": vc["deps"], "inventory": vc["inventory"],
        "cases": {"baseline": vb["cases"], "candidate": vc["cases"]},
        "grader_prompt_sha256": vc["grader_prompt_sha256"],
        "rooms": {"candidate": vc["rooms"]},
        "e23": e23_values,
        "copies": copies,
        "build": {} if a.no_build_compare else {"tree": str(cand), "tree_harness": str(base),
                                                 **({"e23": str(e23)} if e23_values else {})},
    }
    a.out.write_text(json.dumps(expected, indent=1, sort_keys=True) + "\n")
    print(f"wrote {a.out} (variant {a.variant}): {len(expected['name_status']['candidate'])} candidate paths, "
          f"{len(e23_values)} replay files")

    # Cross-check against the manifest's text.
    text = a.manifest.read_text(encoding="utf-8") if a.manifest.is_file() else ""
    rows = [("digest candidate " + k, v) for k, v in vc["tuesday_digests"].items()]
    rows += [("digest baseline " + k, v) for k, v in vb["tuesday_digests"].items()]
    rows += [("payload candidate " + k, v) for k, v in vc["payload"].items()]
    rows += [("payload baseline " + k, v) for k, v in vb["payload"].items()]
    rows += [("dependency " + k, v) for k, v in vc["deps"].items()]
    rows += [("case candidate " + k, v) for k, v in vc["cases"].items() if k != "evals/suite-routing.json"]
    rows += [("case baseline " + k, v) for k, v in vb["cases"].items() if k != "evals/suite-routing.json"]
    rows += [("E23 " + k, v) for k, v in e23_values.items()]
    rows += [("grader prompt", vc["grader_prompt_sha256"]), ("scorer score_item.py", SCORE_ITEM_SHA)]
    rows += [(f"copy {k}", v.get("listing_sha256") or v.get("sha256")) for k, v in copies.items() if k != "manifest"]
    absent = [(label, v) for label, v in rows if v and v not in text]
    print(f"manifest cross-check against {a.manifest}: {len(rows) - len(absent)} of {len(rows)} values printed there")
    for label, v in absent:
        print(f"  NOT IN THE MANIFEST  {label}  {v}")
    print("  (evals/suite-routing.json, the layout probe's case file, is not in the manifest's case table: "
          f"{vc['cases']['evals/suite-routing.json']})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
