"""layout_check.py <layout-plugin.json> <save-probe result.json>: round 1a's init-list checks (preflight).

A copy of the fix round's layout check (round/layout_check.py, sha256 634b89eb...) with its paths changed to
the candidate worktree ($WT_CAND) and the code-name rename applied (the Tuesday arm is `tuesday`, its hash
`tuesday_sha256`). 1a runs only the plugin layout, in two installs, so the two checks are:

1. The routing runner's Tuesday arm in the plugin layout (the explicit panel's arm): one run of a probe case,
   read as before. The session's skill list holds the Tuesday family alone as the runner's own
   foreign_tuesday rule reads it (the CLI lists its own bundled skills in every session): every entry whose
   run_routing.tuesday_base is tuesday or a module carries the file's one run suffix, the run's own skills
   (Tuesday and the three modules) are all there, the outcome is decided (not void, timeout or error), and
   the file's Tuesday hashes equal the candidate's (sync.digests() of the worktree).
2. The fixture runner's two plugin installs, read from the save probe's sessions (save_probe.py keeps each
   session's init skill list): with the module alone, the Tuesday family is that one module; through
   Tuesday, it is Tuesday and the three modules; each session's family entries carry one run suffix, the
   one its install gave, and every session has an init event.

Writes nothing. Exit 0 when both pass.
"""
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path

WT = Path(os.environ.get("WT_CAND", "/var/tmp/tuesday-measure/1a-pins/candidate"))
sys.path[:0] = [str(WT / "evals"), str(WT / "ci")]
import run_routing as rr  # noqa: E402
import sync  # noqa: E402

assert Path(rr.__file__).resolve().is_relative_to(WT.resolve()) and Path(sync.__file__).resolve().is_relative_to(WT.resolve())
FAMILY = set(rr.SKILLS) | {rr.HUB}
SUFFIX = re.compile(r"-([0-9a-f]{8})$")


def family_notes(listed: list[str], want: set[str], suffix: str | None = None) -> tuple[bool, list[str]]:
    """Whether a session's skill list holds exactly `want` from the Tuesday family, under one run suffix
    (`suffix` when the install's own is known), with the CLI's own skills ignored."""
    ok, notes = True, []
    family = [s for s in listed if rr.tuesday_base(s) in FAMILY]
    suffixes = {m.group(1) for s in family for m in [SUFFIX.search(rr.local_name(s))] if m}
    bases = {rr.tuesday_base(s) for s in family}
    notes.append(f"{len(listed)} skills listed, {len(family)} of the Tuesday family {sorted(family)}, "
                 f"{len(listed) - len(family)} the CLI's own")
    if len(suffixes) != 1 or any(not SUFFIX.search(rr.local_name(s)) for s in family):
        ok = False
        notes.append(f"the Tuesday-family entries carry {len(suffixes)} run suffixes, or one carries none: "
                     f"a skill this run did not install is listed")
    elif suffix is not None and suffixes != {suffix}:
        ok = False
        notes.append(f"the Tuesday-family suffix {sorted(suffixes)} is not the install's {suffix}")
    if bases != want or len(family) != len(want):
        ok = False
        notes.append(f"the run's own skills are {sorted(bases)} ({len(family)} entries), not {sorted(want)}")
    return ok, notes


def score_routing(path: Path) -> tuple[bool, list[str]]:
    d = json.loads(path.read_text())
    notes, ok = [], True
    if (d.get("arm"), d.get("layout")) != ("tuesday", "plugin"):
        return False, [f"arm {d.get('arm')} with layout {d.get('layout')} is not the Tuesday arm's plugin layout"]
    runs = [run for res in d["results"] for run in res["runs"]]
    if len(runs) != 1:
        ok = False
        notes.append(f"{len(runs)} runs, not one")
    want = sync.digests()
    got = {k: d.get(k) for k in ("hub_sha256", "tuesday_sha256")}
    if got != {k: want[k] for k in got}:
        ok = False
        notes.append(f"Tuesday's hashes {got} are not the candidate's")
    for run in runs:
        listed = [s for s in run.get("init_skills") or [] if isinstance(s, str)]
        notes.append(f"outcome {run['outcome']}")
        if run["outcome"] in rr.SET_ASIDE:
            ok = False
            notes.append(f"outcome {run['outcome']} is not decided")
        good, more = family_notes(listed, FAMILY)
        ok, notes = ok and good, notes + more
    return ok, notes


def score_probe(path: Path) -> tuple[bool, list[str]]:
    d = json.loads(path.read_text())
    notes, ok, seen = [], True, set()
    for s in d.get("sessions") or []:
        install, names, listed = s.get("install"), s.get("installed") or {}, s.get("init_skills")
        want = FAMILY if install == "Tuesday" else {name for name in names}
        seen.add(install)
        head = f"{install}, {s.get('session')}: "
        if listed is None:
            ok = False
            notes.append(head + "no init event was read")
            continue
        suffixes = {m.group(1) for v in names.values() for m in [SUFFIX.search(v)] if m}
        good, more = family_notes(listed, want, next(iter(suffixes)) if len(suffixes) == 1 else None)
        ok = ok and good
        notes += [head + n for n in more]
    if seen != {"module alone", "Tuesday"}:
        ok = False
        notes.append(f"the probe's sessions cover {sorted(map(str, seen))}, not both plugin installs")
    return ok, notes


def main() -> int:
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    verdicts = []
    for label, scorer, arg in (("plugin layout through Tuesday (routing runner)", score_routing, sys.argv[1]),
                               ("plugin installs of the fixture runner (save probe sessions)", score_probe,
                                sys.argv[2])):
        ok, notes = scorer(Path(arg))
        verdicts.append(ok)
        print(f"{label}: {'PASS' if ok else 'FAIL'}  ({Path(arg).name})")
        for n in notes:
            print(f"  {n}")
    print("layout checks:", "PASS" if all(verdicts) else "FAIL")
    return 0 if all(verdicts) else 1


if __name__ == "__main__":
    raise SystemExit(main())
