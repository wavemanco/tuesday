"""meter.py <label>: one meter reading for the run log (manifest section 18, the stop rule).

A copy of the fix round's meter reader (round/meter.py, sha256 b8b4dcba...) with its paths changed to the
protected run directory: one tiny Haiku call, started clean (child_env, from the candidate worktree). It
saves the session's rate_limit_event to $M/logs/meter/<UTC time>-<label>.json and appends one line to the
run log: the time, the label, the seven-day utilization, the CLI version the session's own init event
reports, and when the seven-day window resets. Paths come from the environment the kit sets (M, WT_CAND,
LOG). TUESDAY_METER_CLI names the CLI binary, `claude` unless a dry run points it at a stub.
"""
import datetime
import json
import os
import subprocess
import sys
from pathlib import Path

M = Path(os.environ.get("M", "/var/tmp/tuesday-measure/1a"))
WT = Path(os.environ.get("WT_CAND", "/var/tmp/tuesday-measure/1a-pins/candidate"))
LOG = Path(os.environ.get("LOG", str(M / "logs" / "run-log.txt")))
CLI = os.environ.get("TUESDAY_METER_CLI", "claude")
sys.path.insert(0, str(WT / "evals"))
from child_env import child_env  # noqa: E402

label = "-".join(sys.argv[1:]) or "reading"
here = M / "logs" / "meter"
here.mkdir(parents=True, exist_ok=True)
now = datetime.datetime.now(datetime.timezone.utc)
try:
    p = subprocess.run([CLI, "-p", "Reply with OK.", "--model", "claude-haiku-5-5", "--output-format",
                        "stream-json", "--verbose"], capture_output=True, text=True, timeout=120, env=child_env(),
                       cwd=here)
    out, err, code = p.stdout, p.stderr, p.returncode
except (OSError, subprocess.SubprocessError) as exc:
    out, err, code = "", str(exc), None
version, info = None, None
for line in out.splitlines():
    try:
        e = json.loads(line)
    except ValueError:
        continue
    if e.get("type") == "system" and e.get("subtype") == "init":
        version = e.get("claude_code_version")
    if e.get("type") == "rate_limit_event":
        info = e.get("rate_limit_info") or e
stamp = now.strftime("%Y-%m-%dT%H:%M:%SZ")
window = ((info or {}).get("unifiedWindows") or {}).get("seven_day") or {}
if "utilization" not in window:
    line = f"{stamp} meter {label}: NO READING (exit {code}; {(out or err).strip()[:160]!r}); CLI {version}"
else:
    (here / f"{now.strftime('%Y%m%dT%H%M%SZ')}-{label}.json").write_text(json.dumps(info) + "\n")
    resets = window.get("resetsAt") or info.get("resetsAt")
    when = datetime.datetime.fromtimestamp(resets, datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ") \
        if isinstance(resets, (int, float)) else None
    line = f"{stamp} meter {label}: seven-day {window['utilization']}; CLI {version}; resets {when}"
LOG.parent.mkdir(parents=True, exist_ok=True)
with open(LOG, "a") as log:
    log.write(line + "\n")
print(line)
