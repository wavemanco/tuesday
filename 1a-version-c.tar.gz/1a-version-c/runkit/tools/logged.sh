#!/bin/bash
# logged.sh <label> <command...>: run one command with its start and end in the run log: UTC time and
# `claude --version` before and after, the command line, and the exit code. A copy of the fix round's
# (round/logged.sh) with the log moved to the protected run directory. The command's own output goes where
# the caller sends it. The command line never carries the account email (it travels in the environment).
set -u
source "$(dirname "${BASH_SOURCE[0]}")/../kit.env"
label=$1; shift
cli() { claude --version 2>/dev/null | head -1 || true; }
v=$(cli); echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) start $label: CLI ${v:-none}: $*" >> "$LOG"
"$@"; code=$?
v=$(cli); echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) end $label: exit $code; CLI ${v:-none}" >> "$LOG"
exit $code
