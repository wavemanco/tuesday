#!/bin/bash
# guard.sh <label> <process group> <status file>: read the meter every GUARD_INTERVAL seconds (20 minutes)
# while a measured step runs; at GUARD_STOP (95%) stop the step's whole process group, so the owner is not
# locked out of Claude. Stopped runs are killed runs (manifest section 14). A copy of the fix round's
# guard (round/guard.sh, sha256 c14cecb1...) with its paths changed to the protected run directory, the
# threshold and meter taken from kit.env, the comparison made in exact decimals (lib/stop_rule.py), a
# reading that fails logged as such, and a KILL for anything still running GUARD_GRACE seconds after TERM.
set -u
source "$(dirname "${BASH_SOURCE[0]}")/../kit.env"
LABEL=$1; PG=$2; ST=$3; n=0
GRACE=${GUARD_GRACE:-60}
alive() { kill -0 -- "-$PG" 2>/dev/null; }
finished() { grep -qE ' (done|stopped)$' "$ST" 2>/dev/null; }
echo "$(date -u +%H:%M:%S) guard: watching process group $PG every ${GUARD_INTERVAL}s, stop at $GUARD_STOP" >> "$ST"
while alive && ! finished; do
  sleep "$GUARD_INTERVAL"
  alive && ! finished || break
  n=$((n+1))
  line=$($METER "guard-$LABEL-$n" 2>&1 | tail -1)
  echo "$(date -u +%H:%M:%S) guard: $line" >> "$ST"
  u=$(echo "$line" | sed -n 's/.*seven-day \([0-9.]*\).*/\1/p')
  if [ -z "$u" ]; then
    echo "$(date -u +%H:%M:%S) guard: no reading this time; the step goes on, next reading in ${GUARD_INTERVAL}s" >> "$ST"
    continue
  fi
  if python3 -I -B "$KIT/lib/stop_rule.py" guard "$u" >> "$ST" 2>&1; then
    echo "$(date -u +%H:%M:%S) guard: meter $u >= $GUARD_STOP, stopping the step (process group $PG)" >> "$ST"
    echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) guard stopped $LABEL at meter $u (process group $PG)" >> "$LOG"
    kill -TERM -- "-$PG" 2>/dev/null
    for _ in $(seq "$GRACE"); do alive || break; sleep 1; done
    if alive; then
      kill -KILL -- "-$PG" 2>/dev/null
      echo "$(date -u +%H:%M:%S) guard: process group $PG still running ${GRACE}s after TERM, sent KILL" >> "$ST"
    fi
    echo "$(date -u +%H:%M:%S) stopped" >> "$ST"
    exit 0
  fi
done
echo "$(date -u +%H:%M:%S) guard: step ended, guard exits after $n reading(s)" >> "$ST"
