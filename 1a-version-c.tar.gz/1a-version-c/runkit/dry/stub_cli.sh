#!/bin/bash
# stub_cli.sh: stands in for the CLI binary in meter.py's dry test (TUESDAY_METER_CLI). Prints a saved-shape
# stream: an init event and a rate_limit_event, or nothing when STUB_CLI_MODE=empty. No session.
[ "${STUB_CLI_MODE:-}" = empty ] && { echo "stub: no stream" >&2; exit 1; }
echo '{"type":"system","subtype":"init","claude_code_version":"0.0.0-stub","session_id":"stub"}'
echo '{"type":"rate_limit_event","rate_limit_info":{"status":"allowed","resetsAt":1795068000,"rateLimitType":"seven_day","unifiedWindows":{"seven_day":{"utilization":0.44,"resetsAt":1795068000,"status":"allowed"}}}}'
echo '{"type":"result","subtype":"success","result":"OK"}'
