#!/bin/bash
# fake_meter.sh <label>: a simulated meter reading for the dry runs. Takes the next value from the file
# $FAKE_METER_SEQ (one a line; the last line repeats), "none" for a failed reading, and prints and logs a
# line in meter.py's own format. Never starts a session.
label=${1:-reading}; seq=${FAKE_METER_SEQ:?}
v=$(head -1 "$seq"); [ "$(wc -l < "$seq")" -gt 1 ] && sed -i 1d "$seq"
stamp=$(date -u +%Y-%m-%dT%H:%M:%SZ)
if [ "$v" = none ]; then line="$stamp meter $label: NO READING (exit 1; 'simulated'); CLI None"
else line="$stamp meter $label: seven-day $v; CLI 0.0.0-dry (stand-in CLI); resets 2026-11-19T06:00:00Z"; fi
echo "$line" >> "${LOG:?}"; echo "$line"
