#!/bin/bash
# dry/dry_run.sh: every offline check of the run kit, from scratch, with claude off PATH. No model, no CLI,
# no runner in execute mode, no network, nothing written in the repository (it is read by `git archive` and a
# shared clone made here). Results in dry/results.txt; each check prints what it expected and what it got.
#   A. syntax of every script; the tools' own self-tests (stop rule, save probe, meter parsing, layout check)
#   B. the expected-values files from builds A and B, cross-checked against the manifest
#   C. the stand-in pair: two folders from `git archive 7b56c17` standing in for both pins
#   D. the rehearsal: a scratch clone with variant A's candidate committed on the branch's merge-back commit
#      5696742 (a merge whose tree equals 7b56c17's), freeze to run_step; the same paths on a parent with a
#      different tree (7b56c17's own parent) are refused; the neutral folder names agree in plan, recovery and runs
#   E. simulated measured steps: the stop rule at start, the guard at 95%, refusals, sealing
#   F. the account email: nothing the kit wrote holds the stand-in address
set -u
D=$(cd "$(dirname "$0")" && pwd); K=$(dirname "$D"); S=$(dirname "$(dirname "$K")")
BUILD=$S/l1a/build; BUILD_B=$S/l1a/build-b
export PYTHONDONTWRITEBYTECODE=1
NP=$(python3 -I -c 'import os; print(":".join(d for d in os.environ["PATH"].split(":") if d and not os.access(os.path.join(d,"claude"), os.X_OK)))')
export PATH=$NP
command -v claude >/dev/null && { echo "claude is still on PATH: refusing to run"; exit 9; }
OUT=$D/results.txt; : > "$OUT"
pass=0; fail=0
say() { echo "$*" | tee -a "$OUT"; }
check() {  # check <wanted exit> <label> <command...>
  local want=$1 label=$2; shift 2
  local log="$D/logs/$(echo "$label" | tr -c 'A-Za-z0-9\n' '_' | cut -c1-80).txt"
  "$@" > "$log" 2>&1; local got=$?
  if [ "$got" = "$want" ]; then pass=$((pass+1)); say "  ok    $label (exit $got)"; else fail=$((fail+1)); say "  FAIL  $label (exit $got, wanted $want): $log"; fi
  LAST=$log
}
grep_check() {  # grep_check <label> <file> <pattern>
  if grep -qE -e "$3" "$2"; then pass=$((pass+1)); say "  ok    $1"; else fail=$((fail+1)); say "  FAIL  $1 (no /$3/ in $2)"; fi
}
show() { sed 's/^/          /' "$1" | cut -c1-220 | tee -a "$OUT" > /dev/null; }
rm -rf "$D/logs" "$D/standin" "$D/rehearsal"; mkdir -p "$D/logs"
CLI_DRY="0.0.0-dry (stand-in CLI)"
DUMMY=dry-run-owner@example.invalid
mkdir -p "$D/logs"; printf '{"oauthAccount": {"emailAddress": "%s"}}' "$DUMMY" > "$D/logs/account.json"
export KIT_ACCOUNT_JSON="$D/logs/account.json"   # the kit reads the scan address from the CLI account file; here, the stand-in

say "run kit dry run, $(date -u +%Y-%m-%dT%H:%M:%SZ), claude off PATH ($(command -v claude || echo 'not found'))"
say ""; say "A. Syntax and the tools' self-tests"
for f in "$K"/*.sh "$K"/tools/*.sh "$D"/*.sh; do check 0 "bash -n $(basename "$f")" bash -n "$f"; done
for f in "$K"/*.py "$K"/tools/*.py "$K"/lib/*.py; do
  check 0 "python parses $(basename "$f")" python3 -I -B -c 'import ast,sys; ast.parse(open(sys.argv[1]).read())' "$f"; done
check 0 "stop rule self-test (thresholds, simulated readings, the chained table)" python3 -I -B "$K/lib/stop_rule.py" self-test
show "$LAST"

say ""; say "B. Expected values from the builds, cross-checked against the manifest"
check 0 "make_expected.py on build A" python3 -I -B "$K/make_expected.py" --build "$BUILD" --variant A --out "$K/expected/expected-A.json"
show "$LAST"
check 0 "make_expected.py on build B" python3 -I -B "$K/make_expected.py" --build "$BUILD_B" --variant B --out "$K/expected/expected-B.json"
show "$LAST"

say ""; say "C. The stand-in pair: both pins from git archive 7b56c17"
C=$D/standin; mkdir -p "$C/base" "$C/cand"
git -C /home/user/tuesday archive 7b56c17 | tar -x -C "$C/base"; git -C /home/user/tuesday archive 7b56c17 | tar -x -C "$C/cand"
git init -q "$C/idrepo" && git -C "$C/idrepo" config user.email "$DUMMY"
SI=(env REPO="$C/idrepo" M="$C/M" PINS="$C/pins" WT_BASE="$C/base" WT_CAND="$C/cand" CLI_VERSION="$CLI_DRY")
check 1 "freeze --dirs with variant A's values stops (path list, candidate digests, cases, rooms, E23)" \
  "${SI[@]}" "$K/freeze.sh" --dirs "$C/base" "$C/cand" "$K/expected/expected-A.json"
grep -E 'STOP |STOPPED' "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
[ ! -e "$C/M/frozen" ] && { pass=$((pass+1)); say "  ok    nothing was copied after the stop"; } || { fail=$((fail+1)); say "  FAIL  a frozen folder exists after a stop"; }
check 0 "make_expected.py for the stand-in (candidate = baseline, empty path list, no replay)" \
  python3 -I -B "$K/make_expected.py" --variant stand-in --out "$C/expected-standin.json" \
  --candidate-tree "$C/cand" --baseline-tree "$C/base" --name-status none --no-build-compare
check 0 "freeze --dirs with the stand-in's own values passes" "${SI[@]}" "$K/freeze.sh" --dirs "$C/base" "$C/cand" "$C/expected-standin.json"
grep -E 'all checks passed|done:' "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
check 1 "preflight --offline on the stand-in fails where 7b56c17 lacks 1a (new fixtures, sentinels, replays)" \
  "${SI[@]}" "$C/M/frozen/kit/preflight.sh" --offline
grep -E '  (PASS|FAIL) ' "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
check 1 "run_step haiku quality --plan on the stand-in: existing parts accepted, new parts plan 0 runs" \
  "${SI[@]}" bash "$C/M/frozen/kit/run_step.sh" haiku quality --plan
grep -E '^  (ok|FAIL) ' "$LAST" | cut -c1-150 | sed 's/^/          /' | tee -a "$OUT" > /dev/null

say ""; say "D. The rehearsal: variant A's candidate committed on the branch's merge-back commit, in a scratch clone"
R=$D/rehearsal; mkdir -p "$R"
git clone -q --shared --no-checkout /home/user/tuesday "$R/repo"
G() { git -C "$R/repo" "$@"; }
G config user.name "dry run"; G config user.email "$DUMMY"
G update-ref refs/remotes/origin/main 7b56c174218e6288bf5f8b8a08a90cf38633b4e8
MERGE=5696742555832dd6e98aff72bafe3c31fa2d1738   # HEAD of claude/skill-job-underwriter-95xjz8: merges main (#20) back
check 0 "the candidate's parent, $MERGE, is a merge commit whose tree equals 7b56c17's" \
  bash -c "[ \$(git -C '$R/repo' rev-list --parents -n 1 $MERGE | wc -w) -eq 3 ] && [ \$(git -C '$R/repo' rev-parse $MERGE^{tree}) = \$(git -C '$R/repo' rev-parse 7b56c17^{tree}) ]"
on_parent() {  # on_parent <parent> <message>: variant A's candidate paths committed on <parent>; prints the SHA
  G checkout -q --detach "$1"
  cut -f2 "$BUILD/patches/C.name-status" | while read -r p; do cp "$BUILD/tree/$p" "$R/repo/$p"; done
  G add -A; G commit -q -m "$2"; G rev-parse HEAD
}
CAND_OTHER=$(on_parent 7b56c17^ "Rehearsal candidate: variant A's paths on 7b56c17's parent, another tree (dry run only)")
CAND=$(on_parent "$MERGE" "Rehearsal candidate: variant A's paths on the merge-back commit (dry run only)")
say "  rehearsal candidate $CAND on $(G rev-parse HEAD^) (tree $(G rev-parse HEAD^^{tree}); 7b56c17's tree $(G rev-parse 7b56c17^{tree}))"
say "  the same paths on a parent with another tree: $CAND_OTHER on $(G rev-parse "$CAND_OTHER^") (tree $(G rev-parse "$CAND_OTHER^^{tree}"))"
RE=(env REPO="$R/repo" M="$R/M" PINS="$R/pins" CLI_VERSION="$CLI_DRY")
check 1 "freeze refuses a candidate that is on no remote branch" "${RE[@]}" "$K/freeze.sh" "$CAND" "$K/expected/expected-A.json"
grep_check "  ... after accepting its parent: a merge whose tree equals the baseline's" "$LAST" "one commit on $MERGE, whose tree [0-9a-f]{40} equals the baseline"
grep_check "  ... and it stops on the remote branch, not on the parent" "$LAST" 'is on no remote branch'
check 1 "freeze refuses a candidate whose parent's tree is not the baseline's (the same paths on 7b56c17's parent)" "${RE[@]}" FREEZE_ALLOW_UNPUSHED=1 "$K/freeze.sh" "$CAND_OTHER" "$K/expected/expected-A.json"
grep_check "  ... naming the parent's tree and the baseline's" "$LAST" "parent [0-9a-f]{40} has tree [0-9a-f]{40}, not the baseline [0-9a-f]{40}'s tree [0-9a-f]{40}"
check 1 "freeze refuses the baseline itself as the candidate (its parent's tree is not the baseline's)" "${RE[@]}" FREEZE_ALLOW_UNPUSHED=1 "$K/freeze.sh" 7b56c17 "$K/expected/expected-A.json"
grep_check "  ... on the parent's tree" "$LAST" "has tree [0-9a-f]{40}, not the baseline"
check 1 "freeze refuses the merge-back commit itself as the candidate (a merge, not one commit on one parent)" "${RE[@]}" FREEZE_ALLOW_UNPUSHED=1 "$K/freeze.sh" "$MERGE" "$K/expected/expected-A.json"
grep_check "  ... as a merge" "$LAST" 'not one commit on one parent'
check 1 "freeze with variant B's values stops on the candidate's case and replay hashes" "${RE[@]}" FREEZE_ALLOW_UNPUSHED=1 "$K/freeze.sh" "$CAND" "$K/expected/expected-B.json"
grep -E 'STOP ' "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
check 0 "freeze with variant A's values passes, the candidate on the merge-back commit" "${RE[@]}" FREEZE_ALLOW_UNPUSHED=1 "$K/freeze.sh" "$CAND" "$K/expected/expected-A.json"
grep -E "^  (ok|STOP) |all checks passed|done:|candidate's parent" "$LAST" | cut -c1-160 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
check 0 "freeze.json logs the candidate's parent SHA and tree beside the baseline's SHA and tree" python3 -I -B -c '
import json, sys
f = json.load(open(sys.argv[1]))["facts"]
assert f["candidate_parent_sha"] == sys.argv[2] and f["baseline_sha"] == sys.argv[3], f
assert f["candidate_parent_tree"] == f["baseline_tree"] and len(f["baseline_tree"]) == 40, f
print("parent", f["candidate_parent_sha"], "tree", f["candidate_parent_tree"], "| baseline", f["baseline_sha"], "tree", f["baseline_tree"])
' "$R/M/frozen/freeze.json" "$MERGE" 7b56c174218e6288bf5f8b8a08a90cf38633b4e8
show "$LAST"
check 1 "freeze refuses to run again over the frozen folder" "${RE[@]}" FREEZE_ALLOW_UNPUSHED=1 "$K/freeze.sh" "$CAND" "$K/expected/expected-A.json"
check 0 "the worktrees are clean after the freeze" bash -c "[ -z \"\$(git -C $R/pins/baseline status --porcelain)\$(git -C $R/pins/candidate status --porcelain)\" ]"
FK=$R/M/frozen/kit
check 0 "preflight --offline on the rehearsal passes" "${RE[@]}" "$FK/preflight.sh" --offline
grep -E '  (PASS|FAIL) |  (ok|FAIL)  ' "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
for s in "haiku quality" "sonnet quality" "opus quality" "all explicit"; do set -- $s
  check 0 "run_step $1 $2 --plan: every command line accepted by the pinned runner with the priced plan" "${RE[@]}" bash "$FK/run_step.sh" "$1" "$2" --plan
  tail -1 "$LAST" | sed 's/^/          /' | tee -a "$OUT" > /dev/null
  [ "$1" = haiku ] && PLAN_HAIKU=$LAST
done
# The neutral folder names (owner question 26): the plan's --out folders are kit.env's maps, and no folder names a module.
for f in alone/part-1 alone/part-4 alone/part-2 alone/part-5 tuesday/part-1 tuesday/part-4 tuesday/part-2 tuesday/part-5 \
         e23/part-1 e23/part-2 e23/part-3 e23/part-4 e23/part-5 e23/part-6 e23/part-7; do
  grep_check "plan: an --out folder is \$RUNS/haiku/$f" "$PLAN_HAIKU" "--out \\\$RUNS/haiku/$f\$"
done
check 1 "plan: no --out folder names or abbreviates a module" grep -E -- '--out [^ ]*/(ju-|mi-|job-underwriter|mock-interview)' "$PLAN_HAIKU"
grep_check "plan: the E23 replay into e23/part-1 reads job-underwriter 7's case file" "$PLAN_HAIKU" 'e23-job-underwriter-7\.json .*--out \$RUNS/haiku/e23/part-1$'
grep_check "plan: the E23 replay into e23/part-7 reads mock-interview 13's case file" "$PLAN_HAIKU" 'e23-mock-interview-13\.json .*--out \$RUNS/haiku/e23/part-7$'
grep -E '^  (ok|FAIL) ' "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
# The runner refuses a pass that differs from its expect file: a Haiku command given Sonnet's expect file.
EX=$(cd "$R/pins/candidate" && DRY_CLI_VERSION="$CLI_DRY" python3 -I -B "$FK/lib/dry_runner.py" evals/run_fixtures.py --skill job-underwriter \
  --eval 7 --model claude-haiku-5-5 --via skill --layout plugin --runs 5 --retry-runs 0 --graders 2 --grader-model claude-sonnet-5-5 \
  --workers 3 --timeout 900 --expect "$R/M/frozen/expect/sonnet/alone/ju-new.json" --out "$D/logs/refusal-out" 2>&1; echo "exit $?")
echo "$EX" > "$D/logs/expect-refusal.txt"
grep_check "the runner refuses a Haiku pass against Sonnet's expect file, before any call" "$D/logs/expect-refusal.txt" '^refused: --expect: model is .claude-haiku-5-5., frozen .claude-sonnet-5-5.'
grep_check "  ... and the dry runner reports the refusal (exit 3)" "$D/logs/expect-refusal.txt" '^exit 3$'
EX=$(cd "$R/pins/candidate" && python3 -I -B "$FK/lib/dry_runner.py" evals/run_fixtures.py --skill job-underwriter --eval 7 --runs 5 \
  --retry-runs 2 --expect "$R/M/frozen/expect/haiku/alone/ju-new.json" --out "$D/logs/refusal-out2" 2>&1; echo "exit $?")
echo "$EX" > "$D/logs/retry-refusal.txt"
grep_check "the runner refuses --retry-runs other than 0 with --expect" "$D/logs/retry-refusal.txt" 'retry-runs 0'
EX=$(cd "$R/pins/candidate" && python3 -I -B "$FK/lib/dry_runner.py" evals/run_routing.py --arm tuesday --layout plugin --cases "$R/M/frozen/suite-explicit.json" \
  --runs 5 --model claude-haiku-5-5 --workers 3 --expect 4d10 a4e5 --json-out "$D/logs/x.json" 2>&1; echo "exit $?")
echo "$EX" > "$D/logs/routing-expect.txt"
grep_check "the manifest's explicit command line as printed (with --expect) is refused by run_routing" "$D/logs/routing-expect.txt" 'are for --merge'
check 0 "run_step haiku quality --recovery prints the killed-run and grade-gap commands" "${RE[@]}" bash "$FK/run_step.sh" haiku quality --recovery
sed -n '1,9p' "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
REC=$LAST
grep_check "recovery: the killed-run move for the new job-underwriter rooms uses runs/haiku/alone/part-4" "$REC" "--skill job-underwriter --eval 7 .*--out $R/M/runs/haiku/alone/part-4 --killed --move"
grep_check "recovery: the grade-gap command for the new mock-interview rooms uses runs/haiku/tuesday/part-5" "$REC" "--out $R/M/runs/haiku/tuesday/part-5 --graders 2 --grade-gaps --move"
grep_check "recovery: the E23 replays recover into runs/haiku/e23/part-1 to part-7" "$REC" "--out $R/M/runs/haiku/e23/part-7 --killed --move"
check 1 "recovery: no folder names or abbreviates a module" grep -E -- '--out [^ ]*/(ju-|mi-|job-underwriter|mock-interview)' "$REC"
check 0 "the tools: save probe self-test on the rehearsal candidate" env WT_CAND="$R/pins/candidate" python3 -I -B "$FK/tools/save_probe.py" --self-test
tail -1 "$LAST" | sed 's/^/          /' | tee -a "$OUT" > /dev/null
mkdir -p "$D/logs/meter-test"
check 0 "the tools: meter.py parses a stub stream (seven-day, CLI, reset time)" env M="$D/logs/meter-test" WT_CAND="$R/pins/candidate" LOG="$D/logs/meter-test/log.txt" TUESDAY_METER_CLI="$D/stub_cli.sh" python3 -I -B "$FK/tools/meter.py" stub
cat "$LAST" | sed 's/^/          /' | tee -a "$OUT" > /dev/null
check 0 "the tools: meter.py reports NO READING on an empty stream" env M="$D/logs/meter-test" WT_CAND="$R/pins/candidate" LOG="$D/logs/meter-test/log.txt" STUB_CLI_MODE=empty TUESDAY_METER_CLI="$D/stub_cli.sh" python3 -I -B "$FK/tools/meter.py" stub-empty
grep_check "  ... and the reading carries no number the stop rule could read" "$LAST" 'NO READING'
(cd "$R/pins/candidate" && WT_CAND="$R/pins/candidate" python3 -I -B "$FK/lib/preflight_checks.py" synth-layout "$D/logs/layout") > /dev/null
python3 -I -B - "$D/logs/layout" <<'PYT'
import json, sys; from pathlib import Path
d = Path(sys.argv[1]); p = json.loads((d / "save-probe.synthetic.json").read_text())
p["sessions"][0]["init_skills"].append("mock-interview-0badc0de:mock-interview-0badc0de")
(d / "save-probe.foreign.json").write_text(json.dumps(p))
r = json.loads((d / "layout-plugin.synthetic.json").read_text()); r["tuesday_sha256"] = "0" * 64
(d / "layout-plugin.wronghash.json").write_text(json.dumps(r))
PYT
check 0 "the tools: layout check passes synthetic files from a real plugin install" env WT_CAND="$R/pins/candidate" python3 -I -B "$FK/tools/layout_check.py" "$D/logs/layout/layout-plugin.synthetic.json" "$D/logs/layout/save-probe.synthetic.json"
check 1 "the tools: layout check fails a second, foreign mock-interview in a session's skill list" env WT_CAND="$R/pins/candidate" python3 -I -B "$FK/tools/layout_check.py" "$D/logs/layout/layout-plugin.synthetic.json" "$D/logs/layout/save-probe.foreign.json"
check 1 "the tools: layout check fails a Tuesday hash that is not the candidate's" env WT_CAND="$R/pins/candidate" python3 -I -B "$FK/tools/layout_check.py" "$D/logs/layout/layout-plugin.wronghash.json" "$D/logs/layout/save-probe.synthetic.json"

say ""; say "E. Simulated measured steps (stubbed runner, simulated meter, guard every 2 seconds)"
SEQ=$D/logs/meter-seq.txt
SIM=(env REPO="$R/repo" M="$R/M" PINS="$R/pins" CLI_VERSION="$CLI_DRY" DRY_LAUNCH=1 METER="$D/fake_meter.sh" FAKE_METER_SEQ="$SEQ" GUARD_INTERVAL=2 GUARD_GRACE=3)
printf '0.81\n' > "$SEQ"
check 1 "haiku at 81%: not started (above 80%)" "${SIM[@]}" bash "$FK/run_step.sh" haiku quality; tail -2 "$LAST" | sed 's/^/          /' | tee -a "$OUT" > /dev/null
printf '0.7455\n' > "$SEQ"
check 1 "sonnet at 74.55%: not started (74.55 + 15.46 > 90)" "${SIM[@]}" bash "$FK/run_step.sh" sonnet quality; tail -2 "$LAST" | sed 's/^/          /' | tee -a "$OUT" > /dev/null
printf 'none\n' > "$SEQ"
check 1 "haiku with no meter reading: not started" "${SIM[@]}" bash "$FK/run_step.sh" haiku quality
check 1 "opus without the owner's go: not started" "${SIM[@]}" bash "$FK/run_step.sh" opus quality
check 1 "explicit on a weekday the suite names (today simulated as one): not started" "${SIM[@]}" EXPLICIT_BLOCKED_DAYS="$(date -u +%A)" bash "$FK/run_step.sh" all explicit --owner-go "dry run"
printf '0.44\n0.45\n0.46\n0.47\n' > "$SEQ"
check 0 "haiku at 44%: starts, runs its 15 command lines through the stubbed runner, guard reads, seals" "${SIM[@]}" bash "$FK/run_step.sh" haiku quality
tail -22 "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
check 0 "the simulated step's logs and seal use the neutral folders and no module-named one" bash -c '
cd "$1/M" || exit 9
for f in alone/part-1 alone/part-4 alone/part-2 alone/part-5 tuesday/part-1 tuesday/part-4 tuesday/part-2 tuesday/part-5 \
         e23/part-1 e23/part-2 e23/part-3 e23/part-4 e23/part-5 e23/part-6 e23/part-7; do
  [ -f "runs/haiku/$f.log" ] || { echo "no runs/haiku/$f.log"; exit 1; }
  ls -d sealed/haiku-quality-*/haiku/$f > /dev/null 2>&1 || { echo "no sealed folder for $f"; exit 1; }
done
bad=$(find runs/haiku sealed -type d \( -name "ju-*" -o -name "mi-*" -o -name "job-underwriter*" -o -name "mock-interview*" \) | head -3)
[ -z "$bad" ] || { echo "module-named folders: $bad"; exit 1; }
echo "15 logs and 15 sealed folders, all neutral"' _ "$R"
show "$LAST"
check 1 "haiku again: not started, its output folders exist" "${SIM[@]}" bash "$FK/run_step.sh" haiku quality; tail -1 "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
printf '0.60\n0.80\nnone\n0.96\n0.97\n' > "$SEQ"
check 4 "sonnet at 60% with 60-second stand-in commands: the guard stops the process group at 96%" \
  "${SIM[@]}" DRY_LAUNCH=sleep:60 bash "$FK/run_step.sh" sonnet quality
tail -8 "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
sed 's/^/          status: /' "$R/M/logs/status/sonnet-quality.status" | tee -a "$OUT" > /dev/null
sleep 1
check 1 "no process of the stopped step is left" pgrep -f "sleep 60"
[ -z "$(ls "$R/M/sealed" 2>/dev/null | grep sonnet)" ] && { pass=$((pass+1)); say "  ok    the stopped step was not sealed"; } || { fail=$((fail+1)); say "  FAIL  the stopped step was sealed"; }
printf '0.50\n0.51\n' > "$SEQ"
check 0 "explicit at 50% with the owner's go: three models in parallel through the stubbed runner, sealed" "${SIM[@]}" bash "$FK/run_step.sh" all explicit --owner-go "dry run: owner's go simulated"
tail -6 "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
printf '0.40\n' > "$SEQ"; rm -rf "$R/M/runs/sonnet"
check 5 "sonnet with a runner that crashes (exit 1 and a traceback): not read as a normal end" "${SIM[@]}" DRY_LAUNCH=crash bash "$FK/run_step.sh" sonnet quality
grep -E 'CRASHED|outside exit' "$LAST" | head -2 | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
printf '0.7251\n' > "$SEQ"
check 1 "opus at 72.51% with the owner's go: not started (72.51 + 17.5 > 90)" "${SIM[@]}" bash "$FK/run_step.sh" opus quality --owner-go "dry run"
printf '0.725\n0.73\n' > "$SEQ"
check 0 "opus at 72.5% with the owner's go: starts and finishes" "${SIM[@]}" bash "$FK/run_step.sh" opus quality --owner-go "dry run"
check 1 "a measured step refuses the offline preflight record without a dry launch" env REPO="$R/repo" M="$R/M" PINS="$R/pins" CLI_VERSION="$CLI_DRY" METER="$D/fake_meter.sh" FAKE_METER_SEQ="$SEQ" bash "$FK/run_step.sh" haiku quality
tail -1 "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
say "  the guard alone, against a process group that ignores TERM:"
setsid bash -c 'trap "" TERM; sleep 120 & trap "" TERM; wait' & GP=$!; sleep 1
printf '0.94\nnone\n0.95\n' > "$SEQ"; : > "$D/logs/guard.status"
check 0 "guard: 94% goes on, no reading goes on, 95% stops with TERM then KILL" env M="$R/M" LOG="$D/logs/guard-runlog.txt" METER="$D/fake_meter.sh" FAKE_METER_SEQ="$SEQ" GUARD_INTERVAL=1 GUARD_GRACE=2 "$FK/tools/guard.sh" test "$(ps -o pgid= -p $GP | tr -d ' ')" "$D/logs/guard.status"
sed 's/^/          /' "$D/logs/guard.status" | tee -a "$OUT" > /dev/null
sleep 1; kill -0 "$GP" 2>/dev/null && { fail=$((fail+1)); say "  FAIL  the process group survived"; kill -KILL -- -"$GP"; } || { pass=$((pass+1)); say "  ok    the process group is gone"; }

say ""; say "F. The account email and the run log"
hits=$(grep -rl --exclude-dir=.git --exclude-dir=repo -F "$DUMMY" "$D" "$K" 2>/dev/null | grep -v "/dry/dry_run.sh$" | grep -v "/dry/results.txt$" | grep -v "/dry/logs/account.json$" | wc -l)
[ "$hits" -eq 0 ] && { pass=$((pass+1)); say "  ok    no file the kit wrote holds the stand-in account address (it was read from the stand-in account file each time)"; } \
  || { fail=$((fail+1)); say "  FAIL  $hits file(s) hold the stand-in account address"; grep -rl --exclude-dir=.git --exclude-dir=repo -F "$DUMMY" "$D" "$K" | tee -a "$OUT"; }
say "  the rehearsal's run log, from the freeze to the last simulated step ($(wc -l < "$R/M/logs/run-log.txt") lines; meter lines and the per-command lines left out):"
grep -vE ' meter |: (start|end) ' "$R/M/logs/run-log.txt" | cut -c1-190 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
find "$K" "$S/l1a/build/tree" "$S/l1a/build/tree-harness" "$S/l1a/build-b/tree" "$S/l1a/build-b/tree-harness" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null
say ""; say "dry run: $pass passed, $fail failed"
[ "$fail" -eq 0 ]
