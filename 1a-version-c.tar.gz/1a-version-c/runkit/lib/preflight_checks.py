"""preflight_checks.py <check> ...: preflight's offline checks, run with the candidate worktree's own harness.

    preflight_checks.py sentinels <frozen dir>
        Every frozen case file (candidate and baseline case files, the seven E23 files) loaded with the pinned
        loader: each declared sentinel list keeps the freezing rules (output_checks.sentinel_declaration_reasons,
        the reader CI and the scan share), the kinds per fixture are the manifest's (section 9), and each E23
        file declares exactly its treatment case's list. Whether a spelling appears in shipped skill text is
        ci/check_skills.py --only fixtures, which preflight.sh runs beside this.
    preflight_checks.py email <root>...
        The account-email scan, set up from TUESDAY_SCAN_ACCOUNT_EMAIL (preflight.sh reads it from the CLI's signed-in account, lib/account_email.py):
        the runtime sentinel is read, the scan's matcher finds the address, the drivers' masking removes it,
        and the folders given hold it 0 times. Prints counts only, never the value.
    preflight_checks.py synth-layout <dir>
        For the offline dry run only: a routing results file and a save-probe result as the two layout checks
        read them, built from a real plugin install of the candidate (names, suffixes and digests), so
        tools/layout_check.py can be run without a session.
"""
import json
import os
import sys
import tempfile
import uuid
from pathlib import Path

sys.dont_write_bytecode = True
WT = Path(os.environ.get("WT_CAND", "/var/tmp/tuesday-measure/1a-pins/candidate"))
sys.path[:0] = [str(WT / "evals"), str(WT / "ci")]
import fixture_clauses as fc  # noqa: E402
import output_checks as oc  # noqa: E402
import run_fixtures as rf  # noqa: E402
import run_routing as rr  # noqa: E402

for mod in (fc, oc, rf, rr):
    assert Path(mod.__file__).resolve().is_relative_to(WT.resolve()), mod.__file__

# Manifest section 9: the fixtures that plant a value, and the kinds each declares. Every other fixture
# declares none.
KINDS = {("job-underwriter", 7): {"government_id", "professional_registration"},
         ("job-underwriter", 8): {"protected_value"},
         ("mock-interview", 9): {"government_id", "professional_registration"},
         ("mock-interview", 12): {"protected_value"}}


def sentinels(frozen: Path) -> int:
    bad, seen = 0, 0
    treatment = {}
    for skill in ("job-underwriter", "mock-interview"):
        for case in fc.load_cases(frozen / "cases" / "candidate" / f"{skill}.evals.json"):
            treatment[(skill, case["id"])] = case
    for key in sorted(set(KINDS) - set(treatment)):
        print(f"  FAIL candidate {key[0]} {key[1]}: the fixture that plants {sorted(KINDS[key])} is not in the case file")
        bad += 1
    for (skill, n), case in sorted(treatment.items()):
        kinds = {str(s.get("kind")) for s in case.get("sentinels") or [] if isinstance(s, dict)}
        want = KINDS.get((skill, n), set())
        problems = oc.sentinel_declaration_reasons(case)
        ok = kinds == want and not problems
        seen += bool(case.get("sentinels"))
        if case.get("sentinels") or want:
            print(f"  {'ok  ' if ok else 'FAIL'} candidate {skill} {n}: kinds {sorted(kinds)}"
                  f"{'' if kinds == want else f' (manifest: {sorted(want)})'}"
                  f"{''.join('; ' + p for p in problems)}")
        bad += not ok
    for path in sorted((frozen / "e23").glob("e23-*.json")):
        skill, n = path.stem[len("e23-"):].rsplit("-", 1)
        cases = fc.load_cases(path)
        case = cases[0] if len(cases) == 1 else None
        same = case is not None and case.get("sentinels") == treatment.get((skill, int(n)), {}).get("sentinels")
        problems = oc.sentinel_declaration_reasons(case) if case else ["not one case"]
        ok = same and not problems
        print(f"  {'ok  ' if ok else 'FAIL'} {path.name}: {len((case or {}).get('sentinels') or [])} list(s), "
              f"{'the treatment case' + chr(39) + 's own' if same else 'NOT the treatment case' + chr(39) + 's'}"
              f"{''.join('; ' + p for p in problems)}")
        bad += not ok
    for skill in ("job-underwriter", "mock-interview"):
        for case in fc.load_cases(frozen / "cases" / "baseline" / f"{skill}.evals.json"):
            if case.get("sentinels"):
                problems = oc.sentinel_declaration_reasons(case)
                print(f"  {'ok  ' if not problems else 'FAIL'} baseline {skill} {case['id']} declares sentinels")
                bad += bool(problems)
    print(f"sentinel declarations: {seen} candidate fixture(s) declare lists; "
          f"{'all keep the rules and match the manifest' if not bad else f'{bad} problem(s)'}")
    return 1 if bad else 0


def email(roots: list[str]) -> int:
    value = (os.environ.get(oc.ACCOUNT_EMAIL_ENV) or "").strip()
    bad = 0

    def check(label, cond):
        nonlocal bad
        bad += not cond
        print(f"  {'ok  ' if cond else 'FAIL'} {label}")
    check(f"{oc.ACCOUNT_EMAIL_ENV} is set for the runner (value not shown)", bool(value) and "@" in value)
    if not value:
        print("account-email scan: NOT SET UP")
        return 1
    runtime = oc.runtime_sentinels(os.environ)
    check("the runner reads it as one runtime sentinel of kind account_email",
          len(runtime) == 1 and runtime[0]["kind"] == "account_email")
    probe = f"saved to room/{value}_notes.md"
    check("the scan's matcher finds it in a saved file's name",
          oc.sentinel_in(oc.sentinel_form(value), oc.sentinel_form(probe), "account_email"))
    check("the scan's matcher does not take another address that contains it",
          not oc.sentinel_in(oc.sentinel_form(value), oc.sentinel_form("co-" + value), "account_email"))
    masked = rf.masked({"reason": f"the CLI said {value}", "argv": [value.upper()]})
    flat = json.dumps(masked)
    check("the drivers' masking removes it from every record they write (any letter case)",
          value.lower() not in flat.lower() and "[account email removed]" in flat)
    total = 0
    needle = value.lower().encode()
    for root in roots:
        n = files = 0
        for p in Path(root).rglob("*"):
            if p.is_file() and ".git" not in p.parts:
                files += 1
                try:
                    n += p.read_bytes().lower().count(needle) + str(p).lower().count(value.lower())
                except OSError:
                    pass
        total += n
        check(f"{root}: the address appears 0 times in {files} files and their names (found {n})", n == 0)
    print(f"account-email scan: {'set up' if not bad else f'{bad} problem(s)'}")
    return 1 if bad else 0


def synth_layout(out: Path) -> int:
    import sync
    out.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        sessions = []
        for install, module in (("module alone", "mock-interview"), ("Tuesday", None)):
            for kind in ("A, save inside the room", "B, append to the plugin's own SKILL.md"):
                run_id = uuid.uuid4().hex[:8]
                room = Path(tmp) / "rooms" / f"case-probe-denied-{run_id}"
                room.mkdir(parents=True)
                _, names = rf.install_in_plugin(room, run_id, module)
                listed = [f"{v}:{v}" for v in names.values()] + ["update-config", "simplify", "init"]
                sessions.append({"install": install, "session": kind, "installed": names, "init_skills": listed,
                                 "verdict": "PASS"})
        run_id = uuid.uuid4().hex[:8]
        hub = [f"tuesday-{run_id}:{s}-{run_id}" for s in [rr.HUB, *rr.SKILLS]]
    d = sync.digests()
    routing = {"arm": "tuesday", "layout": "plugin", "hub_sha256": d["hub_sha256"], "tuesday_sha256": d["tuesday_sha256"],
               "results": [{"id": 1, "runs": [{"outcome": "job-underwriter", "init_skills": hub + ["update-config"]}]}]}
    (out / "layout-plugin.synthetic.json").write_text(json.dumps(routing, indent=1))
    (out / "save-probe.synthetic.json").write_text(json.dumps({"verdict": "PASS", "sessions": sessions}, indent=1))
    print(f"synthetic layout files in {out}")
    return 0


def main() -> int:
    if sys.argv[1:2] == ["sentinels"] and len(sys.argv) == 3:
        return sentinels(Path(sys.argv[2]))
    if sys.argv[1:2] == ["email"]:
        return email(sys.argv[2:])
    if sys.argv[1:2] == ["synth-layout"] and len(sys.argv) == 3:
        return synth_layout(Path(sys.argv[2]))
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main())
