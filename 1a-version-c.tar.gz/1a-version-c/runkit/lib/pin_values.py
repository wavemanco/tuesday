"""pin_values.py <tree> [--e23-out <dir>]: every value the freeze checks, computed from one tree with that
tree's own harness (each tree in its own process, so no module is shared between pins). Prints JSON.

- tuesday_digests: ci/check_skills.tuesday_digests() (hub, tuesday, builds) and the tree's MEASURED_TUESDAY;
- payload: evals/run_fixtures.payload_digests() (hub, tuesday and module:<skill>), what a pass record holds;
- inventory: evals/run_fixtures.inventory(), the runner's own harness listing (every pass record holds it);
- deps: sha256 of the manifest's dependency list (section 4), read from DEPS below;
- cases: sha256 of the case files the round reads;
- grader_prompt_sha256: run_fixtures.GRADER_PROMPT_SHA256;
- rooms: per module, each fixture id's research modes (a room per mode), and its declared sentinel kinds;
- e23: the seven external single-mode case files, generated from this tree's case files exactly as the
  build's make_e23.py writes them, with their sha256 and whether each expands to the treatment's
  expectations and prompt (written to --e23-out when given).
"""
import hashlib
import json
import os
import sys
from pathlib import Path

sys.dont_write_bytecode = True
TREE = Path(sys.argv[1]).resolve()
E23_OUT = Path(sys.argv[sys.argv.index("--e23-out") + 1]) if "--e23-out" in sys.argv else None
sys.path[:0] = [str(TREE / "evals"), str(TREE / "ci")]
os.chdir(TREE)
import check_skills  # noqa: E402
import fixture_clauses as fc  # noqa: E402
import run_fixtures as rf  # noqa: E402

for mod in (check_skills, fc, rf):
    assert Path(mod.__file__).resolve().is_relative_to(TREE), mod.__file__

DEPS = ["ci/check_skills.py", "ci/ledger_rules.py", "ci/package.py", "ci/sync.py", "evals/backfill_tools.py",
        "evals/child_env.py", "evals/compare_arms.py", "evals/fixture_clauses.py", "evals/output_checks.py",
        "evals/research_server.py", "evals/routing_variants.py", "evals/run_fixtures.py", "evals/run_routing.py",
        "evals/run_transcripts.py"]
CASES = ["skills/job-underwriter/evals/evals.json", "skills/mock-interview/evals/evals.json",
         "skills/resume-tailor/evals/evals.json", "evals/suite-explicit.json", "evals/suite-routing.json"]
POSITIVES = (("job-underwriter", 7), ("job-underwriter", 8), ("mock-interview", 9), ("mock-interview", 10),
             ("mock-interview", 11), ("mock-interview", 12), ("mock-interview", 13))


def sha_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha(rel: str) -> str | None:
    p = TREE / rel
    return sha_bytes(p.read_bytes()) if p.is_file() else None


def rooms(skill: str) -> dict:
    raw = json.loads((TREE / "skills" / skill / "evals" / "evals.json").read_text(encoding="utf-8"))
    out = {}
    for case in raw["evals"]:
        out[str(case["id"])] = {"modes": rf.modes_of(case),
                                "sentinels": sorted({str(s.get("kind")) for s in case.get("sentinels") or []
                                                     if isinstance(s, dict)})}
    return out


def e23() -> dict:
    out = {}
    for skill, n in POSITIVES:
        src = TREE / "skills" / skill / "evals" / "evals.json"
        data = json.loads(src.read_text(encoding="utf-8"))
        case = next((c for c in data["evals"] if c["id"] == n), None)
        name = f"e23-{skill}-{n}.json"
        if case is None:
            out[name] = None
            continue
        spec = {"skill_name": data["skill_name"], "clauses": data["clauses"], "evals": [case]}
        body = (json.dumps(spec, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
        if E23_OUT is not None:
            E23_OUT.mkdir(parents=True, exist_ok=True)
            (E23_OUT / name).write_bytes(body)
            ext = fc.load_cases(E23_OUT / name)[0]
        else:
            ext = fc.expand_spec(json.loads(body))[0]
        treat = next(c for c in fc.load_cases(src) if c["id"] == n)
        out[name] = {"sha256": sha_bytes(body), "modes": rf.modes_of(case),
                     "expectations": len(ext["expectations"]),
                     "identical": treat["expectations"] == ext["expectations"] and treat["prompt"] == ext["prompt"]}
    return out


values = {"tree": str(TREE),
          "tuesday_digests": check_skills.tuesday_digests(),
          "measured": dict(check_skills.MEASURED_TUESDAY),
          "payload": rf.payload_digests(),
          "inventory": rf.inventory(),
          "deps": {rel: sha(rel) for rel in DEPS},
          "cases": {rel: sha(rel) for rel in CASES},
          "grader_prompt_sha256": rf.GRADER_PROMPT_SHA256,
          "rooms": {skill: rooms(skill) for skill in ("job-underwriter", "mock-interview")},
          "e23": e23()}
print(json.dumps(values, indent=1, sort_keys=True))
