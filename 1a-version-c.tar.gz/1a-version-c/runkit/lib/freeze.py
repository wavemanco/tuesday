"""freeze.py: the checking and copying half of freeze.sh (manifest sections 3-5, 15, 17 and 21, "Freeze").

    freeze.py <expected.json> <baseline tree> <candidate tree> <staging dir> <facts.json>

<facts.json> is what the shell found with git (or by comparing the two folders in the stand-in dry run):
{"candidate_sha", "baseline_sha", "candidate_parent_sha", "candidate_parent_tree", "baseline_tree" (the three are
 null in the stand-in), "name_status": [...], "harness_name_status": [...] or null,
 "untouched_diff": "<the diff text that must be empty>", "cli_version", "host", "uid", "mode"}.

Every value is computed from each pinned tree by that tree's own harness (pin_values.py, one process per
tree) and compared with the expected values. Any mismatch stops the freeze: nothing is copied and the
script exits 1, naming each mismatch. When every check passes, the frozen inputs are written into
<staging dir> (the shell moves it to $M/frozen and makes it read-only):

  cases/baseline/<module>.evals.json, cases/candidate/<module>.evals.json, cases/resume-tailor.evals.json
  e23/e23-<module>-<id>.json          the seven replays, regenerated from the candidate, equal to the build's
  suite-explicit.json                 the explicit panel's cases
  probe/suite-routing.json            the layout probe's case file (case 1)
  scorers/score_item.py               the carried item's scorer
  expect/<model>/<arm>/<part>.json    one --expect file per fixture-runner invocation of every model step
  expect/<model>/e23/<module>-<id>.json
  expect/explicit.json                the explicit panel's digests and case hash, checked on its results
  kit/                                the run kit as it will run (scripts, tools, lib), each file hashed
  baseline-records/                   subsets.json and the re-check report
  manifest.md                         the manifest the round runs under
  freeze.json                         every value computed, the facts, and the hash of every copied file
and the baseline copies into <staging dir>/../baseline-staging and ../checkrun-staging (listing hashes held
to the expected ones).
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
KIT = Path(__file__).resolve().parent.parent
MODELS = {"haiku": "claude-haiku-5-5", "sonnet": "claude-sonnet-5-5", "opus": "claude-opus-5-5"}
ARMS = {"alone": ("skill", "plugin"), "tuesday": ("tuesday", "plugin")}
PARTS = {"ju-existing": "job-underwriter", "ju-new": "job-underwriter", "mi-existing": "mock-interview",
         "mi-new": "mock-interview"}
SETTINGS = {"grader_model": "claude-sonnet-5-5", "graders": 2, "timeout": 900, "retry_runs": 0}
KIT_FILES = ["kit.env", "preflight.sh", "run_step.sh", "tools/meter.py", "tools/save_probe.py",
             "tools/layout_check.py", "tools/guard.sh", "tools/logged.sh", "lib/stop_rule.py", "lib/pin_values.py",
             "lib/dry_runner.py", "lib/preflight_checks.py", "lib/account_email.py"]


def sha_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha_file(p: Path) -> str:
    return sha_bytes(p.read_bytes())


def listing(root: Path) -> tuple[str, int]:
    """sha256 of the sorted 'relative/path sha256' lines of every file under root (the build's formula)."""
    files = sorted(p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file())
    text = "".join(f"{rel} {sha_file(root / rel)}\n" for rel in files)
    return sha_bytes(text.encode("utf-8")), len(files)


def tree_files(root: Path) -> dict[str, Path]:
    return {p.relative_to(root).as_posix(): p for p in root.rglob("*")
            if p.is_file() and ".git" not in p.relative_to(root).parts and "__pycache__" not in p.parts}


def pin_values(tree: Path, e23_out: Path | None = None) -> dict:
    cmd = [sys.executable, "-I", "-B", str(KIT / "lib" / "pin_values.py"), str(tree)]
    if e23_out is not None:
        cmd += ["--e23-out", str(e23_out)]
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    if p.returncode != 0:
        raise SystemExit(f"pin_values failed on {tree}:\n{p.stderr[-3000:]}")
    return json.loads(p.stdout)


class Checks:
    def __init__(self):
        self.lines, self.failed = [], 0

    def eq(self, label: str, got, want) -> bool:
        ok = got == want
        self.failed += not ok
        if ok:
            self.lines.append(f"  ok    {label}")
        else:
            detail = ""
            if isinstance(got, dict) and isinstance(want, dict):
                keys = sorted(k for k in set(got) | set(want) if got.get(k) != want.get(k))
                detail = "; ".join(f"{k}: got {got.get(k)!r}, expected {want.get(k)!r}" for k in keys[:8])
            elif isinstance(got, list) and isinstance(want, list):
                extra, missing = sorted(set(got) - set(want)), sorted(set(want) - set(got))
                detail = f"extra {extra[:8]}, missing {missing[:8]}, {len(got)} against {len(want)}"
            else:
                detail = f"got {got!r}, expected {want!r}"
            self.lines.append(f"  STOP  {label}: {detail}")
        return ok

    def true(self, label: str, cond: bool, why: str = "") -> bool:
        self.failed += not cond
        self.lines.append(f"  {'ok  ' if cond else 'STOP'}  {label}{'' if cond else ': ' + why}")
        return cond


def compare_trees(c: Checks, label: str, tree: Path, build: Path):
    a, b = tree_files(tree), tree_files(build)
    c.eq(f"{label}: the same file list as {build}", sorted(a), sorted(b))
    differ = sorted(rel for rel in set(a) & set(b) if a[rel].read_bytes() != b[rel].read_bytes())
    c.true(f"{label}: every file byte for byte equal to {build}", not differ, f"{len(differ)} differ: {differ[:8]}")


def expect_file(payload: dict, inventory: dict, model: str, via: str, layout: str, cases: dict, cli: str | None,
                note: str) -> dict:
    return {"note": note, "digests": payload, "inventory": inventory,
            "settings": {"model": model, "via": via, "layout": layout, "cases_sha256": cases, **SETTINGS},
            **({"cli_version": cli, "preflight": [cli]} if cli else {})}


def main() -> int:
    expected_path, base, cand, staging, facts_path = (Path(a) for a in sys.argv[1:6])
    exp = json.loads(expected_path.read_text())
    facts = json.loads(facts_path.read_text())
    c = Checks()
    work = staging.parent / (staging.name + ".work")
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    vb = pin_values(base)
    vc = pin_values(cand, work / "e23")

    print("Pins")
    c.lines.append(f"  baseline {facts.get('baseline_sha')} at {base}")
    c.lines.append(f"  candidate {facts.get('candidate_sha')} at {cand}")
    if facts.get("candidate_parent_sha"):
        c.lines.append(f"  candidate's parent {facts['candidate_parent_sha']}, tree {facts.get('candidate_parent_tree')}"
                       f" (the baseline's tree {facts.get('baseline_tree')})")
    print("\n".join(c.lines)); c.lines.clear()

    print("Paths (manifest section 17; plan write boundary)")
    c.eq("candidate: git diff --name-status from the baseline equals the frozen path list",
         sorted(facts["name_status"]), sorted(exp["name_status"]["candidate"]))
    c.true("candidate: every path is a modification (M), nothing created or removed",
           all(line.startswith("M\t") for line in facts["name_status"]), "an A, D, R or other action is listed")
    if facts.get("harness_name_status") is not None:
        c.eq("baseline: git diff --name-status from 8e72375 equals the harness list",
             sorted(facts["harness_name_status"]), sorted(exp["name_status"]["harness"]))
    c.true("candidate: no change to evals/*.py, ci/sync.py, ci/package.py, conventions/ or skills/resume-tailor/",
           not facts.get("untouched_diff"), f"diff of {len(facts.get('untouched_diff', ''))} characters")
    build = exp.get("build") or {}
    if build.get("tree"):
        compare_trees(c, "candidate tree", cand, Path(build["tree"]))
    if build.get("tree_harness"):
        compare_trees(c, "baseline tree", base, Path(build["tree_harness"]))
    print("\n".join(c.lines)); c.lines.clear()

    print("Digests (sections 3 and 4)")
    for pin, v in (("baseline", vb), ("candidate", vc)):
        c.eq(f"{pin}: check_skills.tuesday_digests()", v["tuesday_digests"], exp["digests"][pin])
        c.eq(f"{pin}: run_fixtures.payload_digests() (the --expect digests)", v["payload"], exp["payload"][pin])
        c.eq(f"{pin}: MEASURED_TUESDAY still 0.2.0's", v["measured"], exp["measured"])
        c.eq(f"{pin}: the 14 dependency hashes (import closure, section 4)", v["deps"], exp["deps"])
        c.eq(f"{pin}: the runner's 15-file inventory", v["inventory"], exp["inventory"])
        c.eq(f"{pin}: grader prompt sha256", v["grader_prompt_sha256"], exp["grader_prompt_sha256"])
    print("\n".join(c.lines)); c.lines.clear()

    print("Cases (section 5) and rooms (section 9)")
    for pin, v in (("baseline", vb), ("candidate", vc)):
        c.eq(f"{pin}: case file hashes", v["cases"], exp["cases"][pin])
    c.eq("candidate: rooms (research modes) and declared sentinel kinds per fixture", vc["rooms"],
         exp["rooms"]["candidate"])
    got_e23 = {k: (v or {}).get("sha256") for k, v in vc["e23"].items()}
    if not exp["e23"]:
        # Only the stand-in dry run expects none: its candidate is the baseline, which has no new fixture.
        c.lines.append("  note  E23: the expected values list no replay file (stand-in dry run only)")
        for name in got_e23:
            (work / "e23" / name).unlink(missing_ok=True)
    else:
        c.eq("E23: the seven replay files regenerated from the candidate", got_e23, exp["e23"])
        c.true("E23: each expands to the treatment's expectations and prompt",
               all((v or {}).get("identical") for v in vc["e23"].values()), "a replay differs from its treatment case")
    if build.get("e23") and exp["e23"]:
        differ = [n for n in exp["e23"] if not (work / "e23" / n).is_file() or
                  (work / "e23" / n).read_bytes() != (Path(build["e23"]) / n).read_bytes()]
        c.true(f"E23: byte for byte equal to the build's ({build['e23']})", not differ, f"differ: {differ}")
    print("\n".join(c.lines)); c.lines.clear()

    print("Copies (sections 5, 15 and 22)")
    copies = exp["copies"]
    for name in ("score_item", "subsets", "recheck_report", "manifest"):
        if name not in copies:
            continue
        src = Path(copies[name]["from"])
        if not src.is_file():
            c.true(f"{name}: {src} exists", False, "missing")
            continue
        if copies[name].get("sha256"):
            c.eq(f"{name}: sha256 of {src}", sha_file(src), copies[name]["sha256"])
    for name in ("baseline", "checkrun"):
        src = Path(copies[name]["from"])
        got = listing(src) if src.is_dir() else (None, 0)
        c.eq(f"{name}: listing sha256 and file count of {src}", list(got),
             [copies[name]["listing_sha256"], copies[name]["files"]])
    kit_hashes = {rel: sha_file(KIT / rel) for rel in KIT_FILES}
    print("\n".join(c.lines)); c.lines.clear()

    if c.failed:
        print(f"\nFREEZE STOPPED: {c.failed} mismatch(es). Nothing was copied; stop for the owner.")
        shutil.rmtree(work)
        return 1

    # Every check passed: write the frozen inputs.
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True)
    for pin, tree in (("baseline", base), ("candidate", cand)):
        for skill in ("job-underwriter", "mock-interview"):
            dst = staging / "cases" / pin / f"{skill}.evals.json"
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(tree / "skills" / skill / "evals" / "evals.json", dst)
    shutil.copyfile(cand / "skills/resume-tailor/evals/evals.json", staging / "cases/resume-tailor.evals.json")
    (work / "e23").mkdir(exist_ok=True)
    shutil.move(str(work / "e23"), str(staging / "e23"))
    shutil.copyfile(cand / "evals/suite-explicit.json", staging / "suite-explicit.json")
    (staging / "probe").mkdir()
    shutil.copyfile(cand / "evals/suite-routing.json", staging / "probe/suite-routing.json")
    if "score_item" in copies:
        (staging / "scorers").mkdir()
        shutil.copyfile(copies["score_item"]["from"], staging / "scorers/score_item.py")
    (staging / "baseline-records").mkdir()
    for name, dst in (("subsets", "subsets.json"), ("recheck_report", "recheck-report.json")):
        if name in copies:
            shutil.copyfile(copies[name]["from"], staging / "baseline-records" / dst)
    if "manifest" in copies:
        shutil.copyfile(copies["manifest"]["from"], staging / "manifest.md")
    for rel in KIT_FILES:
        dst = staging / "kit" / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(KIT / rel, dst)

    cli = facts.get("cli_version")
    inv = vc["inventory"]
    n = 0
    for m, model in MODELS.items():
        for arm, (via, layout) in ARMS.items():
            for part, skill in PARTS.items():
                path = staging / "expect" / m / arm / f"{part}.json"
                path.parent.mkdir(parents=True, exist_ok=True)
                body = expect_file(vc["payload"], inv, model, via, layout,
                                   {skill: vc["cases"][f"skills/{skill}/evals/evals.json"]}, cli,
                                   f"round 1a, {m}, {arm}, {part}: candidate {facts.get('candidate_sha')}")
                path.write_text(json.dumps(body, indent=1, sort_keys=True) + "\n")
                n += 1
        for name, h in exp["e23"].items():
            skill = name[len("e23-"):].rsplit("-", 1)[0]
            path = staging / "expect" / m / "e23" / f"{name[len('e23-'):-len('.json')]}.json"
            path.parent.mkdir(parents=True, exist_ok=True)
            body = expect_file(vb["payload"], vb["inventory"], model, "skill", "plugin", {skill: h}, cli,
                               f"round 1a, {m}, E23 replay {name}: baseline {facts.get('baseline_sha')}")
            path.write_text(json.dumps(body, indent=1, sort_keys=True) + "\n")
            n += 1
    explicit = {"note": "round 1a explicit panel: run_routing takes --expect only with --merge, so run_step.sh "
                        "checks each results file against these values after the run",
                "arm": "tuesday", "layout": "plugin", "runs_per_case": 5,
                "hub_sha256": vc["payload"]["hub_sha256"], "tuesday_sha256": vc["payload"]["tuesday_sha256"],
                "cases_sha256": vc["cases"]["evals/suite-explicit.json"],
                "harness_sha256_inventory": inv}
    (staging / "expect" / "explicit.json").write_text(json.dumps(explicit, indent=1, sort_keys=True) + "\n")

    # The baseline copies, beside the staging folder; the shell moves them to $M/baseline and $M/checkrun.
    for name in ("baseline", "checkrun"):
        dst = staging.parent / f"{name}-staging"
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(copies[name]["from"], dst, symlinks=True)
        got = listing(dst)
        if [got[0], got[1]] != [copies[name]["listing_sha256"], copies[name]["files"]]:
            print(f"FREEZE STOPPED: the copy of {name} lists {got}, not the expected value")
            return 1

    record = {"facts": facts, "expected_file": str(expected_path), "expected_sha256": sha_file(expected_path),
              "baseline": vb, "candidate": vc, "kit_sha256": kit_hashes, "expect_files": n + 1,
              "copied": {}}
    for p in sorted(staging.rglob("*")):
        if p.is_file():
            record["copied"][p.relative_to(staging).as_posix()] = sha_file(p)
    (staging / "freeze.json").write_text(json.dumps(record, indent=1, sort_keys=True) + "\n")
    shutil.rmtree(work)
    print(f"\nall checks passed; {len(record['copied'])} files staged ({n + 1} expect files), "
          f"kit files hashed: {len(kit_hashes)}")
    for rel, h in kit_hashes.items():
        print(f"  {h}  kit/{rel}")
    if "manifest" in copies:
        print(f"  {record['copied']['manifest.md']}  manifest.md")
    return 0


if __name__ == "__main__":
    sys.exit(main())
