"""Print the email of the account the CLI is signed in with, for the account-email scan.

    TUESDAY_SCAN_ACCOUNT_EMAIL=$(python3 -I -B lib/account_email.py)

It reads oauthAccount.emailAddress from $HOME/.claude.json (or the file KIT_ACCOUNT_JSON names: the dry run's stand-in), the account whose address the measured sessions can
see (the fix round's baseline runs copied it into a Skill call's arguments). git config user.email is not used: in
this container it holds the commit trailer's no-reply address, not the account's. The value goes only to stdout for
the caller to export; exit 1, printing nothing, if it is missing or not an address.
"""
import json
import os
import sys
from pathlib import Path

try:
    src = Path(os.environ.get("KIT_ACCOUNT_JSON") or Path(os.path.expanduser("~")) / ".claude.json")
    value = json.loads(src.read_text())["oauthAccount"]["emailAddress"]
except (OSError, ValueError, KeyError, TypeError):
    sys.exit(1)
value = (value or "").strip()
if "@" not in value or any(c.isspace() for c in value):
    sys.exit(1)
sys.stdout.write(value)
