"""dry_runner.py <evals/run_fixtures.py | evals/run_routing.py> <the runner's own arguments...>

Runs one step command line through the pinned runner's own main(), from the worktree it is started in, and
stops it at the first thing that would start a session: the fixture runner's execute(), check_run() and
grade(), the routing runner's run_once(), and any subprocess whose program is `claude`, are replaced by
stubs that record the planned work and stop. So the runner itself parses the arguments, loads the cases,
writes its pass record and holds it to --expect, exactly as in the measured step, and nothing is asked of a
model. Run it with `claude` off PATH as well (preflight.sh and the dry runs do).

Prints the runner's own output, then one line `DRY-RUN-RESULT {json}`: accepted (the runner reached its
first session), the planned runs (fixture runner: one per stem; routing runner: cases x runs), and any
refusal the runner printed. Exit 0 when accepted with the planned count DRY_EXPECT_RUNS (when set), 3 when
the runner refused the pass (an --expect mismatch, for instance), 2 on an argument error, 5 when the plan
holds another number of runs, 4 on anything else.
"""
import contextlib
import io
import json
import os
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True


class DryStop(Exception):
    pass


def refuse_cli():
    real = subprocess.Popen

    class Guarded(real):  # type: ignore[misc,valid-type]
        def __init__(self, args, *a, **k):
            prog = args[0] if isinstance(args, (list, tuple)) else str(args).split()[0]
            if Path(str(prog)).name == "claude":
                raise DryStop(f"dry run: refused to start the CLI ({prog})")
            super().__init__(args, *a, **k)
    subprocess.Popen = Guarded


def main() -> int:
    script, args = sys.argv[1], sys.argv[2:]
    wt = Path(script).resolve().parent.parent
    sys.path[:0] = [str(wt / "evals"), str(wt / "ci")]
    refuse_cli()
    planned, result = [], {"script": script, "worktree": str(wt), "argv": args}
    buf = io.StringIO()
    code = None
    if script.endswith("run_fixtures.py"):
        import run_fixtures as rf
        assert Path(rf.__file__).resolve().is_relative_to(wt), rf.__file__

        def execute(skill, case, out, run, timeout, model, mode, via, layout, pass_id=None, **_):
            planned.append(rf.stem_for(skill, case, mode, run))

        def stop(*a, **k):
            raise DryStop("dry run: stopped before the first check or grade")
        rf.execute, rf.check_run, rf.grade = execute, stop, stop
        rf.cli_version = lambda: os.environ.get("DRY_CLI_VERSION") or None
        sys.argv = [script] + args
        try:
            with contextlib.redirect_stdout(buf):
                code = rf.main()
        except DryStop:
            code = "stopped"
        except SystemExit as exc:
            code = exc.code
        except Exception as exc:  # the runner's own error before its first session, reported as such
            code = f"error: {type(exc).__name__}: {exc}"
    elif script.endswith("run_routing.py"):
        import run_routing as rr
        assert Path(rr.__file__).resolve().is_relative_to(wt), rr.__file__
        parsed = rr.parser().parse_args(args)

        def run_once(*a, **k):
            planned.append(k.get("stream_to").name if k.get("stream_to") else "run")
            raise DryStop("dry run: stopped before the first routing session")
        rr.run_once = run_once
        sys.argv = [script] + args
        try:
            with contextlib.redirect_stdout(buf):
                code = rr.main()
        except DryStop:
            code = "stopped"
            planned = [f"case-{c['id']}-{i}" for c in rr.load_cases(parsed.cases, parsed.case)
                       for i in range(parsed.runs)]
        except SystemExit as exc:
            code = exc.code
        except Exception as exc:
            code = f"error: {type(exc).__name__}: {exc}"
    else:
        print(f"dry_runner: {script} is neither runner")
        return 4
    text = buf.getvalue()
    sys.stdout.write(text)
    refused = [line for line in text.splitlines() if line.startswith("refused:")]
    notes = [line for line in text.splitlines() if line.startswith("note:")]
    result.update(accepted=code == "stopped", exit=code, planned_runs=len(planned), refused=refused, notes=notes,
                  rooms=sorted({p.rsplit(".run", 1)[0] for p in planned}) if script.endswith("run_fixtures.py")
                  else None)
    want = os.environ.get("DRY_EXPECT_RUNS")
    if result["accepted"] and want is not None and int(want) != len(planned):
        result["plan_mismatch"] = f"planned {len(planned)} runs, the manifest prices {want}"
    print("DRY-RUN-RESULT " + json.dumps(result, sort_keys=True))
    summary = f"planned {len(planned)} runs" + (f" in {len(result['rooms'])} room(s)" if result["rooms"] else "")
    summary += "".join(f"; {r}" for r in refused) + "".join(f"; {n}" for n in notes)
    summary += f"; {result['plan_mismatch']}" if result.get("plan_mismatch") else ""
    summary += "" if result["accepted"] else f"; not accepted (exit {code})"
    print("DRY-RUN-SUMMARY " + summary)
    if result.get("plan_mismatch"):
        return 5
    if result["accepted"]:
        return 0
    if code == 3 or refused:
        return 3
    if code == 2:
        return 2
    return 4


if __name__ == "__main__":
    sys.exit(main())
