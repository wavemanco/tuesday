import json, re, sys, difflib
B = sys.argv[1]; C = sys.argv[2]
STOP = set("a an the and or of to in on for with by at from as is are was were be been it its this that these those you your yours we our i me my us not no nor but if so than then there their they them he she his her who whom which what when where why how do does did can can't will would should could may might must one any all each".split())
def toks(t):
    t = t.lower().replace("’","'").replace("‘","'").replace("“",'"').replace("”",'"')
    return re.findall(r"[a-z0-9€£]+(?:'[a-z]+)?", t)
def new_lines(path_b, path_c):
    b = open(path_b).read().splitlines(); c = open(path_c).read().splitlines()
    out=[]
    for tag,i1,i2,j1,j2 in difflib.SequenceMatcher(None,b,c).get_opcodes():
        if tag in ('replace','insert'): out += c[j1:j2]
    return "\n".join(out)
files = ["skills/job-underwriter/references/risk-and-decision.md","skills/mock-interview/references/output-template.md"]
new = {f: new_lines(f"{B}/tree/{f}", f"{C}/tree/{f}") for f in files}
for skill in ("job-underwriter","mock-interview"):
    d = json.load(open(f"{C}/tree/skills/{skill}/evals/evals.json"))
    for e in d["evals"]:
        hay = [("prompt", e.get("prompt",""))] + [("exp#%d"%(i+1), x) for i,x in enumerate(e["expectations"])]
        for f,txt in new.items():
            nt = [t for t in toks(txt) if t not in STOP]
            for n in (2,):
                runs = {tuple(nt[i:i+n]) for i in range(len(nt)-n+1)}
                for where, h in hay:
                    ht = [t for t in toks(h) if t not in STOP]
                    hr = {tuple(ht[i:i+n]) for i in range(len(ht)-n+1)}
                    hit = runs & hr
                    if hit and where=="prompt":
                        print(skill, e["id"], where, f.split('/')[-1], sorted(hit)[:6])
