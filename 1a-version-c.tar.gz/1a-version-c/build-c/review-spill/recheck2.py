"""recheck2.py <repo> <src> <out>: re-run <repo>'s run_fixtures.check_run over saved runs in <src>,
writing checks into <out>; links meta/md into out for the call and removes them after. Copy of
fixround/round/recheck/recheck.py, unchanged in logic. No model is called."""
import os, sys
from pathlib import Path
repo, src, out = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve(), Path(sys.argv[3]).resolve()
sys.path.insert(0, str(repo / "evals"))
import run_fixtures as rf  # noqa
from fixture_clauses import load_cases  # noqa
assert Path(rf.__file__).resolve().parent.parent == repo, rf.__file__
out.mkdir(parents=True, exist_ok=True)
n = invalid = 0
for skill in rf.SKILLS:
    for case in load_cases(repo / "skills" / skill / "evals" / "evals.json"):
        for mode in rf.modes_of(case):
            for run in range(50):
                stem = rf.stem_for(skill, case, mode, run)
                if not (src / f"{stem}.meta.json").exists():
                    continue
                links = []
                for suffix in (".meta.json", ".md"):
                    if (src / f"{stem}{suffix}").exists():
                        link = out / f"{stem}{suffix}"
                        if link.is_symlink() or link.exists():
                            link.unlink()
                        os.symlink(src / f"{stem}{suffix}", link)
                        links.append(link)
                try:
                    record = rf.check_run(skill, case, out, run, mode)
                finally:
                    for link in links:
                        link.unlink()
                n += 1
                invalid += record.get("status") == "harness-invalid"
seen = len(list(src.glob("*.meta.json")))
print(f"{src} -> {out}: {n} runs re-checked ({invalid} harness-invalid) of {seen} meta files")
