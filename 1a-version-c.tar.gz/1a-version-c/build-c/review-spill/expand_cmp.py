import json, sys, importlib.util
from pathlib import Path
def load(repo):
    spec = importlib.util.spec_from_file_location("fc_" + str(abs(hash(repo))), Path(repo) / "evals" / "fixture_clauses.py")
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    out = {}
    for s in ["job-underwriter", "mock-interview", "resume-tailor"]:
        for c in m.load_cases(Path(repo) / "skills" / s / "evals" / "evals.json"):
            out[(s, c["id"])] = json.dumps(c, sort_keys=True, ensure_ascii=False)
    return out
a, b, c = load(sys.argv[1]), load(sys.argv[2]), load(sys.argv[3])
for k in sorted(a):
    print(k, "head==B" if a[k] == b.get(k) else "head!=B", "head==C" if a[k] == c.get(k) else "head!=C")
print("new in C:", sorted(set(c) - set(a)))
for k in sorted(set(c) - set(a)):
    if b.get(k) != c[k]:
        cb = json.loads(b[k]); cc = json.loads(c[k])
        diffs = [i+1 for i,(x,y) in enumerate(zip(cb["expectations"], cc["expectations"])) if x != y]
        print(k, "B->C changed expectations:", diffs, "count B", len(cb["expectations"]), "C", len(cc["expectations"]),
              "other keys differ:", [kk for kk in cc if kk!="expectations" and cb.get(kk)!=cc.get(kk)])
