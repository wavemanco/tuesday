"""One-off: turn build-c/build/make_spec.py (variant B's) into version C's. Asserts each anchor occurs once."""
from pathlib import Path
P = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/build-c/build/make_spec.py")
s = P.read_text(encoding="utf-8")


def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:90])
    s = s.replace(old, new, 1)


# ---- docstring, gate rows ---------------------------------------------------------------------------------------
rep('''import_closure.py and run_gates.py write. The prose is this file's.
"""''', '''import_closure.py and run_gates.py write. The prose is this file's.

Version C (build-c/): the owner's decision of 16 November on question 13, built on variant B, on the base 7b56c17,
which already holds phase H; the trees are head/, tree/ and tree-rehearsal/ (no tree-harness/).
"""''')
rep('''for label in ("candidate", "rehearsal", "harness"):
    GATE_ROWS += json.loads(out_text(f"gates-{label}.json"))''',
    '''for label in ("candidate", "rehearsal"):
    GATE_ROWS += json.loads(out_text(f"gates-{label}.json"))''')

# ---- title and opening ------------------------------------------------------------------------------------------
rep('''w("# Round 1a candidate, variant B · build spec\\n")''', '''w("# Round 1a candidate, version C · build spec\\n")''')
rep('''"to scratch copies under this folder, made from `git archive 8e72375`, and checked there''',
    '''"to scratch copies under this folder, made from `git archive 7b56c17`, and checked there''')
i0 = s.index('w("**Variant B.** This build is')
i1 = s.index('w("- **Base:** `/home/user/tuesday`')
s = s[:i0] + '''w("**Version C, the owner's decision of 16 November.** This build is variant B (`l1a/build-b/`, verified) with "
  "the owner's decision on question 13: version C, with a responsibility sentence in each warning and in both "
  "READMEs (section 6.1). The skill text now lets a warning say, hedged, that a request for money (a fee, or paying "
  "for equipment), a cheque deposit, or bank, tax or government-ID details before an offer is likely or very likely "
  "a scam; a weaker sign (a hiring process run wholly by chat, contact off the employer's domain beyond scheduling) "
  "gets the sign and how to check it, with no verdict; no party (the employer, the sender, a named firm, a named "
  "person) is ever called a scam, hedged or not; and every warning carries once a plain sentence that checking who "
  "sent it, through contact details the candidate finds, and deciding whether to go ahead are the candidate's. Both "
  "module READMEs gain one line: the skill flags warning signs but cannot verify an employer, a recruiter or a "
  "sender, and the checks and the decision to go ahead are the reader's. In the fixtures the party bars (JU 8 #6, "
  "MI 10–12 #4) say \\"hedged or not\\"; `request_verdicts` (JU 8 #18, MI 10 #9, MI 11 #6, MI 12 #9, report only) "
  "quotes and classes each verdict on a thing in the place of variant B's `scam_label_count`; `invite_pointer` "
  "(MI 10–12 #3, core) accepts a hedged verdict on such a request where the invite makes one; and "
  "`responsibility_line` (JU 8 #19, MI 10 #10, MI 11 #7, MI 12 #10) and `no_responsibility_line` (JU 9 #17, JU 10 "
  "#17), report only, read the sentence's presence and absence. Both SKILL.md bodies are variant B's byte for byte. "
  "The base is `7b56c17`, `main` after PR #20 was squash-merged: its tree equals variant B's `tree-harness/` "
  "(`8e72375` with phase H) byte for byte, so phase H is already in it and phase C is the one commit "
  "(`out/h-noop.txt`, `out/b-vs-c-paths.txt`).\\n")
''' + s[i1:]
rep('''w("- **Base:** `/home/user/tuesday`, branch `claude/skill-job-underwriter-95xjz8`, HEAD `8e72375` (main plus round "
  "1a's harness, PR #20 open).")''',
    '''w("- **Base:** `git archive 7b56c17` of `/home/user/tuesday`: `main` with round 1a's harness, PR #20 squash-merged. "
  "The branch's HEAD, `5696742`, merges `main` back; its tree equals `7b56c17`'s and the old phase-H commit "
  "`86fce3f`'s. `8e72375`, variant B's base, is `7b56c17` without phase H.")''')
rep('''"spec\\", below).")
w("- **Authority, in order:**''', '''"spec\\", below), then variant B (`l1a/build-b/`) and the owner's decision of 16 November (fix tag VC).")
w("- **Authority, in order:**''')
rep('''including the owner's instruction of 16 November to land 1a before midnight on Wednesday (section 10); that "''',
    '''including the owner's instruction of 16 November to land 1a before midnight on Wednesday (section 10) and the "
  "owner's decision of 16 November on question 13 (version C, with a responsibility sentence in each warning and in "
  "both READMEs); that "''')
rep('''"it, refusing any old text that does not occur exactly once. `build/make_edits.py` writes `edits.json` from the "
  "slice designs and the fixes; `build/rebuild.sh` rebuilds the three scratch trees from a fresh archive of the "
  "base. This spec''', '''"it, refusing any old text that does not occur exactly once. `build/make_edits.py` writes `edits.json` from the "
  "slice designs and the fixes; `build/rebuild.sh` rebuilds the scratch trees (`head/`, `tree/`, `tree-rehearsal/`) "
  "from a fresh archive of the base. This spec''')

# ---- section 0 ---------------------------------------------------------------------------------------------------
rep('''VB_NEW = ("C06a", "C06b", "C27a")      # the edits variant B adds; C08, C27 and C29-C31 change (fix tag VB)
vb_ids = [c for c in cids if c in VB_NEW]
fix_ids = [c for c in cids if not c[1:].isdigit() and c not in VB_NEW]
assert vb_ids == list(VB_NEW), vb_ids
w("Two commits, in this order. Nothing else is written.\\n")
w("1. **Harness follow-up (phase H), on the 1a harness branch (PR #20), below both 1a pins.** Edits H1–H3. Write "
  "boundary row \\"1a harness\\". Then run the four CI steps. The payload is unchanged, so `check_skills.py` passes "
  "whole (the three accepted digests stay equal). PR #20, with this commit on it, is merged before either pin is "
  "taken (section 10).")
w(f"2. **Candidate (phase C), the 1a fixture commit, above the harness follow-up.** Edits {cids[0]}–{cids[-1]} in the "
  f"order `edits.json` lists them ({len(cids)} edits: C01–C40, the {len(fix_ids)} the fixes and the build review "
  f"added, {', '.join(fix_ids)}, and the {len(vb_ids)} variant B adds, {', '.join(vb_ids)}), then "
  f"`python3 ci/sync.py` and `python3 ci/package.py`. "
  "Write boundary row \\"1a candidate\\". The roadmap rewording rides this commit (E3; plan line 225).\\n")
w(block("python3 -I build/apply.py <tree> H      # the harness follow-up\\n"
        "python3 -I build/apply.py <tree> C      # the candidate, then:\\n"
        "python3 ci/sync.py && python3 ci/package.py", "bash"))''',
'''VB_NEW = ("C06a", "C06b", "C27a")      # the edits variant B added (C06b and C27a now add version C's request_verdicts)
VC_NEW = ("C06c", "C06d", "C13a", "C27b", "C35a")   # the edits version C adds
vb_ids = [c for c in cids if c in VB_NEW]
vc_ids = [c for c in cids if c in VC_NEW]
fix_ids = [c for c in cids if not c[1:].isdigit() and c not in VB_NEW + VC_NEW]
vc_changed = [c for c in cids if "VC" in EDITS[c].get("fixes", []) and c not in VC_NEW]
assert vb_ids == list(VB_NEW) and vc_ids == list(VC_NEW), (vb_ids, vc_ids)
assert all("VC" in EDITS[c].get("fixes", []) for c in VC_NEW)
w("One commit. Nothing else is written. The harness follow-up (phase H, edits H1–H3) is already in the base: PR #20 "
  "was squash-merged into `main` as `7b56c17` with it, and `build/h_noop.py` finds each H edit's new text once and "
  "its old text nowhere in a fresh archive of `7b56c17` (`out/h-noop.txt`), so it is not applied again. The base "
  "passes `ci/check_skills.py` whole (`out/base-check_skills.txt`: the three accepted digests equal).\\n")
w(f"1. **Candidate (phase C), the 1a fixture commit, on `7b56c17`.** Edits {cids[0]}–{cids[-1]} in the order "
  f"`edits.json` lists them ({len(cids)} edits: C01–C40; the {len(fix_ids)} the fixes and the build review added, "
  f"{', '.join(fix_ids)}; the {len(vb_ids)} variant B added, {', '.join(vb_ids)}; and the {len(vc_ids)} version C "
  f"adds, {', '.join(vc_ids)}. Version C also changes {', '.join(vc_changed)}; every edit it adds or changes carries "
  f"the fix tag VC), then `python3 ci/sync.py` and `python3 ci/package.py`. "
  "Write boundary row \\"1a candidate\\". The roadmap rewording rides this commit (E3; plan line 225).\\n")
w(block("python3 -I build/apply.py <tree> C      # the candidate, on git archive 7b56c17, then:\\n"
        "python3 ci/sync.py && python3 ci/package.py", "bash"))''')

# ---- review K5, changes C2 and VB, the new VC entry --------------------------------------------------------------
rep('''"widening of plan line 398. Variant B keeps this in JU 9 and 10; in the warning-sign cases it counts \\"this "
     "request is a scam\\" apart, report only, so there the bar is looser than the skill's rule (VB)."),''',
    '''"widening of plan line 398. Variant B keeps this in JU 9 and 10; in the warning-sign cases it counts \\"this "
     "request is a scam\\" apart, report only, so there the bar is looser than the skill's rule (VB). Version C "
     "makes rule and bar agree again: the skill text may call such a request likely a scam, hedged, never a party, "
     "and the warning-sign cases' bar counts only a party (VC)."),''')
rep('''"for its approval. Variant B narrows it in the warning-sign cases (VB)."),''',
    '''"for its approval. Variant B narrows it in the warning-sign cases (VB); version C keeps that reading, says "
           "\\"hedged or not\\" for a party, and classes a verdict on a thing alone apart (VC)."),''')
rep('''"is not left to an adversarial grader to read as a verdict on the employer."),''',
    '''"is not left to an adversarial grader to read as a verdict on the employer. Version C keeps the party bar and "
           "replaces `scam_label_count` with `request_verdicts` (VC)."),
    ("VC", "Version C, the owner's decision of 16 November on question 13, built on variant B. Skill text, reference "
           "text only (neither SKILL.md body changes): risk-and-decision.md's \\"About the request, not the firm\\" "
           "lets the entry say, hedged and never as a certainty, that a request for money (a fee, or paying for "
           "equipment), a cheque deposit, or bank, tax or government-ID details before an offer is likely or very "
           "likely a scam, beside its quote and its hold; gives a weaker sign (a hiring process run wholly by chat, "
           "contact off the employer's domain beyond scheduling) what it shows and how to check it, with no verdict; "
           "never calls the employer, the sender, a named firm or a named person a scam, a fraud, fake or criminal, "
           "or says it may be one, hedged or not; and answers \\"is this job legit?\\" with what it asks, the hedged "
           "verdict where the request is one of those, the hold, and that the firm cannot be established from here. "
           "A sixth rule, \\"The check and the decision are the candidate's\\", puts once, in one entry about such a "
           "request, the plain sentence \\"Checking who sent it, through contact details you find yourself, and "
           "deciding whether to go ahead are yours.\\": no label, never the watch-out line, no part of the closing "
           "run, and absent with no such entry. The template's invite bullets say the same for the invite paragraph, "
           "and both its examples carry the sentence; the funder example adds \\"these two are very likely a scam\\". "
           "Both module READMEs gain one line after the privacy paragraph. Fixtures: the party bars say \\"hedged or "
           "not\\" and leave a verdict on a thing alone to `request_verdicts`, report only, which replaces "
           "`scam_label_count` at the same numbers and classes each verdict as hedged on such a request, flat or "
           "overreach, each case naming which requests its material holds; `invite_pointer` accepts a hedged verdict "
           "on such a request, and MI 10–12 #3 say whether the invite makes one; `responsibility_line` (appended to "
           "the four warning-sign cases) and `no_responsibility_line` (appended to JU 9 and 10) read the sentence, "
           "report only. Row 17, `no_accusation`, JU 11 and every core screen but #3's reading are variant B's. "
           "Section 6.1 and owner question 13, now a recorded decision, say what each statement scores."),''')
rep('''then rebuilt from a fresh archive of `8e72375`. The edit ids each fix touched are in "
  "brackets; section 3 prints the texts.\\n")''', '''then rebuilt from a fresh archive of the base (`8e72375` for variants A and B; `7b56c17`, which equals it "
  "with phase H, for version C). The edit ids each fix touched are in brackets; section 3 prints the texts.\\n")''')

# ---- summary table ------------------------------------------------------------------------------------------------
rep('''w("| Source files, harness follow-up | 3, every one in the \\"1a harness\\" row: `evals/test_harness.py`, "
  "`ci/test_checks.py`, `evals/README.md` |")''',
    '''w("| Harness follow-up | Already in the base: `7b56c17` holds phase H (`evals/test_harness.py`, `ci/test_checks.py`, "
  "`evals/README.md`; `out/h-noop.txt`), so it is not applied again |")''')
rep('''w("| New fixtures | job-underwriter 7–11 (5), mock-interview 9–13 (5): eleven new treatment rooms. Seven new "
  "clauses: variant A's four, and variant B's `no_party_accusation` and a `scam_label_count` in each module |")
w("| Variant B against variant A | The two `evals.json` files only (`out/a-vs-b.name-status`): JU 8 #6 grades "
  "`no_party_accusation` in place of `no_accusation`, `no_fraud_claim` is rewritten, and JU 8 #18, MI 10 #9, MI 11 #6 "
  "and MI 12 #9 are appended (`scam_label_count`, report only); every other expectation, field and fixture expands "
  "byte for byte as in variant A (`out/lint-fixtures.txt`). Digests, bodies and the path list are variant A's |")''',
    '''b_vs_c = out_text("b-vs-c-paths.txt")
n_bc = int(re.search(r"^## tree/ \\(candidate\\): (\\d+)$", b_vs_c, re.M).group(1))
w("| New fixtures | job-underwriter 7–11 (5), mock-interview 9–13 (5): eleven new treatment rooms. Ten new "
  "clauses: variant A's four; variant B's `no_party_accusation`; version C's `request_verdicts` and "
  "`responsibility_line` in each module and `no_responsibility_line` in job-underwriter's |")
w(f"| Version C against variant B | {n_bc} paths of the candidate tree (`out/b-vs-c-paths.txt`): "
  "`risk-and-decision.md`, `output-template.md`, both module READMEs and both `evals.json` files, and their generated "
  "copies (two Tuesday references and the `dist/` copies). In the fixtures JU 8 #6 and #18 and MI 10–12 #3, #4 and "
  "the last are rewritten, JU 8 #19, JU 9 #17, JU 10 #17, MI 10 #10, MI 11 #7 and MI 12 #10 are appended, and "
  "`scam_label_count` is gone; every other expectation, field and fixture, JU 11 included, expands byte for byte as "
  "in variant B (`out/lint-fixtures.txt`). Both SKILL.md bodies are variant B's |")''')
rep('''for tree, label in (("candidate", "candidate tree"), ("record rehearsal", "record rehearsal"),
                    ("harness follow-up alone", "harness follow-up alone")):''',
    '''for tree, label in (("candidate", "candidate tree"), ("record rehearsal", "record rehearsal")):''')
rep('''w("| Owner questions | @@NQ@@, in section 11, each with a recommendation; 13 and 14 came with the accepted fixes, and "
  "3, 4, 8, 10, 13 and 14 carry the build review's findings; 13 is rewritten for variant B |")''',
    '''w("| Owner questions | @@NQ@@, in section 11, each with a recommendation but 13, now the owner's recorded decision of 16 "
  "November (version C, with a responsibility sentence in each warning and in both READMEs); 13 and 14 came with the "
  "accepted fixes, and 3, 4, 8, 10, 13 and 14 carry the build review's findings |")''')

# ---- section 2 row 11, section 3 intro -----------------------------------------------------------------------------
rep('''     "Distinct names: `no_accusation`, then variant B's `no_party_accusation` and `scam_label_count`, appended to "
     "job-underwriter's; `invite_opening`, `invite_pointer`, `no_fraud_claim` and variant B's `scam_label_count` "
     "after `co_grounded` in mock-interview's."),''',
    '''     "Distinct names: `no_accusation`, then variant B's `no_party_accusation` and version C's `request_verdicts`, "
     "`responsibility_line` and `no_responsibility_line`, appended to job-underwriter's; `invite_opening`, "
     "`invite_pointer`, `no_fraud_claim` and version C's `request_verdicts` and `responsibility_line` after "
     "`co_grounded` in mock-interview's."),''')
rep('''w("Each old text was copied from the file at `8e72375` and occurs exactly once (asserted by `apply.py`). Fixture "
  "objects are printed in Appendix A.\\n")''',
    '''w("Each old text was copied from the file at `8e72375`, whose candidate files are byte-identical at `7b56c17`, and "
  "occurs exactly once (asserted by `apply.py`). Phase H is printed as the record of what the base holds; it is not "
  "applied. Fixture objects are printed in Appendix A.\\n")''')
P.write_text(s, encoding="utf-8")
print("ok part 1")
