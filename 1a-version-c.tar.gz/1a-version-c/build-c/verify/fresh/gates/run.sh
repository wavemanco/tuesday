#!/bin/bash
# run.sh TREE LABEL STEP...: run CI steps offline, claude off PATH, no bytecode; one log per step.
export PYTHONDONTWRITEBYTECODE=1
T=$1; L=$2; shift 2
D=$(dirname "$0")
NEWPATH=""
IFS=: read -ra parts <<< "$PATH"
for p in "${parts[@]}"; do [ -e "$p/claude" ] || NEWPATH="${NEWPATH:+$NEWPATH:}$p"; done
export PATH="$NEWPATH"
command -v claude && { echo "claude still on PATH"; exit 9; }
cd "$T" || exit 9
for s in "$@"; do
  case $s in
    check_skills) cmd=(python3 ci/check_skills.py);;
    sync-check) cmd=(python3 ci/sync.py --check);;
    test_checks) cmd=(python3 ci/test_checks.py);;
    test_harness) cmd=(python3 evals/test_harness.py);;
  esac
  t0=$(date +%s); "${cmd[@]}" > "$D/$L-$s.txt" 2>&1; rc=$?
  echo "$L $s exit $rc ($(( $(date +%s) - t0 ))s)" >> "$D/$L-summary.txt"
done
find "$T" -name __pycache__ -type d -prune -exec rm -rf {} +
echo "$L done" >> "$D/$L-summary.txt"
