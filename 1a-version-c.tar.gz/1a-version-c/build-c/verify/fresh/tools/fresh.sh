#!/bin/bash
# fresh.sh: the final verification of version C from fresh archives, without the build's own scripts.
#   cand/  git archive 7b56c17 with patches/C-c.patch applied by git apply --binary; must equal ../../tree
#   src/   git archive 7b56c17 with only the 11 source paths copied in, then ci/sync.py and ci/package.py; must
#          equal ../../tree (so the 37 generated paths are exactly what the two scripts write)
#   reh/   cand with MEASURED_TUESDAY set to cand's own tuesday_digests() and 0.3.0, then ci/package.py; must
#          equal ../../tree-rehearsal
#   ns/    git diff --name-status between the base and cand in a scratch index; must equal patches/C-c.name-status
#   e23-regen/  the seven E23 files regenerated from cand by the run kit's lib/pin_values.py; must equal ../../e23
#   unz/   the four .skill archives of cand, unzipped (for the scan)
#   bodies.json, digests-cand.json, modes-cand.txt, modes-tree.txt
# Gates run separately (gates/run.sh). Nothing in the repository is written; claude is kept off PATH.
set -euo pipefail
V=$(cd "$(dirname "$0")/.." && pwd); B=$(cd "$V/../.." && pwd); K=$(cd "$B/../runkit" && pwd)
REPO=/home/user/tuesday; BASE=7b56c17
export PYTHONDONTWRITEBYTECODE=1
export PATH=$(python3 -I -c 'import os; print(":".join(d for d in os.environ["PATH"].split(":") if d and not os.access(os.path.join(d,"claude"), os.X_OK)))')
command -v claude >/dev/null && { echo "claude on PATH"; exit 9; }
cd "$V"
rm -rf cand src reh ns e23-regen unz standin bodies.json digests-cand.json modes-cand.txt modes-tree.txt \
       pin-values-base.json pin-values-cand.json src-sync.txt src-package.txt reh-package.txt compare.txt
same() {  # same <a> <b> <label>: file list, bytes and executable bits
  python3 -I -B - "$1" "$2" "$3" <<'PY' | tee -a "$V/compare.txt"
import os, sys
from pathlib import Path
a, b, label = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
def files(r): return {p.relative_to(r).as_posix(): p for p in r.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
fa, fb = files(a), files(b)
bad = sorted(set(fa) ^ set(fb)) + [k for k in sorted(set(fa) & set(fb)) if fa[k].read_bytes() != fb[k].read_bytes()
                                    or bool(os.stat(fa[k]).st_mode & 0o111) != bool(os.stat(fb[k]).st_mode & 0o111)]
ex = sum(bool(os.stat(p).st_mode & 0o111) for p in fa.values())
print(f"{label}: {'equal' if not bad else 'DIFFERENT'}, {len(fa)} files, {ex} executable" + (f"; differing {bad[:8]}" if bad else ""))
sys.exit(1 if bad else 0)
PY
}
mkdir cand; git -C "$REPO" archive "$BASE" | tar -x -C cand
(cd cand && git apply --binary "$B/patches/C-c.patch")
same cand "$B/tree" "cand (fresh archive + git apply of patches/C-c.patch) against build-c/tree"
mkdir src; git -C "$REPO" archive "$BASE" | tar -x -C src
SRC_PATHS="docs/roadmap.html skills/job-underwriter/README.md skills/job-underwriter/SKILL.md
  skills/job-underwriter/evals/evals.json skills/job-underwriter/references/risk-and-decision.md
  skills/mock-interview/README.md skills/mock-interview/SKILL.md skills/mock-interview/evals/evals.json
  skills/mock-interview/references/output-template.md skills/mock-interview/references/personas.md
  skills/mock-interview/references/question-rubric.md"
n=0; for p in $SRC_PATHS; do cp "cand/$p" "src/$p"; n=$((n+1)); done; echo "src: $n source paths copied" | tee -a compare.txt
(cd src && python3 ci/sync.py > "$V/src-sync.txt" && python3 ci/package.py > "$V/src-package.txt")
same src "$B/tree" "src (fresh archive + the 11 source paths, then ci/sync.py and ci/package.py) against build-c/tree"
cp -a cand reh
python3 -I -B - "$V/cand" "$V/reh" "$V/digests-cand.json" <<'PY'
import importlib.util, json, re, sys
from pathlib import Path
cand, reh, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
sys.path.insert(0, str(cand / "ci"))
spec = importlib.util.spec_from_file_location("cs_fresh", cand / "ci" / "check_skills.py")
cs = importlib.util.module_from_spec(spec); spec.loader.exec_module(cs)
d = cs.tuesday_digests()
out.write_text(json.dumps(d, sort_keys=True) + "\n")
p = reh / "ci" / "check_skills.py"; t = p.read_text(encoding="utf-8")
m = re.search(r"^MEASURED_TUESDAY = \{\n(.*?)\n\}$", t, re.S | re.M); body = m.group(1)
for k in ("hub_sha256", "tuesday_sha256", "builds_sha256"):
    body, n = re.subn(rf'("{k}": )"[0-9a-f]{{64}}"', lambda mm: f'{mm.group(1)}"{d[k]}"', body); assert n == 1, k
body, n = re.subn(r'("plugin_version": )"[0-9.]+"', r'\1"0.3.0"', body); assert n == 1
p.write_text(t[:m.start(1)] + body + t[m.end(1):], encoding="utf-8")
print("reh: MEASURED_TUESDAY set to cand's digests", json.dumps(d, sort_keys=True), "and 0.3.0")
PY
(cd reh && python3 ci/package.py > "$V/reh-package.txt")
same reh "$B/tree-rehearsal" "reh (cand + its own digests in MEASURED_TUESDAY, 0.3.0, ci/package.py) against build-c/tree-rehearsal"
mkdir -p ns/g; git -C ns/g init -q .
git -C "$REPO" archive "$BASE" | tar -x -C ns/g; git -C ns/g add -A
find ns/g -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf {} +; cp -a "$V/cand/." ns/g/
git -C ns/g add -A -N; git -C ns/g diff --name-status > ns/computed.name-status; rm -rf ns/g
cmp ns/computed.name-status "$B/patches/C-c.name-status" && echo "ns: git diff --name-status base..cand equals patches/C-c.name-status ($(wc -l < ns/computed.name-status) paths, $(cut -f1 ns/computed.name-status | sort -u | tr '\n' ' '))" | tee -a compare.txt
python3 -I -B "$K/lib/pin_values.py" "$V/cand" --e23-out "$V/e23-regen" > pin-values-cand.json
python3 -I -B "$K/lib/pin_values.py" "$B/head" > pin-values-base.json
same e23-regen "$B/e23" "e23-regen (the seven E23 files regenerated from cand by the kit's pin_values.py) against build-c/e23"
python3 -I -B - pin-values-cand.json <<'PY' | tee -a compare.txt
import json, sys
v = json.load(open(sys.argv[1]))["e23"]
print("e23-regen: " + "; ".join(f"{k} identical={x['identical']}" for k, x in sorted(v.items())))
assert all(x["identical"] for x in v.values())
PY
mkdir unz; for f in cand/dist/*.skill; do n=$(basename "$f" .skill); mkdir -p "unz/$n"; (cd "unz/$n" && python3 -I -B -c 'import zipfile,sys; zipfile.ZipFile(sys.argv[1]).extractall(".")' "$V/$f"); done
echo "unz: $(find unz -type f | wc -l) members of $(ls cand/dist/*.skill | wc -l) archives" | tee -a compare.txt
python3 -I -B - "$V/cand" "$V/bodies.json" <<'PY'
import importlib.util, json, sys
from pathlib import Path
t, out = Path(sys.argv[1]), Path(sys.argv[2])
sys.path.insert(0, str(t / "ci"))
spec = importlib.util.spec_from_file_location("cs_bodies", t / "ci" / "check_skills.py")
cs = importlib.util.module_from_spec(spec); spec.loader.exec_module(cs)
d = {s: len(cs.skill_body((t / "skills" / s / "SKILL.md").read_text(encoding="utf-8")))
     for s in ("job-underwriter", "mock-interview", "resume-tailor", "tuesday")}
out.write_text(json.dumps(d) + "\n"); print("bodies:", d)
PY
gitmodes() {  # the mode git records for each file: 100755 if any executable bit is set, else 100644
  python3 -I -B -c 'import os,sys; from pathlib import Path; r=Path(sys.argv[1])
for p in sorted(x for x in r.rglob("*") if x.is_file() and "__pycache__" not in x.parts):
    print("100755" if os.stat(p).st_mode & 0o111 else "100644", p.relative_to(r).as_posix())' "$1"; }
gitmodes cand > modes-cand.txt; gitmodes "$B/tree" > modes-tree.txt
cmp modes-cand.txt modes-tree.txt && echo "modes: cand and build-c/tree record the same git mode for every file ($(cut -d' ' -f1 modes-cand.txt | sort | uniq -c | tr -s ' ' | tr '\n' ' '))" | tee -a compare.txt
find "$V" "$B/head" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null || true
echo "fresh verification done"
