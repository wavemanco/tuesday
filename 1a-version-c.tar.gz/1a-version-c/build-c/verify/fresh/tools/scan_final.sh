#!/bin/bash
# scan_final.sh [pre|post]: the account-email, key-shaped, home-path and root-folder scan of version C, counts only.
#   pre   before finish_manifest.py: the labels it reads (patch, archives, trees, fresh trees, expect-c)
#   post  after it: the spec, manifest and owner summary, the generators and the whole run kit, appended
# The address is read from git config into the environment of tools/scan.py, never printed or written.
set -euo pipefail
V=$(cd "$(dirname "$0")/.." && pwd); B=$(cd "$V/../.." && pwd); K=$(cd "$B/../runkit" && pwd)
SCAN_EMAIL=$(git -C /home/user/tuesday config user.email); export SCAN_EMAIL
s() { python3 -I -B "$V/tools/scan.py" "$@"; }
if [ "${1:-pre}" = pre ]; then
  {
    s patch "$B/patches/C-c.patch" "$B/patches/C-c.name-status"
    s archives-decompressed "$V/unz"
    s candidate-tree "$B/tree"
    s rehearsal-tree "$B/tree-rehearsal"
    s fresh-trees "$V/cand" "$V/src" "$V/reh"
    s expect-c "$K/expect-c.json"
  } > "$V/scan.txt"
else
  {
    s manifest-summary-spec "$B/spec.md" "$B/manifest.md" "$B/owner-summary.md"
    s scripts-written "$B/build" "$B/verify/tools" "$V/tools" "$B/verify/owner-wording"
    s run-kit "$K"
  } >> "$V/scan.txt"
fi
unset SCAN_EMAIL
cat "$V/scan.txt"
