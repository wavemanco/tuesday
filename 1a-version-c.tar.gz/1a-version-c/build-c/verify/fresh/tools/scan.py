"""scan.py LABEL ROOT...: count the account email (from SCAN_EMAIL, never printed), key-shaped strings, and home paths
other than /home/user in every file under the roots. Zip archives (.skill, .zip) are read member by member, decompressed.
Prints counts only, and for key/home hits the file and pattern name (never the email)."""
import io, os, re, sys, zipfile
from pathlib import Path
email = os.environ.get("SCAN_EMAIL", "").strip().lower()
assert email and "@" in email, "SCAN_EMAIL empty"
variants = {email, email.replace("@", "%40"), email.replace("@", " at ")}
KEYS = {"anthropic/openai sk-": r"(?<![A-Za-z0-9])sk-(?:ant-)?[A-Za-z0-9_-]{16,}",
        "github token": r"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})",
        "aws key id": r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b", "private key": r"-----BEGIN [A-Z ]*PRIVATE KEY",
        "slack token": r"\bxox[abposr]-[A-Za-z0-9-]{10,}", "google api key": r"\bAIza[0-9A-Za-z_-]{35}\b",
        "bearer literal": r"(?i)authorization:\s*bearer\s+[A-Za-z0-9._-]{20,}",
        "jwt": r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"}
KEYS = {k: re.compile(v) for k, v in KEYS.items()}
HOME = {"/home/<other>": re.compile(r"/home/(?!user(?:/|\b))[A-Za-z0-9._-]+"), "/Users/<name>": re.compile(r"/Users/[A-Za-z0-9._-]+"),
        "C:\\Users": re.compile(r"(?i)[A-Z]:\\\\?Users\\\\?[A-Za-z0-9._-]+"),
        "root-folder": re.compile(r"(?<![A-Za-z0-9_.-])/ro" r"ot/")}   # split, so this file holds no such path itself
label, roots = sys.argv[1], [Path(r) for r in sys.argv[2:]]
files = [p for r in roots for p in ([r] if r.is_file() else sorted(r.rglob("*"))) if p.is_file() and "__pycache__" not in p.parts]
n = {"email": 0, "key": 0, "home": 0, "root": 0, "texts": 0, "zip_members": 0}
hits = []
def scan(name, b):
    n["texts"] += 1
    t = b.decode("utf-8", "replace"); tl = t.lower()
    n["email"] += sum(tl.count(v) for v in variants)
    for k, rx in KEYS.items():
        c = len(rx.findall(t))
        if c: n["key"] += c; hits.append(f"  key {k}: {c} in {name}")
    for k, rx in HOME.items():
        c = len(rx.findall(t))
        if c:
            n["root" if k == "root-folder" else "home"] += c; hits.append(f"  {k}: {c} in {name}")
def walk(name, b, depth=0):
    if depth < 3 and b[:4] == b"PK\x03\x04":
        with zipfile.ZipFile(io.BytesIO(b)) as z:
            for m in z.namelist():
                n["zip_members"] += 1; walk(f"{name}!{m}", z.read(m), depth + 1)
    else:
        scan(name, b)
for p in files:
    walk(str(p), p.read_bytes())
print(f"{label}: account email {n['email']} | key-shaped {n['key']} | home paths other than /home/user {n['home']} | "
      f"root-folder paths {n['root']} | {len(files)} files, {n['zip_members']} zip members, {n['texts']} texts")
for h in hits[:40]: print(h)
