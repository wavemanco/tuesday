# Round 1a: what you are approving on Tuesday

Nothing has been measured yet. The full manifest, with every frozen value, is `manifest.md` beside this file.

**What changes for a user**
- **Licences and IDs:** a professional licence or registration counts as evidence at the level stated; passport, licence-card, national ID, tax and social-security numbers are declined, never repeated or looked up.
- **Warning signs in a posting:** job-underwriter quotes a request to pay, deposit a cheque, hand over bank, tax or ID details before an offer, or do all hiring by chat, says no-go and what to hold; it may say, hedged, that a request for money, a cheque or those details is likely a scam, never the firm, the sender or a person, and each warning says once, in your final wording, "I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call." Routine onboarding, chat scheduling and small genuine employers are left alone.
- **Warning signs in an interview invite:** mock-interview opens with one quoted warning and one pointer to job-underwriter, then the normal prep; with no company or role it warns and asks for them instead. The warning follows the same verdict rule and carries the same sentence.
- **Both module READMEs**, in your final wording: "It's an AI assistant and can make mistakes. It points out warning signs in what you share, but it can't confirm who an employer, recruiter or sender really is. Please check before you act; the decision is always yours."
- **Recruiter screens:** pay, notice, location and reason-for-leaving answers come from your own figures; a missing figure is an instruction, never a blank; a salary you stated is not coached as a number to defend.
- **The sentence after the fit ledger:** the rule now quotes the one-sentence form to write (Opus's second try).

**Price** (dollars are API-price equivalents; a point is one point of the weekly meter)

| Step | Dollars | Planning points | Observed-rate points |
|---|---:|---:|---:|
| Haiku / Sonnet / Opus | $58 / $263 / $420 | 2.8–3.4 / 12.5–15.5 / 14.5–17.5 | 8.0 / 13.9 / 36.9 |
| Explicit-command check | $26 | 1.0–1.3 | 2.1 |
| Preflight, scoring, report | — | 3–5.5 | 3–5.5 |
| **This week** | **$768** | **34–43** | **64–66** |
| Interview-driver smoke, after the reset | $21–44 | 0.8–2.2 | 1.7–3.5 |

The direct analog is the fix round: its quality steps cost $812 and its own runs used about 35–38 points at planning rates (the meter moved 65, with other use on the account). Its scoring and verification took about 22 points against 3–5 planned, so expect scoring to cost more than its allowance.

**Step order.** A step starts only at a meter reading of 80% or less and if its high planning estimate keeps the meter at 90% or less; a guard stops it at 95%.
1. Done: the harness pull request is merged, with its follow-up, as `7b56c17`. Then the candidate commit, rehearsal, freeze. No model calls.
2. Preflight: starts at 80% or less.
3. Haiku: 80% or less.
4. Sonnet: 74.5% or less.
5. Explicit-command check: 80% or less, not on a Friday.
6. Opus: 72.5% or less.
7. Scoring, the grade-gap report and the adjudications for your review, then the 0.3.0 record. Starts no runs.

Every measured step can start this week if the reading before preflight is 46.8% or less (43.0% at observed rates); scoring is the exception, in decision 3. The last reading was 44% at 19:45 UTC on Monday, after the build, its reviews and the second accusation version; please read it on Tuesday morning.

**By Wednesday midnight:** the harness pull request on main, the candidate pinned and pushed, all three models, the explicit check and the baseline replays measured and scored, the adjudications in front of you, and, if the bar is met and you accept, the 0.3.0 release record.
**What pushes it to Thursday:** a reading above about 47% before preflight (Opus waits for the reset); observed-rate costs (from 40%, the guard would stop Opus at 95% about 69% of the way through); a usage-limit kill or restart; heavier scoring; a preflight failure or a new CLI; any path or digest mismatch at the pins; your review not done on Wednesday. A gated miss means no release, and the evidence comes to you.

**Decisions** (recommendation first)
1. Approve this manifest and start this week, with the driver smoke after the reset: it is the plan's 1a price, and every meter rule stays.
2. Done: the harness pull request was merged with its three-file follow-up before either pin.
3. Meter for Wednesday: a reset or extra usage on Tuesday morning (recommended), else let scoring start above 80% if it stays at or under 90%, else score after Thursday's reset and land Thursday. Why: from about 44% before preflight, Opus can start this week, but lean scoring (the scorer and the adjudications only, about 3–5 points) would start at about 80–84%; the fix round's scoring took 22 points because of review agents, which 1a's scoring skips.
4. Accept the false-miss rates, 1a 19% nominal (17–23%) and 43% pessimistic (41–46%); 1b 10% / 30%; Round 2 26–27% / 57–58%: a false miss costs a decision, not a rerun.
5. Keep seven core screens, with routine onboarding and the small employer as zero-event gates: it matches the plan's price and estimate.
6. Recorded, your decision of 16 November: version C, with a responsibility sentence in each warning and in both READMEs. In the warning-sign cases only a statement that calls a firm, the sender or a person a scam, hedged or not, fails the release ("Lumenvale is probably a fake company"); a hedged verdict on the request ("This request is very likely a scam. Don't deposit the cheque.") is what the skill may say, and every verdict on a thing is quoted and classed, report only. In the two genuine-employer cases any scam talk still fails.
7. Count a planted value leaked in a dropped or killed session: the leak happened, and counting costs no runs.
8. Approve the quotation adjudication rule: a fixed word-for-word rubric, and you can overturn any call.
9. Score a core screen with dropped runs on misses over finished runs: the plan already does this for routing.
10. Gate the new cases' closing watch-out line on the standing bars: luck alone would miss it under 2% of the time.
11. Freeze the first five usable saved runs per baseline cell: applied before any score was read.
12. Accept job-underwriter's size trade, the licence rule paid for by a shorter dossier bullet: nothing tested reads the cut words.
13. Approve the no-pack turn when company or role is missing: otherwise the anonymous invite would be asked for a pack.
14. Approve the pointer rule in both the template and the instructions: saved Opus packs name job-underwriter in the upgrade menu in 69% of runs with the module alone.
15. Score the recruiter screen's three outcomes as one screen, older recruiter round report-only: its inputs cannot change.
16. Accept medium or high confidence for a stated registration and report the split: both readings are defensible.
17. Accept the renamed invented names, and search the nursing register once for the invented PIN: it cannot be cleared offline.
18. Replay the seven new cases on the baseline's module-alone install: one arm for all seven.
19. Record unmeasured items as open in the 0.3.0 record, and fix the plan's table in its own commit: the record may not touch the plan.
20. Approve a scanned, masked data-branch backup after each model step: the plan needs your approval for each.
21. Report resampled regression power in the record: it changes no threshold.
22. Keep the fix round's ten-run interview runs as 1b's no-change pool: 1a's five-run cells would make that estimate degenerate.
23. Confirm four readings of your 16 November decision: the verdict is the request's alone ("This job is very likely a scam" fails the fee-and-cheque invite's core check, "This is very likely a scam. Don't deposit the cheque." passes); "probably" counts as hedged and "almost certainly" as flat; "is it legit?" says the firm cannot be established only where research has not established it, so the small employer's official pages still clear it; off-domain contact is no invite sign in mock-interview. Each follows your words or keeps a plan bar you did not change.
24. Add the limits line to the top-level README in the 0.3.0 record and to the Tuesday README in Round 2: hub users see the in-warning sentence but neither module README, and 1a's write boundary covers neither file.
