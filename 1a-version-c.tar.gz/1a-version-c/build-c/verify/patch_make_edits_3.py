from pathlib import Path
P = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/build-c/build/make_edits.py")
s = P.read_text(encoding="utf-8")


def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:80])
    s = s.replace(old, new, 1)


# ---- risk-and-decision.md (C03) -----------------------------------------------------------------------------
rep('''text("C03", f, o, n, "item3 Edit 1 (C1, C3, C7; review K5, K9, K10)",
     "Requests table and its five rules, end of Detectable patterns.", fixes=["C1", "C3", "C7", "K5", "K9", "K10"])''',
'''# Version C (VC): a hedged verdict on a request for money, a cheque deposit, or bank, tax or ID details before an
# offer; no verdict on a weaker sign; no party called a scam, hedged or not; the "legit?" answer adds the hedged
# verdict and that the firm cannot be established from here; and a sixth rule, the responsibility sentence.
n = patch(n, "The entry says what the material asks and why that is a sign. Who sent it, and whether the named "
             "employer is involved, stays unproven: never call " + FIRM + " (a supplier or jobs site among them), the "
             "posting or offer, or the message or a request it makes a scam, a fraud, fake or criminal, or say or "
             "suggest it may be one. Saying that requests like this are a known scam pattern is fine, as are a "
             "verification question and saying that the message may not come from who it names. Asked whether a job "
             "is legit, answer with what it asks and the hold, never with a verdict on the firm: \\"I can't establish "
             "that it is; what it asks of you is a known scam pattern, so send and pay nothing yet.\\" Describe the "
             "request in its own words, with no outside statistics.",
          "The entry says what the material asks and why that is a sign. Where it asks for " + VC_REQUESTS + ", the "
          "entry may also say, hedged and never as a certainty, that the request is likely or very likely a scam, "
          "beside its quote and its hold: \\"This request is very likely a scam. Don't deposit the cheque.\\" A weaker "
          "sign, a hiring process run wholly by chat or contact off the employer's domain beyond scheduling, gets what "
          "it shows and how to check it, and no verdict, hedged or not. Who sent it, and whether the named employer is "
          "involved, stays unproven: never call " + FIRM + " (a supplier or jobs site among them) or a named person a "
          "scam, a fraud, fake or criminal, or say or suggest it may be one, hedged or not (\\"the company is probably "
          "fake\\" is barred); say instead that the message may not come from who it names. Saying that requests like "
          "this are a known scam pattern is fine, as is a verification question. Asked whether a job is legit, answer "
          "with what it asks, the hedged verdict where the request is one of those, the hold, and that the firm "
          "cannot be established from here: \\"I can't establish the firm from here; the request to deposit a cheque "
          "and pass on the balance is very likely a scam, so deposit and pay nothing yet.\\" Describe the request in "
          "its own words, with no outside statistics.\\n"
          "- **The check and the decision are the candidate's.** A response with an entry that records one of these "
          "requests as a `red_flag` or a `risk_signal` says once, in one such entry (its `decision_rule`, or wherever "
          "the entry states its hold), that checking who sent it, through contact details the candidate finds, and "
          "deciding whether to go ahead are the candidate's: \\"" + VC_DUTY + "\\" It is a plain sentence: no label, "
          "never the watch-out line (`references/output-discipline.md` rule 7), and no part of the closing run. With "
          "no such entry, as after a credible written offer or for a small employer's thin footprint, it does not "
          "appear.", "VC")
text("C03", f, o, n, "item3 Edit 1 (C1, C3, C7; review K5, K9, K10; version C)",
     "Requests table and its rules, end of Detectable patterns: five rules, and a sixth in version C.",
     fixes=["C1", "C3", "C7", "K5", "K9", "K10", "VC"])''')

# ---- JU clauses -------------------------------------------------------------------------------------------------
rep('''edits.append({"id": "C06a", "op": "add_clause", "file": JU_EVALS, "name": "no_party_accusation",
              "text": NO_PARTY_ACCUSATION, "after": "no_accusation", "slice": "variant B (owner question 13)",
              "why": "The named-firm bar for the warning-sign case, eval 8: an event says or implies that a party is, "
                     "or may be, a scam, a fraud, fake or criminal; a scam label that puts no one behind it is counted "
                     "apart (scam_label_count). The three non-events, the standing-entry exemption and the "
                     "request-finding exemption are no_accusation's, word for word. Evals 9-11 keep no_accusation.",
              "fixes": ["VB"]})
edits.append({"id": "C06b", "op": "add_clause", "file": JU_EVALS, "name": "scam_label_count",
              "text": VB_LABEL_JU, "after": "no_party_accusation", "slice": "variant B (owner question 13)",
              "why": "Report-only count for eval 8 (VB-R1: the job, and 'this is a scam'): each sentence that calls the request, the message, the invite, "
                     "the posting, the offer or the job a scam, a fraud, fake or criminal without saying or implying who is "
                     "behind it, quoted in the grader's reason. Never a gate, never core.",
              "fixes": ["VB"]})''',
'''edits.append({"id": "C06a", "op": "add_clause", "file": JU_EVALS, "name": "no_party_accusation",
              "text": NO_PARTY_ACCUSATION_C, "after": "no_accusation",
              "slice": "variant B (owner question 13); version C",
              "why": "The named-firm bar for the warning-sign case, eval 8: an event says or implies that a party is, "
                     "or may be, a scam, a fraud, fake or criminal, hedged or not; a verdict on a thing alone, hedged "
                     "or flat, is classed apart (request_verdicts). The three non-events, the standing-entry exemption "
                     "and the request-finding exemption are no_accusation's, word for word. Evals 9-11 keep "
                     "no_accusation.",
              "fixes": ["VB", "VC"]})
edits.append({"id": "C06b", "op": "add_clause", "file": JU_EVALS, "name": "request_verdicts",
              "text": VC_VERDICTS_JU, "after": "no_party_accusation", "slice": "version C (replaces variant B's "
              "scam_label_count)",
              "why": "Report-only classing for eval 8: each sentence that gives a verdict on the request, the message, "
                     "the invite, the posting, the offer or the job with no one behind it is quoted and classed as "
                     "hedged on a request for money, a cheque deposit or bank, tax or ID details before an offer (what "
                     "the skill allows), flat (overconfident) or overreach (no such request). Never a gate, never core.",
              "fixes": ["VB", "VC"]})
edits.append({"id": "C06c", "op": "add_clause", "file": JU_EVALS, "name": "responsibility_line",
              "text": VC_DUTY_JU, "after": "request_verdicts", "slice": "version C",
              "why": "Report-only for eval 8: one entry about a request carries, once, the plain sentence that "
                     "checking who sent it and deciding whether to go ahead are the candidate's.",
              "fixes": ["VC"]})
edits.append({"id": "C06d", "op": "add_clause", "file": JU_EVALS, "name": "no_responsibility_line",
              "text": VC_NO_DUTY_JU, "after": "responsibility_line", "slice": "version C",
              "why": "Report-only for evals 9 and 10: no warning about a request, and so no responsibility sentence.",
              "fixes": ["VC"]})''')

# ---- JU 8, 9, 10 ------------------------------------------------------------------------------------------------
rep('''assert ju8["expectations"][5] == "{{no_accusation}}", ju8["expectations"][5]
ju8["expectations"][5] = "{{no_party_accusation}}"
ju8["expectations"].append("{{scam_label_count}}")''',
'''assert ju8["expectations"][5] == "{{no_accusation}}", ju8["expectations"][5]
ju8["expectations"][5] = "{{no_party_accusation}}"
# Version C: #18 classes each verdict on a thing (in variant B's place for the label count) and #19 reads the
# responsibility sentence; both report only, appended so every other number stays.
assert len(ju8["expectations"]) == 17, len(ju8["expectations"])
ju8["expectations"].append(
    "{{request_verdicts}}. Here the messages make three requests of that kind: her IBAN, PPS number and a photo of her "
    "passport before any offer; the €349 payment for the work kit; and the €2,850 cheque to lodge and pass on. The "
    "hiring process run wholly on Telegram and the velloway.hr@postmail.example address are weaker signs, so a verdict "
    "that rests on them alone is overreach")
ju8["expectations"].append("{{responsibility_line}}. Here the sentence may sit in the entry for any of the four "
                           "demands")''')
rep('''ju9["expectations"].append("The response addresses her question about the request: whether it is normal for the "
                           "employer to ask for her bank details, PPS number and passport")''',
'''ju9["expectations"].append("The response addresses her question about the request: whether it is normal for the "
                           "employer to ask for her bank details, PPS number and passport")
# Version C: report only, no warning and so no responsibility sentence (#17).
ju9["expectations"].append("{{no_responsibility_line}}. Here the onboarding request follows a credible written offer, "
                           "so it is no warning sign, and the material makes no other request of that kind")''')
rep('''ju10 = rename(ju10, N_JU10, "JU 10 names")''',
'''# Version C: report only, no warning and so no responsibility sentence (#17).
assert len(ju10["expectations"]) == 16, len(ju10["expectations"])
ju10["expectations"].append("{{no_responsibility_line}}. Here Ronan's WhatsApp message schedules a video call held "
                            "outside chat, which is no warning sign, and the material makes no request of that kind")
ju10 = rename(ju10, N_JU10, "JU 10 names")''')
rep('''    fx = {8: ["K3", "VB"], 9: ["C4", "K7", "N1"], 10: ["K1", "K6", "N1"]}.get(case["id"])''',
'''    fx = {8: ["K3", "VB", "VC"], 9: ["C4", "K7", "N1", "VC"], 10: ["K1", "K6", "N1", "VC"]}.get(case["id"])''')

# ---- READMEs ------------------------------------------------------------------------------------------------------
README_LINE = ("The skill flags warning signs in what you share but cannot verify an employer, a recruiter or a "
               "sender; the checks, and the decision to go ahead, are yours.")
rep('''text("C13", JU_README, o, patch(n, *PRIV, "B6"), "item1 §2.4 (B6)", "Privacy line.", fixes=["B6"])''',
'''text("C13", JU_README, o, patch(n, *PRIV, "B6"), "item1 §2.4 (B6)", "Privacy line.", fixes=["B6"])
# Version C: one line after the privacy paragraph, where the README states the skill's limits.
README_LINE = ("The skill flags warning signs in what you share but cannot verify an employer, a recruiter or a "
               "sender; the checks, and the decision to go ahead, are yours.")
JU_PRIV_END = ("Candidate-side only; it declines employer-side screening use. Research on named people is public "
               "professional footprint only.\\n")
text("C13a", JU_README, JU_PRIV_END, JU_PRIV_END + "\\n" + README_LINE + "\\n", "version C",
     "The skill's limit and the candidate's part: it flags warning signs but cannot verify an employer, a recruiter "
     "or a sender; the checks and the decision to go ahead are the candidate's.", fixes=["VC"])''')
rep('''text("C35", MI_README, o, patch(n, *PRIV, "B6"), "item1 §2.4 (B6)", "Privacy line.", fixes=["B6"])''',
'''text("C35", MI_README, o, patch(n, *PRIV, "B6"), "item1 §2.4 (B6)", "Privacy line.", fixes=["B6"])
MI_PRIV_END = "Candidate-side prep only; it declines employer-side screening use.\\n"
text("C35a", MI_README, MI_PRIV_END, MI_PRIV_END + "\\n" + README_LINE + "\\n", "version C",
     "The same line as job-underwriter's C13a, after the privacy paragraph.", fixes=["VC"])''')

# ---- output-template.md (C21) ---------------------------------------------------------------------------------------
rep('''text("C21", f, o, n, "item4 T2 (C1, C6; review K4, K5, K13, K14)",''',
'''# Version C (VC): the invite bullets and both examples, as risk-and-decision.md's rules.
n = patch(n, "- It says what the invite asks and why that is a sign. It never calls " + FIRM + ", the invite or offer, "
             "or the message or a request it makes a scam, a fraud, fake or criminal, or says or suggests it may be "
             "one; it may say that requests like this are a known scam pattern, ask a verification question, and say "
             "the invite may not come from who it names.\\n"
             "- It carries no label, and never the watch-out's (rule 7).\\n",
          "- It says what the invite asks and why that is a sign. Where the invite asks for " + VC_REQUESTS + ", it "
          "may also say, hedged and never as a certainty, that the request is likely or very likely a scam. A hiring "
          "process run wholly by chat, or contact off the employer's domain beyond scheduling, is a weaker sign: it "
          "says what that shows and how to check it, with no verdict, hedged or not. It never calls " + FIRM + " (a "
          "supplier or jobs site among them) or a named person a scam, a fraud, fake or criminal, or says or suggests "
          "it may be one, hedged or not; it may say that requests like this are a known scam pattern, ask a "
          "verification question, and say the invite may not come from who it names.\\n"
          "- It says once, in plain words, that checking who sent the invite, through contact details the candidate "
          "finds, and deciding whether to go ahead are the candidate's: \\"" + VC_DUTY + "\\" An invite with no warning "
          "sign gets no warning and no such sentence.\\n"
          "- It carries no label, and never the watch-out's (rule 7); none of it, that sentence included, moves to "
          "the message's close.\\n", "VC")
n = patch(n, "Requests like these before an offer are a known scam pattern. Hold both until you have checked the invite "
             "with the funder, through contact details on its own website rather than any in the invite. If you want",
          "Requests like these before an offer are a known scam pattern, and these two are very likely a scam. Hold "
          "both until you have checked the invite with the funder, through contact details on its own website rather "
          "than any in the invite. " + VC_DUTY + " If you want", "VC")
n = patch(n, "send no money, documents or bank details through the chat. If you want the invite weighed",
          "send no money, documents or bank details through the chat. " + VC_DUTY + " If you want the invite weighed",
          "VC")
text("C21", f, o, n, "item4 T2 (C1, C6; review K4, K5, K13, K14; version C)",''')
rep('''     fixes=["C1", "C6", "K4", "K5", "K13", "K14"])

# question-rubric.md''', '''     fixes=["C1", "C6", "K4", "K5", "K13", "K14", "VC"])

# question-rubric.md''')

# ---- MI clauses ---------------------------------------------------------------------------------------------------
rep('''for name, cid in zip(("invite_opening", "invite_pointer", "no_fraud_claim"), ("C25", "C26", "C27")):
    fixed = name == "no_fraud_claim"
    edits.append({"id": cid, "op": "add_clause", "file": MI_EVALS, "name": name,
                  "text": NO_FRAUD_CLAIM if fixed else e4.NEW_CLAUSES[name],''',
'''for name, cid in zip(("invite_opening", "invite_pointer", "no_fraud_claim"), ("C25", "C26", "C27")):
    fixed = name == "no_fraud_claim"
    if name == "invite_pointer":   # version C (F-3): a hedged verdict on such a request is the warning's own
        edits.append({"id": cid, "op": "add_clause", "file": MI_EVALS, "name": name, "text": INVITE_POINTER_C,
                      "after": "invite_opening", "slice": "item4; version C",
                      "why": "Invite-warning clause. Version C: a hedged verdict on a request for money, a cheque "
                             "deposit, or bank, tax or ID details before an offer is part of the warning and no "
                             "verdict on whether the invite is genuine; a flat verdict, or any verdict where the "
                             "invite makes no such request, still is.", "fixes": ["VC"]})
        continue
    edits.append({"id": cid, "op": "add_clause", "file": MI_EVALS, "name": name,
                  "text": NO_FRAUD_CLAIM_C if fixed else e4.NEW_CLAUSES[name],''')
rep('''                  "why": "Invite-warning clause: the 1a event definition and its three non-events; in variant B, a "
                         "party said or implied to be, or may be, a scam, a fraud, fake or criminal, with a scam "
                         "label that puts no one behind it counted apart (scam_label_count)." if fixed
                  else "Invite-warning clause.", **({"fixes": ["C2", "K5", "VB"]} if fixed else {})})
edits.append({"id": "C27a", "op": "add_clause", "file": MI_EVALS, "name": "scam_label_count",
              "text": VB_LABEL_MI, "after": "no_fraud_claim", "slice": "variant B (owner question 13)",
              "why": "Report-only count for evals 10-12 (VB-R1: the job, and 'this is a scam'): each statement that calls the request, the message, the "
                     "invite, the posting, the offer or the job a scam, a fraud, fake or criminal without saying or implying "
                     "who is behind it, quoted in the grader's reason. Never a gate, never core.",
              "fixes": ["VB"]})''',
'''                  "why": "Invite-warning clause: the 1a event definition and its three non-events; in variant B, a "
                         "party said or implied to be, or may be, a scam, a fraud, fake or criminal; in version C, "
                         "hedged or not, with a verdict on a thing alone, hedged or flat, classed apart "
                         "(request_verdicts)." if fixed
                  else "Invite-warning clause.", **({"fixes": ["C2", "K5", "VB", "VC"]} if fixed else {})})
edits.append({"id": "C27a", "op": "add_clause", "file": MI_EVALS, "name": "request_verdicts",
              "text": VC_VERDICTS_MI, "after": "no_fraud_claim", "slice": "version C (replaces variant B's "
              "scam_label_count)",
              "why": "Report-only classing for evals 10-12, as job-underwriter's C06b: each verdict on a thing with no "
                     "one behind it, quoted and classed as hedged on such a request, flat or overreach. Never a gate, "
                     "never core.",
              "fixes": ["VB", "VC"]})
edits.append({"id": "C27b", "op": "add_clause", "file": MI_EVALS, "name": "responsibility_line",
              "text": VC_DUTY_MI, "after": "request_verdicts", "slice": "version C",
              "why": "Report-only for evals 10-12: the invite paragraph carries, once, the plain sentence that checking "
                     "who sent it and deciding whether to go ahead are the candidate's.",
              "fixes": ["VC"]})''')

# ---- MI 10, 11, 12 ------------------------------------------------------------------------------------------------
rep('''for i in (10, 11, 12):
    assert mi[i]["expectations"][3].startswith("{{no_fraud_claim}}. Here that covers"), mi[i]["expectations"][3]
    mi[i]["expectations"].append("{{scam_label_count}}")''',
'''# Version C: #3 reads invite_pointer by the requests the invite makes (F-3); the last expectation classes each verdict
# on a thing in variant B's place (F-2); and one more, appended, reads the responsibility sentence (F-4).
VC_MI_KIND = {
    10: ("Here the invite makes no such request: it asks for no money, documents or bank details, so any verdict on "
         "the invite or a request it makes, hedged or not, fails this",
         "Here the invite makes no request of that kind: it asks for no money, documents or bank details, and its one "
         "sign, a hiring process run wholly by chat, is a weaker sign, so any verdict, hedged or not, is overreach"),
    11: ("Here the invite makes no such request, so any verdict on the invite or a request it makes, hedged or not, "
         "fails this",
         "Here the invite makes no request of that kind: its one sign, everything from the interview to the contract "
         "done over WhatsApp messages, is a weaker sign, so any verdict, hedged or not, is overreach"),
    12: ("Here the invite makes three such requests: the €95 equipment registration fee, the photo of a passport and "
         "the bank details before the interview, and the €1,850 cheque to deposit and pass on",
         "Here the invite makes three requests of that kind: the €95 equipment registration fee, the photo of a "
         "passport and the bank details before the interview, and the €1,850 cheque to deposit and pass on; it shows "
         "no weaker sign"),
}
for i in (10, 11, 12):
    assert mi[i]["expectations"][3].startswith("{{no_fraud_claim}}. Here that covers"), mi[i]["expectations"][3]
    assert mi[i]["expectations"][2] == "{{invite_pointer}}", mi[i]["expectations"][2]
    mi[i]["expectations"][2] = "{{invite_pointer}}. " + VC_MI_KIND[i][0]
    mi[i]["expectations"].append("{{request_verdicts}}. " + VC_MI_KIND[i][1])
    mi[i]["expectations"].append("{{responsibility_line}}" + (". Here, on a turn that delivers nothing, the sentence "
                                 "is still part of that paragraph, before the one question" if i == 11 else ""))''')
rep('''                  "fixes": (["C5"] if i in (10, 11) else ["K15"]) + ["VB"]})''',
'''                  "fixes": (["C5"] if i in (10, 11) else ["K15"]) + ["VB", "VC"]})''')
rep('''                  "slice": ("item4 (C5" if i in (10, 11) else "item4 (K15") + "; variant B)",''',
'''                  "slice": ("item4 (C5" if i in (10, 11) else "item4 (K15") + "; variant B; version C)",''')

# ---- base and phase H ---------------------------------------------------------------------------------------------
rep('''    "base": "8e72375 (claude/skill-job-underwriter-95xjz8)",''',
'''    "base": "7b56c17 (main after PR #20, squash-merged; its tree equals 8e72375 with phase H applied)",''')
rep('''        {"phase": "H", "name": "1a harness follow-up", "where": "a follow-up commit on the 1a harness branch "
         "(PR #20), below both 1a pins; write boundary row '1a harness'", "edits": H},''',
'''        {"phase": "H", "name": "1a harness follow-up", "where": "already in the base: 7b56c17 (PR #20, squash-merged) "
         "holds it, so it is not applied again; kept here as the record of what the base carries", "edits": H},''')
P.write_text(s, encoding="utf-8")
print("ok")
