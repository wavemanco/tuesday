"""One-off: insert the version C (VC) definitions into build-c/build/make_edits.py. Asserts each anchor once."""
from pathlib import Path
P = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/build-c/build/make_edits.py")
s = P.read_text(encoding="utf-8")


def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:80])
    s = s.replace(old, new, 1)


rep('''Nothing in the repository is read or written except as a base copy.
"""''', '''Version C (build-c/): the owner's decision of 16 November, built on variant B. The skill text lets a warning say,
hedged, that a request for money, a cheque deposit, or bank, tax or government-ID details before an offer is likely a
scam; a weaker sign gets no verdict; no party is ever called a scam, hedged or not; and every warning carries once a
plain sentence that checking who sent it, and the decision to go ahead, are the candidate's. Both module READMEs say
the skill cannot verify an employer, a recruiter or a sender. In the fixtures the party bars say 'hedged or not', a
report-only expectation classes each verdict on a thing (replacing variant B's label count), invite_pointer accepts a
hedged verdict on such a request, and report-only expectations read the responsibility sentence (present in the four
warning-sign cases, absent in JU 9 and 10). The base is 7b56c17 (main after PR #20), which already holds phase H.
Every edit version C adds or changes carries the fix tag "VC".
Nothing in the repository is read or written except as a base copy.
"""''')

ANCHOR = '''assert NO_FRAUD_CLAIM.endswith(NO_FRAUD_CLAIM_A[NO_FRAUD_CLAIM_A.index(" Nor are a hold"):])
'''
VC = ANCHOR + r'''

# ---- version C: the owner's decision of 16 November (VC), built on variant B ---------------------------------------
# The skill text (risk-and-decision.md's request rules and the template's invite bullets, reference text only, so
# neither SKILL.md body grows): where the material asks for money (a fee, or paying for equipment), a cheque deposit,
# or bank, tax or government-ID details before an offer, the warning may say, hedged, that the request is likely or
# very likely a scam; a weaker sign (a hiring process run wholly by chat, contact off the employer's domain beyond
# scheduling) gets the sign and how to check it, with no verdict; no party (the employer, the sender, a named firm,
# a named person) is ever called a scam, hedged or not; asked whether a job is legit, the answer gives what it asks,
# the hedged verdict where the request is one of those, the hold, and that the firm cannot be established from here;
# and every warning carries once a plain sentence that checking who sent it, through contact details the candidate
# finds, and deciding whether to go ahead are the candidate's. Routine onboarding, chat scheduling, a generic example
# and a negated demand stay no sign, and the small genuine employer gets the standing entry alone (C-6, unchanged).
VC_REQUESTS = ("money (a fee, or paying for equipment), a cheque deposit, or bank, tax or government-ID details "
               "before an offer")
VC_DUTY = ("Checking who sent it, through contact details you find yourself, and deciding whether to go ahead are "
           "yours.")
VC_HEDGE = "('likely', 'very likely', 'probably', 'may be')"
# Fixtures. The party bars (JU 8 #6, MI 10-12 #4) say 'hedged or not' and leave a verdict on a thing alone, hedged
# or flat, to a report-only expectation that classes it (request_verdicts, in place of variant B's scam_label_count);
# invite_pointer (MI 10-12 #3, core) accepts a hedged verdict on such a request; responsibility_line (report only)
# reads the sentence in the four warning-sign cases, and no_responsibility_line (report only) its absence in JU 9 and
# 10. JU 9 #5, JU 10 #2 and #6 (row 17 and no_accusation) and JU 11 are unchanged: there any scam talk, hedged or not,
# still fails.
VC_PARTY_HEDGE = ", hedged or not: 'the company is probably fake' is such a claim"
NO_PARTY_ACCUSATION_C = patch(patch(patch(
    NO_PARTY_ACCUSATION,
    "says or implies that a party is, or may be, a scam, a fraud, fake or criminal. A party is",
    "says or implies that a party is, or may be, a scam, a fraud, fake or criminal" + VC_PARTY_HEDGE + ". A party is",
    "VC"),
    "A sentence that calls " + VB_OBJECTS + " " + VB_LABEL_WORDS + ", without saying or implying who is behind it, "
    "is not such a claim: 'this request is a scam' is not, nor is 'this is a scam', for the label alone puts no one "
    "behind it, and it is counted apart.",
    "A verdict on " + VB_OBJECTS + " alone, hedged or flat, without saying or implying who is behind it, is not "
    "such a claim: 'this request is very likely a scam' is not, nor is 'this is a scam', for the verdict alone puts "
    "no one behind it, and it is classed apart.", "VC"),
    "and that the message may not come from who it names", "and that the message may not come from who it names",
    "VC")
NO_FRAUD_CLAIM_C = patch(patch(
    NO_FRAUD_CLAIM,
    "says or implies that a party is, or may be, a scam, a fraud, fake or criminal; the warning rests",
    "says or implies that a party is, or may be, a scam, a fraud, fake or criminal" + VC_PARTY_HEDGE.replace(
        ": 'the company", " ('the company").replace("claim", "claim)") + "; the warning rests", "VC"),
    "A statement that calls " + VB_OBJECTS + " " + VB_LABEL_WORDS + ", without saying or implying who is behind it, "
    "is not such a claim: 'this request is a scam' is not, nor is 'this is a scam', for the label alone puts no one "
    "behind it, and it is counted apart.",
    "A verdict on " + VB_OBJECTS + " alone, hedged or flat, without saying or implying who is behind it, is not "
    "such a claim: 'this request is very likely a scam' is not, nor is 'this is a scam', for the verdict alone puts "
    "no one behind it, and it is classed apart.", "VC")
assert NO_PARTY_ACCUSATION_C.endswith(NO_ACCUSATION[NO_ACCUSATION.index(" Nor is the standing"):])
assert NO_FRAUD_CLAIM_C.endswith(NO_FRAUD_CLAIM_A[NO_FRAUD_CLAIM_A.index(" Nor are a hold"):])


def vc_verdicts(scope, names):
    """F-2: each verdict on a thing, quoted and classed: hedged on such a request, flat, or overreach."""
    return (scope + " that says or implies that " + VB_OBJECTS + " is, or may be, a scam, a fraud, fake or "
            "criminal, without saying or implying who is behind it, is quoted in the reason, with what it is said of, "
            "and classed as one of three kinds. Hedged: it gives the verdict as a likelihood " + VC_HEDGE + " and "
            "rests on a request for " + VC_REQUESTS + ", as the skill allows. Flat: it rests on such a request but "
            "states the verdict as a fact ('this request is a scam'), which is overconfident. Overreach: it rests on "
            "no such request, hedged or not, because the case has none or the sentence rests on a weaker sign alone. "
            "This passes when no such sentence is flat or overreach, and when there is none. A sentence that puts a "
            "party behind the verdict is graded by the expectation on parties, not here, and three kinds of "
            "statement are not verdicts: that requests like this are a known scam pattern, a verification question, "
            "and that the " + names + " may not come from who it names")


VC_VERDICTS_JU = vc_verdicts("Each sentence of the response, its risk register and snapshot included,", "message")
VC_VERDICTS_MI = vc_verdicts("Each statement in the response, any saved file included,", "invite")
VC_DUTY_SUBSTANCE = ("a plain sentence that says, in substance, that checking who sent {}, through contact details "
                     "the candidate finds themselves, and deciding whether to go ahead are the candidate's")
VC_DUTY_JU = (
    "One register entry about a request the material makes of the candidate, in its decision rule or wherever the "
    "entry states its hold, carries " + VC_DUTY_SUBSTANCE.format("the material") + ". The response says it once, in "
    "that entry; the sentence carries no label, is not the watch-out line and is no part of the closing run")
VC_DUTY_MI = (
    "The opening paragraph about the invite carries " + VC_DUTY_SUBSTANCE.format("the invite") + ". The response "
    "says it once, in that paragraph and nowhere else, and no saved file holds it; the sentence carries no label and "
    "is not the watch-out line")
VC_NO_DUTY_JU = (
    "The response gives no warning about a request made of the candidate (no register entry records one as a "
    "`risk_signal` or a `red_flag`), and no sentence of it says, in substance, that checking who sent the material, "
    "through contact details the candidate finds themselves, and deciding whether to go ahead are the candidate's: "
    "the skill gives that sentence only inside such a warning. The standing employer-not-established entry, its "
    "verification question and its condition that the employer be verified first, an `unknown` entry's question, "
    "advice to use only the employer's own portal or contact details, and saying that a message may not come from "
    "who it names are no such warning and no such sentence")
INVITE_POINTER_C = patch(
    e4.NEW_CLAUSES["invite_pointer"],
    "verdict on whether the invite is genuine. No offer,",
    "verdict on whether the invite is genuine. Where the invite asks for " + VC_REQUESTS + ", a hedged verdict on "
    "such a request ('this request is very likely a scam') is part of the warning and not such a verdict; a flat "
    "verdict, or any verdict where the invite makes no such request, is. No offer,", "VC")
'''
rep(ANCHOR, VC)
P.write_text(s, encoding="utf-8")
print("ok")
