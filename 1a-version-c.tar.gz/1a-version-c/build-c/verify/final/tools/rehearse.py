import sys, json, re
f = sys.argv[1]; d = json.load(open(sys.argv[2]))
t = open(f, encoding='utf-8').read()
old = {"hub_sha256": "4d10c30930488ed3f63067f9dc47651dad6c2874f3a992817f87951332f1ce80",
       "tuesday_sha256": "8d10162a0a58e5f99fb39356b473c79952cd8faa5533c4a909cecdd28261af12",
       "builds_sha256": "d6670eeaebcc12864e5925bbc8c128e330e47a083bdcaccb61865679ce63c752"}
for k, v in old.items():
    a = f'    "{k}": "{v}",\n'
    assert t.count(a) == 1, k
    t = t.replace(a, f'    "{k}": "{d[k]}",\n')
a = '    "plugin_version": "0.2.0",\n'
assert t.count(a) == 1
t = t.replace(a, '    "plugin_version": "0.3.0",\n')
open(f, 'w', encoding='utf-8').write(t)
