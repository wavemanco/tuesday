import sys, json
sys.dont_write_bytecode = True
root = sys.argv[1]
sys.path.insert(0, root + "/ci")
import check_skills
print(json.dumps(check_skills.tuesday_digests(), indent=1, sort_keys=True))
