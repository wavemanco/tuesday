# Counts only. The account email comes from the environment (SCAN_EMAIL) and is never printed.
import os, re, sys, zipfile, io
email = os.environ.get("SCAN_EMAIL", "").strip().lower()
assert email and "@" in email
enc = email.replace("@", "%40")
KEYS = {
  "anthropic_key": re.compile(rb"sk-ant-[A-Za-z0-9_\-]{10,}"),
  "openai_like": re.compile(rb"\bsk-[A-Za-z0-9]{20,}"),
  "aws_akid": re.compile(rb"\b(AKIA|ASIA)[0-9A-Z]{16}\b"),
  "github_token": re.compile(rb"\b(ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{20,}"),
  "slack_token": re.compile(rb"\bxox[abposr]-[A-Za-z0-9-]{10,}"),
  "google_api": re.compile(rb"\bAIza[0-9A-Za-z_\-]{35}\b"),
  "private_key": re.compile(rb"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
  "bearer": re.compile(rb"(?i)\bbearer\s+[A-Za-z0-9._\-]{24,}"),
  "jwt": re.compile(rb"\beyJ[A-Za-z0-9_\-]{10,}\.eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}"),
  "api_key_assign": re.compile(rb"(?i)\b(api[_-]?key|secret|token|password)\s*[:=]\s*['\"][A-Za-z0-9/+_\-]{20,}['\"]"),
}
HOME = re.compile(rb"/home/([A-Za-z0-9._\-]+)")
OTHER_HOME = re.compile(rb"/Users/[A-Za-z0-9._\-]+|C:\\\\Users\\\\|C:\\Users\\")
ROOT = re.compile(rb"/root/")
def blobs(path):
    data = open(path, "rb").read()
    yield path, data
    if zipfile.is_zipfile(path) and (path.endswith(".skill") or path.endswith(".zip")):
        with zipfile.ZipFile(path) as z:
            for n in z.namelist():
                yield path + "!" + n, z.read(n)
tot = {"files": 0, "email": 0, "email_files": 0, "root_paths": 0, "root_files": 0, "other_home": 0, "home_other_users": 0}
keyc = {k: 0 for k in KEYS}; root_where = {}; key_where = {}; home_where = {}
for root in sys.argv[1:]:
    paths = [root] if os.path.isfile(root) else [os.path.join(dp, f) for dp, dn, fn in os.walk(root) for f in fn]
    for p in paths:
        if os.path.islink(p): continue
        for name, data in blobs(p):
            tot["files"] += 1
            low = data.lower()
            n = low.count(email.encode()) + low.count(enc.encode())
            if n: tot["email"] += n; tot["email_files"] += 1
            r = len(ROOT.findall(data))
            if r: tot["root_paths"] += r; tot["root_files"] += 1; root_where[name] = r
            for m in HOME.finditer(data):
                if m.group(1) != b"user":
                    tot["home_other_users"] += 1; home_where[name] = home_where.get(name, 0) + 1
            o = len(OTHER_HOME.findall(data)); tot["other_home"] += o
            if o: home_where[name] = home_where.get(name, 0) + o
            for k, rx in KEYS.items():
                c = len(rx.findall(data))
                if c: keyc[k] += c; key_where.setdefault(k, []).append(name)
print(tot); print("keys", keyc)
for k, v in key_where.items(): print("KEY", k, v[:5])
for k, v in list(root_where.items())[:20]: print("ROOT", k, v)
for k, v in list(home_where.items())[:20]: print("HOME", k, v)
