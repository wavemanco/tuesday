set -u
say() { echo "$*"; }
fail() { echo "STOPPED: $*"; exit 1; }
G() { git -C "$REPO" "$@"; }
BASE_SHA=7b56c174218e6288bf5f8b8a08a90cf38633b4e8
  BASE=$(G rev-parse --verify --quiet "$BASE_SHA^{commit}") || fail "the baseline pin $BASE_SHA is not in $REPO"
  CAND=$(G rev-parse --verify --quiet "$CAND_ARG^{commit}") || fail "the candidate $CAND_ARG is not a commit in $REPO"
  # The candidate is one commit on a parent whose TREE equals the baseline's: the only pushable branch's HEAD is a
  # merge-back commit (5696742) whose tree equals 7b56c17's, and the branch is never force-pushed, so the candidate
  # cannot sit directly on 7b56c17. The path list below is still taken from the baseline itself.
  [ "$(G rev-list --parents -n 1 "$CAND" | wc -w)" -eq 2 ] \
    || fail "the candidate $CAND is not one commit on one parent (it has no parent, or it is a merge)"
  PARENT=$(G rev-parse --verify --quiet "$CAND^") || fail "the candidate $CAND has no parent"
  PARENT_TREE=$(G rev-parse "$CAND^^{tree}"); BASE_TREE=$(G rev-parse "$BASE^{tree}")
  [ "$PARENT_TREE" = "$BASE_TREE" ] \
    || fail "the candidate $CAND's parent $PARENT has tree $PARENT_TREE, not the baseline $BASE's tree $BASE_TREE"
  say "candidate $CAND: one commit on $PARENT, whose tree $PARENT_TREE equals the baseline $BASE's"
