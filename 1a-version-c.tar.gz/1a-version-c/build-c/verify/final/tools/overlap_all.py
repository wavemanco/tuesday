import sys, json, os
sys.dont_write_bytecode = True
base, cand = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(cand, "ci"))
import check_skills as cs
STOP = cs.ANSWER_KEY_STOP
def toks(t): return [x for x in cs.key_tokens(cs.key_text(t)) if x not in STOP]
def index(root, prompts_only):
    idx = {}
    for skill in ("job-underwriter", "mock-interview", "resume-tailor"):
        cases = json.load(open(f"{root}/skills/{skill}/evals/evals.json", encoding="utf-8"))["evals"]
        hay = [(f"eval {c['id']} prompt", c.get("prompt", "")) for c in cases] if prompts_only else cs.fixture_haystack(cases)
        for where, t in hay:
            for r in cs.key_runs(toks(t), 3): idx.setdefault(r, f"{skill} {where}")
    return idx
def shipped(root):
    out = {}
    for m in ("job-underwriter", "mock-interview", "tuesday"):
        for dp, dn, fn in os.walk(f"{root}/skills/{m}"):
            if "/evals" in dp: continue
            for f in fn:
                if f.endswith(".md"):
                    p = os.path.join(dp, f); out[os.path.relpath(p, root)] = open(p, encoding="utf-8").read()
    return out
for label, po in (("prompts", True), ("prompts+pages", False)):
    ic, ib = index(cand, po), index(base, po)
    sc, sb = shipped(cand), shipped(base)
    runs_c = {(f, r) for f, t in sc.items() for r in cs.key_runs(toks(t), 3) if r in ic}
    runs_b = {(f, r) for f, t in sb.items() for r in cs.key_runs(toks(t), 3) if r in ib}
    new = sorted(runs_c - runs_b)
    print(label, "candidate shipped runs shared:", len(runs_c), "base:", len(runs_b), "new in candidate:", len(new))
    for f, r in new[:30]: print("  NEW", f, " ".join(r), "<-", ic[r])
