import hashlib, json, sys
from pathlib import Path
sys.dont_write_bytecode = True
TREE = Path(sys.argv[1]); OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(TREE / "evals"))
import fixture_clauses as fc
POS = (("job-underwriter", 7), ("job-underwriter", 8), ("mock-interview", 9), ("mock-interview", 10),
       ("mock-interview", 11), ("mock-interview", 12), ("mock-interview", 13))
for skill, n in POS:
    src = TREE / "skills" / skill / "evals" / "evals.json"
    data = json.loads(src.read_text(encoding="utf-8"))
    cases = [c for c in data["evals"] if c["id"] == n]
    assert len(cases) == 1
    spec = {"skill_name": data["skill_name"], "clauses": data["clauses"], "evals": [cases[0]]}
    body = json.dumps(spec, indent=2, ensure_ascii=False) + "\n"
    out = OUT / f"e23-{skill}-{n}.json"; out.write_text(body, encoding="utf-8")
    treat = [c for c in fc.load_cases(src) if c["id"] == n][0]
    ext = fc.load_cases(out)[0]
    same = treat == ext
    modes = (cases[0].get("research") or {}).get("modes") or ["denied"]
    print(out.name, hashlib.sha256(body.encode()).hexdigest(), "whole-case-identical", same, "exp", len(ext["expectations"]), modes)
