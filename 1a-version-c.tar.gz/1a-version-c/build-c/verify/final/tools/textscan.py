import sys, os, re, json
NEW_SENT = "I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call."
NEW_README = "It's an AI assistant and can make mistakes. It points out warning signs in what you share, but it can't confirm who an employer, recruiter or sender really is. Please check before you act; the decision is always yours."
OLD_SENT = "Checking who sent it, through contact details you find yourself, and deciding whether to go ahead are yours."
OLD_README = "The skill flags warning signs in what you share but cannot verify an employer, a recruiter or a sender; the checks, and the decision to go ahead, are yours."
PHRASE = "through contact details you find yourself"
WIDE = ["through contact details", "contact details you find", "find yourself"]
pats = {"NEW_SENT": NEW_SENT, "NEW_README": NEW_README, "OLD_SENT": OLD_SENT, "OLD_README": OLD_README, "PHRASE": PHRASE}
for i,w in enumerate(WIDE): pats["WIDE%d"%i]=w
def norm(s): return re.sub(r"\s+", " ", s)
roots = sys.argv[1:]
for root in roots:
    for dp, dn, fn in os.walk(root):
        for f in sorted(fn):
            p = os.path.join(dp, f)
            if p.endswith('.skill'): continue
            try: t = open(p, encoding='utf-8').read()
            except Exception: continue
            variants = {"raw": t, "norm": norm(t)}
            if p.endswith('.json'):
                try:
                    d = json.loads(t)
                    variants["json"] = norm(json.dumps(d, ensure_ascii=False))
                except Exception: pass
            # also curly-quote normalised
            curly = t.replace('’', "'").replace('‘', "'")
            variants["curly"] = norm(curly)
            for k, s in pats.items():
                counts = {v: x.count(s) for v, x in variants.items()}
                if any(counts.values()):
                    print(f"{k}\t{os.path.relpath(p, root)}\t{counts}")
