import sys, json, re, difflib, os
base, cand = sys.argv[1], sys.argv[2]
STOPWORDS_SRC = open(os.path.join(cand, "ci", "check_skills.py"), encoding="utf-8").read()
# use check_skills' own STOPWORDS (read, not trusted blindly: printed size)
sys.path.insert(0, os.path.join(cand, "ci"))
sys.dont_write_bytecode = True
import check_skills as cs
STOP = cs.ANSWER_KEY_STOP
print("stopwords", len(STOP))
def toks(t): return [x for x in cs.key_tokens(cs.key_text(t)) if x not in STOP]
idx_prompt, idx_all = {}, {}
for skill in ("job-underwriter", "mock-interview", "resume-tailor"):
    cases = json.load(open(f"{cand}/skills/{skill}/evals/evals.json", encoding="utf-8"))["evals"]
    for case in cases:
        p = case.get("prompt", "")
        for r in cs.key_runs(toks(p), 3): idx_prompt.setdefault(r, f"{skill} eval {case['id']} prompt")
    for where, t in cs.fixture_haystack(cases):
        for r in cs.key_runs(toks(t), 3): idx_all.setdefault(r, f"{skill} {where}")
DUTY = "I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call."
README = "It's an AI assistant and can make mistakes. It points out warning signs in what you share, but it can't confirm who an employer, recruiter or sender really is. Please check before you act; the decision is always yours."
for name, t in (("sentence", DUTY), ("readme", README)):
    hits = [(" ".join(r), idx_all[r]) for r in cs.key_runs(toks(t), 3) if r in idx_all]
    print(name, "tokens", toks(t), "hits", hits)
# all added lines in shipped source files
files = []
for m in ("job-underwriter", "mock-interview"):
    for dp, dn, fn in os.walk(f"{cand}/skills/{m}"):
        if "/evals" in dp: continue
        for f in fn:
            if f.endswith(".md"): files.append(os.path.relpath(os.path.join(dp, f), cand))
tot = 0
for f in sorted(files):
    b = open(f"{base}/{f}", encoding="utf-8").read().splitlines()
    c = open(f"{cand}/{f}", encoding="utf-8").read().splitlines()
    added = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, b, c, autojunk=False).get_opcodes():
        if tag in ("replace", "insert"): added += [(j, c[j]) for j in range(j1, j2)]
    for j, line in added:
        # only runs new to this line vs base file as a whole
        base_runs = cs.key_runs(toks("\n".join(b)), 3)
        for r in cs.key_runs(toks(line), 3):
            if r in idx_all and r not in base_runs:
                tot += 1
                print(f"NEW-HIT {f}:{j+1} {' '.join(r)!r} <- {idx_all[r]}")
            elif r in idx_all:
                print(f"OLD-HIT {f}:{j+1} {' '.join(r)!r} <- {idx_all[r]} (run also in base file)")
print("new hits vs prompts:", tot)
