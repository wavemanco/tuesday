import sys, json
sys.dont_write_bytecode = True
from pathlib import Path
root = Path(sys.argv[1])
sys.path.insert(0, str(root / "evals")); sys.path.insert(0, str(root / "ci"))
import run_fixtures as rf
print(json.dumps(rf.payload_digests(root), indent=1, sort_keys=True))
inv = rf.inventory(root)
print(json.dumps(inv, indent=1, sort_keys=True))
