# Independent recount of the spill detector baseline over the fix round's saved runs.
import json, re, sys, glob, os
R = sys.argv[1]
PH = ["can get this wrong", "before you reply or send anything", "it's your call", "it’s your call", "deciding whether to go ahead"]
MARK = "----- file the response produced:"
def norm(s): return re.sub(r"\s+", " ", s).lower()
def jstrings(o):
    if isinstance(o, str): yield o
    elif isinstance(o, dict):
        for v in o.values(): yield from jstrings(v)
    elif isinstance(o, list):
        for v in o: yield from jstrings(v)
def json_views(raw, jsonl):
    dec = []
    for chunk in (raw.splitlines() if jsonl else [raw]):
        try: dec.extend(jstrings(json.loads(chunk)))
        except Exception: pass
    return [norm(raw), norm(" ".join(dec))]
metas = sorted(glob.glob(os.path.join(R, "*", "*", "part-*", "*.meta.json")))
print("runs", len(metas))
tot = {p: {"runs": 0, "occ": {"responses": 0, "files": 0, "grades": 0, "streams": 0}} for p in PH}
surf_n = {"responses": 0, "files": 0, "grades": 0, "streams": 0}
missing_streams = 0
for mp in metas:
    d = os.path.dirname(mp); meta = json.load(open(mp, encoding="utf-8"))
    stem = os.path.basename(mp)[:-len(".meta.json")]
    assert stem == meta.get("stem"), (stem, meta.get("stem"))
    md = open(os.path.join(d, stem + ".md"), encoding="utf-8").read()
    i = md.find(MARK)
    S = {"responses": [[norm(md if i < 0 else md[:i])]], "files": [] if i < 0 else [[norm(md[i:])]], "grades": [], "streams": []}
    for g in sorted(glob.glob(os.path.join(d, glob.escape(stem) + ".grade-*.json"))):
        S["grades"].append(json_views(open(g, encoding="utf-8").read(), False))
    for inv in meta.get("invocations", []):
        sp = os.path.join(d, "streams", os.path.basename(inv["room"]) + ".jsonl")
        if os.path.isfile(sp): S["streams"].append(json_views(open(sp, encoding="utf-8", errors="replace").read(), True))
        else: missing_streams += 1
    for k in S: surf_n[k] += len(S[k])
    for p in PH:
        hit = False
        for k, views in S.items():
            n = sum(max(v.count(p) for v in vs) for vs in views)
            tot[p]["occ"][k] += n
            hit |= n > 0
        tot[p]["runs"] += hit
print("surfaces", surf_n, "missing streams", missing_streams)
for p in PH: print(repr(p), "runs", tot[p]["runs"], "occurrences", sum(tot[p]["occ"].values()), tot[p]["occ"])
