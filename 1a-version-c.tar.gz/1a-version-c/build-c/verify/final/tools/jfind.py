import json,sys,re
d=json.load(open(sys.argv[1]))
pat=sys.argv[2]; w=int(sys.argv[3]) if len(sys.argv)>3 else 200
def walk(o,path):
    if isinstance(o,dict):
        for k,v in o.items(): walk(v,path+[str(k)])
    elif isinstance(o,list):
        for i,v in enumerate(o): walk(v,path+[str(i)])
    elif isinstance(o,str):
        for m in re.finditer(pat,o):
            print('/'.join(path), '::', o[max(0,m.start()-w):m.end()+w].replace('\n',' '))
walk(d,[])
