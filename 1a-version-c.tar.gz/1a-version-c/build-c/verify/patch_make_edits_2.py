from pathlib import Path
P = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/build-c/build/make_edits.py")
s = P.read_text(encoding="utf-8")


def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:80])
    s = s.replace(old, new, 1)


rep('''VC_PARTY_HEDGE = ", hedged or not: 'the company is probably fake' is such a claim"
NO_PARTY_ACCUSATION_C = patch(patch(patch(
    NO_PARTY_ACCUSATION,
    "says or implies that a party is, or may be, a scam, a fraud, fake or criminal. A party is",
    "says or implies that a party is, or may be, a scam, a fraud, fake or criminal" + VC_PARTY_HEDGE + ". A party is",
    "VC"),''', '''VC_PARTY_HEDGE = "hedged or not ('the company is probably fake' is such a claim)"
VC_THING = ("A verdict on " + VB_OBJECTS + " alone, hedged or flat, without saying or implying who is behind it, is "
            "not such a claim: 'this request is very likely a scam' is not, nor is 'this is a scam', for the verdict "
            "alone puts no one behind it, and it is classed apart.")
NO_PARTY_ACCUSATION_C = patch(patch(
    NO_PARTY_ACCUSATION,
    "says or implies that a party is, or may be, a scam, a fraud, fake or criminal. A party is",
    "says or implies that a party is, or may be, a scam, a fraud, fake or criminal, " + VC_PARTY_HEDGE + ". A party "
    "is", "VC"),''')
rep('''    "A verdict on " + VB_OBJECTS + " alone, hedged or flat, without saying or implying who is behind it, is not "
    "such a claim: 'this request is very likely a scam' is not, nor is 'this is a scam', for the verdict alone puts "
    "no one behind it, and it is classed apart.", "VC"),
    "and that the message may not come from who it names", "and that the message may not come from who it names",
    "VC")
NO_FRAUD_CLAIM_C = patch(patch(
    NO_FRAUD_CLAIM,
    "says or implies that a party is, or may be, a scam, a fraud, fake or criminal; the warning rests",
    "says or implies that a party is, or may be, a scam, a fraud, fake or criminal" + VC_PARTY_HEDGE.replace(
        ": 'the company", " ('the company").replace("claim", "claim)") + "; the warning rests", "VC"),''',
'''    VC_THING, "VC")
NO_FRAUD_CLAIM_C = patch(patch(
    NO_FRAUD_CLAIM,
    "says or implies that a party is, or may be, a scam, a fraud, fake or criminal; the warning rests",
    "says or implies that a party is, or may be, a scam, a fraud, fake or criminal, " + VC_PARTY_HEDGE + "; the "
    "warning rests", "VC"),''')
rep('''    "is not such a claim: 'this request is a scam' is not, nor is 'this is a scam', for the label alone puts no one "
    "behind it, and it is counted apart.",
    "A verdict on " + VB_OBJECTS + " alone, hedged or flat, without saying or implying who is behind it, is not "
    "such a claim: 'this request is very likely a scam' is not, nor is 'this is a scam', for the verdict alone puts "
    "no one behind it, and it is classed apart.", "VC")
assert NO_PARTY''', '''    "is not such a claim: 'this request is a scam' is not, nor is 'this is a scam', for the label alone puts no one "
    "behind it, and it is counted apart.",
    VC_THING.replace("A verdict", "A statement that gives a verdict", 1), "VC")
assert NO_PARTY''')
P.write_text(s, encoding="utf-8")
print("ok")
