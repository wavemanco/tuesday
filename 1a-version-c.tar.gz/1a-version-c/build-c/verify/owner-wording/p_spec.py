from pathlib import Path
F = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/build-c/build/make_spec.py")
P = []
NEW = "I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call."
RL = "It's an AI assistant and can make mistakes. It points out warning signs in what you share, but it can't confirm who an employer, recruiter or sender really is. Please check before you act; the decision is always yours."
# data: the detector's baselines
P.append(('''e23 = [l.split() for l in (OUT / "e23.txt").read_text().splitlines() if l.strip()]''',
'''e23 = [l.split() for l in (OUT / "e23.txt").read_text().splitlines() if l.strip()]
# The responsibility sentence's spill detector (VS6), recomputed for the owner's final wording (VO) over the 1,220 saved
# fix-round runs by build/spill_baseline.py: the detector is the zero-baseline phrase.
SPILL = json.loads((OUT / "spill-baseline.json").read_text(encoding="utf-8"))
assert SPILL["runs"] == 1220
DETECTOR = "can get this wrong"
assert SPILL["phrases"][DETECTOR]["runs"] == 0 and SPILL["phrases"][DETECTOR]["occurrences"] == 0
DUTY_VO = ("I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please "
           "confirm who sent it. It's your call.")
README_VO = ("It's an AI assistant and can make mistakes. It points out warning signs in what you share, but it can't "
             "confirm who an employer, recruiter or sender really is. Please check before you act; the decision is "
             "always yours.")


def spill_count(p):
    r = SPILL["phrases"][p]
    where = [f"{r[s]['occurrences']} in {s.replace('responses', 'responses').replace('files', 'saved files')}"
             for s in ("responses", "files", "grades", "streams") if r[s]["occurrences"]]
    return (f"\\"{p}\\" {r['runs']} of {SPILL['runs']:,} runs" +
            (f" ({r['occurrences']} occurrences: {', '.join(where)})" if r["occurrences"] else ""))


SPILL_TEXT = "; ".join(spill_count(p) for p in (DETECTOR, "before you reply or send anything", "it's your call",
                                                 "it\\u2019s your call", "deciding whether to go ahead"))'''))
# intro paragraph
P.append(('''  "person) is ever called a scam, hedged or not; and every warning carries once a plain sentence that checking who "
  "sent it, through contact details the candidate finds, and deciding whether to go ahead are the candidate's. Both "
  "module READMEs gain one line: the skill flags warning signs but cannot verify an employer, a recruiter or a "
  "sender, and the checks and the decision to go ahead are the reader's. In the fixtures the party bars (JU 8 #6, "''',
'''  "person) is ever called a scam, hedged or not; and every warning carries once the responsibility sentence, in the "
  "owner's final wording of 16 November (fix tag VO, \\"The owner's final wording\\" below): \\"" + DUTY_VO + "\\" Both "
  "module READMEs gain one line, also the owner's final wording: \\"" + README_VO + "\\" In the fixtures the party "
  "bars (JU 8 #6, "'''))
P.append(('''  "`invite_pointer` names the three non-events, and the responsibility sentence needs all three of its parts. "''',
'''  "`invite_pointer` names the three non-events, and the responsibility sentence needs all three of its parts (it "
  "goes only on what was shared and may be wrong; confirm who sent it before replying or sending anything; the call "
  "is the candidate's). "'''))
P.append(('''  "(`8e72375` with phase H) byte for byte, so phase H is already in it and phase C is the one commit "
  "(`out/h-noop.txt`, `out/b-vs-c-paths.txt`).\\n")''',
'''  "(`8e72375` with phase H) byte for byte, so phase H is already in it and phase C is the one commit "
  "(`out/h-noop.txt`, `out/b-vs-c-paths.txt`). That commit is made on the branch's merge-back commit `5696742`, "
  "whose tree equals `7b56c17`'s, since the only pushable branch is never force-pushed; the freeze holds the "
  "candidate's parent's tree to the baseline's.\\n")'''))
P.append(('''w(f"1. **Candidate (phase C), the 1a fixture commit, on `7b56c17`.** Edits''',
'''w(f"1. **Candidate (phase C), the 1a fixture commit, on `7b56c17`'s tree** (committed on `5696742`, the branch's "
  f"merge-back commit, whose tree equals `7b56c17`'s). Edits'''))
# VK9, VK10, VS6
P.append(('''     "`responsibility_line` and `no_responsibility_line`: \\"It needs all three parts, who sent it, the check through "
     "contact details the candidate finds, and the decision: a generic 'the decision is yours', or a check "
     "instruction alone, is not the sentence.\\""),''',
'''     "`responsibility_line` and `no_responsibility_line` require all three parts and refuse a generic \\"the decision is "
     "yours\\" or a check instruction alone; with the owner's final wording (VO) the parts read: \\"It needs all three "
     "parts, that it goes only on what was shared and may be wrong, that the candidate confirms who sent it before "
     "replying or sending anything, and that the call is the candidate's: a generic 'the decision is yours', or a "
     "check instruction alone, is not the sentence.\\""),'''))
P.append(('''     "sends the candidate only to contact details they find, as `invite_opening` asks."),''',
'''     "sends the candidate only to contact details they find, as `invite_opening` asks. The owner's final wording (VO) "
     "drops the phrase from the sentence itself."),'''))
P.append(('''     "The risk names MI 13 #2 and asks for its failures that carry the sentence to be reported apart, and freezes the "
     "detector now: a case-insensitive match on \\"deciding whether to go ahead\\", whose baseline is 0 of the 1,220 "
     "saved fix-round runs (responses, saved files, grades and streams)."),''',
'''     "The risk names MI 13 #2 and asks for its failures that carry the sentence to be reported apart, and freezes the "
     "detector now: a case-insensitive match on \\"" + DETECTOR + "\\", whose baseline is 0 of the 1,220 saved "
     "fix-round runs (responses, saved files, grades and streams). It was \\"deciding whether to go ahead\\" (baseline "
     "0) until the owner's final wording (VO) replaced the sentence; recomputed over the same surfaces "
     "(`build/spill_baseline.py`, `out/spill-baseline.json`): " + SPILL_TEXT + ". \\"" + DETECTOR + "\\" is the "
     "zero-baseline phrase, and the most distinctive of the sentence's: \\"it's your call\\" is ordinary advice "
     "(two saved packs carry it), and \\"before you reply or send anything\\", also 0, is a generic instruction a "
     "warning-free answer could give."),'''))
# the owner's final wording subsection, after the review of version C
P.append(('''assert {f for f, *_ in REVIEW_C} == {f"VK{i}" for i in range(1, 11)} | {f"VS{i}" for i in range(1, 9)}
assert not [r for r in REVIEW_C if r[2] == "refuted"]
w("")''',
'''assert {f for f, *_ in REVIEW_C} == {f"VK{i}" for i in range(1, 11)} | {f"VS{i}" for i in range(1, 9)}
assert not [r for r in REVIEW_C if r[2] == "refuted"]
w("")
vo_ids = sorted(set(by_fix.get("VO", [])), key=cids.index)
assert vo_ids == ["C03", "C06c", "C06d", "C13a", "C21", "C27b", "C35a"], vo_ids
w("### The owner's final wording, 16 November (VO)\\n")
w("The owner approved final wording for the responsibility sentence and the README line, replacing the build's "
  "earlier example wording (\\"Checking who sent it, through contact details you find yourself, and deciding whether "
  "to go ahead are yours.\\" and \\"The skill flags warning signs in what you share but cannot verify an employer, a "
  "recruiter or a sender; the checks, and the decision to go ahead, are yours.\\"). The owner rejected \\"through "
  "contact details\\" as overprescription; the separate \\"Verify with the employer, not the sender.\\" rule and the "
  "examples' hold sentences, the existing verification advice, are unchanged. Made in the generator "
  "(`build/make_edits.py`, fix tag VO), then rebuilt from a fresh archive of `7b56c17` and every gate rerun "
  f"[{', '.join(vo_ids)}]:\\n")
w(f"- **The sentence**, in `risk-and-decision.md`'s rule \\"The check and the decision are the candidate's.\\" and in "
  f"`output-template.md`'s invite bullet and both its examples: \\"{DUTY_VO}\\" The bullets now describe its three "
  "parts: the warning goes only on what the candidate has shared and can be wrong; before replying or sending "
  "anything, the candidate should confirm who sent it; and the call is theirs. The rest of each bullet is unchanged "
  "(once only, which entry or paragraph, no label, never the watch-out line, not part of the closing run, absent "
  "with no such warning). `ci/sync.py` and `ci/package.py` carry it to `skills/tuesday/references/` and `dist/`.")
w(f"- **The README line**, in both module READMEs after the privacy paragraph: \\"{README_VO}\\"")
w("- **The fixtures:** `responsibility_line` (JU 8 #19, MI 10 #10, MI 11 #7, MI 12 #10) and `no_responsibility_line` "
  "(JU 9 #17, JU 10 #17) describe the same three parts in substance, still require all three, still refuse a "
  "generic \\"the decision is yours\\" or a check instruction alone, and keep their placement, once-only, no-label, "
  "not-the-watch-out and closing-run rules and the listed non-sentences; neither names \\"through contact details\\" "
  "as part of the sentence. The case hashes and every E23 file change with them (each E23 file holds its module's "
  "whole clause set).")
w(f"- **The spill detector** (VS6) is now a case-insensitive match on \\"{DETECTOR}\\", baseline 0 of the 1,220 saved "
  f"fix-round runs over responses, saved files, grades and streams; the counts: {SPILL_TEXT}.")
w("- **Checked** by `build/lint_fixtures.py` (3e): the old sentence, the old README line and \\"through contact "
  "details you find yourself\\" appear nowhere in shipped text, in either tree and in every decompressed `.skill` "
  "member; the new sentence appears exactly in the rule bullet and both examples of every copy of the two reference "
  "files (32 times in 16 texts) and nowhere else; the new README line once in each of the eight README copies; and "
  "neither shares a run of three content words with any fixture prompt or canned page. Both SKILL.md bodies are "
  "unchanged.")
w("")'''))
P.append(('''assert {f for f, *_ in REVIEW} | {f for f, *_ in REVIEW_C} >= set(by_fix) - {f for f, _ in CHANGES}, set(by_fix)''',
'''assert {f for f, *_ in REVIEW} | {f for f, *_ in REVIEW_C} >= set(by_fix) - {f for f, _ in CHANGES} - {"VO"}, set(by_fix)'''))
# summary row: owner questions
P.append(('''w("| Owner questions | @@NQ@@, in section 11, each with a recommendation but 13, now the owner's recorded decision of 16 "
  "November (version C, with a responsibility sentence in each warning and in both READMEs); 13 and 14 came with the "''',
'''w("| Owner questions | @@NQ@@, in section 11, each with a recommendation but 13, now the owner's recorded decision of 16 "
  "November (version C, with a responsibility sentence in each warning and in both READMEs, in the owner's final "
  "wording), and 15, taken as recommended on 16 November under the owner's approval of the manifest's "
  "recommendations and reversible before the freeze; 13 and 14 came with the "'''))
# section 3 sixth rule
P.append(('''           "request, the plain sentence \\"Checking who sent it, through contact details you find yourself, and "
           "deciding whether to go ahead are yours.\\": no label, never the watch-out line, no part of the closing "''',
'''           "request, the responsibility sentence in the owner's final wording, \\"" + DUTY_VO + "\\": no label, "
           "never the watch-out line, no part of the closing "'''))
# section 6 bullets
P.append(('''  "run by model and install. The sentence needs all three parts (who sent it, the check through contact details the "
  "candidate finds, the decision); a generic \\"the decision is yours\\" is not it.''',
'''  "run by model and install. The sentence needs all three parts (it goes only on what was shared and may be wrong; "
  "confirm who sent it before replying or sending anything; the call is the candidate's); a generic \\"the decision "
  "is yours\\" is not it.'''))
P.append(('''  "`no_responsibility_line`, JU 9 #17, JU 10 #17):** in each warning-sign case the warning carries once, in "
  "substance, a plain sentence that checking who sent the material, through contact details the candidate finds "
  "themselves, and deciding whether to go ahead are the candidate's: in job-underwriter in one entry about a "''',
'''  "`no_responsibility_line`, JU 9 #17, JU 10 #17):** in each warning-sign case the warning carries once, in "
  "substance, the responsibility sentence: that it goes only on what the candidate has shared and may be wrong, that "
  "the candidate should confirm who sent the material before replying or sending anything, and that the call is the "
  "candidate's: in job-underwriter in one entry about a "'''))
P.append(('''w("| The responsibility sentence | \\"Checking who sent it, through contact details you find yourself, and deciding "
  "whether to go ahead are yours.\\" | No event; expected once, in the warning (item 4) | No event; expected nowhere "''',
'''w("| The responsibility sentence | \\"" + DUTY_VO + "\\" | No event; expected once, in the warning (item 4) | No event; "
  "expected nowhere "'''))
# section 7.1 candidate row
P.append(('''w(f"| Candidate | The baseline pin plus the phase-C commit | hub''',
'''w(f"| Candidate | The phase-C commit, on a parent whose tree equals the baseline pin's (the branch's merge-back commit "
  f"`5696742`) | hub'''))
# section 9 lint sentence
P.append(('''  "off-domain invite sign in shipped text, the funder example's two requests, all three parts of the sentence); and "
  "`check_skills.py --only answer-keys --only fixtures --only evals` passes).\\n")''',
'''  "off-domain invite sign in shipped text, the funder example's two requests, all three parts of the sentence); the "
  "owner's final wording (3e: the old sentence, the old README line and \\"through contact details you find "
  "yourself\\" nowhere in shipped text, archive members included; the new sentence 32 times in its 16 expected "
  "texts and nowhere else; the new README line once in each of eight copies; no three-content-word run shared with "
  "a fixture prompt or page); and `check_skills.py --only answer-keys --only fixtures --only evals` passes).\\n")'''))
# Q13 decided
P.append(('''     "the responsibility sentence once in every warning (\\"Checking who sent it, through contact details you find "
     "yourself, and deciding whether to go ahead are yours.\\"), never where no warning is given; both module READMEs "
     "say the skill cannot verify an employer, a recruiter or a sender, and that the checks and the decision to go "
     "ahead are the reader's. The zero bar''',
'''     "the responsibility sentence once in every warning (\\"" + DUTY_VO + "\\", the owner's final wording, which "
     "replaces the earlier example), never where no warning is given; both module READMEs carry the owner's final "
     "line: \\"" + README_VO + "\\" The zero bar'''))
# Q15 taken as recommended
P.append(('''    ("Four readings of the 16 November decision, from the review of version C (VK2, VK5, VK8, VS4).",''',
'''    ("Four readings of the 16 November decision, from the review of version C (VK2, VK5, VK8, VS4). Decided.",'''))
P.append(('''     "Confirm all four as built. Each follows the decision's own words or keeps a plan bar the decision did not "
     "change (plan item 3 (c), item 4's sign list); (a) is the reading that matters for a core screen, and its "
     "alternative is a fixture and skill-text edit before the case hashes freeze."),''',
'''     "Taken as recommended, 16 November: all four confirmed as built, by the session under the owner's approval of "
     "the manifest's recommendations (manifest question 24); reversible before the freeze, where (a)'s alternative is "
     "a fixture and skill-text edit before the case hashes freeze. Each follows the decision's own words or keeps a "
     "plan bar the decision did not change (plan item 3 (c), item 4's sign list)."),'''))
P.append(('''assert sum(q.endswith(" Decided.") for q, _, _ in Q) == 1 and Q[12][0].endswith(" Decided.")''',
'''assert sum(q.endswith(" Decided.") for q, _, _ in Q) == 2 and Q[12][0].endswith(" Decided.") and Q[14][0].endswith(" Decided.")'''))
# Q16
P.append(('''     "Both module READMEs carry the line \\"The skill flags warning signs in what you share but cannot verify an "
     "employer, a recruiter or a sender; the checks, and the decision to go ahead, are yours.\\", and the plugin tree "''',
'''     "Both module READMEs carry the line \\"" + README_VO + "\\", and the plugin tree "'''))
P.append(('''     "carry no such line, and `dist/tuesday.skill` packs no README. The in-warning sentence (\\"Checking who sent it, "
     "through contact details you find yourself, and deciding whether to go ahead are yours.\\") does reach hub users, "''',
'''     "carry no such line, and `dist/tuesday.skill` packs no README. The in-warning sentence (\\"" + DUTY_VO + "\\") "
     "does reach hub users, "'''))
# risk
P.append(('''    "The existing rooms have no expectation that reads it, so count it there with a detector frozen now, a "
    "case-insensitive match on \\"deciding whether to go ahead\\" over chat and saved files, against its baseline of "
    "0 in the 1,220 saved fix-round runs (responses, saved files, grades and streams), report only, and read the "
    "`watch_out` check beside it.",''',
'''    "The existing rooms have no expectation that reads it, so count it there with a detector frozen now, a "
    "case-insensitive match on \\"" + DETECTOR + "\\" over chat and saved files, against its baseline of 0 in the "
    "1,220 saved fix-round runs (responses, saved files, grades and streams; `out/spill-baseline.json`), report "
    "only, and read the `watch_out` check beside it.",'''))
t = F.read_text(encoding="utf-8")
for i, (o, n) in enumerate(P):
    c = t.count(o)
    assert c == 1, (i, c, o[:120])
    t = t.replace(o, n, 1)
F.write_text(t, encoding="utf-8")
print(len(P), "replacements")
