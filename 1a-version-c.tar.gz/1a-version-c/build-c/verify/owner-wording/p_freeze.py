from pathlib import Path
K = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/runkit")
def apply(name, pairs):
    f = K / name; t = f.read_text(encoding="utf-8")
    for i, (o, n) in enumerate(pairs):
        c = t.count(o); assert c == 1, (name, i, c, o[:100]); t = t.replace(o, n, 1)
    f.write_text(t, encoding="utf-8"); print(name, len(pairs))

apply("freeze.sh", [
("""#   outside the checkout (baseline = 7b56c17, candidate = the SHA given), computes every digest, dependency""",
"""#   outside the checkout (baseline = 7b56c17, candidate = the SHA given, one commit on a parent whose tree equals
#   the baseline's: the pushable branch's merge-back commit 5696742), computes every digest, dependency"""),
("""  [ "$(G rev-parse "$CAND^")" = "$BASE" ] || fail "the candidate $CAND is not one commit on top of the baseline $BASE"
""",
"""  # The candidate is one commit on a parent whose TREE equals the baseline's: the only pushable branch's HEAD is a
  # merge-back commit (5696742) whose tree equals 7b56c17's, and the branch is never force-pushed, so the candidate
  # cannot sit directly on 7b56c17. The path list below is still taken from the baseline itself.
  [ "$(G rev-list --parents -n 1 "$CAND" | wc -w)" -eq 2 ] \\
    || fail "the candidate $CAND is not one commit on one parent (it has no parent, or it is a merge)"
  PARENT=$(G rev-parse --verify --quiet "$CAND^") || fail "the candidate $CAND has no parent"
  PARENT_TREE=$(G rev-parse "$CAND^^{tree}"); BASE_TREE=$(G rev-parse "$BASE^{tree}")
  [ "$PARENT_TREE" = "$BASE_TREE" ] \\
    || fail "the candidate $CAND's parent $PARENT has tree $PARENT_TREE, not the baseline $BASE's tree $BASE_TREE"
  say "candidate $CAND: one commit on $PARENT, whose tree $PARENT_TREE equals the baseline $BASE's"
"""),
("""else
  BASE="(stand-in) $WT_BASE"; CAND="(stand-in) $WT_CAND"
""",
"""else
  BASE="(stand-in) $WT_BASE"; CAND="(stand-in) $WT_CAND"; PARENT=""; PARENT_TREE=""; BASE_TREE=""
"""),
("""python3 -I -B - "$FACTS" "$BASE" "$CAND" "$mode" "$CLI_VERSION" <<'PY'
import json, os, socket, sys
from pathlib import Path
f, base, cand, mode, cli = sys.argv[1:6]
lines = lambda p: [l for l in Path(p).read_text().splitlines() if l.strip()]
facts = {"mode": mode, "baseline_sha": base, "candidate_sha": cand, "name_status": lines(f + ".ns"),""",
"""python3 -I -B - "$FACTS" "$BASE" "$CAND" "$mode" "$CLI_VERSION" "$PARENT" "$PARENT_TREE" "$BASE_TREE" <<'PY'
import json, os, socket, sys
from pathlib import Path
f, base, cand, mode, cli, parent, parent_tree, base_tree = sys.argv[1:9]
lines = lambda p: [l for l in Path(p).read_text().splitlines() if l.strip()]
facts = {"mode": mode, "baseline_sha": base, "candidate_sha": cand,
         "candidate_parent_sha": parent or None, "candidate_parent_tree": parent_tree or None,
         "baseline_tree": base_tree or None, "name_status": lines(f + ".ns"),"""),
])
apply("lib/freeze.py", [
("""{"candidate_sha", "baseline_sha", "name_status": [...], "harness_name_status": [...] or null,""",
"""{"candidate_sha", "baseline_sha", "candidate_parent_sha", "candidate_parent_tree", "baseline_tree" (the three are
 null in the stand-in), "name_status": [...], "harness_name_status": [...] or null,"""),
("""    c.lines.append(f"  candidate {facts.get('candidate_sha')} at {cand}")
""",
"""    c.lines.append(f"  candidate {facts.get('candidate_sha')} at {cand}")
    if facts.get("candidate_parent_sha"):
        c.lines.append(f"  candidate's parent {facts['candidate_parent_sha']}, tree {facts.get('candidate_parent_tree')}"
                       f" (the baseline's tree {facts.get('baseline_tree')})")
"""),
])
