"""rep.py FILE PAIRS.json: apply exact (old, new) replacements to FILE, each old occurring exactly once."""
import json, sys
from pathlib import Path
path, pairs = Path(sys.argv[1]), json.loads(Path(sys.argv[2]).read_text(encoding="utf-8"))
t = path.read_text(encoding="utf-8")
for i, (old, new) in enumerate(pairs):
    n = t.count(old)
    if n != 1:
        raise SystemExit(f"pair {i}: old text occurs {n} times: {old[:120]!r}")
    t = t.replace(old, new, 1)
path.write_text(t, encoding="utf-8")
print(f"{path.name}: {len(pairs)} replacements")
