import json, sys
from pathlib import Path
F = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/build-c/build/make_edits.py")
P = []
# docstring
P.append(("""hedged, that a request for money, a cheque deposit, or bank, tax or government-ID details before an offer is likely a
scam; a weaker sign gets no verdict; no party is ever called a scam, hedged or not; and every warning carries once a
plain sentence that checking who sent it, and the decision to go ahead, are the candidate's. Both module READMEs say
the skill cannot verify an employer, a recruiter or a sender. In the fixtures""",
"""hedged, that a request for money, a cheque deposit, or bank, tax or government-ID details before an offer is likely a
scam; a weaker sign gets no verdict; no party is ever called a scam, hedged or not; and every warning carries once the
responsibility sentence: it goes only on what the candidate has shared and can be wrong, the candidate confirms who
sent it before replying or sending anything, and the call is theirs. Both module READMEs say the skill is an AI
assistant that can make mistakes and cannot confirm who an employer, a recruiter or a sender really is. The owner's
final wording of both (16 November, fix tag "VO") replaces the earlier example wording. In the fixtures"""))
P.append(("""spill VS1-VS8) are resolved here too, each by patch() on version C's text, and tagged with the finding's id.
""", """spill VS1-VS8) are resolved here too, each by patch() on version C's text, and tagged with the finding's id.
The owner's final wording (VO) replaces the responsibility sentence (VC_DUTY), its descriptions in both rule bullets,
the two clauses that read it and the README line; every edit it touches carries the fix tag "VO".
"""))
# comment block
P.append(("""# and every warning carries once a plain sentence that checking who sent it, through contact details the candidate
# finds, and deciding whether to go ahead are the candidate's. Routine onboarding,""",
"""# and every warning carries once the responsibility sentence, in the owner's final wording (VO): it goes only on what
# the candidate has shared and can be wrong, the candidate confirms who sent it before replying or sending anything,
# and the call is theirs. Routine onboarding,"""))
P.append(('''VC_DUTY = ("Checking who sent it, through contact details you find yourself, and deciding whether to go ahead are "
           "yours.")''',
'''# VO: the owner's final wording, 16 November, replacing the example "Checking who sent it, through contact details you
# find yourself, and deciding whether to go ahead are yours." (the owner rejected "through contact details" as
# overprescription). Three short sentences, quoted as one block wherever the shipped text carries it.
VC_DUTY = ("I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please "
           "confirm who sent it. It's your call.")
# How the rule bullets and the clauses describe it, part by part.
VO_PARTS_SKILL = ("that the warning goes only on what the candidate has shared and can be wrong, that the candidate "
                  "should confirm who sent {} before replying or sending anything, and that the call is theirs")'''))
P.append(('''VC_DUTY_SUBSTANCE = ("a plain sentence that says, in substance, that checking who sent {}, through contact details "
                     "the candidate finds themselves, and deciding whether to go ahead are the candidate's")
# VK9: the sentence has three parts; a generic 'the decision is yours', or a check instruction alone, is not it.
VR_PARTS = ("It needs all three parts, who sent it, the check through contact details the candidate finds, and the "
            "decision: a generic 'the decision is yours', or a check instruction alone, is not the sentence")''',
'''# VO: the three parts of the owner's wording, in substance, in place of the earlier "who sent it, the check through
# contact details the candidate finds, and the decision".
VO_PARTS = ("that the warning goes only on what the candidate has shared and may be wrong, that the candidate should "
            "confirm who sent {} before replying or sending anything, and that the call is the candidate's")
VC_DUTY_SUBSTANCE = ("the responsibility sentence: plain words, one sentence or a few, that say, in substance, "
                     + VO_PARTS)
# VK9: the sentence has three parts; a generic 'the decision is yours', or a check instruction alone, is not it.
VR_PARTS = ("It needs all three parts, that it goes only on what was shared and may be wrong, that the candidate "
            "confirms who sent it before replying or sending anything, and that the call is the candidate's: a generic "
            "'the decision is yours', or a check instruction alone, is not the sentence")'''))
P.append(('''    "`risk_signal` or a `red_flag`), and no sentence of it says, in substance, that checking who sent the material, "
    "through contact details the candidate finds themselves, and deciding whether to go ahead are the candidate's: "
    "the skill gives that sentence only inside such a warning. "''',
'''    "`risk_signal` or a `red_flag`), and no sentence of it says, in substance, " + VO_PARTS.format("the material")
    + ": the skill gives that sentence only inside such a warning. "'''))
# JU rule bullet
P.append(('''          "the entry states its hold), that checking who sent it, through contact details the candidate finds, and "
          "deciding whether to go ahead are the candidate's: \\"" + VC_DUTY + "\\" It is a plain sentence: no label, "''',
'''          "the entry states its hold), " + VO_PARTS_SKILL.format("it") + ": \\"" + VC_DUTY + "\\" It is a plain "
          "sentence: no label, "'''))
# C06c / C06d / C27b why
P.append(('''              "why": "Report-only for eval 8: one entry about a request carries, once, the plain sentence that "
                     "checking who sent it and deciding whether to go ahead are the candidate's, all three parts.",
              "fixes": ["VC", "VK9"]})''',
'''              "why": "Report-only for eval 8: one entry about a request carries, once, the responsibility sentence "
                     "in the owner's final wording, in substance: it goes only on what was shared and may be wrong; "
                     "confirm who sent it before replying or sending anything; the call is the candidate's. All three "
                     "parts.",
              "fixes": ["VC", "VK9", "VO"]})'''))
P.append(('''                     "generic 'the decision is yours' or a check instruction alone is not it.",
              "fixes": ["VC", "VK9"]})''',
'''                     "generic 'the decision is yours' or a check instruction alone is not it.",
              "fixes": ["VC", "VK9", "VO"]})'''))
# README line
P.append(('''README_LINE = ("The skill flags warning signs in what you share but cannot verify an employer, a recruiter or a "
               "sender; the checks, and the decision to go ahead, are yours.")''',
'''# VO: the owner's final wording, 16 November, replacing "The skill flags warning signs in what you share but cannot
# verify an employer, a recruiter or a sender; the checks, and the decision to go ahead, are yours."
README_LINE = ("It's an AI assistant and can make mistakes. It points out warning signs in what you share, but it can't "
               "confirm who an employer, recruiter or sender really is. Please check before you act; the decision is "
               "always yours.")'''))
P.append(('''     "The skill's limit and the candidate's part: it flags warning signs but cannot verify an employer, a recruiter "
     "or a sender; the checks and the decision to go ahead are the candidate's.", fixes=["VC"])''',
'''     "The skill's limit and the candidate's part, in the owner's final wording: it is an AI assistant and can make "
     "mistakes; it points out warning signs but can't confirm who an employer, recruiter or sender really is; the "
     "reader checks before acting, and the decision is theirs.", fixes=["VC", "VO"])'''))
# MI rule bullet
P.append(('''          "- It says once, in plain words, that checking who sent the invite, through contact details the candidate "
          "finds, and deciding whether to go ahead are the candidate's: \\"" + VC_DUTY + "\\" An invite with no warning "
          "sign gets no warning and no such sentence.\\n"''',
'''          "- It says once, in plain words, " + VO_PARTS_SKILL.format("the invite") + ": \\"" + VC_DUTY + "\\" An "
          "invite with no warning sign gets no warning and no such sentence.\\n"'''))
P.append(('''# into a chat-run invite. VK10: its hold no longer says "through contact details" right before the sentence that does.''',
'''# into a chat-run invite. VK10: its hold no longer says "through contact details" right before the sentence that did
# (the owner's final wording, VO, drops the phrase from the sentence too).'''))
P.append(('''     fixes=["C1", "C6", "K4", "K5", "K13", "K14", "VC", "VK2", "VK3", "VK8", "VK10", "VS1", "VS2", "VS5"])''',
'''     fixes=["C1", "C6", "K4", "K5", "K13", "K14", "VC", "VK2", "VK3", "VK8", "VK10", "VS1", "VS2", "VS5", "VO"])'''))
P.append(('''     fixes=["C1", "C3", "C7", "K5", "K9", "K10", "VC", "VK2", "VK3", "VK4", "VK5", "VK7", "VS2", "VS3", "VS4"])''',
'''     fixes=["C1", "C3", "C7", "K5", "K9", "K10", "VC", "VK2", "VK3", "VK4", "VK5", "VK7", "VS2", "VS3", "VS4", "VO"])'''))
P.append(('''              "why": "Report-only for evals 10-12: the invite paragraph carries, once, the plain sentence that checking "
                     "who sent it and deciding whether to go ahead are the candidate's, all three parts.",
              "fixes": ["VC", "VK9"]})''',
'''              "why": "Report-only for evals 10-12: the invite paragraph carries, once, the responsibility sentence in "
                     "the owner's final wording, in substance: it goes only on what was shared and may be wrong; "
                     "confirm who sent it before replying or sending anything; the call is the candidate's. All three "
                     "parts.",
              "fixes": ["VC", "VK9", "VO"]})'''))
P.append(('''     "The same line as job-underwriter's C13a, after the privacy paragraph.", fixes=["VC"])''',
'''     "The same line as job-underwriter's C13a, after the privacy paragraph.", fixes=["VC", "VO"])'''))
t = F.read_text(encoding="utf-8")
for i, (o, n) in enumerate(P):
    c = t.count(o)
    assert c == 1, (i, c, o[:100])
    t = t.replace(o, n, 1)
F.write_text(t, encoding="utf-8")
print(len(P), "replacements")
