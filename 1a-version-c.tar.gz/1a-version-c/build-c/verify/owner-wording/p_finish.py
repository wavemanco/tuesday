from pathlib import Path
F = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/build-c/build/finish_manifest.py")
P = []
P.append(('''"""Finish version C's manifest and owner summary: the owner's approval and decisions of 16 November, the run kit's
corrections, and the final verification of 17 November. Offline.''',
'''"""Finish version C's manifest and owner summary: the owner's approval and decisions of 16 November (the final wording
of the responsibility sentence and the README line; questions 24 and 26 taken as recommended under the approval), the
run kit's corrections (the explicit command, the neutral output folders, the freeze's parent-tree check), and the
final verification of 17 November. Offline.'''))
# section 3: candidate row and check 2
P.append(('''# ---- expect files, CLI, commands ------------------------------------------------------------------------------------''',
'''# ---- section 3: the candidate's parent (the run kit's freeze check) --------------------------------------------------
rep("| Candidate | One commit on top of the baseline pin: the 11 source edits, then `ci/sync.py` and `ci/package.py` "
    "(48 paths, section 17). Pushed when made. |",
    "| Candidate | One commit on a parent whose tree equals the baseline pin's: the branch's merge-back commit "
    "`5696742` (HEAD of `claude/skill-job-underwriter-95xjz8`, the only pushable branch, never force-pushed), whose "
    "tree equals `7b56c17`'s. The 11 source edits, then `ci/sync.py` and `ci/package.py` (48 paths against "
    "`7b56c17`, section 17). Pushed when made. |")
rep("touches no path under `skills/`, `conventions/`, `ci/`, `evals/` or `dist/`; any such path stops the round.\\n",
    "touches no path under `skills/`, `conventions/`, `ci/`, `evals/` or `dist/`; any such path stops the round. The "
    "candidate is one commit on one parent whose tree equals the baseline's (`git rev-parse <candidate>^^{tree}` "
    "against `<baseline>^{tree}`), and `freeze.json` logs the parent's SHA beside the baseline's.\\n")

# ---- expect files, CLI, commands ------------------------------------------------------------------------------------'''))
# section 8 --out column and the neutral-names note
P.append(('''    "- The `--out` names above reach the model inside each room's path. Whether to make them neutral before the "
    "freeze is question 26; only the names would change.\\n")''',
'''    "- The `--out` names above reach the model inside each room's path, so none names or abbreviates a module "
    "(question 26, taken as recommended): `part-1` and `part-2` hold the existing job-underwriter and mock-interview "
    "rooms, as in the fix round's baseline, `part-4` and `part-5` the new ones, and `e23/part-1` to `e23/part-7` the "
    "replays in section 5's order (job-underwriter 7 and 8, then mock-interview 9 to 13). The expect files keep the "
    "part names of the run kit (`expect/<m>/<arm>/ju-new.json`, `expect/<m>/e23/job-underwriter-7.json`), which no "
    "room's path carries.\\n")
for old, new in (("ju-existing", "part-1"), ("ju-new", "part-4"), ("mi-existing", "part-2"), ("mi-new", "part-5")):
    rep(f"| `$M/runs/<m>/<arm>/{old}` |", f"| `$M/runs/<m>/<arm>/{new}` |")
rep("--via skill --layout plugin <shared>` | `$M/runs/<m>/e23/<module>-<id>` |",
    "--via skill --layout plugin <shared>` | `$M/runs/<m>/e23/part-<n>`, `<n>` 1 to 7 in section 5's order |")
rep("  python evals/compare_arms.py $M/runs/<m>/<arm>/<ju|mi>-existing $M/baseline/<m>/<arm>/part-<1|2> \\\\\\n"
    "      --checks-from $M/runs/<m>/<arm>/<ju|mi>-existing $M/checkrun/<m>/<arm>/part-<1|2>",
    "  python evals/compare_arms.py $M/runs/<m>/<arm>/part-<1|2> $M/baseline/<m>/<arm>/part-<1|2> \\\\\\n"
    "      --checks-from $M/runs/<m>/<arm>/part-<1|2> $M/checkrun/<m>/<arm>/part-<1|2>")'''))
P.append(('''    f"    - The run kit's expected values (`runkit/expect-c.json`, sha256 `{exp_sha}`), written from this build by "
    "the kit's `make_expected.py`, find every one of their 52 values in this manifest.\\n")''',
'''    f"    - The run kit's expected values (`runkit/expect-c.json`, sha256 `{exp_sha}`), written from this build by "
    f"the kit's `make_expected.py`, find every one of their {N_VALUES} values in this manifest.\\n"
    "    - The run kit's stand-in freeze (`freeze.sh --dirs`, a fresh archive of `7b56c17` and a fresh candidate "
    "against `runkit/expect-c.json`) passes every check, and the kit's dry run passes, its rehearsal candidate "
    "committed on the merge-back commit and refused on a parent with another tree.\\n")'''))
# section 20 header and q26
P.append(('''    "Owner, 16 November: the manifest is approved with the recommendation on each question below. Questions 13 and 15 "
    "are decided as written there, and 16 is superseded by 15. Question 26 came from the run kit after the approval "
    "and is open.\\n")''',
'''    "Owner, 16 November: the manifest is approved with the recommendation on each question below. Questions 13 and 15 "
    "are decided as written there, and 16 is superseded by 15. The owner's final wording of the responsibility "
    "sentence and the README line (question 13) replaces the earlier example wording. Question 24 is recorded as "
    "taken as recommended under that approval, and question 26, which came from the run kit after the approval, is "
    "taken as recommended by the session under the same approval; both are reversible before the freeze.\\n")'''))
P.append(('''    "26. **Output folder names** (from the run kit, after the approval; open). Each room and the plugin beside it sit "''',
'''    "26. **Output folder names** (from the run kit, after the approval). *Taken as recommended, 16 November, by the "
    "session under the owner's approval of the manifest's recommendations; reversible before the freeze.* Each room "
    "and the plugin beside it sit "'''))
P.append(('''    "`e23/part-1` to `e23/part-7` for the replays in section 5's order. Section 8's `--out` column and the run kit's "
    "two folder maps change together; no hash, expect file or count changes.\\n")''',
'''    "`e23/part-1` to `e23/part-7` for the replays in section 5's order. Section 8's `--out` column and the run kit's "
    "two folder maps (`PART_FOLDER`, `E23_FOLDER` in `kit.env`) changed together, and the kit's plan, recovery "
    "commands and dry run agree; no hash, expect file or count changes.\\n")'''))
P.append(('''rep("| Freeze | One expect file per step and revision | Digests, inventory and settings from sections 3–8 |",''',
'''rep("| Pin | Baseline SHA; candidate SHA | Section 3's six checks pass; both commits pushed |",
    "| Pin | Baseline SHA; candidate SHA | Section 3's six checks pass; the candidate's parent's tree equals the "
    "baseline's; both commits pushed |")
rep("| Freeze | One expect file per step and revision | Digests, inventory and settings from sections 3–8 |",'''))
P.append(('''vals = [*exp["digests"]["candidate"].values(),''', '''vals = [*exp["digests"]["candidate"].values(),'''))
# owner summary
P.append(('''- **The checks are the user's.** Every warning says once: "Checking who sent it, through contact details you find yourself, and deciding whether to go ahead are yours."
- **The disclaimer.** Both module READMEs say: "The skill flags warning signs in what you share but cannot verify an employer, a recruiter or a sender; the checks, and the decision to go ahead, are yours." The same line''',
'''- **The checks are the user's.** Every warning says once, in your final wording: "I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please confirm who sent it. It's your call."
- **The disclaimer.** Both module READMEs say, in your final wording: "It's an AI assistant and can make mistakes. It points out warning signs in what you share, but it can't confirm who an employer, recruiter or sender really is. Please check before you act; the decision is always yours." The same line'''))
P.append(('''1. Version C, with the responsibility sentence.
2. The manifest, with the recommendation on each smaller decision.''',
'''1. Version C, with the responsibility sentence; the sentence and the README line above are your final wording, replacing the earlier example wording.
2. The manifest, with the recommendation on each smaller decision.'''))
P.append(('''**One question is open**
- **Output folder names.** The run folders named in the manifest (`ju-new`, `mi-existing`, `e23/job-underwriter-7`) sit in every room's path, which the model sees, and they abbreviate or name the module. The harness's own rule is that a room never names its module, and the baseline used `part-1` and `part-2`. *Recommended:* neutral names (`part-1`, `part-2`, `part-4`, `part-5`, `e23/part-1` to `part-7`) before the freeze. Nothing else changes.
''',
'''**Taken as recommended under your approval (16 November; each can be reversed before the freeze)**
- **Output folder names** (question 26). The run folders sit in every room's path, which the model sees, and the harness's own rule is that a room never names its module. They are now neutral: `part-1` and `part-2` for the existing rooms, as in the baseline, `part-4` and `part-5` for the new ones, `e23/part-1` to `part-7` for the replays. Nothing else changes.
- **Four readings of version C** (question 24): only a verdict on a request (or a bare "this" or "it" beside one) passes, a hedged verdict on the whole invite or job fails; "almost certainly", "definitely" and "a classic scam" count as flat; "is it legit?" says the firm cannot be established only where its own pages do not establish it; a weaker sign keeps its class and severity and gets no verdict.
'''))
P.append(('''- The candidate commit is made on `7b56c17` and pushed, then frozen.''',
'''- The candidate commit is made on the branch's merge-back commit `5696742`, whose tree equals `7b56c17`'s (the branch is never force-pushed), and pushed, then frozen; the freeze checks the parent's tree.'''))
t = F.read_text(encoding="utf-8")
for i, (o, n) in enumerate(P):
    c = t.count(o)
    assert c == 1, (i, c, o[:120])
    t = t.replace(o, n, 1)
# N_VALUES: computed from the expected file, before the final-verification text uses it
o = '''exp = json.loads(EXPECT.read_text())
exp_sha = sha(EXPECT)'''
assert t.count(o) == 1
t = t.replace(o, o + '''
N_VALUES = (len(exp["digests"]["candidate"]) + len(exp["digests"]["baseline"]) + len(exp["payload"]["candidate"])
            + len(exp["payload"]["baseline"]) + len(exp["deps"])
            + sum(k != "evals/suite-routing.json" for k in exp["cases"]["candidate"])
            + sum(k != "evals/suite-routing.json" for k in exp["cases"]["baseline"]) + len(exp["e23"]) + 1)''')
o = '''missing = [v for v in vals if v not in text]'''
assert t.count(o) == 1
t = t.replace(o, '''assert len(vals) == N_VALUES, (len(vals), N_VALUES)
missing = [v for v in vals if v not in text]''')
F.write_text(t, encoding="utf-8")
print(len(P) + 2, "replacements")
