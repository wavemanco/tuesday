from pathlib import Path
K = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/runkit")
def apply(name, pairs):
    f = K / name; t = f.read_text(encoding="utf-8")
    for i, (o, n) in enumerate(pairs):
        c = t.count(o); assert c == 1, (name, i, c, o[:100]); t = t.replace(o, n, 1)
    f.write_text(t, encoding="utf-8"); print(name, len(pairs))

apply("kit.env", [
("""# Pins. The baseline is main after PR #20 (squash-merged); its tree equals the old phase H commit.
BASE_SHA=7b56c174218e6288bf5f8b8a08a90cf38633b4e8""",
"""# Pins. The baseline is main after PR #20 (squash-merged); its tree equals the old phase H commit. The candidate is
# one commit on a parent whose tree equals the baseline's: the pushable branch's merge-back commit 5696742 (freeze.sh
# compares the trees, since the candidate cannot sit directly on 7b56c17 and the branch is never force-pushed).
BASE_SHA=7b56c174218e6288bf5f8b8a08a90cf38633b4e8"""),
("""# Install arms (manifest section 7) and the four candidate parts in their order (section 8). Folder names
# are the manifest's; they reach the model as part of each room's path (see README, "Folder names").""",
"""# Install arms (manifest section 7) and the four candidate parts in their order (section 8). The part keys name the
# expect files; the output folders are PART_FOLDER's neutral names below (they reach the model in each room's path)."""),
("""# Output folders, as the manifest names them (section 8). They reach the model inside each room's path, so a
# folder that names or abbreviates a module is seen by the model; to use neutral names instead (the fix round
# used part-1, part-2, ...), change these two maps before the freeze. Nothing else depends on the names.
declare -A PART_FOLDER=([ju-existing]=ju-existing [ju-new]=ju-new [mi-existing]=mi-existing [mi-new]=mi-new)
declare -A E23_FOLDER=([job-underwriter-7]=e23/job-underwriter-7 [job-underwriter-8]=e23/job-underwriter-8
                       [mock-interview-9]=e23/mock-interview-9 [mock-interview-10]=e23/mock-interview-10
                       [mock-interview-11]=e23/mock-interview-11 [mock-interview-12]=e23/mock-interview-12
                       [mock-interview-13]=e23/mock-interview-13)""",
"""# Output folders (manifest section 8, owner question 26). They reach the model inside each room's path, and
# evals/README.md never names a room for its module, so they are neutral: part-1 and part-2 for the existing
# job-underwriter and mock-interview rooms, as in the fix round's baseline, part-4 and part-5 for the new ones, and
# e23/part-1 to e23/part-7 for the replays in section 5's order. Taken on 16 November by the session under the
# owner's approval of the manifest's recommendations; reversible before the freeze, by these two maps alone.
declare -A PART_FOLDER=([ju-existing]=part-1 [ju-new]=part-4 [mi-existing]=part-2 [mi-new]=part-5)
declare -A E23_FOLDER=([job-underwriter-7]=e23/part-1 [job-underwriter-8]=e23/part-2
                       [mock-interview-9]=e23/part-3 [mock-interview-10]=e23/part-4
                       [mock-interview-11]=e23/part-5 [mock-interview-12]=e23/part-6
                       [mock-interview-13]=e23/part-7)"""),
])
