from pathlib import Path
K = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/runkit")
def apply(name, pairs):
    f = K / name; t = f.read_text(encoding="utf-8")
    for i, (o, n) in enumerate(pairs):
        c = t.count(o); assert c == 1, (name, i, c, o[:100]); t = t.replace(o, n, 1)
    f.write_text(t, encoding="utf-8"); print(name, len(pairs))
apply("dry/dry_run.sh", [
("""#   D. the rehearsal: a scratch clone with variant A's candidate committed on 7b56c17, freeze to run_step""",
"""#   D. the rehearsal: a scratch clone with variant A's candidate committed on the branch's merge-back commit
#      5696742 (a merge whose tree equals 7b56c17's), freeze to run_step; the same paths on a parent with a
#      different tree (7b56c17's own parent) are refused; the neutral folder names agree in plan, recovery and runs"""),
("""say ""; say "D. The rehearsal: variant A's candidate committed on 7b56c17 in a scratch clone"
R=$D/rehearsal; mkdir -p "$R"
git clone -q --shared --no-checkout /home/user/tuesday "$R/repo"
G() { git -C "$R/repo" "$@"; }
G config user.name "dry run"; G config user.email "$DUMMY"
G update-ref refs/remotes/origin/main 7b56c174218e6288bf5f8b8a08a90cf38633b4e8
G checkout -q --detach 7b56c17
cut -f2 "$BUILD/patches/C.name-status" | while read -r p; do cp "$BUILD/tree/$p" "$R/repo/$p"; done
G add -A; G commit -q -m "Rehearsal candidate: variant A's paths on 7b56c17 (dry run only)"
CAND=$(G rev-parse HEAD); say "  rehearsal candidate $CAND on $(G rev-parse HEAD^)"
RE=(env REPO="$R/repo" M="$R/M" PINS="$R/pins" CLI_VERSION="$CLI_DRY")
check 1 "freeze refuses a candidate that is on no remote branch" "${RE[@]}" "$K/freeze.sh" "$CAND" "$K/expected/expected-A.json"
check 1 "freeze refuses the baseline itself as the candidate (not one commit on top)" "${RE[@]}" FREEZE_ALLOW_UNPUSHED=1 "$K/freeze.sh" 7b56c17 "$K/expected/expected-A.json"
""",
"""say ""; say "D. The rehearsal: variant A's candidate committed on the branch's merge-back commit, in a scratch clone"
R=$D/rehearsal; mkdir -p "$R"
git clone -q --shared --no-checkout /home/user/tuesday "$R/repo"
G() { git -C "$R/repo" "$@"; }
G config user.name "dry run"; G config user.email "$DUMMY"
G update-ref refs/remotes/origin/main 7b56c174218e6288bf5f8b8a08a90cf38633b4e8
MERGE=5696742555832dd6e98aff72bafe3c31fa2d1738   # HEAD of claude/skill-job-underwriter-95xjz8: merges main (#20) back
check 0 "the candidate's parent, $MERGE, is a merge commit whose tree equals 7b56c17's" \\
  bash -c "[ \\$(git -C '$R/repo' rev-list --parents -n 1 $MERGE | wc -w) -eq 3 ] && [ \\$(git -C '$R/repo' rev-parse $MERGE^{tree}) = \\$(git -C '$R/repo' rev-parse 7b56c17^{tree}) ]"
on_parent() {  # on_parent <parent> <message>: variant A's candidate paths committed on <parent>; prints the SHA
  G checkout -q --detach "$1"
  cut -f2 "$BUILD/patches/C.name-status" | while read -r p; do cp "$BUILD/tree/$p" "$R/repo/$p"; done
  G add -A; G commit -q -m "$2"; G rev-parse HEAD
}
CAND_OTHER=$(on_parent 7b56c17^ "Rehearsal candidate: variant A's paths on 7b56c17's parent, another tree (dry run only)")
CAND=$(on_parent "$MERGE" "Rehearsal candidate: variant A's paths on the merge-back commit (dry run only)")
say "  rehearsal candidate $CAND on $(G rev-parse HEAD^) (tree $(G rev-parse HEAD^^{tree}); 7b56c17's tree $(G rev-parse 7b56c17^{tree}))"
say "  the same paths on a parent with another tree: $CAND_OTHER on $(G rev-parse "$CAND_OTHER^") (tree $(G rev-parse "$CAND_OTHER^^{tree}"))"
RE=(env REPO="$R/repo" M="$R/M" PINS="$R/pins" CLI_VERSION="$CLI_DRY")
check 1 "freeze refuses a candidate that is on no remote branch" "${RE[@]}" "$K/freeze.sh" "$CAND" "$K/expected/expected-A.json"
grep_check "  ... after accepting its parent: a merge whose tree equals the baseline's" "$LAST" "one commit on $MERGE, whose tree [0-9a-f]{40} equals the baseline"
grep_check "  ... and it stops on the remote branch, not on the parent" "$LAST" 'is on no remote branch'
check 1 "freeze refuses a candidate whose parent's tree is not the baseline's (the same paths on 7b56c17's parent)" "${RE[@]}" FREEZE_ALLOW_UNPUSHED=1 "$K/freeze.sh" "$CAND_OTHER" "$K/expected/expected-A.json"
grep_check "  ... naming the parent's tree and the baseline's" "$LAST" "parent [0-9a-f]{40} has tree [0-9a-f]{40}, not the baseline [0-9a-f]{40}'s tree [0-9a-f]{40}"
check 1 "freeze refuses the baseline itself as the candidate (its parent's tree is not the baseline's)" "${RE[@]}" FREEZE_ALLOW_UNPUSHED=1 "$K/freeze.sh" 7b56c17 "$K/expected/expected-A.json"
grep_check "  ... on the parent's tree" "$LAST" "has tree [0-9a-f]{40}, not the baseline"
check 1 "freeze refuses the merge-back commit itself as the candidate (a merge, not one commit on one parent)" "${RE[@]}" FREEZE_ALLOW_UNPUSHED=1 "$K/freeze.sh" "$MERGE" "$K/expected/expected-A.json"
grep_check "  ... as a merge" "$LAST" 'not one commit on one parent'
"""),
("""check 0 "freeze with variant A's values passes" "${RE[@]}" FREEZE_ALLOW_UNPUSHED=1 "$K/freeze.sh" "$CAND" "$K/expected/expected-A.json"
grep -E '^  (ok|STOP) |all checks passed|done:' "$LAST" | cut -c1-160 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
""",
"""check 0 "freeze with variant A's values passes, the candidate on the merge-back commit" "${RE[@]}" FREEZE_ALLOW_UNPUSHED=1 "$K/freeze.sh" "$CAND" "$K/expected/expected-A.json"
grep -E "^  (ok|STOP) |all checks passed|done:|candidate's parent" "$LAST" | cut -c1-160 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
check 0 "freeze.json logs the candidate's parent SHA and tree beside the baseline's SHA and tree" python3 -I -B -c '
import json, sys
f = json.load(open(sys.argv[1]))["facts"]
assert f["candidate_parent_sha"] == sys.argv[2] and f["baseline_sha"] == sys.argv[3], f
assert f["candidate_parent_tree"] == f["baseline_tree"] and len(f["baseline_tree"]) == 40, f
print("parent", f["candidate_parent_sha"], "tree", f["candidate_parent_tree"], "| baseline", f["baseline_sha"], "tree", f["baseline_tree"])
' "$R/M/frozen/freeze.json" "$MERGE" 7b56c174218e6288bf5f8b8a08a90cf38633b4e8
show "$LAST"
"""),
("""for s in "haiku quality" "sonnet quality" "opus quality" "all explicit"; do set -- $s
  check 0 "run_step $1 $2 --plan: every command line accepted by the pinned runner with the priced plan" "${RE[@]}" bash "$FK/run_step.sh" "$1" "$2" --plan
  tail -1 "$LAST" | sed 's/^/          /' | tee -a "$OUT" > /dev/null
done""",
"""for s in "haiku quality" "sonnet quality" "opus quality" "all explicit"; do set -- $s
  check 0 "run_step $1 $2 --plan: every command line accepted by the pinned runner with the priced plan" "${RE[@]}" bash "$FK/run_step.sh" "$1" "$2" --plan
  tail -1 "$LAST" | sed 's/^/          /' | tee -a "$OUT" > /dev/null
  [ "$1" = haiku ] && PLAN_HAIKU=$LAST
done
# The neutral folder names (owner question 26): the plan's --out folders are kit.env's maps, and no folder names a module.
for f in alone/part-1 alone/part-4 alone/part-2 alone/part-5 tuesday/part-1 tuesday/part-4 tuesday/part-2 tuesday/part-5 \\
         e23/part-1 e23/part-2 e23/part-3 e23/part-4 e23/part-5 e23/part-6 e23/part-7; do
  grep_check "plan: an --out folder is \\$RUNS/haiku/$f" "$PLAN_HAIKU" -- "--out \\\\\\$RUNS/haiku/$f\\$"
done
check 1 "plan: no --out folder names or abbreviates a module" grep -E -- '--out [^ ]*/(ju-|mi-|job-underwriter|mock-interview)' "$PLAN_HAIKU"
grep_check "plan: the E23 replay into e23/part-1 reads job-underwriter 7's case file" "$PLAN_HAIKU" 'e23-job-underwriter-7\\.json .*--out \\$RUNS/haiku/e23/part-1$'
grep_check "plan: the E23 replay into e23/part-7 reads mock-interview 13's case file" "$PLAN_HAIKU" 'e23-mock-interview-13\\.json .*--out \\$RUNS/haiku/e23/part-7$'"""),
("""check 0 "run_step haiku quality --recovery prints the killed-run and grade-gap commands" "${RE[@]}" bash "$FK/run_step.sh" haiku quality --recovery
sed -n '1,9p' "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
""",
"""check 0 "run_step haiku quality --recovery prints the killed-run and grade-gap commands" "${RE[@]}" bash "$FK/run_step.sh" haiku quality --recovery
sed -n '1,9p' "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
REC=$LAST
grep_check "recovery: the killed-run move for the new job-underwriter rooms uses runs/haiku/alone/part-4" "$REC" "^## haiku alone ju-new|--skill job-underwriter --eval 7 .*--out $R/M/runs/haiku/alone/part-4 --killed --move"
grep_check "recovery: the grade-gap command for the new mock-interview rooms uses runs/haiku/tuesday/part-5" "$REC" "--out $R/M/runs/haiku/tuesday/part-5 --graders 2 --grade-gaps --move"
grep_check "recovery: the E23 replays recover into runs/haiku/e23/part-1 to part-7" "$REC" "--out $R/M/runs/haiku/e23/part-7 --killed --move"
check 1 "recovery: no folder names or abbreviates a module" grep -E -- '--out [^ ]*/(ju-|mi-|job-underwriter|mock-interview)' "$REC"
"""),
("""check 0 "haiku at 44%: starts, runs its 15 command lines through the stubbed runner, guard reads, seals" "${SIM[@]}" bash "$FK/run_step.sh" haiku quality
tail -22 "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
""",
"""check 0 "haiku at 44%: starts, runs its 15 command lines through the stubbed runner, guard reads, seals" "${SIM[@]}" bash "$FK/run_step.sh" haiku quality
tail -22 "$LAST" | cut -c1-200 | sed 's/^/          /' | tee -a "$OUT" > /dev/null
check 0 "the simulated step's logs and seal use the neutral folders and no module-named one" bash -c '
cd "$1/M" || exit 9
for f in alone/part-1 alone/part-4 alone/part-2 alone/part-5 tuesday/part-1 tuesday/part-4 tuesday/part-2 tuesday/part-5 \\
         e23/part-1 e23/part-2 e23/part-3 e23/part-4 e23/part-5 e23/part-6 e23/part-7; do
  [ -f "runs/haiku/$f.log" ] || { echo "no runs/haiku/$f.log"; exit 1; }
  ls -d sealed/haiku-quality-*/haiku/$f > /dev/null 2>&1 || { echo "no sealed folder for $f"; exit 1; }
done
bad=$(find runs/haiku sealed -name "ju-*" -o -name "mi-*" -o -name "job-underwriter-*" -o -name "mock-interview-*" | grep -v "\\.\\(md\\|json\\|jsonl\\)$" | head -3)
[ -z "$bad" ] || { echo "module-named folders: $bad"; exit 1; }
echo "15 logs and 15 sealed folders, all neutral"' _ "$R"
show "$LAST"
"""),
])
