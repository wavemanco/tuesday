from pathlib import Path
K = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/runkit")
def apply(name, pairs):
    f = K / name; t = f.read_text(encoding="utf-8")
    for i, (o, n) in enumerate(pairs):
        c = t.count(o); assert c == 1, (name, i, c, o[:100]); t = t.replace(o, n, 1)
    f.write_text(t, encoding="utf-8"); print(name, len(pairs))
apply("dry/dry_run.sh", [
("""  if grep -qE "$3" "$2"; then pass=$((pass+1)); say "  ok    $1"; else fail=$((fail+1)); say "  FAIL  $1 (no /$3/ in $2)"; fi""",
 """  if grep -qE -e "$3" "$2"; then pass=$((pass+1)); say "  ok    $1"; else fail=$((fail+1)); say "  FAIL  $1 (no /$3/ in $2)"; fi"""),
("""  grep_check "plan: an --out folder is \\$RUNS/haiku/$f" "$PLAN_HAIKU" -- "--out \\\\\\$RUNS/haiku/$f\\$\"""",
 """  grep_check "plan: an --out folder is \\$RUNS/haiku/$f" "$PLAN_HAIKU" "--out \\\\\\$RUNS/haiku/$f\\$\""""),
("""grep_check "recovery: the killed-run move for the new job-underwriter rooms uses runs/haiku/alone/part-4" "$REC" "^## haiku alone ju-new|--skill job-underwriter --eval 7 .*--out $R/M/runs/haiku/alone/part-4 --killed --move\"""",
 """grep_check "recovery: the killed-run move for the new job-underwriter rooms uses runs/haiku/alone/part-4" "$REC" "--skill job-underwriter --eval 7 .*--out $R/M/runs/haiku/alone/part-4 --killed --move\""""),
("""bad=$(find runs/haiku sealed -name "ju-*" -o -name "mi-*" -o -name "job-underwriter-*" -o -name "mock-interview-*" | grep -v "\\.\\(md\\|json\\|jsonl\\)$" | head -3)""",
 """bad=$(find runs/haiku sealed -type d \\( -name "ju-*" -o -name "mi-*" -o -name "job-underwriter*" -o -name "mock-interview*" \\) | head -3)"""),
])
