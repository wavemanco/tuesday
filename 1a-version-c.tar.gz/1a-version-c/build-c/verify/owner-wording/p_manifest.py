from pathlib import Path
F = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/build-c/build/make_manifest.py")
P = []
P.append(('''edits_sha = sha(C / "edits.json")''',
'''edits_sha = sha(C / "edits.json")
# The owner's final wording (16 November): the sentence and the README line, as the shipped files carry them.
DUTY_VO = ("I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please "
           "confirm who sent it. It's your call.")
README_VO = ("It's an AI assistant and can make mistakes. It points out warning signs in what you share, but it can't "
             "confirm who an employer, recruiter or sender really is. Please check before you act; the decision is "
             "always yours.")
assert (TREE / "skills/job-underwriter/references/risk-and-decision.md").read_text(encoding="utf-8").count(DUTY_VO) == 1
assert (TREE / "skills/mock-interview/references/output-template.md").read_text(encoding="utf-8").count(DUTY_VO) == 3
for m in ("job-underwriter", "mock-interview"):
    assert (TREE / "skills" / m / "README.md").read_text(encoding="utf-8").count(README_VO) == 1, m
# The spill detector (VS6) and its baselines over the 1,220 saved fix-round runs (build/spill_baseline.py).
SPILL = json.loads((OUT / "spill-baseline.json").read_text(encoding="utf-8"))
DETECTOR = "can get this wrong"
assert SPILL["runs"] == 1220 and SPILL["phrases"][DETECTOR]["runs"] == 0


def spill(p, label=None):
    r = SPILL["phrases"][p]
    return f"{label or chr(34) + p + chr(34)} {r['runs']}" + (f" ({r['occurrences']} occurrences)" if r["occurrences"] else "")


SPILL_TEXT = (f"baseline {spill(DETECTOR, 'the detector')} of the 1,220 saved fix-round runs over responses, saved "
              f"files, grades and streams; {spill('before you reply or send anything')}, {spill(chr(105) + 't' + chr(39) + 's your call')}"
              f" runs, {spill('it' + chr(0x2019) + 's your call', 'its curly-apostrophe form')}, and the earlier "
              f"detector {spill('deciding whether to go ahead')}")'''))
P.append(('''    "whole, and a chat-run process gets no verdict. Each warning says once that checking who sent it, through contact "
    "details the candidate finds, and deciding whether to go ahead are the candidate's. | 1 |")''',
'''    "whole, and a chat-run process gets no verdict. Each warning says once, in the owner's final wording, \\"" + DUTY_VO
    + "\\" | 1 |")'''))
P.append(('''    "| The limits line (both module READMEs) | \\"The skill flags warning signs in what you share but cannot verify an "
    "employer, a recruiter or a sender; the checks, and the decision to go ahead, are yours.\\" | 1 |")''',
'''    "| The limits line (both module READMEs), the owner's final wording | \\"" + README_VO + "\\" | 1 |")'''))
P.append(('''    "#10, 11 #7, 12 #10; `no_responsibility_line`: job-underwriter 9 #17, 10 #17): once, in the warning, with all "
    "three parts (who sent it, the check through contact details the candidate finds, the decision), no label, not "
    "the watch-out line; absent where no warning is given.\\n\\n"''',
'''    "#10, 11 #7, 12 #10; `no_responsibility_line`: job-underwriter 9 #17, 10 #17): once, in the warning, with all "
    "three parts of the owner's final wording (it goes only on what was shared and may be wrong; confirm who sent it "
    "before replying or sending anything; the call is the candidate's), no label, not the watch-out line; absent where "
    "no warning is given. A generic \\"the decision is yours\\", or a check instruction alone, is not the sentence.\\n\\n"'''))
P.append(('''    "and mock-interview 13 it is counted by a detector frozen here, a case-insensitive match on \\"deciding whether to "
    "go ahead\\" over chat and saved files (0 of the 1,220 saved fix-round runs), and mock-interview 13 #2 failures "
    "that carry it are reported apart.\\n"''',
'''    "and mock-interview 13 it is counted by a detector frozen here, a case-insensitive match on \\"" + DETECTOR + "\\" "
    "over chat and saved files (" + SPILL_TEXT + "), and mock-interview 13 #2 failures that carry it are reported "
    "apart.\\n"'''))
P.append(('''    "a scam, never of a party or the whole; every warning carries once the sentence \\"Checking who sent it, through "
    "contact details you find yourself, and deciding whether to go ahead are yours.\\" In job-underwriter 9 and 10 "''',
'''    "a scam, never of a party or the whole; every warning carries once the sentence, in the owner's final wording "
    "(16 November), \\"" + DUTY_VO + "\\" and both module READMEs the line \\"" + README_VO + "\\"; both replace the "
    "earlier example wording. In job-underwriter 9 and 10 "'''))
P.append(('''    "four signs; in both, a sign that takes no verdict keeps its entry's class and severity. *Recommended:* confirm "
    "all four as built; each follows the decision's words or keeps a plan bar the decision did not change. The "
    "alternative to (a), accepting a hedged verdict on the whole wherever it rests on such a request, is a fixture "
    "and skill-text edit before the case hashes freeze.\\n"''',
'''    "four signs; in both, a sign that takes no verdict keeps its entry's class and severity. *Taken as recommended, "
    "16 November, by the session under the owner's approval of the manifest's recommendations; reversible before the "
    "freeze:* all four confirmed as built; each follows the decision's words or keeps a plan bar the decision did not "
    "change. The alternative to (a), accepting a hedged verdict on the whole wherever it rests on such a request, is a "
    "fixture and skill-text edit before the case hashes freeze.\\n"'''))
P.append(('''    "line, and the plugin tree ships both; a Tuesday user reads neither in the hub,''',
'''    "line (the owner's final wording above), and the plugin tree ships both; a Tuesday user reads neither in the hub,'''))
# owner summary
P.append(('''     "a request for money, a cheque or those details is likely a scam, never the firm, the sender or a person, and "
     "each warning says once that checking who sent it, and deciding whether to go ahead, are yours. Routine "
     "onboarding, chat scheduling and small genuine employers are left alone.")''',
'''     "a request for money, a cheque or those details is likely a scam, never the firm, the sender or a person, and "
     "each warning says once, in your final wording, \\"" + DUTY_VO + "\\" Routine onboarding, chat scheduling and "
     "small genuine employers are left alone.")'''))
P.append(('''     "- **Both module READMEs:** \\"The skill flags warning signs in what you share but cannot verify an employer, a "
     "recruiter or a sender; the checks, and the decision to go ahead, are yours.\\"")''',
'''     "- **Both module READMEs**, in your final wording: \\"" + README_VO + "\\"")'''))
t = F.read_text(encoding="utf-8")
for i, (o, n) in enumerate(P):
    c = t.count(o)
    assert c == 1, (i, c, o[:120])
    t = t.replace(o, n, 1)
F.write_text(t, encoding="utf-8")
print(len(P), "replacements")
