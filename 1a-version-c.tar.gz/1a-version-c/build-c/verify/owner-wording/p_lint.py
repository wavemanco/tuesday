from pathlib import Path
F = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/build-c/build/lint_fixtures.py")
P = []
P.append(('''   off-domain sign; the funder example names its two requests; the responsibility sentence needs all three parts.
''', '''   off-domain sign; the funder example names its two requests; the responsibility sentence needs all three parts.
3e. The owner's final wording (VO, 16 November): the old responsibility sentence, the old README line and the phrase
   "through contact details you find yourself" appear nowhere in shipped text (every file of the candidate and
   rehearsal trees, and every member of each .skill archive, decompressed); the new sentence appears exactly in the
   rule bullet and both examples of each copy of the two reference files (sources, Tuesday references, dist/ copies
   and archive members) and nowhere else; the new README line exactly once in each copy of the two module READMEs and
   nowhere else; the two clauses describe its three parts and never name "through contact details" as part of it;
   and neither the sentence nor the README line shares a run of three content words with any fixture prompt or
   canned page (check_skills' own tokens and stopwords).
'''))
P.append(('''    for part in ("It needs all three parts, who sent it, the check through contact details the candidate finds, "
                 "and the decision: a generic 'the decision is yours', or a check instruction alone, is not the "
                 "sentence", "a plain sentence that says, in substance, that checking who sent",
                 "through contact details the candidate finds themselves", "deciding whether to go ahead are the "
                 "candidate's", "The response says it once", "carries no label", "is not the watch-out line"):
        say(part in clause, f"{skill} responsibility_line says {part!r}")''',
'''    for part in ("It needs all three parts, that it goes only on what was shared and may be wrong, that the "
                 "candidate confirms who sent it before replying or sending anything, and that the call is the "
                 "candidate's: a generic 'the decision is yours', or a check instruction alone, is not the sentence",
                 "carries the responsibility sentence: plain words, one sentence or a few, that say, in substance, "
                 "that the warning goes only on what the candidate has shared and may be wrong",
                 "that the candidate should confirm who sent", "before replying or sending anything, and that the call "
                 "is the candidate's", "The response says it once", "carries no label", "is not the watch-out line"):
        say(part in clause, f"{skill} responsibility_line says {part!r}")
    for gone in ("through contact details", "deciding whether to go ahead", "checking who sent"):
        say(gone not in clause, f"{skill} responsibility_line (VO) no longer says {gone!r}")'''))
P.append(('''             "an `unknown` entry's question", "may not come from who it names are no such warning and no such sentence",
             "It needs all three parts"):
    say(part in jcl["no_responsibility_line"], f"no_responsibility_line says {part!r}")''',
'''             "an `unknown` entry's question", "may not come from who it names are no such warning and no such sentence",
             "It needs all three parts", "no sentence of it says, in substance, that the warning goes only on what the "
             "candidate has shared and may be wrong, that the candidate should confirm who sent the material before "
             "replying or sending anything, and that the call is the candidate's",
             "a generic 'the decision is yours', or a check instruction alone, is not the sentence"):
    say(part in jcl["no_responsibility_line"], f"no_responsibility_line says {part!r}")
for gone in ("through contact details", "deciding whether to go ahead", "checking who sent"):
    say(gone not in jcl["no_responsibility_line"], f"no_responsibility_line (VO) no longer says {gone!r}")'''))
P.append(('''DUTY = "Checking who sent it, through contact details you find yourself, and deciding whether to go ahead are yours."''',
'''DUTY = ("I'm going only on what you've shared, and I can get this wrong. Before you reply or send anything, please "
        "confirm who sent it. It's your call.")
OLD_DUTY = "Checking who sent it, through contact details you find yourself, and deciding whether to go ahead are yours."
OLD_README_LINE = ("The skill flags warning signs in what you share but cannot verify an employer, a recruiter or a "
                   "sender; the checks, and the decision to go ahead, are yours.")
OLD_PHRASE = "through contact details you find yourself"
PARTS_RD = ("that the warning goes only on what the candidate has shared and can be wrong, that the candidate should "
            "confirm who sent it before replying or sending anything, and that the call is theirs: \\"" + DUTY + "\\"")
PARTS_OT = ("- It says once, in plain words, that the warning goes only on what the candidate has shared and can be "
            "wrong, that the candidate should confirm who sent the invite before replying or sending anything, and "
            "that the call is theirs: \\"" + DUTY + "\\"")'''))
P.append(('''                                      "- **The check and the decision are the candidate's.**", "\\"" + DUTY + "\\"",''',
'''                                      "- **The check and the decision are the candidate's.**", "\\"" + DUTY + "\\"",
                                      PARTS_RD,'''))
P.append(('''                                    "suggests it may be one, hedged or not", "\\"" + DUTY + "\\"",''',
'''                                    "suggests it may be one, hedged or not", "\\"" + DUTY + "\\"", PARTS_OT,
                                    "rather than any in the invite. " + DUTY + " If you want the invite's requests",
                                    "send no money, documents or bank details through the chat. " + DUTY + " If you "
                                    "want the invite weighed",'''))
P.append(('''README_LINE = ("The skill flags warning signs in what you share but cannot verify an employer, a recruiter or a "
               "sender; the checks, and the decision to go ahead, are yours.")''',
'''README_LINE = ("It's an AI assistant and can make mistakes. It points out warning signs in what you share, but it can't "
               "confirm who an employer, recruiter or sender really is. Please check before you act; the decision is "
               "always yours.")'''))
P.append(('''shipped = [p for p in (TREE / "skills").rglob("*.md")] + [p for p in (TREE / "skills").rglob("SKILL.md")]''',
'''# 3e. the owner's final wording (VO): the old texts nowhere, the new ones exactly where expected, in every copy
import io  # noqa: E402
import zipfile  # noqa: E402
REH = C / "tree-rehearsal"
RD_COPIES = ("skills/job-underwriter/references/risk-and-decision.md", "skills/tuesday/references/risk-and-decision.md",
             "dist/claude-code/job-underwriter/references/risk-and-decision.md",
             "dist/claude-code/tuesday/references/risk-and-decision.md",
             "dist/plugin/tuesday/skills/job-underwriter/references/risk-and-decision.md",
             "dist/plugin/tuesday/skills/tuesday/references/risk-and-decision.md",
             "dist/job-underwriter.skill!job-underwriter/references/risk-and-decision.md",
             "dist/tuesday.skill!tuesday/references/risk-and-decision.md")
OT_COPIES = tuple(p.replace("risk-and-decision", "output-template").replace("job-underwriter", "mock-interview")
                  .replace("tuesday/references/output", "tuesday/references/output") for p in RD_COPIES)
OT_COPIES = ("skills/mock-interview/references/output-template.md", "skills/tuesday/references/output-template.md",
             "dist/claude-code/mock-interview/references/output-template.md",
             "dist/claude-code/tuesday/references/output-template.md",
             "dist/plugin/tuesday/skills/mock-interview/references/output-template.md",
             "dist/plugin/tuesday/skills/tuesday/references/output-template.md",
             "dist/mock-interview.skill!mock-interview/references/output-template.md",
             "dist/tuesday.skill!tuesday/references/output-template.md")
README_COPIES = tuple(f"{root}{m}/README.md" for m in ("job-underwriter", "mock-interview")
                      for root in ("skills/", "dist/claude-code/", "dist/plugin/tuesday/skills/")) + \\
                ("dist/job-underwriter.skill!job-underwriter/README.md", "dist/mock-interview.skill!mock-interview/README.md")


def shipped_texts(root):
    """Every file of a tree as text, and every member of each .skill (zip) archive, decompressed."""
    out = {}
    for p in sorted(root.rglob("*")):
        if not p.is_file() or "__pycache__" in p.parts:
            continue
        rel = p.relative_to(root).as_posix()
        b = p.read_bytes()
        if b[:4] == b"PK\\x03\\x04":
            with zipfile.ZipFile(io.BytesIO(b)) as z:
                for m in z.namelist():
                    out[f"{rel}!{m}"] = z.read(m).decode("utf-8", "replace")
        else:
            out[rel] = b.decode("utf-8", "replace")
    return out


WANT = {**{p: 1 for p in RD_COPIES}, **{p: 3 for p in OT_COPIES}}
for label, root in (("candidate", TREE), ("rehearsal", REH)):
    texts = shipped_texts(root)
    members = sum("!" in k for k in texts)
    for old, name in ((OLD_DUTY, "the old responsibility sentence"), (OLD_README_LINE, "the old README line"),
                      (OLD_PHRASE, repr(OLD_PHRASE))):
        hits = {k: t.count(old) for k, t in texts.items() if old in t}
        say(not hits, f"{label}: {name} appears nowhere in {len(texts)} texts ({members} archive members) {hits or ''}")
    got = {k: t.count(DUTY) for k, t in texts.items() if DUTY in t}
    say(got == WANT, f"{label}: the new sentence in exactly the expected places: "
                     f"{sum(got.values())} times in {len(got)} texts (want {sum(WANT.values())} in {len(WANT)})"
                     + ("" if got == WANT else f" {sorted(set(got.items()) ^ set(WANT.items()))}"))
    got = {k: t.count(README_LINE) for k, t in texts.items() if README_LINE in t}
    want = {p: 1 for p in README_COPIES}
    say(got == want, f"{label}: the new README line once in each of the {len(want)} README copies and nowhere else"
                     + ("" if got == want else f" {sorted(set(got.items()) ^ set(want.items()))}"))
    for k in OT_COPIES:
        t = texts[k]
        say(t.count("It's your call.") == 3, f"{label}: {k}: 'It's your call.' three times, in the sentence only")
# the answer-key check, for the new texts: no three content words in a row shared with any fixture prompt or page
_spec = importlib.util.spec_from_file_location("cs_lint", TREE / "ci" / "check_skills.py")
sys.path.insert(0, str(TREE / "ci"))
cs = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(cs)
sys.path.pop(0)
index = {}
n_texts = 0
for skill in ("job-underwriter", "mock-interview", "resume-tailor"):
    cases = json.loads((TREE / "skills" / skill / "evals" / "evals.json").read_text())["evals"]
    for where, t in cs.fixture_haystack(cases):
        n_texts += 1
        toks = [x for x in cs.key_tokens(cs.key_text(t)) if x not in cs.ANSWER_KEY_STOP]
        for run in cs.key_runs(toks, cs.QUOTED_RUN):
            index.setdefault(run, f"{skill} {where}")
for name, t in (("the new sentence", DUTY), ("the new README line", README_LINE)):
    toks = [x for x in cs.key_tokens(cs.key_text(t)) if x not in cs.ANSWER_KEY_STOP]
    hit = cs.shared_run(toks, cs.QUOTED_RUN, index)
    say(hit is None, f"{name}: no run of {cs.QUOTED_RUN} content words shared with the {n_texts} fixture prompts and "
                     f"pages of the three modules {hit or ''}")

shipped = [p for p in (TREE / "skills").rglob("*.md")] + [p for p in (TREE / "skills").rglob("SKILL.md")]'''))
P.append(('''import json
import subprocess
import sys
from pathlib import Path''', '''import importlib.util
import json
import subprocess
import sys
from pathlib import Path'''))
t = F.read_text(encoding="utf-8")
for i, (o, n) in enumerate(P):
    c = t.count(o)
    assert c == 1, (i, c, o[:100])
    t = t.replace(o, n, 1)
F.write_text(t, encoding="utf-8")
print(len(P), "replacements")
