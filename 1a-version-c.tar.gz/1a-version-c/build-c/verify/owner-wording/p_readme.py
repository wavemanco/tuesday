from pathlib import Path
K = Path("/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/runkit")
def apply(name, pairs):
    f = K / name; t = f.read_text(encoding="utf-8")
    for i, (o, n) in enumerate(pairs):
        c = t.count(o); assert c == 1, (name, i, c, o[:100]); t = t.replace(o, n, 1)
    f.write_text(t, encoding="utf-8"); print(name, len(pairs))
apply("README.md", [
("""1. **Candidate commit.** Commit variant C on top of `7b56c17`: the source edits, then `ci/sync.py` and
   `ci/package.py`. Push it. Note the SHA.
""",
"""1. **Candidate commit.** Commit version C as one commit on a parent whose tree equals `7b56c17`'s: the
   branch's merge-back commit `5696742`, HEAD of `claude/skill-job-underwriter-95xjz8`, the only pushable
   branch (never force-pushed). The source edits, then `ci/sync.py` and `ci/package.py`. Push it. Note the SHA.
"""),
("""       --out expected/expected-C.json --manifest <the manifest the owner approves>""",
"""       --out expect-c.json --manifest <the manifest the owner approves>"""),
("""| 1 | `./freeze.sh <candidate SHA> expected/expected-C.json` |""",
"""| 1 | `./freeze.sh <candidate SHA> expect-c.json` |"""),
("""| Part | Selection | Runs per arm |
|---|---|---:|
| `ju-existing` | `--skill job-underwriter --eval 1…6` | 40 |
| `ju-new` | `--eval 7…11` | 30 |
| `mi-existing` | `--skill mock-interview --eval 1…8` | 50 |
| `mi-new` | `--eval 9…13` | 25 |
| E23 replays | one `--cases $M/frozen/e23/e23-<module>-<id>.json` per call | 5 each |""",
"""| Part (expect file) | `--out` folder | Selection | Runs per arm |
|---|---|---|---:|
| `ju-existing` | `part-1` | `--skill job-underwriter --eval 1…6` | 40 |
| `ju-new` | `part-4` | `--eval 7…11` | 30 |
| `mi-existing` | `part-2` | `--skill mock-interview --eval 1…8` | 50 |
| `mi-new` | `part-5` | `--eval 9…13` | 25 |
| E23 replays | `e23/part-1` … `e23/part-7`, in section 5's order | one `--cases $M/frozen/e23/e23-<module>-<id>.json` per call | 5 each |"""),
("""**Output folders** (manifest section 8): `$M/runs/<haiku|sonnet|opus>/<alone|tuesday>/<ju-existing|ju-new|mi-existing|mi-new>`,
`$M/runs/<model>/e23/<module>-<id>`, `$M/runs/<model>/explicit.json`. Each command's output is beside its
folder as `<folder>.log`.""",
"""**Output folders** (manifest section 8, owner question 26): `$M/runs/<haiku|sonnet|opus>/<alone|tuesday>/<part-1|part-4|part-2|part-5>`
(existing job-underwriter, new job-underwriter, existing mock-interview, new mock-interview),
`$M/runs/<model>/e23/part-<1…7>` (job-underwriter 7 and 8, mock-interview 9 to 13), `$M/runs/<model>/explicit.json`.
Each command's output is beside its folder as `<folder>.log`. The expect files keep the part keys
(`$M/frozen/expect/<model>/<arm>/ju-new.json`, `…/e23/job-underwriter-7.json`): they are read by the runner and never
reach a room's path."""),
("""- **The candidate commit.** It is one commit on `7b56c17`, and both pins are on a remote branch.""",
"""- **The candidate commit.** It is one commit, on one parent, and that parent's tree equals `7b56c17`'s tree
  (`git rev-parse "$CAND^^{tree}"` against `"$BASE^{tree}"`): the branch's merge-back commit `5696742`, since the
  candidate cannot sit directly on `7b56c17` and the branch is never force-pushed. `freeze.json` logs the parent's
  SHA and tree beside the baseline's SHA and tree. Both pins are on a remote branch."""),
("""- **The output folder names reach the model.** Each room's path, and the plugin folder beside it, sits under
  the `--out` folder, and the CLI shows the room path to the model. The manifest's names (`ju-new`, `mi-new`,
  `e23/job-underwriter-7`) abbreviate or name the module. The fix round chose neutral `part-1` …
  `part-3` for that reason (evals/README.md, "Through Tuesday": a room never names its module). The kit
  uses the manifest's names as instructed. Two maps in `kit.env`, `PART_FOLDER` and `E23_FOLDER`, change
  them before the freeze; nothing else depends on them. This is the owner's decision.""",
"""- **The output folder names reach the model.** Each room's path, and the plugin folder beside it, sits under
  the `--out` folder, and the CLI shows the room path to the model. The draft's names (`ju-new`, `mi-new`,
  `e23/job-underwriter-7`) abbreviated or named the module, against evals/README.md ("Through Tuesday": a room
  never names its module). Question 26 is taken as recommended (16 November, by the session under the owner's
  approval of the manifest's recommendations; reversible before the freeze): neutral `part-1` and `part-2` for the
  existing rooms, as in the fix round's baseline, `part-4` and `part-5` for the new ones, and `e23/part-1` to
  `e23/part-7` for the replays. They are set in two maps in `kit.env`, `PART_FOLDER` and `E23_FOLDER`; the plan,
  the recovery commands and the seals read them from there, and nothing else depends on them."""),
("""- The rehearsal: a scratch clone with variant A's candidate committed on `7b56c17`, from freeze to
  every step's plan.""",
"""- The rehearsal: a scratch clone with variant A's candidate committed on the branch's merge-back commit
  `5696742` (a merge whose tree equals `7b56c17`'s), from freeze to every step's plan. The freeze accepts that
  parent and refuses the same candidate committed on a parent with a different tree (`7b56c17`'s own parent)."""),
])
