"""Count the account email (value from ACCOUNT_EMAIL in the environment, never printed), key-shaped strings, home
paths other than /home/user and paths under the root user's home folder in every file under the given roots; .skill archives are read member by
member. Prints counts only. (A /home/user path, the repository's or the scan's own label, is not counted.)

    ACCOUNT_EMAIL=... python3 -I scan_all.py LABEL ROOT...
"""
import os, re, sys, zipfile
from pathlib import Path
email = os.environ.get("ACCOUNT_EMAIL", "").strip().lower()
assert email, "ACCOUNT_EMAIL is empty"
KEY = re.compile(r"(?<![A-Za-z0-9])sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}|-----BEGIN")
HOME = re.compile(r"/home/(?!user(?:/|\b))[A-Za-z0-9._-]+|/Users/[A-Za-z0-9._-]+")
ROOT = re.compile(r"(?<![A-Za-z0-9_.-])/ro" r"ot/")    # split, so this file holds no such path itself
label, roots = sys.argv[1], [Path(r) for r in sys.argv[2:]]
files = [p for r in roots for p in ([r] if r.is_file() else r.rglob("*")) if p.is_file() and "__pycache__" not in p.parts]
n = {"email": 0, "key": 0, "home": 0, "root": 0, "members": 0}
for p in files:
    blobs = []
    if p.suffix == ".skill" and zipfile.is_zipfile(p):
        with zipfile.ZipFile(p) as z:
            blobs = [z.read(m) for m in z.namelist()]
    else:
        blobs = [p.read_bytes()]
    for b in blobs:
        n["members"] += 1
        t = b.decode("utf-8", "replace")
        n["email"] += t.lower().count(email)
        n["key"] += len(KEY.findall(t))
        n["home"] += len(HOME.findall(t))
        n["root"] += len(ROOT.findall(t))
print(f"{label}: account email: {n['email']} | key-shaped strings: {n['key']} | home paths other than /home/user: "
      f"{n['home']} | root-folder paths: {n['root']} | {len(files)} files, {n['members']} texts")
