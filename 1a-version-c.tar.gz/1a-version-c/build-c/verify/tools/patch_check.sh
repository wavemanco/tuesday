#!/bin/bash
# patch_check.sh BASE_COMMIT PATCH TREE OUT: apply PATCH with `git apply --binary` to a fresh `git archive BASE_COMMIT`
# in a scratch folder, then compare the result with TREE: the same file list, every byte, and every executable bit
# (the mode git records). Writes one line to OUT; exits 1 on any difference. Nothing in the repository is written.
set -euo pipefail
REPO=/home/user/tuesday; BASE=$1; PATCH=$2; TREE=$3; OUT=$4
W=$(dirname "$OUT")/patchcheck.$$
rm -rf "$W"; mkdir -p "$W"
git -C "$REPO" archive "$BASE" | tar -x -C "$W"
(cd "$W" && git apply --binary "$PATCH")
python3 -I -B - "$W" "$TREE" "$OUT" "$BASE" "$(basename "$(dirname "$PATCH")")/$(basename "$PATCH")" <<'PY'
import os, sys
from pathlib import Path
a, b, out, base, name = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), sys.argv[4], sys.argv[5]
def files(r): return {p.relative_to(r).as_posix(): p for p in r.rglob("*") if p.is_file() and "__pycache__" not in p.parts}
fa, fb = files(a), files(b)
bad = sorted(set(fa) ^ set(fb)) + [k for k in sorted(set(fa) & set(fb)) if fa[k].read_bytes() != fb[k].read_bytes()
                                    or bool(os.stat(fa[k]).st_mode & 0o111) != bool(os.stat(fb[k]).st_mode & 0o111)]
line = (f"same tree: {len(fa)} files, every byte and every executable bit (the mode git records), after git apply "
        f"--binary of {name} to a fresh git archive {base}" if not bad else f"DIFFERENT: {len(bad)} paths: {bad[:10]}")
out.write_text(line + "\n"); print(line)
sys.exit(1 if bad else 0)
PY
rm -rf "$W"
