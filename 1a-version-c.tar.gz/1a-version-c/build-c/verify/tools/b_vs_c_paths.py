"""Every path that differs between variant B (l1a/build-b) and version C (l1a/build-c), per tree, and the E23 files.

    python3 -I b_vs_c_paths.py B_DIR C_DIR OUT_FILE
Version C has no tree-harness/: its base, 7b56c17, holds phase H, so its head/ is compared with variant B's
tree-harness/ (8e72375 with phase H), which must be byte-identical.
"""
import filecmp, sys
from pathlib import Path
sys.dont_write_bytecode = True
B, Cc, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])


def files(root):
    return {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and "__pycache__" not in p.parts}


def differing(sb, sc):
    a, b = files(B / sb), files(Cc / sc)
    return sorted([p for p in a & b if not filecmp.cmp(B / sb / p, Cc / sc / p, shallow=False)]
                  + [p + " (only in B)" for p in a - b] + [p + " (only in C)" for p in b - a])


L = ["# Variant B (l1a/build-b) against version C (l1a/build-c): every differing path"]
for sub, title in (("tree", "tree/ (candidate)"), ("tree-rehearsal", "tree-rehearsal/")):
    d = differing(sub, sub)
    L.append(f"## {title}: {len(d)}")
    L += [f"{sub}/{p}" for p in d]
h = differing("tree-harness", "head")
L.append("## variant B's tree-harness/ (8e72375 + H) against version C's head/ (7b56c17): "
         + ("none (byte-identical)" if not h else ", ".join(h)))
d = differing("e23", "e23")
L.append(f"## e23/: {len(d)}")
L += [f"e23/{p}" for p in d]
out.write_text("\n".join(L) + "\n")
print("\n".join(L))
