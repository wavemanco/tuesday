"""Every path that differs between variant A (l1a/build) and variant B (l1a/build-b), per tree, and the E23 files.

    python3 -I a_vs_b_paths.py A_DIR B_DIR OUT_FILE
"""
import filecmp, sys
from pathlib import Path
sys.dont_write_bytecode = True
A, B, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])


def files(root):
    return {p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and "__pycache__" not in p.parts}


def differing(sub):
    a, b = files(A / sub), files(B / sub)
    return sorted([p for p in a & b if not filecmp.cmp(A / sub / p, B / sub / p, shallow=False)]
                  + [p + " (only in A)" for p in a - b] + [p + " (only in B)" for p in b - a])


L = ["# Variant A (l1a/build) against variant B (l1a/build-b): every differing path"]
for sub, title in (("tree", "tree/ (candidate)"), ("tree-rehearsal", "tree-rehearsal/")):
    L.append(f"## {title}")
    L += [f"{sub}/{p}" for p in differing(sub)]
rest = {s: differing(s) for s in ("tree-harness", "head")}
L.append("## tree-harness/ and head/: " + ("none" if not any(rest.values())
                                          else "; ".join(f"{s}/{p}" for s, ps in rest.items() for p in ps)))
L.append("## e23/")
L += [f"e23/{p}" for p in differing("e23")]
gen = [p for p in differing("tree") if not p.endswith("evals/evals.json")]
L.append("## generated copies of evals.json written by ci/sync.py or ci/package.py: "
         + ("none (evals/ is excluded from every .skill, build and the hub; the dist/ and skills/tuesday/ trees are "
            "byte-identical to variant A's)" if not gen else ", ".join(gen)))
out.write_text("\n".join(L) + "\n")
print("\n".join(L))
