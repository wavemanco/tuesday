#!/bin/bash
# gates.sh TREE LABEL LOGDIR: the four CI steps in the workflow's order, plus routing_variants --check.
export PYTHONDONTWRITEBYTECODE=1
T=$1; L=$2; D=$3
cd "$T" || exit 9
run() { local name=$1; shift; local s=$(date +%s); "$@" > "$D/$L-$name.txt" 2>&1; local rc=$?; echo "$L $name exit $rc ($(( $(date +%s) - s ))s)" >> "$D/$L-summary.txt"; }
: > "$D/$L-summary.txt"
run check_skills python3 ci/check_skills.py
run sync-check python3 ci/sync.py --check
run test_checks python3 ci/test_checks.py
run test_harness python3 evals/test_harness.py
run routing python3 evals/routing_variants.py --check
echo "$L done" >> "$D/$L-summary.txt"
