"""Scan files for the account email (value from the environment, never printed), key-shaped strings and home paths.

    ACCOUNT_EMAIL=... python3 -I scan.py FILE...
Prints counts only. A .skill (zip) file is scanned member by member, decompressed.
"""
import os, re, sys, zipfile
email = os.environ.get("ACCOUNT_EMAIL", "").strip()
print("email value present:", bool(email), "length", len(email))
KEYS = {
    "sk- (raw substring)": re.compile(r"sk-"),
    "sk- key-shaped": re.compile(r"(?<![A-Za-z0-9])sk-[A-Za-z0-9_-]{16,}"),
    "ghp_": re.compile(r"ghp_"), "github token shape": re.compile(r"gh[pousr]_[A-Za-z0-9]{20,}"),
    "AKIA": re.compile(r"AKIA"), "AKIA key-shaped": re.compile(r"AKIA[0-9A-Z]{16}"),
    "-----BEGIN": re.compile(r"-----BEGIN"),
}
HOME = re.compile(r"/home/([A-Za-z0-9._-]+)")
OTHER_HOME = re.compile(r"/Users/[A-Za-z0-9._-]+|[A-Za-z]:\\\\?Users\\\\?[A-Za-z0-9._-]+")
def texts(path):
    if path.endswith(".skill") and zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            for n in z.namelist():
                yield f"{path}!{n}", n + "\n" + z.read(n).decode("utf-8", "replace")
    else:
        yield path, open(path, "rb").read().decode("utf-8", "replace")
total = {}
for p in sys.argv[1:]:
    counts = {"email": 0, **{k: 0 for k in KEYS}, "home other than /home/user": 0, "/home/user": 0, "/Users or C:\\Users": 0}
    rawsk = []
    for name, t in texts(p):
        if email:
            counts["email"] += t.lower().count(email.lower())
        for k, rx in KEYS.items():
            ms = rx.findall(t); counts[k] += len(ms)
        for m in re.finditer(r".{0,12}sk-.{0,12}", t):
            rawsk.append(m.group(0))
        for m in HOME.finditer(t):
            counts["/home/user" if m.group(1) == "user" else "home other than /home/user"] += 1
        counts["/Users or C:\\Users"] += len(OTHER_HOME.findall(t))
    print(os.path.basename(p) if not p.endswith(".skill") else p.split("/")[-1], counts)
    if rawsk:
        ctx = sorted(set(re.sub(r"[^A-Za-z-]", "", s)[:30] for s in rawsk))
        print("   raw 'sk-' contexts (letters only, deduplicated, first 8):", ctx[:8], "of", len(ctx))
