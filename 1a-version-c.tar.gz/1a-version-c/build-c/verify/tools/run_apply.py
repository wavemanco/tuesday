"""Run build/apply.py unchanged except for its folder-name guard, which only admits folders named tree*.

    python3 -I run_apply.py APPLY_PY TREE PHASE...
The guard is replaced by one that admits only .../verify/fresh. Everything else, including the
edits.json it reads (beside apply.py's parent), is apply.py's own code.
"""
import sys
src_path = sys.argv[1]
src = open(src_path, encoding="utf-8").read()
old = 'assert "scratchpad" in str(tree) and tree.name.startswith("tree"), tree'
assert src.count(old) == 1, "guard line not found exactly once"
src = src.replace(old, 'assert "scratchpad" in str(tree) and str(tree).endswith("/verify/fresh"), tree', 1)
sys.argv = [src_path] + sys.argv[2:]
sys.dont_write_bytecode = True
exec(compile(src, src_path, "exec"), {"__name__": "__main__", "__file__": src_path})
