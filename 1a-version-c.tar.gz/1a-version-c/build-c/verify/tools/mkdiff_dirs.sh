#!/bin/bash
# mkdiff_dirs.sh BASE_TREE TREE OUT_PREFIX: git diff --binary of TREE against BASE_TREE (both plain folders), in a scratch index.
set -euo pipefail
BASE=$1; TREE=$2; OUT=$3
G=$(dirname "$OUT")/diffgen.$$
rm -rf "$G"; mkdir -p "$G"; git -C "$G" init -q .
cp -a "$BASE"/. "$G"/; find "$G" -name __pycache__ -type d -prune -exec rm -rf {} +
git -C "$G" add -A
find "$G" -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf {} +
cp -a "$TREE"/. "$G"/; find "$G" -name __pycache__ -type d -prune -exec rm -rf {} +
git -C "$G" add -A -N 2>/dev/null || true
git -C "$G" diff --binary > "$OUT.diff"
git -C "$G" diff --name-status > "$OUT.name-status"
rm -rf "$G"
