#!/bin/bash
# mkpatch.sh BASE_COMMIT TREE OUT_PREFIX: git diff --binary of TREE against `git archive BASE_COMMIT`, in a scratch index.
set -euo pipefail
REPO=/home/user/tuesday; BASE=$1; TREE=$2; OUT=$3
G=$(dirname "$OUT")/patchgen.$$
rm -rf "$G"; mkdir -p "$G"; git -C "$G" init -q .
git -C "$REPO" archive "$BASE" | tar -x -C "$G"
git -C "$G" add -A
find "$G" -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf {} +
cp -a "$TREE"/. "$G"/
git -C "$G" add -A -N 2>/dev/null || true
git -C "$G" diff --binary > "$OUT.patch"
git -C "$G" diff --name-status > "$OUT.name-status"
rm -rf "$G"
