"""Count the CLI account's email (from ~/.claude.json oauthAccount.emailAddress, never printed) in files, git
objects or archives. Usage: scan_real_email.py LABEL PATH...  (.tar.gz members and .skill/.zip members are read)."""
import json, os, sys, tarfile, zipfile, io, urllib.parse
from pathlib import Path
e = json.load(open(os.path.expanduser("~/.claude.json")))["oauthAccount"]["emailAddress"].strip().lower()
local = e.split("@")[0]
forms = {e, urllib.parse.quote(e).lower()}
hits = {}; n = 0
def check(name, b):
    global n; n += 1
    t = b.decode("utf-8", "replace").lower()
    c = sum(t.count(f) for f in forms)
    lc = t.count(local) if len(local) >= 5 else 0
    if c or lc: hits[name] = (c, lc)
def walk(name, b):
    if name.endswith((".tar.gz", ".tgz", ".tar")):
        with tarfile.open(fileobj=io.BytesIO(b)) as tf:
            for m in tf.getmembers():
                if m.isfile(): walk(f"{name}!{m.name}", tf.extractfile(m).read())
    elif name.endswith((".skill", ".zip")) and zipfile.is_zipfile(io.BytesIO(b)):
        with zipfile.ZipFile(io.BytesIO(b)) as z:
            for m in z.namelist(): walk(f"{name}!{m}", z.read(m))
    else: check(name, b)
label = sys.argv[1]
for r in map(Path, sys.argv[2:]):
    for p in ([r] if r.is_file() else [q for q in r.rglob("*") if q.is_file() and ".git" not in q.parts]):
        walk(str(p), p.read_bytes())
print(f"{label}: {n} texts; files with the address: {sum(1 for v in hits.values() if v[0])}; files with its local part only: {sum(1 for v in hits.values() if not v[0] and v[1])}")
for k, (c, lc) in sorted(hits.items()): print(f"  {k}: address {c}, local part {lc}")
