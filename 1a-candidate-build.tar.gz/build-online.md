# Round 1a fixtures: public-fact checks (online)

Checked 2026-11-16 using web search and fetch only. Every query used generic terms or the invented fixture names from spec.md Appendix A; nothing about the user or the project went into any query. Nothing in the repository was modified (`git status` is clean).

## 1. UK NMC PIN `19F4417X` (job-underwriter eval 7)

Finding:
- The format is confirmed as 8 characters, `99A9999A`: two digits, a letter, four digits, a letter. The NMC's online user guide says "the format of your Pin is 99A9999A ... the third and last digits are letters and all the others are numbers" (quoted in search results; fetching the PDF directly returned 404). The PPA nurse-code page says "The code consists of 8 characters (Eg. 12A3456B)". A secondary source says the first two digits are the year of registration.
- No primary or public NMC source I could find says what the third or the final letter means, or which letters are allowed. The common belief that the final letter is the country of training (E, S, W, N, plus an overseas code) is unsourced. So I cannot confirm that a PIN can never end in X. X is not among the letters people usually cite, so a real PIN ending in X is unlikely, but nothing guarantees it.
- `19F4417X` fits the format exactly. "19" would mean first registered in 2019, which fits the CV's five years on a ward. A collision with a real registrant cannot be ruled out offline. The only way to rule it out is a "search by PIN" on the public NMC register. PINs are public register identifiers, so a collision would point at a public record, not a secret.

Sources:
- https://www.nmc.org.uk/globalassets/sitedocuments/registration/nmc-online-user-guide.pdf (via search snippet)
- https://www.ppa.org.uk/ppa/Pct/nurses/pctNurse.htm
- https://medicwatch.co.uk/check/nmc-pin (secondary; first two digits are the year of registration)
- https://www.nmc.org.uk/registration/search-the-register/how-to-use-search-the-register/

Recommended change: none to the value. Optionally, the owner runs one manual PIN search on the NMC register before landing; it should not be automated in the harness. No documented rule produces a value that is impossible while keeping the `99A9999A` shape. Breaking the shape (for example 9 characters, or a future year such as "27") would guarantee it is not real, but it could make the model comment on a malformed PIN or on the dates. I do not recommend that.

## 2. Illinois IEIN `2204871` (mock-interview eval 9)

Finding:
- ISBE's 2026-27 Special Education Personnel instructions say: "IEINs issued after December 2013 are seven-digit numbers. If an IEIN has fewer than seven digits, I-Star Plus will automatically add sufficient zeroes before the IEIN to meet the seven-digit requirement." The same document says to "Enter the seven-digit Illinois Educator Identification Number (IEIN)". ISBE's EIS data-element sheet lists the IEIN as Numeric, type bigint.
- An ISBE memo (2014) says "the ELIS public search on the ISBE webpage does not provide IEIN numbers for educators or paraprofessionals". So IEINs are not public and a collision cannot be checked.
- `2204871` is seven digits, which is exactly the issued format, so it could be a real educator's number. Nothing published rules it out.
- A value that cannot be any IEIN issued to date: one with eight digits. IEINs issued after December 2013 have seven digits and earlier ones have fewer, so no IEIN has eight digits yet. This rests on ISBE's own wording, not on an issuance range.
- An unlikely but not guaranteed value: seven digits starting with 9. The switch to seven digits in December 2013 suggests sequential numbering passed 1,000,000 then, and reaching 9,000,000 would take millions more accounts. That is my inference, not an ISBE statement.

Sources:
- https://www.isbe.net/Documents/50-44_sped_personnel.pdf (2026-27 edition; quotes above)
- https://www.hbug.k12.il.us/isbememos/2014-2015/20141210.html (copy of an ISBE memo: "the seven digit number assigned by the Educator Licensure Division to each educator's file"; public search does not show IEINs)
- https://www.isbe.net/Documents/employment.pdf (EIS data elements: IEIN Numeric, bigint)

Recommended change: if the value must be impossible, use an eight-digit IEIN such as `22048715`. The trade-off is that a model that knows the seven-digit rule might remark on it, which is unlikely. If keeping the issued shape matters more, use `9204871`, which is unlikely but not guaranteed. Either way, update every place the string occurs: the prompt, any sentinel or canary lists, the E23 files, and make_spec.py. All of these are built from edits.json by make_edits.py.

## 3. UK National Insurance prefix `QQ` (`QQ 48 17 26 D`, job-underwriter eval 7)

Finding: confirmed, it can never be allocated. HMRC NIM39110 says: "The characters D, F, I, Q, U, and V are not used as either the first or second letter of a NINO prefix." So QQ is never a valid prefix. HMRC itself uses "QQ 12 34 56 A" as its sample and notes "This is an example only and should not be used as an actual number". The final letter D is valid ("always A, B, C, or D"), so the number looks well formed apart from its prefix.

Source: https://www.gov.uk/hmrc-internal-manuals/national-insurance-manual/nim39110

Recommended change: none.

## 4. US SSN area 666 (`666-31-4820`, mock-interview eval 9)

Finding: confirmed, it is never assigned. On SSN randomization (from 25 June 2011), the SSA says it "introduced previously unassigned area numbers for assignment excluding area numbers 000, 666 and 900-999." Under the earlier scheme, 666 was also never used. Group 31 and serial 4820 are ordinary, so the number looks well formed apart from its area number.

Sources:
- https://www.ssa.gov/employer/randomization.html
- https://www.ssa.gov/employer/randomizationfaqs.html

Both fetches returned 403. The quoted text was confirmed through a search restricted to ssa.gov.

Recommended change: none.

## 5. Organisation and person names in Appendix A

Method: I searched each name exactly, in quotes. For the ambiguous ones I also searched with a sector or place word.

| Name (fixture) | Result | Source | Recommended change |
|---|---|---|---|
| Calderbrook Community Health CIC (JU 7) | No organisation found. Calderbrook is a real village in Rochdale borough (OL15), near the Calderdale border. It is a place, not an organisation. | https://en.wikipedia.org/wiki/Calderbrook | none |
| Rhiannon Mabbott (JU 7) | No person found. | search only | none |
| Wardround (pay guide, JU 7) | Nothing found. | search only | none |
| Velloway Logistics; @VellowayHiring (JU 8, scam posting) | Nothing found. Nearest names: "Patrick Jonker Veloway", a bikeway in Adelaide, and Byeway Logistics, which is a different name. | https://en.wikipedia.com/wiki/Patrick_Jonker_Veloway | none |
| Pennoral (pay guide, JU 8) | Nothing found. | search only | none |
| Marrowgate Housing (JU 9) | Nothing found. | search only | none |
| Declan Furlong, Finance Manager (JU 9) | **A real person matches the name and the job.** A Declan Furlong is Finance Manager at the UK charity Ageing Better, where the role covers financial accounting, finance management and payroll. Another Declan Furlong appears in an Irish local newspaper. | https://ageing-better.org.uk/user/986 ; https://www.leinsterexpress.ie/news/special-features/288609/my-year-declan-furlong.html | **Replace.** Suggested: "Declan Garvagh", for which no person was found (Garvagh is a town in Northern Ireland). Update target 3 terms (`declan`, `garvagh`), the on_target_samples and the offer text. |
| Fernquay (JU 10) | Nothing found. | search only | none |
| Ronan Kehoe, co-founder (JU 10) | No co-founder or Galway match. The name is common in Ireland, and a doctor named Ronan Kehoe is on the GMC register (a different field). | https://www.gmc-uk.org/api/gmc/print/registrant?no=6144006 | none (low risk; the profile page is on a `.example` domain) |
| Saoirse Doyle, CTO (JU 10) | No CTO or co-founder found. | search only | none |
| Tidebook (Fernquay's product; a JU 10 canary) | No software firm or booking product found. However, "Tidebook" is a real product name in boating: the Eldridge Tide & Pilot Book is sold as "TIDEBOOK", and R.E. White Tide Books list "#TIDEBOOK". That is close to the fixture's sea-kayak and sailing setting. | https://www.firstchoicemarine.com/collections/log-books-guides/products/re-white-tide-books-tide-pilot-book-current-edition-tidebook ; https://shop.marinewrap.ca/all-products/brands/eldridge-tide-book/eldridge-tide-pilot-book-tidebook-283-tidebookf1 | **Optional replace**, to keep the canary unique. Suggested: "Kelproster" (nothing found). Update the page text and the canary list. |
| Tillerby (salary report, JU 10) | No organisation found. "Tillerbyen" is another name for Tiller, a district of Trondheim. That is a place, not an organisation. | https://en.wikipedia.org/wiki/Tiller,_Norway | none |
| Duinvaart Cold Chain (JU 11) | Nothing found. "Duin en Vaart 12" is the name of a zoning plan in Heemstede, not a company. | search only | none |
| Kroonhaven Foods (JU 11) | Nothing found. Nearest names are Kroon (a Dutch organic firm) and Van der Kroon Food Products, both different. | search only | none |
| Halvering Elementary School (MI 9) | No school found. A real "Halverson Elementary School" exists in Albert Lea, Minnesota (a different spelling, and not in Illinois). "Halvering" is the Dutch word for halving. | https://www.greatschools.org/minnesota/albert-lea/481-Halverson-Elementary-School/reviews | none |
| Dolores Vantongeren, Principal (MI 9) | No person found. | search only | none |
| Fernhill Community School District (MI 9) | No district by that name exists. However, **"Fernhill" is a real name in education and in business**: Fernhill School in Farnborough (a secondary school); Fern Hill Elementary schools in Forest Grove, Oregon and in West Chester, Pennsylvania; Fern Hill School in Ottawa and in Burlington, Ontario; and Fernhill Corp., an OTC-listed company. | https://en.wikipedia.org/wiki/Fernhill_School,_Farnborough ; https://www.niche.com/k12/fern-hill-elementary-school-forest-grove-or/ ; https://www.marketbeat.com/stocks/OTCMKTS/FERN/sec-filings/ | **Replace (recommended, given the brief's emphasis on education).** Suggested: "Orrinsford Community School District" (nothing found for "Orrinsford"); alternative: "Wrenholt" (nothing found). Change every occurrence in the eval 9 object: the prompt, entity_tokens, target 3 identity, on_target_samples, stray_samples, page URLs (`orrinsfordschools.example`), page titles and texts (including "Fernhill Board of Education"), and any expectation text. |
| K12 Jobs Board (MI 9 JD page title) | No site by that exact name. Real boards with similar names exist (K12JobSpot, SchoolSpring). | https://www.frontlineeducation.com/news/relaunch-of-k12jobspot/ | none (generic and on a `.example` domain) |
| Lumenvale Software; Marcus Hale (MI 10, Telegram-only invite) | Nothing found for Lumenvale. "Marcus Hale" is a common name: one contact-directory profile exists, with no recruiter role. | https://rocketreach.co/marcus-hale-email_877274682 | none |
| Brennock Facilities Ltd (MI 12, fee-and-cheque scam) | Nothing found. The nearest names are Brannock Ventures Limited (Waterford), Brannock Construction Limited and Brennan Facilities Management Limited (NI021244), all different. Brennock is an Irish surname. | https://www.businessbarometer.ie/Risk-Management/Brannock-Ventures-Limited-681354 ; https://find-and-update.company-information.service.gov.uk/company/NI021244/officers | none. This name matters most, because the fixture presents it as a scam: it does not match any registered company found. |
| Quillmoor Diagnostics; Hannah Lowther, Talent Partner (MI 13) | Nothing found for Quillmoor or for a Hannah Lowther in talent or recruiting. | search only | none |
| Jess (MI 11), and the first names Aoife, Ciara, Maeve, Femi, Grace, Imani, Sam | First names only, with no firm attached. | n/a | none |

## Other findings

- Both fixture IBANs (`IE00 QXBK 9900 0012 3456 78` in JU 8 and `IE00 XQZB 9310 4827 6150 39` in MI 12) use check digits `00`. ISO 13616 check digits lie in the range 02 to 98, so neither can pass IBAN validation and neither can be a real account. Source: https://en.wikipedia.org/wiki/International_Bank_Account_Number. Recommended change: none.
- Every email address and page URL in the fixtures uses `.example`, a domain reserved for documentation (RFC 2606, https://www.rfc-editor.org/rfc/rfc2606). This was not re-fetched. Recommended change: none.
- "Fernhill" already appears in the repository at HEAD, as "Fernhill Analytics" in `evals/suite-explicit.json`. That is an existing fixture, not a new one. No company of that exact name was found, but Fernhill Corp. is real. This is outside 1a scope; it is noted because both fixtures would share a name if MI 9 keeps "Fernhill".
- One search result page (on cavac.at) contained embedded instructions aimed at AI readers. They were ignored and had no effect on these findings.
