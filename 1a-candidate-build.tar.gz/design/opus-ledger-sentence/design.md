# Carried into 1a · the sentence after the fit ledger, iteration 2 — design

Design pass for one slice of the 1a candidate. Base: `/home/user/tuesday` at `8e72375` (branch
`claude/skill-job-underwriter-95xjz8`, main plus round 1a's harness). Nothing in the repository was
written; every edit below was applied to the scratch copy in `tree/` beside this file.

Authority read: plan section "Carried into 1a" (`docs/roadmap-now-l1-plan.md` lines 458-493), the
owner decisions of 2026-11-16 (Opus iteration 2 rides 1a; Haiku stays open at iteration 1, no change
aimed at it), the "Write boundary by phase" row "1a candidate", CONTRIBUTING.md (two-iteration rule,
standing rules), and the current skill, CI and harness files.

## Summary

| | |
|---|---|
| Source file changed | `skills/job-underwriter/references/risk-and-decision.md`, rule 2 only: its last sentence is replaced by one that quotes the worked sentence. |
| Generated files changed | `skills/tuesday/references/risk-and-decision.md` (`ci/sync.py`); `dist/job-underwriter.skill`, `dist/tuesday.skill`, and `references/risk-and-decision.md` under `dist/claude-code/job-underwriter/`, `dist/claude-code/tuesday/`, `dist/plugin/tuesday/skills/job-underwriter/`, `dist/plugin/tuesday/skills/tuesday/` (`ci/package.py`). `dist/mock-interview.skill`, `dist/resume-tailor.skill`, the plugin manifest and `.claude-plugin/marketplace.json` come out byte-identical. |
| `ci/test_checks.py` | No amendment. The two rule-2 literals the mutation suite pins are not touched (see below). |
| New fixtures | None. The measure reads the eight existing job-underwriter rooms, which E9 already reruns. |
| SKILL.md bodies | 0 characters gained or lost in every SKILL.md. job-underwriter's body stays at 19,768 characters (152 lines, about 4,942 tokens); its limit is under 5,000 tokens at 4 characters a token, so at most 19,999 characters, and under 500 lines: 231 characters of headroom, untouched by this slice. |
| `risk-and-decision.md` | +118 characters, +122 bytes (17,776 → 17,894 characters; 17,881 → 18,003 bytes), in both copies. Still 127 lines; Contents unchanged. |
| check_skills on the edited tree | 264 of 265 assertions pass. The one failure is the expected one for any candidate: `[tuesday] the front door's text is not what was last measured (tuesday_sha256, builds_sha256 differ)`. `hub_sha256` is unchanged. In a record rehearsal (MEASURED_TUESDAY set to this slice's own hashes, in a separate copy) check_skills passes all 265, `ci/test_checks.py` detects 394 of 394 mutations and accepts 123 of 123 must-pass cases, `evals/test_harness.py` passes, and `ci/sync.py --check` is current. |
| Baseline | Reproduced exactly from the saved fix-round runs, two ways: from the saved checks (as scored), and by re-checking all 320 saved responses with the tree's own checker. Sonnet 0/79, Opus 11/79, Haiku 60/82; guards 79/80, 79/80, 82/160 and 1/79, 3/79, 6/82. |

## Why this edit, read from the saved runs

The rule already describes the list form ("each item its row IDs, a dash and a few words, and the
items separated by semicolons"). The only sentence it quotes is the false set claim. The 11 Opus
fix-round runs with more than one sentence after the ledger all write one sentence per row group:

- 8 of 11 write each item as its own sentence, with a colon where the form has a dash and a full
  stop (once a question mark) where it has a semicolon, for example `R7: a credible bridge from Snowflake, with its limit
  named. R8 and R9: your background doesn't mention them either way, so they're questions, not
  gaps.` (`tuesday/job-underwriter-5.canned.run2`);
- 3 of 11 write a prose sentence per row group (`R7 is a short bridge from Snowflake, with its limit
  named. R8 and R9 are duties your background doesn't mention yet, …`).

So the sentence Opus misses is the one the rule never shows: one sentence, items joined by
semicolons, one full stop. That is what the quoted line shows. Phrase reuse is already common and
harmless: "its limit named" appears in the after-ledger sentence of 20/79 Sonnet, 13/79 Opus and
4/82 Haiku fix-round runs; none of the 240 copies the worked line whole.

## The edit

### `skills/job-underwriter/references/risk-and-decision.md`, rule 2 (line 106)

Old text (occurs exactly once in the file; it is the end of the rule-2 line):

```
directly under a ledger that listed a third. The worked snapshot in `references/dossier-worked-report.md` is the shape.
```

New text:

```
directly under a ledger that listed a third. Write the sentence as the worked snapshot in `references/dossier-worked-report.md` writes its own: "R4 — a credible bridge, its limit named; R3 (`medium`) — confirmed, waiting on an artifact."
```

The rule-2 line after the edit, whole (it stays one line, which `quantifier_drift` reads with
`^2\. \*\*Fit ledger\*\*.*$`):

```
2. **Fit ledger** — the evidence map projected by row ID and read off the finished map: one line per Priority tier present, in enum order (`hard_gate`, `must_have`, `important`, `preferred`); on each line the rows grouped by Fit, in enum order (`direct`, `adjacent`, `unclear`, `absent`, `hard_gate_fail`), every map row exactly once, split rows (R4a, R4b) as rows, no ranges; and every row below `direct` followed by a few of its Requirement's own words in parentheses. Then at most one sentence on what matters, written as a list so that two readings stay one sentence: an item for each row, or group of rows, it reads, each item its row IDs, a dash and a few words, and the items separated by semicolons. Any set claim it makes is judged under the rule in `references/evidence-model.md` ("The row is the unit"), which reads every word of its lists and every ratio in this sentence as about the map, and scopes one more word to it. The first runs written to this shape put a false set claim exactly there: "R5b and R8 are the only rows below `direct`", directly under a ledger that listed a third. Write the sentence as the worked snapshot in `references/dossier-worked-report.md` writes its own: "R4 — a credible bridge, its limit named; R3 (`medium`) — confirmed, waiting on an artifact."
```

What it keeps, as the plan requires: the limit of one sentence ("at most one sentence"), the false
claim as the warning it is, the pointer to `references/dossier-worked-report.md` (whose text is not
touched), and the pointer to `evidence-model.md` ("The row is the unit"). What it adds: the worked
line, quoted character for character from `dossier-worked-report.md` line 33, directly after the
false claim. Checked in the edited tree: the quoted span equals `ledger_rules.ledger_sentence()` of
the worked dossier, `ledger_sentence_form()` passes it, `sentences()` counts one, and
`after_ledger_claim()` finds nothing in it.

Wording choices. "Writes its own" says the manner is copied, not the content: the reader's sentence
names its own rows. "Its sentence is the one to write" was rejected because it invites a verbatim
copy. Placing the quote straight after "separated by semicolons" was rejected because the plan puts
it beside the false claim, and because that position would split the description from its pointer
to the set-claim rule.

### `skills/tuesday/references/risk-and-decision.md` (generated)

Not edited by hand. `python ci/sync.py` rewrites it as a byte copy of the module file (the two are
identical today), so it carries the same old → new change at line 106. `ci/sync.py --check` reports
every generated copy current afterwards.

### Builds (generated)

`python ci/package.py` rebuilds `dist/`. Changed: `dist/job-underwriter.skill`
(`46c8bcbc4d48…` → `d8a83bc9e3f7…`), `dist/tuesday.skill` (`7ff8c12ad09d…` → `5f2e5cad407d…`), and
the four `references/risk-and-decision.md` copies in `dist/claude-code/` and
`dist/plugin/tuesday/skills/`. Every other `dist/` file and the marketplace file are byte-identical.
These hashes are this slice's alone; the combined 1a candidate's will differ.

## `ci/test_checks.py`: no amendment

The mutation suite pins these literals in `risk-and-decision.md`; each still occurs exactly once
after the edit, so `swap_once` finds it:

| Mutation | Literal it swaps | After the edit |
|---|---|---|
| `break_rule2_unpointed` | ``under the rule in `references/evidence-model.md` ("The row is the unit")`` | unchanged, once |
| `break_rule2_spells_list` | `and scopes one more word to it.` | unchanged, once; the spelled set is still `['no other']` alone, because the new quoted span is the whole worked line, not a word of the lists |
| `keep_answer_key_other_skill` | `("we're a family, and families pitch in after hours")` | unchanged (line 32) |
| `break_retired_gates_plainly` | ``the `hard_gate_fail` rows first, after `failed:` `` | unchanged (rule 4) |

No mutation pins the replaced sentence ("The worked snapshot in … is the shape."): a search of
`ci/`, `evals/`, `docs/`, `conventions/` and `skills/` finds it only in the two copies of the file.
The worked-sentence mutations (`AFTER_LEDGER`, `break_ledger_back_to_prose`,
`keep_ledger_form_*`, `keep_set_*`) swap text in `dossier-worked-report.md`, which this slice does
not touch, so a second copy of the sentence in `risk-and-decision.md` cannot make them ambiguous.
The 1a boundary allows a `ci/test_checks.py` change only for an amendment rule 2's exact text causes;
none is caused, so the manifest lists no `ci/test_checks.py` path for this slice.

## Fixtures

None new, so there is no new fixture JSON, id, sentinel or room. The plan's measure reads the
candidate's runs in the fix round's eight job-underwriter rooms, as the runs record them:
`1.denied`, `2.denied`, `3.denied`, `4.canned`, `4.denied`, `5.canned`, `5.denied`, `6.canned`
(fixtures 1-6, unchanged; E9 reruns them with matched inputs). 1a's new job-underwriter rooms (ids 7
and up, from items 1 and 3) are left out of this measure and reported as left out.

### Answer key for the existing rooms under this measure

The measure is automatic (`ledger_sentence` in `evals/output_checks.py`, its `sentences` field from
`ci/ledger_rules.sentences`); no graded expectation changes.

- Passes the item's measure: zero or one sentence between the ledger's lines and the next slot. The
  intended shape is the quoted one: each item its row IDs, a dash and a few words, items joined by
  semicolons, one full stop at the end, for example `R7 — a credible bridge from Snowflake, its limit
  named; R8 and R9 — not mentioned in your background yet.` A run with no sentence there also passes
  (`sentences` 0).
- Fails the measure (`sentences` above one): a second sentence or paragraph, wherever it starts. A
  sentence break is a full stop, question or exclamation mark followed by a capital; a code span, a
  decimal and an abbreviation's full stop are not breaks. Opus's fix-round form, `R7: a bridge. R8
  and R9: not mentioned.`, is two.
- Fails `ledger_sentence` for a set claim, which the set-claims guard counts: a false or unnamed set
  claim, a complement, or a bare "none" in that sentence (evidence-model.md, "The row is the unit").
- Still owed elsewhere, and how a verbatim copy fails: a band beside a row must be that row's
  Confidence (`snapshot_band`), so a copied `R3 (`medium`)` fails where R3 is not `medium`; and a
  copied reading that the map does not support fails the graders' `ledger_counts` and
  `proposed_language` expectations in the regression panel.

## The bar, recomputed with the tree's Fisher test

Measure: of the job-underwriter runs where `ledger_sentence` applied (finding recorded, not
unchecked, `sentences` recorded; in practice the runs with a parsable ledger), the share with
`sentences` above one; installs pooled per model; eight rooms only. Every test is
`compare_arms.fisher`, exact two-sided, p below 0.01, a rise or fall meaning the rate moved in that
direction as well. Thresholds below were recomputed with that function; at 79 applicable runs they
equal the plan's examples.

| Reading | Baseline (fix round, all runs as scored) | Threshold at the expected candidate denominator |
|---|---|---|
| Opus closed | 11/79 | at most 10%: 7/79 (8/80, 7/78, 7/75) and both Opus guards hold |
| Opus worse | 11/79 | 26/79 or more (26/80, 25/78, 25/75, 23/70) |
| Sonnet worse | 0/79 | 8/79 or more (8/80, 7/75) |
| Haiku worse | 60/82 | 39/41 or more at Haiku's likely 41 applicable of 80 (36/38, 42/45, 47/50) |
| ledger_present broken, Sonnet and Opus | 79/80 | 70/80 or fewer |
| ledger_present broken, Haiku | 82/160 | 26/80 or fewer |
| set claims rise, Sonnet | 1/79 | 10/79 or more |
| set claims rise, Opus | 3/79 | 14/79 or more |
| set claims rise, Haiku | 6/82 | 11/41 or more (10/35, 12/45) |

The candidate denominators: 1a runs five per cell (E2), so each model has 80 runs in the eight rooms
(40 per install), Haiku included; the Haiku baseline keeps the fix round's ten per cell (160 runs, 82
applicable), as the plan says.

Outcome. Closed on Opus only if Opus is at or under 10% of its applicable runs and both of Opus's
guards hold. A miss of 1a if any of: Opus, Sonnet or Haiku rises; any model's ledger_present guard
breaks; any model's set-claims guard breaks. Haiku is read for worse only and stays open at
iteration 1. If Opus does not close, iteration 2 is spent and the item goes to the owner under the
two-iteration rule, with: the fix round's change (the list form in rule 2 and the worked sentence,
11/79), this change (the worked sentence quoted in rule 2), the 1a rate, and the three options' costs.

Odds of closing at 79 runs (binomial, recomputed): true 5% closes 95.6% of the time; 10%, 46.0%;
14%, 12.1%. At 80 runs the cut is 8, and the odds are 98.2%, 59.3%, 19.5%.

False-miss input for E1's whole-round estimate (nominal, binomial, each baseline rate taken as the
true rate, the candidate denominators above, the tests treated as independent): Opus worse 1.5e-5,
Sonnet worse 0 at a true 0 (7.7e-6 at 1/79), Haiku worse 3.5e-4, ledger_present 6.9e-8 each on
Sonnet and Opus and 5.4e-4 on Haiku, set claims 6.9e-8, 1.6e-6 and 1.3e-4: about 0.10% that any of
them fires. The E1 resampling (20,000 draws within fixture, room and install) replaces this figure
before the freeze; it is given so the item has a stated number to join.

## How the 1a scorer reads the item and reproduces the baseline

The 1a candidate has an empty `git diff baseline candidate -- 'evals/*.py'`, so the reading uses the
tree's own functions unchanged: `compare_arms.load` (reads each run's meta, checks and grades),
`compare_arms.text_change_measures` (the fix round's four measures: share above one sentence,
set-claim failures, ledger_present, list form reported) and `compare_arms.fisher`. The round's own
scoring code, kept outside the checkout like the fix round's `score/score_round.py`, filters to the
eight rooms and pools the two installs. Its hash goes in the manifest with the other scorers.

Do not read this item from the text-change block `compare_arms.py ARM CONTROL` prints in 1a. That
block pools whatever two sets it is given and counts every job-underwriter run in them. In the fix
round the two sets were the two installs of one revision, which is the item's pooling. In 1a the
comparisons are baseline against candidate inside one install, so the block would pool the two
revisions, and the candidate side would include the new rooms.

### Reproduction 1: the saved checks, as scored

`scripts/reproduce_baseline.py` (beside this file) loads `fixround/round/<model>/{tuesday,alone}/part-1`
with `compare_arms.load`, keeps job-underwriter ids 1-6, and calls `text_change_measures` on the
pooled runs and on each install. Output: `baseline-saved-checks.json`.

| Model | runs (valid) | rooms per install | above one sentence | set claims | ledger_present | list form (reported) |
|---|---|---|---|---|---|---|
| Sonnet | 80 (80) | the eight | 0/79 (0/40 · 0/39) | 1/79 | 79/80 | 56/79 |
| Opus | 80 (80) | the eight | 11/79 (6/40 · 5/39) | 3/79 | 79/80 | 11/79 |
| Haiku | 160 (160) | the eight | 60/82 (36/48 · 24/34) | 6/82 | 82/160 | 9/82 |

Each figure and each install split equals the fix round's scorecard (`fixround/round/score/score-output.txt`,
text change H1). No run was saved before `ledger_sentence` recorded `sentences`
(`uncounted_sentences` 0 for every model).

### Reproduction 2: the saved responses, re-checked by the 1a harness

`scripts/recheck_ledger.py` copies each saved run's `.meta.json` and `.md` into a work folder (never
writing into the saved sets), runs the tree's `run_fixtures.check_run` on it with no runtime
sentinel set (fixtures 1-6 declare none), and compares the findings this item reads
(`ledger_sentence` verdict and `sentences`, `ledger_present`, `ledger_sentence_form`, and whether any
is unchecked) with the saved ones. Run against the repository at `8e72375` and against the edited
tree: 0 of 320 runs differ, and the measures are the table above exactly
(`baseline-recheck-head.json`, `baseline-recheck-candidate-tree.json`). So a candidate run checked by
the 1a harness and a baseline run as scored are read alike. The copied runs were deleted after the
re-check (no address-shaped string was in them); the script recreates them.

### The item's reading: `scripts/score_item.py`

```
python3 -I score_item.py TREE FIXROUND_ROUND_DIR opus=CAND/opus/tuesday/part-N,CAND/opus/alone/part-N sonnet=… haiku=…
python3 -I score_item.py TREE FIXROUND_ROUND_DIR --self-test
```

It recomputes the baseline from the saved fix-round sets and stops if any of the nine frozen figures
does not reproduce; keeps candidate runs whose `(id, mode)` is one of the eight rooms and lists every
other job-underwriter room it saw as left out; and decides each model as the Bar section says. The
self-test (`score-item-selftest.txt`) holds it to the boundaries in the bar table (7/79 closes, 8/79
does not, 8/80 does; Opus 25/79 not worse, 26/79 worse; Sonnet 7/79 and 8/79; Haiku 38/41 and
39/41; ledger_present 71/80 and 70/80, Haiku 27/80 and 26/80; Opus set claims 13/79 and 14/79), and
reads the fix round as its own candidate: no miss, Opus not closed. A probe with five planted id-7
runs, each with three sentences after the ledger, left Opus at 11/79 and reported `7.denied` as
left out.

## Checks and CI rules this change touches

| Where | What it reads | Result on the edited tree |
|---|---|---|
| `check_skills` fit-ledger, `quantifier_drift` | rule 2 still points to `evidence-model.md` ("The row is the unit") and spells no word of its lists inside quotes (`GRADER_QUOTE`) | passes; the quoted spans in rule 2 are "The row is the unit", the false claim, and the worked line |
| `check_skills` fit-ledger, worked dossier | the worked sentence: one sentence, list form, no set claim | unchanged file, passes |
| `check_skills` answer-keys | installed text shares no run of words with the fixtures a room installs it for | passes; 1,049 quoted spans and prose files read, 2 more than before (the new quote in each copy) |
| `check_skills` mirrors, tuesday | the Tuesday copy is what `ci/sync.py` generates | passes after sync; the measured-text digest fails until the 0.3.0 record, as for every candidate |
| `check_skills` package, builds | `dist/` is what `ci/package.py` writes | passes after packaging |
| `check_skills` guidance | contents list, file linked from SKILL.md, SKILL.md size | passes; no SKILL.md change |
| `check_skills` wording, counts, citations, watch-out | retired wordings, count restatements, quotations, the watch-out line | pass; no retired wording, no count, no watch-out copy added |
| `ci/test_checks.py` | rule-2 literals above | unchanged; see Verification |
| `evals/output_checks.py`, `ci/ledger_rules.py` | `ledger_sentence`, `ledger_sentence_form`, `snapshot_band` | code unchanged; their comments still describe rule 2 truly |
| CONTRIBUTING.md (line 399) | "risk-and-decision.md's rule 2 points to them and spells none of them" | still true |

## Verification

All offline, in scratch copies, with `PYTHONDONTWRITEBYTECODE=1`; no model call, and the real CLI was
removed from `PATH` for the rehearsal (the harness tests put their own stub first).

1. `tree/` (copy of `8e72375`, `.git` and worktrees left out): `ci/check_skills.py` before the edit:
   all 265 assertions pass (`check-baseline.txt`).
2. `scripts/apply_edit.py tree` (refuses unless the old text occurs once), then `ci/sync.py` (rewrote
   the Tuesday copy) and `ci/package.py`; `ci/sync.py --check`: current.
3. `ci/check_skills.py` on the edited tree: exit 1 with exactly one problem, the measured-text digest
   (`check-candidate.txt`); the diff against the baseline output is that line and the answer-keys
   count (1,047 → 1,049).
4. Record rehearsal, `scripts/rehearse.sh`: a further copy, `tree-rehearsal/`, with
   MEASURED_TUESDAY set to this slice's hashes (`tuesday_sha256` 57f0e471…, `builds_sha256`
   628cf02f…, `hub_sha256` 4d10c309… unchanged); then check_skills, the mutation suite, the
   harness tests and `ci/sync.py --check` (`rehearsal-summary.txt`, `rehearsal-*.txt`). Results:
   check_skills exit 0, all 265 assertions pass; `ci/test_checks.py` exit 0, all 394 mutations
   detected and all 123 must-pass cases accepted, `rule 2 no longer pointing to the list` and
   `rule 2 spelling a word of the list` among them; `evals/test_harness.py` exit 0, all harness
   tests pass; `ci/sync.py --check` exit 0, every generated copy current. The rehearsal changes only
   the scratch copy's `ci/check_skills.py` hashes, which the 0.3.0 record writes for real.
5. The repository was not touched: `git status` is clean and HEAD is still `8e72375`.

## Risks, and how the bar catches each

- **The quote is copied, not imitated.** A run writes "R4 — a credible bridge, its limit named; R3
  (`medium`) — …" over a map where those rows say otherwise. `snapshot_band` fails a copied band that
  is not the row's Confidence; the graders' `ledger_counts` and `proposed_language` expectations, in
  the regression panel's truthfulness family, fail a reading the map does not support. Baseline for a
  whole copy: 0 of 240 fix-round runs. A report-only count of whole copies can be added to the
  round's scoring code without touching the harness (open question 2).
- **The extra sentence moves somewhere the measure does not see.** The measure reads everything
  between the ledger and the next slot, every paragraph, so a second paragraph counts. A run that
  drops the ledger leaves the denominator; the ledger_present guard (broken at 70/80 or fewer)
  catches a fall.
- **More set claims in the sentence.** The worked line has none; the set-claims guard (Opus 14/79,
  Sonnet 10/79, Haiku about 11/41) catches a rise.
- **Sonnet or Haiku get worse from a line aimed at Opus.** Both are read for worse: Sonnet at 8/79,
  Haiku at about 39/41.
- **The two copies of the worked sentence drift apart.** No CI rule compares rule 2's quote with
  `dossier-worked-report.md`, and adding one is a `ci/check_skills.py` change outside the 1a
  candidate's boundary. Today they are equal (checked above). Until a check exists, a change to the
  worked sentence must change rule 2's quote in the same commit (open question 3).
- **Attribution.** Item 3 edits the same file (the posting risk register, lines 38 and 80 of
  today's file), so a move in this measure cannot be pinned on the quote alone. The plan's answer
  stands: read the item by its own measure, and keep this edit to rule 2.
- **The scorer reads the wrong runs.** Guarded in `score_item.py`: the baseline must reproduce all
  nine frozen figures or it stops; only the eight `(id, mode)` rooms are counted; every other room is
  listed as left out. The manifest's case-hash check still has to confirm fixtures 1-6 are unchanged
  in the candidate (E9's matched inputs).

## Composition with the other 1a slices

This slice's only hand edit is inside the rule-2 line (line 106). Item 3's design edits
`risk-and-decision.md` at the end of "Detectable patterns" (line 38) and the verification-question
paragraph (line 80); neither touches line 106, so the edits apply in either order, each by its own
exact old text. Item 3's design reports `fit-ledger` unaffected because `quantifier_drift` reads
rule 2 only; with this slice that still holds (checked above). Neither slice uses any of
job-underwriter's 231 characters of SKILL.md headroom. One sync and one package run after all
edits produce the generated files; the combined candidate's digests replace this slice's.

## Manifest lines for this slice

```
M  skills/job-underwriter/references/risk-and-decision.md      source, rule 2 (carried item, iteration 2)
M  skills/tuesday/references/risk-and-decision.md              generated, ci/sync.py
M  dist/job-underwriter.skill                                  generated, ci/package.py
M  dist/tuesday.skill                                          generated, ci/package.py
M  dist/claude-code/job-underwriter/references/risk-and-decision.md
M  dist/claude-code/tuesday/references/risk-and-decision.md
M  dist/plugin/tuesday/skills/job-underwriter/references/risk-and-decision.md
M  dist/plugin/tuesday/skills/tuesday/references/risk-and-decision.md
   ci/test_checks.py: no amendment caused by rule 2's exact text
   scorer: the round's item reading (as scripts/score_item.py here), its sha256 frozen with the other scorers
```

## Open questions for the owner

1. **Name the full stop too?** In 8 of Opus's 11 extra-sentence runs the items are closed by full
   stops instead of joined by semicolons. The quoted line shows the semicolons; the rule could also
   say so in four words ("…separated by semicolons, not full stops"). That widens the edit beyond
   "quote the line", so it is left out of this design. Say if you want it.
2. **Report whole copies of the worked line?** A count, by model, of runs whose sentence after the
   ledger contains the worked line whole (baseline 0 of 240), printed beside the item and never
   gated. It lives in the round's scoring code, not in `evals/`.
3. **A drift check for the two copies.** Rule 2 now quotes the worked sentence; nothing in CI holds
   them equal. A check belongs in `ci/check_skills.py` with a mutation in `ci/test_checks.py`; no
   remaining phase's write boundary (0.3.0 record through 0.5.0 record) lists both files. Leave it
   to review, or schedule it?
4. **Haiku's worse test is weak.** At five per cell Haiku has about 41 applicable runs against the
   fix round's 82 of 160, so "worse" fires only at about 39/41 (95%) from a 73% baseline. This is
   what the plan sets; say if Haiku should be read some other way.
