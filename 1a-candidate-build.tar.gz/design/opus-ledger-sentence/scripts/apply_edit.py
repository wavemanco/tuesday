#!/usr/bin/env python3
"""Apply the carried item's one source edit (risk-and-decision.md, rule 2) to a tree.

    python3 -I apply_edit.py TREE

Exact replacement; refuses unless the old text occurs exactly once. The Tuesday copy is
not edited here: ci/sync.py regenerates it, and ci/package.py the builds.
"""
import sys
from pathlib import Path

REL = "skills/job-underwriter/references/risk-and-decision.md"
OLD = ('directly under a ledger that listed a third. '
       'The worked snapshot in `references/dossier-worked-report.md` is the shape.')
NEW = ('directly under a ledger that listed a third. '
       'Write the sentence as the worked snapshot in `references/dossier-worked-report.md` writes its own: '
       '"R4 — a credible bridge, its limit named; R3 (`medium`) — confirmed, waiting on an artifact."')

path = Path(sys.argv[1]) / REL
text = path.read_text(encoding="utf-8")
if text.count(OLD) != 1:
    raise SystemExit(f"expected one old text in {REL}, found {text.count(OLD)}")
path.write_text(text.replace(OLD, NEW), encoding="utf-8")
print(f"{REL}: {len(text)} -> {len(text) - len(OLD) + len(NEW)} chars ({len(NEW) - len(OLD):+d})")
