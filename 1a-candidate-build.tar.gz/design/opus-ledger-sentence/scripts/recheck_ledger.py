#!/usr/bin/env python3
"""Re-check the fix round's saved job-underwriter runs (ids 1-6, the eight rooms) with a tree's
own run_fixtures.check_run, in a copy, and compare the ledger findings the carried item reads
(ledger_sentence and its `sentences`, ledger_present, ledger_sentence_form) with the saved ones.
Then compute the item's measures from the re-check with compare_arms.text_change_measures.

    python3 -I recheck_ledger.py TREE FIXROUND_ROUND_DIR WORK_DIR

Offline: copies .meta.json and .md only (fixtures 1-6 declare no sentinels, and no runtime
sentinel is set), writes .checks.json in WORK_DIR, never in the saved folders. Calls no model.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path

tree, rnd, work = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
os.environ.pop("TUESDAY_SCAN_ACCOUNT_EMAIL", None)
sys.path.insert(0, str(tree / "evals"))
import compare_arms as ca  # noqa: E402
import run_fixtures as rf  # noqa: E402

IDS = range(1, 7)
READ = ("ledger_sentence", "ledger_present", "ledger_sentence_form")
cases = {c["id"]: c for c in rf.cases_for("job-underwriter", list(IDS))}


def key(findings: list[dict]) -> list:
    return sorted((f["check"], f.get("verdict"), f.get("sentences"), f.get("kind")) for f in findings
                  if f.get("check") in READ)


result = {}
for model in ("sonnet", "opus", "haiku"):
    diffs, sets = [], {}
    for arm in ("tuesday", "alone"):
        src = rnd / model / arm / "part-1"
        dst = work / model / arm
        if dst.exists():
            shutil.rmtree(dst)
        dst.mkdir(parents=True)
        metas = sorted(src.glob("job-underwriter-*.meta.json"))
        for meta_path in metas:
            meta = json.loads(meta_path.read_text())
            if meta.get("id") not in IDS:
                continue
            stem = meta["stem"]
            shutil.copy2(meta_path, dst / meta_path.name)
            body = src / f"{stem}.md"
            if body.exists():
                shutil.copy2(body, dst / body.name)
            rec = rf.check_run("job-underwriter", cases[meta["id"]], dst, meta["run"], meta["mode"])
            saved = json.loads((src / f"{stem}.checks.json").read_text())
            if key(saved.get("checks") or []) != key(rec.get("checks") or []) or \
                    (set(READ) & set(saved.get("unchecked") or [])) != (set(READ) & set(rec.get("unchecked") or [])):
                diffs.append({"stem": f"{arm}/{stem}", "saved": key(saved.get("checks") or []),
                              "recheck": key(rec.get("checks") or [])})
        sets[arm] = [r for r in ca.load(dst) if r.get("meta_read")]
    pooled = dict(ca.text_change_measures(sets["tuesday"] + sets["alone"]))
    result[model] = {
        "runs_rechecked": sum(len(v) for v in sets.values()),
        "ledger_findings_differing_from_saved": diffs,
        "h1": "%d/%d" % pooled["ledger_sentence: sentences after the ledger above one"],
        "claims": "%d/%d" % pooled["ledger_sentence: failed for a set claim (any reason but a second sentence)"],
        "present": "%d/%d" % pooled["ledger_present: passing, of job-underwriter's valid runs"],
        "form": "%d/%d" % pooled["ledger_sentence_form: passing, the list form or no sentence (reported)"],
    }
json.dump(result, sys.stdout, indent=2)
print()
