#!/usr/bin/env python3
"""Reproduce the carried item's baseline from the saved fix-round runs, with the tree's own
loader and measure (evals/compare_arms.py: load, text_change_measures), restricted to the fix
round's eight job-underwriter rooms (fixture ids 1-6; 4 and 5 in two modes).

    python3 -I reproduce_baseline.py REPO FIXROUND_ROUND_DIR [--recheck-root DIR]

Offline: reads saved .meta.json/.checks.json/.grade-*.json, calls no model.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

repo, rnd = Path(sys.argv[1]), Path(sys.argv[2])
sys.path.insert(0, str(repo / "evals"))
import compare_arms as ca  # noqa: E402

EXISTING_ROOMS = {(1, None), (2, None), (3, None), (4, "canned"), (4, "denied"),
                  (5, "canned"), (5, "denied"), (6, "canned")}
EXISTING_IDS = {i for i, _ in EXISTING_ROOMS}
MODELS = ("sonnet", "opus", "haiku")
LABELS = {
    "h1": "ledger_sentence: sentences after the ledger above one",
    "claims": "ledger_sentence: failed for a set claim (any reason but a second sentence)",
    "present": "ledger_present: passing, of job-underwriter's valid runs",
    "form": "ledger_sentence_form: passing, the list form or no sentence (reported)",
}


def ju_runs(folder: Path) -> list[dict]:
    """Every saved run in a part folder, kept to job-underwriter's existing ids."""
    runs = ca.load(folder)
    return [r for r in runs if r.get("meta_read") and r["skill"] == "job-underwriter" and r["id"] in EXISTING_IDS]


def part_with_ju(model_dir: Path, arm: str) -> Path:
    hits = [p for p in sorted((model_dir / arm).glob("part-*")) if p.is_dir()
            and any(p.glob("job-underwriter-*.meta.json"))]
    if len(hits) != 1:
        raise SystemExit(f"expected one part folder holding job-underwriter runs in {model_dir / arm}, got {hits}")
    return hits[0]


out = {}
for model in MODELS:
    md = rnd / model
    per_arm = {}
    for arm in ("tuesday", "alone"):
        folder = part_with_ju(md, arm)
        runs = ju_runs(folder)
        rooms = sorted({(r["id"], r["mode"]) for r in runs}, key=str)
        per_arm[arm] = (folder, runs, rooms)
    pooled = per_arm["tuesday"][1] + per_arm["alone"][1]
    measures = dict(ca.text_change_measures(pooled))
    arms = {a: dict(ca.text_change_measures(per_arm[a][1])) for a in per_arm}
    out[model] = {
        "folders": {a: str(per_arm[a][0]) for a in per_arm},
        "runs": {a: len(per_arm[a][1]) for a in per_arm},
        "valid": {a: sum(r["valid"] for r in per_arm[a][1]) for a in per_arm},
        "rooms": {a: [f"{i}{'.' + m if m else ''}" for i, m in per_arm[a][2]] for a in per_arm},
        "uncounted_sentences": ca.uncounted_sentences(pooled),
        **{k: {"pooled": "%d/%d" % measures[v], **{a: "%d/%d" % arms[a][v] for a in arms}} for k, v in LABELS.items()},
    }
json.dump(out, sys.stdout, indent=2)
print()
