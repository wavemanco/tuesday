#!/bin/bash
# A record rehearsal in a separate copy of the edited scratch tree: the slice's own hashes put in
# MEASURED_TUESDAY (plugin_version left at 0.2.0, so the manifest still agrees), then all of CI,
# the mutation suite, the harness tests and the sync check. Never the repository; no model calls.
set -e
D=/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/design/opus-ledger-sentence
rm -rf "$D/tree-rehearsal" && cp -a "$D/tree" "$D/tree-rehearsal" && cd "$D/tree-rehearsal"
export PYTHONDONTWRITEBYTECODE=1
# No real CLI reachable: the harness tests put their own stub `claude` first on PATH; drop the real one.
export PATH="$(echo "$PATH" | tr ":" "\n" | grep -v "^/opt/node22/bin$" | paste -sd:)"
command -v claude && { echo "a real claude CLI is still on PATH"; exit 1; } || true
unset TUESDAY_SCAN_ACCOUNT_EMAIL
python3 - <<'PY'
import re, sys
from pathlib import Path
sys.path.insert(0, "ci")
import check_skills as c
now = c.tuesday_digests()
p = Path("ci/check_skills.py"); t = p.read_text(encoding="utf-8")
for key in ("tuesday_sha256", "builds_sha256", "hub_sha256"):
    t, n = re.subn(rf'"{key}": "[0-9a-f]{{64}}"', f'"{key}": "{now[key]}"', t, count=1)
    assert n == 1, key
p.write_text(t, encoding="utf-8")
print("rehearsal: MEASURED_TUESDAY set to", {k: v[:8] for k, v in now.items()})
PY
set +e
timeout 900 python3 ci/check_skills.py > "$D/rehearsal-check.txt" 2>&1; echo "rehearsal check_skills exit=$?"; tail -1 "$D/rehearsal-check.txt"
timeout 2400 python3 ci/test_checks.py > "$D/rehearsal-test_checks.txt" 2>&1; echo "rehearsal test_checks exit=$?"; tail -1 "$D/rehearsal-test_checks.txt"
timeout 1200 python3 evals/test_harness.py > "$D/rehearsal-test_harness.txt" 2>&1; echo "rehearsal test_harness exit=$?"; tail -1 "$D/rehearsal-test_harness.txt"
timeout 300 python3 ci/sync.py --check > "$D/rehearsal-sync.txt" 2>&1; echo "rehearsal sync --check exit=$?"; cat "$D/rehearsal-sync.txt"
