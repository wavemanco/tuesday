"""The proposed amendment to ci/test_checks.py: the two README-count mutations read the count
from evals.json instead of pinning 8. Applied to a scratch copy only."""
import sys
from pathlib import Path

p = Path(sys.argv[1]) / "ci/test_checks.py"
s = p.read_text()
OLD_A = '''def break_readme_fixture_count(root: Path) -> str:
    """mock-interview's README described four fixtures while evals.json held six."""
    swap_once(root, "skills/mock-interview/README.md", "# 8 test fixtures", "# 4 test fixtures",
              "break_readme_fixture_count")
    return '"4 test fixtures" — evals.json has 8'
'''
NEW_A = '''def mi_fixture_count(root: Path) -> int:
    """The number of fixtures in mock-interview's evals.json, the number its README states.

    Read, not pinned: a round that adds a fixture updates the README's count, and a mutation
    pinned to the old number would go stale in the candidate that does it.
    """
    return len(json.loads((root / "skills/mock-interview/evals/evals.json").read_text())["evals"])


def break_readme_fixture_count(root: Path) -> str:
    """mock-interview's README described four fixtures while evals.json held six."""
    n = mi_fixture_count(root)
    swap_once(root, "skills/mock-interview/README.md", f"# {n} test fixtures", "# 4 test fixtures",
              "break_readme_fixture_count")
    return f'"4 test fixtures" — evals.json has {n}'
'''
OLD_B = '''def break_readme_fixture_noun(root: Path) -> str:
    swap_once(root, "skills/mock-interview/README.md", "# 8 test fixtures", "# 4 test cases", "break_readme_fixture_noun")
    return '"4 test cases" — evals.json has 8'
'''
NEW_B = '''def break_readme_fixture_noun(root: Path) -> str:
    n = mi_fixture_count(root)
    swap_once(root, "skills/mock-interview/README.md", f"# {n} test fixtures", "# 4 test cases",
              "break_readme_fixture_noun")
    return f'"4 test cases" — evals.json has {n}'
'''
for old, new in ((OLD_A, NEW_A), (OLD_B, NEW_B)):
    if s.count(old) != 1:
        raise SystemExit(f"expected one occurrence of {old[:60]!r}")
    s = s.replace(old, new)
p.write_text(s)
print("amended", p)
