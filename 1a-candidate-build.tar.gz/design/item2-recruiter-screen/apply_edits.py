"""Apply item 2's 1a edits to the scratch tree. Each old string must occur exactly once."""
import json, sys
from pathlib import Path

T = Path(sys.argv[1])

def swap(rel, old, new):
    p = T / rel
    s = p.read_text(encoding="utf-8")
    n = s.count(old)
    if n != 1:
        raise SystemExit(f"{rel}: expected one occurrence, found {n}: {old[:80]!r}")
    p.write_text(s.replace(old, new), encoding="utf-8")
    print(f"edited {rel}: {len(new) - len(old):+d} chars")

RUBRIC = "skills/mock-interview/references/question-rubric.md"
PERSONAS = "skills/mock-interview/references/personas.md"
README = "skills/mock-interview/README.md"

# Edit 1: the recruiter-screen coverage rule, after the pre-declared-deliverable bullet.
OLD1 = "- **When a provided research artifact is equally available to interviewers or rival candidates, differentiate from it — never recite it.**"
NEW1 = ("- **A recruiter screen gets a logistics question on each of pay, notice, location and the reason for leaving, and each one's guidance is a logistics slot.** "
        "They are the logistics the recruiter row of `references/personas.md` names, and the only safe answer to each is the candidate's own. "
        "Each is a question row like any other, tagged JD for pay, notice and location, the listed job's terms, and EXP for the reason for leaving. "
        "A figure, constraint or reason the candidate stated fills its slot in their own words, quoted in the row's Provenance and kept at its scope, "
        "and such a figure raises no defend-the-number slot (the answer-slot rule below). "
        "Where they stated none, the slot is an instruction in its own words — \"give your actual notice period\" — or a choice between named options that supplies no figure or reason, "
        "such as giving their own number or asking for the role's band first. "
        "It is never a blank to fill in, in square brackets (`references/output-discipline.md` rule 3), in underscores or as a stand-in such as \"X weeks\", "
        "and never a figure, salary history or reason the candidate did not give. "
        "Like an answer slot, a logistics slot is an instruction for the interview: it asks for no reply here and is not counted under `output-discipline.md` rule 1. "
        "A fact the candidate stated is not asked for again, and a requirement the posting or the recruiter states, such as an office pattern or a start date, is still a fit-snapshot row and keeps its gate rules.\n"
        + OLD1)
swap(RUBRIC, OLD1, NEW1)

# Edit 2: the explicit carve-out in the answer-slot paragraph (line 64).
OLD2 = "none names a method, model, baseline, process or responsibility, and a figure never raises a slot for any other practice."
NEW2 = (OLD2 + " A figure the candidate gives for the job's terms — the pay they want, the notice they owe, where and how often they can work — is the exception: it raises no slot at all, and in a recruiter screen it fills its logistics slot (the coverage rule above).")
swap(RUBRIC, OLD2, NEW2)

# Edit 3: the recruiter row of the relationship priors.
OLD3 = "| Recruiter screen | Conversational + light Skeptic | Logistics, motivation-consistency, and knockout checks in a friendly register; the risk is treating it as unscored |"
NEW3 = ("| Recruiter screen | Conversational + light Skeptic | Logistics (pay, notice, location and the reason for leaving, each a logistics slot under `references/question-rubric.md`), "
        "motivation-consistency, and knockout checks in a friendly register; the risk is treating it as unscored |")
swap(PERSONAS, OLD3, NEW3)

# Edit 4: README fixture count (registry total of this tree).
evals = json.loads((T / "skills/mock-interview/evals/evals.json").read_text(encoding="utf-8"))["evals"]
total = len(evals) + (0 if any(e.get("id") == 13 for e in evals) else 1)
swap(README, "│   └── evals.json                # 8 test fixtures with verifiable expectations",
     f"│   └── evals.json                # {total} test fixtures with verifiable expectations")

# Edit 5 and 6: README install steps and the walkthrough line, adopted verbatim from item 3's design (Edits 4 and 5)
# so the two slices write one text.
OLD5 = """## Install

Skills require code execution to be enabled. Steps below are current as of mid-2026; if a menu has moved, see https://support.claude.com (search "skills").

**Web — claude.ai**
1. Free/Pro/Max: Settings → Capabilities → enable "Code execution and file creation". Team/Enterprise: an owner enables Code execution and Skills under Organization settings → Skills.
2. Customize → Skills → upload the zip (the zip root must be the `mock-interview/` folder itself, not loose files), then toggle it on.
3. Uploaded skills are private to your account unless an org owner provisions them organization-wide.

**Desktop app**
Skills are account-level — anything enabled on claude.ai is already available; manage from Customize in the sidebar. Shortcut: if someone shares the packaged `.skill` file in a chat, the file card shows a "Save skill" button. Cowork sessions sync the skills enabled on your account at session start.

**Claude Code (CLI)**
Filesystem only — copy the `mock-interview/` folder to:
- `~/.claude/skills/mock-interview/` — personal, available in every project, or
- `.claude/skills/mock-interview/` — project-scoped, committed to the repo so teammates get it on clone.

New sessions pick it up automatically; it is also invokable directly as `/mock-interview`.
"""
NEW5 = """## Install

This module also comes inside Tuesday, which runs it when a request needs it. Install one or the other, not both: a module Claude can choose competes with Tuesday for every request. Tuesday's [Install section](../../README.md#install) covers every surface; to install this module on its own:

**claude.ai, on the web or in the desktop app**
1. Turn on code execution: Settings → Capabilities → *Code execution and file creation*. On a Team or Enterprise plan, an owner turns on code execution and skills under Organization settings.
2. Download [`mock-interview.skill`](../../dist/mock-interview.skill), upload it under Customize → Skills and switch it on. The desktop app uses the skills on your claude.ai account, so one upload covers both.

**Claude Code, in one project or in cloud sessions**
Unzip `dist/mock-interview.skill` into the project's `.claude/skills/`. It runs as `/mock-interview`, and Claude also picks it when a request matches its description.

**Claude Code, for yourself across your projects**
Install Tuesday's plugin or its personal install instead: both carry this module, hidden so it does not compete, and `/tuesday:mock-interview` (the plugin) or `/mock-interview` (the personal install) runs it directly.

Every test ran in Claude Code; this module on claude.ai is untested. A skill uploaded to claude.ai also reaches Claude Code, so keep one copy: where you use the plugin or a personal install, do not upload this module to claude.ai as well. If a menu has moved, see https://support.claude.com (search "skills").
"""
swap(README, OLD5, NEW5)
swap(README, "For a visual walkthrough of install and first use, open **`docs/workflow.html`** in any browser — click the boxes.",
     "For a visual walkthrough of first use, open **`docs/workflow.html`** in any browser — click the boxes. Install with the steps below: the walkthrough's own install boxes predate them.")

# Edit 7: append the fixture.
ev = T / "skills/mock-interview/evals/evals.json"
data = json.loads(ev.read_text(encoding="utf-8"))
fixture = json.loads((Path(sys.argv[2])).read_text(encoding="utf-8"))
if any(e.get("id") == fixture["id"] for e in data["evals"]):
    raise SystemExit("fixture id already present")
data["evals"].append(fixture)
ev.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print("appended eval", fixture["id"])
