# Item 2, round 1a slice · Recruiter screens

Scope: plan section "Item 2" (`docs/roadmap-now-l1-plan.md` lines 494–549), the rows marked **1a candidate** only: the `question-rubric.md` rule for logistics slots on pay, notice, location and the reason for leaving, with its explicit carve-out at `question-rubric.md:64`; the recruiter row of `personas.md`; the recruiter fixture, which is also item 4's ordinary scheduling contrast (plan lines 419, 438, 526); and the interview README's fixture count and install steps (plan line 512, with line 365 and line 879). Recorded practice and debriefs are 1b and nothing is designed for them here; section 6 says what 1a must leave room for.

Design only: no repository file or git state was touched. Every edit below was applied to a scratch copy of the tree at HEAD `8e72375` and checked there (section 9).

## 1. Summary

| | |
|---|---|
| Source files changed | `skills/mock-interview/references/question-rubric.md`, `skills/mock-interview/references/personas.md`, `skills/mock-interview/evals/evals.json`, `skills/mock-interview/README.md` |
| Generated files changed (sync, package) | `skills/tuesday/references/question-rubric.md`, `skills/tuesday/references/personas.md`; `dist/mock-interview.skill`, `dist/tuesday.skill`; in both `dist/claude-code/` and `dist/plugin/tuesday/skills/`: `mock-interview/README.md`, `mock-interview/references/question-rubric.md`, `mock-interview/references/personas.md`, `tuesday/references/question-rubric.md`, `tuesday/references/personas.md`. The plugin manifest and the marketplace file do not change here; the version moves at the 0.3.0 record |
| Not changed | `skills/mock-interview/SKILL.md` (and so the generated playbook `skills/tuesday/references/mock-interview.md`), `output-template.md`, every convention, every other module, `evals/*.py`, `ci/sync.py`, `ci/package.py` |
| New fixture | mock-interview eval **13**, one room (`denied`, the default for a fixture without a `research` block) |
| SKILL.md body | mock-interview **+0** characters: 18,311 of a 19,999-character ceiling, headroom 1,688 (section 6) |
| Other sizes, characters (no CI limit) | `question-rubric.md` 23,399 → 25,125 (+1,726; 71 → 72 lines); `personas.md` 11,419 → 11,531 (+112; 89 lines); README 6,955 → 7,297 (+342, all of it item 3's install text and walkthrough line; the count adds 1 more at 13); `evals.json` +6,481 |
| One CI amendment needed | `ci/test_checks.py`: two mutations pin the literal `# 8 test fixtures` in this README and go stale the moment the count changes. Proposed as a count-agnostic edit in the open 1a harness PR (section 5) |
| `check_skills.py` on the scratch tree | Only the expected `[tuesday]` digest failure. With the record rehearsed in a separate copy: all four CI steps pass, the mutation suite only with the section 5 amendment |

The README's install steps and walkthrough line are item 3's design, Edits 4 and 5 (`../item3-posting-signs/design.md`), adopted here word for word so that the two slices write one text. Apply them once.

## 2. Edits

### Edit 1 · `question-rubric.md`, Coverage rules: the recruiter-screen rule

A new bullet between "Every pre-declared deliverable…" (line 34) and "When a provided research artifact…" (line 35), since both neighbours are about what the recruiter announced. It covers each element of the plan's row: the four slots; the candidate's own figures and constraints or a choice between named options; no defend-the-number slot for such a figure; a missing figure as an instruction in the slot's own words ("give your actual notice period") or as a named choice; square-bracketed (`output-discipline.md` rule 3) and underscored blanks invalid; question tags and gate rules preserved; no guessed figure, no re-asked fact, no inferred salary history. It adds "a stand-in such as "X weeks"" to the invalid blanks, since a letter placeholder is the same blank without brackets. It adds no new type tag: `question_type` is a declared enum, and its column holds the five tags.

File: `skills/mock-interview/references/question-rubric.md`

Old (unique; the new bullet is inserted before it, and this line is kept):

~~~~text
- **When a provided research artifact is equally available to interviewers or rival candidates, differentiate from it — never recite it.**
~~~~

New:

~~~~text
- **A recruiter screen gets a logistics question on each of pay, notice, location and the reason for leaving, and each one's guidance is a logistics slot.** They are the logistics the recruiter row of `references/personas.md` names, and the only safe answer to each is the candidate's own. Each is a question row like any other, tagged JD for pay, notice and location, the listed job's terms, and EXP for the reason for leaving. A figure, constraint or reason the candidate stated fills its slot in their own words, quoted in the row's Provenance and kept at its scope, and such a figure raises no defend-the-number slot (the answer-slot rule below). Where they stated none, the slot is an instruction in its own words — "give your actual notice period" — or a choice between named options that supplies no figure or reason, such as giving their own number or asking for the role's band first. It is never a blank to fill in, in square brackets (`references/output-discipline.md` rule 3), in underscores or as a stand-in such as "X weeks", and never a figure, salary history or reason the candidate did not give. Like an answer slot, a logistics slot is an instruction for the interview: it asks for no reply here and is not counted under `output-discipline.md` rule 1. A fact the candidate stated is not asked for again, and a requirement the posting or the recruiter states, such as an office pattern or a start date, is still a fit-snapshot row and keeps its gate rules.
- **When a provided research artifact is equally available to interviewers or rival candidates, differentiate from it — never recite it.**
~~~~

### Edit 2 · `question-rubric.md:64`, the answer-slot paragraph: the explicit carve-out

The sentence that says a figure the candidate gave raises the defend-the-number slots now names the exception. It is worded by the figure's subject (the pay they want, the notice they owe, where and how often they can work), not as "a location figure", so that a CV figure about sites or depots stays a figure that gets defended.

File: `skills/mock-interview/references/question-rubric.md`

Old (unique):

~~~~text
none names a method, model, baseline, process or responsibility, and a figure never raises a slot for any other practice.
~~~~

New:

~~~~text
none names a method, model, baseline, process or responsibility, and a figure never raises a slot for any other practice. A figure the candidate gives for the job's terms — the pay they want, the notice they owe, where and how often they can work — is the exception: it raises no slot at all, and in a recruiter screen it fills its logistics slot (the coverage rule above).
~~~~

### Edit 3 · `personas.md`, Relationship priors: the recruiter row

File: `skills/mock-interview/references/personas.md`

Old (unique):

~~~~text
| Recruiter screen | Conversational + light Skeptic | Logistics, motivation-consistency, and knockout checks in a friendly register; the risk is treating it as unscored |
~~~~

New:

~~~~text
| Recruiter screen | Conversational + light Skeptic | Logistics (pay, notice, location and the reason for leaving, each a logistics slot under `references/question-rubric.md`), motivation-consistency, and knockout checks in a friendly register; the risk is treating it as unscored |
~~~~

The file stays at 89 lines, so the guidance group still needs no contents list for it (section 6).

### Edit 4 · interview README, folder tree: the fixture count

The count is the registry total of `evals.json` in digits (plan lines 365, 512). In the assembled 1a candidate that is **13**: 8 existing, item 1's teacher case, item 4's three invite positives and this recruiter case. In this slice's scratch tree, which holds only eval 13, it is 9.

File: `skills/mock-interview/README.md`

Old (unique):

~~~~text
│   └── evals.json                # 8 test fixtures with verifiable expectations
~~~~

New (assembled 1a candidate):

~~~~text
│   └── evals.json                # 13 test fixtures with verifiable expectations
~~~~

New (this slice's scratch tree, as verified):

~~~~text
│   └── evals.json                # 9 test fixtures with verifiable expectations
~~~~

### Edit 5 · interview README, `## Install`. Item 3's Edit 4, unchanged

Steps aligned with the root README's Install section: a `.skill` file from `dist/`, one copy of each skill, not beside Tuesday, and what was tested. The old steps copied the source folder, `evals/` included, into `.claude/skills/`. The `.skill` files leave the fixtures out, as every test did.

File: `skills/mock-interview/README.md`

Old (unique):

~~~~text
## Install

Skills require code execution to be enabled. Steps below are current as of mid-2026; if a menu has moved, see https://support.claude.com (search "skills").

**Web — claude.ai**
1. Free/Pro/Max: Settings → Capabilities → enable "Code execution and file creation". Team/Enterprise: an owner enables Code execution and Skills under Organization settings → Skills.
2. Customize → Skills → upload the zip (the zip root must be the `mock-interview/` folder itself, not loose files), then toggle it on.
3. Uploaded skills are private to your account unless an org owner provisions them organization-wide.

**Desktop app**
Skills are account-level — anything enabled on claude.ai is already available; manage from Customize in the sidebar. Shortcut: if someone shares the packaged `.skill` file in a chat, the file card shows a "Save skill" button. Cowork sessions sync the skills enabled on your account at session start.

**Claude Code (CLI)**
Filesystem only — copy the `mock-interview/` folder to:
- `~/.claude/skills/mock-interview/` — personal, available in every project, or
- `.claude/skills/mock-interview/` — project-scoped, committed to the repo so teammates get it on clone.

New sessions pick it up automatically; it is also invokable directly as `/mock-interview`.
~~~~

New:

~~~~text
## Install

This module also comes inside Tuesday, which runs it when a request needs it. Install one or the other, not both: a module Claude can choose competes with Tuesday for every request. Tuesday's [Install section](../../README.md#install) covers every surface; to install this module on its own:

**claude.ai, on the web or in the desktop app**
1. Turn on code execution: Settings → Capabilities → *Code execution and file creation*. On a Team or Enterprise plan, an owner turns on code execution and skills under Organization settings.
2. Download [`mock-interview.skill`](../../dist/mock-interview.skill), upload it under Customize → Skills and switch it on. The desktop app uses the skills on your claude.ai account, so one upload covers both.

**Claude Code, in one project or in cloud sessions**
Unzip `dist/mock-interview.skill` into the project's `.claude/skills/`. It runs as `/mock-interview`, and Claude also picks it when a request matches its description.

**Claude Code, for yourself across your projects**
Install Tuesday's plugin or its personal install instead: both carry this module, hidden so it does not compete, and `/tuesday:mock-interview` (the plugin) or `/mock-interview` (the personal install) runs it directly.

Every test ran in Claude Code; this module on claude.ai is untested. A skill uploaded to claude.ai also reaches Claude Code, so keep one copy: where you use the plugin or a personal install, do not upload this module to claude.ai as well. If a menu has moved, see https://support.claude.com (search "skills").
~~~~

### Edit 6 · interview README, line 7. Item 3's Edit 5, unchanged

`docs/workflow.html` still draws the old install boxes until 1b updates it (E22; that file is in the 1b write boundary only).

Old (unique):

~~~~text
For a visual walkthrough of install and first use, open **`docs/workflow.html`** in any browser — click the boxes.
~~~~

New:

~~~~text
For a visual walkthrough of first use, open **`docs/workflow.html`** in any browser — click the boxes. Install with the steps below: the walkthrough's own install boxes predate them.
~~~~

Line 66 (Modes, Drill) is left as it is: the plan cites it in both README rows, and the change it needs, the recorded format, is 1b's (E22).

### Edit 7 · `skills/mock-interview/evals/evals.json`: append eval 13

The file round-trips byte for byte through `json.dumps(data, indent=2, ensure_ascii=False) + "\n"`, so the diff is the appended object alone. The fixture is in section 3.

## 3. The new fixture: mock-interview eval 13

**Id 13** assumes the assembly order of the plan's 1a items: item 1's teacher case 9, item 4's three invite positives 10–12, this case 13. If the assembly orders them otherwise, change `id` alone. No other field refers to it (`enumerate` names expectation 11, not an id).

**One prompt, two outcomes.** It is item 2's recruiter case and item 4's named scheduling contrast at once (plan lines 419, 438, 526): a named recruiter at a named employer books an ordinary recruiter screen by LinkedIn message, and the screen itself is a phone call. Item 4's designer should not write a second copy. Expectation 2 is the contrast's outcome and should be read against item 4's definitions of a warning and a pointer.

**Inputs.** The employer, the recruiter and the candidate are invented. No domain, URL or address appears, so E9's `.example` rule has nothing to apply to. Sam states the pay wanted (£42,000, inside the advert's £38,000–£44,000), the location limit (north Bristol, two office days fine, not more than three) and the reason for leaving (office closing, relocation offer declined). Sam gives **no notice period**, which Hannah's message says she will ask about: "with some answers absent". One CV figure (stock-count discrepancies down by about a third) is there so that the carve-out can be seen not to reach work figures. There is no start-date requirement, so notice is no gate and Step 1 (d) has no gate question to ask. There are no sentinels, no research block and no relative dates.

**Keys.** `checks: ["quotes"]` with `candidate_text` (three entries, each in the prompt) as in every interview fixture; `enumerate: [11]`, the no-overclaim expectation, as in every interview fixture; no `delivers` key, since the turn delivers a pack and keeps its watch-out (the `{{closing}}` clause carries the line).

~~~~json
{
  "id": 13,
  "prompt": "Can you help me get ready for a recruiter screen? I applied last week for an Operations Coordinator job at Quillmoor Diagnostics, and their recruiter, Hannah Lowther (Talent Partner), has been messaging me on LinkedIn to set up the call. Her last message: 'Thanks Sam, that's booked: Thursday at 2pm, a 30-minute phone call with me. I'll ring the mobile number on your application. I'd like to cover your salary expectations, your notice period, how the hybrid pattern would work for you and what's prompting a move, and then I'll tell you about the team and the next steps. If anything changes, message me here.' THE ADVERT: 'Operations Coordinator — Quillmoor Diagnostics (diagnostic-test manufacturer, about 400 staff). Coordinate production schedules between planning, the warehouse and QA; track supplier deliveries and chase late orders; keep stock records accurate; report weekly on on-time dispatch. Requirements: 2+ years in operations or logistics coordination; confident with Excel; ERP experience (SAP or similar) a plus. £38,000–£44,000. Hybrid: two days a week at our Avonmouth site in Bristol.' ABOUT ME (call me Sam): 4 years as a logistics coordinator at a building-supplies wholesaler. I schedule deliveries for our three depots and chase suppliers when orders slip. I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year. Never used SAP — we run our own in-house stock system. What I'd tell her: I'm hoping for £42,000. I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three. Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want.",
  "expected_output": "A complete recruiter-screen prep pack with no legitimacy warning or pointer, since the LinkedIn message only books a phone call: its logistics rows on pay, notice, location and the reason for leaving use Sam's own £42,000, commute limit and reason, leave the unstated notice period as an instruction for the call rather than a blank or a guess, and give the pay figure no defend-the-number coaching, while the stock-count figure still gets its defend-the-number question.",
  "files": [],
  "expectations": [
    "{{pack_first}}",
    "No legitimacy warning and no pointer. Hannah Lowther booking the screen by LinkedIn message is ordinary chat scheduling, and the screen itself is a phone call, so nothing in the message or the pack warns about the invitation or its sender, says or suggests that Quillmoor Diagnostics, its advert or Hannah may not be genuine, or points Sam to job-underwriter, or to any other check of the invitation or the advert, before or instead of the prep; the prep pack is delivered as for any recruiter screen. The dossier offer's own line is not a pointer",
    "The question banks hold a logistics question on each of pay, notice, location and the reason for leaving, the four topics Hannah's message says she will cover, and the guidance of each is a logistics slot built only from what Sam said, each stated answer quoted in its row's Provenance. Pay uses Sam's own £42,000. Location uses Sam's own words: living in north Bristol, two days at Avonmouth being fine, and not wanting more than three. The reason for leaving uses Sam's own reason, the Bristol office closing and the only offer being a relocation to Reading that Sam does not want, kept at its stated scope: not turned into a complaint about the current employer, a wish for growth or any other reason Sam did not give. Notice, which Sam never stated, is an instruction to give the actual notice period on the call, or a choice between ways to answer that supplies no figure, and no cell anywhere states, estimates or suggests a notice period, start date or pay figure Sam did not give. No logistics slot is a blank to fill in: square brackets other than a provenance label, underscores, and a stand-in such as 'X weeks' or '£XX,000' each fail this",
    "Sam's £42,000 fills the pay slot and raises nothing else. No row or cell asks Sam to defend it, or coaches how it was reached, what it is sensitive to, the assumption behind it Sam would defend least or which part of it was Sam's; no cell puts a pay figure, range or counter-offer in Sam's mouth other than £42,000, though the advert's £38,000–£44,000 may be cited as the advert's; and nothing states, estimates or asks what Sam earns now or has earned before. Nothing Sam already said is asked for again, in the message's questions or in the pack: not the pay figure, the commute, the office days or the reason for leaving",
    "The stock-count figure, discrepancies down by about a third, gets a defend-the-number EXP question, so the pay figure's exemption does not reach Sam's work figures — {{defend_number}}",
    "Every question row, the logistics rows included, carries one of the five type tags (VAL, EXP, JD, CO, CASE) in its Type cell and no tag of its own such as LOG or Logistics; and the advert's two days a week at Avonmouth, which Sam's stated commute meets, is not raised as a gap, a gate question or a doubt",
    "{{provenance_column}}",
    "{{interviewer_read}}. Here the only source about Hannah is her own LinkedIn message, so nothing about her style, background or preferences appears beyond what that message says",
    "{{values_source}}. {{loop_source}}. Here the loop source is Hannah's message, one 30-minute phone call with her, and Quillmoor's values were neither supplied nor read",
    "{{closing}}. Here no question asks for the notice period, which the pack leaves as a slot for the call; the upgrade menu may name it",
    "{{no_overclaim}} {{question_premise}}"
  ],
  "enumerate": [
    11
  ],
  "checks": [
    "quotes"
  ],
  "candidate_text": [
    "Can you help me get ready for a recruiter screen? I applied last week for an Operations Coordinator job at Quillmoor Diagnostics, and their recruiter, Hannah Lowther (Talent Partner), has been messaging me on LinkedIn to set up the call.",
    "4 years as a logistics coordinator at a building-supplies wholesaler. I schedule deliveries for our three depots and chase suppliers when orders slip. I rebuilt our stock-count spreadsheet and discrepancies fell by about a third over a year. Never used SAP — we run our own in-house stock system.",
    "What I'd tell her: I'm hoping for £42,000. I live in north Bristol, so two days at Avonmouth is fine, but I wouldn't want more than three. Honestly, I'm looking because our Bristol office is closing next year and the only offer is relocating to Reading, which I don't want."
  ]
}
~~~~

## 4. Answer key for eval 13

| # | A correct response | Fails it |
|---|---|---|
| 1 `pack_first` | The pack in the first message, any questions alongside it | Opening with questions, a checklist or a consent request alone |
| 2 No warning, no pointer (item 4 contrast) | Presents the pack as for any recruiter screen. Nothing about the invitation's legitimacy | Any warning about the LinkedIn message, the phone call or the sender; "may not be genuine", "verify the recruiter"; a pointer to job-underwriter or to any check of the invite or the advert. An ordinary dossier-offer line is not a pointer |
| 3 Logistics slots (core) | Four bank rows, one each for pay, notice, location and the reason for leaving. Pay, location and the reason rest on Sam's quoted words in Provenance, at their scope ("say £42,000"; "two days at Avonmouth is fine, more than three is not"; "the office is closing and you don't want to move to Reading"). Notice is "give your actual notice period" or a named choice that supplies no figure ("give it, or say you'll confirm it from your contract") | A missing row; "your notice is probably a month"; "say you can start in four weeks"; `[X weeks]`, `____ weeks`, "X weeks", "£XX,000"; a reason Sam never gave ("looking for growth", "my manager…"); the reason turned into a complaint about the employer |
| 4 Pay figure and re-asking (core) | £42,000 is said as Sam's figure and nothing more. The advert's band may be cited as the advert's. No question asks again for pay, the commute, office days or the reason | "How did you arrive at £42k?"; "what is it sensitive to", "weakest assumption"; "ask for £44,000", "give a range of £40–45k"; "you're currently on about £38k" or any current or past salary; a closing question "Is £42k firm?" |
| 5 Stock-count figure | A defend-the-number EXP question on the stock-count figure, in Sam's words and slots only (`{{defend_number}}`) | No such question (the carve-out overreaching), or one that supplies a counting method or baseline |
| 6 Type tags and the office pattern | Every Type cell is one of VAL, EXP, JD, CO, CASE (JD for pay, notice and location, EXP for the reason). The advert's two days at Avonmouth is met by Sam's words and is not questioned | A LOG or Logistics tag; a dual-token cell; a gate question or doubt about the commute |
| 7 `provenance_column` | A Provenance column before the guidance, one label per row | Labels trailing the rationale |
| 8 `interviewer_read` | No interviewer read beyond what Hannah's message says | An invented style or background for Hannah |
| 9 `values_source`, `loop_source` | Values unestablished, said so; the loop is the one 30-minute phone call | Values or rounds from memory |
| 10 `closing` | Upgrade menu last in the file; offers, at most three questions and the exact watch-out close the message. No question asks for the notice period, though the upgrade menu may name it | A question asking for the notice period; the watch-out inside the file or not last |
| 11 `no_overclaim`, `question_premise` (enumerated) | Every cell about Sam's past traces to a quote or is a slot | Scheduling deliveries for "three depots" promoted into running them; SAP experience implied |

Deterministic checks on the run: `quotes` (a Provenance quotation not in `candidate_text` fails unless its origin names another source, so a guessed "My notice is one month" in quotation marks fails; the recruiter's words need an origin such as "— Hannah's message") and `watch_out`. Neither the bracket rule nor the blank rule has a deterministic check (`evals/output_checks.py` has none): expectation 3 is graded only.

**Recommended core screen (E1).** Expectations 2, 3 and 4 jointly, both graders: the plan's bar for the recruiter case (line 537: grounded pay, notice, location and reason; usable slots for missing figures; no defend-the-number on the stated pay; no bracketed or underscored blank) is 3 and 4, and item 4's "require no warning on the named scheduling contrast" (line 442) is 2, which the plan counts in this case (line 450). Expectations 1 and 5–11 and both checks go to the regression panel, as for every interview room. A fixture has no `core` key (only transcript scripts do), so the manifest freezes this membership. This is the one 1a core screen for item 2 among the seven E1 counts per model (plan line 739). See open question 2.

## 5. The CI amendment this slice needs: `ci/test_checks.py`

`break_readme_fixture_count` and `break_readme_fixture_noun` swap the literal `# 8 test fixtures` in `skills/mock-interview/README.md`. Once Edit 4 lands, `swap_once` exits with "expected one '# 8 test fixtures' … it has gone stale" and the whole mutation step fails (reproduced, section 9). The 1a candidate's write boundary allows `ci/test_checks.py` "only for an amendment caused by rule 2's exact text", and the 1b candidate's write boundary does not list `ci/test_checks.py` at all, though 1b moves the count again (to 15).

**Recommended:** make the two mutations read the count from `evals.json`, in the open 1a harness PR (#20), whose write boundary lists `ci/test_checks.py`. Then neither candidate edits the file, and the mutations still fail the README on a wrong count. Verified in scratch on HEAD unchanged (8 fixtures) and on the rehearsed candidate (9): 394 mutations detected, 123 must-pass cases accepted in both. `json` is already imported there.

Old (unique):

~~~~text
def break_readme_fixture_count(root: Path) -> str:
    """mock-interview's README described four fixtures while evals.json held six."""
    swap_once(root, "skills/mock-interview/README.md", "# 8 test fixtures", "# 4 test fixtures",
              "break_readme_fixture_count")
    return '"4 test fixtures" — evals.json has 8'
~~~~

New:

~~~~text
def mi_fixture_count(root: Path) -> int:
    """The number of fixtures in mock-interview's evals.json, the number its README states.

    Read, not pinned: a round that adds a fixture updates the README's count, and a mutation
    pinned to the old number would go stale in the candidate that does it.
    """
    return len(json.loads((root / "skills/mock-interview/evals/evals.json").read_text())["evals"])


def break_readme_fixture_count(root: Path) -> str:
    """mock-interview's README described four fixtures while evals.json held six."""
    n = mi_fixture_count(root)
    swap_once(root, "skills/mock-interview/README.md", f"# {n} test fixtures", "# 4 test fixtures",
              "break_readme_fixture_count")
    return f'"4 test fixtures" — evals.json has {n}'
~~~~

Old (unique):

~~~~text
def break_readme_fixture_noun(root: Path) -> str:
    swap_once(root, "skills/mock-interview/README.md", "# 8 test fixtures", "# 4 test cases", "break_readme_fixture_noun")
    return '"4 test cases" — evals.json has 8'
~~~~

New:

~~~~text
def break_readme_fixture_noun(root: Path) -> str:
    n = mi_fixture_count(root)
    swap_once(root, "skills/mock-interview/README.md", f"# {n} test fixtures", "# 4 test cases",
              "break_readme_fixture_noun")
    return f'"4 test cases" — evals.json has {n}'
~~~~

The alternative, pinning `# 13 test fixtures` and "evals.json has 13" in the candidate, needs the owner to widen the 1a candidate's `ci/test_checks.py` boundary, and the same edit again in 1b, outside that write boundary.

## 6. SKILL.md budget and what 1a leaves for 1b

Measured with `ci/check_skills.py`'s own counter (`skill_body()`, then `len(body) // CHARS_PER_TOKEN` against `MAX_BODY_TOKENS`): the body passes while `len(body) // 4 < 5000`, so at most **19,999 characters**.

| Skill | Body now | This slice | Ceiling | Headroom |
|---|---:|---:|---:|---:|
| mock-interview | 18,311 chars, 156 lines, about 4,577 tokens | **+0** | 19,999 | 1,688 |
| job-underwriter (for reference) | 19,768 | +0 | 19,999 | 231 |

This slice puts its rules in the references, as the plan asks. No SKILL.md text is needed for them: Step 3 already sends the writer to `personas.md` and `question-rubric.md` before any question is written.

**What 1a must leave room for.** The plan holds mock-interview's SKILL.md growth to about 1,200 characters across 1a and 1b and reserves the rest of 1a's share for 1b's Step 5 and drill pointers (line 322). A draft of each 1b pointer, one sentence with its file reference, measures 191 and 202 characters (393 together):

- Step 5: "A claim the candidate reports making to an interviewer stays a record of what was said, never evidence; the debrief rule is the `Evidence, verbatim` bullet of `references/output-template.md`."
- Drill: "A recorded or one-way interview gets one timed take per question and no follow-ups, and a conversational AI interviewer keeps them: the format paths are in `references/output-template.md` (Drill mode)."

So items 1 and 4 together should hold mock-interview's SKILL.md to about **+800 characters** in 1a (1,200 − about 400), and never past **+1,295** (1,688 − 393), the point at which 1b's pointers no longer fit under the CI ceiling. Record 1a's actual use at the freeze.

Other room 1b needs from this slice's files:

- `personas.md` is 89 lines. The guidance group requires a `## Contents` list once a reference passes 100 lines, so 1b's recorded/AI-run row and timing strategy either stay within 11 lines or add the list.
- `question-rubric.md` gains one bullet in Coverage rules. 1b's one-way sizing and its scoped exception to follow-ups and hold-then-concede (plan line 503) edit the same two sections. The new bullet's anchors (the deliverable and research-artifact bullets) are unchanged, so 1b's anchors at lines 25–38 and 52–68 shift by one line only.
- The README count moves to 15 in 1b. With section 5's amendment, that needs no CI edit.

## 7. Checks and CI rules each change touches

| Change | Groups and rules it meets | Result in scratch |
|---|---|---|
| Edit 1, rubric bullet | `answer-keys` (two quoted spans, "give your actual notice period" and "X weeks", against every mock-interview prompt, and through Tuesday against every module's prompts; prose at six words); `citations` (quoted spans against `citations.md`); `sections` (`references/output-discipline.md` rule 3 is a rule, not a §); `parameters` (no budget or close phrase in it); `counts`; `wording`; `guidance` (72 lines, Contents already present); `tuesday` and `package` (synced copy, both builds); mutations pinned on rubric literals (``Confidence (`evidence-conventions.md` §2)``, `RUBRIC_EXAMPLE`, `keep_time_in_lead`) | pass; 1,047 → 1,049 answer-key spans, none shared |
| Edit 2, carve-out | the same groups; `parameters` reads it as a reference | pass |
| Edit 3, personas row | `wording`'s personas rules (no "pre-map"; the quote-or-slot pointer line kept); `counts` ("The seven personas" heading untouched); `readmes` ("7 interviewer personas" in the tree unchanged); `guidance` (89 lines); mutations pinned on `## Relationship priors` and the other personas literals | pass |
| Edits 4–6, README | `readmes` (tree and count against `evals.json`); `wording` (no "front door"); `parameters` (the README's "three questions max" sentence untouched); `package` (the README ships in both builds and the `.skill`); mutations `break_readme_fixture_count`, `break_readme_fixture_noun` | pass, but the two mutations need section 5 |
| Edit 7, eval 13 | `evals` (clauses defined and used, no braces left, id unique, no `delivers`, no dates); `fixtures` (each `candidate_text` entry in the prompt; quotes check declared with a list); `parameters` (the closing clause's "At most three questions" = `question_budget` 3; no other budget or close phrase); `watch-out` (the closing clause carries the exact line: 28 → 29 copies); `wording` (no retired wording in expectations); `answer-keys` (the prompt against installed text) | pass; mock-interview 8 → 9 evals, 90 → 101 expectations; parameters 19 → 21 restatements |
| Generated copies | `ci/sync.py --check`; `package`; `builds`; `tuesday` (`MEASURED_TUESDAY`) | current; the digest differs, as expected until the 0.3.0 record |

Plan-level rules: the write boundary row "1a candidate" lists all four source files. `conventions/` and `skills/resume-tailor/` are untouched (Round 1 requires empty diffs). `evals/*.py`, `ci/sync.py` and `ci/package.py` are untouched. No routing text or description changes (plan line 520).

## 8. Risks, and how the bar catches a regression

- **The carve-out reaching CV figures.** Read loosely, "location figure" could exempt a work figure about sites or depots from defend-the-number coaching. Edit 2 names the figure by its subject instead. Caught by eval 13 #5 (the stock-count figure must still be defended) and the existing `defend_number` expectations in MI2 and MI5, which E9 reruns.
- **Guessed or placeholder slots.** A model that fills the notice slot with "one month" or `[X weeks]` fails eval 13 #3. No deterministic check reads blanks, so graders alone hold it; two graders must pass it.
- **Fabricated pay coaching.** Pushing for the band's top, a range, or a current-salary estimate fails #4. A quoted invented figure also fails `quotes`.
- **A false warning on ordinary scheduling.** Item 4's new Step 0 case and template lines could fire on a LinkedIn booking. #2 is the contrast, and it is in the recommended core screen.
- **A regression room now in scope.** MI8's loop opens with a 30-minute round with the recruiter, so its round-1 mini-pack now owes four logistics slots. Dara states none of the four, so all four are instructions. MI8's inputs cannot change (E9 baseline reuse), and its expectations do not read a pay or notice figure the pack might invent. The no-overclaim family still covers cells about the past. Recommend the 1a record read MI8's round-1 rows, report-only, for invented figures and blanks.
- **Logistics rows in non-recruiter rounds.** The rule is scoped to a recruiter screen. A pack that adds them elsewhere breaks no expectation but adds rows. Report it if graders note it, and do not gate on it.
- **Quoting the recruiter's words without an origin.** A logistics row that quotes Hannah's "your notice period" in Provenance with no origin is held to `candidate_text` and fails `quotes`, an existing hazard for every recruiter-email fixture (MI5, MI8). It falls in the regression panel's quote family, not the core screen.
- **Answer keys at assembly.** Items 1 and 4 add rubric or template text and fixtures. Rerun `--only answer-keys` on the assembled tree: this slice's quoted spans passed against this tree's prompts only.
- **Core-screen arithmetic.** A joint screen of three expectations may sit below the 95% nominal per-screen rate E1's whole-round estimate assumes (plan line 731). The resampled estimate before the freeze should use the frozen bundle.

## 9. Verification

Scratch tree: `/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/design/item2-recruiter-screen/tree` (HEAD `8e72375` plus Edits 1–7, then `ci/sync.py` and `ci/package.py`). Scripts: `apply_edits.py` (the edits, each old string asserted unique), `amend_test_checks.py` (section 5), `probe/probe_fixture.py`.

| Step | Result |
|---|---|
| `python ci/check_skills.py`, baseline copy of HEAD | All checks passed (265 assertions): `check-baseline.txt` |
| `python ci/check_skills.py`, scratch tree | 1 problem: `[tuesday] … (tuesday_sha256, builds_sha256 differ)`, the expected digest failure; every other group passes (`check-final.txt`). New digests: tuesday_sha256 `8d99eaf26af1234a4b95815a88244a653022af558a94da25e78dc29a9d37f606`, builds_sha256 `098f488556366856906855f66a77d5945e46d557357b537e435e44d9c7010f65` (this slice alone; the assembled candidate's differ) |
| `python ci/sync.py --check` | every generated copy is current |
| Record rehearsal in a separate copy (`rehearsal/`: `MEASURED_TUESDAY` set to those digests and 0.3.0, packaged) | `check_skills.py` all checks passed; `sync.py --check` current; `evals/test_harness.py` all harness tests passed |
| `python ci/test_checks.py`, rehearsal, unamended | **fails**: `break_readme_fixture_count expected one '# 8 test fixtures' … gone stale` (`test-checks-unamended.txt`) |
| `python ci/test_checks.py`, rehearsal, with section 5 | All 394 mutations detected, and all 123 must-pass cases accepted (`test-checks-amended.txt`) |
| `python ci/test_checks.py`, HEAD with section 5 only | All 394 mutations detected, and all 123 must-pass cases accepted (`test-checks-head-amended.txt`) |
| Offline probe: eval 13 through `fixture_clauses.load_cases` and `output_checks.run_checks` on synthetic packs, no model called | Loads with 11 expectations, room `denied`, stem `mock-interview-13.run0`. A correct pack passes `quotes` (7 findings) and `watch_out`. The same pack quoting "My notice is one month" as Sam's fails `quotes` on that row (`probe/probe-output.txt`) |

## 10. Open questions for the owner

1. **The `ci/test_checks.py` amendment.** Land the count-agnostic version in the 1a harness PR #20 (recommended), or widen the 1a candidate's boundary to pin `13`? Without one of them, the mutation step fails on the 1a candidate, and again on 1b.
2. **The core screen for eval 13.** Is it expectations 2, 3 and 4 jointly (recommended, since the plan counts the contrast in this case), or 3 and 4, with item 4's no-warning outcome as a separate zero-observed bar?
3. **Re-asking as a core outcome.** #4 holds "never re-ask for a stated fact" in the core screen, so a closing question like "Is £42k firm?" fails the screen. Keep it core, or move that sentence to the regression panel?
4. **MI8's recruiter round.** Accept a report-only read of MI8's round-1 logistics rows in the 1a record, since its expectations cannot change before Round 2?
5. **A user-facing mention.** The plan does not ask the interview README to describe recruiter-screen slots in 1a. Leave that to the 0.3.0 record's root README usage update, or add one line under "What to provide" now?
