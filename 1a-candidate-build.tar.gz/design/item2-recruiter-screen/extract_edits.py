"""Print each edit of apply_edits.py as old/new blocks, exactly as the script applies them."""
import json, sys
from pathlib import Path
src = Path("apply_edits.py").read_text()
src = src[:src.index("# Edit 7")]
src = src.replace("T = Path(sys.argv[1])", "T = Path('/home/user/tuesday')")
recorded = []
src = src.replace("def swap(rel, old, new):", "def swap(rel, old, new):\n    recorded.append((rel, old, new)); return\n")
ns = {"recorded": recorded, "__name__": "x"}
exec(compile(src, "apply_edits.py", "exec"), ns)
out = []
for rel, old, new in recorded:
    out.append({"file": rel, "old": old, "new": new})
Path("edits.json").write_text(json.dumps(out, indent=1, ensure_ascii=False))
for e in out:
    print(e["file"], len(e["old"]), len(e["new"]), Path("/home/user/tuesday", e["file"]).read_text(encoding="utf-8").count(e["old"]))
