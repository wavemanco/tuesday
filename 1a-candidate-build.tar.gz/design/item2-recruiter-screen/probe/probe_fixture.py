"""Offline probe: load fixture 13 from the scratch tree the way the runner does, and run the
deterministic checks on synthetic responses. No model is called."""
import json, sys
from pathlib import Path

TREE = Path(sys.argv[1])
sys.path.insert(0, str(TREE / "evals"))
import fixture_clauses, output_checks, run_fixtures  # noqa: E402

cases = fixture_clauses.load_cases(TREE / "skills/mock-interview/evals/evals.json")
case = next(c for c in cases if c["id"] == 13)
print("modes:", run_fixtures.modes_of(case), "stem:", run_fixtures.stem_for("mock-interview", case, "denied", 0))
print("expectations:", len(case["expectations"]), "enumerate:", case["enumerate"])
watch = output_checks.declared_watch_out((TREE / "skills/mock-interview/SKILL.md").read_text(encoding="utf-8"))

SNAPSHOT = """## Fit snapshot

| # | JD requirement | Your evidence, verbatim | Confidence | Gap type | Gap and bridge language | Provenance |
|---|---|---|---|---|---|---|
| F1 | 2+ years in operations or logistics coordination | "4 years as a logistics coordinator at a building-supplies wholesaler" — your message | high | none | Meets it as stated | [grounded] |
| F2 | ERP experience (SAP or similar) a plus | "Never used SAP — we run our own in-house stock system." — your message | medium | transferability | Your material says an in-house system, not SAP | [grounded] |
"""

def pack(rows: str) -> str:
    return ("Your prep pack is saved as quillmoor_operations-coordinator_interview_pack.md.\n\n"
            "Say the word and I'll play the recruiter on A1.\n"
            "I can also save a tuesday-dossier.md recording the gaps this prep exposed.\n\n"
            "Do you want the deeper research pass on Quillmoor?\n\n" + watch + "\n"
            "----- file the response produced: quillmoor_operations-coordinator_interview_pack.md -----\n"
            "# Quillmoor Diagnostics — Operations Coordinator\n\n" + SNAPSHOT + "\n## Question banks\n\n"
            "| # | Question | Type | Provenance | Answer guidance | Rationale |\n|---|---|---|---|---|---|\n" + rows +
            "\n## Upgrade menu\n\n- Your notice period → the notice slot in A2 becomes your own words\n")

GOOD = (
    '| A1 | "What are your salary expectations?" | JD | [grounded] "I\'m hoping for £42,000." | Logistics slot: say £42,000, in your own words. | Hannah\'s message names salary; F1 |\n'
    '| A2 | "What\'s your notice period?" | JD | [grounded] "your notice period" — Hannah\'s LinkedIn message | Logistics slot: give your actual notice period, as your contract states it. | Hannah\'s message names it |\n'
    '| A3 | "How would the hybrid pattern work for you?" | JD | [grounded] "I live in north Bristol, so two days at Avonmouth is fine, but I wouldn\'t want more than three." | Logistics slot: two days at Avonmouth is fine; more than three is not, said in your own words. | F1 |\n'
    '| A4 | "What\'s prompting the move?" | EXP | [grounded] "our Bristol office is closing next year and the only offer is relocating to Reading, which I don\'t want" | Logistics slot: the office closing and not wanting to relocate to Reading, in your own words. | F1 |\n'
    '| A5 | "Walk me through how the discrepancy figure was counted." | EXP | [grounded] "discrepancies fell by about a third over a year" | How it was counted, in your own words; if you do not know, say so. | Defend-the-number |\n')
BAD_QUOTE = GOOD.replace('"your notice period" — Hannah\'s LinkedIn message', '"My notice is one month"')


for label, body in (("correct", pack(GOOD)), ("guessed-notice quote", pack(BAD_QUOTE))):
    rec = output_checks.run_checks(case, "denied", body, research_log=[], watch_out=watch, generated_files=[])
    rows = [(i["check"], i.get("target"), i["verdict"], i.get("kind"), (i.get("why") or "")[:120]) for i in rec["checks"]]
    print(f"== {label}: status {rec['status']}")
    for r in rows:
        if r[2] != "PASS" or r[0] != "quotes":
            print("   ", r)
    print("    quotes verdicts:", [r[2] for r in rows if r[0] == "quotes"])
