"""Apply item 1's skill-text edits to the scratch tree given as argv[1]. Each old string must occur exactly once."""
import sys
from pathlib import Path
root = Path(sys.argv[1])

EDITS = {
"skills/job-underwriter/SKILL.md": [
 ("- **Government ID.** If an upload is or contains a passport, license, or ID number, don't use it, say it isn't needed for evaluating a role, and proceed. Check content, not filename.",
  "- **Government ID.** A passport, driver's license, national ID, tax ID, social-security number or background check, pasted or uploaded: don't repeat or use the document or its number; say it isn't needed. A license or registration is evidence as stated, by kind, issuer, class, status and expiry; its number goes in no research call, and checking it is the candidate's."),
 ("A `pack_feedback` section (written by mock-interview) is discovery input: its rehearsal gaps and new evidence leads become questions to verify, never verified evidence. A dossier with a higher major version than 1.x: say so and proceed standalone. No dossier at all: run standalone at full value — the dossier is an enhancer, never a gate.",
  "A `pack_feedback` section is discovery input: its rehearsal gaps and new evidence leads become questions to verify, never verified evidence."),
],
"skills/mock-interview/SKILL.md": [
 ("- **Government ID.** If an upload is or contains a passport, license, or ID number, don't use it, tell the user it isn't needed for interview prep, and proceed without it. Check content, not filename.",
  "- **Government ID.** A passport, driver's license, national ID, tax ID, social-security number or background check, pasted or uploaded: don't repeat or use the document or its number; say it isn't needed for interview prep, and proceed. A license or registration is evidence as stated: its kind, issuer, class, status and expiry go in the gap-and-bridge language, its number in no research call, and checking it is the candidate's. Check content, not filename."),
],
"skills/job-underwriter/README.md": [
 ("**Privacy by design:** never upload government IDs — the skill refuses them.",
  "**Privacy by design:** never upload government IDs — the skill won't repeat or use one. A professional license or registration counts as evidence, described by its kind, issuer, status and expiry, and its number never goes into a web search or page fetch."),
 ("# 6 test fixtures with verifiable expectations", "# 7 test fixtures with verifiable expectations"),
],
"skills/mock-interview/README.md": [
 ("**Privacy by design:** never upload government IDs — the skill refuses them.",
  "**Privacy by design:** never upload government IDs — the skill won't repeat or use one. A professional license or registration counts as evidence, described by its kind, issuer, status and expiry, and its number never goes into a web search or page fetch."),
 ("# 8 test fixtures with verifiable expectations", "# 9 test fixtures with verifiable expectations"),
],
}
for rel, pairs in EDITS.items():
    p = root / rel
    text = p.read_text(encoding="utf-8")
    for old, new in pairs:
        n = text.count(old)
        if n != 1:
            sys.exit(f"{rel}: old string occurs {n} times: {old[:70]!r}")
        text = text.replace(old, new)
    p.write_text(text, encoding="utf-8")
    print("edited", rel)
