#!/bin/bash
# A record rehearsal in a separate copy: the candidate's own hashes in MEASURED_TUESDAY, and the two
# README fixture-count literals in ci/test_checks.py moved to the count this slice gives; then all of CI
# and the mutation suite. Never the repository.
set -e
D=/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/design/item1-licences-ids
rm -rf "$D/tree-rehearsal" && cp -a "$D/tree" "$D/tree-rehearsal" && cd "$D/tree-rehearsal"
export PYTHONDONTWRITEBYTECODE=1
python3 - <<'PY'
import re, sys
from pathlib import Path
sys.path.insert(0, "ci")
import check_skills as c
now = c.tuesday_digests()
p = Path("ci/check_skills.py"); t = p.read_text(encoding="utf-8")
for key in ("tuesday_sha256", "builds_sha256", "hub_sha256"):
    t, n = re.subn(rf'"{key}": "[0-9a-f]{{64}}"', f'"{key}": "{now[key]}"', t, count=1)
    assert n == 1, key
p.write_text(t, encoding="utf-8")
q = Path("ci/test_checks.py"); u = q.read_text(encoding="utf-8")
for old, new in (('"# 8 test fixtures", "# 4 test fixtures"', '"# 9 test fixtures", "# 4 test fixtures"'),
                 ('"# 8 test fixtures", "# 4 test cases"', '"# 9 test fixtures", "# 4 test cases"'),
                 ("evals.json has 8'", "evals.json has 9'")):
    assert old in u, old
    u = u.replace(old, new)
q.write_text(u, encoding="utf-8")
print("rehearsal: MEASURED_TUESDAY set to", {k: v[:8] for k, v in now.items()})
PY
set +e
timeout 900 python3 ci/check_skills.py > "$D/rehearsal-check.txt" 2>&1; echo "rehearsal check_skills exit=$?"; tail -1 "$D/rehearsal-check.txt"
timeout 1800 python3 ci/test_checks.py > "$D/rehearsal-test_checks.txt" 2>&1; echo "rehearsal test_checks exit=$?"; tail -1 "$D/rehearsal-test_checks.txt"
timeout 900 python3 evals/test_harness.py > "$D/rehearsal-test_harness.txt" 2>&1; echo "rehearsal test_harness exit=$?"; tail -1 "$D/rehearsal-test_harness.txt"
timeout 300 python3 ci/sync.py --check > "$D/rehearsal-sync.txt" 2>&1; echo "rehearsal sync --check exit=$?"
