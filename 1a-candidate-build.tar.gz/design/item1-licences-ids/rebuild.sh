#!/bin/bash
# Rebuild the scratch tree from the repository and apply item 1's design, then sync, package and run CI.
set -e
D=/tmp/claude-0/-home-user-tuesday/ef77e489-8808-5f2b-a3f0-8906fb79ef25/scratchpad/l1a/design/item1-licences-ids
rm -rf "$D/tree" && mkdir -p "$D/tree"
(cd /home/user/tuesday && tar --exclude=.git --exclude=__pycache__ -cf - .) | (cd "$D/tree" && tar -xf -)
export PYTHONDONTWRITEBYTECODE=1
python3 "$D/apply_skill_edits.py" "$D/tree"
python3 "$D/append_fixtures.py" "$D/tree"
cd "$D/tree"
python3 ci/sync.py
python3 ci/package.py > "$D/package-out.txt" 2>&1
set +e
timeout 900 python3 ci/check_skills.py > "$D/candidate-check.txt" 2>&1
echo "check_skills exit=$?"
