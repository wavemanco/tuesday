"""Build E23's external single-mode case files from a candidate tree: the module's whole clause set and
the one new fixture, unchanged, so the expanded expectations hash the same in both revisions."""
import json, sys
from pathlib import Path
tree, out = Path(sys.argv[1]), Path(sys.argv[2])
for skill, n in (("job-underwriter", 7), ("mock-interview", 9)):
    data = json.loads((tree / "skills" / skill / "evals" / "evals.json").read_text(encoding="utf-8"))
    case = next(c for c in data["evals"] if c["id"] == n)
    spec = {"skill_name": skill, "clauses": data["clauses"], "evals": [case]}
    path = out / f"e23-{skill}-{n}.json"
    path.write_text(json.dumps(spec, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(path)
