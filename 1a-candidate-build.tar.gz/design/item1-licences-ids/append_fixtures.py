"""Append item 1's fixtures to the evals.json files under the tree given as argv[1], in the files' own format."""
import json, sys
from pathlib import Path
root, here = Path(sys.argv[1]), Path(__file__).parent
for skill, name in (("job-underwriter", "ju-eval-7.json"), ("mock-interview", "mi-eval-9.json")):
    path = root / "skills" / skill / "evals" / "evals.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    case = json.loads((here / name).read_text(encoding="utf-8"))
    if any(c.get("id") == case["id"] for c in data["evals"]):
        sys.exit(f"{skill}: id {case['id']} already present")
    data["evals"].append(case)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(skill, "now", len(data["evals"]), "fixtures")
