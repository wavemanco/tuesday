import sys
sys.dont_write_bytecode = True
from pathlib import Path
for root in sys.argv[1:]:
    sys.path.insert(0, str(Path(root) / "ci"))
    import importlib
    import check_skills as cs
    cs = importlib.reload(cs)
    out = []
    for s in ("job-underwriter", "mock-interview"):
        p = Path(root) / "skills" / s / "SKILL.md"
        b = cs.skill_body(p.read_text()) if 'skill_body' in dir(cs) else None
        out.append((s, len(b), len(b) // cs.CHARS_PER_TOKEN, cs.MAX_BODY_TOKENS))
    print(root[-40:], out)
    sys.path.pop(0)
