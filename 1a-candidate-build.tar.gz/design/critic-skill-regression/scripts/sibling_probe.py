"""Read-only probe of the fix round's saved mock-interview responses: how often the response
(chat plus appended files) and its upgrade menu name job-underwriter. Offline, no model.
    python3 sibling_probe.py ROUND_DIR
"""
import collections, glob, re, sys
rnd = sys.argv[1]
for m in ("sonnet", "opus", "haiku"):
    for a in ("alone", "tuesday"):
        menu = collections.Counter(); tot = collections.Counter(); anyn = nd = 0
        for f in sorted(glob.glob(f"{rnd}/{m}/{a}/part-2/mock-interview-*.run*.md")):
            fid = re.search(r"mock-interview-(\d+)", f).group(1)
            t = open(f).read(); tot[fid] += 1
            mm = re.search(r"#+\s*Upgrade menu(.*?)(\n#+ |\Z)", t, re.S | re.I)
            if mm and re.search(r"job[- ]underwriter", mm.group(1), re.I):
                menu[fid] += 1
            if fid != "4":
                nd += 1; anyn += bool(re.search(r"job[- ]underwriter", t, re.I))
        print(m, a, "named anywhere (non-dossier ids):", f"{anyn}/{nd}", "| in upgrade menu:",
              " ".join(f"MI{i}:{menu[i]}/{tot[i]}" for i in sorted(tot, key=int)))
