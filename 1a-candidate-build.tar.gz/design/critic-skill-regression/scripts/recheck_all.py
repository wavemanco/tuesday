#!/usr/bin/env python3
"""Re-check every saved fix-round run of the existing rooms (job-underwriter 1-6, mock-interview 1-8)
with a tree's own run_fixtures.check_run, in a work copy. Prints {stem: [(check, verdict, extra)]}.

    python3 -I recheck_all.py TREE ROUND_DIR WORK_DIR OUT_JSON
Offline; copies .meta.json and .md only; never writes in ROUND_DIR. Calls no model.
"""
import json, os, shutil, sys
sys.dont_write_bytecode = True
from pathlib import Path

tree, rnd, work, outp = (Path(a) for a in sys.argv[1:5])
os.environ.pop("TUESDAY_SCAN_ACCOUNT_EMAIL", None)
sys.path.insert(0, str(tree / "evals"))
import run_fixtures as rf  # noqa: E402

SK = {"job-underwriter": (range(1, 7), "part-1"), "mock-interview": (range(1, 9), "part-2")}
res = {}
for skill, (ids, part) in SK.items():
    cases = {c["id"]: c for c in rf.cases_for(skill, list(ids))}
    for model in ("sonnet", "opus", "haiku"):
        for arm in ("alone", "tuesday"):
            src = rnd / model / arm / part
            dst = work / model / arm / part
            if dst.exists():
                shutil.rmtree(dst)
            dst.mkdir(parents=True)
            for mp in sorted(src.glob(f"{skill}-*.meta.json")):
                meta = json.loads(mp.read_text())
                if meta.get("id") not in ids:
                    continue
                stem = meta["stem"]
                shutil.copy2(mp, dst / mp.name)
                b = src / f"{stem}.md"
                if b.exists():
                    shutil.copy2(b, dst / b.name)
                rec = rf.check_run(skill, cases[meta["id"]], dst, meta["run"], meta["mode"])
                res[f"{model}/{arm}/{stem}"] = {
                    "status": rec.get("harness_status") or rec.get("status"),
                    "checks": sorted([[f.get("check"), f.get("verdict"), f.get("kind"), f.get("sentences"),
                                       f.get("reason")] for f in rec.get("checks") or []], key=str),
                    "unchecked": sorted(rec.get("unchecked") or []),
                }
outp.write_text(json.dumps(res, indent=1, sort_keys=True))
print(len(res), "runs rechecked")
