import json, sys
from pathlib import Path
tree = Path(sys.argv[1]); resp = Path(sys.argv[2]).read_text(encoding="utf-8")
sys.path[:0] = [str(tree / "evals"), str(tree / "ci")]
import output_checks as oc, fixture_clauses as fc
case = next(c for c in fc.load_cases(tree / "skills/job-underwriter/evals/evals.json") if c["id"] == 8)
line = oc.declared_watch_out((tree / "skills/job-underwriter/SKILL.md").read_text(encoding="utf-8"))
log = [{"id": "a", "tool": "mcp__web__search", "kind": "search", "query_or_url": "Velloway Logistics careers",
        "outcome": "returned", "urls_returned": [], "targets": []},
       {"id": "b", "tool": "mcp__web__search", "kind": "search",
        "query_or_url": "order processing coordinator salary Ireland 2026", "outcome": "returned",
        "urls_returned": ["https://pennoral.example/2026-ireland-customer-operations-pay-guide"], "targets": [2]}]
attempt = {"label": "first", "events": [{"type": "assistant", "message": {"content": [{"type": "text", "text": resp}]}},
                                        {"type": "result", "result": resp}],
           "complete": True, "calls_log": [], "canned": True, "files": []}
rec = oc.run_checks(case, "canned", resp, log, watch_out=line, attempts=[attempt])
print("status:", rec["status"])
for c in rec["checks"]:
    if c["verdict"] != "PASS" or c["check"] in ("sentinel", "severity", "gates_line", "watch_out", "yes_names_page"):
        print(f"  {c['verdict']:4} {c['check']}:{c.get('target')} — {c['why'][:150]}")
print("unchecked:", rec["unchecked"])
