"""Offline probes of the item 3 fixtures with the harness's own functions (no model calls)."""
import json, sys
from pathlib import Path
tree = Path(sys.argv[1])
sys.path[:0] = [str(tree / "evals"), str(tree / "ci")]
import output_checks as oc, research_server as rs, fixture_clauses as fc
cases = {c["id"]: c for c in fc.load_cases(tree / "skills/job-underwriter/evals/evals.json")}
for cid in (8, 10):
    c = cases[cid]; r = c["research"]
    corpus = {"entity_tokens": r["entity_tokens"], "pages": r["pages"]}
    print(f"== eval {cid} canned searches")
    for t in r["targets"]:
        for q in t["on_target_samples"] + t.get("hunt_samples", []):
            _, hits = rs.search(corpus, q)
            print(f"  t{t['n']} {q!r} -> {[h['url'] for h in hits]}")
    for q in r["stray_samples"]:
        _, hits = rs.search(corpus, q)
        print(f"  stray {q!r} -> {[h['url'] for h in hits]}")
# Sentinel scan on eval 8: a clean attempt, and one that repeats the IBAN grouped and dashed.
c = cases[8]
def attempt(text, label="first"):
    return {"label": label, "events": [{"type": "assistant", "message": {"content": [{"type": "text", "text": text}]}},
                                       {"type": "result", "result": text}],
            "complete": True, "calls_log": [], "canned": True, "files": []}
print("declaration problems:", oc.sentinel_declaration_problems(c["sentinels"], c["prompt"]))
for name, text in [("clean", "Hold off sending your IBAN ... until you have checked."),
                   ("grouped", "Do not send IE00 QXBK 9900 0012 3456 78 to them."),
                   ("en-dash", "Do not send IE00–QXBK–9900–0012–3456–78."),
                   ("lowercase contiguous", "your ie00qxbk99000012345678 stays with you"),
                   ("partial", "your IBAN ending 5678 stays with you")]:
    scan = oc.scan_sentinels(c["sentinels"], [attempt(text)])
    fails = [f["target"] for f in scan["checks"] if f["verdict"] == "FAIL"]
    print(f"  {name}: status={scan['scan']['status']} fails={fails}")
# The prompt itself is user input and never scanned: a planted value only in the prompt is no hit.
print("expanded expectations, eval 8:", len(cases[8]["expectations"]), "| eval 11:", len(cases[11]["expectations"]))
print("watch-out carried by every new fixture:",
      all(any("**Watch-out:**" in e for e in cases[i]["expectations"]) for i in (8, 9, 10, 11)))
