# Underwriting — Remote Order Processing Coordinator, "Velloway Logistics"

## Decision snapshot

**No — do not go ahead, and send nothing while you check. Status: `no_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R5 (At least €30,000 a year)
- `must_have` — direct: R1, R3 · adjacent: R2 (Confident with spreadsheets)
- `important` — direct: R4

R5 — 'up to' sets a ceiling, not a rate; R2 (`medium`) — a weekly tracker, not modelling.

**Opportunity ledger.** Four demands made of you are confirmed severe red flags (RR1, RR2, RR3, RR4), and the employer is not established (RR5).

- **Hard gates:** none failed; unconfirmed: R5 (At least €30,000 a year).
- **Severe red flags:** RR1 (`severity: high`), RR2 (`severity: high`), RR3 (`severity: high`), RR4 (`severity: high`).
- **What would have to be different:** no request to pay, to lodge a cheque or to send bank, tax or ID details before an offer, and interviews held outside chat with an employer you can reach yourself.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Named in the posting as Velloway Logistics; not established from any page | `[grounded]` posting; searches returned nothing |
| Market calibration | Order processing and customer operations coordinators in Ireland: median base €31,200 a year (Pennoral 2026); the posting states only an 'up to' hourly ceiling | `[generic]` Pennoral 2026 Ireland Customer Operations Pay Guide |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Strong attention to detail | must_have | direct | medium | none | 60 tickets a day | `[grounded]` your message | none |
| R2 | Confident with spreadsheets | must_have | adjacent | medium | transferability | A weekly tracker in Excel | `[grounded]` your message | none |
| R3 | Good written English | must_have | direct | medium | none | Ticket replies daily | `[grounded]` your message | none |
| R4 | A quiet place to work | important | direct | low | none | Not stated; assumed | `[inferred]` | none |
| R5 | At least €30,000 a year (your hard constraint) | hard_gate | unclear | high | hard_gate | 'Up to €26 an hour' is a ceiling, commission varies and hours run 15–30 | `[grounded]` posting and your constraint | none |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Bank, tax and ID details before an offer | red_flag | high | "Before your chat interview, please send your IBAN, your PPS number and a clear photo of your passport" | The request comes before any offer | `[grounded]` the messages | Ask Velloway Logistics, through contact details you find yourself on its own site or careers page, never the Telegram chat: did you send this request? Hold your details meanwhile; who sent it is unresolved | confirmed |
| RR2 | Payment for equipment | red_flag | high | "Please pay €349 by bank transfer to our equipment partner" | A payment asked of a candidate | `[grounded]` the messages | Ask Velloway, through contact details you find yourself: do you charge for a work kit? Pay nothing meanwhile; the sender is unresolved | confirmed |
| RR3 | Hiring process run wholly by chat | red_flag | high | "Our whole hiring process runs on Telegram, so there are no calls or video interviews" | No interview outside chat | `[grounded]` posting | Ask Velloway, through contact details you find yourself: is this role yours, and how do you interview? The sender is unresolved | confirmed |
| RR4 | A cheque to lodge and pass on | red_flag | high | "We are posting you a cheque for €2,850. Lodge it to your account ... transfer the rest to our equipment partner" | Money passed on after a chat offer | `[grounded]` the messages | Ask Velloway, through contact details you find yourself: did you make this offer? Lodge nothing meanwhile; the sender is unresolved | confirmed |
| RR5 | Employer not established from attributable sources | risk_signal | medium | "Velloway Logistics" | The entity may be too new or small to have a footprint, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site? | unresolved |

## Evidence status

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | yes | Searched "Velloway Logistics careers": no results, so the employer is not established |
| 2 | Role-family sweep | yes | Searched "order processing coordinator salary Ireland 2026": Pennoral 2026 Ireland Customer Operations Pay Guide |
| 3 | Hiring manager's public footprint | n/a | No person is named |

Want me to save this as `tuesday-dossier.md`?

**Upgrade menu.** Your CV would sharpen R2; the employer's own careers page would settle RR5.

1. Have you found Velloway's own site or phone number independently? (RR1) — answer in text, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.
