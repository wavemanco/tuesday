import json, sys
from pathlib import Path
D = Path(__file__).resolve().parent
sys.path.insert(0, str(D))
import apply_text as at
notes = {
 0: "Edit 1 · risk-and-decision.md, end of \"Detectable patterns\" (after its last paragraph, line 38). Adds the requests table and its five rules. No heading is added, so `## Contents` is unchanged.",
 1: "Edit 2 · risk-and-decision.md, \"The risk-register record\", end of the verification-question paragraph (line 80). A pointer to the one exception, not a second copy of it.",
 2: "Edit 3 · job-underwriter README, `## Install` (lines 7–24). Steps aligned with the root README's Install section.",
 3: "Edit 4 · mock-interview README, `## Install` (lines 9–26). Same text, module name swapped.",
 4: "Edit 5 · mock-interview README, line 7. `docs/workflow.html` still draws the old install boxes until 1b updates it (E22, write boundary row \"1b candidate\").",
 5: "Edit 6 · job-underwriter README, folder tree (line 77). The count is the registry total: 10 in this scratch tree (6 + item 3's 4); **11 in the 1a fixture commit** if item 1's nurse fixture lands with it. Write the digits the final `evals.json` holds.",
 6: "Edit 7 · roadmap.html, At a glance row \"Scam and legitimacy signals in job-underwriter\" (line 126). E3.",
 7: "Edit 8 · roadmap.html, entries data row title (line 193). E3.",
 8: "Edit 9 · roadmap.html, the same row's detail (line 193). E3.",
}
out = []
for i, (path, old, new) in enumerate(at.EDITS):
    out.append(f"### {notes[i]}\n\nFile: `{path}`\n\nOld (copied from the file, unique):\n\n~~~~text\n{old}\n~~~~\n\nNew:\n\n~~~~text\n{new}\n~~~~\n")
(D / "design-edits.md").write_text("\n".join(out), encoding="utf-8")
fx = json.loads((D / "fixtures-item3.json").read_text(encoding="utf-8"))
blocks = ["### Clause added to `\"clauses\"`\n\n~~~~json\n" + json.dumps(fx["clauses"], indent=2, ensure_ascii=False) + "\n~~~~\n"]
for case in fx["evals"]:
    blocks.append(f"### Eval {case['id']}\n\n~~~~json\n" + json.dumps(case, indent=2, ensure_ascii=False) + "\n~~~~\n")
(D / "design-fixtures.md").write_text("\n".join(blocks), encoding="utf-8")
print("ok")
