"""Item 3 text edits (design pass, scratch only): each (file, old, new) applied once to a tree.

    python apply_text.py TREE          # apply, failing on any old text that is not there exactly once
    python apply_text.py --print       # print the edits as the design records them
"""
import sys
from pathlib import Path

RD = "skills/job-underwriter/references/risk-and-decision.md"
JU_README = "skills/job-underwriter/README.md"
MI_README = "skills/mock-interview/README.md"
ROADMAP = "docs/roadmap.html"

REQUESTS_BLOCK = """

**Requests made of the candidate.** Check the posting, and every message from whoever is recruiting, for what it asks the candidate to do. These requests are severe when the material directs them at the candidate:

| Request | Severe (`red_flag`, `severity: high`) when | Not a signal |
|---|---|---|
| Pay for the job or for equipment | Asked at any stage, after an offer as well | — |
| Deposit a cheque | Asked at any stage, after an offer as well | — |
| Give bank, tax or government-ID details | Asked before an offer | After a credible offer, in writing and naming the role and its pay, payroll and identity checks are routine onboarding: no entry, or an `unknown` |
| Go through a hiring process run wholly by chat | The material says or shows that the interviews and the offer happen only in chat, whether or not it names an employer | Scheduling by chat for an interview held elsewhere |

- **Directed, or nothing.** A request counts only where the material asks it of this candidate. A generic example, a negated demand and scheduling by chat establish no signal, and they raise no other entry's severity, the standing entry's included.
- **A clear demand is confirmed.** Quoted, it is a `red_flag` at `severity: high` with `status: confirmed`, since the material does ask it; so it is a severe red flag in the snapshot, and a confirmed severe red flag is a `no_go` (Decision semantics). A demand whose meaning or stage is unclear (is this message an offer?) is not yet one: record an `unknown` or a `risk_signal`, `unresolved`, and let its verification question settle it.
- **Quote the demand, never the values.** The source quote keeps the action, amount, method and platform in the material's own words and order. An account, card, wallet or government-ID number, or another personal or financial detail, is never repeated, in the quote or anywhere else: cut it at an ellipsis (`...`). A bracketed or angle-bracketed placeholder is not a cut, since square brackets are the provenance labels' (`references/output-discipline.md` rule 3).
- **Verify with the employer, not the sender.** The sender is what is not yet verified, so this entry's question is the one exception to asking a live interviewer: it goes to the employer the material names, through contact details the candidate finds independently on that employer's own site or careers page, never the chat, address or number the request came from. Its `decision_rule` holds the payment, the deposit or the disclosure while the candidate checks. Where no employer can be identified independently, the entry keeps the question and the hold and records the sender's identity as unresolved.
- **About the request, not the firm.** The entry concludes what the request asks. Who sent it, and whether the named employer is involved, stays unproven: nothing calls a named firm a scam or a fraud. Describe the request in its own words, with no outside statistics."""

INSTALL_OLD_TAIL = """New sessions pick it up automatically; it is also invokable directly as `/{name}`."""


def install_old(name: str) -> str:
    return f"""## Install

Skills require code execution to be enabled. Steps below are current as of mid-2026; if a menu has moved, see https://support.claude.com (search "skills").

**Web — claude.ai**
1. Free/Pro/Max: Settings → Capabilities → enable "Code execution and file creation". Team/Enterprise: an owner enables Code execution and Skills under Organization settings → Skills.
2. Customize → Skills → upload the zip (the zip root must be the `{name}/` folder itself, not loose files), then toggle it on.
3. Uploaded skills are private to your account unless an org owner provisions them organization-wide.

**Desktop app**
Skills are account-level — anything enabled on claude.ai is already available; manage from Customize in the sidebar. Shortcut: if someone shares the packaged `.skill` file in a chat, the file card shows a "Save skill" button. Cowork sessions sync the skills enabled on your account at session start.

**Claude Code (CLI)**
Filesystem only — copy the `{name}/` folder to:
- `~/.claude/skills/{name}/` — personal, available in every project, or
- `.claude/skills/{name}/` — project-scoped, committed to the repo so teammates get it on clone.

New sessions pick it up automatically; it is also invokable directly as `/{name}`."""


def install_new(name: str) -> str:
    return f"""## Install

This module also comes inside Tuesday, which runs it when a request needs it. Install one or the other, not both: a module Claude can choose competes with Tuesday for every request. Tuesday's [Install section](../../README.md#install) covers every surface; to install this module on its own:

**claude.ai, on the web or in the desktop app**
1. Turn on code execution: Settings → Capabilities → *Code execution and file creation*. On a Team or Enterprise plan, an owner turns on code execution and skills under Organization settings.
2. Download [`{name}.skill`](../../dist/{name}.skill), upload it under Customize → Skills and switch it on. The desktop app uses the skills on your claude.ai account, so one upload covers both.

**Claude Code, in one project or in cloud sessions**
Unzip `dist/{name}.skill` into the project's `.claude/skills/`. It runs as `/{name}`, and Claude also picks it when a request matches its description.

**Claude Code, for yourself across your projects**
Install Tuesday's plugin or its personal install instead: both carry this module, hidden so it does not compete, and `/tuesday:{name}` (the plugin) or `/{name}` (the personal install) runs it directly.

Every test ran in Claude Code; this module on claude.ai is untested. A skill uploaded to claude.ai also reaches Claude Code, so keep one copy: where you use the plugin or a personal install, do not upload this module to claude.ai as well. If a menu has moved, see https://support.claude.com (search "skills")."""


EDITS = [
    # Item 3: the requests table and its rules, at the end of Detectable patterns.
    (RD,
     "The candidate's stated non-negotiables extend this list per engagement: a role attribute that conflicts with "
     "one is a red flag for *this* candidate whatever the market thinks of it.",
     "The candidate's stated non-negotiables extend this list per engagement: a role attribute that conflicts with "
     "one is a red flag for *this* candidate whatever the market thinks of it." + REQUESTS_BLOCK),
    # Item 3: the one exception to the live-interviewer question, pointed to where the rule is.
    (RD,
     "which is a next action, not a verification question. `severity: high` entries are the \"severe red flags\" "
     "the decision snapshot must carry.",
     "which is a next action, not a verification question. A request from the table under Detectable patterns is "
     "the one exception: its rule says where its question goes. `severity: high` entries are the \"severe red "
     "flags\" the decision snapshot must carry."),
    # README install steps, both modules (plan line 365).
    (JU_README, install_old("job-underwriter"), install_new("job-underwriter")),
    (MI_README, install_old("mock-interview"), install_new("mock-interview")),
    # mock-interview's walkthrough still draws the old install steps until 1b (E22).
    (MI_README,
     "For a visual walkthrough of install and first use, open **`docs/workflow.html`** in any browser — click the boxes.",
     "For a visual walkthrough of first use, open **`docs/workflow.html`** in any browser — click the boxes. Install with the steps below: the walkthrough's own install boxes predate them."),
    # README fixture count, job-underwriter (plan line 365). 10 in this scratch tree (6 + item 3's 4); 11 once
    # item 1's nurse fixture lands in the same commit.
    (JU_README,
     "    └── evals.json                      # 6 test fixtures with verifiable expectations",
     "    └── evals.json                      # 10 test fixtures with verifiable expectations"),
    # E3: "legitimate small employer" in both roadmap rows, in the fixture commit.
    (ROADMAP,
     "A real small employer is a test case that must never be flagged",
     "A legitimate small employer is a test case that must never be flagged"),
    (ROADMAP,
     "No false scam accusations: quote signals, protect real small employers",
     "No false scam accusations: quote signals, protect legitimate small employers"),
    (ROADMAP,
     "A test case with a real small employer must never reach red_flag.",
     "A test case with a legitimate small employer must never reach red_flag."),
]


def main(argv: list[str]) -> int:
    if argv[1:] == ["--print"]:
        for path, old, new in EDITS:
            print(f"=== {path}\n--- old\n{old}\n+++ new\n{new}\n")
        return 0
    tree = Path(argv[1])
    for path, old, new in EDITS:
        target = tree / path
        text = target.read_text(encoding="utf-8")
        n = text.count(old)
        if n != 1:
            raise SystemExit(f"{path}: old text found {n} times, not once:\n{old[:120]}")
        target.write_text(text.replace(old, new, 1), encoding="utf-8")
        print(f"edited {path} ({len(new) - len(old):+d} chars)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
