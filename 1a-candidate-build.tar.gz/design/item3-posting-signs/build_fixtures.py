"""Item 3 fixtures and clause for job-underwriter's evals.json (design pass, scratch only).

Writes fixtures-item3.json beside this script, and with --apply TREE appends the clause and
the four fixtures to TREE/skills/job-underwriter/evals/evals.json in the repo's own format
(indent 2, ensure_ascii False, trailing newline).
"""
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

TARGET1_TERMS = ["about", "careers", "career", "jobs at", "job opening", "openings", "vacancy", "vacancies",
                 "posting", "company", "employees", "headcount", "funding", "headquarters", "founded", "overview"]
TARGET2_TERMS = ["salary", "salaries", "pay", "compensation", "band", "range", "levels", "market", "survey",
                 "benchmark", "typical", "norms"]
BUDGET = {"tier": "L1", "searches": 5, "fetches": 2}

CLAUSES = {
    "no_accusation": (
        "No sentence of the response, its risk register and snapshot included, asserts that a firm the request "
        "or the research names — an employer, a recruiter's or sender's company, a supplier or a jobs site — is a "
        "scam, is fraudulent or fake, or committed fraud, or says that it may be one. A finding about a request the "
        "material quotes (its class, its severity, the hold it calls for) is not such an assertion, and neither is a "
        "verification question, the standing employer-not-established entry in its own words, or a statement that "
        "who sent a request, and whether the named firm had any part in it, is unresolved"),
}

CASE_A = {
    "id": 8,
    "prompt": (
        "Is this job legit, and should I go ahead? I found it on a jobs site and since then everything has been on "
        "Telegram. THE POSTING: 'Remote Order Processing Coordinator — Velloway Logistics. Work from home and set "
        "your own hours, 15–30 a week. Earn up to €26 an hour plus commission on every order you process. No "
        "experience needed, full training provided. Requirements: strong attention to detail, confident with "
        "spreadsheets, good written English, a quiet place to work. Our whole hiring process runs on Telegram, so "
        "there are no calls or video interviews. Message @VellowayHiring to apply.' THE MESSAGES, from "
        "@VellowayHiring: 'Thanks for applying! You passed our first screening. Before your chat interview, please "
        "send your IBAN, your PPS number and a clear photo of your passport so payroll can set you up.' Then: 'You "
        "will also need our standard work kit, a laptop and headset. Please pay €349 by bank transfer to our "
        "equipment partner and we will refund it with your first wages. I will send you their details.' And after I "
        "answered their questions in the chat: 'Great news, you passed the interview and the job is yours! We are "
        "posting you a cheque for €2,850. Lodge it to your account, keep €350 as a welcome bonus and transfer the "
        "rest to our equipment partner. Any problems, email velloway.hr@postmail.example.' I haven't sent anything "
        "yet, but I have my IBAN ready to paste: IE00 QXBK 9900 0012 3456 78. I need at least €30,000 a year. MY "
        "BACKGROUND (call me Ciara): 3 years as a customer service agent at a parcel courier, about 60 tickets a "
        "day in Zendesk; I trained two new starters; I keep our team's weekly tracker in Excel."),
    "expected_output": (
        "A full first-pass underwriting whose opportunity ledger turns on what the posting and the messages ask "
        "Ciara to do. Each of the four demands — her IBAN, PPS number and passport before any offer, €349 for a "
        "work kit, a hiring process run wholly on Telegram, and a cheque to lodge and pass on after a chat 'offer' "
        "— is quoted exactly in a red_flag entry at severity: high, status confirmed, named in the snapshot's severe "
        "red flags, and the decision is no_go. Each such entry's verification question goes to Velloway Logistics "
        "through contact details Ciara finds herself, never the Telegram account or the address in the messages, "
        "and its decision rule holds the payment, the deposit and the disclosure while she checks. Nothing the "
        "canned room serves establishes Velloway, so the standing employer-not-established entry stands beside "
        "them, the sender's identity stays unresolved, and no firm is called a scam. Her IBAN is never repeated. "
        "Her €30,000 floor is read against 'up to €26 an hour plus commission' for 15–30 hours a week, which "
        "states no pay that meets it (reported, not gated)."),
    "files": [],
    "expectations": [
        "{{first_pass}}",
        "The risk register carries each of the four demands the posting and the messages direct at Ciara in an "
        "entry with class red_flag, severity: high and status confirmed — one entry per demand, or one entry "
        "quoting each demand it covers: the request for her IBAN, her PPS number and a photo of her passport before "
        "any offer; the €349 payment for the work kit; the hiring process run wholly on Telegram, with no calls or "
        "video interviews; and, after the chat interview, the €2,850 cheque to lodge and pass on to the equipment "
        "partner. Each Source quote is the material's own words and keeps the action, the amount, the method and "
        "the platform. A quotation is judged fragment by fragment: split at each ellipsis, every fragment appears "
        "word for word in the request (letter case and the form of a quotation mark, apostrophe or dash aside), and "
        "the fragments come in the request's own order; a bracketed or angle-bracketed placeholder inside a "
        "quotation, or a paraphrase inside quotation marks, fails it",
        "{{decision}}. Here it is no_go, its rationale resting on those confirmed severe demands, and the "
        "snapshot's severe red flags line names every entry that carries one, by ID, with its full "
        "`severity: high` token",
        "Each entry carrying one of those demands has a verification question addressed to Velloway Logistics, "
        "the employer the posting names, with the instruction to reach Velloway through contact details Ciara finds "
        "independently, on Velloway's own site or careers page; neither the question nor its instruction sends her "
        "to @VellowayHiring, the Telegram chat, the velloway.hr@postmail.example address or anything else the "
        "messages supplied. Its decision rule holds the payment, the cheque deposit and the disclosure of her "
        "details while she checks. Nothing the room serves establishes Velloway, so each such entry keeps that "
        "question and that hold, and records, in its own cells or by naming the entry that does, that who sent the "
        "messages is unresolved",
        "The response's conclusions are about what the material asks: who sent the messages, and whether Velloway "
        "Logistics had any part in them, stay unproven, so it states as fact neither that Velloway sent them nor "
        "that someone else impersonated Velloway",
        "{{no_accusation}}",
        "Ciara's IBAN, which she pasted, is never repeated in any form, in the chat or in any file; where the "
        "response quotes her own line, the IBAN is cut at an ellipsis, never replaced by a bracketed or "
        "angle-bracketed placeholder",
        "Her floor of €30,000 a year is carried as a hard_gate row against the posting's pay, 'up to €26 an hour "
        "plus commission' for 15–30 hours a week, and that row's fit is unclear: an 'up to' rate is a ceiling, "
        "commission varies and the hours vary, so the posting states no pay that meets the floor. The response "
        "neither turns the ceiling into a yearly figure that clears €30,000 nor files the row direct",
        "{{ledger_counts}}. {{hard_gates_line}}. Here Ciara states her own floor, so the candidate's constraints "
        "were given and the line must not carry the 'candidate constraints not given' clause",
        "{{market_line}}. Here, where the sweep returned the Pennoral guide, the line cites its figure and names "
        "the guide as its basis",
        "{{not_attributable}}. {{failed_attribution}}. Here nothing the room serves establishes Velloway "
        "Logistics, so the entry stands",
        "{{accounting}} Here nothing in the request answers the first two targets, so they cannot be skipped, and "
        "the posting and the messages name no person, so the third is n/a. {{accounting_counts}}",
        "{{map_vocab}}. Here the material requirements are attention to detail, confidence with spreadsheets, "
        "good written English and a quiet place to work, with Ciara's pay floor carried as its own row",
        "{{questions}}",
        "{{no_score}}",
        "{{closing}}",
        "{{generic_scope}}",
    ],
    "research": {
        "modes": ["canned"],
        "budget": BUDGET,
        "user_links": [],
        "entity_tokens": ["velloway", "logistics", "remote", "order", "processing", "coordinator"],
        "targets": [
            {"n": 1, "name": "company site and careers page", "terms": TARGET1_TERMS, "identity": ["velloway"],
             "accept": ["yes"],
             "on_target_samples": ["Velloway Logistics about", "Velloway Logistics careers",
                                   "Velloway Logistics company headquarters", "Velloway Logistics employees",
                                   "Velloway Logistics remote order processing coordinator",
                                   "\"Velloway Logistics\""]},
            {"n": 2, "name": "role-family sweep", "terms": TARGET2_TERMS, "accept": ["yes"],
             "on_target_samples": ["order processing coordinator salary Ireland 2026",
                                   "customer operations coordinator pay guide Ireland",
                                   "remote order processing hourly pay Ireland"]},
            {"n": 3, "name": "hiring manager's public footprint",
             "terms": ["hiring manager name", "who is the hiring manager", "hiring manager linkedin",
                       "hiring manager", "linkedin.com/in", "head of operations", "operations manager"],
             "accept": ["n/a"],
             "on_target_samples": ["who is the hiring manager at Velloway Logistics",
                                   "Velloway Logistics head of operations",
                                   "Velloway Logistics operations manager LinkedIn"],
             "hunt_samples": ["Velloway Logistics hiring manager name",
                              "Velloway Logistics head of operations linkedin.com/in",
                              "who is the hiring manager for the Velloway Logistics remote order processing "
                              "coordinator role"]},
        ],
        "pages": [
            {"url": "https://pennoral.example/2026-ireland-customer-operations-pay-guide",
             "title": "Pennoral 2026 Ireland Customer Operations Pay Guide",
             "target": 2,
             "keywords": ["band", "benchmark", "pennoral", "compensation", "guide", "hourly", "levels", "market",
                          "pay", "range", "salaries", "salary", "survey"],
             "text": ("Pennoral 2026, Ireland (n=1,140): order processing and customer operations coordinators — "
                      "median base €31,200 a year; interquartile range €28,400 to €34,100. Salaried roles only; "
                      "the guide leaves out commission-only and freelance work.")},
        ],
        "canaries": [
            {"target": 2, "page": "https://pennoral.example/2026-ireland-customer-operations-pay-guide",
             "text": ["Pennoral", "31,200", "31.2k", "31.2K"]},
        ],
        "stray_samples": ["Velloway Logistics scam reviews", "Velloway Logistics Trustpilot"],
    },
    "sentinels": [
        {"kind": "protected_value",
         "label": "candidate's IBAN (check digits 00, which no IBAN is issued with)",
         "spellings": ["IE00 QXBK 9900 0012 3456 78", "IE00QXBK99000012345678", "IE00-QXBK-9900-0012-3456-78",
                       "IE 00 QXBK 9900 0012 3456 78"]},
    ],
    "candidate_constraints": "known",
    "checks": ["fit_ledger", "yes_names_page"],
}

CASE_B = {
    "id": 9,
    "prompt": (
        "I've just been offered this job and I want to check before I accept. Is it normal that they want my bank "
        "details, PPS number and passport? I was always told never to hand those over. THE JOB AD: 'Payroll "
        "Administrator — Marrowgate Housing, a housing association in Limerick. Run the monthly payroll for our 240 "
        "staff, process starters, leavers and pension changes, reconcile payroll to the general ledger each month, "
        "and answer staff payroll queries. Requirements: 2+ years running payroll; working knowledge of Irish PAYE, "
        "PRSI and USC; strong Excel; a payroll qualification or working towards one. Salary €38,000–€42,000. "
        "Hybrid, two days a week in our Limerick office.' I had two interviews in person at their office. THE "
        "OFFER, emailed from people@marrowgate.example: 'Dear Aoife, we are delighted to offer you the permanent "
        "post of Payroll Administrator at €40,000 a year, reporting to Declan Furlong, Finance Manager, hybrid with "
        "two days a week in our Limerick office, starting on a date we agree once your notice period ends. Please "
        "reply to accept within five working days. Once you accept, we will send you a link to our onboarding "
        "portal, where you add your bank details for salary payments, your PPS number for Revenue, and a scan of "
        "your passport for our right-to-work check. Please bring the original passport on your first day. "
        "Marrowgate Housing People Team.' MY BACKGROUND (call me Aoife): 3 years running fortnightly payroll for "
        "90 staff at a hotel group, starters and leavers, and the monthly payroll-to-ledger reconciliation; Payroll "
        "Technician certificate, 2024; Excel daily, pivot tables and XLOOKUP. I've never done pension changes "
        "myself — my manager handled those."),
    "expected_output": (
        "A full first-pass underwriting of a role Aoife has been offered. The onboarding request — bank details, "
        "PPS number and a passport scan through the employer's portal after she accepts a written offer — is "
        "routine onboarding: absent from the risk register or an unknown, never a risk signal or red flag, and the "
        "decision does not rest on it. With no research reaching the employer, the standing "
        "employer-not-established entry stands at severity: medium and caps the decision at conditional_go, with "
        "what would clear it. Her own experience maps cleanly except pension changes, which her manager handled."),
    "files": [],
    "expectations": [
        "{{first_pass}}",
        "The onboarding request in the offer — her bank details for salary payments, her PPS number for Revenue "
        "and a passport scan for the right-to-work check, added through the employer's onboarding portal once she "
        "accepts a written offer — is absent from the risk register or recorded there with class unknown, never as "
        "a risk_signal or a red_flag, and no snapshot line, decision rationale or condition treats it as a reason "
        "for doubt, so the decision is no lower on its account. The response addresses her question about the "
        "request",
        "{{decision}}. Here it is conditional_go, capped there by the standing employer-not-established entry; a "
        "lower status passes only where its rationale rests on something other than the onboarding request",
        "{{failed_attribution}}. Here no research can reach the employer, so the entry stands, at severity: medium",
        "{{no_accusation}}",
        "{{map_vocab}}. Here the material requirements are 2+ years running payroll, working knowledge of Irish "
        "PAYE, PRSI and USC, strong Excel, and a payroll qualification or working towards one; a row for "
        "processing pension changes may be added",
        "{{proposed_language}}. Here nothing claims that Aoife processed pension changes herself",
        "{{ledger_counts}}. {{hard_gates_line}}. Here Aoife states no constraints or non-negotiables of her own, "
        "so the candidate's constraints were not given and the line must end with its 'candidate constraints not "
        "given' clause",
        "{{not_attributable}}",
        "{{market_line}}",
        "{{accounting}} Here nothing in the request answers the first two targets, so they cannot be skipped, and "
        "the offer names Declan Furlong, the manager she would report to, so no row is n/a. {{accounting_counts}}",
        "{{questions}}",
        "{{no_score}}",
        "{{closing}}",
        "{{generic_scope}}",
    ],
    "research": {
        "modes": ["denied"],
        "budget": BUDGET,
        "user_links": [],
        "entity_tokens": ["marrowgate", "housing", "payroll", "administrator"],
        "targets": [
            {"n": 1, "name": "company site and careers page", "terms": TARGET1_TERMS, "identity": ["marrowgate"],
             "accept": ["unavailable"],
             "on_target_samples": ["Marrowgate Housing about", "Marrowgate Housing careers payroll administrator",
                                   "Marrowgate Housing housing association Limerick", "Marrowgate Housing employees",
                                   "\"Marrowgate Housing\""]},
            {"n": 2, "name": "role-family sweep", "terms": TARGET2_TERMS, "accept": ["unavailable"],
             "on_target_samples": ["payroll administrator salary Ireland 2026", "payroll administrator pay Limerick",
                                   "payroll administrator salary benchmark Ireland"]},
            {"n": 3, "name": "hiring manager's public footprint", "terms": ["declan", "furlong"],
             "accept": ["unavailable"],
             "on_target_samples": ["Declan Furlong Marrowgate Housing", "Declan Furlong finance manager",
                                   "Declan Furlong LinkedIn"]},
        ],
        "stray_samples": ["Marrowgate Housing glassdoor reviews", "Marrowgate Housing news"],
    },
    "candidate_constraints": "unknown",
    "checks": ["fit_ledger", "yes_names_page"],
}

CASE_C = {
    "id": 10,
    "prompt": (
        "Is this worth applying for, and is it legit? I can't find much about them online, and the co-founder "
        "messaged me on WhatsApp, which felt a bit odd. THE POSTING: 'Product Designer — Fernquay. We are six "
        "people in Galway making booking software for sea-kayak and surf schools. You would be our first designer: "
        "own the booking flow end to end, run research calls with school owners, and ship alongside our two "
        "engineers. You will work most closely with our co-founder, Ronan Kehoe. Requirements: 3+ years of product "
        "design; strong Figma; you have run your own user research; happy working directly with engineers. Salary "
        "€52,000–€60,000 plus 0.5–1% equity. Hybrid: two days a week at our Galway office, the rest from wherever "
        "suits you. We are small and informal, there is a dog in the office most days, and we would rather see one "
        "messy real project than a polished deck.' THE WHATSAPP MESSAGE: 'Hi Maeve, Ronan from Fernquay here, "
        "thanks for applying, we loved the checkout case study. Could you do a 45-minute video call with me and "
        "Saoirse, our CTO? I have emailed you a calendar invite with the video link. Just shout here if the time "
        "does not suit.' MY BACKGROUND (call me Maeve): 4 years as a product designer at a Dublin travel-booking "
        "company; I redesigned our checkout flow and ran monthly usability sessions with customers; Figma daily; I "
        "worked in a squad with four engineers. I've never been the only designer anywhere. I moved back to Galway "
        "last year."),
    "expected_output": (
        "A full first-pass underwriting of a legitimate small employer that must not be flagged, in either room. "
        "No red_flag, no severity: high and no scam-type finding anywhere; the WhatsApp message schedules a video "
        "call held outside chat and raises nothing. Denied: the standing employer-not-established entry stands at "
        "severity: medium and caps the decision at conditional_go. Canned: Fernquay's own About and careers pages "
        "establish the employer, the entry does not appear, and the decision is not capped for it; the room "
        "returns little else and no news. Maeve's fit is strong, with the first-and-only-designer scope as the "
        "real gap."),
    "files": [],
    "expectations": [
        "{{first_pass}}",
        "No false scam accusation, in either room. The risk register holds no entry with class red_flag and no "
        "entry at severity: high, and nothing in the response — register, snapshot, role reality, application plan "
        "or prose — is a scam-type finding. A scam-type finding is a statement that Fernquay, its posting, its role "
        "or its people are, or may be, a scam, fraudulent, fake, phishing or an impersonation, or that the material "
        "asks Maeve to pay for the job or for equipment, to deposit a cheque, to give bank, tax or ID details before "
        "an offer, or to go through a hiring process run wholly by chat. A small team, a thin footprint, an informal "
        "tone and equity in the pay are not signs of fraud, and the standing employer-not-established entry, in its "
        "own words and at severity: medium, is not a scam-type finding",
        "Ronan's WhatsApp message, which schedules a video call held outside chat, is treated as ordinary "
        "scheduling: it is the source of no risk-register entry and raises no other entry's severity, the standing "
        "employer-not-established entry's included",
        "{{failed_attribution}}. Here, in a room that could not search, the entry stands at severity: medium, "
        "never high; where the room returned Fernquay's own About or careers page, that page establishes the "
        "employer, the response names it, and the entry does not appear",
        "{{decision}}. Here it is go or conditional_go, and no condition, hold or no_go rests on Fernquay's size, "
        "its footprint, its tone or the WhatsApp message",
        "{{no_accusation}}",
        "{{market_line}}. Here, where the sweep returned the Tillerby report, the line cites its figure and names "
        "the report as its basis, and the posting's own €52,000–€60,000 is compared against it",
        "Where Ronan Kehoe's public profile was read, it is used only as public professional footprint — his "
        "roles — and it feeds role reality's scope read or the application plan's positioning with its source "
        "named; where it was not read, nothing about him is asserted beyond what the posting and his message say",
        "{{map_vocab}}. Here the material requirements are 3+ years of product design, strong Figma, running her "
        "own user research, and working directly with engineers; being the company's first and only designer may "
        "be carried as an implied requirement, against Maeve's own statement that she has never been the only "
        "designer",
        "{{ledger_counts}}. {{hard_gates_line}}. Here Maeve states no constraints or non-negotiables of her own, "
        "so the candidate's constraints were not given and the line must end with its 'candidate constraints not "
        "given' clause",
        "{{not_attributable}}",
        "{{accounting}} Here no input answers any target and the co-founder was named, so no row is skipped or "
        "n/a. {{accounting_counts}}",
        "{{questions}}",
        "{{no_score}}",
        "{{closing}}",
        "{{generic_scope}}",
    ],
    "research": {
        "modes": ["canned", "denied"],
        "budget": BUDGET,
        "user_links": [],
        "entity_tokens": ["fernquay", "product", "designer"],
        "targets": [
            {"n": 1, "name": "company site and careers page", "terms": TARGET1_TERMS, "identity": ["fernquay"],
             "accept": {"canned": ["yes"], "denied": ["unavailable"]},
             "on_target_samples": ["Fernquay about", "Fernquay careers product designer",
                                   "Fernquay booking software Galway", "Fernquay employees founded",
                                   "Fernquay sea-kayak surf schools", "\"Fernquay\""]},
            {"n": 2, "name": "role-family sweep", "terms": TARGET2_TERMS,
             "accept": {"canned": ["yes"], "denied": ["unavailable"]},
             "on_target_samples": ["product designer salary Ireland 2026", "product designer pay Galway startup",
                                   "product designer salary benchmark Ireland"]},
            {"n": 3, "name": "hiring manager's public footprint", "terms": ["ronan", "kehoe"],
             "accept": {"canned": ["yes"], "denied": ["unavailable"]},
             "on_target_samples": ["Ronan Kehoe Fernquay", "Ronan Kehoe co-founder", "Ronan Kehoe product lead"]},
        ],
        "pages": [
            {"url": "https://fernquay.example/about", "title": "About Fernquay", "target": 1,
             "keywords": ["about", "booking", "company", "employees", "founded", "headquarters", "kayak", "overview",
                          "people", "sailing", "schools", "software", "surf", "team", "who"],
             "text": ("Fernquay makes Tidebook, booking software for sea-kayak, surf and sailing schools in Ireland "
                      "and Scotland. Six people, based in Galway. Founded 2023 by Ronan Kehoe and Saoirse Doyle, and "
                      "funded by its customers.")},
            {"url": "https://fernquay.example/careers/product-designer", "title": "Product Designer — Fernquay careers",
             "target": 1,
             "keywords": ["apply", "careers", "hiring", "job", "jobs", "opening", "openings", "posting", "vacancies",
                          "vacancy"],
             "text": ("Open now: Product Designer, our first design hire. Hybrid, two days a week in Galway. "
                      "€52,000–€60,000 plus equity. Apply with one real project to jobs@fernquay.example.")},
            {"url": "https://tillerby.example/2026-ireland-design-salary-report",
             "title": "Tillerby 2026 Ireland Design Salary Report", "target": 2,
             "keywords": ["band", "benchmark", "compensation", "tillerby", "levels", "market", "pay", "range",
                          "report", "salaries", "salary", "survey"],
             "text": ("Tillerby 2026, Ireland (n=520): product designers with 3 to 5 years — median base €57,000; "
                      "interquartile range €51,500 to €62,000.")},
            {"url": "https://www.linkedin.example/in/ronan-kehoe", "title": "Ronan Kehoe — Co-founder, Fernquay",
             "target": 3,
             "keywords": ["ceo", "cofounder", "founder", "kehoe", "linkedin", "profile", "ronan"],
             "text": ("Ronan Kehoe, co-founder and CEO at Fernquay. Before that, product lead at a Galway "
                      "travel-software company for five years.")},
        ],
        "canaries": [
            {"target": 1, "page": "https://fernquay.example/about", "text": ["Tidebook", "2023"]},
            {"target": 2, "page": "https://tillerby.example/2026-ireland-design-salary-report",
             "text": ["Tillerby", "57,000", "57k", "57K"]},
        ],
        "stray_samples": ["Fernquay glassdoor reviews", "Fernquay scam", "Fernquay news"],
    },
    "candidate_constraints": "unknown",
    "checks": ["fit_ledger", "yes_names_page"],
}

CASE_D = {
    "id": 11,
    "prompt": (
        "I was laid off last week and I'm applying for everything. Are either of these worth my time? FIRST: "
        "'Operations Analyst — Duinvaart Cold Chain, Rotterdam. Track on-time delivery and temperature compliance "
        "across our refrigerated fleet, build weekly dashboards in Power BI, and work with depot managers on route "
        "changes. Requirements: 2+ years in logistics or operations analysis; strong SQL; Power BI or Tableau; Dutch "
        "a plus. Hybrid, three days a week in our Rotterdam office.' SECOND: 'Supply Planner — Kroonhaven Foods, "
        "Utrecht. Own the 13-week supply plan for our chilled ready-meals range, balance production capacity against "
        "the forecast, and run the weekly S&OP meeting. Requirements: 3+ years of supply or demand planning in FMCG; "
        "advanced Excel; SAP IBP or a similar planning system; fluent Dutch. On-site in Utrecht.' MY BACKGROUND "
        "(call me Femi): 4 years as an operations analyst at a parcel carrier in Amsterdam; SQL and Power BI daily, "
        "including the on-time delivery dashboard our depot managers use; I ran our weekly route-performance review. "
        "My Dutch is conversational, not fluent. I've never worked in planning."),
    "expected_output": (
        "Report only: this records how the current skill handles two pasted postings in one request, and gates "
        "nothing. The observations are whether each posting gets its own underwriting and decision, whether the "
        "two assessments stay apart, whether one closing run ends the message, and whether a comparison or recap "
        "appears beside the snapshots."),
    "files": [],
    "expectations": [
        "{{first_pass}}",
        "Both postings are underwritten in this response: each has its own evidence map, its own risk register and "
        "its own decision of go, conditional_go, hold_pending_answers or no_go, with its rationale and what would "
        "change it",
        "Each posting's map rows, register entries and decision rest on that posting's own text: no requirement, "
        "quotation or register entry of one posting is filed under the other, and Femi's evidence is mapped to "
        "each posting's requirements separately",
        "{{not_attributable}}. {{failed_attribution}}. Here no research can reach either employer, so the entry "
        "stands for each",
        "{{no_accusation}}",
        "{{proposed_language}}. Here nothing claims planning experience or fluent Dutch",
        "{{questions}}",
        "{{no_score}}. Here neither posting gets one",
        "{{closing}}. Here the closing run comes once, after both assessments",
    ],
    "checks": [],
}

CASES = [CASE_A, CASE_B, CASE_C, CASE_D]


def main(argv: list[str]) -> int:
    out = HERE / "fixtures-item3.json"
    out.write_text(json.dumps({"clauses": CLAUSES, "evals": CASES}, indent=2, ensure_ascii=False) + "\n",
                   encoding="utf-8")
    if len(argv) == 3 and argv[1] == "--apply":
        path = Path(argv[2]) / "skills" / "job-underwriter" / "evals" / "evals.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        data["clauses"].update(CLAUSES)
        have = {c["id"] for c in data["evals"]}
        data["evals"] += [c for c in CASES if c["id"] not in have]
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(f"applied {len(CASES)} fixtures to {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
