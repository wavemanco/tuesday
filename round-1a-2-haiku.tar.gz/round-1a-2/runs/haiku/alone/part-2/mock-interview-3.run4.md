Your Stripe prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-3-denied-ded04a25/7556beab-1e25-436f-baa5-6ca2fba54c9a/scratchpad/stripe_product-operations-manager_interview_pack.md.

Web search was not permitted in this session, so the pack says nothing about Stripe's values, interview process or current strategy. I haven't filled those gaps from memory. The pack is built on generic Product Operations requirements and labelled that way. With no CV or JD, every evidence cell is empty, so the question banks are answer scaffolds rather than rehearsed stories. I've given the persona weights equal weight because I don't know who you're meeting.

Two questions would reshape it:
1. Who is the final round with, and what is their role relative to you: hiring manager, a peer on the team, or someone outside the function? Did the recruiter list any focus areas or a take-home?
2. Can you paste the job description and/or your CV? If not, I'll keep this version as built.

I can also play the Pressure interviewer on P2 ("Your answer to the last question depended on information you don't have yet. Why should I trust it?") for a live drill, and save a tuesday-dossier.md recording the gaps this prep exposed. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe: Product Operations Manager, final round prep pack

Role: Product Operations Manager. Company: Stripe. Round: final round. Interviewer and relationship: not given. Built without a JD, CV or interviewer, so every requirement is generic, every bank is a scaffold, and persona weights are flat.

## How to use

- **Personas** describe how a question arrives. **Types** describe what it scores.
- Type key: **VAL** behavioral, **EXP** work-experience deep-dive, **JD** role-driven, **CO** company and strategy, **CASE** live problem.
- Guidance is scaffolding, not a script. Rehearse it aloud, in your own words, until it runs in 90 to 120 seconds.
- Where guidance says "if none, say so", that is the honest answer when the thing did not happen. It is not a gap to hide.

## Fit snapshot

No JD, CV or recruiter note was supplied, so nothing about your past is quoted yet. Every row is a role-family requirement written as generic prose, and every evidence cell is `none given`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run a recurring operating process end to end, such as planning, reviews or launches (role family) | none given | none | [generic] | discovery | Your material does not show this yet, and the pack does not assume it. Selection scaffold: pick a recurring process you ran or helped run, and say what it decided and who attended. If you ran none, say so plainly and say how you would set one up. |
| F2 | Get product, engineering, sales and finance to one decision when they disagree (role family) | none given | none | [generic] | discovery | Selection scaffold: pick a decision where teams disagreed, and say what you did to reach one, in your own words. If there was no such decision, say so and describe how you would approach it. |
| F3 | Define and track metrics for a product area (role family) | none given | none | [generic] | discovery | Selection scaffold: name one metric you have tracked, what it counted, and what it could not tell you. If you have tracked none, say so and name the first metric you would define. |
| F4 | Answer an operational question from data (role family) | none given | none | [generic] | discovery | Selection scaffold: name a real question you answered with data and the tool you used. If there is none, say so and say how you would start. |
| F5 | Turn many competing requests into a ranked set of work (role family) | none given | none | [generic] | discovery | Selection scaffold: name the criteria you have used to rank requests and who made the call. If you have not ranked requests, say so and name the criteria you would start from. |

## Persona table

Relationship and round type are unknown, so the round-type priors do not set the weights. Each persona gets equal weight, four questions each, and I have not guessed a skew.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | Live problems from the role's own work: a slipped launch, a metric drop, a meeting to design | Equal weight. A final round usually includes a live problem, but the material does not say which round this is | Clarify, then structure, then recommend. Name the assumption you would check first |
| Skeptic | "What would make you a bad hire?" and "weakest on day one" | Equal weight. Final rounds often test the one risk the team has not settled | Name the real risk and the check you would run first. Do not bluff |
| Pressure | A 60-second motivation question, then a follow-up that challenges your position | Equal weight. Composure is scored whatever the round | Hold a position through two follow-ups, then concede the specific uncertainty |
| Peer Evaluator | Seams with their team, and who gets credit when work crosses teams | Equal weight. Peer-style probing is common in final rounds and the relationship is unknown | Propose seam principles rather than pretending to know their seam. Frame reciprocity |

## Question banks

Coverage: the stated role-family requirements F1 to F5 map to the question IDs below. The bank is shorter than the usual 18 to 26 because there is no JD to draw requirements from. It grows once you share one.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A launch you're coordinating is due Thursday. Two days out, engineering says it will slip a week, and sales wants it to ship. What do you do?" | CASE | [generic] | Clarify first: what slips, what it breaks, and who decides by when. Lay out two or three options, each with its cost. Recommend one, say what you would tell each team, and write the decision down. Speakable in 90 to 120 seconds | A live problem from the role family, asked as a decision. It makes no claim about your past. Covers F1 and F2 |
| C2 | "A metric on a product ops dashboard drops 20 percent in a week. Diagnose it." | CASE | [generic] | Structure it: is the drop real (instrumentation, pipeline, or a definition change), where (segment, region, surface), and what changed (launch, pricing, incident). Say what you would check first and what result would change your mind. Do not conclude before you have said what you need | A diagnosis question that tests reasoning, not recall. Covers F3 and F4 |
| C3 | "How would you set up a weekly operating review for a product area that has none?" | CASE | [generic] | Start from the decision the review exists to make. Then cover the owner, the inputs, the agenda, who has decision rights, and how items get in and out. Keep it to what you would do in the first four weeks | A design question about a recurring process. Covers F1 |
| C4 | "How would you decide which of five requests from product teams gets done first?" | CASE | [generic] | Name the criteria before the ranking: impact, cost, deadline, and what it unblocks. Say who makes the final call and how you would tell a team it is not first. Write the criteria down so the ranking can be challenged | A prioritisation problem from the role's daily work. Covers F5 |
| S1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name the one area. Say what you would do in the first two weeks to close it, and who you would ask. Make no claim about your history | A skeptic's opening, aimed at the gap the snapshot cannot yet rule out. Covers F1 to F3 |
| S2 | "Why product operations, and why would you be better at it than someone who has done it longer?" | JD | [generic] | Say what you would bring that is specific to this role, and what you would do first. If your time in this function is shorter than another candidate's, say so in one sentence and stop. Do not claim years you have not worked | A motivation probe with a comparison built in. The guidance does not adopt the comparison as a fact |
| S3 | "What would make you a bad hire for this role?" | JD | [generic] | Name the real risk you see, which is likely the least-covered requirement among F1 to F5, and the check you would run to test it. Avoid false modesty and avoid a list of virtues | A skeptic's closing probe. It tests whether you can name a risk without either bluffing or collapsing |
| S4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold, a persona stem: pick a time you told someone senior something they did not want to hear. It needs a named stake, a moment you did not fold, and a working relationship at the end. If no such time comes to mind, say so plainly, then say how you would raise it | An open prompt from the values persona stems. It is asked here because composure matters in a final round, not because a values round was detected |
| P1 | "Sixty seconds: why this role, and why now?" | JD | [generic] | A 60-second arc: what draws you to product operations, one thing you would do first in the role, and one question for them. Practise until it lands inside a minute | A composure question with a timer. Rehearse the arc so the first sentence is not a search |
| P2 | "Your answer to the last question depended on information you don't have yet. Why should I trust it?" | CASE | [generic] | Hold the position through two follow-ups. Name the assumption it depends on and the check you would run first. Concede the uncertainty specifically, and do not fold on the core recommendation | A pressure follow-up that works on any answer. The hold-then-concede structure is the rehearsal |
| P3 | "Sixty seconds: why should we move you from where you are to here?" | JD | [generic] | Name the one thing this role offers that your current work does not, and why now. Do not list every reason. Stop at 60 seconds | A motivation question with a time box. It tests whether you can choose one reason and stop |
| P4 | "If you had 60 seconds to change one thing about how product decisions get made here, what would it be?" | CO | [generic] | Pick one change. Say the evidence you would need before proposing it, and what would make it fail. Concede in one clause that an outsider's view is partial | A company-altitude question that scores judgment over knowledge. It presumes nothing about your past |
| E1 | "Our teams sit side by side. Where is the seam between product ops and our team, and what happens when we disagree?" | JD | [generic] | Propose seam principles: who owns the decision, who owns the data, and how a disagreement escalates. Do not pretend to know their seam. Say what you would bring to their team | A peer's probe into turf. It asks about principles, not facts you cannot know. Covers F1 and F2 |
| E2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Selection scaffold, a persona stem: pick a time work crossed teams, and say whose work did what, in your own words. If you have no such time, say so plainly, then say how you would credit a shared outcome | An open prompt on collaboration. It tests credit-sharing, which peers probe in collegial form |
| E3 | "What do you need from my team in your first quarter to make the job work?" | JD | [generic] | Name two or three specific asks, each with a reason. Do not invent a need you have not thought through. Ask for the thing you would actually use | A peer's collegial test of what the hire costs their team. It is scored on specificity |
| E4 | "Two teams want the same engineering time next quarter. How do you handle that as a peer?" | CASE | [generic] | Clarify what each team needs and by when. Propose a way to decide that does not depend on who asks loudest. Name who makes the final call and how you would tell the team that loses | A peer-level live problem about shared resources. Covers F2 and F5 |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What decision did this team make last quarter that you would want a new hire to understand?" | It shows you are thinking about decisions, not only tasks |
| R2 | "What does success look like for this role at six months?" | It makes the success measure theirs to define, and gives you the test you will be held to |
| R3 | "Where has product operations gone wrong here before, and what changed afterwards?" | It is an honest question that a manager will answer candidly, and it surfaces the real risk |
| R4 | "Which teams does this role work with most in the first quarter, and where do they usually disagree?" | It shows you are already looking at the seams, which is what a peer evaluator will want to see |
| R5 | "If we hired the wrong person for this role, what would the signs be by month three?" | It asks what failure looks like in their words, and the answer is the bar you will be held to |
| R6 | Reciprocity, if your interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?" | It turns the conversation into a peer one. There is no interviewer profile, so no reverse question is tied to their own career path |

## Prohibited claims

No candidate sentence exists yet, so no inflated form of your material can be listed. A claim the pack has not seen cannot be coached. This section is rebuilt once a CV arrives.

| Not coached | Basis | Honest form |
|---|---|---|
| Any process, metric or decision you did not run yourself | Generic pressure pattern for this role family, not a claim about you | Say what you ran, in your own words. If you ran none, say so and say how you would approach it |
| Years in the function you do not have | Same generic pattern | Say the years you actually have, in your own words |

## Sources

Provided documents: your message, which named the company, the role and the round, and nothing else.

Searches sent this session, each refused because the web search permission was not granted. None returned a result:

- `Stripe company values principles` (refused)
- `Stripe interview process Product Operations Manager final round` (refused)
- `Stripe recent news strategy 2026` (refused)

Research tier: L1 — searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Values cheat sheet, section 10. Dropped: no values-style round is detected, and no published values are in hand |
| 2. `Stripe interview process Product Operations Manager` | unavailable | Loop structure and persona weights. No loop source establishes the loop, so the weights are flat and say so |
| 3. `Stripe strategy` and recent news | unavailable | CO and CASE questions grounded in current strategy. These are generic here |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Would have fixed the requirements in the fit snapshot. The search did not run |

## Upgrade menu

- A pasted JD → the five generic rows in the fit snapshot (F1 to F5) become the posting's own words, and the bank's JD questions get the posting's requirements to draw on
- Your CV → each fit row gets a quoted sentence of yours, and the banks become story-mapped where your sentences carry a story
- Who you are meeting and their role relative to you → persona weights and the reverse questions reflect that round
- A recruiter's note on focus areas, or any take-home or presentation → coverage of that deliverable and a graded-deliverable section
- Turning on web search → reruns research targets 1 to 3: the values page, the interview process, and recent strategy
- An interviewer's name → an interviewer read from their public career, and a reverse question tied to their own path
- Any location or right-to-work condition in the posting → one gate row, asked once
- A deeper research pass (L2), with up to 6 more searches and 2 more fetches, several more minutes, which also needs web search turned on. Want it?
