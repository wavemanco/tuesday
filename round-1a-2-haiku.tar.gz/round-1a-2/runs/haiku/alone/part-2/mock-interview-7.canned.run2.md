Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-7-canned-5d39555d/a3488e30-4ac1-48a2-8ac6-200d1ac39061/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. I built it on the company's own interview page, which says the 60 minutes are one "Outage Hour" with the hiring manager: a live-incident tabletop, then a values conversation.

# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations (relationship: hiring manager, per the company's interviewing page; not yet confirmed by you)
**Format:** one 60-minute "Outage Hour" session: a live-incident tabletop on a simulated outage during a live event, then a values conversation (saltmarshgames.com/careers/interviewing). No take-home.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behavioral / values: does your past behavior show the company's published values |
| EXP | Experience deep-dive: what you actually did, and how you'd defend a claim |
| JD | Role-driven: can you do the listed job, including its gaps |
| CO | Company knowledge: homework depth |
| CASE | Live problem: structure and reasoning, delivered live |

Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

## Fit snapshot

Requirements are quoted from your JD. Evidence is quoted from your own message, exactly as you wrote it. The bridge column says what you can say, and where the material is silent, it gives an answer slot instead of words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (your JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title and a weekly content-drop calendar, not live events across two titles. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned for more than one title, or ran a live event rather than a drop, say what and how you decided; if not, say so plainly and say how you would approach two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" (your JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | Your material shows one team you worked with, QA, through the checklist. It is silent on design, art, engineering and community. Answer slot: if you coordinated any of those four on a content update, say which and how; if none, say so plainly and say how you would set that coordination up. |
| F3 | "own the post-event review and the KPIs it reports" (your JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Presenting numbers is not owning the review that produced them. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: did you own the review behind those numbers, or set the KPIs? If yes, say how; if not, say so plainly. |
| F4 | "manage the release checklist with QA" (your JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the checklist and QA, but says wrote and still used, not managed. Bridge: "I wrote the release checklist our QA team still uses." Limited inspectable proof: expect a probe on how it is maintained today. |
| F5 | "3+ years producing live-service games or apps" (your JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The years, the title and the studio are in the quote. "Live-service" is not in your words; it rests on the weekly drops, so do not give it as a title. Bridge: "For four years I was an associate producer at a puzzle-game studio." |
| F6 | "experience running a content calendar" (your JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how the weekly drops were scheduled and changed. |
| F7 | "comfortable with player-retention metrics" (your JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | The quote reaches the requirement. No figures are in your material, so expect a defend-the-number probe (D1). |
| F8 | "clear written communication" (your JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | Your material names one piece of writing, but not its clarity. Answer slot: if you can point to written work others relied on, name it and what it was for; if not, say so plainly. |

Not JD lines, so no rows: people management ("Never led a team", your message) and in-app purchases ("Never worked on a game with in-app purchases.", your message). The JD asks for neither by name. Both are in the Skeptic bank (B3, B4) and the prohibited list.

## Prohibited claims

These are not coached in any answer, hold or bridge. Built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the post-event review or the KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." Limit, in the pack's own analysis: your material says presenting, not owning. |
| Ran live events across two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." |
| Was a producer | Inflated form of F5 | "an associate producer", as quoted |
| Led a team | Stated negative | "I've never led a team." (from "Never led a team") |
| Worked on a game with in-app purchases | Stated negative | "I haven't worked on a game with in-app purchases." (from "Never worked on a game with in-app purchases.") |

## Reading the interviewer

Public footprint only, from one search listing (I could not open the page).

- **Career pattern:** Head of Live Operations at Saltmarsh; previously a QA lead at a console studio.
- **Published talk:** "Patch Notes Are a Promise" (GDC 2026). Its argument, as the listing gives it: a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. "Ship the Patch Not the Promise" is his talk's theme. C2 is the value he is most likely to test; rehearse it.
  2. The QA side of your story (F4) will land with him. Tell it plainly.
  3. A write-up of a post-event note (A5) is in his lane.
- **Shared jump:** none offered. Nothing in your material shows a move from QA into live operations, so I have not paired his path with one of your sentences.

## Persona table

The loop source documents a values conversation, so the values persona is certain in this session. The Outage Hour makes Case the lead format. Peer is omitted: this is a hiring-manager session, not a peer round.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop | High. The company's own page names it as the session's first half. | Clarify, then act, then log what you'd record for the review | 5 (A1 to A5) |
| Skeptic | A hiring manager checking gaps: ownership, leadership, monetisation | High. The hiring-manager role makes gap-checking the default. | Rehearse B1 until it is plain; bridge from quotes only | 4 (B1 to B4) |
| Values / Behavioral | The values conversation | Certain. The loop source documents it. | Map each value to a quote, or use a scaffold with its honest branch | 3 (C1 to C3) |
| Data-Driven Prober | Retention and KPI figures | Medium-high. Two of your JD lines are metrics. | Name the weakest assumption before they do | 3 (D1 to D3) |
| Pressure | Time-boxed 60 minutes | Medium. | Pause, restate, hold two follow-ups | 2 (E1 to E2) |
| Conversational | The opening biography | Medium. | Run the 90-second arc from your own quotes | 3 (F1 to F3) |

Weights rest on the company's interview page. If Tobias is not the hiring manager, the Skeptic weight moves (question at the end).

## Question banks

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your live event starts in two hours and players on one platform report a broken reward screen. Walk me through what you do." | CASE | [grounded] Outage Hour format, saltmarshgames.com/careers/interviewing | Clarify before deciding: how many players, which platform, whether the build or the server is at fault, and whether to pause the event. Name who you call and in what order (engineering, QA, community). Draft the first player-facing message and state only what is confirmed. Say what you'd log for the post-event review. | The loop's documented format. A live problem with no claim about your past. |
| A2 | "Seven days after an update, retention on one title is down four points. Diagnose it." | CASE | [generic] | Clarify the cohort and the comparison window first. Check release timing, what shipped, and whether the drop sits in one segment or all of them. Say what you would rule out before blaming the update. | Retention is in your JD (F7). The scenario is a pattern for the problem, not a fact about this studio. |
| A3 | "Tell me about a time a release or live event went wrong on your watch, and what you did." | CASE | [generic]; nearest quote: "Wrote the release checklist our QA team still uses." | Open prompt. Pick a time a release or event went wrong that you were in the room for. If none comes to mind, say so plainly, then give the nearest thing your material carries, the checklist you wrote, and how you'd handle the next one. | The Outage Hour tests incident handling. No sentence in your material carries an incident, so this is a selection scaffold with its honest branch. |
| A4 | "Assume two titles now share one events calendar and a single live-ops group. What do you do in your first month?" | CASE | [grounded] Project Larkspur news item, saltmarshgames.com (search listing only, not opened) | Clarify capacity, dependencies and what each title's players expect. Propose one calendar with a rule for priority between titles, and name the trade-off you'd settle first. Answer slot: if you have planned for two titles before, say how; if not, say so plainly and say how you'd learn the second title. | Covers F1 and the coordination line, and uses the company's current direction. The scenario is set by the question, so it presupposes nothing about you. |
| A5 | "Write the first three sentences of the note you'd send the team after a live event that missed its retention target." | JD | [generic] | Lead with the number and what it was measured against. Then what you think happened, marked as a hypothesis. Then what you're checking next, and by when. Keep each sentence to what you know. | Covers "clear written communication" (F8). A writing exercise, not a claim about your past. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role owns the post-event review and the KPIs it reports. Have you owned one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | **Highest-ROI prep in this pack.** This will be asked in some form, and it sits where your material is thinnest. Hold the line in your quote: "I presented the monthly retention numbers to the studio head." Answer slot: if you owned the review behind those numbers, say what you ran and decided, in your own words; if another person's review produced them, say that plainly and say what you would own. Hold through two follow-ups by returning to what you presented. | F3 is the gap. This gets the deepest rehearsal: the most follow-ups and the exact wording of the held position. |
| B2 | "Your calendar was weekly. A live event runs on a different cadence. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what weekly cadence taught you, from running it. Then what you'd check for an event: length, lead time for art and engineering, and the player-facing deadline. Answer slot: if you have planned an event rather than a drop, say how; if not, say so plainly and what you'd ask first. | F1 is transferable, not direct. The question tests whether you see the difference. |
| B3 | "This role coordinates four teams with no line authority. Have you led a team?" | JD | [grounded] "Never led a team" (your message); "Wrote the release checklist our QA team still uses." (your message) | Say it plainly: "I've never led a team." Then the coordinating evidence in its own sentence: the checklist QA still uses. Then a ramp plan: how you'd earn trust from design, art, engineering and community without authority. Do not claim you coordinated them unless you did. | Your own stated gap. "Coordinate" is in the JD even though "lead" is not. |
| B4 | "What would you need to know about a title's monetisation before you changed its events calendar?" | JD | [generic]; plain acknowledgment from "Never worked on a game with in-app purchases." (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what you'd ask first: which purchases sit alongside the events, and what the calendar is expected to move. Name no monetisation practice you did not do. | Not a JD line. A live-service calendar meets monetisation, so expect it. The question presupposes nothing about the studio's model. |

### Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "Players Before Plans" (saltmarshgames.com/values); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Open prompt. Pick a time a drop was moved, cut or changed because of what players were doing or saying. If none comes to mind, say so plainly, then give the nearest thing your material carries, the weekly drops, and how you decided. | The values conversation is documented. The value is published; the story must be yours. |
| C2 | "Tell me about a time you announced something before it was built." | VAL | [grounded] "Ship the Patch Not the Promise" (saltmarshgames.com/values); "Wrote the release checklist our QA team still uses." (your message) | Pick a time a note or announcement got ahead of the build. If none, say so plainly, then describe what the release checklist you wrote covers, in your own words. | His talk's theme is patch notes matching what shipped. Likely the value he tests hardest. |
| C3 | "Give me an example of a process you left better than you found it." | VAL | [grounded] "Leave the Build Greener" (saltmarshgames.com/values); "Wrote the release checklist our QA team still uses." (your message) | Open prompt. Pick a process you changed for the better. If none, say so plainly. Then the checklist: if you know what it replaced, say so; if you started it from nothing, say that. | The third value. The checklist is the only sentence you have on process. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How were the monthly retention numbers you presented counted, and by whom?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the assumption you'd defend least, before they ask. Say who counted: you or a team. If you did not set the definition, say whose it was. Do not supply a cohort definition or method you did not use. Answer slot. | F7 defend-the-number slot. Figures raise the probe; your material holds no method. |
| D2 | "How, if at all, did you connect the monthly retention numbers to the content drops?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | The weakest assumption is the connection itself. If you connected them, say how. If you presented the figures without linking them to drops, say that plainly. Do not attribute a change to a drop unless you can show it. Answer slot. | The likeliest prober follow-up on F3, F6 and F7. |
| D3 | "Walk me through the release checklist you wrote: what it covers and how QA uses it today." | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Describe what it covers in your own words, to the depth you know it. Say what you don't know about how QA uses it now. Do not claim you manage it; the quote says you wrote it and QA still uses it. | JD line "manage the release checklist with QA" (F4). |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you rather than someone who has run live events across two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Pause and restate the question. Anchor in what you ran. Do not claim a second title. Hold the position through two follow-ups. Concede what you have not done, in your own words, and only where it's true. | Composure test on F1. |
| E2 | "That retention figure: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold: you presented the figure, and you're clear about what you did with it. Concede any part you cannot account for, specifically, in your own words. Hold, then concede; never fold on the core claim. | Attribution probe on F7. |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." (all your message) | A 90-second arc in this order, each sentence as you wrote it. Add nothing between them. | Uses only quotes. Casual, but scored. |
| F2 | "What's a live-service game you've been playing lately, and what does its live team do well?" | CO | [generic] | Name one game. Say one thing its live team does well, from playing it, not from inside it. Do not claim knowledge of its internals. | Casual on a JD topic, so scored. No claim about the company. |
| F3 | "What did those four years look like day to day, and what was live about them?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Describe the work in your own words. Say which part of the four years was live-service work, and how you know it was live. Answer slot: if little of it was live, say so. | JD "3+ years producing live-service games or apps" (F5). The title is the limit. |

## Values / principles cheat sheet

Values-style round detected: the loop source documents a values conversation. Published values fetched from saltmarshgames.com/values.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | F1 quote, "I ran the weekly content-drop calendar for our main title for the last two years." Scaffold in C1, with its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F4 quote, "Wrote the release checklist our QA team still uses." Scaffold in C2, with its honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4 quote again. Scaffold in C3, with its honest branch. Do not claim an improvement you did not make |

## Reverse questions

Each has a "why it lands." Tobias is the only interviewer, so no peer reciprocity question is included.

1. "Your GDC talk argues a live team is judged by how often its patch notes describe what shipped. What does that look like on your team week to week?" Why it lands: it shows you read his public work, and it hands him his own argument. Source is a search listing; check the talk before the interview.
2. "Project Larkspur moves two titles to one shared calendar and one live-ops group. What has the first stretch taught the team?" Why it lands: it shows you read the company's news. Check the item first; I saw it only in a search listing.
3. "Who owns the post-event review today, and which KPIs does it report?" Why it lands: it answers the JD's F3 line from the source, and tells you what owning it means here.
4. "How does QA sign-off work with the live-ops team now?" Why it lands: it ties to the checklist and tests whether the release process is written down.
5. "What would make the first 90 days in this role a clear success?" Why it lands: it turns the gap questions into an agreed scorecard, which is what a hiring manager is trying to get from you.

## Coverage against the JD

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A4, B2, F1 |
| Coordinate design, art, engineering and community on each update | A4, B3 |
| Own the post-event review and the KPIs it reports | B1, D1, D2 |
| Manage the release checklist with QA | D3, C2 |
| 3+ years producing live-service games or apps | F3, E1 |
| Experience running a content calendar | F1, B2 |
| Comfortable with player-retention metrics | A2, D1, E2 |
| Clear written communication | A5 |

## Sources

**Provided documents:** your JD and your message (both pasted).

**Searches and fetches sent:**

| Query | Result |
|---|---|
| "Saltmarsh Games values" | saltmarshgames.com/values, fetched |
| "Saltmarsh Games interview process live operations producer" | saltmarshgames.com/careers/interviewing, fetched |
| "Tobias Wrenfield Saltmarsh Games" | talks.gdconf.example listing for "Patch Notes Are a Promise" (GDC 2026), search snippet only, not opened |
| "Saltmarsh Games news 2026 live events mobile titles" | saltmarshgames.com/news/project-larkspur, search snippet only, not opened |

**Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values cheat sheet: three names, read from the official page |
| 2. Saltmarsh interview process | yes | Loop: one 60-minute Outage Hour, hiring manager, no take-home; persona weights and A1 to A3 |
| 3. Saltmarsh strategy / recent news | yes | Found the Larkspur item (snippet only); moved A4 and reverse question 2 |
| 4. Tobias Wrenfield + company | yes | Interviewer read and reverse question 1; both from a search listing, not opened |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions |

Facts from listings I could not open are marked as such. Verify them before relying on them.

## Upgrade menu

- **A deeper research pass (L2):** a company strategy brief, Tobias's other talks and posts, loop reports, recent org context. Adds a fuller CO bank and sharper reverse questions. Costs up to 6 more searches and 2 more page fetches, several minutes. Say the word and I'll run it.
- **A live incident or release day you were in, in your own words:** moves A3 and C2 from selection scaffolds to story-mapped answers.
- **Planning you did across more than one title, or a live event (not a drop):** moves F1 and B2 toward presentation, and gives A4 a story.
- **Any coordination with design, art, engineering or community on an update:** moves F2 from discovery to a quoted row, and strengthens B3.
- **A written piece others relied on (a patch note, a post-event write-up):** moves F8 from discovery to grounded, and gives A5 a sample to build on.
- **The numbers behind your retention figures, and how they were counted:** gives D1 and E2 an answer you can repeat under a second question.

---

Two offers, neither pushed:
- **Drill:** I can play Tobias as the Skeptic on B1, the question the pack names as highest-ROI prep, and give feedback against that question's guidance.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed (ownership of the review, leadership, monetisation), so later sessions start from them.

If you'd like the pack as a Word document, say so and I'll convert it.

Is Tobias the hiring manager for this role? If he's a skip-level or a panel member, the persona weights change.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Candidate:** Femi
**Interviewer:** Tobias Wrenfield, Head of Live Operations (relationship: hiring manager, per the company's interviewing page; not yet confirmed by you)
**Format:** one 60-minute "Outage Hour" session: a live-incident tabletop on a simulated outage during a live event, then a values conversation (saltmarshgames.com/careers/interviewing). No take-home.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behavioral / values: does your past behavior show the company's published values |
| EXP | Experience deep-dive: what you actually did, and how you'd defend a claim |
| JD | Role-driven: can you do the listed job, including its gaps |
| CO | Company knowledge: homework depth |
| CASE | Live problem: structure and reasoning, delivered live |

Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

## Fit snapshot

Requirements are quoted from your JD. Evidence is quoted from your own message or CV, exactly as you wrote it. The bridge column says what you can say, and where the material is silent, it gives an answer slot instead of words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (your JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title and a weekly content-drop calendar, not live events across two titles. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you planned for more than one title, or ran a live event rather than a drop, say what and how you decided; if not, say so plainly and say how you would approach two titles. |
| F2 | "coordinate design, art, engineering and community teams on each update" (your JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | Your material shows one team you worked with, QA, through the checklist. It is silent on design, art, engineering and community. Answer slot: if you coordinated any of those four on a content update, say which and how; if none, say so plainly and say how you would set that coordination up. |
| F3 | "own the post-event review and the KPIs it reports" (your JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [grounded] | transferability | Presenting numbers is not owning the review that produced them. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: did you own the review behind those numbers, or set the KPIs? If yes, say how; if not, say so plainly. |
| F4 | "manage the release checklist with QA" (your JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the checklist and QA, but says wrote and still used, not managed. Bridge: "I wrote the release checklist our QA team still uses." Limited inspectable proof: expect a probe on how it is maintained today. |
| F5 | "3+ years producing live-service games or apps" (your JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | The years, the title and the studio are in the quote. "Live-service" is not in your words; it rests on the weekly drops, so do not give it as a title. Bridge: "For four years I was an associate producer at a puzzle-game studio." |
| F6 | "experience running a content calendar" (your JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | The quote reaches the requirement. Expect a probe on how the weekly drops were scheduled and changed. |
| F7 | "comfortable with player-retention metrics" (your JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | The quote reaches the requirement. No figures are in your material, so expect a defend-the-number probe (D1). |
| F8 | "clear written communication" (your JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | Your material names one piece of writing, but not its clarity. Answer slot: if you can point to written work others relied on, name it and what it was for; if not, say so plainly. |

Not JD lines, so no rows: people management ("Never led a team", your message) and in-app purchases ("Never worked on a game with in-app purchases.", your message). The JD asks for neither by name. Both are in the Skeptic bank (B3, B4) and the prohibited list.

## Prohibited claims

These are not coached in any answer, hold or bridge. Built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the post-event review or the KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." Limit, in the pack's own analysis: your material says presenting, not owning. |
| Ran live events across two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." |
| Was a producer | Inflated form of F5 | "an associate producer", as quoted |
| Led a team | Stated negative | "I've never led a team." (from "Never led a team") |
| Worked on a game with in-app purchases | Stated negative | "I haven't worked on a game with in-app purchases." (from "Never worked on a game with in-app purchases.") |

## Reading the interviewer

Public footprint only, from one search listing (I could not open the page).

- **Career pattern:** Head of Live Operations at Saltmarsh; previously a QA lead at a console studio.
- **Published talk:** "Patch Notes Are a Promise" (GDC 2026). Its argument, as the listing gives it: a live team is judged by how often its patch notes describe what actually shipped.
- **Implications:**
  1. "Ship the Patch Not the Promise" is his talk's theme. C2 is the value he is most likely to test; rehearse it.
  2. The QA-side of your story (F4) will land with him. Tell it plainly.
  3. A write-up of a post-event note (A5) is in his lane.
- **Shared jump:** none offered. Nothing in your material shows a move from QA into live operations, so I have not paired his path with one of your sentences.

## Persona table

The loop source documents a values conversation, so the values persona is certain in this session. The Outage Hour makes Case the lead format. Peer is omitted: this is a hiring-manager session, not a peer round.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Case / Strategist | The Outage Hour tabletop | High. The company's own page names it as the session's first half. | Clarify, then act, then log what you'd record for the review | 5 (A1 to A5) |
| Skeptic | A hiring manager checking gaps: ownership, leadership, monetisation | High. The hiring-manager role makes gap-checking the default. | Rehearse B1 until it is plain; bridge from quotes only | 4 (B1 to B4) |
| Values / Behavioral | The values conversation | Certain. The loop source documents it. | Map each value to a quote, or use a scaffold with its honest branch | 3 (C1 to C3) |
| Data-Driven Prober | Retention and KPI figures | Medium-high. Two of your JD lines are metrics. | Name the weakest assumption before they do | 3 (D1 to D3) |
| Pressure | Time-boxed 60 minutes | Medium. | Pause, restate, hold two follow-ups | 2 (E1 to E2) |
| Conversational | The opening biography | Medium. | Run the 90-second arc from your own quotes | 3 (F1 to F3) |

Weights rest on the company's interview page. If Tobias is not the hiring manager, the Skeptic weight moves (question at the end).

## Question banks

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your live event starts in two hours and players on one platform report a broken reward screen. Walk me through what you do." | CASE | [grounded] Outage Hour format, saltmarshgames.com/careers/interviewing | Clarify before deciding: how many players, which platform, whether the build or the server is at fault, and whether to pause the event. Name who you call and in what order (engineering, QA, community). Draft the first player-facing message and state only what is confirmed. Say what you'd log for the post-event review. | The loop's documented format. A live problem with no claim about your past. |
| A2 | "Seven days after an update, retention on one title is down four points. Diagnose it." | CASE | [generic] | Clarify the cohort and the comparison window first. Check release timing, what shipped, and whether the drop sits in one segment or all of them. Say what you would rule out before blaming the update. | Retention is in your JD (F7). The scenario is a pattern for the problem, not a fact about this studio. |
| A3 | "Tell me about a time a release or live event went wrong on your watch, and what you did." | CASE | [generic]; nearest quote: "Wrote the release checklist our QA team still uses." | Open prompt. Pick a time a release or event went wrong that you were in the room for. If none comes to mind, say so plainly, then give the nearest thing your material carries, the checklist you wrote, and how you'd handle the next one. | The Outage Hour tests incident handling. No sentence in your material carries an incident, so this is a selection scaffold with its honest branch. |
| A4 | "Assume two titles now share one events calendar and a single live-ops group. What do you do in your first month?" | CASE | [grounded] Project Larkspur news item, saltmarshgames.com (search listing only, not opened) | Clarify capacity, dependencies and what each title's players expect. Propose one calendar with a rule for priority between titles, and name the trade-off you'd settle first. Answer slot: if you have planned for two titles before, say how; if not, say so plainly and say how you'd learn the second title. | Covers F1 and the coordination line, and uses the company's current direction. The scenario is set by the question, so it presupposes nothing about you. |
| A5 | "Write the first three sentences of the note you'd send the team after a live event that missed its retention target." | JD | [generic] | Lead with the number and what it was measured against. Then what you think happened, marked as a hypothesis. Then what you're checking next, and by when. Keep each sentence to what you know. | Covers "clear written communication" (F8). A writing exercise, not a claim about your past. |

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role owns the post-event review and the KPIs it reports. Have you owned one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | **Highest-ROI prep in this pack.** This will be asked in some form, and it sits where your material is thinnest. Hold the line in your quote: "I presented the monthly retention numbers to the studio head." Answer slot: if you owned the review behind those numbers, say what you ran and decided, in your own words; if another person's review produced them, say that plainly and say what you would own. Hold through two follow-ups by returning to what you presented. | F3 is the gap. This gets the deepest rehearsal: the most follow-ups and the exact wording of the held position. |
| B2 | "Your calendar was weekly. A live event runs on a different cadence. What changes?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Say what weekly cadence taught you, from running it. Then what you'd check for an event: length, lead time for art and engineering, and the player-facing deadline. Answer slot: if you have planned an event rather than a drop, say how; if not, say so plainly and what you'd ask first. | F1 is transferable, not direct. The question tests whether you see the difference. |
| B3 | "This role coordinates four teams with no line authority. Have you led a team?" | JD | [grounded] "Never led a team" (your message); "Wrote the release checklist our QA team still uses." (your message) | Say it plainly: "I've never led a team." Then the coordinating evidence in its own sentence: the checklist QA still uses. Then a ramp plan: how you'd earn trust from design, art, engineering and community without authority. Do not claim you coordinated them unless you did. | Your own stated gap. "Coordinate" is in the JD even though "lead" is not. |
| B4 | "What would you need to know about a title's monetisation before you changed its events calendar?" | JD | [generic]; plain acknowledgment from "Never worked on a game with in-app purchases." (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then what you'd ask first: which purchases sit alongside the events, and what the calendar is expected to move. Name no monetisation practice you did not do. | Not a JD line. A live-service calendar meets monetisation, so expect it. The question presupposes nothing about the studio's model. |

### Values / Behavioral (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "Players Before Plans" (saltmarshgames.com/values); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Open prompt. Pick a time a drop was moved, cut or changed because of what players were doing or saying. If none comes to mind, say so plainly, then give the nearest thing your material carries, the weekly drops, and how you decided. | The values conversation is documented. The value is published; the story must be yours. |
| C2 | "Tell me about a time you announced something before it was built." | VAL | [grounded] "Ship the Patch Not the Promise" (saltmarshgames.com/values); "Wrote the release checklist our QA team still uses." (your message) | Pick a time a note or announcement got ahead of the build. If none, say so plainly, then describe what the release checklist you wrote covers, in your own words. | His talk's theme is patch notes matching what shipped. Likely the value he tests hardest. |
| C3 | "Give me an example of a process you left better than you found it." | VAL | [grounded] "Leave the Build Greener" (saltmarshgames.com/values); "Wrote the release checklist our QA team still uses." (your message) | Open prompt. Pick a process you changed for the better. If none, say so plainly. Then the checklist: if you know what it replaced, say so; if you started it from nothing, say that. | The third value. The checklist is the only sentence you have on process. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How were the monthly retention numbers you presented counted, and by whom?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Name the assumption you'd defend least, before they ask. Say who counted: you or a team. If you did not set the definition, say whose it was. Do not supply a cohort definition or method you did not use. Answer slot. | F7 defend-the-number slot. Figures raise the probe; your material holds no method. |
| D2 | "How, if at all, did you connect the monthly retention numbers to the content drops?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message); "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | The weakest assumption is the connection itself. If you connected them, say how. If you presented the figures without linking them to drops, say that plainly. Do not attribute a change to a drop unless you can show it. Answer slot. | The likeliest prober follow-up on F3, F6 and F7. |
| D3 | "Walk me through the release checklist you wrote: what it covers and how QA uses it today." | JD | [grounded] "Wrote the release checklist our QA team still uses." (your message) | Describe what it covers in your own words, to the depth you know it. Say what you don't know about how QA uses it now. Do not claim you manage it; the quote says you wrote it and QA still uses it. | JD line "manage the release checklist with QA" (F4). |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you rather than someone who has run live events across two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | Pause and restate the question. Anchor in what you ran. Do not claim a second title. Hold the position through two follow-ups. Concede what you have not done, in your own words, and only where it's true. | Composure test on F1. |
| E2 | "That retention figure: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." (your message) | Hold: you presented the figure, and you're clear about what you did with it. Concede any part you cannot account for, specifically, in your own words. Hold, then concede; never fold on the core claim. | Attribution probe on F7. |

### Conversational (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years."; "Wrote the release checklist our QA team still uses."; "Presented the monthly retention numbers to the studio head." (all your message) | A 90-second arc in this order, each sentence as you wrote it. Add nothing between them. | Uses only quotes. Casual, but scored. |
| F2 | "What's a live-service game you've been playing lately, and what does its live team do well?" | CO | [generic] | Name one game. Say one thing its live team does well, from playing it, not from inside it. Do not claim knowledge of its internals. | Casual on a JD topic, so scored. No claim about the company. |
| F3 | "What did those four years look like day to day, and what was live about them?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Describe the work in your own words. Say which part of the four years was live-service work, and how you know it was live. Answer slot: if little of it was live, say so. | JD "3+ years producing live-service games or apps" (F5). The title is the limit. |

## Values / principles cheat sheet

Values-style round detected: the loop source documents a values conversation. Published values fetched from saltmarshgames.com/values.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | F1 quote, "I ran the weekly content-drop calendar for our main title for the last two years." Scaffold in C1, with its honest branch |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F4 quote, "Wrote the release checklist our QA team still uses." Scaffold in C2, with its honest branch |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them | F4 quote again. Scaffold in C3, with its honest branch. Do not claim an improvement you did not make |

## Reverse questions

Each has a "why it lands." Tobias is the only interviewer, so no peer reciprocity question is included.

1. "Your GDC talk argues a live team is judged by how often its patch notes describe what shipped. What does that look like on your team week to week?" Why it lands: it shows you read his public work, and it hands him his own argument. Source is a search listing; check the talk before the interview.
2. "Project Larkspur moves two titles to one shared calendar and one live-ops group. What has the first stretch taught the team?" Why it lands: it shows you read the company's news. Check the item first; I saw it only in a search listing.
3. "Who owns the post-event review today, and which KPIs does it report?" Why it lands: it answers the JD's F3 line from the source, and tells you what owning it means here.
4. "How does QA sign-off work with the live-ops team now?" Why it lands: it ties to the checklist and tests whether the release process is written down.
5. "What would make the first 90 days in this role a clear success?" Why it lands: it turns the gap questions into an agreed scorecard, which is what a hiring manager is trying to get from you.

## Sources

**Provided documents:** your JD and your message (both pasted).

**Searches and fetches sent:**

| Query | Result |
|---|---|
| "Saltmarsh Games values" | saltmarshgames.com/values, fetched |
| "Saltmarsh Games interview process live operations producer" | saltmarshgames.com/careers/interviewing, fetched |
| "Tobias Wrenfield Saltmarsh Games" | talks.gdconf.example listing for "Patch Notes Are a Promise" (GDC 2026), search snippet only, not opened |
| "Saltmarsh Games news 2026 live events mobile titles" | saltmarshgames.com/news/project-larkspur, search snippet only, not opened |

**Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values cheat sheet: three names, read from the official page |
| 2. Saltmarsh interview process | yes | Loop: one 60-minute Outage Hour, hiring manager, no take-home; persona weights and A1 to A3 |
| 3. Saltmarsh strategy / recent news | yes | Found the Larkspur item (snippet only); moved A4 and reverse question 2 |
| 4. Tobias Wrenfield + company | yes | Interviewer read and reverse question 1; both from a search listing, not opened |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions |

Facts from listings I could not open are marked as such. Verify them before relying on them.

## Upgrade menu

- **A deeper research pass (L2):** a company strategy brief, Tobias's other talks and posts, loop reports, recent org context. Adds a fuller CO bank and sharper reverse questions. Costs up to 6 more searches and 2 more page fetches, several minutes. Say the word and I'll run it.
- **A live incident or release day you were in, in your own words:** moves A3 and C2 from selection scaffolds to story-mapped answers.
- **Planning you did across more than one title, or a live event (not a drop):** moves F1 and B2 toward presentation, and gives A4 a story.
- **Any coordination with design, art, engineering or community on an update:** moves F2 from discovery to a quoted row, and strengthens B3.
- **A written piece others relied on (a patch note, a post-event write-up):** moves F8 from discovery to grounded, and gives A5 a sample to build on.
- **The numbers behind your retention figures, and how they were counted:** gives D1 and E2 an answer you can repeat under a second question.
