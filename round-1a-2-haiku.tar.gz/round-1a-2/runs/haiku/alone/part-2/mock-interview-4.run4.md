Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-4-denied-e69c04de/28d0a1b6-49d2-42db-a5a9-0dcdae88beb8/scratchpad/quartzline_platform-apis-pm_interview_pack.md. It is built on your dossier alone, since web search was refused, so the company's values, interview format and strategy are not in it. Your dossier is also about three months old, so check the requirement lines against the current posting.

The highest-return prep is A1, the objection the underwriter named: "You have never held the PM title or owned a roadmap." Rehearse the plain words first ("I haven't held a product manager title, and I haven't owned a product roadmap"), then the integration work, and hold through two follow-ups before conceding.

Say the word and I'll play the Skeptic on A1. I can also add a `pack_feedback` section to tuesday-dossier.md recording what this prep exposes, for you to carry forward. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_platform-apis-pm_interview_pack.md -----
# Product Manager, Platform APIs at Quartzline: interview prep

Round: hiring-manager conversation, 45 minutes, Thursday. Interviewer name not given.
Changelog: first pack. Built from the underwriting dossier you pasted (dossier 1.1, generated 2026-08-14). No CV text or posting text was supplied beyond what the dossier carries.
Age check: the dossier is about three months old. If the posting or the team has changed since August, the requirement lines below may be out of date.
Decision carried in: conditional_go. The two conditions are kept throughout: the bridge is positioned as adjacent, never as PM experience, and the squad-authority question is verified in the interview.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

- **EXP**: what you actually did in your own past work.
- **JD**: the role's stated responsibilities and requirements, gaps included.
- **CASE**: a live problem from the role, structured aloud.
- VAL (values) and CO (company strategy) do not appear in this pack. Neither has a source in hand: no values-style round was detected, and company research did not run.

Guidance is scaffolding, not a script. Say it in your own words. An answer slot is an instruction for the interview: answer the branch that is true for you, and say so plainly if the other one is.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | low | [grounded] | transferability | The dossier grades this requirement low, and V1 is high-confidence at its own scope. Say the title gap first, in plain words: "I haven't held a product manager title." Then the quote at its scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Your material shows integration work for clients. It does not show product management. |
| F2 | "Owning a roadmap and prioritization authority (R1 sub-claim)" (dossier W2) | none given | none | [grounded] | capability | The dossier records this absence, so the words come from it: "I haven't owned a product roadmap." Then one thing you would do to learn roadmap ownership, said as a plan and never as past. The nearest material is in F5, and it is input to a roadmap, not ownership of one. |
| F3 | "Shipped API or platform products" (dossier R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier V1 | high | [grounded] | transferability | Integration work on a vendor's APIs is adjacent to shipping a platform product. The dossier does not flag this row, so the transferability call is this pack's reading of V1, and the underwriter may disagree. Words: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Your material shows integrations built for clients, not a product you shipped. |
| F4 | "Technical fluency: API docs, schemas" (dossier R3, important) | "Wrote the internal integration playbook her team uses" — dossier V2 | low | [grounded] | discovery | The playbook touches the documentation side. The material does not show schemas. Words: "I wrote the internal integration playbook." Answer slot: if you have worked with an API reference or a schema, name which one and your part in it. If you have not, say so plainly, and say what you would learn first. |
| F5 | "Stakeholder management across engineering, sales, customers" (dossier R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier V3 | medium | [grounded] | transferability | Confirmed, with limited inspectable proof, so expect a probe. Words: "I ran quarterly roadmap-input sessions feeding client evidence to product." Your material shows client and product contact. It does not show managing engineering or sales. |
| F6 | "Agile delivery experience" (dossier R5, preferred; dossier W3) | none given | low | [grounded] | discovery | No verified entry speaks to agile delivery in those words, so the clarify strategy gives an answer slot. If you have delivered work in sprints or from a backlog, say how and what your part was. If you have not worked that way, say so plainly, and say what you would want to confirm about how these squads work. |
| F7 | "Define and track adoption metrics" (dossier role_profile responsibilities; dossier unknowns) | none given | none | [grounded] | discovery | Silence, not a recorded absence: the material does not show whether you have measured adoption. Answer slot: if you have counted adoption of anything, say what you counted and how. If you have not, say so, and say how you would define adoption before you measured it. |

Gap type follows the routing rule in the output template: transferability where a quote carries adjacent work, discovery where the material is silent, capability only where the dossier records the absence.

## Persona table

Relationship prior: hiring manager. The loop is not established by any loop source, and no archetype is named, so these weights rest on the round-type prior alone. The pack says so rather than assuming a company process.

| Persona | How it shows up in this round | Likelihood, with reasoning | Weight | Counter-strategy |
|---|---|---|---|---|
| Skeptic | The title and roadmap objection; "why this role, now" | High. The hiring-manager prior is buying capability and derisking gaps. The dossier names the objection, and R1 is a must-have gap | 5 | Plain words first, then the sourced limit, then the ramp as a plan. Hold two follow-ups, concede on the third |
| Case / Strategist | Live roadmap problems: squads disagreeing, flat adoption, writing the first spec | High. The JD's own verbs are the cases | 4 | Clarify, then objective, options, criteria, and who decides |
| Data-Driven Prober | Adoption measurement, the 30+ count | Medium. Adoption metrics are in the JD and the baseline is unknown; the 30+ is a figure you gave | 3 | Name the weakest assumption before it is named for you. Say plainly what you do not know |
| Pressure | "How much of that was actually you?" | Medium. A high-confidence figure invites the question | 3 | Pause, restate, hold through two follow-ups |
| Conversational | Opener and biography | Medium. A generic prior for hiring-manager rounds, with no interviewer profile to adjust it | 2 | Ninety-second arc; treat casual questions about the JD's topics as scored |
| Peer Evaluator | The seam with the two squads; credit across teams | Low to medium. The squads are the seam, but a hiring manager is not usually a peer | 2 | Reciprocity framing; state seam principles rather than pretending to know the seam |
| Values / Behavioral | Not included | No values round is detected: no loop source, no archetype fallback, and no values page in hand | 0 | None |

## Question banks

Depth follows weight: Skeptic 5, Case 4, Prober 3, Pressure 3, Conversational 2, Peer 2. Nineteen questions in total.

### Bank A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] "Having held a product manager title or role" (dossier P1, prohibited_claims); "Owning a roadmap and prioritization authority (R1 sub-claim)" (dossier W2, acknowledge_gap) | Open with the plain words, in order: "I haven't held a product manager title, and I haven't owned a product roadmap." Then the quote at its scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live." The reason you fit is the integration work, not a title. Then the ramp, as a plan: the two or three things you would learn first, in your own words. Hold through two follow-ups by returning to the integrations. On a third, concede the roadmap gap outright. Never fold on the integration work. Answer slot: if any stage of those integrations was yours to decide, say which and how you decided. If none was, or it was not yours, say so plainly. | The underwriter named this as the most likely objection (dossier OBJ1). It targets R1, the must-have, so it is the highest-return prep in this pack. Rehearse it until the plain words come without effort. Deepest rehearsal: three follow-up levels. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Having owned a product roadmap" (dossier P2, prohibited_claims) | Name the roadmap part in the plain words: "I haven't owned a product roadmap." Then one thing you would do to learn it, said as a plan, never as past. One honest weak spot is enough. | Open prompt. Its theme is the raising line "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities). |
| A3 | "What does agile delivery look like to you on a product team?" | JD | [grounded] | Answer slot: if you have delivered work in sprints or from a product backlog, say how and what your part was, in your own words. If you have not worked that way, say so plainly, and say what you would want to confirm about how these squads work. | No verified entry speaks to agile delivery word for word, so the clarify strategy allows only the slot (dossier W3). The question carries no claim about your past. |
| A4 | "Describe the first decision you would want to make alone in this role." | JD | [generic] | Pick one roadmap decision for the partner-facing API platform, and say what evidence you would need before making it. Say it as a plan. Do not claim decision rights you do not yet hold. If the squads' decision rights are unclear, say that you would ask first. | Raising line: "Own the roadmap for the partner-facing API platform." The question puts the decision-authority risk on the table (dossier RISK1). |
| A5 | "Why this role, now, when the roadmap part is new to you?" | JD | [grounded] "Owning a roadmap and prioritization authority (R1 sub-claim)" (dossier W2, acknowledge_gap) | Answer slot: say in your own words what draws you to the roadmap part. If the pull comes from the integration work, say which part of it. If nothing yet pulls you there, say so, and say what you would want to test first. | The Skeptic's "why now" stem. It ties the motivation answer to the title gap, so the two answers agree. |

### Bank B: Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two squad leads want different things from the partner API next quarter. How do you decide, and who decides?" | CASE | [generic] | Structure it aloud: clarify what each squad is asking and why; the partner outcome the roadmap serves; the options; the criteria you would use; who holds the final call, and what you would escalate. Name the decision-rights question as one you would confirm first. Do not assert who holds the call. The interviewer's answer is what the reverse question RQ1 gets you. | A live problem with no past claim, so it needs no quote. It tests the decision-authority risk (dossier RISK1). Raising line: "Write specs and drive delivery with two engineering squads." |
| B2 | "A partner integration slipped two weeks and adoption is flat. Where do you start?" | CASE | [generic] | Clarify first: what adoption means here and how it is counted, because you cannot diagnose a number you have not defined. Then segment the flat adoption: by partner type, and by where partners stop in the integration. Separate a delivery slip from lower demand. Name the metric you would check first, and the assumption behind it. | Raising line: "Define and track adoption metrics." The baseline is not stated (dossier RISK2), so the structure starts with the definition. |
| B3 | "How would you run discovery with integration partners in your first month?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Plan, not past: name the partner segments you would talk to first, the two or three questions you would take into each conversation, and what would change your priorities. The bridge is the scoping and requirements method you have used with clients, at the scope of those integrations. | Raising line: "Run discovery with integration partners." The first-month plan is a plan, so it asserts no past. V1 appears only as the bridge's scope. |
| B4 | "If you wrote the first spec for the partner API roadmap, what would it contain?" | CASE | [generic] | Outline it aloud: the problem and who it is for; the partner outcome it is meant to move; the scope you would defend and what you would cut; the dependencies on the two squads; the adoption measure and its baseline. If the baseline is unknown, say so. | Raising line: "Write specs and drive delivery with two engineering squads." The spec is the JD's own verb. |

### Bank C: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you know partner API adoption is working? What's the baseline today?" | JD | [grounded] | Name the adoption measure you would use and why it fits, then the assumption you would defend least. On the baseline: if you do not know it, say so, and say you would establish it first. Do not quote a current number. Answer slot: if you have counted the adoption of anything, say what you counted, how, and the assumption you would defend least. If you have not, say so plainly. | Raising line: "Define and track adoption metrics." The baseline is unstated (dossier RISK2). This is the question that tests whether you measure before you promise. |
| C2 | "Walk me through one roadmap-input session. What did product do with what you brought?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | Answer slot: say what you saw product do with the evidence. If you did not see it, say so plainly. Name the limit before it is asked: this is the part of your material with the least inspectable proof, so say what you can show and what you cannot. | V3 is medium confidence, and a prober will find the seam. Volunteering the limit is the rule the underwriter's handoff sets (dossier rule 1). |
| C3 | "How did you count the 30+ integrations, and which of them were yours to lead?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Defend the number in your own words: how you counted, what you would exclude, and the assumption behind the count you would defend least. Then which part was yours: name the stages you led from scoping, requirements, architecture, UAT and go-live. Answer slot: if some integrations were supported rather than led, say so. If you did not keep a count, say that. | A figure you gave raises the defend-the-number slots. V1 is high confidence, and its playbook is the inspectable artifact. |

### Bank D: Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Thirty integrations. How much of that was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Pause. Restate the question in your own words. Answer from the quote: "I led 30+ end-to-end client integrations of the vendor's REST APIs," and name the stages you led. Hold through two follow-ups. On a third, concede specifically where your part was support rather than lead. Never fold the whole claim. Answer slot: name which of the five stages were yours to lead and which you supported. If you led the whole sequence, say so and say what you would defend. | Pressure stem. The held position is one V1 carries. The figure raises the slots in C3, so the honest answer is given per stage. |
| D2 | "Sixty seconds: what would you do in your first thirty days that a PM with three years would not?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Speak as a plan. Start from the stages you led with clients, requirements and UAT, and say what you would take into the roadmap work. Then one thing you would not claim to do yet. | Time-boxed. The answer is a plan with a past scope behind it, not a claim that you are the PM-equivalent. |
| D3 | "Your integrations were built around a vendor's APIs. Ours are partner-facing. Why would that transfer?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Hold the position V1 carries: the scoping and requirements for those integrations were yours to lead, at the scope stated. Concede where it stops. Answer slot: if you have worked on the platform side of a partner-facing product, say what, and what your part was. If you have not, say so plainly. | Raising line: "Own the roadmap for the partner-facing API platform." This is also the coverage for R2, shipped API or platform products. |

### Bank E: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1); "Wrote the internal integration playbook her team uses" (dossier V2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier V3) | A ninety-second arc, in this order: the client integrations you led, the playbook you wrote from them, and the roadmap input you carried to product. Close on the roadmap part as what you want to grow into, in your own words. State the title gap in the plain words, so it is not the interviewer's first reveal. | Casual openers are scored. This one sets up the title question before it is asked. |
| E2 | "What are you actually doing with API docs these days?" | JD | [grounded] "Wrote the internal integration playbook her team uses" (dossier V2) | Name the playbook at its scope: the internal integration playbook your team uses. Answer slot: if you have worked with API reference docs or schemas, name which and your part. If you have not, say so, and say what you would learn first. | R3 is important, and it is asked casually here. F4 is discovery, so the schema part stays a slot. |

### Bank F: Peer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Where's the seam between your work and the engineering squads — what happens when you disagree?" | JD | [grounded] | Answer slot: if you have disagreed with an engineering lead about scope or timing, say what it was and how it resolved, in your own words. If you have not, say so, and state the principle you would use. | Raising line: "Write specs and drive delivery with two engineering squads." Disagreement is where the stakeholder claim in F5 gets tested. |
| F2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier V1) | Name the stages you led, and which were shared. Say "we" for the team's outcome and "I" for what you led. Do not claim credit for stages that were not yours. | Peer register. The stage list in V1 is the only scope you can name. |

### Requirement coverage

| Requirement | Questions |
|---|---|
| R1: 3+ years product management experience | A1, A2, A5, D2 |
| R1 sub-claim: owning a roadmap and prioritization authority | A2, A5, B1 |
| R2: shipped API or platform products | D3, B3 |
| R3: technical fluency, API docs and schemas | E2 |
| R4: stakeholder management across engineering, sales, customers | F1, F2. Sales: none, because your material shows no sales work and no question here invents it |
| R5: agile delivery experience | A3 |
| Responsibility: own the roadmap for the partner-facing API platform | A4, D3, B1 |
| Responsibility: run discovery with integration partners | B3 |
| Responsibility: write specs and drive delivery with two engineering squads | B1, B4, F1 |
| Responsibility: define and track adoption metrics | B2, C1 |
| Current company strategy (CO) | none, and why: research did not run, so no current strategy is in hand |
| Values (VAL) | none, and why: no values-style round was detected and no values page is in hand |

## Reverse questions

No interviewer profile exists, so no reverse question ties to the interviewer's own career path. Add a name to get one (upgrade menu). This is not a peer conversation, so no reciprocity question is required.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" | This is the decision-authority risk the dossier could not verify (RISK1). You need the answer before you accept. |
| RQ2 | "How is partner API adoption measured today, and what is the current baseline?" | It names the baseline gap (RISK2). It also shows you measure before you promise. |
| RQ3 | "How do discovery and spec-writing split between this role and the two squads?" | It tests the seam that B1 and F1 rehearse, and it turns the responsibilities into a division of labour. |
| RQ4 | "What does agile delivery look like on these squads, in sprint and backlog terms?" | R5 is a requirement you have not shown. Learning the team's model is the honest move, and it reads as diligence. |
| RQ5 | "What would a strong first ninety days look like to you?" | It gets the hiring manager's bar in their own words, so your plan can be aimed at it. |
| RQ6 | "If someone has held this role before, what was left undone when they moved on?" | It surfaces the inherited backlog, which tells you what the roadmap is really for. |

## Prohibited claims

What this pack will not coach, with the basis for each entry and its honest form. The dossier's prohibited_claims bind every cell above.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims (P1), listed by field | "I haven't held a product manager title." A plain acknowledgment sourced to P1. No slot. |
| Having owned a product roadmap | Dossier prohibited_claims (P2) and acknowledge_gap (W2), listed by field | "I haven't owned a product roadmap." A plain acknowledgment sourced to P2 and W2. |
| Having set prioritization for an engineering squad | Dossier prohibited_claims (P3), listed by field | "I haven't set prioritization for an engineering squad." A plain acknowledgment sourced to P3. |
| Shipped API or platform products | Inflated form of F3 (V1), built locally: "shipped" widens "led integrations" | V1 at its own scope: "Led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is this pack's observation, in its analysis: the material says integrations you led, not a product you shipped. No first-person negative. |
| Owned the roadmap for client integrations | Inflated form of F5 (V3), built locally: "roadmap-input sessions" widens to "owned the roadmap" | V3 at its own scope: "Ran quarterly roadmap-input sessions feeding client evidence to product." The limit is this pack's observation: input to product, not ownership of its roadmap. No first-person negative. |

## Sources

**Provided documents.** `tuesday-dossier.md`, dossier version 1.1, generated 2026-08-14. Consumed sections:

- `role_profile`: satisfied the JD tier. Requirements R1 to R5 and the four responsibilities are the supplied JD lines. Its unknowns (decision authority; how adoption is measured today) feed RISK1 and RISK2.
- `verified_candidate_evidence`: satisfied the CV tier. Entries are cited as V1 (the 30+ integrations, high confidence), V2 (the integration playbook, high confidence) and V3 (roadmap-input sessions, medium confidence).
- `handoff_to_mock_interview`: uncertain_or_weak_areas W1 to W3; likely_interviewer_objections OBJ1; prohibited_claims P1 to P3; opportunity_risks_to_validate RISK1 and RISK2; questions_for_employer EMP1 and EMP2 (carried into RQ1 and RQ2).
- `decision`: context only.
- Not present in the dossier: `evidence_map` and `evidence_state`. The fit grading therefore comes from the handoff entries, and no rejected inferences are on record.

**Searches and fetches.** Three searches were sent. Each was refused, because permission to use the search tool had not been granted, and none returned a result. No fetches were sent.

- "Quartzline values": refused
- "Quartzline interview process product manager platform APIs": refused
- "Quartzline strategy recent news": refused

**Research tier: L1, searches 0 of 6 (3 sent, all refused), fetches 0 of 2.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Whether a values-style round exists, and the values cheat sheet. Without it, no values section and no VAL bank |
| 2. `Quartzline interview process {role family}` | unavailable | Loop structure and persona weights. Without it, the weights rest on the hiring-manager prior alone |
| 3. `Quartzline strategy` / recent news | unavailable | CO questions. Without it, the pack has no strategy-grounded question |
| 4. `{interviewer name} Quartzline` | n/a | No name was given, so there was no query to form. The interviewer read and a tied reverse question are absent |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile supplies the JD, which fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Permission to search, or the company's values page pasted → the values section and VAL questions, if a values round is detected; the loop structure, which sharpens the persona weights.
- The posting's current text → confirms the requirement lines in the fit snapshot, which come from an August dossier.
- Your CV → the dossier's verified claims get story-mapped in your own sentences, rather than the underwriter's, so the quotes in F1 to F5 become your lines.
- The interviewer's name → an interviewer read, persona weights from their public footprint, and a reverse question tied to their career path.
- What the recruiter says about the squad leads' decision rights → sharpens A4, B1 and RQ1 with the employer's own answer.
- A deeper research pass, once search is permitted: up to 6 more searches and 2 more fetches, several more minutes, for the strategy brief that would add CO questions. Want it?
