Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-3-denied-c07e24df/5daa5381-1c97-4be4-b65f-3db5a2e8033d/scratchpad/stripe_product-operations-manager_interview_pack.md`.

I built it without your CV, a job posting, or the round details, and web search was refused in this session, so the questions are generic and the requirements are role-family patterns rather than Stripe's. Persona weights are flat because I don't know who you're meeting. The upgrade menu at the end of the file lists what each input would unlock.

Say the word and I'll play the Skeptic on E1, "Which part of this role would you be weakest at on day one?" It's the question the pack names as the highest-ROI prep, since a version of it is likely to come up.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Who are you meeting in this round (your future manager, a peer, or someone more senior), and did the recruiter name any focus areas or a take-home?

Could you paste the job posting and, if you're willing, a CV or a few lines on your recent work? The pack will then quote your own words instead of generic patterns. I can also keep going without them.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: stripe_product-operations-manager_interview_pack.md -----
# Stripe, Product Operations Manager: final round prep pack

Interviewer: not given. Relationship: not given, so persona weights are flat.
Built without a CV, a job posting, round details or web research. Every requirement below is a role-family pattern, and every question is generic. Treat this as a first pass to be replaced once you send the inputs in the upgrade menu.

Not in this pack, because the inputs that build them are missing: prep triage, values cheat sheet, grounding brief, reading the interviewer, graded deliverables, delivery coaching.

## How to use

Personas describe how a question arrives. Types describe what it is scoring.

| Type | Name | Meaning |
|---|---|---|
| EXP | Work-experience deep-dive | Tests what you actually did, and how you would say so |
| JD | Role / JD-driven | Tests the requirements of the job, including the gaps |
| CO | Company and strategy | Tests homework depth. Generic here, because no research ran |
| CASE | Live problem | Tests structure and reasoning on a problem from the role |
| VAL | Values | Not used. No values round was established |

Guidance is scaffolding, not a script. Where guidance says "if you have not done this, say so," that branch is the honest answer, and it is as valid as the other.

## 1. Fit snapshot

No CV, no posting, and no recruiter or interviewer words were given. So this is the worksheet variant: every evidence cell reads "none given," confidence is none, and the gap type is discovery. The requirements are role-family patterns, written as plain prose and labeled [generic]. None is quoted, and none is a gate, since nothing you have said or been sent names an eligibility, location or schedule term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Runs a recurring operating cadence, such as planning or business reviews, across several functions. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence: a cadence you ran or reliably took part in, its inputs, the decision it fed, and who attended. Selection scaffold: pick a recurring review you ran or took part in, and say what it decided. If none, say so and say how you would set one up |
| F2 | Designs and runs launch and readiness processes. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence: a launch or change you prepared for, with the checklist, the owner for each item, and what was held back. Selection scaffold: pick a launch or change you prepared for, and say what you checked before it went out. If you have not prepared one, say so and name the first checklist item you would write |
| F3 | Defines, instruments and reports operational metrics. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence: a metric you defined, what it counted, how often it was reported and who read it. Selection scaffold: pick a metric you reported, and say what it counted. If you have not reported one, say so and say what you would measure first |
| F4 | Influences teams that you do not manage. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence: a decision you moved across teams without authority, with who had to agree and what changed. Selection scaffold: pick a case where you got a team to change its plan without managing it. If none, say so and say how you would approach it |
| F5 | Manages a request queue and makes prioritization trade-offs visible. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence: an intake or queue you ran, the rule you used to decide what waited, and how requesters learned the result. Selection scaffold: pick a queue or backlog you triaged, and say what rule decided the order. If none, say so and describe the rule you would start with |
| F6 | Chooses, maintains and documents internal tools and playbooks. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence: a tool or playbook you built or maintained, what it replaced, and who uses it. Selection scaffold: pick a tool or document your team relied on, and say what you changed in it. If none, say so and name the document you would write first |
| F7 | Analyzes data, in SQL or spreadsheets, to answer operational questions. Role-family pattern, no posting | none given | none | [generic] | discovery | Strong evidence: a question you answered from data, the tool you used and the answer it gave. Selection scaffold: pick an operational question you answered with data, and say which tool. If you have not done this, say so and say how you would learn the tool you would need |

## 2. Prohibited claims

Entries are built from sentences you have said. You have not yet sent a CV or a message describing your experience, so there is nothing to stretch, and no inflated-form entries exist. This pack has coached no claim about your past. The list will be built when you send that material.

| Not coached | Basis | Honest form |
|---|---|---|
| none yet | No candidate sentences given | Not applicable until your material arrives |

## 3. Persona table

No relationship or round is known, so no persona leads. Each persona gets three questions, which is a flat weighting. A flat pack is noticeably weaker than a weighted one: you will meet every style, but you will not know which one to rehearse hardest until you say who is interviewing.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Follows a number down to its assumptions | Equal, 3 questions. No relationship known | Name the assumption you would defend least, before it is asked |
| Pressure / Stress | Time-boxes answers and challenges your position | Equal, 3 questions. No relationship known | Pause, restate the question, hold through two follow-ups before any concession |
| Values / Behavioral | Scenario probes for past behavior, often as STAR-shaped stories | Equal, 3 questions. No values round established | Use "we" for context and "I" for your own part. Say plainly when you have no such case |
| Case / Strategist | Live problems from the role | Equal, 3 questions. No relationship known | Clarify, then structure, then answer. Think aloud and name one premise to challenge |
| Skeptic | Probes gaps and motivation | Equal, 3 questions. No relationship known | Rehearse the likeliest objection until it is routine. Name gaps plainly and give a ramp |
| Conversational / Rapport | Casual openers that are still scored | Equal, 3 questions. No relationship known | Prepare a 90-second arc and treat casual questions about the role as scored |
| Peer Evaluator | Seam and credit questions from a colleague's side | Equal, 3 questions. No relationship known | Give principles for the seam, and what you bring to their team as well as what you need |

## 4. Question banks

Provenance is [generic] on every row. No row makes a claim about your history, so no row quotes you. Where a question asks for a past example, the guidance asks you to choose a real one, or to say plainly that you have none.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "When have you put a number in front of a leader? How was it counted?" | EXP | [generic] | Open prompt, so choose a real instance. Say the metric, what it counted, what it was sensitive to, and the assumption you would defend least. Say which part of the count was yours. If you have never reported a number to a leader, say so, then describe the nearest operating measure you did track, or how you would define one. Do not reconstruct a figure you cannot recall | F3 and F7 are both unevidenced, so this is where a prober starts. The question asks you to choose an instance and supplies none |
| A2 | "How would you know a process change you made had actually worked?" | CASE | [generic] | Name the outcome you would watch, the baseline you would compare against, and one thing that could make the result look better than it is. Name the weakest assumption before the interviewer does. If you have run such a check, say how. If not, say so and describe the check you would set up first | F3 lands here: can you separate a change from its noise. CASE, because the question is about reasoning on a change, not a past event |
| A3 | "Suppose a weekly metric moves sharply in one week. What do you check before you tell anyone?" | JD | [generic] | Walk the checks in order: whether the data changed, whether the definition changed, whether a launch or an outage explains it, whether the pattern is seasonal. Say what you would report, and to whom, before you have a cause. Give the order you would follow; do not claim a past case unless you have one | F3 and F7 are the requirements this tests. The answer is method, which needs no past event to be credible |

### B. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why should we hire you over someone who has run this function for years?" | JD | [generic] | Hold. Do not apologize or argue the comparison. Name the one thing you would bring that you can show, then the one area where the other person is stronger, in your own words. Concede the specific gap, not the whole case. If the second follow-up presses the same point, return to the one thing you can show | Tests composure under a time box. The hold comes first, and the first concession is named and specific |
| B2 | "Tell me about a result you are proud of. How much of it was actually you?" | EXP | [generic] | Open prompt: choose a real result. Split it into what you did, what others did, and what happened anyway. Name your share without rounding it up. If you have no result you are proud of, say so and pick the one you learned most from. Hold the split through two follow-ups, and concede only the part you cannot defend | An attribution probe. The honest answer is the split, and the rehearsal is holding it under pressure |
| B3 | "Your 90-day plan sounds generic. What would you actually do on day one?" | CASE | [generic] | Name the first question you would ask and whom you would ask it of. Then name the first thing you would stop checking, not a list of things you would do. Hold the first answer through two follow-ups. A plan you cannot yet defend should be a sequence of questions, not a list of conclusions | Pressure on specificity, asked at the moment a plan feels most like a script. Bears on F2 and F5 without claiming experience |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Open prompt: choose one decision you disagreed with that reached leadership. Say what you said, to whom and when, and what happened next, including what it cost you. Use "we" for context and "I" for what you did. If you have never raised an unpopular point with leadership, say so, then describe the closest disagreement you did raise | A behavioral stem. The answer must show a hard point landing. No company value is established, so this tests general behavior |
| C2 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] | Open prompt: choose a case where a customer need and an internal target pulled apart. Name the metric, the customer, the choice you made and what it cost. If you have not faced that choice, say so, then describe how you would weigh it | Tests judgment about trade-offs. Bears on F4 |
| C3 | "Tell me about a process you built that did not work." | EXP | [generic] | Open prompt: choose a process that failed and that you had a hand in. Say what failed, the part that was yours, and what you changed afterwards. Do not blame the people who used it. If none of your processes failed, say so, then describe the nearest failure you saw and what you did about it | Tests honest self-assessment. The failure needs a named cause and your share in it. Its follow-ups overlap with E1 |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A launch review shows the same milestone has slipped three weeks running. Walk me through what you do." | CASE | [generic] | Clarify first: which milestone, which team owns the slip, what changed. Then structure: cause (scope, dependency, capacity), who needs to know and when, and the decision you would ask leadership to make. Say the assumption you are testing. Think aloud, and name one premise you would challenge | Tests clarifying before structuring. The scenario is generic and carries no company detail. Bears on F1 and F2 |
| D2 | "Teams send you requests for a shared resource faster than you can triage them. How do you design the intake?" | CASE | [generic] | Clarify the volume, the resource and who decides. Then propose a triage rule, what you would stop accepting, and how you would make trade-offs visible to requesters. Say what you would measure to know it works, and name one thing you would not automate | Tests prioritization design, which is F5 and part of F1. The answer is a method, so it needs no past claim |
| D3 | "What would you want to understand about a company's current priorities before you designed its operating cadence?" | CO | [generic] | Name three questions: what the company is trying to change this year, which teams carry the most cross-functional load, and where decisions currently stall. Say how you would test the answers in your first two weeks. Read the company's own published priorities before the interview. Until research runs, this question stays generic | A CO question without company research is generic by design, and it is labeled so. It asks for a method of learning the company, not facts about it |

### E. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Highest-ROI prep in this pack, because a version of it will be asked. Name the one requirement you could least show on day one, and why, in your own words. Then the ramp: who you would ask, what you would read, and the first thing you would deliver. Say plainly what you have not done. Rehearse three follow-ups: why that gap matters, what you would do first, and how you would know you had closed it. Do not claim a gap is closed; describe how it would close | No material you have given shows which requirement is thinnest, so the pack cannot name one. The deepest rehearsal is your own gap and your own ramp. A skeptic asks this in some form, because it is what a requirement with no evidence behind it invites |
| E2 | "Why this role, and why now?" | EXP | [generic] | Give one reason in your own words, tied to the work the role does rather than to the company's mission. Then say why the timing fits your own plans. Keep it to 60 seconds. If the reason depends on the company name, rewrite it until it depends only on the work | Tests motivation consistency. No history is cited, so the answer rests on your own reasons, and the guidance supplies none |
| E3 | "If I looked at your background, what would I say is missing for this role?" | JD | [generic] | Name the gap you would expect an interviewer to find, and the requirement it sits under. Do not argue it away. Then say what you would do about it in the first month. If you cannot name one, say so, and name the requirement you would most want evidence for | A probe built as an invitation to self-assess. Calibrated candor beats bluffing. Shares E1's deepest follow-ups |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | Build a 90-second arc from three parts: what you did in your last role, what changed because of it, and why this role is the next step. Use only things you can state in your own words. If one part is thin, keep it short rather than padding it. Say it aloud twice before any interview | A casual opener is still scored. The arc gives it structure without a story you have not told yet |
| F2 | "What tools are you using day to day right now?" | JD | [generic] | Name the tools you have used in the last year, and one thing you did with each. Do not list tools you have only read about. If a tool the role uses is new to you, say so, and say how you learn a tool | Tests F6 casually. The honest short list beats the long one |
| F3 | "What is a product you use that you think is well run?" | CO | [generic] | Pick one you use yourself. Name the one operating choice you would want to learn from, and why. Keep it to a feature or process, not a brand | A casual CO question. It shows whether you look at how things are operated, not only at what they do. Generic: no company research |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | EXP | [generic] | Propose principles for the seam, such as who decides what, and how disagreements escalate, rather than facts about a team you do not know well. Then give one real disagreement with a peer and how it resolved. If you have none, say so and describe how you would handle one | Tests F4 in a peer register: influence across teams without authority. The answer is principles plus an honest example |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Say how you name contributors in a launch or review. Give one case where credit went to the wrong place and what you did about it. If you have not had that case, say so and state the rule you use | Credit-sharing is a peer's test of turf. A real case beats a rule, and the rule is the fallback |
| G3 | "What would you need from my team to do this job well?" | JD | [generic] | Name the specifics: decision rights, data access, a standing meeting, a named owner for each process. Then say what you would bring to their team in return. Ask one question back, not a list | Turns a peer's question into a reciprocity conversation. Tests whether your needs are specific and whether you give back |

## 5. Requirement coverage

| Requirement | Questions | Note |
|---|---|---|
| F1 Operating cadence | D1, D2 | |
| F2 Launch and readiness | B3, D1 | |
| F3 Metrics and dashboards | A1, A2, A3 | |
| F4 Influence across teams | C2, G1, G2, G3 | |
| F5 Prioritization and intake | D2, E3 | |
| F6 Tooling and documentation | F2 | |
| F7 Analysis from data | A1, A3 | |

Every requirement has at least one question. The requirements are role-family patterns, not a posting, so this table will need to be checked against the posting once you send it.

## 6. Reverse questions

No interviewer profile exists, so none of these is tied to one. A reciprocity question is left out until you know the interviewer is a peer.

1. "What does a strong first quarter look like for someone in this role?" Why it lands: it shows you plan around outcomes, not a title.
2. "Which operating process is working least well for this team right now?" Why it lands: it invites candor and shows you will look for problems, not only successes.
3. "How does this team find out about a launch or change that affects it, and where does that break down?" Why it lands: it asks about the seam that product operations exists to close.
4. "What would make you say in six months that hiring for this role was the right call?" Why it lands: it draws out the bar they will score you against.
5. "How do you decide when two teams' priorities conflict, and who makes that call?" Why it lands: it surfaces decision rights, the central tension in this kind of role.
6. "How does this team measure whether its own operating work is paying off?" Why it lands: it signals that you think about measuring operations.

## 7. Sources

Provided documents: the request only. "Stripe, Product Operations Manager, final round." No CV, posting, recruiter note or interviewer name was provided.

Searches sent: three, each refused because web search was not permitted in this session.
- "Stripe company values principles": refused
- "Stripe interview process product operations manager final round": refused
- "Stripe product operations manager job description": refused

Research tier: L1, searches 3 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Every call refused. Values cheat sheet not built. No values round was established |
| 2. Stripe interview process, product operations | unavailable | Every call refused. Loop structure not established, so persona weights are flat |
| 3. Stripe strategy and recent news | unavailable | No call sent, because search was not permitted. Would have moved the CO bank, which is generic (D3, F3) |
| 4. Interviewer name and Stripe | n/a | No name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | The one call was refused. Would have moved the fit snapshot requirements and the JD-tagged questions, which are role-family patterns |

## 8. Upgrade menu

- Your CV, or a few lines on your recent work → the fit snapshot rows F1 to F7 get quoted evidence in place of "none given," and the selection scaffolds become story maps in your own words
- The job posting → requirements become quoted and grounded, the JD-tagged questions are retuned to its wording, and any gate it names gets its own row
- Who you are meeting and the round type → persona weights, the reverse questions, and the emphasis of each bank are recomputed
- Any focus areas or take-home the recruiter named → a build section for each deliverable
- Permission for web search in this session → the values cheat sheet, the interview-process structure and current company strategy, which would replace the generic CO questions with company-specific ones. A rerun takes up to six searches and two page fetches
- A deeper research pass, offered once: up to six more searches and two more page fetches, several more minutes. It adds the company strategy brief, the interviewer's public talks and writing if you name one, and recent org context. It needs search permission first
- The interviewer's name → a tailored reverse question, and persona weights read from their public professional footprint, if search is allowed
- A tuesday-dossier.md would add verified evidence in place of the generic rows, and a list of claims this pack must not coach
