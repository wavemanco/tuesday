Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-8-canned-04050606/88b18f81-c1b0-43f2-91c2-903e5cb7ce22/scratchpad/ashgrove_member_experience_lead_interview_pack.md. It is built for all three rounds on 28 November, with one shared fit snapshot and a mini-pack per round.

I didn't search anything. The values, the recruiter's process and the strategy points you gave were enough to ground it, so nothing in it comes from my memory of Ashgrove. The strategy section relies on the four points you summarised, not the full brief.

The pack's highest-ROI prep is R2-B1, the "never worked in a contact centre" question from your manager. Say the word and I'll play that Skeptic and push back on your answer.

I can also save a tuesday-dossier.md that records the three gaps this prep exposed (contact centre, presenting above regional level, and regulated complaints), for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Ashgrove Credit Union: Member Experience Lead interview pack

For Dara. Three rounds on 28 November 2026, in loop mode: one shared fit snapshot, then a mini-pack per round.

- Round 1: 30 minutes with the recruiter.
- Round 2: 45 minutes with the Head of Member Services, your manager, mostly behavioural. Name not yet assigned.
- Round 3: 60 minutes with a panel of two branch managers, including a 20-minute complaint escalation case. Scored against the four values. Names not yet assigned.

Built on the material you sent: your background, the JD text, the four values as you copied them on 19 November 2026, the recruiter's email, and the strategy points as you summarised them. Nothing was searched. Interviewer reads are absent because no names are assigned.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores:

- **VAL**: behaviour that shows the published values
- **EXP**: your own experience, and whether it holds up under scrutiny
- **JD**: the listed job's responsibilities and requirements
- **CO**: company and strategy knowledge
- **CASE**: a live problem from the job

Persona letters: **A** Conversational, **B** Skeptic, **C** Values/Behavioral, **D** Case/Strategist, **E** Data-Driven Prober, **F** Pressure, **G** Peer Evaluator.

IDs read as round, persona, number. R2-B1 is Round 2, Skeptic, first question.

Guidance is scaffolding, not a script. Where a cell says "answer slot", the honest branch ("say so plainly") is a complete answer, not a failure.

## Fit snapshot (shared across all rounds)

Requirements are the JD's own words. Evidence is your sentences, verbatim, with origin named. No requirement here is a gate: none is a term, licence or credential. Years of experience is graded on fit, not treated as a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as branch supervisor." (your message) | medium | [grounded] | presentation | Your material says six years in retail banking. Bridge, in your words: "For six years I worked in retail banking, the last three as a branch supervisor." Adds nothing the quote does not. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Adjacent work at its own scope: "I handled the branch's formal complaints log." Your material does not say the log followed rules set outside the branch. Answer slot: the JD raises regulated complaints, so expect a probe. If the log followed external rules, say which and how you applied them. If it did not, say so plainly and describe how the log was kept. |
| F3 | "own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Your material is one branch's log, not a process across branches. Bridge: "At branch level I handled the formal complaints log." Answer slot: if you handled complaints across more than one branch, say how. If not, say so plainly and stay with the one log. |
| F4 | "...and the contact centre" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan, never as a past. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Bridge: "I built the monthly complaints spreadsheet our regional manager uses." Your material does not say it carried resolution times. Answer slot: if it did, say how they were measured. If not, say so plainly and say which measure you would add first. |
| F6 | "coach branch supervisors on escalations" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | low | [grounded] | transferability | The adjacent work is training tellers, not coaching supervisors. Bridge: "I trained new tellers on our escalation script." Answer slot: if you have coached a supervisor on escalations, say what you did. If not, say so plainly and say what you would coach first. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent on digital work, so the words are an answer slot. If you worked with a digital team or on a self-service journey, say what you did. If not, say so plainly and say what you would ask a digital team first. |
| F8 | "confident presenting to senior leaders" (JD) | "Never worked in a contact centre, and I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | You stated the absence. Words: "I haven't presented to anyone above regional level." Then the plan, as a plan: what you would show first. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Bridge: "I built the monthly complaints spreadsheet our regional manager uses." Your material does not name Excel. Answer slot: name the tool and the features you used, in your own words. If it was not Excel, say what it was. |

Confidence is medium on F1, F2, F3, F5 and F9 because nothing has been inspected. The upgrade menu names the artifact that would raise them.

## Prohibited claims

Claims this pack will not coach. Each entry names its basis and its honest form. No answer slot, hold, bridge or reverse question in this pack asserts, softens or implies any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the member complaints process end to end across branches and the contact centre | Inflated form of F3 and F4 | F3's quote at its own scope. Your material shows one branch's log and no contact-centre work, and that is the limit. For F4: "I haven't worked in a contact centre." |
| Coached branch supervisors on escalations | Inflated form of F6 | F6's quote: you trained new tellers on the escalation script. |
| Reported complaint volumes and resolution times to senior leaders | Inflated form of F5 and F8 | F5's quote at its scope: a monthly spreadsheet your regional manager uses. For F8: "I haven't presented to anyone above regional level." |
| Presented to senior leaders | Negative you stated, F8 | "I haven't presented to anyone above regional level." No answer slot on this one. |
| Built Excel reporting | Inflated form of F9 | F9's quote: "I built the monthly complaints spreadsheet our regional manager uses." |

## Grounding brief

What to sound current on. Facts are from the July 2026 strategy points you gave, not from a checked copy of the brief. The full brief was not pasted, so company-strategy depth is limited to these points.

- **Digital shift**: "move 40% of member service to digital channels by 2028" (your message, from the brief)
- **Branch consolidation**: "consolidate eight branches into five hubs over 2027" (your message, from the brief)
- **New product**: "launch a small-business lending product in Q1 2027" (your message, from the brief)
- **Competitive frame**: app-only banks as the main pressure (your message, from the brief)

Vocabulary to use: digital channels, hubs, self-service journeys, member service, escalations.

## Values cheat sheet

The panel is the values round. The recruiter's email says it "score[s] against the four values", so every value gets a VAL question in Round 3. Working meanings paraphrase the published text. Mapped stories use your quoted sentences, and where none carries a story, a selection scaffold ends in its honest branch.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side first. | F2: "I handled the branch's formal complaints log and trained new tellers on our escalation script." No story is carried. Scaffold in R3-C1: pick one log entry you decided from the member's side. If none comes to mind, say so plainly. |
| Plain Words | If a member needs it explained twice, the wording failed. | F6: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Scaffold in R3-C2: if the script was reworded after tellers got it wrong, say what changed and how you knew. If it never changed, say so. |
| Neighbours, Not Numbers | Each branch is part of its town. | F1: "6 years in retail banking, the last 3 as branch supervisor." No town story is carried. Scaffold in R3-C3: a branch you supervised, and what you knew about its town that the figures did not show. If none, say so. |
| Own the Fix | Keep hold of a problem until it is solved. | F3: "I handled the branch's formal complaints log and trained new tellers on our escalation script." No solved-problem story is carried. Scaffold in R3-C4: one complaint you saw through, what you needed from others, and when it closed. If none, say so. |

## Round 1: Recruiter screen (30 minutes)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| A Conversational | Friendly opener, background, then logistics | High. A recruiter screen is a logistics and motivation check in a friendly register. Its four logistics slots are the recruiter-screen coverage rule, so they sit here beyond the usual persona depth. | Rehearse the 90-second arc. Treat casual questions as scored. |
| B Skeptic (light) | One knockout probe on the stated gap | Low to medium. The recruiter will likely raise the one absence you stated. | Say the plain acknowledgment, then the plan. |

### Question bank

#### A: Conversational

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Walk me through your background in about two minutes." | EXP | [grounded] "6 years in retail banking, the last 3 as branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | A 90-second arc in your own words: six years in retail banking, the last three as a branch supervisor. Then the complaints log. Then the escalation training. Then the spreadsheet. Stop there. The contact-centre gap comes up in R1-B1 if asked. | F1, F2 and F5 are the three facts this round tests. The opener is the first place a recruiter checks the CV. |
| R1-A2 | "Why complaints work, and why Ashgrove?" | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." | Say what the complaints work has meant to you, in your own words. If a particular branch complaint gave you that, say which. If none did, say so plainly and give your real reason for wanting the role. | The recruiter's values-adjacent motivation check. The value is quoted from the published page. |
| R1-A3 | "Digital is 40% of member service by 2028. What does that do to complaints?" | CO | [grounded] "move 40% of member service to digital channels by 2028" | Say what changes when service moves to apps: which complaints arrive digitally, and how they reach a person. Name what you would measure first. If you have worked on a digital channel, say so. If not, say so plainly and say what you would ask first. | The strategy point is the one most likely to be asked casually. F7 is your weakest area here. |
| R1-A4 | "What are you looking for on pay?" | JD | [generic] | Logistics slot: give your own figure, or ask for the band before you name one. Supply no figure from this pack. | Pay is a knockout check, and the only safe answer is your own. |
| R1-A5 | "When could you start, and what notice do you owe?" | JD | [generic] | Logistics slot: give your actual notice period, in your own words. | Notice is a knockout check, and the only safe answer is your own. |
| R1-A6 | "The brief consolidates eight branches into five hubs by 2027. Where would you be based?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" | Logistics slot: state the location and days you can work, in your own words. | The hub plan is why location is likely to be asked. |
| R1-A7 | "Why are you looking to move on from your current role?" | EXP | [generic] | Logistics slot: one sentence, your own reason. Make it one you hold. | The recruiter's reason-for-leaving check. A reason you do not hold will not survive round two. |

#### B: Skeptic (light)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-B1 | "You've never worked in a contact centre. Does that worry you about this role?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't worked in a contact centre." Then the plan, said as a plan: what you would do in the first month to learn how a contact-centre complaint runs. Do not claim contact-centre experience. | F4 is a capability gap you stated. The recruiter's version is the first time it is said aloud. |
| R1-B2 | "Which of your six years would you count as customer operations?" | JD | [grounded] "6 years in retail banking, the last 3 as branch supervisor." | Name the years that were customer-facing, in your own words. If none of them were customer operations as the JD means it, say so plainly. | F1 is presentation: the years are retail banking, and the JD says customer operations. Keep the answer at the quote's scope. |

**Reverse questions, Round 1**

| Question | Why it lands |
|---|---|
| "Which interviewers will be on the panel, and what does each one score?" | Shows you have read the recruiter's note about the values round, and gets the scoring structure. |
| "What would success look like in this role at six months?" | Asks for the measure the business uses, which you can later match to your reporting. |

## Round 2: Head of Member Services (45 minutes, your manager)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | Past-behaviour probes, STAR-shaped | Highest. The recruiter says this round is mostly behavioural. Depth 4. | Choose stories where the hard part landed. Where none exists, say so. |
| B Skeptic | Manager testing whether a capability gap is safe to hire around | High. Your manager is buying capability and checking the two gaps you stated. Depth 3. | Plain acknowledgment, then a specific plan. |
| D Case/Strategist | A live problem from the actual job | Medium. Your manager's live roadmap is the consolidation and the escalation load. Depth 2. | Clarify, then structure, then decide. |
| E Data-Driven Prober | Questions about the spreadsheet | Medium. Your CV names the spreadsheet your regional manager uses. Depth 2. | Say what it counts, and say what you do not know. |
| F Pressure | A time-boxed challenge | Low. The round is mostly behavioural. Depth 1. | Hold, then concede the limit. |

### Question bank

#### C: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-C1 | "Tell me about a time you had to explain a complaint decision to a member who didn't like it." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. Choose one log entry you explained. Say the decision, the member's objection, what you said, and what they did next. If no such time comes to mind, say so plainly, then give the nearest thing the log carries, or how you would handle it. | F2 is the complaints evidence. The honest answer is an entry from the log, or a plain "none". |
| R2-C2 | "Walk me through how you trained new tellers on the escalation script." | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say the order you taught it in, what the tellers got wrong, and what you changed. Answer slot: if you checked whether tellers used the script on the floor, say how. If you did not, say so plainly. | F6 is the nearest proof of coaching. The manager will test whether it was yours. |
| R2-C3 | "How would you coach a branch supervisor whose escalations keep landing on you?" | JD | [grounded] "coach branch supervisors on escalations"; "6 years in retail banking, the last 3 as branch supervisor." | Use your own seat as a supervisor. Say what you would want from a coach, and the first question you would ask. Answer slot: if you have coached a supervisor or a teller on escalation, say what you did. If not, say so plainly. | The JD's coaching line. F1 is the only supervisory seat your material carries. |
| R2-C4 | "Give me an example of when you put a member ahead of a branch target." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." | Open prompt. Pick a decision where the member's side and a branch measure pulled apart. Name the measure, what you chose, and what it cost. If no such time comes to mind, say so plainly. | Members First is the value this round scores most. No story is carried, so the pack does not supply one. |

#### B: Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "You've never worked in a contact centre. How would you learn one in your first 90 days?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't worked in a contact centre." Then the plan, said as a plan: the first weeks of sitting with the team, walking one complaint from first contact to close, and bringing back what breaks. | **Highest-ROI prep in this pack.** F4 is the role's first line and your manager's first probe. A plain answer, not a defence, changes the round. |
| R2-B2 | "You've not presented above regional level. How would you present complaint trends to senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: what you would show first, and how you would rehearse it with your manager. | F8 is a capability gap you stated. The manager will test whether the plan is specific. |
| R2-B3 | "How would you know a complaint was fixed, rather than moved to another team?" | JD | [generic] | Name the tests in your own words: the member accepts the outcome, the complaint does not reopen, and the handover is recorded. Make no claim about your past. | Tests end-to-end ownership. A generic question with a generic answer. |

#### F: Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-F1 | "Sixty seconds: why should we give this to someone without contact-centre experience?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold: name what your material carries, in its own words: the formal complaints log, the escalation training, the spreadsheet. Concede: "I can't claim contact-centre experience, and I'd want the first month to test that." If the follow-up presses, return to the log. | Pressure tests whether you hold a real position without folding. The position is limited to your quotes. |

#### D: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-D1 | "A member's complaint has been open for weeks and has passed between two branches. What do you do this week?" | CASE | [generic] | Clarify who holds it today and what has been promised. Decide one owner. Send the member a plain-words update. Fix the handover. Log the reason. Make no claim about your past. | A generic live problem from the JD's end-to-end line. |
| R2-D2 | "Two of your branch supervisors escalate almost everything to you. What changes?" | CASE | [grounded] "coach branch supervisors on escalations" | Find out why first: training, authority, or unclear rules. Name what you would coach first, and what you would stop doing yourself. Make no claim about your past. | The JD's coaching line, put as a case about the role, not about you. |

#### E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-E1 | "Walk me through the monthly complaints spreadsheet. What does it count, and how?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what it counts, in your own words, and what you would change. Answer slot: if it held resolution times, say how they were measured and which assumption you would defend least. If it did not, say so plainly and say which measure you would add first. | F5 and F9 are medium because nothing has been inspected. This probe is the one that inspects them. |
| R2-E2 | "Which parts of the formal complaints log followed rules set outside the branch, and which didn't?" | JD | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Answer slot: name the rules that applied and how you applied them, in your own words. If the log followed none set outside the branch, say so plainly and describe how it was kept. | The JD's regulated-complaints line. The second branch lets the premise be false. |

**Reverse questions, Round 2**

| Question | Why it lands |
|---|---|
| "How will complaint ownership split between branch managers and the contact centre once the hubs replace branches?" | Shows you have read the 2027 consolidation, and turns the seam into a design conversation. |
| "What would the first 90 days look like for someone coming in to lead the contact-centre side?" | Converts your stated gap into a plan conversation with your manager. |
| "Which of the four values is hardest to see in a complaint, day to day?" | Shows you have read the values, and invites your manager to say what they score. |

## Round 3: Panel of two branch managers (60 minutes, values round, 20-minute case)

### Persona weights

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | One probe per value | Highest. The panel scores against the four values. Depth 4, one per value. | One story per value, or the honest "none". |
| D Case/Strategist | The 20-minute escalation case, then a follow-up | High. The case is the round's largest block. Depth 3. | Clarify, decide one owner, then the handover. |
| G Peer Evaluator | Seam questions, and "what would you need from me" | Medium to high. Branch managers are the closest thing to peers in this loop. Depth 3. | Propose seam principles, not a seam you have not seen. Reciprocity. |
| E Data-Driven Prober | Volumes and resolution-time measures | Medium. The JD names both measures. Depth 2. | Name the assumption you would defend least. |

### Question bank

#### C: Values/Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-C1 | Members First, Always: "When did you decide a complaint from the member's side of the counter, against the branch rule?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. Pick one log entry you decided from the member's side. Say which rule, if any, applied, and why you decided as you did. If none comes to mind, say so plainly, then give the nearest entry the log carries. | The panel's first value. The nearest sentence is the log, and the honest branch is a plain "none". |
| R3-C2 | Plain Words: "Tell me about an explanation you had to rewrite because people didn't understand it the first time." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. If the escalation script was reworded after tellers got it wrong, say what changed and how you knew. If it never changed, say so, and say what you would check first. | Plain Words is scored by how the answer itself is said, so keep it short. |
| R3-C3 | Neighbours, Not Numbers: "Tell me about a complaint where the figures and the town told you different things." | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town."; "6 years in retail banking, the last 3 as branch supervisor." | Open prompt. Use a branch you supervised, and what you knew about its town that the figures did not show. If there is no such case, say so, then say how you would find out what a town wants from its branch. | F1 is your only branch-level evidence, so the story must come from you. |
| R3-C4 | Own the Fix: "Tell me about a complaint you kept hold of until it was solved, when it wasn't yours to fix." | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved."; "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Open prompt. Pick one complaint. Say what you held, what you needed from others, and when it closed. If none comes to mind, say so plainly. | Own the Fix is the value that decides the escalation case. The story must be real, or the honest "none". |

#### D: Case/Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-D1 | "A member has been passed between your branch and the contact centre three times, and asks for one named person. You have twenty minutes. Talk us through it." | CASE | [generic] | Clarify first: what the member has been told, what was promised and by whom, and what is still open. Decide one owner today. Send a plain-words holding reply with that owner's name and a date for the next update. Agree with both sides who does what. Record the handover and its reason. Report the pattern to the Head of Member Services. Name the step you would need help with. Make no claim about your past. | The 20-minute case. Structure and ownership are scored. It is a generic problem, so the guidance makes no claim about you. |
| R3-D2 | "What would you need from the branch manager before you change anything?" | CASE | [generic] | Ask for the branch's current file, the rules they work to, and the people who handled it. Say you would ask before you change any process. | Tests partnership, not solutions. |
| R3-D3 | "What would make your plan wrong after a week?" | CASE | [generic] | Name the first signal you would watch, and what you would do if it appeared. | Tests whether you can see the failure in your own plan. |

#### G: Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-G1 | "Our branches own a complaint until it reaches the contact centre. Where's the seam, and what happens when we disagree about it?" | JD | [grounded] "own the member complaints process end to end across branches and the contact centre" | Propose a seam principle, such as one named owner at every handover, written down. Do not claim to know their seam. Answer slot: if you have resolved a handover disagreement, say how. If not, say so plainly and name the principle you would test first. | The panel's peer probe on the JD's end-to-end line. |
| R3-G2 | "What would a new Member Experience Lead do in the first month that would genuinely help your branches?" | JD | [generic] | Reciprocity. Ask about their branches' pain points first. Then offer one specific proposal, framed as a question you would test. | The reciprocity question for a peer panel. |
| R3-G3 | "Our digital teams want self-service journeys. What would you need to know before designing one for complaints?" | JD | [grounded] "work with digital teams on self-service journeys" | Name what you would need to know: where complaints start, what members try first, and where they give up. Answer slot: if you have worked with a digital team, say what you did. If not, say so plainly. | The JD's digital line. F7 is discovery, so this is the only round that asks it directly. |

#### E: Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-E1 | "Which measure in a monthly complaints report would you trust least: volumes or resolution times?" | JD | [grounded] "report monthly on complaint volumes and resolution times" | Name the assumption you would defend least in whichever measure you pick, in your own words. If you have not measured either, say so. | The JD's reporting line. The weakest-assumption move, applied to measures rather than to figures you have not given. |
| R3-E2 | "How would you know whether a complaint was resolved, as opposed to closed?" | JD | [generic] | Name the evidence you would look for: the member's acceptance, reopened complaints, and repeat contact. Make no claim about your own system. | Separates resolution from closure, which the JD's resolution-time line depends on. |

**Reverse questions, Round 3**

| Question | Why it lands |
|---|---|
| "What does a good complaint outcome look like to you, from the member's side?" | Invites the panel to say what they score, and lets you use Members First in their own terms. |
| "When a branch and the contact centre disagree about an owner, who decides?" | Shows you have thought about the seam, and gets a real answer about decision rights. |
| "What would the first 90 days need to prove?" | Asks for success criteria, which you can then answer against. |
| "What is one thing you wish the last person in this role had done differently?" | Peer candour. Panel members answer this more freely than managers do. |

## Requirement coverage

Each JD requirement, and the question IDs that cover it.

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches and the contact centre | R1-B1, R2-B1, R2-D1, R3-D1, R3-G1 |
| Report monthly on complaint volumes and resolution times | R2-E1, R3-E1, R3-E2 |
| Coach branch supervisors on escalations | R2-C3, R2-D2 |
| Work with digital teams on self-service journeys | R1-A3, R3-G3 |
| 4+ years in financial-services customer operations | R1-B2 |
| Experience handling regulated complaints | R2-C1, R2-E2 |
| Confident presenting to senior leaders | R2-B2, R2-F1 |
| Comfortable with Excel reporting | R2-E1 |

## Sources

- **Provided documents**: your message (background, the JD text, the four values as you copied them on 19 November 2026, the recruiter's email, and the strategy points you summarised).
- **Searches and fetches**: none sent.

**Research tier: L0, no searches; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Values cheat sheet. The four values you copied this morning fix the names and the working meanings. |
| 2. Ashgrove interview process, member services | skipped | Loop structure. The recruiter's email names the three rounds, their interviewers, and the values scoring. That is a loop source. |
| 3. Ashgrove strategy and recent news | skipped | Grounding brief and CO questions. The four strategy points you gave fix those premises. A full brief would deepen them. |
| 4. Interviewer name and Ashgrove | n/a | Round 2 and Round 3 interviewers have roles but no names, so there is no query to form. |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Interviewer names for Rounds 2 and 3** → persona weights from their public footprint, and a tailored reverse question for each round.
- **The full July 2026 strategy brief, pasted** → a fuller grounding brief, and deeper CO questions in R1-A3 and R3-G3.
- **Your notice period, and the pay and location you would accept** → R1-A4 to R1-A7 get your own answers in place of the logistics slots.
- **An anonymised copy of the monthly complaints spreadsheet, with all member data removed** → lifts F5 and F9 from medium to high, and makes R2-E1 and R3-E1 concrete. Check first that you are allowed to share it.
- **What the formal complaints log had to follow, such as rules or timeframes** → upgrades F2 and the regulated-complaints answer in R2-E2.
- **Any coaching of a supervisor or teller, and any digital or self-service work** → fills the answer slots at F6, F7, R2-C2, R2-C3 and R3-G3 with stories.
- **Written materials for the panel case, if sent** → lets R3-D1 be rehearsed against the actual problem.
- **Deeper research, once**: a research pass of up to 6 more searches and 2 more fetches, several minutes. It would look for the strategy brief itself, interviewer public talks, and recent leadership changes. Say if you want it.
- **`tuesday-dossier.md`** → would record the three gaps this pack exposed (the contact centre, presenting above regional level, and regulated complaints) for later sessions.
