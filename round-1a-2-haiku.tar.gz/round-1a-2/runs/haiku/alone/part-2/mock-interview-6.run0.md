Your combined prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-6-denied-6e4382bb/98ade97f-6600-49dd-bd45-68dac20d2b4f/scratchpad/Larkfield_engineering-manager_interview_pack.md. It's built in loop mode: one shared fit snapshot, then a mini-pack for each of the three rounds, with 8–9 questions and 5 reverse questions per round.

Three things shaped it:
- **Research didn't run.** All three web searches were refused in this session, so the pack has nothing on Larkfield's values, interview process or strategy. The round 3 questions name no company value, and the strategy questions are marked generic.
- **Your gaps are the centre of the pack.** Managing managers, hardware and device-management work, and the scale from six to eleven are the gaps your material doesn't close. Each has an honest answer path: say the gap plainly, then give a plan. Answer slots are instructions for the interview, not questions to you.
- **Highest-ROI prep is A2** (the hardware and device objection) in round 1. Round 2 tests the same ground in B4.

Two things to check before you rehearse:
- The pack treats your role description as the requirement list.
- Every claim about your past comes from your own sentences, quoted in the file. Nothing is inferred beyond them. The prohibited list spells out the stretched versions to avoid, such as "designed the hiring loop" for "I run our hiring loop" and "caused the 60% drop" for "after I pushed a reliability quarter through".

Other options:
- I can run a live drill. Tell me the round and question ID; by default I'll play the Skeptic on A2.
- I can save a tuesday-dossier.md recording the gaps this prep exposed, to carry into later sessions.

One question: can you paste the full job description and your CV? If you'd rather I proceed on what you've given, say so and both will stay on the upgrade menu.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: Larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems: Engineering Manager interview prep pack (three rounds)

**Role:** Engineering Manager, two device-management squads, 11 engineers (industrial IoT, ~600 people)
**Mode:** Loop. One shared fit snapshot and sources block, then a mini-pack per round.

| Round | When | Who | Length | Round type |
|---|---|---|---|---|
| 1 | Tuesday | Hiring manager, Director of Engineering (interviewer name not given) | 45 min | Hiring manager |
| 2 | Thursday, the following week | Panel: two staff engineers and a product manager | 60 min | Peer panel |
| 3 | Following Monday | VP Engineering | 30 min | Values and leadership philosophy, as the recruiter described it |

Round 3 is a values-style round because the recruiter's own words name one. Round 1's persona weights rest on the relationship prior; no interviewer profile was given.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- **Type key:** VAL = values and behaviour, whether past behaviour shows a value. EXP = experience deep-dive, whether what you wrote survives scrutiny. JD = role-driven, can you do the listed job, gaps included. CO = company and strategy knowledge. CASE = live problem from the role.
- **CO items are generic here.** No company research ran (see Sources), so the pack says so in each one.
- **Guidance is scaffolding, not a script.** Speak it in your own words. The only things you may assert about your past are your own quoted sentences, quoted in the Provenance column.
- **Answer slots** are instructions for the interview, not questions. Each has an honest second branch, and that branch is always allowed.

## 1. Fit snapshot

Requirements are quoted from your role description. Evidence is quoted from your message. Nothing else is treated as a fact about you.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — your message | "9 years engineering, 3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material shows one team of six, not two squads. Your words: "For three years I was team lead of six." Answer slot: if you have ever been answerable for more than one team, say how it worked; if not, say so plainly and say what you would do first with two. |
| F2 | "Lead two squads building device-management services" — your message (the device part) | none given | none | [grounded] | discovery | Your material does not show device-management work. That is the pack's observation, not words for you. Answer slot: if you have built or run services that manage devices or their fleets, say what they did and what you owned; if not, say so and say how you would learn the domain. |
| F3 | "own delivery, hiring and growth for 11 engineers" — your message (delivery) | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | The nearest thing your material shows is delivery for six. Your words: "I was team lead of six." Eleven is the role's number, not yours. Answer slot: if you have been answerable for delivery across more than one team, say how; if not, say so and say what you would hold to first. |
| F4 | "own delivery, hiring and growth for 11 engineers" — your message (hiring) | "I run our hiring loop for backend roles — about 40 interviews last year." — your message | medium | [grounded] | none | Your words: "I run our hiring loop for backend roles, about 40 interviews last year." Backend only; say so if asked about device roles. Limited inspectable proof, so expect a probe on the number (B5). |
| F5 | "own delivery, hiring and growth for 11 engineers" — your message (growth) | none given | none | [grounded] | discovery | Your material does not show growing engineers. Answer slot: if you grew someone into a larger role, say what you did and what they did; if not, say so and say how you would start with eleven. |
| F6 | "partner with hardware and product on roadmap" — your message (product part) | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | medium | [grounded] | transferability | At its own scope: "I pushed a reliability quarter through against roadmap pressure." The sentence shows a roadmap fight, not partnership with product on a roadmap. Answer slot: if you have set roadmap trade-offs with product, say which and how; if not, say so. |
| F7 | "partner with hardware and product on roadmap" — your message (hardware part) | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | discovery | The negative covers owning a hardware roadmap, not partnering with hardware, so the gap is open both ways. Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Answer slot: if you have worked with a hardware team on a roadmap without owning it, say what that was and what you did; if not, say so and say how you would start. |
| F8 | Managing managers: not in the role text; raised by you as your gap | "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | none | [grounded] | capability | Plain acknowledgment: "I've never managed managers." The role text does not say the job manages managers, so whether it does is a question for the hiring manager (A1). Say how you would learn it, as a plan, never as a past. |

**Gap rows with no quoted sentence** (F2, F5) are the pack's own observation that your material is silent. Their words are answer slots, never assertions.

## 2. Prohibited claims

These are claims this pack will not coach. Every guidance cell is written against this list.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the device-management roadmap, or owned a hardware roadmap | Inflated form of F6 and F7 | F6's sentence at its own scope: "I pushed a reliability quarter through against roadmap pressure." Limit, as the pack's observation: your material says a quarter, not a roadmap. |
| Designed the hiring loop | Inflated form of F4 | "I run our hiring loop for backend roles." Limit: your material says run, not design. |
| Caused the 60% drop in on-call burden | Inflated form of the 60% sentence, which says "after", not "because" | "dropped 60% after I pushed a reliability quarter through." Limit: the sentence gives sequence, not an established cause. |
| Led two squads or 11 engineers | Inflated form of F1 and F3 | "I was team lead of six." |
| Managed managers | Negative you stated (F8) | Plain acknowledgment: "I've never managed managers." No slot. |
| Owned a hardware-adjacent roadmap | Negative you stated (F7) | Plain acknowledgment: "I've never owned a hardware-adjacent roadmap." No slot. |

## 3. Requirement coverage

| Requirement | Questions |
|---|---|
| Lead two squads building device-management services | A2, A5 |
| Own delivery for 11 engineers | A3, A5 |
| Own hiring | B5 |
| Own growth for 11 engineers | C4 |
| Partner with product on roadmap | A6, B8, B9 |
| Partner with hardware on roadmap | A2, A6, B9 |
| Manager of managers (not in role text; raised by you) | A1, C5 |

Both headline figures on your material get a defend-the-number question: the 40 interviews (B5) and the 60% (B6, A8, C7).

---

## Round 1: Hiring manager (Tuesday, 45 min)

### Persona table

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Quiet probing of the three gaps: managers, hardware, scale | High | Hiring-manager prior. The gaps sit in the role text and in your own sentences. | Plain acknowledgment first, then a plan. Rehearse A2 until it is boring. |
| Case / Strategist | Live problems from the device roadmap | High | Hiring-manager prior: they buy capability and test it on their roadmap. | Clarify, structure, name the partners. No claims about past incidents. |
| Pressure | Composure test on your one headline figure | Low | No stress signals in the material. Kept to one question so it is still touched. | Pause, restate, hold through two follow-ups. |

Weights: Skeptic 4 (A1 to A4), Case 3 (A5 to A7), Pressure 1 (A8). Prober is carried by round 2.

### Question bank

**Highest-ROI prep: A2.** The hardware and device gap (F2, F7) is the largest one in the pack, and it will be raised in some form. The honest answer is shorter than the fear.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You haven't managed managers. If these two squads need leads, what would you do first?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message | Open with the plain acknowledgment: "I've never managed managers." Then a plan in the future tense: what you would check about the leads' roles and where you would get help. Answer slot: if you have set up, coached or chosen someone who led people, say what you did and what they did; if not, say so plainly. Do not describe a leadership layer you have not run. | F8 is the gap no story closes, so the test is whether you can say it cleanly and still show a plan. The question is conditional on leads, which the role text does not state, so it makes no claim about the role. |
| A2 | "Where have you worked with hardware, or on a device, and what did you own there?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message; [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Hold with the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then the one roadmap example you have, in its own words: "I pushed a reliability quarter through against roadmap pressure." Then the partnering plan. Answer slot: if you have worked alongside a hardware team or on device data, say what and what your part was; if not, say so and say how you would start with the hardware leads. Follow-up 1 ("So what's the roadmap story?"): return to the quarter, one sentence. Follow-up 2 ("Why should we believe partnering works?"): concede what you have not done. Do not add a hardware example. | This is the deepest rehearsal because it is the most predictable objection. The panel's version comes in round 2 (B4). |
| A3 | "Eleven engineers is almost double the six you have led. What changes?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | Say the number you actually led: six. Then name what changes in how you run delivery and planning at eleven, as a plan. Answer slot: if you have been answerable for delivery across more than one team, say how it worked; if not, say so and say what you would hold to first. | The scale step is the one the quote does not reach (F1, F3). |
| A4 | "Why leave a payments company for device management?" | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | Give your actual reason in your own words, in under a minute. Answer slot: the reason for leaving is yours to state; do not borrow the role's language for it. | A motivation probe on your current employer, used to test whether the move is a step or an escape. Tagged EXP because it concerns your history. |
| A5 | "A firmware update fails on two percent of devices in the field. Where do you start?" | CASE | [generic] | Clarify scope first: how many devices, which versions, whether the failure is rollback-safe. Then decide who stops the rollout and who is told. Name the hardware and product people as the ones who fix the constraints, not the ones you wait for. Make no claim about past incidents. | A live problem from the role's device-management work, scored on structure and clarification rather than on a right answer. |
| A6 | "Product wants device onboarding in one quarter. Hardware says the next board revision slips. How do you run that roadmap conversation?" | CASE | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Structure: objective, options, trade-offs, who is in the room, what you bring back. If you use your own precedent, use the sentence and nothing more. Answer slot: if you have run a trade-off like this, say how and who held what; if not, say so and describe how you would set it up. | A partnering question with hardware and product at one table. Your one real roadmap example is kept to its sentence. |
| A7 | "Who buys device-management services, and why would they switch?" | CO | [generic] | Research did not run, so this is generic and the guidance says so. Say what you would learn first and name two things to check: the buyer's own fleet, and the incumbent's pricing. Do not state Larkfield's market position. | A CO item the hiring manager may use to test altitude. Generic by necessity; the upgrade menu says what would make it specific. |
| A8 | "That 60% — how much of it was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Hold: "I pushed the quarter through against roadmap pressure." Hold through two follow-ups. Concede specifically, and only if true: "I can't separate my share of the drop from the team's." Answer slot: name the decisions that were yours and the ones that were the team's, in your own words. If you know how the 60% was counted, say it; if not, say so. | A pressure probe on the one headline figure. The structure is hold, then concede; the counting is a slot, not a claim. |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What would make you regret this hire in a year?" | Asks for their success criteria and reveals what they fear. |
| "Which of the two squads is further behind, and what is it blocked on?" | Shows you want the real problem, not the pitch. |
| "Who on the hardware side makes the device-interface decisions, and how do they reach you?" | Tests the seam you would be partnering across. |
| "What did the last person in these squads get right, and what would you change?" | Continuity question; hiring managers answer it candidly. |
| "What would the first ninety days need to deliver for you to call it a good start?" | Turns the interview toward the shared plan. |

---

## Round 2: Panel, two staff engineers and a product manager (Thursday, 60 min)

### Persona table

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Peer Evaluator | Seam questions, disagreement, credit-sharing (staff engineers and PM) | High | Panel blend: each staff engineer's top two personas are Peer and Prober. The PM's top two are Case and Peer. | Give seam principles, not claimed knowledge. Disagreement stories only if you have one. |
| Data-Driven Prober | Denominators and windows on your two figures | High | Staff-engineer prior: they check numbers that touch their own work. | Say what you counted, the window, and the baseline; say "I don't know" where true. |
| Case / Strategist (PM) | Roadmap trade-offs with product | Medium | PM's second persona; the role partners with product on the roadmap. | Clarify, options, who decides. |

Weights: Peer 4 (B1 to B4), Prober 3 (B5 to B7), Case 2 (B8, B9). No Pressure or Conversational weight: no signals in the material.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between device management and firmware, and what happens when you disagree?" | JD | [grounded] "Lead two squads building device-management services" — your message | Give seam principles, not a map of their architecture. For disagreement, tell a story only if you have one. Answer slot: if you have disagreed with an equal across a boundary, say what you did and how it ended; if not, say what you would do first. | A peer probe on the seam. The role names device management, which your material does not show (F2), so the guidance claims none. |
| B2 | "How do you handle credit when a fix spans two teams?" | VAL | [generic] | Name who did what, in one story. Use "I" only for what you did. Answer slot: if you have had credit contested, say what you did; if not, say how you would handle it. | A peer credit probe. The 60% story may be tested here, so credit has to be exact. |
| B3 | "Our staff engineers hold the architecture. How would you handle a design decision you disagree with?" | JD | [generic] | Propose a process: write the position down, state the cost, agree a decision date. Answer slot: if you have done this, say how it ended; if not, say how you would raise it. | A collaboration probe. No history is needed to answer it well. |
| B4 | "How have you said no to product?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure." — your message | Your only roadmap example is that sentence. Say what the pressure was, who applied it, and what you held. Answer slot: if you said no to a specific request, say what and to whom; if you did not, say so and say what you did instead. | The panel will test whether "against roadmap pressure" was a refusal or a delay. The guidance does not pick one. |
| B5 | "Of the about 40 interviews last year, how many did you run yourself, and how were they counted?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Give the figure as you gave it. Then the counting, in your own words: what the 40 were, which you ran and which you only sat in on. Answer slot: name the counting method and the weakest assumption behind the number; if you do not know how it was counted, say so. Note that your loop was backend roles. | A defend-the-number probe. Your material gives no counting method, so the pack supplies none. |
| B6 | "Your on-call load fell 60%. Over what window, and against what baseline?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Answer slots only: your material gives no window and no baseline. Say what you counted and over what period. If you do not know the baseline, say so and say what you would measure. Name the assumption you would defend least. | A defend-the-number probe. The pack supplies no window, baseline or method. |
| B7 | "How was the work for that quarter chosen?" | JD | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Answer slot: if you chose which work went into the quarter, say how you decided; if the list was set by others, or there was no list, say so plainly. | A planning-process probe on the quarter. Your material does not show a selection process, so the second branch must stay open. |
| B8 | "A customer asks for a feature that breaks the reliability roadmap you'd just set. Walk me through the trade-off." | CASE | [generic] | Clarify who the customer is and what breaks. Options: ship, defer, split, or say no with reasons. Say who decides. Say what you would bring to product, not what you would win. | A PM-led trade-off. Generic because no product detail is known. |
| B9 | "Hardware says a device change needs two quarters; product needs it in one. What do you bring to the next roadmap review?" | CASE | [generic] | Propose a ruling on what is fixed, what is negotiable, and who decides. Name the dates you need. Make no claim about hardware's constraints. | Tests whether you can hold the seam between two partners. |

### Reverse questions

| Question | Why it lands |
|---|---|
| "What could a new engineering manager do in their first month that would genuinely help your team?" | Reciprocity question for peers. It shows you are thinking about their load, not only yours. |
| "Where do product and firmware disagree most often, and how does that get settled?" | Tests the seam directly; the answer shows whether the process works. |
| "What's the last design decision that got reversed here, and why?" | Shows how they handle being wrong. |
| "Which service has the worst on-call history right now, and what's being done about it?" | Connects to your 60% story and to what they actually care about. |
| "What would you want a new manager to stop doing in the first quarter?" | Surfaces the habits they have learned to resist. |

---

## Round 3: VP Engineering, values and leadership philosophy (Monday, 30 min)

### Persona table

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Values / Behavioral | Scenario prompts for "values and leadership philosophy" | High | The recruiter named the round this way. | Story beats only from your quoted sentences; selection scaffolds where none carries the story. |
| Pressure / altitude | Composure on the people-leadership gap, and on the one figure | Medium | VP altitude prior: composure and time-boxed answers. | Pause, hold once, concede specifically. |
| Conversational | Opener and closer, which are still scored | Medium | Short round; the opener and the closing question carry weight. | Rehearse the 90-second arc and a real answer to the closing question. |

Weights: Values 4 (C1 to C4), Pressure 3 (C5 to C7), Conversational 2 (C8, C9). Case and CO are omitted: there is no strategy research and no VP-level case in the material.

### Question bank

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | The beats the sentence states: the quarter, the roadmap pressure, the 60%. Answer slot: the unpopular-truth beat (what you said to leadership, who heard it, what they decided). If you said the hard thing, say what and to whom; if the quarter went through without such a conversation, say so and give the nearest thing you did. | Open prompt, themed from the recruiter's "values and leadership philosophy". Your one story carries pressure but not the telling of it. |
| C2 | "What's your leadership philosophy in one sentence, and where did it come from?" | VAL | [generic] | One sentence you already believe, in your words. Say where it came from only if you can say so honestly. No claim about your past. | Philosophy is scored for coherence with the story in C1, so the two should match. Generic because no quoted sentence states a philosophy. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Pick a case where a customer's need cost you a number, and say what the number was. If no such case comes to mind, say so plainly, then give the nearest thing you did, or how you would handle it. | A standard values probe. Larkfield's customers are not named in any source, so the guidance names none. |
| C4 | "Tell me about someone you grew who then needed more scope than your team could give." | VAL | [grounded] "3 as a team lead of 6" — your message | Pick a person you developed. Answer slot: if you grew someone into a larger role, say what you did and what they did; if none moved on under your watch, say so and give the plan for growing eleven people. | Growth is a role requirement your material does not show (F5). This is where the VP is likely to probe it. The honest branch is built in. |
| C5 | "You haven't managed managers. Why bet on a first attempt at leaders over someone who has done it?" | EXP | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." — your message; [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Hold once: the case for you is the delivery and hiring you have run, in your quoted words, not manager-of-managers experience. Then concede specifically: "I haven't managed managers. I'd expect to learn it, and here's how I'd check myself." Do not fold to "I'm ready". Answer slot: if you have held leaders accountable for results, say what you did; if not, say so. | A pressure probe on F8. The hold is the honest one and the concession is the specific one. |
| C6 | "Sixty seconds: why you over an internal candidate?" | JD | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message; [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." — your message | Give your own reasons in order: the team you have led, the hiring you run, the reliability result. Do not claim to know the other candidates. | A timed pressure question. Its guidance rests only on your quoted sentences. |
| C7 | "What did you give up to get that reliability quarter through?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." — your message | Answer slot: if something was given up, say what and who decided; if nothing was, say so plainly. Hold the fact that you pushed it through. Do not invent a cost to sound more honest. | A pressure probe that presumes a cost the material does not show. The second branch allows there was none. |
| C8 | "So — walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." — your message | Speak it in about 90 seconds: nine years, three of them as team lead of six, currently at a payments company. Then the reason for this move, in your words. Answer slot: that reason. | A conversational opener that is still scored. The arc uses only your quoted sentence and the reason you give. |
| C9 | "What's the part of this job you're least looking forward to?" | VAL | [generic] | Name a real part that you would own, and do not perform humility. | Casual register, still scored for candour. Generic. |

### Reverse questions

| Question | Why it lands |
|---|---|
| "Which of the company's values do you see colliding most often in practice, and how do people settle it?" | Treats values as trade-offs, which a values round rewards. It names no value, because none is in hand. |
| "What do managers here most often get wrong in their first year?" | Asks for the failure mode directly. |
| "When an on-call problem and a roadmap problem arrive together, who decides which comes first?" | Connects to your 60% story and to the decision rights you would inherit. |
| "What would you need to see from a new manager at ninety days to call it the right hire?" | Gives you their measure of success in their own words. |
| "What would you want the next engineering manager here to do that the current ones don't?" | Shows you are looking for the gap they actually have. |

---

## 4. Sources

**Provided documents:** your message. It contains the role description (quoted in the fit snapshot), the three rounds, your background, and the recruiter's words for round 3 ("values and leadership philosophy"). It has no CV, no full job description, no interviewer name, no values page, and no working-style assessment.

**Searches sent (all refused, so nothing came back):**
- "Larkfield Systems values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT device management strategy": refused

**Fetches sent:** none.

**Research tier: L1, searches 3 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Would have moved the values cheat sheet. None is included, because no published values are in hand. Round 3 questions name no Larkfield value. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Would have checked round formats. The three rounds are established by your and the recruiter's words, so it would have moved format detail only. |
| 3. Larkfield Systems strategy and recent news | unavailable | Would have moved the CO items. A7 stays generic. |
| 4. Interviewer name and Larkfield | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative Engineering Manager JD | skipped | The role description in your message fixes the fit snapshot's requirements. |

**Loop:** the three rounds you named, each with its length and who runs it, establish the loop. No archetype fallback was needed.

## 5. Upgrade menu

- **Full job description text:** requirement rows F1 to F8 gain the posting's own wording, and any requirement the posting adds gets its own row and question.
- **Your CV:** F1, F3, F4 and F6 gain exact CV sentences, and the story beats in A3, C1 and C8 can quote your CV rather than your summary.
- **Interviewer names for rounds 1 to 3:** personas per panelist in round 2, a tailored reverse question per round, and an interviewer read from public footprint.
- **Larkfield's published values page, pasted:** the round 3 values cheat sheet, and C1 to C4 map to named values.
- **Recruiter's note on round formats:** confirms whether any round includes a presentation or take-home. If one does, it gets a graded-deliverable section.
- **Whether the two squads have their own leads:** settles F8 and the answer branch of A1.
- **Where the role is based and how many days on site, if posted:** a gate row, which the pack must then show.
- **Search access, or a pasted strategy brief:** the three refused targets would run. Values would be checked against the official page, loop structure against the process, and strategy would turn A7 from generic into grounded.
- **Dossier:** with no tuesday-dossier.md present, one would carry F2, F5, F7 and F8 into later sessions as the gaps to verify.
