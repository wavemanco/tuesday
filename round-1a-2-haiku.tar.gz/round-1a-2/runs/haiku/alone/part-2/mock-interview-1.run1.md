I'll load the mock-interview skill, since it covers this kind of prep pack.
I'll read the reference files the skill requires before writing anything.
I've read the core references. Before I write, I'll run the one research check the skill's budget supports: Northwind's published values, which the pack needs to state accurately.
The search was refused, so this pack runs at L1 with one call spent and no research beyond your note. I'll save the pack, then present it.
Your prep pack is saved as /var/tmp/tuesday-measure/1a2/runs/haiku/alone/part-2/rooms/case-1-denied-e7e00309/northwind_senior-gtm-strategy-lead_interview_pack.md. I built it on your note alone: one 60-minute conversation with Dan as a peer, your JD highlights as the requirements, and no research beyond your note, since the one search was refused.

# Northwind Data: Senior GTM Strategy Lead, Emerging Products

**Candidate:** Priya
**Interview:** single 60-minute conversation with Dan Kovac, Director of Sales Strategy. Peer: both report to the same VP.
**Built on:** your note (candidate background, JD highlights, Northwind research note, interviewer profile). No full JD text. No CV document. One search, refused, so no research beyond your note.
**Changelog:** first build.

## How to use this pack

- **Personas** describe how a question arrives: its tone and method.
- **Types** describe what is being scored: **JD** (a stated requirement), **EXP** (what you did, and how precisely you attribute it), **CO** (company and strategy knowledge), **CASE** (a live problem from the role), **VAL** (published values; none detected here).
- Guidance is scaffolding, not a script.
- An **answer slot** is an instruction for the interview. Answer it in your own words, from your own experience. If a practice was not yours, or did not happen, say so plainly.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD (your message) | "9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material shows product strategy and ops, not go-to-market ownership, so do not stretch it. Keep the scope: nine years, a large consumer-tech company, product strategy and ops. Answer slot: the JD's line makes a probe on your product decisions likely. Which product-strategy decisions were yours to set, and how did you decide? If none were yours, say so and describe how you worked on them. |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD (your message) | none given | none | [grounded] | discovery | Answer slot: if you have found whitespace across land, adopt, expand or renew, say where and how. If you have not, say so and say how you would find it first. |
| F3 | "run independent analysis in SQL and Tableau" — JD (your message) | "skilled in SQL/Tableau" — your message | low | [inferred] | presentation | Clarify-strategy note only, never an assertion: the quote names tools, not an analysis. Derivation: this pack's reading of a low-confidence quote. Answer slot: if you ran an analysis where the question, the data pull and the conclusion were yours, say which and what it changed. If you have not, say so and say what you would check first. |
| F4 | "partner-motion design experience required" — JD (your message) | "built partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Words at the quote's scope: "I built a partner-level revenue model used in carrier negotiations." Limit, as this pack's observation: your material shows a model, not the design of a partner motion. Answer slot: which parts of the model were yours to set, and what it was built to answer. If any part was not yours, say so. |
| F5 | "strong cross-functional influence" — JD (your message) | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | Bridge rewords only this quote: "I set annual volume targets with cross-org consensus." Answer slot: who disagreed on those targets, and what got them to consensus. If no one disagreed, say so. |
| F6 | "AI experience a plus" — JD (your message) | "uses AI tools daily" — your message | medium | [grounded] | transferability | Words: "I use AI tools daily." Limit: this is use, not building anything with them. Answer slot: say what you use AI tools for, in your own words. If that is all it is, say so. |
| F7 | Role-family expectation: sales-ops or quota-setting for a GTM role — [generic] | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | Words, from your own stated negative: "I haven't done classic sales-ops or quota-setting." Then a closure path, said as a plan and never as a past: how you would learn it, from whom, and what you would check first. |
| F8 | Headline figure the interviewer is likely to raise; no JD line — [generic] | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | discovery | Words, at the quote's scope: "I proposed a store-surface change, and it was credited with a ~$400M ARR uplift." Answer slot (defend-the-number): how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. |

## Prohibited claims

What this pack will not coach, and why. Built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1: "own GTM strategy" widens "9 at a large consumer-tech company in product strategy & ops" | F1's quote at its own scope. Observation, in analysis only: the material shows product strategy and ops, not GTM ownership. A1 and D1 slots stay inside product strategy. |
| Designed the partner motion | Inflated form of F4: "built … model" widened to "designed" the motion | F4's quote. Observation: the material shows a model, not a motion's design. |
| Led cross-functional alignment | Inflated form of F5: "set targets with cross-org consensus" widened to leading the alignment | F5's quote. Observation: consensus on targets, not leading the effort. |
| Drove the ~$400M ARR uplift | Inflated form of F8: "proposed … credited with" widened to "drove" | F8's quote at its own scope. Defend-the-number slots apply. |
| Ran independent analysis in SQL and Tableau | Inflated form of F3: "skilled in SQL/Tableau" widened to a named analysis | Clarify-strategy note only. Never asserted. |
| Built AI products or features | Inflated form of F6: "uses AI tools daily" widened to building | F6's quote. Slots ask what you use them for. |
| Has done sales-ops or quota-setting | Negative you stated, F7 | Plain acknowledgment from F7: "I haven't done classic sales-ops or quota-setting." No slot. |

## Grounding brief

From your research note. The note is undated. If it is more than about six months old, refresh it before the interview.

- Stated priorities: "enterprise expansion"; "an AI copilot launch ('Compass')"; "reaching profitability" [grounded].
- Competitive frame: "main competitive threat is bundling by a much larger platform vendor" [grounded].
- Use these words as Northwind's own. Do not correct Dan's framing.

## Reading the interviewer

Source: your note. Nothing was checked against public sources this run, because the search was refused.

- **Career pattern:** pricing and monetization, with one early-stage-startup chapter. Self-described as "relentlessly data-driven."
- **Practical implications:**
  - The Prober persona rises. Expect every figure to be taken back to its assumptions.
  - Case questions tilt toward pricing, packaging and unit economics, which is Dan's native ground.
  - The startup chapter means builder stories land well, and expect probes on scrappiness.
  - As a peer, Dan will test the seam between the two teams and how disagreements are handled.
- **Mirror opportunity:** shared domain of monetization. Your partner revenue model (F4) is a fair vocabulary mirror. No shared career jump is known, so none is offered.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Data-Driven Prober | Takes figures back to inputs, denominators and assumptions | Highest. Peer relationship prior plus a self-described data-driven interviewer | Know how each figure was counted, or say plainly you do not know. Name the weakest assumption first. | 5 |
| Peer Evaluator | Seam questions, disagreement with equals, credit-sharing, what the hire needs from them | High. Peer relationship prior; the hire's cost to Dan's team is the test | Propose seam principles, not a claim to know the seam. Say what you bring, not only what you need. | 4 |
| Case / Strategist | Live problem from the role or from Northwind's priorities | Medium. Pricing-led interviewer; the note's priorities and threat are the material | Clarify, then structure, then answer. Think aloud. | 3 |
| Skeptic | The GTM-ownership gap and the sales-ops gap | Medium. Your two real gaps are the likeliest objections | Name the weakest part yourself. Ramp plan. Calibrated candor. | 3 |
| Pressure / Stress | Time-boxed challenges on the $400M and on the product-strategy background | Lower. Peer register rarely escalates, but a data-driven peer can press | Hold through two follow-ups. Concede the specific, not the core. | 2 |
| Conversational / Rapport | Casual journey question, casual AI question | Lower, and easy to underrate. Casual questions are still scored | Pre-scripted 90-second arc. Treat AI as scored. | 2 |
| Values / Behavioral | Published-values probes | Not present. No values-style round is detected, so no bank | None. | 0 |

## Question banks

Types: JD, EXP, CO, CASE, VAL. Provenance comes first in each row.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the partner-level revenue model: what went in, and what came out." | EXP | [grounded] "built partner-level revenue model used in carrier negotiations" | Story-mapped on F4. Beats: you built the model, and it was used in carrier negotiations. The quote says it was used, not by whom, so say no more than that. Then inputs and outputs, named plainly. Answer slot: if any part was set by someone else, name the part and who set it. If you cannot describe an input, say so. | F4 is the closest evidence to the partner-motion requirement, and the likeliest place for a prober to start. EXP because it tests what was yours. |
| A2 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Defend-the-number, in your words: how it was counted; what it is sensitive to; the assumption you would defend least; which part was yours. Answer slot: if you did not see how it was counted, say so. You proposed the change, and it was credited with the uplift. Name the assumption before Dan does. | F8 is the headline figure most likely to be probed. The defend-the-number slots are the rehearsal every CV figure gets. |
| A3 | "Which assumption behind those annual volume targets would you defend least?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Defend-the-number on the targets: how they were set, the assumption you would defend least, and which part was yours. Answer slot: if you did not set the targets, or had no part in the assumption, say so. Do not improvise a method for setting them. | F5's consensus claim rests on a target figure. Probers ask for the assumptions behind targets as a matter of course. |
| A4 | "What would you query first to size expansion whitespace, and what would make you distrust the result?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew"; [grounded] "run independent analysis in SQL and Tableau" | Clarify "expansion" first: which accounts, which ARR. Then the grain, the denominator, the one assumption you would check first, and the result that would make you distrust the number. Speak to the logic of the query, not to a query you have run. No claim about your past. | F2 has no evidence. A live problem tests the requirement without asking for a past the material does not show. CASE, because it is a problem from the role, and a prober will follow up on the denominator. |
| A5 | "Tell me about an analysis you ran end to end: your question, your data, your conclusion." | EXP | [inferred] "skilled in SQL/Tableau". Low confidence: coaching note only. | Open prompt with a selection scaffold. Pick an analysis where the question, the data pull and the conclusion were yours, and say what it changed. If none comes to mind, say so plainly. Then give the nearest thing your material carries, the SQL and Tableau skill you named, and how you would run an analysis you have not done. | F3 is low confidence. The material names tools, not an analysis, so the answer cannot be asserted from the tools alone. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [grounded] "both report to same VP" (your note); [generic] persona stem | Propose seam principles, not a claim that you know the seam: who sets the targets, who owns the forecast, who decides when two plans collide. Then say what you would bring to Dan's team, not only what you would need from it. Answer slot: a disagreement with an equal, and how it ended. If you have none to offer, describe the rule you would propose. | The persona's signature probe. A peer's first test is whether the hire adds to or reduces their load. JD because it scores cross-functional influence. |
| B2 | "How do you handle credit when work spans two teams?" | JD | [generic] persona stem; [grounded] "set annual volume targets with cross-org consensus" | Open prompt. Pick a time work spanned two teams and credit was at stake. Say what you did to put the other team's work first, and what you kept. If none comes to mind, say so plainly, then give the nearest thing your material carries, the cross-org targets, and say who got credit for what. | Peer evaluators probe credit-sharing. The nearest sentence in your material is the cross-org targets, which is why it is quoted here. |
| B3 | "Tell me about a time your number and a peer's number disagreed." | JD | [grounded] "set annual volume targets with cross-org consensus" | Open prompt, selection scaffold. A usable story needs the two numbers, the assumption that differed, and what was agreed. If the nearest is the target consensus, say who disagreed and what moved them, in your own words. If none of it was a disagreement, say so. | F5 is medium confidence: a consensus sentence with no record of the disagreement behind it. This question asks for that record. |
| B4 | "If I handed you a whitespace question tomorrow, what would you need from my team?" | CASE | [generic] | Ask for definitions before data: which account stage, which ARR, which decision the number serves. Name one thing you would bring to Dan's team. | A collegial test of partnership. It also reaches F2's requirement without a claim about your past. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our main competitive threat is bundling by a much larger platform vendor. How would you decide whether the new lines ship bundled or standalone?" | CO, CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Clarify what a bundle changes for the buyer and for Northwind. Objective: pick the metric. Segment: who buys the lines alone, and who already buys the platform. Approach: standalone where the buyer is distinct; bundle or attach where it is not. Metrics, and one risk: price pressure. Think aloud, and challenge one premise respectfully. No claim about your past. | Dan's pricing career makes bundling and packaging their native ground, and the note names it as the threat. Asked as a problem, it tests strategy, not history. |
| C2 | "Enterprise expansion is one of three stated priorities. Where is the expansion whitespace for a new product line?" | CO | [grounded] "enterprise expansion" (your research note) | Pick one account segment, one expansion trigger and one metric before listing anything. Name what you do not know yet, and what data would settle it. | Ties F2's whitespace requirement to the note's first priority. Using the note's own words is what makes the answer sound current. |
| C3 | "Compass is launching while we reach profitability. How does Compass change go-to-market for one of your lines?" | CO, CASE | [grounded] "an AI copilot launch ('Compass')"; [grounded] "reaching profitability" (your research note) | Name one trade-off: attaching Compass to a line, against protecting margin. Say which way you would call it, and what would change your mind. | Compass and profitability are two of the three priorities, and a trade-off between them is the altitude this round scores. The question makes no claim about the candidate. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "own GTM strategy for two new product lines" (JD); [grounded] "No classic sales-ops or quota-setting experience." (your message) | **Highest-ROI prep in this pack.** Name the weakest part yourself, first: "I haven't done classic sales-ops or quota-setting." Then the ramp: what you would do in your first 90 days to close it, and whom you would learn from. Answer slot on GTM ownership: say whether you have owned go-to-market for a product line. If you have, say which and what you decided. If not, say so, and say what carries over from product strategy. Hold through two follow-ups, then concede exactly the sales-ops point. | Follow-up 1, "How would you set a quota without having done it?" Answer: you would not set one alone. Name who would review your assumptions. Follow-up 2, "So why should I trust you with GTM ownership?" Hold: say what the product-strategy work and the revenue model show, and stop there. Concede: "I'd want a review of the first targets before I own them." Limit named: no claim of quota experience, and no claim of GTM ownership beyond what the quotes carry. F1 and F7 are the two gaps a peer pricing the hire will test first. This is the rubric's deepest rehearsal. |
| D2 | "Walk me through your first 90 days owning GTM for a new product line." | CASE | [grounded] "own GTM strategy for two new product lines" (JD) | A plan, not a past. First weeks on listening and sizing whitespace. Decision rights with Sales. An inventory of partner terms. The first number you would defend. Name one thing you would stop doing. | F1 is the requirement's gap. A plan lets judgment show without a claim about the past. |
| D3 | "What do you use AI tools for day to day, and what would you test first here?" | JD | [grounded] "AI experience a plus" (JD); [grounded] "uses AI tools daily" (your message) | Answer slot: say what you use AI tools for, in your own words. If that is all it is, say so. Then one GTM use you would test first, and how you would know it worked. | F6 is medium confidence on use alone. The plus-skill is asked directly here, so the answer stays at use. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should I trust a product-strategy person with go-to-market?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message); [grounded] "built partner-level revenue model used in carrier negotiations" (your message) | Hold: the product-strategy work and the partner revenue model are the evidence, stated as they are. Do not call the work go-to-market. Hold through two follow-ups. Concede the specific: "I haven't done classic sales-ops or quota-setting." Do not fold on the product-strategy claim to restore harmony. | A pressure interviewer tests whether you hold a position without going defensive. The position is one your quotes carry, and the concession is one you can name. |
| E2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold: "I proposed the change, and it was credited with the uplift." Concede specifically: if you do not know your share of the credit, say so plainly. Do not produce a share. | F8: the stake is the figure, and a held position is only as strong as the quote carries. Folding to a bigger share is the failure this question exists to catch. |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; [grounded] "9 at a large consumer-tech company in product strategy & ops"; [grounded] "built partner-level revenue model used in carrier negotiations" (all your message) | A 90-second arc: consulting, then consumer tech and product strategy and ops, then the partner revenue model. Stop before the $400M unless asked. Keep each beat at the scope its quote gives. | Casual openers are scored. A pre-scripted arc keeps the record straight and the answer economical. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message); [grounded] "AI experience a plus" (JD) | Same answer slot as D3, delivered casually: say what you use AI tools for, plainly. Do not overclaim. | The plus-skill, asked casually, is still scored. The register does not change what is being measured. |

## Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| "own GTM strategy for two new product lines" (JD) | D1, D2, E1 (F1) |
| "identify whitespace across land/adopt/expand/renew" (JD) | A4, C2 (F2) |
| "run independent analysis in SQL and Tableau" (JD) | A4, A5 (F3) |
| "partner-motion design experience required" (JD) | A1 (F4) |
| "strong cross-functional influence" (JD) | B1, B2, B3 (F5) |
| "AI experience a plus" (JD) | D3, G2 (F6) |
| Sales-ops and quota-setting (role-family expectation, [generic]; candidate's stated negative) | D1, E1 (F7) |
| Headline figures (your message) | A2, A3, E2 (F8) |

## Reverse questions

At least one ties to Dan's own path. One is a reciprocity question for a peer.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You went from pricing and monetization into a startup chapter. What did that change about how you choose which problems to work on?" | Ties to Dan's own path and turns an interview into a peer conversation. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity for a peer. Signals that you think about Dan's load, not just your own. |
| R3 | "Where do Sales Strategy and emerging-products GTM most often disagree: targets, forecast, or pricing?" | Asks for the seam directly. The answer shows where the work actually is. |
| R4 | "How is Compass changing the way pricing gets set for new lines?" | Combines Dan's pricing career with the note's Compass priority. |
| R5 | "Of the three priorities (enterprise expansion, Compass, reaching profitability), which one will your team's numbers be judged on this year?" | Shows you researched the company, and asks how success is measured. |

## Sources

- **Provided:** your message, covering candidate background, JD highlights, the Northwind research note and the interviewer profile notes. No full JD text, no CV document, no dossier.
- **Searches and fetches:** one search, "Northwind Data company values principles". Refused; nothing returned. No fetches.
- **Values cheat sheet:** omitted. No values-style round is detected. No loop source names one, and the single session is fixed by your note.

**Research tier: L1, searches 1 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The one call was refused. It would have moved the values cheat sheet, which is omitted because no values round is detected, and any values-themed question. |
| 2. Northwind Data interview process, senior GTM | skipped | Your note fixes the session count (one 60-minute conversation) and the interviewer (a peer). Those are the loop outputs this pack uses. |
| 3. Northwind strategy and recent news | skipped | Your pasted research note supplies the three priorities and the competitive threat for the CO bank. Its date is unknown and is flagged in the grounding brief. |
| 4. Dan Kovac, Northwind | unavailable | A name was given, so a query could be formed. The host refused the earlier search, and no further call was sent. Would have moved the interviewer read and one reverse question. |
| 5. Representative senior GTM JD | skipped | Your JD highlights fix the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Full JD text, or the posting pasted** → the six JD rows quote the posting rather than your highlights, and A4 and D2 firm up.
- **The recruiter's note on focus areas or any pre-declared deliverable** → coverage of that deliverable as its own build section.
- **Dan's public footprint, such as talks and posts** → an interviewer read and a reverse question built on what Dan has published. This needs a search the host refused this run.
- **The date of the Northwind research note** → confirms whether the CO bank is current. Older than about six months means refresh.
- **Location, travel or pay terms in the posting** → any such term becomes a gate row. None appears in your highlights, so none is asserted here.
- **A CV document** → the F rows gain a check against an inspectable artifact. The quotes stay as you wrote them.
- **Deep research (L2), on your word:** up to 6 more searches and 2 more fetches, several minutes. It adds a strategy brief, Dan's talks, role-family loop reports and recent org context.

---

Say the word and I'll play the Skeptic on D1, the question the pack names as its highest-ROI prep.
I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

1. Can you paste the full JD text? The highlights set the requirements, but the fit-snapshot quotes should come from the posting itself.
2. Did Dan or the recruiter name any focus areas, or a deliverable such as a presentation or take-home?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Northwind Data: Senior GTM Strategy Lead, Emerging Products

**Candidate:** Priya
**Interview:** single 60-minute conversation with Dan Kovac, Director of Sales Strategy. Peer: both report to the same VP.
**Built on:** your note (candidate background, JD highlights, Northwind research note, interviewer profile). No full JD text. No CV document. One search, refused, so no research beyond your note.
**Changelog:** first build.

## How to use this pack

- **Personas** describe how a question arrives: its tone and method.
- **Types** describe what is being scored: **JD** (a stated requirement), **EXP** (what you did, and how precisely you attribute it), **CO** (company and strategy knowledge), **CASE** (a live problem from the role), **VAL** (published values; none detected here).
- Guidance is scaffolding, not a script.
- An **answer slot** is an instruction for the interview. Answer it in your own words, from your own experience. If a practice was not yours, or did not happen, say so plainly.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD (your message) | "9 at a large consumer-tech company in product strategy & ops" — your message | medium | [grounded] | transferability | Your material shows product strategy and ops, not go-to-market ownership, so do not stretch it. Keep the scope: nine years, a large consumer-tech company, product strategy and ops. Answer slot: the JD's line makes a probe on your product decisions likely. Which product-strategy decisions were yours to set, and how did you decide? If none were yours, say so and describe how you worked on them. |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD (your message) | none given | none | [grounded] | discovery | Answer slot: if you have found whitespace across land, adopt, expand or renew, say where and how. If you have not, say so and say how you would find it first. |
| F3 | "run independent analysis in SQL and Tableau" — JD (your message) | "skilled in SQL/Tableau" — your message | low | [inferred] | presentation | Clarify-strategy note only, never an assertion: the quote names tools, not an analysis. Derivation: this pack's reading of a low-confidence quote. Answer slot: if you ran an analysis where the question, the data pull and the conclusion were yours, say which and what it changed. If you have not, say so and say what you would check first. |
| F4 | "partner-motion design experience required" — JD (your message) | "built partner-level revenue model used in carrier negotiations" — your message | medium | [grounded] | transferability | Words at the quote's scope: "I built a partner-level revenue model used in carrier negotiations." Limit, as this pack's observation: your material shows a model, not the design of a partner motion. Answer slot: which parts of the model were yours to set, and what it was built to answer. If any part was not yours, say so. |
| F5 | "strong cross-functional influence" — JD (your message) | "set annual volume targets with cross-org consensus" — your message | medium | [grounded] | presentation | Bridge rewords only this quote: "I set annual volume targets with cross-org consensus." Answer slot: who disagreed on those targets, and what got them to consensus. If no one disagreed, say so. |
| F6 | "AI experience a plus" — JD (your message) | "uses AI tools daily" — your message | medium | [grounded] | transferability | Words: "I use AI tools daily." Limit: this is use, not building anything with them. Answer slot: say what you use AI tools for, in your own words. If that is all it is, say so. |
| F7 | Role-family expectation: sales-ops or quota-setting for a GTM role — [generic] | "No classic sales-ops or quota-setting experience." — your message | none | [grounded] | capability | Words, from your own stated negative: "I haven't done classic sales-ops or quota-setting." Then a closure path, said as a plan and never as a past: how you would learn it, from whom, and what you would check first. |
| F8 | Headline figure the interviewer is likely to raise; no JD line — [generic] | "proposed a store-surface change credited with a ~$400M ARR uplift" — your message | medium | [grounded] | discovery | Words, at the quote's scope: "I proposed a store-surface change, and it was credited with a ~$400M ARR uplift." Answer slot (defend-the-number): how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you do not know how it was counted, say so plainly. |

## Prohibited claims

What this pack will not coach, and why. Built locally from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1: "own GTM strategy" widens "9 at a large consumer-tech company in product strategy & ops" | F1's quote at its own scope. Observation, in analysis only: the material shows product strategy and ops, not GTM ownership. A1 and D1 slots stay inside product strategy. |
| Designed the partner motion | Inflated form of F4: "built … model" widened to "designed" the motion | F4's quote. Observation: the material shows a model, not a motion's design. |
| Led cross-functional alignment | Inflated form of F5: "set targets with cross-org consensus" widened to leading the alignment | F5's quote. Observation: consensus on targets, not leading the effort. |
| Drove the ~$400M ARR uplift | Inflated form of F8: "proposed … credited with" widened to "drove" | F8's quote at its own scope. Defend-the-number slots apply. |
| Ran independent analysis in SQL and Tableau | Inflated form of F3: "skilled in SQL/Tableau" widened to a named analysis | Clarify-strategy note only. Never asserted. |
| Built AI products or features | Inflated form of F6: "uses AI tools daily" widened to building | F6's quote. Slots ask what you use them for. |
| Has done sales-ops or quota-setting | Negative you stated, F7 | Plain acknowledgment from F7: "I haven't done classic sales-ops or quota-setting." No slot. |

## Grounding brief

From your research note. The note is undated. If it is more than about six months old, refresh it before the interview.

- Stated priorities: "enterprise expansion"; "an AI copilot launch ('Compass')"; "reaching profitability" [grounded].
- Competitive frame: "main competitive threat is bundling by a much larger platform vendor" [grounded].
- Use these words as Northwind's own. Do not correct Dan's framing.

## Reading the interviewer

Source: your note. Nothing was checked against public sources this run, because the search was refused.

- **Career pattern:** pricing and monetization, with one early-stage-startup chapter. Self-described as "relentlessly data-driven."
- **Practical implications:**
  - The Prober persona rises. Expect every figure to be taken back to its assumptions.
  - Case questions tilt toward pricing, packaging and unit economics, which is Dan's native ground.
  - The startup chapter means builder stories land well, and expect probes on scrappiness.
  - As a peer, Dan will test the seam between the two teams and how disagreements are handled.
- **Mirror opportunity:** shared domain of monetization. Your partner revenue model (F4) is a fair vocabulary mirror. No shared career jump is known, so none is offered.

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Data-Driven Prober | Takes figures back to inputs, denominators and assumptions | Highest. Peer relationship prior plus a self-described data-driven interviewer | Know how each figure was counted, or say plainly you do not know. Name the weakest assumption first. | 5 |
| Peer Evaluator | Seam questions, disagreement with equals, credit-sharing, what the hire needs from them | High. Peer relationship prior; the hire's cost to Dan's team is the test | Propose seam principles, not a claim to know the seam. Say what you bring, not only what you need. | 4 |
| Case / Strategist | Live problem from the role or from Northwind's priorities | Medium. Pricing-led interviewer; the note's priorities and threat are the material | Clarify, then structure, then answer. Think aloud. | 3 |
| Skeptic | The GTM-ownership gap and the sales-ops gap | Medium. Your two real gaps are the likeliest objections | Name the weakest part yourself. Ramp plan. Calibrated candor. | 3 |
| Pressure / Stress | Time-boxed challenges on the $400M and on the product-strategy background | Lower. Peer register rarely escalates, but a data-driven peer can press | Hold through two follow-ups. Concede the specific, not the core. | 2 |
| Conversational / Rapport | Casual journey question, casual AI question | Lower, and easy to underrate. Casual questions are still scored | Pre-scripted 90-second arc. Treat AI as scored. | 2 |
| Values / Behavioral | Published-values probes | Not present. No values-style round is detected, so no bank | None. | 0 |

## Question banks

Types: JD, EXP, CO, CASE, VAL. Provenance comes first in each row.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the partner-level revenue model: what went in, and what came out." | EXP | [grounded] "built partner-level revenue model used in carrier negotiations" | Story-mapped on F4. Beats: you built the model, and it was used in carrier negotiations. The quote says it was used, not by whom, so say no more than that. Then inputs and outputs, named plainly. Answer slot: if any part was set by someone else, name the part and who set it. If you cannot describe an input, say so. | F4 is the closest evidence to the partner-motion requirement, and the likeliest place for a prober to start. EXP because it tests what was yours. |
| A2 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Defend-the-number, in your words: how it was counted; what it is sensitive to; the assumption you would defend least; which part was yours. Answer slot: if you did not see how it was counted, say so. You proposed the change, and it was credited with the uplift. Name the assumption before Dan does. | F8 is the headline figure most likely to be probed. The defend-the-number slots are the rehearsal every CV figure gets. |
| A3 | "Which assumption behind those annual volume targets would you defend least?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Defend-the-number on the targets: how they were set, the assumption you would defend least, and which part was yours. Answer slot: if you did not set the targets, or had no part in the assumption, say so. Do not improvise a method for setting them. | F5's consensus claim rests on a target figure. Probers ask for the assumptions behind targets as a matter of course. |
| A4 | "What would you query first to size expansion whitespace, and what would make you distrust the result?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew"; [grounded] "run independent analysis in SQL and Tableau" | Clarify "expansion" first: which accounts, which ARR. Then the grain, the denominator, the one assumption you would check first, and the result that would make you distrust the number. Speak to the logic of the query, not to a query you have run. No claim about your past. | F2 has no evidence. A live problem tests the requirement without asking for a past the material does not show. CASE, because it is a problem from the role, and a prober will follow up on the denominator. |
| A5 | "Tell me about an analysis you ran end to end: your question, your data, your conclusion." | EXP | [inferred] "skilled in SQL/Tableau". Low confidence: coaching note only. | Open prompt with a selection scaffold. Pick an analysis where the question, the data pull and the conclusion were yours, and say what it changed. If none comes to mind, say so plainly. Then give the nearest thing your material carries, the SQL and Tableau skill you named, and how you would run an analysis you have not done. | F3 is low confidence. The material names tools, not an analysis, so the answer cannot be asserted from the tools alone. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam, and what happens when we disagree?" | JD | [grounded] "both report to same VP" (your note); [generic] persona stem | Propose seam principles, not a claim that you know the seam: who sets the targets, who owns the forecast, who decides when two plans collide. Then say what you would bring to Dan's team, not only what you would need from it. Answer slot: a disagreement with an equal, and how it ended. If you have none to offer, describe the rule you would propose. | The persona's signature probe. A peer's first test is whether the hire adds to or reduces their load. JD because it scores cross-functional influence. |
| B2 | "How do you handle credit when work spans two teams?" | JD | [generic] persona stem; [grounded] "set annual volume targets with cross-org consensus" | Open prompt. Pick a time work spanned two teams and credit was at stake. Say what you did to put the other team's work first, and what you kept. If none comes to mind, say so plainly, then give the nearest thing your material carries, the cross-org targets, and say who got credit for what. | Peer evaluators probe credit-sharing. The nearest sentence in your material is the cross-org targets, which is why it is quoted here. |
| B3 | "Tell me about a time your number and a peer's number disagreed." | JD | [grounded] "set annual volume targets with cross-org consensus" | Open prompt, selection scaffold. A usable story needs the two numbers, the assumption that differed, and what was agreed. If the nearest is the target consensus, say who disagreed and what moved them, in your own words. If none of it was a disagreement, say so. | F5 is medium confidence: a consensus sentence with no record of the disagreement behind it. This question asks for that record. |
| B4 | "If I handed you a whitespace question tomorrow, what would you need from my team?" | CASE | [generic] | Ask for definitions before data: which account stage, which ARR, which decision the number serves. Name one thing you would bring to Dan's team. | A collegial test of partnership. It also reaches F2's requirement without a claim about your past. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Our main competitive threat is bundling by a much larger platform vendor. How would you decide whether the new lines ship bundled or standalone?" | CO, CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Clarify what a bundle changes for the buyer and for Northwind. Objective: pick the metric. Segment: who buys the lines alone, and who already buys the platform. Approach: standalone where the buyer is distinct; bundle or attach where it is not. Metrics, and one risk: price pressure. Think aloud, and challenge one premise respectfully. No claim about your past. | Dan's pricing career makes bundling and packaging their native ground, and the note names it as the threat. Asked as a problem, it tests strategy, not history. |
| C2 | "Enterprise expansion is one of three stated priorities. Where is the expansion whitespace for a new product line?" | CO | [grounded] "enterprise expansion" (your research note) | Pick one account segment, one expansion trigger and one metric before listing anything. Name what you do not know yet, and what data would settle it. | Ties F2's whitespace requirement to the note's first priority. Using the note's own words is what makes the answer sound current. |
| C3 | "Compass is launching while we reach profitability. How does Compass change go-to-market for one of your lines?" | CO, CASE | [grounded] "an AI copilot launch ('Compass')"; [grounded] "reaching profitability" (your research note) | Name one trade-off: attaching Compass to a line, against protecting margin. Say which way you would call it, and what would change your mind. | Compass and profitability are two of the three priorities, and a trade-off between them is the altitude this round scores. The question makes no claim about the candidate. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "own GTM strategy for two new product lines" (JD); [grounded] "No classic sales-ops or quota-setting experience." (your message) | **Highest-ROI prep in this pack.** Name the weakest part yourself, first: "I haven't done classic sales-ops or quota-setting." Then the ramp: what you would do in your first 90 days to close it, and whom you would learn from. Answer slot on GTM ownership: say whether you have owned go-to-market for a product line. If you have, say which and what you decided. If not, say so, and say what carries over from product strategy. Hold through two follow-ups, then concede exactly the sales-ops point. | Follow-up 1, "How would you set a quota without having done it?" Answer: you would not set one alone. Name who would review your assumptions. Follow-up 2, "So why should I trust you with GTM ownership?" Hold: say what the product-strategy work and the revenue model show, and stop there. Concede: "I'd want a review of the first targets before I own them." Limit named: no claim of quota experience, and no claim of GTM ownership beyond what the quotes carry. F1 and F7 are the two gaps a peer pricing the hire will test first. This is the rubric's deepest rehearsal. |
| D2 | "Walk me through your first 90 days owning GTM for a new product line." | CASE | [grounded] "own GTM strategy for two new product lines" (JD) | A plan, not a past. First weeks on listening and sizing whitespace. Decision rights with Sales. An inventory of partner terms. The first number you would defend. Name one thing you would stop doing. | F1 is the requirement's gap. A plan lets judgment show without a claim about the past. |
| D3 | "What do you use AI tools for day to day, and what would you test first here?" | JD | [grounded] "AI experience a plus" (JD); [grounded] "uses AI tools daily" (your message) | Answer slot: say what you use AI tools for, in your own words. If that is all it is, say so. Then one GTM use you would test first, and how you would know it worked. | F6 is medium confidence on use alone. The plus-skill is asked directly here, so the answer stays at use. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should I trust a product-strategy person with go-to-market?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (your message); [grounded] "built partner-level revenue model used in carrier negotiations" (your message) | Hold: the product-strategy work and the partner revenue model are the evidence, stated as they are. Do not call the work go-to-market. Hold through two follow-ups. Concede the specific: "I haven't done classic sales-ops or quota-setting." Do not fold on the product-strategy claim to restore harmony. | A pressure interviewer tests whether you hold a position without going defensive. The position is one your quotes carry, and the concession is one you can name. |
| E2 | "That $400M. How much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (your message) | Hold: "I proposed the change, and it was credited with the uplift." Concede specifically: if you do not know your share of the credit, say so plainly. Do not produce a share. | F8: the stake is the figure, and a held position is only as strong as the quote carries. Folding to a bigger share is the failure this question exists to catch. |

### G. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; [grounded] "9 at a large consumer-tech company in product strategy & ops"; [grounded] "built partner-level revenue model used in carrier negotiations" (all your message) | A 90-second arc: consulting, then consumer tech and product strategy and ops, then the partner revenue model. Stop before the $400M unless asked. Keep each beat at the scope its quote gives. | Casual openers are scored. A pre-scripted arc keeps the record straight and the answer economical. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message); [grounded] "AI experience a plus" (JD) | Same answer slot as D3, delivered casually: say what you use AI tools for, plainly. Do not overclaim. | The plus-skill, asked casually, is still scored. The register does not change what is being measured. |

## Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| "own GTM strategy for two new product lines" (JD) | D1, D2, E1 (F1) |
| "identify whitespace across land/adopt/expand/renew" (JD) | A4, C2 (F2) |
| "run independent analysis in SQL and Tableau" (JD) | A4, A5 (F3) |
| "partner-motion design experience required" (JD) | A1 (F4) |
| "strong cross-functional influence" (JD) | B1, B2, B3 (F5) |
| "AI experience a plus" (JD) | D3, G2 (F6) |
| Sales-ops and quota-setting (role-family expectation, [generic]; candidate's stated negative) | D1, E1 (F7) |
| Headline figures (your message) | A2, A3, E2 (F8) |

## Reverse questions

At least one ties to Dan's own path. One is a reciprocity question for a peer.

| # | Question | Why it lands |
|---|---|---|
| R1 | "You went from pricing and monetization into a startup chapter. What did that change about how you choose which problems to work on?" | Ties to Dan's own path and turns an interview into a peer conversation. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity for a peer. Signals that you think about Dan's load, not just your own. |
| R3 | "Where do Sales Strategy and emerging-products GTM most often disagree: targets, forecast, or pricing?" | Asks for the seam directly. The answer shows where the work actually is. |
| R4 | "How is Compass changing the way pricing gets set for new lines?" | Combines Dan's pricing career with the note's Compass priority. |
| R5 | "Of the three priorities (enterprise expansion, Compass, reaching profitability), which one will your team's numbers be judged on this year?" | Shows you researched the company, and asks how success is measured. |

## Sources

- **Provided:** your message, covering candidate background, JD highlights, the Northwind research note and the interviewer profile notes. No full JD text, no CV document, no dossier.
- **Searches and fetches:** one search, "Northwind Data company values principles". Refused; nothing returned. No fetches.
- **Values cheat sheet:** omitted. No values-style round is detected. No loop source names one, and the single session is fixed by your note.

**Research tier: L1, searches 1 of 6, fetches 0 of 2**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | The one call was refused. It would have moved the values cheat sheet, which is omitted because no values round is detected, and any values-themed question. |
| 2. Northwind Data interview process, senior GTM | skipped | Your note fixes the session count (one 60-minute conversation) and the interviewer (a peer). Those are the loop outputs this pack uses. |
| 3. Northwind strategy and recent news | skipped | Your pasted research note supplies the three priorities and the competitive threat for the CO bank. Its date is unknown and is flagged in the grounding brief. |
| 4. Dan Kovac, Northwind | unavailable | A name was given, so a query could be formed. The host refused the earlier search, and no further call was sent. Would have moved the interviewer read and one reverse question. |
| 5. Representative senior GTM JD | skipped | Your JD highlights fix the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- **Full JD text, or the posting pasted** → the six JD rows quote the posting rather than your highlights, and A4 and D2 firm up.
- **The recruiter's note on focus areas or any pre-declared deliverable** → coverage of that deliverable as its own build section.
- **Dan's public footprint, such as talks and posts** → an interviewer read and a reverse question built on what Dan has published. This needs a search the host refused this run.
- **The date of the Northwind research note** → confirms whether the CO bank is current. Older than about six months means refresh.
- **Location, travel or pay terms in the posting** → any such term becomes a gate row. None appears in your highlights, so none is asserted here.
- **A CV document** → the F rows gain a check against an inspectable artifact. The quotes stay as you wrote them.
- **Deep research (L2), on your word:** up to 6 more searches and 2 more fetches, several minutes. It adds a strategy brief, Dan's talks, role-family loop reports and recent org context.
