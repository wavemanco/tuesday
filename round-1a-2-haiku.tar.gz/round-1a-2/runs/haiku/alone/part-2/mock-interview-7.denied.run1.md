Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-7-denied-bf0ebae7/bc07eb9e-6700-4269-9266-434463145ad2/scratchpad/saltmarsh_live_operations_producer_interview_pack.md`. Two things to know first. I couldn't research Saltmarsh Games: all four web searches were refused because search permission isn't granted in this session, so the values, interview process and interviewer sections are missing. I also assumed Tobias is your hiring manager.

# Live Operations Producer, Saltmarsh Games: interview prep for Femi

**Company:** Saltmarsh Games (mobile, about 350 people). **Role:** Live Operations Producer. **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Relationship:** assumed hiring manager, not yet confirmed. **Round:** 60 minutes, format not stated.

## How to use + type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and stop where your material stops.

- **VAL**: behavioural and values. Not used: no values round detected.
- **EXP**: your own past work, checked for what was actually yours.
- **JD**: the listed job, including its gaps.
- **CO**: company knowledge. Not built: research did not run.
- **CASE**: a live problem from the role.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows weekly content drops on one title. That is adjacent to live events across two titles, so the bridge stays at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD names two titles, so expect a probe on how the calendar would work across them. If you ever planned for more than one title, say how; if you did not, say so and describe how you would split the work. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | discovery | [grounded] | discovery | Your material does not show coordinating those teams. Answer slot: if you coordinated any of them on a drop, say which and how, in your own words; if you did not, say so and describe how you would run one update across all four. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | discovery | Presenting numbers is not owning a review or choosing KPIs, so the bridge should not be stretched. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose a KPI or wrote a review after an event, say which and how; if you did not, say so and say what you would measure first. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches this requirement in role terms: you presented retention every month. Words: "Presented the monthly retention numbers to the studio head." Expect a probe on how the numbers were built; your material does not show that you built them. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | presentation | The years are met on the title you held. Keep the title as written and do not say "producer" for it. Whether a puzzle studio's weekly content drops count as live-service is for the interviewer to judge. Length of experience is not a gate, so this row is graded like any other. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Direct match. Expect a probe on the calendar itself, so know its cadence and who it served. |
| F7 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Direct match. Words: "I wrote the release checklist our QA team still uses." Expect a probe on what it covers. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [inferred] | presentation | A checklist a team still uses is written work that holds up over time. Your material shows one document, not written communication in general, so do not generalise from it. |
| F9 | "lead a team" (not in the JD; a likely probe) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Words: "I have never led a team." Then how you would coordinate without line authority, said as a plan and never as a past. |
| F10 | in-app purchases (not in the JD; a likely probe) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Words: "I have never worked on a game with in-app purchases." Then what you would do to learn the purchase side, said as a plan. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. Your material says one main title. |
| Owned the post-event review or chose its KPIs | Inflated form of F3 | F3's quote at its own scope. |
| Owned the retention figures | Inflated form of F4 | "Presented the monthly retention numbers to the studio head." |
| Producer title | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." |
| Led a team | Negative you stated (F9) | "I have never led a team." |
| Experience with in-app purchases | Negative you stated (F10) | "I have never worked on a game with in-app purchases." |

## Persona table

No interviewer profile and no loop source were found, so the weights use the hiring-manager prior and a fallback archetype, not this company's documented process.

| Persona | How it shows up here | Likelihood and reasoning | Weight (questions) | Counter-strategy |
|---|---|---|---|---|
| Skeptic | "Which part of this would you be weakest at?" on two titles, team leadership and purchases | High. A hiring manager derisks the gaps in F1, F2, F9 and F10 first | 5 | Rehearse the two-title and no-team-lead questions until they are plain; concede the gap, then give your plan |
| Case / Strategist | A live calendar plan and a retention diagnosis | High. The JD's first line and its retention requirement are live-problem material | 5 | Clarify, then objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | The retention numbers you presented, and the review's KPIs | Medium. The retention requirement and F3 invite a probe | 3 | Say what you presented; say plainly what you did not calculate |
| Pressure | A composure test on team leadership and the checklist | Medium. A 60-minute hiring-manager round sometimes tests composure | 2 | Hold the calendar and checklist through two follow-ups; concede the team gap once, plainly |
| Conversational | A journey opener and a "what have you played" question | Medium. Casual openers are scored too | 2 | A 90-second arc from your own sentences only |
| Values / Behavioral | Not weighted: no values round detected | Not detected | 0 | None |

Total: 17 questions, one under the usual floor of 18, because the missing research leaves fewer grounded angles.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role plans the live-events calendar for two titles. How would you run that, given what you have done?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the calendar you ran, at its scope: one main title, weekly, for two years. Then the honest branch: if you planned for more than one title, say how; if you did not, say so and set out how you would split the calendar across two: what you would plan first and what you would need from each team. Hold through two follow-ups by returning to the calendar you ran. **Highest-ROI prep in this pack:** the two-title line makes this question likely in some form. | F1 is the thinnest link to the headline requirement, and the JD's two-title line is its raising source. |
| A2 | "You have not led a team. This role coordinates four teams on every update. How do you get them moving without authority over them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say "I have never led a team" first. Then answer the coordination question as a plan: the mechanics you would use, such as a shared calendar, one named owner per update, and a checkpoint with each team. Answer slot: if you coordinated any of those teams on a drop, say which and how; if you did not, say so and stay with the plan. | F9 and F2 are the gaps this presses. |
| A3 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say "I have never worked on a game with in-app purchases." Then say what you would do to learn the purchase side, as a plan: who you would talk to and what you would read first. Claim no purchase knowledge. | F10. The question is generic because the JD does not raise purchases; the acknowledgment has its source. |
| A4 | "The role owns the post-event review and its KPIs. What is the closest you have come to that?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented and to whom, in those words. Answer slot: if you chose a KPI or wrote a review after an event, say which and how; if there was no such review, or it was not yours, say so and say what you would measure first after a live event. | F3 is the thin bridge. The question asks for the closest instance and presupposes no review, so the honest branch stays open. |
| A5 | "Why move from a puzzle studio to a role built around two live titles?" | EXP | [generic] | Selection scaffold: pick the honest reason, a specific piece of work you want to do next. If no reason comes to mind, say so plainly, then give the nearest thing your material carries: four years of weekly content drops. | No sentence in your material states a reason for moving. The "why now" probe is standard for a Skeptic. |

### B. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two titles, one live-events calendar, four teams. How would you plan next quarter? What do you need to know first?" | CASE | [generic] | Clarify first: which titles and their current retention, team capacity, QA windows, and how large each event is. Then objective, segmentation, approach, metrics, risks. Think aloud, and challenge one premise respectfully. | The JD's first line is the raising source. Generic, since it is a pattern for the problem, not a fact about this company. |
| B2 | "A live event launched last week, and day-7 retention on one title fell. Diagnose it." | CASE | [generic] | Clarify the baseline and what changed. Ask whether the drop started at launch or before it. Name the cohort you would check. Then say which post-event review you would run and what it would report. Keep to event content and player behaviour unless asked. | Covers the retention requirement and F3's KPI gap in one live problem. |
| B3 | "Design, art and engineering disagree on an event's scope eight days before release. How do you decide?" | CASE | [generic] | Name who owns the decision and the cost of each option in days. Cut scope before you cut QA time. Put the trade-off in writing for the leads. | Coordination is F2's gap. A live decision tests it without asking about your past. |
| B4 | "Walk me through the release checklist you wrote. What is on it?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Say what it covers, in your own words, and the one step you would add. Answer slot: if QA or others changed it, say who and how; if you cannot recall what is on it, say so. | F7 is direct. The question asks for content, so the answer shows whether the checklist is yours. |
| B5 | "What would your first 30 days look like in this role?" | JD | [generic] | Sequence it as plan: learn both calendars, sit in on a release with QA, meet the four team leads, run the first post-event review. Plan language only. | The Skeptic's day-one question, and F2 again. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were put together." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Describe your part in the presentation, at its own scope. Answer slot: if you calculated any part, say which; if you only presented them, say so and say where the definition came from. | F4. The question presupposes a method, so the second branch lets the method be someone else's. |
| C2 | "Which retention figure you presented would you defend least, and why?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Weakest-assumption move: name the assumption behind the figure you would defend least, in your words, before they do. If no figure comes to mind, say you would defend the definition first, not a number. | A figure raises the defend-the-number probe. You have stated none, so the move stays a slot. |
| C3 | "What population did the retention numbers you presented cover?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know the population, say it; if not, say so and say whose definition the numbers used. | The JD's retention requirement is the raising source. The question presupposes a population, so the honest branch stays open. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone who has never led a team over someone who has?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." · [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold-then-concede. Hold on the calendar you ran, and return to it through two follow-ups. Concede once, plainly: "I haven't led a team, and that's a real gap for this role." Do not fold on the calendar. | F9 is the gap, and F6 is the hold. The hold is what your material carries, no more. |
| D2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it, and QA still uses it." Concede only what others changed, and say plainly if you do not know. Answer slot: if QA revised it since, say what you know and what you wrote. | F7's attribution probe, in the Pressure register. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." · [grounded] "Presented the monthly retention numbers to the studio head." | A 90-second arc in order: the studio, the calendar, the checklist, the retention presentations. Use only these sentences, in your own words. | F5, F6 and F7 in order. Casual openers are scored too. |
| E2 | "What have you played from your catalogue, and what would you change?" | JD | [generic] | Name a title you have actually played, and one thing you noticed as a player, not as a critique. If you have not played them, say so and ask what they would want a new player to notice. | Tests whether you know the product. Generic, because research did not run. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B1 |
| Coordinate design, art, engineering and community teams | A2, B3 |
| Own the post-event review and the KPIs it reports | A4, B2 |
| Manage the release checklist with QA | B4, D2 |
| 3+ years producing live-service games or apps | E1 |
| Experience running a content calendar | E1, A1 |
| Comfortable with player-retention metrics | C1, C2, C3, B2 |
| Clear written communication | none, and why: no question tests writing. B4 covers the artifact only. |

## Reverse questions

Tobias's public profile was not found, so these are role-generic.

1. "What did the last live event teach the team, and what changed because of it?" Why it lands: it asks about the post-event review in practice.
2. "Who signs off a drop, and how far ahead is the calendar set?" Why it lands: it shows you are thinking about planning mechanics.
3. "Which of the two titles is more retention-sensitive right now?" Why it lands: it shows you want to prioritise, not just execute.
4. "Who owns the KPI definitions, and where are they written down?" Why it lands: it tests the KPI ownership the JD names.
5. "Where do purchase decisions sit relative to live events?" Why it lands: it finds the purchase scope before you are asked about it.
6. "What would success look like at 90 days?" Why it lands: it gives you a written outcome to plan against.

## Sources

**Provided documents:** the JD and your background, both in your message. No CV file was supplied.

**Searches:** four were sent and all were refused, because web search permission was not granted in this session. I did not retry them. Queries: "Saltmarsh Games values"; "Saltmarsh Games interview process live operations producer"; "Saltmarsh Games mobile studio"; "Tobias Wrenfield Saltmarsh Games Head of Live Operations". Nothing about the company or the interviewer is established beyond your message.

Research tier: L1 — searches 4 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet: not built. No values round was detected. |
| 2. Saltmarsh Games interview process | unavailable | Loop structure: not established. The fallback archetype applies, so persona weights rest on a hiring-manager prior, not this company's process. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Grounding brief and CO questions: not built. No call was sent for this target. |
| 4. Tobias Wrenfield with Saltmarsh Games | unavailable | Interviewer read and tailored reverse questions: not built. |
| 5. Representative Live Operations Producer JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Web search allowed in this session → company values, interview process and recent news, plus Tobias's public footprint: a values cheat sheet, CO questions grounded in current strategy, and a tailored reverse question.
- The recruiter's note on the round's format and focus areas → confirms one session or a panel, and reweights the banks.
- The release checklist, or a sample of it → F7 moves from a stated line to something you can show.
- The figures you presented, and their period → C1 to C3 get sharper. Any figure would be yours to state.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several minutes. It also needs search permission.
- A `tuesday-dossier.md` would add verified evidence to the fit rows.

---

I can also play Tobias for a live drill. I'd start with the Skeptic on A1, the two-title question the pack names as highest-ROI prep. And I can save a `tuesday-dossier.md` recording the gaps this prep exposed, so later sessions start from them.

Would Tobias be your manager, and did the recruiter say what the 60 minutes will cover?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep for Femi

**Company:** Saltmarsh Games (mobile, about 350 people). **Role:** Live Operations Producer. **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Relationship:** assumed hiring manager, not yet confirmed. **Round:** 60 minutes, format not stated.

## How to use + type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script: say it in your own words, and stop where your material stops.

- **VAL**: behavioural and values. Not used: no values round detected.
- **EXP**: your own past work, checked for what was actually yours.
- **JD**: the listed job, including its gaps.
- **CO**: company knowledge. Not built: research did not run (see Sources).
- **CASE**: a live problem from the role.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows weekly content drops on one title. That is adjacent to live events across two titles, and the bridge stays at that scope: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD names two titles, so expect a probe on how the calendar would work across them. If you ever planned for more than one title, say how; if you did not, say so and describe how you would split the work. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | discovery | [grounded] | discovery | Your material does not show coordinating those teams. Answer slot: if you coordinated any of them on a drop, say which and how, in your own words; if you did not, say so and describe how you would run one update across all four. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | low | [inferred] | discovery | Presenting numbers is not owning a review or choosing KPIs, and the bridge should not be stretched. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose a KPI or wrote a review after an event, say which and how; if you did not, say so and say what you would measure first. |
| F4 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | presentation | The quote reaches this requirement in role terms: you presented retention every month. Words: "Presented the monthly retention numbers to the studio head." Expect a probe on how the numbers were built; your material does not show that you built them. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | presentation | The years are met on the title you held. Keep the title as written: "4 years as an associate producer at a puzzle-game studio." Do not say "producer" for it. Whether a puzzle studio's weekly content drops count as live-service is for the interviewer to judge. Length of experience is not a gate, so this row is graded like any other. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | Direct match. Words: as quoted. Expect a probe on the calendar itself, so know its cadence and who it served. |
| F7 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | none | Direct match. Words: "I wrote the release checklist our QA team still uses." Expect a probe on what it covers. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [inferred] | presentation | A checklist a team still uses is written work that holds up over time. Your material shows one document, not your written communication in general, so do not generalise from it. |
| F9 | "lead a team" (not in the JD; a likely probe) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Words: "I have never led a team." Then how you would coordinate without line authority, said as a plan and never as a past. |
| F10 | in-app purchases (not in the JD; a likely probe) | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Words: "I have never worked on a game with in-app purchases." Then what you would do to learn the purchase side, said as a plan. |

## Prohibited claims

Not coached, and why. Each entry names its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live events across two titles | Inflated form of F1 | F1's quote at its own scope. Your material says one main title. |
| Owned the post-event review or chose its KPIs | Inflated form of F3 | F3's quote at its own scope. |
| Owned the retention figures | Inflated form of F4 | "Presented the monthly retention numbers to the studio head." |
| Producer title | Inflated form of F5 | "4 years as an associate producer at a puzzle-game studio." |
| Led a team | Negative you stated (F9) | "I have never led a team." |
| Experience with in-app purchases | Negative you stated (F10) | "I have never worked on a game with in-app purchases." |

## Persona table

No interviewer profile and no loop source were found, so the weights use the hiring-manager prior and the fallback archetype, not this company's documented process. Depth follows weight.

| Persona | How it shows up here | Likelihood and reasoning | Weight (questions) | Counter-strategy |
|---|---|---|---|---|
| Skeptic | "Which part of this would you be weakest at?" on two titles, team leadership and purchases | High. A hiring manager derisks the gaps in F1, F2, F9 and F10 first | 5 | Rehearse the two-title and no-team-lead questions until they are plain; concede the gap, then give your plan |
| Case / Strategist | A live calendar plan and a retention diagnosis | High. The JD's first line and its retention requirement are live-problem material | 5 | Clarify, then objective, segmentation, approach, metrics, risks; think aloud |
| Data-Driven Prober | The retention numbers you presented, and the review's KPIs | Medium. The retention requirement and F3 invite a probe | 3 | Say what you presented; say plainly what you did not calculate |
| Pressure | A composure test on team leadership and on the checklist | Medium. A 60-minute hiring-manager round sometimes tests composure | 2 | Hold the calendar and checklist through two follow-ups; concede the team gap once, plainly |
| Conversational | A journey opener and a "what have you played" question | Medium. Casual openers are scored too | 2 | A 90-second arc from your own sentences only |
| Values / Behavioral | Not weighted: no values round was detected | Not detected | 0 | None |

Total: 17 questions. That is under the usual floor of 18 because the research gaps leave fewer grounded angles than a full pack would have.

## Question banks

### A. Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "The role plans the live-events calendar for two titles. How would you run that, given what you have done?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Start with the calendar you ran, at its scope: one main title, weekly, for two years. Then the honest branch: if you planned for more than one title, say how; if you did not, say so and set out how you would split the calendar across two: what you would plan first and what you would need from each team. Hold through two follow-ups by returning to the calendar you ran. **Highest-ROI prep in this pack:** the two-title line makes this question likely in some form. | F1 is the thinnest link to the headline requirement, and the JD's two-title line is its raising source. JD because it scores the listed job. |
| A2 | "You have not led a team. This role coordinates four teams on every update. How do you get them moving without authority over them?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say "I have never led a team" first. Then answer the coordination question as a plan: the mechanics you would use, such as a shared calendar, one named owner per update, and a checkpoint with each team. Answer slot: if you coordinated any of those teams on a drop, say which and how, in your own words; if you did not, say so and stay with the plan. | F9 and F2 are the gaps this question presses. JD because the coordination line is in the listed job. |
| A3 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." | Say "I have never worked on a game with in-app purchases." Then say what you would do to learn the purchase side, as a plan: who you would talk to and what you would read first. Claim no purchase knowledge. | F10 is the gap. The question is generic: the JD does not raise purchases, so the question carries a generic label, and the acknowledgment has its source. |
| A4 | "The role owns the post-event review and its KPIs. What is the closest you have come to that?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented and to whom, in those words. Answer slot: if you chose a KPI or wrote a review after an event, say which and how; if there was no such review, or it was not yours, say so and say what you would measure first after a live event. | F3 is the thin bridge. The question asks for the closest instance and presupposes no review, so the honest branch stays open. |
| A5 | "Why move from a puzzle studio to a role built around two live titles?" | EXP | [generic] | Selection scaffold: pick the honest reason, a specific piece of work you want to do next. If no reason comes to mind, say so plainly, then give the nearest thing your material carries: four years of weekly content drops. | No sentence in your material states a reason for moving. The "why now" probe is standard for a Skeptic. |

### B. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Two titles, one live-events calendar, four teams. How would you plan next quarter? What do you need to know first?" | CASE | [generic] | Clarify first: which titles and their current retention, team capacity, QA windows, and how large each event is. Then objective, segmentation, approach, metrics, risks. Think aloud, and challenge one premise respectfully. | The JD's first line is the raising source. Generic, because the question is a pattern for the problem, not a fact about this company. |
| B2 | "A live event launched last week, and day-7 retention on one title fell. Diagnose it." | CASE | [generic] | Clarify the baseline and what changed. Ask whether the drop started at launch or before it. Name the cohort you would check. Then say which post-event review you would run and what it would report. Keep to event content and player behaviour unless asked. | Covers the retention requirement and F3's KPI gap in one live problem. |
| B3 | "Design, art and engineering disagree on an event's scope eight days before release. How do you decide?" | CASE | [generic] | Name who owns the decision and the cost of each option in days. Cut scope before you cut QA time. Put the trade-off in writing for the leads. | Coordination is F2's gap. A live decision tests it without asking about your past. |
| B4 | "Walk me through the release checklist you wrote. What is on it?" | JD | [grounded] "Wrote the release checklist our QA team still uses." | Say what it covers, in your own words, and the one step you would add. Answer slot: if QA or others changed it, say who and how; if you cannot recall what is on it, say so. | F7 is direct. The question asks for content, so the answer shows whether the checklist is yours. |
| B5 | "What would your first 30 days look like in this role?" | JD | [generic] | Sequence it as plan: learn both calendars, sit in on a release with QA, meet the four team leads, run the first post-event review. Plan language only. | The Skeptic's day-one question, and F2 again. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were put together." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Describe your part in the presentation, at its own scope. Answer slot: if you calculated any part, say which; if you only presented them, say so and say where the definition came from. | F4. The question presupposes a method, so the second branch lets the method be someone else's. |
| C2 | "Which retention figure you presented would you defend least, and why?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Weakest-assumption move: name the assumption behind the figure you would defend least, in your words, before they do. If no figure comes to mind, say you would defend the definition first, not a number. | A figure raises the defend-the-number probe. You have stated none, so the move stays a slot. |
| C3 | "What population did the retention numbers you presented cover?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: if you know the population, say it; if not, say so and say whose definition the numbers used. | The JD's retention requirement is the raising source. The question presupposes a population, so the honest branch stays open. |

### D. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire someone who has never led a team over someone who has?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." · [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold-then-concede. Hold on the calendar you ran, and return to it through two follow-ups. Concede once, plainly: "I haven't led a team, and that's a real gap for this role." Do not fold on the calendar. | F9 is the gap, and F6 is the hold. The hold is what your material carries, no more. |
| D2 | "That checklist. How much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Hold: "I wrote it, and QA still uses it." Concede only what others changed, and say plainly if you do not know. Answer slot: if QA revised it since, say what you know and what you wrote. | F7's attribution probe, in the Pressure register. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." · [grounded] "Presented the monthly retention numbers to the studio head." | A 90-second arc in order: the studio, the calendar, the checklist, the retention presentations. Use only these sentences, in your own words. | F5, F6 and F7 in order. Casual openers are scored too. |
| E2 | "What have you played from your catalogue, and what would you change?" | JD | [generic] | Name a title you have actually played, and one thing you noticed as a player, not as a critique. If you have not played them, say so and ask what they would want a new player to notice. | Tests whether you know the product. Generic, because research did not run. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two titles | A1, B1 |
| Coordinate design, art, engineering and community teams | A2, B3 |
| Own the post-event review and the KPIs it reports | A4, B2 |
| Manage the release checklist with QA | B4, D2 |
| 3+ years producing live-service games or apps | E1 |
| Experience running a content calendar | E1, A1 |
| Comfortable with player-retention metrics | C1, C2, C3, B2 |
| Clear written communication | none, and why: no question tests writing. B4 covers the artifact only. |

## Reverse questions

Tobias's public profile was not found, so these are role-generic. None ties to his career path.

1. "What did the last live event teach the team, and what changed because of it?" Why it lands: it asks about the post-event review in practice.
2. "Who signs off a drop, and how far ahead is the calendar set?" Why it lands: it shows you are thinking about the planning mechanics.
3. "Which of the two titles is more retention-sensitive right now?" Why it lands: it shows you want to prioritise, not just execute.
4. "Who owns the KPI definitions, and where are they written down?" Why it lands: it tests the KPI ownership the JD names.
5. "Where do purchase decisions sit relative to live events?" Why it lands: it finds the purchase scope before you are asked about it.
6. "What would success look like at 90 days?" Why it lands: it gives you a written outcome to plan against.

## Sources

**Provided documents:** the JD and your background, both in your message. No CV file was supplied.

**Searches:** four were sent and all were refused, because web search permission was not granted in this session. I did not retry them. The queries were: "Saltmarsh Games values"; "Saltmarsh Games interview process live operations producer"; "Saltmarsh Games mobile studio"; "Tobias Wrenfield Saltmarsh Games Head of Live Operations". Nothing about the company or the interviewer is established beyond your message.

Research tier: L1 — searches 4 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet: not built. No values round was detected. |
| 2. Saltmarsh Games interview process | unavailable | Loop structure: not established. The Generic archetype is the fallback, so the persona weights rest on a hiring-manager prior, not this company's process. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Grounding brief and CO questions: not built. No call was sent for this target, because search was refused for the others. |
| 4. Tobias Wrenfield with Saltmarsh Games | unavailable | Interviewer read and tailored reverse questions: not built. |
| 5. Representative Live Operations Producer JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Web search allowed in this session → company values, interview process and recent news, plus Tobias's public footprint: a values cheat sheet, CO questions grounded in current strategy, and a tailored reverse question.
- The recruiter's note on the round's format and focus areas → confirms one session or a panel, and reweights the banks.
- The release checklist, or a sample of it → F7 moves from a stated line to something you can show.
- The figures you presented, and their period → C1 to C3 get sharper. Any figure would be yours to state.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several minutes. It also needs search permission.
- A tuesday-dossier.md would add verified evidence to the fit rows.
