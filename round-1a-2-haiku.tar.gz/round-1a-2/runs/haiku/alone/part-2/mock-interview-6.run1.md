I can't search the web in this session (the permission was refused), so the pack rests on your message and the role summary. I'll write it that way, with the gaps marked, and save it to the scratchpad.
Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-6-denied-f3f4379e/ec5cf029-ab95-44db-b6da-00968e1190da/scratchpad/larkfield-systems_engineering-manager_interview_pack.md`. It covers all three rounds: a shared fit snapshot, then a question bank, persona weights and reverse questions for each.

I built it from your message and the role summary alone. Web search was refused in this session, so the pack has nothing on Larkfield's values, interview process or strategy. The round C values angle therefore runs on the recruiter's wording and your own stories.

The two gaps you named are the centre of the prep:
- **Managing managers (A2):** the highest-ROI rehearsal. Hold the team-of-six claim, concede the gap in plain words, then give a plan.
- **Hardware roadmap (A1, B7):** the same pattern. The honest answer is the acknowledgment plus a ramp plan, not a claimed past.

The 60% on-call figure gets defend-the-number questions in all three rounds (A6, B3, C6), so be ready to say how it was counted and which part was yours.

I can also run a drill on A2, the managers question. Say the word and I'll play the Director. I can save a `tuesday-dossier.md` recording the gaps this prep exposed, and convert the pack to Word if you want it.

Two things would sharpen the pack:
1. Can you paste the full job posting, or the recruiter's exact text? That turns the summary-based requirement rows into quoted lines and lets me check every requirement is covered.
2. Does the posting or recruiter state a location, on-site or lab-day pattern, or travel? If it does, I'll surface it as a gate rather than try to bridge it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield-systems_engineering-manager_interview_pack.md -----
# Larkfield Systems, Engineering Manager: interview prep pack

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people). Lead two squads building device-management services; own delivery, hiring and growth for 11 engineers; partner with hardware and product on roadmap.
**Rounds (loop mode, three sessions):**
- **A.** Tuesday, 45 min, Director of Engineering. Hiring manager and your prospective boss.
- **B.** The Thursday after, 60 min panel: two staff engineers and a product manager.
- **C.** The following Monday, 30 min, VP Engineering. The recruiter describes it as "values and leadership philosophy".

**Built on:** your message and the role summary you gave. No full job posting, no company values page and no strategy material were available, so nothing about Larkfield itself is drawn from outside your inputs. Sources section shows why.

## How to use + type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding, not a script. Rehearse the shape, then say it in your own words.

- **VAL**: values and behavioral. Whether past behavior shows the company's published values (none are in hand, so round C uses the recruiter's wording).
- **EXP**: experience deep-dive. Whether your claims survive scrutiny and what was actually yours.
- **JD**: role-driven. Whether you can do the listed job, including its gaps.
- **CO**: company and strategy knowledge. No CO bank: no strategy material was available.
- **CASE**: a live problem. Structure and reasoning, delivered live.

An **answer slot** is an instruction for the interview. It is not a question to answer here, and it has two honest branches: you did it and say how, or it was not yours or did not happen, and you say so plainly.

## The fit snapshot

Each requirement is quoted from your role summary, or marked as a gap. Evidence is quoted from your message only.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (your message, role summary) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material shows one team of six, led for three years. Words: "For three years I was team lead of six." Answer slot: if you have led more than one team at once, say how; if not, say so, and describe how you would split two squads. |
| F2 | "own delivery" (your message, role summary) | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | none | The quote reaches delivery ownership in the role's terms: a quarter pushed through against competing demands. Words: "I pushed a reliability quarter through against roadmap pressure." Expect a probe on the figure in F3. |
| F3 | "own delivery" (your message, role summary) | "My team's on-call burden dropped 60%" (your message) | medium | [grounded] | discovery | The figure has nothing inspected behind it, and how it was counted is not in your material. Answer slot: say how the 60% was counted, which assumption you would defend least, and which part of the quarter was yours. If you do not know how it was counted, say so and say what you would check. Never supply a baseline. |
| F4 | "own delivery, hiring and growth for 11 engineers" (your message, role summary), hiring part | "I run our hiring loop for backend roles" (your message); "about 40 interviews last year" (your message) | medium | [grounded] | none | The quote reaches hiring in the role's terms. The role does not say which disciplines the 11 engineers are, so expect a question on that. Words: "I run our hiring loop for backend roles, about 40 interviews last year." The 40 raises the defend-the-number slots in F3: how it was counted, the assumption you would defend least, which part was yours. |
| F5 | "hiring and growth for 11 engineers" (your message, role summary), growth part | none given | none | [grounded] | discovery | Your message says nothing about growing engineers. Answer slot: if you have grown an engineer into a bigger role, say who and what you did; if not, say so and describe what you would do in their first 90 days, as a plan. |
| F6 | "partner with hardware and product on roadmap" (your message, role summary), hardware part | "I've never owned a hardware-adjacent roadmap" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn the hardware constraints, said as a plan and never as a past. Nothing added to make the gap smaller. |
| F7 | "partner with hardware and product on roadmap" (your message, role summary), product part | "pushed a reliability quarter through against roadmap pressure" (your message) | medium | [grounded] | transferability | The roadmap pressure is the adjacent work. Words: the quote, at its own scope. Answer slot: if product was a partner in that quarter, say how the decision was made; if it was decided without them, or they were not involved, say so. |
| F8 | Leading the 11 engineers may mean leading other leads ([generic]: not in your role summary) | "I've never managed managers" (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never managed managers." Then the plan for structuring two squads, as a plan. Whether the role has leads under you is not in your inputs; the upgrade menu asks. |
| F9 | Location and on-site pattern, travel ([generic]: not in your message or role summary) | none given | none | [generic] | hard_gate | Your material does not establish whether the role needs on-site or lab days, or a location. If the posting sets one, it is a gate: surfaced, never bridged. Step 1 (d) asks whether it is met. |

**Routing notes.** F9 is a gate the material is silent on, so it is surfaced, not bridged. F6 and F8 are gaps you stated, so their words are the plain acknowledgment. F1, F3 and F5 are the rows that carry answer slots.

## Requirement coverage

| Requirement (source) | Question IDs |
|---|---|
| "Lead two squads building device-management services" | A1, A2, A3, A4, B5, B6, C7 |
| "own delivery" | A6, B3, B4, C5, C6 |
| "hiring" (part of "hiring and growth for 11 engineers") | A5, C4 |
| "growth" (part of "hiring and growth for 11 engineers") | A7 |
| "partner with hardware and product on roadmap" | A1, B2, B5, B7, C7 |
| Leading leads ([generic], F8) | A2, A8 |
| Location and on-site pattern (F9, hard gate) | none, and why: a gate, surfaced in F9; the pack cannot coach around it |

## Prohibited claims

Built locally from the fit snapshot, before the banks. Nothing in any answer, slot, hold or reverse question may assert, soften or imply these.

| Not coached | Basis | Honest form |
|---|---|---|
| Has managed managers | F8, your stated negative | "I've never managed managers." Plain acknowledgment, no slot. |
| Owned a hardware-adjacent roadmap | F6, your stated negative | "I haven't owned a hardware-adjacent roadmap." Plain acknowledgment, no slot. |
| Led two squads, or ran two teams | Inflated form of F1 | "For three years I was team lead of six." Your material shows one team. The limit is this pack's observation, not a line for you to say. |
| Designed the reliability plan, or owned the reliability programme | Inflated form of F2 and F3 | "I pushed a reliability quarter through against roadmap pressure." The answer slots stay on what was yours. |
| Set the hiring bar, or built the hiring process | Inflated form of F4 | "I run our hiring loop for backend roles." C4's slot asks whose bar it was. |

Not listed: growing engineers into bigger roles. Your material is silent on it, so it is an answer slot (F5), not a prohibition.

## Persona weights by round

Depth follows weight. The loop-mode bank is eight questions per round, so the top persona gets three, mid-weight two, low-weight one. Every plausible persona is touched.

### Round A: Director of Engineering (Tuesday, 45 min)

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| Case/Strategist | 3 | Hiring managers buy capability and test it on their actual roadmap (A3, A4, A5) | Clarify, then structure, then answer; say your assumptions aloud |
| Skeptic | 2 | The managers and hardware gaps (F6, F8) are the objections they will test (A1, A2) | Rehearse the objection until it is boring; concede the gap in your own words, then give the plan |
| Data-Driven Prober | 2 | The 60% and the 40 interviews are headline figures (A6, A7) | Say how each figure was counted, or that you do not know |
| Pressure | 1 | A time-boxed composure check (A8) | Pause, restate, hold the position through two follow-ups, then concede the specific gap |

Conversational appears only in the reverse-question stage. Values/behavioral is round C's job.

### Round B: Staff engineers and product manager (Thursday, 60 min)

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | 2 | The staff engineers price what you add to their work (B2, B8) | Offer seam principles, not claimed knowledge of their seam |
| Data-Driven Prober | 2 | Staff engineers test the reliability work in depth (B3, B4) | Name the weakest assumption before they do |
| Case/Strategist | 2 | The product manager tests roadmap trade-offs (B5, B6) | Clarify the constraint, then give options with trade-offs named |
| Skeptic | 1 | The hardware gap, raised from the product side (B7) | Plain acknowledgment, then the plan |
| Conversational | 1 | The opener is scored too (B1) | A ninety-second arc you can tell without notes |

### Round C: VP Engineering (Monday, 30 min)

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| Values/Behavioral | 3 | The recruiter named this round "values and leadership philosophy" (C1 to C4) | Map a story only where a quoted sentence carries it; otherwise a selection scaffold with its honest branch |
| Pressure | 2 | A skip-level, time-boxed, composure check (C5, C6) | Hold a real position through two follow-ups; concede specifically |
| Case/Strategist | 1 | Altitude: where strategy stops and roadmap starts (C7) | Name the decision and who should own it |
| Skeptic | 1 | The managers gap, at altitude (C5) | Concede plainly; stay with the plan |

## Question banks

### Round A: Director of Engineering

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap"; [grounded] "pushed a reliability quarter through against roadmap pressure" | Name the hardware gap in your own words: "I haven't owned a hardware-adjacent roadmap." Then your closest adjacent sentence: "I pushed a reliability quarter through against roadmap pressure." Then a ramp plan, said as a plan: how you would learn the hardware team's constraints from their own release cadence. Keep it under ninety seconds. | F6 and F7. Their question is open, so the hardware gap is the likeliest answer you will need to give. |
| A2 | "You haven't managed managers. How would you run two squads if each one needs a lead?" | JD | [grounded] "I've never managed managers"; [grounded] "3 as a team lead of 6" | **Highest-ROI prep in this pack.** Hold: "For three years I was team lead of six." Concede specifically: "I've never managed managers." Hold through two follow-ups by returning to the team of six, then concede the one skill you have not used yet. Then the plan, as a plan: what you would do first with two leads. Answer slot: if you have worked through someone else's lead, say how; if not, say so. | F8 and F1. The title change is the objection they will raise first, and the rehearsed honest answer is the one that changes the interview. |
| A3 | "The two squads disagree on priority: one wants hardware-facing features, the other reliability work. How do you decide?" | CASE | [generic] | Clarify each squad's commitments and the hardware dates first. Set decision criteria out loud. Decide, and say how you would tell both squads. Make no claim about your past. | A live problem from the role's two squads and its hardware partner. [generic]: a pattern for the problem, not a fact about Larkfield. |
| A4 | "A firmware update raised offline-reconnect failures on devices by 20%. Which squad takes it, and what happens in the first week?" | CASE | [generic] | Clarify scope: which devices, which firmware. Contain first, root-cause second. Bring hardware and product in on the same day. Define what success looks like before you start. | Device-management domain, a live problem. Makes no claim about your past. |
| A5 | "Plan hiring for the 11 engineers over the next twelve months. What do you need to know first?" | JD | [grounded] "I run our hiring loop for backend roles" | Ask before planning: which disciplines the 11 are, which squads need people, what attrition looks like, and how much loop capacity exists. Then sketch the plan, anchored only on the loop you run. | F4. Hiring is the role's named responsibility; the question is a live plan, so CASE delivery. |
| A6 | "Walk me through how the 60% on-call reduction was counted." | EXP | [grounded] "My team's on-call burden dropped 60%" | Defend the number in your own words: how it was counted, the assumption you would defend least (name it before they do), and which part was yours. Answer slot: if you cannot say how it was counted, say so and say what you would check first. | F3, the headline figure. This is the defend-the-number slot, and an unrehearsed answer here is where interviews go wrong. |
| A7 | "Tell me about an engineer who moved up on your team. What did you do, and what did they do?" | JD | [generic] | Open prompt. Pick a time an engineer on your team took on more. If none comes to mind, say so plainly, then describe how you would grow an engineer in their first 90 days, as a plan. | F5 and the growth half of the role. No question covered it until now. [generic]: no entity-specific claim. |
| A8 | "Sixty seconds: why should we hire you over someone who has already managed managers?" | JD | [grounded] "I've never managed managers"; [grounded] "3 as a team lead of 6" | Pressure form. Pause and restate. Hold the team of six for three years, and the reliability quarter, in their quoted terms. Concede: "I've never managed managers." Hold through two follow-ups; do not fold the team-of-six claim. | F8 and F1. Time-boxed, so it tests composure as much as content. |

**Reverse questions, Round A** (each with its reason)

- "What would the first six months look like for the person in this seat, and what would make you say it went wrong?" Lands: it surfaces their success criteria, so you can meet them.
- "Which of the two squads is further behind right now, and what is holding it?" Lands: it shows you think in terms of delivery.
- "How are hardware-facing roadmap calls made today, and where would this role sit in them?" Lands: it tests the partnership line directly, from the side that decides.
- "What is the hiring plan for the next year, and which roles are hardest to fill?" Lands: it shows you are ready to own hiring.
- "What did the last person in this role leave undone?" Lands: it names the real job.

### Round B: Staff engineers and product manager

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "So, walk me through the journey to here." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" | A ninety-second arc: nine years, three as team lead of six, the payments company, the hiring loop, the reliability quarter. Tell it in your own words and end on the reliability quarter, because that is the story this panel will test. | F1, F2 and F4. Casual register, scored all the same. |
| B2 | "Where is the seam between your squads and the device-side teams, and what happens when you disagree?" | JD | [grounded] "partner with hardware and product on roadmap" | Offer seam principles: who decides what, and how disagreement escalates. Do not pretend to know their seam. Answer slot: if you have disagreed with an equal on a shared system, say how it was settled; if not, say so and give the principle you would use. | F7. Peer register: the seam is where hardware and software collide. |
| B3 | "You say on-call burden dropped 60%. What does that measure leave out?" | EXP | [grounded] "My team's on-call burden dropped 60%" | Name the weakest assumption first: what the measure does not capture. Then how it was counted, and which part was yours. Answer slot: if you cannot say how it was counted, say so. | F3. Staff engineers count pages, so the weakest-assumption move matters most here. |
| B4 | "Walk me through the reliability quarter: what was the roadmap pressure, and how did you hold the quarter?" | EXP | [grounded] "pushed a reliability quarter through against roadmap pressure" | The beats the quote states: the roadmap pressure, the quarter, the push through it. Answer slot: if a decision point was yours, say which and how you decided it; if it was made above you or with others, say so. | F2. The attribution test: what was actually yours. |
| B5 | "Product wants a feature that hardware cannot ship until next quarter. What do you do first?" | CASE | [generic] | Clarify the dependency and the customer cost. Separate what can ship on current firmware. Put the options to product with the trade-off named. Decide with a date. | F7 and the role's partnership line. A PM's native ground; [generic] pattern. |
| B6 | "A firmware release slips six weeks and two squads depend on it. Plan the next quarter." | CASE | [generic] | Structure: what each squad can finish without it, what to cut, which dependency to unblock first, and what the customer hears. Name the assumption you are making about the slip. | Live CASE on the role's two squads. Makes no claim about your past. |
| B7 | "You haven't owned a hardware-adjacent roadmap. Which hardware-facing decision would you be least able to judge?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap" | Plain acknowledgment: "I haven't owned a hardware-adjacent roadmap." Then name the decision type you would need to learn, as a plan. Never claim you have judged one. | F6, asked from the product side. Rehearse it separately: it comes from a different interviewer. |
| B8 | "What is the hardest technical trade-off a team you have led has made?" | EXP | [grounded] "3 as a team lead of 6" | Open prompt. Pick one trade-off, name the two options, what you chose and why. If none comes to mind, say so, then give the nearest one from the reliability quarter. | F1. Peer register; a trade-off story is what peers listen for. |

**Reverse questions, Round B**

- "What could a new person do in their first month that would genuinely help your team?" Lands: a reciprocity question from peers. It turns an interview into a working conversation.
- "Where do the device-side and software teams disagree most often, and how does it get settled?" Lands: it shows you are already thinking about the seam.
- "Which roadmap call from the last two quarters would you most want to have made differently?" Lands: it invites candor, and product managers tend to answer it.
- "What would make the reliability work stick after it was delivered?" Lands: it ties to your strongest story and invites a second round of detail.
- "When a staff engineer and a manager disagree, who makes the call here?" Lands: it tests decision rights, which matter for this role.

### Round C: VP Engineering

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "What is your leadership philosophy, in a sentence?" | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | State a belief you would defend under follow-up, in your own words. Anchor it in the reliability quarter only as far as the quote goes. Do not state a philosophy you have not acted on. No published values are in hand, so this question is open. | The recruiter named this round "values and leadership philosophy". No values page was available. |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "pushed a reliability quarter through against roadmap pressure" | Mapped to the reliability quarter, using the quote's beats: the pressure, the push. Answer slot: if the case went to leadership, say to whom and what you said; if the quarter was argued with product only, say so. | A values question with a story the quote carries. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | [grounded] "My team's on-call burden dropped 60%" | Selection scaffold: pick a time you chose the people using the service over an internal number. If none comes to mind, say so plainly, then give the reliability quarter in its quoted terms, without stretching it into a customer story. | No quoted sentence carries a customer story, so this is a scaffold. The honest branch is the point. |
| C4 | "How do you decide who is good enough to hire, and who gets to say no?" | VAL | [grounded] "I run our hiring loop for backend roles" | Answer slot: whose bar the loop applies. If you set it, say how; if it was set for you, say so. Then what you do when a panel disagrees. | F4. The VP asks who holds the standard; the answer must match what you actually did. |
| C5 | "Your squads miss a delivery date by a quarter. Sixty seconds: what do you tell me?" | Pressure, JD | [grounded] "pushed a reliability quarter through against roadmap pressure" | Pause and restate. Hold the trade-off you would put in front of the VP, and what you would stop. Concede specifically what you do not know yet. Hold through two follow-ups. | F2 and F8. A hypothetical; time-boxed. |
| C6 | "That reliability result: how much of the 60% was actually you?" | EXP | [grounded] "My team's on-call burden dropped 60%"; [grounded] "pushed a reliability quarter through against roadmap pressure" | Separate what you pushed from what the team did. Name the part you would defend, concede plainly the rest, and do not fold the push. Answer slot: if you did specific technical work, say what; if you pushed the time and the call, say that. | F3 and F2. The attribution probe, in pressure form. |
| C7 | "Where does a strategy stop and a roadmap start, and who holds the line between hardware and software?" | CASE | [generic] | Structure: which decisions belong at which altitude, what you would escalate, and what you would not. Name who should own the line. | Altitude, the VP's ground. [generic] pattern, not a fact about Larkfield. |

**Reverse questions, Round C**

- "What does leadership here mean by leadership philosophy when it is tested in practice?" Lands: it turns the values frame into an example they will share.
- "When leaders here disagree between reliability and features, how is the call made?" Lands: it shows you care about decision rights.
- "What have you seen a strong engineering manager here do that you would want the next one to do too?" Lands: it exposes the values in practice, from the person who holds them.
- "What would you need the next person to fix in their first quarter?" Lands: it names the real risk and invites you to commit to a plan.

**Values angle for round C.** No published Larkfield values are in hand, so the values cheat sheet is not built. The round's questions (C1 to C4) run on your own stories and an honest branch when none fits. Paste Larkfield's values page and the cheat sheet can be built, with a mapped story for each value.

## Sources

**Provided documents:** your message (background, the three rounds, your two gaps) and the role summary you gave. No dossier, no job posting, no interviewer names.

**Searches sent:** three, all refused by the host (WebSearch permission was not granted):
- "Larkfield Systems industrial IoT company values": refused.
- "Larkfield Systems engineering manager interview process": refused.
- "Larkfield Systems strategy news 2026": refused.

**Target accounting**

Research tier: L1 (default). Searches 0 of 6 completed, fetches 0 of 2. The host refused search; no L2 run was possible.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Would have built the values cheat sheet. Refused, so no values section; round C runs on the recruiter's wording. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Would have confirmed the loop. The loop is established by your schedule instead; persona weights follow the three named rounds. |
| 3. Larkfield Systems strategy and recent news | unavailable | Would have built the CO bank. Refused, so no CO questions; CASE questions A3, A4, B5, B6 and C7 are generic. |
| 4. Interviewer name, Larkfield Systems | n/a | No names were given, so there was no query to form. No interviewer read. |
| 5. Representative engineering manager JD | unavailable | Would have supplied a representative JD for the requirements. Your role summary is the requirement source instead. |

## Upgrade menu

- **Full job posting text** → F1 to F9 become quoted JD lines, not summary lines, and the banks are checked against every requirement.
- **Larkfield's values page, pasted** → the values cheat sheet is built, and round C's C1 to C4 get mapped stories where your quoted sentences carry them.
- **Web search permitted** → targets 1 to 3 run; a deeper pass becomes offerable.
- **The interviewers' names, for each round** → personas per member, and reverse questions tied to their paths.
- **Whether the two squads have leads under you** → confirms or retires F8 and A2's premise.
- **The posting's location, on-site or travel terms** → resolves F9, the gate.
- **Any deliverable the recruiter named** (a presentation, a take-home) → a graded-deliverable section for each.
