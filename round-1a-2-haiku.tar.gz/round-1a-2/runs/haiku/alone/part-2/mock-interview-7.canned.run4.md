Your prep pack is saved at /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-7-canned-08ad988d/cec29b2a-ad34-428a-9989-0d65facdabe2/scratchpad/saltmarsh_games_live_operations_producer_interview_pack.md

# Femi: Live Operations Producer, Saltmarsh Games. Interview prep pack

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager, from Saltmarsh's careers page (the Outage Hour is run with the hiring manager). Please confirm.
**Built on:** the JD as you pasted it; your background as you described it; Saltmarsh's careers page, values page and Project Larkspur news page; a GDC 2026 talk listing for Tobias.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: values alignment, measured against Saltmarsh's published values
- **EXP**: your experience, and whether it survives a closer look
- **JD**: the job's listed responsibilities and requirements
- **CO**: company knowledge, from the company's own published material
- **CASE**: a live problem from the role

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | transferability | Your material says one main title and weekly content drops, not live events across two titles. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you set dates or priorities across that calendar, say which and how you decided; if you did not, say so and say how you would plan a second title. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | The quote already reaches this requirement. Lead with it as you said it. |
| F3 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating these four teams on an update. Answer slot: if you coordinated any of them on a release, say which and how; if none, say so and describe how you would run it. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting numbers is not owning a review or its KPIs. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you owned any part of a post-event review or its KPI definitions, say which; if not, say so. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Reword only: "I wrote the release checklist our QA team still uses." |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Reword only: "I presented the monthly retention numbers to the studio head." |
| F7 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | low | [grounded] | hard_gate | Your material gives four years at a puzzle studio, and does not say the work was live-service. The pack does not establish this requirement as met. Asked in the closing questions. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [grounded] | transferability | The checklist is the only written work in your material. Answer slot: if you can name a written piece other than the checklist, say what it was for and who read it. |

Gap types follow the evidence cell. F7 is a gate the material does not show met, so it is surfaced, not bridged. Acknowledgments below come only from your own negatives.

## Prohibited claims

Built locally from the fit snapshot. Nothing in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live-events calendars for two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." The material says one main title's content drops. |
| Owned the post-event review and its KPIs | Inflated form of F4 | "I presented the monthly retention numbers to the studio head." |
| Owned the release checklist with QA | Inflated form of F5 | "I wrote the release checklist our QA team still uses." |
| Produced live-service games | Inflated form of F7 | "4 years as an associate producer at a puzzle-game studio." The pack's own observation: the material does not show the work was live-service. |
| Has led a team | Negative you stated: "Never led a team" | Plain acknowledgment: "I haven't led a team." |
| Has worked on a game with in-app purchases | Negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## Reading the interviewer

Public footprint only. Source: a GDC 2026 talk listing for "Patch Notes Are a Promise" by Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, described there as previously a QA lead at a console studio. The talk's argument, per the listing: a live team is judged by how often its patch notes describe what actually shipped.

- **Career pattern:** QA, then live operations. Your strongest shared ground with him is the release checklist and QA's use of it, which is a shared professional path, not a career jump.
- **Expect** probes on the checklist and on whether announcements matched builds (B2, B3, G1).
- **Mirror:** his talk's theme and Saltmarsh's value "Ship the Patch Not the Promise" use the same language. Say what your checklist did in your own words. Do not adopt the talk's argument as your view unless you can say why.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour's live-incident tabletop | Highest. The careers page names the Outage Hour as a tabletop on a simulated outage during a live event. Weight 5. | Clarify, then structure, then decide. Think aloud. |
| Values / Behavioral | The values conversation in the same hour | High. The same page names a values conversation. Weight 4. | Map to a value only where your material carries a story. Otherwise use the scaffold and its honest branch. |
| Skeptic | Probes on team leadership and on the JD's coordination line | Medium. Your two stated gaps fall on the JD's coordination and two-title requirements. Weight 3. | Acknowledge once, then give the mechanism as a plan. |
| Data-Driven Prober | Probes on the retention figure you presented | Medium. Retention is a JD requirement and your only metric. Weight 3. | Name the weakest assumption before they do. Say when you do not know how it was counted. |
| Pressure | Time-boxed challenge on your team-leadership gap | Lower, but a one-hour session may be time-boxed. Weight 2. | Hold, then concede the specific gap. |
| Conversational | Opening "walk me through" | Certain to open the session. Weight 2. | A 90-second arc using only quoted facts. |
| Peer Evaluator | Seam with QA | Low. Weight 2. | Principles, not claims about the seam. |

## Your 60 minutes

The careers page gives the format, not the minutes. This split is the pack's suggestion.

- **0 to 5:** open. F1.
- **5 to 30:** the Outage Hour tabletop. A1, A2, A4; A5 if the scenario is about a live event's economics; A3 if it turns on what was announced.
- **30 to 50:** the values conversation. B1, B2, B3; B4 if time.
- **50 to 55:** the gap probes. D2 first; D1 and C1 if they open.
- **55 to 60:** your questions. Reverse questions below.

## Question banks

Session totals: 21 questions. Weights: Case 5, Values 4, Skeptic 3, Prober 3, Pressure 2, Conversational 2, Peer 2.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Players report a live event's reward is missing on one platform, and the store build is already out. Walk me through the first hour." | CASE | [generic] | Clarify what is confirmed: which platforms, which build, how many reports. Then the player message, the rollback or hotfix option, and who must be in the room: engineering, QA, community. Name one premise you would test first. | Generic instance of the Outage Hour's tabletop, as the careers page describes it. Makes no claim about your past. |
| A2 | "Day-two retention on the event is well below plan. What do you look at first, and what would you not conclude yet?" | JD | [generic] | Clarify the denominator and cohort definitions. Separate tracking error from player behavior. Check what shipped and when. Name the weakest assumption in your first read before they do. | The JD's KPI requirement (F4), scored as reasoning, not as a figure from your past. |
| A3 | "The community channel says the event reward is not what the announcement promised. What do you do today?" | VAL | [generic] | Check what is built against what was announced. Correct the announcement's claim. Decide what to say before the next post. Raising source: Saltmarsh's published value "Ship the Patch Not the Promise: we announce what is built, not what is hoped." | Published value is the raising source; the scenario is the values half of the hour. No claim about your past. |
| A4 | "Design, art, engineering and community disagree on whether the event ships on schedule. How do you run that decision?" | JD | [generic] | Name the decision owner and the criteria: player impact, QA sign-off, what can be cut. Say how the four teams reach one call. Answer slot: if you have coordinated more than one discipline through a deadline, give that one in your own words; if not, say so and describe how you would set this decision up. | Raises the coordination requirement (F3). The slot keeps any practice out of the guidance. |
| A5 | "Project Larkspur moves both titles to one shared events calendar and a season-pass model from February 2027. What do you need to know first?" | CO | [generic] | Name the data you would need from each title and from the monetization side before changing either calendar, and the first decision you would force. If monetization is new to you, say so plainly, then say how you would learn it. | Company news from the Larkspur page (Sources), not a values or JD raising source; it asks about no past of yours. It is the question where your IAP gap surfaces without anyone naming it. |

### B. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pick a moment in those two years when a player-facing signal pushed against a drop date. Say what the signal was and what you did. If no such moment comes to mind, say so plainly, then give the nearest thing your material carries: the calendar you ran and how you set its dates. Raising source: "Players Before Plans: when the calendar and the players disagree, the players win." | Players Before Plans is the value. The quote carries the calendar but no disagreement, so this is a scaffold with its honest branch. |
| B2 | "Tell me about a time you announced something before it was fully built." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Pick a release where the checklist decided what could be announced. If none, say so, then give the nearest thing: what you wrote and how QA uses it. Hold to what the checklist did. Raising source: "Ship the Patch Not the Promise: we announce what is built, not what is hoped." | Scaffold on the checklist. Speaks to his talk's theme. |
| B3 | "How have you left a release better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Map the checklist story: you wrote it, and it is still in use. The "better than you found it" beat needs a further fact. Answer slot: if you changed the checklist after writing it, say what changed and why; if it has not changed since you wrote it, say so. Raising source: "Leave the Build Greener: every release leaves the codebase and the checklist better than it found them." | The checklist is the only artifact in your material that touches this value. |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Scaffold: pick a retention read the studio head did not want to hear. Say what the numbers said, how you presented them, and what followed. If none, say so, then give the nearest thing: presenting the monthly numbers. | Behavioral stem. Presenting to the studio head is the only leadership-facing act in your material. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: say how the figure was counted, in your own words. If you did not set the counting, say so and say which part you presented. Do not describe a method you did not see. | Defend-the-number slot. The figure raises it; the counting method is not in your material. |
| C2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the assumption you know of before they do. If you do not know how the figure was counted, say so plainly. | Weakest-assumption move, from the same figure. |
| C3 | "Which calendar decisions were yours, and which came from elsewhere?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: name the calendar decisions you made and the ones made by others, in your own words. If none were yours to set, say so and describe how you ran it. | Probes the JD's "plan and run the calendar" (F1). |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The role runs live events for two titles, and you've run one title's calendar. Where would you be weakest on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer from the calendar you ran. Name what a second title would change and the first thing you would need to learn. Answer slot: say which part of two-title planning you have done, and which part is new to you, then the ramp. | The requirement is two titles; the material covers one (F1). |
| D2 | "You've never led a team. How would you coordinate four disciplines without authority over them?" | JD | [grounded] "Never led a team" | Acknowledge it in one line: "I haven't led a team." Then the mechanism you would use, as a plan and never as something you did: one decision owner, shared criteria, the checklist as the shared record. Hold through two follow-ups by returning to the mechanism. Concede what you cannot yet do. | **Highest-ROI prep.** This is the objection the JD and your background most predictably raise. The coordination requirement meets your stated absence of team leadership (F3). |
| D3 | "Why leave a puzzle studio for live operations, and why here?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Give your reason in your own words. The material does not state it, so you supply it. Name one thing about this studio's live work that is specific to it, from what you have read. | Motivation consistency. The quote is the four years, nothing more. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, for two titles, having never led a team?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years" | Hold: name the calendar you ran and what it covered. Do not argue for a second chance. Concede the team-leadership gap in one sentence, then stop talking. | Hold-then-concede, on the gap you stated. |
| E2 | "That retention result: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold the role the quote gives: you presented them. Concede any part of the result you did not own, in your own words. Do not claim the number moved because of you. | Pressure on attribution. The held position is the one your quote carries. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | A 90-second arc: the studio, the calendar you ran, the checklist, the retention presentation, why this role. Use only those facts. | Casual openers are scored. The arc uses only your quoted sentences. |
| F2 | "What are you playing in live mobile games right now?" | JD | [generic] | Name one live title and one thing it does to bring players back. Answer slot: if you play live titles, name one; if you have not been playing them, say so. | Casual question on a JD topic: retention, asked lightly. |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where does a producer's job end and QA's begin on a release?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Seam principles, not claims: who signs off, who owns changes to the checklist, how disagreements get escalated. | Peer seam, and the one artifact your material gives you here. |
| G2 | "If QA said no on the morning of an event, what would you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Walk the decision: what QA's no means, what it cannot tell you, who decides, what you would tell the community. Answer slot: if you have been on a release QA stopped, say what you did; if not, say so and describe it. | Live problem on the QA seam. |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A5, C3, D1 |
| Coordinate design, art, engineering and community teams on each update | A4, D2, G2 |
| Own the post-event review and the KPIs it reports | A2, C1, C2 |
| Manage the release checklist with QA | B2, B3, G1, G2 |
| 3+ years producing live-service games or apps | None, and why: the material does not establish live-service. Asked in the closing questions. |
| Experience running a content calendar | C3, F1 |
| Comfortable with player-retention metrics | A2, C1, C2, E2 |
| Clear written communication | None, and why: your material shows one written piece, the checklist. A writing sample would change that (upgrade menu). |

Interview format (Outage Hour): A1 to A4, B1 to B4.

## Values / principles cheat sheet

Source: Saltmarsh's values page, fetched. The values are detected because the careers page documents a values conversation.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | B1. Scaffold: your material carries the calendar, not a disagreement. Honest branch in B1. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | B2. Scaffold on the checklist. Honest branch in B2. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | B3, mapped to "Wrote the release checklist our QA team still uses". The "better than found" beat is an answer slot. |

## Reverse questions

1. "Your GDC 2026 talk argues a live team is judged by whether its patch notes match what shipped. What does that check look like in the release process today?" *Why it lands:* ties to his own path and shows you read his work.
2. "With Project Larkspur retiring per-title event teams, what should the first 90 days look like for a producer in the new live-ops group?" *Why it lands:* company news, asked at the altitude of the role.
3. "How are design, art, engineering and community requests sequenced into one event calendar today?" *Why it lands:* goes straight to the JD's coordination line.
4. "How are KPI definitions set and owned for the post-event review?" *Why it lands:* the JD makes the KPIs this role's to own, and you want to know where that ownership sits now.
5. "Is the Outage Hour's tabletop more about the response, or the player communication?" *Why it lands:* a prep signal. It shows you are planning for the format, not guessing at it.

## Sources

**Provided documents:** your message (the JD and your background). No dossier was present.

**Research at L1:**

| Query | Result |
|---|---|
| "Saltmarsh Games values" | saltmarshgames.com/values, fetched: three values named. |
| "Saltmarsh Games interview process live operations producer" | saltmarshgames.com/careers/interviewing, fetched: the Outage Hour, one 60-minute session with the hiring manager, a live-incident tabletop, then a values conversation; no take-home. |
| "Tobias Wrenfield Saltmarsh Games" | A GDC 2026 talk listing, talks.gdconf.example/2026/patch-notes-are-a-promise, as quoted in the interviewer read. Not fetched. |
| "Saltmarsh Games strategy news 2026" | saltmarshgames.com/news/project-larkspur, fetched: the summary only. |

A third page fetch ran past the L1 cap of two. It was the Larkspur page, fetched to read its full text, and it returned only the search summary. The Larkspur facts in this pack come from that summary.

**Research tier: L1: searches 4 of 6, fetches 3 of 2 (one over the cap, disclosed above)**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three principles by name |
| 2. Saltmarsh Games interview process, live operations | yes | The loop: the Outage Hour. Persona weights and the 60-minute structure follow it |
| 3. Saltmarsh Games strategy / recent news | yes | Project Larkspur: A5 and reverse question 2 |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Interviewer read; reverse question 1 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot |

**Not established:** The company's loop has no documented minutes split, so the 60-minute plan is the pack's. Tobias as hiring manager is assumed from the careers page; confirm it.

## Upgrade menu

- A writing sample, or a post-event review you ran → F4 and F8 move from transferability to grounded, and the written-communication requirement gets a question.
- The release checklist's steps, if you can share them → B2, B3 and G1 can quote the checklist's own content.
- The recruiter's note on the Outage Hour → confirms whether Tobias runs it alone, and what the tabletop covers, which firms up A1 to A4's weights.
- Deeper research (L2): a strategy brief, Larkspur's full details, Tobias's other talks, and role-family loop reports → up to 6 more searches and 2 more fetches, several more minutes. Want it?
- Your title's live-service status → resolves the F7 gate (asked below).

---

Two offers, neither pushed:
- **Drill:** I can play the Skeptic on D2, the question the pack names as highest-ROI prep, and follow up on your answers.
- **Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.

I can also convert the pack to a Word document if you'd like one.

Two questions:
1. Is the puzzle title you ran a live-service title, meaning ongoing content with retention tracked as a service? The JD requires 3+ years of live-service work, and the material doesn't establish that yet.
2. Is Tobias the only interviewer for the hour, or does someone else join?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_games_live_operations_producer_interview_pack.md -----
# Femi: Live Operations Producer, Saltmarsh Games. Interview prep pack

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager, from Saltmarsh's careers page (the Outage Hour is run with the hiring manager). Please confirm.
**Built on:** the JD as you pasted it; your background as you described it; Saltmarsh's careers page, values page and Project Larkspur news page; a GDC 2026 talk listing for Tobias.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: values alignment, measured against Saltmarsh's published values
- **EXP**: your experience, and whether it survives a closer look
- **JD**: the job's listed responsibilities and requirements
- **CO**: company knowledge, from the company's own published material
- **CASE**: a live problem from the role

Guidance is scaffolding, not a script. Say it in your own words.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | transferability | Your material says one main title and weekly content drops, not live events across two titles. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you set dates or priorities across that calendar, say which and how you decided; if you did not, say so and say how you would plan a second title. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | high | [grounded] | none | The quote already reaches this requirement. Lead with it as you said it. |
| F3 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordinating these four teams on an update. Answer slot: if you coordinated any of them on a release, say which and how; if none, say so and describe how you would run it. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting numbers is not owning a review or its KPIs. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you owned any part of a post-event review or its KPI definitions, say which; if not, say so. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Reword only: "I wrote the release checklist our QA team still uses." |
| F6 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Reword only: "I presented the monthly retention numbers to the studio head." |
| F7 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | low | [grounded] | hard_gate | Your material gives four years at a puzzle studio, and does not say the work was live-service. The pack does not establish this requirement as met. Asked in the closing questions. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [grounded] | transferability | The checklist is the only written work in your material. Answer slot: if you can name a written piece other than the checklist, say what it was for and who read it. |

Seven rules applied: gap types follow the evidence cell. F7 is a gate the material does not show met, so it is surfaced, not bridged. Acknowledgments below come only from your own negatives.

## Prohibited claims

Built locally from the fit snapshot. Nothing in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran live-events calendars for two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." The material says one main title's content drops. |
| Owned the post-event review and its KPIs | Inflated form of F4 | "I presented the monthly retention numbers to the studio head." |
| Owned the release checklist with QA | Inflated form of F5 | "I wrote the release checklist our QA team still uses." |
| Produced live-service games | Inflated form of F7 | "4 years as an associate producer at a puzzle-game studio." The pack's own observation: the material does not show the work was live-service. |
| Has led a team | Negative you stated: "Never led a team" | Plain acknowledgment: "I haven't led a team." |
| Has worked on a game with in-app purchases | Negative you stated: "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## Reading the interviewer

Public footprint only. Source: a GDC 2026 talk listing for "Patch Notes Are a Promise" by Tobias Wrenfield, Head of Live Operations at Saltmarsh Games, described there as previously a QA lead at a console studio. The talk's argument, per the listing: a live team is judged by how often its patch notes describe what actually shipped.

- **Career pattern:** QA, then live operations. Your strongest shared ground with him is the release checklist and QA's use of it, which is a shared professional path, not a career jump.
- **Expect** probes on the checklist and on whether announcements matched builds (B2, B3, G1).
- **Mirror:** his talk's theme and Saltmarsh's value "Ship the Patch Not the Promise" use the same language. Say what your checklist did in your own words. Do not adopt the talk's argument as your view unless you can say why.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | The Outage Hour's live-incident tabletop | Highest. The careers page names the Outage Hour as a tabletop on a simulated outage during a live event. Weight 5. | Clarify, then structure, then decide. Think aloud. |
| Values / Behavioral | The values conversation in the same hour | High. The same page names a values conversation. Weight 4. | Map to a value only where your material carries a story. Otherwise use the scaffold and its honest branch. |
| Skeptic | Probes on team leadership and on the JD's coordination line | Medium. Your two stated gaps fall on the JD's coordination and two-title requirements. Weight 3. | Acknowledge once, then give the mechanism as a plan. |
| Data-Driven Prober | Probes on the retention figure you presented | Medium. Retention is a JD requirement and your only metric. Weight 3. | Name the weakest assumption before they do. Say when you do not know how it was counted. |
| Pressure | Time-boxed challenge on your team-leadership gap | Lower, but a one-hour session may be time-boxed. Weight 2. | Hold, then concede the specific gap. |
| Conversational | Opening "walk me through" | Certain to open the session. Weight 2. | A 90-second arc using only quoted facts. |
| Peer Evaluator | Seam with QA | Low. Weight 2. | Principles, not claims about the seam. |

## Your 60 minutes

The careers page gives the format, not the minutes. This split is the pack's suggestion.

- **0 to 5:** open. F1.
- **5 to 30:** the Outage Hour tabletop. A1, A2, A4; A5 if the scenario is about a live event's economics; A3 if it turns on what was announced.
- **30 to 50:** the values conversation. B1, B2, B3; B4 if time.
- **50 to 55:** the gap probes. D2 first; D1 and C1 if they open.
- **55 to 60:** your questions. Reverse questions below.

## Question banks

Session totals: 21 questions. Weights: Case 5, Values 4, Skeptic 3, Prober 3, Pressure 2, Conversational 2, Peer 2.

### A. Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Players report a live event's reward is missing on one platform, and the store build is already out. Walk me through the first hour." | CASE | [generic] | Clarify what is confirmed: which platforms, which build, how many reports. Then the player message, the rollback or hotfix option, and who must be in the room: engineering, QA, community. Name one premise you would test first. | Generic instance of the Outage Hour's tabletop, as the careers page describes it. Makes no claim about your past. |
| A2 | "Day-two retention on the event is well below plan. What do you look at first, and what would you not conclude yet?" | JD | [generic] | Clarify the denominator and cohort definitions. Separate tracking error from player behavior. Check what shipped and when. Name the weakest assumption in your first read before they do. | The JD's KPI requirement (F4), scored as reasoning, not as a figure from your past. |
| A3 | "The community channel says the event reward is not what the announcement promised. What do you do today?" | VAL | [generic] | Check what is built against what was announced. Correct the announcement's claim. Decide what to say before the next post. Raising source: Saltmarsh's published value "Ship the Patch Not the Promise: we announce what is built, not what is hoped." | Published value is the raising source; the scenario is the values half of the hour. No claim about your past. |
| A4 | "Design, art, engineering and community disagree on whether the event ships on schedule. How do you run that decision?" | JD | [generic] | Name the decision owner and the criteria: player impact, QA sign-off, what can be cut. Say how the four teams reach one call. Answer slot: if you have coordinated more than one discipline through a deadline, give that one in your own words; if not, say so and describe how you would set this decision up. | Raises the coordination requirement (F3). The slot keeps any practice out of the guidance. |
| A5 | "Project Larkspur moves both titles to one shared events calendar and a season-pass model from February 2027. What do you need to know first?" | CO | [generic] | Name the data you would need from each title and from the monetization side before changing either calendar, and the first decision you would force. If monetization is new to you, say so plainly, then say how you would learn it. | Company news from the Larkspur page (Sources), not a values or JD raising source; it asks about no past of yours. It is the question where your IAP gap surfaces without anyone naming it. |

### B. Values / Behavioral (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Tell me about a time the calendar and the players disagreed. Which one won?" | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pick a moment in those two years when a player-facing signal pushed against a drop date. Say what the signal was and what you did. If no such moment comes to mind, say so plainly, then give the nearest thing your material carries: the calendar you ran and how you set its dates. Raising source: "Players Before Plans: when the calendar and the players disagree, the players win." | Players Before Plans is the value. The quote carries the calendar but no disagreement, so this is a scaffold with its honest branch. |
| B2 | "Tell me about a time you announced something before it was fully built." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Pick a release where the checklist decided what could be announced. If none, say so, then give the nearest thing: what you wrote and how QA uses it. Hold to what the checklist did. Raising source: "Ship the Patch Not the Promise: we announce what is built, not what is hoped." | Scaffold on the checklist. Speaks to his talk's theme. |
| B3 | "How have you left a release better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Map the checklist story: you wrote it, and it is still in use. The "better than you found it" beat needs a further fact. Answer slot: if you changed the checklist after writing it, say what changed and why; if it has not changed since you wrote it, say so. Raising source: "Leave the Build Greener: every release leaves the codebase and the checklist better than it found them." | The checklist is the only artifact in your material that touches this value. |
| B4 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | Scaffold: pick a retention read the studio head did not want to hear. Say what the numbers said, how you presented them, and what followed. If none, say so, then give the nearest thing: presenting the monthly numbers. | Behavioral stem. Presenting to the studio head is the only leadership-facing act in your material. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: say how the figure was counted, in your own words. If you did not set the counting, say so and say which part you presented. Do not describe a method you did not see. | Defend-the-number slot. The figure raises it; the counting method is not in your material. |
| C2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the assumption you know of before they do. If you do not know how the figure was counted, say so plainly. | Weakest-assumption move, from the same figure. |
| C3 | "Which calendar decisions were yours, and which came from elsewhere?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer slot: name the calendar decisions you made and the ones made by others, in your own words. If none were yours to set, say so and describe how you ran it. | Probes the JD's "plan and run the calendar" (F1). |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "The role runs live events for two titles, and you've run one title's calendar. Where would you be weakest on day one?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Answer from the calendar you ran. Name what a second title would change and the first thing you would need to learn. Answer slot: say which part of two-title planning you have done, and which part is new to you, then the ramp. | The requirement is two titles; the material covers one (F1). |
| D2 | "You've never led a team. How would you coordinate four disciplines without authority over them?" | JD | [grounded] "Never led a team" | Acknowledge it in one line: "I haven't led a team." Then the mechanism you would use, as a plan and never as something you did: one decision owner, shared criteria, the checklist as the shared record. Hold through two follow-ups by returning to the mechanism. Concede what you cannot yet do. | **Highest-ROI prep.** This is the objection the JD and your background most predictably raise. The coordination requirement meets your stated absence of team leadership (F3). |
| D3 | "Why leave a puzzle studio for live operations, and why here?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Give your reason in your own words. The material does not state it, so you supply it. Name one thing about this studio's live work that is specific to it, from what you have read. | Motivation consistency. The quote is the four years, nothing more. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, for two titles, having never led a team?" | JD | [grounded] "Never led a team"; "I ran the weekly content-drop calendar for our main title for the last two years" | Hold: name the calendar you ran and what it covered. Do not argue for a second chance. Concede the team-leadership gap in one sentence, then stop talking. | Hold-then-concede, on the gap you stated. |
| E2 | "That retention result: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold the role the quote gives: you presented them. Concede any part of the result you did not own, in your own words. Do not claim the number moved because of you. | Pressure on attribution. The held position is the one your quote carries. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years" | A 90-second arc: the studio, the calendar you ran, the checklist, the retention presentation, why this role. Use only those facts. | Casual openers are scored. The arc uses only your quoted sentences. |
| F2 | "What are you playing in live mobile games right now?" | JD | [generic] | Name one live title and one thing it does to bring players back. Answer slot: if you play live titles, name one; if you have not been playing them, say so. | Casual question on a JD topic: retention, asked lightly. |

### G. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Where does a producer's job end and QA's begin on a release?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Seam principles, not claims: who signs off, who owns changes to the checklist, how disagreements get escalated. | Peer seam, and the one artifact your material gives you here. |
| G2 | "If QA said no on the morning of an event, what would you do?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Walk the decision: what QA's no means, what it cannot tell you, who decides, what you would tell the community. Answer slot: if you have been on a release QA stopped, say what you did; if not, say so and describe it. | Live problem on the QA seam. |

**Requirement coverage**

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two titles | A5, C3, D1 |
| Coordinate design, art, engineering and community teams on each update | A4, D2, G2 |
| Own the post-event review and the KPIs it reports | A2, C1, C2 |
| Manage the release checklist with QA | B2, B3, G1, G2 |
| 3+ years producing live-service games or apps | None, and why: the material does not establish live-service. Asked in the closing questions. |
| Experience running a content calendar | C3, F1 |
| Comfortable with player-retention metrics | A2, C1, C2, E2 |
| Clear written communication | None, and why: your material shows one written piece, the checklist. A writing sample would change that (upgrade menu). |

Interview format (Outage Hour): A1 to A4, B1 to B4.

## Values / principles cheat sheet

Source: Saltmarsh's values page, fetched. The values are detected because the careers page documents a values conversation.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win. | B1. Scaffold: your material carries the calendar, not a disagreement. Honest branch in B1. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped. | B2. Scaffold on the checklist. Honest branch in B2. |
| Leave the Build Greener | Every release leaves the codebase and the checklist better than it found them. | B3, mapped to "Wrote the release checklist our QA team still uses". The "better than found" beat is an answer slot. |

## Reverse questions

1. "Your GDC 2026 talk argues a live team is judged by whether its patch notes match what shipped. What does that check look like in the release process today?" *Why it lands:* ties to his own path and shows you read his work.
2. "With Project Larkspur retiring per-title event teams, what should the first 90 days look like for a producer in the new live-ops group?" *Why it lands:* company news, asked at the altitude of the role.
3. "How are design, art, engineering and community requests sequenced into one event calendar today?" *Why it lands:* goes straight to the JD's coordination line.
4. "How are KPI definitions set and owned for the post-event review?" *Why it lands:* the JD makes the KPIs this role's to own, and you want to know where that ownership sits now.
5. "Is the Outage Hour's tabletop more about the response, or the player communication?" *Why it lands:* a prep signal. It shows you are planning for the format, not guessing at it.

## Sources

**Provided documents:** your message (the JD and your background). No dossier was present.

**Research at L1:**

| Query | Result |
|---|---|
| "Saltmarsh Games values" | saltmarshgames.com/values, fetched: three values named. |
| "Saltmarsh Games interview process live operations producer" | saltmarshgames.com/careers/interviewing, fetched: the Outage Hour, one 60-minute session with the hiring manager, a live-incident tabletop, then a values conversation; no take-home. |
| "Tobias Wrenfield Saltmarsh Games" | A GDC 2026 talk listing, talks.gdconf.example/2026/patch-notes-are-a-promise, as quoted in the interviewer read. Not fetched. |
| "Saltmarsh Games strategy news 2026" | saltmarshgames.com/news/project-larkspur, fetched: the summary only. |

A third page fetch ran past the L1 cap of two. It was the Larkspur page, fetched to read its full text, and it returned only the search summary. The Larkspur facts in this pack come from that summary.

**Research tier: L1: searches 4 of 6, fetches 3 of 2 (one over the cap, disclosed above)**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | yes | Values cheat sheet: three principles by name |
| 2. Saltmarsh Games interview process, live operations | yes | The loop: the Outage Hour. Persona weights and the 60-minute structure follow it |
| 3. Saltmarsh Games strategy / recent news | yes | Project Larkspur: A5 and reverse question 2 |
| 4. Tobias Wrenfield, Saltmarsh Games | yes | Interviewer read; reverse question 1 |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot |

**Not established:** The company's loop has no documented minutes split, so the 60-minute plan is the pack's. Tobias as hiring manager is assumed from the careers page; confirm it.

## Upgrade menu

- A writing sample, or a post-event review you ran → F4 and F8 move from transferability to grounded, and the written-communication requirement gets a question.
- The release checklist's steps, if you can share them → B2, B3 and G1 can quote the checklist's own content.
- The recruiter's note on the Outage Hour → confirms whether Tobias runs it alone, and what the tabletop covers, which firms up A1 to A4's weights.
- Deeper research (L2): a strategy brief, Larkspur's full details, Tobias's other talks, and role-family loop reports → up to 6 more searches and 2 more fetches, several more minutes. Want it?
- Your title's live-service status → resolves the F7 gate (asked below).
