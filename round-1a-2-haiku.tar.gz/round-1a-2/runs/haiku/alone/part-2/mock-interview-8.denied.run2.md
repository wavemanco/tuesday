Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-8-denied-1cdd63fc/f799acd0-85b6-47d4-af86-da3ef768eeeb/scratchpad/ashgrove_credit_union_member_experience_lead_interview_pack.md`. It covers all three rounds, with 25 questions in total.

The main findings:

- **Your biggest gap is end-to-end ownership.** The JD asks you to own complaints across branches and the contact centre. Your material shows one branch's formal log. Question B1 is the one to rehearse hardest, and the answer has to stay inside what you actually did.
- **Two gaps are stated absences, so answer them plainly.** You have never worked in a contact centre and never presented above regional level. Use a plan for each, not a claim of experience.
- **Three gaps are silences, not absences.** Resolution times, digital and self-service work, and whether the formal log ran to regulated timescales are not in your material. Each gets an answer slot. If you can answer them truthfully, the pack gets stronger.
- **The values round has no member-side story yet.** None of your sentences carries a Members First, Plain Words or Neighbours story. The pack gives selection scaffolds with an honest "say so, then give the nearest thing" branch.
- **The 20-minute case (C7) has a structure.** It covers clarify, options, decide and act, then measure and communicate, with the member explanation in plain words.

I ran no searches. Your pasted values, JD, recruiter email and strategy summary covered everything the research would have fetched. The strategy quotes are your summary, not the published brief, so check the wording before you use it in the room.

Two offers, neither pushed: I can play the Skeptic on B1 as a live drill, or save a `tuesday-dossier.md` recording the gaps this prep exposed. I can also convert the pack to Word if you want it.

Is the formal complaints log run to set deadlines or a regulator's rules, and did the spreadsheet ever record how long cases took?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_credit_union_member_experience_lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

Three rounds on 28 November 2026. Round 1: recruiter, 30 min. Round 2: Head of Member Services (your future manager), 45 min, mostly behavioural. Round 3: panel of two branch managers, 60 min, including a 20-minute complaint-escalation case, scored against the four published values. Panel names are not yet assigned, so no interviewer read is included.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

- **VAL**: behavioural / values alignment
- **EXP**: work-experience deep-dive (does what you did survive scrutiny)
- **JD**: role and JD-driven (can you do the listed job, gaps included)
- **CO**: company and strategy knowledge
- **CASE**: hypothetical or live problem

Guidance is scaffolding, not a script. Say it in your own words. Where a cell says "answer slot", the interviewer's probe is likely and you answer from what actually happened, including "that was not mine" or "I have not done that".

## Fit snapshot

Your material is the message you sent me (background sentences quoted exactly). The JD is the text you pasted.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log, trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material shows one branch's formal log, not end-to-end ownership across branches or the contact centre, so the bridge stays at the log. Words: "I handled the branch's formal complaints log." Answer slot: the JD's end-to-end line makes a probe on which stages were yours likely. If you set any stage of a complaint's path, say which and how you decided; if none was yours to set, say so and stay with the log. |
| F2 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | The sentence reaches monthly reporting. Nothing in your material shows resolution times. Answer slot: if the spreadsheet recorded how long cases took, say what it counted and how; if it did not, say so and say what you would add first. |
| F3 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log, trained new tellers on our escalation script." — your message | low | [inferred] | transferability | Training tellers is not coaching supervisors, and the bridge should not stretch. Words at the tellers' scope: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor on an escalation, say how; if you did not, say so and say how you would start. |
| F4 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material does not show digital or self-service work, and says nothing against it. Answer slot: if you worked with anyone building a digital channel, say what you did; if you did not, say so and say how you would learn the member journeys first. |
| F5 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | high | [grounded] | none | Already met. Say the six years and the three as a supervisor, in those words. |
| F6 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log, trained new tellers on our escalation script." — your message | medium | [grounded] | discovery | Your material says formal complaints. It does not say whether the log ran to set timescales or a regulator's rules. Answer slot: if it did, say which and how you applied them; if it did not, say so and say that the formal log is the nearest thing you have. |
| F7 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated absence. Words: "I've never presented to anyone above regional level." Then how you would prepare, said as a plan, never as a past. |
| F8 | "the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A stated absence. Words: "I've never worked in a contact centre." Then how you would learn the contact-centre flow, said as a plan. |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | The sentence reaches reporting in other terms. Reword only it: say you built the monthly complaints spreadsheet. Do not name functions or formulas you have not told me you used. |

Confidence grades your evidence. Provenance grades what this pack says about it. On a gap row, Provenance grades the gap statement.

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer, hold, bridge or reverse question below asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 | F1's quote at its own scope. Pack observation, not a first-person negative: your material shows the branch's log. |
| Tracked resolution times | Inflated form of F2 | F2's quote at its own scope. Pack observation: the material does not show resolution times. |
| Coached branch supervisors on escalations | Inflated form of F3 | F3's quote at the tellers' scope. |
| Handled regulated complaints | Inflated form of F6 | "formal complaints log", at its own scope. |
| Presented to senior leaders; worked in a contact centre | Negatives you stated (F7, F8) | Plain acknowledgment: "I've never presented to anyone above regional level." and "I've never worked in a contact centre." No answer slot on either. |

Worked-in-digital (F4) is not listed. The material is silent on it, so it is an answer slot.

## Question banks

Round weights follow the relationship priors. Round 1 is a recruiter screen: conversational, with logistics. Round 2 is your manager, mostly behavioural: skeptic first, then values. Round 3 is a values-scored panel: values first, then pressure, then the case.

### Round 1: Recruiter (30 min), weights: Conversational 3, light Skeptic 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your path to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log, trained new tellers on our escalation script." | Under 90 seconds: six years in retail banking, the last three as a branch supervisor, then the complaints work in the words above. Add no roles, dates or titles. | Casual opener, still scored. F5 is met and F1 is the first thing the panel will ask about. |
| A2 | "What are your pay expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask what the band is first. Do not guess a band or quote a past salary you have not given me. | Recruiter logistics check. Pay is a fixed knockout. |
| A3 | "What is your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. Your material gives none, so none is assumed. | Start-date check. |
| A4 | "Where would you be based, and how many days in an office?" | JD | [generic] | Logistics slot: say where you can work and which days. The material gives neither. | Hub consolidation makes location a live question in 2027. |
| A5 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot: give your own reason in your own words. Keep it to one sentence and make no comment about your employer. | Recruiter knockout on motivation. |
| A6 | "What do you know about where we're heading?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, as you summarised it) | Name the 40%-by-2028 target. Then ask one question about where complaints go in that shift. Do not claim to have worked on it. | Strategy is the first differentiator. F4 is the gap the digital target puts under pressure. |

### Round 2: Head of Member Services (45 min, mostly behavioural), weights: Skeptic 5, Values/Behavioral 3, Case 1

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role owns complaints end to end across branches and the contact centre. Which part of that have you owned yourself?" | JD | [grounded] "I handled the branch's formal complaints log, trained new tellers on our escalation script." | **Highest-ROI prep in this pack.** Hold the quote: the branch's formal complaints log, and training tellers on the escalation script. Answer slot: if any stage of a complaint's path was yours to set, say which and how you decided, in your own words; if none was, say so plainly and describe how you ran the log. Hold through two follow-ups by returning to the log. | F1 is where the role's end-to-end line presses hardest, and the probe will come in some form. The objection is aimed at the thinnest part of your material, so do not thicken it. |
| B2 | "You haven't worked in a contact centre. How would you run complaints across one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I've never worked in a contact centre." Then a plan: how you would learn the flow, who you would ask, what you would look at first. Said as a plan, not a past. | F8, the stated negative. A plan answers the question; a claim to contact-centre knowledge does not. |
| B3 | "What's your experience presenting to senior leaders?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare, with the monthly spreadsheet as the material you would start from, said as a plan. | F7. The role's presenting requirement is the one you have stated no evidence for. |
| B4 | "Walk me through the formal complaints log you handled." | EXP | [grounded] "I handled the branch's formal complaints log, trained new tellers on our escalation script." | Beats: the log, handled by you; training tellers on the escalation script. Answer slot: how cases moved to closure. If you set steps, say which; if not, say so and describe what the log did. | F1 and F6. The probe checks attribution. |
| B5 | "You built the complaints spreadsheet your regional manager uses. Does it track resolution times?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what it holds, in your words. Answer slot: if it recorded how long cases took, say how it counted them; if it did not, say so and say what you would add first. | F2 and F9. The JD asks for resolution times; your material does not show them. |
| B6 | "The role coaches branch supervisors on escalations. Have you coached a supervisor on one, and what happened?" | JD | [grounded] "I handled the branch's formal complaints log, trained new tellers on our escalation script." | Answer slot: if you have, say how. If you have not, say so, then give the nearest thing you did: training tellers on the escalation script, at that scope. | F3. The question's premise is the JD's line; the answer can be no. |
| B7 | "The role works with digital teams on self-service journeys. What have you done there?" | JD | [grounded] | Answer slot: if you worked with anyone building a digital channel, say what you did. If you did not, say so and say how you would learn the member journeys first. | F4, silence in the material. An honest "not yet" is the right answer. |
| B8 | "Tell me about a time you decided a complaint from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log, trained new tellers on our escalation script." | Selection scaffold: pick a complaint where the member's side changed what you decided. If none comes to mind, say so plainly, then give the nearest thing your material carries: how you handled the formal log. | Members First, Always is a published value; this question scores it. Your material shows no member-side story, so the honest branch is required. |
| B9 | "Tell me about a time someone needed something explained twice, and what you did." | VAL | [grounded] "trained new tellers on our escalation script" (the same sentence as B8) | Selection scaffold: pick a time an explanation did not land first time, and what you changed. If none comes to mind, say so, then give the nearest thing: how you trained tellers to explain the escalation script. | Plain Words is a published value. Your material shows training, not a member explanation that failed. |
| B10 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log, trained new tellers on our escalation script." | Selection scaffold: pick a case you stayed with to the end, and what you did at each handover. If none comes to mind, say so, then give the nearest thing: how you ran the formal log. | Own the Fix, the value about keeping hold until it is solved. |
| B11 | "Give me two minutes on the complaints picture you would bring to a senior team." | CASE | [generic] | Structure: the headline, the volume, what resolution times say or do not say, and the decision you need. Name a figure here only if you have one from your own work. Do not invent one. | Presenting is your stated gap. This question tests structure, not a past. |

### Round 3: Panel of two branch managers (60 min incl. 20-min case), weights: Values/Behavioral 5, Pressure 3, Case 2

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You've never worked in a contact centre. Why should we trust you with complaints there?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause, then restate the question. Hold on what your material carries: six years in retail banking and the branch's log. Concede specifically: "I've never worked in a contact centre." Then give your plan. Hold through two follow-ups before any concession beyond that. | F8 under pressure. Hold-then-concede: never fold on the core claim. |
| C2 | "How much of the branch's complaints log was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log, trained new tellers on our escalation script." | Say what you handled in your own words. If the branch's process set parts of it, say which. Do not widen "handled" into "ran" or "owned". | F1 attribution probe. The honest answer is the quote at its own scope. |
| C3 | "When did you put a member ahead of an internal target?" | VAL | [generic] | Selection scaffold: pick a case where the member's need changed your approach. If none, say so plainly, then give the nearest thing your material carries. | Members First, Always, asked as a stem. |
| C4 | "In two sentences, what is an escalation for a member?" | VAL | [generic] | No story needed. Answer in plain words and stop. Ask for a clearer version of your own answer if the panel asks. | Plain Words, scored directly. Your answer is the evidence. |
| C5 | "Eight branches are moving into five hubs. Which of our towns would you handle differently from a central hub, and why?" | VAL | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as you summarised it) | Selection scaffold on local knowledge. If you do not know the towns, say so and say what you would ask first. Do not invent local detail. | Neighbours, Not Numbers, asked against the hub plan. |
| C6 | "Tell me about a problem you found that nobody had asked you to solve." | VAL | [generic] | Selection scaffold: pick a time you found an issue and kept hold of it. If none comes to mind, say so, then give the nearest thing your material carries: the formal log. | Own the Fix, scored directly. |
| C7 | "A member's complaint about a branch fee has been escalated twice. She now calls the contact centre, and her branch supervisor says the original decision was right. You have 20 minutes. What do you do?" | CASE | [generic] | **The 20-minute case. Structure:** 0 to 3 minutes, clarify: what the fee was, what the member wants, what the deadline is, who decided what. 3 to 8 minutes, options: a re-review, a supervisor conversation, an interim step for the member. 8 to 15 minutes, decide and act: one owner, a next step the member can follow, and the explanation in plain words. 15 to 20 minutes, measure and communicate: what you would record, what you would report, and who hears it next. Say the process is the one you would propose. Do not claim contact-centre experience. | Covers the JD's supervisor coaching and Own the Fix in one live problem. The case is the interviewer's, so the guidance makes no claim about your past. |
| C8 | "Three of our branches close into hubs over 2027. What happens to complaints from the branches that close?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as you summarised it) | Name the hub plan, then the questions you would ask: open cases, timescales, who owns them during the move. Do not claim to have run a consolidation. | Strategy-grounded differentiator. The brief is the only source, so the answer stays at the level the brief supports. |

## Values cheat sheet

Condition met: the panel scores against the four published values, and you pasted them. Each value maps to a story only where a quoted sentence carries one. Where none does, the honest branch applies.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No quoted sentence carries a member-side decision. Selection scaffold, B8 and C3. Honest branch: say so, then give the formal log. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | Nearest quote: "trained new tellers on our escalation script" (F3). Scaffold, B9 and C4. Honest branch: say so. |
| Neighbours, Not Numbers | Every branch is part of its town. | No quoted sentence carries it. Scaffold, C5. Honest branch: say what you would ask first. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | Nearest quote: "I handled the branch's formal complaints log" (F1). Scaffold, B10, C6 and C7. Honest branch: say so. |

## Reverse questions

Each has a reason it lands.

1. "What does a good first 90 days look like in this role, measured against the hub timeline?" Lands because it asks the manager to define success, which you can then test against.
2. "Where does a complaint currently get stuck between a branch and the contact centre?" Lands because it asks for the real problem, and it tells you where your branch log experience meets their process.
3. "Which resolution-time measure does the regional team use today, and who checks it?" Lands because it asks about the reporting requirement directly, and it surfaces whether F2's gap is one they expect you to fill.
4. "How does the digital team choose which self-service journey comes first?" Lands because it engages with the digital requirement without claiming prior work on it.
5. "What would make you say six months from now that this hire was the right call?" Lands because it asks for their scoring, which is the thing you are being measured on.

## Requirement coverage

| JD requirement | Questions |
|---|---|
| Own complaints end to end across branches and the contact centre | B1, B2, B4, C1, C7 |
| Monthly reporting on complaint volumes and resolution times | B5, B11 |
| Coach branch supervisors on escalations | B6, C7 |
| Work with digital teams on self-service journeys | A6, B7 |
| 4+ years in financial-services customer operations | A1 |
| Experience handling regulated complaints | B4 (discovery; see upgrade menu) |
| Confident presenting to senior leaders | B3, B11 |
| Comfortable with Excel reporting | B5 |

## Sources

- Provided documents: the JD text, the values page text (copied 19 November 2026), the strategy brief summary, the recruiter's email, and your background message.
- Search and fetch: none run. The pasted values, JD and strategy summary fixed every research target, so no calls were needed.
- Research tier: L1, searches 0 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page fixed the values cheat sheet |
| 2. Ashgrove interview process | skipped | The recruiter's email fixed the three rounds and their lengths |
| 3. Ashgrove strategy / recent news | skipped | The strategy summary you pasted supplies the current priorities. Its wording is yours, not the brief's, so verify before quoting |
| 4. Interviewer name | n/a | No names yet; the panel is not assigned |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot |

## Prohibited list note

Strategy quotes are as you summarised them. Check the published brief before using the exact wording in the room.

## Upgrade menu

- Whether the formal complaints log ran to set timescales or a regulator's rules → turns F6 and B4 from discovery into a stated answer
- Whether the spreadsheet recorded resolution times, and how → turns F2, B5 and the reporting line into stated evidence
- Any stage of a complaint you set yourself → turns F1 and B1 into a grounded answer rather than a plan
- The published strategy brief, not the summary → verifies the wording in A6, C5 and C8
- Round 2 and panel names → personal persona weights and a tailored reverse question
- A tuesday-dossier.md would carry the gaps this prep exposed into later sessions
