Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-5-denied-381c3b28/785f8f06-3cfe-43d7-bf49-dcc4c0d5fb19/scratchpad/kelverton-rail_senior-partnerships-manager_interview_pack.md`.

It's built on your message alone. I didn't have the job description or the market report's text, and my one web search for Kelverton was refused by the host, so the pack has no company research. The panel and POV are your own words, so the structure is solid, but the commercial and strategy content is generic until I see the report.

The three things to prepare most:

- **The POV (section 4).** Three theses, each with a concession, plus an explicit anti-pick. The close is "what it means for the operators themselves", framed as hypotheses to test, since you have no operator-side rail experience.
- **B2, the quota question.** You've never carried a direct quota, and that is the question most likely to come up in some form. Hold on the influenced £4M, concede the quota gap plainly, and give a ramp plan rather than a past.
- **C1 and C2, Ross on the influenced number.** Know what the £4M measured, what you can't defend about how it was counted, and where you'd say "I don't know".

Prep triage is in the file, sized to about four hours.

Two things I chose: I treated the panel as a hiring-manager round (Deepa) blended with a commercial-director round (Ross), and I left out the values cheat sheet and interviewer read because no values round or public profile was available.

Would you paste the market report's lead recommendations and the job description? The report's consensus shortlist is what the POV has to differentiate from, and the JD would turn the role-family requirements into exact quotes.

If you'd like me to play the Skeptic on B2 as a live drill, say the word. I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later sessions.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: kelverton-rail_senior-partnerships-manager_interview_pack.md -----
# Interview prep pack: Senior Partnerships Manager, Kelverton Rail

**Round:** second round, panel, 60 minutes. First 15 minutes: a short point of view (POV), no slides.
**Panel:** Deepa, VP Partnerships (your future manager). Ross, Commercial Director (will push on commercials).
**Built on:** your message only. No job description, no market report text, no public research (see Sources).

## How to use this pack, and the type key

Personas describe how a question arrives. Types describe what is being scored.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Values | Published values, shown in past behaviour. None detected here. |
| EXP | Experience | Whether your past claims survive scrutiny, and what you did yourself. |
| JD | Role | Whether you can do the listed job, including its gaps. |
| CO | Company and strategy | Whether you think at their altitude. Limited here, see Sources. |
| CASE | Live problem | Structure and reasoning on a problem from the role. |

Guidance is scaffolding, not a script. Where guidance says "answer slot", it wants your own answer in your own words, and either honest branch is a good answer.

## Prep triage (about 4 hours)

1. **75 min. Build the POV (section 4).** Choose one thesis, write its concession, then say the 15-minute version aloud twice and time it.
2. **45 min. Commercial drill.** C1, C2 and C3, with Ross interrupting.
3. **30 min. The highest-return rehearsal.** B2, the quota question, held through two follow-ups.
4. **30 min. Case questions.** A2, A4 and A7.
5. **20 min. Reverse questions (section 11).** Pick the three you would ask on Tuesday.
6. **20 min. Re-read the pack.** Cut any sentence about your past that is not your own.

Everything else is insurance.

## 1. Fit snapshot

Requirements come from your message, where you quoted the recruiter. No JD was supplied, so there are no `[inferred]` JD requirements. Rows F3 and F4 are the two gaps the panel is most likely to test.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "our operator partnerships over the next 18 months" (your message) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | transferability | Your material says transport consulting on bus and light rail planning, and the operator world from the other side. It does not say you have run an operator relationship, so keep the claim at that scope. Answer slot: if you held a direct operator relationship, say what it was in your own words; if you did not, say so plainly and say how you would learn the operator view. |
| F2 | [generic] grows a partner base and the revenue it brings (role family, unquoted) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Keep the word influenced: "I took it from 6 partners to 40." The £4M is influenced revenue, and say so when you say it. |
| F3 | [generic] carries a commercial target for partner-sourced revenue (role family, unquoted) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | This is a gap you stated, so the words are yours to give: "I've never carried a direct quota." Then the number you can stand behind: "roughly £4M of influenced revenue." Closing the gap is a plan, not a past: how you would ramp into a target, and what you would ask for first. |
| F4 | [generic] sells into rail operators (role family, unquoted) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't sold into rail." Then how you would learn the rail buying cycle, framed as a plan. |
| F5 | [generic] leads partnerships at senior level (role family, unquoted) | "9 years in partnerships" (your message) | low | [inferred] | discovery | Years alone do not show seniority, and the material does not show whether you have set strategy or led people. Answer slot: if you have set partnership strategy or led others, say what, in your own words; if not, say so, and say what you would need to show. |

## 2. Prohibited claims

These are not coached anywhere in the pack, including in answer slots, holds, bridges and reverse questions. Built here because no dossier was supplied.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned £4M of revenue, or drove £4M | Inflated form of F2. The material says influenced, not owned. | "Roughly £4M of influenced revenue," at its own scope. Pack observation: your material says influenced, not owned. |
| Carried a quota, or closed partner deals to target | Sourced negative (F3) | "I've never carried a direct quota." No slot. |
| Sold into rail, or built rail accounts | Sourced negative (F4) | "I haven't sold into rail." No slot. |
| Ran operator relationships, or know the operators' side of the business | Inflated form of F1. Your consulting was on the planning side of transport work. | The F1 quote at its own scope. |
| Cut operator delays, costs or disruption by any figure | Outcome you never stated. | Describe what you would test with operators, as a hypothesis, with no figure. |

## 3. Persona weights

Relationship priors: a hiring-manager round sets Case/Strategist and Skeptic as the starting weights. A commercial-director round sets Pressure and Data-Driven Prober. The panel is a blend, assigned per member below. No interviewer profile was available, so there is no profile-based adjustment.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist (Deepa) | Live problem on operator partnerships, and the POV's first-90-days and measurement questions | High. The POV is a graded deliverable, and a manager is buying judgement on her own problem. | Name the one hypothesis your POV rests on, the test, and the operator metric it would move. |
| Pressure (Ross) | Interrupts the commercial answers, time-boxes them, asks for a number | High. The recruiter said Ross will push on commercials. | Pause, restate the question, hold a position through two follow-ups before conceding anything real. |
| Data-Driven Prober (Ross) | Asks how the £4M was counted, and what the influenced figure is sensitive to | Medium to high. The one number on your CV is an influenced figure, which is what a prober tests first. | Name the weakest assumption before he does. Say plainly what you do not know about the counting. |
| Skeptic (Deepa) | Quota gap, rail gap, seniority | Medium. Your three gaps are the ones a manager most wants to check. | Rehearse the quota question until it is plain. Concede precisely. |
| Conversational (Deepa) | Opening walk-through, motivation for rail | Low to medium. Casual, but still scored. | Use a 90-second arc built on the quoted sentences. |

Depth follows weight. Case/Strategist gets 6 questions, Pressure and Prober together 6, Skeptic 4, Conversational 2: a total of 18.

## 4. Graded deliverable: the 15-minute POV

Your message quotes the brief: a short POV on "where you'd take our operator partnerships over the next 18 months", with the close "Please land on what it means for the operators themselves." No slides.

**Grounded facts to build on:** F1 ("5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)") and F2 ("took it from 6 partners to 40, roughly £4M of influenced revenue"). Every claim about your past in the POV must be one of these sentences, at its own scope.

**Three theses. Each carries a concession.**

- **T1. Partner on an outcome operators already report.** Build the partnership around one scheduling measure that operators already answer to. *Concession:* much of that outcome depends on things the software does not control, such as crews and engineering access, so attribution will be contested. Define the shared measure before any contract.
- **T2. Sell to the people who build the timetable.** Start with network planning teams and use the trade-offs they already make. *Concession:* planning teams often have no budget line, and the buying decision sits with commercial or contract teams. Frame the planning view as a hypothesis, drawn from how network planning works, not from having run those relationships.
- **T3. Scale through integrators.** Enable the systems integrators who already work with operators. *Concession:* there are few rail integrators, the channel takes margin, and you give up direct contact with the operator. This thesis draws on the channel mechanics in F2.

**Anti-pick.** Say plainly that you would not start with the largest operators. Start with one or two whose contract cycle lands inside the 18 months, and say no to a broad pitch. The pitch should show the choice.

**Differentiation against the consensus answer.** I have not seen the market report, so I cannot name its shortlist. Upgrade menu item 1 covers this. Until then, take the report's lead recommendation as the one consensus item to acknowledge, and diverge from it with one reason.

**Operator close.** Land each thesis on what it means for an operator, as a hypothesis to test with them: a measure they can take to their own board, the planners keeping control of the timetable, and one thing they would have to accept. Do not claim an operator outcome as a fact.

## 5. Question banks

Provenance quotes are your own sentences from section 1 or from your message. Questions are the panel's line.

### Case/Strategist (Deepa): 6 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What is the first thing you would test with an operator in the first 90 days?" | CASE | [generic] | Name the single hypothesis your POV rests on, the test, who you would run it with, and the operator metric it would move. Keep it to one test. | The POV's first hypothesis is the probe a manager asks next. [generic] because it is a pattern for the problem, not a fact about this company. |
| A2 | "Which operators would you start with, and why those?" | CASE | [generic] | Criteria in order: contract cycle timing, willingness to share planning data, and size. Then the anti-pick: why not the largest. | Follows the POV's anti-pick, and tests judgement about the buyer. |
| A3 | "Why now, for operator partnerships in the next 18 months?" | CO | [grounded] "where you'd take our operator partnerships over the next 18 months" (your message) | Give the reason the strategy gives, in your own words. Answer slot: if the reason is one you cannot explain, say so and say what you would check first. | The recruiter's own framing sets the 18-month horizon. Strategy detail is missing (see Sources), so the answer must not assume it. |
| A4 | "An operator's planning team says the scheduling tool adds work for them. What do you do?" | CASE | [generic] | Structure: what you would ask them first, what you would change this quarter, what you would not change, and what you would record. Needs no claim about your past. | The close asks what it means for operators, and this tests it with a live complaint. |
| A5 | "How would you know, in 18 months, that this worked for an operator?" | CASE | [grounded] "what it means for the operators themselves" (your message) | Name two operator-side measures, where the data would come from, and one measure you would not trust. | The recruiter's close, turned into a test of measurement. |
| A6 | "Walk me through how you would decide which operator to say no to." | CASE | [generic] | Name the criteria you would use to decline, and the person you would tell. Keep the anti-pick concrete. | Tests the anti-pick from section 4 without asking about your past. |

### Skeptic (Deepa): 4 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "What would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" (your message) | Say the rail gap in your own words: "I haven't sold into rail." Then how you would learn the rail buying cycle, as a plan. | F4 is the gap the panel will check first. |
| B2 | "You've never carried a quota. Why should we give you a commercial number?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" (your message); "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | **The highest-return rehearsal in this pack.** Hold: the number you can stand behind is the influenced revenue, and say what you did to grow the partner base. Concede: "I've never carried a direct quota." Then a plan, not a past: a ramp into a target, and what you would ask for first. Hold through two follow-ups by returning to "roughly £4M of influenced revenue." Answer slot: if you had any closing responsibility on a deal, say what; if you had none, say so plainly. | F3 is the commercial gap, and this is the question most likely to be asked in some form. The answer must not reach past what you stated. |
| B3 | "Five years in transport consulting. Which side of the table were your clients on?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | Open question, so answer it from your own experience. Say which side you worked on, and what that gave you. Do not describe operator-side experience you did not have. | F1 is the transferability case. Probing the side of the table tests the relationship inversion the prohibited list guards against. |
| B4 | "Influenced revenue is what a partner claims credit for. Did the partners you added come to you, or did you go to them?" | EXP | [grounded] "took it from 6 partners to 40" (your message) | Answer slot: if you went to them, or they came to you, say which and what you did; if the answer is mixed, say so. Do not invent a sourcing story. | Tests whether the 6-to-40 growth is yours to describe, which the material does not show. |

### Pressure and Prober (Ross): 6 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should anyone believe influenced revenue means anything?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Pause, then state the number and what it measured. Concede what influence cannot prove. Hold the number through two follow-ups. Answer slot on counting: if you know the rule used to count influence, say it; if you do not, say you do not know how it was counted. | The pressure version of the influenced-revenue question. Hold, then concede the part that is genuinely unproven. |
| C2 | "Walk me through how the £4M was counted." | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Name the weakest assumption behind the figure before Ross does. Answer slot: which part of the count was yours, and which was the company's rule. Say plainly what you cannot defend. | Defend-the-number question. The pack does not supply a counting method, because you have not given one. |
| C3 | "Give me a number you would commit to in year one." | JD | [generic] | Do not invent a figure. Give the method: a ramp with a stated assumption and the variable that moves it, and say which number you would want to confirm first. | Commercial pressure with no past basis. The pack supplies no year-one figure. |
| C4 | "Who in an operator actually pays for this?" | CO | [generic] | Name the budget holder as a hypothesis you would test. Do not claim knowledge of operator budgets you do not have. | Commercial probe on the operator side, where your material is thinnest. |
| C5 | "Is the POV a commercial plan or a wish list?" | CASE | [generic] | Separate the parts with a revenue line from the parts that are hypotheses. Say which is which, plainly. | Tests whether the POV can carry a commercial case, which Ross will push on. |
| C6 | "If the partner doesn't hit its number, whose fault is it?" | EXP | [generic] | Hold the shared-measure point from T1: the outcome depends on things the software does not control. Name who would decide what counts as a miss before the contract, and do not blame the partner or the product. | A pressure version of the attribution problem in T1's concession, asked as a blame question. |

### Conversational (Deepa): 2 questions

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "9 years in partnerships" (your message); "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message); "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | A 90-second arc: transport planning, then partnerships, then the channel at the payments company, then why rail. Use only these sentences. Keep it under two minutes. | Covers F1, F2 and F5 in the order they are asked. |
| D2 | "What's drawing you to rail specifically?" | EXP | [grounded] "Never sold into rail specifically" (your message) | Answer slot: give your own reason in your own words. The material shows transport planning work and no rail selling, so say that plainly and connect it to the operator view. | Motivation is scored, and the answer must not reach past what you stated. |

**Count:** 6 + 4 + 6 + 2 = 18 questions in the banks.

**Requirement coverage.** "our operator partnerships over the next 18 months": A1, A2, A3, A6, B3. "what it means for the operators themselves": A4, A5. The commercial requirement (role family): B2, C1, C2, C3, C4, C5, C6. Rail selling (role family): B1, D2. Senior leadership (role family): B4, D1. Quota ownership: B2, C3.

## 6. Values and principles cheat sheet

Omitted. No values-style round was detected, and no published values were in hand.

## 7. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would success look like for this role at six months, and at eighteen?" | Ties your answer to the 18-month horizon Deepa set, and tests what a manager means by it. |
| R2 | "Which operators are you most worried about losing, or failing to reach?" | Shows you are thinking about operators, not only the pipeline. |
| R3 | "How is the commercial target set for this role, and how much would be partner-sourced versus direct?" | Asks Ross directly about the structure you have not carried. It converts his push into a shared question. |
| R4 | "Where do operator partnerships sit today between product, planning and sales?" | Tests the seam you will have to work across, without assuming the answer. |
| R5 | "What would make you say, twelve months in, that you hired the wrong person?" | A manager's answer tells you what she is actually scoring. |

## 8. Interviewer read, delivery coaching

Both omitted. No public footprint for Deepa or Ross was researched, and no working-style assessment was offered.

## 9. Sources

- **Provided:** your message, including the recruiter's quoted lines, the panel and format, and your background. The market report is not in what I have. You said you have read it, but I have not seen its text, so this pack does not describe its contents.
- **Searches and fetches:** one web search for the company (query: "Kelverton Rail scheduling software train operators") was refused by the host, which did not grant permission. No results were returned, and no fetch was attempted.

**Research tier:** L1 requested, not delivered. Searches 0 of 6 (one refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton values | unavailable | Values cheat sheet (section 6). Omitted anyway, since no values round was detected. |
| 2. Interview process, role family | skipped | Round structure is fixed by your message: panel, 60 minutes, a 15-minute POV, then Q&A. |
| 3. Company strategy and recent news | unavailable | Current strategy for the CO questions (A3, C4). The one refused search covered this target. |
| 4. Deepa and Ross, public footprint | unavailable | Interviewer read (section 8) and persona weights from their backgrounds. Names and titles were in hand, so the search could be formed, but it was refused. |
| 5. Representative JD for the title | unavailable | Would have made requirement rows `[inferred]` instead of role-family prose. No JD was supplied, and the search was refused. |

## 10. Prohibited claims, rendered

Section 2 is the list. It binds every answer slot, hold and reverse question above.

## 11. Upgrade menu

- **The market report's lead recommendations, pasted here.** This is the consensus item the POV must differentiate from (section 4), and it upgrades A3 and A5 from strategy-free to grounded.
- **The job description text.** Rows F1 to F5 that now carry role-family wording become `[grounded]` requirement quotes, and the JD-tagged questions can use the posting's exact lines.
- **Permission to run research (L1).** Company strategy and recent moves would ground the CO questions (A3, C4), and public footprints for Deepa and Ross would add an interviewer read and sharper reverse questions. Deep research (L2) is also available, once, for strategy briefs, interviewer writing and loop reports. It adds up to six searches and two fetches and needs your go-ahead.
- **How the £4M influenced figure was counted, in your own words.** This sharpens the answer slots in C1 and C2. Nothing is supplied for you.
- **Any direct operator-side or rail-adjacent work.** Confirms or narrows the transferability in F1 and the rail-selling gap in F4.
- **A dossier, `tuesday-dossier.md`, from a prior session.** It would add verified evidence and any prohibited claims to this pack.
