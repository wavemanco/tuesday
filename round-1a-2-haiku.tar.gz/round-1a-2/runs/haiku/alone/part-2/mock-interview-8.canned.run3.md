Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-8-canned-79f252d6/aed9dd4d-93bf-4d26-93c1-8d2fed1ac146/scratchpad/ashgrove_member-experience-lead_interview_pack.md`. It covers all three rounds: 24 questions, a fit snapshot, a values cheat sheet, reverse questions for each interviewer, and the escalation case.

One thing to check first: 28 November 2026 is a Saturday. Confirm the date and times with the recruiter.

The biggest risk is H1, "Which part of this role would you be weakest at on day one?" The honest answer is the contact centre, which you have never worked in. Rehearse saying that first, then what carries over from the complaints log, then what you would learn first. The pack also has a pressure question on your lack of senior presenting (H8). It gives the honest sentence to say and the point where you should concede rather than fold.

Some things the pack doesn't claim, because your material doesn't support them:
- Whether the complaints were regulated, or which rules applied.
- Whether your spreadsheet measures resolution times.
- Any coaching of supervisors. You trained tellers and supervised, but the pack doesn't claim you coached.
- Any Excel detail beyond "spreadsheet".

Consolidating eight branches into five hubs sits against your values. The pack tells you to answer from the member's side and not to argue the decision with the panel, who may be affected.

I didn't run any web research. Your pasted values, the recruiter's email and the strategy brief were enough to ground the pack. I also didn't assume your pay, notice, location or reason for leaving; those are answers only you can give.

Would you like me to play the Head of Member Services on H1 in a live drill, with follow-ups that react to your answer? I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Member Experience Lead, Ashgrove Credit Union: interview prep pack

Loop mode: three rounds on 28 November 2026, shared fit snapshot, one mini-pack per round.
Interviewers: recruiter (30 min), Head of Member Services, your future manager (45 min), panel of two branch managers (60 min, including a 20-minute escalation case, and the values round). Names are not given for any of them.

## How to use this pack

Personas are how a question is asked. Types are what it scores:

- **VAL**: values and behaviour, scored against the four published values
- **EXP**: your own past work, and whether it holds up under questions
- **JD**: requirements straight from the job description
- **CO**: company strategy, which you should sound current on
- **CASE**: a live problem from the role

Guidance is scaffolding, not a script. Say it in your own words. Where a guidance cell says "answer slot", it is an instruction for the interview, not a question to me.

Highest-ROI prep: **H1**, the contact-centre gap. It is the largest requirement you cannot claim, the Head of Member Services is the person who would manage it, and it will almost certainly come up in some form. Rehearse it until the plain acknowledgment comes out first and cleanly.

## Fit snapshot

Requirements are quoted from the job description, the recruiter's email or the values and strategy text you pasted. Your evidence is quoted from your own message, since no CV was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | Your quote reaches the requirement in role-relevant terms. Words: "I have six years in retail banking, the last three as a branch supervisor." Expect a probe on whether retail banking counts as financial-services customer operations; your own description answers it. |
| F2 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log" — your message | medium | [grounded] | transferability | Your material says formal complaints, in one branch's log. It does not say the complaints were regulated, or which rules applied. Answer slot: the JD's "regulated" line makes a probe on rules and timescales likely. If any applied to your log, say which and what you did, in your own words; if none did, or you did not know them, say so plainly and say how you handled the log. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" — JD | "I handled the branch's formal complaints log" — your message | low | [inferred] | transferability | Your material shows one branch's formal log, not an end-to-end process across branches. Bridge: "I handled the branch's formal complaints log." Answer slot: which steps of a complaint were yours to set (logging, deciding, replying, closing); if none were, say so and stay with the log you ran. |
| F4 | "Own the member complaints process end to end across branches and the contact centre" — JD | "Never worked in a contact centre." — your message | none | [grounded] | capability | Stated absence; the gap wording cannot close. Words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan and never as a past. Never describe contact-centre work you have not done. |
| F5 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | discovery | Your material does not show whether the spreadsheet counts volumes, resolution times or both. Answer slot: if it counts resolution times, say how it is counted and which assumption you would defend least; if it does not, say so and say what you would add first. |
| F6 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Your quote already reaches reporting, but does not name the tool. Bridge reworded from the quote only: "I built the monthly complaints spreadsheet our regional manager uses." Say the tool's name only once you have confirmed it. |
| F7 | "coach branch supervisors on escalations" — JD | "trained new tellers on our escalation script" — your message; "the last 3 as a branch supervisor" — your message | low | [inferred] | transferability | Your material shows you trained tellers on an escalation script, and supervised for three years. It does not show coaching supervisors. Bridge: "I trained new tellers on our escalation script, and I was a branch supervisor for the last three years." Answer slot: if you have coached a supervisor on an escalation, say how; if not, say so and describe the nearest thing you did. |
| F8 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material says nothing on this. Answer slot: if you have worked with anyone on a self-service journey, say who and what changed; if not, say so plainly and say what you would look at first, as a plan. |
| F9 | "confident presenting to senior leaders" — JD | "I've never presented to anyone above regional level." — your message | none | [grounded] | capability | Stated absence. Words: "I haven't presented to anyone above regional level." Then how you would prepare, as a plan. Never describe presentations to senior leaders. |

Gap types, in plain terms:

- **Capability** rows (F4, F9) are gaps you stated. Give the honest sentence, then the plan.
- **Discovery** rows (F5, F8) are gaps the material is silent on. They become answer slots.
- **Transferability** rows (F2, F3, F7) are adjacent work. Make the case at the scope the quote carries, and name the limit.

## Prohibited claims

Not coached in any answer, hold or drill, because the material does not support them. Each is built from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Running complaints across a contact centre | Inflated form of F3 and F4; you stated you have not worked in one | The F4 sentence, "I haven't worked in a contact centre." The pack's own observation: your material shows a branch log only. |
| Owning the complaints process end to end across branches | Inflated form of F3 | F3's quote at its own scope: the branch's formal complaints log. |
| Handling regulated complaints, or knowing the rules that applied | Inflated form of F2 | F2's quote at its own scope: formal complaints. Slot stays inside that scope. |
| Presenting to senior leaders | Negative you stated, F9 | "I haven't presented to anyone above regional level." No slot. |
| Coaching branch supervisors on escalations | Inflated form of F7; you trained tellers and supervised | The F7 quote at its own scope. |
| The spreadsheet measures resolution times, or feeds group reporting | Inflated form of F5 and F6 | "I built the monthly complaints spreadsheet our regional manager uses." Whether it measures resolution times is an answer slot (F5), not a claim. |

## Persona table

The recruiter's email says the Head of Member Services round is "mostly behavioural", so it overrides the usual hiring-manager weighting. The panel is weighted on values because the recruiter says it scores against the four values.

| Round | Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|---|
| Recruiter, 30 min | Conversational / rapport | Friendly openers, logistics, motivation | Heaviest. Recruiter-screen prior; logistics and motivation are asked casually and are still scored | Pre-scripted 90-second arc; treat casual questions as scored; answer logistics in your own words |
| Recruiter, 30 min | Skeptic, light | "Why this role, why now" | Light. Prior for recruiter screens; the reason for leaving is the only probe | Give the reason plainly, without elaboration |
| Head of Member Services, 45 min | Skeptic | The contact-centre and senior-presenting gaps, raised by the person who would manage them | Heaviest. Your two stated gaps are the first thing a manager checks | Name the gap in the first sentence, then the plan; hold through two follow-ups |
| Head of Member Services, 45 min | Values / behavioural | "Tell me about a time…" against the values | Heavy. The recruiter says the round is mostly behavioural | STAR shape, "I" for what you did, "we" for the branch; only the stories your quotes carry |
| Head of Member Services, 45 min | Case / strategist | Hubs and digital, as plans for next year | Middle. Your manager's roadmap is the strategy brief | Say the framework aloud; clarify before structuring |
| Head of Member Services, 45 min | Pressure | "Why would I put you in front of senior leaders?" | Light. A composure check on a stated gap | Pause, restate, hold, then concede the specific gap |
| Panel, 60 min | Values / behavioural | Four scored values stories | Heaviest. The panel scores the four values | Map each value to a story, or use the honest branch |
| Panel, 60 min | Case / strategist | 20-minute escalation case, plus a hub-merger case | Heavy. The case is the longest single block in the loop | Clarify → objective → owner → steps → record → member communication → risks |
| Panel, 60 min | Skeptic / pressure | Coaching supervisors; supervision track record | Light. Two targeted probes | Plain sentences; hold the supervision record, concede what you have not done |
| Panel, 60 min | Data-driven prober | The monthly report | Light. One probe on what the spreadsheet counts | Name what it counts; name the assumption you would defend least |

## Question banks

### Recruiter round (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | A ninety-second arc from those two sentences: the six years and the last three as a supervisor, then the complaints log and the teller training, in your own words. Nothing beyond them. | F1 and F2 are first heard here, and the arc is the first impression. |
| R2 | "What's drawing you to Ashgrove?" | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." | Choose one published value you can tell a story for from your own material, and say why it matters to you. Keep it on the work, not on a strategy you have only read in a brief. | Motivation is asked in every screen; the recruiter scores whether you read the values. |
| R3 | "What are your pay expectations?" | JD | [generic] | Logistics slot: give your own number, or ask for the band the role carries before you name one. No figure is supplied in this pack. | Pay is a knockout check in a friendly register; nothing in your material fixes a figure. |
| R4 | "What's your notice period?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. | Notice is a knockout check; only your own figure fills it. |
| R5 | "Where would you need to be based?" | JD | [generic] | Logistics slot: state the locations and days you can work, in your own words. The role's office pattern is not in the JD or the brief; ask the recruiter before you commit to one. | Location is a knockout check; the role's pattern is not in the material. |
| R6 | "Why are you looking to move now?" | EXP | [generic] | Logistics slot: give the reason in your own words, at the level you would give a manager. No reason is supplied in this pack. | The reason for leaving is the motivation-consistency check; it must match the rest of the story. |

### Head of Member Services round (45 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre." | The highest-ROI rehearsal in this pack. Lead with the stated gap: "I haven't worked in a contact centre." Then what carries over, in the words of F3: "I handled the branch's formal complaints log." Then what you would learn first, as a plan. Hold through two follow-ups by returning to the complaints log, never by adding to it. Concede exactly what is missing: contact-centre flow, call volumes, and the people who run it. | F4 is the largest requirement you cannot claim, and this manager will test it first. Naming it early is the non-defensive answer that changes the interview. |
| H2 | "Your experience is branch-based. How would you run complaints across a contact centre you haven't worked in?" | JD | [grounded] "I handled the branch's formal complaints log" "Never worked in a contact centre." | Answer slot: if you have handled any contact-centre complaint or escalation, say how, in your own words; if not, say so plainly and describe how you would learn the contact-centre side, as a plan. | F3 and F4 together: a premised question whose premise is the stated gap. The second branch allows that no such experience exists. |
| H3 | "Tell me about a time a complaint you handled didn't end where the member wanted." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt: choose a complaint that reached the formal log. Say what the member wanted, what you did, and what stayed unresolved, then what you did next. "I" for what you did, "we" for the branch. If no such complaint comes to mind, say so plainly, then describe the nearest one the log carried. | Tests Own the Fix in behavioural form. Only the log is in your material, so the story stays within it. |
| H4 | "Tell me about a time you had to explain something to a member more than once." | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt: choose a time you explained something and had to explain it again. Say what you changed in how you said or wrote it. If no such time comes to mind, say so plainly, then describe how you trained tellers on the script, without claiming the script was your rewrite. | Plain Words in behavioural form; the teller training is the nearest sentence you have. |
| H5 | "How would you keep complaints sound as eight branches become five hubs during 2027?" | CO | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as pasted) | Structure, not forecast: what the member sees on day one of a move; which open complaints move and which stay with the branch; what you would measure before and after. Say what you would protect. Do not argue for or against any closure. | The strategy names this change, and the panel's branch managers may be living through it. Tension to hold: Neighbours, Not Numbers against consolidation. |
| H6 | "The strategy is to move 40% of member service to digital channels by 2028. What happens to the complaints that stay at the counter?" | CO, JD | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, as pasted) | Clarify first what counts as member service in that 40%. Say which complaint types you would expect to move online and which will not. Name what you would want to measure. Do not guess the split. | Covers the JD's self-service line from the strategy side. No question asks about your past work with digital teams; F8 is the answer slot if one is raised. |
| H7 | "Walk me through how you would coach a branch supervisor on an escalation that went wrong." | JD | [grounded] "trained new tellers on our escalation script" | Answer slot: if you have coached a supervisor on an escalation, say how and what changed; if not, say so plainly, then describe the nearest thing you did and how you would open the first conversation. | F7: coaching is in the JD; the nearest sentence is teller training. |
| H8 | "You've never presented above regional level. Why would I put you in front of senior leaders?" | JD | [grounded] "I've never presented to anyone above regional level." | Pause, then restate the question. Plain acknowledgment: "I haven't presented to anyone above regional level." Then hold: what you can point to is the monthly spreadsheet your regional manager uses. Hold through two follow-ups; concede specifically: you have not presented to this level, and you would want support on the first one. Never fold on the claim that the spreadsheet is a presentation. | F9, the senior-presenting gap, under pressure. A held position they can back is the one that survives the second follow-up. |
| H9 | "Walk me through what your monthly complaints spreadsheet counts." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Describe what the spreadsheet tracks, in your own words. Name the measure you would defend least. Answer slot: if it tracks resolution time, say how it is counted; if it does not, say so and say what you would add first. | F5: a defend-the-number question for a report the JD asks for. |

### Panel round (60 min, including the 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Tell me about a time you decided something from the member's side of the counter, when the process pointed the other way." | VAL | [grounded] "Members First, Always — we decide from the member's side of the counter." | Selection scaffold: pick a decision where the member's view and the process disagreed. Say what the process said, what the member needed, what you chose and why. If no such time comes to mind, say so plainly, then give the nearest complaint from your log, in its own terms. | Members First is scored; your material carries no story for it, so the honest branch is the answer. |
| P2 | "Tell me about a problem you found that nobody had been assigned to fix. What did you do?" | VAL | [grounded] "Own the Fix — whoever finds the problem keeps hold of it until it is solved." "I handled the branch's formal complaints log" | Selection scaffold: pick a problem you found. State what you did and what stayed open at the end. The value says "until it is solved", so do not say it was solved unless it was. If none comes to mind, say so plainly, then describe the nearest thing the log carried, without claiming it closed. | Own the Fix is tested by what stayed open; the honest answer is the test. |
| P3 | "Tell me about a time a number pointed one way and the town pointed the other." | VAL | [grounded] "Neighbours, Not Numbers — every branch is part of its town." "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold: pick a time a figure and a local situation disagreed. If your spreadsheet has such a case, say what it showed and what you did; if not, say so plainly and describe how you would check a figure against the branch. | Neighbours, Not Numbers is the value your material is thinnest on, and a spreadsheet is a number. Say where the number stops being enough. |
| P4 | "Tell me about an explanation you rewrote because it didn't land." | VAL | [grounded] "Plain Words — if a member needs it explained twice, we wrote it wrong." "trained new tellers on our escalation script" | Selection scaffold: pick a time an explanation had to be reworked. Say what you changed. If none comes to mind, say so, then describe the teller training as the nearest thing, without claiming it was your rewrite. | Plain Words is scored; the honest branch applies. |
| P5 | "A member has escalated a complaint for the second time. The first reply was a template. What do you do?" | CASE | [generic] | Clarify before structuring: what the member asked for, what the log shows, what has been decided and who decided it. Then objective, owner, steps: a reply in plain words, the next checkpoint, what you record, when it goes up a level. Name a timescale only if you know it; if you do not, say you would check it first. Challenge one premise respectfully. | The escalation case the recruiter named. Uses the role's own problem and makes no claim about your past. |
| P6 | "Your branch is one of the eight going into a hub next year. Complaints rise in the two months before the move. What do you do?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as pasted) [generic] structure | Clarify whether the rise comes from the move or from earlier. Separate open cases from new ones. Keep local contact points in view and say what you would tell the town. Do not debate the closure decision. | Second case; combines the strategy with escalation. Branch managers may be living this, so treat the decision as settled. |
| P7 | "How would you coach a supervisor whose escalations keep coming to you when they should have been settled at the counter?" | JD | [grounded] "trained new tellers on our escalation script" | Answer slot: if you have coached a supervisor on this, say how and what changed; if not, say so plainly, then describe the first conversation you would have and what you would look at with them first. | F7 again, from a different angle: the panel tests coaching separately from the manager. |
| P8 | "You've supervised for three years. Why should two branch managers believe you can coach supervisors across more than one branch?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Hold: state what you did as a branch supervisor, then what you have not done. Concede specifically: coaching across branches is new to you. Do not fold on whether you can supervise. | A pressure probe on F7. Two follow-ups before you concede anything real. |
| P9 | "Walk us through how you report complaint volumes and resolution times each month." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Describe what your monthly spreadsheet covers, in its own terms. Answer slot: if it covers resolution times, say how they are counted and which assumption you would defend least; if it does not, say so and say what you would add. Do not say senior leaders use it, because the material says your regional manager does. | F5 and F6: a defend-the-number question on the JD's reporting requirement. |

### Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| 4+ years in financial-services customer operations | R1 | Covered by the arc and F1 |
| Experience handling regulated complaints | H3, P5 | F2 answer slot sits in H3 and in P5's clarify step |
| Own the complaints process end to end across branches and the contact centre | H1, H2, P6 | The contact-centre gap is H1 |
| Report monthly on complaint volumes and resolution times | H9, P9 | F5 answer slot |
| Coach branch supervisors on escalations | H7, P7, P8 | F7 answer slot |
| Work with digital teams on self-service journeys | H6 | Strategy side only. No question asks about past digital work; F8 is the answer slot if one is raised |
| Confident presenting to senior leaders | H8 | F9 |
| Comfortable with Excel reporting | H9, P9 | F6 |

## Values cheat sheet

The panel's round is the values round, because the recruiter says it scores against the four values. Each value maps to a story only where one of your quoted sentences carries one. None of them does fully, so each row gives the honest branch.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a story. Selection scaffold in P1; if none comes, say so, then the nearest complaint from your log. |
| Plain Words | If a member needs it explained twice, the wording was wrong | F7 quote: "trained new tellers on our escalation script." Selection scaffold in P4; the teller training is the nearest thing, and not a rewrite of the script. |
| Neighbours, Not Numbers | Every branch is part of its town | F5 quote: "I built the monthly complaints spreadsheet our regional manager uses." Selection scaffold in P3; say where a number stops being enough. |
| Own the Fix | Whoever finds the problem keeps hold of it until solved | F3 quote: "I handled the branch's formal complaints log." Selection scaffold in P2; say what stayed open, do not claim closure. |

## Grounding brief

Vocabulary and facts from the material you pasted. Current as of this pack. Terms to use: the brief's own.

| Item | Source | Note |
|---|---|---|
| Member-owned, about 900 staff | JD, as pasted | Use the JD's own description |
| "consolidate eight branches into five hubs over 2027" | Strategy brief, July 2026, as pasted | Dates to 2027; the panel's branch managers may be affected |
| "move 40% of member service to digital channels by 2028" | Strategy brief, as pasted | Ask what counts as member service before you answer |
| "launch a small-business lending product in Q1 2027" | Strategy brief, as pasted | Not in the JD; use only if asked about the wider business |
| "the main competitive pressure is app-only banks" | Strategy brief, as pasted | Frame the competitive context in the brief's own words |

Tension to hold, not to correct: the values say "Neighbours, Not Numbers — every branch is part of its town", and the brief consolidates eight branches into five hubs. Answer from the member's side, and do not argue the decision with the interviewer.

## Reverse questions

Each has a reason it lands. No interviewer profiles were provided, so none ties to a career path. The panel is not a peer round, so no reciprocity question.

**Recruiter**

- "Is the 28 November schedule confirmed for each round, and which day is it?" Why it lands: you noticed the date needs checking, and it is a practical question the recruiter can answer.
- "What is the brief for the 20-minute case, and will I get any material beforehand?" Why it lands: shows you are ready for the case without asking for the answer.
- "Which of the four values do candidates most often find hardest to show?" Why it lands: shows you are preparing for the values scoring, and it tells you where to spend your time.

**Head of Member Services**

- "How is complaint handling split today between branches and the contact centre, and where does an escalation get stuck?" Why it lands: it tests the end-to-end requirement and shows you read the JD.
- "As the hub plan moves forward, how do you want complaint volumes and resolution times reported to you each month?" Why it lands: it places the monthly report in the manager's own plan.
- "What would you need to see in the first 90 days to know the role is working?" Why it lands: a manager's answer tells you the scoring you will face.

**Panel**

- "When a branch moves into a hub, who owns the complaints that were already open at the old branch?" Why it lands: it is Own the Fix in practice, and the branch managers have the answer.
- "What does a good escalation look like from a branch manager's side of the counter?" Why it lands: it turns the values round into a conversation about their view.
- "What do you wish the complaints log captured that it doesn't?" Why it lands: shows you think about data quality, which fits your spreadsheet.

## Sources

- Job description: as pasted in your message.
- Company values: as pasted, copied from ashgrovecu.org/about/values on 19 November 2026.
- Strategy: the 2026 strategy brief (July 2026), as summarised in your message and sent by the recruiter.
- Loop: the recruiter's email, as pasted. It establishes the three rounds and who runs each.
- Your background: your message.

Research tier: L0 — no searches; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Inputs fix it: the values text is pasted, so the values cheat sheet rests on it. A quick check against the official page is in the upgrade menu. |
| 2. Ashgrove interview process, Member Experience Lead | skipped | Inputs fix it: the recruiter's email names the three rounds and who runs each, so the loop is established. |
| 3. Ashgrove strategy / recent news | skipped | Inputs fix it: the strategy brief is pasted and is under six months old. |
| 4. Interviewer names | n/a | No names were given, so there was no query to form. The interviewer read is absent. |
| 5. Representative JD | skipped | The JD was supplied. |

No research calls were sent in this pack.

## Upgrade menu

- The names of the recruiter, Head of Member Services and both branch managers → a per-round interviewer read, persona weights for each panel member, and reverse questions tuned to their career paths.
- The monthly complaints spreadsheet, with member data removed, or a list of its columns → an inspectable artifact. F5 and F6 can then rest on a checkable figure, and H9 and P9 answer what the sheet actually counts.
- Whether the spreadsheet is built in Excel → F6's bridge names the tool.
- Any contact-centre exposure, even indirect (taking calls, handling a queue, receiving escalations routed from one) → rewrites F4 from a capability gap to a transferability gap, if it is true. Leave it as it is otherwise.
- Whether the 20-minute case comes with a written brief or materials → P5 and P6 move from generic structure to a grounded case.
- Whether the recruiter has pre-declared any exercise or deliverable → a build section for it.
- Your pay expectations, notice period, location and reason for leaving → fills R3 to R6 in your own words. None was assumed.
- Your prep hours before 28 November → a sized prep triage, in priority order.
- A quick check of the pasted values page against the official page, up to two calls → confirms the four names and definitions before the values round.
- Deep research (L2): loop reports for this role family and recent leadership or reorganisation news; up to 6 searches and 2 page fetches, several more minutes. Offered once; say if you want it.
