Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-8-denied-68eeb792/06d156ed-2d0e-4269-8363-cddb265db9cb/scratchpad/ashgrove_member-experience-lead_interview_pack.md`. It covers all three rounds, the fit gaps, the values cheat sheet, the escalation drill, the strategy angle, reverse questions and an upgrade menu.

The three things that matter most:

- **Your biggest exposure is the contact centre and senior presenting, and you've stated both as gaps.** Say them plainly first: "I haven't worked in a contact centre" and "I haven't presented to anyone above regional level." Then give a plan, not a claim. The highest-ROI rehearsal is R2-B1, "Which part of this role would you be weakest at on day one?"
- **Your spreadsheet is both your best evidence and a trap.** The panel's Neighbours, Not Numbers value is the one your spreadsheet seems to contradict. Name that before they do.
- **Don't stretch "handled the log" into "owned the process."** Resolution times, supervisor coaching and digital work aren't in your material. The pack gives you honest answer slots for those, not claims.

I took the reading that the round 2 manager is your future manager and that round 3 is scored against the values. I built it at the provided-documents tier only, with no web searches, because the values, JD, loop and strategy were all in your message. The values text is your copy from their site, which I haven't checked against the live page.

Offers, neither pushed:
- **Drill:** I can play the Skeptic on R2-B1, the contact-centre question, and give feedback against its guidance.
- **Dossier:** I can save a `tuesday-dossier.md` recording these gaps for later sessions.
- **Word:** I can convert the pack to .docx once you've finished iterating.

One question, which decides whether the regulated-complaints requirement is met:

Was the formal complaints work you handled governed by a regulator's or ombudsman's rules or deadlines?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**Candidate:** Dara
**Role:** Member Experience Lead (member-owned credit union, about 900 staff)
**Rounds (28 November 2026), loop mode:**
1. 30 min, recruiter
2. 45 min, Head of Member Services (your future manager), mostly behavioural
3. 60 min, panel of two branch managers, including a 20-minute complaint escalation case; scored against the four values

Interviewers for rounds 2 and 3 beyond the names above are not yet known. Personas below are weighted from round type and the recruiter's description, not from interviewer profiles.

---

## 1. How to use this pack and type key

Personas describe **how a question is asked**. Types describe **what is being scored**. Guidance is scaffolding for a spoken answer, not a script. Rehearse the structure, then say it in your own words.

| Tag | Name | What is scored |
|---|---|---|
| VAL | Values / behavioural | Whether past behaviour shows the published values |
| EXP | Experience deep-dive | Whether what is on your CV survives questions about what you did |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy | Whether you know where Ashgrove is heading and what it means for complaints |
| CASE | Live problem | Structure and reasoning on a problem from the role |

---

## 2. Fit snapshot

Everything the pack says about your past is drawn from the quotes in the evidence column. "Your message" means what you wrote to me in this conversation. Nothing else about your experience is assumed.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | high | [grounded] | none | No gap. Say it as written: six years in retail banking, the last three as a branch supervisor. |
| F2 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows one branch's formal complaints log, not an end-to-end process. Keep the log in your words: "I handled the branch's formal complaints log." Answer slot: if any step beyond the log was yours to set, say which and how you decided; if there was no such step, say so and stay with the log. |
| F3 | "experience handling regulated complaints" (JD; gate) | "I handled the branch's formal complaints log" (your message) | low | [grounded] | hard_gate | Your material does not establish this. It shows a formal log, not whether that work ran to a regulator's or ombudsman's rules or deadlines. The one question about it is asked in this message. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your words reach monthly complaint reporting. Say them as written: "I built the monthly complaints spreadsheet our regional manager uses." Nothing added to them. |
| F5 | "resolution times" within the reporting requirement (JD) | none given | none | [grounded] | discovery | Your material is silent on resolution times. Answer slot: if any resolution-time figure was in the spreadsheet, say what it counted; if none was, say so and say what you would measure first. |
| F6 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your evidence is coaching tellers, not supervisors. Keep the words: "trained new tellers on our escalation script." Answer slot: if you have coached a supervisor or anyone beyond tellers on an escalation, say who and what you did; if not, say so and say how you would start. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material is silent here. Answer slot: if you have worked on a digital journey, say which part and what you changed; if not, say so and say what you would bring from the branch floor. |
| F8 | Work across the contact centre (JD: "across branches and the contact centre") | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your own words: "I haven't worked in a contact centre." Then how you would learn it, said as a plan, never as a past. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | Your own words: "I haven't presented to anyone above regional level." Then how you would prepare, said as a plan. |
| F10 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | Your material says spreadsheet, not Excel by name. Say the tool you used and one thing you did in it, in your own words. |

**Routing note.** F3 is a gate and the material does not show it met, so it is `hard_gate`: surfaced, not bridged. F8 and F9 are gaps you stated, so their words come from your own negatives. F5 and F7 are silence, so their words are answer slots.

**Pack observations (analysis, not words for you).** The material shows a formal complaints log at one branch, a spreadsheet, and teller coaching. It does not show end-to-end ownership, regulated work, resolution-time reporting, supervisor coaching, digital work, contact-centre work, or senior presentation.

---

## 3. Grounding brief (strategy, from your recruiter's brief)

Learn the vocabulary; do not recite it. The brief is the document the panel wrote. Using its phrasing shows you read it.

- **40% digital by 2028.** Move 40% of member service to digital channels by 2028. For complaints, the question is whether the complaints move with the channel or just get harder to see.
- **Eight branches into five hubs over 2027.** A consolidation puts complaints in flight at the branches that close. Expect questions about continuity.
- **Small-business lending, Q1 2027.** A new product generates a new complaint category. Mention only if asked; you have no evidence on it.
- **Competitive pressure: app-only banks.** Complaints that start in an app are the new normal. Do not claim knowledge of Ashgrove's internal plans beyond the brief.

---

## 4. Persona weights by round

| Round | Dominant personas (weight) | Why |
|---|---|---|
| 1, recruiter, 30 min | Conversational (3), light Skeptic (2) | Logistics and motivation, asked in a friendly register. Logistics are scored. |
| 2, Head of Member Services, 45 min | Skeptic (4), Values/Behavioural (4), Case (2) | Future manager. Buying capability and derisking the gaps in F2, F3, F8, F9. Mostly behavioural. |
| 3, panel, 60 min | Values/Behavioural (5), Case (3), Pressure and Data-Driven Prober (2 each) | Scored against the four values. The 20-minute escalation case is the largest single block. |

Panel members are unnamed. Personas are blended to the round, not assigned to individuals.

---

## 5. Question banks

Provenance comes first: every candidate sentence a guidance cell rests on is quoted in its row. Answer slots are instructions for the interview, not questions to me.

### Round 1: Recruiter screen (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1-A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | 90-second arc: six years in retail banking, the last three as a branch supervisor, then the complaints log at your branch and the spreadsheet your regional manager uses. Stop there. | F1 and F4 are the strongest facts you have; the arc uses only them. |
| R1-A2 | "What's your notice period?" | JD | [grounded] none given | Logistics slot: give your actual notice period in your own words. Do not estimate it. | Recruiter logistics are scored; a blank is a stumble. |
| R1-A3 | "What salary are you looking for?" | JD | [grounded] none given | Logistics slot: name the figure you want, or ask for the role's band first. Give your own number, never a figure you have not decided on. | Pay is a knockout check in a friendly register. |
| R1-A4 | "Where would you be based, and how often would you need to be in the office?" | JD | [grounded] none given | Logistics slot: state where you can work and how often you can attend in person. The recruiter has not named an office pattern. | Location is a knockout check. |
| R1-A5 | "Why are you leaving your current role?" | EXP | [grounded] none given | Logistics slot: give your own reason in your own words. Keep it to the true one and do not criticise your employer. | Motivation consistency is scored in round 1. |
| R1-B1 | "You've never worked in a contact centre. Why this role?" | EXP | [grounded] "Never worked in a contact centre" | Say it plainly: "I haven't worked in a contact centre." Then the link you can truthfully draw: the branch complaints log, and what you would learn first. Do not invent a contact-centre experience. | F8 is a stated gap and the first thing a skeptic will test. Naming it first costs less than being caught. |

### Round 2: Head of Member Services (45 min, behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2-B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre"; [grounded] "I handled the branch's formal complaints log" | **Highest-ROI prep in this pack.** Name the gap first: "I haven't worked in a contact centre." Then the log you handled, in its own words. Hold through two follow-ups by returning to the log. Concede the contact-centre gap explicitly; do not fold on the log. Plan: how you would learn the contact-centre queue in your first weeks. | F8 and F2 together are the most predictable objection. The pack names it deepest because it will come in some form. |
| R2-B2 | "How would you present complaint trends to a senior leadership group you haven't presented to yet?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the plan: start from the monthly spreadsheet your regional manager uses, say what you would show first, and say who you would rehearse with. | F9 is a stated gap. Acknowledge it, then give a plan, not a claim. |
| R2-B3 | "Tell me about the monthly complaints spreadsheet. How much of it was yours?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what you built and what your regional manager did with it, in those words. If any part of the data or the layout was someone else's, say which. | F4 and F10. The question tests attribution, and "built" must stay as built. |
| R2-B4 | "Volumes you can see. What about resolution times?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if any resolution-time figure was in the spreadsheet, say what it counted; if none was, say so and say what you would measure first. | F5 is silence. The honest answer is the one you can give without inventing a measure. |
| R2-B5 | "Tell me about a time you disagreed with your manager about how a complaint should be handled." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Pick a real disagreement if you had one. If none comes to mind, say so plainly, then describe the nearest decision you made on a logged complaint and who you took it to. | Behavioural core of round 2. The log is the only sentence your material carries. |
| R2-C1 | "A complaint has been escalated to you twice and the member is still not clear what happens next. What do you do?" | CASE | [generic] | Structure: what the member needs to know, who owns the next step, what is written down, and what you tell your team. Name one owner and one plain-words reply. No claim about your past. | Live problem from the escalation process; scores whether you act on the member's side. |

### Round 3: Panel of two branch managers (60 min, including the 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3-V1 | "Tell me about a time you decided a complaint from the member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Pick the complaint you would most want to redo from the member's side. If you cannot name a clear case, say so, then describe how you handled one log entry in that spirit. | Members First. Your material shows the log, not the decision; say which is which. |
| R3-V2 | "Tell me about a time you made something hard for a member easier to follow." | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt. If you changed the script or the wording members saw, say what changed and why. If you did not, say so and describe what you taught tellers about explaining things once. | Plain Words. The script is the only writing you have; the story must be real. |
| R3-V3 | "Tell me about a time a number pulled you away from the people behind it." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Open prompt. Expect the spreadsheet to come up. Be ready to say what it misses about the member's situation, in your own words, and what you would do about it. Do not claim the spreadsheet always put people first. | Neighbours, Not Numbers. The panel will test the spreadsheet against this value. |
| R3-V4 | "Tell me about a complaint you didn't hand off until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt. Name a complaint you kept until closed and what you did to keep hold of it. If handoffs were routine, say so and describe how you tracked one to closure. | Own the Fix. Your material shows the log, not closure; say which. |
| R3-C2 | Escalation case (20 min): "A member has complained three times about a fee and the branch has refunded it once. The member now says they will go to the ombudsman. Walk us through what you do." | CASE | [generic] | Clarify first: what the member has been told, what the file shows, and which regulatory deadline applies (ask, do not assume). Then objective (one owner, a written plain-words reply), approach (call the member, fix the root cause at the branch), metrics (time to resolution, repeat complaints), and risks (missed deadline, the refund being the wrong fix). Think aloud. | Round 3's largest block. The panel scores the structure and the member's side. |
| R3-P1 | "Walk me through how the monthly complaints numbers were counted." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Say what the spreadsheet counted, in your own words. If you did not define the counting, say who did. Do not explain a method you were not responsible for. | Data-Driven Prober. Attribution, in your words. |
| R3-P2 | "Two branch supervisors disagree on whether to refund a member. You coach both. What do you say?" | JD | [grounded] "trained new tellers on our escalation script" | Structure: what each supervisor is weighing, what the member is owed, and what the policy says. Offer to coach both to the same decision rule. No claim about coaching supervisors. | F6. The case tests coaching of supervisors; your evidence is tellers, so keep the answer on the structure. |

### Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| 4+ years in financial-services customer operations | R1-B1 (quote F1) | Covered by F1 |
| Own the complaints process end to end | R2-B1, R3-V4 | F2 slot |
| Regulated complaints experience | Gate; asked in this message | F3 |
| Monthly reporting on volumes and resolution times | R2-B3, R2-B4, R3-P1 | F4 and F5 |
| Coach branch supervisors on escalations | R3-P2 | F6 |
| Work with digital teams on self-service | none, and why: silence, so no rehearsed past. Use the slot in F7 if asked. | F7 |
| Confident presenting to senior leaders | R2-B2 | F9 |
| Comfortable with Excel reporting | R2-B3 | F10 |

---

## 6. Values cheat sheet (panel round)

The panel scores each value. Map a story where one of your quoted sentences carries one; where none does, the selection scaffold and its honest branch are the answer.

| Value | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Row F2 (log) carries no decision. Scaffold: R3-V1. Honest branch: say so. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | Row F6 (tellers, escalation script). Scaffold: R3-V2. Honest branch: say so. |
| Neighbours, Not Numbers | Every branch is part of its town | No quote carries this. Scaffold: R3-V3, with the spreadsheet as the likely opening. Honest branch: say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until solved | Row F2 (log). Scaffold: R3-V4. Honest branch: say so. |

**Trap to avoid.** Neighbours, Not Numbers is the value your best evidence most seems to contradict, because you built a spreadsheet. Name that tension before a panel does.

---

## 7. Escalation case drill (round 3, 20 minutes)

This is generic: not a fact about Ashgrove, and not a claim about your past.

1. **Clarify (2 min).** Ask which regulatory deadline applies and what the file shows. Do not assume the ombudsman's rules.
2. **Objective (2 min).** One owner, a member who understands the next step, and a fix for the root cause.
3. **Approach (8 min).** Call the member first. Write one plain-words reply. Check whether the refund was the right remedy. Involve the branch manager on the root cause.
4. **Metrics (4 min).** Time to resolution, repeat complaints for the same member, and whether the root cause recurs.
5. **Risks (4 min).** The deadline, a refund that is the wrong fix, and a member who escalates again.

Think aloud. Challenge one premise respectfully, such as whether the refund is the right remedy.

---

## 8. Reverse questions

Each has a "why it lands."

1. "What does a good first 90 days look like for this role?" Why it lands: it shows you are already planning the job, not the interview.
2. "Right now, how are complaints from the contact centre and from branches routed to one owner?" Why it lands: it asks the question the consolidation makes urgent, in the panel's own terms.
3. "As channels shift toward the 40% digital target, how will you know whether complaints are moving or just getting harder to see?" Why it lands: it tests the strategy against the complaints data, the role's real job.
4. "What would make a branch manager's escalations easier to hand to this role?" Why it lands: it treats the panel as peers who will work with you.
5. "What would you want the new lead to fix first?" Why it lands: it invites the answer that defines the first quarter, and you can listen for the Own the Fix value.

A reverse question tied to a named interviewer's own path is possible once their names are known (upgrade menu). None is included now, because no profile exists.

---

## 9. Prohibited claims

Not coached, and why. Each entry names its basis, and the honest form is the quote at its own scope.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned the complaints process end to end" | Inflated form of F2 | "I handled the branch's formal complaints log." Your material says the log, not the process. |
| "Reported resolution times" | Inflated form of F5 | F4's quote only. Resolution times are silent. Slot R2-B4. |
| "Coached branch supervisors" | Inflated form of F6 | "trained new tellers on our escalation script." Slot R3-P2. |
| "Presented to senior leaders" | Negative you stated, F9 | "I haven't presented to anyone above regional level." No slot. |
| "Worked in a contact centre" | Negative you stated, F8 | "I haven't worked in a contact centre." No slot. |

---

## 10. Sources

- **Provided documents:** the job description and the requirements in your message; the recruiter's email on the process; the company values as you copied them on 19 November 2026 from ashgrovecu.org/about/values; the 2026 strategy brief as your recruiter sent it to you. I have not checked the values or the brief against the live site or the original brief.
- **Searches and fetches:** none run.

**Research tier:** L0 (provided documents only). Every default target was covered by a provided document, so no search was needed.

| Target | Status |
|---|---|
| Official company values | n/a: provided in your message |
| Loop structure | n/a: provided in the recruiter's email |
| Current strategy | n/a: provided in the recruiter's brief |
| Interviewer public footprint | n/a: no interviewer named |
| Representative JD | n/a: JD supplied |

---

## 11. Upgrade menu

- The Head of Member Services' name → a tailored reverse question, and persona weights read from their public footprint.
- The two branch managers' names → per-member persona assignment for round 3.
- Your regulated-complaints answer → F3 becomes a grounded row instead of a gate, and R1-B1 and R2-B1 gain a sourced limit.
- The resolution-time figures you reported, if any → R2-B4 and R3-P1 become concrete defend-the-number answers.
- An example of coaching a supervisor or any digital work → F6 and F7 gain grounded evidence, and R3-P2 and the digital question get a story.
- Your recruiter's note on any pre-declared deliverable → coverage of that deliverable, if one exists.
