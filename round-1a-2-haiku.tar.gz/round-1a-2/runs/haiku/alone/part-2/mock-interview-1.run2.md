Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-1-denied-18b379cd/0800d2bf-4709-4e51-9455-968da530cbea/scratchpad/northwind_senior-gtm-strategy-lead_interview_pack.md`. I built it for a single peer round with Dan, from the JD highlights rather than the full JD. Web search was refused in this session, so nothing about Northwind's values, loop or current strategy is re-verified.

# Northwind Data: Senior GTM Strategy Lead, Emerging Products. Interview prep pack for Priya

**Interviewer:** Dan Kovac, Director of Sales Strategy. Relationship: **peer** (both report to the same VP). Round: single 60-minute conversation.
**Built on:** the JD highlights you gave (not the full JD), your candidate summary, the interviewer profile and your research note. Nothing here is a fact about Northwind or Dan beyond those inputs.

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores:
  - **VAL**: behavioral and values alignment
  - **EXP**: work-experience deep-dive, where attribution is tested
  - **JD**: role and JD-driven
  - **CO**: company and strategy knowledge
  - **CASE**: live problem
- **Guidance is scaffolding, not a script.** Say it in your own words. The quote in the Provenance column is the most you can say about your experience.
- **Provenance labels:** `[grounded]` traces to your input. `[inferred]` is a derivation, named. `[generic]` is a pattern with no fact about Northwind or Dan.
- **Answer slot** = an instruction for the interview, not a question to me.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights, your note) | "9 at a large consumer-tech company in product strategy & ops" (the coach's notes); "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | medium | [grounded] | transferability | Your material shows product strategy and ops, and a proposal with a credited uplift. It does not show go-to-market ownership. Bridge at that scope: "I spent nine years in product strategy and ops." Answer slot: if any go-to-market decision on a launch was yours to make, say which and how you decided; if none was, say so and stay with the store-surface proposal. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights, your note) | "Built a partner-level revenue model used in carrier negotiations" (the coach's notes) | low | [inferred] | discovery | Derived from the revenue model, the nearest quote. Nothing in the material shows a whitespace or lifecycle-stage analysis. Answer slot: if you have sized open revenue across land, adopt, expand or renew, say where and how you counted it; if you have not, say so and say what you would look at first. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights, your note) | "skilled in SQL/Tableau" (the coach's notes) | medium | [grounded] | presentation | Reword only the quote: "I'm skilled in SQL and Tableau." The tools are reached; "independent analysis" is not shown. The analysis itself is scored in A4. |
| F4 | "partner-motion design experience required" (JD highlights, your note) | "Built a partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | Bridge at the quote's scope: "I built a partner-level revenue model used in carrier negotiations." Your material shows a model used in negotiations, not partner-motion design. Answer slot: if you shaped the terms or incentives of a partner arrangement, say which and how you decided; if the model informed a negotiation someone else designed, say so and what your part was. |
| F5 | "strong cross-functional influence" (JD highlights, your note) | "set annual volume targets with cross-org consensus" (the coach's notes) | medium | [grounded] | presentation | Reword only the quote: "I set annual volume targets with cross-org consensus." Reaches the requirement in other terms. |
| F6 | "AI experience a plus" (JD highlights, your note) | "uses AI tools daily" (the coach's notes) | low | [inferred] | discovery | Derived from usage. Usage is not building, and the material does not show what the use produced. Answer slot: describe the tasks you use AI tools for, concretely; if you have built anything with them, say what. |
| F7 | Role-family prose, not a JD highlight: sales operations or quota-setting work (`[generic]`) | "No classic sales-ops or quota-setting experience." (the coach's notes) | none | [grounded] | capability | The material states the absence. Confirm it in your own words before using it; the pack supplies no words for it. Closure path: the volume-target work in F5 and the proposal work in F1, bridged at their own scope. No quota claim. |
| F8 | Headline figure, no JD line | "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | medium | [grounded] | none | No gap in the words: the sentence states the figure and your role in it. Expect a probe on the figure itself. Limited inspectable proof, so the verification caveat applies. See A1 to A3. |

**Routing note.** No gate rows. None of the JD highlights is a term (location, pay, schedule, travel, authorization), and the material says nothing about those. The full JD may contain one, which is why it is asked for below.

## 3. Grounding brief

From your research note. Not re-verified, because search was refused.

| # | Company fact | Provenance | Use in the answer |
|---|---|---|---|
| 1 | Enterprise expansion is a stated priority | "Northwind's three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note) | Frame the product line's first job against this. Check it is still current before the call. |
| 2 | An AI copilot launch, 'Compass', is a stated priority | Same quote (your research note) | Name Compass only as the priority your note gives. Do not describe what it does. |
| 3 | Reaching profitability is a stated priority | Same quote (your research note) | Cost the trade-off against this one. |
| 4 | The main competitive threat is bundling by a much larger platform vendor | "main competitive threat is bundling by a much larger platform vendor" (your research note) | The competitive frame for C3. Name no competitor specifics you have not checked. |

## 4. Reading the interviewer

Public profile only. Nothing beyond your note was used.

| Signal | Source | Practical implication |
|---|---|---|
| Self-described "relentlessly data-driven" | your note | Every figure gets taken to its denominator. Prober weight is top. |
| Career spine in pricing and monetization | your note | Case and peer questions tilt to pricing, packaging and unit economics. That is Dan's native language. |
| One early-stage startup chapter | your note | Builder stories land. Expect probes on big-company pace and scrappiness. |
| Peer, same VP | your note | Expect seam, credit and disagreement probes. Reciprocity framing matters. |

**Mirror opportunities:** none offered. The material shows no shared professional path with Dan's career.

## 5. Persona table

| Persona | How it shows up | Weight (depth) | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Every figure taken to its counting method and assumptions | 5 (top) | Peer prior, and the self-described "relentlessly data-driven" pushes it to the top | Name the weakest assumption first. Say plainly when you cannot walk through a count. |
| Peer Evaluator | Seam, credit, disagreement, reciprocity | 4 | Peer prior. The hire shapes Dan's load, so the probe is what it costs them. | Reciprocity framing. Propose seam principles, not a map of someone else's team. |
| Case / Strategist | A live plan on a launch; a priority trade-off | 3 | The pricing spine tilts cases toward pricing and packaging. The JD's ownership and whitespace lines are the raising sources. | Clarify, structure aloud, challenge one premise. |
| Skeptic | The sales-ops and quota gap; "what would make you wrong" | 3 | F7 is the one gap the material states, and the JD's sales-facing lines make it likely | Calibrated candor. Name the closure path. Do not bluff. |
| Pressure | "How much of that was you"; "why leave product, why now" | 2 | Attribution probes are the Pressure form of the Prober's questions. Not a skip-level round. | Hold through two follow-ups. Concede specifically. |
| Conversational | The journey; AI usage asked casually | 2 | Casual openers are scored. The JD's AI line is asked lightly. | A 90-second arc. Treat casual questions as scored. |
| Values / Behavioral | An unpopular truth to leadership | 1 | No values round is established. Kept at 1 so the style is not met for the first time live. | Selection scaffold ending in the honest branch. |

Depth: Prober 5, Peer 4, Case 3, Skeptic 3, Pressure 2, Conversational 2, Values 1. Total 20.

## 6. Question banks

**Highest-ROI prep: D2.** The volume-target versus quota question is where Dan's profile and the one gap the material states both point. Rehearse D2, then D1, to the deepest level before anything else.

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Beats the sentence states: you proposed the store-surface change, and it is credited with about $400M of ARR uplift. Say "about" where the sentence says "~". Defend-the-number slot: if you know how the figure was counted, say how, in your own words; if you do not, say so. Name the assumption you would defend least before they ask. Answer slot: if any part of the rollout or the counting was yours to set, say which and how you decided; if none was, say so and stay with the proposal. | F8 is a headline figure. Dan's profile makes this the most likely first probe. |
| A2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | The weakest-assumption move, in your words, before Dan names one. Answer slot: if you can name the assumption and what it is sensitive to, say so. If you cannot name one, say that you cannot walk through the count. Do not reach for a method you cannot repeat. | The second-level follow-up on F8. An assumption the candidate cannot name is the riskiest moment in the session. |
| A3 | "What did the partner-level revenue model take as inputs, and which of them would you defend least?" | EXP | [grounded] "Built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Beats: you built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: name the inputs you know the model used and the one you would defend least. If the inputs came from someone else, say who supplied them and what part of the model was yours. | F4 is the partner-motion requirement. The Prober checks the model's denominators, so this is where that requirement is tested. |
| A4 | "Tell me about an analysis you ran in SQL or Tableau that changed a decision." | JD | [grounded] "skilled in SQL/Tableau" (the coach's notes); "run independent analysis in SQL and Tableau" (JD highlights, your note) | Open prompt: choose one instance. Selection scaffold: an analysis you ran yourself, from question to chart, that changed a named decision, with a number you can defend and a clear line between your work and any shared data pipeline. Honest branch: if no analysis you ran changed a decision, say so plainly, then describe the nearest analysis you ran and what it changed. | F3 reaches the JD's "independent analysis" only in tool terms. The open prompt lets you choose your strongest real example. |
| A5 | "For a new product line, which of land, adopt, expand or renew would you look at first for whitespace, and why?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights, your note) | A live approach question with no claim about your past. Structure: which stage holds the most open revenue, how you would size it, and what would make your first read wrong. Name the four stages in order, then say which you would test first. | The JD's whitespace line is the role's core. The Prober asks for the approach before the number. The label stands alone because nothing here asserts a fact about you. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your work and sales strategy's, and what happens when we disagree?" | JD | [grounded] "strong cross-functional influence" (JD highlights, your note) | Give seam principles, not a map: name the decisions each team owns and how a disagreement gets settled, such as data, a named owner, or a time limit. Disagreement slot: tell one real disagreement with an equal team, what you did, and where it landed. If you have none to tell, say so and state the principle you would use. | The Peer Evaluator's stem. The seam is where Dan's pricing view meets a launch's go-to-market. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes); [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Credit as your material states it: you set the targets with cross-org consensus, and you proposed the change that is credited with the uplift. Name what was the team's and what was yours. If you cannot split the credit, say so. Do not claim sole credit. | A credit probe is the peer form of the attribution test. F5 and F8 carry both sentences. |
| B3 | "For a partner motion on a new product line, what would you need from pricing, and what would you bring?" | JD | [grounded] "partner-motion design experience required" (JD highlights, your note); [grounded] "Built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Reciprocity: name two things you need from pricing, such as a price floor or packaging rules, and one thing you bring, in your own words. Answer slot: if you designed partner terms, say which. If you built the model that informed a negotiation, say that and stop there. | The Peer Evaluator's reciprocity line. F4 cannot close the partner-motion requirement on its own, so this tests it from the peer side. |
| B4 | "You've spent your career in pricing and monetization. What does a partner's price do to a land-versus-expand decision?" | CASE | [generic] | A live problem in Dan's own domain. Structure: which price moves the decision, for which segment, and what it does to the partner's incentive. Name the trade-off aloud. If you have a view, give it as a view, not as a past event. | It is Dan's expertise, and a peer check on the same seam. The guidance is structure, so the label stands alone. |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the plan for a new product line's first two quarters. What do you need to know first?" | CASE | [grounded] "own GTM strategy for two new product lines" (JD highlights, your note) | Clarify, then objective, then segmentation across land, adopt, expand and renew, then approach, metrics and risks. Speak the structure aloud before you use it. Name one premise you would challenge. | The JD's ownership line as a plan question. Nothing here claims past work. |
| C2 | "Northwind's stated priorities are enterprise expansion, the Compass copilot launch and reaching profitability. Which one should a new product line serve first, and what does it cost the other two?" | CO | [grounded] "Northwind's three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note) | Pick one, name the trade-off in cost terms, and say what would change your mind. Before the call, check the three priorities are still current. Your note is not re-verified. | Company-altitude question built on your note, because search was refused. Picking and costing a priority is the test. |
| C3 | "The main threat is a much larger platform vendor bundling. How would you defend a standalone product line against that?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Frame the bundle as a pricing and packaging problem you can test: where the bundle's price anchors, which customers it reaches first, and what a standalone line must show to be chosen. Name no competitor specifics you have not checked. | The competitive frame from your note is the differentiator question. The guidance names no fact about the competitor. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." (the coach's notes) | Name the weakest area in your own words. If it is sales operations or quota-setting, say so once, plainly, and do not argue it away. Then give the closure path: the volume-target work and what you would learn first. Confirm the negative in your own words before you say it. The pack supplies no words for it. | The persona stem aimed at the gap F7 records. |
| D2 | "What's the difference between a volume target and a quota, and which one would you set for this team?" | JD | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Define the difference in your own words. General definition, not a fact about Northwind: a quota is an individual seller's share of a target. Then say which you would set for this team and why. Answer slot: if you have set a quota, say which. If you have not, say so and say what you would need to learn before setting one. | The highest-ROI objection. The quote carries volume targets, not quotas, so the guidance can only describe that difference. Deepest rehearsal: hold the volume-target distinction through two follow-ups. |
| D3 | "What would make you the wrong hire for this role?" | VAL | [generic] | Calibrated candor, one answer. Name a gap you can state without apology, the closure path you would take, and the one part of the role you would ask a peer to watch. Do not bluff a competency. | A skeptic's closer. Nothing about your past is asserted here. The gap is named in your words, not the pack's. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Hold, then concede. Hold: you proposed the change, and it is credited with about $400M. Hold through two follow-ups by returning to the proposal. Concede specifically: the part of the uplift you cannot split from the team's work, in your own words. Do not agree to a share your material does not give. | The Pressure stem on F8. The strength is in the concession, not the figure. |
| E2 | "Sixty seconds: you've spent nine years in product. Why leave that for a sales-strategy role, and why now?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | Give your own reason for the move and for now, in sixty seconds. Answer slot: state the reason for leaving the product role and why now, in your own words. The material gives neither. | The Pressure form of the Skeptic's "why, why now." F1 is the transfer the answer has to carry. |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior a number they did not want. It needs a stake, the moment you did not fold, and a relationship intact at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries, which is the volume-target consensus or the store-surface proposal, and what pushback, if any, you met. | No values round is established, so the persona is weighted 1. It stays in the pack so the style is not met for the first time live. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | A 90-second arc: consulting first, then the consumer-tech product and ops years, then this role. State the path in those terms and no more. | Casual openers are scored. The arc should land the F1 transfer in the first two minutes. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (the coach's notes) | Name two or three tools and the concrete tasks you use them for, in your own words. Do not describe building AI products or running AI programs. | The JD's AI line, asked casually. F6 is low confidence, so the answer stays on usage. |

### Requirement coverage

| JD requirement | Covered by | Note |
|---|---|---|
| own GTM strategy for two new product lines | C1 | F1 is transferability; its slot is in the fit snapshot |
| identify whitespace across land/adopt/expand/renew | A5 | F2 is discovery; its slot is in the fit snapshot |
| run independent analysis in SQL and Tableau | A4 | F3 |
| partner-motion design experience required | A3, B3 | F4 is transferability |
| strong cross-functional influence | B1, B2 | F5 |
| AI experience a plus | G2 | F6 is discovery |
| Full JD text | none, and why: only highlights were supplied | See the upgrade menu |
| Sales-ops and quota-setting (not in the highlights) | D1, D2 | Covered because it is the likeliest objection; not a JD line |

## 7. Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer slot, hold, bridge or rationale in this pack asserts or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the go-to-market strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation: your material shows product strategy and ops, not go-to-market ownership. |
| Set quotas, or sized seller capacity | Sourced negative (the coach's notes) plus inflated form of F5 | F5's quote at its scope, "annual volume targets". The negative is confirmed only in your own words. |
| Designed the partner program or its incentives | Inflated form of F4 | "Built a partner-level revenue model used in carrier negotiations" at its own scope. |
| Delivered or owned the ~$400M | Inflated form of F8 | "proposed ... credited with" at its own scope. The sentence says proposed and credited, not delivered. |
| Expert in SQL and Tableau | Inflated form of F3 | "skilled in SQL/Tableau". |
| Built AI products or ran AI programs | Inflated form of F6 | "uses AI tools daily". |
| Led cross-functional alignment | Inflated form of F5 | "set annual volume targets with cross-org consensus". |

## 8. Values / principles cheat sheet

Dropped. No values were available: web search was refused, and no company values were supplied.

## 9. Reverse questions

| # | Question to ask Dan | Why it lands |
|---|---|---|
| R1 | "You came into sales strategy from pricing and monetization. What did that background let you see in sales motions that the sales teams missed?" | Ties to Dan's own path. Turns an interrogation into a peer conversation. |
| R2 | "Which number does your team argue about most with Finance, and what is the definition fight?" | Shows you want the denominator. Speaks to a data-driven peer. |
| R3 | "When a partner's price and a direct price collide, who decides, and on what data?" | Tests the seam on the partner motion. |
| R4 | "How is the Compass launch changing what Sales Strategy is asked to measure?" | Uses a stated priority from your note, and asks what has changed. |
| R5 | "What would a new person do in their first month that would genuinely help your team?" | Reciprocity question, since Dan is a peer. |
| R6 | "What's the question about the new product lines your team still can't answer?" | Shows you are thinking about the work, not the job title. |

## 10. Delivery coaching

Dropped. No working-style assessment was provided, and none was solicited.

## 11. Sources

**Provided documents:** the JD highlights (your note), the candidate summary (the coach's notes), the interviewer profile (your note), and the research note (your note). No dossier was consumed.

**Searches sent:**

| Query | Target | Outcome |
|---|---|---|
| Northwind Data company values operating principles | 1 | refused |
| Northwind Data interview process Senior GTM Strategy Lead Emerging Products | 2 | refused |
| Northwind Data Compass AI copilot launch enterprise expansion profitability | 3 | refused |
| Dan Kovac Director of Sales Strategy Northwind Data pricing monetization | 4 | refused |

"Refused" means the search permission was not granted. No fetches were sent.

**Research tier:** L1, searches 4 of 6 sent, all refused; fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have produced the values cheat sheet. Dropped. |
| 2. `{company} interview process {role family}` | unavailable | Would have fixed the loop structure. Treated as a single peer round. |
| 3. `{company} strategy` / recent news | unavailable | Would have refreshed the grounding brief. Your research note supplies the priorities, which are not re-verified. |
| 4. `{interviewer name} {company}` | unavailable | Would have added the interviewer's public footprint. Persona weights rest on your profile only. |
| 5. Representative `{role title}` JD | unavailable | Would have filled the JD-tagged gaps. Your highlights fix only part of the fit snapshot. |

## 12. Upgrade menu

- **Full JD text** → gate rows for location, pay, schedule, travel and authorization, if the JD states them. Also the rest of the requirement list, so the coverage table has no gaps.
- **Recruiter's note on focus areas, a deliverable or process details** → a graded-deliverable section if one is announced, and reweighted personas.
- **Search permission granted** → the values cheat sheet, a loop-structure read, a refreshed strategy sweep, and a re-verified grounding brief. C2 and C3 would then be checked against current sources.
- **Your own words confirming "No classic sales-ops or quota-setting experience"** → D1, D2 and F7 can carry a plain acknowledgment in place of an answer slot.
- **Any quota, sales-ops or partner-design work you did, described in your words** → F1, F2, F4 and F6 move from answer slots to story-mapped answers, with each sentence quoted.
- **Interviewer's public talks or writing** → persona weights from their own words, and a reverse question tied to their published themes.
- **Prep time available** → a prep triage section, sized to the time.
- **Deep research (L2), offered once** → a strategy brief, interviewer talks, and role-family loop reports, using up to 6 further searches and 2 fetches. Only if search permission is granted.
- **A `tuesday-dossier.md`, if you have one** → verified evidence in place of the locally built prohibited list, and named objections in place of the inferred one.

---

**Drill:** I can play Dan as the Prober on D2, the highest-ROI question, and give feedback against its guidance cell.
**Dossier:** I can save a `tuesday-dossier.md` recording the gaps this prep exposed, for carrying into later sessions.
**Word:** I can convert this pack to a Word document if you want one.

1. Can you paste the full JD text? The highlights don't show location, pay, schedule or travel, which are gates the material says nothing about.
2. Did the recruiter or the invite name a focus area, a deliverable or a process detail for this round?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior-gtm-strategy-lead_interview_pack.md -----
# Northwind Data: Senior GTM Strategy Lead, Emerging Products. Interview prep pack for Priya

**Interviewer:** Dan Kovac, Director of Sales Strategy. Relationship: **peer** (both report to the same VP). Round: single 60-minute conversation.
**Built on:** the JD highlights you gave (not the full JD), your candidate summary, the interviewer profile and your research note. Web search was refused in this session, so company values, loop structure and current strategy are not re-verified. Nothing here is a fact about Northwind or Dan beyond those inputs.

## 1. How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores:
  - **VAL**: behavioral and values alignment
  - **EXP**: work-experience deep-dive, where attribution is tested
  - **JD**: role and JD-driven
  - **CO**: company and strategy knowledge
  - **CASE**: live problem
- **Guidance is scaffolding, not a script.** Say it in your own words. The quote in the Provenance column is the most you can say about your experience.
- **Provenance labels:** `[grounded]` traces to your input. `[inferred]` is a derivation, named. `[generic]` is a pattern with no fact about Northwind or Dan.
- **Answer slot** = an instruction for the interview, not a question to me. It asks for no reply here.

## 2. Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights, your note) | "9 at a large consumer-tech company in product strategy & ops" (the coach's notes); "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | medium | [grounded] | transferability | Your material shows product strategy and ops, and a proposal with a credited uplift. It does not show go-to-market ownership. Bridge at that scope: "I spent nine years in product strategy and ops." Answer slot: if any go-to-market decision on a launch was yours to make, say which and how you decided; if none was, say so and stay with the store-surface proposal. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights, your note) | "Built a partner-level revenue model used in carrier negotiations" (the coach's notes) | low | [inferred] | discovery | Derived from the revenue model, the nearest quote. Nothing in the material shows a whitespace or lifecycle-stage analysis. Answer slot: if you have sized open revenue across land, adopt, expand or renew, say where and how you counted it; if you have not, say so and say what you would look at first. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights, your note) | "skilled in SQL/Tableau" (the coach's notes) | medium | [grounded] | presentation | Reword only the quote: "I'm skilled in SQL and Tableau." The tools are reached; "independent analysis" is not shown. The analysis itself is scored in A4. |
| F4 | "partner-motion design experience required" (JD highlights, your note) | "Built a partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | Bridge at the quote's scope: "I built a partner-level revenue model used in carrier negotiations." Your material shows a model used in negotiations, not partner-motion design. Answer slot: if you shaped the terms or incentives of a partner arrangement, say which and how you decided; if the model informed a negotiation someone else designed, say so and what your part was. |
| F5 | "strong cross-functional influence" (JD highlights, your note) | "set annual volume targets with cross-org consensus" (the coach's notes) | medium | [grounded] | presentation | Reword only the quote: "I set annual volume targets with cross-org consensus." Reaches the requirement in other terms. |
| F6 | "AI experience a plus" (JD highlights, your note) | "uses AI tools daily" (the coach's notes) | low | [inferred] | discovery | Derived from usage. Usage is not building, and the material does not show what the use produced. Answer slot: describe the tasks you use AI tools for, concretely; if you have built anything with them, say what. |
| F7 | "No classic sales-ops or quota-setting experience" is not a JD highlight. It is role-family prose: sales operations or quota-setting work (`[generic]`) | "No classic sales-ops or quota-setting experience." (the coach's notes) | none | [grounded] | capability | The material states the absence. Confirm it in your own words before using it, because the pack supplies no words for it. Closure path: the volume-target work in F5 and the proposal work in F1, bridged at their own scope. No quota claim. |
| F8 | Headline figure, no JD line | "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | medium | [grounded] | none | No gap in the words: the sentence states the figure and your role in it. Expect a probe on the figure itself. Limited inspectable proof, so the verification caveat applies. See A1 to A3. |

**Routing note.** No gate rows. None of the JD highlights is a term (location, pay, schedule, travel, authorization), and the material says nothing about those. The full JD may contain one, which is why it is asked for below.

## 3. Grounding brief

From your research note. Not re-verified, because search was refused.

| # | Company fact | Provenance | Use in the answer |
|---|---|---|---|
| 1 | Enterprise expansion is a stated priority | "Northwind's three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note) | Frame the product line's first job against this. Check it is still current before the call. |
| 2 | An AI copilot launch, 'Compass', is a stated priority | Same quote (your research note) | Name Compass only as the priority your note gives. Do not describe what it does. |
| 3 | Reaching profitability is a stated priority | Same quote (your research note) | Cost the trade-off against this one. |
| 4 | The main competitive threat is bundling by a much larger platform vendor | "main competitive threat is bundling by a much larger platform vendor" (your research note) | The competitive frame for C3. Name no competitor specifics you have not checked. |

## 4. Reading the interviewer

Public profile only. Nothing beyond your note was used; the public-footprint search was refused.

| Signal | Source | Practical implication |
|---|---|---|
| Self-described "relentlessly data-driven" | your note | Every figure gets taken to its denominator. Prober weight is top. |
| Career spine in pricing and monetization | your note | Case and peer questions tilt to pricing, packaging and unit economics. That is Dan's native language. |
| One early-stage startup chapter | your note | Builder stories land. Expect probes on big-company pace and scrappiness. |
| Peer, same VP | your note | Expect seam, credit and disagreement probes. Reciprocity framing matters. |

**Mirror opportunities:** none offered. The material shows no shared professional path with Dan's career, so no mirror is built.

## 5. Persona table

| Persona | How it shows up | Weight (depth) | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Every figure taken to its counting method and assumptions | 5 (top) | Peer prior, and the self-described "relentlessly data-driven" pushes it to the top | Name the weakest assumption first. Say plainly when you cannot walk through a count. |
| Peer Evaluator | Seam, credit, disagreement, reciprocity | 4 | Peer prior. The hire shapes Dan's load, so the probe is what it costs them. | Reciprocity framing. Propose seam principles, not a map of someone else's team. |
| Case / Strategist | A live plan on a launch; a priority trade-off | 3 | The pricing spine tilts cases toward pricing and packaging. The JD's ownership and whitespace lines are the raising sources. | Clarify, structure aloud, challenge one premise. |
| Skeptic | The sales-ops and quota gap; "what would make you wrong" | 3 | F7 is the one gap the material states, and the JD's sales-facing lines make it likely | Calibrated candor. Name the closure path. Do not bluff. |
| Pressure | "How much of that was you"; "why leave product, why now" | 2 | Attribution probes are the Pressure form of the Prober's questions. Not a skip-level round. | Hold through two follow-ups. Concede specifically. |
| Conversational | The journey; AI usage asked casually | 2 | Casual openers are scored. The JD's AI line is asked lightly. | A 90-second arc. Treat casual questions as scored. |
| Values / Behavioral | An unpopular truth to leadership | 1 | No values round is established. Kept at 1 so the style is not met for the first time live. | Selection scaffold ending in the honest branch. |

Depth: Prober 5, Peer 4, Case 3, Skeptic 3, Pressure 2, Conversational 2, Values 1. Total 20.

## 6. Question banks

**Highest-ROI prep: D2.** The volume-target versus quota question is where Dan's profile and the one gap the material states both point. Rehearse D2, then D1, to the deepest level before anything else.

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Beats the sentence states: you proposed the store-surface change, and it is credited with about $400M of ARR uplift. Say "about" where the sentence says "~". Defend-the-number slot: if you know how the figure was counted, say how, in your own words; if you do not, say so. Name the assumption you would defend least before they ask. Answer slot: if any part of the rollout or the counting was yours to set, say which and how you decided; if none was, say so and stay with the proposal. | F8 is a headline figure. Dan's profile makes this the most likely first probe. |
| A2 | "Which assumption behind that figure would you defend least?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | The weakest-assumption move, in your words, before Dan names one. Answer slot: if you can name the assumption and what it is sensitive to, say so. If you cannot name one, say that you cannot walk through the count. Do not reach for a method you cannot repeat. | The second-level follow-up on F8. An assumption the candidate cannot name is the riskiest moment in the session. |
| A3 | "What did the partner-level revenue model take as inputs, and which of them would you defend least?" | EXP | [grounded] "Built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Beats: you built a partner-level revenue model, and it was used in carrier negotiations. Answer slot: name the inputs you know the model used and the one you would defend least. If the inputs came from someone else, say who supplied them and what part of the model was yours. | F4 is the partner-motion requirement. The Prober checks the model's denominators, so this is where that requirement is tested. |
| A4 | "Tell me about an analysis you ran in SQL or Tableau that changed a decision." | JD | [grounded] "skilled in SQL/Tableau" (the coach's notes); "run independent analysis in SQL and Tableau" (JD highlights, your note) | Open prompt: choose one instance. Selection scaffold: an analysis you ran yourself, from question to chart, that changed a named decision, with a number you can defend and a clear line between your work and any shared data pipeline. Honest branch: if no analysis you ran changed a decision, say so plainly, then describe the nearest analysis you ran and what it changed. | F3 reaches the JD's "independent analysis" only in tool terms. The open prompt lets you choose your strongest real example. |
| A5 | "For a new product line, which of land, adopt, expand or renew would you look at first for whitespace, and why?" | JD | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights, your note) | A live approach question with no claim about your past. Structure: which stage holds the most open revenue, how you would size it, and what would make your first read wrong. Name the four stages in order, then say which you would test first. | The JD's whitespace line is the role's core. The Prober asks for the approach before the number. The label stands alone because nothing here asserts a fact about you. |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between your work and sales strategy's, and what happens when we disagree?" | JD | [grounded] "strong cross-functional influence" (JD highlights, your note) | Give seam principles, not a map: name the decisions each team owns and how a disagreement gets settled, such as data, a named owner, or a time limit. Disagreement slot: tell one real disagreement with an equal team, what you did, and where it landed. If you have none to tell, say so and state the principle you would use. | The Peer Evaluator's stem. The seam is where Dan's pricing view meets a launch's go-to-market. |
| B2 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes); [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Credit as your material states it: you set the targets with cross-org consensus, and you proposed the change that is credited with the uplift. Name what was the team's and what was yours. If you cannot split the credit, say so. Do not claim sole credit. | A credit probe is the peer form of the attribution test. F5 and F8 carry both sentences. |
| B3 | "For a partner motion on a new product line, what would you need from pricing, and what would you bring?" | JD | [grounded] "partner-motion design experience required" (JD highlights, your note); [grounded] "Built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Reciprocity: name two things you need from pricing, such as a price floor or packaging rules, and one thing you bring, in your own words. Answer slot: if you designed partner terms, say which. If you built the model that informed a negotiation, say that and stop there. | The Peer Evaluator's reciprocity line. F4 cannot close the partner-motion requirement on its own, so this tests it from the peer side. |
| B4 | "You've spent your career in pricing and monetization. What does a partner's price do to a land-versus-expand decision?" | CASE | [generic] | A live problem in Dan's own domain. Structure: which price moves the decision, for which segment, and what it does to the partner's incentive. Name the trade-off aloud. If you have a view, give it as a view, not as a past event. | It is Dan's expertise, and a peer check on the same seam. The guidance is structure, so the label stands alone. |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch the plan for a new product line's first two quarters. What do you need to know first?" | CASE | [grounded] "own GTM strategy for two new product lines" (JD highlights, your note) | Clarify, then objective, then segmentation across land, adopt, expand and renew, then approach, metrics and risks. Speak the structure aloud before you use it. Name one premise you would challenge. | The JD's ownership line as a plan question. Nothing here claims past work. |
| C2 | "Northwind's stated priorities are enterprise expansion, the Compass copilot launch and reaching profitability. Which one should a new product line serve first, and what does it cost the other two?" | CO | [grounded] "Northwind's three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note) | Pick one, name the trade-off in cost terms, and say what would change your mind. Before the call, check the three priorities are still current. Your note is not re-verified. | Company-altitude question built on your note, because search was refused. Picking and costing a priority is the test. |
| C3 | "The main threat is a much larger platform vendor bundling. How would you defend a standalone product line against that?" | CO | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | Frame the bundle as a pricing and packaging problem you can test: where the bundle's price anchors, which customers it reaches first, and what a standalone line must show to be chosen. Name no competitor specifics you have not checked. | The competitive frame from your note is the differentiator question. The guidance names no fact about the competitor. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience." (the coach's notes) | Name the weakest area in your own words. If it is sales operations or quota-setting, say so once, plainly, and do not argue it away. Then give the closure path: the volume-target work and what you would learn first. Confirm the negative in your own words before you say it. The pack supplies no words for it. | The persona stem aimed at the gap F7 records. |
| D2 | "What's the difference between a volume target and a quota, and which one would you set for this team?" | JD | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Define the difference in your own words. General definition, not a fact about Northwind: a quota is an individual seller's share of a target. Then say which you would set for this team and why. Answer slot: if you have set a quota, say which. If you have not, say so and say what you would need to learn before setting one. | The highest-ROI objection. The quote carries volume targets, not quotas, so the guidance can only describe that difference. Deepest rehearsal: hold the volume-target distinction through two follow-ups. |
| D3 | "What would make you the wrong hire for this role?" | VAL | [generic] | Calibrated candor, one answer. Name a gap you can state without apology, the closure path you would take, and the one part of the role you would ask a peer to watch. Do not bluff a competency. | A skeptic's closer. Nothing about your past is asserted here. The gap is named in your words, not the pack's. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" (the coach's notes) | Hold, then concede. Hold: you proposed the change, and it is credited with about $400M. Hold through two follow-ups by returning to the proposal. Concede specifically: the part of the uplift you cannot split from the team's work, in your own words. Do not agree to a share your material does not give. | The Pressure stem on F8. The strength is in the concession, not the figure. |
| E2 | "Sixty seconds: you've spent nine years in product. Why leave that for a sales-strategy role, and why now?" | EXP | [grounded] "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | Give your own reason for the move and for now, in sixty seconds. Answer slot: state the reason for leaving the product role and why now, in your own words. The material gives neither. | The Pressure form of the Skeptic's "why, why now." F1 is the transfer the answer has to carry. |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior a number they did not want. It needs a stake, the moment you did not fold, and a relationship intact at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries, which is the volume-target consensus or the store-surface proposal, and what pushback, if any, you met. | No values round is established, so the persona is weighted 1. It stays in the pack so the style is not met for the first time live. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm" and "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | A 90-second arc: consulting first, then the consumer-tech product and ops years, then this role. State the path in those terms and no more. | Casual openers are scored. The arc should land the F1 transfer in the first two minutes. |
| G2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (the coach's notes) | Name two or three tools and the concrete tasks you use them for, in your own words. Do not describe building AI products or running AI programs. | The JD's AI line, asked casually. F6 is low confidence, so the answer stays on usage. |

### Requirement coverage

| JD requirement | Covered by | Note |
|---|---|---|
| own GTM strategy for two new product lines | C1 | F1 is transferability; its slot is in the fit snapshot |
| identify whitespace across land/adopt/expand/renew | A5 | F2 is discovery; its slot is in the fit snapshot |
| run independent analysis in SQL and Tableau | A4 | F3 |
| partner-motion design experience required | A3, B3 | F4 is transferability |
| strong cross-functional influence | B1, B2 | F5 |
| AI experience a plus | G2 | F6 is discovery |
| Full JD text | none, and why: only highlights were supplied | See the upgrade menu |
| Sales-ops and quota-setting (not in the highlights) | D1, D2 | Covered because it is the likeliest objection; not a JD line |

## 7. Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer slot, hold, bridge or rationale in this pack asserts or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the go-to-market strategy for a product line | Inflated form of F1 | F1's quote at its own scope. The limit is this pack's observation: your material shows product strategy and ops, not go-to-market ownership. |
| Set quotas, or sized seller capacity | Sourced negative (the coach's notes) plus inflated form of F5 | F5's quote at its scope, "annual volume targets". The negative is confirmed only in your own words. |
| Designed the partner program or its incentives | Inflated form of F4 | "Built a partner-level revenue model used in carrier negotiations" at its own scope. |
| Delivered or owned the ~$400M | Inflated form of F8 | "proposed ... credited with" at its own scope. The sentence says proposed and credited, not delivered. |
| Expert in SQL and Tableau | Inflated form of F3 | "skilled in SQL/Tableau". |
| Built AI products or ran AI programs | Inflated form of F6 | "uses AI tools daily". |
| Led cross-functional alignment | Inflated form of F5 | "set annual volume targets with cross-org consensus". |

## 8. Values / principles cheat sheet

Dropped. No values were available: web search was refused, and no company values were supplied.

## 9. Reverse questions

| # | Question to ask Dan | Why it lands |
|---|---|---|
| R1 | "You came into sales strategy from pricing and monetization. What did that background let you see in sales motions that the sales teams missed?" | Ties to Dan's own path. Turns an interrogation into a peer conversation. |
| R2 | "Which number does your team argue about most with Finance, and what is the definition fight?" | Shows you want the denominator. Speaks to a data-driven peer. |
| R3 | "When a partner's price and a direct price collide, who decides, and on what data?" | Tests the seam on the partner motion. |
| R4 | "How is the Compass launch changing what Sales Strategy is asked to measure?" | Uses a stated priority from your note, and asks what has changed. |
| R5 | "What would a new person do in their first month that would genuinely help your team?" | Reciprocity question, since Dan is a peer. |
| R6 | "What's the question about the new product lines your team still can't answer?" | Shows you are thinking about the work, not the job title. |

## 10. Delivery coaching

Dropped. No working-style assessment was provided, and none was solicited.

## 11. Sources

**Provided documents:** the JD highlights (your note), the candidate summary (the coach's notes), the interviewer profile (your note), and the research note (your note). No dossier was consumed.

**Searches and fetches sent:**

| Query | Target | Outcome |
|---|---|---|
| Northwind Data company values operating principles | 1 | refused |
| Northwind Data interview process Senior GTM Strategy Lead Emerging Products | 2 | refused |
| Northwind Data Compass AI copilot launch enterprise expansion profitability | 3 | refused |
| Dan Kovac Director of Sales Strategy Northwind Data pricing monetization | 4 | refused |

"Refused" means the search permission was not granted. No fetches were sent.

**Research tier:** L1 — searches 4 of 6 sent, all refused; fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `{company} values` | unavailable | Would have produced the values cheat sheet, section 8. Dropped. |
| 2. `{company} interview process {role family}` | unavailable | Would have fixed the loop structure. Treated as a single peer round. |
| 3. `{company} strategy` / recent news | unavailable | Would have refreshed the grounding brief. Your research note supplies the priorities, which are not re-verified. |
| 4. `{interviewer name} {company}` | unavailable | Would have added the interviewer's public footprint. The persona weights rest on your profile only. |
| 5. Representative `{role title}` JD | unavailable | Would have filled the JD-tagged gaps. Your highlights fix only part of the fit snapshot. |

## 12. Upgrade menu

- **Full JD text** → gate rows for location, pay, schedule, travel and authorization, if the JD states them. Also the rest of the requirement list, so the coverage table has no gaps.
- **Recruiter's note on focus areas, a deliverable or process details** → a graded-deliverable section if one is announced, and reweighted personas.
- **Search permission granted** → the values cheat sheet, a loop-structure read, a refreshed strategy sweep, and a re-verified grounding brief. C2 and C3 would then be checked against current sources.
- **Your own words confirming "No classic sales-ops or quota-setting experience"** → D1, D2 and F7 can carry a plain acknowledgment in place of an answer slot.
- **Any quota, sales-ops or partner-design work you did, described in your words** → F1, F2, F4 and F6 move from answer slots to story-mapped answers, with each sentence quoted.
- **Interviewer's public talks or writing** → persona weights from their own words, and a reverse question tied to their published themes.
- **Prep time available** → a prep triage section, sized to the time.
- **Deep research (L2), offered once** → a strategy brief, interviewer talks, and role-family loop reports, using up to 6 further searches and 2 fetches. Only if search permission is granted. Its time cost is the searches themselves.
- **A `tuesday-dossier.md`, if you have one** → verified evidence in place of the locally built prohibited list, and named objections in place of the inferred one.
