Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-1-denied-ca49f7e3/77db981d-804c-4e14-a32f-27b4bf43957e/scratchpad/northwind_senior_gtm_strategy_lead_interview_pack.md`. It covers 21 questions across seven personas, each tagged by type, with a fit snapshot, prohibited-claims list, reverse questions, and a source accounting.

Web search was refused in this session, so I could not check Northwind's values, interview loop, strategy, or Dan's public footprint. The strategy and priorities come only from your research note, which is undated. The interviewer read uses only your profile note. Check the note's date before the interview.

**What the pack says to prioritize**
- **Highest-ROI prep (D1):** "Which part of this role would you be weakest at on day one?" The sales-ops and quota gap plus the partner-motion gap are the most likely objection, and Dan's sales-strategy role makes it their turf. Rehearse the plain acknowledgment, hold on the volume-target work you actually did, and concede the quota gap without inventing experience.
- **Your headline figure (A1, E2):** the ~$400M is "credited with" in your own words. Expect a probe on how it was counted and what share was yours. Only say what you can defend.
- **Partner motion (A2, B4):** the revenue model is the nearest evidence. Be clear whether you designed partner terms or only modeled them for negotiations.

**Persona weights:** Data-Driven Prober 5, Peer Evaluator 4, Case/Strategist 3, Skeptic 3, Pressure 2, Conversational 2, Values 2 (touched only, since no values round is established).

**Open question:** did the recruiter name any focus areas or a pre-declared deliverable such as a POV, deck or take-home for the hour? If so, I'll add a build section for it.

Drill offer: I can play the Skeptic on D1 and give feedback against that question's guidance. Dossier offer: I can save a `tuesday-dossier.md` recording the gaps this prep exposed. Word offer: I can convert the pack to .docx if you want it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: northwind_senior_gtm_strategy_lead_interview_pack.md -----
# Northwind Data: Senior GTM Strategy Lead, Emerging Products

**Interview:** Dan Kovac, Director of Sales Strategy (peer, same VP) · 60-minute single conversation · Candidate: Priya
**Changelog:** first pack, no regeneration.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Tag | Name | Meaning in this pack |
|---|---|---|
| VAL | Behavioral / values | No values round detected, so VAL questions are open prompts |
| EXP | Experience deep-dive | Tests whether your own claims survive attribution |
| JD | Role / JD-driven | Tests the stated responsibilities, including gaps |
| CO | Company and strategy | Built only from your research note, which I could not verify |
| CASE | Live problem | A problem from the role, structured aloud |

Guidance is scaffolding, not a script. Each cell should be speakable in 90 to 120 seconds. Answer slots are instructions for the interview: answer from your own experience, in your own words.

## Fit snapshot

Requirements are the six JD highlights you supplied. The full JD text was not seen. The highlights name no location, work-authorization, travel or pay term, so the snapshot has no gate rows. Quoted candidate evidence comes from your message unless marked otherwise.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "in product strategy & ops" (your message) | low | [inferred] | transferability | The material shows product strategy and ops, not go-to-market ownership of a product line. Bridge at the quote's own scope: "9 at a large consumer-tech company in product strategy & ops." Answer slot: if you set go-to-market for any product line, say which and what you decided; if not, say so and say what product strategy covered. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | none given | none | [grounded] | discovery | No material shows a whitespace analysis across the four lifecycle stages. Answer slot: name a place where demand was under-served, which stage it sat in, and how you found it; if you have none, say so and describe how you would look for whitespace across the four stages. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (your message) | low | [inferred] | presentation | The quote reaches the tools, not independent work. Reword only: "Your material says you are skilled in SQL/Tableau." |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (your message) | medium | [grounded] | transferability | The quote shows a revenue model used in negotiations, not design of a partner motion. Bridge at its own scope: "I built a partner-level revenue model used in carrier negotiations." Caveat: expect a probe on what design, if any, sits behind it. Answer slot: if you designed partner terms or a motion yourself, say which and how you decided; if the model was an input to negotiations rather than a design, say so. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (your message) | medium | [grounded] | presentation | The quote reaches influence in other terms. Bridge with the quote only: "I set annual volume targets with cross-org consensus." Caveat: expect a probe on how the consensus was reached. |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (your message) | low | [inferred] | transferability | Use is adjacent to building AI products, which the material does not show. Bridge: "I use AI tools daily." Answer slot: if you built or shipped anything AI-based, say which; if not, say that. |
| F7 | sales-ops and quota-setting work (role-family expectation, not a JD highlight) | "No classic sales-ops or quota-setting experience" (your message) | high | [grounded] | capability | A stated absence. Words: "I haven't got classic sales-ops or quota-setting experience." Then how you would learn the mechanics, said as a plan, never as a past. |
| F8 | headline result (no JD highlight; the attribution probe) | "proposed a store-surface change credited with ~$400M ARR uplift" (your message) | medium | [grounded] | none | No requirement to bridge. Expect a probe on attribution: "credited with" is the material's wording, so say what you proposed and what share is yours, in your own words. |
| F9 | career arc (no JD highlight) | "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" (your message) | medium | [grounded] | none | No requirement to bridge. Use the two quotes at their own scope for the opening arc. |

Seven rules applied to this snapshot: confidence, provenance and gap type each hold one token; the evidence column holds only your sentences; the requirement column quotes only the highlights; the bridges reword or quote and add no practice; gap types follow the evidence cell; F7 is the only row whose words are a negative you stated.

## Prohibited list

Each entry names its basis. None of these may be asserted, implied or softened in any answer, hold, bridge or reverse question below.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned go-to-market for a product line | Inflated form of F1 | The quote at its own scope: "in product strategy & ops." The pack's observation: your material says product strategy and ops, not go-to-market ownership. |
| Designed partner motions or partner programs | Inflated form of F4 | "built a partner-level revenue model used in carrier negotiations." The pack's observation: the material says a model, not a motion. |
| Set quotas or ran sales-ops | Inflated form of F5, and the negative in F7 | "set annual volume targets with cross-org consensus" at its scope, plus the plain acknowledgment from F7: "I haven't got classic sales-ops or quota-setting experience." |
| Drove the ~$400M ARR | Inflated form of F8 | "proposed a store-surface change credited with ~$400M ARR uplift." The pack's observation: the material says proposed and credited with, not delivered or owned. |
| Built AI products | Inflated form of F6 | "uses AI tools daily." |
| Independent analysis drove decisions | Inflated form of F3 | "skilled in SQL/Tableau." |

## Persona weights

Round: a single 60-minute conversation with a peer. No loop source establishes the loop, so the fallback is the generic archetype, which says flat weights and no values round. Weights are stated plainly so you can correct them.

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | Two-level follow-ups on every figure; asks for denominators and assumptions | 5, top. The interviewer self-describes as "relentlessly data-driven", and the peer prior already leans this way. Very likely. | Name the weakest assumption before it is asked; say plainly where you do not know how a figure was counted. |
| Peer Evaluator | Seam questions, "what would you need from me", credit | 4. Peer relationship prior. Both report to the same VP, so the hire touches the interviewer's own work. Likely. | Reciprocity framing; propose seam principles instead of claiming to know the seam. |
| Case / Strategist | Live whitespace and pricing problems | 3. The interviewer's career spine is "pricing and monetization", which tilts cases toward pricing and packaging. | Clarify, structure aloud, name the pricing lever explicitly. |
| Skeptic | The sales-ops and quota gap, and the partner-motion gap | 3. F4 and F7 are the largest gaps in the material. Likely at least once. | Plain acknowledgment, then a ramp plan stated as a plan. |
| Pressure / Stress | "How much of that was actually you?" on the largest figure | 2. A peer register lowers this, but a probe on the figure is still likely. | Hold, then concede specifically. |
| Conversational / Rapport | A biography opener | 2. It opens the round and is scored. | A pre-scripted 90-second arc. |
| Values / Behavioral | Open prompts from persona stems | 2, touched for coverage only. No published values were available and no values round is detected. | Selection scaffold; say so if no story comes. |

## Reading the interviewer

Source: your profile note only. A public-footprint search was refused in this session, so no talks or writing were checked.

- **Career pattern:** a "pricing and monetization" spine with one early-stage-startup chapter, as you described it.
- **What this means in the room:** expect every metric to be probed to its assumptions; expect cases to lean toward pricing and packaging; expect the startup chapter to surface as questions about pace and scrappiness, asked lightly.
- **Mirror opportunity:** the monetization vocabulary. F4 is the nearest sentence to it, and it should be used only at its own scope.
- **Shared jump:** not established. The material has no startup chapter for you, so no shared jump is offered.

## Grounding brief

Built from your research note alone. The note is undated and I could not verify it this session. Strategy is perishable, so check it before you use these phrases.

- "Northwind's three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability"
- "main competitive threat is bundling by a much larger platform vendor"
- Vocabulary to use: enterprise expansion, Compass, profitability, bundling.

## Question banks

Provenance sits before guidance. Every candidate sentence a guidance claim rests on is quoted in the Provenance column.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" | Defend-the-number slot. Say how it was counted, in your own words. Name what it is most sensitive to and the assumption you would defend least. Say which part was yours. Your material says "credited with", so the count, not you, assigns the figure. Answer slot: if you know the counting method, say it; if you don't, say so plainly. | F8 is the headline figure and the likeliest probe. EXP because it tests attribution, and "credited with" is the wording the probe will test. |
| A2 | "What inputs to that partner revenue model did you not control?" | EXP, JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Weakest-assumption move on the model: name the input you controlled least and how you would defend it. Answer slot: if you set the inputs, say which; if someone else set any, say who. | F4 is where the partner-motion requirement presses hardest. A2 tests whether the model is an input or a design. |
| A3 | "When has an analysis you ran changed a decision? What did you check before trusting it?" | JD | [inferred] "skilled in SQL/Tableau" | Open prompt; the quote carries no story, so this is a selection scaffold. Pick an analysis you ran yourself: the question, the cut you chose, what you checked before trusting it. If none changed a decision, say so plainly, then give how you would validate a whitespace model. | F3 is low confidence, so this is a coaching note, not a claim. Dan will ask for denominators. |
| A4 | "Where do you use AI tools day to day, and where do you not trust them?" | JD | [grounded] "uses AI tools daily" | Name the tools and the tasks in your own words; keep it to use, not building. Answer slot: name one task where you checked the output. | F6. The prober will test use against building; keep the two apart. |
| A5 | "What did those annual volume targets assume?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Weakest-assumption move. Define consensus in your words: who agreed, and to what. "Set" means set. Do not turn it into quota. Answer slot: if someone else set the assumptions, say who. | F5 is the evidence for the influence requirement, and the prober will check what consensus meant. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side on pricing and sales strategy. Where is the seam, and how do we decide when we disagree?" | JD | [grounded] "career spine is pricing and monetization" (interviewer profile note) | Propose seam principles: who owns the number, who owns the model, what goes to the VP. Do not pretend to know the seam. | Peer prior. A collegial probe on whether the hire adds to Dan's load. |
| B2 | "What would you need from my team in your first month?" | JD | [generic] | Name two inputs you would need, data or decisions, and who decides. Do not promise outcomes. | Peer probe on load and reciprocity. |
| B3 | "How do you handle credit when work spans teams?" | VAL | [grounded] "set annual volume targets with cross-org consensus" | Use the cross-org item. Say what you did and what the other side did. "We" for context, "I" for your contribution. Answer slot: if credit on the targets was shared unevenly, say how. | Persona stem. The consensus sentence is the only cross-org evidence in the material. |
| B4 | "If we split a partner motion between us, what would you take and what would you hand me?" | CASE | [generic] | State a split principle: what needs the partner relationship, what needs the sales data. Do not claim partner-motion design. | F4 seam, asked collegially. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two new product lines, one sales org. Where do you look for whitespace first across land, adopt, expand and renew?" | CASE, JD | [grounded] "own GTM strategy for two new product lines"; "identify whitespace across land/adopt/expand/renew" (JD highlights) | Clarify the objective, segment, name the stage you would look at first and the metric that tells you. Name a pricing lever as one angle, since the interviewer's career is in pricing. | The JD's own ask, tilted to the interviewer's native ground. |
| C2 | "Enterprise expansion is a stated priority. What would you measure first to know whether it is working on a new line?" | CO, CASE | [grounded] "Northwind's three stated priorities are enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note) | Name two metrics and the assumption behind each. Treat the priority as stated in the note. Do not assert Northwind's figures. | CO from your note, unverified. Labeled as such so the note's date gets checked. |
| C3 | "Bundling by a much larger platform vendor is the main threat. How would you price against a bundle?" | CO, CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note) | State the trade-off in your own words: hold price, add value, or match with a bundle of your own. Name what you would need to know first. Do not assert Northwind's pricing. | The most pricing-native question for this interviewer. Unverified note, same caveat as C2. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | **Highest-ROI prep.** "Which part of this role would you be weakest at on day one?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message); "partner-motion design experience required" (JD highlights) | Lead with the plain acknowledgment: "I haven't got classic sales-ops or quota-setting experience." Then the partner gap, at F4's scope. Hold through two follow-ups by returning to what you have set: "annual volume targets with cross-org consensus," and say that you have not set quotas. Concede plainly where your uncertainty sits: how quotas interact with whitespace. Then a ramp plan, as a plan: what you would learn first and from whom. Never claim sales-ops or quota work. | This is the single most predictable objection. F7 and F4 together are the largest gaps, and quota is the interviewer's own turf. Expect three follow-up levels. |
| D2 | "I don't see classic sales-ops or quota-setting in your background. How would you close that in this role?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message) | Plain acknowledgment first. Bridge with the quote at its scope: "set annual volume targets with cross-org consensus." Answer slot: if you have worked alongside anyone who set quotas, say what you did there; if not, say so and say how you would learn the mechanics. | F7 is a stated absence, so the acknowledgment is sourced. |
| D3 | "Skilled in SQL and Tableau: why should I believe you run independent analysis?" | JD | [inferred] "skilled in SQL/Tableau" (your message) | Clarify-strategy note, because confidence is low. The material shows the tools, not independent work. Say what you would show and how you would check it. Claim an analysis only if you ran one alone; if you did not, say so. | F3. The interviewer will ask what "independent" means. |

### E. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, given the sales-ops gap?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your message) | Hold, then concede. Hold on what you have set: the volume targets and the revenue model. Concede the sales-ops gap by name. Do not argue that sales-ops experience is unnecessary. | A pressure stem on F7. The held position is what the quotes carry. |
| E2 | "That result: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" (your message) | Say what you did, which is proposing the change, and what "credited with" means. Your share goes in your own words. Concede what you cannot measure. Hold through two follow-ups. | The largest claim, and a standard honesty probe. |

### F. Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm"; "9 at a large consumer-tech company in product strategy & ops" (your message) | A 90-second arc in order: consulting, then consumer tech, then this role. Use the two quotes at their scope. Make no startup claim. | Casual register, still scored. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (your message) | Name the tools you use and one task for each. Keep it to use. Answer slot: name one task where you checked the output. | The plus-skill asked casually. |

### G. Values / Behavioral (weight 2, touched)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the truth reached leadership, what it was, what you did, what happened. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the annual volume targets, or how you would handle it. | Persona stem. No published values exist to map. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold. If none comes, say so plainly. | Touched for coverage only. |

## Requirement coverage

| JD highlight | Questions | Note |
|---|---|---|
| own GTM strategy for two new product lines | C1, D1, F1 | Evidence is adjacent (F1) |
| identify whitespace across land/adopt/expand/renew | C1, C2 | F2 is a discovery gap |
| run independent analysis in SQL and Tableau | A3, D3 | F3 is low confidence |
| partner-motion design experience required | A2, B4, D1 | F4 is transferability |
| strong cross-functional influence | A5, B3, E1 | F5 |
| AI experience a plus | A4, F2 | F6 |
| Stated absence: sales-ops and quota-setting | D1, D2, E1 | F7 |

Total questions: 21, within the 18 to 26 range.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "What could a new person do in their first month that would genuinely help your team?" | Reciprocity, the peer case. Shows you are thinking about Dan's team's load, not only your own. |
| R2 | "You spent a chapter at an early-stage startup and the rest of your career in pricing and monetization. What did that chapter change in how you price?" | Tied to the interviewer's own path. Turns a motivation probe into a peer conversation. |
| R3 | "Where does the Compass launch touch the sales strategy team's plan?" | Grounded in your note. Asks rather than assumes. |
| R4 | "Which pricing decision on the current roadmap are you least sure about?" | Pricing is the interviewer's native ground; shows interest in the real problem. |
| R5 | "When the GTM plan and the pricing model disagree, where does the decision go?" | Probes the seam, and shows you want the escalation path clear. |
| R6 | "What would make the first two quarters on the new lines look like a success to the VP?" | Expectations and altitude. |

## Sources

**Provided documents:** the JD highlights; your candidate background note; the interviewer profile note; your research note (undated).

**Research tier: L1, searches 0 of 6 returned results (4 refused), fetches 0 of 2 (none attempted).**

| Query sent | Outcome |
|---|---|
| "Northwind Data company values" | refused |
| "Northwind Data interview process sales strategy" | refused |
| "Northwind Data strategy Compass AI copilot enterprise expansion profitability" | refused |
| "Dan Kovac Director of Sales Strategy Northwind Data" | refused |

"Refused" means the web search permission was not granted in this session. I did not retry.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Values cheat sheet not built. No values round is detected, so the section is dropped. |
| 2. Interview process | unavailable | Loop structure unknown. Persona weights rest on relationship priors and the generic fallback, stated above. |
| 3. Strategy and recent news | unavailable | Freshness of your research note not verified. CO questions are labeled from it. |
| 4. Dan Kovac with Northwind | unavailable | Public footprint not checked. The interviewer read rests on your profile note only. |
| 5. Representative JD | skipped | JD highlights were supplied. |

Sections dropped for their conditions: prep triage (prep time not given), graded deliverables (none declared), delivery coaching (no assessment provided), values cheat sheet (no values round detected).

## Upgrade menu

- The full JD text → the highlights become the posting's own lines, and any location, work-authorization or travel term becomes a gate row, none of which the highlights show.
- The recruiter's note on focus areas or a pre-declared deliverable (a POV, deck or take-home) → coverage of that deliverable, with its own build section.
- Interviewer's public footprint (a search was refused this session) → a grounded reverse question from their talks and writing, and persona weights checked against them.
- Northwind's published values, pasted → a values cheat sheet, but only if a values round is established.
- Your own account of how the ~$400M figure was counted, and which part was yours, said in your words → A1 and E2 regenerate on your material instead of answer slots.
- Your answers to the answer slots, given outside a drill (for example, whether you set any go-to-market stage or any partner term) → F-rows and banks regenerate on those quotes.
- The date of your research note → verifies or retires C2, C3 and R3.
- Deep research pass (strategy brief, interviewer talks, role loop reports), up to 6 more searches and 2 more fetches, several more minutes → offered once. Search was refused this session, so it would need permission first. Want it?
- A `tuesday-dossier.md` → verified evidence and a prohibited-claims list that bind every cell, in place of the local list above.
