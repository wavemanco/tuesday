Your prep pack is saved as `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-7-canned-4d44ee4a/9207fb58-5f80-431d-bf92-93273c31059b/scratchpad/saltmarsh_live-operations-producer_interview_pack.md`. I built it on one assumption: that Friday's session is the Outage Hour and Tobias runs it as hiring manager. The careers page describes that format, but nothing I found names him as the person who runs it.

**What the research changed**

- **The session is a live-incident tabletop, then values.** Saltmarsh's careers page says every loop ends in a single 60-minute "Outage Hour" with the hiring manager: a simulated outage during a live event, then a values conversation. So expect a case-heavy first half. Practise A1 (a patch breaks progress for one player group) and A3 (QA wants a delay, community wants a notice).
- **The company values are now confirmed:** Players Before Plans, Ship the Patch Not the Promise, and Leave the Build Greener. Your release-checklist sentence maps to the third. Nothing in your material speaks to the other two, so for those the honest move is to say so.
- **Current strategy:** a September 2026 announcement, Project Larkspur, moves both titles onto one shared events calendar from February 2027. The pack uses it only in your reverse questions, because an interviewer's question can't rest on a news item. I only saw the search snippet, not the full page.

**The objection to rehearse hardest (C1):** "You presented retention numbers. What did you decide about what they measured?" The JD asks you to own the KPIs and the post-event review, and your material only shows that you presented the monthly numbers. Practise the hold, and be ready to say plainly if you didn't define the measures.

**Gaps the pack won't paper over**

- No team leadership. The honest line is "I haven't led a team," and the pack never lets that become coordination experience.
- No in-app-purchase work. Same treatment, with retention as your honest bridge.
- Two titles versus one, and "content drops" versus "live-service." The pack flags these as answer slots, not stories.
- Written communication has no strong evidence in your material. The release checklist is the nearest thing.

**Things to verify before Friday**

- The GDC talk listing for Tobias came from a domain I could not confirm as a conference site. I'd treat his career path (previously a QA lead at a console studio) as unverified until you check it. Only use reverse question R4 after you've confirmed it.
- Tobias's title and the hiring-manager role are from the company's own pages, not from anyone at Saltmarsh.

**Research used:** 4 of 6 searches and 2 of 2 page fetches. The deeper research pass (strategy brief, his talks, loop reports, recent org news) is optional and would add more strategy questions. Say the word and I'll run it.

Two offers, neither pushed:
- I can play the Skeptic on C1, the objection the pack ranks as highest-value prep, as a live drill.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

Is Friday's session the Outage Hour, and is Tobias the hiring manager who will run it, or is there a second round before an offer?

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live-operations-producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

Role: Live Operations Producer. Company: Saltmarsh Games. Interviewer: Tobias Wrenfield, Head of Live Operations (assumed hiring manager; see Interviewer read). Format: one 60-minute session, the Outage Hour, per the company careers page.

## How to use

Personas are how a question is asked. Types are what it scores: **VAL** values and behaviour, **EXP** your own experience, **JD** the listed role, **CO** company knowledge, **CASE** a live problem. Guidance is scaffolding, not a script. Rehearse the honest branch as much as the answer.

**Session shape** (from the careers page format, not a confirmed agenda):

| Minutes | Segment | Question IDs |
|---|---|---|
| 0–5 | Opening and your story | F1 |
| 5–30 | Outage Hour tabletop | A1, A3, A5, A2 |
| 30–45 | Values conversation and the calendar | B1, B2, B3, A4 |
| 45–55 | Skeptic and pressure probes | C1, C2, C3, C4, E1 |
| 55–60 | Your questions | R1–R5 |

Probes will interleave in a real session. Insurance items (D1, D2, E2) come up only if the interviewer goes deeper.

## The fit snapshot

The JD has no term gates. "3+ years" is a length of experience, graded on fit like any other requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material shows one title and weekly content drops, not two titles of live events. Words: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: the JD asks for two titles, so expect a probe on planning across a second one. If you planned anything across a second title, say what; if not, say so and describe your first step. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show how you worked with design, art, engineering or community on an update. Answer slot: describe how one update moved from plan to release across those teams, in your own words. If you did not run that coordination, say so plainly and describe how you would. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting numbers is not owning the review or the KPIs, and the bridge should not stretch. Words: "I presented the monthly retention numbers to the studio head." Answer slot: if you chose which numbers went in, or how they were defined, say so; if you did not, say so plainly. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement in other terms. Words: "I wrote the release checklist our QA team still uses." Writing a checklist is not managing each release, so expect a probe on what you did with it after release. Answer slot: say what you did with it release by release, in your own words, if anything. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Four years is in the material, but "live-service" is not. Words: "I have four years as an associate producer at a puzzle-game studio, and for two of them I ran its weekly content drops." Answer slot: if the title ran as a live product after launch, describe how in your own words; if you cannot, say so plainly. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | Covered in the quote's own terms. Use the quote's words. Expect a probe on scope, which F1 already covers. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting is adjacent to analysing. Words: "I presented the monthly retention numbers to the studio head." Answer slot: say what you did with the numbers in your own words. If you analysed them, say how; if you presented figures you did not compute, say so. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | The checklist is the nearest written artifact in your material, and it does not show a write-up. Answer slot: name a written piece you produced that others used, in your own words. If none comes to mind, say so. |

**Gaps outside the JD's wording, from your message.** You have never led a team, and you have never worked on a game with in-app purchases. Neither is a JD requirement, but both are likely probes. They are handled in the prohibited list and the Skeptic bank, not as bridges.

## Interviewer read

Public footprint only, from search results. Neither the careers page nor the search result names Tobias as the person who runs the Outage Hour; the assumption rests on his title.

- **Career pattern** (search listing, not fetched): a GDC 2026 talk listing describes Tobias Wrenfield as Head of Live Operations at Saltmarsh Games, previously a QA lead at a console studio. The listing's domain did not confirm as a conference site, so treat this as unverified until you check it.
- **Self-described argument** (same listing): "a live team is judged by how often its patch notes describe what actually shipped."
- **Implications:** expect QA-minded probes. The release checklist (F4) and the Ship the Patch Not the Promise value both sit on his stated argument. Do not quote the talk back at him unless you have confirmed it.
- **Mirror opportunity:** the release checklist (F4) is the one shared professional ground your material offers. Describe it in your own words.

## Persona table

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Case / Strategist | The Outage Hour's live-incident tabletop | High. The careers page names a 60-minute tabletop on a simulated outage during a live event | Clarify, set the objective in player terms, decide, name who you need, say what players hear | 5 (A1–A5) |
| Skeptic | Probes on KPIs, team leadership, IAP, and live-service | High. The hiring manager is buying capability and the JD has three open gaps for you | Hold the one position, then concede specifically | 4 (C1–C4) |
| Values / Behavioral | The values conversation after the tabletop | High. The careers page names one, and the company publishes three values | Scaffold, with the honest branch where no story exists | 3 (B1–B3) |
| Data-Driven Prober | Denominator and definition probes on the retention numbers | Medium. Retention is a JD requirement, but no figure was given | Say what you know and what you do not | 2 (D1–D2) |
| Pressure / Stress | Time-boxed challenges on the two-title gap | Low to medium | Hold two follow-ups before any concession | 2 (E1–E2) |
| Conversational / Rapport | Opening biography and a casual question on live events | Low to medium | 90-second arc | 2 (F1–F2) |

The Peer Evaluator is not weighted. This is not a peer round.

## Question banks

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event is running, and a patch breaks progress for one group of players. Walk me through your first thirty minutes." | CASE | [generic] | Clarify what breaks, for whom, and how many players. State the objective in player terms first (Players Before Plans). Choose between hotfix, rollback and pausing the event; name who you need on the call, which is engineering, QA and community. Say what players will be told and when. Name two metrics to watch: affected players' progress and error rate. | The tabletop format from the careers page. Labelled [generic] because it is a pattern for the problem, not a fact about this company or about you. |
| A2 | "You would plan and run the live-events calendar for two titles. How would you sequence the next quarter?" | JD, CASE | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Start from the calendar you ran: what it held and what it took to plan. Then say what changes with two titles: which dates collide, which teams are shared, what you would need to see before committing. Answer slot: if you have sequenced anything across a second title, say what; if not, say so plainly and describe your first step. | F1 is the evidence for the two-title line and the likeliest place to be probed. The premise is the JD's; the guidance does not claim you have done it. |
| A3 | "On event day a patch goes out with two known issues still open. QA wants a delay and community wants a notice. What do you do?" | CASE | [generic] | Structure it: what each issue does to players, what the delay costs, what the notice must say. Ship the Patch Not the Promise means the notice names only what shipped. Decide, then say who signs off, and record it for the post-event review. | Tests the release-checklist requirement under pressure without asking about your past. |
| A4 | "What goes into a post-event review, and which KPIs would it report?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | Describe a review in its parts: what the event was meant to do, what happened, what you would change, and who owns each. Say what you presented to the studio head and where those numbers came from, in those words. Answer slot: if you defined any KPI or chose what the review reported, say which and how; if you did not, say so plainly and say what you would report first. | Owning the review is the JD line F3 does not yet reach. The second branch lets the practice be absent. |
| A5 | "How would you get design, art, engineering and community onto one update?" | CASE | [generic] | Structure it: one owner per update, a shared dated checklist, a cut-off date per team, and a decision point for scope. Answer slot: if you ran a multi-team update, say how and what slipped; if you did not, say so plainly and describe how you would start. | F2 has no quote. Coordination across four teams is the JD's first duty and the material is silent on it. The slot is the honest form. |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "You presented retention numbers. What did you decide about what they measured?" | JD, EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Hold: "I presented the monthly retention numbers to the studio head." Hold through two follow-ups by returning to that sentence. Concede specifically: if you did not define the measures, say so and say what you would want to define. Answer slot: if you made any choice about the figures, say which in your own words; if none, say so. | The highest-ROI rehearsal in this pack. This is the JD's KPI-ownership line (F3) meeting the only retention evidence you have. Rehearse it until it is boring. |
| C2 | "You've never led a team. How would you get four functions to move on your schedule?" | JD | [grounded] "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." Then answer the coordination question from A5's structure, in your own words. Do not describe any leadership, formal or informal, that you have not stated. | The JD asks for coordination, not team leadership. The question presupposes a negative you stated, so it is sourced. |
| C3 | "You haven't worked on a game with in-app purchases. Why would you be right for these titles?" | JD | [grounded] "Never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the strongest sentence you have: "I presented the monthly retention numbers to the studio head." Do not claim monetisation experience, and do not promise to pick it up quickly. | IAP is not in the JD, so this is a skeptic's probe rather than a requirement. Retention is the JD's stated metric and the honest bridge. |
| C4 | "You've worked on a puzzle title. What carries over to live-service?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Name what carries over, from your own material: the content calendar and the release checklist. Answer slot: if you can describe what made the title run live after launch, say so in your own words; if you cannot, say so plainly. | The JD requires live-service years (F5). The question does not say whether the puzzle title was live-service, and neither does the guidance. |

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "What did the monthly retention numbers you presented actually measure?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you can say what the figure counted, say it in your own words. If you did not compute it or cannot repeat how it was counted, say so plainly. Name the assumption you would defend least, if you know one. | The prober asks for the denominator. No figure was given, so the defend-the-number slots do not apply, but the plain answer is the same. |
| D2 | "A content drop lands, and retention for the group that got it dips a week later. How would you tell whether the drop caused the dip?" | CASE | [generic] | Clarify the group and what else changed that week. Compare against a holdout or a previous drop. Name the weakest assumption in your comparison before the interviewer does. | A metric-diagnosis case from the role's own calendar. [generic]: it makes no claim about your past. |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run live events on two titles?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; [grounded] "Wrote the release checklist our QA team still uses" | Hold on what you have: one title for two years. Concede the two-title gap explicitly. Then name what you bring besides: the release checklist QA still uses. Do not argue that you have two-title experience. | A composure test on F1, the JD's two-title line. The answer is hold, then concede. |
| E2 | "That content calendar: how much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Hold: "I ran it for two years." Say what you decided and what others decided. Concede any part that was not yours. Do not widen the scope. | An attribution probe on F1. The honest answer is the precise scope. |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; [grounded] "Presented the monthly retention numbers to the studio head" | A 90-second arc using only those three sentences: four years at a puzzle studio, two of them running the content calendar, and presenting retention to the studio head. Close with why this role, in your own words; your material does not state that reason. | An opener scored on communication economy. Biography from quoted sentences only. |
| F2 | "What are you playing these days, and how do you think it runs live?" | JD | [generic] | Pick a game you actually play. Name what is live about it: events, drops, what changes at a reset. Keep to what you have played. | Casual register on a live-events topic. The question is scored. |

**Coverage.**

| JD requirement | Question IDs |
|---|---|
| Live-events calendar for two titles | A2, E1 |
| Coordinate design, art, engineering and community | A5, C2 |
| Own the post-event review and KPIs | A4, C1 |
| Manage the release checklist with QA | A3, B3 |
| 3+ years producing live-service | C4, F1 |
| Experience running a content calendar | E2, F1 |
| Comfortable with player-retention metrics | D1, C1 |
| Clear written communication | none, and why: a live 60-minute session does not ask for a written sample. The upgrade menu asks for one. |

## Values cheat sheet

The values conversation is documented in the careers page's loop, so this section applies. Values are from the company's values page.

| Value (official name) | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and the players disagree, the players win | B1: selection scaffold. Your quoted sentence "I ran the weekly content-drop calendar for our main title for the last two years" carries the calendar but not a disagreement. If no such time comes to mind, say so plainly, then give the nearest thing the calendar carries: how you set the drops. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | B2: selection scaffold. No quoted sentence speaks to it. If you cannot name a time you announced something before it was built, say so plainly. |
| Leave the Build Greener | Every release leaves the codebase and checklist better than it found them | B3: story map from "Wrote the release checklist our QA team still uses." Answer slot: if you changed the checklist after a release, say what changed and why; if you have not, say so plainly. |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Project Larkspur moves both titles onto one shared events calendar from February 2027. What would a new producer need to learn first to run it?" | Shows you read the company's announcement and asks for working knowledge rather than claiming any. |
| R2 | "How does the live-ops group decide when an event waits and when it ships?" | Tests how Players Before Plans and Ship the Patch Not the Promise work in practice. |
| R3 | "What did the last post-event review look like, and who wrote it?" | Asks directly about the JD's ownership line, and the answer tells you where it sits. |
| R4 | "You came into live operations from QA leadership. What do you check on a patch that you would have missed before?" | Ties to his path. Use only after you have confirmed the GDC listing. |
| R5 | "What does success look like at 90 days for whoever runs this calendar?" | Role-scope question that shows you are thinking about the job, not just the offer. |

## Prohibited claims

Each entry has a basis and an honest form. Nothing in this pack asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Leading a team | Stated negative: "Never led a team" (your message) | Plain acknowledgment: "I haven't led a team." |
| Monetisation or in-app-purchase experience | Stated negative: "Never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |
| Owning the post-event review or the KPIs | Inflated form of F3. The material says you presented numbers, not that you defined measures | F3's quote at its own scope. The limit is this pack's observation: your material shows presenting, not defining. A4's slot asks only what you chose. |
| Running live events across two titles | Inflated form of F1. The material shows one title | F1's quote at its own scope. A2's slot stays inside the one title you ran. |
| Live-service experience | Inflated form of F5. The material does not say the puzzle title ran live | F5's quote at its own scope. C4's slot asks only what made it live, if anything. |

## Sources

**Provided:** the JD text; your background message.

**Searches (4):**
1. "Saltmarsh Games values": returned saltmarshgames.com/values.
2. "Saltmarsh Games interview process live operations producer": returned saltmarshgames.com/careers/interviewing.
3. "Tobias Wrenfield Saltmarsh Games": returned talks.gdconf.example/2026/patch-notes-are-a-promise. Search snippet only, not fetched.
4. "Saltmarsh Games strategy news": returned saltmarshgames.com/news/project-larkspur. Search snippet only, not fetched.

**Fetches (2):**
1. saltmarshgames.com/careers/interviewing: the Outage Hour paragraph.
2. saltmarshgames.com/values: the three values.

**Research tier: L1 — searches 4 of 6, fetches 2 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh values | yes | Values cheat sheet: three values by name |
| 2. Interview process | yes | The Outage Hour: one 60-minute session with the hiring manager, a live-incident tabletop, then a values conversation. Persona weights and the session shape follow it |
| 3. Strategy / news | yes | Project Larkspur snippet: two titles on one shared events calendar from February 2027. Feeds R1 and R2. It is not a raising source, so no question presumes it |
| 4. Interviewer name | yes | GDC listing snippet for Tobias Wrenfield. Interviewer read, marked unverified |
| 5. Representative JD | skipped | The JD supplied fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- Confirmation that Tobias runs the Outage Hour → confirms the hiring-manager persona weights and removes the one assumption in the pack.
- Your release checklist or a post-event write-up → lifts F4 and F8 from a quote to a named artifact.
- The live-service status of the puzzle title after launch → lifts F5 to fully grounded.
- How the monthly retention numbers were counted, in your own words → makes C1 and D1 answer-ready.
- A deeper research pass (L2): a strategy brief, the interviewer's talks, role-family loop reports and recent org context. Up to 6 more searches and 2 more fetches, several more minutes. → Adds CO questions and sharpens R1 and R4.
- Fetching the Larkspur page → firms up R1 and the strategy vocabulary.
- If Tobias raises Larkspur in the interview, a CO question enters the bank.
