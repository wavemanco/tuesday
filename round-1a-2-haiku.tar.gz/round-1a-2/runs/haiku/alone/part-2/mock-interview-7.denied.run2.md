I'll load the interview-prep skill so the pack is built to your role and interviewer.
The spec is loaded. The pack needs company values, loop structure and the interviewer's public footprint from research, not memory, so I'll load the search tool first.
Web search was refused by the permission prompt, so research did not run. I won't retry it. The pack will be built from your message and the JD alone, and it will say so. Next I'll write the pack file.
Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-7-denied-c501cf1a/eaecbd1d-b9bd-42eb-b1d9-e333d675bc04/scratchpad/saltmarsh_live_operations_producer_interview_pack.md. I built it for a hiring-manager round, since your note didn't say who you're meeting. Web search wasn't permitted in this session, so the pack has no company values, loop structure or interviewer research. The Sources section shows the four attempts.

The pack is built on your message and the JD. Here is what it says most clearly:

- **The biggest risk is "two titles and a post-event review."** You ran one title's content-drop calendar and presented retention numbers. C1 is the question to rehearse first. Concede the gap precisely, and don't stretch "ran the calendar" into "owned the calendar for two titles."
- **Leadership and in-app purchases are stated gaps.** Say "I haven't led a team" and "I haven't worked on a game with in-app purchases" plainly, then give a plan. Don't claim experience you don't have.
- **Your strongest evidence is the release checklist.** QA still uses it, so it maps cleanly to the JD's QA line. If you can share it, that evidence gets stronger.

Say the word and I'll play the Skeptic on C1, the question the pack names as its highest-ROI prep. I can also save a tuesday-dossier.md recording the gaps this prep exposed, for you to carry into later sessions. If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would reshape it:

1. Is Tobias your future manager, or is this a peer or skip-level conversation? Your answer reweights every bank.
2. Did the recruiter name focus areas, or announce a presentation or take-home for Friday? If so, the pack needs a build section for it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: saltmarsh_live_operations_producer_interview_pack.md -----
# Live Operations Producer, Saltmarsh Games: interview prep pack

**Role:** Live Operations Producer. **Company:** Saltmarsh Games (mobile studio, about 350 people). **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Relationship:** assumed to be a hiring manager, since the round type wasn't stated. **Length:** 60 minutes, Friday.

**Changelog:** first version.

## How to use this pack

Personas describe how a question is asked. Types describe what it scores. The guidance is scaffolding, not a script: speak each answer in 90 to 120 seconds, in your own words.

Type key:

- **VAL**: behavioral and values alignment.
- **EXP**: your past work, and whether it holds up under questions.
- **JD**: the role's stated requirements.
- **CO**: company and strategy knowledge. None is written here, because research did not run.
- **CASE**: a live problem from the role.

## Fit snapshot

Requirement text is quoted from the JD. Evidence text is quoted from your message, which is the only material about your background this pack has. Nothing about your past is written here beyond those quotes.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title's weekly content-drop calendar, run for two years, and not a plan across two titles. Say that: "I ran the weekly content-drop calendar for our main title for the last two years." Don't treat content drops as live events unless you can say how they are the same. Answer slot: if you have planned or run calendar work for a second title, say which and how you decided what went in it; if you haven't, say so plainly and say how you would start on the second. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | No sentence in your material covers coordinating those four functions. Answer slot: if you coordinated any of them on a release, name which, what each had to deliver, and how you kept them in step; if you worked with only some of them, say which, and say how you would bring in the rest. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Your material says you presented monthly retention numbers. It does not say you ran a post-event review or set its KPIs. Say: "I presented the monthly retention numbers to the studio head." Answer slot: if any post-event review was yours, say what it covered and which KPIs it reported; if none was, say so plainly and say what you would review first after a drop. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms, so no reframing is needed. Words: "I wrote the release checklist our QA team still uses." Don't turn "wrote" into "manage" or "own". The checklist is an inspectable artifact: sharing it would raise this row. |
| F5 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | none | The quote reaches the requirement in role terms. Words: "I presented the monthly retention numbers to the studio head." Your material has no figure, so expect a probe on how the numbers were counted. B1 covers that. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | transferability | Four years on a puzzle game count toward this only if the game was live-service, and your material doesn't say. Words: "4 years as an associate producer at a puzzle-game studio." Answer slot: if the game ran content after launch that players came back to, say what it was and how it was run; if it didn't, say so plainly and name the live part of your work. |
| F7 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The checklist is a written document QA uses every release, which reaches the requirement in other terms. Words: "I wrote the release checklist our QA team still uses." Don't supply writing samples you haven't shown. |
| F8 | Lead a team (role-family pattern, not JD text) | "Never led a team" (your message) | none | [grounded] | capability | You stated this absence. Words: "I haven't led a team." Then how you would direct people without line authority, said as a plan, never as a past. |
| F9 | Monetization through in-app purchases (role-family pattern, not JD text) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | You stated this absence. Words: "I haven't worked on a game with in-app purchases." Then how you would learn the monetization side, said as a plan, never as a past. |

## Prohibited claims

Built from the fit snapshot. Each entry names its basis, and the honest form is what the pack will say instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F1 | "I ran the weekly content-drop calendar for our main title for the last two years." The limit is the pack's observation, not words for you: your material says one title's calendar, not a plan across two. A2 and C1 stay inside that calendar. |
| Owned the post-event review and its KPIs | Inflated form of F3 | "I presented the monthly retention numbers to the studio head." The pack's observation: your material says you presented numbers, not that you owned the review. |
| Manages the release checklist with QA | Inflated form of F4 | "I wrote the release checklist our QA team still uses." The pack's observation: your material says you wrote it and QA uses it, not that you manage it. |
| Led a team | Your stated negative (F8) | Plain acknowledgment: "I haven't led a team." No slot. |
| Has shipped or run a game with in-app purchases | Your stated negative (F9) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." No slot. |

## Persona table

Relationship prior: a hiring manager tends to weight Case and Skeptic highest. Your material supports no interviewer signal, since research did not run, so the weights rest on that prior and the gaps above.

| Persona | How it shows up | Weight and why | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live problems from this role: a retention drop, two titles sharing one QA team, a first 90 days | 5, top. The hiring-manager prior buys capability, and the JD is mostly work to be run | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. |
| Skeptic | Probes the gaps: two titles, coordination, leading a team, in-app purchases | 4. Seven of the nine fit rows (F1, F2, F3, F6, F7, F8, F9) carry a gap, and the hiring-manager prior weights this persona high | Rehearse the single most predictable objection until it's plain. Concede the specific gap; don't argue it away. |
| Data-Driven Prober | Asks how the retention numbers were counted, and what the post-event review measured | 3. The JD names retention metrics, and F5 has no figure behind it | Name the weakest assumption yourself. Say plainly when you don't know how something was counted. |
| Pressure | Time-boxed challenge on leading a team and on what you actually did | 3. The leadership gap is the first thing a stress interviewer goes to | Pause, restate, hold through two follow-ups, then concede the specific gap. |
| Conversational | Warm opener, then a casual question about mobile games | 2. Casual questions are still scored | A 90-second arc built only from your own sentences. |
| Values/Behavioral | Open-prompt stories about hard calls | 2. No values round is detected: no loop source was read, and the fallback archetype says no | A selection scaffold that ends in its honest branch. |

Peer Evaluator is left out. The relationship isn't a peer one, so it would only dilute the weights. If the round turns out to be cross-team, the weights change.

## Question banks

Each row's Provenance carries every sentence its guidance rests on. "Answer slot" means an instruction for the interview, not a question for this conversation.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your weekly content drop is two weeks out and day-7 retention on the main title has dropped. Walk me through what you'd do." | CASE | [generic] | Clarify first: what changed, whether the drop or something else moved the number, and what has already been ruled out. Then objective, segmentation, the next move, and the metric you would check first. Name one risk to your plan. | A live problem from the JD's work: retention, the calendar and the post-event review together. It makes no claim about your past, so the guidance makes none. Covers R3 and R7 (see coverage). |
| A2 | "Sketch a quarter's calendar for two mobile titles whose updates must share one QA team. What goes first?" | CASE | [generic] | Ask what QA capacity is and which title has the harder date. Build from constraints: fixed dates first, then the drops that depend on QA, then the rest. Name the release checklist as the gate. Don't invent QA headcount. | The JD's two titles and QA line as one problem. A hypothetical, so no claim about your past. |
| A3 | "How would you get design, art, engineering and community to ship one update together, from brief to live?" | JD | [grounded] "coordinate design, art, engineering and community teams on each update" (JD) | Walk the sequence: the brief, who signs off each function's part, the date each has to hit, the check before release, and what the community needs to know. Answer slot: if you coordinated any of those functions on a real release, name which and what you did; if you worked with only some, say which, then say how you would bring in the rest. Don't describe a process you never ran as if you had run it. | F2 is discovery: no sentence covers coordination. The question is the JD's line in its own words, and the guidance adds no past event. |
| A4 | "What would you do in your first ninety days running the calendar for two live titles?" | JD | [generic] | Listen first: each title's current calendar, its last few post-event reviews, and who owns the release checklist. Then propose one change, with the reason and how you would know it worked. Keep it to three steps. | Covers the JD's calendar and post-event review lines as a plan, not a past. |
| A5 | "Write me the note you'd send the four teams before a drop. Say it the way you'd write it." | JD | [generic] | Order it the way the teams act on it: what ships, the date, the owner in each function, what you need back by when, and the one risk. Keep it under two minutes spoken. | Covers "clear written communication" with a live writing exercise. No claim about your past. |

### B. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The retention numbers you presented to the studio head: how were they counted?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Before they ask, name the assumption behind the figure you would defend least, in your own words. Then say what you can and cannot say about how it was counted. If you don't know, say that plainly. Answer slot: if you pulled or built the cohort definitions yourself, say so and how; if someone else set them, say that. | F5 is the evidence for the retention requirement, and this is where it is most likely to be probed. Your material has no figure, so there is nothing to defend yet. |
| B2 | "After a content drop, how did you know it worked?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | Name the measures you watched, who read them, and how a drop's result reached the next plan. Answer slot: if you ran a review of a drop's results, say what it covered; if drops were judged only on the monthly retention numbers, say so plainly and say what you would add after each drop. Don't describe a review you did not run. | F3 is transferability, and the JD's post-event review line raises this probe. Your material doesn't state how drops were judged, so the answer is a slot. |
| B3 | "Walk me through the release checklist you wrote. Which item would you change first?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Describe what the checklist covers and why it runs in that order. For the change, name the item and the reason in your own words. Answer slot: if a QA failure led to any item, say which and what happened; if none did, say so plainly. | F4 is the evidence for the QA requirement and F7 for written communication. The question asks for your reasoning, which the quote doesn't contain. |

### C. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "The role owns two titles and a post-event review. You've run one calendar and presented numbers. Why should we believe you can own both?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" (your message); "Presented the monthly retention numbers to the studio head" (your message) | **The highest-ROI prep in this pack.** Hold through two follow-ups: "I ran the weekly content-drop calendar for our main title for the last two years, and I presented the monthly retention numbers to the studio head." Concede the specific gap: you have not owned a second title or a post-event review. Answer slot: if you have planned or reviewed anything beyond the main title, say what and how you decided it; if not, say so, and say the first thing you would do to close the gap. Expect a second follow-up on what you would drop if the two titles conflict: answer with the trade-off, not a claim of experience. | F1 and F3 are the two requirements this question tests, and the most likely objection to you. It is aimed at exactly where your material is thin, so the rehearsal is about conceding precisely, not about adding. |
| C2 | "This is a mobile live-ops role, and you haven't worked on a game with in-app purchases. What's your plan for that?" | JD | [grounded] "never worked on a game with in-app purchases" (your message) | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then the plan, as a plan: what you would read first, which metrics you would ask the monetization side for, and whom you would ask. Don't claim any monetization work. | F9 is a stated capability gap. The acknowledgment is yours, and the plan is what you would do, not what you did. |
| C3 | "You haven't led a team. This role coordinates design, art, engineering and community on every update. How would you get them to move on your schedule?" | JD | [grounded] "Never led a team" (your message); "coordinate design, art, engineering and community teams on each update" (JD) | Plain acknowledgment: "I haven't led a team." Then the method, as a plan: whose agreement you would need, the dates you would set and who would hold them, and what you would do when a function says no. Answer slot: if you have got a function to move on a date without managing it, say when and how; if you haven't, say so plainly. Hold once, then concede. | F8 is a stated capability gap, and coordination is the JD's verb. The question presses the gap against the requirement it sits next to. |
| C4 | "Your four years were on a puzzle game. Was it live-service, and what did live mean day to day?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message) | Answer both branches. If the game ran content after launch that players came back to, say what it was and how the team ran it. If it did not, say so plainly, then name the nearest live part of your work. Don't call the puzzle work live-service unless you can say what made it live. | F6 is transferability. The question is the JD's live-service requirement asked about your one game, so it names no event you haven't stated. |

### D. Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has led teams?" | JD | [grounded] "Never led a team" (your message); "Wrote the release checklist our QA team still uses" (your message) | Pause. Restate the question. Hold: "I haven't led a team, and the work I can point to is the calendar and the checklist." Hold through two follow-ups. Concede the leadership gap in those words, then return to the work you did. | F8 and F4 are the two rows this question presses. The hold is only what your quotes carry. |
| D2 | "That retention figure you presented: how much of it was actually yours?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" (your message) | Hold: "I presented the monthly retention numbers to the studio head." Answer slot: if you built or pulled the figures yourself, say which steps; if someone else produced them and you presented them, say that. Hold through two follow-ups, then concede which part you can't speak to. | The attribution probe on F5. Presenting is what your quote says. Don't turn "presented" into "analyzed". |
| D3 | "QA still uses your checklist. Why, and what would you change if you had to rewrite it today?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" (your message) | Hold: "I wrote it, and QA still uses it." Concede what you don't know about why QA kept it. Then the change you would make, in your own words. Hold through two follow-ups. Don't say it works because it's good. | F4's quote held under pressure. The concession is about why it persisted, which your material doesn't show. |

### E. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio" (your message); "I ran the weekly content-drop calendar for our main title for the last two years" (your message); "Wrote the release checklist our QA team still uses" (your message); "Presented the monthly retention numbers to the studio head" (your message) | A 90-second arc in this order: four years at the puzzle studio, two years on the calendar, the checklist QA still uses, the retention numbers you presented. Use your own words; add no adjective the quotes don't carry. End on why you want this role, in your own words. | An open, warm opener that is still scored. Every beat is a quoted sentence, so the arc claims nothing you haven't said. |
| E2 | "What have you been playing on mobile lately, and what is it doing to keep you coming back?" | CASE | [generic] | Name one game you actually play and one live thing in it that brings you back: an event, a limited drop, a reward track. If you don't play mobile games much, say so, then give the game you know best and one live thing in it. Don't guess at a title's internals. | A JD plus-skill asked casually, so it is scored. The guidance makes no claim about your past. |

### F. Values/Behavioral (weight 2)

No values round is detected, so no VAL question maps to a published value. These two are general behavioral probes.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Open prompt. Pick a time you told someone senior something they did not want to hear: the stake, what you said, what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | A persona stem. The nearest thing your material carries is the retention presentation, and only if its news was bad. |
| F2 | "When did you put a player ahead of an internal metric?" | VAL | [generic] | Open prompt. Pick a time a number pulled one way and the player experience the other. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would decide it. | A persona stem for live operations. It is a trade-off question, so the honest answer may be a decision, not a story. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, A4, C1 |
| Coordinate design, art, engineering and community teams on each update | A3, C3 |
| Own the post-event review and the KPIs it reports | A1, B2, C1 |
| Manage the release checklist with QA | A2, B3 |
| 3+ years producing live-service games or apps | C4 |
| Experience running a content calendar | B2, C1 |
| Comfortable with player-retention metrics | A1, B1, D2 |
| Clear written communication | A5, B3 |

## Reverse questions

Each one has a "why it lands". No interviewer profile exists, so none is tied to their own path, and the round is not a peer one, so no reciprocity question is needed.

1. "What does a good live-events calendar look like here, and where does the current one break?" Why it lands: it shows you are planning for the work, not the title.
2. "Which post-event reviews do you trust most, and what do you wish they reported?" Why it lands: it opens the KPI conversation from the problem's side.
3. "How is the release checklist gated with QA today, and who can stop a release?" Why it lands: it ties the question to the JD's release line and shows you know the gate matters.
4. "Where does monetization sit in the calendar decisions, and who makes that call?" Why it lands: it turns the in-app purchase gap into a question, not a claim.
5. "What would the first six months need to look like for you to say this was the right hire?" Why it lands: it reveals their bar and lets you check it against your plan.
6. "How much of the calendar is set by the title leads, and how much is the producer's to set?" Why it lands: it clarifies what "plan and run" means in practice.

## Sources

**Provided:** the JD and your background, both in your message. No CV document was supplied, so every evidence quote is from your message.

**Searches:** all four were refused. The web search was not permitted in this session, so none of their results came back.

- "Saltmarsh Games values": refused.
- "Saltmarsh Games interview process live operations producer": refused.
- "Saltmarsh Games mobile game studio news strategy": refused.
- "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused.

Research tier: L1 — searches 4 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Values cheat sheet, section dropped: no published values in hand, and no values round is detected. |
| 2. Saltmarsh Games interview process | unavailable | Loop structure unknown, so the persona weights are the hiring-manager prior, not this company's loop. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Grounding brief and CO questions not written. The pack has no current company context. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Interviewer read dropped, and the reverse questions are role-generic rather than tailored. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Round type and relationship (the question below) → persona weights and reverse questions retuned to the round.
- Recruiter's note on focus areas and any deliverable → a build section for a presentation, take-home or case, if one was announced.
- Search access granted → rerun research: the values cheat sheet, the loop structure, current strategy, and Tobias's public footprint (talks, posts, career path) for a tailored reverse question.
- The release checklist itself, shared as a document → F4 moves from medium to high, and B3 and A5 can cite its contents.
- The retention figures you presented → F5 and B1 gain a number to defend. Without it, B1 stays a slot.
- Whether the puzzle game ran content after launch → F6 and C4 become grounded in your own words.
- Your CV as a document → the evidence quotes cite your CV rather than your message, which is easier to check line by line.
- Prep time before Friday → a prep triage that puts the questions to rehearse first.
- A deeper research pass (L2): up to 6 more searches and 2 more fetches, several more minutes, for a strategy brief and the interviewer's public talks and writing → want it?
- A `tuesday-dossier.md` → the gaps this prep exposed, carried into later sessions.
