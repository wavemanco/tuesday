# Saltmarsh Games: Live Operations Producer. Interview pack

**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not yet confirmed; built as a hiring-manager round.
**Round format (public, saltmarshgames.com/careers/interviewing):** a single 60-minute hiring-manager interview, "the Outage Hour": a live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

## 1. How to use
- **Personas** = how a question arrives. **Types** = what is scored: VAL (values), EXP (your experience, attribution), JD (the listed job), CO (company), CASE (live problem).
- Guidance is scaffolding, not a script. Quotes in the tables are your own words from your message or CV.

## 2. Prep triage (Friday is tomorrow)
I wrote "3 days" in my brief; by today's date, Friday is tomorrow.
1. **B1**, the post-event review and KPI question. Say it aloud three times, including the answer slot.
2. **A2 and A3**, the outage and the live-event tabletop. Practise out loud with a timer.
3. **Values V1 to V3.** Write one honest story per value, or accept the honest branch.
4. **E1**, your 90-second walk-through, using only your four quoted sentences.
5. **B2 and B3**: your plain acknowledgment, then how you would learn it. Twenty seconds each.
Everything else is insurance.

**Suggested 60-minute shape:** 0–5 opener and E1. 5–25 Outage Hour (A1 to A3). 25–35 values (V1 to V3). 35–50 review, KPIs and retention (B1, C1, C2). 50–55 checklist and gaps (C3, B3). 55–60 your reverse questions.

## 3. Fit snapshot
Requirements are quoted from the JD you supplied. Evidence is quoted from your message ("your message").

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | Your material says one title and weekly content drops. Bridge: "For two years I ran the weekly content-drop calendar for our main title." Answer slot: if you have planned across more than one title, say how; if not, say so and say how you would sequence two. |
| F2 | "coordinate design, art, engineering and community teams on each update" (JD) | none given | none | [grounded] | discovery | Your material does not show coordination with those teams. Answer slot: name a content update you got other teams to move on, what each needed from you, and what you did. If none comes to mind, say so and describe how you would run one. |
| F3 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Your material says presented, not owned. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you defined the KPIs or ran a review after an event, say which and how; if you presented numbers others defined, say that plainly. |
| F4 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | none | The quote reaches the requirement. Probe likely on how you run each release through it; the quote does not say you do. Say what you wrote and who uses it. |
| F5 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | medium | [grounded] | presentation | Bridge: "Four years as an associate producer at a puzzle-game studio." Your material does not say live-service; the content drops are the nearest evidence. The title "associate" may be probed. |
| F6 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | Bridge: say the quote in your own words. No artifact is in the material; expect a probe on it. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | Bridge reworded from the quote only. No figure, definition or method is in the material. See C1 and C2. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | Bridge: the quote only. Your material shows a document in use, not how clear it is. Make no claim about clarity. |

**Gates:** none. No JD requirement is a legal, credential or location term, so no row is `hard_gate`.

**Gaps the JD does not name, from your message:**
- In-app purchases. Your message says "never worked on a game with in-app purchases." Not a JD requirement; covered by B2.
- Leading people. Your message says "Never led a team." The JD says "coordinate", not lead; covered by B3.

## 4. Prohibited list
Not to be coached as your claims, and the honest form of each.

| Not coached | Basis | Honest form |
|---|---|---|
| "I ran live events across two titles" | inflated form of F1 | "For two years I ran the weekly content-drop calendar for our main title." Pack observation: your material says one title. |
| "I owned the KPIs and the post-event review" | inflated form of F3 | "I presented the monthly retention numbers to the studio head." Pack observation: your material says presented, not owned. |
| "I managed the release checklist with QA" | inflated form of F4 | "I wrote the release checklist our QA team still uses." |
| "I've produced live-service games" | inflated form of F5 | "Four years as an associate producer at a puzzle-game studio." Pack observation: live-service is not in your material. |
| "I have led a team" | your stated negative | "I haven't led a team." (plain acknowledgment) |
| "I've worked on in-app purchase games" | your stated negative | "I have never worked on a game with in-app purchases." (plain acknowledgment) |

## 5. Persona table
| Persona | How it shows up | Weight, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | The Outage Hour tabletop on a live event | 5 (A1 to A4). The round is a live-incident tabletop, so this is the main format. | Clarify, then contain, then communicate, then review. Think aloud. |
| Skeptic | "Why should we trust you with KPIs and with in-app purchases?" | 4 (B1 to B3). Hiring-manager prior, and your two stated absences are openings. | Hold the bridge from your quote. Say the plain acknowledgment, then the plan. |
| Values / Behavioral | The values conversation after the tabletop | 3 (V1 to V3). Round format names it. | One story per value, or the honest branch. |
| Data-Driven Prober | "How was that retention number counted?" | 2 (C1, C2). JD requires retention metrics. | Say what you presented and which assumption you would defend least. |
| Conversational | "Walk me through the journey" | 2 (E1, E2). Casual questions are still scored. | A 90-second arc from your four quotes. |
| Pressure | "Sixty seconds: why you?" | 1 (D1). The title "associate" is visible. | Pause, restate, hold one claim through two follow-ups. |

**Interviewer read (public footprint, GDC 2026 talk "Patch Notes Are a Promise"):** Tobias came to live ops from QA at a console studio, and argues that a live team is judged by whether its patch notes describe what actually shipped. Implications: the release checklist (F4) and the post-event review (F3) will be probed for accuracy; "Ship the Patch Not the Promise" is his value in practice, so lead with what shipped. This is a shared professional path only in the QA-to-live-ops sense; there is no such path on your side, so do not claim one.

## 6. Question banks
Coverage line below each bank. Question IDs are letter-by-persona.

**Case (weight 5)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "A live event launched last week and players are reporting that a reward is granted twice. What do you do in the first hour?" | CASE | [generic] | Clarify scope: how many players, whether it is still granting, and who owns the reward. Contain first, then tell design, engineering, QA and community, in that order of need. Say what you will not do until you know the cause. | The Outage Hour's live-incident tabletop. No claim about you. |
| A2 | "The fix is ready, but QA needs a day you do not have. What do you do?" | CASE | [generic] | Name what the day protects, and what the risk of skipping it is. Propose a decision order: the call, who is told, what goes out. Do not promise a patch you cannot verify. | JD's "manage the release checklist with QA"; V2 covers the same principle. |
| A3 | "Two titles' events collide in the same week. Plan it." | CASE | [generic] | Clarify fixed dates and team capacity. Structure: objective, segments, sequencing, metrics per title, two risks. Speak it in 90 seconds. | JD's "plan and run the live-events calendar for two of our mobile titles". |
| A4 | "What should a post-event review answer, and what would you need before calling an event a success?" | CASE | [generic] | Set the questions first: did it hit its target, what moved retention, what did it cost. Separate the event's effect from other changes, and name your weakest assumption. | JD's "own the post-event review and the KPIs it reports". Structure, not your history. |

Coverage: JD "plan and run" → A3, B4, E1. "Coordinate" → A2, B3, P1 (see note). "Own review and KPIs" → A4, B1, C2. "Manage the checklist with QA" → A2, C3.

**Skeptic (weight 4)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "The role owns the post-event review and the KPIs it reports. You presented retention numbers. What did you own in those reviews, and what did you only present?" | JD | [grounded] "Presented the monthly retention numbers to the studio head" | The highest-ROI rehearsal in this pack. Say what you presented, to whom, and how often, in those words. Answer slot: if you defined the KPIs or ran a review after an event, say which and how; if you presented numbers others defined, say that plainly and say how you would own them here. Hold through two follow-ups by returning to what you presented. | F3, the "own" against "presented" gap. Deepest rehearsal because it arrives in some form. |
| B2 | "Have you worked on a game with in-app purchases? How would you plan an event on one?" | EXP | [grounded] "never worked on a game with in-app purchases" | Say it: "I have never worked on a game with in-app purchases." Then how you would learn it, as a plan. Then one thing you would want to know about the purchase side of an event. | Not a JD requirement, so this probe comes from your own gap. |
| B3 | "You haven't led a team, and this role coordinates four. Why would that work?" | JD | [grounded] "Never led a team" | Say it: "I haven't led a team." Then the coordination answer slot: name a time you got people outside your own team to move on something, what they needed, and what you did. If none comes to mind, say so and describe how you would run it. Do not claim leadership. | F2 has no evidence; "coordinate" is the JD's raising source. |
| B4 | "Your background is one title. Why would a two-title calendar work for you?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say the quote's scope: one title, two years, weekly. Answer slot: if you have planned across more than one title, say how; if not, say so and say how you would sequence two. | F1, transferability; "two of our mobile titles" is the raising source. |

Coverage: "Comfortable with retention metrics" → B1, C1, C2. "Clear written communication" → none, and why: the Outage Hour is spoken; the only written evidence is C3.

**Values (weight 3)**. Values published: Players Before Plans (when the calendar and the players disagree, the players win), Ship the Patch Not the Promise (announce what is built, not what is hoped), Leave the Build Greener (every release leaves the codebase and the checklist better than it found them).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time the calendar and the players disagreed." | VAL | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Open prompt: pick a time the calendar and players pulled apart. Your material carries no such story. If none comes to mind, say so plainly, then give the nearest thing: how you handled a drop you would have changed. | Players Before Plans. Honest branch: no story in the material. |
| V2 | "Tell me about a time you announced something before it was built." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Open prompt. The checklist is the nearest evidence that you gate what ships. If no such time comes to mind, say so, then describe how the checklist stops a promise from shipping. | Ship the Patch Not the Promise. Honest branch: no story in the material. |
| V3 | "What did you leave better than you found it?" | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Open prompt. Say what the checklist changed, only if you can name it. If not, say so and describe what you would leave better. | Leave the Build Greener. Honest branch: the checklist is in use, but "better than it found" is not in the material. |

**Prober (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me how the retention numbers you presented were put together." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you set the definition or the cohort cut, say which and why; if someone else set them, say who and what you would check first. Never describe a method you cannot repeat. | F7; premised only on the quote. |
| C2 | "Which assumption behind those numbers would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | The weakest-assumption move, in your own words, before they ask. If you do not know, say so plainly. No figure was given, so this is the move itself. | Prober stem; F7. |
| C3 | "What is in the release checklist you wrote, and what would you change now?" | JD | [grounded] "Wrote the release checklist our QA team still uses" | Describe its structure and who uses it. If you would change something, say what and why. Do not say it caught anything unless you can name it. | F4; Tobias's QA background makes this likely. |

**Pressure (weight 1)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why hire an associate producer to run two titles?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio" | Pause, restate, then answer in three beats from your quotes: four years, the weekly calendar, the checklist. Hold the first claim through two follow-ups. Concede the one-title gap, once, specifically. | F5; pressure register. |

**Conversational (weight 2)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio"; "I ran the weekly content-drop calendar for our main title for the last two years"; "Wrote the release checklist our QA team still uses"; "Presented the monthly retention numbers to the studio head" | 90 seconds in those four beats, in that order, in your words. Stop after the last one. | Casual, but scored. The arc states only what the quotes state. |
| E2 | "What are you playing right now, and what would you change about its live events?" | JD | [generic] | Name a title you actually play and what you see from outside: cadence and rewards. Say when you cannot see the internals. No claim to insider knowledge. | Casual question about the live-events requirement. |

## 7. Reverse questions
Each has a "why it lands."
1. "What does a good post-event review look like here, and who writes it?" Lands because it asks how "own" works in practice.
2. "Which two titles are on the calendar, and where is each in its live cycle?" Lands because it shows you want the real calendar.
3. "You came to live ops from QA. What from that work does the producing side use most?" Lands because it asks about his path (public talk and background), not an interrogation.
4. "How are the KPIs for this role set: by the producer, or handed down?" Lands because it tests the "own" wording.
5. "Do these titles use in-app purchases, and how does that change event planning?" Lands because it turns B2 into a question you asked.

## 8. Values cheat sheet
Summarised in V1 to V3 above. Each value maps to a story only where one of your quotes carries it; otherwise the honest branch is written in.

## 9. Sources
- **Provided:** the JD text, and your background message.
- **Research tier: L1.** Searches: 3 of 6. Fetches: 2 of 2.

| Target | Status | What it moved |
|---|---|---|
| 1. Saltmarsh values | yes | Three values by name and meaning: Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener. Section 8 and V1 to V3. |
| 2. Saltmarsh interview process | yes | Outage Hour format (60 minutes, live-incident tabletop, values conversation, no take-home). Round type and A1 to A4. |
| 3. Saltmarsh strategy / news | skipped | Budget went to targets 1, 2, 4; the pack names no current strategy, so no CO questions. |
| 4. Tobias Wrenfield | yes | Head of Live Operations; previously QA lead at a console studio; GDC 2026 talk "Patch Notes Are a Promise". Interviewer read, C3, reverse question 3. |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot. |

- Queries sent: "Saltmarsh Games mobile studio values" (returned saltmarshgames.com/values); "Saltmarsh Games interview process live operations producer" (returned saltmarshgames.com/careers/interviewing); "Tobias Wrenfield Head of Live Operations Saltmarsh Games" (returned a GDC 2026 talk page). Fetched both Saltmarsh pages. The GDC page was not fetched; its summary comes from the search snippet.

## 10. Upgrade menu
- Confirm Tobias is the hiring manager and whether the recruiter sent focus areas → confirms the round's weights.
- A concrete example of a cross-team update (design, art, engineering or community) → upgrades F2 and B3 from discovery.
- A story for each value, from your own work → upgrades V1 to V3 from honest branch to story.
- The retention definition you used, if you can share it → unlocks defend-the-number slots in C1 and C2.
- Your live-service evidence, if any → upgrades F5.
