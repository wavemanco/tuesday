# Interview pack: Senior Partnerships Manager, Kelverton Rail (second round, panel)

Panel: Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). 60 minutes: a 15-minute spoken POV, then Q&A. Ross will push on commercials.

Built on: your message and the recruiter's email as you quoted it. No JD, no CV text, no market report and no web research (search was refused in this session).

## How to use

Personas are how a question will be asked. Types are what it scores: **CASE** (live problem), **EXP** (your past and its numbers), **JD** (the listed job), **CO** (company and market), **VAL** (values; none detected here). Guidance is scaffolding, not a script. Say it in your own words.

## Prep triage (4 hours)

1. **POV script, about 90 min.** Pick the lead thesis in the graded deliverable below, write the 15 minutes as five beats, and rehearse aloud twice with a timer.
2. **Commercial defence, about 75 min.** Write the honest answer for B1, B2 and B4, and say B4's hold-then-concede out loud until it is boring.
3. **Deepa's rail gap, about 45 min.** A3 is the highest-ROI prep in this pack: the objection is the one most likely to be asked. Then A4 and A7.
4. **Journey arc, about 15 min.** A6, under 90 seconds.
5. **Reverse questions, about 15 min.** Pick three from the list below.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" — recruiter's email | "9 years in partnerships" — your message; "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | medium | [grounded] | transferability | Your material shows partnerships and an ISV channel, not operator partnerships. The words that stay: "I was running the ISV channel at a payments company, and took it from 6 partners to 40." Answer slot: which parts of that channel work would carry over to operators, and which would not. Say the ones you think would not, too. |
| F2 | "what it means for the operators themselves" — recruiter's email | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | medium | [grounded] | presentation | The quote already reaches the requirement in operator terms. Reword only: "Five years in transport consulting, on bus and light rail network planning." No added practice. |
| F3 | "Ross will push on commercials" — recruiter's email | "roughly £4M of influenced revenue" — your message; "never carried a direct quota, only influenced revenue" — your message | low | [grounded] | transferability | Influence is not a quota, and the bridge should not stretch. Words: "The number I can show is influenced revenue, about £4M, and I've never carried a direct quota." Answer slot: how you would take on a direct commercial target in your first year. |
| F4 | Rail-sector sales or partnering experience — [generic], no JD supplied | "Never sold into rail specifically" — your message | none | [grounded] | capability | A gap you stated. Words: "I've never sold into rail specifically." Then how you would learn the rail sales cycle, said as a plan, never as a past. |

Your material does not show a JD requirement list, so rows F1 to F4 use the recruiter's own words and one role-family requirement marked [generic]. The gate question is in the upgrade menu.

## Graded deliverable: the 15-minute POV

The recruiter's words: "present a short POV on where you'd take our operator partnerships over the next 18 months" and "Please land on what it means for the operators themselves." Both are announced, so the POV is scored.

**Grounded facts to build on:** F1 (channel scale, as influenced revenue), F2 (planning-side work), F4 (no rail sales, said plainly).

**Generic context, verify before you say it aloud:** UK rail is in structural reform. Government has moved to bring train operators under public control within a planned Great British Railways body, with contracts replacing franchises. That changes who the buyer is and what they measure. I could not check the current state this session.

**Thesis T1 (recommended lead): plan with the operator, not after it.** Partner where operators make timetable and engineering decisions, not only where they sign. Grounding: F2.
- Concession, mandatory: "I haven't sold into rail, so the planning-side entry point is a hypothesis. I'd test it in the first 90 days with operators who will talk to me."
- Differentiation: the consensus answer is more partners and co-selling. T1 says partners matter only where they change a planning decision.
- Anti-pick: "I wouldn't set partner count as the headline goal in rail." Say why, in terms of what the operator experiences.
- Operator benefit: fewer late or disrupted changes, confirmed with operators as their own measure.

**Thesis T2 (commercial close, for Ross): put an operator outcome on the partnership scorecard, with influenced revenue as the trailing number.** Grounding: F1, F3.
- Concession, mandatory: "Influenced revenue overstates what closes, and I've never carried a direct quota, so the operator measure is a hypothesis you can test."
- Differentiation: most candidates will report pipeline. Show what the operator would see.

**Suggested 15-minute shape:** problem from the planning side (2 min); T1 (4 min); what it means for operators, two outcomes and one measured (4 min); concession and first 90 days (3 min); the commercial hand-off to T2 (2 min).

**The consensus answer is not known here.** The strategy team's market report is not in this session. Its shortlist is what the panel will compare against. Differentiation is unfinished until its key points are in the session.

## Persona table

| Persona | Who | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | Deepa | Live operator problems; "what would you do first" | High: she is the hiring manager and the POV is her test of altitude | Clarify, then structure, then the operator outcome |
| Skeptic | Deepa | The rail gap, motivation, "why leave, why now" | Medium-high: payments to rail is the visible gap | Plain acknowledgment, then the bridge the material holds, then the ramp |
| Data-Driven Prober | Ross | Asks how £4M and 6 to 40 were counted | High: headline figures on the record, and Ross is named as the commercial pusher | Say how counted, or say you don't know, and name the weakest assumption first |
| Pressure | Ross | "Why should I believe you can be held to a quota?" | High: "Ross will push on commercials" is the recruiter's own warning | Hold the record, then concede the gap explicitly, then a plan |
| Conversational | Deepa | "Walk me through the journey" as an opener | Low to medium: a casual opener is still scored | A 90-second arc |
| Peer Evaluator | Ross | Seam with sales; who owns the operator relationship | Low to medium: a commercial director is peer-adjacent to partnerships | Propose seam principles, not a claimed answer |

## Question banks

Deepa: Case/Strategist (weight 4), then Skeptic (weight 3). Ross: Data-Driven Prober (weight 5), then Pressure (weight 4).

**Deepa**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Sketch what you would do with operators in your first 90 days." | CASE | [generic] | Clarify first: which operators, which contracts, what they already buy. Structure: listen to planners, map the three operators that matter, test one partnership motion, report back with an operator measure. Makes no claim about your past. | The live version of the POV's first 90 days; generic because no JD was supplied. |
| A2 | "An operator tells you their planners lose a day every time a timetable change lands late. What does your partnership do about it?" | CASE | [generic] | Diagnose before pitching: which step is late, who in the operator owns it, whether a partner is the fix or part of the problem. Measure it in the operator's terms. | Tests the "what it means for operators" close in a live form. |
| A3 | "You've never sold into rail. Why would an operator take advice from a partnerships lead with no rail sales?" | JD | [grounded] "Never sold into rail specifically" — your message; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | Plain acknowledgment: "I've never sold into rail specifically." Then the bridge your material carries: five years on bus and light rail network planning. Answer slot: if you have seen an operator choose a supplier or partner, say what they weighed; if not, say so and say how you would learn it in your first month. | F4 is the most predictable objection. Rehearse until the acknowledgment is calm and the plan is specific. |
| A4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" — your message | Name the rail sales cycle and the operator decision process as the part you'd learn first, in your own words, then your ramp as a plan. | Skeptic stem; a self-assessment the material supports. |
| A5 | "What would an operator's partnership look like at month 18 if you'd done the job well?" | CASE | [inferred] derived from the recruiter's close, "what it means for the operators themselves" — recruiter's email | Describe one operator outcome you'd measure before any revenue, and how you'd know it moved. Land it in the POV's close. | Asks the POV's last sentence again; answer it in the operator's terms. |
| A6 | "So — walk me through the journey." | EXP | [grounded] "9 years in partnerships" — your message; "Last 4 at a payments company running the ISV channel" — your message; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" — your message | A 90-second arc in your order: partnerships, then the payments channel, then transport consulting. Name only what the quotes state. | A casual opener that is scored; the arc is the first thing both interviewers hear. |
| A7 | "Why leave a payments company where the channel works?" | EXP | [grounded] "Last 4 at a payments company running the ISV channel" — your message | Answer slot: say why, in your own words. If the reason is the operator side of the market, say so and tie it to the transport quote, only if that is true. If the reason is something else, say that. | Motivation probe; "why now" is not in your material, so the answer is yours. |
| A8 | "What would you need from me in the first month?" | JD | [grounded] "Last 4 at a payments company running the ISV channel" — your message | Name what you would need: access to operator relationships, and the commercial rules. Name what you would bring: the ISV channel work you ran. | Peer-style reciprocity from the future manager. |

**Ross**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the £4M was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | Say how it was counted, in your own words, then name the assumption you would defend least before he does. Answer slot: if you know the attribution rule, say it; if you don't, say so and say who did. | A defend-the-number slot; the figure is on your record. |
| B2 | "Of the 40 partners, how many produced the £4M, and how do you know?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" — your message | Answer slot: give the split you can state. If you can't split it, say the figure is influenced, not closed, and how you'd split it next. | A denominator question on the partner count and the figure together. |
| B3 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" — your message | Name the assumption first, in your own words. If you don't know one, say so, and don't invent a defence. | Stem for the weakest-assumption move. |
| B4 | "You've never carried a direct quota. Why should I believe you can be held to one?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" — your message | Plain acknowledgment: "I've never carried a direct quota." Hold the influence record as it stands. Concede that a quota is a different discipline and say specifically what you'd do to take one on in your first 90 days. | Ross's push on commercials. Hold, then concede the gap. Do not fold on the record itself. |
| B5 | "Sixty seconds: why should I trust influenced revenue at all?" | EXP | [grounded] "roughly £4M of influenced revenue" — your message | Hold the scope: it is influenced, and it's a number you can explain. Concede it overstates a closed number. Say what you would track alongside it. | Stress stem; influence is the weakest point of the record. |
| B6 | "Operators run to government-set budgets and contracts. How does a partner's revenue fit inside that?" | CO | [generic] — and "Ross will push on commercials" — recruiter's email | Structure: where the operator's money comes from, who signs, and what you would need to learn before you forecast. A plan, not a claim. | Ross is testing whether you know the buyer's money. The fact is generic: verify it first. |
| B7 | "Walk me through a rail sales cycle, from first meeting to signed contract." | CASE | [grounded] "Never sold into rail specifically" — your message | Plain acknowledgment: "I've never sold into rail specifically." Answer slot: say what you know from the planning side about who decides, and that mapping the cycle is your first-month task. | A premised question on something you have not done; the honest answer is ready. |
| B8 | "How many of the 40 were active by the end, and how did you measure that?" | EXP | [grounded] "took it from 6 partners to 40" — your message | Answer slot: say what you tracked. If you did not track activity, say so and say what you would track first. | Partner count is a headline figure; activity is the next question. |

## Requirement coverage

| Requirement (source) | Covered by | Note |
|---|---|---|
| Operator partnerships over 18 months (recruiter) | A1, A5, POV | — |
| What it means for operators (recruiter) | A2, A5, B6, POV close | — |
| Commercials (recruiter, Ross) | B1 to B5, B8, A8 | — |
| Rail sales or partnering experience [generic] | A3, A4, B7 | — |
| Partnerships background (your message) | A6, A7, A8 | — |

No JD is supplied, so no JD requirement is covered by a JD-tagged question. The upgrade menu says what it would add.

**Count:** 16 banked questions (A1 to A8, B1 to B8). That is below the usual range of 18 to 26 because the panel's Q&A is about 45 minutes. Widen it if a JD arrives.

## Reverse questions

Each has a "why it lands."
1. **To Deepa:** "What would make you say in six months that this hire was the right call?" Lands by turning scoring into shared success criteria.
2. **To Deepa:** "Which operator partnerships work today, and what do they have in common?" Lands because it shows your POV is grounded in the existing book.
3. **To Deepa:** "What did you change in the partnerships function in your first year?" Lands as a peer question about her own path, without assuming one.
4. **To Ross:** "How is partnership revenue counted today, direct, influenced or both, and who sets the rule?" Lands on the commercial push and shows you care about the rule.
5. **To Ross:** "When an operator deal goes quiet, where does it usually stall: procurement, the planning team, or a change of ownership?" Lands because it asks about the buyer's real friction.
6. **To Ross (reciprocity):** "What would a new person do in their first month that would genuinely help your commercial team?" Lands as a peer question, not a pitch.

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| "I have sold into rail" or "I have rail sales experience" | F4, negative you stated | "I've never sold into rail specifically." Plain acknowledgment, no slot. |
| "I carried a quota" or "I owned a revenue target" | F3, negative you stated | "I've never carried a direct quota." |
| "I drove £4M of revenue" | Inflated form of F3 | "roughly £4M of influenced revenue", at its scope. Your material says influenced, not closed. |
| "I know how operators buy" or "I know operator procurement" | Inflated form of F2 | "bus and light rail network planning", at its scope. No claim about procurement. |
| "I built a 40-partner channel" | Inflated form of F1 | "took it from 6 partners to 40". |

## Sources

- **Provided documents:** your message (background, round description, the recruiter's email as you quoted it). Not provided: JD, CV text, the strategy team's market report.
- **Searches sent:** three, all refused by the host ("permission not granted"). (1) "Kelverton Rail scheduling software train operators" (2) "Great British Railways train operators contracts partnerships 2026" (3) "UK rail operators digital timetabling scheduling software procurement 2026". None returned results.
- **No dossier** was present.

**Research tier:** L1 attempted — searches 0 of 6 (three refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton values | unavailable | Refused. Would have moved nothing here: no values-style round is detected. |
| 2. Interview process, role family | unavailable | Refused. Would have set loop structure; the panel is already named. |
| 3. Strategy and recent news | unavailable | Refused (query 2). Would have moved the generic UK rail context in the POV and B6. |
| 4. Deepa and Ross, public footprint | unavailable | Not sent: no search was permitted. Would have moved the interviewer read and two reverse questions. |
| 5. Representative JD | unavailable | Refused (query 3 was about the market, not a JD). Would have turned the requirement rows into [inferred] JD rows. |

**Dropped sections:** grounding brief (no research), reading the interviewer (no public footprint), values cheat sheet (no values round), delivery coaching (no assessment).

## Upgrade menu

- **JD text** → F1 to F4 become JD-sourced requirements; A1 to A8 gain JD-tagged coverage; the [generic] row becomes [grounded].
- **Market report's key points** → the POV's differentiation is written against the consensus answer, not beside it.
- **Your account of how the £4M was counted** → B1 to B3 move from answer slots to quoted, rehearsable answers.
- **Web search permission** → the L1 research runs: current Kelverton and rail-reform sources, and a check on the generic context in the POV.
- **Interviewers' full names and public profiles (Deepa, Ross)** → the interviewer read and two tailored reverse questions.
- **Recruiter's prep email** → confirms whether the POV is scored on the same criteria as the Q&A.
