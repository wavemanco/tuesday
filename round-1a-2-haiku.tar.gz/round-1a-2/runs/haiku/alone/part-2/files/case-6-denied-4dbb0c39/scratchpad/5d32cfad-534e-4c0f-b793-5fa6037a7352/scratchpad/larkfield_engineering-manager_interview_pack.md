# Larkfield Systems: Engineering Manager interview prep pack

**Role:** Engineering Manager, Larkfield Systems (industrial IoT, ~600 people). Two squads on device-management services; delivery, hiring and growth for 11 engineers; partnering with hardware and product on the roadmap.
**Format:** Loop mode. Three sessions, shared fit snapshot, then one mini-pack per round.
**Round 1:** Tuesday, 45 min, hiring manager (Director of Engineering, your would-be boss).
**Round 2:** Thursday, 60 min, panel: two staff engineers and a product manager.
**Round 3:** Following Monday, 30 min, VP Engineering. The recruiter describes it as "values and leadership philosophy."
**Interviewer names:** none given, so there is no interviewer read and no interviewer-tailored weights.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script. Where your material does not carry an answer, the guidance gives an **answer slot**: it tells you the honest branch to take, in your own words.

- **VAL** — behavioral and values: does past behavior show the value or philosophy being asked about
- **EXP** — your experience, probed: does what you did survive scrutiny
- **JD** — the role's stated requirements, including the gaps
- **CO** — company knowledge: strategy, recent moves (none researched here, so CO questions are generic)
- **CASE** — a live problem from the role, reasoned aloud

Quotes in the Evidence and Provenance cells are your own sentences from this conversation, or the role summary and recruiter description you gave.

## Basis, research, and what is left out

- **Research:** web search was not permitted this session. The pack therefore rests on your message and the recruiter's description alone. Nothing about Larkfield's values, interview process, or strategy is in it. Every Larkfield-specific claim you will hear from the panel is something to learn live.
- **Sections not included:** prep triage (no prep time given), graded deliverables (none declared), grounding brief (no research), values cheat sheet (no research and no published values in hand), interviewer reading (no names), delivery coaching (no assessment provided).

## The fit snapshot

Shared across all three rounds. The Requirement column quotes the role summary you gave; the Evidence column quotes your own sentences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role summary | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material shows one team of six, not two squads. Say it at the quote's scope: three years as a team lead of six. Answer slot: if you have coordinated a second team, say how, in your own words; if you have not, say so plainly and stay with the team of six. |
| F2 | "own delivery, hiring and growth for 11 engineers" — role summary | "I run our hiring loop for backend roles — about 40 interviews last year" — your message | medium | [grounded] | none | Hiring is covered in the role's own terms: the loop, backend roles, about 40 interviews. Lead with the loop and the count rather than an adjective. The probe is what you decided inside the loop, so state only that. |
| F3 | "own delivery" — role summary | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | presentation | Your sentence already reaches delivery under roadmap pressure. Reword only that sentence: "I pushed a reliability quarter through against roadmap pressure, and on-call burden dropped 60% after." Add no practice, figure or event. The 60% is a limited measure: expect a probe on it. |
| F4 | "growth for 11 engineers" — role summary | none given | none | [grounded] | discovery | Your material does not show how you have grown engineers. Answer slot: name one engineer whose path you changed and what you did. If you cannot, say so plainly and say how you would approach growth across 11. |
| F5 | "partner with hardware and product on roadmap" — role summary | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | Plain acknowledgment, in your words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, stated as a plan, never as a past. Your product-side roadmap experience is F3's sentence, at its own scope. |
| F6 | [generic] Leading managers of leads, if the role includes them — not in your role summary | "never managed managers" — your message | none | [grounded] | capability | Plain acknowledgment: "I've never managed managers." The role summary does not say whether this role manages managers. Confirm it in the job description (see the questions at the end). |
| F7 | [generic] On-site, location or right-to-work requirement — not in your role summary | none given | none | [generic] | hard_gate | Your material does not establish whether this role has a location or on-site term you cannot meet. No bridge is written for it. It is asked once at the end of this message. |

**What the table shows, in analysis:** your material reaches the hiring requirement and the delivery requirement in role terms. It shows one team of six rather than two squads. It shows no growth evidence (F4), no hardware roadmap (F5), and no management of managers (F6). Those three are the places the three rounds will press.

## Prohibited claims

Built locally from the fit snapshot: the stretched wordings a pressured answer tends to reach for. No answer slot, hold, bridge or rationale in this pack asserts, softens or implies any of them.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned delivery across two squads" | Inflated form of F1 | The quote at its own scope: "3 as a team lead of 6." The limit is the pack's observation: your material shows one team of six. |
| "I ran hiring and growth for 11 engineers" | Inflated form of F2 and F4 | "I run our hiring loop for backend roles — about 40 interviews last year." Your material shows no growth and no 11. |
| "The reliability quarter caused the 60% drop" | Inflated form of F3: a sequence turned into a cause | "My team's on-call burden dropped 60% after I pushed a reliability quarter through." The sentence says after, not because. |
| "I've owned a hardware roadmap," or any hardware-partnering claim | Sourced entry: your own negative (F5) | "I've never owned a hardware-adjacent roadmap" as the plain acknowledgment. |
| "I've managed managers" | Sourced entry: your own negative (F6) | "I've never managed managers" as the plain acknowledgment. |

## Persona weights by round

Relationship priors set the starting weights (hiring manager: Case and Skeptic; panel: each member's top two; executive: Case and Pressure, with values rounds led by Values/Behavioral). No interviewer profiles exist, so there are no interviewer-signal adjustments. The loop is established by your message and the recruiter's words, so the rounds stand as named.

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 Director | Skeptic | Probes the gaps: hardware, managers, growth | High. A hiring manager buys capability and derisks gaps. F5, F6 and F4 are where the material is thin. | Rehearse A3 until it is boring. Hold a position through two follow-ups before any concession. |
| 1 Director | Case / Strategist | A live roadmap problem | High. The summary's "partner with hardware and product" is the Director's own roadmap. | Clarify before structuring. Name the constraint first. |
| 1 Director | Data-Driven Prober | Asks how the 60% and the 40 were counted | Medium. Two figures are quoted in your material. | Know what you can and cannot say about each count. |
| 1 Director | Pressure | Time-boxed challenge on "why you" | Medium-low, but scored. | Pause, restate the question, anchor in what you said. |
| 2 Staff engineers | Data-Driven Prober | Denominators and measures behind the figures | High. Technical depth verification is their job. | Name the weakest assumption before they do. |
| 2 Staff engineers | Pressure | "How much of that was actually you?" | High. | Split the credit in your own verbs; concede only what you do not know. |
| 2 Product manager | Peer Evaluator | Seams with hardware and engineering; what you need from them | High. The PM prices your cost to their load. | Reciprocity framing. Propose seam principles, not claims about their teams. |
| 2 Product manager | Conversational | A casual opener | Medium. Casual questions are scored. | One 90-second arc, no more. |
| 3 VP | Values / Behavioral | Scenario probes, STAR-shaped stories | High. The recruiter's words name this round. | Map each story to a quote where one exists, a selection scaffold where none does. |
| 3 VP | Pressure | Composure on a short motivation question | Medium. 30 minutes is short; composure is scored. | Pause, restate, anchor. Hold the position. |
| 3 VP | Case / Strategist | A trade-off between reliability and a hardware launch | Medium. | Structure the trade-off aloud. |
| 3 VP | Conversational | A small-talk close | Low. | Never answer "I think you've covered everything" to the reverse-question slot. |

## Question banks

Depth follows weight: the top persona gets the most questions, mid-weight personas get fewer, and low-weight personas get the fewest. The sessions total 24 questions.

### Round 1: Director of Engineering (hiring manager), 45 min

**Highest-ROI prep in the pack: A3.** The Director's roadmap is hardware-adjacent, your material has no hardware roadmap, and this is the most likely objection in the whole loop.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | A 90-second arc in those beats: nine years in engineering, three leading a team of six, now at a payments company. Then the answer slot: say, in your own words, why this role. Do not front the reliability story; let them ask for it. | An opener is scored for economy and interest. F1 and the payments-company sentence are the only biography in your material. |
| A2 | "Walk me through how you run the hiring loop for backend roles." | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" — your message | Story-mapped on F2: the loop, backend roles, the about-40 interviews, in those words. Answer slot: name one decision you made inside the loop yourself. If you ran a process others set, say so and describe your part. | F2 is your strongest direct evidence for the hiring requirement. The probe is what you decided, not what the process was. |
| A3 | "The role partners with hardware and product on the roadmap. What have you done with a hardware roadmap?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap" — your message; [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message | Lead with the plain acknowledgment: "I've never owned a hardware-adjacent roadmap." Then the one roadmap story you have, at its own scope: "I pushed a reliability quarter through against roadmap pressure." Then a plan, stated as a plan: what you would learn first from the hardware team. Hold through two follow-ups by returning to the quote, never by adding to it. Concede specifically: "No hardware roadmap. Here is what I'd do in the first thirty days." | F5 is a capability gap you stated yourself, so the only honest answer is the negative plus a plan. This is the objection the Director is most likely to press. |
| A4 | "The role is to lead two squads and own delivery, hiring and growth for 11 engineers. Which of those have you done at that size?" | JD | [grounded] "3 as a team lead of 6" — your message; [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" — your message; [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message | Take the requirements in order, each in the quote's own terms. Two squads: three years as a team lead of six, which is one team. Delivery: the reliability quarter. Hiring: the loop and the about-40 interviews. Growth has no quote: answer slot, name one engineer whose path you changed, or say plainly that you have not, and say how you would approach growth across 11. | F1, F2, F3 and F4 each reach a different scope. The question tests whether you can say which of them you have done, at what size. |
| A5 | "I don't see managers of managers in your background. Does this role need you to do that, and how would you handle it?" | JD | [grounded] "I've never managed managers" — your message; [grounded] "3 as a team lead of 6" — your message | Plain acknowledgment first: "I've never managed managers." Then the nearest thing your material carries, at its scope: three years as a team lead of six. Then a plan for leading leads, if the role has them. If it does not, say so and ask the Director to confirm. Hold through two follow-ups. | F6 is a negative you stated, so the Skeptic can test whether you state it without folding. The question's second clause makes the Director say whether the role has this layer. |
| A6 | "Sixty seconds: why should we hire you over someone who has run a hardware roadmap?" | JD | [grounded] "I've never owned a hardware-adjacent roadmap" — your message; [grounded] "3 as a team lead of 6" — your message | Pause and restate: "You're asking why me over someone who has run a hardware roadmap." Then what you bring from the quotes, and the plain acknowledgment in the same breath. Hold the position through two follow-ups: do not fold into "I'd learn fast." The case is what you have, not what you lack. | A Pressure stem on F5. The comparison is hypothetical, so the question presupposes only your own negative. |
| A7 | "How was that 60% counted, and how much of it was you?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | Defend-the-number slots: how the 60% was counted, in your words; what it is sensitive to; the assumption you would defend least; which part was yours. Answer slot: if you know the counting method, say it; if you do not, say so, and say what you would check first. Do not explain how the figure was reached: a method you cannot repeat under a second question is worse than none. | The 60% is your most quoted result. Your sentence says "after," which is a sequence, not a cause. |
| A8 | "Product wants a feature that adds load to the devices, and the hardware team says the firmware cannot take it this quarter. How do you decide?" | CASE | [generic] pattern for a roadmap trade-off; the raising source is the role summary's "partner with hardware and product on roadmap" | Structure aloud: clarify what the feature must do and what the firmware constraint is; name who is affected; options (slip, narrow scope, change the rollout); what you would watch; what you would ask hardware first. Say the framework once, then reason. No claim about your past. | The Director's roadmap is the role's hardest test, and your material is silent on hardware. This measures reasoning, not history. |

### Round 2: panel, two staff engineers and a product manager, 60 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "So, walk me through the journey." | EXP | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company" — your message | The same 90-second arc as A1, with the same beats. Stop there; let the panel pull the rest. | The PM's opener is a scored question in a casual register. Low weight means one arc is enough. |
| B2 | "Which on-call measure moved, and over what window?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" — your message | Defend-the-number, in your words: the measure, the window, the assumption you would defend least, and which part was yours. Answer slot: if you do not know the window, say so and say what you would check first. | Staff engineers verify depth. The on-call measure and window are the questions behind the 60%. |
| B3 | "How much of that drop was actually you?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message; [grounded] "My team's on-call burden dropped" — your message | Your sentence already splits the credit: you pushed the quarter through, and the drop is your team's result. Say that split once. Hold through two follow-ups. Answer slot: if other changes contributed, name them; if you do not know, say you cannot rule them out. | A Pressure stem on F3. The test is whether you hold a credit split under challenge without inflating it. |
| B4 | "Hardware and product disagree on a roadmap item. Where is the seam, and what happens when we disagree?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message | Reciprocity framing. Propose seam principles, not claims about how those teams work. Use your sentence at its own scope: the one time you held a position against roadmap pressure. Answer slot: if you have taken a position against product, tell it in your words; if you have not, describe the principle you would use and say plainly that you have not run that seam. | A Peer Evaluator probe on partnership, which is the role summary's "partner with hardware and product on roadmap." Peers test seams before they test answers. |
| B5 | "Device-management services are in the field. What do you need to know before you change one?" | CASE | [generic] pattern for a device-management service; the raising source is the role summary's "device-management services" | Structure: what runs where; what breaks in the field and how you would find out; rollout and rollback; who you would need to ask. Say what you would check first, not what you know about their system. No claim about your past. | Tests technical approach to the service the role owns. Generic, because your material has no device-management experience. |
| B6 | "You said about 40 interviews last year. What does that count?" | EXP | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" — your message | Defend-the-number: say, in your words, what the 40 counts. Answer slot: if you do not know exactly, say so. Name the assumption you would defend least, in your own words. Which part was yours: the loop you run, not the whole hiring process. | Staff engineers probe denominators. A count is a figure, so the defend-the-number slots apply. |
| B7 | "What do you need from product in your first month, and what could you give back?" | JD | [generic] reciprocity pattern for a peer relationship | Name what you need from product, then what you would bring to their team, stated as a plan rather than a past. No claim about your history. | A PM's load question. Peers price what a hire costs their work, so the reciprocity answer is scored. |
| B8 | "Give me a time you were wrong about a technical call." | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message | Open prompt. Pick a time you were wrong, with a named stake and what changed. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | A Pressure stem. The honest branch matters more than the story: the panel checks whether you can say "I was wrong" without theatre. |

### Round 3: VP Engineering, values and leadership philosophy, 30 min

No published values are in hand, so the VAL questions draw on the recruiter's description ("values and leadership philosophy") as the raising source. Where a question needs a value's name, the pack does not supply one.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "In a sentence or two, what is your leadership philosophy, and where did it come from?" | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message | Scaffold: state a philosophy you would defend with one decision from your material. The decision you can point to is the reliability quarter. If you cannot tie the sentence to a decision, say so, then give the decision you can point to. Where it came from: say it in your own words; the pack holds nothing on that. | The recruiter's "leadership philosophy" is a raising source. A VP round tests whether a philosophy is a belief you have acted on. |
| C2 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message | Map: the stake is roadmap pressure; your action is pushing the quarter through; the result is the on-call drop. Answer slot: if leadership pushed back, say what they said; if the reliability quarter was not an unpopular truth to them, say so plainly. Do not add stakes or reactions. | A Values/Behavioral stem. Your only evidence for "unpopular" is the roadmap-pressure sentence, and the VP will test whether the ending is real. |
| C3 | "When did you put a customer ahead of an internal metric?" | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" — your message | Honest branch first: your material shows no customer story. If you have one, name the metric it beat and the outcome. If you do not, say so plainly, then use the reliability quarter only as the roadmap-versus-reliability trade it was, without calling it a customer story. | A values stem. The material does not carry a customer story, so the pack does not supply one. |
| C4 | "The role includes growth for 11 engineers. Tell me about an engineer whose path you changed." | VAL | [grounded] "own delivery, hiring and growth for 11 engineers" — role summary | Answer slot: name one engineer whose path you changed and what you did, in your own words. If you cannot, say so plainly, then say how you would approach growth for 11 engineers in your first six months. | Growth has no quote in your material (F4). The VP will probe it. The question's raising source is the role summary, not a claim about your history. |
| C5 | "A VP asks you to cut reliability work to hit a hardware launch. What do you say?" | CASE | [generic] pattern for a reliability trade-off; the raising source is the role summary's "partner with hardware and product on roadmap" | Structure: what the launch is; what the reliability cost is; who decides; what you would put in writing. State the principle and what you would test. Do not play a position you have not held. No claim about your past. | Leadership philosophy under a live trade-off. Your material carries no hardware case, so the answer is reasoning. |
| C6 | "Sixty seconds: why this role, and why now?" | JD | [grounded] "currently at a payments company" — your message | Answer slot: say why this role, in your own words. The pack holds no reason of yours. Pause, restate, then anchor in what you have said: nine years, one team of six, a payments company. Hold: do not pivot to a hardware roadmap you have not owned. | A short motivation question from the VP, scored as composure. Your material has no reason for the move, so the pack leaves it to you. |
| C7 | "Tell me about a hire you got wrong." | VAL | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year" — your message | Scaffold: pick a hire that did not work out and what your loop caught or missed. Name what you would change in the loop, in your own words. If you have no such hire, say so plainly and give the nearest decision you would now make differently. | Hiring is a role-summary requirement. The loop sentence is the only hiring evidence you have given, so this rehearses it from the other side. |
| C8 | "What is the biggest risk to engineering here over the next year?" | CO | [generic] pattern for device-management at fleet scale; no claim about Larkfield | Say what you would test first, not what you believe about Larkfield. You have not seen their roadmap or strategy, so say that. Name one risk common to device-management services, labeled as a pattern, and what you would ask to check it. | CO questions need research, and none ran. Without it, this question tests judgment and honesty about what you do not know. |

### Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| "Lead two squads building device-management services" (role summary) | A4, B5, A8 |
| "own delivery" (role summary) | A4, B2, B3 |
| "hiring" (role summary) | A2, B6, C7 |
| "growth for 11 engineers" (role summary) | A4, C4 (answer slots; no quote) |
| "partner with hardware and product on roadmap" (role summary) | A3, A6, A8, B4, C5 |
| Managers of managers ([generic]; not in the summary) | A5 |
| On-site or location term ([generic]; gate) | None in the banks. Asked once in the message, not drilled. |
| "values and leadership philosophy" (recruiter) | C1, C2, C3, C7 |

## Reverse questions

Each one is asked of the interviewer. Each has a "why it lands."

**Round 1, Director of Engineering.** No profile exists, so none of these ties to the Director's own path. Adding their name would enable one.

1. "What would the first 90 days need to show for the hardware partnership to be going well?" — It turns A3 into a shared definition of success, and shows you think in outcomes.
2. "Which of the two squads carries the most roadmap pressure right now, and what is it?" — It shows you are asking where the pressure falls, and tests whether the roadmap is clear.
3. "How is the hiring plan for the 11 engineers shaped over the next two quarters?" — It connects to F2 and to the loop you already run.
4. "Which hardware and product people would I work with most, and what do they need from engineering?" — It asks about partner scope directly.
5. "What would you need to see in six months to say this was the right hire?" — It asks for the success test in the Director's own words.

**Round 2, panel.**

1. (Product manager, peer reciprocity) "What could a new person do in their first month that would genuinely help your team?" — A peer prices your cost to their load; this shows you are doing the same.
2. (Staff engineer) "Which part of the device-management services carries the most on-call load today?" — It lets you test the 60% story against their current picture.
3. (Staff engineer) "Which decisions in the service are hardest to reverse?" — It shows the architecture-level thinking the panel scores.
4. (Product manager) "How do product and engineering agree which reliability work counts on the roadmap?" — It is a seam question, and it shows you expect one.
5. (Staff engineer) "What would you have wanted the team to do differently in its last large release?" — It invites an honest account of the team's own risk.

**Round 3, VP Engineering.**

1. "What does a good leadership decision look like here, one you would want repeated?" — It asks for the values in the VP's own terms.
2. "Where has the team's stated approach cost something in practice?" — Candor is a values signal; it lets you hear where the hard truth lands.
3. "How do you want leads to trade reliability against the roadmap when you are not in the room?" — It asks the philosophy question back, from the VP's side.
4. "What would you keep from how engineering leadership works today, and what would you change?" — It shows judgment about inherited practice.
5. "What would the first 90 days need to change for the team?" — It is a leadership question, and it closes on the work rather than on you.

## Sources

**Provided documents:** your message (role summary, your background, the three round descriptions, your two negatives); the recruiter's description of the final round as "values and leadership philosophy."

**Searches sent (all refused, so no results came back):**
- "Larkfield Systems values": refused
- "Larkfield Systems interview process engineering manager": refused
- "Larkfield Systems industrial IoT strategy news": refused

**Research tier:** L1, searches 0 of 6 (all refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet (section 10 of the template) and mapped VAL stories in C1 to C4 and C7. Those run as selection scaffolds instead. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop structure. Your message and the recruiter's words already establish the three rounds, so the weights stand. |
| 3. Larkfield Systems strategy and recent news | unavailable | CO grounding. C8 stays generic. |
| 4. Interviewer name and company | n/a | No interviewer name was given. |
| 5. Representative engineering manager JD | unavailable | A representative posting would have given the requirements a source beyond the role summary (F4 and F6 would be sourced). Not sent, since search was refused for the session. |

## Upgrade menu

- **Full job description text** → F1 to F4 get source-quoted requirements; the requirement coverage table checks against the full list, not the summary.
- **Whether the role has a location, on-site term or right-to-work condition** → F7 settles: cleared, or planned for.
- **The recruiter's note on what each round will assess, and any declared deliverable** → the round weights and any build section.
- **Larkfield's published values or leadership principles, pasted** → the values cheat sheet, and mapped stories in C1 to C4 and C7 in place of selection scaffolds.
- **Permission for web search** → a targeted research pass: values, the loop's structure, and recent strategy. That would ground C8 and let CO questions use Larkfield's actual positions. A deeper research pass is also available once search is permitted: up to 6 more searches and 2 more fetches, several more minutes. Ask if you want it.
- **Interviewer names** (the Director, the two staff engineers, the product manager, the VP) → an interviewer read, persona weights from their public footprint, and tailored reverse questions.
- **How the 60% was counted, and over what window** → A7 and B2 become rehearsable with a counting method you can repeat, not slot form.
- **Your team's structure below the six: any leads, any managers** → F6 and A5 settle.
- **A `tuesday-dossier.md` file, if you have one** → verified evidence and a prohibited-claims guardrail for every guidance cell, so the pack would no longer rely on this message alone.
