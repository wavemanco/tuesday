# Kelverton Rail: Senior Partnerships Manager, second-round panel prep

Panel (Tuesday, 60 minutes): Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). First 15 minutes: a spoken point of view on operator partnerships over the next 18 months, no slides, landing on what it means for the operators. The rest is Q&A, with Ross pressing on commercials.

Research: web search was refused in this session, so nothing below about Kelverton itself is researched. Company facts are absent, and anything generic is labelled `[generic]`.

## How to use + type key

Personas are how a question is asked. Types are what it scores:

- **VAL**: behavioural and values alignment. Not used here: no values were published or quoted.
- **EXP**: deep-dive on your own experience and what you actually did.
- **JD**: the role's stated requirements, including the gaps.
- **CO**: company and strategy knowledge. Thin here, because research did not run.
- **CASE**: a live problem from the role, scored on structure.

Guidance is scaffolding, not a script. Rehearse the beats, never a memorised paragraph.

## Prep triage (4 hours)

1. **POV build, then two timed runs aloud (80 min).** Build section and B1, B3. Stop at 15 minutes each time.
2. **Ross's commercial pressure (75 min).** A1 to A5. Say each answer aloud, then have someone push the weakest assumption.
3. **Deepa's skeptic and case (45 min).** B2 first, since it is the highest-ROI rehearsal, then B4, B5.
4. **Reverse questions and the 90-second arc (20 min).** C1 and the reverse questions.
5. **Final read against the quotes (20 min).** Check that every sentence you plan to say traces to a quote below.

Everything else is insurance.

## Fit snapshot

Requirements are the recruiter's own words, as quoted in your message, or role-family prose with no source. No JD was supplied.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter, as quoted in your message) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | transferability | Your material says five years of bus and light rail network planning, and that you know the operator world "from the other side". It does not say you advised on or carried operators' commercial decisions, so the bridge stays at the planning work. Answer slot: if any of that work touched an operator's commercial decision, say which and what you did, in your own words; if it did not, say so plainly. |
| F2 | grow a partner base and its revenue (role-family, unquoted) | "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." (your message) | medium | [grounded] | transferability | Say it at its own scope: a payments ISV channel, six partners to forty, about £4M of influenced revenue. The bridge to operators is a channel-growth record, not a rail-partner one. Answer slot: if you can say what you did to take the channel from six partners to forty, say it in your own words; if you cannot say how the figure was counted, say that plainly. |
| F3 | carry commercial accountability for operator revenue (role-family, unquoted) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | Words you have given: "I've never carried a direct quota." Then the plan, said as a plan: which number you would ask to be measured on first, and why. |
| F4 | sell into rail operators (role-family, unquoted) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | Words you have given: "I haven't sold into rail specifically." Then how you would learn operator buying, said as a plan and never as a past. |
| F5 | pipeline math for operator deals (role-family, unquoted) | none given | none | [generic] | discovery | Answer slot: if you have built or used a pipeline model, say which stages you counted and what you assumed; if you have not, say so, and say what you would build first. |
| F6 | margin and pricing for operator contracts (role-family, unquoted) | none given | none | [generic] | discovery | Answer slot: if you have set or argued a price or a margin, say what it was and what you knew at the time; if you have not, say so, and say how you would test it with an operator. |

Gate rows: none established. Your material says nothing about location, office days or right to work, and the recruiter's note does not name them. See the upgrade menu.

Gap types here follow the routing rule: F1 and F2 are transferability because a quote carries adjacent work that does not reach operator commercial work; F3 and F4 are capability because you stated the absence; F5 and F6 are discovery because the material is silent.

## Graded deliverable: the 15-minute point of view

Announced by the recruiter. Two things must be in it: a point of view on operator partnerships over 18 months, and what it means for the operators.

**Facts to build on:** F1, "bus and light rail network planning". You can speak from that planning work at its own scope. You cannot speak to the operators' buying process, which is F4.

**Talk track:**

- **0:00 to 1:30, the operator's problem, in operator terms.** `[generic]` Start from what an operator has to get right every day, not from your product.
- **1:30 to 6:00, thesis one: start where the timetable breaks.** Partnership effort goes first to disruption recovery, where a schedule change costs most. Grounded on F1 at its scope. Mandatory concession: the operator's planning team may already own recovery, and then the partnership is a feature rather than a platform.
- **6:00 to 10:00, thesis two: share planning data under agreed terms.** Partner and operator plan from one data set, under terms both sides sign. Mandatory concession: data sharing is slow and may take most of the 18 months.
- **10:00 to 13:00, the commercial shape: pay on what the operator can measure.** Mandatory concession: you carry margin risk, and the numbers are not yet built. If you have not built them, say so.
- **13:00 to 15:00, what it means for the operators.** Close on a change in the operator's day, in their words. This is the line the recruiter asked for: "Please land on what it means for the operators themselves."

**Differentiation.** The consensus answer is a bigger partner programme and more integrations. Say no to partner count as the 18-month goal: your own record is a channel count (F2), and an operator's buying is not a channel. Name that choice aloud.

## Persona table

Panel members get personas by their role, from relationship priors. No interviewer profile was available, so the interviewer read is dropped.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Pressure (Ross) | Interrupts, time-boxes, asks "so what did you own?" | High. Recruiter says Ross will "push on commercials", and a commercial director presses hardest where influenced revenue meets owned revenue (F3) | Hold through two follow-ups, then concede the specific gap |
| Data-Driven Prober (Ross) | Asks how the £4M was counted, and what assumption you would defend least | High. The £4M figure raises the defend-the-number slots (F2, A1) | Name the weakest assumption before he does |
| Case / Strategist (Deepa) | The POV itself, then a live problem on operator buying | High. She is the hiring manager, and the POV is her first test of thinking | Clarify, structure, then state the thesis |
| Skeptic (Deepa) | Rail sales and quota gaps (F3, F4) | High. These are the two gaps the material is clearest about | Rehearse B2 until it is plain; bridge only with the planning work |
| Conversational / rapport | Opening walk-through, closing "anything you want to ask?" | Medium. Casual questions still score | Use the 90-second arc; never answer a reverse-question slot with "I think you've covered everything" |
| Peer Evaluator | Seam questions with adjacent teams | Low. No peer is on the panel; this weight tilts up if Ross is read as a peer on commercial work | Not weighted |
| Values / Behavioral | Scenario probes on published values | Not weighted. No values were published or quoted, and research did not run | Not weighted |

Depth follows weight: Pressure and Prober get five questions, Case and Skeptic five, Conversational three.

## Question banks

### Ross (Pressure and Prober), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Say how it was counted, in your own words. Name the assumption behind the figure you would defend least before he asks. Answer slot: if you can say which part was yours (the partners you recruited, the deals you were in, the influence you can show), say so; if you cannot say how it was counted, say that plainly. Hold "influenced, not owned" through the first two follow-ups by returning to the figure | The £4M is the sentence Ross will test first. F2 is the evidence; the defend-the-number slots apply |
| A2 | "You've never carried a quota. Why should we trust you with our number?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | Say "I've never carried a direct quota." Then the number you would ask to be measured on first, as a plan. Hold through two follow-ups, then concede the gap specifically. Do not describe influenced revenue as owned | F3 is a stated absence. The hold-then-concede structure is the pressure test |
| A3 | "An operator says your platform only pays back after two years on their timetable. How do you price it?" | CASE | [generic] | Clarify the operator's budget cycle and what they count as value. Structure price, term and services. Name the margin you would protect and the one you would give up. Say the margin logic aloud. Makes no claim about your past | F6 is silent on pricing; this case rehearses the reasoning without inventing a deal |
| A4 | "Talk me through a pipeline of twelve operator deals in a year. Which stage do you trust least?" | CASE | [generic] | Name the stages, and name each conversion rate as an assumption. Weakest-assumption move: state the stage you trust least, and why. Answer slot: if you have built a pipeline model, say which stages you counted; if you have not, say so | F5 is silent on pipeline math; the question tests whether you can separate a stage from its assumption |
| A5 | "Why would an operator pay for a partnership at all, when they already run planning in-house?" | CO | [generic] | Name the operator's cost of disruption and the partner's role in it, in their terms. Not researched, so the cost claims stay generic: say so if asked for a number | Ross tests commercial altitude. CO without research is generic, and the pack says so |

### Deepa (Case and Skeptic), weight 5

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where do you want operators to be in eighteen months that they can't be today?" | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" and "Please land on what it means for the operators themselves." | Start at one operator outcome, one operator type and one mechanism. Land on what changes for the operator in their words. This is the POV's close, so rehearse it as the POV, not alone | The recruiter's own wording is the raising source; this question is the POV's opening probe |
| B2 | "You've never sold into rail. Why would an operator take a call from you?" | JD | [grounded] "Never sold into rail specifically" and "bus and light rail network planning" | Highest-ROI rehearsal in this pack. Words: "I haven't sold into rail specifically." Then what you bring, at its own scope: the network planning work. Hold through two follow-ups by returning to the planning work, not to sales. Concede specifically: the buying process is the part you would learn first, and you would say so. Answer slot: what you would do in the first 90 days to learn operator buying | F4 is the most predictable objection to this candidate, and F1 is the only thing that answers it |
| B3 | "What did you produce in the network planning work, and who used it?" | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | Name the outputs in your own words. If your role was analysis inside a team, say that. Do not name a product or client you were not asked about | Tests whether F1's planning work was your output or a team's; the honest answer is the bridge |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "never carried a direct quota, only influenced revenue" and "Never sold into rail specifically" | Name rail buying and the owned-number side, plainly. Then the ramp plan: what you would learn first and from whom. Do not promise results | The Skeptic stem. F3 and F4 are the honest answer, and the ramp plan is the rehearsal |
| B5 | "Tell me about a partnership that didn't work. What did you do?" | EXP | [generic] | Selection scaffold: pick a partnership that stalled. It needs a named stake, a moment you had to decide, and what you did about it. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, which is F2's channel | An open prompt. The theme comes from the persona stem, not from any fact about you |

### Conversational / rapport, weight 3

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" and "9 years in partnerships, last 4 at a payments company running the ISV channel — took it from 6 partners to 40, roughly £4M of influenced revenue." | Ninety-second arc, in order: the planning work, then the channel. Each clause at its quoted scope. Do not add a client, a deal or an outcome the quotes do not carry | The biography opener is scored. F1 and F2 are the arc |
| C2 | "Why operators, and why now?" | EXP | [generic] | Selection scaffold: say why operators in your own words. If you have not said it aloud before, rehearse it once in the drill. If no answer comes, say so plainly and give the nearest thing your material carries | Motivation is not in your material, so the pack cannot supply it |
| C3 | "What's the first thing you'd want to see in our operator data?" | CASE | [generic] | Name one data set you would ask for first, and what it would tell you. Keep it to one | Casual, but a live problem. Rapport questions on the role's own topic are scored |

## Requirement coverage

| Requirement | Questions covering it |
|---|---|
| Recruiter: "where you'd take our operator partnerships over the next 18 months" | B1, B3, POV build |
| Recruiter: "Please land on what it means for the operators themselves." | B1, POV close |
| Recruiter: "Ross will push on commercials." | A1 to A5 |
| Influenced vs owned revenue (your message) | A1, A2, B4 |
| Rail sales (your message) | B2, B4 |
| Quota attainment (role-family, unquoted) | A2 |
| Pipeline math for operator deals (role-family, unquoted) | A4 |
| Margin and pricing (role-family, unquoted) | A3, A4 |
| Operator knowledge (your message) | B3, C1 |
| Partner growth (role-family, unquoted) | A1, C1 |
| JD's own requirement list | none, and why: no JD was supplied, so the pack cannot check against it. See the upgrade menu |

Session total is thirteen questions, below the roughly eighteen a full pack carries. The shortfall is the missing JD: a JD would give the requirement rows something to draw on.

## Prohibited claims

Built here from the fit snapshot, because no dossier was present.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the partner pipeline or the £4M | Inflated form of "never carried a direct quota, only influenced revenue" | The quote at its own scope: influenced revenue. Your material says influenced, not owned |
| Signed the 34 extra partners | Inflated form of "took it from 6 partners to 40" | The quote at its own scope: a channel that went from six partners to forty |
| Sold into rail, or has rail operator relationships | Negative you stated, F4 | "I haven't sold into rail specifically." No slot |
| Knows how operators make commercial decisions | Inflated form of "so I know the operator world from the other side" | The quote at its own scope: bus and light rail network planning |

## Delivery coaching

Not included: no working-style assessment was offered.

## Sources

- **Provided documents:** the recruiter's email, as quoted in your message. Only the passages you quoted were available; the email was not pasted. The internal market report you read was not pasted and is not used here.
- **Your message:** your background, as quoted throughout.

Research tier: L1, searches 5 of 6, fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton values | unavailable | Refused (query: "Kelverton Rail company values"). Would have decided whether a values cheat sheet applies, and whether the POV uses published values |
| 2. Kelverton interview process | unavailable | No query was sent for this target; the search batch was refused by the permission check before one could be formed. Would have set loop structure beyond the round-type priors |
| 3. Kelverton strategy / recent news | unavailable | Refused (query: "Kelverton Rail scheduling software train operating companies strategy news"). Would have supplied CO questions and current POV references; A5 and the POV's operator claims stay generic |
| 4. Interviewer footprint (Deepa, Ross) | unavailable | Refused (queries: "Kelverton Rail Ross Commercial Director", "Kelverton Rail Deepa VP Partnerships"). Would have produced an interviewer read and persona reasoning per member |
| 5. Representative JD | unavailable | Refused (query: "Kelverton Rail Senior Partnerships Manager job description"). Would have supplied `[inferred]` requirement rows |

All five searches were refused by the host's permission check. No fetch was attempted.

## Upgrade menu

- JD text → F1 to F6 gain quoted requirement rows instead of recruiter or role-family wording, and the coverage table can check against the JD's own list.
- Kelverton's market report, pasted → the POV's differentiation is checked against the report's consensus, not assumed.
- How the £4M and the six-to-forty growth were counted → A1 and F2's defend-the-number slots can be answered in your own words before the drill.
- Any hard term in the recruiter's note (location, office days, right to work) → any gate becomes a `hard_gate` row, surfaced prominently.
- Search permission granted → L1 research can be retried: values, interview process, strategy, and the public footprint of Deepa and Ross.
