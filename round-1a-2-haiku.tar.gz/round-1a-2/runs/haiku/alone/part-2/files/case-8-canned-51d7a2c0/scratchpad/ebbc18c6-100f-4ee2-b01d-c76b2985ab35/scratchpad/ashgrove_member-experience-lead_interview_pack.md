# Ashgrove Credit Union: Member Experience Lead, interview prep pack

**Company:** Ashgrove Credit Union (member-owned, about 900 staff)
**Role:** Member Experience Lead
**Rounds, 28 November 2026:**
- Round 1: 30 minutes with the recruiter (name not given)
- Round 2: 45 minutes with the Head of Member Services, your future manager, mostly behavioural (name not given)
- Round 3: 60 minutes with a panel of two branch managers, including a 20-minute complaint escalation case; the panel scores the four values (names not given)

**Mode:** loop mode, three rounds. Shared fit snapshot first, then one mini-pack per round with its own persona weights, bank, and reverse questions.
**Version:** first version. Nothing has changed yet.

---

## How to use this pack

**Personas** describe how a question is asked. **Types** describe what is being scored.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Behavioural / values alignment | Whether past behaviour shows the published values, not generic virtue |
| EXP | Work-experience deep-dive | Whether the CV's claims survive scrutiny, and what you actually did |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company and strategy knowledge | Whether you know the July 2026 brief and can think at its altitude |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. Each guidance cell is written to be said aloud in 90 to 120 seconds.

**Terms used in the tables:**
- **Answer slot:** an instruction for the interview with two honest branches. You answer from your own experience, or you say plainly that the practice was not yours or did not happen. It is never a question to me.
- **Plain acknowledgment:** a negative you have already said about yourself, repeated as you said it. Nothing is added to it.
- **Provenance:** the label first, then the exact sentence from your message or the source document that the guidance rests on.

---

## Fit snapshot

Requirements come from the JD text you pasted. Evidence is quoted from your message, verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | presentation | Your material says six years in retail banking, the last three as a branch supervisor. Say it in those words. Nothing is added to reach 4+. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log and trained new tellers on our escalation script." (your message) | medium | [grounded] | transferability | Complaints work is in your material. Regulated is not. Say "I handled the branch's formal complaints log." Answer slot: if rules set outside the branch governed the log, name them and how you kept to them; if the log followed no rules you can name, say so plainly and describe how you ran it. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material places you at the branch log, not the process end to end across branches and the contact centre. Stay at the log's scope. Answer slot: if you set how a complaint moved from log to close, say which steps were yours; if others set the process, or it did not reach beyond the branch, say so and stay with the log. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Your sentence already reaches monthly complaints reporting. Volumes and resolution times are not in it. Say the sentence as it is. Answer slot: if the spreadsheet carried either measure, say which and how you counted it; if it carried neither, say so and say what you would add first. |
| F5 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | low | [inferred] | discovery | Derivation: the sentence names a spreadsheet, not a tool, and not a level of skill. It shows that you built a monthly report, nothing more. Answer slot: name the tool you built it in and what you were comfortable doing in it; if you cannot say, say so. |
| F6 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Your stated absence. Plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare to present to senior leaders, said as a plan. Never describe a presentation you have not given. |
| F7 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material places the training with new tellers, not supervisors. Say it at that scope. Answer slot: if you have coached other staff or supervisors on escalations, say how; if the training was for tellers only, say so and describe how you would start with supervisors. |
| F8 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | The JD asks for it and nothing in your material shows it. Answer slot: if you worked with a digital or product team on a customer journey, say what the journey was and what your part was; if you have not, say so plainly and say how you would start. |
| F9 | "the contact centre" (JD: "across branches and the contact centre") | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your stated absence. Plain acknowledgment: "I've never worked in a contact centre." Then how you would learn contact-centre work, said as a plan. |

**Gates:** none. The JD names no licence, credential or legal bar. "4+ years" is a length requirement and is graded like the rest. Pay, notice and location are not in the JD; they come up only as recruiter-screen logistics (R1.3 to R1.5).

---

## Prohibited claims

These are not coached anywhere in this pack, including in answer slots, holds, reverse questions and rehearsal.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns the member complaints process end to end across branches and the contact centre | Inflated form of F3. Your sentence places you at the branch log. | F3's quote at its own scope. Limit, as this pack's observation: your material says the branch log. The slot stays inside the log. |
| Experience in a contact centre | Your stated negative (F9) | "I've never worked in a contact centre." No slot. |
| Has presented to senior leaders | Your stated negative (F6) | "I've never presented to anyone above regional level." No slot. |
| Handled regulated complaints | Inflated form of F2. Your sentence says the formal log. | F2's quote at its own scope. Limit, as this pack's observation: your material does not say the log was regulated. |
| Advanced Excel | Inflated form of F5. Your sentence names a spreadsheet and no level of skill. | F5's answer slot only. |
| Coached branch supervisors | Inflated form of F7. Your sentence says new tellers. | F7's quote at its own scope. |

---

## Grounding brief

From the July 2026 strategy brief, as you summarised it to me:
- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs during 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

**Currency:** July 2026. Today is 19 November 2026. No newer material was searched. Check each line above against the brief itself before the interview; the brief is not in this conversation.

**The tension to be ready for:** the hub plan against "Neighbours, Not Numbers". Do not argue against the plan, and do not promise to keep any branch open. Talk about what happens to a town's members in concrete steps.

---

## Values cheat sheet

Values are quoted from the page you pasted (ashgrovecu.org/about/values, copied 19 November 2026). Your material carries no story that is a clean match for any value, so each row is a selection scaffold ending in an honest branch, or the answer slot it draws on.

| Value | Working meaning | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold on F3: pick a time a member's complaint changed what you did for the next member. If none comes to mind, say so plainly, then give the nearest thing the log carries: "I handled the branch's formal complaints log." |
| Plain Words | If a member needs it explained twice, the wording was wrong | Selection scaffold on F7: "trained new tellers on our escalation script." Say what the script asked a teller to say, in plain words. If its wording never changed, say so. |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold on F4: pick a time a figure in your spreadsheet affected one branch's members. If none did, say so and give the nearest case where a number and a town disagreed. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Answer slot on F3 (R2.2, R3.4): if you kept a complaint until it was solved, say what you did at each point; if someone else closed it, say who and what your part was. |

---

## Requirement coverage

| JD requirement | Questions |
|---|---|
| 4+ years in financial-services customer operations | R1.1 |
| Own the member complaints process end to end across branches and the contact centre | R2.2, R2.5, R3.4, R3.5 |
| Experience handling regulated complaints | R2.12 |
| Report monthly on complaint volumes and resolution times | R2.7, R3.11, R3.12 |
| Coach branch supervisors on escalations | R2.9, R3.7 |
| Work with digital teams on self-service journeys | R3.6, R3.9 |
| Confident presenting to senior leaders | R1.8, R2.6 |
| Comfortable with Excel reporting | R2.7 (tool), R3.11 |

Every JD requirement has at least one question. None is left uncovered.

---

## Round 1: recruiter screen (30 minutes)

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / Rapport Builder | A friendly biography opener, with the logistics asked casually | Top weight (4 questions). A recruiter screen's prior is conversational, and the logistics are scored. | Script one 90-second arc (R1.1). Answer each logistics question as its own slot. |
| Skeptic (light) | One or two gap checks on the knockouts | Lower weight (2 questions). The two stated absences are the first things a screen checks. | Plain acknowledgment only, then the plan. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1.1 | "So, walk me through your path to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log and trained new tellers on our escalation script."; "I built the monthly complaints spreadsheet our regional manager uses." | Use only those three sentences, in your words: six years in retail banking, the last three as a branch supervisor; then the log and the training; then the spreadsheet. Stop there. Do not add a stage, a number or a team. | Covers F1, F3 and F4 in one arc. The biography is scored casually, so it is scripted once. |
| R1.2 | "What drew you to this role?" | JD | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD) | Answer with your reason in your own words. Your material gives none, so this guidance supplies none. If the complaints work is the reason, say which part of it, in two sentences. | An open prompt with its theme taken from the JD's complaints line. |
| R1.3 | "What are your salary expectations?" | JD | [generic] Pay is not in the JD or in your material. | Give the figure you have decided on, in your own words. If you have not decided, ask for the band for this role first, then answer. The pack supplies no figure and no salary history. | Logistics slot. Not a gate: the material states no pay. |
| R1.4 | "What's your notice period?" | JD | [generic] Notice is not in your material. | Give your actual notice period. The pack does not know it, and a guessed figure is the one answer that cannot be walked back. | Logistics slot. |
| R1.5 | "Where would you be based, and what travel can you do between sites?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as you summarised it) | Name your base and the sites you can reach. Do not comment on which branches should close. | Logistics slot. The hub plan is the reason this is likely to be asked closely. The role's location is not in the material. |
| R1.6 | "Why are you looking to leave your current role?" | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Give one sentence of reason in your own words. The material gives none, so this guidance supplies none. Keep it about the work. | Logistics slot, tagged EXP because it tests consistency with the path. |
| R1.7 | "Nothing in your background is a contact centre. How do you see that?" | EXP | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I've never worked in a contact centre." Then one sentence, as a plan, on how you would learn contact-centre work. No slot asks for a contact-centre story. | The screen's first knockout check. The question rests on your own negative. |
| R1.8 | "This role presents to senior leaders. How do you handle that?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I've never presented to anyone above regional level." Then how you would prepare, as a plan. Do not describe a presentation you have not given. | Light Skeptic. The JD raises presenting; your own words carry the negative. |

**Reverse questions**

| Question | Why it lands |
|---|---|
| "What would a good first month look like for whoever takes this role?" | Asks for the standard, so the interviewer sets the measure you will be judged by. |
| "Where does this role sit relative to the branches and the contact centre?" | Shows you read the JD's structure. |
| "Which of the three strategy moves matters most to this role?" | Uses the July brief and shows you read it. |
| "How will the hub move change what this role is measured on?" | Ties the strategy to Neighbours, Not Numbers. |
| "What's the one part of the complaints process you'd most like changed?" | Invites a problem to own, which is the Own the Fix value. |

---

## Round 2: Head of Member Services (45 minutes, behavioural)

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Stories tested against the four values, in STAR shape | Top weight (4 questions). The recruiter says the round is mostly behavioural, which moves it from the manager's usual prior toward values. | Map each value only to a story from your quotes. Say where none exists. |
| Skeptic | Quiet probes on the two stated absences and on the end-to-end claim | Weight 3. A hiring manager's prior includes the Skeptic, and the two negatives are the obvious probes. | Plain acknowledgment, then the plan, then calibrated candour. |
| Case / Strategist | A live problem from the hub move and the complaints work | Weight 2. The hiring-manager prior includes a case; the formal case is in round 3. | Clarify before structuring. Use the brief's own words. |
| Pressure / Stress | Time-boxed challenges to motive and credit | Weight 2. You will probably meet one; it is the composure check. | Pause, restate, hold through two follow-ups, then concede specifically. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R2.1 | "Tell me about a time a member's complaint changed how you ran the next one." | VAL | [grounded] "I handled the branch's formal complaints log." | Open prompt, so you choose the complaint. Pick one in the log that changed what you did next. Name the complaint, the change, and which side of the counter you were on at each step. If none comes to mind, say so plainly, then give the nearest thing the log carries: what you handled and how. | Members First. No sentence in your material says a complaint changed your practice, so the guidance does not say it did. |
| R2.2 | "Tell me about a complaint you kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log." | Answer slot: if you kept a complaint until it was solved, say what you did at each point. If someone else closed it, say who and what your part was. If you did not carry one to a solution, say so and describe how you handled the log. | Own the Fix. The value names the idea of keeping hold; the log is the only sentence that raises it. |
| R2.3 | "Tell me about a time a member needed something explained more than once." | VAL | [grounded] "trained new tellers on our escalation script" | Scaffold: the escalation script is the nearest thing your material carries. Say what it asked a teller to say to a member, in plain words. If you changed its wording after a member did not follow it, say what changed. If you did not, say so. | Plain Words. The honest branch is "I never had to." |
| R2.4 | "Tell me about a time a number you reported changed something for one branch's members." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Scaffold: pick a time a figure reached one branch's members. Say the figure, the branch and what changed for the members. If the spreadsheet never reached a branch's members, say so and give the nearest case where a number met a town. | Neighbours, Not Numbers. The honest branch is the point of the question. |
| R2.5 | "You haven't worked in a contact centre, and this role owns complaints across one. Why should we believe you can run it?" | JD | [grounded] "I handled the branch's formal complaints log"; "Never worked in a contact centre" | Highest-ROI prep. Hold: say what the log was and what you did with it. Concede: "I haven't worked in a contact centre." Then the plan, as a plan: how you would learn it first. Hold through two follow-ups by returning to the log and the concession. Do not claim the branch and the contact centre are the same work. | The most predictable objection to you, asked directly. Both quotes are yours. The hold is only what the log quote carries. |
| R2.6 | "What's the part of this role you'd be weakest at on day one?" | JD | [grounded] "I've never presented to anyone above regional level."; "Never worked in a contact centre" | Name the two gaps as plain acknowledgments: "I've never presented to anyone above regional level." and "I haven't worked in a contact centre." Then one plan for each, as a plan. Do not volunteer a third gap. | The two stated absences are your strongest material here. |
| R2.7 | "Walk me through the monthly complaints spreadsheet: what it's built in, and what it reports." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say the tool you built it in and what it reports, in your own words. Your material names neither, so this guidance names neither. Answer slot: if you can say how comfortable you are in the tool, say what you did in it; if you cannot say, say so. | Covers F4 and F5 (Excel). The tool is the probe the JD's Excel line invites. |
| R2.8 | "Eight branches are moving to five hubs during 2027. Complaints from the branches that close will come in. What do you do first?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (strategy brief, as you summarised it); structure is [generic] | Clarify before structuring: which complaints, which branches, which members, and what the regional manager already tracks. Then the objective. Then approach, measures and risks. Do not argue for or against the plan. Do not promise to keep any branch open. | A CO and CASE question grounded in the July brief. It tests whether Neighbours, Not Numbers survives the plan. |
| R2.9 | "Tell me how you'd coach a branch supervisor who is escalating everything." | JD | [grounded] "trained new tellers on our escalation script" | Answer slot: if you have coached other staff or supervisors on escalations, say how. If the training was for tellers only, say so and describe how you would start with a supervisor. Then the first step, as a plan. | The JD's coaching line is the raising source. Your only escalation training is for tellers, so the answer keeps that scope. |
| R2.10 | "Sixty seconds: why you over someone with contact-centre years?" | JD | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "Never worked in a contact centre" | Pause and restate. Hold: six years in retail banking and what you did with the log. Concede specifically: "I haven't worked in a contact centre." Then one sentence on what you bring that is yours. Do not argue the other candidate down. | Pressure stem. Hold, then concede. |
| R2.11 | "That complaints log: how much of the outcome was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log" | Pause and restate. Hold: say which parts you handled, in those words. Concede where it is true: if others made decisions you carried out, say so. Do not claim the outcome. | Pressure attribution probe. The guidance holds only what the quote carries. |
| R2.12 | "What rules did your complaints log have to follow, and who set them?" | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if rules set outside the branch governed the log, name them and how you kept to them, in your own words. If the log followed no rules you can name, say so plainly and describe how you ran it. Do not use the word "regulated" unless you can say what regulated it. | The JD's regulated-complaints line. This is where F2 is tested. The second branch allows that there were no outside rules. |

**Reverse questions**

| Question | Why it lands |
|---|---|
| "What would you want the first 90 days to change about how complaints are handled?" | Asks for the standard and shows the manager's priority. |
| "Which complaint decision last quarter would you have wanted to make differently?" | Shows judgment and names a real decision. |
| "How do branches tell you a complaint process isn't working?" | Shows how the manager hears about problems, which is a Neighbours question. |
| "Where does the 2027 hub move leave the complaints workload?" | Connects to the July brief. |
| "What's the one thing you'd like the next hire to fix that you couldn't?" | Names the real problem and the gap you would close. |

---

## Round 3: branch-manager panel (60 minutes, with a 20-minute case and values scoring)

**Persona table**

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Values / Behavioural | Each value scored, against STAR-shaped stories | Top weight (4 questions). The recruiter says the panel scores the four values. | One mapped story per value, or the honest branch. |
| Case / Strategist | The 20-minute complaint escalation case, plus the strategy questions | Top weight (4 questions). The recruiter names a case. | Clarify facts first. Structure. Think aloud. Use the brief's words. |
| Peer Evaluator | Seam questions between branches and digital; who gets credit | Weight 2. Two branch managers are the people your team would hand work to and take it from. | Seam principles, not claims about a seam you have not seen. |
| Data-Driven Prober | Probes on the spreadsheet: how it counts, which number you would defend least | Weight 2. The spreadsheet is the one artifact in your material the panel can probe. | Say what you counted. Say plainly when you do not know. Name the weakest assumption before they do. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R3.1 | "Tell me about a time you decided something from a member's side of the counter." | VAL | [grounded] "I handled the branch's formal complaints log." | Open prompt. Pick a complaint in the log where the member's side changed the decision. Name the decision and what the member needed. If none did, say so plainly, then give the nearest complaint you handled and how you handled it. | Members First, scored by the panel. |
| R3.2 | "When did a member not follow what you told them, and what did you change?" | VAL | [grounded] "trained new tellers on our escalation script" | Scaffold: the script is the nearest thing your material carries. Say what it asked a teller to say, in plain words. If you changed its wording after a member did not follow it, say what. If you did not, say so and say what you would check first. | Plain Words, scored by the panel. |
| R3.3 | "Tell me about a time a decision that looked right on the numbers was wrong for one town." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Scaffold: pick a time a figure pointed one way and a town needed another. If the spreadsheet never showed such a case, say so and give the nearest time a number and a town disagreed. Do not promise to keep a branch open. Say what you would check. | Neighbours, Not Numbers, scored by the panel. |
| R3.4 | "Tell me about a problem you found and kept hold of until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log." | Answer slot: if you found a problem in the log and kept hold of it, say what you did at each point and what was solved. If it was solved by others, say who and your part. If you did not carry one to a solution, say so and describe how you handled the log. | Own the Fix, scored by the panel. The log is the only sentence that raises it. |
| R3.5 | "A member's complaint about a closed branch has been escalated to you. They say the nearest branch is gone and the app doesn't help. Walk me through the twenty minutes." | CASE | [grounded] "20-minute case on a complaint escalation" (recruiter's email); [generic] case structure | This is a rehearsal case built from the brief, not the panel's own case. Structure: clarify what was promised and what the member needs; decide who keeps hold of the fix; reply in plain words; record what you would track for the monthly report; say what you would escalate and to whom. Do not claim you have run a case like this. | The 20-minute case is the single most scored item. Rehearse the structure, not a story. |
| R3.6 | "Digital service is moving to 40% of member service by 2028. What complaints does that move, and what would you measure?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, as you summarised it) | Clarify which complaints move with the channel and which stay in branch. Measures: volume and resolution time by channel, and the complaints a channel change creates. Name the assumption you would test first. Do not give a figure for the share. | A CO question grounded in the brief. Differentiates you from candidates who have not read it. |
| R3.7 | "A branch manager says her supervisors escalate everything to the contact centre. What do you do in the first week?" | CASE | [grounded] "coach branch supervisors on escalations" (JD); "trained new tellers on our escalation script" (your message, optional tie-in) | Structure: find out what they escalate and why; check the script they use; coach one supervisor on one type of case; measure before and after. If you bring in the script, use the tellers sentence and no more: you trained tellers on it. | The JD's coaching line, delivered as a live problem. The tellers sentence is the only tie. |
| R3.8 | "App-only banks are our main pressure. What would a member expect from a complaint made in an app?" | CO | [grounded] "the main competitive pressure is app-only banks" (strategy brief, as you summarised it) | Describe member expectations as your own general view, and say so. Keep to a clear route, a clear answer and a person who can be reached. Do not present these as Ashgrove data. | Tests altitude on the competitive pressure. |
| R3.9 | "Our teams sit side by side. Where's the seam between branches and digital, and what happens when you disagree?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Propose one seam principle: who keeps hold of a complaint that crosses the two. Answer slot: if you have worked with a digital team, say what it was; if not, say so and say how you would start. Do not pretend to know their seam. | Peer Evaluator. F8 is discovery, so the answer slot is the only way your past enters this answer. |
| R3.10 | "How do you handle credit when a complaint fix needs two teams?" | VAL | [grounded] "whoever finds the problem keeps hold of it until it is solved" (Own the Fix value, as you pasted it) | Say who keeps hold, in one sentence, and how the other team gets the credit it earned. Claim no past example. Your material has none for this (F8 is none given). | Peer Evaluator. The panel probes credit-sharing; the value is the raising source. |
| R3.11 | "How did you count what the spreadsheet reports?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what you counted, in your own words. If you cannot say how a count was made, say that and say what you would check first. Do not reconstruct a method you did not use. | Data-Driven Prober. The spreadsheet is the only numbers-adjacent artifact in your material. |
| R3.12 | "Which number in that spreadsheet would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if the sheet carried a number you can name, name it, and the assumption behind it you would defend least. If it carried no figure you can name, say so and say what it tracked. | The weakest-assumption probe. Your material names no figure, so the guidance names none. |

**Reverse questions**

| Question | Why it lands |
|---|---|
| "Which part of the complaints process would you change first, if you could?" | Asks the panel to name a problem, which shows where you would start. |
| "What do the branch managers need from the complaints lead that they aren't getting now?" | Names the stakeholder need in one question. |
| "What could someone new do in their first month that would genuinely help your branch?" | Reciprocity question for a peer panel. It turns the round into a conversation between peers. |
| "How do you each see Neighbours, Not Numbers working in the hub plan?" | Shows you read the values, and invites the tension out in the open. |
| "What does a good escalation decision look like from where you sit?" | Asks for the standard the panel scores against. |

---

## Sources

**Provided documents** (your message of 19 November 2026):
1. Your background (six years in retail banking, the last three as a branch supervisor, the complaints log, the escalation training, the spreadsheet, the two absences).
2. The JD text.
3. The four values, copied from ashgrovecu.org/about/values.
4. The recruiter's email about the three rounds, including the panel's values scoring.
5. Your four-point summary of the July 2026 strategy brief. The brief itself is not in this conversation.

**Dossier:** none present.

**Searches and fetches:** none sent.

**Research tier:** L0. No search or fetch was run. Every research target is either fixed by material you supplied or has no query to run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The pasted values page fixes the values cheat sheet. A search would not change it. |
| 2. Ashgrove interview process, Member Experience Lead | skipped | The recruiter's email fixes the three rounds, their lengths, and the panel's composition. |
| 3. Ashgrove strategy and recent news | skipped | The July 2026 brief, as you summarised it, fixes the grounding brief. Recent news beyond it is in the upgrade menu. |
| 4. Interviewer name and Ashgrove | n/a | No interviewer name was given, so there was no query to form. The interviewer read is absent. |
| 5. Representative Member Experience Lead JD | skipped | The JD you supplied fixes the fit snapshot and the JD questions. |

---

## Upgrade menu

- The names of the round 2 and round 3 interviewers → persona weights from their public footprint, and a reverse question tied to their career path.
- The rules your complaints log had to follow, named → R2.12 and F2 get concrete wording in place of an answer slot.
- Any figure from the spreadsheet or the log (its volumes, its resolution times, how they were counted) → F4 and R3.11 to R3.12 get real figures to defend.
- Your CV as a document → F1, F3, F4 and F7 can quote it, and more sentences may enter the fit snapshot.
- The round 3 case brief, if the recruiter will share it → R3.5 rehearses the real case rather than the rehearsal case.
- Deep research (L2, offered once; at most six searches and two page fetches): recent Ashgrove news beyond the July brief, and loop reports for this role family. It would update the grounding brief and the strategy questions.

