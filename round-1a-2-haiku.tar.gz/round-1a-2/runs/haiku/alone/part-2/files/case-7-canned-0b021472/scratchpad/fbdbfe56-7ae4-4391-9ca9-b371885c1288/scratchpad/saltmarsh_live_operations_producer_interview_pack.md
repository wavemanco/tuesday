# Interview pack: Live Operations Producer, Saltmarsh Games

**Role:** Live Operations Producer
**Company:** Saltmarsh Games (mobile, about 350 people)
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship assumed to be hiring manager, because the company's own page describes its single 60-minute round as the Outage Hour with the hiring manager. Confirm this (see the question in the message).
**Round:** 60-minute Outage Hour, Friday. A live-incident tabletop on a simulated outage during a live event, then a values conversation. No take-home.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** behavioural / values alignment. **EXP** experience deep-dive. **JD** role and JD-driven. **CO** company and strategy. **CASE** live problem.
- Guidance is scaffolding, not a script. Speak it in your own words. Anything in quotation marks is what your own material says.
- Answer slots are instructions for the interview, not questions to answer here. Each one gives both honest branches.

## Fit snapshot

Requirements are quoted from the JD you pasted. Your evidence is quoted from your message. The material has no hard gates: the JD names no location, work-authorisation or credential requirement.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | none | No gap; the quote reaches the requirement. Limited inspectable proof, so expect a probe on what the calendar contained. Say it as you wrote it: "I ran the weekly content-drop calendar for our main title for the last two years." |
| F2 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses" — your message | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote it, and QA still uses it. The bridge rewords only that: "I wrote the release checklist our QA team still uses." Do not add that you signed off releases. |
| F3 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head" — your message | medium | [grounded] | discovery | The quote touches retention metrics without showing whether you defined, computed or interpreted them. Answer slot: if you produced or interpreted those numbers, say how, in your own words. If you presented numbers others produced, say so plainly and stay with the presentation. |
| F4 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio" — your message | medium | [grounded] | transferability | Adjacent work: four years, and a puzzle studio. Your message does not say the title was live-service in the JD's sense. Bridge: "I was an associate producer at a puzzle-game studio for four years." Do not extend that to live-service. Answer slot: if the title ran continuous updates, say what those were; if it shipped as a one-off, say so. |
| F5 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years" — your message | medium | [grounded] | transferability | Adjacent work: one title and weekly drops, not two titles and live events. Bridge stays at the quote's scope: "I ran the weekly content-drop calendar for our main title." Answer slot: if you planned anything beyond weekly drops, such as live events or a second title, say what, in your own words. If not, say so and say how you would plan two titles first. |
| F6 | "own the post-event review and the KPIs it reports" — JD | none given | none | [grounded] | discovery | Your material does not show a post-event review or KPI reporting. The nearest line is F3, which is not a review. Answer slot: if you ran a review after a drop or other release and reported its figures, say what it measured. If not, say so plainly and say how you would structure one. |
| F7 | "coordinate design, art, engineering and community teams on each update" — JD | none given | none | [grounded] | discovery | Your material does not show coordination with those teams. Answer slot: if you coordinated any of them on a drop, name which and what you did. If you did not work with one, say which. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses" — your message | low | [inferred] | discovery | Evidence is indirect: a document other teams use, not a record of your writing. Derived by this pack, not your claim. Answer slot: if you wrote anything else a team acted on, name it. |

## Prohibited claims

Built locally from the fit snapshot. These are claims a candidate reaches for under pressure. No answer, hold, bridge or reverse question may assert, soften or imply them.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team | Stated negative: "Never led a team" — your message | Plain acknowledgment: "I haven't led a team." Then only the coordination you did, if any (F7's slot). |
| Owned the post-event review and the KPIs | Inflated form of F3 | F3's quote at its own scope. The limit is this pack's observation: your material says you presented the numbers, not that you owned the KPIs. |
| Ran live events, or planned two titles | Inflated form of F5 | "I ran the weekly content-drop calendar for our main title." |
| Managed the release checklist with QA | Inflated form of F2 | "I wrote the release checklist our QA team still uses." |
| Worked on live-service games | Inflated form of F4 | "I was an associate producer at a puzzle-game studio for four years." |
| Worked on a game with in-app purchases | Stated negative: "never worked on a game with in-app purchases" — your message | Plain acknowledgment: "I haven't worked on a game with in-app purchases." |

## Reading the interviewer

Public footprint only: a GDC 2026 talk page ("Patch Notes Are a Promise") and its description of him as previously a QA lead at a console studio.

- **Career pattern:** QA, then Head of Live Operations. His published argument is that a live team is judged by how often its patch notes describe what actually shipped.
- **Implication 1:** the release checklist is the part of your material that lines up with his argument. Keep the checklist answers tied to what it gated.
- **Implication 2:** the Outage Hour is his format. Say your first clarifying questions aloud before proposing any action.
- **Implication 3:** do not overstate your QA side. Your checklist work is in his professional domain; it is not a shared career jump.
- **Mirror opportunity (shared professional domain):** "Wrote the release checklist our QA team still uses" (F2) sits beside his QA-lead background. Use it only as a point of contact, never as a claim about his experience.

## Persona table

Relationship prior for a hiring manager is Case/Strategist and Skeptic. The Outage Hour is a documented source that adds a values conversation, so Values rises. He has no self-described data-driven profile, so Prober stays at middle weight.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live incident or calendar problem, scored on structure | Highest: the Outage Hour is a live-incident tabletop, documented on the company's careers page | Clarify, then structure, then decide, and say each step aloud |
| Skeptic | "Why you, for two titles and live events?" | High: F4 and F5 are the mismatches the JD names | Hold the one core claim, concede the gaps in your own words, and show a 30-day plan |
| Values/Behavioral | Scenario mapped to the three published values | High: the company's page documents a values conversation in the same hour | Map each value to a story only where your material carries one; otherwise use the selection scaffold |
| Data-Driven Prober | Asks how the retention figure was counted | Middle: your one retention line invites it | Say what you did and did not produce |
| Pressure | Time-boxed challenge on fit | Low-middle: no interviewer signal of a pressure style | Pause, restate, hold through two follow-ups |
| Conversational | Opening journey question | Low-middle: an opener is near-certain even if the rest is scored | Pre-rehearse a 90-second arc |

## Question banks

Ordered by persona weight. Type is one token. Provenance leads with one label, then the candidate sentences the guidance rests on.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Your live event is running and players report a missing reward in the event shop. Walk me through your first 30 minutes." | CASE | [generic] | Clarify scope first: how many players, which platforms, whether the event is still live. Then decide between pausing and patching, name who you call (engineering on-call, QA, community), decide what players hear now and what waits, and note what goes into the post-event review. Claims nothing about your past. | The Outage Hour's format, per the company's careers page. [generic] because it is a pattern for the problem, not a fact about this studio. |
| A2 | "Day-two retention on a live event dropped sharply. What do you check first?" | CASE | [generic] | Confirm the metric definition and cohort. Separate a release or calendar change from an external one. Segment by platform and version before deciding anything. Name the weakest assumption in the first read. | JD requirement R3 (retention) is the raising source. Structure over answer. |
| A3 | "Plan a live-events calendar for two titles for next quarter. What do you need to know first?" | CASE | [generic] | Ask about each title's cadence, its player base, and which teams are available. Then build the calendar with checkpoints and a release gate tied to the checklist. | Raised by the JD's "live-events calendar for two of our mobile titles" (F5). |
| A4 | "Engineering says a fix will slip a week, and the event is already announced. What do you do?" | CASE | [generic] | Separate what is built from what is hoped. Decide what the announcement says. Consider shortening the event or swapping content. Name who decides, and what QA is told. | The company's value "Ship the Patch Not the Promise" (values page) raises it. |
| A5 | "Project Larkspur moves two titles to one shared events calendar from February. What would you protect first?" | CO | [grounded] company news, not your material | Name the one thing you would protect and why (for example, release gating on the shared calendar), in the company's terms. Do not claim any experience with a shared calendar. | The company's September 2026 news; this is the strategy differentiator. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've run a weekly content calendar on one title. Two titles, live events, owning KPIs: why should we believe you can do that?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years"; [grounded] "4 years as an associate producer at a puzzle-game studio" | Highest-ROI prep. Hold: "I ran the weekly content-drop calendar for our main title for the last two years." Then say what transfers from that work and what you would do in the first 30 days. Concede in your own words, naming the gap the material does not show: two titles, live events. Hold through two follow-ups by returning to the calendar and the 30-day plan, never by adding scope. Answer slot: if you planned anything beyond weekly drops, say what in your own words; if not, say so plainly. | F5 and F4 are the two mismatches the JD raises. The skeptic will ask some form of this, so it gets the deepest rehearsal. |
| B2 | "You've never led a team, and this role coordinates four disciplines. Where does that break?" | JD | [grounded] "Never led a team" | Plain acknowledgment: "I haven't led a team." Then describe coordination only if it happened. Answer slot: if you coordinated design, art, engineering or community on a drop, name which and what you did; if you did not work with one, say which. Never imply leadership. | F7 gap. The JD's coordination line raises it. |
| B3 | "You wrote the checklist. What have you done with post-event reviews and KPIs?" | JD | [grounded] "Wrote the release checklist our QA team still uses"; [grounded] "Presented the monthly retention numbers to the studio head" | Say what you did in those words: wrote the checklist, presented the monthly numbers. Answer slot: if you ran a review after a drop and reported its figures, say what it measured. If not, say so plainly and say how you would structure a post-event review. | F6 and F2. The JD owns post-event review; no quote carries it. |
| B4 | "Have you worked on a game with in-app purchases?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment: "I haven't worked on a game with in-app purchases." Then say what you would learn first. | Not a JD requirement. Included because you flagged it, so it is a likely probe. |

### C. Values/Behavioral (weight 4)

Company values come from the company's published page: Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time the calendar and the players disagreed. What did you do?" | VAL | [inferred] "I ran the weekly content-drop calendar for our main title for the last two years", as the nearest line | Selection scaffold: pick a time a planned drop or date had to move for players' sake. It needs a named stake, what you decided, and who decided. If no such time comes to mind, say so plainly, then give the nearest thing your material carries: the weekly drop calendar and how you would handle a conflict between it and player reports. | The value "Players Before Plans" from the company page. Your material shows no such decision, so the scaffold ends in the honest branch. |
| C2 | "Tell me about a time you announced something before it was ready." | VAL | [inferred] "Wrote the release checklist our QA team still uses", as the nearest line | Selection scaffold: pick a time an announcement outran the build. If the checklist ever stopped a release or changed an announcement, say how. The quote says only that you wrote it and QA still uses it. If it stopped nothing, say so plainly and say how you would use it to gate announcements. | "Ship the Patch Not the Promise" from the company page. |
| C3 | "Tell me about a time you left a process better than you found it." | VAL | [grounded] "Wrote the release checklist our QA team still uses" | Story beats the quote states: you wrote the checklist, and it is still in use. If there was a prior checklist it replaced, say so. If there was none, say so and do not invent one. | "Leave the Build Greener" from the company page. The checklist is the one story your material carries. |
| C4 | "Tell me about a time you had to tell leadership something unwelcome." | VAL | [grounded] "Presented the monthly retention numbers to the studio head" | If a monthly figure was unwelcome and you said so, tell that. If the presentations carried only good news, say that plainly. Do not invent an ending. | A standard values stem. The presentation is the nearest sentence you have. |

### D. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through how the retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say in your own words whether you counted or defined them, and how. If you presented numbers someone else produced, say so plainly and say what you presented. Do not describe a counting method you did not use. | F3. The question presumes a method. The second branch allows that you did not count them. |
| D2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you know an assumption behind the figures you presented, name it. If you did not produce them, say so and name the one question you would ask their owner. | Weakest-assumption move for F3. |
| D3 | "How did you know whether a content drop worked? What did you look at?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Say what you looked at after drops, if anything. If nothing was tracked, say so plainly. | Bridges to the post-event review (F6). |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why hire someone with no live-events experience over a live-ops producer who has it?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Pause. Restate the question. Hold: the weekly calendar you ran for two years, then one concrete first-month plan. Concede a specific gap in your own words. Hold through two follow-ups. | Time-boxed fit challenge. |
| E2 | "That retention result: how much of it was actually you?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Answer slot: if you produced any part of the figure, say which part. If you presented it without producing it, say so. | F3 under pressure. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey to here." | JD | [grounded] "4 years as an associate producer at a puzzle-game studio"; [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | A 90-second arc: four years as an associate producer, two years on the weekly calendar, the checklist, the monthly retention presentation. Each beat is one of the quotes. | Opening question. Casual, but scored. |
| F2 | "What live game are you playing right now, and what would you change about its update cadence?" | JD | [generic] | Name a live game you actually play, and one thing you would change in its cadence. If you do not play live games, say so, and name the one you studied. | A casual route to the JD's live-service requirement. |

### Requirement coverage

| JD requirement | Covered by |
|---|---|
| "Plan and run the live-events calendar for two of our mobile titles" | A3, B1 |
| "coordinate design, art, engineering and community teams on each update" | A1, B2 |
| "own the post-event review and the KPIs it reports" | B3, D3 |
| "manage the release checklist with QA" | B3, C3 |
| "3+ years producing live-service games or apps" | B1, E1, F2 |
| "experience running a content calendar" | B1, F1 |
| "comfortable with player-retention metrics" | A2, D1, D2 |
| "clear written communication" | none, and why: it is scored across every answer and gets no separate question, because nothing in the material shows writing for an external audience. |

## Values / principles cheat sheet

Detected: the company's own careers page documents a values conversation in the Outage Hour.

| Value | Working meaning | Mapped story |
|---|---|---|
| Players Before Plans | When the calendar and players disagree, the players win | None carried by your material. Selection scaffold and honest branch in C1. |
| Ship the Patch Not the Promise | Announce what is built, not what is hoped | F2 is the nearest line. Selection scaffold and honest branch in C2. |
| Leave the Build Greener | Every release leaves the codebase and checklist better than it found them | F2: "Wrote the release checklist our QA team still uses." Story beats only as C3 states them. |

## Reverse questions

Ask at least five. Each has a reason it lands.

1. "With Project Larkspur retiring per-title event teams, who owns the shared calendar day to day?" *Why it lands:* shows you read the company's own news from September, and puts the role's scope in front of him.
2. "Your GDC talk argues patch notes should describe what shipped. What does your team check before a patch note goes out?" *Why it lands:* ties to his published argument, and it is a professional question, not a personal one.
3. "How is the Outage Hour scored, and what does a strong answer look like?" *Why it lands:* signals you are preparing for the format, not guessing at it.
4. "What would a new producer's first 30 days on the shared calendar look like, and what would you want fixed first?" *Why it lands:* shows you are planning for the job, not for the interview.
5. "Which of the two titles has the bigger retention gap right now?" *Why it lands:* a direct question about the work the role owns, and it reveals how the company measures retention.

## Sources

Provided documents: your JD and background message.

| Query | Result |
|---|---|
| "Saltmarsh Games values" | saltmarshgames.com/values, returned. Fetched: three values named (Players Before Plans, Ship the Patch Not the Promise, Leave the Build Greener). |
| "Saltmarsh Games interview process live operations producer" | saltmarshgames.com/careers/interviewing, returned. Fetched: one 60-minute Outage Hour with the hiring manager, a live-incident tabletop then a values conversation; no take-home. |
| "Saltmarsh Games strategy news" | saltmarshgames.com/news/project-larkspur, returned (search snippet, not fetched): September 2026. Moves Tidepool Tactics and Lantern Row to a season-pass model with one shared events calendar from February 2027, and retires per-title event teams in favour of a single live-ops group. |
| "Tobias Wrenfield Saltmarsh Games" | Talk page, "Patch Notes Are a Promise" GDC 2026, returned (search snippet): Tobias Wrenfield, Head of Live Operations, previously a QA lead at a console studio. |

**Research tier: L1, searches 4 of 6, fetches 2 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | yes | Values cheat sheet; C1 to C3 |
| 2. `Saltmarsh Games interview process live operations producer` | yes | Loop: one 60-minute Outage Hour with the hiring manager; persona weights |
| 3. `Saltmarsh Games strategy` / recent news | yes | Project Larkspur (September 2026); A5 and reverse question 1 |
| 4. `Tobias Wrenfield Saltmarsh Games` | yes | GDC 2026 talk; interviewer read and reverse question 2 |
| 5. representative `Live Operations Producer` JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions |

## Upgrade menu

- A line on what the L2 deep pass would add (strategy brief, his talks, role-family loop reports, recent org context), up to 6 more searches and 2 more fetches, several more minutes. It would firm up A5 and the interviewer read.
- Any live-events or live-service work, even outside the job, moves F4 and F5 from transferability to grounded specifics.
- The retention figure and how it was produced converts D1 and D2 from slots into defend-the-number answers.
- The checklist's history (what it replaced, what it gated) turns C2 and C3 into full stories.
- A written line on whether you have run a post-event review or reported KPIs turns B3 and F6 from slots into grounded answers.
