# Quartzline: Product Manager, Platform APIs. Hiring-manager prep pack

Round: 45-minute conversation with the hiring manager. Interviewer name not given. Built from the underwriting dossier (`tuesday-dossier.md`, generated 2026-08-14) and no web research (see Sources).

## How to use

Personas describe how a question is asked. Types describe what is being scored. The guidance is scaffolding, not a script: say it in your own words, and stop where your material stops.

Type key:

- **VAL**: behavioural and values alignment. Not in this pack, because no values round was detected.
- **EXP**: a deep-dive on your own experience. Tests whether what you claimed survives scrutiny.
- **JD**: the role's own responsibilities and requirements.
- **CO**: company and strategy knowledge. Not in this pack, because research did not run.
- **CASE**: a live problem from the role, scored on structure and reasoning.

Provenance labels: `[grounded]` traces to the dossier or your own sentences. `[inferred]` is this pack's derivation, named where it occurs. `[generic]` is a role-family pattern with no claim about you or Quartzline.

Evidence IDs used below: **dossier E1** is `verified_candidate_evidence` item 1, **dossier E2** is item 2, and **dossier E3** is item 3. Requirement lines marked "JD line" are quoted from the dossier's `role_profile`, which stands in for the job description.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (JD line, R1) | None given for product management years. Adjacent: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | low | [grounded] | transferability | Your material shows integration work and roadmap input, not product-management years. Lead with the limit: "I haven't held a product manager title or role." Then the adjacent work at its own scope: E1 and E3 as quoted. The years figure is not in any verified entry, so do not add one |
| F2 | "Own the roadmap for the partner-facing API platform" (JD line; R1 sub-claim, dossier acknowledge_gap) | None given. Dossier prohibited_claims: "Having owned a product roadmap" | none | [grounded] | capability | Stated absence, from the dossier. Words: "I haven't owned a product roadmap." Then how you would learn it, said as a plan and never as a past |
| F3 | "Shipped API or platform products" (JD line, R2) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | high | [inferred] | transferability | Integration work on an API platform reaches the requirement only in part. Words at E1's scope: "I led integrations of the vendor's REST APIs from scoping through go-live." Limit, as this pack's observation: the material shows integrations, not a product you shipped. The underwriter's weak-area list does not include R2, so flag this to them |
| F4 | "Technical fluency: API docs, schemas" (JD line, R3) | "Wrote the internal integration playbook her team uses" (dossier E2) | high | [inferred] | discovery | The playbook touches documentation. The material does not show schemas, or whether the playbook reaches the requirement. Answer slot: if you wrote or reviewed API docs or schemas, say which; if you did not, say so plainly |
| F5 | "Stakeholder management across engineering, sales, customers" (JD line, R4) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | medium | [inferred] | transferability | Customers and product are reached by E1 and E3. Engineering and sales are not shown. Say the customer and product work at its quoted scope. Answer slot for engineering and sales. The underwriter has no weak-area row for R4, so flag this to them |
| F6 | "Agile delivery experience" (JD line, R5) | None given | low | [grounded] | discovery | Dossier clarify area (R5). No verified entry speaks to agile delivery, so no bridge is offered. Answer slot: if you have run sprint-based or similar delivery, say which and what cadence; if you have not worked that way, say so and ask what the squads mean by agile delivery |

Gap types follow the routing rule. Transferability carries an adjacent quote and its limit. Discovery has an answer slot. Capability has a stated negative from the dossier.

## Prohibited list

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier prohibited_claims | Plain acknowledgment: "I haven't held a product manager title or role." No slot |
| Having owned a product roadmap | Dossier prohibited_claims | Plain acknowledgment: "I haven't owned a product roadmap." No slot |
| Having set prioritization for an engineering squad | Dossier prohibited_claims | Plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot |
| Shipped an API or platform product | Inflated form of F3 (E1) | E1 at its own scope: integrations from scoping through go-live. The limit is this pack's observation, not a first-person negative |
| Ran discovery with integration partners | Inflated form of E1 (scoping and requirements) | E1 at its own scope. A3's slot stays inside the scoping and requirements steps |
| Years of integration leadership | Figure from the dossier decision prose only; no verified entry carries it | Not coached as a fact about your past. Use E1 and E3 at their scope; any years figure is yours to state, and you should confirm it first |

## Persona table

| Persona | How it shows up in this round | Likelihood, with reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Quiet probing of the R1 gap and the roadmap sub-claim. "Why this, why now" | Highest. Hiring-manager prior: they are buying capability and derisking gaps. The dossier's likely objection is a Skeptic question | Rehearse the objection until it is plain. Bridges built only from quoted adjacent work, with the limit said first. A ramp plan as a plan | 5 |
| Case / Strategist | Live problems on the roadmap and partner discovery | High. The JD's responsibilities are roadmap, discovery and delivery, and a hiring manager scores structure on them | Clarify, then objective, segmentation, approach, metrics, risks. Think aloud. Challenge one premise | 4 |
| Data-Driven Prober | Adoption metrics, the "30+" figure, and how the client evidence was counted | Elevated. The JD names adoption metrics, the dossier says no baseline is stated, and E1 carries a figure | Know how each figure was counted, or say you do not. Name the weakest assumption first | 4 |
| Pressure / Stress | Time-boxed "why you" and "how much was actually you" | Medium. Hiring-manager rounds sometimes time-box, and the title gap invites a challenge | Hold the quoted position through two follow-ups, then concede the title and roadmap specifically | 3 |
| Conversational | Casual "walk me through" openers and the JD's tooling question | Low to medium. Casual questions are still scored | A 90-second arc with three beats at quoted scope | 2 |

Not included: Peer Evaluator (a hiring-manager round, not a peer) and Values (no values round detected). The session total is 18 questions, with the top persona at depth 5.

## Question banks

### Skeptic (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] dossier prohibited_claims, quoted: "Having held a product manager title or role"; "Having owned a product roadmap". "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Start with the plain acknowledgment: "I haven't held a product manager title or role, and I haven't owned a product roadmap." Then the adjacent work at its scope: "I led integrations from scoping through go-live, and I ran the sessions that fed client evidence to product." Then the limit once: "I haven't set prioritization for an engineering squad." Then the ramp, as a plan: "In the first months I'd want to learn how the squads decide priorities today, and how adoption is measured." Concede the roadmap specifically. Do not add years, titles or decisions | The underwriter named this as the most likely objection. It is built from the R1 sub-claim and the prohibited list, so its premise is sourced and the question is asked as written. Highest-ROI prep in the pack: it will come in some form |
| A2 | "What part of this role would you be weakest at on day one?" | JD | [grounded] dossier prohibited_claims, quoted: "Having owned a product roadmap". Dossier clarify area R5, "Agile delivery experience" | Name the roadmap first, in the plain acknowledgment's words. Then delivery cadence. Answer slot: if you have run sprint-based or similar delivery, say which team and what cadence; if you have not worked that way, say so plainly, and ask what the squads mean by agile delivery before you say more | F2 and F6 are the two weakest rows; this asks for the honest ordered answer |
| A3 | "Have you run discovery with integration partners? Where, and what did you learn?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; JD line "Run discovery with integration partners" | Answer slot: if any of the scoping you led was discovery with a client, say which and what you learned, in your own words. If your part was scoping and requirements rather than discovery, say that, and describe what that step covered | The responsibility is raised by the JD. E1 is the nearest quote, and its scope stops at scoping |
| A4 | "Why this role, and why now?" | JD | [generic] pattern for a motivation probe. Nearest quote: "Ran quarterly roadmap-input sessions feeding client evidence to product" | Say what this role reaches that your current work does not: the decisions that E3 sits next to. Use your own words, and do not claim a motivation you have not stated. The "why now" has no source in your material, so it is yours to supply | Skeptic motivation probe. The pattern is generic; the only claim about you is the E3 quote at its scope |
| A5 | "The role works with engineering, sales and customers. Which of those have you managed directly, and how?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Customers: E1 at its scope. Product: E3 at its scope. Answer slot: engineering and sales are not in your material. If you worked with engineering or sales on an integration, say who and what happened; if you did not, say so plainly, and say how you would build those relationships | F5. The JD raises R4, and the dossier has no weak-area row for it |

### Case / Strategist (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you would decide the first three things on this platform's roadmap, with two engineering squads and adoption metrics to define." | CASE | [generic] role-family case, raised by JD lines "Own the roadmap for the partner-facing API platform" and "Define and track adoption metrics" | Clarify first: which partners, what adoption means, what the squads can take. Then objective, segmentation by integration stage, approach, metrics, risks. Think aloud, and challenge one premise. Make no claim about a roadmap you have run | The role's core case. The label is generic because the case makes no claim about your past |
| B2 | "A partner integration due to go live in six weeks is still in UAT at week five. What do you do?" | CASE | [generic] role-family case. Anchor: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Clarify the cause and the partner's exposure. Then decide: scope, date or risk. You can draw on the UAT step in your integrations at E1's scope, and say what UAT covered there, not what you would claim to have decided | JD line "Write specs and drive delivery with two engineering squads". Anchored on E1 only for the UAT step |
| B3 | "A partner asks for a feature that only they need. How do you decide?" | CASE | [generic] role-family case. Anchor: "Ran quarterly roadmap-input sessions feeding client evidence to product" | Clarify whether this is one partner or a segment, and what evidence the request carries. Then name who decides. Say that E3 sent client evidence to product through sessions, and that you would want to know how product weighs it. If you do not know, say so | A roadmap call that tests R1 authority. E3 is the quote, so the sessions are not described beyond their scope |
| B4 | "Two squad leads disagree on the sequence of the next two releases. What do you do?" | CASE | [generic] role-family case, raised by JD line "Write specs and drive delivery with two engineering squads". Prohibited list: "Having set prioritization for an engineering squad" | First ask which calls are yours and which are the squad leads'. That is the decision-rights question the JD leaves open. Then the path to a decision, and what gets recorded. Do not claim you have set a squad's sequence | Tests the decision-authority unknown directly. The answer is the question about decision rights |

### Data-Driven Prober (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How would you measure adoption of the partner API platform?" | JD | [generic] role-family measurement pattern, raised by JD line "Define and track adoption metrics" | Name the metric, its denominator and its segment, and the assumption you would defend least, in your own words. Answer slot: if you tracked any adoption measure in your integration work, say which and how it was counted; if you did not, say so plainly | The responsibility's baseline is unstated (dossier risk). The metric is a proposal, not a claim about your past |
| C2 | "Walk me through how the 30-plus integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Say what counts as one integration, at E1's scope: end-to-end, from scoping through go-live. Name the assumption you would defend least, then which part was yours. If you do not know how the count was kept, say so | E1 is the only figure in the verified evidence. Defend-the-number slot: the figure stays as quoted |
| C3 | "Did any of those integrations produce a measure you would call adoption? Which one, and how was it measured?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if one did, name it and how it was measured. If none did, say so plainly, and say what you would measure first | Links the adoption responsibility to the one piece of your evidence closest to it. Honest answer either way |
| C4 | "How did you know the client evidence you passed to product was representative?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" | Answer slot: if you checked whether the evidence was representative, say how; if you did not check it, say so, and say what you would check. Keep to the sessions and the evidence they carried | E3 is medium confidence, and the dossier says to expect a probe. Rehearse the limit before it is asked for |

### Pressure / Stress (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over a product manager who has held the title?" | JD | [grounded] dossier prohibited_claims, quoted: "Having held a product manager title or role". "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Hold, then concede. Hold the position you can carry: the adjacent work at its scope, then the limit in the plain acknowledgment. Through two follow-ups, return to the quotes. Concede the title and the roadmap specifically. Never fold into claiming product-management years | Pressure version of A1. The hold is the quoted work, not a stronger claim |
| D2 | "Of those integrations, how much was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer at the sentence's scope: you led them, from scoping through go-live. If any part was not yours, say which, in your own words. If all of it was yours, say so. Do not inflate or shrink the claim | Attribution probe. The truthful answer is the sentence itself |
| D3 | "Name an API or platform product you have shipped. You have sixty seconds." | JD | [grounded] JD line "Shipped API or platform products" | Answer slot: if you shipped one, name it and your part, in your own words. If nothing you shipped was an API or platform product, say so plainly, then give the nearest thing your material carries: the integrations from scoping through go-live (dossier E1) | R2 is a must-have, and the dossier does not classify it as a weak area. Flagged to the underwriter |

### Conversational (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to here." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook her team uses"; "Ran quarterly roadmap-input sessions feeding client evidence to product"; plain acknowledgment from dossier prohibited_claims: "Having owned a product roadmap" | A 90-second arc in three beats, each at its quoted scope: the integrations, the playbook, the roadmap-input sessions. Then the step you have not taken, the title and the roadmap, in the plain acknowledgment's words. Do not add years or dates your material does not state | Casual register, scored. The arc is the three quotes and nothing else |
| E2 | "What are you actually playing with in API docs and schemas these days?" | JD | [grounded] JD line "Technical fluency: API docs, schemas"; "Wrote the internal integration playbook her team uses" | Answer slot: name only the docs or schemas you have actually worked with. If the nearest is the playbook, say what it covers. If you have not worked with schemas, say so plainly. Do not name tools you have not used | R3 coverage. F4 is discovery, so the honest answer is the target |

## Requirement coverage

| Requirement | Question IDs |
|---|---|
| R1: 3+ years product management experience | A1, A2, B4, D1 |
| R2: Shipped API or platform products | D3 |
| R3: Technical fluency: API docs, schemas | E2 |
| R4: Stakeholder management across engineering, sales, customers | A5, B4 |
| R5: Agile delivery experience | A2 (clarify slot only) |
| Responsibility: own the roadmap | A1, B1, B3 |
| Responsibility: run discovery with integration partners | A3 |
| Responsibility: write specs and drive delivery with two squads | B2, B4 |
| Responsibility: define and track adoption metrics | C1, C3, C2, C4 |

## Reverse questions

Asked of the interviewer. There is no interviewer profile, so none ties to a career path, and this is not a peer round, so there is no reciprocity question.

1. "Which roadmap decisions does this PM make alone, and which belong to the squad leads?" Why it lands: the JD asserts decision authority and the material does not evidence it. Their answer tells you whether the role is what it says.
2. "How is partner API adoption measured today, and what is the current baseline?" Why it lands: the baseline is unstated. Asking it reads as diligence, and the answer decides whether the adoption responsibility can be measured at all.
3. "What would make you say in six months that hiring someone from integration work was the right call?" Why it lands: it turns the likely objection into their success criteria, and the answer shows what the ramp has to cover.
4. "Which partner integration problems most often reach the squads, and how do they get to the roadmap?" Why it lands: it tests the seam between partner discovery and squad delivery, which is where the JD's two responsibilities meet.
5. "What did the last person in this role get right in the first 90 days, and what did they struggle with?" Why it lands: it gives you a ramp picture from the employer, and it is a question that rarely gets asked well.

## Sources

**Provided documents.** The dossier, `tuesday-dossier.md`, generated 2026-08-14. Sections consumed: `handoff_to_mock_interview` (verified evidence E1 to E3, uncertain areas, likely objection, risks, employer questions, prohibited claims), and `role_profile` (requirement lines and responsibilities, treated as JD lines). `decision` was read for context only. `evidence_map`, `evidence_state` and `risk_register` are absent from this dossier. The "seven years of integration leadership" figure appears only in the decision prose, so the pack does not rest on it.

**Dossier age.** The dossier is about fourteen weeks old (2026-08-14 against today, 2026-11-19). Quartzline may have changed the posting, the squad structure or the interview loop since then. Re-check the posting and the recruiter's process note before Thursday.

**Date.** 2026-11-19 is a Thursday. If the interview is today, the prep below is a short read. If it is next Thursday, you have seven days.

**Research tier: L1.** Searches 0 of 6, fetches 0 of 2. Both searches were refused by the host's permission check ("Quartzline values" and "Quartzline Product Manager Platform APIs interview"). Nothing was retried.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | Values cheat sheet. Not triggered, since no values round was detected. Moves nothing in this pack |
| 2. Quartzline interview process, product role family | unavailable | Loop structure. Persona weights follow the hiring-manager prior instead |
| 3. Quartzline strategy and recent news | unavailable | CO bank and CASE grounding. The CASE questions are generic as a result |
| 4. Interviewer name and Quartzline | n/a | No name was given, so there was no query to form |
| 5. Representative Product Manager, Platform APIs JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD questions |

Queries sent, both refused: "Quartzline values"; "Quartzline Product Manager Platform APIs interview".

**Grounding gap.** Without research, the pack cannot say what Quartzline's current platform strategy is, and the CASE questions are generic. Treat them as structure practice, not as a read of Quartzline.

## Upgrade menu

- The interviewer's name, with their public footprint → personas weighted from their background, and a reverse question tied to their path. Research on the company was refused in this session, so this needs a session with search allowed.
- Any recruiter note on focus areas or a pre-declared exercise → coverage of that deliverable, and the question banks reweighted to match.
- Hours you have before Thursday → a prioritized schedule, with the objection drill first.
- A fresh underwriting of the current posting → checks R1 and R5 against the current JD, and confirms whether R2 and R4 belong on the weak-area list.
- Deep research (L2), if search is later allowed → up to six further searches and two fetches, covering the strategy brief, interviewer talks and recent org context. It runs only on your consent.
