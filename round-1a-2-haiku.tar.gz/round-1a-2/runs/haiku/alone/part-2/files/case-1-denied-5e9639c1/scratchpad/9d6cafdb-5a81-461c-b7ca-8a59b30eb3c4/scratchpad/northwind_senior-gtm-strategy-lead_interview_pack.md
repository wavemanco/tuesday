# Northwind Data: Senior GTM Strategy Lead, Emerging Products. Interview prep pack

**Interviewer:** Dan Kovac, Director of Sales Strategy. A peer: you would both report to the same VP.
**Round:** one 60-minute conversation. No loop source establishes the loop, so the persona weights rest on the peer relationship and Dan's profile, not on a documented process.
**Built on:** the JD highlights, your notes, Dan's profile and your research note. Outside research did not run (see Sources).

## How to use, and the type key

Personas describe how a question arrives. Types describe what it scores. Guidance is scaffolding for a spoken answer, not a script.

| Type | Meaning |
|---|---|
| VAL | Values and behaviour: how you act, with a story that shows it |
| EXP | Your experience, tested for attribution: what was actually yours |
| JD | The listed role, including the parts you do not yet cover |
| CO | Company and strategy knowledge. None in this pack; see Sources |
| CASE | A live problem, reasoned aloud |

Quoted text is the only thing this pack lets you say about your past. Anything in square brackets other than a label is not used. Where a sentence is missing, the guidance is an answer slot: you fill it in your own words, and "not mine" or "I have not done this" are honest answers.

## Peer-level framing

Dan is a peer, not your manager. He is not scoring you for a hiring decision alone; he is judging what the hire does to his own work. Expect seam questions, not a hiring-manager interrogation. Your strongest move is reciprocity: what you bring to his team, not what you need from it. Do not treat the conversation as a pitch to a boss.

## Prep triage

Prep time was not stated, so no schedule is set. The order below is the order to rehearse in.

1. D1 (the quota and sales-ops objection). This is the highest-ROI prep in the pack, rehearsed with its follow-ups.
2. B1, B2 and B3 (defend your numbers and your analysis).
3. A2 and A4 (attribution on the consensus and the revenue model).
4. The remaining banks, in weight order.

Everything else is insurance.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" (JD highlights) | "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | medium | [grounded] | transferability | Your notes place you in product strategy and ops for nine years. They do not show go-to-market ownership of a new product line, and the bridge stays at that scope: "Nine years in product strategy and ops at a large consumer-tech company." Answer slot: if you set go-to-market direction for a product line, say which and how you decided; if you did not, say what you did do in product strategy and ops. |
| F2 | "identify whitespace across land/adopt/expand/renew" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | discovery | The model is a revenue artefact, but your notes do not show it finding whitespace across the lifecycle stages, and the pack does not assume it did. Answer slot: if you have used a model to find revenue that was not being captured, say where and how; if you have not, say so and say which stage you would start with. |
| F3 | "run independent analysis in SQL and Tableau" (JD highlights) | "skilled in SQL/Tableau" (the coach's notes) | medium | [grounded] | none | The tools are reached. A skill statement with nothing inspected behind it: expect a probe on "independent". Say the tools in your notes' words and be ready to name one analysis you ran alone (see B3). |
| F4 | "partner-motion design experience required" (JD highlights) | "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | medium | [grounded] | transferability | The model is partner economics, not partner-motion design. Stay at the quote's scope: "I built a partner-level revenue model used in carrier negotiations." Answer slot: if you have shaped how partners were recruited, paid or run, say which and how; if the model was your only partner-facing work, say so and say how you would learn partner motion design. |
| F5 | "strong cross-functional influence" (JD highlights) | "set annual volume targets with cross-org consensus" (the coach's notes) | medium | [grounded] | none | The quote reaches the requirement in role terms: cross-organisation agreement. Expect a probe on how the consensus was reached (see A2). |
| F6 | "AI experience a plus" (JD highlights) | "uses AI tools daily" (the coach's notes) | low | [inferred] | transferability | Daily use of AI tools is not AI product experience, and the bridge stays at use. Answer slot: if you have built or shipped something with AI, say what; if not, say you use the tools daily and for what. |
| F7 | Sales-ops and quota-setting fluency. Not in the JD highlights; this is the interviewer's domain. [generic] | "No classic sales-ops or quota-setting experience." (the coach's notes) | none | [grounded] | capability | Your notes say you have no classic sales-ops or quota-setting experience. The pack gives no words for that; the words are yours, and they are not given here. Answer slot: if you have set or defended a target others were held to, say what it was and whom it reached; if not, say that plainly and name what you have done near it. |

Gate rows: none. The highlights contain no gate term (authorisation, licence, location, pay). The full JD may name one; see the upgrade menu.

Analysis: the pack's own observation is that your material shows product strategy and ops, a partner-level revenue model, volume targets with cross-org consensus and a store-surface proposal. It does not show go-to-market ownership of a new product line, partner-motion design, sales-ops or quota work, or independent analysis beyond the tools named. The bridges above carry that limit.

## Prohibited claims

Built locally from the fit snapshot. None of the entries below may be coached, implied or stretched in any answer, hold or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned GTM strategy for a product line | Inflated form of F1 | "Nine years in product strategy and ops at a large consumer-tech company." The material shows product strategy and ops, not GTM ownership. |
| Designed a partner motion | Inflated form of F4 | "I built a partner-level revenue model used in carrier negotiations." The material shows a model, not a motion. |
| Set quotas, or ran quota-carrying sales | Inflated form of F5 and F7 | "Set annual volume targets with cross-org consensus." Volume targets are not quotas. |
| Built AI products | Inflated form of F6 | "Uses AI tools daily." |
| Caused the ~$400M ARR uplift | Inflated form of the store-surface line | "Proposed a store-surface change credited with ~$400M ARR uplift." Credited is not caused. |

## Reading the interviewer

Everything below is from the profile you gave; no outside research on Dan ran.

- **Career pattern:** pricing and monetisation is the spine of his career. He is a Director of Sales Strategy.
- **Self-described style:** "relentlessly data-driven." Every number you give will be taken to its denominator.
- **One early-stage-startup chapter:** a builder story may land with him, but your notes carry no startup chapter, so do not offer one.

Practical implications:

1. Case questions will tilt toward pricing and packaging. Use his vocabulary only where your quotes carry it, which is the partner revenue model.
2. Rehearse every figure to its assumption (B1, B4) before the conversation.
3. A shared professional domain exists: monetisation. The partner revenue model (F2 and F4) is the bridge into it. There is no shared jump to point to.

## Persona table

| Persona | How it shows up | Weight, and why | Counter-strategy |
|---|---|---|---|
| Peer Evaluator | Seam questions between his team and yours; credit and reciprocity | 5. The peer prior is the top weight; a peer's first question is what the hire does to his load | Seam principles, not a claimed map; reciprocity framing (A1, A3, A5) |
| Data-Driven Prober | Denominators, assumptions, attribution of every figure | 5. The peer prior plus his self-description: "relentlessly data-driven" | Know the weakest assumption of each figure before he names it (B1, B2, B4) |
| Case / Strategist | Live problems on whitespace and renewal, pricing-tilted | 3. The JD's whitespace requirement plus his pricing career spine | Clarify, objective, segments, approach, metrics, risks (C1 to C3) |
| Skeptic | Quota and sales-ops gap; partner-motion gap; credit for the $400M | 3. The three largest gaps in the fit snapshot sit in his domain | Hold the quote's scope; concede the gap; give a plan (D1 to D3) |
| Pressure / Stress | Time-boxed challenges to AI and to the $400M | 2. A peer conversation rarely runs as a stress test | Pause, restate, hold through two follow-ups (E1, E2) |
| Conversational / Rapport | Opening biography; casual AI question | 2. Opens the conversation; casual questions are still scored | 90-second arc from quotes; use stays at use (F1, F2) |

Total: 20 questions. Values/Behavioural is not weighted: no values-style round is detected, and the values page was not read.

## Question banks

### Peer Evaluator (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our teams sit side by side. Where is the seam between your GTM work and sales strategy, and what happens when we disagree?" | JD | [generic] persona stem, Peer Evaluator. The one example rests on "set annual volume targets with cross-org consensus" (the coach's notes) | Propose seam principles, not a map you have not seen: who owns a number that two teams both touch, and how a disagreement gets settled. Say plainly that you do not know the seam from outside. Give one example of working across a boundary, in your own words, from the consensus quote. Claim no history with his team. | The Peer Evaluator's opening stem. F5 is the only quote on cross-organisation work, so it supplies the example. The seam presupposes a seam the pack cannot know, so the guidance asks for principles. |
| A2 | "Tell me how the consensus on those volume targets came together. Who had to agree?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Tell the story from the quote's beats: annual targets, set, with cross-org consensus. Say who was in the room and what each wanted, if you know. Answer slot: if you brought the organisations together, say how; if the targets were set by another lead and you were one voice, say that. Add no disagreement or outcome the quote does not carry. | F5 reads as strong, so a peer will ask who did the work. EXP because attribution is what is tested. |
| A3 | "How do you handle credit when a launch spans our teams and yours?" | VAL | [generic] persona stem, Peer Evaluator | Use "we" for the team's context and "I" for your contribution, one sentence each. Name the specific thing you did and who else did it. If you have a case where you gave credit away on purpose, say it. If not, say how you would handle it, as a plan. Do not describe a credit story the material does not carry. | Credit-sharing is a peer probe that arrives in collegial form. No quote carries a credit story, so the guidance is a selection scaffold with its honest branch. VAL because it scores behaviour. |
| A4 | "The partner-level revenue model: which part did you build yourself, and which came from others?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Say what the model was used for, in the quote's words: built, partner-level, used in carrier negotiations. Then the split: what you built and what others supplied, in your own words. Answer slot: if others supplied inputs or the framing, name them and what you did with them; if you built all of it, say so. | F4 is the partner-motion evidence and the richest attribution probe. The quote fixes the scope. |
| A5 | "What would you bring to my team in the first quarter, and what would you need from us?" | JD | [generic] persona stem, Peer Evaluator. The reciprocity framing rests on no quote | Lead with what you would take off his team's plate, a piece of GTM analysis tied to the role's own list, then one specific ask. Do not describe a pipeline plan for his team that you have not seen. | Reciprocity is the Peer Evaluator's counter-strategy. He is testing whether the hire adds to or lightens his load. No claim about your past is made. |

### Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how that $400M figure was counted." | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" (the coach's notes) | Use the quote's words: proposed, credited with, about 400 million ARR uplift. Then the four defend-the-number moves in your own words: how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you know how it was counted, say so; if you did not count it yourself, say that plainly and say which part of the work you did. Never supply a method. | The most probed figure in the record. Defend-the-number applies to any headline figure. |
| B2 | "How did you set the annual volume targets? What did you look at, and what would have changed the number?" | EXP | [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | Describe the targets in the quote's terms: annual, set, with cross-org consensus. Then name the input you looked at and the one that would have moved the target, in your own words. Answer slot: if you chose the inputs, say which; if you did not, say what you brought to the discussion. No baseline or method is supplied here. | Volume targets are the nearest thing to quotas in your record, which makes this the prober's route into F7. The rehearsal is attribution, not the number. |
| B3 | "Tell me about an analysis you ran yourself, end to end. What did you check before you trusted it?" | JD | [grounded] "skilled in SQL/Tableau" (the coach's notes) | Open prompt. Pick one analysis you ran alone. Name the tool in your notes' words and what question it answered. Say what you checked before trusting it. If none was run alone, say so, then give the nearest analysis you did and who else touched it. Describe no analysis your notes do not carry. | The JD asks for independent analysis. The notes say "skilled", which is a self-description, so expect a probe on "independent". |
| B4 | "What did the partner revenue model take as inputs, and which input would you doubt most?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Name the inputs you can list, in your own words. Name the one you would doubt most before he does; that is the weakest-assumption move. Answer slot: if you cannot list the inputs, say so and say what you would check first. Name no inputs your notes do not carry. | F4's model is the most inspectable artefact in your record, and the prober's natural target. Naming the weak assumption first turns a challenge into credibility. |
| B5 | "Tell me about an analysis you ran that changed a decision. What did it change?" | JD | [grounded] "skilled in SQL/Tableau" (the coach's notes). The scenario rests on no quote | Open prompt. Choose one instance where your analysis changed a decision. If none comes to mind, say so plainly, then give the nearest analysis your notes carry and what you would do to make one happen. Keep to what the analysis changed; do not add how the decision-makers reacted. | Pairs with B3 on the independent-analysis requirement. A decision outcome is the proof a prober looks for, and the notes supply none. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "If a much larger platform vendor bundled a comparable product, where would the whitespace be across land, adopt, expand and renew?" | CASE | [generic] case built from the JD requirement "identify whitespace across land/adopt/expand/renew" (JD highlights) | Clarify first: what the bundle includes, which customers it reaches, what you can measure. Then the objective, the segments, the approach stage by stage across land, adopt, expand and renew, the metrics, and one risk. Name one premise you would challenge. Use pricing and packaging language where it fits; a bundle is a packaging question. Claim no past work on this. | A live problem from the JD's whitespace line. The bundling threat appears only in your research note, which is not a raising source, so the question is hypothetical and presupposes nothing. CASE because it scores structure. |
| C2 | "How would you price an AI add-on for an enterprise account so it adds spend without cannibalising the core?" | CASE | [generic] role-family pricing case. Dan's pricing lens rests on his public career pattern, from the profile you gave | Clarify what cannibalising means for this account. Then the unit economics: what the add-on costs to serve, what it is worth to the buyer, where it sits in the package. State one assumption you would test first. If you have done no pricing work, say you would test it. | Dan's career spine is pricing and monetisation, so the case leans toward his native language. AI is a JD plus. Generic because no source confirms Northwind's pricing. |
| C3 | "Renewal rates fall in one segment. Diagnose it." | CASE | [generic] role-family metric diagnosis. The renew stage is the JD's line "identify whitespace across land/adopt/expand/renew" (JD highlights) | Clarify the metric and how the segment is defined. Segment the drop before naming a cause: by product, tenure, size, channel. Give two hypotheses and what each predicts. Name the first data cut you would run and the metric you would check it against. | A strategist diagnosis on the renew stage. A prober also watches the denominator, so define the segment first. |

### Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't run sales ops or set quotas. Why would I trust you with go-to-market for two new product lines?" | JD | [grounded] "9 at a large consumer-tech company in product strategy & ops" (the coach's notes). [grounded] "set annual volume targets with cross-org consensus" (the coach's notes) | **Highest-ROI prep.** Hold, then concede. First the nearest thing you did, at the quotes' scope: nine years in product strategy and ops, and annual volume targets set with cross-org consensus. Hold that position through two follow-ups by returning to what you did, not adding to it. Then concede in one plain sentence that you have not run sales ops or set quotas. Then the plan: what you would learn first and from whom. Answer slot: if you have set or defended a target others were held to, say what it was; if not, say so, and do not stretch the volume-target line into quota work. | F7 is the largest gap, and the interviewer owns the domain. This objection will arrive in some form. Deepest rehearsal: the most follow-up levels and an explicit concession, with no more than the quotes carry. |
| D2 | "That $400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with ~$400M ARR uplift" (the coach's notes) | Hold the quote's own words: you proposed the change, and the uplift is credited with it. Do not say you delivered the uplift. Concede what you cannot claim: credit is not your share of the result. Then say what you did as the proposer, in your own words. Answer slot: if you did more than propose it, say what; if others built or measured it, say so. | "Caused the $400M" is on the prohibited list. This is B1's objection at its hardest, so the hold is the quote's scope. |
| D3 | "Your record shows a partner-level revenue model. What is your experience designing a partner motion?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" (the coach's notes) | Hold the quote at scope: you built a model, and it was used in negotiations. A partner motion is a different thing: how partners are recruited, paid and run. Answer slot: if you have shaped any of those, say which and how; if not, say that plainly, and say how you would learn it, as a plan rather than a past. | F4 is the partner-motion requirement, rated transferability. The skeptic's probe is the gap, and the honest answer is a limit with a plan. |

### Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you over someone who has run quota-carrying sales strategy?" | JD | [generic] pressure stem from the persona file. The anchor is "9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | Pause. Restate the question in your own words. Answer in three beats: the nine years in product strategy and ops, the cross-org consensus on targets, the plan for the quota gap. Hold through two follow-ups. Claim no quota experience. Concede the gap in one sentence, then move to the plan. | A time-boxed version of D1. It tests composure under the same objection. |
| E2 | "You list AI as a plus, and you use AI tools daily. That's not experience, is it?" | JD | [grounded] "uses AI tools daily" (the coach's notes) | Hold the quote's scope: you use AI tools daily. Name the tasks, in your own words. If daily use is not AI product work, say so plainly. Do not extend the claim to building or shipping anything. | The JD lists AI as a plus. Pressure tests whether daily use is presented honestly. The inflated form is on the prohibited list. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" (the coach's notes) | A pre-scripted 90-second arc from the quotes alone: two years of strategy consulting at a top firm, then nine years at a large consumer-tech company in product strategy & ops. Mark two moves: the partner revenue model and the consensus targets. End on why this role follows. Add no outcome the quotes do not carry. | Biography is the most likely opener, and a casual register is still scored. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily" (the coach's notes) | Casual but scored. Name the tools you use and one task each does for you, in your own words. Keep to use. If you have built something, say what; if not, say you use them and stop there. List no tool you have not used. | AI is a JD plus, and the casual register hides the score. The guidance keeps use at use. |

## Requirement coverage

| JD requirement | Question IDs |
|---|---|
| own GTM strategy for two new product lines | C1, D1, E1 |
| identify whitespace across land/adopt/expand/renew | C1, C3 |
| run independent analysis in SQL and Tableau | B3, B5 |
| partner-motion design experience required | D3, A4 |
| strong cross-functional influence | A1, A2, A3 |
| AI experience a plus | E2, F2 |
| Not in the JD highlights: sales-ops and quota fluency (interviewer's domain) | D1, E1 |
| Not in the JD highlights: pricing and monetisation (interviewer's domain) | C2 |

No JD requirement is left uncovered. The highlights are the only JD text, so mid-list items may be missing (see the upgrade menu).

## Reverse questions

Ask these in your own words. Each one has a "why it lands."

| # | Question | Why it lands |
|---|---|---|
| R1 | "Your career has run through pricing and monetisation. Which pricing question does your team keep coming back to?" | Ties to his own path, which converts an interview into a peer conversation and shows you looked at him. |
| R2 | "What could a new person do in their first month that would genuinely help your team?" | The reciprocity question. Peers weight it heavily as a preparation signal. |
| R3 | "Where do emerging-products and sales-strategy numbers disagree today?" | Names the seam directly, which is the question A1 turns on. |
| R4 | "If a much larger platform vendor bundled a competitor's product, who owns the response on your side?" | Hypothetical, so it does not assert a threat. It finds the owner of the question C1 tests. |
| R5 | "How does the push toward profitability show up in the decisions you see each week?" | Asks what the constraint means in practice, without asserting the priority from the research note, which is unverified. |

## Sources

- **Provided documents:** your notes on the candidate; the JD highlights (six lines, not the full posting); Dan's profile as you described it; your research note (three priorities: enterprise expansion, an AI copilot launch called Compass, reaching profitability; a competitive threat of bundling by a much larger platform vendor). The note is undated, so it is treated as unverified.
- **Calls made:** three web searches, each refused because search permission was not granted in this session. No fetches were sent.

Research tier: L1, searches 3 of 6, fetches 0 of 2. No link was read.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind Data values | unavailable | Section 10 would need a values-style round, which needs a loop source; the values page alone would not have brought it in. Query "Northwind Data values" was refused. |
| 2. Northwind Data interview process, sales strategy | unavailable | Loop structure, and whether a values round exists. Query "Northwind Data interview process sales strategy" was refused. Persona weights rest on the peer relationship instead. |
| 3. Northwind strategy and recent news | skipped | Your research note supplies the priorities and competitive frame, though it is undated. The note answers the target, so no search was sent. |
| 4. Dan Kovac, Northwind | unavailable | The interviewer read, persona weights and a tailored reverse question. Query "Dan Kovac Director of Sales Strategy Northwind Data" was refused. The read rests on your profile alone. |
| 5. Representative JD | skipped | The JD highlights were supplied, so no representative posting was needed. |

No tuesday-dossier.md was present.

## Upgrade menu

- Permission for web search, or the Northwind values page and Dan's public profile pasted in → rows 1, 2 and 4 would move from unavailable to yes, and would bring the interviewer read and a tailored reverse question. A deeper research pass (up to six more searches and two more fetches, several minutes) is available once, on your request.
- The full JD text → any gate rows, and the mid-list requirements the six highlights leave out, which currently have no questions.
- Your own sentence on sales-ops and quota work → a plain acknowledgment would replace the answer slots in D1, E1 and F7.
- The recruiter's note on the session structure → confirms whether this is a single session or part of a loop, and sets the persona weights to match.
- A dated Northwind strategy source → verifies the three priorities and the bundling frame, and enables CO questions, which are absent now.
- A tuesday-dossier.md → verified evidence and prohibited claims from a dossier in place of the local ones.
