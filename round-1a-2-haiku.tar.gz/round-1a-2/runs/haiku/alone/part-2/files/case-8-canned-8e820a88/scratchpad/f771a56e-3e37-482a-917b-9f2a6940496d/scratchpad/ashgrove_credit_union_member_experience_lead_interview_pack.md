# Interview prep: Member Experience Lead, Ashgrove Credit Union

**For:** Dara. **Interview:** 28 November 2026, three rounds. **Built on:** your background message, the JD as you pasted it, the values you copied on 19 November 2026, your summary of the July 2026 strategy brief, and the recruiter's email. No research was run (tier L0), so the pack contains no outside facts.

**Assumption:** the regulated-complaints requirement is treated as a gate the material does not establish, until you answer the one question in the message.

## How to use this pack

Personas describe how a question arrives. Types describe what is being scored.

| Type | Meaning |
|---|---|
| VAL | Behaviour against Ashgrove's published values |
| EXP | What you actually did in your past roles, and whether it survives scrutiny |
| JD | Can you do the listed job, including its gaps |
| CO | Strategy and company knowledge |
| CASE | A live problem from the role, answered aloud |

Guidance is scaffolding, not a script. Each guidance cell is written to be said in 90 to 120 seconds. Anything in quotation marks is your own sentence, quoted from your message, the JD, the values page you copied, or the strategy summary you gave me.

## Fit snapshot

Each requirement from the JD, set against your own words.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | high | [grounded] | none | No gap. Say the years and the role in those words. Describe the branch work in your own terms; do not relabel retail banking as customer operations. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | hard_gate | Your material does not establish the regulated timescales or steps. No bridge is written for this row. The one question in this message asks whether it is met. |
| F3 | "own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows a branch-level log, not end-to-end ownership. Words: "I handled the branch's formal complaints log." Answer slot: if you owned any step from first contact to close, say which and how you decided; if you did not, say so and stay with the log. |
| F4 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Your stated absence, so the words come from it: "I've never worked in a contact centre." Then how you would learn the contact-centre side, as a plan and never as a past. |
| F5 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | discovery | The material shows a monthly spreadsheet and does not show whether it tracked volumes or resolution times. Answer slot: if it tracked resolution times, say how it counted them and which figures; if it did not, say so and say what you would measure first. |
| F6 | "coach branch supervisors on escalations" (JD) | "I trained new tellers on our escalation script" (your message); "the last 3 as a branch supervisor" (your message) | medium | [grounded] | transferability | The quote carries training tellers, not coaching supervisors. Words: "I trained new tellers on our escalation script." Answer slot: if you coached a supervisor on an escalation, say how; if you did not, say so and say what carries over from training tellers. |
| F7 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show digital work. Answer slot: if you worked with a digital or self-service team, say what the journey was and your part in it; if you did not, say so plainly and say how you would start. |
| F8 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Your stated absence, so the words come from it: "I've never presented to anyone above regional level." Then how you would prepare, as a plan. |
| F9 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms. Say what you built. Name Excel only if it was Excel; the material does not say which tool it was. |

**Gap types used above:** hard_gate (F2), transferability (F3, F6), capability (F4, F8), discovery (F5, F7), presentation (F9), none (F1).

## Prohibited list

Claims this pack will not coach, and why. Each entry gives its basis and the honest form to use instead.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns the complaints process end to end across branches and the contact centre | Inflated form of F3 | "I handled the branch's formal complaints log." The limit is the pack's own observation: your material shows one branch's log. |
| Has worked in contact-centre complaints | Sourced negative, F4 | "I've never worked in a contact centre." |
| Has regulated complaints handling experience | Inflated form of "formal complaints log", F2 | The log, at its own scope. The regulated-timescales question is asked in this message. |
| Coached branch supervisors on escalations | Inflated form of F6 | "I trained new tellers on our escalation script." |
| Reports resolution times monthly | Inflated form of F5 | "I built the monthly complaints spreadsheet our regional manager uses." Resolution times fall to the answer slot. |
| Presented to senior leaders | Sourced negative, F8 | "I've never presented to anyone above regional level." |

## Personas and weights

Relationship priors set the start. The recruiter's email makes the panel the values round, so values are scored in the loop regardless of what happens in the other rounds. The interviewers beyond the recruiter and Head of Member Services are not yet named, so the panel is weighted by blend.

| Round | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| 1, recruiter | Conversational, with light Skeptic | Friendly opener, logistics, one challenge on contact-centre experience | High for logistics, since the recruiter is screening pay, notice, location and reason for leaving. Light Skeptic on F4. The risk is treating this round as unscored. | Pre-scripted 90-second arc. Treat logistics as scored. Give the true answer to each. |
| 2, Head of Member Services | Skeptic (top weight), then Case/Strategist, then Values/Behavioural | Probes the scope gap, the regulated gate and presenting. Strategy questions as live problems. Mostly behavioural stories. | Top weight to Skeptic because the JD's scope and regulated-complaints lines map to F2, F3 and F4, and they will manage you. Case/Strategist next because the strategy brief gives them live problems. | Rehearse the scope objection until it is boring. Hold, then concede the specific gap. Answer case questions by walking the problem aloud. |
| 3, panel of two branch managers | Values/Behavioural (top weight), then Pressure, then Data-Driven Prober, then Case | Four values scored one by one. Pressure on the spreadsheet and presenting. Prober on the monthly numbers. The 20-minute escalation case. | Values is guaranteed by the recruiter. Pressure and Prober follow F5, F8 and F9. Case is the 20-minute escalation case. | Map a story to each value where your sentences carry one, and say so where they do not. Hold, then concede. Say the first thing you would ask in the case. |

Depth follows weight: Skeptic in round 2 has four questions, Values in round 3 has four plus the case.

## Question banks

### Round 1: Recruiter screen (30 minutes)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through your background." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" (your message); "I handled the branch's formal complaints log" (your message) | A 90-second arc: the six years, the last three as a branch supervisor, then the complaints log. Say only what those sentences say. | Conversational opener, scored for economy. F1 and F3 are the evidence. |
| A2 | "What are your pay expectations for this role?" | JD | [generic] logistics slot; no claim about you | Instruction: give your own number, or ask for the band first. The pack supplies no figure. | Pay is a knockout check. The only safe answer is yours. |
| A3 | "What's your notice period?" | JD | [generic] logistics slot; no claim about you | Instruction: give your actual notice period in your own words. | Notice is a knockout check. |
| A4 | "Which branches or hubs could you work from?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" (strategy summary you gave me) | Instruction: name the locations you can work from, in your own words. Mention the 2027 hubs only if you want to. | The hub consolidation makes location a live question. |
| A5 | "Why are you leaving your current role?" | EXP | [generic] logistics slot; no claim about you | Instruction: give your own reason, in your own words. The pack supplies none. | Reason for leaving is a logistics check, and it is scored for consistency. |
| A6 | "Have you worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre" (your message) | Plain acknowledgment: "I've never worked in a contact centre." Then the limit, stated as a limit: "What I do bring is the branch's formal complaints log." Do not claim contact-centre work. | F4 is a stated gap the recruiter can screen on. A plain answer stops it from becoming a cut. |

### Round 2: Head of Member Services (45 minutes, mostly behavioural)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Take me through a complaint you handled from first contact to closure." | EXP | [grounded] "I handled the branch's formal complaints log" (your message) | Tell one complaint from the log, in your order of events. Answer slot: the outcome and the time it took, if you have them. If you do not, say so. | Behavioural opener. F3's quote is the evidence. |
| B2 | "You've run one branch's complaints. Owning the process across branches and a contact centre: which part have you never done?" | JD | [grounded] "I handled the branch's formal complaints log" (your message); "Never worked in a contact centre" (your message) | **Highest-ROI prep in this pack.** Hold: "I handled the branch's formal complaints log, and I've never worked in a contact centre." Hold through two follow-ups by returning to the log. Concede specifically: "The contact centre is the part I haven't done." Then say how you would learn it, as a plan. | The most predictable objection: the scope gap in F3 and F4. A rehearsed, non-defensive answer changes this interview. Depth: this question gets the most follow-up rehearsal. |
| B3 | "What does a regulated complaint need, from first contact to final response?" | JD | [grounded] "I handled the branch's formal complaints log" (your message) | Say the steps you know and where your knowledge stops. Then say what you would check first. Answer slot: if you ran any regulated step, say which and how; if you did not, say so plainly. | Regulated complaints is the JD's gate, and your material does not establish it (F2). The one question in this message asks about it. |
| B4 | "Forty per cent of member service is moving to digital by 2028. How would a complaint raised in the app reach you?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (strategy summary you gave me) | Structure: where the complaint enters, how the member is identified, one owner, the timescale kept visible, and what the monthly report records. Structure only; no past digital work claimed. | A strategy-grounded case. Delivery is a live problem, which the Case persona scores. |
| B5 | "Eight branches become five hubs in 2027. What happens to complaints open at a branch that closes?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (strategy summary you gave me) | Structure: list open cases, name an owner for each, tell the member what changes and when, keep each timescale, and say what the town hears. | A strategy-grounded case that ties to the Neighbours, Not Numbers value. |
| B6 | "Have you worked with a digital team on a self-service journey? If yes, what was your part; if no, how would you start?" | JD | [grounded] "work with digital teams on self-service journeys" (JD) | Answer slot: if you worked on a self-service journey, say your part; if not, say so plainly and describe how you would start with a digital team. | F7 is a discovery gap. The question states the JD's line without assuming your answer. |
| B7 | "A supervisor brings you an escalation they handled badly. How do you coach them?" | JD | [grounded] "I trained new tellers on our escalation script" (your message); "coach branch supervisors on escalations" (JD) | Structure: ask what the supervisor did and why, check it against the script, agree the next step, then follow up. Answer slot: if you coached a supervisor on an escalation, say how, in your words; if not, say so and say what carries over from training tellers. | F6 is a transferability gap. The honest branch names the tellers, not supervisors. |
| B8 | "Tell me about a time you had to tell a senior person something they didn't want to hear." | VAL | [generic] selection scaffold; no quoted sentence carries it | Pick a time you had to say something unwelcome to someone senior. It needs a named stake, a moment you did not soften it past recognition, and what happened after. If no such time comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | A Skeptic and Pressure stem. Your material carries no case above regional level, so expect the honest branch. |

### Round 3: Panel of two branch managers (60 minutes, including a 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a decision you made from the member's side of the counter." | VAL | [generic] selection scaffold; nearest sentence: "I handled the branch's formal complaints log" (your message) | Pick a moment when a member's need changed what you did. Say what the member needed, what you chose, and what it cost. If none comes to mind, say so plainly, then give the nearest thing the log carries, and how you would decide. | Members First. The panel scores it. |
| C2 | "Tell me about a time a member needed something explained twice. What did you do?" | VAL | [grounded] "I trained new tellers on our escalation script" (your message) | Story anchor: the script and the new tellers. Answer slot: if you changed how the script was explained after someone did not follow it, say what changed and why; if you did not, say so and say what you would change now. | Plain Words. The nearest sentence is training, not a member, so keep it at that scope. |
| C3 | "Tell me about a complaint where the town it came from mattered to how you handled it." | VAL | [generic] selection scaffold; no quoted sentence carries it | Pick a complaint where local context changed the handling. Say what you knew about the place and what you did. If none comes to mind, say so plainly. Do not claim local knowledge your material does not show. | Neighbours, Not Numbers. The panel scores it. |
| C4 | "Tell me about a complaint you kept hold of until it was solved, even after it moved to someone else's desk." | VAL | [grounded] "I handled the branch's formal complaints log" (your message) | Tell a case from the log that you kept until it closed. If you handed complaints on, say so and why. | Own the Fix. The log is the evidence. |
| C5 | "How much of the result on your complaints spreadsheet was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Hold: "I built the spreadsheet." Through two follow-ups, separate what you built from the figures. Concede the part you cannot vouch for, specifically, in your own words. | A Pressure question. The honest answer is the separation, not a defence of the numbers. |
| C6 | "How does your spreadsheet count a complaint as resolved, and which assumption behind it would you defend least?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." (your message) | Answer slot: if the sheet counted resolution, say how, in your words, and name the assumption you would defend least. If it did not record resolution times, say so plainly and say what you would measure first. | A Data-Driven Prober question on F5. The resolution-time requirement is a discovery gap. |
| C7 | "You've never presented above regional level. Why should senior leaders trust a Member Experience Lead's monthly numbers?" | EXP | [grounded] "I've never presented to anyone above regional level." (your message) | Hold: the numbers are only as good as the method behind them, and the method is what you can walk through. Concede: "I haven't presented above regional level," then say what you would do first, as a plan. Do not claim executive experience. | F8 is a capability gap. Pressure tests whether you hold without bluffing. |
| C8 | Case, 20 minutes: "A member's complaint has been open 40 days and has moved between the branch and the contact centre twice. They're at your counter, angry. You have twenty minutes. What do you do?" | CASE | [grounded] "Own the member complaints process end to end across branches and the contact centre" (JD) | Structure: stop the handoffs and name one owner; speak to the member; check the timescale and what is owed; decide the fix within your authority; agree what the branch and the contact centre each do; record the decision and the cause; follow up. Say the first question you would ask. No claim about past cases. | The 20-minute case from the recruiter's email. Own the Fix and the JD's end-to-end line. |

## Requirement coverage

| JD requirement | Question IDs | Note |
|---|---|---|
| 4+ years in financial-services customer operations | A1 | Met on your stated years. |
| Experience handling regulated complaints | B3 | Hard gate; one question in this message. |
| Own the process end to end across branches and the contact centre | B2, C8 | The scope objection is B2. |
| Report monthly on volumes and resolution times | C5, C6 | F5 is a discovery gap. |
| Coach branch supervisors on escalations | B7 | F6 is a transferability gap. |
| Work with digital teams on self-service journeys | B4, B6 | F7 is a discovery gap. |
| Confident presenting to senior leaders | C7 | F8 is a capability gap. |
| Comfortable with Excel reporting | C5, C6 | F9 is a presentation gap. |

Recruiter logistics (pay, notice, location, reason for leaving) are not JD requirements, so they are not in this table. They are A2 to A5.

## Values cheat sheet

Ashgrove's four values, as you copied them on 19 November 2026.

| Value | Working meaning | Your story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No quoted sentence carries a decision of this kind. Selection scaffold, with its honest branch, in C1. Nearest sentence: "I handled the branch's formal complaints log." |
| Plain Words | If a member needs it explained twice, the writing was wrong | "I trained new tellers on our escalation script." Story anchor in C2, at the scope of training tellers. |
| Neighbours, Not Numbers | Every branch is part of its town | No quoted sentence carries it. Selection scaffold, with its honest branch, in C3. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | "I handled the branch's formal complaints log." Story in C4, plus C8 for the case. |

## Grounding: the strategy you gave me

Current framing, as you summarised the July 2026 brief. I have not read the brief itself.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

Before the panel, check each figure against the published brief. Use the brief's own wording in the room, not your summary.

## Reverse questions

Ask two or three. Each has a reason it lands.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a good first ninety days look like for the complaints process across branches and the contact centre?" | Asks what success means in the role, and shows you are planning to own the end-to-end process. |
| R2 | "As the five hubs come in during 2027, how do you expect complaints to be routed?" | Uses the strategy brief in their own terms. Shows you read it. |
| R3 | "Where does a complaint raised through the app or online tend to get stuck today?" | Asks for the real picture on digital. Signals interest in the 40% target. |
| R4 | "What does senior leadership ask for in the monthly complaints report, and what is missing from it today?" | Leads into the presenting gap, and shows you would fix it rather than hide it. |
| R5 | "Which branch supervisors find escalations hardest to handle, and what would help them most?" | Ties to the coaching requirement. Role-generic: no interviewer profile was given, so there is no personal tie. |

## Sources

- **Provided:** the JD as you pasted it; the values as you copied them from ashgrovecu.org/about/values on 19 November 2026 (I did not fetch them); the recruiter's email; your summary of the July 2026 strategy brief (I did not read the brief); your background message.
- **Research tier:** L0. No searches or fetches were run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | Fixed by the values you pasted. Feeds the values cheat sheet. |
| 2. Interview process | skipped | Fixed by the recruiter's email: three rounds, their content and the values scoring. |
| 3. Strategy and recent news | unavailable | Not run at L0. Would have checked for moves after July 2026; the summary you gave covers the July brief only. |
| 4. Interviewer name | n/a | No names given for the Head of Member Services or the panel. |
| 5. Representative JD | skipped | Fixed by the JD you supplied. |

## Upgrade menu

- Your answer to the one question in this message → B3 and F2 move from a hard gate to grounded, or become a plain limit.
- The Head of Member Services' name → an interviewer read and tailored reverse questions (R5 gains a personal tie).
- The panel's names → per-member persona weights for round 3.
- The published strategy brief or a link → checks the figures in B4, B5 and the grounding section against the source.
- Your complaints spreadsheet's column headings, with no data → C5 and C6 become grounded in the sheet's own terms, and F5 moves toward presentation.
- Deep research (L2), offered once → adds the interviewer's public footprint, recent organisation news and loop reports for this role family. Caps: six further searches and two further fetches.
- A `tuesday-dossier.md` from job-underwriter → verified evidence for F rows and a checked list of claims to avoid.
