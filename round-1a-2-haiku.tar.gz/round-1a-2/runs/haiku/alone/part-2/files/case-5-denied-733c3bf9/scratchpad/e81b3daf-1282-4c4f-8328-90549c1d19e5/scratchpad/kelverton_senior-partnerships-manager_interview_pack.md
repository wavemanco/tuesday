# Senior Partnerships Manager, Kelverton Rail: second-round prep pack

**Role:** Senior Partnerships Manager. **Company:** Kelverton Rail. **Round:** second round, panel, 60 minutes: a 15-minute spoken POV (no slides), then Q&A.
**Panel:** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director). Ross will push on commercials.
**Built on:** your message and the recruiter's email as you quoted it. No JD, no CV and no research yet, so this is a first version. The market report was not available to me.

## How to use this pack

Personas are how a question arrives. Types are what is being scored:

- **EXP**: what you actually did, and whether the figures hold up.
- **JD**: whether you can do the listed job, gaps included.
- **CO**: company and strategy knowledge. None in this pack, because no research has run.
- **CASE**: a live problem, reasoned aloud.
- **VAL**: values. None in this pack, because no values round is established.

The guidance is scaffolding, not a script. Rehearse your own words.

## Prep triage (about 4 hours)

1. **75 min: the POV (section "Graded deliverable: the POV").** Pick T1 as the thesis and close on T3. Say it aloud twice and time it: aim for about 9 minutes, which leaves room for interruptions.
2. **60 min: Ross's bank (A1 to A8).** Drill A5 hardest: the quota question is the highest-ROI prep in this pack. Rehearse three follow-ups, not one.
3. **40 min: Deepa's bank (B1 to B7).** B1 (the first 90 days) and B5 (what you would be weakest at) first.
4. **45 min: two live drills**, one against Ross on Pressure and one against Deepa on Case (see the drill offer in the message).
5. **10 min: reverse questions**, then a final read of the POV close.

Everything else is insurance.

## Fit snapshot

Requirements come from the recruiter's email, quoted. There is no JD, so rows with a `[generic]` requirement raise no answer slot; they carry only the candidate's own stated absences.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Ross will push on commercials." (recruiter's email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material shows influenced revenue, not a target you carried. Bridge: "I took it from 6 partners to 40, roughly £4M of influenced revenue." Answer slot: expect a probe on how the £4M was counted and which part was yours to shape. If you can say, say so in your own words; if it was credited to others, or you cannot say how it was counted, say that plainly. |
| F2 | "what it means for the operators themselves" (recruiter's email) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | presentation | The quote already reaches the requirement. Bridge: "I know the operator world from the other side." Answer slot: expect a probe on which operator decisions you saw up close. If you were in the room for one, say which; if you advised from outside, say that. |
| F3 | sales into rail operators (role family, no source) | "Never sold into rail specifically" (your message) | none | [grounded] | capability | The candidate stated the absence. Words: "I haven't sold into rail specifically." Then how you would learn rail buying, said as a plan, never as a past. |
| F4 | direct sales quota ownership (role family, no source) | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | The candidate stated the absence. Words: "I've never carried a direct quota." The influenced-revenue quote may follow it, at its own scope. |
| F5 | "where you'd take our operator partnerships over the next 18 months" (recruiter's email) | "9 years in partnerships" (your message) | medium | [grounded] | transferability | Nine years of partnership work reaches partnerships, not operator partnerships. Bridge: "I've spent nine years in partnerships." The 18-month plan is a plan, not a past. Answer slot: if you have run a multi-year partner plan, describe one in your own words; if not, say so and present the 18-month view as a plan. |

Where the material is silent: the material does not show how Kelverton's operators buy, how many operators it serves or what its commercial targets are. Those are not gaps in your record. They are things to ask in the room.

## Prohibited claims

Built locally from the fit snapshot. None of the guidance below may assert, soften or imply these.

| Not coached | Basis | Honest form |
|---|---|---|
| "I sold into rail" | Stated negative, F3 | "I haven't sold into rail specifically." |
| "I carried a quota" | Stated negative, F4 | "I've never carried a direct quota." |
| "I drove £4M of revenue" | Inflated form of F1 | "roughly £4M of influenced revenue." The limit is the pack's observation: your material says influenced, not sourced or closed. |
| "I designed the ISV channel model" | Inflated form of F1's "running the ISV channel" | "running the ISV channel" |
| "I know how operators buy" or "I've bought from operators" | Inflated form of F2 | "I know the operator world from the other side." |
| "The 40 partners came from my playbook alone" | Inflated form of F1 | "took it from 6 partners to 40" |

## Interviewer read

Dropped. You gave names and titles only. No public footprint has been checked, so persona weights rest on round-type priors, below.

## Persona table

| Member | Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Ross | Data-Driven Prober | "Walk me through how that number was counted." | High. The recruiter says Ross will push on commercials, and your revenue figure is influenced, not sourced. | Name the weakest assumption before he does. |
| Ross | Pressure | "How much of that was actually you?" | High. The quota gap is the obvious pressure point. | Hold the position through two follow-ups, then concede the absence plainly. |
| Deepa | Case / Strategist | A live problem: the first 90 days, the operator's planning cycle. | Medium-high. A hiring manager buys capability and reasons on live problems. | Clarify before structuring. |
| Deepa | Skeptic | "Which part of this role would you be weakest at on day one?" | Medium-high. The rail and quota gaps are her likely probes. | Plain acknowledgment, then a ramp plan. |
| Both | Conversational | A warm opener, "walk us through the journey." | Low-medium. A panel usually opens friendly, and the opener is still scored. | A 90-second arc. |
| Both | Peer Evaluator | A seam with product or sales. | Low. It can come from either member. | Seam principles, not invented detail. |

## Graded deliverable: the POV

**Declared by the recruiter:** a 15-minute spoken POV on "where you'd take our operator partnerships over the next 18 months", landing on "what it means for the operators themselves". No slides.

**Grounded facts to build on:**
- F2: "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"
- F1: "took it from 6 partners to 40, roughly £4M of influenced revenue"

**Theses (each with a concession):**

- **T1. Build around the operator's planning calendar, not the product release cycle.** Grounded in F2. Concession: I don't yet know how Kelverton's operators plan change or on what cycle, and that differs by operator and by contract. I'd check two operators before committing. (The planning-calendar claim is `[generic]`.)
- **T2. Fewer, deeper operator partnerships, not the 40-partner playbook.** Grounded in F1. Concession: the ISV channel model may not transfer to a small set of large operators. I'd treat the playbook as a hypothesis, not a plan.
- **T3. Measure partnerships by operator outcome, with one commercial link Ross can hold.** Grounded in F1's influence measure. Concession: operator outcomes are hard to attribute to a scheduling tool, and they are often not the operator's to share.

**Recommendation:** lead with T1, close on T3 as the commercial bridge, and keep T2 as the anti-pick: say plainly that a partner-count target is not the headline.

**Differentiation:** the consensus answer is generic, such as better integrations, data sharing or consolidation `[generic]`. I have not seen the market report, so I can't yet tell which thesis it already leads with. Check that before the panel and avoid reciting it.

**What it means for the operators:** name one concrete operator outcome you actually believe, for example fewer changes re-planned late `[generic]`. Say it as your claim, not as the report's.

**Speaking build (about 9 minutes):** the operator's problem (2 min), T1 (3 min), the commercial bridge T3 (2 min), what it means for operators (1 min), the concession (1 min).

## Question banks

Ross, Data-Driven Prober and Pressure (weight: top, 8 questions).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how that £4M of influenced revenue was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" | Defend the number in your own words: say how influence was counted, if you know. Name the assumption you would defend least before he asks. Answer slot: if you did the counting, say how; if someone else did it, say so and say what you can speak to. | F1 is the commercial requirement and the likeliest probe. EXP because it tests attribution. |
| A2 | "Which part of that would have happened without you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Name the counterfactual problem in your own words: influence is not attribution. Answer slot: if you can separate what you influenced from what others closed, say so; if you cannot, say that plainly. | Follow-on to F1: a prober's second level. |
| A3 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "roughly £4M of influenced revenue" | Name the assumption in your own words before he does. Do not supply one. | Persona stem. Turns a gotcha into a credibility point. |
| A4 | "Which operator decision did you see up close, and what did it cost them?" | EXP | [grounded] "so I know the operator world from the other side" | Answer slot: if you were in the room for an operator's planning decision, say which and what you saw; if you advised from outside, say so. Do not describe a decision you did not see. | F2 is the operator-side claim. The question presupposes an event the quote does not state, so the second branch lets it be false. |
| A5 | "You've never carried a quota. Why should we believe you can be accountable for commercial outcomes here?" | JD | [grounded] "never carried a direct quota, only influenced revenue" | **Highest-ROI prep in this pack.** Hold: what you have carried is the channel's growth, from 6 partners to 40. Hold through two follow-ups by returning to that. Concede: "I haven't carried a direct quota," and say what you would do in the first 90 days to learn how targets are set here. Never claim you could carry one easily. | F4 is the stated absence Ross will press. The hold is only what the quote carries. |
| A6 | "Sixty seconds: why would an operator buy from someone who hasn't sold rail?" | JD | [grounded] "Never sold into rail specifically"; "so I know the operator world from the other side" | Say "I haven't sold into rail specifically," then the operator-side sentence, then what you would do first, as a plan. | F3 with F2 as the answer's only positive. |
| A7 | "That £4M: how much of it was actually you?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer in your words: influence and ownership are different, and say which part is yours. Answer slot: if you can name your share, name it; if the share is not yours to state, say so plainly. | Pressure stem. Tests the same figure from the other direction as A1. |
| A8 | "Why would an operator pay for a partnership, rather than just buy the software?" | CASE | [generic] | Structure it: what the operator gets from a partner that software alone does not give, how that would show up in its own numbers, and what would make it stop paying. Make no claim about your past. | A live commercial problem. Ross asks it as a decision, not a record. |

Deepa, Case / Strategist and Skeptic (weight: high, 7 questions).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch the first 90 days in this role. What do you need to know first?" | CASE | [generic] | Clarify, then objective, segmentation, approach, metrics, risks. Ask which operators are live, what they are contracted to and when their planning cycles run. Do not invent operators or numbers. | The stem a case rewards. Not about your past. |
| B2 | "Pick one operator planning cycle you'd build around. What breaks if you get the timing wrong?" | CASE | [grounded] "so I know the operator world from the other side" | Use the calendar point from T1. Answer slot: if you have seen a planning cycle go wrong, say what happened; if not, reason it from the operator side and label which parts are inference. | The live version of T1. |
| B3 | "Which operator would you start with, and why that one?" | CASE | [generic] | Name your criteria before the operator: size of change exposure, timing, and whether an outcome can be measured. | Segmentation under a case frame. |
| B4 | "How would you measure the first six months?" | CASE | [generic] | Separate operator outcomes from revenue, and say how you would link them, which is T3. | Tests whether T3 holds up under a case. |
| B5 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically"; "never carried a direct quota, only influenced revenue" | Name rail sales and direct quota, plainly, in that order. Then the ramp plan, said as a plan. Add no past. | F3 and F4 are the weakest rows and the Skeptic's natural probe. |
| B6 | "I don't see rail sales in your background. How would you handle that?" | JD | [grounded] "Never sold into rail specifically" | "I haven't sold into rail specifically." Then your plan for the first 90 days and the operator-side knowledge from F2, quoted. | F3 is the gap she is most likely to name. |
| B7 | "Why is this the next step after nine years in partnerships?" | EXP | [grounded] "9 years in partnerships" | Say why operator partnerships matter to you, in your own words. Do not claim past operator-side roles the material does not show. | Motivation consistency, F5. |

Conversational (weight: low, 2 questions).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "So, walk us through the journey." | EXP | [grounded] "9 years in partnerships"; "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" | A 90-second arc: operator-side consulting, then partnerships, ending on the ISV channel. Use only these facts. | Opener, scored for economy. |
| C2 | "What are you most curious about in our operator business?" | JD | [generic] | Name one question from the operator angle of T1. Claim no knowledge of Kelverton's business beyond the recruiter's words. | A casual question on a JD topic is still scored. |

Peer Evaluator (weight: low, 2 questions).

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Where's the seam between partnerships and product, and what happens when you disagree?" | JD | [generic] | State a seam principle, not a fact about their teams. Name how you would raise a disagreement. | Peer seam probe. |
| D2 | "How do you handle credit when a deal spans sales and partnerships?" | EXP | [grounded] "roughly £4M of influenced revenue" | Answer slot: if credit was shared on a deal, say how; if you cannot say, say so. | Credit-sharing probe on the same figure. |

**Requirement coverage:**

| Requirement | Covered by |
|---|---|
| "Ross will push on commercials." | A1, A2, A5, A7, A8 |
| "what it means for the operators themselves" | POV section, B2, B3, C2 |
| "where you'd take our operator partnerships over the next 18 months" | POV section, B4 |
| Sales into rail operators (role family) | A6, B5, B6 |
| Direct quota ownership (role family) | A5, B5 |
| "9 years in partnerships" (background) | B7, C1, D2 — none beyond that |

**Highest-ROI objection:** A5, the quota question. It will come in some form. Rehearse three follow-ups with the hold, then the concession.

## Reverse questions

Five, each with why it lands. No interviewer profile exists, so none is tied to a career path.

1. "How do operators plan change today, and where would a partner sit in that cycle?" Why it lands: shows you think in operator terms and opens the POV.
2. "How is a partnership measured today: partner-sourced revenue, operator outcomes, or both?" Why it lands: tests the commercial frame Ross runs, and you will inherit it.
3. "What would make the first 90 days a success for you, Deepa?" Why it lands: the manager's own expectation, asked directly.
4. "Where does partnerships sit against sales and product on operator deals?" Why it lands: a seam question that shows you think about handoffs.
5. "Which operator relationship would you most want me to understand first, and what's its history?" Why it lands: signals you want the account picture before the plan.

## Sources

- Provided: your message, which includes the recruiter's email as quoted there. The market report was not provided to me.
- Searches sent: none. Fetches sent: none.

**Research tier: L0, searches 0 of 6, fetches 0 of 2 (research not yet consented).**

| Target | Status | What it would have moved |
|---|---|---|
| 1. Kelverton values | unavailable | Vocabulary in the POV close; no values round is established, so no cheat sheet |
| 2. Kelverton interview process (partnerships) | unavailable | Loop structure; this session's format is already set by the recruiter's email |
| 3. Kelverton strategy / recent news | unavailable | The POV's current-priority framing and any CO question |
| 4. Deepa and Ross, public footprint | unavailable | Persona weights and a career-linked reverse question |
| 5. Representative partnerships JD | unavailable | JD rows marked `[inferred]` in place of `[generic]` |

## Upgrade menu

- A JD's text → F3 and F4 gain sourced requirement wording, and A5, B5 and B6 are checked against it.
- The market report's key points → the POV's differentiation and a check that T1 to T3 are not the consensus answer.
- Deepa and Ross's public footprint → persona weights and a reverse question tied to their career paths.
- Quick research on Kelverton's values, loop and recent strategy → the POV close in the company's own vocabulary, and any CO question.
- The recruiter's prep email → confirms whether anything beyond the POV is graded.
- Your CV → quotes for F1 and F5 beyond your message.
