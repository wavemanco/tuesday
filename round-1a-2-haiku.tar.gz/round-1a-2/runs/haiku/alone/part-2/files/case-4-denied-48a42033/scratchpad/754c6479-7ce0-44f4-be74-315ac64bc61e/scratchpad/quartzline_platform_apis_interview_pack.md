# Interview pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager (Thursday). Interviewer name not given, so no interviewer read.
**Built from:** your underwriting dossier (`tuesday-dossier.md`, dated 2026-08-14, decision conditional_go). No CV text, no interviewer profile, no live research (see Sources).
**Before Thursday:**
1. The dossier is three months old (today is 2026-11-19). Confirm the role's current scope and requirements with the recruiter. If the JD changed, the fit snapshot changes with it.
2. Rehearse A1 aloud at least twice. It is the objection most likely to be asked in some form.
3. Read the prohibited list (section 13) once. Nothing in this pack asserts those claims, including under pressure.

## 1. How to use + type key

Personas describe how a question arrives; types describe what it scores. Guidance is scaffolding, not a script. Say it in your own words.

| Tag | Meaning |
|---|---|
| **JD** | Can you do the listed job, including its gaps |
| **EXP** | Do your past claims survive scrutiny, and what exactly was yours |
| **CASE** | Structure and reasoning on a live problem from this role |
| **VAL** | Not used: no published company values were available |
| **CO** | Not used: no company research ran |

## 2. Fit snapshot

Requirements are quoted from the dossier's `role_profile`. Evidence is quoted from the dossier's `verified_candidate_evidence` (E1 to E3 are its entries 1 to 3, in order). Nothing else is evidence.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (dossier role_profile, R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | low | [grounded] | transferability | Adjacent work only. Say it at its own scope: "I led 30+ end-to-end client integrations of the vendor's REST APIs." Your material shows integration leadership, not product management years, so do not state or imply PM years. |
| F2 | "Shipped API or platform products" (dossier role_profile, R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | high | [grounded] | transferability | Your evidence is integrations built on the vendor's APIs, taken live for clients. It is not products you shipped. Say: "I led integrations from scoping through go-live." Do not say "shipped." |
| F3 | "Technical fluency: API docs, schemas" (dossier role_profile, R3, important) | "Wrote the internal integration playbook her team uses" (dossier E2) | low | [grounded] | discovery | The playbook documents integration work. It is not API docs or schemas, so do not stretch it into that. Answer slot: if you wrote, reviewed or maintained API docs or schemas, say which and what your part was; if you did not, say so, then say what you would read first. |
| F4 | "Stakeholder management across engineering, sales, customers" (dossier role_profile, R4, important) | "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | medium | [grounded] | transferability | Say it at its own scope: you ran sessions that fed client evidence to product. The material shows clients and product, not engineering or sales. Confidence is medium (confirmed, limited inspectable proof), so volunteer that limit before a probe finds it. |
| F5 | "Agile delivery experience" (dossier role_profile, R5, preferred) | none given | low | [grounded] | discovery | No evidence either way. Answer slot: if you ran sprints, planning or reviews with an engineering team, say which and your part; if you worked to another cadence, say what it was. Dossier strategy is clarify. |
| F6 | Owning a roadmap and prioritization authority (dossier R1 sub-claim; dossier acknowledge_gap) | none given | none | [grounded] | capability | Words from the dossier's prohibited_claims field: "I haven't owned a product roadmap or set prioritization for an engineering squad." Then a plan for learning it, said as a plan and never as a past. |

**Gate status:** the dossier lists no hard gates, so no gate rows.

**Pack observation (analysis, not words for you):** the material shows integration leadership and client-facing roadmap input. It does not show PM tenure, roadmap ownership, or authority over an engineering squad.

## 3. Prohibited list

Claims this pack will not coach, in any answer, slot, hold or reverse question.

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | Sourced: dossier prohibited_claims | "I haven't held a product manager title." Then E1 at its own scope. |
| Owned a product roadmap | Sourced: dossier prohibited_claims and acknowledge_gap | F6's acknowledgment. E3 at its own scope. |
| Set prioritization for an engineering squad | Sourced: dossier prohibited_claims | F6's acknowledgment, then the ramp plan. |
| Shipped API or platform products | Inflated form of F2, built locally from E1 | E1 at its own scope: integrations taken live for clients. Observation: your material shows integrations, not products you shipped. No first-person negative. |

## 4. Persona weights

| Persona | Weight | Why |
|---|---|---|
| Skeptic | Highest (5 questions) | A hiring-manager round buys capability and derisks gaps. The dossier's objection lives here. |
| Case / Strategist | High (5 questions) | Hiring managers run live problems on their roadmap. The role's discovery and adoption responsibilities are the problems. |
| Data-Driven Prober | Medium (3 questions) | E1 and E3 carry figures and a session program that probers test. |
| Conversational | Low (3 questions) | Casual openers are still scored. D2 carries the motivation probe. |
| Pressure | Low (2 questions) | Composure check on attribution and the trust question. |

Total: 18 questions. No interviewer profile, so no adjustment from public signals.

## 5. Question banks

### Skeptic (weight 5): deepest rehearsal

**Highest-ROI prep:** A1. The dossier's underwriter named this objection, so it is theirs, not an inference. Its negatives are sourced by the dossier's prohibited_claims field. Hold on E1, concede specifically, then ramp. Rehearse it aloud.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've never held the PM title or owned a roadmap. Why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] dossier likely_interviewer_objections, named by the underwriter; "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Hold on E1: the scoping and requirements work is the part of the PM job you have done with partners, in those words. Hold through two follow-ups by returning to E1, not adding to it. On the second follow-up, concede: "I haven't held the PM title or owned a roadmap, and I don't have three years of that." Then the ramp plan, in your own words. Never claim PM years or roadmap ownership. | F1 and F6. The most likely objection, and the one where a pack is most tempted to thicken the story. |
| A2 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities); "I haven't owned a product roadmap or set prioritization for an engineering squad." (F6, dossier acknowledge_gap) | Name the weakest part first: owning the roadmap and setting priorities across two squads. Use F6's acknowledgment. Then the first weeks, as a plan: meet both squad leads, learn how they currently set work. Do not offer past accomplishments as proof of roadmap skill. | F6 is the honest answer; this is the Skeptic's stem. |
| A3 | "Tell me how you'd handle a disagreement with an engineering lead about what gets built next." | JD | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibilities) | Selection: if you have had such a disagreement, say what it was and what part was yours; if you have not, say so plainly, then say how you would approach it: understand the lead's constraints, make the trade-off visible, confirm who decides. Do not claim authority over priorities. | The squad-authority unknown is the dossier's main risk. This answer shows judgment without claiming a decision right. |
| A4 | "How do you read an API schema when you're scoping a client integration?" | JD | [grounded] "Technical fluency: API docs, schemas" (dossier role_profile R3); E1 "scoping, requirements, architecture" | Scope the answer to E1's stages. Answer slot: if you read or wrote schemas during scoping, say what you checked and your part; if you did not, say so and say what you would check first. | F3, a discovery gap. Keep to what you did. |
| A5 | "How have you run delivery with engineering teams? What cadence did you use?" | JD | [grounded] "Agile delivery experience" (dossier role_profile R5); no quote carries it | Clarify: if you ran sprints, planning or reviews with an engineering team, say which and your part. If you worked another way, say what it was. Add: "Here is what I'd want to confirm about how this team defines delivery." | F5, dossier strategy clarify. Preferred requirement, so the honest answer is short. |

### Case / Strategist (weight 4 to 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch how you'd run discovery with integration partners for a new API capability. What do you need to know first?" | CASE | [grounded] "Run discovery with integration partners" (dossier role_profile responsibilities); "scoping, requirements, architecture, UAT, go-live" (dossier E1) | Clarify, then objective, partner segmentation, approach, metrics, risks. Use E1's stages as the ones you have done: "for client integrations I have run scoping, requirements, architecture, UAT and go-live." Name which partners you'd see first and why. | The live version of the role's discovery responsibility. Asks about no past. |
| B2 | "Adoption of a partner API dropped 20% last quarter. How do you diagnose it?" | CASE | [grounded] "Define and track adoption metrics" (dossier role_profile responsibilities) | First beat: how is adoption defined and counted, and what was the baseline? Name that assumption before they do. Then split causes: partner-side, API-side, measurement. Give no figure. | Adoption baseline is unknown in the dossier. Asking for it is the strong move. |
| B3 | "Which roadmap calls would you make alone, and which would go to the squad leads?" | JD | [grounded] "Own the roadmap for the partner-facing API platform" (dossier role_profile responsibilities) | Give principles, not a claimed split: calls that change partner contracts or commitments versus squad capacity and sequencing. Say you would confirm the split with the leads. Do not assert current authority. | The squad-authority question, answered with principles. The reverse question returns it to them. |
| B4 | "A partner needs a capability your squads can't ship this quarter. What do you do?" | CASE | [generic] | Structure: what the partner needs and why, options (interim path, scope cut, later date), who decides (confirm with the leads), what you tell the partner. Assert no past. | A live trade-off the role will face. |
| B5 | "What would you need from the squad leads in your first month?" | JD | [grounded] "Write specs and drive delivery with two engineering squads" (dossier role_profile responsibilities) | Plan, not past: meet each lead, understand their current work and how they decide sequencing, ask which decisions they want to keep. Naming decision rights as a question shows you are not assuming them. | F6, as a plan. Turns the unknown into a constructive first-month list. |

### Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30-plus integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Say what counted as one complete integration, the assumption you would defend least, and which integrations were yours to lead. Answer slot: if you kept a count, say how; if you did not, say so and say how you would count now. Mention that the integration playbook can be inspected. | E1 is high-confidence and inspectable. The count method is not in the quote, so it is a slot. |
| C2 | "How do you know the integration playbook is in use?" | EXP | [grounded] "Wrote the internal integration playbook her team uses" (dossier E2) | Quote E2 at its own scope. Answer slot: if you tracked use (who, how often), say how; if not, say the claim rests on what you observed. | E2 is high-confidence and inspectable. The probe asks about adoption of your own artifact. |
| C3 | "What did the roadmap-input sessions feed into, and how would you know?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | Volunteer the limit: "I can't show a specific roadmap change in writing." Say what went to product: client evidence. What product did with it was product's call. Answer slot: if a product decision changed because of that evidence, say which and your part; if you cannot name one, say so. | F4, medium confidence. Expect this probe, so state the limit first. |

### Conversational / Rapport (weight 2 to 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (E1); "Wrote the internal integration playbook her team uses" (E2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (E3) | About 90 seconds, in this order: integrations (E1), the playbook (E2), the roadmap-input sessions (E3). Close by naming what sits closest to the partner platform, in those terms. Do not call the journey a PM path. | The opener is scored. Your three verified entries are the whole arc. |
| D2 | "Why this role, now?" | JD | [generic] | Say, in your own words, what draws you to owning the partner platform's roadmap. Do not frame the move as experience you already have. Point to what in E1 and E3 connects, in those words. | The motivation probe. The answer is a motive, not a claim. |
| D3 | "Which API have you spent the most time in, and what did you learn from it?" | JD | [grounded] "vendor's REST APIs" (dossier E1) | Name the vendor's REST APIs at E1's scope. Answer slot: what you learned about the API, from the integrations you led. If you did not learn anything specific, say so. | Tests R2 and R3 through a concrete example. |

### Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "That integration number. How much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Hold: say what you led, in those words. Concede specifically: name the parts that were the client's, the vendor's or the team's. Hold through two follow-ups. Do not expand "led" into "built" or "owned." | The strongest verified claim. Pressure tests attribution. |
| E2 | "Sixty seconds: why would a squad lead trust a PM who hasn't owned a roadmap?" | JD | [grounded] "I haven't owned a product roadmap or set prioritization for an engineering squad." (F6, dossier prohibited_claims); "Ran quarterly roadmap-input sessions feeding client evidence to product" (E3) | Hold: lead with what they can check, E3's sessions and client evidence. Concede: "They shouldn't trust a roadmap claim I can't back. What I can offer is ..." Then the first-month plan from B5. | F6 and F4. A held position is one the material carries. |

## 6. Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| R1 3+ years PM experience (must) | A1, A2, B3, E2 | Answered honestly, no PM years claimed. |
| R2 Shipped API or platform products (must) | A1, C1, E1 | Covered at integration scope. |
| R3 Technical fluency: API docs, schemas (important) | A4, D3 | Answer slot; the material may not show it. |
| R4 Stakeholder management: engineering, sales, customers (important) | A3, B5, C3 | Sales: none, and why: no sentence in your material touches sales. |
| R5 Agile delivery (preferred) | A5 | Answer slot. |
| Responsibilities: roadmap, discovery, specs and delivery, adoption metrics | B3, B1, B5, B2 | Covered. |

## 7. Reverse questions

Five plus one, each with why it lands. No interviewer profile, so none tied to their path.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: it tests the squad-authority risk head-on, and the dossier lists it as unresolved.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: the dossier flags that no baseline is stated, and this asks for it as diligence.
3. **"Has the scope of this role changed since it was posted?"** Why it lands: the dossier is from August. Asking shows you are checking currency, not reciting a posting.
4. **"What would you need to see in the first 90 days to call the hire a success?"** Why it lands: it gives you the expectations you need to plan the ramp.
5. **"What did the last person in this role spend most of their time on?"** Why it lands: it shows what the job really involves, and whether the role is new or a backfill.
6. **"What would you want the squad leads to know about how I'd work with them?"** Why it lands: it turns the authority question into a joint design, and tests whether the hiring manager expects that collaboration.

## 8. Sources

- **Provided:** your pasted `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14). Consumed sections: `handoff_to_mock_interview` (evidence, strategies, objection, risks, employer questions, prohibited claims), `role_profile` (requirements and responsibilities), `decision` (context only). `dossier E1` to `E3` are the three `verified_candidate_evidence` entries in order.
- **Research:** two web searches were attempted, "Quartzline company values" and "Quartzline Platform APIs partner API product". The host refused both (permission not granted). Neither returned a result.

**Research tier:** L1, searches 0 of 6 completed (2 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline values` | unavailable | Values cheat sheet (section 10) omitted. Query refused. |
| 2. `Quartzline interview process hiring manager` | unavailable | Loop structure; persona weights are relationship priors only. No call sent: search is not permitted in this run. |
| 3. `Quartzline strategy` / recent news | unavailable | Grounding brief and CO bank omitted. Query refused. Matters most, because the dossier is three months old. |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name given, so no query could be formed. |
| 5. representative `Product Manager, Platform APIs` JD | skipped | The dossier's role_profile fixes the fit snapshot and the JD questions. |

## Upgrade menu

- The interviewer's name → persona weights from public footprint, and a reverse question tied to their own career path.
- The current JD posting → confirms or changes rows F1 to F6 against what the role now asks.
- Your CV text → more grounded story mapping beyond E1 to E3.
- The recruiter's note on what the round covers → reweights the banks.
- Search permission → Quartzline values and recent strategy, which would add the grounding brief and a CO bank.
