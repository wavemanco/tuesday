# Interview pack: Priya, Senior GTM Strategy Lead, Emerging Products, Northwind Data

- **Role:** Senior GTM Strategy Lead, Emerging Products. Company: Northwind Data (B2B data-infrastructure SaaS, about 3,000 employees).
- **Interviewer:** Dan Kovac, Director of Sales Strategy. Relationship: peer, both reporting to the same VP.
- **Round:** one 60-minute conversation with Dan.
- **Research:** web search was not permitted in this session, so nothing here rests on fresh research. See Sources.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored. Guidance is scaffolding, not a script.

| Tag | Name | Meaning |
|---|---|---|
| VAL | Behavioral / values | Whether past behavior shows a published value |
| EXP | Work-experience deep-dive | Whether your claims survive scrutiny and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, gaps included |
| CO | Company and strategy | Whether you know the company's priorities and competitive frame |
| CASE | Live problem | Structure and reasoning on a problem from the role, asked live |

## Fit snapshot

Requirements are quoted from the JD highlights you supplied (the full JD was not supplied). Evidence is quoted from your background note and is marked as such.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "own GTM strategy for two new product lines" — JD highlights | "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" — your background note | low | [inferred] | transferability | Your note shows product strategy and ops, not go-to-market for a launch. Words: "in product strategy & ops." Answer slot: the JD's own-GTM line makes a probe on launches likely. If you made a go-to-market call on a launch, say which and how you decided, in your own words. If you did not, say so plainly and stay with product strategy and ops. |
| F2 | "identify whitespace across land/adopt/expand/renew" — JD highlights | "proposed a store-surface change credited with a ~$400M ARR uplift" — your background note | medium | [grounded] | transferability | Your note shows an opportunity found on one consumer surface, not whitespace across the lifecycle. Words: "proposed a store-surface change." Limit: expect a probe on the figure. Answer slot: say how you found that opportunity. If you did not look across the lifecycle stages, say so plainly. |
| F3 | "run independent analysis in SQL and Tableau" — JD highlights | "skilled in SQL/Tableau" — your background note | medium | [grounded] | presentation | The quote reaches the tools in other terms. Words: "skilled in SQL and Tableau." Answer slot: if you ran an analysis end to end yourself, name it in your own words. If the work was part of someone else's analysis, say so plainly. |
| F4 | "partner-motion design experience required" — JD highlights | "built a partner-level revenue model used in carrier negotiations" — your background note | medium | [grounded] | transferability | Adjacent: a revenue model for partners, not the design of a partner motion. Words: "I built a partner-level revenue model used in carrier negotiations." Answer slot: expect a probe on what the partner motion was and what you designed in it. If you designed any part of one, say which. If the model was the extent of your partner work, say that plainly. |
| F5 | "strong cross-functional influence" — JD highlights | "set annual volume targets with cross-org consensus" — your background note | medium | [grounded] | presentation | The quote reaches cross-org influence in other terms. Words: "I set annual volume targets with cross-org consensus." Answer slot: expect a probe on how the consensus was reached. Say what you did. If a function did not agree at first, say how it was settled. |
| F6 | "AI experience a plus" — JD highlights | "uses AI tools daily" — your background note | low | [inferred] | transferability | Your note shows daily use of AI tools, not building AI products. Words: "I use AI tools daily." Limit: say what you use them for. Do not describe products you built. |
| F7 | Sales-ops and quota-setting, not a highlighted requirement, but in Dan's own domain — your background note | "No classic sales-ops or quota-setting experience" — your background note | none | [grounded] | capability | A stated absence. Words: "I don't have classic sales-ops or quota-setting experience." No slot: do not claim either. The nearest bridge is F5's quote at its own scope, not a claim of this one. |
| F8 | The ~$400M ARR uplift: a headline figure, not a highlighted requirement — your background note | "proposed a store-surface change credited with a ~$400M ARR uplift" — your background note | medium | [grounded] | none | No gap in the row. The figure raises the defend-the-number slots in A1 and A2, and expect a probe on it. Words: "I proposed a store-surface change credited with a ~$400M ARR uplift." |
| G1 | Location, work authorization and pay: not in the supplied highlights | none given | none | [generic] | hard_gate | Your material does not establish these. Surfaced, not bridged. The one question asked with this pack is whether the gate is met. |

## Prohibited claims

Built locally from the fit snapshot. Each entry names its basis and its honest form. No answer slot, hold, bridge or rationale in this pack asserts any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns go-to-market for product lines | Inflated form of F1 | F1's quote at its own scope, "in product strategy & ops." The limit is this pack's observation: your material shows product strategy and ops, not go-to-market for a launch. D3's slot stays inside what you did. |
| Designed a partner motion | Inflated form of F4 | F4's quote, "built a partner-level revenue model used in carrier negotiations." D1's slot asks which part of a partner motion you designed, if any. |
| Drove the ~$400M, or is responsible for it | Inflated form of F8 | F8's quote, "proposed a store-surface change credited with a ~$400M ARR uplift." A2 and E2 hold to "proposed" and "credited." |
| Set quotas or ran sales ops | Stated negative, F7 | "I don't have classic sales-ops or quota-setting experience." A plain acknowledgment, with no slot. |
| Built AI products or features | Inflated form of F6 | "I use AI tools daily." F2 keeps the claim to use. |
| Ran independent analysis end to end | Inflated form of F3 | "skilled in SQL and Tableau." A5 asks for an instance and allows that there is none. |

## Reading the interviewer

Public footprint was not researched (search refused). The read below uses only your profile of Dan.

- **Career pattern:** pricing and monetization is the spine; one early-stage-startup chapter; current title Director of Sales Strategy.
- **Self-described style:** "relentlessly data-driven."
- **Practical implications:**
  1. Expect every number to be traced to its denominator. The Prober bank (A) carries the most weight for this reason.
  2. Pricing is Dan's native language. Where your material earns a pricing-adjacent point, use the quoted words, and let the packaging and unit-economics angle carry the case questions.
  3. The startup chapter means builder stories land with Dan. You have no startup chapter in your material, so do not borrow one.
  4. Same VP, so seam questions will be collegial. The Peer bank (B) is weighted to match.
- **Mirror opportunities:** none offered. Your material and Dan's profile show no shared professional path to build on.

## Persona table

Relationship prior for a peer round: Peer Evaluator and Data-Driven Prober. Interviewer signals raise Prober (data-driven self-description, analytics-heavy history) and tilt the case questions toward pricing (pricing and monetization spine). The fit-snapshot gaps raise Skeptic. There is no values round in the material, so Values is kept only as a light touch.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Weight |
|---|---|---|---|---|
| Data-Driven Prober | Traces each figure to its counting and assumptions | High. Peer prior plus "relentlessly data-driven" | Know how each figure was counted, or say plainly you do not know. Name the weakest assumption before they do. | 5 (A1 to A5) |
| Peer Evaluator | Seams between teams, disagreement, credit, what you need from them | High. Same VP, and the JD asks for cross-functional influence | Reciprocity first. Propose seam principles, not a claimed seam. | 4 (B1 to B4) |
| Case / Strategist | Live whitespace and bundling problems, pricing-tilted | Medium. The JD's lifecycle line and Dan's pricing spine | Clarify, then structure: objective, segments, approach, metrics, risks. | 3 (C1 to C3) |
| Skeptic | Probes the partner-motion and quota gaps | High for the two gap rows, F4 and F7 | Acknowledge the gap, then bridge with the quote at its scope. Plan, not past. | 3 (D1 to D3) |
| Pressure | Time-boxed challenges on the $400M and the GTM gap | Low to medium. Peers rarely stress, but the figure is the obvious target | Hold the quoted position through two follow-ups, then concede the specific gap | 2 (E1, E2) |
| Conversational | Opener on your journey; casual question on AI | Medium. Rapport openers are scored | A 90-second arc from the quotes; say the AI limit | 2 (F1, F2) |
| Values / Behavioral | Open prompts on unpopular truths and customers | Low. No values round is established | Selection scaffolds with the honest branch | 2 (G1, G2) |

## Question banks

Type is one token. Dual-tags are explained in the rationale. Every question's Provenance carries the candidate sentences its guidance rests on.

### A. Data-Driven Prober (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how the ~$400M ARR uplift was counted." | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Answer slot on the figure. Say how it was counted, in your own words. If you do not know the counting method, say so plainly. Weakest-assumption slot: name the assumption behind the figure you would defend least. If you have none to name, say so. Say which part of the change was yours to propose. | F8 is the headline figure, and a figure raises the defend-the-number slots. Dan is a prober, so the counting question is the likeliest opening. EXP because it tests what was yours. |
| A2 | "How much of that uplift was yours, and how was it credited?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change." Answer slot on credit: if you know how credit was assigned, say so. If not, say so plainly and say who would know. Hold through two follow-ups by returning to the proposal, never widening it. | F8's "credited" is the prober's second layer after the count. The premise stays at the quote's scope. |
| A3 | "Take me through the partner-level revenue model. What were its inputs, and which one would you not trust?" | EXP | [grounded] "built a partner-level revenue model used in carrier negotiations" | Story map from the quote: built, a partner-level revenue model, used in carrier negotiations. Answer slot: name the inputs you actually used and the one you would not trust. If you do not recall, say so and name what you do recall. Do not describe the negotiation outcome unless you know it. | F4 is the adjacent evidence for partner-motion design, and partner work is central to the role. The "would not trust" move is the weakest-assumption slot. |
| A4 | "How many functions signed off on the annual volume targets, and where did the numbers come from?" | EXP | [grounded] "set annual volume targets with cross-org consensus" | Answer slot: say which functions were in the consensus and what the targets were built from, in your own words. If you did not build the numbers, say so and say whose they were. Do not supply a count. | F5 raises how the consensus was reached. Dan will want the denominator. |
| A5 | "Tell me about an analysis you ran yourself in SQL and Tableau, and what it was for." | JD | [grounded] "skilled in SQL/Tableau"; [grounded] "run independent analysis in SQL and Tableau" (JD highlights) | Open prompt, theme from the JD line. Selection scaffold: pick an analysis you ran yourself, with the question it answered and the data it used. If none comes to mind that you ran end to end, say so plainly, then name the nearest piece of analysis you did and whose question it answered. | The JD line is the raising source. Your material carries the tools but no analysis, so the guidance is a selection scaffold, not a story. Primary JD, with EXP delivery. |

### B. Peer Evaluator (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where's the seam between emerging products and sales strategy, and what happens when we disagree?" | JD | [grounded] "strong cross-functional influence" (JD highlights); [grounded] "set annual volume targets with cross-org consensus" | Propose seam principles, not a claimed seam: who decides a price, who owns a forecast, how a disagreement reaches the VP. Disagreement: open prompt. Pick a time two functions disagreed on a number, say what you proposed and how it settled. If none comes to mind, say so plainly, then give the nearest one your material carries, the volume-target consensus in F5. | The peer prior and the JD's influence line make this the collegial seam probe. Peer delivery: guidance does not claim a seam it has not seen. |
| B2 | "What would you need from me in the first ninety days, and what could you bring to my team?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Reciprocity: name one thing you would need from Dan's side, such as access to the data your work depends on. Then what you bring: the partner-level revenue model, described as it was, with the carrier negotiations as its use. Do not promise what you cannot deliver. | Reciprocity is what a peer evaluator scores. "Bring" rests only on F4. |
| B3 | "How do you handle credit when work spans teams? Tell me how credit went on the store-surface change." | VAL | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Credit story: say who was credited and what you did to make your part visible. If credit went to others and you did not contest it, say so. Answer slot on practice: if you made a specific move about credit, name it. If not, say that. | F8 is the one credit claim in the material. The question is the peer version of the credit probe. |
| B4 | "Pricing and monetization are my home turf. Where would you defer to me, and where would you push back?" | JD | [grounded] "built a partner-level revenue model used in carrier negotiations" | Answer in the model's terms. Where your model touched a price, say so. Where it did not, say you would defer on price. Name the one place you would push back and why, based on your own work. | Dan's spine makes pricing their native ground. F4 is the nearest pricing-adjacent evidence. Peer delivery. |

### C. Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sketch how you'd find whitespace across land, adopt, expand and renew for a new product line. What do you need to know first?" | CASE | [grounded] "identify whitespace across land/adopt/expand/renew" (JD highlights) | A live problem, with no claim about your past. Clarify first: what the line sells, to whom, at what price points. Objective: the whitespace to size. Segment by lifecycle stage. Approach per stage. Metrics per stage. Risks. For Dan, name the packaging lever you would test at each stage and the unit-economics check you would run first. Use Northwind's words: land, adopt, expand, renew. | The JD's lifecycle line is the requirement. Dan is a pricing career, so the packaging and unit-economics angle scores the structure too. Type CASE, with the JD line as the requirement it tests. |
| C2 | "Northwind's three priorities include enterprise expansion and an AI copilot launch called Compass. Which would you test first, and why?" | CO | [grounded] "enterprise expansion, an AI copilot launch ('Compass'), and reaching profitability" (your research note, undated and not web-verified) | Name the hypothesis, the segment, the metric and the first test. Use the research note's own words. Do not state any fact about Compass you have not seen. | This is the only CO source this session. The note has no date, so the guidance claims nothing beyond it. |
| C3 | "Bundling by a much larger platform vendor is the main threat. How would you price against a bundle?" | CASE | [grounded] "main competitive threat is bundling by a much larger platform vendor" (your research note, undated and not web-verified) | Structure: what the bundle replaces for the customer, which segment is exposed, the packaging response, the unit-economics guardrail, the metric that says the response works. Say what you would not do: match the bundle's price across the whole base. | Pricing-first, in Dan's native ground. CASE, because it is a live problem about the market, not a claim about your past. |

### D. Skeptic (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Partner-motion design is required for this role. Where would you be weakest on day one?" | JD | [grounded] "partner-motion design experience required" (JD highlights); [grounded] "built a partner-level revenue model used in carrier negotiations" | Name the weakest part plainly. Bridge with F4's quote at its own scope. Answer slot: if you designed any part of a partner motion, say which. If not, say so and name what you would learn first. Do not claim partner-motion design. | The most direct gap in F4, and the skeptic's usual question. Plan language, not past. |
| D2 | "You don't have classic sales-ops or quota-setting experience. How would you set annual targets for a new product line?" | JD | [grounded] "No classic sales-ops or quota-setting experience" (your background note); [grounded] "set annual volume targets with cross-org consensus" | Highest-ROI prep in this pack. Acknowledge first: "I don't have classic sales-ops or quota-setting experience." Bridge at the quote's scope: "I set annual volume targets with cross-org consensus." Hold through two follow-ups by returning to what you set and how the consensus was reached. Concede specifically: name the part of quota-setting you have not done, and what you would use to set a new line's first targets. Never call volume targets quota. | Dan runs sales strategy and will probe targets first. The stated negative is the source for the acknowledgment, and the quote is the bridge. This gets the deepest rehearsal because the material is thinnest exactly where the question aims. |
| D3 | "Which go-to-market decision for a launch, if any, did you own?" | JD | [grounded] "own GTM strategy for two new product lines" (JD highlights); [grounded] "then 9 at a large consumer-tech company in product strategy & ops" | Answer slot: if you made a go-to-market call on a launch, say which and how you decided. If you did not, say so plainly, then describe the nearest work from product strategy and ops, at its own scope. | F1's gap. "If any" keeps the premise open, so the question does not assume a decision. |

### E. Pressure (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why you, over someone who has run go-to-market for a product line?" | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops" | Hold: the sixty seconds state what you have, at the quote's scope, plus F4 and F5 as your nearest pieces. Do not claim go-to-market for a launch. Concede specifically if pressed: name the launch gap in one sentence and what you would do first. | Stress testing composure. The hold is a position the material carries. |
| E2 | "That ~$400M: how much of it was actually you?" | EXP | [grounded] "proposed a store-surface change credited with a ~$400M ARR uplift" | Hold: "I proposed the change." Concede specifically: say which part of the uplift you cannot attribute, and that you do not know how it was counted if that is true. Do not fold on the proposal, and do not add to it. | The pressure form of A2. The hold is the quote's own scope. |

### F. Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | JD | [grounded] "2 years strategy consulting at a top firm, then 9 at a large consumer-tech company in product strategy & ops"; [grounded] "built a partner-level revenue model used in carrier negotiations" | A 90-second arc with the quoted beats in order: consulting, then consumer-tech product strategy and ops, then the partner revenue model, then why this role. Say each beat at its own scope, then stop. | Rapport openers are scored. The arc uses only the quoted beats. |
| F2 | "What are you actually playing with in AI these days?" | JD | [grounded] "uses AI tools daily"; [grounded] "AI experience a plus" (JD highlights) | Name the tools you use daily and what you use them for. If you have built an AI feature, name it. Otherwise say you use AI tools, and say the limit. | The JD's plus-skill, asked casually. Casual questions about a JD topic are scored. |

### G. Values / Behavioral (weight 2, light touch)

No values round is established, so these are a rehearsal touch, not a predicted round.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something unwelcome, with a named stake, a moment you held the point, and a working relationship at the end. Your material carries no such story. Say so plainly, then say how you would handle it. Use "we" for context and "I" for what you did. | Persona stem. Keeps the candidate from meeting the style for the first time live. |
| G2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Selection scaffold: pick a time a customer's need cost a team a target, with what you chose and what it cost. Your material carries no such story. Say so plainly, then say how you would decide. | Persona stem, touch only. |

### Requirement coverage

| Stated requirement | Questions | Note |
|---|---|---|
| Own GTM strategy for two new product lines | D3, E1 | Gap: F1 |
| Identify whitespace across land/adopt/expand/renew | C1 | Covered by a case |
| Run independent analysis in SQL and Tableau | A5 | Gap: F3 |
| Partner-motion design experience required | D1, A3, B2 | Gap: F4 |
| Strong cross-functional influence | B1, B3, A4 | Evidence: F5 |
| AI experience a plus | F2 | Gap: F6 |
| Sales-ops and quota-setting (stated absence, not a highlight) | D2, A4 | Gap: F7 |
| Location, work authorization and pay (not in highlights) | none, and why: the question asked with this pack decides whether the gate is met | Gate: G1 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "How did your pricing and monetization work carry into sales strategy?" | Ties to Dan's own path. Turns a probe into a peer conversation, and shows you researched them. |
| "Where does pricing for emerging products sit between your team and mine today?" | The seam question. Shows you know the boundary is live. |
| "Which of the three priorities, enterprise expansion, Compass or profitability, is pulling hardest on the sales plan this year?" | Uses the research note's own priorities. Asks for a ranking, which is what a strategy peer wants. |
| "When a bundle shows up in a deal, what does sales need from strategy first?" | Peer reciprocity on the competitive threat. |
| "What could a new person do in the first month that would genuinely help your team?" | Reciprocity question. A peer weights it heavily. |
| "How do you know an expansion motion is working before the renewal date?" | Asks about the lifecycle the JD names. Shows you are thinking in land, adopt, expand, renew. |

## Sources

Provided documents: the JD highlights (six lines, quoted in the fit snapshot); your background note (quoted in the fit snapshot as "your background note"); your profile of Dan Kovac; your research note on Northwind's three priorities and its competitive threat (quoted in C2 and C3, undated and not verified). No dossier was present.

Search calls sent, all refused (permission not granted in this session):

1. "Northwind Data company values principles": refused.
2. "Northwind Data Compass AI copilot launch": refused.
3. "Dan Kovac Director of Sales Strategy Northwind": refused.

No fetches were sent.

Research tier: L1 — searches 3 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Northwind values | unavailable | Would have confirmed whether a values round exists. None is established, so the values cheat sheet is omitted. VAL themes stay as persona stems. |
| 2. Interview process | skipped | Your own words fix the loop: one 60-minute conversation with Dan. |
| 3. Strategy / recent news | unavailable | Would have verified and dated the research note, which feeds C2 and C3. |
| 4. Dan Kovac public footprint | unavailable | Would have added talks and writing to the interviewer read and the reverse questions. |
| 5. Representative JD | skipped | The JD highlights were supplied. |

## Upgrade menu

- **Web search permission:** re-runs the three refused searches. The values search would confirm whether a values round exists, the strategy search would verify and date the Compass and bundling points, and Dan's public footprint would sharpen the Prober bank and the reverse questions.
- **Full JD text:** the requirement rows currently rest on six highlights. The full text would add mid-list requirements, which would become rows and questions.
- **Your CV text:** the evidence cells currently quote your background note. Your CV's own sentences would make the grounded rows cite your CV directly.
- **Recruiter's note on round focus:** confirms whether a case or a presentation is in the 60 minutes. Currently assumed to be a conversation only.
- **Date on the research note:** dates C2 and C3, so their freshness can be stated.
- **Work authorization, location and pay terms:** would settle G1, the one gate the material does not establish.
- **Deep research (L2), offered once:** up to 6 more searches and 2 more fetches, several minutes. Needs web search permission first. Want it?
