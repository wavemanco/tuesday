# Interview prep pack: Product Manager, Platform APIs at Quartzline

**Round:** 45-minute conversation with the hiring manager (your note). Interviewer name: not given.
**Built from:** `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14, decision `conditional_go`). Web search was refused in this session, so no company research is in this pack.
**Age check:** the dossier is about 14 weeks old. Before Thursday, confirm with the recruiter that the posting, the responsibilities and the squad structure have not changed. Anything in this pack that rests on the posting is only as current as the dossier.

## 1. How to use this pack and the type key

Personas describe how a question arrives. Types describe what it scores.

| Tag | Name | What it scores |
|---|---|---|
| JD | Role and JD-driven | Whether you can do the listed job, including its gaps |
| EXP | Experience deep-dive | Whether your claims survive scrutiny and what was actually yours |
| CASE | Live problem | Structure and reasoning on a problem from the role, delivered live |
| CO | Company and strategy | Not used: no company research ran, so no question here is grounded in current strategy |
| VAL | Values | Not used: no values-style round was detected |

Guidance is scaffolding, not a script. Say it in your own words. Where a cell says "answer slot," the interviewer's probe is real and your honest answer is either branch the slot allows.

## 2. Fit snapshot

Requirement lines come from the dossier's `role_profile` (the supplied posting's lines, as the dossier records them). Evidence quotes come from the dossier's `verified_candidate_evidence` and `uncertain_or_weak_areas`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" — dossier R1 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; "Wrote the internal integration playbook" — dossier E2; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | low | [inferred] | transferability | Bridge with its limit named: "I haven't held a product manager title. I led 30+ end-to-end client integrations of the vendor's REST APIs." The limit is the pack's observation, not words for you: the material shows client-facing integration work, not product management years. Do not claim the years. |
| F2 | "Owning a roadmap and prioritization authority" — dossier R1 sub-claim | none given. The dossier records the absence under `acknowledge_gap` | none | [grounded] | capability | Plain acknowledgment: "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad." Then a plan, never a past: name the first two things you would do with the squad leads. No bridge here. |
| F3 | "Shipped API or platform products" — dossier R2 (must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | low | [inferred] | transferability | The material shows integrations of the vendor's APIs, not a platform product you shipped. Say that limit, then point to the integrations at their own scope. Answer slot: if you shipped a product of your own, name it and the part that was yours; if not, say so plainly. |
| F4 | "Technical fluency: API docs, schemas" — dossier R3 (important) | "Wrote the internal integration playbook" — dossier E2 | low | [inferred] | discovery | The material shows an integration playbook, not API documentation or schemas. Answer slot: if you wrote or reviewed API docs or schemas, say which and what you checked in them; if not, say so and say what the playbook covers, in your own words. |
| F5 | "Stakeholder management across engineering, sales, customers" — dossier R4 (important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | low | [inferred] | transferability | The material reaches customers (requirements, UAT, go-live) and product (roadmap input). It does not show engineering or sales. Answer slot: if you have managed a disagreement with engineering or sales, say what it was and what you did; if not, say so. |
| F6 | "Agile delivery experience" — dossier R5 (preferred) | none given. The dossier records the gap as `discovery` with `clarify` | low | [grounded] | discovery | No quote touches Agile delivery. Clarify, do not bridge: answer the requirement's own wording. Say what you have done that matches, or that you have not worked that way and what you would want to confirm about how this team defines it. |
| F7 | "Define and track adoption metrics" — posting responsibility, dossier role_profile | none given. The dossier records no current baseline | none | [grounded] | discovery | No quote reaches adoption metrics. Answer slot: if you have tracked an adoption number, say what it counted; if not, say so and propose a first version. |
| F8 | "Run discovery with integration partners" — posting responsibility, dossier role_profile | "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | low | [inferred] | transferability | The material shows client requirements and roadmap input, not partner discovery sessions. Answer slot: if you have run discovery with a partner, say what you asked and what it changed; if not, say so and point to the requirements work at its own scope. |

Gate rows: none. The dossier's `hard_gates` is empty, and nothing in the inputs states a term you do or do not meet.

Three things this snapshot changes from the dossier:
- F3 and F4 are not in the dossier's `uncertain_or_weak_areas`. The pack grades them from the evidence and flags them for the underwriter's next pass.
- The dossier's decision prose gives "seven years of integration leadership." No verified entry carries a tenure, so the pack does not use it (see section 3).
- F8 is built from E3 alone. It is a discovery gap, not a verified claim about partner work.

## 3. Prohibited claims

The dossier's `prohibited_claims` binds every cell below. The rows marked "built here" are this pack's own inflated-form entries, built from the quotes above.

| Not coached | Basis | Honest form |
|---|---|---|
| Having held a product manager title or role | Dossier `prohibited_claims` | Plain acknowledgment: "I haven't held a product manager title." No answer slot. |
| Having owned a product roadmap | Dossier `prohibited_claims` and the `acknowledge_gap` area for roadmap authority | Plain acknowledgment: "I haven't owned a product roadmap." No answer slot. |
| Having set prioritization for an engineering squad | Dossier `prohibited_claims` and the `acknowledge_gap` area | Plain acknowledgment: "I haven't set prioritization for an engineering squad." No answer slot. |
| Seven years of integration leadership | Built here. The figure appears only in the dossier's decision prose, not in any verified entry | Not coached until you confirm a tenure. Use E1 at its own scope, with no duration. If you confirm a figure, it goes in the fit snapshot as a new quote, and the rows that draw on it are regenerated. |
| Shipped an API or platform product | Built here: inflated form of F3 (the wording "API or platform product" widens E1) | E1 at its own scope. The limit, that the material shows integrations and not a product, is the pack's observation, never a first-person negative. |
| Owned partner-facing roadmap decisions | Built here: inflated form of the posting's "Own the roadmap" line, widening E3 | E3 at its own scope: roadmap-input sessions feeding client evidence to product. The limit is the pack's observation. |

## 4. Persona table

Weights are a shown judgment. The hiring-manager prior is Case/Strategist plus Skeptic (they are buying capability and de-risking gaps). The dossier's named objection and the fit snapshot's gaps push Skeptic to the top. No interviewer profile exists, so no interviewer-signal adjustment applies. No values-style round is established, so Values is not banked.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy | Depth |
|---|---|---|---|---|
| Skeptic | Probes the title gap and the roadmap gap directly | Highest. The dossier names the objection, and F1 and F2 are the largest gaps | Concede the gap in one sentence, then the evidence at its own scope; never argue the title | 5 (bank A) |
| Case/Strategist | Live role problems: adoption, two squads, partner discovery | Highest. A hiring manager buys judgment on the actual roadmap | Clarify before structuring; say the decision you cannot make alone | 5 (bank B) |
| Data-Driven Prober | Asks how the 30+ was counted; asks for the roadmap-session record | Medium. E1's figure and E3's medium confidence invite it | Defend the number at its scope; name the weakest assumption before it is named for you | 3 (bank C) |
| Pressure | Sharp challenges to the title and to the "how much was you" question | Medium. The gap is visible on the page, and a hiring manager may test composure | Hold through two follow-ups, concede exactly, do not fold on the core | 3 (bank D) |
| Conversational | Opening "walk me through it," and a casual question about the role | Low to medium. Short round, but openers are scored | A 90-second arc; treat casual questions as scored | 2 (bank E) |
| Values / Behavioral | Not banked | Not established. No loop source names a values round, and the fallback archetype is not in use | If one appears, use the bank D selection scaffold | 0 |

## 5. Question banks

Each question carries its provenance first. The rule: a claim about your past rests on a quote in the same row, or it is an answer slot.

### Bank A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] the dossier's named objection, asked as written. Negatives sourced by dossier `prohibited_claims` ("Having held a product manager title or role"; "Having owned a product roadmap"). Evidence: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live"; "Wrote the internal integration playbook"; "Ran quarterly roadmap-input sessions feeding client evidence to product" | Concede in one sentence: "I haven't held the product manager title, and I haven't owned a product roadmap." Then the evidence at its own scope, quoted above. Name the limit: "The part I can show is the client-facing side of this work, not the prioritization side." Medium caveat on E3: "The proof for the roadmap sessions is limited, and I can describe them, not show you the outcomes." Do not argue that a PM with three years is equivalent. Answer slot: say what you would want to see from yourself in the first 90 days, as a plan. Follow-up 1 ("Which roadmap decision would you make first?"): "Before I name one, I'd want to know which decisions are mine and which belong to the squad leads." Follow-up 2 ("Then why not wait for a PM?"): "That's a fair question. The part I can show is the integration work. The rest you'd be judging on the plan, not on experience I don't have." Hold through both before saying anything more. | Named by the underwriter as the most likely objection, so it gets the deepest rehearsal and is the highest-ROI prep in this pack. Asked as the dossier wrote it because each negative has a source. Draws on F1 and F2. |
| A2 | "Give me the requirement you'd be weakest on day one." | JD | [grounded] "Own the roadmap for the partner-facing API platform" (posting responsibility, dossier role_profile) | Name roadmap ownership as the day-one weak point, using F2's plain acknowledgment: "I haven't owned a product roadmap." Then a plan for the first weeks, in your words. Answer slot: name what you would first ask the squad leads, to find out which roadmap decisions are yours. Do not add a bridge: F2 is a capability gap. | Open prompt drawn from the posting's own responsibility. Tests whether you can name a weak point without defending it. |
| A3 | "Which shipped API or platform product would you point to?" | JD | [grounded] "Shipped API or platform products" (dossier R2, must_have). Evidence: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" | Answer slot: if you shipped a product of your own, name it and the part that was yours. If not, say so plainly, then point to the integrations you led, at their own scope: client integrations of the vendor's REST APIs. Do not call the integrations a platform product. | The premise "shipped product" is raised by R2, and the second branch lets it be false. F3 is not in the dossier's weak areas; flagged for the underwriter. |
| A4 | "The role lists Agile delivery as preferred. How do you define it?" | JD | [grounded] "Agile delivery experience" (dossier R5, preferred) | Clarify, do not bridge. Answer the requirement's own wording. Say what you have done that matches it, in your own words. If you have not worked that way, say so and say what you would want to confirm about how this team defines it. Do not name a framework you have not used. | F6 is a discovery gap with no quote. The question presupposes nothing about your past, so the guidance makes no claim. |
| A5 | "What is your experience with API docs and schemas?" | JD | [grounded] "Technical fluency: API docs, schemas" (dossier R3, important). Evidence: "Wrote the internal integration playbook" | Answer slot: if you wrote or reviewed API docs or schemas, name which and what you checked. If not, say so, and say what the integration playbook covers, in your own words. Do not describe the playbook as API documentation. | F4. The playbook is adjacent evidence. The material does not show docs or schemas, so this is discovery, not capability. |

### Bank B: Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner's integration has stalled at UAT, and adoption of the API is flat this quarter. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify first: what "stalled" and "flat" are measured against, and whether the partner or the integration is the unit. Segment by partner size and integration stage. State two hypotheses, then the first data you would pull. Name the metric you would trust least. Make no claim about a past incident. | A live problem from the posting's adoption responsibility. Generic: no current strategy was researched, so there is no company-specific framing. |
| B2 | "How would you define and track adoption for a partner-facing API?" | JD | [generic] | Define adoption as a unit before a metric: who counts as adopting, over what period, against what baseline. Ask for the current baseline first. Answer slot: if your team already tracks an adoption number, say what it counts and what it misses; if not, say so and propose a first version. | F7. No baseline is in the material. This is also the opening for reverse question 2. |
| B3 | "Two engineering squads both want next quarter's API work. How do you choose?" | CASE | [generic] | Clarify whose call it is before you give a framework: the squad leads' or the PM's. Then criteria: partner impact, dependencies, cost. Say which decisions you would take to the squad leads. Do not describe a call you have made. | The posting names two squads. This is where the decision-authority risk shows, and the answer tests whether you know the difference between owning and advising. |
| B4 | "How would you run discovery with an integration partner you have not worked with before?" | JD | [generic] | Start from what you need to learn (where integrations stall), who you would talk to (the partner's engineers and product owner), and what you would bring back to the squads. Describe the method as a plan. Answer slot: if you have run partner discovery, say what you asked and what it changed; if not, say so and point to the client requirements work at its own scope. | F8. The posting names partner discovery. The material shows client requirements, not partner discovery. |
| B5 | "This role works across sales, customers and engineering at once. Who would push back hardest on a partner API decision, and what would you do?" | JD | [generic] raising source: "Stakeholder management across engineering, sales, customers" (dossier R4) | Name each group's likely concern as a question you would ask, not a fact about the people. Answer slot: if you have managed a disagreement between client-facing and engineering teams, say what it was and what you did; if you have not managed one with engineering or sales, say so and say what you would bring from the client side. | F5. Asked casually in a hiring-manager register, but scored. |

### Bank C: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the quarterly roadmap-input sessions were run." | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3, medium) | Say what the sessions were, how often, and what client evidence you took to product, in your own words. Name the caveat before it is extracted: "The proof for these is limited; I can describe them, not show the outcomes." Answer slot: if any decision product made came from that evidence, say which and what part was yours; if you cannot tell whether it changed anything, say so. | E3 is the seam the dossier said to expect a probe on. Medium confidence means the caveat goes in the answer. |
| C2 | "How was the 30+ counted, and which of the five stages was yours to decide?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1, high) | Defend the number in your own words: how you counted the 30+ (started, finished, or led), and which of scoping, requirements, architecture, UAT and go-live were yours to decide. Weakest-assumption move: name the assumption behind the 30+ you would defend least, before they do. Do not claim a stage you did not decide. | The headline figure is the magnet for a prober. The four slots a figure raises are how it was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. |
| C3 | "Which assumption behind that number would you defend least?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Name the assumption in your own words before they name it. If you do not know how each integration was counted, say so plainly. Do not invent a counting rule to fill the gap. | Same figure, different probe. The honest branch "I don't know how it was counted" is a valid answer. |
| C4 | "What artifact would I look at to check the roadmap-input sessions?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3, medium) | Answer slot: name any artifact you kept (an agenda, notes, the evidence you took to product) and whether you still have it. If you kept none, say so plainly. | E3's proof is the upgrade lever. A dated note or agenda would move E3 from medium to high. |

### Bank D: Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You haven't held a PM title. Why shouldn't I screen you out?" | JD | [grounded] plain acknowledgment from dossier `prohibited_claims` ("Having held a product manager title or role"). Evidence: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Hold the position: the integration work is real, and you can point to the playbook. Restate the quote at its scope. First follow-up: return to E1, not to a bigger claim. Second follow-up: concede exactly: "You're right that I haven't held the title or owned the roadmap. That's the gap, and the plan is what I'd show you." Do not fold on the core claim that the integrations are real. | Hold-then-concede. A held position must be one the quotes carry. |
| D2 | "That integration number — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Hold the number and name your part in your own words, stage by stage, from the list in the quote. Concede exactly where work was shared. Answer slot: if a stage was run by someone else, say so. Do not reduce "led" to "contributed" unless that is what happened. | Attribution is the honest-answer test. The stage list is in the quote, so naming stages is allowed. |
| D3 | "Sixty seconds: why you?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); "Wrote the internal integration playbook" (dossier E2) | Open with the gap in one clause, then the strongest quote at its scope, then the plan for F2 in one sentence. Do not add a tenure or a product. | A 60-second answer under time pressure is the Pressure persona's test. Length forces the discipline. |

### Bank E: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); "Wrote the internal integration playbook" (dossier E2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3, medium) | A 90-second arc: the integration work at its scope, the playbook, the roadmap sessions with the caveat named, the gap in one sentence, why this role. | The opener is scored. A prepared arc is what keeps it short and inside the evidence. |
| E2 | "What is the part of this role you're most curious about?" | JD | [generic] | Name the partner side of the roadmap, specifically: where partner needs and the squads' capacity conflict. Ask a question back. Do not claim expertise you have not described. | Casual register, scored for interest and specificity. |

### Requirement coverage

| Requirement or responsibility | Questions |
|---|---|
| R1, 3+ years PM | A1, D1, E1 |
| R1 sub-claim, roadmap and prioritization authority | A1, A2, B3 |
| R2, shipped API or platform products | A3 |
| R3, API docs and schemas | A5 |
| R4, stakeholder management | B5 |
| R5, Agile delivery (preferred) | A4 |
| Responsibility: own the partner-facing roadmap | A2, B3 |
| Responsibility: run discovery with partners | B4 |
| Responsibility: specs and delivery with two squads | B3 |
| Responsibility: define and track adoption metrics | B1, B2 |

## 6. Scripts

These are the three scripts the fit snapshot supports. Each one is drawn from its row, and none adds a fact.

**Bridge script (F1, transferability).** Use for "why should we count your experience toward this role?"
> "I haven't held a product manager title. I led 30+ end-to-end client integrations of the vendor's REST APIs, covering scoping, requirements, architecture, UAT and go-live. I also wrote the internal integration playbook, and I ran quarterly roadmap-input sessions that fed client evidence to product. That's the adjacent work. It isn't the prioritization side of the job, and I'd say so."

Each clause is quoted from the dossier (E1, E2, E3) or is the plain acknowledgment from `prohibited_claims`. The last sentence is the stated limit.

**Acknowledge-gap script (F2, capability).** Use for "have you owned a roadmap or set priorities for an engineering squad?"
> "I haven't owned a product roadmap, and I haven't set prioritization for an engineering squad. Here's how I'd approach the first 90 days: [your own plan, in your words]."

No bridge. The plan is a plan, never a past. Name the first two things you would do with the squad leads.

**Clarify script (F6, discovery).** Use for "tell me about your Agile delivery experience."
> "How do you define Agile delivery here? Once I know that, I can tell you what I've done that matches it, and what I haven't."

This asks before it claims. Use the honest branch if you have not worked that way.

## 7. Reverse questions

Each one has a "why it lands." Questions 1 and 2 come from the dossier's `questions_for_employer` and `opportunity_risks_to_validate`.

1. **"Which roadmap decisions does this PM make alone, and which belong to the squad leads?"** Why it lands: decision authority versus the squad leads is asserted in the posting and not evidenced. This is the question you need answered before accepting.
2. **"How is partner API adoption measured today, and what is the current baseline?"** Why it lands: adoption is named as a responsibility, and no baseline is stated. The question reads as diligence, and the answer tells you whether the metric exists.
3. **"How do the two squads currently decide which partner-facing work comes first?"** Why it lands: it tests whether the role has a real prioritization mechanism, and it connects to B3.
4. **"What did the last person to own this roadmap hand over, and what did they leave unfinished?"** Why it lands: it tells you what the seat is actually for. (Generic question.)
5. **"What would success look like at 90 days, and what would tell you the hire isn't working?"** Why it lands: it converts the gap into a shared definition of success, which makes the first quarter easier to judge later.

No interviewer profile exists, so no reverse question ties to the interviewer's own path. That is in the upgrade menu.

## 8. Sources

**Provided documents**
- `tuesday-dossier.md` (dossier_version 1.1, generated 2026-08-14, decision `conditional_go`). Context only: the decision.
- Sections consumed: `handoff_to_mock_interview` (`verified_candidate_evidence`, `uncertain_or_weak_areas`, `likely_interviewer_objections`, `opportunity_risks_to_validate`, `questions_for_employer`, `prohibited_claims`, `high_priority_requirements`) and `role_profile` (requirements, responsibilities, unknowns).
- Sections absent from the dossier and therefore not used: `evidence_map`, `evidence_state`, `risk_register`.
- E2 is quoted without its "her team uses" clause. That clause narrows the playbook's audience and is not needed for any claim here.
- The "seven years" figure is in the dossier's decision prose only. It is not used (section 3).
- Your message: round type (45-minute hiring-manager conversation) and the date.

**Research tier:** L1, searches 3 of 6, fetches 0 of 2. User links read: none.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Quartzline company values` | unavailable | Refused. Would have moved the values cheat sheet, which is dropped because no values-style round was detected. Queries: "Quartzline company values": refused. |
| 2. `Quartzline interview process` for this role family | unavailable | Refused. Would have moved loop structure. The loop rests on your message (one 45-minute conversation with the hiring manager), so the persona weights do not depend on it. Queries: "Quartzline Product Manager Platform APIs interview process": refused. |
| 3. `Quartzline strategy` and recent news | unavailable | Refused. Would have moved the CO bank. Without it, no question is grounded in current strategy and the CASE questions stay `[generic]`. Queries: "Quartzline partner API platform news strategy 2026": refused. |
| 4. `{interviewer name} Quartzline` | n/a | No interviewer name was given, so there is no query to form. The interviewer read is absent. |
| 5. representative Product Manager, Platform APIs JD | skipped | The dossier's `role_profile` fixes the fit snapshot and the JD-tagged questions. |

Web search permission was refused on every call. The calls were not retried.

## 9. Upgrade menu

- **The interviewer's name** → persona weights from their public footprint, and a reverse question tied to their own career path (target 4, currently n/a).
- **The posting, pasted** → the requirement lines move from the dossier's summary to verbatim `[grounded]` quotes, and F1 through F8 are regraded against the exact wording.
- **A recruiter's note on the round** → confirms whether the 45 minutes is the only conversation or part of a loop. If it is part of a loop, the schedule reweights the banks.
- **A dated roadmap-input note, agenda, or the evidence you took to product** → E3 and C1 move from medium to high confidence, and the caveat in C1 can be dropped.
- **Web search permission in a later session** → company values, interview process, and strategy (targets 1 to 3). A deeper pass adds up to 6 more searches and 2 more fetches, several minutes more. Offered once; say the word if you want it.
- **A current `tuesday-dossier.md`** → the dossier is about 14 weeks old. A refreshed one against the current posting would confirm or change R1 through R5, the decision-authority risk, and the adoption baseline.
