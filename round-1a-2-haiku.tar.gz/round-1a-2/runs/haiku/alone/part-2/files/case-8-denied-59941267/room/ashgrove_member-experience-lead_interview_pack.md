# Ashgrove Credit Union: Member Experience Lead, interview pack

For Dara. Built 19 November 2026. First version.

Rounds: recruiter screen, 30 minutes (28 November). Head of Member Services, 45 minutes, mostly behavioural, your manager (28 November). Panel of two branch managers, 60 minutes, including a 20-minute complaint escalation case, scored against the four values (28 November). The panel members are not named yet.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what it scores.
- Type key: **VAL** behavioural and values alignment. **EXP** your own work, tested. **JD** a stated role requirement. **CO** company and strategy. **CASE** a live problem.
- Guidance is scaffolding, not a script.
- **Answer slots** are instructions for the interview. Each has two honest branches: say what you did, or say the thing was not yours or did not happen. Prepare both; never prepare the branch you do not have.
- In the Provenance column, the label comes first, then the sentences of yours the guidance rests on.

## Fit snapshot

Requirements are quoted from the job description you pasted. Evidence is quoted from your message; if you send your CV, the sources become "your CV". None of the eight requirements is a gate (a term or credential), so no row is a hard gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material shows the branch's log, not the process end to end, and nothing beyond the branch. Bridge at the quote's scope: "I handled the branch's formal complaints log." Expect a probe on how far the process ran past the log. Answer slot: see B3. |
| F2 | "the contact centre" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you stated, so the words are yours: "I've never worked in a contact centre." Then how you would learn it, framed as a plan and never as a past. Nothing is added to make the gap smaller. |
| F3 | "report monthly on complaint volumes and resolution times" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | medium | [grounded] | presentation | Your material shows a monthly spreadsheet, not what it counted. The bridge rewords only the quote: "I built the monthly complaints spreadsheet our regional manager uses." Volumes and resolution times are not in the quote, so do not claim them without saying what the sheet held. |
| F4 | "coach branch supervisors on escalations" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Adjacent work: you trained tellers, not supervisors, on the escalation script. Limit: no coaching of supervisors is shown. Bridge at the quote's scope: "trained new tellers on our escalation script." |
| F5 | "work with digital teams on self-service journeys" — JD | none given | none | [grounded] | discovery | Your material is silent on digital work. This is silence, not a stated absence. Answer slot: see C5. |
| F6 | "4+ years in financial-services customer operations" — JD | "6 years in retail banking, the last 3 as a branch supervisor." — your message | medium | [grounded] | none | The quote already reaches the requirement in role-relevant terms, so the bridge is the quote itself. Medium confidence: you state it and nothing inspectable backs it, so expect a check on dates. |
| F7 | "experience handling regulated complaints" — JD | "I handled the branch's formal complaints log and trained new tellers on our escalation script." — your message | medium | [grounded] | transferability | Your material says formal complaints, not regulated ones, and does not say which rules or time limits the log ran to. Bridge at the quote's scope. Answer slot: see B3. |
| F8 | "confident presenting to senior leaders" — JD | "Never worked in a contact centre, and I've never presented to anyone above regional level." — your message | none | [grounded] | capability | A gap you stated: "I haven't presented to anyone above regional level." Then how you would prepare a first presentation to senior leaders, as a plan. |
| F9 | "comfortable with Excel reporting" — JD | "I built the monthly complaints spreadsheet our regional manager uses." — your message | low | [inferred] | discovery | The sentence does not name Excel, so the link is this pack's inference, derived from the spreadsheet sentence. Lead with the spreadsheet, and do not call it Excel expertise until you have said which functions you used. Answer slot: see D3. |

Reading the table: F2 and F8 are gaps you stated, so their words are yours to say. F5 is a gap your material is silent on, so its words are an answer slot. F9 is inferred from one sentence and must not be upgraded in the room.

## Grounding brief: the company's current direction

Source: the strategy summary the recruiter sent you, as you pasted it. This is your copy of the summary, not the brief itself. Read the brief before 28 November and check each line against it.

| Item | What the summary says | Provenance |
|---|---|---|
| Digital | "move 40% of member service to digital channels by 2028" | [grounded] the summary you pasted |
| Branches | "consolidate eight branches into five hubs over 2027" | [grounded] the summary you pasted |
| Lending | "launch a small-business lending product in Q1 2027" | [grounded] the summary you pasted |
| Competition | "the main competitive pressure is app-only banks" | [grounded] the summary you pasted |

## Persona weights

No interviewer profiles were supplied, so the weights come from the round types. Depth follows weight: the top personas get 5 questions, the mid one 3, the low one 2.

| Round | Persona | Likelihood and reasoning | Counter-strategy | Weight and bank |
|---|---|---|---|---|
| 1. Recruiter screen | Conversational / rapport | High. A 30-minute screen is scored on logistics and motivation even in a friendly register. | A 90-second arc for the opening question; logistics answered in your own words. | 5, bank A |
| 2. Head of Member Services | Skeptic | High. The two gaps the JD names (the contact centre, presenting to senior leaders) are the first things a hiring manager checks. The round is also mostly behavioural, which lowers the weight of case questions. | Rehearse B1 until it is plain. Name your gaps first when asked. | 5, bank B |
| 2. Head of Member Services | Values / behavioural | High. The recruiter described the round as mostly behavioural. | STAR shape; "I" for your part. | 5, bank V |
| 3. Panel | Case / strategist | High. A 20-minute complaint escalation case is set. | Clarify, objective, segment, actions, change, metrics, risk. | 5, bank C |
| 3. Panel | Pressure / stress | Medium. Two members and a time box suggest it, but the panel's style is not stated. | Pause, restate, hold two follow-ups before conceding. | 2, bank P |
| 3. Panel | Data-driven prober | Medium. Branch managers run monthly reporting, and the JD puts reporting first in the list. | Know what the spreadsheet counts; name the assumption you would defend least. | 3, bank D |

The panel's members are not named, so the panel is weighted as a blend of the top two personas (values and case), with pressure and prober at lower depth.

## Prohibited claims

These are the claims this pack will not coach, and why. Each has its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end across branches and the contact centre | Inflated form of F1 and F2 | The quote at its own scope: "I handled the branch's formal complaints log and trained new tellers on our escalation script." Observation, in analysis only: your material shows the branch's log, not the process end to end. |
| Has worked in or run a contact centre | Negative you stated, F2 | Plain acknowledgment: "I've never worked in a contact centre." No slot on this claim. |
| Presented to senior leaders | Negative you stated, F8 | Plain acknowledgment: "I haven't presented to anyone above regional level." No slot on this claim. |
| Coached branch supervisors on escalations | Inflated form of F4 | The quote at its own scope: "trained new tellers on our escalation script." Observation: your material shows tellers, not supervisors. |
| Reported volumes and resolution times to leaders each month | Inflated form of F3 | The quote at its own scope: "I built the monthly complaints spreadsheet our regional manager uses." Observation: your material does not show what the spreadsheet counted. |
| Excel expert, or advanced Excel functions | Inflated form of F9 | The quote at its own scope. Observation: no software is named. |

Not listed, and handled as answer slots instead: any digital or self-service work (F5). Your material is silent, which is not the same as a denial.

## Question banks

Questions below are interviewer lines for rehearsal. Answer slots are instructions for the interview and ask for no reply here.

### A. Conversational: recruiter screen (round 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "So, walk me through your career so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." "I handled the branch's formal complaints log and trained new tellers on our escalation script." | About 90 seconds, in this order: six years in retail banking, the last three as a branch supervisor, the complaints log, then teaching new tellers the escalation script. Use your own words. Add no role, result or title the quotes do not give. | The opening arc. It draws on F6, F1 and F4, so every claim in it is one you can defend in round 2. |
| A2 | "What are your salary expectations for this role?" | JD | [generic] | Logistics slot: give your own figure, or ask what band the role carries before you name one. Do not give a figure you have not chosen. | Pay is a recruiter logistics check. The material holds no fact about your pay, so the slot holds only your choice. |
| A3 | "What's your notice period?" | JD | [generic] | Logistics slot: give the notice you actually owe, in your own words. If you are unsure of the contractual term, say so and say when you will confirm it. | Notice is a knock-out logistics check. The material holds no notice term. |
| A4 | "Where would you be based, and how many days a week could you be in the office?" | JD | [generic] | Logistics slot: state your location and the office days you can work, with any limit you have, in your own words. | The role's location pattern is not in the material. Only you can answer this. |
| A5 | "Why are you looking to move on from your current role?" | EXP | [generic] | Logistics slot: give the true reason in one or two sentences, then say what draws you to this role. Do not criticise your current employer. | The reason for leaving is a graded screen question. The material holds no reason for you. |

### B. Skeptic: Head of Member Services round (round 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You've never worked in a contact centre. How would you own complaints that run through one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Hold the fact first: "I've never worked in a contact centre." Then the slot: say how you would learn how complaints move through a contact centre, framed as a plan and never as a past. Hold through two follow-ups. On the second, concede the specific gap you would close first. Do not claim contact-centre knowledge you lack. | **Highest-ROI prep in this pack.** The JD puts the contact centre inside the complaints remit, and F2 is a stated gap the panel can check in one question. The question presupposes the JD's own line and your stated negative, nothing more. |
| B2 | "You've never presented above regional level. Why should senior leaders trust you to present to them?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then the slot: say how you would prepare a first presentation to senior leaders, as a plan. Do not argue that presenting at regional level is the same thing. Hold, then concede one specific step you would take first. | F8 is the second stated gap, and the JD scores it directly. The only material you gave is the negative, so the pack adds nothing to it. |
| B3 | "You handled the branch's complaints log. Which rules or time limits did it run to, and which parts of the process did you own from start to finish?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Say the log's scope in the quote's words: you handled it. Answer slot, rules and time limits: if you worked to particular rules or time limits on it, name them and say what you did to keep to them; if you did not track them, say so. Answer slot, steps: name the steps you ran from start to finish; if the log covered only part of the process, say which part. | Covers the JD's end-to-end line (F1) and its regulated-complaints line (F7). The premise is the quote. It names no rule, and the guidance supplies none. |
| B4 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Name the two stated gaps in your own words: the contact centre, and presenting above regional level. Then a plan for the first 30 days, in order. Do not invent a weakness to look humble. | The Skeptic's stem. Naming the gaps first lowers the cost of B1 and B2. |
| B5 | "Ashgrove plans to consolidate eight branches into five hubs during 2027. Where does your branch experience help with that?" | CO | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." | Use only the three years as a branch supervisor: the branch-level view that a hub change touches. Answer slot: if you were part of a branch change, say what it was and your part in it; if you were not, say so, and describe what you would check in a branch before a hub move. | The consolidation line is the company's current move. F6 carries the adjacent evidence. The premise is the summary you pasted. |

### V. Values and behavioural: round 2 and panel values scoring

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| V1 | "Tell me about a time you decided something from the member's side of the counter, when the process pointed the other way." | VAL | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Selection scaffold: pick a time a member's position changed a decision made against a rule or target. It needs a named stake, a moment you did not simply follow the process, and what the member got. If the complaints log holds such a time, use it. If none comes to mind, say so plainly, then give the nearest thing your material carries: how you handled the log. | Members First is the value the panel scores first. F1 is the only sentence you gave about member-facing work, so the honest branch may well be the one you need. |
| V2 | "When did you have to explain something to a customer more than once? What did you change?" | VAL | [grounded] "trained new tellers on our escalation script." | Scaffold: a time an explanation did not land, and what you changed, in words the member could follow. If the escalation script is the nearest case, say how you made it clear to new tellers. If you cannot name a case, say so, and say how you would check a letter or script with a member before using it. | Plain Words is scored on a real change, not on a claim to use plain words. The script is the nearest true case, held at its own scope. |
| V3 | "Tell me about a time a branch's local situation changed what you decided." | VAL | [generic] | Scaffold: a time the town around a branch (a local employer, a closure, a local habit) changed a decision. Your material does not show one. If none comes to mind, say so plainly, and say how you would check a branch's local context before a hub decision. | Neighbours, Not Numbers has no sentence of yours behind it, so the guidance supplies no story. |
| V4 | "Tell me about a problem you found that wasn't yours to fix, and what happened next." | VAL | [grounded] "I handled the branch's formal complaints log." | Scaffold: a time you kept hold of a problem until it was solved, with its stake and its outcome. If the complaints log holds one, use it. If you did not stay with a problem to its end, say so, and tell the nearest one with its real ending. | Own the Fix asks whether you stayed with the work to its end. The material shows the log, not an ending. |
| V5 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I've never presented to anyone above regional level." | Your material reaches regional level and no higher, so any example should be one you gave at that level. Answer slot: if you have one, name who it reached and what it was; if you do not, say so plainly, then say how you would deliver a hard truth to senior leaders, as a plan. Do not use an example aimed above regional level. | The stem for the values round. The guidance keeps the story inside the scope of your stated sentence. |

### C. Case / strategist: panel (round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | Case, 20 minutes: "A member has been bounced between a branch and the contact centre for three weeks over a fee. The branch says it's explained; the contact centre says the member has escalated twice. Walk us through what you'd do, and what you'd change so it doesn't happen again." | CASE | [generic] | Run it in an order the panel can follow. **Clarify**: what the fee is, what the member has been told, whether the complaint is logged, and which timescale applies (your complaints rules set it; ask for it in the room). **Objective**: one clear answer to the member and one named owner. **Segment** why it bounced: no owner, or no handover. **Actions today**: name one owner (Own the Fix), call the member with a plain summary (Plain Words), check the log entry (Members First). **Change the process**: one owner per complaint across branch and contact centre, and a handover rule. **Metrics**: time to resolution and repeat contacts. **Risk**: the branch supervisor's view. Pace: 4 minutes clarifying, 6 structuring, 6 actions, 4 on change. | The panel's case. It is scored on structure, on the value hooks, and on whether you clarify before you act. It presupposes no fact about your past. |
| C2 | "Ashgrove plans to move 40% of member service to digital channels by 2028. What does that do to the complaints process?" | CO | [grounded] "move 40% of member service to digital channels by 2028" | Name what moves to digital and what stays in branches. The complaints most likely to stay on the phone or at the counter are the hard ones. Keep one measure that stays visible across channels. Do not claim digital experience you lack; say what you would check first. | Strategy is the differentiator at this level. The figure is from the summary you pasted; check it against the brief before you say it in the room. |
| C3 | "Eight branches become five hubs during 2027. Where do open complaints go on the day a branch closes?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" | Clarify whether an open complaint moves with the member or stays with the branch. Name the owner. Say that each complaint's clock keeps running through the move, then say how you would confirm the timescale. Propose one check: the open-complaints list reviewed before the branch closes. | Tests whether you can plan for the seam, not whether you know the answer. The question presupposes only the summary's line. |
| C4 | "A branch supervisor sends you every escalation the same day it arrives. How would you coach them?" | JD | [grounded] "trained new tellers on our escalation script." | Ask first what they are escalating and why. Separate what they can decide from what needs you. Agree one threshold. Coach on one live complaint rather than in the abstract. Check again after two weeks. Answer slot: the nearest thing you have is training tellers on the escalation script; say how you would carry that over to supervisors, or say you have not done so. | Covers the JD's coaching line (F4). The script is the honest nearest case, and it is at teller level. |
| C5 | "What self-service journey would you want to fix first, and how would you work with the digital team on it?" | JD | [generic] | Pick a journey where complaints start, such as a member's own route to report a problem or to track a case. Say what you would measure before changing it. Then how you would bring the digital team in: a shared problem statement, and a test with real complaints. Answer slot: if you have worked with a digital team, say what it was and your part in it; if not, say so and give this approach. | Covers the JD's digital line (F5). Your material is silent on digital work, so the guidance describes an approach, not a record. |

### P. Pressure: panel (round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Sixty seconds: why should we hire someone who has never worked in a contact centre?" | JD | [grounded] "Never worked in a contact centre, and I've never presented to anyone above regional level." | Pause, then restate: "The contact centre is the part I haven't worked in." Then the case for the work you did, from your own quotes: the complaints log, and teaching tellers the escalation script. Hold through two follow-ups. Concede one specific: you would need to learn first contact in the contact centre before you led it. Do not argue the negative away. | The pressure version of B1. The sixty-second frame tests composure and a held position, not a new fact. |
| P2 | "That complaints log. How much of it was actually you?" | EXP | [grounded] "I handled the branch's formal complaints log and trained new tellers on our escalation script." | Hold on what you did: you handled the log and trained the tellers. Concede exactly where your part stopped, naming any decision that was your manager's or the regional team's. Answer slot: if decisions on those complaints were yours, say which; if they were not, say so. | An attribution probe on F1. The hold is only the quote; the concession marks the honest edge of it. |

### D. Data-driven prober: panel (round 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Walk me through what the monthly spreadsheet holds, and how its figures were worked out." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Say what the spreadsheet holds, in its own terms. Name the assumption behind the figure you would defend least, and say which part you built. Answer slot: if you set the counting rules, say which; if your regional manager set them, say so; if you cannot say how a figure was worked out, say so plainly. | The prober's question for a reporting role, and reporting is in the JD (F3). The premise is only that you built the sheet. |
| D2 | "A monthly report says resolution times fell this quarter. What would you check before you believed it?" | JD | [generic] | Check the clock: where it starts and where it stops. Check complaints closed without resolution, reopened cases, and whether the mix of complaints changed. Then say what you would show a senior leader alongside the number. | Covers the reporting line with a general pattern. It makes no claim about you or about the company. |
| D3 | "What did you use to build that spreadsheet, and what could it do?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Name the tool and the functions you used, in your own words. Answer slot: if you did not use Excel, say what you did use. Do not claim functions you cannot show. | Excel is a JD requirement with no sentence of yours behind it (F9). The question asks you to name the tool rather than assume it. |

### Requirement coverage

| JD requirement | Covered by | Note |
|---|---|---|
| Own the complaints process end to end across branches and the contact centre | B1, B3, P1 | B1 covers the contact-centre half. |
| Report monthly on complaint volumes and resolution times | D1, D2, D3 | |
| Coach branch supervisors on escalations | C4 | |
| Work with digital teams on self-service journeys | C5, C2 | |
| 4+ years in financial-services customer operations | A1 | The quote carries it; A1 walks through the years. No separate JD question. |
| Experience handling regulated complaints | B3 | |
| Confident presenting to senior leaders | B2, V5 | |
| Comfortable with Excel reporting | D3, D1 | |

All four values have a values question: V1 to V4. V5 covers the behavioural stem.

## Values cheat sheet

Values are the copy you pasted from the company's values page on 19 November 2026. Check them against the page before the interview.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter. | No sentence of yours carries a story here. F1 is the nearest. Use V1: a selection scaffold, with its honest branch. |
| Plain Words | If a member needs it explained twice, the wording was wrong. | F4 carries "trained new tellers on our escalation script." Use V2: a scaffold, with its honest branch. |
| Neighbours, Not Numbers | Every branch is part of its town. | No sentence of yours carries a story. Use V3: a selection scaffold, with its honest branch. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved. | F1 is the nearest. Use V4: a scaffold, with its honest branch. |

## Reverse questions

Ask two or three in the room. Each one is a question about the job, not about your interview.

| Question | Why it lands |
|---|---|
| "When a complaint has bounced between a branch and the contact centre, who owns it, and how is that decided?" | It shows you have thought about the seam the role must fix, and it gets you the ownership rule the role is meant to create. |
| "How will open complaints be tracked through the branch consolidation into five hubs?" | It ties your question to the 2027 brief, and it shows you read it. |
| "How much of the monthly complaints reporting is built by hand today, and what would you change first?" | It invites the manager to describe the reporting as it is, which is where the reporting part of the role starts. |
| "How does the role work with the digital team on self-service: who decides what goes into a journey?" | It puts the digital requirement to the manager, and shows you understand that it is shared work. |
| "What would a strong first 90 days look like in this role?" | It asks for the bar in the manager's own terms, and it gives you the plan that B4 asks for. |
| "What did the last person in this role get right, and what would you have them change?" | It gets the manager's view of the role's real demands, not the job description's. |
| Reciprocity, for the panel: "What could a new person do in their first month that would genuinely help your branch?" | It makes the panel a peer conversation, and it shows you are thinking about their branch, not only your own job. |

## Sources

- **Provided documents:** the job description you pasted; the recruiter's email (rounds, timings, panel scoring); the four values, copied from the company's values page on 19 November 2026; the strategy summary the recruiter sent, as you pasted it; your background, as stated in your message.
- **Dossier:** none present.
- **Searches and fetches:** none sent. The inputs above covered each research target, so no search was needed.

Research tier: L1 — searches 0 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | skipped | The values you pasted fix the values cheat sheet. Checking them against the live page is the one thing left. |
| 2. Interview process | skipped | The recruiter's email fixes the rounds, timings and scoring. |
| 3. Company strategy / recent news | skipped | The summary you pasted fixes the grounding brief. The brief itself would sharpen C2 and C3. |
| 4. Named interviewer | n/a | No names were given, so there was no query to form. |
| 5. Representative JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The names of the panel members and the Head of Member Services → personas weighted per person, an interviewer read, and a reverse question tied to their own path
- The strategy brief itself, not the summary → C2 and C3 worded from the brief's own text, and a grounding brief you can cite
- Your CV → fit snapshot evidence cited as "your CV" rather than "your message", with any CV lines probed in the banks
- Ashgrove's complaints policy or escalation stages, if the recruiter will share them → C1 and C4 made concrete rather than generic
- Prep time before 28 November → a prioritised triage section, sized to the time you have
- Deep research, offered not run: up to 6 further searches and 2 further fetches on the brief, the panel members' public talks, loop reports and recent news. It adds a few minutes of research time → persona weights and a sharper company bank
- The recruiter's reply on whether any deliverable is due before the rounds → build sections for it (none now)
- A tuesday-dossier.md → a record of the gaps this prep exposed, for later sessions
