# Interview prep pack: Live Operations Producer, Saltmarsh Games

**Role:** Live Operations Producer
**Company:** Saltmarsh Games (mobile games, about 350 people, from your note)
**Interviewer:** Tobias Wrenfield, Head of Live Operations. Relationship not confirmed; this pack assumes a hiring-manager round.
**Format:** 60 minutes, Friday. Round type and panel composition not stated.

---

## How to use this pack

Personas describe how a question arrives. Types describe what it scores.

| Type | Meaning in this pack |
|---|---|
| EXP | Work-experience deep-dive: what you actually did, and whether it holds up under questions |
| JD | Role-driven: whether you can do the listed job, including its gaps |
| CASE | Hypothetical or live problem from the role, scored on structure and reasoning |
| CO | Company and strategy knowledge. Not covered: no research was run |
| VAL | Values alignment. Not covered: no published values were in hand and no values-style round was detected |

Guidance is scaffolding, not a script. Say it in your own words. Do not memorize a sentence you cannot back with something you did.

---

## Fit snapshot

The requirements are the sentences of the JD you pasted. The evidence is your message, quoted verbatim.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | transferability | The material does not show two titles or live events. Words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD names two titles and live events, so expect a probe on whether you planned for more than one title or ran events rather than drops. If you did, say which and how, in your own words. If not, say so, and say which part of the calendar work you would expect to carry to a second title and what you would need to learn first. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years" (your message) | medium | [grounded] | none | No gap. The quote runs a content calendar in the JD's own terms. Expect a probe on how the calendar was run; answer it from the same sentence. |
| F3 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | Your material shows a QA-facing artifact and nothing about coordinating design, art, engineering or community on an update. That is silence, not a stated absence, so the bridge claims no coordination. Answer slot: if you coordinated with design, art, engineering or community on an update, say which team, what was agreed and how you did it. If you did not, say so plainly, and say how you would set that coordination up in your first month. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | transferability | Presenting numbers is adjacent to owning a review and the KPIs behind it. Words: "Presented the monthly retention numbers to the studio head." Answer slot: the JD asks you to own the review and its KPIs, so expect a probe on who set what the numbers measured and whether you ran any review. If you set or ran either, say what and how. If not, say what you presented and whether anyone reviewed it. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses" (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: a checklist you wrote, that QA still uses. Words: "Wrote the release checklist our QA team still uses." Expect a probe on who maintains it now and who signs releases off. Answer slot: if you maintain it or sign releases off, say so and how. If you wrote it and have not kept it up since, say that. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio" (your message) | low | [inferred] | discovery | The years are there. Whether the title ran as a live service is not in your material, and the bridge does not supply it. Words: "4 years as an associate producer at a puzzle-game studio." Answer slot: if the puzzle title ran as a live service, with updates after launch, say what that looked like in your words. If it did not, say what the four years covered. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head" (your message) | medium | [grounded] | presentation | The quote reaches retention in the JD's terms. Words: "Presented the monthly retention numbers to the studio head." Expect a probe on how a retention number was defined and counted. Answer slot: say what you know about the definition in your own words, and say what you do not know, including whether someone else set it. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses" (your message) | low | [inferred] | discovery | Your material shows written artifacts. It does not show how clearly they read. Answer slot: name one written thing you would show, say who used it, and say what they did with it. |
| G1 | Stated gap, not a JD requirement: leading a team (your message) | "Never led a team" (your message) | none | [grounded] | capability | Words: "Never led a team." The JD asks you to coordinate four teams and does not use the word lead, so the probe will most likely come through the coordination line (see F3). |
| G2 | Stated gap, not a JD requirement: in-app purchases (your message) | "never worked on a game with in-app purchases" (your message) | none | [grounded] | capability | Words: "I've never worked on a game with in-app purchases." Then a plan, not a past: what you would learn first about purchase-driven events. The JD names retention and KPIs and does not mention monetization. |

**Pack observation, not words for you:** the JD says coordinate, not lead, and says nothing about monetization. Your two stated gaps are therefore not JD lines, but an interviewer reading your CV will reach them. Your material is also silent on live-service titles, which the JD names directly (F6).

---

## Reading the interviewer

Not available. No public footprint for Tobias Wrenfield was researched, so there is no career pattern, style or published material to read. Persona weights use the hiring-manager prior only, and no reverse question is tied to Tobias's path. See the upgrade menu.

---

## Persona table

No loop source establishes the loop, so the pack falls back to the Generic archetype: a screen, a hiring manager, then a panel, with flat weights. These weights come from the hiring-manager prior and from your gaps. They do not come from Saltmarsh's documented process, which was not checked. No values-style round is detected, so there is no values section.

Depth: top persona 5 questions, mid personas 3, low personas 2.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (top, 5) | Probes the three-year bar, the two titles, the coordination line and your two stated gaps | High. The JD lines and your own two stated gaps make this the likeliest line of questioning. A hiring manager's first job is to derisk | Rehearse A2 and A3 until the plain acknowledgment is boring. Bridge only from your quotes |
| Case/Strategist (mid, 3) | Live problems on the calendar, art and engineering capacity, and a retention dip | High. The JD's calendar and coordination lines are case material | Clarify, then structure, then name checks and a written decision |
| Data-Driven Prober (mid, 3) | Asks how retention was defined and counted, and what a KPI measured | Medium-high. The JD names retention metrics, and F7 is a presented number with no method attached | Say what you know about the number. Name the assumption you would defend least, if you know one. Say plainly when you do not know |
| Peer Evaluator (mid, 3) | Seams between design, art, engineering, community and QA | Medium. Rises sharply if the round is a panel of those leads | Propose seam rules rather than claiming you have run them |
| Pressure (low, 2) | Time-boxed challenges on the three-year bar and on the checklist's ownership | Low to medium. A hiring manager may still test composure | Hold a position through two follow-ups, then concede the real gap |
| Conversational (low, 2) | The opener, and the "anything else?" at the end | Medium. The first five minutes are scored, even when casual | Use the F1 arc from the Conversational bank. End with your own reason for the role |

---

## Question banks

Each row's Provenance carries the label first, then every sentence of yours the guidance rests on, quoted exactly. A row with a [generic] label makes no claim about you.

### A. Skeptic (top persona, 5 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Our role plans the live-events calendar for two titles. What from your calendar work carries over to two?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years" | Open with the calendar in those words: weekly, the main title, the last two years. Then name one part you expect to carry over, framed as what you would do, not as something done. Answer slot: if you planned for more than one title, or ran live events rather than drops, say which and how, in your own words. If not, say so plainly, and name what you would learn first about a second title. Do not claim a second title by analogy | F1 is the evidence for the calendar requirement. The two-title premise is the JD's own line, so the question may presuppose it; the guidance does not adopt it as your experience |
| A2 | "You've never worked on a game with in-app purchases. What would you need to learn before you planned events for a title that has them?" | EXP | [grounded] "never worked on a game with in-app purchases" | Highest-return rehearsal in this pack. Plain acknowledgment first: "I've never worked on a game with in-app purchases." Then a plan: what you would ask about the title's reported KPIs, how you would learn how purchases are measured, and how you would read the first event against a baseline you set. Hold without claiming purchase knowledge by analogy to the puzzle title. If the second follow-up is "so you'd be learning on our time?", concede it plainly: yes, the first weeks would carry the learning, and say what you would do to shorten it | This is your stated gap, and the most likely objection to this candidate. The question's premise is your own sentence, so it may rest on it. The honest answer is the acknowledgment plus a plan |
| A3 | "You've never led a team, and this role coordinates four. Why would that work?" | JD | [grounded] "Never led a team", "Wrote the release checklist our QA team still uses" | Plain acknowledgment: "I've never led a team." Then the difference you can speak to: coordination is the JD's word. Answer slot: name one release or update where you worked across teams, what you did, and who you worked with. If the work was mainly with QA, say that. If you have not coordinated across teams, say so plainly and describe how you would build that coordination in your first month | Your stated gap, raised through the JD's coordination line (F3). The guidance claims no leadership; the quote carries only the QA checklist |
| A4 | "Which part of this JD would you be weakest at on day one?" | JD | [grounded] "Never led a team", "never worked on a game with in-app purchases" | Name one of your two stated gaps in your own words, then the ramp: what you would do in the first thirty days to close it. Do not add a third weakness you have not stated. Answer slot: if your weakest area is one you have not named here, name it and describe the ramp | An open prompt about the role. Your two stated gaps are the only candidate sentences it can draw on; the JD's live-service line is a further gap, not yet a stated one (F6) |
| A5 | "The JD asks for three years on live-service titles. Why should we take you over someone who has that?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years" | Do not argue the comparison. Hold on what you did: four years at a puzzle-game studio, and two years running the weekly content-drop calendar for the main title. Concede what you cannot claim: live-service titles, if none are on your record. Hold through two follow-ups. On the second, concede plainly that someone with that record would be the safer hire for the first quarter, and say what you would do to show you learn fast. Answer slot: if the puzzle title ran as a live service with updates after launch, say what that was in your words. If not, say what it was, and do not call it live service | Premised question, presupposing the JD's three-year line, which is a raising source. F6 is the evidence and it is thin, so the hold must stay at what the two quotes carry |

### B. Case/Strategist (mid persona, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Retention dropped 15 percent in the month after a title's last major event. You have the next two weeks. What do you do?" | CASE | [generic] | Clarify first: what the 15 percent is measured against, which players, and whether the event is the only thing that changed. Then an objective, the segments you would check, and a short list of checks you could run in a day. Name the post-event review you would run and what it would measure. Say the risk of acting before you know the cause | A live problem on the JD's retention and review lines. The case is a pattern for the problem, not a fact about this studio or about you |
| B2 | "You have eight weeks, two titles, one shared art team and an engineering sprint that is already full. Plan the event calendar." | CASE | [generic] | Clarify the constraints: art capacity per title, what engineering can carry, and which dates are fixed. Sequence by dependency, and treat the release checklist as a gate on every event, not a last step. Name one trade-off you would make and why. Show the calendar as a written page: dates, owners, gates | The calendar line and the coordination line of the JD put this case on the role's real work. The case is generic: it presumes nothing about your past |
| B3 | "A live event is ready. QA's checklist flags one item, engineering calls it minor, and design wants it out today. What happens?" | CASE | [grounded] "Wrote the release checklist our QA team still uses" | Separate the three positions. Ask what the flagged item protects against and who owns the call. The decision is yours to make and to write down, with who agreed and what was accepted. Name the release checklist as the record the call goes into. If you have made a call like this before, tell it in your own words. If not, say how you would make it | The checklist line of the JD and the written-communication line both sit in this decision. The only candidate sentence is the checklist quote, and the guidance claims no past decision |

### C. Data-Driven Prober (mid persona, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me what the retention numbers you presented measured, and how they were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what they measured, in your own words, and what you know about how they were counted. Name the assumption you would defend least, if you know one. Answer slot: if you set the definition or know how it was counted, say how. If someone else set it, say so, and say what you did with the numbers. If you did not know the method, say that plainly | F7 is the evidence. The probe on definition is the likeliest follow-up to a presented number, and the question's premise is the quote's |
| C2 | "Which assumption behind that retention figure would you defend least?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Name the assumption you would defend least, in your own words, before they do, if you know one. If you do not know the assumptions, say that. Do not name one you cannot stand behind | A Prober stem. Its premise, that a figure exists, is the quote's. The weakest-assumption move converts a gotcha into a credibility gain |
| C3 | "The role owns the post-event review and the KPIs it reports. How would you structure one?" | CASE | [grounded] "Presented the monthly retention numbers to the studio head" | Structure in order, in about a minute: what the event was meant to do, the target set before launch, the read window, what counts as a miss, and who decides the follow-up. Then: if you have run a review after an event, say what it covered. If you have only presented numbers, say that, and say you have not owned a review | A JD-raised process question, so the structure is generic. The candidate's part rests on the quote, and the answer names what you have not done, not what you did |

### D. Peer Evaluator (mid persona, 3 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Design and engineering disagree on what ships in an update. You're the producer. What do you do?" | CASE | [generic] | Find what each side is protecting and what each date costs. Decide who owns the call, make it, and write it down: what was cut, who agreed, and when you will check. Keep the checklist as the gate, not the tiebreaker. If you have a past case like this, tell it in your own words | The JD's coordination line raises a seam between teams. Generic: it is a pattern for the problem |
| D2 | "Tell me about a time you coordinated across teams on an update." | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Open prompt: take the example you have and tell it in the order it happened. If it is the QA checklist, tell it that way: what you wrote and who uses it now. Answer slot: if you coordinated with design, art, engineering or community on an update, name the team, what was agreed, and what you did. If you have not coordinated across those teams, say so plainly and describe how you would set it up in your first month | The theme comes from the JD's coordination line, a raising source. F3 is discovery, so the only candidate sentence is the QA quote, and the slot holds the honest branch |
| D3 | "Community says a live event is confusing players. Engineering's fix is two sprints out. What do you tell players, and what do you write down?" | CASE | [generic] | Separate the message from the fix. For players in the meantime: what they see now, what the team says, and when. Write the decision in one place, with the owner, the date and the known cost of waiting. Name the post-event review as where the fix gets checked | The community and written-communication lines in the JD put a decision in writing. Generic: the case is a pattern |

### E. Pressure (low persona, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we take you over someone with three years on live-service titles?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Presented the monthly retention numbers to the studio head" | Hold the position you can back: four years at a puzzle-game studio, two years running the weekly content-drop calendar for the main title, and presenting retention to the studio head. Concede the real gap: no live-service titles in your material. Hold through two follow-ups. Do not add anything to the hold under pressure | A short time-boxed version of A5. The hold is only what the quotes carry, and a held position you cannot back is the one the second follow-up breaks |
| E2 | "What happened after you presented retention to the studio head?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head" | Say what followed, in your own words, if anything did. Answer slot: if a decision came from the numbers, say what it was and whether it was yours to make. If nothing followed, or you do not know, say so. Do not invent a reaction | A pressure follow-up on a presented number. The question presupposes only the presentation. Its second branch allows that nothing followed |
| E3 | "How much of that checklist is actually yours?" | EXP | [grounded] "Wrote the release checklist our QA team still uses" | Hold: "I wrote it. QA uses it." Concede what you do not know: whether it has changed since you wrote it, and who keeps it now. Answer slot: if you have changed it or sign it off, say so. If you wrote it and have not kept it up since, say that. Do not claim the rest of the checklist | The "how much was you" probe tests attribution. The hold is the quote, and the concession is what the material does not show |

### F. Conversational (low persona, 2 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio", "I ran the weekly content-drop calendar for our main title for the last two years", "Wrote the release checklist our QA team still uses", "Presented the monthly retention numbers to the studio head" | A 90-second arc in these four sentences, in this order. Then name your two gaps plainly: "Never led a team" and "never worked on a game with in-app purchases". Answer slot: say why this role, in your own words. The material gives no reason, so the reason must come from you | A casual opener is scored for economy and honesty. The arc uses only your sentences, and the reason for the role is a slot, not a claim |
| F2 | "What's a live event you've played and liked, from any game?" | CASE | [generic] | Name one event and its game. Say what you saw in it and why you think it worked, in terms of what you observed. Do not cite numbers you have not seen | A casual question on live-ops craft. Scored for specificity and judgement. Generic: it presumes nothing about you |

---

## Requirement coverage

| JD requirement, or stated gap | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A1, B2 |
| Coordinate design, art, engineering and community teams on each update | D1, D2, D3, A3 |
| Own the post-event review and the KPIs it reports | C2, C3, E2 |
| Manage the release checklist with QA | B3, E3 |
| 3+ years producing live-service games or apps | A5, E1 |
| Experience running a content calendar | A1, B2 |
| Comfortable with player-retention metrics | C1, C2 |
| Clear written communication | B3, D3 |
| Stated gap, not a JD requirement: leading a team | A3 |
| Stated gap, not a JD requirement: in-app purchases | A2 |

---

## Interview pacing (60 minutes)

*Added at your request. This is beyond the pack's standard sections. It is a plan for holding time, not a script; the interviewer sets the order.*

| Minutes | Block | Questions |
|---|---|---|
| 0 to 5 | Opener and your arc, then your two gaps named plainly | F1 |
| 5 to 20 | The JD's calendar and the gaps. Give A2 the most time | A1, A2, A5 |
| 20 to 35 | Coordination across teams, and leadership | D2, D1, A3, D3 |
| 35 to 50 | Metrics and the review | C1, C2, C3, E2 |
| 50 to 55 | Checklist and a live call. Use only what has not come up | B3, E3, B1 or B2 |
| 55 to 60 | Your reverse questions. Pick two from the list below | R1, R2, R4 |

If time runs short, cut the case questions first. A2 and A5 are the two you cannot skip.

---

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which two titles would this role plan for, and where is each in its life cycle?" | Shows you read the JD's "two of our mobile titles" and gives you the calendar's real shape |
| R2 | "For a title with in-app purchases, which KPIs does the role report, and who sets them?" | Asks about your stated gap directly, and about the KPIs you would own |
| R3 | "Where does the release checklist get signed off, and who can stop a release?" | Tests the QA line and decision rights, which is B3 turned around |
| R4 | "What did the last post-event review change, and who read it?" | The JD's review line. Shows you care whether a review drives action |
| R5 | "What does a producer who is doing well here look like at six months?" | Asks for the success measure without a product question. Scores as interest in the job |

None of these is tied to Tobias's own career path. That requires the public-footprint research listed in the upgrade menu.

---

## Sources

- **Provided documents:** the JD you pasted, and the background in your message. Quotes labelled "your message" are your sentences, verbatim.
- **Dossier:** none present.

**Research tier: L0, no searches, user links read 0.**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | No values page in hand, none fetched. Would have moved the values cheat sheet; the section is dropped because no values-style round is detected |
| 2. Saltmarsh Games interview process, live operations | unavailable | Would have named the rounds and their interviewers. Without it, the loop falls back to the Generic archetype with flat weights |
| 3. Saltmarsh Games strategy and recent news | unavailable | Would have grounded one CO question and the case questions in current strategy. The cases here are generic |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Would have given the interviewer read, persona weights from his footprint, and a reverse question tied to his path |
| 5. Representative live operations producer JD | skipped | The JD you pasted fixes the fit snapshot and the JD-tagged questions |

You asked me to flag where company research would help rather than run it, so I took that as declining research, and no search was sent. If you want the research run before Friday, say so.

---

## Prohibited claims

Built locally from the fit snapshot. Each entry names its basis and its honest form. No answer, hold or reverse question in this pack asserts any of these.

| Not coached | Basis | Honest form |
|---|---|---|
| Led a team, or managed people | Negative you stated (G1) | "Never led a team." Plain acknowledgment, no slot |
| Worked with in-app purchases, or has monetization experience | Negative you stated (G2) | "I've never worked on a game with in-app purchases." Plain acknowledgment, no slot |
| Ran a live-events calendar for two titles | Inflated form of F1 | The quote at its own scope: the weekly content-drop calendar for our main title. Your material does not show two titles or live events |
| Live-service titles, or live-service experience | Inflated form of the years line (F6) | "4 years as an associate producer at a puzzle-game studio," at its own scope. Your material does not say the title was a live service |
| Owned the post-event review, or owned the KPIs | Inflated form of F4 | "Presented the monthly retention numbers to the studio head." Your material shows the presenting, not the owning |
| Defined the retention metrics | Inflated form of F7 | The same presenting quote. Whether you set the definition is an answer slot, not a claim |
| Coordinated across design, art, engineering or community on updates | Inflated form of the QA checklist (F3) | "Wrote the release checklist our QA team still uses." The coordination is an answer slot, not a claim |

---

## Upgrade menu

- **Tobias Wrenfield's public footprint** (talks, posts, career path) → an interviewer read, persona weights from his footprint, and a reverse question tied to his path
- **Saltmarsh's values page**, as a link or pasted text → a values cheat sheet, if a loop source documents a values-style round
- **The round's format**: Tobias alone or a panel, and who else sits on it → persona weights for each member. A panel raises the Peer Evaluator bank
- **Saltmarsh's current strategy or recent news**, as a brief you paste or a research pass → a CO question and case questions grounded in current strategy, where B1 to B3 are now generic
- **Whether the puzzle title ran as a live service after launch**, in a sentence or two → F6, A5 and E1 rewritten from your words
- **How many items the release checklist covers, and who signs it off**, in your words → F5 and E3 gain the missing facts
- **A written artifact you would show**, with who used it → F8 gains a named artifact
- **The recruiter's note on focus areas or a case exercise**, if there is one → coverage weights, and a build section for any deliverable
- **No dossier is present.** A `tuesday-dossier.md` would record the gaps this prep exposed for later sessions
