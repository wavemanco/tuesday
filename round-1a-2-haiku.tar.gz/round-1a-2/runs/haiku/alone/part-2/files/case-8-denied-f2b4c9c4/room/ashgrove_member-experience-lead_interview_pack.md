# Interview pack: Member Experience Lead, Ashgrove Credit Union

Candidate: Dara. Rounds: 28 November 2026, three rounds (loop mode). Prepared 19 November 2026.

## How to use this pack

- **Personas** describe how a question arrives. **Types** describe what is being scored.
- Type key: **VAL** values alignment (the published values) · **EXP** your own experience and what you attributed to yourself · **JD** the listed job and its requirements · **CO** company and strategy · **CASE** a live problem.
- Guidance is scaffolding, not a script. Every sentence about your past is quoted from your message, marked "your message", or it is an answer slot for you to fill in your own words.
- Answer slots are instructions for the interview. They ask you for nothing here.

## Fit snapshot (shared across rounds)

You gave me no CV, so every quote comes from your message. The JD is treated as the scoring sheet. No JD requirement is a gate in the sense of a legal or credential bar, so none is surfaced as a gate. The "4+ years" line is graded on fit, not treated as a gate.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | medium | [grounded] | presentation | Say the same facts in your words: six years in retail banking, the last three as a branch supervisor. Your material says "retail banking", not the JD's phrase, so do not borrow the JD's wording as your title. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | "I handled the branch's formal complaints log." Expect a probe on what made those complaints regulated. Answer slot: if you worked to specific rules or deadlines, name them; if the log did not carry them, say so plainly. |
| F3 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | "I haven't presented to anyone above regional level." Then how you would prepare for a senior audience, said as a plan and never as a past. |
| F4 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | "I built the monthly complaints spreadsheet our regional manager uses." Your material says spreadsheet, not Excel. Do not name Excel skills you cannot show. |
| F5 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Adjacent work at one branch and one log. "I handled the branch's formal complaints log." Limit: the material does not show end-to-end ownership. Answer slot: if you took a complaint from first contact to close, say which steps you ran; if others ran parts, say so. |
| F6 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | "I haven't worked in a contact centre." Then how you would learn the channel, as a plan. No claim of contact-centre complaint work. |
| F7 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | transferability | Adjacent: a monthly spreadsheet, not volumes or resolution times shown. Answer slot: say what the spreadsheet recorded, in your own words. If it did not record resolution times, say so and say what you would add first. |
| F8 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | "I trained new tellers on our escalation script." Adjacent: teller training, not supervisor coaching. Answer slot: if you coached anyone on how to decide an escalation, say who and how; if not, say so and say how you would coach supervisors, as a plan. |
| F9 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Answer slot: if you have worked with a digital or product team on a customer journey, say which and what your part was; if not, say so plainly. |

**Requirement coverage.** Each JD line and the questions that cover it.

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | S1, B1 |
| experience handling regulated complaints | B4, P5 |
| confident presenting to senior leaders | B2 |
| comfortable with Excel reporting | B3, P7 |
| own the complaints process end to end across branches and the contact centre | B1, P6 |
| report monthly on complaint volumes and resolution times | B3, P7 |
| coach branch supervisors on escalations | B10 |
| work with digital teams on self-service journeys | B9 |

## Grounding brief (shared)

Source: your summary of Ashgrove's July 2026 strategy brief. The brief text was not pasted, so check every figure against it before you quote one.

- Digital: "move 40% of member service to digital channels by 2028"
- Branches: "consolidate eight branches into five hubs over 2027"
- Lending: "launch a small-business lending product in Q1 2027"
- Competition: "the main competitive pressure is app-only banks"

Use "digital channels", "hubs" and "app-only banks" as they appear here. Expect the consolidation to be probed hardest, because it runs against the "Neighbours, Not Numbers" value (see B9, P8). Do not offer a view on the plan you have not seen. Ask about it.

---

## Round 1: Recruiter screen, 30 minutes

**Persona table**

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Conversational / rapport | Open journey question, casual asks | Top weight. A recruiter screen is conversational, and the relationship prior puts this first. | Rehearse one 90-second arc. |
| Logistics (knockouts) | Pay, notice, location, reason for leaving | Standing weight. The recruiter checks these before anyone else does. | Give your own answers in your own words. |
| Skeptic (light) | "Why this, why now", the contact-centre gap | Mid weight. Light-touch, but the gap will come up. | Say the limit once, plainly. |

**Question bank (8)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "Walk me through your journey so far." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor."; "I handled the branch's formal complaints log" | Give a 90-second arc in your own words: the six years, the last three as branch supervisor, then the formal complaints log. Add no role, title or responsibility the sentences do not state. | The most likely opener. The arc is where a CV line gets repeated, so it must match what you wrote. |
| S2 | "What's drawing you to this role?" | JD | [generic] | Answer slot: give your own reason, in your own words. The material gives none, so this is not a script. | Motivation consistency is the light-skeptic check. [generic] because this is a stem, not a fact about you. |
| S3 | "What are your pay expectations?" | JD | [generic] | Logistics slot: give your own figure, or ask for the band first. | A knockout. The material gives no figure, so none is supplied. |
| S4 | "What notice would you need to give?" | JD | [generic] | Logistics slot: give the notice you actually owe. | Same logic as S3. The material does not state it. |
| S5 | "Where are you based, and what working pattern can you do?" | JD | [generic] | Logistics slot: give your actual location and working pattern. | The hub plan makes location a live question later, so keep this exact. |
| S6 | "Why are you leaving your current role?" | EXP | [generic] | Logistics slot: give your reason in one true, forward-looking sentence. Never give a reason you did not give. | The panel may follow up on this. Keep it short and true. |
| S7 | "How do you feel about the contact-centre side of this role?" | JD | [grounded] "Never worked in a contact centre" | "I haven't worked in a contact centre." Then how you would learn the channel, as a plan. No claim of past contact-centre work. | F6 is the gap the later rounds will test. Say it once, plainly, here. |
| S8 | "What's the part of your work you're proudest of?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Use the spreadsheet: you built it, it is monthly, your regional manager uses it. Say those in your words. If something else is the part you are proudest of, say that instead. Do not add what the spreadsheet changed. | An open prompt. The spreadsheet is the nearest sentence the material carries. |

**Reverse questions**

| Question | Why it lands |
|---|---|
| "Who will be on the three rounds, and what does each one assess?" | Shows you are planning. It asks for the panel structure. |
| "What has been hardest for the complaints function this year?" | Signals you want the real problem, not the job advert. |
| "What would success look like at six months?" | Invites a measurable answer you can plan against. |
| "How does the digital target in the strategy shape this role's first year?" | Shows you have read the brief. |
| "What is the timeline from the final round to a decision?" | Practical, and it shows you are serious about the role. |

---

## Round 2: Head of Member Services, 45 minutes, mostly behavioural

The Head of Member Services would be your manager. The personas weight toward Skeptic because a manager is buying capability and checking the gaps.

**Persona table**

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | The contact-centre gap, presenting above regional, the reporting claim | Top weight (5). A manager derisks the gaps before she hires. | Hold the position through two follow-ups, then concede the specific gap. |
| Values / behavioural | STAR-shaped prompts on the four values | Mid weight (3). The round is "mostly behavioural". | Use the nearest sentence you have, and name the limit where there is no story. |
| Case / strategist | The digital shift and the hub plan | Lower weight (2). A manager's roadmap question is likely, but not the main event. | Name what you would watch. Do not argue the plan. |

**Question bank (10)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Complaints also come through the contact centre, and you haven't worked in one. What makes you the person to own them end to end?" | JD | [grounded] "Never worked in a contact centre"; "I handled the branch's formal complaints log" | Hold, then concede. Say: "I haven't worked in a contact centre. I handled the branch's formal complaints log." Hold the branch-scope claim through two follow-ups. Answer slot: if you have handled a complaint that began in a contact centre, say so and what you did; if not, say so plainly and say how you would learn the channel, as a plan. Concede the specific gap, never the core claim you can back. | **Highest-ROI prep in this pack.** The JD names the contact centre and F6 is the gap. The second follow-up is where a held position usually breaks. |
| B2 | "Tell me about the most senior audience you've presented to." | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment first: "I haven't presented to anyone above regional level." Then name the largest audience you did present to, and what you showed them, in your own words. If that was regional, say so. Then how you would prepare for a senior audience, as a plan. | F3 is a stated gap, so the honest answer is the limit, given without bluffing. |
| B3 | "Tell me what your monthly complaints spreadsheet recorded." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: say what it recorded, in your own words. If it recorded volumes but not resolution times, say so and say what you would add first. Do not describe a measure you did not track. | F7 and F4. The JD asks for volumes and resolution times monthly. The quote carries only the spreadsheet. |
| B4 | "Tell me about a formal complaint you took through to the end." | EXP | [grounded] "I handled the branch's formal complaints log" | Story-mapped on the quote: the log, and the entries you handled. Name one complaint, what you decided, and what was decided above you. Answer slot: expect "what made that complaint regulated?" If you worked to specific rules or deadlines, name them; if the log did not carry them, say so. | F2, the best evidence for the regulated-complaints line and its likeliest probe. |
| B5 | "Tell me about a time you decided a complaint from the member's side of the counter, when the procedure pointed the other way." | VAL | [grounded] "Members First, Always: we decide from the member's side of the counter." (published value, pasted) | Selection scaffold: pick a complaint where you went against the procedure for the member's sake, and say what the procedure said. If none comes to mind, say so plainly, then give the nearest thing your log carries: the complaint from B4, and what you decided. Do not supply an ending the material does not carry. | No quoted sentence carries this story, so the scaffold ends in its honest branch. |
| B6 | "Tell me about an explanation you gave a member that they had to hear twice." | VAL | [grounded] "trained new tellers on our escalation script"; "Plain Words: if a member needs it explained twice, we wrote it wrong." (published value, pasted) | Selection scaffold: if you explained something twice, say what you changed the second time. If no such time comes, say so, then give the nearest thing your material carries: the escalation script you trained tellers on. Say what it said, and only claim it was clear if you know it was. | The published value sets the bar. The teller script is the nearest sentence. |
| B7 | "Tell me about a problem you found and kept until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold: pick a problem you found and held until it was solved, and say what it solved. If none comes to mind, say so plainly. The nearest thing is the spreadsheet: say what problem it addressed, and whether you saw the fix through. If you did not, say that. | "Own the Fix" is tested by "until it is solved". The spreadsheet is the nearest sentence, and the honest branch is required. |
| B8 | "A member's complaint was closed without anyone calling them back. What would you check first?" | CASE | [generic] | Structure: check the case record and who closed it and on what basis; check the promised callback and whether it was logged; contact the member first; then ask whether other closed cases share the gap. Name what you would check, not what you found. | A live problem from the end-to-end line. It asks about no past, so it makes no claim about you. |
| B9 | "Ashgrove plans to move 40% of member service to digital by 2028. Where do complaints fit in that?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the brief) | Name what you would watch: complaint volumes by channel, and the members who will not go digital. Say what you do not yet know about the plan. Do not describe digital work the material does not show. | Tests the JD's "digital teams" line (F9) at strategy level. Labelled CO because it asks about the company's stated direction. |
| B10 | "Tell me about an escalation you helped someone else decide." | JD | [grounded] "trained new tellers on our escalation script" | Story-mapped on the quote: you trained tellers on the script, and the beats are the ones the sentence states. Answer slot: if you helped a colleague or supervisor decide an escalation, say who and what you did. If not, say so plainly and say how you would coach a supervisor, as a plan. | F8. The JD raises coaching supervisors, and the material shows teller training only. |

**Reverse questions**

| Question | Why it lands |
|---|---|
| "Where do you see complaint volumes heading as more service moves to digital?" | Shows you have read the strategy, and invites a real answer. |
| "When branches consolidate into hubs in 2027, what happens to complaints still open at a closing branch?" | The member-visible risk in the plan. A question a manager will want to answer. |
| "How do you want this role to work with branch supervisors on escalations?" | Ties to B10 and to the JD's coaching line. |
| "What did the last person in this role find hardest in the first six months?" | Shows you intend to own the role, not just fill it. |
| "What would you need to see in the first thirty days for the role to be working?" | Shows you will plan against the manager's own measures. |

---

## Round 3: Panel of two branch managers, 60 minutes, with a 20-minute escalation case

The panel scores against the four published values. The recruiter confirmed this, so the values round is detected and the values cheat sheet below applies. The two members' names are not known, so the persona weights blend across the panel: values first, then peer evaluation for the two branch managers, plus the case.

**Persona table**

| Persona | How it shows up | Weight and reasoning | Counter-strategy |
|---|---|---|---|
| Values / behavioural | Four scored value prompts, and the 20-minute case's values lens | Top weight (4). The recruiter says this round is the values round. | Map each value to the nearest sentence you have, or name the limit. |
| Case / strategist | The 20-minute escalation case; the hub question | Mid weight (2). A timed case, and the hub plan touches the panel's own branches. | Clarify, structure, then decide. Ask before you assert. |
| Peer evaluator | Where the seam is between branch and contact centre; disagreement | Mid weight (1 as a peer probe, blended with values for each member). Two branch managers are your nearest peers in this round. | Propose seam principles. Do not pretend to know Ashgrove's seam. |
| Data-driven prober | "How was that counted?" | Low weight (1). A spreadsheet claim will be checked. | Say what you know, and say when you do not. |

**Question bank (8)**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "When did you last put a member ahead of a number someone above you was tracking?" | VAL | [grounded] "Members First, Always: we decide from the member's side of the counter." (published value, pasted) | Selection scaffold: pick a decision where the member's side beat a tracked figure. Name the figure, and what you did. If none comes to mind, say so plainly; then give the nearest thing your material carries, the complaint from B4, and what was decided above you. | Members First, stated as a trade-off. The honest branch is required. |
| P2 | "Tell me about a letter or script you rewrote because members kept misreading it." | VAL | [grounded] "trained new tellers on our escalation script" | Selection scaffold: if you rewrote a letter or script, say what changed and why. If you did not, say so, then give the escalation script you trained tellers on, and say what you would change in it now. | Plain Words. Never claim a rewrite that did not happen. |
| P3 | "Tell me about a decision where a branch's local knowledge changed the answer the numbers gave." | VAL | [grounded] "Neighbours, Not Numbers: every branch is part of its town." (published value, pasted) | Selection scaffold: if local knowledge changed a decision, say what it was and what the number said. If none, say so plainly, then say how you would make the case for local context to a regional manager, as a plan. | No candidate sentence carries a story here. The hub plan is the probe behind it (P8). |
| P4 | "Tell me about a recurring complaint you traced to its cause and stayed with until it stopped." | VAL | [grounded] "Own the Fix: whoever finds the problem keeps hold of it until it is solved." (published value, pasted); "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold: pick a recurring problem you traced and held to its end. If none, say so plainly. The nearest thing is the spreadsheet your regional manager uses: say what it showed, and whether you saw anything through. | Own the Fix. The spreadsheet is the nearest sentence and the honest branch is required. |
| P5 | "A member has complained twice about the same fee. The branch says the fee is correct. The member now says they will take it to an external body. You have twenty minutes: what do you do, and what do you bring to the branch manager?" | CASE | [generic] | Pace it. Three minutes clarifying: the fee terms, the two earlier responses, what the member is asking for. Five minutes deciding: check the fee against its terms; if the terms are unclear, have a second decision-maker review it. Seven minutes on options and risks: call the member before any letter, refund if owed, the exposure of going to an external body, the member's trust. Five minutes on what you record, what you close, and what would stop a third complaint. Name what you would bring to the branch manager, not a decision you would take alone. | The 20-minute case from the recruiter's email. A generic live problem, so it makes no claim about your past. Also covers regulated complaints (F2) at the level of practice. |
| P6 | "Where does a complaint most often stall between a branch and the contact centre, and what happens when you and a branch manager disagree on the outcome?" | JD | [generic] | Propose principles, not claims about this bank's seam: one named owner from first contact; a written handover between branch and contact centre; a named decider, with a time limit, when two managers disagree. Say you do not yet know Ashgrove's seam, and say you would ask. | Peer evaluator: seam-splitting and disagreement style. Principles let you answer without inventing knowledge of the seam. |
| P7 | "Walk me through how that spreadsheet counted a complaint as resolved." | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: say what counted as resolved on it, in your own words. If you did not set that definition, say whose it was. If the spreadsheet had no definition, say so plainly. Do not name a counting method the material does not show. | Prober. The question presupposes a resolution definition the quote does not carry, so the second branch must allow there was none. Same answer as B3 and F7. |
| P8 | "Neighbours, Not Numbers sits beside a plan to go from eight branches to five hubs in 2027. How would you keep that value real in the hubs?" | CO | [grounded] "Neighbours, Not Numbers: every branch is part of its town."; "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Name what would keep local knowledge in a hub: a named contact per town, and complaints that carry branch context into the hub. Say what you do not know about the plan and what you would ask first. Do not argue the plan, and do not imply that any panel member's branch is closing. | The panel's own branches are affected, and the value and the plan collide. The strongest answer asks rather than asserts. |

**Reverse questions**

| Question | Why it lands |
|---|---|
| "What could a new Member Experience Lead do in the first month that would genuinely help your branches?" | Reciprocity, which a peer panel weights heavily. |
| "How do you measure resolution time today, and do you trust the figure?" | Shows you care about the numbers, and invites candour. |
| "When service moves to digital, what do you most want to stay at branch level?" | A values hook, asked as a question. |
| "How will the hub consolidation change where a member's complaint goes?" | An operational question that shows you have read the strategy. |
| "What does a good escalation decision look like to you?" | Asks them to define the standard you are being scored against. |

### Values / principles cheat sheet (shared, lives with the panel round)

Condition met: the recruiter's email says the panel is the values round, and the four values are pasted from ashgrovecu.org/about/values (copied 19 November 2026).

| Value (official name) | Working meaning (paraphrased) | Mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | No candidate sentence carries a story. Selection scaffold ending in the honest branch: P1, B5. |
| Plain Words | If a member needs it explained twice, it was written wrong | Nearest sentence: F8, "trained new tellers on our escalation script". Selection scaffold ending in the honest branch: P2, B6. |
| Neighbours, Not Numbers | Every branch is part of its town | No candidate sentence carries a story. Selection scaffold ending in the honest branch: P3, P8. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Nearest sentence: F7, "I built the monthly complaints spreadsheet our regional manager uses." Selection scaffold ending in the honest branch: P4, B7. |

---

## Prohibited claims

These are the claims this pack will not coach, and why. No answer, slot, hold or reverse question in this pack asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| "Owned complaints end to end across branches and the contact centre" | Inflated form of F5 and F6: the material shows one branch's formal log | "I handled the branch's formal complaints log," and "I haven't worked in a contact centre." |
| "Presented to senior leaders" | Negative you stated, F3 | "I haven't presented to anyone above regional level." No slot. |
| "Coached branch supervisors on escalations" | Inflated form of F8: the material shows teller training | "I trained new tellers on our escalation script." |
| "Reported monthly on resolution times" | Inflated form of F7: the material shows a monthly spreadsheet | The spreadsheet quote, at its own scope. What it recorded is the slot (B3, P7). |
| "Excel skills" | Inflated form of F4: the material says spreadsheet | "I built the monthly complaints spreadsheet our regional manager uses." |

## Sources

- **Provided documents:** the JD (your message); the recruiter's email (the three rounds, the panel, the values round, the case); the values text, pasted from ashgrovecu.org/about/values and copied 19 November 2026; your summary of Ashgrove's July 2026 strategy brief (the brief text was not pasted); your background (your message).
- **Research tier:** L1, with no searches or fetches sent. The inputs answer every target, so no call was spent.

Research tier: L1, searches 0 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values text you pasted (copied 19 November 2026) fixes the cheat sheet and the values questions. |
| 2. Ashgrove interview process, Member Experience Lead | skipped | The recruiter's email names the three rounds, their lengths, who runs each, and the values round. That is a loop source, and it fixes the loop and the persona weights. |
| 3. Ashgrove strategy / recent news | skipped | Your summary of the July 2026 brief is in hand and is under six months old. Figures still need checking against the brief text. |
| 4. Interviewer name | n/a | No names were given for the Head of Member Services or the panel members. |
| 5. Representative Member Experience Lead JD | skipped | You supplied the JD, which fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The names of the Head of Member Services and the two panel branch managers → persona weights for each named interviewer, and a reverse question tied to each one's public career path. Public footprint only.
- The strategy brief itself, pasted → B9 and P8 would quote the brief instead of your summary, and the four figures would be checked.
- Your CV → the fit-snapshot rows and the banks would quote your CV lines, not your message. This sharpens F1, F2, F5 and F7 in particular.
- Any contact-centre or digital-team work, in your own words, only if true → F6 and F9 move from an answer slot to a story.
- The panel case brief, if the recruiter has one → P5 can be rehearsed against the real material. One email to the recruiter.
- Prep time available → a sized prep triage, with the rounds ordered by weight.
- A deeper research pass (L2), offered once: up to 6 more searches and 2 more fetches, several minutes. It would add public footprints and recent Ashgrove leadership or reorganisation news. Its value is limited unless you have the names. Say if you want it.
- tuesday-dossier.md → would carry verified evidence and the objection this pack ranks highest, with its prohibited-claim guardrails.
