# Atlas Freight — Operations Manager: interview prep pack

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not named. **Round:** not stated. Built for a hiring-manager round by working assumption, because the role is a people-leadership hire and a hiring manager is the likeliest first interviewer. Persona weights change if your round is a peer or skip-level.
**Changelog:** first version.

## 1. How to use this pack

- **Personas** describe how a question is asked. **Types** describe what it scores.
- **Type key:** **JD** = can you do the listed job, including its gaps. **EXP** = do your past claims survive scrutiny, and what exactly was yours. **CASE** = structure and reasoning on a live problem from this role. **VAL** = past behavior against a value (none published, so these are scaffolds). **CO** = company knowledge (none in this pack: no research was run).
- Guidance is scaffolding, not a script. Each cell is speakable in about 90 to 120 seconds.

## 2. Fit snapshot

Requirements are quoted from the JD you supplied. Your evidence is quoted from your message. Nothing in the evidence column is a summary.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows one site's operations and one site's peak plan, not daily operations across four sites. Keep the scope exactly as it is: "I ran the site's peak-season surge plan two years running." Answer slot: if you have run daily operations at more than one location, say where and what you were accountable for; if you have not, say so plainly and say how you would learn four sites in your first 90 days. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | low | [grounded] | transferability | This is accuracy at one site. It does not reach on-time performance or cost per shipment, and the pack does not treat it as a stand-in for either. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you have moved on-time performance or cost per shipment in any role, say what you measured and what changed; if you have not, say so plainly and say the first measure you would set. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message); "no formal people-management of 12 people" (your message) | medium | [grounded] | capability | You stated this absence. Words: "I haven't formally managed 12 people. I'm currently a senior shift manager over 3 supervisors." Then how you would grow from 3 to 12, said as a plan and never as a past. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | high | [grounded] | presentation | The quote reaches the Excel half of the requirement. Words: "I'm solid in Excel." No practice is added. |
| F5 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | You stated this absence. Words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | hard_gate | Your material establishes seven years in operations and a current shift-manager role. It does not establish five years of operations leadership, and the pack will not bridge it. Surfaced only. Step 1 asks the one question this row earns. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | high | [grounded] | none | The quote already reaches the requirement. Words: "I'm Green Belt certified." |

**Reading the gaps:** F3, F5 and F6 are the sharpest. F1 and F2 are the scope gaps the JD's operations lines press on. F4 and F7 are strengths to state plainly.

## 3. Prohibited claims

The claims this pack will not coach, each with its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran daily terminal operations across four sites | Inflated form of F1 | F1's quote at its own scope. The pack's observation, not a first-person negative: your material says one site's operations. |
| Managed a team of 12 supervisors | Negative you stated, F3 | "I haven't formally managed 12 people." Plain acknowledgment, no slot. |
| Built Power BI reporting, or used Power BI | Negative you stated, F5 | "I haven't used Power BI." Plain acknowledgment, no slot. |
| Cut the mis-pick rate 40% on my own | Inflated form of F2's attribution | The quote at its own scope: "I cut mis-pick rate 40% by redesigning the pick path." Whether the 40% was yours alone is a slot (B1), not a claim. |
| Five years of operations leadership | Gate row F6, not established by your material | Pack observation only: your material does not show it. Words for you come from Step 1's answer, not from this pack. |

## 4. Reading the interviewer

Not applicable: no interviewer named, no public profile researched. Persona weights below rest on the round-type prior and the JD.

## 5. Persona table

| Persona | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | Probes the JD's five-year gate and the 12-supervisor line against your three-supervisor role | 5 (5 questions) | F3, F5 and F6 are the gaps the JD states most plainly; a hiring manager derisks there first | Rehearse the single predictable objection until it is calm. Name the gap, then the plan. |
| Data-Driven Prober | Asks how the 40% was counted and what the baseline was | 3 | The 40% figure is your headline metric, and F2 shows where its scope ends | Name the weakest assumption before they do. Say plainly what you do not know. |
| Case / Strategist | Live problems on on-time performance and cost per shipment across sites | 3 | Hiring-manager prior: the JD's operations lines are the live problems the role carries | Clarify before structuring. Name the first metric you would check. |
| Pressure / Stress | Time-boxed challenges to "why you over someone who has run four sites" | 2 | Stress tests composure on the scope gap | Pause, restate, anchor in the quote, hold through two follow-ups, then concede specifically. |
| Values / Behavioral | Scenario probes about bad news and supervisor performance | 2 | No company values in hand, so these run as selection scaffolds | Choose a real story; if none exists, say so and give the nearest one. |
| Conversational / Rapport | "Walk me through the journey"; a casual question about reporting tools | 2 | Casual questions on JD topics are still scored | A ready 90-second arc. Answer the reporting question with the Power BI gap stated plainly. |
| Peer Evaluator | Seam questions with other teams; credit when work spans teams | 2 | Carried at low weight because the round type is unknown | Propose seam principles rather than invented experience. |

## 6. Question banks

Each row's Provenance holds every candidate sentence its guidance rests on. Rows that make no claim about you carry the label alone.

### A — Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "never used Power BI"; "no formal people-management of 12 people" | Highest-ROI prep in this pack. Name the two gaps in your own words: "I haven't used Power BI." "I haven't formally managed 12 people." Then say how you would close each, as a plan. Hold the plan to two follow-ups. | Covers F5 and F3, the two stated absences. The JD's team and reporting lines make this the most likely opening question. |
| A2 | "I don't see five years of operations leadership in your background. How would you handle that?" | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | Answer slot. If your years of leading people in operations add up to five, say the dates and roles. If they do not, say so plainly, then give the seven years in operations and your current supervisory role as the record you can stand behind. | F6 is a hard gate the material does not establish. The question is aimed at the gate, so it stays honest by naming the gap. |
| A3 | "You lead three supervisors today. What makes you think you can lead twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Say the three-supervisor role plainly. Answer slot: if you have set priorities for those supervisors or handled a performance issue with one of them, say which and what you decided; if you have not, say so, and state how you would build the team of twelve as a plan. | F3 is a capability row, so the answer is the stated negative plus a plan, never a claim to past leadership of twelve. |
| A4 | "Why should we believe a pick-path fix carries over to on-time performance and cost per shipment?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Give the 40% in your own words and do not stretch it. Then answer slot: if you have moved on-time or cost per shipment in any role, say what you measured; if not, say so and name the first measure you would set at a terminal. | F2 is a transferability row. The question presses the gap between accuracy and the JD's two metrics, so the honest answer is the limit plus the plan. |
| A5 | "What is it about this step that made you apply?" | [generic] | [generic] | Selection scaffold: give one sentence on the reason you want the step, and say only what you have actually read about the company. If you have read nothing yet, say so. | Motivation probes are standard for this role. No claim about your past is made, so the label stands alone. |

### B — Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name the weakest assumption in your own words before they do. Answer slot: if you counted it, say the period and the source; if it was counted for you, say so plainly. Then say which part of the change was yours to design. | The 40% is your headline figure, so it draws defend-the-number probes. F2 holds its scope. |
| B2 | "What was the starting mis-pick rate, and over what period?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you know the starting rate and the period, give both. If you do not, say so. Do not reconstruct a baseline. | A baseline is the part of "how it was counted" that the sentence implies but does not state. |
| B3 | "You ran the peak-season plan two years running. What did it deliver, and how was that measured?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Describe the plan in your own words. Answer slot: if you can give a measured outcome, say how it was counted and which part was yours; if you cannot, say so and say what you would measure. | The question presumes an outcome that the quote does not carry, so it is an answer slot whose second branch allows that no measured result exists. |

### C — Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "A terminal's on-time performance dropped ten points in a month. What do you ask first?" | CASE | [generic] | Clarify first: which terminal, which lanes or carriers, what changed in the same month. Then structure: volume, labor, equipment, the schedule. Name the first metric you would check and what would make you stop. | A live problem drawn from the JD's on-time line. No claim about your past. |
| C2 | "Cost per shipment is up eight percent across four sites. Where do you start?" | CASE | [generic] | Clarify the definition of cost per shipment and whether all four sites moved together. Then split the cost into labor, linehaul and rework, and say which you would check first. | Drawn from the JD's cost line. Scores structure over a right answer. |
| C3 | "You take over four sites with different peak-season plans. How do you standardize without breaking what works?" | CASE | [grounded] "ran the site's peak-season surge plan two years running" | Give the principle first: standardize the core steps, let each site own its local constraints. Use your peak plan only as the one example you have. Answer slot: if the plan you ran had a step you would carry across sites, name it and say why; if you cannot, say so. | Tests the JD's four-site scope with your one real peak-season example. |

### D — Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has run four sites?" | JD | [grounded] "7 years in warehouse and distribution ops"; "cut mis-pick rate 40% by redesigning the pick path" | Pause. Restate the question. Anchor in the two quotes. Hold through two follow-ups. Concede specifically: "I haven't run four sites; I have run one site's shifts and its peak plan." | The Pressure persona tests composure on the scope gap, so the hold has to be a position your quotes carry. |
| D2 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the redesign as yours only if it was. Answer slot: if others carried out the change, name their part; if you did the redesign alone, say so. Concede any uncertainty about the result specifically. | A held position you cannot back is the one the second follow-up breaks. |

### E — Values / Behavioral (weight 2)

No company values are in hand, so these are selection scaffolds.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Tell me about a time you had to tell leadership an operational truth they did not want to hear." | VAL | [generic] | Selection scaffold: pick a time you carried bad news upward. It needs a named stake, the message you gave and what followed. If no such time comes to mind, say so plainly, then give the nearest thing you have done, or how you would handle it. | No published value to map to, so the story is chosen, not supplied. |
| E2 | "When did a supervisor's result fall short, and what did you do about it?" | VAL | [grounded] "currently a senior shift manager over 3 supervisors" | Answer slot: pick a time you handled one of your three supervisors falling short. Say what you decided and what happened. If none has happened, say so and say how you would handle it. | The JD's supervisor line is the raising source; the three-supervisor role is the only supervisory fact you have stated. |

### G — Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "So, walk me through the journey." | JD | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc in this order: seven years in warehouse and distribution ops, the pick-path redesign, the peak plan, the three supervisors you lead today, and the step you want. Each beat uses the quote's own words. | Casual openers are still scored, and this one is your full record in order. |
| G2 | "What are you actually playing with in reporting these days?" | JD | [grounded] "solid Excel"; "never used Power BI" | Excel first: "I'm solid in Excel." Then the Power BI gap, stated plainly: "I haven't used Power BI." Then the plan. | The JD's reporting line is a plus-skill asked casually. The honest answer is one sentence each way. |

### H — Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| H1 | "Our teams sit side by side. Where's the seam with operations, and what happens when we disagree?" | JD | [generic] | Propose seam principles: a shared metric agreed before the work, one owner for each handoff, disagreements settled on the data. Answer slot: if you have had a real disagreement with another team, pick it and say how it resolved; if not, give the principle and say so. | Seam and disagreement probes are the peer persona's core. The round type is unknown, so this stays light. |
| H2 | "How do you handle credit when work spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if others shared the redesign, name their part in the change; if you did it alone, say so. Do not claim a team you cannot name. | The 40% change is the cleanest example of work that could have crossed teams. |

**Session total:** 19 questions (A 5, B 3, C 3, D 2, E 2, G 2, H 2).

**Requirement coverage**

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, C3 |
| Drive on-time performance and cost-per-shipment down | A4, C1, C2 |
| Lead a team of 12 supervisors | A1, A3, E2 |
| Build reporting in Excel/Power BI | G2, A1 |
| 5+ years operations leadership required | A2 |
| Lean/Six Sigma a plus | none, and why: the Green Belt quote already reaches it (F7), so it needs no drill of its own |

## 7. Reverse questions

Each has a "why it lands." No interviewer profile exists, so none is tied to a career path. Add the interviewer's name to get one.

1. "What does the first ninety days look like for someone taking the four-site role?" Why it lands: it shows you think in the role's scope, not just its title.
2. "How are on-time performance and cost per shipment reported today, and who reads them?" Why it lands: it shows you would own the reporting the JD asks for.
3. "Which of the four sites is furthest from target right now, and what is driving the gap?" Why it lands: it shows you go to the problem rather than the summary.
4. "How is the supervisor team set up today, and what would the supervisors most need from their manager?" Why it lands: it shows you are ready to lead people, not only process.
5. "What would you want the next person to have fixed within six months?" Why it lands: it asks for the real priority, and a clear answer tells you what success means here.
6. "What would make you say, a year from now, that this was the right hire?" Why it lands: it asks for the success criteria in their own words.

## 8. Sources

- **Provided documents:** the Atlas Freight Operations Manager job description, as pasted in your message; your background, as stated in the same message.
- **Research tier: L0.** No search or fetch was run. The company's values, interview loop and current news are therefore not in this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Values cheat sheet (section 10 of the template), not included. Research not run: consent pending. |
| 2. Atlas Freight interview process, operations | unavailable | Loop structure and persona weights. The weights here use the round-type prior. |
| 3. Atlas Freight strategy and recent news | unavailable | Company-knowledge (CO) questions and a grounding brief. |
| 4. Interviewer name and Atlas Freight | n/a | No interviewer named, so there was no query to form. |
| 5. Representative Operations Manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## 9. Upgrade menu

- Your round type and the interviewer's relationship to you (hiring manager, peer, skip-level, recruiter) → persona weights recomputed for that round.
- Your years of leading people in operations → resolves the hard gate in F6, and A2 becomes a plain answer.
- Permission to run research at L1 (about six searches, two page fetches) → Atlas Freight's published values, which unlocks a values cheat sheet, company vocabulary, and CO questions; the interview process for an operations manager role, which sets the loop weights.
- The interviewer's name → a public-footprint read, persona adjustments, and a reverse question tied to their career path.
- Any measured on-time or cost-per-shipment result from any role → upgrades A4 and F2 from answer slots to stated evidence.
- Any focus areas or pre-declared deliverables from the recruiter → coverage for those areas, and build sections for any take-home.
- A `tuesday-dossier.md` from an earlier engagement → verified evidence and prohibited claims, which would replace the local prohibited list.
