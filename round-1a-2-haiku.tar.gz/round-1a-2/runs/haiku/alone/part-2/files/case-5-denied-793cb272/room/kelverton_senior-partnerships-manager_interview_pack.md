# Interview pack: Senior Partnerships Manager, Kelverton Rail, second round

**Role:** Senior Partnerships Manager. **Company:** Kelverton Rail (UK rail tech, ~600 staff, scheduling software for train operating companies).
**Panel (Tuesday, 60 minutes):** Deepa (VP Partnerships, your future manager) and Ross (Commercial Director).
**Format:** 15 minutes of spoken POV, no slides, on operator partnerships over the next 18 months, landing on what it means for the operators themselves. Then Q&A, with Ross pushing on commercials.
**Built on:** your background message and the recruiter's email. No JD text and no research run yet, so this is an L0 pack (see Sources).

## How to use + type key

Personas are how a question is asked. Types are what is being scored. Guidance is scaffolding, not a script: say it in your own words, and never say a sentence this pack does not give you a quote for.

| Tag | Meaning |
|---|---|
| VAL | Behavioural / values alignment |
| EXP | Your own experience, probed for what was actually yours |
| JD | Role-driven: can you do the listed job, gaps included |
| CO | Company and market knowledge |
| CASE | Live problem, scored on structure and reasoning |

## Prep triage (about 3.5 of your 4 hours)

1. **60 min:** Build the POV from the three theses in the graded-deliverable section. Speak each thesis with its concession in the same breath. Time one full run at 15 minutes.
2. **45 min:** Ross's bank (B1 to B6). Highest-ROI prep in this pack is **B1 and B2**: the £4M figure is the thing Ross is most likely to probe, and the recruiter has said he will push on commercials. Practise naming the weakest assumption in your own words, without notes.
3. **30 min:** Hold-then-concede on B3 and B4, the direct-quota and influenced-revenue pushback. Say the plain acknowledgment once, then stop talking.
4. **30 min:** Deepa's Skeptic bank (C1 to C4). C2 is the rail point. Say the plain acknowledgment, then the planning-work bridge, then your plan for the first 90 days.
5. **30 min:** Full run: the POV, then five minutes of Q&A drawn at random from the banks.
6. **15 min:** Choose three reverse questions and rehearse them until they sound like your own.

Everything else is insurance.

## Fit snapshot

Requirements come from the recruiter's own words, quoted from her email (the JD text was not supplied). Gap-and-bridge language is spoken aloud, so the bridges below add no practice, figure or event that you did not give.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "where you'd take our operator partnerships over the next 18 months" (recruiter email) | "Last 4 at a payments company running the ISV channel" (your message); "took it from 6 partners to 40" (your message) | medium | [grounded] | transferability | Your material gives partner management at a payments company. The transferable part is the channel itself, which you took from six partners to forty. Anything about operator partnerships is an answer slot, not a claim: if you have shaped a partner's plan with an operator before, say how; if you have not, say so and say what you would test first. |
| F2 | "what it means for the operators themselves" (recruiter email) | "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)" (your message) | medium | [grounded] | presentation | Reword only this line: five years on bus and light rail network planning, so you know the operator world from the other side. The limit, as this pack's own observation: the material shows planning work, not operator buying decisions. Answer slot: if any of your consulting clients were operators, say which and what you saw of their decisions; if they were not, say so and say what you saw of how operators plan. |
| F3 | "Ross will push on commercials." (recruiter email) | "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | medium | [grounded] | transferability | Your material says influenced revenue, roughly £4M, not revenue you owned. Use the phrase as written. Expect a probe on how the figure was counted. Those are the defend-the-number slots in B1 and B2; this pack does not supply a method. |
| F4 | "selling into UK rail operators" (inferred from the company's market, as your message describes it: "sells scheduling software to train operating companies") | "Never sold into rail specifically" (your message) | none | [grounded] | capability | Plain acknowledgment only: "I haven't sold into rail specifically." Then your plan for learning operator buying, said as a plan and never as a past. No claim of rail work. |
| F5 | "carrying a direct quota" (inferred from "Ross will push on commercials") | "never carried a direct quota, only influenced revenue" (your message) | none | [grounded] | capability | Plain acknowledgment only: "I've never carried a direct quota." Then your plan for taking one on, said as a plan. Do not describe influenced revenue as if it were a quota. |

No hard gates appear in the recruiter's email, and no JD was supplied, so there are no gate rows. Whether a gate exists is the question in the message this pack was delivered with.

## Graded deliverable: the 15-minute POV

**The recruiter's brief, quoted:** "a short POV on where you'd take our operator partnerships over the next 18 months — no slides needed, just talk us through it. Please land on what it means for the operators themselves."

**Grounded facts to build on:**
- F2: "so I know the operator world from the other side", from your transport consulting.
- F1: "took it from 6 partners to 40". This is partner-management scale at a payments company, not operator work. Do not present it as operator experience.

**Theses. Speak each with its concession. The market claims inside them are [generic]: a pattern for operator planning, not a fact about Kelverton's market, to be checked against the internal report.**

| Thesis | Concession, said in the same breath |
|---|---|
| T1: Operators buy reliability under pressure, so start from their planning cycle (timetable change, disruption recovery) rather than from our roadmap. [generic] | Operators' planning teams may treat a vendor inside their process as a risk, and may not share the data the partnership needs. |
| T2: Fewer, deeper operator partnerships before wider reach: co-build with two or three operators first, then widen. [generic] | It is slower and reaches fewer partners. Ross will ask what it does to the partner count, so have that answer ready. |
| T3: Tie partner economics to operator outcomes such as on-time running or the cost of a change, not to seats. [generic] | Attribution is hard, and operators may refuse outcome-linked terms. |

**Differentiation from the consensus answer:** the usual answer is more partners, more integrations and lower price. The anti-pick: "I would not make partner count the headline metric for operators." Risk: F1 is a partner-count record, so keep the statement about operators, not your past: partner count was the right headline for an ISV channel; for operators it is the wrong one.

**The close:** each thesis ends on one operator-side outcome, said in operator terms. This is the "what it means for the operators themselves" landing, not a fourth thesis.

**Timing:** 0 to 2 min, frame the question. 2 to 6 min, the operator problem and T1. 6 to 11 min, T2 and T3 with their concessions. 11 to 14 min, what it means for operators. 14 to 15 min, one ask of the panel.

## Persona table

| Persona | Who on the panel | How it shows up | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|---|
| Case / Strategist | Deepa | The POV itself, then live follow-ups on it | 5 | The recruiter pre-declared the POV, and a hiring-manager round leans Case plus Skeptic | Clarify, structure, state the concession, land on operators |
| Pressure / Prober | Ross | Numbers and commercials: how was £4M counted, why should we trust a commercial target | 5 | The recruiter named commercials, and a commercial director probes attribution first | Defend the number, name the weakest assumption, hold then concede |
| Skeptic | Deepa | Rail, direct selling, the payments-to-operators transfer | 4 | The fit gaps (F1, F4, F5) are where a hiring manager derisks | Plain acknowledgment, the bridge from the quote, a plan for day one |
| Conversational | Either | The opener, and casual questions about rail | 2 | An open invitation to talk, and casual questions are still scored | A 90-second arc from your quotes; an honest answer on what you have read |

## Question banks

Ordered by weight. Provenance carries every sentence the guidance rests on.

### Bank A: Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Talk us through where you'd take our operator partnerships over the next 18 months." | CASE | [grounded] "where you'd take our operator partnerships over the next 18 months" (recruiter email) | This is the graded POV, run as in the section above: frame, operator problem, three theses with concessions, what it means for operators, one ask. Time it. | The pre-declared deliverable; the recruiter's own words |
| A2 | "What would change for an operator if your plan worked?" | CASE | [grounded] "what it means for the operators themselves" (recruiter email) | One operator-side outcome per thesis, in operator terms: fewer disrupted timetables, shorter change cycles, less planning effort. Present them as your argument, not as operator data. | Recruiter asked for this landing; most candidates go vague here |
| A3 | "What would you need to learn about our operators in the first 90 days before committing to a target?" | CASE | [generic] | Clarify before answering: which operators are live, how their planning cycle runs, who decides and who signs, what they already buy and what they measure. Say it as a list, and do not state the answers. | Case scoring rewards clarifying before structuring; needs no claim about your past |
| A4 | "Why would an operator partner with us rather than keep planning in-house?" | CASE | [generic] | Name the real alternative (an in-house planning team, or an incumbent tool), the cost of switching, and the one thing that would make them move. Concede the strongest reason to stay in-house. | Most candidates skip the in-house option; this is where T1's concession gets tested |
| A5 | "What would you stop doing in the partner programme?" | CASE | [generic] | Name one thing you would stop and what stopping it would cost. This is the anti-pick from the POV. Keep it about operators, not your record. | A differentiated answer scores as judgement; the risk is that it reads as a dig at F1 |

### Bank B: Pressure / Prober, Ross (weight 5; six questions because commercials is the pushback the recruiter named)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the roughly £4M of influenced revenue was counted." | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Say how it was counted, in your own words, and which part was yours. Name what the figure is most sensitive to. Answer slot: if you know the attribution rule, say it; if you do not know how it was counted, say so plainly. Hold no method you did not give. | F3. A figure you gave raises the defend-the-number slot, and this is the probe most likely to come first |
| B2 | "Which assumption behind that £4M would you defend least?" | EXP | [grounded] "took it from 6 partners to 40, roughly £4M of influenced revenue" (your message) | Name the weakest assumption before he does, in your own words. Answer slot: if you can name one, say it and what it would do to the figure; if you cannot, say that plainly and say which number you would check first. | Highest-ROI item in this pack. The weakest-assumption move turns a gotcha into a credibility gain |
| B3 | "You've never carried a direct quota. Why would I give you a commercial target?" | EXP | [grounded] "never carried a direct quota, only influenced revenue" (your message) | Hold: say what the influenced-revenue figure was, in the words you used. Then the plain acknowledgment: "I've never carried a direct quota." Hold through two follow-ups. Concede specifically: "A quota is a different discipline, and I'd need time and a target to learn it." | F5. Hold-then-concede: do not fold on the core claim, and do not dress influence up as a quota |
| B4 | "Influenced revenue isn't revenue. What did you close yourself?" | EXP | [grounded] "roughly £4M of influenced revenue" (your message) | Do not argue the word; the quote already uses "influenced". Answer slot: if you closed any deal yourself, name it and what you did; if you did not, say so plainly and say what your role was in the influence. Never give a closed-deal figure you did not give. | F3 and F5 together. The honest branch is the one that holds |
| B5 | "How would you price an outcome-linked deal with an operator?" | CASE | [generic] | Structure: what the operator values; how the outcome is measured and by whom; where the attribution risk sits; a pilot-sized first step. Concede the attribution problem. Make no pricing claim about your past. | Ross's commercial pushback will reach pricing; T3's concession sits here |
| B6 | "If a partnership costs us margin in year one, why should we accept it?" | CASE | [generic] | Name the margin you would accept and the evidence, by a date, that would make you stop. Hold the trade and concede the risk. Supply no figure you were not given. | The investment question in every commercial round; the answer is a test, not a number |

### Bank C: Skeptic, Deepa (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Your last four years were in payments, and our customers are train operators. What transfers?" | JD | [grounded] "Last 4 at a payments company running the ISV channel" (your message); "took it from 6 partners to 40" (your message) | Story-map on the channel: you took it from six partners to forty. Say what transfers in those terms, then the limit: the buyer changes, and you have not sold to operators. Answer slot: say whether any partner you ran sold into a buyer like an operator; if none did, say so and say what you would test first. | F1, the transferability gap. A skeptic tests the bridge where it is thinnest |
| C2 | "You've never sold into rail. Why would an operator buy from you?" | JD | [grounded] "Never sold into rail specifically" (your message); "so I know the operator world from the other side" (your message) | Open with the plain acknowledgment: "I haven't sold into rail specifically." Then the planning-work bridge: you know the operator world from the other side, from planning work. Then your plan for the first 90 days. Claim no rail work. | F4, capability. The acknowledgment is the only honest opener, and the bridge is planning work only |
| C3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never sold into rail specifically" (your message); "never carried a direct quota" (your message) | Name the two you know, in your own words, with one plan each: rail buying, and carrying a direct quota. Do not add a list of others. | F4 and F5. The answer is the two stated negatives, not a general self-criticism |
| C4 | "Our commercial and partnership teams disagree on price. What do you do?" | CASE | [generic] | Name the root of the disagreement (margin against reach), who decides, and how you would put the disagreement in writing before the meeting. Concede that you would sometimes lose the argument. | Seam question from a peer-style angle; needs no claim about your past |

### Bank D: Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So, walk me through the journey." | EXP | [grounded] "5 years in transport consulting (bus and light rail network planning, so I know the operator world from the other side)"; "9 years in partnerships"; "Last 4 at a payments company running the ISV channel" (your message) | A 90-second arc in this order: five years in transport consulting, then partnerships, the last four in payments running the ISV channel, and why operators now. Use only what those quotes say. The arc does not reconcile the nine years with the consulting years; see the upgrade menu. | Rapport openers are scored. The arc is written from your sentences |
| D2 | "What are you reading about rail at the moment?" | CO | [generic] | Name what you have read and one thing it changed your view on. If you have read nothing recent, say so and name the first source you would read. | Casual register, scored for interest. The honest branch is required |
| D3 | "What's the most interesting operator problem you've come across?" | EXP | [grounded] "bus and light rail network planning" (your message) | Pick one planning problem you worked on and say what you did yourself. Answer slot: if your planning work produced no problem you can describe, say so plainly and describe the nearest one. | F2. An open prompt whose theme comes from the quote |

### Requirement coverage

| Requirement (source) | Covered by |
|---|---|
| POV on operator partnerships over 18 months (recruiter) | A1, A3, A4 |
| What it means for operators (recruiter) | A2, A5, D3 |
| Commercials, which Ross will push (recruiter) | B1 to B6 |
| Direct quota (inferred, F5) | B3, B4, C3 |
| Rail selling (inferred, F4) | C2, C3, D2 |
| Transfer from payments (F1) | C1 |
| JD-tagged requirements | None, and why: no JD text was supplied. Once it is, its requirements get JD questions |

Session total: 18 questions, the floor of the rubric's range. Coverage is against the recruiter's words, not a JD.

## Reverse questions

| Question to ask | Why it lands |
|---|---|
| "When an operator partnership has worked here, what was the operator's first win?" | Shows you would look at operators' results, not only at deal size |
| "Which operator relationship is the team most worried about in the next six months?" | Shows you want to know where the pressure is; invites Deepa to set priorities |
| "How is influenced revenue credited between partnerships and sales today?" | Tests whether the commercial model is settled; lands with Ross |
| "What would you want the first six months to have proven?" | Signals outcome thinking to a future manager |
| "What could a new person do in the first month that would genuinely help the operator team?" | Reciprocity framing, aimed at Deepa's team |
| "Where do partnerships and product disagree most right now?" | Finds the seam, and shows you understand the company is not one team |

## Prohibited claims

What this pack will not coach, and why. Built locally from the fit snapshot. None of these may appear in an answer, a bridge or a hold.

| Not coached | Basis | Honest form |
|---|---|---|
| Built or designed the ISV channel | Inflated form of F1 | "running the ISV channel", at its own scope. The material says running and growth, not design |
| Sold to operators, or owned operator relationships | Inflated form of F2 | F2's line at its own scope. The material shows planning work, not operator sales |
| Owned the £4M | Inflated form of F3 | "roughly £4M of influenced revenue". Influence is not ownership |
| Carried a quota | Stated negative, F5 | "I've never carried a direct quota." Plain acknowledgment |
| Sold into rail | Stated negative, F4 | "I haven't sold into rail specifically." Plain acknowledgment |

## Sources

- **Provided documents:** the recruiter's email, as quoted in your message (the panel, the format, the POV brief, "Ross will push on commercials."); your background message; Kelverton's internal market report, which you have read but which is not in this environment. Nothing here is drawn from the report, so the POV's differentiation is not yet checked against it.
- **Searches and fetches sent this turn:** none.
- **Dossier consumed:** none.

Research tier: L0 — your material and the recruiter's words only

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Kelverton values | unavailable | Would have moved a values sheet. Research consent was deferred to the upgrade menu this turn; no values round is detected yet |
| 2. Kelverton interview process, Senior Partnerships | unavailable | Would have moved the loop structure and the persona weights |
| 3. Kelverton strategy / recent news | unavailable | Would have moved a grounding brief and a check that the POV's operator claims are current |
| 4. Deepa / Ross with Kelverton | unavailable | Would have moved the interviewer read and a reverse question tied to their paths |
| 5. Representative Senior Partnerships Manager JD | unavailable | Would have moved the JD-tagged questions and the requirement rows |

## Upgrade menu

- The JD text, or its requirement lines → the recruiter-quoted rows become JD rows, JD questions appear, and any hard gate (right to work, office days, travel, a licence) is surfaced
- The market report's headline findings → the POV's differentiation can be checked against the consensus it names, and the anti-pick in A5 can be sharpened
- The clients of your transport consulting → whether F2's "operator world" rests on client work or on observation, which changes the F2 bridge
- How the nine years in partnerships divide across consulting and payments → D1's arc can be stated in the order it happened
- Your own account of how the £4M was counted, in your words → B1 and B2 move from answer slots to story-mapped answers, using only what you say
- A light research pass (L1: up to six searches and two page fetches on Kelverton's recent operator news and strategy) → the grounding brief, a current-strategy CO question, and the target accounting filled in
- Public career profiles for Deepa and Ross → the interviewer read, weights per panel member, and a reverse question tied to their own paths
- A tuesday-dossier.md → its verified evidence and prohibited claims would bind this pack's guidance, in place of the quotes-as-given
