# Interview pack: Engineering Manager, Larkfield Systems (loop of three rounds)

Candidate: Yusuf. Role: Engineering Manager, Larkfield Systems (industrial IoT, about 600 people). Rounds: Tuesday 24 Nov, hiring manager (Director of Engineering); Thursday 26 Nov, panel (two staff engineers and a product manager); Monday 30 Nov, VP Engineering ("values and leadership philosophy").

Note: 26 Nov is US Thanksgiving. Confirm that panel's date and time zone with the recruiter.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: behavioral and values alignment.
- **EXP**: deep-dive on your own experience, including whether claims survive scrutiny.
- **JD**: the stated role and its requirements.
- **CO**: company and strategy knowledge. None in this pack (see Sources).
- **CASE**: a live problem from the role, with no claim about your past.

The guidance is scaffolding, not a script. Rehearse what you actually did, in your own words.

## Sources

Provided documents: your message (role summary, round schedule, your background, your own gap list, and the recruiter's phrase "values and leadership philosophy"). No CV, no posting text, no interviewer names.

Research tier: L1 — searches 2 of 6, fetches 0 of 2. Both searches were refused for lack of permission, so no research result is in this pack.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Search refused. Would have supplied published values for the VP round; no values cheat sheet is included |
| 2. Larkfield Systems interview process | unavailable | Search refused. Would have confirmed the loop structure; the three rounds here rest on your message alone |
| 3. Larkfield Systems strategy / recent news | unavailable | No search sent. Would have supplied current priorities for the VP round and any CO questions; none are in this pack |
| 4. Interviewer name + company | n/a | No interviewer names given, so no query could be formed |
| 5. Representative role JD | unavailable | No search sent. Your summary is short, not posting text; requirements below are taken from it |

Refused calls, listed: "Larkfield Systems values industrial IoT" (refused); "Larkfield Systems engineering manager interview process" (refused).

Dossier: none consumed.

## Fit snapshot (shared across all three rounds)

Requirements come from your role summary, quoted, and from your own gap list. Evidence is quoted from your message.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" — role summary | "3 as a team lead of 6" — your message | medium | [grounded] | transferability | Your material says one team of six for three years, not two squads. Say it in those terms: "I was a team lead of six for three years." Answer slot: the role raises two squads, so expect a probe on what changes at that size. If you have coordinated two groups, say how; if not, say so and say how you would run them |
| F2 | "own delivery, hiring and growth for 11 engineers" — role summary | "I run our hiring loop for backend roles" — your message; "about 40 interviews last year" — your message | medium | [grounded] | none | No gap on hiring. Keep the scope as you stated it: backend roles, and about 40 interviews last year. Do not widen it to all hiring |
| F3 | "own delivery, hiring and growth for 11 engineers" — role summary | "I pushed a reliability quarter through against roadmap pressure" — your message | medium | [grounded] | presentation | The quote already reaches delivery in other terms: "I pushed a reliability quarter through against roadmap pressure." Use it as written, with no added detail |
| F4 | "own delivery, hiring and growth for 11 engineers" — role summary | none given | none | [grounded] | discovery | Growth is not covered by anything you wrote. Answer slot: if you have grown an engineer into a larger role, name who and what you did, in your own words; if not, say so and say how you would start |
| F5 | "partner with hardware and product on roadmap" — role summary | "never owned a hardware-adjacent roadmap" — your message | none | [grounded] | capability | Your own stated absence. Words: "I've never owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan, never as a past |
| F6 | "no manager-of-managers experience" — your gap list | "I've never managed managers" — your message | none | [grounded] | capability | Your own stated absence. Words: "I haven't managed managers." Then the plan for closing it, as a plan |
| F7 | "industrial/hardware domain" — your gap list | "industrial/hardware domain unfamiliar" — your message | none | [grounded] | capability | Your own stated gap. The sentence you say aloud must be yours; this pack does not write it. The material shows no industrial or device work. Answer slot: say what you know about device fleets today, and how you would learn the domain |

Gap types follow the routing rule in `references/output-template.md`. Confidence follows the evidence bands.

## Prohibited claims

The pack will not coach these claims, and no guidance cell may assert, soften or imply them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned a hardware-adjacent roadmap | Stated absence, F5 | "I've never owned a hardware-adjacent roadmap." |
| Managed managers | Stated absence, F6 | "I haven't managed managers." |
| Led two squads | Inflated form of F1 | "a team of six for three years" |
| Owned hiring across the company | Inflated form of F2 | "I run our hiring loop for backend roles" |
| The 60% on-call drop as yours alone | Inflated form of F3 | "My team's on-call burden dropped 60% after I pushed a reliability quarter through" |

## Persona weights by round

| Round | Dominant personas | Why |
|---|---|---|
| 1. Hiring manager (Director of Engineering, future boss), 45 min | Skeptic 5, Case/Strategist 4, Pressure 3, Prober 3 | Relationship prior: hiring manager. They are buying capability and checking the gaps F1, F5, F6. Expect live problems on their roadmap |
| 2. Panel (two staff engineers, one PM), 60 min | Data-Driven Prober 4, Peer Evaluator 4, Case/Strategist 3 | Peer prior: they price the hire's effect on their own work. Staff engineers probe numbers; the PM tests the roadmap |
| 3. VP Engineering, 30 min | Values/Behavioral 5, Pressure 3, Case/Strategist 2 | Values round, detected from the recruiter's own words. No published values in hand, so the VAL questions use selection scaffolds |

Interviewer names were not given, so the interviewer read is absent. Weights rest on relationship priors only.

## Round 1: Hiring manager (Director of Engineering), 45 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've led six people. This role is two squads and eleven engineers. Why is that a step you can take?" | JD | [grounded] "3 as a team lead of 6"; [grounded] "Lead two squads building device-management services" | Name the step in your own words: "I was a team lead of six for three years," then what changes at eleven. Concede the scale plainly. Answer slot: if you have run anything of this size, say what; if not, say so and say how you would get there | F1 is the step the role raises; the question is the scoring sheet's line |
| A2 | "Which part of this role would you be weakest at on day one?" | Skeptic stem | [grounded] "never owned a hardware-adjacent roadmap" | This is the highest-ROI prep in this pack. Say the weakest part first, in your own sentence: "I've never owned a hardware-adjacent roadmap." Then the plan: what you would learn first and who you would ask. Hold through two follow-ups by returning to the plan. Concede the gap; do not fold on the plan | F5 is the stated absence the role's roadmap partnership presses on hardest, so this objection will arrive in some form. Rehearsed calibrated candor beats a bluff |
| A3 | "Why leave a payments company to take this role?" | Skeptic stem | [generic] | Selection scaffold: give the one real reason in a sentence, the thing this role gives you that your current role does not. If the reason is the domain itself, say so. The pack has no reason from you, so nothing is supplied | A motivation probe every hiring manager asks; no sentence of yours yet carries the answer |
| A4 | "Two squads, eleven engineers. What do you do in the first ninety days?" | CASE | [generic] | Clarify first: what is the delivery state, what is the roadmap, who are the two squads. Then the objective, the sequence, and the risks. Do not describe a past you have not stated | A live problem on the role itself; it presupposes nothing about your past |
| A5 | "Hardware says a firmware release slips a quarter. Product still wants the feature date. What do you do?" | CASE | [generic] | Structure it: what you would ask hardware and product, what decision is yours, what you would tell each side. Name the trade-off aloud | The role names partnering with hardware and product; this is that tension as a decision, not a fact about your past |
| A6 | "Your 60% on-call number. How much of that was actually you?" | Pressure | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Hold: "I pushed the reliability quarter through; the drop was my team's." Hold through two follow-ups. Concede what you did not measure. Answer slot: if other changes landed in the same window, say what they were; if none did, say so | A figure raises the defend-the-number slots: how it was counted, what it is sensitive to, which part was yours |
| A7 | "Walk me through how that 60% was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Name the source and the window in your own words. Name the assumption you would defend least. If you cannot recall how it was counted, say so plainly: "I don't know how it was counted; here is where it lives" | Prober-style defend-the-number question, rehearsed so the honest branch is ready |
| A8 | "Tell me how you run the hiring loop." | EXP | [grounded] "I run our hiring loop for backend roles"; [grounded] "about 40 interviews last year" | Describe the stages you run and the ones you do not. Keep the scope at backend roles. Answer slot: which stages were yours to set, and which were set for you | F2 is the hiring evidence; the question tests whether the scope holds |

Requirement coverage, round 1: F1 (A1), F5 (A2), F3 (A6, A7), F2 (A8), F4 (no question; see the upgrade menu), F6 (no question here; see round 3 C3), F7 (A5, with no past claim).

## Round 2: Panel (two staff engineers, one PM), 60 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | Peer stem | [generic] | Propose seam principles, not a picture of their system. Give one disagreement story only if you have one; if not, say so and say how you would disagree with an equal | Peer probe on partnership; no past claim made |
| B2 | "Which of the on-call numbers would you defend least?" | Prober | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure" | Name the weakest assumption before they do. Answer slot: if you can say how the figure was counted, say so; if you cannot, say so plainly | Staff engineers probe numbers; this is the defend-the-number slot again, from a different seat |
| B3 | "How would you run a roadmap with a hardware team that sets its own dates?" | JD | [grounded] "partner with hardware and product on roadmap"; [grounded] "I pushed a reliability quarter through against roadmap pressure" | Use the quote as written. You pushed a reliability quarter through; you have not set hardware dates. Say so, then the approach you would take. Answer slot: if you have negotiated a date with a team that did not own it, say how; if not, say so | PM question on the role's core partnership; the quote carries the only roadmap pressure you have stated |
| B4 | "Three asks for two squads: new device onboarding, a firmware-update reliability problem, an enterprise feature. Which first?" | CASE | [generic] | Clarify: what is the cost of delay on each, what is the risk, what is already committed. Give an order and its reasons. Name one premise you would challenge | A roadmap case the PM will recognise; presupposes nothing about you |
| B5 | "Of the roughly forty interviews you ran, which one changed a decision?" | Prober | [grounded] "about 40 interviews last year"; [grounded] "I run our hiring loop for backend roles" | Say how you would count a changed decision before you answer. If you have an example, give it in your own words. If you have no count, say so | Counts are a magnet for probers; this is the defend-the-number slot on hiring |
| B6 | "What does a staff engineer on these squads need from you that they do not get today?" | Peer reciprocity | [generic] | Ask it as a real question. Listen for the answer and name the one you could act on first | A reciprocity question: it turns the panel's load into your first-month plan |

Requirement coverage, round 2: F1 (B3), F2 (B5), F3 (B2), F5 (B3), F4 (B6 reaches growth only as a question), F7 (B4 touches the hardware domain only through the roadmap).

## Round 3: VP Engineering ("values and leadership philosophy"), 30 min

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure" | Story-mapped on that sentence: the roadmap pressure, the quarter you pushed through, the outcome you stated. The unpopular-truth beat is an answer slot: say who you told what they did not want to hear. If the quarter was agreed before you pushed, say so | The recruiter's "values and leadership philosophy" makes this VAL; the quote is the only story you have stated |
| C2 | "Tell me about a time you developed someone into a bigger role." | VAL | [generic] | Selection scaffold: pick a time you helped someone grow, the thing they did, and what you did. If no such time comes to mind, say so plainly, then give the nearest thing your material carries (the hiring loop, F2), or how you would handle it | A standard leadership probe for an EM with growth in the role; no past claim |
| C3 | "You've never managed managers. Why isn't that disqualifying?" | Pressure | [grounded] "I've never managed managers" | Plain acknowledgment: "I haven't managed managers." Hold through two follow-ups: the plan, not the past. Concede the real gap. Do not fold on the plan | F6 is the stated absence a VP will test; the hold-then-concede structure is the rehearsal |
| C4 | "What is your leadership philosophy, in a sentence?" | VAL | [generic] | Say it in your own words. Anchor it in one thing you did, using only the quotes above. Do not borrow a slogan you cannot back | A values round opens on philosophy; a slogan with no story fails the next question |
| C5 | "How do you balance roadmap pressure against reliability over two years?" | CASE | [generic] | Clarify the constraint, state the principle you use, then give a rule for when reliability wins. Name what would make you change the rule | A strategy-altitude question on the trade-off in your reliability quarter; presupposes nothing about your past |

Requirement coverage, round 3: F3 (C1), F6 (C3), F2 (C2 through the hiring loop), F1 (none; see the upgrade menu), F5 and F7 (none; see the upgrade menu).

## Reverse questions

Each one carries a "why it lands" line.

**Round 1, Director of Engineering**

1. "What would success look like for the two squads at six months?" Why it lands: it turns the scale question into a shared target you can measure against.
2. "Where do hardware and product disagree most with engineering today, and how is it resolved?" Why it lands: it shows you have read the role's partnership line and want the real seam.
3. "What did the last engineering manager in this role get right, and what would you change?" Why it lands: it asks what the job actually needs, which is the question you need answered before you say yes.

**Round 2, panel (peer reciprocity)**

4. "What could a new engineering manager do in the first month that would genuinely help your team?" Why it lands: reciprocity framing; it asks what you bring to their team, not only what you need.
5. "Where does the roadmap most often surprise your squads?" Why it lands: it invites the PM to name the seam, which is the peer probe you want to meet.

**Round 3, VP Engineering**

6. "Which of your stated values would you say the company most often fails to live, and where?" Why it lands: an honest, specific question answers the values round's real test better than a slogan.
7. "How do you decide between roadmap and reliability when they conflict?" Why it lands: it connects to your reliability quarter and gives the VP a chance to say how they think.

## Prohibited claims check

Before delivery, every cell was checked against the prohibited list. No cell asserts owning a hardware-adjacent roadmap, managing managers, leading two squads, owning hiring across the company, or the 60% as yours alone.

## Upgrade menu

- The full posting text, or the recruiter's email with role details → the requirement rows become [grounded] from the posting, and the two-squads and hardware lines get checked word for word.
- Larkfield's published values page (paste it), or the values list from the recruiter → a values cheat sheet for round 3, and the VAL questions get mapped stories instead of scaffolds.
- Interviewer names for each round → persona weights per person, and a reverse question tied to each interviewer's path.
- Where the 60% on-call number came from (the pager or dashboard export, its start and end dates) → F3 moves from medium toward high, and A7 and B2 can be answered with a checked count.
- The outcomes of the hiring loop you ran, even a rough count (how many interviews changed a decision) → B5 becomes answerable, and F2 gains a verifiable figure.
- Any work with hardware, device fleets or industrial customers, or a roadmap you contributed to → F5 and F7 get a real bridge; if none exists, the plan stays a plan.
- Whether the role has an on-site or location requirement → checks whether any gate row applies; the summary is silent.
- Permission to run the research (web search) → the values, interview process and strategy targets run, and the values cheat sheet and CO questions can be added.
