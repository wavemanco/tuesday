# Stripe: Product Operations Manager, final round

Interviewer and relationship: not given. Built as a flat-weight pack for a full final loop. No CV, no job description and no research results were available, so this pack is generic and says so wherever it applies.

## How to use

Personas describe how a question arrives. Types describe what is being scored.

| Type | Name | What it scores |
|---|---|---|
| VAL | Behavioral / values alignment | Past behavior against the company's published values |
| EXP | Work-experience deep-dive | Whether your stated experience survives scrutiny |
| JD | Role / JD-driven | The role's stated responsibilities, including your gaps |
| CO | Company and strategy knowledge | How well you understand the business |
| CASE | Hypothetical / live problem | Structure and reasoning on a problem from the role |

Guidance is scaffolding, not a script. Each guidance cell should be speakable in 90 to 120 seconds.

## Fit snapshot

Worksheet variant: nothing about your background is in this session, so every evidence cell is `none given`. The requirements are role-family prose, not quotes from a posting, so they are `[generic]`.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| R1 | Designing and running cross-functional operating processes: planning, reviews, cadence (role family) | none given | none | [generic] | discovery | Selection scaffold: pick a process you set up, ran or changed, end to end. If none comes to mind, say so plainly, then describe how you would design one for this team |
| R2 | Building dashboards and metrics that teams act on (role family) | none given | none | [generic] | discovery | Selection scaffold: pick a metric someone used to make a decision. If you have none, say so, then say which one you would build first and why |
| R3 | Analytical judgment: turning messy data into a decision (role family) | none given | none | [generic] | discovery | Selection scaffold: pick a time data changed a decision, including a time it did not. If none, say so, then describe how you would check a surprising number |
| R4 | Launch and rollout coordination across product, engineering, go-to-market and legal (role family) | none given | none | [generic] | discovery | Selection scaffold: pick a launch or rollout you coordinated, or one you watched closely. If none, say so, then describe how you would run the first two weeks |
| R5 | Stakeholder management across senior and adjacent teams (role family) | none given | none | [generic] | discovery | Selection scaffold: pick a disagreement between two teams you helped resolve, or say you have not. Then describe how you would settle one with an equal |
| R6 | Working with tools and systems for projects, tasks or records (role family) | none given | none | [generic] | discovery | Selection scaffold: name the tools you have used for operating work and how far you used them. If you have used few, say so, then name the one you would learn first |
| R7 | Clear written communication: updates, decision logs, documentation (role family) | none given | none | [generic] | discovery | Selection scaffold: pick a written update or decision record you produced. If none, say so, then describe the structure you would use |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| None built yet | No sentence about your experience is in this session, so there is no wording to stretch. | Rebuilt when a CV or a story arrives. Every guidance cell below makes no claim about your past |

## Persona table

Relationship is unknown, so the weights are flat, and I am saying so plainly. The loop could not be established from research, so the fallback is the generic archetype, which gives no tilt. Every plausible persona is covered.

| Persona | How it shows up | Likelihood | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Data-Driven Prober | Asks how a number was counted | 3 questions | Flat weight; a final round for an operations role often includes a metrics check | Name the weakest assumption before it is asked |
| Pressure / Stress | Time-boxed, interrupts, challenges | 3 questions | Flat weight; composure is scored in any final | Pause, restate, hold two follow-ups, then concede precisely |
| Values / Behavioral | Scenario questions on how you work with people | 3 questions | Flat weight; no published values were retrieved, so these are selection scaffolds | One clear story per question, or say plainly that you have none |
| Case / Strategist | Live operating problem | 3 questions | Flat weight; the role's work is largely diagnosis and process design | Clarify, structure, then answer, and think aloud |
| Skeptic | Probes the gap between your background and the role | 3 questions | Flat weight, but this is the most predictable objection in any final | Rehearse it until it is plain; name the gap and the ramp |
| Conversational | Friendly opener that is still scored | 2 questions | Lower weight, but casual questions are still scored | Pre-script a 90-second arc |
| Peer Evaluator | Seams between teams, credit and disagreement | 2 questions | Lower weight; a peer may sit in the panel | Propose seam principles rather than claimed knowledge of their seam |

## Question banks

### Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through how you would measure whether an operating process is working." | JD | [generic] | Name the outcome first, then the input metrics, then one thing the metric can hide. Say which check you would run first | Tests R2 at the level of method, not history |
| A2 | "Pick a number you used to make a decision. How was it counted, and which assumption would you defend least?" | EXP | [generic] | Selection scaffold: pick a number from work you actually did. If you have none, say so plainly, then walk through how you would count one for this role. Name the weakest assumption before they ask. Do not explain a method you could not repeat under a second question | Tests R3 and whether the number is yours; a prober checks attribution |
| A3 | "Our dashboard shows a 15 percent drop last month. What do you check before you tell anyone?" | CASE | [generic] | Check first whether the definition or the data pipeline changed, then seasonality, then mix shift, then segment. Say the order aloud | Tests R3 in a live form |

### Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "You have sixty seconds: why should we hire you over someone who has done this before?" | JD | [generic] | Answer with the one thing you can show, not a list of adjectives. Concede the gap in one sentence, then say how you would close it in thirty days. Hold this position through two follow-ups | Pressure persona scores composure; this is also the Skeptic's likely opener |
| B2 | "That process you would run: how much of its success would be down to you, and how much to the team?" | EXP | [generic] | Hold, then concede: say your part in one sentence and the team's in one sentence. If pushed on the split, concede the part you cannot separate. Do not claim sole credit and do not disclaim your own part | Tests R5 and attribution honesty under pressure |
| B3 | "Why are you leaving where you are, and why now?" | EXP | [generic] | Give one honest sentence about the previous role, positive but brief. Then say what pulls you toward this one, not what pushes you away | Motivation consistency; probed in almost every final |

### Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time the truth landed, or say it did not. Context in "we", your contribution in "I": what you said, what happened, what you would change. If none comes to mind, say so plainly | Standard behavioral probe; no published value is named because none was retrieved |
| C2 | "When did you put a customer ahead of an internal metric?" | VAL | [generic] | Same scaffold as C1. If you have no such time, say so, then describe how you would decide between a customer outcome and a metric | Tests judgment on the customer side of operations |
| C3 | "Tell me about a process you changed that people resisted." | VAL | [generic] | Selection scaffold: name the process, who resisted and why, what you did about it, and what held. If none, say so, then describe your approach to change | Tests R1 and change management |

### Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You are asked to set up an operating review for a product area of forty people with no shared metrics. What do you do in the first thirty days?" | CASE | [generic] | Clarify the goal and who decides, then the current state, then a minimal metric set, then the rollout. Think aloud and challenge one premise | Tests R1 and R2; standard case structure |
| D2 | "A launch is two weeks late and three teams disagree on scope. Walk me through what you do." | CASE | [generic] | Separate the decision from the information, name the decision owner, and propose a date for the decision. Say what you would not do | Tests R4 |
| D3 | "What do you already know about how this company makes money, and what would you want to learn first?" | CO | [generic] | Say what public sources you have read and what they told you, then name what you would verify. Do not recite a summary of the company | CO questions go generic without research; this is the honest version |

### Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one specific area of the role, such as a tool or method you have not used, not a vague one. Give the ramp at thirty, sixty and ninety days. Do not bluff a competency the interviewer may own | Highest-ROI prep in this pack: the mismatch probe is the most predictable objection, and without your CV I cannot name your specific gap. Filling it is the first thing to do |
| E2 | "Why this role, and why now?" | EXP | [generic] | Give the pull toward this kind of work and what you want next, in two parts. Keep it specific to the role's scope; drop generic praise | Motivation consistency; the Skeptic's second favorite line |
| E3 | "Tell me about the area where you have the least direct experience for this role." | JD | [generic] | Name the area plainly, then what you have done nearby, without stretching it, then the ramp. Do not describe the area as if you had done it | Open prompt that surfaces the gap on purpose; it asks you to choose the instance |

### Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through your journey." | EXP | [generic] | A 90-second arc: where you started, one turn that shaped your work, where you are now, why this role. Say it aloud twice before the day | Casual openers are scored on communication economy |
| F2 | "What are you playing with in this space these days?" | JD | [generic] | Name two tools or methods you use and one you are trying, one sentence each. Keep it to things you have actually done | Casual version of R6 |

### Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam, and what happens when we disagree?" | JD | [generic] | Propose principles for finding a seam rather than claiming knowledge of theirs. For a disagreement with an equal, name who owns the decision and how you would reach it | Peer persona tests partnership fit and disagreement style |
| G2 | "How do you handle credit when work spans teams?" | VAL | [generic] | Say who you credit and how you name it, in your own words. Do not claim credit you cannot point to | Peer persona probe on credit-sharing |

## Requirement coverage

| Requirement | Covered by | Note |
|---|---|---|
| R1 processes | D1, C3 | |
| R2 dashboards and metrics | A1, D1 | |
| R3 analytical judgment | A2, A3 | |
| R4 launch coordination | D2 | |
| R5 stakeholders | B2, G1 | |
| R6 tools | F2 | |
| R7 written communication | none, and why | No written exercise was named; add one if the recruiter names a take-home |

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| 1 | "What does a strong first ninety days look like in this role?" | Shows you think in outcomes rather than tasks |
| 2 | "Which decision the team made last quarter would you most want a new person to understand?" | Signals you read the team's work, not just the job posting |
| 3 | "When product and go-to-market disagree on a launch, how is the call usually made?" | Tests your understanding of the seam, and the answer tells you how decisions move |
| 4 | "What would make this role fail within a year?" | Surfaces the real risk, and your answer shows candor |
| 5 | "How will the person you report to measure success in this role?" | Sets the terms you will be held to |
| 6 | If the interviewer is a peer: "What could a new person do in their first month that would genuinely help your team?" | Reciprocity; turns the conversation toward partnership |

## Sources

Provided documents: your message only (company, role, final round, research requested). No job description, CV or dossier was provided.

Searches sent, all refused by the session's permission setting; none was retried:

- "Stripe company values principles": refused
- "Stripe interview process product operations manager final round": refused
- "Product Operations Manager job description responsibilities qualifications": refused
- "Stripe strategy news 2026": refused

Research tier: L1 attempted, nothing returned: searches 0 of 6 (4 refused), fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet (section 10): dropped. VAL questions are generic scaffolds |
| 2. Stripe interview process, product operations | unavailable | Loop structure. Without it the loop is not established, so persona weights stay flat |
| 3. Stripe strategy and recent news | unavailable | CO bank: D3 is generic instead of grounded in current strategy |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there was no query to form |
| 5. Representative Product Operations Manager JD | unavailable | Would have turned the R-rows from `[generic]` into quoted `[inferred]` requirements |

## Upgrade menu

- Your CV, or a few lines on your background → the fit snapshot gets verbatim quotes, the selection scaffolds become story-mapped answers, and the prohibited list gets built from your own sentences
- The job description from the posting → the R-rows become quoted `[grounded]` requirements, and the coverage table checks real requirements
- Who you are meeting and their role → persona weights and a tailored reverse question
- The recruiter's note on focus areas or a take-home → coverage of any deliverable, with its own build section
- Stripe's official values page, pasted → the values cheat sheet and VAL questions with mapped stories
- Stripe strategy or recent news, pasted → CO questions grounded in current strategy
- Web search re-allowed → a representative JD, the values page, the interview process, and a strategy sweep at the default research tier

