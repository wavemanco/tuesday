# Interview prep pack: Operations Manager, Atlas Freight

Role: Operations Manager (daily terminal operations, 4 sites, 12 supervisors). Company: Atlas Freight (regional logistics, 800 employees). Interviewer: not known. Round type: not known, so persona weights are flat and said so below.

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **VAL** behavioural/values; **EXP** your past work, probed; **JD** the posting's requirements; **CO** company knowledge (none in this pack, see Sources); **CASE** a live problem.
- Guidance is scaffolding, not a script. Speak it in your own words. Anything in an "answer slot" is an instruction for the interview, not a question to answer here.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows one shift, with three supervisors, not four sites. Words for you: "I'm a senior shift manager over three supervisors." Answer slot: if you have run daily operations across more than one site, or set a routine that spans sites, say what it was and how you decided; if not, say so, and say how you would apply your routine across four. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | low | [grounded] | transferability | The quote is pick accuracy, not on-time performance or cost per shipment. Words: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked on-time performance or cost per shipment at any point, say what and what you did with it; if you did not, say so and say what you would measure first. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three supervisors is the scope your material gives; twelve is not in it. Words: "I'm a senior shift manager over three supervisors." Answer slot: if you have led more supervisors than this, or through a layered structure, say how; if not, say so and say how you would structure a team of twelve. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | hard_gate | Your material does not establish how many of those seven years were in leadership roles. This cell asks nothing. Asked once in the message that delivers this pack. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel, never used Power BI" (your message) | medium | [grounded] | capability | The Power BI absence is one you stated. Words: "I haven't used Power BI." Excel stays at its own scope: "solid Excel." Any Power BI plan is a plan, not a past. |
| F6 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement. It is self-reported, so it is inspectable only with the certificate (upgrade menu). |

Observation, not words for you: the material supports one site, three supervisors, one quantified pick-accuracy result and a Green Belt. Everything above that is in the posting but not in your sentences is a question for the interview, not a claim here.

## Prohibited claims

Built locally from the fit snapshot. These are the stretches a candidate reaches for under pressure. None of them is coached as a claim, in any answer, slot or drill.

| Not coached | Basis | Honest form |
|---|---|---|
| Running daily operations across four sites | Inflated form of F1 | F1's quote at its own scope. Pack observation: your material shows one shift with three supervisors. |
| Leading twelve supervisors | Inflated form of F3 | F3's quote at its own scope. |
| Having driven on-time performance or cost-per-shipment down | Inflated form of F2 | F2's quote. Pack observation: your material shows pick accuracy. |
| Having built Power BI reporting | Negative you stated, F5 | Plain acknowledgment: "I haven't used Power BI." No answer slot on Power BI past work. |

## Persona weights

No relationship or round type was given, so weights are flat-ish and rest on the generic archetype (the posting reads as a hiring-manager loop). This changes when you answer the round question.

| Persona | How it shows up here | Weight | Reasoning | Counter-strategy |
|---|---|---|---|---|
| Skeptic | "Why you, with three supervisors, for twelve?" | 4 | The biggest scope gap sits here. | Rehearse A2 until it is calm; name the gap, then a ramp plan. |
| Data-Driven Prober | Asks how the 40% was counted | 4 | A headline figure, and the posting asks for reporting. | Defend-the-number slots, B1 to B3. |
| Case / Strategist | Live site problems | 3 | The posting is operational. | Clarify, segment, then act. |
| Pressure | Challenges your scope and the 40% | 3 | Stress probes on a one-site record. | Hold, then concede what is real. |
| Conversational | "Walk me through your path." | 2 | Casual opener, still scored. | A 90-second arc from your own sentences. |
| Peer | Seams with finance or other sites | 2 | Cost-per-shipment crosses teams. | Propose principles, not a made-up history. |
| Values / Behavioural | "Unpopular truth to leadership" | 1 | No published values in hand and no values round detected, so this is a generic probe. | Selection scaffold, with the honest branch. |

## Question banks

Question IDs run by persona. Provenance carries the sentence each guidance claim rests on. Each rationale refers to your history only by fit-snapshot row.

### Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which requirement in this posting would you be weakest on in your first 90 days?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Name the weakest requirement honestly: four sites and twelve supervisors, from F1 and F3. Then a ramp plan: visit each site, learn each site's on-time and cost baseline before changing anything. This is a plan, not a past. | F1 and F3 are the scope gap the posting leans on. |
| A2 | "Your record shows one shift and three supervisors. How would you run four sites and twelve?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | **Highest-ROI prep in this pack.** Say the scope plainly: "three supervisors at my current site." Then the structure: site leads, a weekly cross-site review, one shared metric set. Answer slot: if you ran any cross-site routine, say what it was and how you decided; if not, say so, and say what you would copy from the pick-path redesign. Hold through two follow-ups by returning to the scope, never by adding to it. | F1 and F3 are where this objection lands; it will come in some form. |
| A3 | "You're solid in Excel, but how would you build the reporting here, in Power BI?" | JD | [grounded] "solid Excel, never used Power BI" | Plain acknowledgment: "I haven't used Power BI." Then Excel: "I'm solid in Excel," and how you would build the first report in it. Answer slot: if you have started learning Power BI, say what you did; if not, say your plan and when you would start. | F5 is the stated absence; the question asks for a plan, not a claim. |

### Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was measured." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Story-mapped on F2: the redesign and the 40%, in your words. Defend-the-number slots: how the rate was counted, what it is sensitive to, the assumption you would defend least, and which part was yours. If you cannot say how it was counted, say so. | The headline figure on your record; probers go here first. |
| B2 | "What was the mis-pick rate before, and over what period?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Answer slot: if you have the before and after figures and the period, say them; if not, say so and say what you would check. Never supply a baseline. | A defend-the-number slot on the same figure. |
| B3 | "On the peak-season surge plan, what did you track, and how did you know it worked?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Answer slot: name what you tracked and how you read it; if you tracked nothing formally, say so and describe how you judged it. | The surge plan is the second thing probers reach for after the 40%. |
| B4 | "What's the on-time performance number you would defend, and how is it calculated?" | JD | [grounded] "drive on-time performance and cost-per-shipment down" (JD) | Answer slot: if you tracked on-time performance, say how it was calculated; if you did not, say so and say what you would measure first. | F2 is the gap. The question asks for a number; the honest answer may be that you did not track it. |

### Case / Strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "On-time performance dropped eight points at one site last week. Diagnose it." | CASE | [generic] | Clarify what changed and when. Segment by shift, lane and carrier. Check the data source before the numbers. Name what you would do in the first 48 hours. No claim about your past. | A live problem from the posting's core metric. |
| C2 | "Cost per shipment is rising at one of four sites. What do you do in the first two weeks?" | CASE | [generic] | Clarify scope. Separate volume from cost. Visit the site before changing a process. Name one hypothesis early and test it. | The posting's cost line, as a decision. |
| C3 | "Design the reporting cadence for four sites reporting to a regional leader." | JD | [grounded] "build reporting in Excel/Power BI" (JD) | Name the first report and its three numbers. Excel first, Power BI as a plan with a start date. | Covers the reporting requirement as a design problem. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Why should we hire someone who runs three supervisors over someone who has run a multi-site team?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" | Hold: the record is three supervisors at one site, and it is the record you bring. Hold through two follow-ups. Concede what is real: the jump to twelve across four sites is large. Then say what you would do in the first 90 days. Never fold on the scope. | F1 and F3; hold-then-concede. |
| D2 | "How many years have you led people, and in what roles?" | JD | [grounded] "7 years in warehouse and distribution ops" | Answer slot: give the number of years you have led people, from your own record, and the roles. The gate is that number; the material does not state it. | F4 is a gate; asked here and in the message. |
| D3 | "That 40% — how much of it was really you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the part that was yours. Answer slot: if the redesign was a team effort, name which part was yours; if you did not lead it, say so plainly. | Probes attribution under pressure. |

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through your path to here." | EXP | [grounded] "7 years in warehouse and distribution ops"; "currently a senior shift manager over 3 supervisors" | A 90-second arc: seven years in warehouse and distribution, then the senior shift manager role, in your own words. | Casual opener that is still scored. |
| E2 | "What are you playing with in Power BI these days?" | JD | [grounded] "never used Power BI" | Plain acknowledgment: "I haven't used Power BI." Then your plan. Do not claim a tool you have not used. | F5 comes up casually. |

### Peer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1p | "Cost per shipment crosses finance and the sites. What would you need from finance to own it?" | JD | [generic] | Propose principles: a shared cost definition, a monthly review, one owner per number. Do not invent a history with finance. | Seams between teams. |

### Values / Behavioural (weight 1)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told a senior person something they did not want to hear, with a named stake, what you said, and how it ended. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. Your material carries no such sentence. | Generic probe; no published values in hand. |
| G2 | "Tell me about your Lean or Six Sigma work, and the project you ran." | EXP | [grounded] "green belt certified" | Answer slot: name the project you led under the Green Belt, if one; if the certificate was training without a project, say so. | Covers the Lean/Six Sigma requirement. |

## Requirement coverage

| Requirement (JD) | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, A2, C2 |
| Drive on-time performance and cost-per-shipment down | B4, C1, C2, F1p |
| Lead a team of 12 supervisors | A2, D1 |
| Build reporting in Excel/Power BI | A3, C3, E2 |
| 5+ years operations leadership required | D2 (gate) |
| Lean/Six Sigma a plus | G2 |

## Reverse questions

1. "How do the four sites' on-time numbers compare right now?" Why it lands: shows you read the posting's metric before the interview.
2. "Is there a shared reporting view across the sites today, or is each site its own?" Why it lands: it tests the reporting gap honestly, and the answer tells you what Power BI would have to do.
3. "How are the twelve supervisors split across the four sites?" Why it lands: it asks about the scope you are being judged on.
4. "What would a strong first 90 days look like to you?" Why it lands: the answer is the scorecard you will be measured on.
5. "Which of the four sites is hardest to run, and what makes it so?" Why it lands: it shows you are thinking about the work, not the title.

## Sources

Provided documents: the job description pasted in your request; your background in your message.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Every call was refused: web search was not permitted in this session. Would have moved the values cheat sheet; no values section is included. |
| 2. Atlas Freight interview process | unavailable | Refused as above. Would have named the loop, which sets the persona weights and whether a values round exists. Weights here are the generic archetype. |
| 3. Atlas Freight strategy / recent news | unavailable | No call sent after the refusal. Would have fed the CO bank; no CO questions are included. |
| 4. Interviewer name + Atlas Freight | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

Queries sent (both refused): "Atlas Freight regional logistics company values"; "Atlas Freight interview process operations manager".

## Upgrade menu

- The round type and who you are meeting → reweights every persona bank and tailors the reverse questions.
- Atlas Freight's published values, or the recruiter's notes on the process → a values cheat sheet, and a loop structure in place of the generic weights. Research could not run here, so this is the route to them.
- The interviewer's name → an interviewer read, and reverse questions tied to their career path.
- A copy of your Green Belt certificate → F6 becomes inspectable rather than self-reported.
- Your 5+ years of leadership, stated by you → the gate row (F4) and D2 become answerable from your record.
- A Power BI plan or any Excel report you built → A3 and C3 gain something to point at.
- Prep time available → a prioritised schedule.
- A Word version of this pack, on request.
