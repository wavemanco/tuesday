# Live Operations Producer, Saltmarsh Games: interview prep pack

**Role:** Live Operations Producer. **Company:** Saltmarsh Games (mobile, about 350 people). **Interviewer:** Tobias Wrenfield, Head of Live Operations. **Relationship:** assumed hiring manager, not yet confirmed. **Length:** 60 minutes.

Built only from the job description and your background message. Web search was refused this session, so nothing about the company, its values or Tobias is established. Where a fact would need it, the pack says so.

## How to use + type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and stop when the answer is complete.

| Tag | Name | What it scores |
|---|---|---|
| VAL | Values / behavioral | Whether past behavior shows a published value. None is established here. |
| EXP | Experience deep-dive | Whether what you did survives scrutiny, and what was actually yours |
| JD | Role / JD-driven | Whether you can do the listed job, including its gaps |
| CO | Company knowledge | Homework on strategy and recent moves. None is established here. |
| CASE | Live problem | Structure and reasoning on a problem from this role |

**Answer slots** are instructions for the interview, not questions to answer here. Each gives the honest branch: if you did it, say how; if you did not, say so plainly.

## The fit snapshot

Requirements are quoted from the JD you supplied. Evidence is quoted from your background message. Nothing here is a claim you have not made.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | transferability | Your material shows one title and a weekly content-drop calendar, not live events across two titles. Bridge, in your words: "I ran the weekly content-drop calendar for our main title for the last two years." Answer slot: the JD asks for two titles, so expect a probe on the second. If you have planned events for more than one title, say which and how the work was split. If you have not, say so and say how you would start on the second. |
| F2 | "experience running a content calendar" (JD) | "I ran the weekly content-drop calendar for our main title for the last two years." (your message) | medium | [grounded] | none | No gap. The quote reaches the requirement in role terms. Expect a probe on what you set versus what was set for you. |
| F3 | "coordinate design, art, engineering and community teams on each update" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | Your material shows a QA-facing artifact, not coordination with design, art, engineering or community. Answer slot: if you coordinated any of those four teams on a content drop, name the team and what you did. If you did not work with them on drops, say so and say how you would set up that coordination on the first update. |
| F4 | "own the post-event review and the KPIs it reports" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | transferability | Your material says you presented monthly retention numbers. It does not say you owned a post-event review or the KPIs behind it. Bridge: "I presented the monthly retention numbers to the studio head." Answer slot: if you reviewed a content drop after it shipped, say what you looked at and who you reported to. If the monthly report was your only review, say so. |
| F5 | "manage the release checklist with QA" (JD) | "Wrote the release checklist our QA team still uses." (your message) | medium | [grounded] | presentation | The quote reaches the requirement in other terms: you wrote the checklist and QA still uses it. Bridge, reworded from that quote only: "I wrote the release checklist our QA team still uses." Do not add that you run it each release; your material does not say so. |
| F6 | "3+ years producing live-service games or apps" (JD) | "4 years as an associate producer at a puzzle-game studio." (your message) | medium | [grounded] | transferability | The four years meet the length in total. Your material does not say the puzzle title was live-service, and your title was associate producer. Bridge: "I have four years as an associate producer at a puzzle-game studio." Answer slot: if the puzzle title ran on a live cadence, say what it was, for example weekly drops. If it did not, say so. |
| F7 | "comfortable with player-retention metrics" (JD) | "Presented the monthly retention numbers to the studio head." (your message) | medium | [grounded] | none | No gap in role terms: you presented retention to the studio head each month. Your material shows no figure, so there is no number to defend yet. Expect a probe on how the numbers were built. |
| F8 | "clear written communication" (JD) | "Wrote the release checklist our QA team still uses." (your message) | low | [inferred] | discovery | A written artifact exists, but your material does not show how clear it is to its readers. Answer slot: name the written piece you are most proud of and what the reader did with it. If none comes to mind, say so. |
| F9 | Live-service monetization, not named in the JD [generic] | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Stated absence: "I haven't worked on a game with in-app purchases." Say how you would learn it, as a plan and never as a past. Do not claim monetization work. |
| F10 | People leadership, not required by the JD, which asks you to coordinate [generic] | "Never led a team, and never worked on a game with in-app purchases." (your message) | none | [grounded] | capability | Stated absence: "I haven't led a team." Say how you would coordinate four teams without managing them, as a plan and never as a past. |

**Gate rows:** none. The JD's experience length is not a gate under the suite's definition, so F6 is graded on fit.

**Analysis (the pack's own observation, not words for you):** your material shows one title, a calendar you ran, a checklist you wrote and a report you presented. It does not show coordination across four functions, ownership of KPIs, or any monetized title.

## Prohibited claims

These are not coached in any answer, hold or slot. Each entry gives its basis and its honest form.

| Not coached | Basis | Honest form |
|---|---|---|
| "I owned the live-events calendar for two mobile titles" | Inflated form of F1 and the JD's two-title line | Your quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The material says one title. |
| "I manage people" or "I have led a team" | Stated negative (F10) | "I haven't led a team." |
| "I owned the post-event review and the KPIs" | Inflated form of F4 | "I presented the monthly retention numbers to the studio head." |
| "I have in-app purchase or monetization experience" | Stated negative (F9) | "I haven't worked on a game with in-app purchases." |
| "I ran live-service events" | Inflated form of F6 | "4 years as an associate producer at a puzzle-game studio." Say the cadence you ran, if any. |
| "I manage the release checklist with QA" | Inflated form of F5 | "I wrote the release checklist our QA team still uses." |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic | Quiet probing of the gaps: day-one weakness, leadership, the missing monetization work | **High.** A hiring manager is buying capability and derisking the gaps. F3, F9 and F10 are the material's gaps, and the JD's coordination line points at them. | Rehearse the one objection (A2) until it is plain. Bridge only from quotes. Acknowledge stated gaps once, specifically. |
| Case / Strategist | Live problems on a live-events calendar for two titles | **High.** The JD is a calendar and coordination job, so the hiring manager will test how you think about one. | Clarify, then structure: objective, constraints, calendar, dependencies, KPIs. Name one premise you would challenge. |
| Data-Driven Prober | Asks how the retention numbers were built and what you would defend least | **Medium.** Retention is a JD requirement, but no figure is quoted, so the probe is about method, not a number. | Say what you presented and whose method it was. Name the weakest assumption you know, or say you do not know it. |
| Pressure / Stress | Time-boxed, loaded questions about leadership and whether one title is enough | **Medium.** A 60-minute round often has one hard moment; no stress style is established for this interviewer. | Pause and restate. Hold the quoted position through two follow-ups. Concede one specific gap, then stop. |
| Conversational / Rapport | Open "walk me through" and "what would you want to know" | **Low to medium.** Typical opener, but casual questions are still scored. | A 90-second arc in your own order. Treat the closing question as scored. |

Weights: Skeptic 5, Case 5, Prober 3, Pressure 3, Conversational 2. Total 18 questions, within the coverage band. The hiring-manager prior puts Case and Skeptic on top, and the JD's coordination and retention lines lift the Prober.

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "What part of this job would you be weakest at on day one?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." "Never led a team, and never worked on a game with in-app purchases." | Start from the first quote: four years, associate producer, puzzle-game studio. Name the two gaps in your own words: "I haven't led a team." and "I haven't worked on a game with in-app purchases." Then one sentence on how you would close the second, as a plan. Keep it under 90 seconds. | Day-one weakness is the Skeptic's standard frame and it aims at F9 and F10. JD because it scores fit to the posting. |
| A2 | "You've never led a team. Why would we make you the person coordinating design, art, engineering and community on every update?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." JD: "coordinate design, art, engineering and community teams on each update" | **The highest-ROI rehearsal in this pack.** Hold the true position: "The job asks me to coordinate, and I haven't led a team." Answer slot: if you have coordinated across any of those four teams on a content drop, name the team and what you did, in your own words. If you have not, say so and say how you would set up that coordination on the first update. Hold through two follow-ups by returning to what coordinating means here, never by claiming leadership. Concede once and specifically: "I can't yet show I've led people, so I'd want the first updates to show how I coordinate." | F3 and F10 are where this question aims, and it will come in some form. The premise that you lead is the question's, and the JD's word is "coordinate". The answer must not claim leadership. |
| A3 | "The JD asks for two titles. Walk me through how far your experience reaches beyond the one you ran the calendar for." | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Hold the scope the quote carries: one main title, a weekly content-drop calendar, two years. Say plainly that the second title is untested for you. Answer slot: if you have planned events for more than one title, say which and how the work was split. If you have not, say so and say what you would do in your first month to learn the second title's cadence. | F1 is transferability: the probe lands on the one-title limit. The premise is the JD's two-title line, and the second branch lets the wider experience be absent. |
| A4 | "You wrote the release checklist. What do you do with it today to manage release with QA?" | JD | [grounded] "Wrote the release checklist our QA team still uses." JD: "manage the release checklist with QA" | Say what you wrote, in those words. Answer slot: if you ran a release against the checklist with QA, say which step was yours and what QA did. If you wrote it and did not run releases against it, say that, and say how you would take on the running. Do not describe a release process you did not run. | F5 is presentation: the quote reaches the requirement, but "manage" is not in it. The second branch allows the checklist never having been run by you. |
| A5 | "Your title has been a puzzle game. What do you think changes when a title has in-app purchases?" | JD | [grounded] "Never worked on a game with in-app purchases." | Acknowledge once: "I haven't worked on a game with in-app purchases." Then answer as an expectation, not as experience: name one thing you would check first, such as what an event is meant to move and what it might cost players. Do not describe any monetized work. | F9. The JD does not name in-app purchases; the probe is the usual one for mobile live operations, and it is a role-family pattern rather than a fact about this employer. |

### Case / Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sketch the next three months of live events across both titles. What do you need to know first?" | CASE | [grounded] JD: "Plan and run the live-events calendar for two of our mobile titles" | Clarify out loud first: which two titles, what event types each runs, the current cadence, the KPI each team reports against, and who owns the release checklist for each. Then give objective, constraints, calendar shape, dependencies by team, and the review and KPIs. Name one premise you would challenge. Do not describe either title's state; you do not know it. | The live problem from the JD's calendar line. CASE asks about no past, so the guidance makes no claim about you. |
| B2 | "An event on one title finished last week and retention is down. Diagnose it." | CASE | [generic] | Clarify: what the event was, how retention is defined, the baseline to compare against, and whether the drop is across all players or one segment. Then list causes in order: what else shipped in the window, a release or outage, seasonality, cohort mix. Name the one check you would run first. | Retention is a JD requirement, and this is the diagnosis form it takes. Scores the order of questions, not the answer. |
| B3 | "Your next event needs a release in three weeks, and the QA checklist is due the same week. What do you cut and what do you protect?" | CASE | [grounded] JD: "manage the release checklist with QA" | Protect the QA gate and anything that breaks a release. Cut the scope that can move to the next drop. Say who you would call before cutting anything: design, engineering, QA, community. | The checklist line becomes a live trade-off. No past claim. |
| B4 | "On a monetized title, what would you put on the event dashboard, and what would you not trust?" | CASE | [generic] | Name one primary metric the event is meant to move, one guardrail it must not damage, and the assumption behind the primary metric that you would check first. Say how you would read the number before you trust it. Name no figures. | Covers the retention requirement and the monetization probe at once. The question's monetized frame is the interviewer's, and the answer claims no experience. |
| B5 | "What would you need from design, art, engineering and community before you commit to an event date?" | CASE | [grounded] JD: "coordinate design, art, engineering and community teams on each update" | One question per team, in order: design, what is the content scope; art, what is the asset lead time; engineering, what must be built or flagged; community, what players will be told. Then QA's gate. This is a process answer, not an account of your past. | Scores the coordination line directly, and gives a way to answer it without leadership experience. |

### Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "How did you count the retention numbers you presented?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Say what you presented and whose calculation it was. If you built the calculation, walk through it in your own words. If you presented someone else's, say whose and what you checked. If you do not know how the figure was counted, say so plainly. Name the weakest assumption you know of before they ask. | F7. Retention is a JD requirement and this is the prober's usual first question. No figure is quoted, so the method is the probe. The second branch allows that you do not know the method. |
| C2 | "Which of the retention numbers you presented would you defend least, and why?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Name, in your own words, the assumption you would defend least. If you do not know the assumptions, say so and say what you would check first. Do not invent a weakness to look humble. | The weakest-assumption move. It is the counter-strategy this persona scores, and it turns the gotcha into a credibility point. |
| C3 | "After a content drop, what did you review, and who read it?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Answer slot: if you reviewed a drop after it went live, say what you looked at and who you reported it to. If the monthly retention report was your only review, say that. Do not describe a review format you did not run. | F4. The JD's post-event review line is the premise, and the second branch allows that no such review was yours. |

### Pressure / Stress (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "You have sixty seconds. Why hire someone who has never led a team to coordinate four teams?" | JD | [grounded] "Never led a team, and never worked on a game with in-app purchases." "I ran the weekly content-drop calendar for our main title for the last two years." | Pause and restate the question in one line. Hold the position the quotes carry: "The job asks me to coordinate, and I have run a weekly content-drop calendar for two years." Concede the specific gap once: "I haven't led a team, and I'd want support on that." Hold through two follow-ups; do not fold on the calendar record. | F10 and F3. Stress interviewers test composure under a loaded question. Hold, then concede the one true gap. |
| D2 | "That release checklist QA still uses: how much of it was actually you?" | EXP | [grounded] "Wrote the release checklist our QA team still uses." | Say what you wrote. Answer slot: if others changed it, say which parts and whether you agreed. If they did not, say so. Hold what you wrote; do not claim the checklist as the team's current design unless you know it. | F5. An attribution probe, which rewards exact wording. |
| D3 | "Four years at one studio, one title family. Why should this be your next step?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Give the reason in your own words, in terms of the work in the posting: coordinating across more functions and owning a KPI review. Answer slot: your material does not state a reason for moving, so say it in your own words. Do not criticise your studio. | F6. The reason to move is not in your material. Pressure questions probe it, so the answer must come from you, not from the pack. |

### Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." | Ninety seconds, in your own words, in this order: the studio and role, the calendar you ran, the checklist you wrote, the retention report you presented, and the gap you would most like to close. Then stop. | The biography opener. Casual register is still scored, and the arc keeps the answer inside the quotes. |
| E2 | "What would you want to know about the two titles before your first calendar meeting?" | JD | [generic] | Name three: the current event cadence for each title, the KPIs each team reports against, and who owns the release checklist for each. Say one of them aloud. | A question you ask, not a claim about you. Rapport openers score whether you have read the JD. |

## Requirement coverage

| Requirement (JD) | Questions that cover it |
|---|---|
| Plan and run the live-events calendar for two titles | A3, B1, E2 |
| Coordinate design, art, engineering and community on each update | A2, B5, D1 |
| Own the post-event review and the KPIs it reports | C3, RQ2 |
| Manage the release checklist with QA | A4, B3, D2 |
| 3+ years producing live-service games or apps | A1, D3 |
| Experience running a content calendar | A3, E1 |
| Comfortable with player-retention metrics | B2, B4, C1, C2 |
| Clear written communication | none, and why: the round is spoken, so writing cannot be tested directly. The upgrade menu asks for a written sample. |

## Reverse questions

Each one, with why it lands. Tobias's profile was not available, so none ties to their own path; the upgrade menu says what would add one.

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "How is the calendar for the two titles set each quarter, and who decides when a team's date conflicts with QA's?" | Tests the process at the seam the JD names, and shows you read the calendar line closely. |
| RQ2 | "What does a post-event review look like here, and which KPIs does it report?" | Asks about the exact line the JD gives the role, so it shows you read the posting. |
| RQ3 | "Which of the two titles is more sensitive to retention right now, and who owns that number?" | A concrete question about ownership, and it treats retention as the spine of the job. |
| RQ4 | "What would coordination across design, art, engineering and community look like for this role in the first ninety days?" | A sharper version of the usual first-90-days question, aimed at the coordination gap. |
| RQ5 | "What has the live team learned from an event that changed how the next one was planned?" | Asks for a case, not a slogan, and tells you how the team learns. |

## Prep notes for the room

- **The one objection to rehearse until it is boring is A2:** you have not led a team, and the job asks you to coordinate. Your true answer is the calendar and the checklist, and the honest gap.
- **Do not say "we" for work you did not do.** Use "I" for what you ran or wrote, and name the team when you coordinated.
- **Two stated gaps need one clean sentence each.** "I haven't led a team." and "I haven't worked on a game with in-app purchases." Say them once, then move to what you did.

## Sources

- **Provided documents:** the job description you supplied; your background message.
- **Searches:** two were sent. Both were refused, so nothing was returned:
  - "Saltmarsh Games mobile game studio live operations": refused.
  - "Tobias Wrenfield Head of Live Operations Saltmarsh Games": refused.
- **Dossier:** none consumed.

**Research tier:** L1 — searches 2 of 6, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Saltmarsh Games values` | unavailable | No call sent; search was refused for this session. Would have moved the values cheat sheet, which this pack therefore omits. |
| 2. `Saltmarsh Games interview process live operations` | unavailable | No call sent; search was refused. Would have set the loop structure and the persona weights for the other rounds. |
| 3. `Saltmarsh Games strategy` / recent news | unavailable | The company query above was refused. Would have moved the CO bank and the grounding brief. |
| 4. `Tobias Wrenfield Saltmarsh Games` | unavailable | The interviewer query above was refused. Would have moved the interviewer read, the persona weights and a tailored reverse question. |
| 5. Representative `Live Operations Producer` JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- Round type and relationship → confirms whether Tobias is your manager; if it is a panel, the other members' personas are added and the weights rebalance.
- Tobias's public footprint, once search is allowed → persona weights read from it, and a reverse question tied to their own path.
- Saltmarsh's values or a pasted careers page → the values cheat sheet, for a values-style round.
- A written sample you are allowed to share, such as the release checklist text or a post-event report → F5 and F8 get inspectable proof, and their confidence can rise.
- The second title's details, such as which titles and their event cadence → the F1 and A3 answer slots narrow to something you can rehearse.
- The recruiter's email on focus areas or any pre-declared exercise → a build section for it.
- Your prep time before Friday → a prioritized schedule for the pack.
- A `tuesday-dossier.md`, if you have one → its verified evidence and prohibited claims replace the inferred rows.
