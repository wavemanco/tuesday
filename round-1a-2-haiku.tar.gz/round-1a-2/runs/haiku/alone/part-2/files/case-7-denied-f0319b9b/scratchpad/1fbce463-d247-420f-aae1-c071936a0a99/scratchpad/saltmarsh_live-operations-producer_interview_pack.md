# Live Operations Producer, Saltmarsh Games: interview prep pack

**Interviewer:** Tobias Wrenfield, Head of Live Operations. **Length:** 60 minutes, Friday.
**Relationship assumed:** hiring manager. Not confirmed. Persona weights below rest on this.
**Changelog:** first version.

---

## 2. How to use, and the type key

**Personas** are how a question arrives: the Case/Strategist poses a live problem, the Skeptic presses your gaps, and so on. **Types** are what gets scored:

- **VAL**: published values. None in this pack (see section 10 note).
- **EXP**: your own experience, checked for precise attribution.
- **JD**: the job's stated requirements.
- **CO**: company strategy. None in this pack (research refused).
- **CASE**: a live problem from the role.

**Guidance is scaffolding, not a script.** Each cell is speakable in about 90 to 120 seconds.

**Labels.** `[grounded]` means traceable to your own sentence or to the JD text you gave. `[inferred]` is this pack's derivation. `[generic]` is a pattern for the role with no claim about you or about Saltmarsh.

**Answer slots.** Where a question asks about a practice your material does not show, the guidance gives two honest branches. Say whichever is true. Neither branch is a wrong answer.

**Read first: where you stand.**

- Strongest, all from your own sentences: the weekly content-drop calendar you ran for two years, the release checklist QA still uses, and the monthly retention presentations to the studio head.
- Weakest, in the order an interviewer is likely to press: owning the post-event review and its KPIs; coordinating four teams without leading them; one title rather than two; no live-service label on the puzzle title; no in-app purchase experience.
- Highest-return rehearsal: B1. The JD asks you to own the review and KPIs. Your material shows you presented retention numbers. That gap is the one most likely to be asked in some form.
- Stated gaps, handled plainly: you have never led a team, and you have never worked on a game with in-app purchases. The pack gives you the plain sentence for each, then a plan. It does not give you a defence.
- The JD asks you to coordinate design, art, engineering and community. It does not ask you to lead them. Keep "coordinate" and "lead" separate in every answer.
- Prep time was not stated, so no prep-triage schedule is included.

---

## 4. Fit snapshot

Requirements are quoted from the JD you pasted. Evidence is quoted from your message. The JD names no gate (location, work authorisation, pay), so the snapshot has no `hard_gate` row. In-app purchases are not in the JD, so they get no row here. They appear in B4 and in the prohibited list.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Plan and run the live-events calendar for two of our mobile titles" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | transferability | Your material says one title, weekly content drops, for two years. It does not say two titles or live events. Say the calendar at its own scope. Medium confidence because it is your account, not a document the interviewer can see. Answer slot: if any of those drops were time-limited events, say which and how they ran; if none were, say so. If you have not planned two calendars, say so and describe how you would keep two titles from colliding. |
| F2 | "experience running a content calendar" — JD | "I ran the weekly content-drop calendar for our main title for the last two years." — your message | medium | [grounded] | none | The sentence reaches the requirement in the JD's own terms. Expect a probe on scope (one title, weekly). Lead with the calendar in those words. |
| F3 | "3+ years producing live-service games or apps" — JD | "4 years as an associate producer at a puzzle-game studio." — your message | medium | [grounded] | transferability | Four years meets the three-year count. The material does not say the puzzle title was live-service. "Content-drop" suggests it was, but that is for you to describe in your words. Answer slot: if you can say what made the title live-service, say it; if you cannot, say the content-drop calendar is the closest thing you ran, and say what it was. |
| F4 | "comfortable with player-retention metrics" — JD | "Presented the monthly retention numbers to the studio head." — your message | medium | [grounded] | discovery | The sentence shows you presented retention numbers. It does not show whether you built, chose or interpreted them. Answer slot: if you built or chose the metric or how it was counted, say how, in your own words. If you presented numbers someone else built, say that plainly and say what you did with them. |
| F5 | "own the post-event review and the KPIs it reports" — JD | "Presented the monthly retention numbers to the studio head." — your message | low | [inferred] | transferability | Reporting a KPI to a head is adjacent to owning a review. That adjacency is this pack's derivation, not your claim. Never say you owned a post-event review. Say what you presented and to whom. Answer slot: if you ran or shaped a review of a release or event, say which; if the monthly presentation is the closest you came, say so. |
| F6 | "coordinate design, art, engineering and community teams on each update" — JD | "Never led a team, and never worked on a game with in-app purchases." — your message | none | [grounded] | discovery | Your material does not show coordinating design, art, engineering or community on a release. The one negative you gave is about leading a team, which this line does not ask for. Answer slot: if you coordinated any of those teams on a release, say which and how, in your own words; if you did not, say so and describe how you would run it. |
| F7 | "manage the release checklist with QA" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | presentation | The sentence already reaches the requirement, and QA's continued use is in it. Say it in those words: "I wrote the release checklist our QA team still uses." Do not add sign-off, ownership or a QA process beyond what the sentence says. |
| F8 | "clear written communication" — JD | "Wrote the release checklist our QA team still uses." — your message | medium | [grounded] | none | The checklist is the written artifact the requirement points at. Same sentence, same scope. Bringing the checklist itself would move this row (upgrade menu). |

**Notes on the columns.** Confidence grades your evidence, and Provenance grades this pack's statement about it. On a gap row, Provenance grades the gap statement: F6's gap is in the material's silence, so its words are an answer slot, not a claim.

---

## 8. Persona table

**Weights and why.** Relationship prior: hiring manager, assumed. No loop source was established, so the archetype is generic and the weights rest on the relationship prior and the JD's own lines. No interviewer profile exists, so there are no signal adjustments. These weights reflect a relationship prior, not Saltmarsh's documented process.

| Persona | Weight and depth | How it shows up here | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|---|
| Case/Strategist | 5, so 5 questions (A1 to A5) | Live problems on the calendar, a cross-team conflict, a QA block, a post-event review | Top weight. A hiring manager buys capability and tests it on the roadmap. The JD's calendar and coordination lines are roadmap work. | Clarify, then objective, segmentation, approach, metrics, risks. Say the structure aloud. |
| Skeptic | 4, so 5 questions (B1 to B5) | Probes on review and KPI ownership, team leadership, live-service, in-app purchases, who chose the metric | Second weight. Your gaps are visible in the material, and they are where a hiring manager derisks. | Rehearse B1 until it is plain. Calibrated candour beats bluffing a competency you have not shown. |
| Data-Driven Prober | 3, so 3 questions (C1 to C3) | How the retention figure was counted; which KPI you would drop | Mid weight. The JD names retention metrics and KPIs twice. | Say what you do not know about how a number was counted. Name the assumption you would defend least. |
| Peer Evaluator | 2, so 2 questions (F1, F2) | The seam between a content drop and a feature release; credit across four teams | Low weight. Peer seams are a peer's probe, and the hiring manager is the relationship here. The JD's coordination line is the raising source. | Propose seam principles, not a seam you have not seen. Name each team's part before your own. |
| Pressure / Stress | 2, so 2 questions (D1, D2) | Sixty-second "why you"; "how much of that was actually you" | Low weight. A time-boxed interview with a hiring manager may still push the live-service label. | Hold the calendar through two follow-ups. Concede specifically, never fold on the core claim. |
| Conversational / Rapport | 2, so 3 questions (E1 to E3) | A journey opener, a "what are you playing" aside, a checklist walk-through | Low weight but scored. The casual register is where communication economy gets judged. E3 is one above the floor because no other question reaches the JD's written-communication line. | A 90-second arc. Treat the casual questions about JD topics as scored. |
| Values / Behavioral | Dropped | None | No published values were read (research refused). No loop source. The generic archetype detects no values round. Nothing here earns a values bank. | If the interview runs a values-style sequence, the JD's coordination line is the closest raising source. None is built here. |

---

## 9. Question banks

**Requirement coverage.**

| JD requirement | Questions |
|---|---|
| Plan and run the live-events calendar for two of our mobile titles | A2, B3 |
| Coordinate design, art, engineering and community teams on each update | A3, B2, F1, F2 |
| Own the post-event review and the KPIs it reports | A5, B1, C2, C3 |
| Manage the release checklist with QA | A4 |
| 3+ years producing live-service games or apps | B3, D1, E1 |
| Experience running a content calendar | A2, B3, D2, E1 |
| Comfortable with player-retention metrics | B5, C1, C2 |
| Clear written communication | E3 |

Every requirement has at least one question. None is uncovered.

### A. Case/Strategist (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Retention on the main title has dropped over the past three weeks, and it started after a content drop. Talk me through how you'd diagnose it." | CASE | [generic] | Clarify first: which retention definition, which cohort, and whether the drop is across the whole base or in one segment. Split it: did the drop change who plays, or how long they stay? Check what else moved that week (a store change, a bug, a price change, a rival's event) before crediting the drop. Name the metric you trust least and what you would check first. Close with what you would tell design and whether you would hold or roll back. No claim about your history is made here. | The top persona's case problem. The JD asks for comfort with retention metrics, and B5 and C1 cover your past. Tagged CASE because the scoring is structure. The scenario is generic because it is not drawn from your material. |
| A2 | "Sketch next quarter's live-events calendar across two titles. What do you need to know first?" | JD | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Clarify first: each title's release cadence, what counts as a live event for each, the QA and community lead times, and what is already booked. Then a structure: a fixed weekly rhythm, one slot per title, a freeze date before QA sign-off, and a way to see collisions between the titles. Use your main-title calendar as the reference point, in its own words. Answer slot: if you have sequenced two calendars before, say how; if you have not, say so and describe how you would keep the two titles from colliding. | The JD's calendar line. The calendar you ran is the only one in your material, so the answer rests on it. The hold is one title, not two. |
| A3 | "Your design team wants a live event that needs a new art pipeline in three weeks. Engineering says it needs two. Community has already told players the date. What do you do?" | CASE | [generic] | Structure: what the date is anchored to and what the event must achieve; the smallest version that hits that; who decides between design, art and engineering, and by when; what community says now and what they say if the date moves. Name a decision owner and a review point. No claim about your past. | The JD's coordination line, across all four teams (F1, F6). It asks for the decision path, not your record. |
| A4 | "QA blocks a release on a checklist item the team says is out of date. How do you handle it?" | CASE | [grounded] "Wrote the release checklist our QA team still uses." | Clarify: is the item out of date, or is the team disputing what the check is for? Who owns the checklist, and what is the release risk if it ships without the check? Then decide the item with QA, not around them. If the checklist is wrong, change it through its owner and record the change. Do not waive the check for the date without a named decision. Answer slot: if you changed the checklist after QA raised an item, say what changed and who signed it; if you have not, say so and describe how you would change one. | The JD's release-checklist line (F7). The only claim about your past is the checklist sentence, quoted, and the guidance adds nothing to it. |
| A5 | "Walk me through what a post-event review should contain, and who should read it." | JD | [grounded] "Presented the monthly retention numbers to the studio head." | The framework is generic. Contents: what the event was meant to do; the KPI and its baseline; what happened against it; the causes you can support and the ones you cannot; decisions and owners; what changes next time. Readers: the leads for design, art, engineering and community, and whoever takes the KPIs upward. Answer slot: if you have written or presented a review of an event or release, say which and what it reported. The monthly presentation is the closest sentence you gave, so if that is the closest, say so and say what you would add to it. | The JD's ownership line (F5). The framework is generic. Your history enters only through the quote and the slot. |

### B. Skeptic (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Which part of this job would you be weakest at on day one?" | JD | [grounded] "Presented the monthly retention numbers to the studio head." | **Highest-return rehearsal in this pack.** Name the weakest part in the JD's own terms: owning the post-event review and the KPIs it reports, across two titles. Say what you did with the monthly retention numbers, in those words. Then give the ramp, in order: read the last reviews, rebuild the KPI set with the owners, run the first review alongside someone who has done it. Hold through two follow-ups by returning to the presentation and the plan. Concede specifically that owning the review is new to you. Answer slot: if you have owned or shaped an event review, say so; if the presentation is the closest, say that. | Most likely objection: the JD asks for ownership of the review and KPIs, and your material shows reporting a KPI to a head. The question is open, and the guidance rests on your quote and on a plan, not a claimed practice. |
| B2 | "I don't see team leadership in your background. How do you coordinate design, art, engineering and community on an update when you don't lead any of them?" | JD | [grounded] "Never led a team" | Plain acknowledgment first: "I haven't led a team." Then the coordination answer. Coordinating four teams is a different job from leading them. Say what you did with any of those teams on a release, in your own words. If you did not coordinate them, say so and describe how you would run it: one release owner, a shared calendar, a standing check-in with each lead, and a named decider when they disagree. Do not say "in all but name" or "effectively led". | The team-leadership gap. The negative in the question is your own stated negative, so the premise has a source. The JD asks for coordination, not leadership, and the answer must not stretch one into the other. |
| B3 | "Four years on puzzle games. Is a live-service calendar for two titles the same job?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Do not argue the label. Say what the content drops were, in your words: weekly, for your main title, for two years. Say whether time-limited events were part of them. Answer slot: if your title ran live events, say how they worked; if the drops were the only live element, say that, and say what carries over into a calendar for two titles. Do not call the puzzle title live-service unless you can say what made it so. | The JD's live-service line and calendar line (F1, F3). The JD names live-service directly, so the question is likely. |
| B4 | "I don't see in-app purchase work in your background. How would you think about monetisation when you plan content for a title?" | JD | [grounded] "never worked on a game with in-app purchases" | Plain acknowledgment first: "I've never worked on a game with in-app purchases." Then do not claim monetisation knowledge. Say how you would learn it, stated as a plan: ask the monetisation owner what each drop is sold as, check how past drops have performed with the team, and ask design which content is paid. Do not describe any purchase data you have not seen. | Your stated gap. In-app purchases are not in the JD, so this is a Skeptic stem built on your own negative, not a JD-raised question. It is ranked below B1 and B2. It is tagged JD because it concerns the role's monetisation side. |
| B5 | "You presented retention numbers. Did you pick the metric, or inherit it?" | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot: say which metric it was, and whether you chose it or inherited it. If you chose it, say what you chose and why. If you inherited it, say so. If you did not know how a number was counted, say that plainly and name the assumption you would check first. Do not describe a retention definition your material does not give you. | The JD's retention line (F4). The Skeptic's version of "did you build it". The answer is a slot, not a fact. |

### C. Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the monthly retention numbers you presented were counted." | EXP | [grounded] "Presented the monthly retention numbers to the studio head." | Answer slot. Say how the numbers were counted, in your own words. If you did not compute them, say so, say who did, and say what you checked. Name the assumption you would defend least. No figure is given in your material, so no defend-the-number slot is raised yet (upgrade menu). | F4. A prober asks for the method, and the honest answer is what you know. |
| C2 | "What would you want to see before you trusted a retention number in a post-event review?" | JD | [generic] | Generic metric discipline: the definition and its window; the baseline and comparison group; sample size and date range; whether the event was the only change in the period; whether the number moved for players or for measurement. Name one thing you would check first, and why. No claim about your past. | The JD's retention line and KPI-review line (F4, F5). Prober style: the denominator, not the headline. |
| C3 | "Name a KPI you would stop reporting on a live title, and why." | JD | [generic] | Pick a metric that moves with noise or that players can game, and say what would replace it. The reason has to be about the metric, not about reporting effort. No claim about your past; if you have stopped reporting a number, say which and why, but only if that is true. | The JD's KPI line (F5). It forces a choice of metric, which a prober follows up. |

### D. Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you, for a live-service role, with puzzle-game experience?" | JD | [grounded] "4 years as an associate producer at a puzzle-game studio." | Pause, restate, then answer in under sixty seconds: the four years, the calendar you ran for two years, and the checklist QA still uses. Hold the calendar and the checklist through two follow-ups. Concede specifically on the live-service label and on team leadership. Never fold on the calendar. Answer slot: if you can name what in the drops was live, say it; if not, concede that the title is not what the JD calls live-service, and name what carries over. | The JD's live-service line, time-boxed. Hold-then-concede. |
| D2 | "That content calendar. How much of it was actually you?" | EXP | [grounded] "I ran the weekly content-drop calendar for our main title for the last two years." | Pause. Say what you ran: the weekly calendar for your main title, for two years. Hold through two follow-ups. Separate what was the team's from what was yours, in your own words. Answer slot: if any part of the calendar was yours to set, say which and how you decided; if you ran a calendar others set, say that and describe what you did. Do not turn "ran" into "set" or "owned" unless you decided it. | The attribution probe on your strongest claim. Hold-then-concede on the calendar. |

### E. Conversational / Rapport (weight 2, three questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "4 years as an associate producer at a puzzle-game studio." "I ran the weekly content-drop calendar for our main title for the last two years." "Wrote the release checklist our QA team still uses." "Presented the monthly retention numbers to the studio head." | A 90-second arc with four beats, in this order: four years as an associate producer at a puzzle-game studio; two years on the weekly calendar for your main title; the checklist QA still uses; the monthly retention presentations to the studio head. Close on why this role: the calendar for two titles, and what you would need to learn, which is the review and its KPIs. Keep "I" for what you did and keep each quote at its own scope. | Opener in a casual register, scored as a communication check. All four beats come from your sentences. |
| E2 | "What are you playing at the moment in mobile live-service games?" | JD | [generic] | Name what you actually play, if anything. If you play none, say so, and say what you have looked at to understand how these games are run. Do not claim familiarity with a title you have not played. | A casual question on the JD's live-service topic. It is scored, and honesty is the answer. |
| E3 | "Walk me through the first item on the release checklist you wrote." | JD | [grounded] "Wrote the release checklist our QA team still uses." | Casual-sounding, but scored for written clarity. Say the item in one sentence: what it checks and who signs it. Keep it short. Answer slot: if the first item has changed since you wrote it, say so. | The JD's written-communication line. No other question reaches it, and the checklist is the artifact. |

### F. Peer Evaluator (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Our design and engineering leads sit side by side with you. Where's the seam between a content drop and a feature release, and what happens when you disagree?" | JD | [generic] | Propose seam principles, not a seam you have not seen. A drop is content on a fixed system; a feature release changes the system, so it gets an earlier freeze and a separate QA pass. When you disagree with a lead, name the trade: date against scope, and who decides. Answer slot: if you have disagreed with a team over a release, say how it was settled; if you have not, say so and say how you would settle it. | The JD's coordination line (F6). The peer register: seam and disagreement. |
| F2 | "How do you handle credit when a drop depends on four teams?" | JD | [generic] | Name each team's part first, then what you did, in your own words. Do not claim the drop as yours where the parts were theirs. Answer slot: if you did a part no one else did, say which; if you did not, say so. | The JD's coordination line across four teams (F6). Credit-sharing is a peer probe. |

---

## 11. Reverse questions

No interviewer profile exists, so none of these ties to Tobias's own path. Each has a "why it lands" line.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What does a good first 90 days look like in this role, and who would I need to earn trust with first?" | Shows you have thought about the gap in coordination, and gives you a plan you can check. |
| R2 | "How is the live-events calendar decided today: who proposes, who signs off, and how often does a planned event slip?" | Tests the JD's "plan and run" line against the real calendar. Reveals governance and how healthy the calendar is. |
| R3 | "What does the post-event review look like now, and which KPIs does it report?" | The JD says you would own it. You need the current state before you accept. |
| R4 | "If either title sells in-app purchases, how does that change what the content team plans for?" | Your own gap, turned into diligence. It shows you know the question matters without claiming experience you lack. |
| R5 | "When design, art, engineering and community disagree on an update, who makes the call, and how is it recorded?" | Finds the decision owner, which is the seam the coordination line depends on. |
| R6 | "What is the one thing about the two titles you'd want a new person to understand in their first month?" | Open, and it lets Tobias say what he is actually worried about. |

---

## 13. Prohibited claims

Built locally from the fit snapshot. None of these is coached, asserted, softened or implied in any cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the live-events calendar for two titles | Inflated form of F1: one title and weekly drops, stretched to two titles and live events | The quote at its own scope: "I ran the weekly content-drop calendar for our main title for the last two years." The limit is this pack's observation: your material says one title and weekly drops. A2 and F1's slot stay inside that scope. |
| Shipped or ran live-service titles | Inflated form of F3: a puzzle-game studio, stretched to a live-service claim | "4 years as an associate producer at a puzzle-game studio." The pack's observation: the material does not state the title's live-service status. |
| Owned the post-event review and its KPIs | Inflated form of F5: presenting numbers, stretched to ownership of a review | "Presented the monthly retention numbers to the studio head." The pack's observation: presenting is what the material shows. |
| Built or chose the retention metric | Inflated form of F4: presenting, stretched to building | The quote at its own scope. B5 and C1 ask how it was counted; the slot allows the honest branch. |
| Owned the QA sign-off or ran the checklist process | Inflated form of F7: writing the checklist, stretched to running QA's process | "Wrote the release checklist our QA team still uses." The pack's observation: the material says you wrote it and that QA still uses it. |
| Led or managed a team | Negative you stated (F6): "Never led a team" | Plain acknowledgment: "I haven't led a team." No slot on this. |
| Has worked with in-app purchases | Negative you stated (F6): "never worked on a game with in-app purchases" | Plain acknowledgment: "I've never worked on a game with in-app purchases." No slot on this. |

Not listed: coordinating design, art, engineering and community on releases. Your material is silent on it, so it is an answer slot (F6), not a prohibited claim.

---

## 14. Sources

**Provided documents.** Your message, containing the JD text and your background. No dossier. No links read.

**Searches sent.** All four were refused by the session's permission. Nothing was returned for any of them.

1. "Saltmarsh Games values mobile game studio": refused.
2. "Saltmarsh Games interview process Live Operations Producer": refused.
3. "Saltmarsh Games strategy news 2026": refused.
4. "Tobias Wrenfield Saltmarsh Games Head of Live Operations": refused.

**Fetches sent.** None.

**Consequences.** Nothing about Saltmarsh's values, loop, strategy or Tobias's public work is established. The persona weights use the relationship prior and the generic archetype. The values section, the grounding brief and the interviewer read are dropped. The "Saltmarsh" name is common, so any search result would have needed checking against the company before use.

**Research tier: L1, searches 4 of 6 (all refused), fetches 0 of 2; user links read 0**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Saltmarsh Games values | unavailable | Refused. Would have supplied published value names for VAL questions and the values cheat sheet. Dropped because no values round is detected. |
| 2. Saltmarsh Games interview process, Live Operations Producer | unavailable | Refused. Would have named the loop and could have established a values round or a different persona mix. Persona weights rest on the relationship prior and the generic archetype instead. |
| 3. Saltmarsh Games strategy / recent news | unavailable | Refused. Would have supplied the CO bank and the grounding brief. Both are dropped, so no CO question is written. |
| 4. Tobias Wrenfield, Saltmarsh Games | unavailable | Refused. Would have supplied an interviewer read, a persona adjustment and a tailored reverse question. None is built. |
| 5. Representative Live Operations Producer JD | skipped | The JD you supplied fixes the fit snapshot and the JD-tagged questions. |

---

## 15. Upgrade menu

- **Permission for web search** → the four refused lookups can be run again. That would turn the values section, the loop-based persona weights, a current strategy bank and an interviewer read from generic to sourced. Deep research (L2) is also available: up to six more searches and two more fetches, several minutes. Say the word if you want either.
- **The retention figure you presented, and how it was counted** → defend-the-number slots on F4, C1 and B5, with the exact figure in your own words.
- **The release checklist, redacted** → moves F7 and F8 toward high confidence, since an inspectable artifact is what the high band needs.
- **The content calendar, redacted** → moves F1 and F2 toward high confidence, and makes A2 and D2 answerable with something the interviewer can see.
- **Whether your drops included time-limited events** → closes the F1 and B3 answer slots.
- **Whether you coordinated design, art, engineering or community on a release, and how** → turns F6 from a slot into a sourced answer, and answers A3 and F1 directly.
- **Whether the puzzle title ran live events, and what made it so** → lets F3 say the live-service part in your words.
- **The round type, and whether Tobias is the person you would report to** → reweights every bank. This is the one question in the message.
