# Interview prep pack: Operations Manager, Atlas Freight

Assumed round: hiring-manager round (your note didn't say who you're meeting). Interviewer unknown. Research tier: L0, provided documents only.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is scored: VAL (values), EXP (your experience, defended), JD (the listed job), CO (company knowledge), CASE (live problem).
- Guidance is scaffolding, not a script. Speak it in your own words, in 90–120 seconds.

## Fit snapshot

Quotes are from your message unless marked.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows one shift, not four sites. Say the shift you run, in those words. Answer slot: the four-site scope makes a probe likely. If you have run or covered more than one site, say how; if not, say so and say what you'd do first. |
| F2 | "lead a team of 12 supervisors" (JD) | "senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Three is not twelve, and the bridge must not stretch it. Say the three. Answer slot: how you'd lead twelve is a plan, not a past. |
| F3 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Accuracy is adjacent to on-time and cost, not the same. Answer slot: if you measured any effect on throughput, time or cost, say what; if not, say so. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message) | medium | [grounded] | transferability | Seven years is operations; your message does not say how many were leadership. Answer slot: give the year you first led people, and say what the leadership years were. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message); "never used Power BI" (your message) | high (Excel), none (Power BI) | [grounded] | transferability (Excel), capability (Power BI) | Excel is a credible base. Power BI: "I haven't used Power BI." Then how you'd learn it, as a plan. |
| F6 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | high | [grounded] | none | Lead with the certification as stated. A project you ran with it would be an answer slot. |

## Prohibited claims

| Not coached | Basis | Honest form |
|---|---|---|
| Ran four sites or terminal-wide operations | Inflated form of F1 | "senior shift manager over 3 supervisors" |
| Led twelve supervisors | Inflated form of F2 | "senior shift manager over 3 supervisors" |
| Improved on-time performance or cost per shipment | No quote supports it (F3) | The pick-path result, at its own scope |
| Built Power BI reporting | Negative stated in F5 | "I haven't used Power BI." |
| Five years of leadership | Duration not stated (F4) | The year you first led people, if you give it |
| Led the pick-path redesign | "redesigning" does not say who led it | "cut mis-pick rate 40% by redesigning the pick path", with your part named in your own words |

## Persona weights

| Persona | How it shows up | Likelihood | Counter-strategy |
|---|---|---|---|
| Skeptic | Attacks the 3-to-12 and 1-to-4 jumps | High (5) | Hold the facts you have, concede the gap plainly |
| Data-driven prober | Asks how the 40% was counted | High (4) | Name the baseline and the weakest assumption before they do |
| Pressure | Pushes on a bad site week | Medium (3) | Hold-then-concede |
| Case / strategist | Live site problem | Medium (3) | Structure out loud |
| Conversational | Peak-season story | Low (2) | A tight story with a clear part |

## Question banks

### Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "You manage three supervisors. This role leads twelve across four sites. What makes you think you can?" | JD | [grounded] "senior shift manager over 3 supervisors" | **Highest-ROI prep.** Hold: "Right now I'm over three supervisors, on one shift." Concede: the jump is real and untested. Hold through two follow-ups by returning to the three. Answer slot: if you've led more people or covered more than one site, say how; if not, name the first thing you'd do with twelve, as a plan. | F2 is the widest gap, and this question will come in some form. |
| S2 | "You've never used Power BI. How would you build the reporting this role needs?" | JD | [grounded] "solid Excel"; "never used Power BI" | "I haven't used Power BI. I'm solid in Excel. Here's how I'd close the gap: ..." Plan, not past. | F5. Stating the gap first is what makes the answer credible. |
| S3 | "The role requires five years of operations leadership. Where are your years?" | JD | [grounded] "7 years in warehouse and distribution ops"; "senior shift manager over 3 supervisors" | Give the seven years of operations, then the year you first led people. Answer slot: the leadership start date is not in your material. Say it. | F4. |
| S4 | "Who leads your supervisors now, and how do you hold them to standard?" | JD | [grounded] "senior shift manager over 3 supervisors" | Describe the three, the standard you set, and how you check it. Answer slot: any method you actually used; if none is formal, say so. | Tests the "lead a team" requirement at its real size. |

### Pressure (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "Your 40% was mis-pick rate. We measure on-time and cost per shipment. Why should I believe you can move those?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Hold the 40% at its scope. Concede: accuracy is not on-time or cost. Answer slot: if the redesign changed throughput or cost, say what; if not, say so. | F3. Hold-then-concede. |
| P2 | "Two of your sites missed on-time this month. Your boss asks why. What do you say?" | CASE | [generic] | Structure: which site, which cause, what you check first, what you tell your boss. No claim about your past. | Pressure on a live problem, not a record. |

### Data-driven prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "How was the 40% counted, and what was it sensitive to?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" | Name the baseline period and the counting method. Name the assumption you'd defend least before they do. Name which part was yours. Answer slot: the material doesn't give the baseline or method; say what you have. | F3's number is the magnet for a prober. |
| D2 | "What did the peak-season surge plan cost, and what did it hit?" | EXP | [grounded] "ran the site's peak-season surge plan two years running" | Say what the plan covered and what you tracked. Answer slot: volume, labour hours or on-time, whichever you used. If none, say so. | Peak plan is your strongest operations story; the numbers are not in your material. |
| D3 | "Show me how you'd build a weekly on-time report in Excel." | JD | [grounded] "solid Excel" | Name the inputs, the layout and the one chart you'd lead with. Plan, not past. | F5 under a live test. |
| D4 | "What did your Green Belt project deliver?" | EXP | [grounded] "green belt certified" | If you ran a project, name it and its result. Answer slot: if certification is what you have, say so. | F6 is a certificate, and a probe will ask for the project. |

### Case / strategist (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Two of four sites are missing on-time and cost per shipment is up. What do you do in your first 30 days?" | CASE | [generic] | Structure: measure on-time and cost by site and lane first; find the constraint; talk to supervisors; pick one fix; set a review cadence. No claim about your past. | The JD's core job, as a problem. |
| C2 | "Your pick-path redesign cut mistakes. Would a similar approach move on-time at a site with different constraints?" | CASE | [grounded] "redesigning the pick path" | Yes, if the constraint is the same; name what you'd check first. The transfer is the argument, not the result. | Bridges F3 to the on-time metric. |

### Values (not detected; no bank)

No values-style round was detected and no published values were provided, so no values bank is built.

### Conversational (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Tell me about the peak-season plan you've run." | EXP | [grounded] "ran the site's peak-season surge plan two years running" | A short story: the situation, your part, what changed the second year. Answer slot: who else made calls. | Low weight, but the easiest place to sound grounded. |
| R2 | "Tell me about a time a supervisor disagreed with a change you wanted." | VAL | [generic] | Pick one real time. Say what you did to get agreement. Story-selection scaffold; no quote supports a specific. | Generic leadership probe for the 12-supervisor scope. |

### Requirement coverage

| JD requirement | Questions | Note |
|---|---|---|
| Daily terminal ops, 4 sites | S1, C1 | |
| On-time and cost per shipment | P1, C1, C2 | |
| Lead 12 supervisors | S1, S4, R2 | |
| Excel / Power BI reporting | S2, D3 | |
| 5+ years ops leadership | S3 | |
| Lean / Six Sigma | D4 | |

## Reverse questions

1. "What does success look like in the first six months across the four sites?" Why: it shows you're thinking about the scope, not just the job title.
2. "How many supervisors are there today, and how is the span split across sites?" Why: it tells you whether the 12 is a real load or a target.
3. "Who builds the reporting now, and in what tool?" Why: it tells you how much Power BI matters on day one.
4. "Is on-time or cost per shipment further from target right now?" Why: it shows you're asking for the priority, not a platitude.
5. "Is there a continuous-improvement function, and who runs it?" Why: it tests whether your Green Belt has a home.

## Upgrade menu

- The round type and who you'll meet → reweights every persona and may replace the Skeptic bank
- The interviewer's name → a tailored reverse question and persona weights from their public footprint
- Company research at L1 (up to 6 searches, 2 page fetches) → current strategy, values and vocabulary for the Case and reverse banks
- Your site's actual on-time %, cost per shipment, and team history → answer slots S1, S3, P1, D1, D2 get grounded
- Any gate the JD sets (location, licence, shift pattern) → a gate row in the fit snapshot
