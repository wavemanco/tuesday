# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not given. Round type: "final round", relationship not stated. Built with flat persona weights (see Persona table). Regeneration: first version, no changelog.

## How to use this pack

- **Personas** describe how a question arrives (the register and the pressure). **Types** describe what the question scores.
- Type key: **VAL** behavioural / values alignment. **EXP** work-experience deep-dive. **JD** role-driven. **CO** company and strategy knowledge. **CASE** live problem.
- Guidance is scaffolding, not a script. Rehearse it aloud, in your own words, and cut anything you could not say out loud to someone who was in the room.
- Provenance: nothing in this pack is yet traceable to your CV or a job description. Every bank row is `[generic]` until those arrive.

## Fit snapshot

No job description or CV has been supplied, so this is the worksheet variant: the requirements are role-family patterns, not quotes from a posting, and no evidence cell holds anything from your past. Gate rows: none known, since no posting has stated any location, authorisation or schedule term.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Run an operating cadence and business reviews for a product area (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a cadence you ran end to end: what it reviewed, who attended, what changed afterwards. Selection scaffold: pick a review cadence you ran or took part in; if you did not, say so plainly, then name the nearest meeting that made decisions and what you did in it |
| F2 | Define, build and use metrics and dashboards that drive decisions (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a metric you defined, its source, and a decision it changed. Selection scaffold: pick a metric you built or relied on; say how it was counted; if you have none, say so plainly and say what you would measure first |
| F3 | Design cross-functional processes and intake that set priorities (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a process you designed or changed, the teams it touched, and how priorities moved. Selection scaffold: pick a process that crossed teams; if you did not design it, say so plainly, then describe how you worked inside it |
| F4 | Coordinate launches or programmes across several teams (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is one launch you coordinated: its dates, its blockers and what you did when they moved. Selection scaffold: pick a launch or programme with more than one team; if you were not the coordinator, say so plainly and describe your part |
| F5 | Write clearly for executives and turn analysis into a recommendation (role-family pattern, no posting supplied) | none given | none | [generic] | discovery | Strong evidence is a document or update that changed a decision, with its audience named. Selection scaffold: pick one piece of writing that reached leadership; if none did, say so plainly and describe the nearest written recommendation you made |

## Prohibited claims

The list is empty, and that is the finding rather than an omission. No candidate sentence exists yet in this conversation, and a prohibited entry is the stretched form of something the candidate said. When your CV or a dossier arrives, this section is rebuilt from it.

Also not coached, because nothing was established about it: any claim about Stripe's values, interview loop, strategy or recent events. Those are absent from this pack for the reason given under Sources.

## Persona table

No interviewer is known and the round type is unstated, so weights are flat across the four plausible personas, using the Relationship priors for a final round. Each row shows its reasoning, and each is a generic pattern, not a finding about this loop.

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Case / Strategist | A live operations problem: diagnose a metric drop, plan a launch, design a review | High. Operations roles are usually tested on live problems; this is a role-family pattern, not confirmed for this loop | Clarify, then structure, then name the metric you would watch |
| Data-Driven Prober | "How was that counted?" and "what assumption would you defend least?" | Medium to high. Metric-heavy role; probes come in every round that reads your CV | Know how each number you cite was counted; say plainly when you do not know |
| Pressure / Skeptic | Motivation probes, "why not someone with more direct experience?", a day-one gap | Medium. Final rounds test fit and motivation; no known gap yet | Pause, restate, hold a position through two follow-ups, then concede only what is true |
| Values / Behavioural | STAR-shaped stories on disagreement, unpopular truths, failures | Medium. The fallback big-tech archetype usually includes a values-style round, but no loop source confirms one here | Pick a real story, say "we" for context and "I" for your own contribution |
| Conversational / Rapport | "Walk me through the journey", "what are you playing with lately" | Low to medium. Casual, but still scored | Keep a 90-second arc ready; treat casual questions as scored |

## Question banks

Total 18 questions, weighted by depth: Case 5 (highest), Prober 3, Pressure 4, Values 4, Conversational 2. Each guidance cell is `[generic]`: none of it asserts anything about your past, because no sentence of yours is quoted yet.

### A. Data-Driven Prober (3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Which metric would you use to tell whether an operations process is working, and why that one?" | JD | [generic] | Name the outcome first, then one leading indicator and one guardrail. Say what the metric would miss | Tests whether you can separate a number from the outcome it stands for. Role-family pattern for operations roles |
| A2 | "Tell me about a time you used a number to make a decision. How was it counted?" | EXP | [generic] | Open prompt. Pick a number you used to decide something. Give how it was counted, what it was sensitive to, the assumption you would defend least, and which part was yours. Answer slot: if you have no such number, say so plainly and describe the nearest decision you made from incomplete data | An open prompt with a persona stem. The probe comes after the answer, so the counting detail has to be ready |
| A3 | "What is a metric you rely on that could mislead you? Why?" | JD | [generic] | Name one metric and the assumption behind it, before the interviewer does. Say what would show it was misleading | Converts a gotcha into a credibility point. Role-family pattern |

### B. Case / Strategist (5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A conversion rate in a key funnel dropped 15% this month. How do you diagnose it?" | CASE | [generic] | Clarify the metric definition and the time window. Segment before hypothesising. Name two or three hypotheses, the data that would separate them, and what you would do first. Keep it to about two minutes | The highest-weight persona's standard live problem. Generic, because no company data was consulted |
| B2 | "You are asked to set up an operating review for a product area that has none. What do you do in the first 30 days?" | CASE | [generic] | Start with who needs the review and what decision it serves. Then the first meeting's agenda, the metric set, and who owns follow-up | Tests whether you can build a cadence rather than run one. Maps to F1 |
| B3 | "A launch slipped two weeks, and three teams disagree about the cause. Walk me through what you do." | CASE | [generic] | Separate facts from accounts. Name the decision that needs making now and who makes it. Propose a way to agree the cause without waiting for a consensus | Tests coordination under disagreement. Maps to F4 |
| B4 | "How would you design an intake process for cross-team requests so the highest-impact work gets done first?" | JD | [generic] | State the criteria before the process: value, effort, urgency, who is blocked. Then the intake form, the review rhythm, and how you say no | Tests prioritisation design. Maps to F3 |
| B5 | "What would you want to understand about how this team works before proposing any change?" | CASE | [generic] | Name three or four specific questions about decisions, owners and current pain points. Show you would listen before changing anything | Presupposes nothing about the team. Gives a strong, honest answer to a question that appears in many rounds |

### C. Pressure / Skeptic (4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Sixty seconds: why should we hire you over someone with more direct operations experience?" | JD | [generic] | Pause. Restate the question. Answer with what you can show for the role, in your own words. Hold the position through two follow-ups; concede only the part that is true | Time-boxed challenge to the fit. Pressure-persona pattern |
| C2 | "Which part of this role would you be weakest at on day one?" | JD | [generic] | Name one specific area. Say how you would learn it in the first month, and who you would ask | Persona stem. A calibrated answer beats a bluff |
| C3 | "Why operations rather than a product role?" | EXP | [generic] | Answer with the work you want to do and why, in your own words. The pack cannot supply your motive; if your reason is not yet clear to you, say so and name what you are still deciding | Motivation-consistency probe. Common in final rounds |
| C4 | "That result you're proudest of: how much of it was actually you?" | EXP | [generic] | Separate three things: what you did, what the team did, and what you would not claim. Answer slot: if the result was mostly someone else's, say so plainly and describe your part | Attribution probe. Rehearsed honesty under pressure |

### D. Values / Behavioural (4)

No published values were established, so these are generic behavioural prompts, not mapped to any value. Tagged EXP, not VAL, for that reason.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Tell me about a time you delivered an unpopular truth to leadership." | EXP | [generic] | Open prompt. Choose a real instance with a named stake. Say what you said, how it landed, and what happened next. Answer slot: if no such time comes to mind, say so plainly, then give the nearest instance | Persona stem. Standard behavioural probe for leadership-facing roles |
| D2 | "When did you put a customer ahead of an internal metric?" | EXP | [generic] | Open prompt. Name the customer, the metric, and the trade-off. Say what you gave up | Persona stem. Common in customer-led companies, but no company value confirms it here |
| D3 | "Tell me about a process you owned that failed. What did you change?" | EXP | [generic] | Open prompt. Name the failure plainly, then the change you made and how you knew it worked. Answer slot: if no process of yours failed, say so, then describe the closest failure you did own | Tests ownership and self-correction |
| D4 | "Tell me about a time you disagreed with a peer and still had to reach a decision together." | EXP | [generic] | Open prompt. Name the disagreement, how you surfaced it, and how the decision was made. Say what you would do differently | Stakeholder and influence probe. Maps to the cross-functional line in F3 |

### E. Conversational / Rapport (2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey to this point." | EXP | [generic] | Build a 90-second arc: the role you held, what you did in it, and what you want next, in your own sentences. The arc cannot be written until your CV is supplied; until then, use this skeleton and fill it from your own words | Casual opener that still scores. Pre-scripted arc is the rehearsal |
| E2 | "What have you been reading or working on in operations lately?" | JD | [generic] | Name one thing you can speak to in depth. If you have none, say so and name what you would read first | Tests genuine interest, not recall. Casual but scored |

### Requirement coverage

| Role-family requirement | Question IDs | Note |
|---|---|---|
| Operating cadence and business reviews (F1) | B2, A1 | |
| Metrics and dashboards (F2) | A1, A3, B1, A2 | |
| Cross-functional process and prioritisation (F3) | B4, B5, D4 | |
| Launches and programmes across teams (F4) | B3 | |
| Writing for executives (F5) | C1, C3 | Coverage is thin; a written-recommendation question would strengthen it |

## Reverse questions

Each one is aimed at the role or the team, not at the company's published claims, which were not established.

| # | Question | Why it lands |
|---|---|---|
| R1 | "What would a strong first 90 days look like for this role, and who would judge it?" | Shows you plan for outcomes and identify the people who decide |
| R2 | "Which decision from this team's last quarter would you have wanted an operations partner for?" | Signals that you think in decisions, not in tasks |
| R3 | "How does this team know whether product operations is working?" | Surfaces the metric the team actually uses, and the gap between it and what they say |
| R4 | "What is the hardest trade-off this team is making right now?" | Invites a conversation at the interviewer's altitude |
| R5 | "Where does this role's authority end, and how do you handle decisions outside it?" | Tests whether the role is designed for influence or for control |
| R6 | "What could someone in this role do in their first month that would genuinely help your team?" | Reciprocity question. Use it if the interviewer turns out to be a peer; it works in any case |

## Sources

- Provided documents: the user's message only. No job description, CV, interviewer name, recruiter guidance, strategy brief or values page was supplied.
- Searches sent: 2. Both were refused by the host, so neither returned any result. Fetches sent: 0.
  - "Stripe company values principles official" (domain-limited to stripe.com): refused.
  - "Stripe interview process product operations manager final round": refused.
- Research tier line: Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Stripe values` | unavailable | Every call was refused. Would have moved the values section, which is therefore absent; no value names are given in this pack |
| 2. `Stripe interview process Product Operations` | unavailable | Every call was refused. Would have moved the loop structure; the persona weights therefore fall back to the big-tech archetype and are flagged as a pattern |
| 3. `Stripe strategy` / recent news | unavailable | No call sent: the host had refused the search. Would have moved the CO questions; there are none in this pack |
| 4. `{interviewer name} Stripe` | n/a | No interviewer name was given, so there was no query to form |
| 5. representative `Product Operations Manager` JD | unavailable | No call sent: the host had refused the search. Would have moved the fit snapshot's requirement rows from role-family prose to `[inferred]` quotes |

## Upgrade menu

- A job description, pasted → the five `[generic]` requirement rows in the fit snapshot become quoted rows, and the requirement coverage table is rechecked against the posting's own list
- Your CV, pasted → the fit snapshot gets your sentences as evidence, the defend-the-number slots for A2 and C4 get their real figures, and E1 gets a story arc drawn from your own words
- The round type and who you are meeting → the persona weights stop being flat, and the reverse questions can be tied to the interviewer's path
- Your recruiter's note on focus areas, or any take-home or presentation → a graded-deliverable section, built to the assignment
- Stripe's values page, pasted → a values cheat sheet with a mapped story for each value your CV or stories support
- Permission to run web research → targets 1, 2 and 5 can be run, which replaces the fallback loop pattern with sourced structure and the generic requirement rows with a representative JD
- A `tuesday-dossier.md` → would add verified evidence, and make the highest-ROI objection evidence-derived rather than inferred

Highest-ROI prep, for now: rehearse B1 (the live diagnosis) and C1 (the sixty-second fit answer). Both will come up in some form, and neither depends on a CV.
