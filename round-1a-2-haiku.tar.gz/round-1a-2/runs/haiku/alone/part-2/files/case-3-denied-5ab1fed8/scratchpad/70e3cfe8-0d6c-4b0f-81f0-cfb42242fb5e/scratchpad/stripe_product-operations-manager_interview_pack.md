# Interview prep pack: Product Operations Manager, Stripe (final round)

Interviewer: not known. Round type: "final round", format not known. Built at research tier L1, but both web searches were refused, so nothing below comes from Stripe's published pages (see Sources).

## How to use

- **Personas** describe how a question is asked (the register and the pressure). **Types** describe what is being scored.
- Type key: **VAL** behavioral/values, **EXP** past-work deep-dive, **JD** role requirements, **CO** company strategy, **CASE** live problem.
- Guidance is scaffolding, not a script. Answers must come from your own experience, in your own words.
- Your material is not in this pack yet (no CV, no job posting), so no answer makes a claim about your past. Where an answer needs one, it is marked as an answer slot: say what is true for you, or say plainly that it was not yours or did not happen.

## Fit snapshot

No CV and no job posting were supplied, so this is a worksheet: requirements are generic for the role family, and every evidence cell is "none given."

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | Operating cadence for product and launch work (generic) | none given | none | [generic] | discovery | Strong evidence looks like: a process you set up or ran end to end, and the team that depended on it. Answer slot: pick a process you ran for a team that relied on it; if you did not set it up, say whose it was. If there is no such process, say so, and describe how you would build one. |
| F2 | Coordinating decisions across product, engineering, finance and legal (generic) | none given | none | [generic] | discovery | Strong evidence looks like: a decision that needed groups with competing priorities to agree, and what you did. Answer slot: pick one such decision, say what you did, and if someone else drove it, say so. |
| F3 | Metrics and dashboards for launch or program health (generic) | none given | none | [generic] | discovery | Strong evidence looks like: a metric you defined or tracked, how it was counted, and its weakest assumption. Answer slot: name a metric you tracked and how it was counted; if you did not define it, say who did. |
| F4 | Launch or rollout management with a clear owner and timeline (generic) | none given | none | [generic] | discovery | Strong evidence looks like: a launch you helped run, your role in it, and what slipped. Answer slot: pick one launch; say what your part was and what you would change. |
| F5 | Written updates and escalations to senior leaders (generic) | none given | none | [generic] | discovery | Strong evidence looks like: an update or escalation you wrote, who read it, and what changed as a result. Answer slot: pick one; say who it went to and what happened next. |

No gate rows: no posting was supplied, so no requirement is known to be a hard gate.

## Prohibited claims

None listed, and the reason is in the pack's analysis: no sentence about your past has been given yet, so there is no wording to stretch into a larger claim. The pack will not coach any claim about your work that you have not stated in this conversation. When you add your CV, this section will be rebuilt from its sentences.

## Persona weights

Flat weights, said plainly: no relationship to the interviewer is known, no interviewer profile exists, and no loop source establishes the final round's structure. The pack therefore uses the generic archetype's flat weights and does not describe Stripe's final round.

| Persona | Weight (depth) | How it shows up here | Counter-strategy |
|---|---|---|---|
| Data-Driven Prober | 3 | Follow-ups on any number or measure you give | Name how a figure was counted and its weakest assumption before they do |
| Pressure / Stress | 3 | Time-boxed challenges, questions about how much was yours | Pause, restate, hold the position through two follow-ups |
| Values / Behavioral | 3 | Scenario probes on how you treat people and customers. No published values are in hand, so these are informal | Use a story where you actually acted; if none comes to mind, say so |
| Case / Strategist | 3 | Live operating problems | Clarify, then structure, then answer, thinking aloud |
| Skeptic | 3 | Where a gap would show first, and why now | One specific answer and a concrete ramp plan; do not bluff |
| Conversational / Rapport | 3 | Casual openers about your path and current interests | Keep a 90-second arc; treat casual questions as scored |
| Peer Evaluator | 3 | Where the seam with product sits, credit, what you need from them | Propose seam principles rather than claiming to know theirs |

Likelihood is medium for all seven, for the reason above: nothing separates them yet.

## Question banks

Each guidance cell is written against the rule above: no claim about the candidate's past, and each honest branch allows that the thing never happened.

### A. Data-Driven Prober

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Tell me about a metric you reported on. How was it counted?" | EXP | [generic] | Pick one metric you reported. Say what it measured, how it was counted, and what it was sensitive to. If you did not count it yourself, say whose it was. If you have no such metric, say so and name the nearest figure you handled. | Open prompt from the Prober stem; no CV line to defend yet, so the guidance chooses nothing for you. |
| A2 | "Which assumption behind that figure would you defend least?" | EXP | [generic] | Name the weakest assumption in your own words before they do. Stop there; do not add a method you cannot repeat. | Deepest follow-up of A1. Naming the weak spot first converts a gotcha into a credibility point. |
| A3 | "How would you know a process change you made actually worked?" | JD | [generic] | Name the before-and-after measure, what you compared against, and one thing you would not claim from it. If you have not measured one, say what you would measure first. | Maps to F3 (metrics) and F1. Asked as a method, so the answer is a plan, not a record. |

### B. Pressure / Stress

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Sixty seconds: why should we hire you for this?" | JD | [generic] | One sentence on the operating work you have done, one on what you would do first here, then stop. Hold the position through two follow-ups; do not extend the 60 seconds into a pitch. | Pressure stem; maps to F5 and F4. The hold is the structure, not extra content. |
| B2 | "Tell me about a result you are proud of. How much of it was actually you?" | EXP | [generic] | Say what you led and what you contributed to, in your own verbs. Concede specifically where others shared the credit. Do not fold on the part you did. If nothing comes to mind, say so and give the nearest result. | Open prompt; the hold-then-concede structure is the point. |
| B3 | "Convince me you would still want this job in a year, when the novelty is gone." | JD | [generic] | Name two or three parts of this kind of work you would want to keep doing after the novelty fades. Answer in those terms, not in enthusiasm. | Skeptic-adjacent motivation probe, asked under time pressure. |

### C. Values / Behavioral

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you had to deliver news a team did not want to hear." | VAL | [generic] | Pick a time the news was unwelcome. Say what you said, to whom, and what happened after. If no such time comes to mind, say so plainly, then give the nearest one. | Values stem. No published values are in hand, so no value is mapped and no story is assumed. |
| C2 | "When did you put a customer or user ahead of an internal metric?" | VAL | [generic] | Same scaffold as C1: one specific decision, what it cost, what you did. If none comes to mind, say so, then give the nearest one. | Values stem. Customer-over-metric stories are a common probe, so have one ready or a clear honest branch. |

### D. Case / Strategist

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "A launch you own slips two weeks, two days before a customer commitment. What do you do?" | CASE | [generic] | Clarify what the commitment is and who depends on it. State the objective, the options (hold, cut scope, split the launch), the decision, and the message to each group. Think aloud. | F4 is the closest requirement. A live problem, so it asks about no past. |
| D2 | "A product team ships fast but keeps dropping handoffs. Where do you start?" | CASE | [generic] | Clarify which handoffs, who owns each, and what breaks. Give the structure before any proposal. Propose one fix and one measure. | F1, operating cadence, asked as a live problem. |
| D3 | "A key metric dropped 20% last month. Diagnose it." | CASE | [generic] | First check whether the measurement changed. Then segment (by region, product, cohort) and form one hypothesis per segment. Name what you would check first. | Generic diagnosis; F3's measurement logic applied live. |

### E. Skeptic

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Which part of this job would you be weakest at on day one?" | JD | [generic] | Name one specific area and a concrete ramp plan: what you would read, who you would ask, what you would do in the first two weeks. Do not claim you have no weak spot. | Skeptic stem. The honest answer is a specific area, not a general humility line. |
| E2 | "Where would a gap in your background show up first in this role?" | JD | [generic] | Name the area and what you would do about it. If you do not think there is a gap, say what you would check to find out. | Asked without assuming any gap; the candidate names it. |
| E3 | "Why now, and why here?" | EXP | [generic] | One honest sentence on what you want that your current situation does not offer, in your own words. No criticism of your current employer. | Motivation-consistency probe; the Skeptic's central question. |

### F. Conversational / Rapport

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "So, walk me through the journey." | EXP | [generic] | A 90-second arc: where you started, what you have done in operations, and why this role. Keep each beat to something you did. Practice it aloud twice. | Rapport opener. It is scored like any other question. |
| F2 | "What part of product operations are you most interested in right now?" | JD | [generic] | Name one area, and what you have read or built in it. Keep it short and specific. | Casual phrasing of a JD topic; scored as much as any formal probe. |

### G. Peer Evaluator

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| G1 | "Our teams sit side by side. Where is the seam between product and operations, and what happens when we disagree?" | JD | [generic] | Propose principles for the seam (who decides what, how disagreements escalate) rather than claiming to know theirs. Give a disagreement story if you have one. If not, say so and describe how you would handle one. | F2. The honest answer is a principle plus a plan. |
| G2 | "How do you handle credit when work spans teams?" | EXP | [generic] | Describe how you name contributors. Never claim credit for another person's work. If you have no example, say so and describe your practice. | Peer credit probe; tests attribution honesty. |
| G3 | "What would you need from us in your first 30 days?" | JD | [generic] | A short, concrete list of what you would need, and one thing you would offer back. | Reciprocity; signals you are thinking about their load, not only yours. |

### Requirement coverage

| Requirement | Questions |
|---|---|
| F1 Operating cadence | A3, D2 |
| F2 Cross-functional decisions | G1 |
| F3 Metrics and dashboards | A1, A2, A3, D3 |
| F4 Launch management | B1, D1 |
| F5 Written updates and escalations | B1 |

Coverage is against generic requirements, because no posting was supplied. Once you share the posting, this table is rebuilt against its own list.

## Reverse questions

Each one carries its reason.

1. "What does a strong first six months look like in this role?" Why it lands: it shows you are planning, and it gives you their scoring criteria.
2. "Which operating problem is the team most trying to fix this year?" Why it lands: it shows interest in current priorities without claiming knowledge of them.
3. "When priorities conflict between product and finance, how does this role resolve it?" Why it lands: it maps the seam and invites the interviewer to describe the job.
4. "What would make you say the last person in this role did excellent work?" Why it lands: it asks for outcome criteria, the closest thing to a rubric.
5. "How will this round's decision get made, and who will be in the room?" Why it lands: final rounds often have a committee, and the question shows you know it.
6. "What would a new person on this team do in their first month that would genuinely help you?" Why it lands: reciprocity, useful if the interviewer is a peer.

## Sources

- Provided by you: the role, the company, "final round," and the request for prep. No job posting, CV, interviewer name, recruiter guidance or values page was provided.
- Searches sent, both refused (web search permission not granted in this session):
  - "Stripe company values principles", restricted to stripe.com — refused.
  - "Stripe interview process product operations manager final round" — refused.
- Fetches: none sent.

Research tier: L1 — searches 2 of 6, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Stripe values | unavailable | Values cheat sheet, which is dropped from this pack because no published values are in hand. The refused search was the only path to it |
| 2. Stripe interview process, product operations | unavailable | Loop structure. Persona weights stay flat, and the pack does not describe the final round |
| 3. Stripe strategy / recent news | unavailable | Company and strategy (CO) questions. None are included, so no strategy question is grounded |
| 4. Interviewer name and Stripe | n/a | No interviewer name was given, so there is no query to form |
| 5. Representative product operations manager JD | unavailable | Requirements for the fit snapshot. Replaced here by generic role-family prose, labeled [generic] |

## Upgrade menu

- A job posting → the five generic requirements become quoted, [grounded] rows, and the coverage table is rebuilt against the posting's own list
- A short CV or background summary → the worksheet's evidence cells fill in, and the guidance can be story-mapped where your sentences carry a story
- The name of the interviewer, or their title → persona weights from their public footprint, and a reverse question tied to their own career path
- A recruiter email: which rounds make up the final, the format, any take-home or presentation → weights and coverage recomputed, and any graded deliverable gets its own build section
- Web search allowed in this session → the two refused targets run: Stripe's published values (a values cheat sheet with mapped stories) and the interview process (loop structure and persona weights)
- Stripe's values page pasted in → the values cheat sheet, without a search
- A deeper research pass, optional: up to 6 more searches and 2 fetches, several minutes, covering strategy, interviewer talks and recent org context → strategy questions (CO), grounded in current facts
- `tuesday-dossier.md` → a record of gaps this prep exposes, carried into later sessions
