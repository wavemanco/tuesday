Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-4-denied-b4f2acd1/1cda1386-66ff-4da7-bab8-4a8c31cc031d/scratchpad/quartzline_product-manager-platform-apis_interview_pack.md. It's built for a hiring-manager round on Thursday 19 November, from your dossier and its JD. I couldn't run web research because search permission was refused, so it has no company strategy or values.

Say the word and I'll play the Skeptic on A1, the objection your dossier names as the highest-ROI prep.
I can also add a `pack_feedback` section to your tuesday-dossier.md recording the gaps this prep exposed.
If you'd like the pack as a Word document, say so and I'll convert it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: quartzline_product-manager-platform-apis_interview_pack.md -----
# Interview pack: Product Manager, Platform APIs at Quartzline

Round: hiring manager, 45 minutes. Date assumed: Thursday, 19 November 2026 (today's date). Interviewer name: not given. Built from the pasted dossier (version 1.1, dated 2026-08-14) and the JD it carries. No web research was run.

## How to use

Personas describe how a question arrives. Types describe what is being scored.

Type key: **JD** = a stated requirement or responsibility; **EXP** = what you actually did; **CASE** = a live problem in the role; **CO** = company strategy (none in this pack); **VAL** = values (none in this pack).

Guidance is scaffolding, not a script. An *answer slot* is an instruction for the interview: answer it in your own words, from your own experience, on either branch it gives.

## Prep triage

The dossier's condition for this role: the bridge is positioned as adjacent work, never as PM experience, and squad authority is verified in the room rather than assumed.

In priority order:

1. **A1**, the objection. Say the two negatives plainly, then the bridge in the quoted words.
2. **D1**, the 90-second arc, so the opening is settled before the round starts.
3. **Reverse questions R1 and R2**, on decision authority and the adoption baseline.

Everything else is insurance.

**Interview timing (45 minutes)**

- 0–3 min: opening, then D1.
- 3–15 min: A1, A2, A4 (objection, years, shipped).
- 15–27 min: B1, B2 (case).
- 27–35 min: C1, C3 (attribution and adoption).
- 35–40 min: E1 or E2 if the round turns pressured; otherwise A5 and A3.
- 40–45 min: your reverse questions, R1 and R2 first.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "3+ years product management experience" (JD, role_profile R1, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | low | [inferred] | transferability | Say the title plainly first: "I haven't held the product manager title or role." Then the adjacent work at its own scope: "I led client integrations of the vendor's REST APIs," and "I ran quarterly roadmap-input sessions feeding client evidence to product." The limit is the pack's observation, not your words: the material shows integration leadership and input to product, not PM years. |
| F2 | "Shipped API or platform products" (JD, role_profile R2, must_have) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1 | high | [grounded] | transferability | Words at E1's scope: "I led client integrations of the vendor's REST APIs, from scoping to go-live." The limit is the pack's observation: the material shows integrations of the vendor's APIs, not a platform product you shipped. Answer slot: if you shipped a product or platform component yourself, say what and your part; if you did not, say what the integration work did carry. |
| F3 | "Technical fluency: API docs, schemas" (JD, role_profile R3, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; "Wrote the internal integration playbook" — dossier E2 | low | [inferred] | discovery | The material touches the requirement (architecture, requirements, a playbook) without showing docs or schemas. Answer slot: if you wrote, reviewed or changed API docs or schemas, say which and your part; if you did not, say so and say what you would check first. |
| F4 | "Stakeholder management across engineering, sales, customers" (JD, role_profile R4, important) | "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" — dossier E1; "Ran quarterly roadmap-input sessions feeding client evidence to product" — dossier E3 | medium | [grounded] | transferability | Words at scope: "I led client integrations," and "I ran quarterly roadmap-input sessions feeding client evidence to product." Clients and product are in the material; engineering and sales are not. Expect a probe on E3, and volunteer the limit: say what you can show and what you cannot. |
| F5 | "Agile delivery experience" (JD, role_profile R5, preferred) | none given | low | [inferred] | discovery | No verified entry speaks to the word, so there is no bridge. Answer slot: if you ran delivery on a sprint or similar cadence, say how in your own words; if you never worked that way, say so, and say what you would want to confirm about how this team defines agile delivery. |
| F6 | "Own the roadmap for the partner-facing API platform" (JD responsibility; dossier R1 sub-claim) | none given | none | [grounded] | capability | Acknowledge, do not bridge. Words, sourced by the dossier's acknowledge_gap area (uncertain_or_weak_areas) and prohibited_claims: "I haven't owned a product roadmap," and "I haven't set prioritization for an engineering squad." Then the ramp, as a plan and never as a past. |
| F7 | "Define and track adoption metrics" (JD responsibility) | none given | none | [grounded] | discovery | No quote speaks to adoption. Answer slot: if you measured adoption of anything, name it and how it was counted; if you did not, say so and say what you would measure first. |

## Prohibited list

Claims this pack will not coach, built from the dossier's prohibited_claims and from the fit snapshot.

| Not coached | Basis | Honest form |
|---|---|---|
| Held a product manager title or role | Sourced: dossier prohibited_claims | Plain acknowledgment: "I haven't held the product manager title or role." No slot. |
| Owned a product roadmap | Sourced: dossier prohibited_claims and uncertain_or_weak_areas (acknowledge_gap) | Plain acknowledgment: "I haven't owned a product roadmap." No slot. |
| Set prioritization for an engineering squad | Sourced: dossier prohibited_claims | Plain acknowledgment: "I haven't set prioritization for an engineering squad." No slot. |
| Shipped a platform product | Inflated form of E1: "shipped" stretches "led integrations" | E1 at its own scope. The limit is the pack's observation; A4's slot stays inside the integrations. |
| Owned the partner-facing API roadmap | Inflated form of E3: "roadmap-input sessions" stretched to ownership | E3 at its scope: sessions that fed client evidence to product. |
| A number of years of integration leadership | A length of time in the dossier's decision summary, not in any verified entry | No number of years. A2 answers from E1 and E3 only. |

## Question banks

Personas in weight order. Depth follows weight: the top-weight personas get 4–5 questions, mid-weight 3, low-weight 2.

### A. The Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You have never held the PM title or owned a roadmap — why should we hire you into one instead of a PM with three years of the actual job?" | JD | [grounded] The question is the dossier's likely_interviewer_objections item, as written; its negatives are the prohibited_claims items "Having held a product manager title or role" and "Having owned a product roadmap". Bridge: "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | **Highest-ROI prep in this pack.** Open with the two negatives in these words: "I haven't held the product manager title or role, and I haven't owned a product roadmap." Then the bridge in quoted words: "I led 30+ end-to-end client integrations of the vendor's REST APIs, scoping through go-live," and "I ran quarterly roadmap-input sessions feeding client evidence to product." Name the limit yourself: this is adjacent to roadmap ownership, not the same thing. Answer slot: if in those sessions you ever argued for a priority that changed what product did, say what and your part; if no priority changed, or it was not yours to argue, say so and stay with the sessions. Hold through two follow-ups by returning to the integrations. Concede the roadmap specifically: "I haven't set a roadmap's priorities, and the first months are where I'd want to learn how the squad leads decide." Close the ramp as a plan, not a past: what you would learn in the first weeks, and from whom. | The underwriter named this as the likeliest objection. R1 is a must-have, and F1 is the transferability gap it presses on. The question's negatives are sourced, so the question may be asked as written. JD, because it scores R1 directly. |
| A2 | "The role asks for 3+ years of product management experience. Where does your experience meet that line?" | JD | [grounded] "3+ years product management experience" (JD, role_profile R1); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Say where the work touches the line: the integrations, in E1's words. Do not total any number of years. Answer slot: if any of your years touched product decisions, say which and your part; if none did, say so, and say which of the integration work is nearest to them. | F1 is the transferability gap. The answer must not produce a year count the material never gives. JD, because R1 is the stated line. |
| A3 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Agile delivery experience" (JD, role_profile R5); "Own the roadmap for the partner-facing API platform" (JD responsibility, F6) | Name the roadmap gap plainly first: "I haven't owned a product roadmap" (F6). On agile delivery, clarify before you claim: ask what agile delivery looks like on these two squads. Answer slot: if you ran delivery on a sprint or similar cadence, say how; if you never worked that way, say so and say what you would want to confirm. | A persona stem for the Skeptic. The R5 gap has the clarify strategy, and F6's acknowledgment is the honest first answer. JD, because it scores the role's own gaps. |
| A4 | "You led integrations of the vendor's APIs. Have you shipped an API or platform product yourself?" | JD | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Answer from E1 at its scope: "I led client integrations of the vendor's REST APIs, from scoping to go-live." Answer slot: if you shipped a product or platform component yourself, say what and your part; if you did not, say so, and say what the integration work did carry. Do not describe the integrations as a shipped product. | F2 is the must-have "Shipped API or platform products", met only by adjacent work. The question is a yes-or-no probe with no premise about your history. JD, because R2 is a must-have. |
| A5 | "How do you handle stakeholders across engineering, sales and customers?" | JD | [grounded] "Stakeholder management across engineering, sales, customers" (JD, role_profile R4); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Start with the client and product work in E1 and E3, in their words. Answer slot: if you worked directly with engineering or sales on that work, say how; if you worked through clients or product, say that and stop there. Do not claim engineering or sales stakeholder work the material does not carry. | F4 is transferable: clients and product are carried, engineering and sales are not. R4 is important, and this question scores it. JD. |

### B. The Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "A partner's integration works, but their adoption has dropped since go-live. Walk me through how you'd diagnose it." | CASE | [generic] | Clarify first: what counts as adoption for this partner, and what changed at go-live. Then segment: which partners, which endpoints. Check the integration against the docs, then talk to the partner. Name the metric you would check first and what would change your mind. Speakable in 90 seconds. No past case is cited; this question asks for none. | A live problem from the role's partner discovery and adoption responsibilities. It makes no claim about your past. CASE, because the bar is structure. |
| B2 | "Two engineering squads disagree about what the partner platform builds next, and the roadmap has to settle it. What do you do?" | CASE | [generic] | Clarify whose decision it is before deciding anything: ask each squad lead which decisions belong to them. Then lay the options against partner evidence and adoption, name the decision owner and the tie-break, and say what you would not decide alone. | This is the decision-authority question the dossier asks you to verify in the room. The answer should show you ask rather than assume. CASE. |
| B3 | "What would you do in your first 30 days in this role?" | CASE | [generic] | A plan, not a past. Learn the roadmap, the two squads and the partner adoption numbers before proposing changes. Name the people you would meet first and the decisions you would want to see made. | A ramp plan for the acknowledged roadmap gap (F6). The question presupposes nothing about your history. CASE. |
| B4 | "A partner says the API docs and the schema disagree. How do you triage it?" | CASE | [generic] | Reproduce the disagreement with one concrete request first. Decide which artifact is the source of truth, then route the fix: docs, schema or service. Say what you would need from engineering, and what you would not sign off without. | Covers R3 as a live problem, which needs no claim about your past. CASE. |

### C. The Data-Driven Prober (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Walk me through how the 30+ integrations were counted." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Say the count in E1's words. Answer slots: how the count was made, in your own words, and what "end-to-end" meant in it; the assumption behind the number you would defend least; and which integrations you led and which you did not. If you cannot say how it was counted, say that. | Defend-the-number slots for the one figure in the material. The pack supplies no counting method, baseline or assumption. EXP, because it tests attribution. |
| C2 | "How much of the playbook did you write yourself?" | EXP | [grounded] "Wrote the internal integration playbook" (dossier E2) | Answer from E2: "I wrote" the playbook, in your own words. Answer slot: if others changed or added to it, say how; if you wrote all of it, say so. | The playbook is the high-confidence, inspectable item, so the attribution probe comes here. EXP. |
| C3 | "Did you measure adoption of anything those sessions fed?" | JD | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3); "Define and track adoption metrics" (JD responsibility, F7) | Answer slot: if you measured adoption of anything, name it and how it was counted; if you did not, say so and say what you would measure first. Never describe a metric you did not track. | F7 is the opportunity risk: adoption is a stated responsibility with no baseline, and the material is silent on it. The question is yes or no. JD, because the responsibility is stated. |
| C4 | "Did the evidence from those sessions ever change a product decision?" | EXP | [grounded] "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | Answer slot: if you can name a decision it changed, say which and your part; if you cannot, say you fed evidence in and did not track what it changed. Volunteer the limit first: say what you can show and what you cannot. | E3 is the medium-confidence claim, and a probe is expected. The honest branch is the one the material supports. EXP. |

### D. The Conversational / Rapport Builder (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "So — walk me through the journey." | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1); "Wrote the internal integration playbook" (dossier E2); "Ran quarterly roadmap-input sessions feeding client evidence to product" (dossier E3) | A 90-second arc, in this order: the integrations (E1), the playbook (E2), the roadmap-input sessions (E3), then the role. Answer slot for the last beat: say what drew you to this role, in your own words; the material does not say. Keep the title out of the arc; if it is raised, use the acknowledgment from F1. | Casual in register, still scored. The arc uses three quotes in order, and it is the opening most likely to set the round's tone. EXP. |
| D2 | "How do you work with API docs and schemas?" | JD | [grounded] "Technical fluency: API docs, schemas" (JD, role_profile R3) | Answer slot only: if you have written, reviewed or changed API docs or schemas, say which and your part; if not, say so and say what you would check first. Do not name a tool or format the material does not name. | R3 is important, and no verified entry speaks to docs or schemas, so the answer is the slot. JD, because the requirement is stated. |
| D3 | "What drew you to this role?" | EXP | [generic] | Selection scaffold, not a story: pick the thing about the partner-facing platform that you can speak to from your own experience, and say why it matters to you. If nothing in your work points there, say that plainly and say what you would want to learn. | The motivation probe comes in every round, and no quote carries a reason, so the answer is yours to write. EXP. |

### E. The Pressure / Stress Interviewer (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "Sixty seconds: why should we take a chance on you over someone with three years in the job?" | JD | [grounded] "3+ years product management experience" (JD, role_profile R1); "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Pause, then restate the question in your own words. Hold: "I haven't held the title or owned the roadmap. What I bring is the integration work, and the input I've fed into product." Hold through two follow-ups by returning to the integrations. Concede the named gap: "I'd expect the first months to be the roadmap part." Finish inside 60 seconds. | The time-boxed version of A1. Hold-then-concede: the concession names the acknowledged gap and nothing else. JD. |
| E2 | "That integration result — how much of it was actually you?" | EXP | [grounded] "Led 30+ end-to-end client integrations of the vendor's REST APIs — scoping, requirements, architecture, UAT, go-live" (dossier E1) | Hold "led" through two follow-ups: say what leading meant, in your own words. Answer slot: if others carried parts of a given integration, say which parts and what you led. Concede only what is actually uncertain, such as the count: "I'd want to check the count before I put a figure on my share." Do not fold on what you led. | A pressure probe on the attribution of the one figure. Hold-then-concede, with the concession limited to the real uncertainty. EXP. |

### Requirement coverage

| Requirement or responsibility | Question IDs |
|---|---|
| R1, 3+ years product management (must) | A1, A2, E1 |
| R2, shipped API or platform products (must) | A4 |
| R3, technical fluency with API docs and schemas (important) | B4, D2 |
| R4, stakeholder management across engineering, sales, customers (important) | A5 |
| R5, agile delivery experience (preferred) | A3 |
| Own the roadmap for the partner-facing API platform | A1, A3, B2 |
| Run discovery with integration partners | B1 |
| Write specs and drive delivery with two engineering squads | B2 |
| Define and track adoption metrics | C3 |

## Persona table

| Persona | How it shows up | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| Skeptic (5) | Probes the title and the roadmap gap, one question at a time | High. The hiring-manager prior, plus R1 as a must-have and F1 as a transferability gap. A1 is the underwriter's own objection. | Two sourced negatives first, the quoted bridge, then the ramp as a plan. |
| Case / Strategist (4) | Live problems on the partner platform: diagnosis, squad disagreement, the first month | High. The hiring-manager prior, and the role decides across squads. | Clarify before structuring; say whose call it is. |
| Data-Driven Prober (4) | "How was 30+ counted?"; what adoption did you track? | Medium-high. Adoption is a stated responsibility with no baseline, and E1 and E3 carry a figure and a medium-confidence claim. | Say what you can and cannot show; volunteer the limit. |
| Conversational (3) | The open "journey" question; the why-this-role question | Medium. Casual register, still scored. | The 90-second arc; the why-this-role answer is yours to write. |
| Pressure (2) | The time-boxed "why you, not someone with three years" | Low to medium. Not a relationship prior for a hiring manager, but the 60-second objection may come in some form. | Pause, restate, hold twice, concede the named gap. |

No peer, skip-level or values persona is weighted: the material names no peer round and no values round. With no interviewer profile and one session, there are no interviewer or loop adjustments to the priors.

## Reverse questions

| # | Question | Why it lands |
|---|---|---|
| R1 | "Which roadmap decisions does this role make alone, and which belong to the two squad leads?" | Tests the decision-authority claim the JD makes without evidence; the answer tells you whether the role is what it says. |
| R2 | "How is partner API adoption measured today, and what is the current baseline?" | Adoption is named as a responsibility with no baseline stated, so the answer shows whether the number exists yet. |
| R3 | "What would a strong first 90 days look like for this role?" | Surfaces what they expect from a hire without a PM title, and lets you test the ramp plan against it. |
| R4 | "How should discovery with integration partners be split between this role and the squads?" | Pins the seam the JD names in "Run discovery with integration partners" before you accept it. |
| R5 | "What has made this role hard to fill or hard to start?" | Surfaces the real risk behind the posting, which is the thing you need to know before accepting. |
| R6 | "How will you know in six months that a hire into this role has worked?" | Shows what success means to them, and gives you the measure to hold yourself to. |

## Sources

- **Provided:** the pasted tuesday-dossier.md, version 1.1, dated 2026-08-14. Consumed sections: handoff_to_mock_interview (verified evidence E1–E3, numbered in the order the dossier lists them; the weak areas; the likely objection; the risks; the employer questions; the prohibited claims), role_profile (requirements R1–R5 and responsibilities, quoted as the JD's lines), and decision (context only). Absent from the dossier: evidence_map, risk_register and evidence_state, so there are no rejected inferences.
- **Sections dropped by their conditions:** interviewer read (no profile), values cheat sheet (no values round detected), graded deliverables (none declared), grounding brief (no strategy research), delivery coaching (no assessment).
- **Searches and fetches:** one search, "Quartzline partner API platform product strategy", refused (search permission was not granted in this session). No fetches.

**Research tier:** L1 — searches 0 of 6 (1 attempted, refused), fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Quartzline values | unavailable | The values cheat sheet, which is dropped because no values round is detected. No call was sent; search is unavailable in this session. |
| 2. Quartzline interview process, product manager | unavailable | Loop structure and persona weights. No call was sent; search is unavailable in this session. |
| 3. Quartzline strategy / recent news | unavailable | The CO bank and a grounding brief. The one query sent was refused. |
| 4. Interviewer name and company | n/a | No interviewer name was given. |
| 5. Representative product manager JD | skipped | The supplied JD (dossier role_profile) fixes the fit snapshot and the JD-tagged questions. |

## Upgrade menu

- The interviewer's name → a reverse question tied to their own career path, and persona weights from their public footprint. Without a name, the reverse questions are role-generic.
- Search permission, or the posting's full text → the company's current strategy and loop structure: a CO question, and per-round weights. Without it, the case questions are generic.
- Notes or records of the roadmap-input sessions, or the product decisions they fed → would move C4 and E3 from medium confidence toward inspectable proof.
- A document or schema you wrote or reviewed → turns the D2 and B4 slots into stories.
- Adoption figures you tracked, or the baseline the team uses → turns C3 and F7 from slots into stories.
