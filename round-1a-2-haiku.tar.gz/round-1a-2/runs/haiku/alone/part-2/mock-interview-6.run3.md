Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-6-denied-2ed21e23/34702eac-bc69-46dd-ab63-58f3ec8b92cf/scratchpad/larkfield_engineering-manager_interview_pack.md`. It has one shared fit snapshot and a mini-pack for each round. Web search was refused in this session, so the pack has no company research. Its values and loop claims come only from your message and the recruiter's words. Round 3's values cheat sheet is dropped for that reason.

The highest-ROI prep is A2. Round 1 will almost certainly ask where you're weakest, and the honest answer is two gaps: you've never managed managers, and you've never owned a hardware-adjacent roadmap. Rehearse both aloud, each with a plan for how you'd close it.

Two offers, neither pushed:
- Say the word and I'll play the Skeptic on A2 in a live drill.
- I can save a `tuesday-dossier.md` recording the gaps this prep exposed, to carry into later sessions.

If you'd like the pack as a Word document, say so and I'll convert it.

Two questions would reshape it:
1. Can you paste the full posting? Right now the requirements are your own role summary, so the fit rows would become posting quotes.
2. Does the role state any location, on-site pattern or work-authorization requirement? The pack has no gate rows yet.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: larkfield_engineering-manager_interview_pack.md -----
# Larkfield Systems, Engineering Manager: loop prep pack (three rounds)

Role: Engineering Manager, Larkfield Systems (industrial IoT, about 600 people).
Interviewers: Round 1 hiring manager, Director of Engineering (name not given). Round 2 panel, two staff engineers and a product manager (names not given). Round 3 VP Engineering (name not given).
Changes in this version: first build, no prior version.

## How to use + type key

Personas describe how a question is asked. Types describe what is being scored.

- **VAL**: behavioral / values alignment. Whether past behavior shows the values.
- **EXP**: work-experience deep-dive. Whether your claims hold up under scrutiny.
- **JD**: role-driven. Can you do the listed job, including its gaps.
- **CO**: company and strategy knowledge. Not covered here, because no research ran (see Sources).
- **CASE**: live problem from the role, reasoned aloud.

Guidance is scaffolding, not a script. Say it in your own words. Where a cell says "answer slot", the answer is yours to give, and either honest branch is a valid answer.

## Prep triage

Prep time was not stated, so this is an order, not a schedule.

1. **A6 (Round 1, the Skeptic on the two gaps).** This is the highest-ROI rehearsal. Round 1 will almost certainly ask where you are weakest, and the honest answer has two parts: you have not managed managers, and you have not owned a hardware-adjacent roadmap. Rehearse saying both plainly, then a plan for each, until it is boring.
2. **A2 and A3 (Round 1, the two-squads and scope questions).** You have led one team of six. The role is two squads and eleven engineers. Rehearse the shape change.
3. **B1 and B3 (Round 2, the hardware seam and the technical probe).** Round 2 includes a staff engineer who may ask what the reliability quarter actually changed in the system. Your material does not show that, so the answer is an answer slot.
4. **C1 and C3 (Round 3, the pressure story and the leading-leaders question).** The VP round is the values round. C3 asks you to say the manager-of-managers gap aloud to the most senior person in the loop.
5. **The 60% figure (A5, B2).** Know how it was counted and which part was yours.

Everything else is insurance.

## Fit snapshot

Requirements come from the role description in your message. No full posting was supplied, so the requirements are the role description's own words. Evidence is quoted from your message. Confidence, provenance and gap type each hold one token.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Lead two squads building device-management services" (your message) | "3 as a team lead of 6" (your message) | medium | [grounded] | transferability | Your material says one team of six, not two squads. Words: "I led a team of six for three years." Answer slot: if you have set direction for two groups at once, say how and what you decided; if you have not, say so and say how you would divide ownership between the two squads. |
| F2 | "own delivery, hiring and growth for 11 engineers" (your message), hiring part | "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | medium | [grounded] | none | No gap on hiring. Lead with the loop in your own terms: you run the hiring loop for backend roles, about 40 interviews last year. Expect a probe on whether the bar would change for hardware-adjacent roles; that is a question, not a gap. |
| F3 | "own delivery, hiring and growth for 11 engineers" (your message), delivery part | "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | medium | [grounded] | presentation | The quote already reaches delivery in other terms. Words: "I pushed a reliability quarter through against roadmap pressure." Do not add a timeline or a plan you did not state. The 60% figure raises the defend-the-number slots (A5). |
| F4 | "own delivery, hiring and growth for 11 engineers" (your message), growth part | none given | none | [grounded] | discovery | Your material is silent on growth: no line on development, promotion or career conversations. Answer slot: if you have grown engineers, say how and what happened to them; if you have not, say so and say how you would start with eleven. |
| F5 | "partner with hardware and product on roadmap" (your message), hardware part | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | A gap you stated. Words: "I haven't owned a hardware-adjacent roadmap." Then how you would learn it, said as a plan and never as a past. |
| F6 | "partner with hardware and product on roadmap" (your message), product part | "pushed a reliability quarter through against roadmap pressure" (your message) | low | [inferred] | transferability | The quote shows you facing roadmap pressure, not partnering on a roadmap. The bridge is this pack's derivation, not your claim. Answer slot: if you have worked jointly with product on what got built, say how; if the pressure came from a decision made without you, say that. |
| F7 | Lead of leads, a role-family requirement, unquoted (generic) | "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | none | [grounded] | capability | A gap you stated. Words: "I've never managed managers." Then how you would learn it. The role text does not state this requirement, so the pack does not treat it as a stated requirement. |

Gate rows: the material says nothing about location, on-site pattern or work authorization. The one question in the closing asks about these.

## Prohibited claims

Built locally from the fit snapshot. Claims the candidate reaches for under pressure. No claim below is coached in any cell.

| Not coached | Basis | Honest form |
|---|---|---|
| Led two squads, or led eleven engineers | Inflated form of F1 | "I led a team of six for three years." The limit is this pack's own observation: your material says one team, not two squads. |
| Owned a hardware roadmap | Negative you stated, F5 | "I haven't owned a hardware-adjacent roadmap." No slot. |
| Managed managers | Negative you stated, F7 | "I've never managed managers." No slot. |
| Drove the 60% on-call drop alone | Inflated form of the reliability quarter, F3 | "After I pushed a reliability quarter through against roadmap pressure, the on-call burden dropped 60%." Say what was yours and what was the team's, in your words. |

## Persona table, with reasoning

Relationship priors from the round, adjusted by the loop. No public interviewer profile was supplied, so no interviewer signals apply. Panel members are not named, so personas are assigned by round.

| Round | Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|---|
| 1 Director | Skeptic | Probes gaps directly: scope, squads, managing managers | High. A hiring manager is buying capability and derisking the gaps in F1, F5, F7 | Rehearse the gaps until plain. Concede without folding on the team-lead record. |
| 1 Director | Case / Strategist | Live problem from the role: two squads, a hardware dependency | High. The role text is the case | Clarify first, then structure. Ask about the squads before answering. |
| 1 Director | Data-Driven Prober | Asks how the 60% was counted | Medium. A closer read of the CV raises the number | Name the weakest assumption before they do. Say plainly what you do not know. |
| 2 Panel (staff) | Peer Evaluator | Seam between squads and hardware; credit; disagreement | High. Staff engineers price what a hire costs their work | Propose seam principles. Do not invent a seam you have not run. |
| 2 Panel (staff) | Data-Driven Prober | Asks what the reliability quarter changed technically | Medium to high. Staff-level probes go into the system | The answer is a slot: say what you know changed, and what you do not. |
| 2 Panel (PM) | Case / Strategist | Roadmap trade-off with a hardware slip | High. The PM owns roadmap partnership | Clarify the dependency first. Say what you would tell product. |
| 2 Panel (PM) | Conversational | Friendly journey question that is scored | Medium | Pre-rehearse a 90-second arc from quoted sentences only. |
| 3 VP | Values / Behavioral | Scenario probes against values and leadership philosophy | High. The recruiter's words name the round | Map stories where a quote carries one. Otherwise a selection scaffold and its honest branch. |
| 3 VP | Pressure | Holds a position; asks why you should lead leaders | High. The VP is the final check on F7 | Hold the position through two follow-ups. Concede the gap plainly. |

Loop detection: your message and the recruiter's words name the three rounds, so the loop is established by a loop source. Round 3 is values-style because the recruiter's words name a values and leadership round.

## Mini-pack: Round 1, hiring manager (Director), 45 min

Persona weights: Skeptic 4, Case 4, Prober 3.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two squads, eleven engineers. Where would you start in the first month?" | CASE | [grounded] "Lead two squads building device-management services" (your message) | Clarify before structuring: ask what each squad owns, where delivery is slipping and who owns the hardware dependencies. Then say how you would sequence it. No past claim is made. | The role text is the case. CASE because it is a live problem; no claim about your past. |
| A2 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "I've never managed managers and never owned a hardware-adjacent roadmap." (your message) | Say both gaps in your own words: "I haven't owned a hardware-adjacent roadmap," and "I've never managed managers." Then the plan for each: how you would learn it and who you would lean on. | F5 and F7 are the two gaps the role most presses. This is the highest-ROI rehearsal. |
| A3 | "You've led six people. Two squads is eleven. What changes?" | EXP | [grounded] "3 as a team lead of 6" (your message) | "I led a team of six for three years." Then the shape change, in your words. Answer slot: if you have split ownership across two groups, say how and what you decided; if you have not, say so and say how you would divide the work. | F1, transferability. The premise is the role's two squads, which the quote does not carry; the slot allows that you have not done it. |
| A4 | "A device firmware update fails on five percent of units. What is your first hour?" | CASE | [generic] | Clarify the rollout, the failure mode and whether the hardware team is involved. Say what you would hold and what you would tell product. | Partner with hardware; a pattern, not a claim about your past. |
| A5 | "Walk me through how that 60 percent on-call figure was counted." | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Say what was counted, over what period, and the assumption you would defend least. Say which part was yours and which was the team's. Answer slot: if you cannot say how it was counted, say so plainly. | F3, defend-the-number. A figure you gave raises these slots and no others. |
| A6 | "What would you need to know about how this team hires before you change its bar?" | JD | [grounded] "I run our hiring loop for backend roles — about 40 interviews last year." (your message) | "I run our hiring loop for backend roles, about 40 interviews last year." Then ask what the bar is for hardware-adjacent roles. Do not claim you have set a bar for another discipline. | F2, none. The question checks the hiring requirement against your actual experience. |
| A7 | "Roadmap pressure from hardware and product will hit both squads. How do you say no?" | JD | [grounded] "I pushed a reliability quarter through against roadmap pressure." (your message) | Hold the position: say what you pushed back on and why. Concede where it cost something. Answer slot: if you did not push back in that case, say so and say what you would do. | F3 and F6. Hold through two follow-ups before any concession. |

Round 1 reverse questions, each with why it lands:
- "What would make this role succeed in year one?" It asks the Director to name the bar, which you can then aim at.
- "How do the two squads split the hardware dependencies today?" It shows you have read the role's hardware line and invites the Director to show the real seam.
- "What did the last person in this role get right, and what did they miss?" It shows you value the work already done, without criticizing it.
- "What do you need from this hire in the first ninety days?" It converts the interview into planning.
- "Which decision would you want me to own without checking with you?" It tests the autonomy the role actually grants.

## Mini-pack: Round 2, panel (two staff engineers and a PM), 60 min

Persona weights: Peer Evaluator 4, Data-Driven Prober 3, Case 3, Conversational 2.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Where's the seam between your squads and the hardware team, and what happens when you disagree?" | JD | [grounded] "partner with hardware and product on roadmap" (your message) | Propose seam principles, not a seam you have run: who decides, how disputes escalate, what each side needs. Say plainly that you have not owned a hardware-adjacent roadmap, and that you would learn the seam before drawing it. | F5 and F6. Peer Evaluator: they are pricing the disagreement, not the seam. |
| B2 | "What did the reliability quarter actually change in the system?" | EXP | [grounded] "I pushed a reliability quarter through against roadmap pressure." (your message) | Say what you know changed and what you do not. Answer slot: if you can name the technical change and your part in it, say so; if the change was the team's, or you do not know it in detail, say so and say what you would check. | F3, technical probe. The question presumes a system change your quote does not carry, so the answer allows that there was none you can describe. |
| B3 | "Which assumption behind the 60 percent would you defend least?" | EXP | [grounded] "My team's on-call burden dropped 60% after I pushed a reliability quarter through against roadmap pressure." (your message) | Name the weakest assumption before they do: the period, the definition of on-call, the team's size. Say what you do not know. | F3, defend-the-number. The weakest-assumption move converts a probe into credibility. |
| B4 | "How do you handle credit when a reliability win spans teams?" | VAL | [generic] | Name who did what, in your own terms, and what you took and what you gave away. Do not claim credit for work you did not do. | A persona stem. The question is open, so guidance makes no claim about your past. |
| B5 | "Tell me about a time you traded a roadmap item for stability." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure." (your message) | Story map from the quote: the roadmap pressure, the reliability quarter, what you pushed through. Answer slot: if the trade was not yours to make, say so and say what you did do. | An open prompt that the quote can answer. The theme comes from the role's roadmap line. |
| B6 | "How would you grow engineers you haven't met yet?" | JD | none given | Answer slot: if you have grown engineers, say how and what happened to them; if you have not, say so and say how you would start with eleven. | F4, discovery. The material is silent on growth, so the words are an answer slot, not a claim. |
| B7 | "So, walk me through the journey." | VAL | [grounded] "9 years engineering, 3 as a team lead of 6, currently at a payments company." (your message) | A 90-second arc from quoted sentences only: nine years, three as a team lead, the payments company, the hiring loop, the reliability quarter. | Conversational register, scored. Pre-rehearse the arc. |

Round 2 reverse questions, each with why it lands:
- "What would a new person do in their first month that would genuinely help your team?" It is the reciprocity question for a peer panel; it shows you are thinking about what you bring.
- "Where do you disagree with product most often?" It invites a seam conversation and shows you care about the tension.
- "What is the hardest technical decision the team has made this year?" It draws out the staff engineers' view of the work.
- "What would you want the next EM to change?" It asks for the honest critique.
- "How does the team decide what to stop doing?" It probes the roadmap and delivery culture.

## Mini-pack: Round 3, VP Engineering, values and leadership philosophy, 30 min

Persona weights: Values / Behavioral 5, Pressure 3, Case / Strategist 2.

Values cheat sheet: dropped. Round 3 is values-style, but no published Larkfield values were in hand (see Sources), so there is no value list to map. Paste the company's values page and this section can be built.

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [grounded] "I pushed a reliability quarter through against roadmap pressure." (your message) | Story map from the quote: the roadmap pressure, the reliability quarter, the moment you did not fold. Answer slot: if the truth did not land, say so and say what followed. | Open prompt. The reliability quarter is the nearest quoted story. |
| C2 | "What is your leadership philosophy in one sentence, and where has it failed?" | VAL | none given | Answer slot: give your own sentence; if it has not been tested on managers, say so. | An open prompt about your philosophy. The material does not carry one, so the guidance does not supply one. |
| C3 | "Why should we trust you to lead leaders when you haven't?" | VAL | [grounded] "I've never managed managers." (your message) | "I've never managed managers." Then the plan: how you would learn it, who you would ask to coach you, and what you would watch first. Hold through two follow-ups. | F7, pressure. The VP is the final check on the gap, so this is the hold-then-concede question. |
| C4 | "When did you put a customer ahead of an internal metric?" | VAL | none given | Answer slot: if you have a story like this, say it in your own words; if not, say so and give the nearest thing your material carries, which is the reliability quarter, described as an internal priority. | A persona stem. The material has no customer story, so the honest branch is the slot. |
| C5 | "What would you want to be true about device management in two years?" | CASE | [generic] | Name an outcome you could measure and the first thing you would check. No past claim. | Strategy-style question at VP altitude. Generic, not grounded in any company material. |

Round 3 reverse questions, each with why it lands:
- "What does the company mean by its values in a hardware-adjacent team?" It asks the VP to make the values concrete, and it shows you read them.
- "What did you learn from the last leadership change here?" It shows you care about how the organization decides.
- "What would make you regret this hire in year one?" It asks for the honest bar.
- "How do you want engineering to work with hardware leadership?" It invites a philosophy answer and tests the partnership line.
- "What is the one leadership habit you most want this team to keep?" It asks for the VP's own view, which is a values answer.

## Requirement coverage

| Requirement | Covered by |
|---|---|
| Lead two squads building device-management services | A1, A3 |
| Own delivery | A5, B2, B3, F3 |
| Own hiring | A6, B7 |
| Own growth for 11 engineers | B6 |
| Partner with hardware and product on roadmap | A1, A4, A7, B1, B5 |
| Lead of leads (role-family, unquoted) | A2, C3 |

## Sources

Provided documents: the role description in your message, and your background and gaps as stated in the same message.

Research tier: L0, because web search was not permitted in this session. No search returned a result, so nothing below is researched.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Larkfield Systems values | unavailable | Values cheat sheet, section 10. Search query "Larkfield Systems values" refused. |
| 2. Larkfield Systems interview process, engineering manager | unavailable | Loop structure. Query "Larkfield Systems interview process engineering manager" refused. The loop here is established by your message and the recruiter's words, not by research. |
| 3. Larkfield Systems strategy / recent news | unavailable | CO bank and grounding brief. Not sent. |
| 4. Interviewer name and company | n/a | No names were given. |
| 5. Representative engineering manager JD | unavailable | Would have supplied requirement text; the role description in your message is the only requirement source. Not sent. |

Refused: "Larkfield Systems values", "Larkfield Systems interview process engineering manager".

## Upgrade menu

- The full posting text → six requirement quotes become posting quotes, not your role summary, and the fit snapshot's requirements upgrade from role description to posting.
- The company's values page, pasted → the values cheat sheet, and the VP round's value-by-value map.
- The interviewer names → tailored reverse questions and persona weights from their public footprint.
- The recruiter's email about the rounds → confirms the loop structure and any pre-declared deliverable.
- Location, on-site pattern or work authorization, if the posting states one → a fit-snapshot gate row.
- Permission for web search → research on values, loop structure and strategy.
