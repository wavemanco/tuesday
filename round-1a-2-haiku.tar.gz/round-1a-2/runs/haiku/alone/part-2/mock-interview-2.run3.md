Your prep pack is saved as `/var/tmp/tuesday-measure/1a2/runs/haiku/alone/part-2/rooms/case-2-denied-9c5a7f9d/atlas_freight_operations-manager_interview_pack.md`. I built it as a hiring-manager or operations-director round with the finance and HR voices you listed, since your round and interviewer aren't given. I also couldn't search Atlas Freight: the search permission wasn't granted, so the pack has no company values, interview process or strategy.

# Atlas Freight, Operations Manager: interview prep pack

Role: Operations Manager, Atlas Freight. Interviewer: not known. Round and relationship: not known, so persona weights are a generic blend. First version, no changelog.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **EXP** = your past work, checked for what you actually did. **JD** = a stated requirement of the job. **CASE** = a live problem from the role, with no claim about your past. **CO** = company knowledge (none here, because research did not run). **VAL** = published company values (none here, because no values round was detected).
- Guidance is scaffolding, not a script. Aim for 90 to 120 seconds spoken, in your own words.
- An **answer slot** is an instruction for the interview: it tells you what to say if the question goes there. It is not a question to answer here.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows one site's operations, not four terminals. Bridge: "Seven years in warehouse and distribution ops." Answer slot: if you have been accountable for daily operations across more than one site, say how; if not, say so and say how you would run four. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows mis-pick rate, not on-time performance or cost per shipment. Bridge: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked an on-time or cost measure, name it; if you did not, say so. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors on one shift. Bridge: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have directed supervisors across shifts or sites, say how; if not, say so. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | hard_gate | Your material does not establish five years of leadership: the seven years is operations work, and when your leadership began is not in it. Surfaced, not bridged. The gate question is below. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message); "never used Power BI" (your message) | medium | [grounded] | capability | Stated absence: "I haven't used Power BI." Excel is the part your material supports. Your plan for learning Power BI is a plan, not a past. |
| F6 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement. No project is in the material, so expect a probe for one. Bridge: "I'm green belt certified." |

## Persona table

Built as a hiring-manager or operations-director round, with the finance/analytics and HR voices you listed. No loop source was read, so the fallback is a generic archetype, and these weights are a judgment, not a documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live terminal problems: on-time misses, cost drift | High. An operations interviewer buys capability for a four-site job, and the JD is mostly live-problem territory. | Clarify, then structure, then act. Name the first two moves. |
| Skeptic | The 5+ years and 12-supervisor lines | High. These are the JD's two largest gaps, and the material is thinnest exactly there. | Hold to your own quotes, then concede the specific gap. |
| Data-Driven Prober | The 40% mis-pick figure | Medium-high. It is the only performance number in your material, and a finance or analytics voice is the likeliest prober. | Defend the number: how it was counted, what it is sensitive to, what was yours. |
| Pressure | Composure on the 40% and on "why you over a multi-site candidate" | Medium. Depends on the round's tone. | Hold through two follow-ups before conceding anything real. |
| Conversational | Journey question, Excel question | Medium. An HR or first-round voice would open here. | A rehearsed 90-second arc. |
| Peer Evaluator | Seams with finance, credit for shared fixes | Low to medium. Only if a peer is in the loop. | Propose seam principles; reciprocity. |

## Question banks

### Case/Strategist (highest weight, 6 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two of your four terminals are missing on-time targets this month. What do you look at first, and what would you do before Monday?" | CASE | [generic] | Clarify first: which two terminals, what "missing" means, how on-time is defined. Then segment by shift, lane and dock, and name the first two actions. No claim about your past. | The JD's first two lines, put as a live problem. Generic because it is a pattern for the problem, not a fact about this employer. |
| A2 | "Cost per shipment has risen for two quarters. Diagnose it." | CASE | [generic] | Clarify the cost definition. Split it into labour, overtime, rework and volume. Say what you would measure before you change anything. | Covers the cost half of the JD's second line, which no past-facing question reaches. |
| A3 | "You're running three supervisors on a shift. How would you lead twelve across four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Start with the quote. Then describe the cadence you would set for twelve: one standard, a weekly review, a named owner per site. Answer slot: if you have directed supervisors across shifts or sites, say how; if not, say so. | F3 is the evidence for the span requirement, and this is the likeliest place to be pressed on it. |
| A4 | "The role builds reporting in Excel and Power BI. Which would you build first, and how would you start in Power BI?" | JD | [grounded] "solid Excel" (your message); "never used Power BI" (your message) | Lead with Excel in your words. Then the Power BI line: "I haven't used Power BI." Then how you would learn it, as a plan. Never describe a Power BI report you have not built. | F5 is the capability gap. The honest version is the plain statement and a plan. |
| A5 | "Lean and Six Sigma are a plus here. Where would you apply them in your first six months?" | JD | [grounded] "green belt certified" (your message) | Name the certification as held. Then one place you would apply the method, framed as a plan. Answer slot: if you have led a project under the belt, name it and your part; if not, say so. | F6 reaches the requirement. The probe for a project is the one to prepare. |
| A6 | "Where would you look first for cost savings in a terminal?" | JD | [generic] | Structure: cost per shipment split into labour, overtime, rework and throughput. Name what you would measure first and what you would leave alone. | Cost-per-shipment is the JD's second metric; A2 covers diagnosis, this covers where savings come from. |

### Skeptic (highest-ROI prep)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "The role asks for five years of operations leadership and a team of twelve supervisors. Which part of this are you weakest at on day one?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | **Highest-ROI prep in this pack.** Hold, then concede. Open with your two quotes, word for word. Hold through two follow-ups by returning to them. Then concede the gap in your own words and name the first thing you would do to close it. Answer slot: if you can date when your people leadership began, say so; if you cannot, say that plainly. | F4 is a gate your material does not establish, and F3 is the span gap. This is the objection the JD makes most likely. Never claim five years of leadership. |
| S2 | "Lean and Six Sigma are a plus. What have you done with the belt beyond the certification?" | JD | [grounded] "green belt certified" (your message) | Start with the certification as held. Answer slot: if you applied the method to a project, name it and your part; if the certification is the extent of it, say so plainly and say where you would apply it first. | F6's requirement is met on paper, so the probe lands on the project. |

### Data-Driven Prober (finance or analytics voice)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend the number. Name the baseline and the period in your own words. Name the assumption you would defend least, before they ask. Answer slot: if you counted it, say how; if the count was not yours to make, say so plainly. | F2 is the one performance figure in your material, and a prober's first target. Naming the weak assumption converts a gotcha into a credibility point. |
| B2 | "Which of the 40% would you attribute to the pick-path redesign, and what else changed in the same period?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Separate what the redesign did from anything else that changed. Answer slot: if other changes happened, name them and say how you separated them; if you did not separate them, say so. | Attribution is the probe behind the headline figure; B1 covers the count. |
| B3 | "On-time performance and cost per shipment are the headline metrics here. Which did you track, and how?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name what you tracked, in your own words. Answer slot: if on-time performance or cost per shipment was among them, say how; if neither was, say so plainly. Do not extend the mis-pick figure to either. | F2 is a transferability gap; the honest answer is which metric you actually held. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold, then concede. Restate the quote exactly. Hold through two follow-ups. Concede only what is true. Answer slot: if others shaped the redesign, name their part first; if it was yours, say what you did in your own words. | The pressure version of B1. Holding an honest position without folding is what it tests. |
| P2 | "Sixty seconds: why you over someone who has run a multi-site terminal?" | JD | [grounded] "ran the site's peak-season surge plan two years running" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold to your two quotes. Answer slot: if you have run more than one site, say so; if not, say so plainly, then name what you would bring. Do not fold on the peak plan. | F1 and F2 are the honest case; the interviewer is asking you to compare, not to inflate. |

### Conversational (HR or first round)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message); "green belt certified" (your message) | A 90-second arc: where you started (the seven years), where you are (the shift role), one result you can point to (the 40%), the belt, and why this role. Use only those sentences. | Casual questions are still scored. Every clause rests on one of your quotes. |
| K2 | "Tell me about the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Open with the quote. Then the plan's shape, in your words. Answer slot: if the plan's results were counted, say what was counted; if nothing was, say so and say what you would measure next year. | F1's second quote. A story you can tell, with no figure you have not given. |
| K3 | "What are you actually playing with in Excel these days?" | JD | [grounded] "solid Excel" (your message) | Name one workbook or report you built, what it reported, and who used it, in your own words. Answer slot: if you have built nothing you would call reporting, say so and name the nearest thing. | The JD's Excel half, asked casually. |

### Peer Evaluator (only if a peer is in the loop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Q1 | "Our teams sit side by side — where's the seam with finance, and what happens when reporting disagrees?" | CASE | [generic] | Propose seam principles: one agreed definition of on-time and cost per shipment before a report goes out, and one owner for a disputed number. Do not pretend to know their seam; ask one question back. | Reporting is in the JD, and the seam question tests whether you collaborate across the same numbers. |
| Q2 | "How do you handle credit when a fix spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name who else touched the pick path, if anyone did, and what you did. Answer slot: if the redesign was yours alone, say so; if others shaped it, name their part first. | A credit probe lands hardest on your headline result. |

**Coverage.** Each JD requirement, with the questions that cover it:

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, A3, P2 |
| Drive on-time performance and cost-per-shipment down | A1, A2, A6, B3 |
| Lead a team of 12 supervisors | A3, S1 |
| Build reporting in Excel/Power BI | A4, K3 |
| 5+ years operations leadership required | S1 (gate, F4) |
| Lean/Six Sigma a plus | A5, S2 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What do on-time performance and cost per shipment look like across the four sites today, and which site is furthest from target?" | Shows you read the job's metrics as the job. |
| "How is cost per shipment defined here, and who owns that number?" | Shows you want the definition before you make a claim about it. |
| "What reporting exists now, in Excel or Power BI, and who maintains it?" | Tells you how big the Power BI gap is, from their side. |
| "What would make the first six months a clear success for this role?" | Gets the scoring criteria in their words. |
| "How are the twelve supervisors organised across the sites, and what would the role inherit?" | Lands the span question on their structure, not yours. |
| If the person across the table is a peer: "What could a new person do in their first month that would genuinely help your team?" | Reciprocity: turns the seam into a joint problem. |

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer, hold or question in this pack asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1 | "7 years in warehouse and distribution ops", at its own scope. Your material says one site, which is the pack's observation, not words for you. |
| Leads twelve supervisors, or five years of operations leadership | Inflated form of F3 and F4 | "currently a senior shift manager over 3 supervisors". Your material does not establish five years of leadership, which is the pack's observation. |
| Built Power BI reporting | Stated negative, F5 | "I haven't used Power BI." A plain acknowledgment, with no slot. |
| Delivered Lean Six Sigma projects | Inflated form of F6 | "green belt certified", at its own scope. |
| Cut on-time performance or cost per shipment | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path", at its own scope. |

## Sources

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight` values | unavailable | Values cheat sheet. Both searches were refused because search permission was not granted. No values page was read, no values round was detected, and nothing was taken from memory. |
| 2. `Atlas Freight` interview process, operations manager | unavailable | Loop structure. Refused as above. Persona weights therefore rest on the generic archetype, said plainly. |
| 3. `Atlas Freight` strategy / recent news | unavailable | Could have moved the CO bank. No call was sent, because search permission was not granted, so CO questions are absent. |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

Queries sent, all refused:
- "Atlas Freight regional logistics company values": refused.
- "Atlas Freight operations manager interview process": refused.

Provided documents: your message (the JD text, and your background).

## Upgrade menu

- Your round type and who you are meeting → persona weights, and whether the Peer questions and reciprocity question stay in.
- Permission for web search → rows 1 to 3 re-run: the values page, the interview process, and recent strategy, which would add a CO bank.
- The start date of your people leadership → resolves gate F4, and lets S1 carry a dated answer.
- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint.
- The recruiter's prep email → coverage of any deliverable they announced.

---

Want a live rehearsal? I'll play the Skeptic on S1, the highest-ROI prep in the pack, and react to what you actually say.
I can also save a `tuesday-dossier.md` recording the gaps this prep exposed, for you to carry into later sessions.
If you'd like the pack as a Word document, say so and I'll convert it.

Two questions, and they change the pack:
1. Who are you meeting (your future manager, a peer, or HR), and is this a screen, a panel or a final round?
2. When did you first direct other people's work, and does that reach five years? The JD makes five years of operations leadership a requirement, and your material doesn't establish it yet.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas_freight_operations-manager_interview_pack.md -----
# Atlas Freight, Operations Manager: interview prep pack

Role: Operations Manager, Atlas Freight. Interviewer: not known. Round and relationship: not known, so persona weights are a generic blend. First version, no changelog.

## How to use

- **Personas** describe how a question is asked. **Types** describe what is being scored.
- Type key: **EXP** = your past work, checked for what you actually did. **JD** = a stated requirement of the job. **CASE** = a live problem from the role, with no claim about your past. **CO** = company knowledge (none in this pack, because research did not run). **VAL** = published company values (none in this pack, because no values round was detected).
- Guidance is scaffolding, not a script. Aim for 90 to 120 seconds spoken, in your own words.
- An **answer slot** is an instruction for the interview: it tells you what to say if the question goes there. It is not a question to answer here.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "7 years in warehouse and distribution ops" (your message); "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows one site's operations, not four terminals. Bridge: "Seven years in warehouse and distribution ops." Answer slot: if you have been accountable for daily operations across more than one site, say how; if not, say so and say how you would run four. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows mis-pick rate, not on-time performance or cost per shipment. Bridge: "I cut mis-pick rate 40% by redesigning the pick path." Answer slot: if you tracked an on-time or cost measure, name it; if you did not, say so. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Your material shows three supervisors on one shift. Bridge: "I'm currently a senior shift manager over 3 supervisors." Answer slot: if you have directed supervisors across shifts or sites, say how; if not, say so. |
| F4 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | low | [grounded] | hard_gate | Your material does not establish five years of leadership: the seven years is operations work, and when your leadership began is not in it. Surfaced, not bridged. The gate question is in this message. |
| F5 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message); "never used Power BI" (your message) | medium | [grounded] | capability | Stated absence: "I haven't used Power BI." Excel is the part your material supports. Your plan for learning Power BI is a plan, not a past. |
| F6 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | The quote reaches the requirement. No project is in the material, so expect a probe for one. Bridge: "I'm green belt certified." |

Gap type and confidence each hold one token. Provenance on a gap row grades the pack's statement of the gap, not a capability claim.

## Persona table

Built as a hiring-manager or operations-director round, with the finance/analytics and HR voices you listed. Round and relationship are not given. No loop source was read, so the fallback is a generic archetype, and the weights below are a judgment, not a documented process.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy |
|---|---|---|---|
| Case/Strategist | Live terminal problems: on-time misses, cost drift | High. An operations interviewer buys capability for a four-site job, and the JD is mostly live-problem territory. | Clarify, then structure, then act. Name the first two moves. |
| Skeptic | The 5+ years and 12-supervisor lines | High. These are the JD's two largest gaps, and the material is thinnest exactly there. | Hold to your own quotes, then concede the specific gap. |
| Data-Driven Prober | The 40% mis-pick figure | Medium-high. It is the only performance number in your material, and a finance or analytics voice is the likeliest prober. | Defend the number: how it was counted, what it is sensitive to, what was yours. |
| Pressure | Composure on the 40% and on "why you over a multi-site candidate" | Medium. Depends on the round's tone. | Hold through two follow-ups before conceding anything real. |
| Conversational | Journey question, Excel question | Medium. An HR or first-round voice would open here. | A rehearsed 90-second arc. |
| Peer Evaluator | Seams with finance, credit for shared fixes | Low to medium. Only if a peer is in the loop. | Propose seam principles; reciprocity. |

## Question banks

### Case/Strategist (highest weight, 6 questions)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Two of your four terminals are missing on-time targets this month. What do you look at first, and what would you do before Monday?" | CASE | [generic] | Clarify first: which two terminals, what "missing" means, how on-time is defined. Then segment by shift, lane and dock, and name the first two actions. No claim about your past. | The JD's first two lines, put as a live problem. Generic because it is a pattern for the problem, not a fact about this employer. |
| A2 | "Cost per shipment has risen for two quarters. Diagnose it." | CASE | [generic] | Clarify the cost definition. Split it into labour, overtime, rework and volume. Say what you would measure before you change anything. | Covers the cost half of the JD's second line, which no past-facing question reaches. |
| A3 | "You're running three supervisors on a shift. How would you lead twelve across four sites?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Start with the quote. Then describe the cadence you would set for twelve: one standard, a weekly review, a named owner per site. Answer slot: if you have directed supervisors across shifts or sites, say how; if not, say so. | F3 is the evidence for the span requirement, and this is the likeliest place to be pressed on it. |
| A4 | "The role builds reporting in Excel and Power BI. Which would you build first, and how would you start in Power BI?" | JD | [grounded] "solid Excel" (your message); "never used Power BI" (your message) | Lead with Excel in your words. Then the Power BI line: "I haven't used Power BI." Then how you would learn it, as a plan. Never describe a Power BI report you have not built. | F5 is the capability gap. The honest version is the plain statement and a plan. |
| A5 | "Lean and Six Sigma are a plus here. Where would you apply them in your first six months?" | JD | [grounded] "green belt certified" (your message) | Name the certification as held. Then one place you would apply the method, framed as a plan. Answer slot: if you have led a project under the belt, name it and your part; if not, say so. | F6 reaches the requirement. The probe for a project is the one to prepare. |
| A6 | "Where would you look first for cost savings in a terminal?" | JD | [generic] | Structure: cost per shipment split into labour, overtime, rework and throughput. Name what you would measure first and what you would leave alone. | Cost-per-shipment is the JD's second metric, and A2 covers diagnosis; this covers where savings come from. |

### Skeptic (highest-ROI prep)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| S1 | "The role asks for five years of operations leadership and a team of twelve supervisors. Which part of this are you weakest at on day one?" | JD | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message) | **Highest-ROI prep in this pack.** Hold, then concede. Open with your two quotes, word for word. Hold through two follow-ups by returning to them. Then concede the gap in your own words and name the first thing you would do to close it. Answer slot: if you can date when your people leadership began, say so; if you cannot, say that plainly. | F4 is a gate your material does not establish, and F3 is the span gap. This is the objection the JD makes most likely. Never claim five years of leadership. |
| S2 | "Lean and Six Sigma are a plus. What have you done with the belt beyond the certification?" | JD | [grounded] "green belt certified" (your message) | Start with the certification as held. Answer slot: if you applied the method to a project, name it and your part; if the certification is the extent of it, say so plainly and say where you would apply it first. | F6's requirement is met on paper, so the probe lands on the project. |

### Data-Driven Prober (finance or analytics voice)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "Walk me through how the 40% mis-pick reduction was counted." | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Defend the number. Name the baseline and the period in your own words. Name the assumption you would defend least, before they ask. Answer slot: if you counted it, say how; if the count was not yours to make, say so plainly. | F2 is the one performance figure in your material, and a prober's first target. Naming the weak assumption converts a gotcha into a credibility point. |
| B2 | "Which of the 40% would you attribute to the pick-path redesign, and what else changed in the same period?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Separate what the redesign did from anything else that changed. Answer slot: if other changes happened, name them and say how you separated them; if you did not separate them, say so. | Attribution is the probe behind the headline figure; B1 covers the count. |
| B3 | "On-time performance and cost per shipment are the headline metrics here. Which did you track, and how?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name what you tracked, in your own words. Answer slot: if on-time performance or cost per shipment was among them, say how; if neither was, say so plainly. Do not extend the mis-pick figure to either. | F2 is a transferability gap; the honest answer is which metric you actually held. |

### Pressure

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "That 40% — how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold, then concede. Restate the quote exactly. Hold through two follow-ups. Concede only what is true: answer slot, if others shaped the redesign, name their part first; if it was yours, say what you did in your own words. | The pressure version of B1. Holding an honest position without folding is what it tests. |
| P2 | "Sixty seconds: why you over someone who has run a multi-site terminal?" | JD | [grounded] "ran the site's peak-season surge plan two years running" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold to your two quotes. Answer slot: if you have run more than one site, say so; if not, say so plainly, then name what you would bring. Do not fold on the peak plan. | F1 and F2 are the honest case; the interviewer is asking you to compare, not to inflate. |

### Conversational (HR or first round)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| K1 | "So — walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" (your message); "currently a senior shift manager over 3 supervisors" (your message); "cut mis-pick rate 40% by redesigning the pick path" (your message); "green belt certified" (your message) | A 90-second arc: where you started (the seven years), where you are (the shift role), one result you can point to (the 40%), the belt, and why this role. Use only those sentences. | Casual questions are still scored. Every clause rests on one of your quotes. |
| K2 | "Tell me about the peak-season surge plan you ran." | EXP | [grounded] "ran the site's peak-season surge plan two years running" (your message) | Open with the quote. Then the plan's shape, in your words. Answer slot: if the plan's results were counted, say what was counted; if nothing was, say so and say what you would measure next year. | F1's second quote. A story you can tell, with no figure you have not given. |
| K3 | "What are you actually playing with in Excel these days?" | JD | [grounded] "solid Excel" (your message) | Name one workbook or report you built, what it reported, and who used it, in your own words. Answer slot: if you have built nothing you would call reporting, say so and name the nearest thing. | The JD's Excel half, asked casually. |

### Peer Evaluator (only if a peer is in the loop)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| Q1 | "Our teams sit side by side — where's the seam with finance, and what happens when reporting disagrees?" | CASE | [generic] | Propose seam principles: one agreed definition of on-time and cost per shipment before a report goes out, and one owner for a disputed number. Do not pretend to know their seam; ask one question back. | Reporting is in the JD, and the seam question tests whether you collaborate across the same numbers. |
| Q2 | "How do you handle credit when a fix spans teams?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name who else touched the pick path, if anyone did, and what you did. Answer slot: if the redesign was yours alone, say so; if others shaped it, name their part first. | A credit probe lands hardest on your headline result. |

**Coverage.** Each JD requirement, with the questions that cover it:

| JD requirement | Questions |
|---|---|
| Own daily terminal operations across 4 sites | A1, A3, P2 |
| Drive on-time performance and cost-per-shipment down | A1, A2, A6, B3 |
| Lead a team of 12 supervisors | A3, S1 |
| Build reporting in Excel/Power BI | A4, K3 |
| 5+ years operations leadership required | S1 (gate, F4) |
| Lean/Six Sigma a plus | A5, S2 |

## Reverse questions

| Question | Why it lands |
|---|---|
| "What do on-time performance and cost per shipment look like across the four sites today, and which site is furthest from target?" | Shows you read the job's metrics as the job. |
| "How is cost per shipment defined here, and who owns that number?" | Shows you want the definition before you make a claim about it. |
| "What reporting exists now, in Excel or Power BI, and who maintains it?" | Tells you how big the Power BI gap is, from their side. |
| "What would make the first six months a clear success for this role?" | Gets the scoring criteria in their words. |
| "How are the twelve supervisors organised across the sites, and what would the role inherit?" | Lands the span question on their structure, not yours. |
| If the person across the table is a peer: "What could a new person do in their first month that would genuinely help your team?" | Reciprocity: turns the seam into a joint problem. |

## Prohibited claims

Built locally from the fit snapshot. These are the claims a candidate reaches for under pressure. No answer, hold or question in this pack asserts, softens or implies them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran operations across four sites | Inflated form of F1 | "7 years in warehouse and distribution ops", at its own scope. Your material says one site, which is the pack's observation, not words for you. |
| Leads twelve supervisors, or five years of operations leadership | Inflated form of F3 and F4 | "currently a senior shift manager over 3 supervisors". Your material does not establish five years of leadership, which is the pack's observation. |
| Built Power BI reporting | Stated negative, F5 | "I haven't used Power BI." A plain acknowledgment, with no slot. |
| Delivered Lean Six Sigma projects | Inflated form of F6 | "green belt certified", at its own scope. |
| Cut on-time performance or cost per shipment | Inflated form of F2 | "cut mis-pick rate 40% by redesigning the pick path", at its own scope. |

## Sources

Research tier: L1 — searches 2 of 6, fetches 0 of 2; user links read 0.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. `Atlas Freight` values | unavailable | Values cheat sheet. Both searches were refused because search permission was not granted. No values page was read, no values round was detected, and nothing was taken from memory. |
| 2. `Atlas Freight` interview process, operations manager | unavailable | Loop structure. Refused as above. Persona weights therefore rest on the generic archetype, said plainly. |
| 3. `Atlas Freight` strategy / recent news | unavailable | Could have moved the CO bank. No call was sent, because search permission was not granted, so CO questions are absent. |
| 4. `{interviewer name} Atlas Freight` | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | Your JD fixes the fit snapshot and the JD-tagged questions. |

Queries sent, all refused:
- "Atlas Freight regional logistics company values": refused.
- "Atlas Freight operations manager interview process": refused.

Provided documents: your message (the JD text, and your background).

## Upgrade menu

- Your round type and who you are meeting → persona weights, and whether the Peer questions and reciprocity question stay in.
- Permission for web search → rows 1 to 3 re-run: the values page, the interview process, and recent strategy, which would add a CO bank.
- The start date of your people leadership → resolves gate F4, and lets S1 carry a dated answer.
- The interviewer's name → a tailored reverse question, and persona weights read from their public footprint.
- The recruiter's prep email → coverage of any deliverable they announced.
