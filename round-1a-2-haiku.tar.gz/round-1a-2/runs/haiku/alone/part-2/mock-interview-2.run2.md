This matches the interview-prep skill, so I'll load it and build the prep pack from your JD and background.
Your prep pack is saved at `/tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-2-denied-efe01bcf/a2d12d4c-080b-4bbd-afb3-384c3154112f/scratchpad/atlas_freight_operations_manager_interview_pack.md`. I built it for a hiring-manager round, since you didn't say who you're meeting. I had only your JD and background, so it has no company research, no values section and no interviewer read.

# Atlas Freight: Operations Manager interview pack

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not known
**Round:** assumed hiring-manager round
**Research tier:** L0, provided material only

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what it scores: JD (the listed job), EXP (what you did, precisely), CASE (a live problem), VAL (past behaviour).
- Guidance is scaffolding, not a script. Say only what you did, in your own words.
- **Answer slot** lines are instructions for the interview. They are not questions for you to answer here.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows one site's peak-season plan, run two years running. Say it as: "For two years I ran the site's peak-season surge plan." Limit: four sites and daily terminal ownership are not in your material. Answer slot: say which parts of that plan were yours to set, and which were the site's. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows one accuracy result, not on-time performance or cost. Say it as: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: say which measure you moved, and by how much, if any other. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Say it at its own scale: "I lead three supervisors now." Limit: the JD's twelve is a larger team than your material shows. Answer slot: say how you would lead a larger team, as a plan. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [inferred] | discovery | Your material says solid Excel, not what reporting you have built in it. Answer slot: name one report you built in Excel, what it tracked, and who used it. If no one relied on one, say so. |
| F5 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | Your own words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | low | [inferred] | discovery | Your material gives seven years in operations, but not how many of them were spent leading people. Answer slot: state the count you can defend from your own dates, and the scope it covered. Do not round up. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | Covered by the credential. Say: "I'm Green Belt certified." Expect a probe on where you applied it (C2). |

## Prohibited claims

The pack will not coach these, because your material does not support them.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations across four sites | Stretched form of "ran the site's peak-season surge plan two years running" (one site) | That quote at its own scope. A1 stays inside it. |
| Led twelve supervisors | Stretched form of "over 3 supervisors" | "over 3 supervisors" at its own scope. |
| Drove on-time performance and cost-per-shipment down | Stretched form of "cut mis-pick rate 40%" | The mis-pick quote at its own scope. A2 covers this. |
| Built reporting in Power BI | Negative you stated: "never used Power BI" | "I haven't used Power BI." |
| Ran the pick-path redesign as a Lean or Six Sigma project | Joins "green belt certified" to the redesign, which your material does not | The Green Belt quote at its own scope. C2 asks where you applied it. |

## Persona table

Weights start from the hiring-manager prior (Case and Skeptic). No interviewer signal adjusts them, because none is known.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Bank (depth) |
|---|---|---|---|---|
| Skeptic | Presses the scale gap (3 supervisors and 1 site against 12 and 4) and the Power BI gap | Top weight. The JD states both scale numbers | Rehearse A1 until it is plain. Hold the scope you ran. Concede the scale, not the work | A (5) |
| Case / Strategist | Live operations problems: an on-time drop, rising cost, a new site | High. Hiring managers test structure on live problems | Clarify, then segment, then talk to the site before changing its process | B (4) |
| Data-Driven Prober | Asks how figures were counted and what you built in Excel | Medium. The reporting line and your 40% result both invite it | Name the weakest assumption before it is asked | C (3) |
| Pressure / Stress | Time-boxed "why you"; "how much was actually you" | Medium-low. Common in later rounds | Pause, restate, hold once, then concede specifically | D (2) |
| Conversational / Rapport | Open "walk me through" and a casual Power BI question | Low-medium. Casual wording is still scored | A 90-second arc. A plain Power BI line | E (2) |
| Values / Behavioural | STAR-style stories about unpopular truths or process change | Low-medium. No values round was named | Selection scaffolds. Say so where no story comes to mind | F (2) |
| Peer Evaluator | Seam-splitting between teams | Not weighted, since a hiring-manager round is assumed | n/a | none |

## Question banks

### A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've been running three supervisors. This role runs twelve across four sites. What makes you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); "lead a team of 12 supervisors" and "Own daily terminal operations across 4 sites" (JD) | Highest-return rehearsal in this pack. Open with the scope you have run: three supervisors, one site. Then say what carries over, in your own words. Answer slot: if you have led more people or more than one site, say how many and when; if not, say so plainly and say what you would do in the first 90 days. Hold through two follow-ups by returning to the three you led. Concede the scale gap plainly. Do not fold on what the three-supervisor work did show. | F1 and F3 are the scale gap. This is the objection most likely to come up in some form, so it gets the deepest rehearsal. |
| A2 | "The JD asks you to drive on-time performance and cost-per-shipment down. Which of those have you moved, and by how much?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say the one result you have: mis-pick rate, down 40%, by redesigning the pick path. Do not stretch it to on-time or cost. Answer slot: if you moved on-time performance or cost-per-shipment, name the measure and your part of it. If not, say so plainly and name the measure you would start with. | F2 is the gap. The question tests whether you can tell an accuracy result from the two metrics the role names. |
| A3 | "The job says build reporting in Excel or Power BI. Which have you built reports in?" | JD | [grounded] "solid Excel" and "never used Power BI" (your message) | Excel is where you can answer. Answer slot: name a report you built in Excel, what it tracked, and who used it. For Power BI, say the plain line: "I haven't used Power BI." Then your plan to learn it, said as a plan. | F4 and F5. A skeptic will ask about Power BI directly. |
| A4 | "Five years of operations leadership is required. How many years have you led people?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Give the count you can defend from your own dates. Answer slot: if the count is under five, say the number and the scope it covered. Do not round up. | F6. Years of leading people are not in your material. |
| A5 | "Why move from a shift role into an operations manager role now?" | JD | [generic] | Give your own reason in your own words. Answer slot: if the reason is scope, say which scope, in the posting's terms: sites, supervisors, or reporting. | "Why now" is the skeptic's motivation probe. Only you can answer it, so the guidance supplies no reason. |

### B: Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "One site's on-time rate has dropped for three weeks. Walk me through your first 48 hours." | CASE | [generic] | Clarify the measure first (which orders, which cut-off, which shift); segment by shift, lane and dock; talk to that site's supervisors before changing any process; then decide what to change. | A live operations problem from the role. It makes no claim about your past. |
| B2 | "Cost-per-shipment is up across the network this quarter. Where do you look first?" | CASE | [generic] | Start with the definition: what is in the numerator and the denominator. Then split cost by site, by labour and transport, and by volume. Check whether volume fell while fixed cost held. | The JD's cost line, asked as a structure test. |
| B3 | "A new site joins the network next month. What is your first week?" | CASE | [generic] | Learn the site's daily plan, shift handover, supervisor roster and the numbers it already reports. Set one first measure. Do not change a process until you have watched a full shift. | The JD's four-site scope, as a live problem. |
| B4 | "You owe the four site leads one weekly scorecard. What goes on it, and what do you build it in?" | JD | [grounded] "solid Excel" and "never used Power BI" (your message) | Choose the few measures the JD names: on-time performance, cost-per-shipment, mis-picks. Build the first version in Excel. For Power BI, say "I haven't used Power BI," then your plan. Answer slot: name the reports you have built in Excel and who used them. | F4 and F5. It tests reporting judgement without requiring Power BI. |

### C: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Show me the most complicated Excel model or report you've built. Who relied on it?" | EXP | [grounded] "solid Excel" (your message) | Confidence is low: "solid" is a self-rating, not evidence. Name one specific workbook: what it tracked, how often it ran, and who used it. Answer slot: if no one relied on a workbook you built, say so. | F4. This is the Excel test a prober runs. |
| C2 | "Your Green Belt: which project did you apply it to, and what was your part?" | EXP | [grounded] "green belt certified" (your message) | The certificate is the fact. Answer slot: if a project used the method, name the project and your part in it. If not, say so, and say what you would apply it to in this role. | F7. Probers check whether a certificate was used in practice. |
| C3 | "Which assumption behind the 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the weakest assumption before it is asked. Answer slot: say how the 40% was counted: the baseline period, what counted as a mis-pick, and what else changed in the same period. If you cannot say how it was counted, say so. | The 40% invites the prober's question, and the answer must be yours. |

### D: Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already run four sites?" | JD | [generic] | Pause, then restate the question. Hold the one thing you can point to: the mis-pick result, and the surge plan you ran two years running. Concede plainly that they have run four sites and you have run one. Hold once. Do not fold on the mis-pick result. | A stress stem. It tests composure, not content. |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the part you did, in your words. Concede the part the team or the site carried, without folding on your part. Answer slot: say what you did and what others did. | The hold-then-concede structure. |

### E: Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: seven years in warehouse and distribution, the current role over three supervisors, the mis-pick result, the surge plan. | An opener in a casual register is still scored. |
| E2 | "What are you playing with in reporting these days?" | JD | [grounded] "never used Power BI" (your message) | Say the plain line: "I haven't used Power BI." Then what you do in Excel now, and your Power BI plan, said as a plan. | The casual wording tests the JD's Power BI line. |

### F: Values / Behavioural (weight 2; no values round was named)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, a moment you did not fold, and a working relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | Your material carries no such story, so the guidance does not supply one. |
| F2 | "Tell me about a time you changed a process and people pushed back." | VAL | [generic] | Selection scaffold with the same honest branch. The pick-path redesign is the nearest story, but your material does not show pushback, so do not assume it is the answer. | The material does not show the pushback this question asks about. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, B3 |
| Drive on-time performance and cost-per-shipment down | A2, B2 |
| Lead a team of 12 supervisors | A1 |
| Build reporting in Excel/Power BI | A3, B4, C1, E2 |
| 5+ years operations leadership required | A4 |
| Lean/Six Sigma a plus | C2 |

## Reverse questions

1. "What does a strong first 90 days look like in this role?" Why it lands: it shows you are planning around the scope gap, and asks for their expectations.
2. "How is on-time performance measured across the four sites today, and who owns that number?" Why it lands: it tells you whether reporting exists before they ask.
3. "What reporting do the site leads get now, and how much of it is built in Power BI?" Why it lands: it shows how much weight the Power BI line carries.
4. "Which site is furthest behind on cost-per-shipment, and what is the plan there?" Why it lands: it turns the cost line into a conversation about where the work is.
5. "How are the twelve supervisors spread across the four sites, and where is the current team stretched?" Why it lands: it finds the real scale problem.
6. "What would make you say, a year from now, that this was the right hire?" Why it lands: it asks for their success criteria, which you can then meet.

## Sources

- **Provided material:** the JD and your background, both in your message. No search or fetch was run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Would have moved a values cheat sheet. Not run: research has not been agreed yet (question 2). |
| 2. Atlas Freight interview process, operations manager | unavailable | Would have moved the persona weights and loop structure. |
| 3. Atlas Freight strategy and recent news | unavailable | Would have moved the CO questions and a grounding brief. |
| 4. Interviewer name and company | n/a | No interviewer name was given. |
| 5. Representative operations manager JD | skipped | Your pasted JD fixes the fit snapshot and JD questions. |

## Upgrade menu

- The round and who you are meeting → reweights the persona table and every bank
- Atlas Freight's public material (values, recent news), if you say yes to question 2 → a values section and company-grounded CASE and CO questions
- The interviewer's name → a tailored reverse question and persona weights
- Your Green Belt certificate → "green belt certified" moves from medium to high confidence
- A list of the Excel reports you built, with who used them → F4 and C1 gain quotable specifics
- The number of years you have led people → closes F6's gap

---

**Drill:** say the word and I'll play the Skeptic on A1, the scale question, which the pack names as the highest-return prep.
**Dossier:** I can save a `tuesday-dossier.md` recording the scale and Power BI gaps this prep exposed, to carry into later sessions.

Two questions:

1. Who are you meeting, and what round is it: hiring manager, peer, panel, or recruiter screen? The answer reweights every bank.
2. Should I research Atlas Freight's public material (values, recent news, the usual loop for an operations manager role)? It adds a values section and company-grounded questions. Until you answer, the pack stays at what you gave me.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: atlas_freight_operations_manager_interview_pack.md -----
# Atlas Freight: Operations Manager interview pack

**Role:** Operations Manager, Atlas Freight (regional logistics, 800 employees)
**Interviewer:** not known
**Round:** assumed hiring-manager round, since no round was given
**Research tier:** L0, provided material only

## How to use this pack

- **Personas** describe how a question is asked. **Types** describe what it scores: JD (the listed job), EXP (what you did, precisely), CASE (a live problem), VAL (past behaviour), CO (company knowledge, not run at this tier).
- Guidance is scaffolding, not a script. Say only what you did, in your own words.
- **Answer slot** lines are instructions for the interview. They are not questions for you to answer here.

## Fit snapshot

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own daily terminal operations across 4 sites" (JD) | "ran the site's peak-season surge plan two years running" (your message) | medium | [grounded] | transferability | Your material shows one site's peak-season plan, run two years running. Say it as: "For two years I ran the site's peak-season surge plan." Limit: four sites and daily terminal ownership are not in your material. Answer slot: say which parts of that plan were yours to set, and which were the site's. |
| F2 | "drive on-time performance and cost-per-shipment down" (JD) | "cut mis-pick rate 40% by redesigning the pick path" (your message) | medium | [grounded] | transferability | Your material shows one accuracy result, not on-time performance or cost. Say it as: "I cut the mis-pick rate 40% by redesigning the pick path." Answer slot: say which measure you moved, and by how much, if any other. |
| F3 | "lead a team of 12 supervisors" (JD) | "currently a senior shift manager over 3 supervisors" (your message) | medium | [grounded] | transferability | Say it at its own scale: "I lead three supervisors now." Limit: the JD's twelve is a larger team than your material shows. Answer slot: say how you would lead a larger team, as a plan. |
| F4 | "build reporting in Excel/Power BI" (JD) | "solid Excel" (your message) | low | [inferred] | discovery | Your material says solid Excel, not what reporting you have built in it. Answer slot: name one report you built in Excel, what it tracked, and who used it. If no one relied on one, say so. |
| F5 | "build reporting in Excel/Power BI" (JD) | "never used Power BI" (your message) | none | [grounded] | capability | Your own words: "I haven't used Power BI." Then how you would learn it, said as a plan and never as a past. |
| F6 | "5+ years operations leadership required" (JD) | "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | low | [inferred] | discovery | Your material gives seven years in operations, but not how many of them were spent leading people. Answer slot: state the count you can defend from your own dates, and the scope it covered. Do not round up. Length is graded here, not treated as a gate. |
| F7 | "Lean/Six Sigma a plus" (JD) | "green belt certified" (your message) | medium | [grounded] | none | Covered by the credential. Say: "I'm Green Belt certified." Expect a probe on where you applied it (C2). |

**Confidence** grades your evidence. **Provenance** grades what this pack wrote about it. Quoted text is only what you wrote or what the JD says.

## Prohibited claims

These are claims the pack will not coach, because the material does not support them. Your own answers stay within the quotes.

| Not coached | Basis | Honest form |
|---|---|---|
| Ran terminal operations across four sites | Stretched form of "ran the site's peak-season surge plan two years running" (one site) | That quote at its own scope. The material shows one site. A1 stays inside it. |
| Led twelve supervisors | Stretched form of "over 3 supervisors" | "over 3 supervisors" at its own scope. A1 stays inside it. |
| Drove on-time performance and cost-per-shipment down | Stretched form of "cut mis-pick rate 40%" | The mis-pick quote at its own scope. The material shows accuracy, not on-time performance or cost. A2 covers this. |
| Built reporting in Power BI | Negative you stated: "never used Power BI" | "I haven't used Power BI." No claim of Power BI work. |
| Ran the pick-path redesign as a Lean or Six Sigma project | Joins "green belt certified" to the redesign, which the material does not | The Green Belt quote at its own scope. C2 asks where you applied it. |

## Persona table

Weights are a shown judgment. The starting point is the hiring-manager prior (Case and Skeptic). No interviewer signal adjusts it, because none is known.

| Persona | How it shows up | Likelihood, with reasoning | Counter-strategy | Bank (depth) |
|---|---|---|---|---|
| Skeptic | Presses the scale gap (3 supervisors and 1 site against 12 and 4) and the Power BI gap | Top weight. The JD states both scale numbers, and a hiring manager is buying capability against gaps | Rehearse A1 until it is plain. Hold the scope you ran. Concede the scale, not the work | A (5) |
| Case / Strategist | Live operations problems: an on-time drop, rising cost, a new site | High. Hiring managers test structure on the live problems they actually have | Clarify, then segment, then talk to the site before changing its process | B (4) |
| Data-Driven Prober | Asks how figures were counted and what you built in Excel | Medium. The reporting line and your 40% result both invite it | Name the weakest assumption before it is asked. Say plainly what you do not know | C (3) |
| Pressure / Stress | Time-boxed "why you"; "how much was actually you" | Medium-low. Common in later rounds | Pause, restate, hold once, then concede specifically | D (2) |
| Conversational / Rapport | Open "walk me through" and a casual Power BI question | Low-medium. Casual wording is still scored | A 90-second arc. A plain Power BI line | E (2) |
| Values / Behavioural | STAR-style stories about unpopular truths or process change | Low-medium. No values round was named, so this stays at depth 2 | Selection scaffolds. Say so where no story comes to mind | F (2) |
| Peer Evaluator | Seam-splitting between teams | Not weighted, since a hiring-manager round is assumed. Add it if the round turns out to be a peer | n/a | none |

## Question banks

Types: JD, EXP, CASE, VAL. No CO questions appear, because company research did not run.

### A: Skeptic (weight 5)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "You've been running three supervisors. This role runs twelve across four sites. What makes you ready for that?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message); "lead a team of 12 supervisors" and "Own daily terminal operations across 4 sites" (JD) | Highest-return rehearsal in this pack. Open with the scope you have run, in those numbers: three supervisors, one site. Then say what carries over, in your own words. Answer slot: if you have led more people or more than one site, say how many and when; if not, say so plainly and say what you would do in the first 90 days. Hold through two follow-ups by returning to the three you led. Concede the scale gap plainly. Do not fold on what the three-supervisor work did show. | F1 and F3 are the scale gap, and the twelve and four are the JD's own numbers. This is the objection most likely to come up in some form, so it gets the deepest rehearsal. |
| A2 | "The JD asks you to drive on-time performance and cost-per-shipment down. Which of those have you moved, and by how much?" | JD | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Say the one result you have: mis-pick rate, down 40%, by redesigning the pick path. Do not stretch it to on-time or cost. Answer slot: if you moved on-time performance or cost-per-shipment, name the measure and your part of it. If you have not, say so plainly and name the measure you would start with. | F2 is the gap. The question tests whether you can tell an accuracy result from the two metrics the role names. |
| A3 | "The job says build reporting in Excel or Power BI. Which have you built reports in?" | JD | [grounded] "solid Excel" and "never used Power BI" (your message) | Excel is where you can answer. Answer slot: name a report you built in Excel, what it tracked, and who used it. For Power BI, say the plain line: "I haven't used Power BI." Then your plan to learn it, said as a plan. | F4 and F5. A skeptic will ask about Power BI directly, so the plain line needs to be ready. |
| A4 | "Five years of operations leadership is required. How many years have you led people?" | JD | [grounded] "currently a senior shift manager over 3 supervisors" (your message) | Give the count you can defend from your own dates. Answer slot: if the count is under five, say the number and the scope it covered. Do not round up. | F6. Years of leading people are not in your material, and length is graded, not a gate. |
| A5 | "Why move from a shift role into an operations manager role now?" | JD | [generic] | Give your own reason in your own words. Answer slot: if the reason is scope, say which scope, in the posting's own terms: sites, supervisors, or reporting. | "Why now" is the skeptic's motivation probe. Only you can answer it, so the guidance supplies no reason. |

### B: Case / Strategist (weight 4)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| B1 | "One site's on-time rate has dropped for three weeks. Walk me through your first 48 hours." | CASE | [generic] | Speak in this order: clarify the measure first (which orders, which cut-off, which shift); segment by shift, lane and dock; talk to that site's supervisors before changing any process; then decide what to change. | A live operations problem from the role. It makes no claim about your past. |
| B2 | "Cost-per-shipment is up across the network this quarter. Where do you look first?" | CASE | [generic] | Start with the definition: what is in the numerator and the denominator. Then split cost by site, by labour and transport, and by volume. Check whether volume fell while fixed cost held. | The JD's cost line, asked as a structure test. The figures are the interviewer's, not yours. |
| B3 | "A new site joins the network next month. What is your first week?" | CASE | [generic] | Week one: learn the site's daily plan, shift handover, supervisor roster and the numbers it already reports. Set one first measure. Do not change a process until you have watched a full shift. | The JD's four-site scope, as a live problem. It makes no claim about your past. |
| B4 | "You owe the four site leads one weekly scorecard. What goes on it, and what do you build it in?" | JD | [grounded] "solid Excel" and "never used Power BI" (your message) | Choose the few measures the JD names: on-time performance, cost-per-shipment, mis-picks. Build the first version in Excel, the tool you have used. For Power BI, say "I haven't used Power BI," then your plan. Answer slot: name the reports you have built in Excel and who used them. | F4 and F5. It tests reporting judgement without requiring Power BI. |

### C: Data-Driven Prober (weight 3)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Show me the most complicated Excel model or report you've built. Who relied on it?" | EXP | [grounded] "solid Excel" (your message) | Confidence is low: "solid" is a self-rating, not evidence. Name one specific workbook: what it tracked, how often it ran, and who used it. Answer slot: if no one relied on a workbook you built, say so. | F4. This is the Excel test a prober runs. |
| C2 | "Your Green Belt: which project did you apply it to, and what was your part?" | EXP | [grounded] "green belt certified" (your message) | The certificate is the fact. Answer slot: if a project used the method, name the project and your part in it. If you have not applied it to a project, say so, and say what you would apply it to in this role. | F7. Probers check whether a certificate was used in practice. |
| C3 | "Which assumption behind the 40% would you defend least?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Name the weakest assumption before it is asked. Answer slot: say how the 40% was counted: the baseline period, what counted as a mis-pick, and what else changed in the same period. If you cannot say how it was counted, say so. | Defend-the-number rule. The 40% invites the prober's question, and the answer must be yours. |

### D: Pressure / Stress (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| D1 | "Sixty seconds: why you over someone who has already run four sites?" | JD | [generic] | Pause, then restate the question. Hold the one thing you can point to: the mis-pick result, and the surge plan you ran two years running. Concede plainly that they have run four sites and you have run one. Hold once. Do not fold on the mis-pick result. | A stress stem. It tests composure, not content. |
| D2 | "That 40%: how much of it was actually you?" | EXP | [grounded] "cut mis-pick rate 40% by redesigning the pick path" (your message) | Hold the part you did, in your words. Concede the part the team or the site carried, without folding on your part. Answer slot: say what you did and what others did. If the redesign was not yours alone, say so. | The hold-then-concede structure. The quote is the claim you are defending. |

### E: Conversational / Rapport (weight 2)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| E1 | "So, walk me through the journey." | EXP | [grounded] "7 years in warehouse and distribution ops" and "currently a senior shift manager over 3 supervisors" (your message) | A 90-second arc: seven years in warehouse and distribution, the current role over three supervisors, the mis-pick result, the surge plan. Tell it in your own words. | An opener in a casual register is still scored. |
| E2 | "What are you playing with in reporting these days?" | JD | [grounded] "never used Power BI" (your message) | Say the plain line: "I haven't used Power BI." Then what you do in Excel now, and your Power BI plan, said as a plan. | The casual wording tests the JD's Power BI line. |

### F: Values / Behavioural (weight 2; no values round was named)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| F1 | "Tell me about a time you delivered an unpopular truth to leadership." | VAL | [generic] | Selection scaffold: pick a time you told someone senior something they did not want to hear. It needs a named stake, a moment you did not fold, and a working relationship at the end. If none comes to mind, say so plainly, then give the nearest thing your material carries, or how you would handle it. | A standard behavioural probe. Your material carries no such story, so the guidance does not supply one. |
| F2 | "Tell me about a time you changed a process and people pushed back." | VAL | [generic] | Selection scaffold with the same honest branch. The pick-path redesign is the nearest story, but your material does not show pushback, so do not assume it is the answer. | The redesign is the closest story. The material does not show the pushback this question asks about. |

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own daily terminal operations across 4 sites | A1, B3 |
| Drive on-time performance and cost-per-shipment down | A2, B2 |
| Lead a team of 12 supervisors | A1 |
| Build reporting in Excel/Power BI | A3, B4, C1, E2 |
| 5+ years operations leadership required | A4 |
| Lean/Six Sigma a plus | C2 |

## Reverse questions

Each one has a reason it helps you.

1. "What does a strong first 90 days look like in this role?" Why it lands: it shows you are planning around the scope gap, and it asks for their expectations directly.
2. "How is on-time performance measured across the four sites today, and who owns that number?" Why it lands: it tells you whether reporting exists before they ask about it.
3. "What reporting do the site leads get now, and how much of it is built in Power BI?" Why it lands: it shows how much weight the Power BI line carries.
4. "Which site is furthest behind on cost-per-shipment, and what is the plan there?" Why it lands: it turns the cost line into a conversation about where the work is.
5. "How are the twelve supervisors spread across the four sites, and where is the current team stretched?" Why it lands: it finds the real scale problem and shows you are thinking about it.
6. "What would make you say, a year from now, that this was the right hire?" Why it lands: it asks for the manager's own success criteria, which you can then meet.

## Sources

- **Provided material:** the JD, pasted in your message; your background, in the same message. No search or fetch was run.
- **Research tier:** L0. No search or fetch was run.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Atlas Freight values | unavailable | Would have moved a values cheat sheet. Not run: research was not yet consented to (question 2). No values round was named, so no cheat sheet is included either way. |
| 2. Atlas Freight interview process, operations manager | unavailable | Would have moved the persona weights and the loop structure. |
| 3. Atlas Freight strategy and recent news | unavailable | Would have moved the CO questions and a grounding brief. |
| 4. Interviewer name and company | n/a | No interviewer name was given, so there was no query to form. |
| 5. Representative operations manager JD | skipped | The JD you pasted fixes the fit snapshot and the JD questions. |

## Upgrade menu

- The round and who you are meeting (hiring manager, peer, panel, or recruiter screen) → reweights the persona table and every bank
- Atlas Freight's public material (values, recent news), if you say yes to question 2 → a values section and company-grounded CASE and CO questions
- The interviewer's name → a tailored reverse question and persona weights from their public footprint
- Your Green Belt certificate → "green belt certified" moves from medium to high confidence, and C2's hold gets firmer
- A list of the Excel reports you built, with who used them → F4 and C1 gain quotable specifics, and both move to [grounded]
- The number of years you have led people → closes F6's gap, and A4 gets a defensible answer
- The recruiter's prep email → coverage of any exercise they announced
