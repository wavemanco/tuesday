Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-8-denied-497478d2/b8ccaa49-44d2-448e-9acd-fe5ce3a2efab/scratchpad/ashgrove_member_experience_lead_interview_pack.md, and I've sent it to you. I built it on the three rounds you described, with the recruiter's email and the July brief as the research base. I didn't run any web research, so the strategy section is only as current as the brief.

**Where to put your time, in order:**

1. **M5, the presentation objection.** The Head of Member Services will likely test "never presented above regional level." Hold on the spreadsheet your regional manager uses, concede the gap specifically, then give a plan. Don't concede the claim itself. The plan has to be a plan, not a past event.
2. **The escalation case (section 8).** Work the outline aloud: clarify first, then objective, structure, run it, metrics, close. Name the member's side first, and hit Members First, then Own the Fix, then Plain Words.
3. **The "end to end" and "coach supervisors" gaps (M1, M7, P6).** Your material shows one branch's complaints log and tellers trained on the script, not the full process or supervisor coaching. Say the narrow version plainly. The pack does not supply the wider claim.

**Things the pack will not coach:** "regulated complaints" (your sentence says *formal*), "presented to senior leaders," "worked in a contact centre," and any resolution-time tracking you haven't told me about. Each of these has a plain-words answer in the file.

**Values:** the four values have no stories in your material yet, so the values cheat sheet gives selection scaffolds with an honest fallback rather than invented stories. If you have a complaint you carried from first contact to close, it would turn P1, P4 and M6 into real answers.

**Strategy tensions to be ready for:** branch consolidation against "Neighbours, Not Numbers," and the digital target against "Members First" and "Plain Words" (the app-can't-finish-a-complaint case). Answer with the principle, not a view on which branches close.

Your logistics answers (pay, notice, locations, reason for leaving) are yours to give; the pack has no figures for them.

I can also run a live drill on M5 or the escalation case, or save a tuesday-dossier.md recording the gaps this prep exposed. A Word version of the pack is available if you want one.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member_experience_lead_interview_pack.md -----
# Interview prep pack: Member Experience Lead, Ashgrove Credit Union

**For:** Dara · **Company:** Ashgrove Credit Union (member-owned, about 900 staff)
**Rounds (28 November 2026, loop mode):**
1. Recruiter, 30 min
2. Head of Member Services (future manager), 45 min, mostly behavioural
3. Panel of two branch managers, 60 min, including a 20-minute complaint-escalation case; scored against the four values

Interviewers in rounds 2 and 3 are not yet named, so there is no interviewer read. This is the first version.

---

## 1. How to use this pack

- **Personas** describe how a question arrives (friendly, sceptical, pressured, peer). **Types** describe what is being scored:
  - **VAL**: behavioural / values alignment
  - **EXP**: deep-dive into your own past
  - **JD**: the job's stated requirements
  - **CO**: company and strategy knowledge
  - **CASE**: a live problem, solved aloud
- Guidance is scaffolding, not a script. Say it in your own words. Where a cell says **answer slot**, the answer is yours to give. The pack cannot supply it.
- Every claim about your past rests on a sentence you wrote, quoted in the Provenance column. If a claim has no such quote, the cell is a slot or a scaffold, not a story.

---

## 2. Fit snapshot

Requirements are quoted from the JD you supplied. Your evidence is quoted from your own message. Confidence grades your evidence. Provenance grades what this pack wrote about it.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor." (your message) | high | [grounded] | presentation | Say the quote as it is: six years in retail banking, the last three as a branch supervisor. Do not relabel it as contact-centre or operations work. |
| F2 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material shows a formal complaints log at branch level, not regulated timescales or referrals. Answer slot: if the log carried regulatory deadlines or an external referral route, say which and what you did with them; if it did not, say so and say what "formal" meant in your branch. |
| F3 | "Own the member complaints process end to end across branches and the contact centre" (JD) | "I handled the branch's formal complaints log" (your message) | low | [grounded] | transferability | The quote covers one branch's log, not the end-to-end process. Answer slot: say which steps you owned, and which sat with others, in your own words. |
| F4 | "report monthly on complaint volumes and resolution times" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | The quote reaches monthly complaints reporting. It does not say what the sheet counted. Keep the words of the quote. The volume and resolution-time questions are in the question banks as answer slots. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message), "the last 3 as a branch supervisor" (your message) | low | [inferred] | transferability | Your material shows you trained tellers, and that you were a supervisor. It does not show you coached supervisors. Answer slot: if you coached other supervisors on escalations, say how; if you trained only tellers, say so and say what carried over. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show this. Answer slot: if you have worked with any team on a digital or self-service process, say what; if not, say so and say how you would learn the member's journey. |
| F7 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level." (your message) | none | [grounded] | capability | Words: "I haven't presented to anyone above regional level." Then how you would build that skill, said as a plan and never as a past. Nothing added to make the gap feel smaller. |
| F8 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses." (your message) | medium | [grounded] | presentation | Your message says spreadsheet, not Excel. Say what you built in the terms you used. If you used specific Excel functions, say which in the interview. |
| F9 | "across branches and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | Words: "I haven't worked in a contact centre." Then how you would learn the contact-centre side, said as a plan. |

**Gap types:** presentation (the quote reaches the requirement in other terms), transferability (adjacent work that does not reach it), discovery (the material is silent), capability (you stated the absence).

---

## 3. Prohibited claims

These are claims the pack will not coach, because they go beyond what you wrote. No answer, hold, bridge or rationale in this pack asserts them.

| Not coached | Basis | Honest form |
|---|---|---|
| Owned the complaints process end to end | Inflated form of F3 | Your quote at its own scope: the branch's formal complaints log. The pack's observation, not words for you: your material describes the log, not the end-to-end process. |
| Handled regulated complaints | Inflated form of F2 | Your quote at its own scope: "formal complaints log." The observation: "formal" is not "regulated." |
| Coached branch supervisors on escalations | Inflated form of F5 | Your quote at its own scope: you trained new tellers on the escalation script. |
| Tracked resolution times in the monthly report | Inflated form of F4 | Your quote at its own scope. What the sheet counted is an answer slot (M3). |
| Presented to senior leaders | Negative you stated, F7 | Plain acknowledgment: "I haven't presented to anyone above regional level." No slot. |
| Worked in a contact centre | Negative you stated, F9 | Plain acknowledgment: "I haven't worked in a contact centre." No slot. |

---

## 4. Persona weights

Weighting uses the relationship priors, then the loop. Interviewer profiles are absent, so no signal adjustments apply.

| Round | Dominant personas | Likelihood and reasoning | Counter-strategy |
|---|---|---|---|
| 1. Recruiter, 30 min | Conversational (top); light Skeptic | Logistics (pay, notice, location, reason for leaving) and motivation are scored in a friendly register. Treat the casual questions as scored. | Pre-script a 90-second arc for "walk me through your path." Answer each logistics question with your own figure or reason, or ask for the band first. |
| 2. Head of Member Services, 45 min | Skeptic (top); Values/Behavioral; light Case | The hiring-manager prior is Case plus Skeptic, but the round is stated as mostly behavioural, so behavioural sits second. The manager is buying the capability and checking the gaps F3, F7 and F9. | Rehearse the presentation gap (M5) until it is boring. Use STAR-shaped stories only where a quote carries one. Where none does, say so. |
| 3. Panel of two branch managers, 60 min | Values/Behavioral (top); Peer Evaluator; Data-Driven Prober; Case (escalation) | The panel scores the four values, so Values is guaranteed. Branch managers are peers who would take coaching from this role, so the Peer prior applies. Reporting numbers invite probing. | Map a story to each value where a quote carries one, or give a selection scaffold ending in its honest branch. Run the escalation case against the outline in section 8. |

**Depth:** round 2 gives its top persona five questions, and round 3 gives its top persona four. The banks are split by round below, because each round is its own interview.

---

## 5. Question banks

**Types:** VAL, EXP, JD, CO, CASE. The coverage line at the end of this section maps each JD requirement to question IDs.

### Round 1: Recruiter (30 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| R1 | "Walk me through your path to here." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor." · "I handled the branch's formal complaints log" · "I built the monthly complaints spreadsheet our regional manager uses." | About 90 seconds. Start with the six years and the last three as a branch supervisor. Then the complaints log and the spreadsheet, in your own words. Add no titles, team sizes or outcomes you did not state. | F1 sets the opening and F2 and F4 follow from it. Conversational register is still scored. |
| R2 | "What pay are you looking for, and what band have you been told?" | JD | [generic] | Logistics slot: give the figure you actually expect, or ask for the advertised band before you name one. Do not guess a figure. | Pay is a knockout check in a friendly register. Your own number is the only safe answer. |
| R3 | "When could you start, and what notice do you owe your current employer?" | JD | [generic] | Logistics slot: give your actual notice period in your own words. | Notice is a logistics check. The answer is yours to give. |
| R4 | "Where are you based, and which of our sites can you get to?" | JD | [generic] | Logistics slot: name the locations you can work from. | The recruiter has not stated an office pattern, so this question does not assume one. |
| R5 | "What's prompting the move?" | EXP | [generic] | Logistics slot: give your actual reason for leaving, in one or two sentences. It does not have to be the whole story. | The reason for leaving is a motivation check. The pack has no reason on record, so none is supplied. |
| R6 | "Why this role, and why now?" | JD | [grounded] "I handled the branch's formal complaints log" · "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: if your reason comes from the complaints work, use those two sentences and say what you want to do with that work. If your reason is something else, say that. | Motivation-consistency. The pack does not supply a reason you did not state. |
| R7 | "You haven't worked in a contact centre. What's your answer to that?" | JD | [grounded] "Never worked in a contact centre" · "trained new tellers on our escalation script" | Plain acknowledgment: "I haven't worked in a contact centre." Then answer slot: say what from branch complaints work carries over, such as the log or the escalation script, and how you would learn the contact-centre side. | F9 is a stated gap that the interviewer will raise. The acknowledgment is yours to give. |
| R8 | "What do you know about where we're heading?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, July 2026) | Name the 2028 digital target and the 2027 branch consolidation, in your own words. Do not claim knowledge of which branches are affected. | A CO question scored on whether you read the strategy brief. |

### Round 2: Head of Member Services (45 min)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| M1 | "Our complaints process runs end to end across branches and the contact centre. Which part have you owned?" | JD | [grounded] "I handled the branch's formal complaints log" | Story-mapped on F3: the branch's log, at its own scope. Answer slot: if you set the process end to end, say how; if you handled the log within a process others set, say so and say what the log covered. | F3 is the requirement with the widest gap. The honest answer is the narrow one. |
| M2 | "Tell me about formal complaints you handled, and the rules you worked to." | JD | [grounded] "I handled the branch's formal complaints log" | Answer slot: if the log carried regulatory timescales or an external referral route, say which and what you did with them; if it did not, say so and say what "formal" meant in your branch. | F2. The JD says regulated; your material says formal. The gap is the word, and the answer should show that. |
| M3 | "You built the monthly spreadsheet. What did it record, and how?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: say what the sheet recorded in your own words. If it recorded volumes or resolution times, say how each was counted. If it did not record resolution times, say so. | F4. The JD names volumes and resolution times, so the probe is likely. A figure you give must be defended only as you counted it. |
| M4 | "What have you presented to senior leaders, and how did it go?" | JD | [grounded] "I've never presented to anyone above regional level." | Plain acknowledgment: "I haven't presented to anyone above regional level." Then answer slot: name the most senior audience you have presented to and what you took from it. Do not describe a presentation above regional level. | F7. Say the gap first, then the nearest real presentation. |
| M5 | "You've never presented above regional level. Why should I trust you in front of the executive team?" | JD | [grounded] "I've never presented to anyone above regional level." · "I built the monthly complaints spreadsheet our regional manager uses." | **Highest-ROI prep in this pack.** Hold: the spreadsheet your regional manager uses is the reporting you can point to. Concede specifically: "I haven't presented above regional level, and I won't pretend otherwise." Then a plan, said as a plan: how you would prepare for a senior audience. Hold through two follow-ups by returning to the spreadsheet and the plan. Concede only the gap, never the claim. | F7 is the gap most likely to be probed. Interviewers test the candidate's composure under this objection, so the held position must be one you can back. |
| M6 | "Tell me about a complaint you carried from first contact to close. What did you decide?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint with a named stake, a decision you made, and an outcome you can state. If none comes to mind, say so plainly, then give the nearest thing your log carries, or how you would handle it. | The behavioural core of this round. Your quote does not carry a story, so the pack does not invent one. |
| M7 | "When have you coached someone through an escalation?" | JD | [grounded] "trained new tellers on our escalation script" | Answer slot: if you coached a supervisor or a teller through a live escalation, say what you did. If the training was only the script, say so and say what the tellers did with it. | F5. The JD asks about supervisors, and your quote is about tellers. The gap is the word, not the work. |
| M8 | "You haven't worked in a contact centre. How would you learn it?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then a plan: how you would learn the contact-centre side in your first 90 days. Said as a plan, never as a past. | F9. A stated gap that needs a learning plan, not a bridge. |
| M9 | "We are moving 40% of member service to digital by 2028. A member cannot finish a complaint in the app. What do you do?" | CASE | [grounded] "move 40% of member service to digital channels by 2028" (strategy brief, July 2026) | Structure aloud: clarify what the member is trying to finish, then the objective, then the segments affected, the approach, the metrics and the risks. Keep the member's side first. This question makes no claim about your past. | F6 and the digital target. Interviewers test the structure more than the answer. |

### Round 3: Panel of two branch managers (60 min, including a 20-minute case)

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| P1 | "When did you decide from the member's side of the counter when the rules pointed the other way?" | VAL | [grounded] "I handled the branch's formal complaints log" | Selection scaffold: pick a complaint where the member's side and the rule disagreed, and say what you decided. If none comes to mind, say so plainly, then give the nearest thing your log carries. | Members First, Always. Your quote does not carry a story, so the scaffold ends in its honest branch. |
| P2 | "Tell me about a time you explained something a member had to hear twice." | VAL | [grounded] "trained new tellers on our escalation script" | Answer slot: if you reworded the escalation script or the way you explained it, say what changed. If the script was fixed and you only taught it, say so. | Plain Words. The gap is whether you changed the wording, and the answer is yours. |
| P3 | "How has a branch-level decision you were close to affected the town it serves?" | VAL | [grounded] "the last 3 as a branch supervisor" | Selection scaffold: pick a decision from your branch that had a visible effect on local members. If no such decision was yours, say so, and say what you saw from the supervisor's seat. | Neighbours, Not Numbers. The branch consolidation makes this probe likely, so have an honest answer ready. |
| P4 | "Tell me about a problem you found that nobody had been assigned, and what you kept hold of until it was fixed." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Selection scaffold: if the spreadsheet showed a problem nobody owned, say what it showed and what you did. Claim the fix only if it was yours. If the sheet showed no such problem, say so and give the nearest case. | Own the Fix. A probe you must not inflate. |
| P5 | "Walk me through how a complaint gets counted in your monthly sheet." | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses." | Answer slot: say what the sheet recorded and what counted as one complaint, in your own words. If it recorded volumes, say how; if you did not track them, say so. | F4 and F8. The probe is about the method, and only your own account of it counts. |
| P6 | "A branch manager disagrees with an escalation decision you coached them on. What do you do?" | JD | [grounded] "the last 3 as a branch supervisor" | Answer slot: if you coached a supervisor who disagreed, say what you did. If you have not, say so and name the principle you would use. | F5 and the coaching requirement, asked collegially. |
| P7 | "Where does a branch complaint end and the contact centre's work begin?" | JD | [grounded] "Never worked in a contact centre" | Plain acknowledgment: "I haven't worked in a contact centre." Then name the seam as a principle, such as who keeps the case once it moves, and say you would confirm it with the contact-centre lead. | F9, asked as a seam question. Propose a principle, not a seam you do not know. |
| P8 | "How would you tell whether a complaint was resolved, not just closed?" | JD | [generic] | Name what "resolved" would mean for a member, such as their confirmation or no repeat contact, and say how you would check it. | The JD names resolution times. This is method, not a claim about your past. |
| P9 | *Escalation case (see section 8).* | CASE | [generic] | Run the outline in section 8. | The 20-minute case. Presupposes nothing about your past. |

### Coverage line

| JD requirement | Covered by |
|---|---|
| 4+ years in financial-services customer operations | R1, R6 |
| Experience handling regulated complaints | M1, M2 |
| Own the complaints process end to end across branches and the contact centre | M1, P1, P7 |
| Report monthly on complaint volumes and resolution times | M3, P5, P8 |
| Coach branch supervisors on escalations | M7, P6, P9 |
| Work with digital teams on self-service journeys | M9, R8 |
| Confident presenting to senior leaders | M4, M5 |
| Comfortable with Excel reporting | M3, P5 (F8 is the same sentence; a further answer is not needed) |

---

## 6. Values cheat sheet

Values round detected: the panel scores against four values. Values are quoted from the published page you copied on 19 November 2026.

| Value (official name) | Working meaning | Your mapped story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | F2 and F3: the branch's formal complaints log. The quote does not carry a story. Selection scaffold ending in its honest branch, P1 and M6. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | F5: "trained new tellers on our escalation script." The quote carries teaching, not rewording. Answer slot, P2. |
| Neighbours, Not Numbers | Every branch is part of its town | F1 and the supervisor role: "the last 3 as a branch supervisor." No quote carries a local decision. Selection scaffold with its honest branch, P3. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | F4: "I built the monthly complaints spreadsheet our regional manager uses." The quote carries a sheet, not a fix. Selection scaffold, P4. |

**Honest branch for all four:** if no story comes to mind, say so plainly, then give the nearest thing your material carries.

---

## 7. Grounding brief (from the July 2026 strategy you were sent)

Stated facts only, as the brief gives them:
- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

Recent news after July 2026 was not searched (research tier L0). Check before the interview.

**Tensions to be ready to discuss:**
- **Consolidation against Neighbours, Not Numbers.** Eight branches becoming five is a change for each town. Answer with the principle: how members would still get complaints handled and explained. Do not take a position on which branches close.
- **Digital against Members First and Plain Words.** A member who cannot finish a complaint in the app is the case in M9. Answer with the member's side first, then the channel.
- **Small-business lending.** A new product means new complaint types. Ask about it as a reverse question (section 9) rather than claiming knowledge of it.

---

## 8. Escalation case outline (round 3, 20 minutes)

The case is a live problem. Its details are the panel's, so the outline gives structure and timings, not facts.

| Minutes | Step | What to do |
|---|---|---|
| 0–2 | Clarify | Ask what happened, what the member has been told, and what the rules are. Do not start solving. |
| 2–5 | Objective | State the outcome you are aiming for: the member heard, the case owned, the rule applied correctly. |
| 5–8 | Structure | Name the steps: contain, decide, explain, record, follow up. Say which you would do first. |
| 8–16 | Run it | Work through the case aloud. Name the member's side first. Keep one open risk. |
| 16–18 | Metrics | Say how you would know it was resolved, not just closed. |
| 18–20 | Close | State the owner and the next check, and say what you would tell the branch manager. |

**Values to hit, in order:** Members First, Own the Fix, Plain Words. Neighbours, Not Numbers comes in if the case touches a branch's town.

Do not claim the process has been followed in any branch you have run. Say what you would do.

---

## 9. Reverse questions

| # | Question | Why it lands |
|---|---|---|
| RQ1 | "What would you want the complaints role to have fixed by the end of the first 90 days?" | Asked of the Head of Member Services, it puts the Own the Fix value in the first question you ask. |
| RQ2 | "How is the monthly complaints report used by leadership today, and what would you change in it?" | It refers to the spreadsheet you built without claiming credit for it, and it shows you read the reporting requirement. |
| RQ3 | "How will the branch-to-hub changes affect where complaints from each town are handled?" | Shows you read the strategy and care about the members in each branch, not only the numbers. |
| RQ4 | "Once a complaint leaves a branch, who keeps hold of it until it's solved?" | Asked of the panel, it tests the Own the Fix value in their own process. |
| RQ5 | "What would a new person do in their first month that would genuinely help your branches?" | Reciprocity question for the peer panel: it turns the round into a conversation about what you bring. |
| RQ6 | "Which of the three rounds do you think decides it, and what should I prepare that the rounds won't tell me?" | Asked of the recruiter, it gives you the scoring priority without asking for anything confidential. |

---

## 10. Scope and sources

**Research tier:** L0. Provided documents only. No search or fetch was run.

**Provided documents:**
- The job description you supplied.
- The recruiter's email about the three rounds.
- The values page text you copied on 19 November 2026 (ashgrovecu.org/about/values).
- The July 2026 strategy brief, as the recruiter sent it.
- Your background, from your message.

**Target accounting:**

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Company values | skipped | The pasted values already fix the cheat sheet (section 6). |
| 2. Interview process | skipped | The recruiter's email fixes the loop and the persona weights. |
| 3. Strategy and recent news | unavailable | L0 tier. Recent news after July 2026 would have updated the CO question R8 and the grounding brief. |
| 4. Interviewer name | n/a | No interviewer names were given. |
| 5. Representative JD | skipped | Your JD fixes the fit snapshot and the JD questions. |

**Dossier:** none consumed.

---

## 11. Upgrade menu

- **Names of the Head of Member Services and the two panel branch managers** → tailored persona weights and a reverse question for each.
- **Research at L1** (recent news since the July brief, and the interview process) → updates R8, the grounding brief and the loop structure. At most six searches and two page fetches.
- **Deep research at L2** (the interviewers' published talks, loop reports for this role family, recent organisation news) → at most six further searches and two further fetches. It costs more and is offered once.
- **Your actual pay expectation, notice, locations and reason for leaving, in your own words** → fills the logistics slots R2 to R5. The pack will not supply them.
- **The Excel functions you used, if any** → upgrades F8, M3 and P5 from presentation to grounded.
- **A complaint you carried from first contact to close** → upgrades M6, P1 and P4 from selection scaffolds to story-mapped answers.
- **The recruiter's prep email, if it names scored deliverables** → coverage of any deliverable it declares.
- **A tuesday-dossier.md, if you have one** → evidence-derived objections in place of inferred ones, and any prohibited claims it records.
