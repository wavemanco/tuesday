Your prep pack is saved as /tmp/claude-0/-var-tmp-tuesday-measure-1a2-runs-haiku-alone-part-2-rooms-case-8-canned-afb47644/b0d4e667-5740-4b62-8156-bee5b4ea5525/scratchpad/ashgrove_member-experience-lead_interview_pack.md. I built it in loop mode, one mini-pack per round, since you have three scheduled.

Three things to know before you open it:

- **The biggest gap is contact-centre ownership.** The JD asks you to own complaints across branches and the contact centre, and you've never worked in a contact centre. Question B2 is the one to rehearse first, with three follow-ups. The pack's answer is to state the gap plainly and then give a plan. It never claims the experience.
- **The panel's 20-minute case is D3.** It's a live escalation with no claim about your past, so there's nothing to bluff. Run it twice against a timer.
- **28 November is a Saturday.** Confirm the times, and whether all three rounds are one visit, with the recruiter.

I didn't run any web searches. Your pasted values, the recruiter's round structure and your summary of the strategy brief covered everything the research would have checked. The round 2 and 3 interviewers are unnamed, so there's no interviewer read. If you get their names, the pack can tailor the panel weights and reverse questions.

I can run a drill on B2 with the Skeptic persona, or save a tuesday-dossier.md recording the gaps this prep exposed. I can also convert the pack to Word if you'd like it.

**Watch-out:** Suggested answers can make your experience sound bigger than what you told me — rehearse only what you actually did, in your own words.

----- file the response produced: ashgrove_member-experience-lead_interview_pack.md -----
# Interview pack: Member Experience Lead, Ashgrove Credit Union

**For:** Dara
**Role:** Member Experience Lead, Ashgrove Credit Union (member-owned, about 900 staff)
**Rounds:** three, on 28 November 2026 (a Saturday, so confirm the times and whether all three rounds are one visit)
- Round 1: recruiter, 30 minutes
- Round 2: Head of Member Services (your future manager, unnamed), 45 minutes, mostly behavioural
- Round 3: panel of two branch managers (unnamed), 60 minutes, including a 20-minute complaint-escalation case; the panel scores against the four values

**Format:** loop mode. One shared fit snapshot and sources block, then a mini-pack per round.
**Not included, because the inputs do not support them:** interviewer read (no names for rounds 2 and 3), graded deliverables (none declared), delivery coaching (no assessment provided).

---

## How to use, and the type key

Personas describe how a question arrives. Types describe what is being scored. Guidance is scaffolding, not a script: say it in your own words, and stop where your material stops.

**Persona IDs:** A Conversational, B Skeptic, C Values/Behavioral, D Case/Strategist, E Peer Evaluator, F Pressure, G Data-Driven Prober.

**Type tags:**
- **VAL**: behavioural, tests whether past behaviour shows a published value.
- **EXP**: work-experience deep-dive, tests whether your stated history holds up.
- **JD**: tests a requirement in the job description, including the gaps.
- **CO**: company and strategy knowledge.
- **CASE**: a live problem from the role, reasoned aloud.

---

## Prep triage (9 days)

In order:

1. **B2**, the contact-centre and end-to-end question. It is the biggest gap and the most likely objection. Say it aloud, then rehearse three follow-ups.
2. **F1**, the spreadsheet "how much was actually you" probe, with B3 (resolution times). Practise holding what you built and conceding only what was your regional manager's choice.
3. **D3**, the 20-minute escalation case. Run it twice against a timer.
4. **C1 to C4**, the four values. Write each as a 90-second answer from your own material. Where the answer is a selection scaffold, decide now what you would say in the honest branch.
5. **B4, B5, B6**, short plain answers to the coaching, digital and senior-presentation gaps, each followed by the plan you would use.

Everything else is insurance.

---

## Fit snapshot (shared)

Each requirement from the JD, paired with the sentences you have given me, verbatim. Evidence cells quote only your own words (your message) or the JD text.

| # | Requirement (source) | Evidence, verbatim | Confidence | Provenance | Gap type | Gap and bridge language |
|---|---|---|---|---|---|---|
| F1 | "Own the member complaints process end to end across branches" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | transferability | Your material says the branch's formal complaints log, not the end-to-end process. Say it in those words: "I handled the branch's formal complaints log." Answer slot: which stages of a complaint were yours to run, from first contact to close, in your own words. If the log was one stage of a longer process run by others, say so. |
| F2 | "and the contact centre" (JD) | "Never worked in a contact centre" (your message) | none | [grounded] | capability | A gap you stated, so it can be said plainly: "I've never worked in a contact centre." Then a plan, said as a plan and never as a past: how you would learn the contact centre's complaint routes in your first month. Nothing added to make the gap smaller. |
| F3 | "report monthly on complaint volumes" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote already reaches monthly reporting. Say it as it is: "I built the monthly complaints spreadsheet our regional manager uses." Do not add what it counted unless you can say it. |
| F4 | "resolution times" (JD) | none given | none | [grounded] | discovery | Your material does not show whether the spreadsheet recorded how long complaints took. Answer slot: if it did, say what it counted and how you would defend that number, in your own words. If it did not, say so, and say what you would add first. |
| F5 | "coach branch supervisors on escalations" (JD) | "trained new tellers on our escalation script" (your message) | medium | [grounded] | transferability | Your material shows tellers, not supervisors. Say it as it is: "I trained new tellers on our escalation script." Answer slot: if you coached anyone beyond tellers on an escalation, say who and what you decided together. If not, say so, and say how you would coach a branch supervisor on one. |
| F6 | "work with digital teams on self-service journeys" (JD) | none given | none | [grounded] | discovery | Your material does not show work with a digital team. Answer slot: if you have worked with one on a self-service journey, say what you did. If not, say so, and say how you would start. |
| F7 | "4+ years in financial-services customer operations" (JD) | "6 years in retail banking, the last 3 as a branch supervisor" (your message) | medium | [grounded] | none | The quote already reaches the requirement. Say the years in those words. Expect the timeline to be confirmed. |
| F8 | "experience handling regulated complaints" (JD) | "I handled the branch's formal complaints log" (your message) | medium | [grounded] | presentation | The quote reaches complaints in role terms. The regulated part is not shown. Bridge: "I handled the branch's formal complaints log." Answer slot: if the log carried regulatory deadlines, referrals or ombudsman cases, say which and what you did with them. If it did not, say what it did carry. |
| F9 | "confident presenting to senior leaders" (JD) | "I've never presented to anyone above regional level" (your message) | none | [grounded] | capability | A gap you stated: "I've never presented to anyone above regional level." Then a plan for how you would prepare for a senior audience. Never a claim to senior presenting. |
| F10 | "comfortable with Excel reporting" (JD) | "I built the monthly complaints spreadsheet our regional manager uses" (your message) | medium | [grounded] | presentation | The quote reaches reporting in other terms. Bridge, unchanged: "I built the monthly complaints spreadsheet our regional manager uses." Answer slot: name the tool you used and what it calculated, if you can say. If it was not Excel, say what it was. |

Confidence grades your evidence. Provenance grades this pack's statement about it. Gap type is the routing from the evidence cell: F4 and F6 are discovery because the material is silent, not because you have said no.

---

## Prohibited claims (not coached in this pack)

Each entry names its basis and its honest form. Nothing in any guidance cell asserts, softens or implies these.

| Not coached | Basis | Honest form |
|---|---|---|
| Owns the complaints process end to end across branches and the contact centre | Inflated form of F1 and F2 | F1 at its own scope: "I handled the branch's formal complaints log." The contact centre is the plain acknowledgment from F2. The limit is this pack's observation: your material says the branch log, not the end-to-end process. |
| Owned the monthly complaints reporting, or designed its measures | Inflated form of F3 and F10 ("built" stretched to "owned" or "designed") | F3 at its own scope. B3 and G1 ask only what the spreadsheet counted. |
| Coached branch supervisors on escalations | Inflated form of F5 | F5 at its own scope: "I trained new tellers on our escalation script." B4 asks only what you did beyond tellers. |
| Handled regulated complaints, stated as a record | Inflated form of F8 | F8 at its own scope: "I handled the branch's formal complaints log." The regulated part is in the answer slot, not in a claim. |
| Presented to senior leaders | Sourced: your stated negative (F9) | "I've never presented to anyone above regional level." |
| Contact-centre experience | Sourced: your stated negative (F2) | "I've never worked in a contact centre." |

Digital self-service work (F6) is not on this list. Your material is silent on it, so it is an answer slot, not a claim you have made or not made.

---

## Grounding brief (strategy and vocabulary)

Source: your summary of Ashgrove's July 2026 strategy brief, which the recruiter sent. I have not seen the full brief, so use these phrases as your summary has them, and check the full document before the interview if you can.

- Move 40% of member service to digital channels by 2028.
- Consolidate eight branches into five hubs over 2027.
- Launch a small-business lending product in Q1 2027.
- The main competitive pressure is app-only banks.

Vocabulary to use: "member service", "digital channels", "hubs". Nothing in your material shows experience with small-business lending, so do not talk about it as experience. Nothing you pasted is stale. The brief is under six months old.

---

## Requirement coverage

| JD requirement | Covered by |
|---|---|
| Own the member complaints process end to end across branches | B2, C4, E1 |
| ... and the contact centre | B1, B2, E1 |
| Report monthly on complaint volumes | F1 (hold), G1 |
| ... and resolution times | B3 |
| Coach branch supervisors on escalations | B4, C7, D3 |
| Work with digital teams on self-service journeys | B5 |
| 4+ years in financial-services customer operations | A1, which walks the years; the quote already reaches the requirement, so no separate question |
| Experience handling regulated complaints | A2, D3 |
| Confident presenting to senior leaders | B6 |
| Comfortable with Excel reporting | G1 |

---

## Sources and research

**Provided documents:** your message, containing the JD text, the four values as copied from ashgrovecu.org on 19 November 2026, the recruiter's process email, your summary of the July 2026 strategy brief, and your background.

**Research tier:** L1. Searches 0 of 6. Fetches 0 of 2.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Ashgrove values | skipped | The values cheat sheet. The four values were pasted from the official page this morning, so the input already fixes the output. |
| 2. Interview process | skipped | The loop structure. The recruiter's email names the three rounds, their lengths and who runs them, so no archetype fallback is needed. |
| 3. Strategy and recent news | skipped | The grounding brief and the CO question. The July 2026 summary you pasted is under six months old. |
| 4. Interviewer name and company | n/a | No names for rounds 2 or 3, so no query could be formed. The interviewer read is absent. |
| 5. Representative JD | skipped | The JD was supplied, so it fixes the fit snapshot and the JD-tagged questions. |

---

## Round 1: recruiter screen (30 minutes)

**Persona weights.** The relationship prior for a recruiter screen is Conversational plus a light Skeptic. Conversational is weighted high (about 6 of 8 rows): logistics and motivation are asked in a friendly register, and they are scored. Skeptic is light (1 row), because the one stated gap a recruiter is likely to probe is the contact-centre gap.

**Persona table**

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| A Conversational | high, 7 rows | Logistics and motivation are scored in a casual register | Pre-script a 90-second career arc. Treat "what made you apply" as scored. |
| B Skeptic | light, 1 row | The contact-centre gap is the first thing a skeptic finds | One plain sentence, then a plan. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| A1 | "Walk me through the route from retail banking to where you are now." | EXP | [grounded] "6 years in retail banking, the last 3 as a branch supervisor" | Story-mapped on F7: six years in retail banking, the last three as a branch supervisor. Give the sequence in your own words and stop at the supervisor role. About 90 seconds. | F7 is the years requirement, and this is where it is first confirmed. EXP because the arc is your own history. |
| A2 | "What did handling the branch's formal complaints log involve day to day?" | JD | [grounded] "I handled the branch's formal complaints log" | Use the quote's words: you handled the branch's formal complaints log. Describe what handling meant in your own steps. Answer slot: if the log carried regulatory deadlines, referrals or ombudsman cases, say which and what you did with each. If it did not, say what it did carry. | F8 and F1 sit under this. A recruiter checks the requirement a branch log can only partly meet, regulated complaints, before passing you on. |
| A3 | "What's the reason you're looking to move on from your current role?" | EXP | [generic] | Logistics slot: give your own reason, in your own words, true and short. No reason is supplied here, and none should be added. | Recruiters ask this for consistency. The only safe answer is yours. |
| A4 | "What are your pay expectations for this role?" | JD | [generic] | Logistics slot: give your own figure, or ask for the band first. This pack supplies no figure and no salary history. | Pay is a knockout check in a recruiter's register. |
| A5 | "What notice do you need to give your current employer?" | JD | [generic] | Logistics slot: give your actual notice period. | Notice sets the earliest start date the recruiter needs before the next rounds. |
| A6 | "Which branches could you work from, given the move to hubs?" | JD | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Logistics slot: name the locations you can work from, in your own words, from your own constraints. | Location is a knockout check, and the consolidation makes it live. |
| A7 | "What made you apply to us?" | CO | [grounded] "move 40% of member service to digital channels by 2028" (your summary of the brief) | Name one thing from the brief in your own words, and say why it matters for complaints. Answer slot: your own reason for applying. No reason is supplied here. | The recruiter is checking motivation and whether you have read the brief. |
| B1 | "Which part of this role would you be weakest at on day one?" | JD | [grounded] "Never worked in a contact centre" | Say it plainly: "I've never worked in a contact centre." Then a ramp plan, as a plan: how you would learn contact-centre complaint routes in your first month. No claim of contact-centre experience. | This is the one stated gap a skeptic reaches first. A plain answer closes it in one sentence. |

**Reverse questions (Round 1)**

| Question | Why it lands |
|---|---|
| "What does the Head of Member Services most need the complaints lead to change in the first 90 days?" | It asks for the manager's priority and lets you answer the ownership line of the JD. |
| "How does the move to five hubs change where complaints arrive first, in a branch or in the contact centre?" | It ties the question to the brief and shows you read it. |

---

## Round 2: Head of Member Services (45 minutes, mostly behavioural)

**Persona weights.** The relationship prior for a hiring manager is Case plus Skeptic. The round is mostly behavioural, so Values/Behavioral moves up to match Skeptic. Case stays light (2 rows), because the manager's roadmap questions are the only live problems in this round.

**Persona table**

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | high, 5 rows | Round is mostly behavioural | STAR-shaped stories. "We" for context, "I" for what you did. |
| B Skeptic | high, 5 rows | Manager is buying capability and checking gaps | Rehearse the most likely objection until it is plain. Hold, then concede only what is true. |
| D Case/Strategist | light, 2 rows | Manager's roadmap questions | Clarify, structure, then answer. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C1 | "Tell me about a time you put a member ahead of a process." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt, selection scaffold: pick one member decision that went beyond the default process. If the complaints log is the nearest thing, say what you did for one member in it. If nothing comes to mind, say so plainly, then give the nearest work your material carries and how you would handle it. | Members First is scored, and F1 is the nearest sentence you have given. |
| C2 | "Tell me about a time a member didn't understand something you'd told them. What did you do next?" | VAL | [grounded] "trained new tellers on our escalation script" | Scaffold: if you changed the script's wording so tellers could say it plainly, say what you changed. If the script was handed to you, say so. If none comes to mind, say so and give the nearest. | Plain Words is scored on whether the member understood. |
| C3 | "Tell me about a time a branch's numbers and its town told you different things." | VAL | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Scaffold: pick a time a figure pointed one way and the people in the town another. Say which you followed and why. Your nearest numbers story is the spreadsheet: say what it showed and who it reached, only as you can say it. If none comes to mind, say so plainly. | This value pulls against your spreadsheet, so the panel will test whether numbers ever led you to people. |
| C4 | "Tell me about a time you kept hold of a problem until it was solved." | VAL | [grounded] "I handled the branch's formal complaints log" | Mapped: the complaints log you handled is the story spine. Beats: the complaint you took through the log. Answer slot: if you kept one complaint to its close, say what closed it. If the log moved on without you, say so, and say what you did with the part that was yours. | Own the Fix is the value your log covers most directly. The honest version is the complaint you held to close, if you did. |
| C5 | "Tell me about a time you gave a member an answer they did not want." | VAL | [grounded] "I handled the branch's formal complaints log" | Open prompt, scaffold: pick a member who did not get the answer they wanted. Say what you told them, how you said it plainly, and what you did next. If none comes to mind, say so and give the nearest. | Members First and Own the Fix both score here. Hard truths told plainly are what the values round tests. |
| B2 | "You've handled a branch's formal complaints log. This role owns complaints across the contact centre as well. What's your experience there?" | JD | [grounded] "I handled the branch's formal complaints log"; [grounded] "Never worked in a contact centre" | **Highest-ROI prep in this pack.** Open with the quote's words and the plain negative: "I handled the branch's formal complaints log. I've never worked in a contact centre." Follow-up 1 (what end to end meant in your branch): name the stages you handled, from your material, and say where your part stopped. Follow-up 2 (how would you run complaints through a contact centre): hold the plan, not a past. Say what you would map first. Follow-up 3 (so you can't do this job?): concede the specific gap, not the core. "I can't claim contact-centre experience. I can name the first three things I'd do." Hold through two follow-ups. Concede only the contact-centre gap. Never claim end-to-end ownership. | F1 and F2 are the largest gaps, and the JD's scope line makes this the objection most likely in some form. It gets the deepest rehearsal because it will be asked. |
| B3 | "Does that monthly spreadsheet track how long complaints take to resolve?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Answer slot: if it recorded resolution times, say what it counted, and how you would defend that number in your own words. If it did not, say so, and say what you would add first. Name no method and no baseline. | F4: the JD asks for resolution times, and nothing in your material shows them. A direct probe is likely. |
| B4 | "Have you coached anyone on escalation decisions beyond tellers?" | JD | [grounded] "trained new tellers on our escalation script" | Answer slot: if you coached anyone else on escalations, say who and what you decided together. If the only training you did was tellers on the script, say so plainly, and then say how you would coach a branch supervisor on an escalation. | F5: the JD asks about supervisors. Your material shows tellers, so say so. |
| B5 | "Have you worked with a digital team on a self-service journey?" | JD | [grounded] JD line "work with digital teams on self-service journeys" | Answer slot: if you have, say what you did. If not, say so and say how you would start with a digital team. | F6: silence in your material. Both honest answers are yours to give. |
| B6 | "The role presents to senior leaders. Have you presented to senior leaders, and if so, to whom?" | JD | [grounded] "I've never presented to anyone above regional level" | Plain acknowledgment: "I've never presented to anyone above regional level." Then a plan: how you would prepare for a senior audience. No claim of senior presenting. | F9: a stated gap, so say it, then give the plan. |
| D1 | "The plan has eight branches becoming five hubs over 2027. What happens to a complaint that's open when its branch closes?" | CASE | [grounded] "consolidate eight branches into five hubs over 2027" (your summary of the brief) | Clarify first: whose complaint it is, and whether a regulatory clock is running. Objective: no member loses the thread. Segment open complaints from new ones, and by channel. Approach: a handover standard with a named owner. Metrics to suggest, not claim: time to first contact, time to resolution, reopen rate. Risks: complaints fall into the gap between hub and branch. Think aloud. Claim nothing about your own experience of a closure. | A live problem on the manager's roadmap. The answer tests structure, not experience. |
| D2 | "What would you look at first in the complaints process in your first month?" | CASE | [generic] | Clarify first: what the monthly report should tell the board, where open complaints sit now, and which branch or the contact centre holds the largest backlog. Then a 30-day plan with three checks. No claim about your past. | The manager's most likely first-month question. |

**Reverse questions (Round 2)**

| Question | Why it lands |
|---|---|
| "What would a good first quarter in this role look like to you?" | It asks for the manager's definition of success, which you can then test your plan against. |
| "When an escalation reaches this role from a branch, which decision do you most want the lead to own?" | It separates coaching from taking cases over, which matters to the JD's coaching line. |

*No interviewer profile exists, so the reverse question tied to the interviewer's path is not possible yet. The upgrade menu says what a name would add.*

---

## Round 3: branch-manager panel (60 minutes, with 20-minute escalation case)

**Persona weights.** The panel is two branch managers, with no names yet. Values/Behavioral is the top persona, because the panel scores against the four values. The 20-minute escalation case is the centre of the round. Peer Evaluator (2 rows) fits branch managers who will work beside this role. Pressure (1 row) and Prober (1 row) are light, because the spreadsheet is the one claim they are likely to test.

**Persona table**

| Persona | Weight | Why | Counter-strategy |
|---|---|---|---|
| C Values/Behavioral | high, 3 rows | Panel scores against the four values | Map each value to a story you can actually tell. Say the honest branch aloud when a story is missing. |
| D Case/Strategist | the 20-minute case, depth in its follow-ups | Live escalation problem | Clarify, decide, coach, close the loop, record. Say the sequence aloud. |
| E Peer Evaluator | 2 rows | Branch managers work beside this role | Seam principles, not claimed knowledge. Credit shared. |
| F Pressure | 1 row | The spreadsheet is the claim they are likely to test | Hold what you built. Concede only what was not yours. |
| G Data-Driven Prober | 1 row | The JD names Excel reporting | Name the tool and what it calculated, in your own words. |

**Values cheat sheet (panel scores against these)**

| Value | Working meaning | Your story |
|---|---|---|
| Members First, Always | Decide from the member's side of the counter | Selection scaffold, no quoted story carries a member-side decision. Pick a time you decided from the member's side. The nearest is F1: "I handled the branch's formal complaints log." If none comes, say so plainly, then give the log work and how you would handle it. |
| Plain Words | If a member needs it explained twice, we wrote it wrong | Selection scaffold. The nearest is F5: "I trained new tellers on our escalation script." If you changed the wording so it could be said plainly, say what. If the script was handed to you, say so. |
| Neighbours, Not Numbers | Every branch is part of its town | Selection scaffold. The nearest numbers story is F3: "I built the monthly complaints spreadsheet our regional manager uses." Say what it showed and who it reached, only as you can say it. If none, say so. |
| Own the Fix | Whoever finds the problem keeps hold of it until it is solved | Mapped on F1: "I handled the branch's formal complaints log." The beat is the complaint you took through the log. Answer slot: if you kept one complaint to its close, say what closed it. If the log moved on without you, say so. |

**Question bank**

| # | Question | Type | Provenance | Answer guidance | Rationale |
|---|---|---|---|---|---|
| C6 | "What do you know about the town a branch serves, and how would you use it when a complaint comes in?" | VAL | [generic] | Hypothetical, no claim about your past. Say what you would want to know about the town: the branch's customers, the services they use, the local issues that come up. Then how that changes a complaint handled from the member's side. | Neighbours, Not Numbers, asked as a method. |
| C7 | "How would you coach a branch supervisor who is nervous about escalating a complaint?" | JD | [grounded] JD line "coach branch supervisors on escalations" | Hypothetical, no claim about your past. Say what you would ask the supervisor first, what you would let them decide, and the one thing you would check together before it goes up. | The JD's coaching line, asked as a coaching moment. |
| C8 | "What's the clearest thing you've explained to a member? What told you it landed?" | VAL | [grounded] "trained new tellers on our escalation script" | Open prompt, scaffold: if your nearest is the script training, say what you did to make it plain, in your own words. If you never checked that a member had understood, say so and say how you would check. | Plain Words is scored on whether the member understood. |
| D3 | "A member's third complaint about the same charge reaches you. The second reply said 'we'll look into it' and nothing happened. Now the member is going to the ombudsman. The branch supervisor says part of the charge was refunded, but nobody told the member. Twenty minutes: what do you do, and what do you say to the member, the supervisor and the regional manager?" | CASE | [grounded] JD line "coach branch supervisors on escalations" | Scaffold with no claim about your past. Sequence: (1) clarify the facts: what was refunded and when, and whether a regulatory deadline is running. (2) Act today: call the member and say the refund plainly. (3) Coach the supervisor without taking the case off them. (4) Fix the gap that let nobody tell the member, and keep hold until the member knows and the fix is in place. (5) Record the case for the monthly report. Reactive follow-ups: the regional manager says "just send the refund letter" (hold: the member hears it in plain words first, and concede the timing if a letter must follow). "You've never worked in a contact centre, so how would you handle this one there?" (answer with the plan, not a past). Rehearse twice, timed. | A live escalation problem, which the JD and the panel both name. It asks about no past. |
| E1 | "Our branches and the contact centre sit side by side. Where's the seam, and what happens when we disagree about a complaint?" | JD | [grounded] JD line "across branches and the contact centre" | Propose seam principles, not a known seam: one owner per complaint, a handover rule, and disagreements settled by the member's outcome. Claim no knowledge of the seam. No claim about your past. | The panel's seam question, and the JD's end-to-end line is the raising source. |
| E2 | "When a complaint fix spans two teams, who gets the credit, and how do you handle it?" | VAL | [generic] | Answer with reciprocity: credit the people who fixed the member's problem, and say what you would bring to their branch. Do not invent a credit story. | Credit-sharing is the peer's test, and it sits under Own the Fix. |
| F1 | "That spreadsheet your regional manager uses. How much of it was actually you?" | EXP | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Hold: say what you built, in the sentence's own words. Hold through two follow-ups by returning to what you built. Concede specifically: if the measures or format were your regional manager's choice, say so. Answer slot: if you chose what it measured, say which measures and why. If the regional manager set them, say so plainly. | The panel's pressure test on your strongest claim. Hold the true version, and concede only what was not yours. |
| G1 | "What's in the monthly complaints spreadsheet, and what would you defend least about it?" | JD | [grounded] "I built the monthly complaints spreadsheet our regional manager uses" | Weakest-assumption move, in your own words: name the assumption you would defend least, if you know it. If you don't know how a figure was counted, say so. Answer slot: name the tool you used and what it calculated, if you can say. If it was not Excel, say what it was. | The JD names Excel reporting, so the panel will ask what the tool was and what it calculated. |

**Reverse questions (Round 3)**

| Question | Why it lands |
|---|---|
| "What would you need from a complaints lead in the first month that would help your branch?" | Reciprocity for a peer panel. It shows you are thinking about what you bring to their work, not only what you need. |
| "When a branch closes into a hub, how do its open complaints get handed over?" | A practical seam question for branch managers who may be living the consolidation. It ties to the brief. |

---

## Upgrade menu

- Interviewer names for rounds 2 and 3 → an interviewer read from their public footprint, persona weights tuned to them, and a reverse question tied to their career path.
- The full July 2026 strategy brief, not your summary → quotes from it in place of your paraphrase, and a check on the "hubs" and "40%" language in A6, A7 and D1.
- Your CV → fit-snapshot evidence cells quoting your CV, and a check that F1 to F10 match it.
- The monthly complaints spreadsheet itself, or a sample with its column headers → an inspectable artifact, which would raise F3 and F10 from medium to high and answer F4 and B3 from the file rather than from memory.
- Any figure you reported from that spreadsheet → defend-the-number answer slots for the figure, in your own words.
- A recruiter email confirming any pre-declared deliverable or presentation → a build section for it. None has been declared so far.
- A tuesday-dossier.md, if you have one → verified evidence and any limits it records, in place of the inferred gaps above.
- A deeper research pass is available: up to 6 more searches and 2 more fetches, several more minutes, run only on your go-ahead. It would target Ashgrove's full strategy and any published interview accounts.
