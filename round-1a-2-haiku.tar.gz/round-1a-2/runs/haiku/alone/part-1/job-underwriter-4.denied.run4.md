**Yes, worth applying, on conditions. Status: `conditional_go`.** Renata's evidence reads direct on the stated requirements. The open items are whether Brindlemoor is a live employer, the unstated pay and contract, and who decides on rate changes. Research did not run, so the employer is unverified, not shown to be absent.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK-based)
- `must_have` — direct: R2, R3, R4, R6, R7 · adjacent: R5 (Build and monitor rating models)
- `important` — adjacent: R8 (Recommendations for underwriting and product)
- `preferred` — direct: R9 (Insurance experience)

R5 (`medium`) — motor pricing transfers, pet drivers unexercised; R8 — underwriting recommendations evidenced, product side not; R1 (`low`) — location and right to work not given.

**Opportunity ledger.** The role is clearly scoped and fully remote (RR4, positive). The employer is unverified (RR3), salary and contract basis are unstated (RR2), and the posting asks for recommendations without saying who decides (RR1). People management is not in the JD (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR3 — the posting appears on Brindlemoor's own careers page and the employer checks out; (2) RR2 — pay and permanent-or-fixed basis confirmed; (3) RR1 — rate decision rights are clear; (4) R1 — location and right to work confirmed.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` JD header; not verified (see RR3) |
| Mandate | Build and monitor rating models; design and read price tests; turn results into recommendations | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Analyst-level remit with a "Senior" title; no people-management line in the JD | `[inferred]` from the JD's verbs and silence on reports |
| Market calibration | Not run; no search was available | — |
| Unknowns | Salary, contract basis, decision rights on rates, team size, whether people management is expected | — |
| Contradictions | None found; only one source (the JD) was available | — |

Hiring manager Odile Varga's public footprint was not checked, so the scope read cannot be set against her remit.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (location) | hard_gate | unclear | low | hard_gate | JD says fully remote UK. Renata's location and right to work were not given. A UK motor role suggests a UK base | `[grounded]` JD; `[inferred]` UK base | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics at a UK motor insurer, last two as senior analyst | `[grounded]` user statement, unverified | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Both used daily | `[grounded]` user statement | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book | `[grounded]` user statement | none |
| R5 | Build and monitor rating models for a pet product | must_have | adjacent | medium | transferability | Motor GLM work carries over. Pet-specific risk drivers and claims behaviour are not exercised | `[inferred]` from motor GLM work against the pet mandate | G1 |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` user statement | none |
| R7 | Present results to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting. No actuarial-lead presentations stated | `[grounded]` user statement | none |
| R8 | Turn results into recommendations for underwriting and product | important | adjacent | medium | transferability | Underwriting recommendations are evidenced. Product-side recommendations are not | `[grounded]` user statement; `[inferred]` product gap | G2 |
| R9 | Insurance experience | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` user statement | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Rating models for a pet product (R5, must_have) | transferability | Motor GLM build and maintenance. No pet or other non-motor product | Must-have at adjacent; the likeliest objection in interview | Any non-motor rating model; any product with renewal-based or vet-cost-driven claims | A sanitized model documentation sheet or validation pack | `[inferred]` bridge from motor work; `[generic]` that interviewers probe pet-specific drivers |
| G2 | Product recommendations (R8, important) | discovery | Underwriting recommendations presented quarterly. Product-side proposals not in the record | Shows whether the role reaches product decisions | Pricing changes proposed to product owners, even if declined | An excerpt from a pricing review deck | `[grounded]` user statement |
| G3 | Location and right to work (R1, hard_gate) | hard_gate | Not given | Gate cannot be checked until answered | — | Answered in the question below | `[grounded]` JD location term |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Recommendations without stated decision rights | risk_signal | medium | "turn the results into recommendations" | The role may propose rate changes that others approve | `[inferred]` from the JD's verbs against its silence on decision rights | When a price change comes out of this role, who decides it, and what sign-off does it need? | unresolved |
| RR2 | Salary and contract basis unstated | unknown | — | (no salary in the posting) | Pay may be below the market band, or the post may be fixed-term. Band not calibrated: no search was run | `[generic]` pattern for withheld pay; calibration not run | What is the salary band for this post, and is the contract permanent or fixed-term? | unresolved |
| RR3 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. Search was refused, so this is unverified, not found absent | `[generic]` pattern for companies of this size; not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR4 | Concrete outputs named | positive_signal | — | "build and monitor rating models, design and read price tests" | Scope is specific and measurable | `[grounded]` JD | Who else is on the pricing team, and what does it report into? | noted |
| RR5 | People management not stated | unknown | — | "Senior Pricing Analyst" | "Senior" may or may not include line-management | `[inferred]` from the title and silence on reports | Does this role line-manage anyone now, or is that planned within a year? | unresolved |

No `severity: high` entries.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with "Built and maintained the GLM rating model for the young-driver book," the 14 price tests, and the quarterly review to the head of underwriting | R4, R6, R7 | `[grounded]` user statements | pending your approval |
| P2 | Describe pet as an adjacent transfer, not experience: "Motor GLM rating and test design carry over; pet-specific drivers are new to me." | R5 | `[inferred]` from R5 | pending your approval |
| P3 | Before applying, find the live posting on Brindlemoor's careers page and confirm pay and contract basis with the recruiter | RR3, RR2 | `[generic]` hiring pattern | pending your approval |
| P4 | Ask RR1 and RR5 verbatim at first contact | Register doubles as interview preparation | `[grounded]` register | pending your approval |

Nothing above adds a claim the record does not hold. Pet experience is not claimed anywhere.

## Evidence status

Verified: none yet. Every claim so far is Renata's own statement and is unverified.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search for Brindlemoor's existence and live posting was refused by the host's permission setting. Would have moved RR3 and the contradictions row |
| 2. Role-family sweep | unavailable | Search for pay and scope norms for senior pricing analysts was refused. Would have set the market calibration line and RR2's band |
| 3. Hiring manager's public footprint | unavailable | Search for Odile Varga's public professional footprint was refused. A name was given, so the query could form. Would have set the scope read and which story to lead with |

## Upgrade menu

- Grant WebSearch permission and the three declared checks above run. They settle RR3 and set the market band for RR2.
- The live posting link from Brindlemoor's careers page. It closes RR3 or confirms it stays open.
- The budgeted salary and contract basis. RR2 closes, and the figure is set against the band.
- A sanitized pet-pricing artifact, or any non-motor pricing sample. R5 moves toward `high`.

I can also write this up as `tuesday-dossier.md` if you want it kept.

Q1 (R1, RR2) — What are your non-negotiables, covering location, right to work, minimum pay and contract type, so the hard-gate checks can run?

Q2 (RR1) — On your pricing work, did you set rates yourself, or recommend changes that others decided? Give one example and who signed it off.

Q3 (G1) — Have you priced or monitored anything with pet-like features (renewal-based or lifetime cover, claims driven by vet costs), or any non-motor product? If not, say skip.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.