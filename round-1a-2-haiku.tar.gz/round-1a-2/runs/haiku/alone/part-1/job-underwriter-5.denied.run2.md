**Yes, it's worth applying, with conditions.** Your core stack matches every must-have on paper. The open items are BigQuery, CRM ingestion, and data contracts, plus two checks I can't make from here: your own pay floor and location, and whether the posting is live.

Research tier: L1, with two searches refused, so the company's own pages were not checked.

**Decision snapshot**

**Worth applying, as a conditional go. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver office), R2 (salary band)
- `must_have` — direct: R3 (5+ years data engineering), R4 (SQL and Python), R5 (dbt and a cloud warehouse), R6 (Airflow or similar orchestration), R7 (data quality testing)
- `important` — adjacent: R8 (BigQuery-based warehouse) · unclear: R9 (ingestion from app and CRM), R10 (data contracts)
- `preferred` — none in the posting.

R3, R4, R5, R6, R7 — direct, all at `medium`, from your own account and the CV, not yet probed; R8 (`medium`) — transferable from Snowflake and dbt, BigQuery itself unused; R9, R10 — unclear until the questions below are answered.

**Opportunity ledger.** Pay sits near the market median (RR4), and the outputs are concrete. Against that: scope is wider than a typical single-domain Senior role (RR1), no hiring manager or team is named (RR2), posting liveness is unchecked (RR3), and the equity is unvalued (RR5). No severe red flags.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver office), R2 (salary band); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) your pay floor and location fit R1 and R2; (2) the posting is live on Pellucid's own careers page (RR3); (3) your BigQuery ramp holds up in interview (R8); (4) your CRM ingestion and contract-definition experience matches what the role needs (R9, R10).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, founded 2016, Denver, 264 staff, Series C ($52M, Feb 2026) | `[grounded]` pasted About page; not checked from here |
| Mandate | Build and run reporting pipelines: ingestion from app and CRM, dbt warehouse on BigQuery, data contracts for analysts | `[grounded]` JD |
| Scope read | Wider than the usual single-domain ownership for this title; ingestion, modelling and contracts are bundled | `[generic]` scope norm from the pay report, set against `[grounded]` JD text |
| Market calibration | Senior at Series B–D: base median $151,000, IQR $139,000–$163,500; posted $148k–$166k (midpoint $157k). This is a band, not this employer's offer | `[generic]` Datawright 2026 report, n=2,310, as provided by your recruiter |
| Unknowns | Team size, hiring manager, equity value and vesting, whether this is the only data engineer on reporting | — |
| Contradictions | None found between the JD and the pasted About page | `[grounded]` both pasted |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | No candidate location given | `[grounded]` JD; candidate location not given | Q3 |
| R2 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | Your pay floor not given | `[grounded]` JD | Q3 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at one payroll company; intake claim, not probed | `[grounded]` your account | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use; no artifact yet | `[grounded]` your account | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake; the JD names no specific warehouse | `[grounded]` your account | none |
| R6 | Airflow or similar orchestration | must_have | direct | medium | none | Airflow in production use | `[grounded]` your account | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` your account | none |
| R8 | dbt-modelled warehouse in BigQuery | important | adjacent | medium | transferability | dbt and cloud-warehouse work carries over; BigQuery never used | `[inferred]` transfer from Snowflake and dbt; `[grounded]` "never used BigQuery" | G1, Q1 |
| R9 | Ingestion from app and CRM | important | unclear | low | discovery | Ingestion experience is not described; CRM not mentioned | `[grounded]` your account silence | G2, Q2 |
| R10 | Data contracts analysts depend on | important | unclear | low | discovery | Tests exist; consumer-facing contracts not described | `[grounded]` your account silence | G3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery-specific work (R8, important) | transferability | Snowflake and dbt carry over; BigQuery's own cost, partitioning and access model unexercised | This is the stack the posting names for the warehouse | Any BigQuery sandbox; warehouse migrations; cost tuning on another platform | A sandbox build, or a migration note | `[grounded]` intake; `[inferred]` transfer |
| G2 | CRM ingestion (R9, important) | discovery | Ingestion from the product database is plausible from payroll work; CRM is not described | Named first in the responsibility list | Syncing a CRM into a warehouse; app-database extracts; owning a source's schema changes | A pipeline diagram or a connector config | `[grounded]` silence in your account |
| G3 | Data contracts (R10, important) | discovery | dbt tests and Great Expectations cover quality, not consumer agreements | "Our analysts depend on" implies consumer-facing guarantees | Schema-change notices, SLAs, owner sign-off with consumers | A contract or schema-change doc | `[grounded]` silence in your account |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Scope wider than typical single-domain ownership | risk_signal | low | "ingestion from our app and CRM, a dbt-modelled warehouse …, and the data contracts" | Could be one person accountable for three areas, or part of a team | `[generic]` scope norm from the pay report; `[grounded]` JD | Is this the only data engineer on reporting, or part of a team? Which of the three areas would I own alone? | unresolved |
| RR2 | No hiring manager or team named | unknown | — | Posting names no hiring manager | Team structure is unknown | `[grounded]` posting silence | Who would I report to, and how many data engineers are on the team? | unresolved |
| RR3 | Posting liveness and company facts unverified from here | unknown | — | Pasted About page and JD | The posting may be stale, or the company facts may be out of date | `[grounded]` posting and About page; searches refused | Is this requisition open and accepting applications now? | unresolved |
| RR4 | Pay at market | positive_signal | — | "$148,000–$166,000" | Pay is in line with the market median | `[grounded]` JD; `[generic]` band from the pay report | Is the base range final for this level? | noted |
| RR5 | Equity unvalued | unknown | — | "plus equity" | Total compensation is unknown | `[grounded]` JD | What are the grant size, vesting schedule and valuation? | unresolved |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the posting is live on Pellucid's own careers page before you apply | RR3 | `[grounded]` posting | for you to do |
| P2 | Lead with the Snowflake, dbt, Airflow and data-quality work as direct, and name BigQuery as unused | R5–R8 | `[grounded]` rows | proposed; positioning wording pending your approval |
| P3 | Prepare one sanitized artifact from the 180-model project (model graph or test-coverage summary) | Raises R3–R7 from `medium` toward `high` | `[grounded]` confidence bands | proposed; pending your approval |
| P4 | Ask RR1, RR2 and RR5 at the first screen, verbatim | The register doubles as interview prep | `[grounded]` register | proposed |

**Evidence status**

Verified: none yet. Your account is intake prose and stays at `medium`.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused, so the company's own pages were not checked. Would have settled RR3 and the employer facts |
| 2. Role-family sweep | skipped | Your recruiter's pay report already fixes the band and scope norm; no call sent |
| 3. Hiring manager's public footprint | n/a | No name given |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` file to carry into your prep.

**Upgrade menu**

- Allow web search: I would rerun target 1 (posting live, employer matches its About page) within the remaining L1 budget of 3 searches and 2 fetches.
- Any BigQuery work, even a small sandbox → R8 moves toward `direct`.
- A sanitized model graph or test-coverage report from the 180-model project → R3–R7 move toward `high`.
- Your pay floor and location → R1 and R2 close. The status is likely `go` if they fit, `no_go` if they don't.
- A named hiring manager or the team description → RR2 and the scope read.
- The equity grant terms → RR5 closes.

**Questions**

G1 (R8): Have you run anything on BigQuery, such as a sandbox, a side project or a migration, even small? If not, how quickly did you pick up a warehouse you hadn't used before?

G2 (R9): Have you built ingestion from a CRM (Salesforce, HubSpot or similar) or from a product's application database? Which tools did you use, and who owned the source?

Gates (R1, R2): Are you able to work remotely from the US, or from Denver? What is your minimum base salary?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.