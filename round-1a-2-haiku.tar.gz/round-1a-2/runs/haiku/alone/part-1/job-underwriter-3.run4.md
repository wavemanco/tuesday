**Decision: `no_go`.** Your feeling is right. The posting fails both of your hard constraints, so the fit on paper doesn't matter.

- **Hard gates, both failed:** Location, "On-site in our Austin office 5 days a week — no exceptions," against your remote-only requirement. Pay, "$70–85k base," against your $150k floor, which is $65k or more below it at the top of the range.
- **Fit (evidence map, on the candidate's side):** You match the 8+ years requirement directly. Paid, lifecycle, experimentation, SQL/GA4/Braze, and team leadership at 3–7 people are direct or adjacent. The $8M→$40M ARR scale-up is adjacent, since it was B2C subscription and this is B2B-leaning e-commerce enablement. Channel breadth (SEO, PR, brand, partnerships, sales ops) is partly adjacent, and "team of one" is the opposite of the team you've managed.
- **Opportunity (risk register, separate ledger):**
  - RR1, `risk_signal`, `severity: medium`: "evenings and weekends when it matters is just who we are" is an always-on expectation. Verification question: "What does a typical week look like in the first six months, including evenings and weekends?"
  - RR2, `risk_signal`, `severity: medium`: "team of one" under a Head of title, with "we believe in players who don't need a bench," is responsibility without stated resources across seven channels. Verification question: "What budget and headcount are committed to paid, SEO, lifecycle and sales ops in year one?"
  - RR3, `risk_signal`, `severity: medium`: "success metrics will evolve as we learn" on a mandate with no stated targets. Verification question: "What three numbers will define success at 6 and 12 months?"
  - RR4, `risk_signal`, `severity: medium` (standing entry, employer not established): I could not verify Novaline exists as described. See evidence status.
  - Compensation: the stated band is well under what a Head-level role with 8+ years normally pays. I did not check that band against current data, so treat it as an assumption, `[generic]`, not a finding. Equity is "meaningful" but unquantified.
  - Positive: "profitable since day one" is a claim worth checking, but it is unverified and not yet a signal.

**Hard gates:** failed: location (on-site Austin, 5 days, "no exceptions") and base pay (stated $70–85k against your $150k floor). Both are stated as terms, not left open.

**Why `no_go` and not `hold`:** A hold is for a failed gate that might move. The location line says "no exceptions," and the pay range is stated outright. The one thing that could change this is if the company has real flexibility on either term. Question 2 below asks about that.

**Evidence status**

Research tier: L0 — no searches; user links read 0

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | unavailable | Web search was not permitted in this session, so Novaline's existence and whether this posting is live are unverified. |
| 2. Role-family sweep (scope, title, pay) | unavailable | Same. Market calibration above is `[generic]` and from general pattern only. |
| 3. Hiring manager's public footprint | n/a | No hiring manager named in the posting. |

**Upgrade menu.** Each item is what the input would unlock:
- A link to the live posting, or the company's own careers page: would verify the employer and the posting (RR4), and show whether the pay and location terms match the copy.
- Recruiter messages, if any: would show whether pay or location is actually flexible, which is the only path back toward a hold.
- Web research, if you grant search permission: would verify Novaline and calibrate the pay band against current role-family data.

**Questions** (2 of 3 allowed)
1. Do you have the live posting link or Novaline's careers page? This is the quickest way to confirm the role is real.
2. Has anyone at Novaline said anything about flexibility on pay or on remote work? If the answer is yes, the status changes from `no_go` to `hold_pending_answers`.

A dossier file (`tuesday-dossier.md`) can be produced at the end of the engagement if you want a record of this assessment; say so and I'll write it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.