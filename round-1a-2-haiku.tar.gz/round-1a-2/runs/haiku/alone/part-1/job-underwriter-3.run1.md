**Decision: `no_go`.** The posting fails both of your hard constraints, so the strong paper match doesn't change the answer. Your sense that something is off is also grounded in the posting's own wording.

- **R1 and R2 fail:** the posted base is $70–85k against your $150k floor, and the role is on-site in Austin five days a week with "no exceptions" against your remote-only requirement.
- **What's off, in the text:** the pay sits far below what a Head-of-function scope with 8+ years of required experience usually carries. The role is "a team of one" with seven functions. The posting says evenings and weekends are "just who we are," that success metrics "will evolve," and that equity is "meaningful" but unquantified.
- **What isn't here:** nothing in the posting asks you for money, bank details, or personal information, so this is not a scam signal. It's a poorly matched role.

## Decision snapshot

- **Status:** No, not on these terms. R1 and R2 both fail, so `no_go`.
- **Fit ledger:**
  - *Hard gate:* R1 `hard_gate_fail`; R2 `hard_gate_fail`.
  - *Must-have:* R3, R4, R5, R6 `direct` (medium confidence each, CV-only).
  - *Important:* R10 `adjacent` (SQL and analytics carry over; no sales-ops ownership shown); R7, R8, R9, R11 `unclear` (no evidence either way).
  - *Preferred:* R12 `unclear`.
- **Opportunity ledger:** RR1 and RR2 are always-on and team-of-one signals; RR3 is the pay-to-scope mismatch; RR4 is the unquantified equity; RR5 is the undefined success metrics; RR6 is the employer, which I could not verify.
- **Hard gates:** `failed: R1 (base pay against a $150k floor), R2 (on-site Austin, five days a week)`; met: none. Candidate constraints were given, so no unknown flag applies.
- **Severe red flags:** RR3 (`severity: high`).
- **What would change this:** both gates would have to change. The role would need to be remote-eligible and pay at least $150k base. That is a different role from the one posted.

## Evidence map

| # | Requirement | Priority | Fit | Gap | Confidence | Provenance |
|---|---|---|---|---|---|---|
| R1 | Base pay at least $150k (your floor) | hard_gate | hard_gate_fail | hard_gate | high | `[grounded]` posting's own range |
| R2 | Remote-only, Portland | hard_gate | hard_gate_fail | hard_gate | high | `[grounded]` posting: "on-site… no exceptions" |
| R3 | 8+ years growth leadership | must_have | direct | none | medium | `[grounded]` your 9 years, two lead/head roles |
| R4 | Paid acquisition | must_have | direct | none | medium | `[grounded]` your stated ownership |
| R5 | Lifecycle/CRM | must_have | direct | none | medium | `[grounded]` your stated ownership; Braze |
| R6 | Revenue growth end to end | must_have | direct | none | medium | `[grounded]` $8M to $40M ARR, budget you controlled |
| R7 | SEO and content | important | unclear | discovery | low | `[grounded]` absent from your inputs |
| R8 | Brand and PR | important | unclear | discovery | low | `[grounded]` absent from your inputs |
| R9 | Partnerships | important | unclear | discovery | low | `[grounded]` absent from your inputs |
| R10 | Sales ops | important | adjacent | transferability | medium | `[inferred]` limit: no pipeline or CRM ownership shown |
| R11 | Running alone, without a bench | important | unclear | discovery | low | `[inferred]` your track record is building teams of 3–7 |
| R12 | Thriving on ambiguity, shifting metrics | preferred | unclear | discovery | low | `[inferred]` tiering from the posting's structure |

## Opportunity risk register

| ID | Signal | Class | Severity | Status | Provenance |
|---|---|---|---|---|---|
| RR1 | Always-on expectation: "evenings and weekends when it matters is just who we are" | risk_signal | medium | unresolved | `[grounded]` quoted |
| RR2 | Responsibility without resources: seven functions, team of one, no budget stated | risk_signal | medium | unresolved | `[grounded]` posting scope against its silence on budget |
| RR3 | Pay against scope and your floor: $70–85k for a Head-level role, $65k below your floor at the top of the range | red_flag | high | confirmed | `[grounded]` posting figure against your stated floor. Market band not checked (no search). |
| RR4 | Equity unquantified: "meaningful equity upside" with no grant, vesting or valuation | risk_signal | medium | unresolved | `[grounded]` quoted |
| RR5 | Accountability without definition: "success metrics will evolve as we learn" | risk_signal | medium | unresolved | `[grounded]` quoted |
| RR6 | Employer not established: research unavailable, so the employer and the posting's liveness are unverified | risk_signal | medium | unresolved | `[generic]` pattern for unverified postings |

Positive signal: the posting states Series A and profitability since day one. This is unverified and self-reported.

Verification questions, for the employer if you pursue it anyway:
- RR1: "What does a normal week look like for this role, and how often do evenings and weekends come up?"
- RR2: "What budget and headcount are committed to this role on day one?"
- RR3: "Is the $70–85k range fixed, and how was it set for a role with this scope?"
- RR4: "What is the equity grant size, vesting schedule, and current valuation basis?"
- RR5: "How will success be measured in year one, and who sets those targets?"
- RR6: "Can you point me to this role on Novaline's own careers page, and who would I interview with?"

## Gap recovery queue

No gap here is worth closing for this decision. R7–R9 and R11 are real gaps but do not change the status. The two gates decide it.

## Research tier and evidence status

Research tier: L1 — searches 1 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company's official site and careers page | unavailable | Web search permission was not granted in this session. One search was attempted and refused; no page was fetched. |
| 2 | Role-family sweep (title, scope, pay band) | unavailable | Same cause. No market calibration was run. |
| 3 | Hiring manager's public footprint | n/a | No hiring manager was named. |

## Application plan

None recommended under the current terms. If the posting later changes to remote with a base of at least $150k, the evidence map would reassess it.

## Dossier offer

If you want this carried into later work, I can write it to `tuesday-dossier.md`.

## Upgrade menu

- **A live posting link or Novaline's careers page:** verifies the employer (RR6) and whether the pay and on-site terms are current.
- **Search permission:** enables the role-family pay sweep (calibrates RR3 against market) and company checks (funding, leadership).
- **Equity terms:** would size RR4. It would not lift R1, which is a base-pay gate.
- **Deeper research (L2), offered once:** up to 5 more searches and 2 more fetches, once search permission is granted.

No questions this turn. Nothing I could ask would change the status, because both gates are stated firmly in the posting.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.