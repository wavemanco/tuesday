**Decision: `conditional_go`.** Yes, it's worth applying, as long as the posting checks out. Your must-haves are evidenced on your CV. The real gaps are BigQuery and two responsibilities the CV doesn't show: ingestion and data contracts.

- **Hard gates:** none failed; unconfirmed: R9 (Remote (US) or Denver office), R10 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Fit ledger:**
  - `hard_gate`: `unclear`: R9 (remote US or Denver office), R10 (salary range)
  - `must_have`: `direct`: R1, R2, R3, R4a, R5, R6
  - `important`: `adjacent`: R4b (BigQuery); `unclear`: R7 (ingestion from app and CRM), R8 (data contracts analysts depend on)
  - R4b is a bridge, not a match: Snowflake is shown, BigQuery is not. R7 and R8 are open because the CV is silent on them, not because it contradicts them.
- **Opportunity ledger:** The company's own About page describes a funded, mid-sized company (RR3, positive, unverified). The role's scope bundles four areas into one seat (RR1, low). The hiring manager, the live posting and equity are unknown (RR2, RR4).
- **Severe red flags:** none found.
- **What would change this:** For `conditional_go`, the conditions are: (a) the role is live on the company's careers page as written (RR2); (b) ingestion and contract ownership are real parts of the job that you can speak to (R7, R8); (c) your location and base floor fit R9 and R10. It drops to `no_go` only if R9 or R10 fails on your own constraints.

**Market calibration** `[generic]`: Datawright 2026 (recruiter-supplied, n=2,310, Series B–D): median $151,000, IQR $139,000–$163,500. The posting's $148,000–$166,000 (midpoint $157,000) sits at market, not above it. The equity figure is unquantified. This is a pattern from the report, not this employer's offer.

**Evidence map**

| # | Priority | Fit | Confidence | Gap | Requirement | Evidence and provenance |
|---|---|---|---|---|---|---|
| R1 | must_have | direct | medium | — | 5+ years data engineering | 6 years at a B2B payroll company `[grounded]` CV |
| R2 | must_have | direct | medium | — | Strong SQL and Python | Both daily `[grounded]` CV |
| R3 | must_have | direct | medium | — | dbt | ~180-model dbt project `[grounded]` CV |
| R4a | must_have | direct | medium | — | Cloud warehouse (JD's generic wording) | Snowflake `[grounded]` CV |
| R4b | important | adjacent | medium | transferability | BigQuery (named in the JD's responsibilities) | Never used `[grounded]` CV |
| R5 | must_have | direct | medium | — | Orchestration with Airflow or similar | Airflow `[grounded]` CV |
| R6 | must_have | direct | medium | — | Data quality testing | Set up a Great Expectations suite `[grounded]` CV |
| R7 | important | unclear | — | discovery | Ingestion from app and CRM | CV silent on sources `[grounded]` |
| R8 | important | unclear | — | discovery | Data contracts analysts depend on | CV silent `[grounded]` |
| R9 | hard_gate | unclear | — | hard_gate | Remote (US) or Denver office | Your location not given `[grounded]` |
| R10 | hard_gate | unclear | — | hard_gate | Salary $148,000–$166,000 | Your floor not given `[grounded]` |

**Gap recovery queue**
- **R4b (transferability):** The adjacent evidence is dbt, a cloud warehouse, and modelling at 180-model scale, all of which carry over. The limit is BigQuery's own operating model (cost and pricing, partitioning and clustering, access controls), which you haven't exercised `[generic]`. The strengthener is a small dbt project on BigQuery, or a clear account of which conventions you'd port and which you'd re-check.
- **R7 and R8 (discovery):** The question for each is in the closing block. What closes them is a concrete example of either.
- **R9 and R10 (hard gates):** Surfaced here. They're genuinely unknown, so they're asked, not worked around.

**Opportunity risk register**
- **RR1** — `risk_signal`, `low`: Ingestion, warehouse modelling, contracts and reporting in one seat. `[inferred]` from the JD's scope language. Verification question: "Is this the only data engineering seat, and which of these four areas does the role own versus share?" Status: unresolved.
- **RR2** — `unknown`: No hiring manager is named. Employer existence and posting liveness rest on the company's own pages only; I did not run an independent check. Verification question: "Who is the hiring manager, and where is the live posting on your careers site?" Status: unresolved.
- **RR3** — `positive_signal`: $52M Series C (February 2026), 264 employees, founded 2016, per the company's own About page `[grounded]`, self-reported. Verification question: "How much runway does the Series C give this data team's roadmap?" Status: unresolved.
- **RR4** — `unknown`: Equity is unquantified. Verification question: "What's the equity grant, vesting schedule, and current valuation basis?" Status: unresolved.

**Application plan (as far as evidence allows)**
- Lead with the four must-haves the CV evidences: dbt on Snowflake at 180-model scale, Airflow, Great Expectations, and daily SQL and Python.
- Address BigQuery directly in the application, as a bridge with its limit named, not as a gap you hope nobody asks about.
- Don't draft resume language yet. Any CV wording for this role is proposed and needs your approval before it's used.

**Research tier: L0 — no searches.** I ran this on the documents you provided. Your default is L1, which I haven't run because you haven't asked for it.

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company's official site and careers page (is the posting live, and does the entity match?) | skipped | L0 tier; not run |
| 2 | Role-family sweep (pay and scope for this seniority) | skipped | L0 tier; not run. The Datawright figures are the recruiter's, unchecked |
| 3 | Hiring manager's public footprint | n/a | No name given |

I can write up this assessment as `tuesday-dossier.md` for later use if you want to keep it.

**Upgrade menu**
- **Research at L1** (up to 5 searches and 2 page fetches): checks the live posting and employer footprint, and checks the role-family pay for this seniority at Series C-stage companies. Consent is yours; I haven't run it.
- **Your location and base floor:** settles R9 and R10, the two gates that can change the decision.
- **Equity terms:** settles RR4.
- **A BigQuery artifact** (even a small dbt project): would narrow R4b's limit.

**Questions**

R7 — Have you built ingestion from an operational app database or event stream, and from a CRM? Which tools, and roughly what volume?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R8 — Have you owned data contracts (schema, freshness or SLA promises) that downstream analysts relied on? What happened when one broke?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

R9 and R10 — Where are you based relative to remote-US or Denver, and what base-salary floor do you need?
Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.