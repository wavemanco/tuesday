## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.** (Evidence map: R1–R7)
- `hard_gate`: unclear: R6 (Bristol hybrid, two days a week in the office)
- `must_have`: direct: R1, R2, R3 · adjacent: R4, R5a · absent: R5b
- `important`: direct: R7

Your strongest case is R1–R3 and R7. The gaps are forecast ownership (R4) and billing or finance work (R5b). R5a is real revenue-data work but not billing data.

**Opportunity ledger.** (Risk register: RR1–RR4) The posting is specific about scope and pay, but it bundles revenue ops, billing data and forecasting into one role, and I could not check that the employer exists as described (RR2).

- **Hard gates:** none failed; unconfirmed: R6 (Bristol hybrid). Your pay floor and location were not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Confirm the employer and the role on Quillfield's own careers page or from the recruiter's email domain (RR2).
  2. Confirm whether the forecast is signed off by you or by finance, and whether you would have access to billing data (RR1, R4, R5b).
  3. Confirm the Bristol commute and the pay against your floor (R6).

## Research tier

Research tier: L0 — no searches; user links read 1

I read the posting you linked. I did not search for Quillfield, the recruiter's domain or Tamsin Achebe, so everything about the market and the employer below is either from the posting or labelled `[generic]`, and I give no market pay band.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organisation | Quillfield, invoicing software company (per you); posting sits on a job board, not an employer page | `[grounded]` posting; your description |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting for sales and finance; run the quarterly revenue forecast with the CFO | `[grounded]` posting |
| Working pattern | Bristol, hybrid, two office days a week | `[grounded]` posting |
| Pay | £61,500–£67,000 plus share options | `[grounded]` posting |
| Scope read | Three jobs in one title: revenue ops, billing-data stewardship and forecasting with finance | `[inferred]` from the mandate list |
| Market calibration | Not run; no L1 sweep | — |
| Unknowns | Who signs off the forecast; whether billing data is yours to change or only to read; reporting line; hiring manager's background | — |
| Contradictions | None found within the posting | `[grounded]` posting |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 4+ years in revenue, sales ops or analytics at a B2B software company | must_have | direct | medium | none | Five years in sales ops, two in revenue ops; the company is a B2B payments business, close to but not the same as software | `[grounded]` your CV summary | none |
| R2 | HubSpot or Salesforce administration | must_have | direct | medium | none | Salesforce admin certified; certificate not yet inspected | `[grounded]` your CV summary | Share the certificate to raise to high |
| R3 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly and Excel daily are stated; the depth of modelling is not shown | `[grounded]` your CV summary | Ask for one modelling example |
| R4 | Experience owning a forecast | must_have | adjacent | medium | transferability | You ran the monthly pipeline review, which feeds a forecast, but finance owned the forecast itself | `[inferred]` from your pipeline-review role | See G1 |
| R5a | Revenue data work | must_have | adjacent | medium | transferability | Renewal and pipeline dashboards are revenue data, not billing data | `[inferred]` from your dashboard work | None |
| R5b | Working with finance on billing or revenue data | must_have | absent | none | capability | You have never worked on billing data, and no finance collaboration is stated | `[grounded]` your statement | See G2 |
| R6 | Bristol hybrid, two office days a week | hard_gate | unclear | high | hard_gate | Your location and your in-office limits were not given | `[grounded]` posting; your location not given | Question 3 |
| R7 | Build pipeline and renewal reporting | important | direct | medium | none | You rebuilt pipeline and renewal dashboards | `[grounded]` your CV summary | None |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R4) | transferability | Pipeline review but no forecast | The posting says the role runs the forecast with the CFO | Any input you gave to forecast weighting, or any reconciliation of pipeline to actuals | A forecast or pipeline-review pack you produced | `[inferred]` |
| G2 | Billing and finance data (R5b) | capability | No billing work stated | Billing data is named in the mandate | Any reconciliation of renewals or pipeline against invoices | A sanitised reconciliation example | `[grounded]` posting and your statement |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Three jobs in one title: revenue ops, billing data and forecasting | risk_signal | medium | "own our CRM and billing data … run the quarterly revenue forecast with the CFO" | The role may be a finance-adjacent job with a revenue-ops title, or a finance role with a sales-ops title | `[inferred]` from the mandate list | Question 2 | unresolved |
| RR2 | Employer not established from attributable sources | risk_signal | medium | "Quillfield … Tallyboard Jobs" | Not verified from here; the posting is on a job board, and the page does not link to an employer page | `[grounded]` posting; the check was not run | Question 1 | unresolved |
| RR3 | Salary and share options stated | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is disclosed, so the comparison against your floor can be made | `[grounded]` posting | None | noted |
| RR4 | Forecast sign-off not stated | unknown | — | "run the quarterly revenue forecast with the CFO" | You may own the forecast, or only prepare it for the CFO | `[inferred]` from the posting | Question 2 | unresolved |

## Application plan

- **Lead with:** two years running revenue ops for the UK team, Salesforce admin certification, the pipeline and renewal dashboards you rebuilt, weekly SQL, and the monthly pipeline review with your sales director.
- **Position R4 honestly:** the pipeline review is an input to the forecast. Use that only if it is accurate for you; I am not drafting wording that claims forecast ownership.
- **Do not claim** billing-data work or forecast ownership. Those are the two places a hiring manager is most likely to probe.
- **Proposed CV edits:** none drafted yet. Any wording for the CV or a cover note needs your approval before it is used.

## Evidence status

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Quillfield official site and careers page | skipped | L0, no searches |
| 2 | Role-family sweep: scope, title and pay | skipped | L0, no searches |
| 3 | Hiring manager's public footprint (Tamsin Achebe) | skipped | L0, no searches; name given by the recruiter |

## Upgrade menu

- **Research (L1):** a check of Quillfield's careers page, a role-family pay and scope sweep, and a look at the hiring manager's public footprint. It would cost up to 5 searches and 2 page fetches. Say so and I will run it.
- **Your artefacts:** a forecast or pipeline-review pack would move R4 up; a sanitised billing reconciliation would address R5b; a certificate copy would confirm R2.
- **Missing inputs:** your pay floor and whether you can work in Bristol two days a week.

If you want, I can write this up as a `tuesday-dossier.md` file once the questions are answered.

**Questions**

1. **[RR2]** Can you share the Quillfield careers-page link or the recruiter's email domain, so the employer can be checked? Answer in text or say skip.
2. **[RR1, RR4]** Have you ever supplied forecast inputs, or reconciled pipeline or renewals against invoices or finance figures, even informally? Answer in text or say skip.
3. **[R6]** Where are you based, and what is your floor on pay and your limit on office days? Answer in text or say skip.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.