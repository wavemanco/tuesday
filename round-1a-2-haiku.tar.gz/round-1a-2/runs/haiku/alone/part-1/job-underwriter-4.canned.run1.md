**Worth applying to, on three conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R1 (Fully remote, UK location)
- `must_have`: direct: R2, R3, R4, R5, R6, R7
- `important`: adjacent: R8 (Recommendations for underwriting and product), R10 (Pet-insurance product)
- `preferred`: direct: R9 (Insurance experience)

R1 is a contradiction between sources, not a gate you fail. R10 is the one real limit: the six must-haves are direct on the CV, and the pet-product gap sits in an important row.

**Opportunity ledger.** The posting is live and consistent with the JD on the work itself, but its location conflicts with the careers page (RR1), and the material gives no pay or management scope (RR3, RR4). The hiring manager's public talk points at the same concern the role is about (RR5, positive). No severe red flags.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK location, contradicted by the careers page); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) location settled as remote, RR1 and R1; (2) pet-product transfer accepted after interview probing, R10; (3) pay checked against the band below, RR3.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; careers page is live for this role | `[grounded]` careers page, fetched |
| Mandate | Own pricing analytics for the pet-insurance product; build and monitor rating models; design and read price tests; recommend to underwriting and product | `[grounded]` JD |
| Reporting line | Reports to the Director of Pricing (Odile Varga) | `[grounded]` careers page and JD |
| Working pattern | JD: fully remote (UK). Careers page: Leeds office four days a week | `[grounded]` both, contradictory |
| Scope read | A normally scoped senior analyst post: one product, one reporting line, no stated team | `[inferred]` from the JD's listed duties |
| Market calibration | Senior pricing analyst, UK insurers and insurtechs: median £58,400, interquartile range £52,100–£64,900 (Pricewell 2026, n=612) | `[generic]` role-family pay survey; not this employer's offer |
| Unknowns | Base pay; whether the role manages anyone; which of the two locations is true; how new pet pricing is expected to be | — |
| Contradictions | Location: JD "Fully remote (UK)" against careers page "Leeds office four days a week" | `[grounded]` both sources |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (location) | hard_gate | unclear | none | hard_gate | JD says fully remote; careers page says Leeds four days a week. No candidate statement of this constraint was given, so there is nothing to grade | `[grounded]` both sources | Q1 below; RR1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two senior, at a UK motor insurer. CV only, no inspectable artifact | `[grounded]` CV | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both. CV only | `[grounded]` CV | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for a young-driver motor book. Motor, not pet | `[grounded]` CV | none |
| R5 | Build and monitor rating models | must_have | direct | medium | none | "Built and maintained" is the build half. Monitoring is not stated in those words | `[grounded]` CV; `[inferred]` that maintenance covers monitoring | Confirm monitoring work in interview |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team. CV only | `[grounded]` user answer | none |
| R7 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting. Actuarial audience not claimed | `[grounded]` user answer | none |
| R8 | Recommendations for underwriting and product | important | adjacent | medium | transferability | Underwriting recommendations are evidenced through the pricing review and price tests. Product recommendations are not | `[inferred]` from R6 and R7 | Name the limit in interview |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` CV | none |
| R10 | Pet-insurance product pricing | important | adjacent | medium | transferability | Motor rating and price testing carry over. No pet, small-book or non-motor pricing is in the material given. Limit: pet risk and lapse behaviour are untested | `[inferred]` from the JD's product and the CV's motor scope | Q2 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-product pricing (R10) | transferability | Motor pricing and price testing, no pet work | The one important row below `direct`. A credible bridge narrows the objection most likely in interview | Any non-motor pricing, a small or niche book, a product you rebuilt or re-rated, a rating factor you added for a new risk | A rating-factor paper, a price-test readout, a model-review note | `[inferred]` bridge from motor work; `[generic]` that pet risk differs from motor |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Location conflict between JD and careers page | unknown | — | "Fully remote (UK)" / "Leeds office four days a week" | The careers page may reflect a later hybrid policy, or the JD may be out of date | `[inferred]` from the two sources' conflict | Is this role fully remote as advertised, or based in Leeds four days a week as your careers page says? | unresolved |
| RR2 | Pet product new to the candidate's work | risk_signal | low | "Own pricing analytics for our pet-insurance product" | The role may expect early pet pricing fluency, with onboarding behind it | `[inferred]` from R10 | What does the first six months look like for someone new to pet pricing? | unresolved |
| RR3 | Pay not in the material given | unknown | — | (no salary in material) | Pay may sit at or near the survey band, or the posting may not state it | `[generic]` band; `[grounded]` absence of pay in the material | What is the base salary budgeted for this post? | unresolved |
| RR4 | Management scope not stated | unknown | — | (no reference to managing staff) | The role may or may not lead analysts; the candidate has never managed anyone | `[grounded]` absence; `[inferred]` that it matters to a senior post | Does this role line-manage any analysts now or later? | unresolved |
| RR5 | Hiring manager's stated interest matches the role | positive_signal | — | Talk "Small Books, Loud Errors" (2025 Insurance Pricing Forum), on monitoring rating models in small books | The manager's current concern is monitoring small books, which is close to the role's brief | `[grounded]` search snippet of the talk title; `[inferred]` on the link to the role | What did you learn about monitoring small books that you would want this role to act on? | noted |

Standing entry: employer not established does not apply. The Brindlemoor careers page is live and matches the JD. The search for "Brindlemoor insurtech pet insurance" returned nothing, so the company's public footprint beyond that page is not confirmed.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the location with the recruiter before investing in the loop | see RR1, R1 | `[grounded]` careers page and JD | pending your approval |
| A2 | Lead with motor price testing and presenting to underwriting, which are direct | R6, R7 | `[grounded]` CV and your answers | pending your approval |
| A3 | Name the pet limit yourself, with the bridge from motor, before the interviewer does | see R10, G1 | `[inferred]` | pending your approval |
| A4 | Ask RR5's question in the first interview; it shows you have read the manager's work | see RR5 | `[grounded]` talk title | pending your approval |

Each row is a proposal. Nothing here changes your CV until you approve it.

## Evidence status

Verified: none yet. Your answers are recorded at CV-equivalent standing until you confirm the extraction.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor careers Senior Pricing Analyst" and "Brindlemoor insurtech pet insurance" (no results). Fetched "Senior Pricing Analyst — Brindlemoor careers" (brindlemoor.co.uk/careers/senior-pricing-analyst). Moved the location contradiction (RR1, R1) |
| 2. Role-family sweep | yes | Searched "senior pricing analyst UK insurance salary GLM pricing", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example). Moved the market calibration line |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing", which returned a professional profile and the 2025 forum talk. Read from search snippets only; the pages were not fetched. Moved RR5 and the positioning in the application plan |

## Upgrade menu

- A current job listing or recruiter note that states the location and any management scope → R1 and RR1 close; RR4 closes.
- The budgeted salary → RR3 closes, set against the survey band.
- A rating-factor paper, price-test readout, or model-review note from motor work → R5 becomes `high`.
- Any pet, small-book or non-motor pricing work, even a side project → R10 moves toward `direct`.
- A deeper research pass on Brindlemoor (funding, leadership changes, staff reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

If you want the full dossier file written for this role, say so; it is offered once, and I will emit it on request.

Questions, tagged to their rows:

1. R1 — Is fully remote a must for you, or could you work from Leeds four days a week?
2. R10 — Have you priced any product outside motor, such as a small book, a niche line, or pet, even as a side project?
3. RR3 — What base salary would you need from this role, and is it a floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.