**Decision snapshot: `conditional_go`.** Renata fits the stated requirements well. The posting is unverified, the pay is unstated, and the pet-insurance gap is real but probably closable.

**Fit ledger** (per requirement, not a score)

- **Strong:** 4+ years pricing analytics (5 years, last 2 senior). Strong SQL and Python (daily). GLM experience (built and maintained a rating model). Presenting to underwriting leads (quarterly review with the head of underwriting). Insurance experience, a plus (UK motor).
- **Adjacent:** Running price tests with underwriting (14 last year). Fits the "design and read price tests" duty directly. The JD doesn't say what domain or tooling the tests use, so the fit is adjacent rather than strong.
- **Gap:** Pet-insurance domain. Renata has never worked on it. Not a listed requirement, but the role owns a pet product.
- **Unknown:** People leadership. The JD doesn't mention reports. Renata has never managed anyone, so this matters only if the role has them.

**Hard gates**

- Fully remote (UK): Renata's location and right to work in the UK aren't stated. Unverified, not failed.
- Pay: not stated in the posting. Unverified.

**Role reality**

- Scope: owns pricing analytics for one product, builds and monitors rating models, runs tests, makes recommendations to underwriting and product. Senior IC work on the JD's face. `[grounded]`
- Employer: "Brindlemoor (insurtech)." I have not checked that the company exists as described, its stage, or whether this posting is live. `[unverified]`
- Market calibration: not run. No research has been done.

**Evidence map**

| Requirement | Fit | Evidence | Confidence |
|---|---|---|---|
| 4+ yrs pricing/actuarial | Strong | 5 yrs UK motor pricing | High (stated, not verified) |
| SQL and Python | Strong | Daily use | High (stated) |
| GLM | Strong | Built and maintained a young-driver GLM | High (stated) |
| Present to underwriting/actuarial leads | Strong | Quarterly review, head of underwriting | High (stated) |
| Price tests | Adjacent to strong | 14 tests with underwriting | Medium (domain differs) |
| Insurance (plus) | Met | UK motor | High (stated) |
| Pet insurance | Gap | None | n/a |

**Gap recovery queue**

- **Pet-insurance domain.** Likely a transferability gap, not a capability one. Pricing a GLM, reading test results and presenting them don't depend on the product line, though pet claims behave differently (frequency, lifetime cover, vet-cost inflation). `[inferred]` Closing it means showing Renata can learn the domain. Renata can't claim pet experience she doesn't have.
- **People leadership.** Closes or stays open depending on the answer to the question below.

**Opportunity risk register**

- **Unverified employer.** Medium severity. This is why the decision is conditional. Verify with the live posting link, the company's careers page, or the recruiter's email domain.
- **Pay unstated.** Medium. The posting withholds it, which is worth a question.

**Application plan (as far as evidence allows)**

- Lead with the GLM ownership, the 14 tests and the presentations to underwriting. These are the parts of the JD Renata has done.
- Describe motor work by what it was: "UK motor pricing." Don't call it insurance-wide or imply pet experience.
- Frame pet as a domain to learn, not a claim. Any wording for a CV or outreach stays a proposal until Renata approves it.

**Evidence status**

Research tier: L0 — no searches. Only the posting and Renata's stated background were used. Nothing about Brindlemoor, its stage, pay or market norms is verified.

**Dossier offer:** If you want, I can save this assessment as a `tuesday-dossier.md` file for later use.

**Upgrade menu**

- **Research on Brindlemoor (L1):** up to 5 searches and 2 page fetches. Checks the company exists as described, whether the posting is live, and roughly what pay is normal for this seniority. Needs your consent.
- **Live posting link:** confirms the role and its wording.
- **Pay range or the recruiter's stated band:** turns the unknown pay gate into a real check.
- **Right-to-work or location confirmation:** closes the UK remote gate.

**Questions**

1. Does this role have direct reports? Renata has never managed anyone, and that changes the fit.
2. What is the pay range, and is it UK-based remote with no conditions?
3. Should I run the L1 company research (up to 5 searches, 2 fetches) to verify Brindlemoor before you decide?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.