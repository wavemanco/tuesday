**Decision: `no_go`.** Don't pursue this posting as written. Your fit is strong on paper, but two of your hard constraints fail on the posting's own terms, and no wording in an application can change either one.

**Decision snapshot**

- **Fit (your side):** Strong on experience. Your $8M→$40M ARR scale-up, paid/lifecycle/experimentation ownership, and SQL/GA4/Braze all map to the core of the role. The gaps are in SEO/content, brand, PR, partnerships, and sales ops.
- **Opportunity (role side):** Weak. Scope, pay, location, and culture all point the same way.
- **Hard gates failed:**
  1. **Base pay.** The posting says $70–85k; your floor is $150k. The gap is $65k–80k. [grounded]
  2. **Location.** Austin on-site five days a week, "no exceptions," against your remote-only requirement. [grounded]

Research tier: L0, no searches. The decision rests on the posting and your stated constraints, so research wouldn't change it.

**Evidence map**

| # | Priority | Fit | Gap | Requirement | Confidence |
|---|---|---|---|---|---|
| 1 | Must | Strong | none | 8+ years growth leadership | high (9 years, two companies) |
| 2 | Must | Strong | none | Own revenue growth, scaled impact | high ($8M→$40M ARR, budget you controlled) |
| 3 | Must | Strong | none | Paid acquisition, lifecycle/CRM, experimentation | high |
| 4 | Must | Strong | none | Analytics tooling (SQL, GA4, Braze) | high |
| 5 | Preferred | Partial | capability | SEO/content | low: not in your evidence |
| 6 | Preferred | Partial | capability | Brand, PR, partnerships, sales ops | low: not in your evidence |
| 7 | Must | Mismatch | hard_gate | Base pay | `$70–85k` vs `$150k` floor |
| 8 | Must | Mismatch | hard_gate | On-site, five days in Austin | remote-only, no relocation |

**Opportunity risk register**

| Class | Severity | Item | Basis |
|---|---|---|---|
| hard_gate | high | Pay is roughly half your floor | [grounded] posting vs your floor |
| hard_gate | high | On-site five days, "no exceptions" | [grounded] posting text |
| scope | high | Seven revenue functions for one person to start, "we believe in players who don't need a bench" | [grounded] posting text; [inferred] that this is under-resourced |
| culture | high | "Evenings and weekends when it matters is just who we are" | [grounded] posting text |
| scope | medium | "Success metrics will evolve as we learn" | [grounded] posting text; [inferred] unclear accountability |
| market | medium | Head-of-level title at $70–85k base is low for a Series A growth leader | [generic] pattern, not verified for this employer |
| verification | medium | Employer not verified; "profitable since day one" alongside a Series A is worth asking about | not-established (no research run) |

The title, the one-person scope, and the pay look like a senior generalist role relabeled as Head-level. That is an inference, not a finding.

**Application plan:** None. Don't apply to this posting as written. If a recruiter has already reached out, a short reply stating your $150k floor and remote-only requirement would screen it quickly. I can draft that for your approval, but I won't send anything.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | L0 run; decision doesn't depend on it |
| 2. Role-family comp and scope sweep | skipped | L0 run; the pay gap is already decisive |
| 3. Hiring manager footprint | n/a | No hiring manager named |

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` for your job search records.

**Upgrade menu**

- **L1 research (up to 5 searches, 2 page fetches):** verifies Novaline exists as described, checks funding and leadership churn, and gives a real comp band for this seniority. Would make the market and verification rows evidence-based instead of `[generic]`.
- **The live posting link or the company's careers page:** resolves whether the posting is current and consistent.
- **The recruiter's email domain, if one reached out:** helps confirm the employer.

**Questions**

1. Did this come from a recruiter or directly from the company? If you have the live posting link, please share it.
2. Has anyone at Novaline said the Austin requirement or the base pay is flexible? If so, that changes the gate read and I'll re-underwrite.
3. Do you want the L1 research run now to verify the company and the comp band?

Answer any, skip any, or say "run research" and I'll start it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.