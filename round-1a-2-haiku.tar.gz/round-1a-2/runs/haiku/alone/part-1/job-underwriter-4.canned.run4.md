## Decision snapshot

**Decision: `conditional_go`.** Apply, after three things are confirmed. Your requirement fit is strong. The open items are the role's scope, its pay, and whether the employer checks out, and none of those are about your skills.

- **Fit ledger (requirements, strongest first):** Met: 4+ years pricing analytics, GLM build and maintenance, SQL and Python, presenting to underwriting leads, price-test design and reading, UK motor insurance. Partial: turning results into product recommendations, and model monitoring in production. Not evidenced: pet-insurance domain.
- **Opportunity ledger:** The role is clearly scoped to pricing analytics. The posting gives no pay, no team size, and no reporting line. The employer is unverified because no research was run.
- **Hard gates:** Remote UK work and right to work are unknown; your location isn't stated. Pay is unknown; your floor isn't stated. No gate has failed.
- **Confidence:** Every fit row rests on your own account in this conversation. That is a lead to verify, not verified evidence, so the rows sit at medium confidence.

Research tier: L0, no searches. Brindlemoor, Odile Varga and the role-family pay band are unverified. Anything about them below is `[generic]` or comes from the JD.

## Role reality

- **Scope:** Senior individual-contributor analytics work: rating models, price tests, and recommendations. The JD says "own" but doesn't say whether that includes leading people. `[inferred]` from the JD wording, not stated.
- **Product:** Pet insurance is a new product line. Pricing rests on different drivers than motor, such as breed, age, and lifetime versus annual cover. `[generic]`
- **Market calibration:** A senior pricing analyst with 4+ years is a common title in UK insurance. Pay bands for this level are `[generic]`, and I haven't checked them.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence (your account) |
|---|---|---|---|---|---|---|
| 1 | 4+ years pricing or actuarial analytics | must-have | Met | medium | none | 5 years at a UK motor insurer, last 2 as senior analyst |
| 2 | Strong SQL and Python | must-have | Met | medium | none | Daily use in both |
| 3 | GLM experience | must-have | Met | medium | transferability to pet | Built and maintained the young-driver GLM |
| 4 | Presenting to underwriting or actuarial leads | must-have | Met | medium | none | Quarterly pricing review to the head of underwriting |
| 5 | Design and read price tests | must-have (named in responsibilities) | Met | medium | none | 14 tests last year with underwriting |
| 6 | Turn results into recommendations for underwriting and product | must-have | Partial | medium | presentation to product | Underwriting recommendations shown; product not described |
| 7 | Build and monitor rating models | must-have | Partial | medium | monitoring | Built and maintained; ongoing monitoring not described |
| 8 | Insurance experience | preferred | Met | medium | none | UK motor |
| 9 | Pet-insurance domain | implied | Not evidenced | n/a | transferability | No pet experience |
| 10 | Fully remote, UK | hard_gate | Unknown | n/a | location and right to work | Not stated |
| 11 | Pay against your floor | hard_gate | Unknown | n/a | comp | Pay not stated in the JD; floor not stated |
| 12 | Team leadership, if the role has reports | implied | Unknown | n/a | people management | Never managed anyone; JD silent |

## Gap recovery queue

- **Row 9 (pet domain, transferability):** Pet pricing uses the same GLM and test-design methods on different risk drivers. What would close it: a short account of any work on claims-frequency or severity modelling, or on non-motor lines, if you have it. Otherwise this stays a labeled gap, and the application should address it directly.
- **Row 6 (product recommendations, presentation):** What would close it: one example where a price-test result changed a product decision, even informally.
- **Row 7 (monitoring):** What would close it: how you tracked model performance after build, such as A/E checks or drift reviews.
- **Row 12 (people management):** Closes once the scope is confirmed. If the role has reports, the gap is capability, not presentation. Say that plainly in the application rather than implying experience you don't have.

## Opportunity risk register

- **Unverified employer (high):** I couldn't confirm that Brindlemoor exists as described. Resolve it with the live posting link, the company's careers page, or the recruiter's email domain.
- **Pay withheld (medium):** The JD doesn't state pay, and nothing here tests it against your floor. Ask the recruiter for the band before any interview.
- **Remote and right to work (medium):** Unconfirmed. If it fails, the role fails regardless of fit.
- **Scope mismatch (medium):** If the role includes managing people, your profile doesn't match it.

## Application plan

- **Lead with:** GLM build and maintenance, 14 price tests, and quarterly presentations to underwriting leadership. These map to the JD's most specific asks.
- **Address directly:** the pet-insurance gap, and the product and monitoring evidence in rows 6 and 7. Don't claim pet experience.
- **Proposed wording for any CV or outreach text stays unfinalized until you approve it.**

## Evidence status

Research tier: L0, no searches. No declared targets were run.

## Next step

Apply once the three questions below are answered. Set the decision to `go` if they all come back clear, or to `no_go` if the remote-UK or pay checks fail.

1. **Row 12:** Does the role manage people or lead a team, or is it individual-contributor work? (The JD doesn't say.)
2. **Row 11:** What is the pay band, and what is your floor?
3. **Row 10:** Where are you based, and are you eligible to work in the UK?

Research upgrade, if you want it: L1 would check whether Brindlemoor exists as described, pull a role-family pay band, and look at Odile Varga's public professional background. It uses up to 5 searches and 2 page fetches. Say the word and I'll run it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.