**Yes, it's worth applying, on three conditions. Status: `conditional_go`.** Your fit is strong on the core stack (dbt, Airflow, SQL, Python, data quality testing). The open questions are your location and pay floor, which I can't check because you haven't given them, and whether this role owns the CRM ingestion and data contracts.

**Fit ledger.**

- `hard_gate` — unclear: R9 (Remote (US) or Denver office), R10 (Salary $148,000–$166,000)
- `must_have` — direct: R1, R2, R3, R4, R5; adjacent: R6 (warehouse in BigQuery)
- `important` — unclear: R7 (Ingestion from our app and CRM), R8 (Data contracts our analysts depend on)

R1, R2, R3, R4 and R5 are direct at `medium`, self-reported and not yet backed by an artifact. R6 (`low`) — Snowflake modelling carries over, BigQuery is unused. R7 and R8 — discovery, your background is silent on both.

**Opportunity ledger.** The posting is consistent and the pay sits inside the market band (RR5, RR6 positive). Open items are the equity terms, the unnamed hiring manager, and who owns the contracts (RR1, RR2, RR4), plus a thin independent footprint for the employer (RR3).

- **Hard gates:** none failed; unconfirmed: R9 (Remote (US) or Denver office), R10 (Salary $148,000–$166,000); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) location eligibility for R9 confirmed; (2) the $148,000 floor, or your own floor, sits inside the posted range (R10); (3) CRM ingestion and data-contract ownership (R7, R8) confirmed as this role's scope in the first screen (RR1)

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` employer's about page |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled warehouse in BigQuery, data contracts for analysts | `[grounded]` JD, fetched from the careers page |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Scope read | Domain ownership of pipelines and contracts; no direct reports stated | `[inferred]` from the JD's responsibilities against its silence on reports |
| Market calibration | Senior Data Engineer at Series B–D companies: base median $151,000, IQR $139,000–$163,500; "Senior" usually means 5–8 years | `[generic]` Datawright 2026 report, from a search snippet, not fetched |
| Stated compensation | $148,000–$166,000 plus equity. The midpoint ($157,000) sits inside the IQR, above the median | `[grounded]` JD; band `[generic]` |
| Unknowns | Hiring manager, team size, equity terms, contract ownership, your location and pay floor | — |
| Contradictions | None. The careers page text matches the JD as provided. The posting is marked "Accepting applications" | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, self-reported; no artifact yet | `[grounded]` your background | Confirm dates in CV wording |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no artifact yet | `[grounded]` your background | A sanitized model or pipeline snippet would raise to high |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, a cloud warehouse; both halves met; self-reported | `[grounded]` your background | Sanitized model lineage would raise to high |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration; self-reported | `[grounded]` your background | Pipeline DAG overview would raise to high |
| R5 | Experience with data quality testing | must_have | direct | medium | none | Great Expectations suite set up; self-reported | `[grounded]` your background | Test-suite listing would raise to high |
| R6 | Warehouse in BigQuery (JD responsibility) | must_have | adjacent | low | transferability | Snowflake modelling carries over. Limit: no BigQuery use, so its tooling, cost model and SQL dialect are unexercised | `[inferred]` adjacency from the Snowflake work; `[generic]` that the platform switch is learnable | Gap G2 |
| R7 | Ingestion from our app and CRM | important | unclear | low | discovery | Background is silent on CRM ingestion | `[grounded]` JD; silence in your background | Gap G1, question Q3 |
| R8 | Data contracts our analysts depend on | important | unclear | low | discovery | Background is silent on data contracts | `[grounded]` JD; silence in your background | Gap G1, question Q3 |
| R9 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location wasn't given, so the check is unknown | `[grounded]` JD | Question Q1 |
| R10 | Salary $148,000–$166,000 | hard_gate | unclear | none | hard_gate | The posted range is given; your floor wasn't | `[grounded]` JD; band `[generic]` | Question Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion and data contracts (R7, R8, important) | discovery | Background names a warehouse and modelling work but not CRM ingestion or analyst-facing contracts | If you owned either, that is the strongest match for the posting's wording; if not, it's the main scope risk | Building source connectors or sync jobs for a CRM or product database; publishing a schema or contract that downstream teams depended on; setting SLAs or change-notice rules for a dataset | A contract document, a CRM sync DAG, a schema-change log (sanitized) | `[grounded]` JD; `[inferred]` that these decide the scope question |
| G2 | BigQuery warehouse (R6, must_have) | transferability | Snowflake modelling and dbt at scale; no BigQuery use | Named in the responsibilities, not in the requirement wording | Snowflake-to-other-warehouse work; cost or partitioning decisions on any cloud warehouse; any GCP project access | Any BigQuery-adjacent project, or a Snowflake model you can compare | `[inferred]` transfer from Snowflake; `[generic]` that the switch is learnable in weeks |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Contract and CRM ownership undefined | unknown | — | "the data contracts our analysts depend on" | This role may own pipelines while contracts are shared with analysts or other teams | `[inferred]` from the JD's list against its silence on ownership | Which data contracts would I own from day one, and which are shared with analysts or other teams? | unresolved |
| RR2 | No hiring manager or team size named | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Reporting line and team shape are unknown; a senior role without reports is typical for this title | `[generic]` typical scope from the pay report snippet; `[inferred]` from the posting's silence | Who would I report to, and how big is the data team? | unresolved |
| RR3 | Independent footprint thin beyond the employer's own site | risk_signal | medium | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states." | Small or young employers often have thin public footprints; the employer's own pages are the main attributable source found here | `[generic]` pattern for companies of this size, not a claim about this one | Who would I be interviewing with, and who signs the offer? | unresolved |
| RR4 | Equity terms unstated | unknown | — | "plus equity" | Equity may be a material share of total pay and is not sized | `[inferred]` from "plus equity" with no terms | What is the grant size, type and vesting schedule? | unresolved |
| RR5 | Posted base range sits inside the market band | positive_signal | — | "Salary $148,000–$166,000" | Pay is at market for this seniority, not below it | `[grounded]` posting figure against `[generic]` band (search snippet of the Datawright report) | Is this range the approved budget for the hire, or the band you hire within? | noted |
| RR6 | Concrete scope and funded stage | positive_signal | — | "Build and run the pipelines behind our tutoring platform's reporting" | Defined scope and a recently funded employer, so the role is probably real and funded | `[grounded]` JD and employer's about page (self-reported) | How many people are on the data team today, and what did the Series C fund? | noted |

No severe red flag was found: no request for money, deposits or bank details appears in the material.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm location (R9) and your pay floor (R10) with the recruiter before investing in the loop | Two unconfirmed gates | `[grounded]` gate rows | pending your approval |
| A2 | Put RR1 and RR2 to the employer in the first screen | Scope and reporting line | `[grounded]` register | pending your approval |
| P1 | Lead with the roughly 180-model dbt project on Snowflake and the Great Expectations suite; state plainly that BigQuery isn't used yet and that Snowflake modelling is the transfer case | R3, R5, R6 | `[grounded]` your background; `[inferred]` transfer | pending your approval; any CV wording goes to `resume_edits_pending_approval` |

## Evidence status

Verified: none yet. Your background is self-report, so every row above is a lead until you answer a probe about it.

Research tier: L1 — searches 2 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): posting live, text matches the JD as provided. Searched "Pellucid Learning live online tutoring K-12 Denver", which returned no results. Moved: role reality's contradictions row (none) and RR3 |
| 2. Role-family sweep | yes | Searched "senior data engineer salary Series B D company base pay 2026", which returned "Datawright 2026 Data Engineering Pay Report" (datawright.example/2026-data-engineering-pay-report) and the employer's about page. The report was read from its snippet, not fetched. Moved: the market calibration line, `[generic]` |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form. The upgrade menu names what a name would unlock |

Target 1 had one query return nothing and the rest returned only the employer's own pages. That is the source of RR3.

## Upgrade menu

- Your location and pay floor → R9 and R10 close, and the decision moves to `go` or `no_go`.
- A sanitized dbt model, a Great Expectations test list, or an Airflow DAG overview → R2, R3, R4 and R5 move to `high`.
- A CRM ingestion job or contract document you owned → G1 closes; R7 and R8 move from `unclear` toward `direct`.
- The full Datawright report, fetched → confirms the figures the search snippet and your recruiter gave.
- A named hiring manager → RR2 closes and the scope read sharpens.
- Deeper research on the employer (funding, leadership changes, public reports; up to 5 more searches and 2 more fetches) — offered once; say the word and it runs.

If you want this kept, I can write it to a `tuesday-dossier.md` file so a later interview-prep pass can pick it up.

**Questions:**

- R9 — Are you based in the US, and would fully remote work for you, or do you need the Denver office?
- R10 — What base-salary floor do you need to hold for this role?
- R7, R8 — Have you built CRM ingestion or owned data contracts that analysts relied on? If so, what did you own, and what broke or changed?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.