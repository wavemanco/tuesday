**Yes, apply.** Your core analytics requirements are direct matches. The gaps are mentoring, clinician partnership and healthcare data, and I could not verify the employer from here. Status: `conditional_go`.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0. All three searches were refused by a permission prompt, so no research ran.

## Decision snapshot

- **Status:** `conditional_go`. Apply once the posting is confirmed on Harborlight's own careers site (RR1).
- **Fit ledger.**
  - `must_have`: direct: R1, R2, R3, R4, R5, R6 (medium confidence on all, since the evidence is your own account); unclear: R8 (mentoring junior analysts)
  - `important`: unclear: R7 (partnering with clinicians)
  - `preferred`: adjacent: R9 (healthcare data, HIPAA)
- **Opportunity ledger.** The scope is specific and realistic for the title (RR5). The employer and live posting are unverified (RR1). Clinician involvement, mentoring load and regulated-data handling are unknown (RR2, RR3, RR4).
- **Hard gates:** none stated in the JD; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 verifies through Harborlight's own careers page; (2) RR3 shows mentoring is a real remit you can take on; (3) the healthcare experience is framed as consent and consumer-PII work, never as HIPAA experience.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning |
|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at a subscription company, as you stated. No artifact yet. |
| R2 | Expert SQL | must_have | direct | medium | presentation | Daily SQL on Snowflake. "Daily use" is not the same as "expert"; a sanitized query sample would show the level. |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year and an 11% retention lift from a pricing test. The result is strong but unverified. |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance from scratch with 40+ governed dashboards. Covers the self-serve dashboard work. |
| R5 | Own the metrics layer | must_have | direct | medium | presentation | Governed dashboards and the monthly metrics memo cover it, but the CV should name the metric definitions explicitly. |
| R6 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly memo read by the exec team; monthly presentations to the VP Product. |
| R7 | Partner with clinicians, not only PMs | important | unclear | low | discovery | PM work is evidenced. Clinician work is not in your account. |
| R8 | Mentor two junior analysts | must_have | unclear | low | discovery | Not in your account. Could be real, but there is nothing to inspect yet. |
| R9 | Healthcare data (HIPAA), a plus | preferred | adjacent | medium | transferability | GDPR/CCPA consumer PII and a consent-state model carry over. Limit: no PHI, no HIPAA controls, no clinical data. |

## Gap recovery queue

- **G1 — Mentoring (R8, transferability/discovery).** Nothing in your account shows managing or developing analysts. This is the largest gap against a `must_have`.
- **G2 — Clinicians (R7, discovery).** Your PM partnership is evidenced; clinician work is not.
- **G3 — Healthcare data (R9, transferability).** The bridge is consent and PII handling. The limit is that you have not handled PHI or worked under HIPAA controls.

## Opportunity risk register

| # | Signal | Class | Severity | Hypothesis | Verification question | Status |
|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified | risk_signal | medium | `[generic]` pattern for companies of this size, not a claim about this one: the posting may be stale or the employer may be small and not well indexed. | Which team does this role sit in, and who would I be interviewing with? | unresolved |
| RR2 | Clinician involvement unstated | unknown | — | `[inferred]` from the JD's "partner with clinicians" against its silence on how often | How often does this role work directly with clinicians, and which decisions do they inform? | unresolved |
| RR3 | Mentoring scope and team size unstated | unknown | — | `[inferred]` from the JD listing mentoring with no team context | How many analysts are on the team today, and what does mentoring look like in practice? | unresolved |
| RR4 | Regulated member data | risk_signal | low | `[inferred]` from the JD's HIPAA reference: analysts here likely work under access and review controls | What access controls and review process govern analysts' use of member health data? | unresolved |
| RR5 | Scope is defined | positive_signal | — | `[grounded]` the JD names specific deliverables: a metrics layer, self-serve dashboards, two mentees | What does success look like at 12 months for the metrics layer? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the posting on Harborlight's own careers page before applying | RR1 | `[grounded]` the posting is the only source so far | pending your approval |
| P2 | Lead with experiment design and the 11% result, with the cell-level detail ready | R3 | `[grounded]` your account | pending your approval |
| P3 | Present healthcare work as consent and consumer PII, not HIPAA | R9 | `[grounded]` your account; the framing is a choice | pending your approval |
| P4 | Prepare a specific mentoring story, or say plainly you have not mentored analysts yet | R8 | `[grounded]` your account (no mentoring stated) | pending your approval |

## Evidence status

Verified: none yet. Your claims are from your own account and have no artifact behind them.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both searches were refused by the permission prompt. Would have confirmed the employer and the live posting (RR1). |
| 2. Role-family sweep | unavailable | The search was refused. Would have set market calibration for title, scope and pay. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

## Upgrade menu

- A redacted Looker dashboard screenshot or a metrics memo excerpt → R4, R5 and R6 move toward `high`.
- A redacted readout of the 11% pricing test, or any experiment summary → R3 moves toward `high`.
- A sanitized query sample → R2 moves toward `high`.
- A link to the live posting or the careers page → RR1 closes.
- Permission for WebSearch → I can rerun the company check and the salary sweep, which would also let the market calibration line be written.
- Any mentoring, hiring or review example → R8 moves off `unclear`.
- Any clinician-facing work → R7 moves off `unclear`.
- Location, work authorization, schedule and pay floor → the hard-gate checks can run.

If you want, I can also produce a `tuesday-dossier.md` from this assessment, so the verification questions can carry into interview prep.

Questions:

1. **G1 (R8):** Have you ever managed, mentored, hired or reviewed analysts? If so, how many, and what did you own: goals, reviews, or onboarding?
2. **G2 (R7):** Has your work ever involved clinicians or other clinical-facing stakeholders, even indirectly?
3. **Constraints:** Do you have location, work-authorization, schedule or pay constraints for this role? The JD does not state location, so the hard-gate checks cannot run yet.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.