**Decision: conditional_go.** Apply only if you can answer Q1 with a yes. You're not wasting your time, but the must-have gap is real and a recruiter may screen on it before reading anything else.

**Fit ledger (candidate side, CV only):** Strong on technical fluency, stakeholder coordination, and partner discovery. Partial on shipped platform products and launch coordination. Gaps on the 3+ years of PM experience (must-have), adoption metrics, and roadmap ownership. Agile delivery is unstated, so it's unknown rather than a gap.

**Hard gates:** None stated in the posting. Location, authorization, level, and your pay floor aren't in what you gave me, so they're unchecked.

**Opportunity ledger (role side, [grounded] from the JD):** A specific, credible scope: a partner-facing API platform, two squads, and defined adoption metrics. The posting withholds compensation, which is worth knowing before you spend time on it. I haven't verified that Quartzline exists as described.

**Role reality:** For a Series B platform PM role, "3+ years PM" usually means owning priorities and shipping decisions, not just sitting near the product. [generic]

**Research tier: L0, no searches.** This is below the default. I didn't search this pass, so the employer is unverified. Evidence status:

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | L0, no searches run this pass; upgrade item 1 |
| 2 | Role-family sweep (title, scope, pay) | skipped | L0, no searches run this pass |
| 3 | Hiring manager's public footprint | n/a | No name given |

I also wrote this pass without loading the full reference set, so the fit labels below are plain words rather than the skill's enum values.

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Must-have | 3+ yrs PM experience | Gap | Medium | Transferability | No PM title. Product-adjacent years may count only if you held decisions. The posting says "experience", not title. |
| 2 | Must-have | Shipped API or platform products | Partial | Medium | Transferability | 30+ REST integrations end to end, but on the consumer side of a platform, not as its owner. |
| 3 | Must-have | Technical fluency (docs, schemas) | Strong | Medium (CV only) | None | REST integration architecture, OpenAPI, Postman, SQL. |
| 4 | Must-have | Stakeholder management | Strong | Medium | None | Coordinated vendor engineers, client engineers, and PMs on custom builds. No sales work stated. |
| 5 | Must-have | Agile delivery | Unknown | None | Discovery | Not on the CV. It may exist. |
| 6 | Responsibility | Own the roadmap | Partial | Medium | Transferability | Ran quarterly input sessions that fed product. No evidence you set priorities. |
| 7 | Responsibility | Partner discovery | Strong | Medium | None | Scoping workshops and client feedback sessions. |
| 8 | Responsibility | Specs and drive two squads | Partial | Medium | Transferability | Wrote requirements documents. Driving squad delivery isn't stated. |
| 9 | Responsibility | Define and track adoption metrics | Gap | None | Capability | No metric you defined or tracked. |
| 10 | Responsibility | Launches with sales and support | Partial | Medium | Discovery | You owned UAT and go-live. Sales and support coordination isn't stated. |

**Gap recovery queue** (what each gap is and what would close it)
- Rows 1 and 6: evidence of decisions you owned, such as a backlog, a prioritization call, or a feature you scoped and shipped. Closed by Q1.
- Row 9: any metric you defined or watched for an integration or tool. Closed by Q3 and by the triage tool in Q2 if it's real.
- Row 5: sprint or squad experience. Closed by Q3.

**Opportunity risk register**
- *Screen-out risk, high:* the "3+ years PM" line. Not a hard gate, since it names experience length, but it's a likely first-pass cut.
- *Unverified employer, medium:* no check run. Resolve with the live posting link or the company's careers page.
- *Compensation withheld, medium:* unknown fit against your floor.
- *Memory lead, not evidence:* the request-triage tool adopted by support agents. I can't use it until you confirm it.

**Application plan**
- Apply if Q1 returns owned decisions. If it doesn't, a closer title such as technical PM for integrations or implementation PM is the more honest target.
- Lead with the 30+ integrations as partner discovery, specs, and go-live, and say so plainly. Don't claim adoption you can't show.
- Proposed CV language, **pending your approval; nothing here is used until you approve it:**
  - "Led 30+ client REST API integrations end to end: discovery workshops, requirements, architecture, UAT, go-live."
  - "Turned quarterly client feedback into product roadmap input."
  - Don't use "product manager," "owned the roadmap," or "drove adoption" unless Q1–Q3 confirm them.

**Upgrade menu**
1. Research at L1 to confirm Quartzline's existence, level, and pay band. It costs up to 5 searches and 2 fetches.
2. The live posting link or the company's careers page.
3. The triage tool, if real: a description, who adopted it, and any usage numbers.
4. Your pay floor and location constraints.
5. A dossier file, so the evidence carries forward. I can produce a `tuesday-dossier.md` at the end of this engagement if you want one.

**Questions**
- **Q1:** Have you ever owned a backlog or made a prioritization call, even for one product area or custom-build workstream? What decided it, and what happened?
- **Q2:** Did you build the request-triage tool? Who adopted it, and what number showed that?
- **Q3:** Have you worked in sprints or on a squad with a PM role, and did you track any integration metric, such as time-to-go-live or activation?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.