**No, you're not wasting your time, but it's a stretch. `conditional_go`: apply on the conditions below, and go in with the titled-years gap named, not hidden.**

## Decision snapshot

**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**
- `must_have`: direct: R3 · adjacent: R1a (PM-type work), R2 (shipped products), R4 (partner discovery), R5 (two engineering squads), R7 (sales and support launches) · unclear: R6 (adoption metrics) · absent: R1b (3+ years PM)
- `important`: direct: R8 · unclear: R9 (agile delivery)

R3 and R8 are your strongest rows. R1b is the clear miss. R2 and R5 are real bridges with their limits named.

**Opportunity ledger.** The role is well defined: it names the roadmap, two squads and launch work (RR1, `positive_signal`). But it states no pay, no contract basis and no screen threshold (RR4), and I could not verify the employer (RR2).

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the 3+ years bar is tested with the recruiter (RR4); (2) the posting is confirmed on Quartzline's own careers page (RR2); (3) R6 gets an answer, either an adoption number or a clear no.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` your description; not checked online |
| Mandate | Own the roadmap for a partner-facing API platform; run partner discovery | `[grounded]` JD |
| Delivery | Specs and delivery across two engineering squads; launches with sales and support | `[grounded]` JD |
| Outcomes | None stated; the JD asks you to define and track adoption metrics | `[grounded]` JD, by absence |
| Scope read | Platform-owner scope, a normal size for the title | `[inferred]` from the JD's list of duties |
| Market calibration | Not established: no search ran, so no band for this title or seniority | — |
| Compensation | Not stated in the JD | `[grounded]` JD, by absence |
| Unknowns | Contract basis, pay, decision rights over what ships, whether 3+ years is a screen | — |
| Contradictions | None checked; no careers page was read | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | PM-type work: requirements docs, quarterly roadmap input | must_have | adjacent | medium | transferability | You wrote requirements and collected client input for product. Limit: no roadmap or ship decisions claimed | `[grounded]` CV | Q2 |
| R1b | 3+ years product management, titled | must_have | absent | medium | capability | You say you never held a PM title. Literal screen risk, see RR4 | `[grounded]` your statement | RR4 question |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST integrations shipped end to end, and the playbook the team uses. Limit: client integrations, not a partner platform product you owned | `[grounded]` CV | Q2 |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI, integration architecture. CV-only, so capped at medium | `[grounded]` CV | Upgrade menu: a schema you have reviewed |
| R4 | Discovery with integration partners | must_have | adjacent | medium | transferability | Scoping workshops and requirements documents. Limit: discovery was for one client's build, not a product roadmap | `[inferred]` bridge from CV | Q2 |
| R5 | Specs and delivery with two engineering squads | must_have | adjacent | medium | transferability | Requirements documents; coordinated vendor engineers, client engineers and PMs on custom builds. Limit: no sprint ownership stated | `[grounded]` CV | Q3 |
| R6 | Define and track adoption metrics | must_have | unclear | low | discovery | CV silent. A prior-context lead about a triage tool is unconfirmed and is not evidence | `[grounded]` CV silence; memory lead unconfirmed | Q1 |
| R7 | Launches coordinated with sales and support | must_have | adjacent | low | transferability | UAT and go-live coordination with clients. Sales and support coordination not stated | `[grounded]` CV | Q2 |
| R8 | Stakeholder management: engineering, sales, customers | important | direct | medium | none | 30+ client engagements; coordinated three parties on custom builds | `[grounded]` CV | none |
| R9 | Agile delivery experience | important | unclear | low | discovery | CV silent on sprints or agile process | `[grounded]` CV silence | Q3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Titled PM years (R1b) | capability | No PM title held | A numeric floor is often screened before anyone reads the CV | Roles where implementation-to-product work was the job | Recruiter's answer on the screen | `[generic]` screening pattern |
| G2 | Adoption metrics (R6) | discovery | No stated measure of usage or outcome | Must-have; an adoption number would move this row most | A tool or process you measured after it went live | Usage numbers; a sanitized one-pager | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Roadmap ownership and squads named | positive_signal | — | "Own the roadmap for our partner-facing API platform" | Scope is defined and the post has real authority | `[grounded]` JD | Which launch decisions does this role own alone? | noted |
| RR2 | Employer and posting not verified | unknown | — | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Not checked this session; the posting may be stale or may not match the company | `[grounded]` search refused | Can you point me at this role on Quartzline's own careers page, and who would I interview with? | unresolved |
| RR3 | Adoption measure not stated | unknown | — | "define and track adoption metrics" | Success may be undefined in year one | `[inferred]` from the JD's silence on targets | What adoption number is this role measured on in its first year? | unresolved |
| RR4 | 3+ years PM is a must-have | risk_signal | medium | "3+ years product management experience (must-have)" | A numeric years floor is often screened literally before a human reads the CV | `[generic]` screening pattern | Is the three-year product management requirement a hard screen, or would a strong platform lead from implementation work be considered? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the posting on Quartzline's careers page before investing | see RR2 | `[grounded]` RR2 | pending your approval |
| A2 | Ask the recruiter RR4's question before the loop | see R1b | `[grounded]` RR4 | pending your approval |
| E1 | CV line: "Ran quarterly roadmap-input sessions collecting client feedback for the product team" | Presents R1a without a PM title | `[grounded]` CV | pending your approval |
| E2 | CV line: "Wrote the internal integration playbook the whole team uses" | Shows R2 and R5 with no added claim | `[grounded]` CV | pending your approval |
| A3 | If the triage tool is real, get its usage numbers and a sanitized one-pager | see R6, G2 | `[grounded]` memory lead, unconfirmed | pending your approval |
| A4 | In interviews, say you have no titled PM record and describe the bridge with its limits | Avoids a screen you would fail later | `[generic]` interview pattern | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls were refused, so the posting and the employer were not checked. Would have moved the contradictions row and RR2 |
| 2. Role-family sweep | unavailable | Same refusal. Would have set the market calibration and RR4's band |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Dossier offer

If you want this kept for later interview prep, I can save it as `tuesday-dossier.md`.

## Upgrade menu

- Granting web search, or pasting Quartzline's live posting link → RR2 closes, the contradictions row fills, and the market calibration becomes `[generic]` from a real sweep.
- The triage tool's usage numbers or a one-pager → R6 moves from `unclear` to an inspectable row.
- The recruiter's answer on the three-year screen → RR4 closes, and the decision can simplify.
- A redacted requirements document or playbook excerpt → R2 and R5 move to a higher confidence.
- The hiring manager's name → the positioning for that reader.

## Questions

**Q1 (R6).** The request-triage tool in your notes: did you build it, how many support agents used it, and what measure moved (usage, time to triage, something else)?

**Q2 (R1a, R2, R7).** On the 30+ integrations, when a client asked for something outside the product plan, who decided whether it shipped? Did any of your input change a product decision, and who ran the sales and support handoffs at go-live?

**Q3 (R5, R9).** Have you worked in sprints or agile squads with an engineering team? What was your role in them?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.