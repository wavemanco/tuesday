I'll load the job-underwriter skill for this, and fetch the posting.
The posting is readable. Before building the assessment, I'll read the reference files the skill requires for the evidence map, risk register, and output format.
**Decision: conditional_go.** Apply, but confirm the employer exists and check the salary and location before you spend time on it.

**Snapshot**

- **Fit ledger** (per requirement, detail in the map below)
  - *Must, direct:* SQL, Salesforce administration.
  - *Must, adjacent:* 4+ years in RevOps or sales ops (years match; the company is a payments company, not software), revenue data work with finance (no billing data), CRM and billing ownership (CRM yes, billing no).
  - *Must, unclear:* spreadsheet modelling (Excel daily, but modelling isn't described), forecast ownership.
- **Hard gates:** none failed on the evidence. Two are unconfirmed: two days a week in the Bristol office (your location isn't stated) and the £61,500–£67,000 salary against your floor (not stated).
- **Confidence:** medium on the evidence you gave me. I did not verify the employer.

**Research tier: L0, no searches; user links read 1**

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | L0: no research run. Offered in the upgrade menu. |
| 2 | Role-family sweep (scope, title, pay) | skipped | L0: no research run. |
| 3 | Hiring manager's public footprint | skipped | L0: no research run. Name given: Tamsin Achebe. |

**Evidence map**

| # | Priority | Requirement | Fit | Gap | Confidence | Evidence |
|---|---|---|---|---|---|---|
| 1 | must | 4+ yrs RevOps/sales ops/analytics at B2B software co. | adjacent | presentation | medium | 5 yrs sales ops, 2 running RevOps; company is B2B payments |
| 2 | must | HubSpot or Salesforce admin | direct | none | high | Salesforce admin certified |
| 3 | must | Strong SQL and spreadsheet modelling | direct | discovery | medium | SQL weekly, Excel daily; modelling not described |
| 4 | must | Experience owning a forecast | unclear | discovery | low | Finance owned the company forecast; you run the monthly pipeline review |
| 5 | must | Experience working with finance on billing or revenue data | adjacent | transferability | low | Renewal and pipeline work; no billing data |
| 6 | implied | Owns CRM and billing data | adjacent | transferability | medium | CRM owned in practice; billing not |
| 7 | hard_gate | Bristol, two days a week in office | unclear | hard_gate | n/a | Your location not stated |
| 8 | hard_gate | £61,500–£67,000 plus share options | unclear | hard_gate | n/a | Your salary floor not stated |

**Gap recovery queue**

- **Row 4, forecast ownership.** The posting puts the quarterly revenue forecast with the CFO, which is the core of the role. Closing this needs evidence of contributing to a forecast, even if finance owned the final number.
- **Row 5, billing and finance data.** Closing this needs evidence of working with finance on bookings, invoiced revenue, renewals or ARR, even without billing-system access.
- **Row 3, modelling.** Closing this needs an example of a spreadsheet model you built, not just daily Excel use.

**Opportunity risk register**

- **Unverified employer (standing entry).** The posting is on an aggregator (tallyboard.example) and I could not check Quillfield's existence. This keeps the decision at conditional_go. To resolve it: the company's own careers page, or the recruiter's email domain.
- **Scope step-up.** The role owns the forecast and billing data, both beyond your current remit. Expect the interview to probe rows 4 and 5 directly.
- **Compensation and location.** Unknown until your floor and commute are stated.

**Application plan**

- Lead with the Salesforce admin certification, the pipeline and renewal dashboards, and SQL.
- For the forecast gap, describe the pipeline review you run as an input to forecasting only as far as that is accurate. Don't write "forecasting experience."
- Don't use "billing" or "forecast ownership" for anything you haven't done.
- Any CV wording goes to you for approval before use.

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` for the mock-interview skill if you want to prep for interviews later.

**Upgrade menu**

- **L1 research** (up to 5 searches, 2 fetches): confirms whether Quillfield exists as described, and gives the market pay band for this seniority to test £61.5k–£67k against. It also checks Tamsin Achebe's public professional background, within public professional sources only.
- **Your salary floor and location:** settles the two unknown hard gates.
- **A CV or portfolio:** I've worked from your description, not a CV. Any document would firm up rows 1, 3 and 6.

**Questions** (row IDs in brackets)

1. [Row 4] Have you contributed to any forecast, such as pipeline-to-forecast inputs, commit or best-case calls, or forecast accuracy reviews with your sales director, even if finance owned the final number?
2. [Row 5] Have you worked with finance on any bookings, invoiced revenue, renewal billing or ARR reporting, even without access to the billing system?
3. [Rows 7, 8] What is your salary floor, and can you commute to Bristol two days a week?

Answer any, skip any, or say "skip"; silence counts as an answer.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.