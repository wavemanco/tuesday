**Decision snapshot**

- **Status: `conditional_go`.** Apply, once the two hard gates below are checked against your own constraints. R1–R5, the must-haves, each read `direct` against your background. The open items are R7 and R8, which the posting asks for and your background doesn't show, and R6, the BigQuery transfer.
- **Fit ledger:**
  - `hard_gate`: R9 (`unclear`, location: Remote US or Denver); R10 (`unclear`, pay: $148,000–$166,000)
  - `must_have`: R1, R2, R3, R4, R5 (all `direct`)
  - `important`: R6 `adjacent` (BigQuery); R7 `unclear` (CRM ingestion); R8 `unclear` (data contracts)
  - Read: R7 and R8 are the rows that could move the decision. R6 is a ramp, not a gap in kind.
- **Opportunity ledger:** No red flags. RR1 (thin independent footprint) and RR2 (no hiring manager named) are unresolved. RR3 and RR4 are positive: the posting states its pay range, and the company reports a Series C.
- **Hard gates:** none failed; unconfirmed: R9 (location: Remote US or Denver), R10 (pay: $148,000–$166,000); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** Confirm R9 and R10 against your location and pay floor. Confirm or rule out CRM ingestion and data-contract experience (R7, R8). If R7 or R8 is absent and the team's scope rests on them, the status moves toward `hold_pending_answers`.

**Role reality**

- **Role:** Senior Data Engineer. Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, and the data contracts analysts depend on. Scope reads as one domain's pipelines. `[grounded]` from the posting.
- **Market calibration:** The posted range's midpoint ($157,000) sits above the $151,000 median and inside the $139,000–$163,500 interquartile range. The top of the range ($166,000) exceeds the upper bound. `[generic]`: Datawright 2026 pay report, US, n=2,310. The search returned the same figures, but at a `datawright.example` address, which I can't confirm as a real publisher. Treat it as the copy your recruiter sent.
- **Scope vs. seniority:** The 5+ year requirement and no direct reports match the report's "Senior" pattern (5–8 years, one domain). `[generic]`
- **Company:** The careers page is live and matches the posting. The About text (31 states, founded 2016, 264 staff, Series C, $52M, February 2026) appeared in a search snippet; I did not fetch that page. `[grounded]` from the company's own site. No independent press coverage turned up.
- **Unknowns:** hiring manager; team size; whether BigQuery work is expected from day one; whether CRM ingestion and data contracts are already built or greenfield.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | medium | none | 6 years at a B2B payroll company (CV) |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Both daily (CV) |
| R3 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project, about 180 models, on Snowflake (CV) |
| R4 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration (CV) |
| R5 | Data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite (CV) |
| R6 | BigQuery (in the posting body, not the requirement list) | important | adjacent | medium | transferability | Snowflake dbt work transfers; BigQuery specifics are unknown |
| R7 | Ingestion from app and CRM | important | unclear | low | discovery | Ingestion work is implied; CRM not named |
| R8 | Data contracts analysts depend on | important | unclear | low | discovery | Not in the background |
| R9 | Location: Remote (US) or Denver | hard_gate | unclear | n/a | hard-gate | Your location not given |
| R10 | Pay: $148,000–$166,000 | hard_gate | unclear | n/a | hard-gate | Your floor not given |

Confidence is medium on R1–R6 because these rest on your CV alone. Those claims hold up only if references or work samples confirm them.

**Gap recovery queue**

- **R6, transferability:** dbt on Snowflake carries over. BigQuery-specific operations (partitioning, cost controls, slot behavior) are not yet demonstrated. Closes with a BigQuery sandbox project or a short course, or with a plain, accurate statement of the ramp.
- **R7, discovery:** Unknown whether CRM ingestion was ever part of your work. Closes if you have done it, even partly.
- **R8, discovery:** Same. Data contracts are a specific practice. Closes only if you have done something you'd call one.
- **R9, hard-gate:** Closes when your location is compared against the remote and Denver terms.
- **R10, hard-gate:** Closes when your base floor is compared against the posted range.

**Opportunity risk register**

| ID | Signal | Class | Severity | Provenance | Verification question |
|---|---|---|---|---|---|
| RR1 | Independent footprint thin: one search returned only the company's own pages | risk_signal | low | `[generic]` for small-company pattern | "Who is the hiring manager, and how big is the data team?" |
| RR2 | Hiring manager not named | unknown | n/a | `[grounded]` from posting | "Who would I be reporting to, and who would I work with day to day?" |
| RR3 | Posted pay range stated, in band | positive_signal | n/a | `[grounded]` posting; `[generic]` band | None needed |
| RR4 | Series C, $52M, February 2026 | positive_signal | n/a | `[grounded]` company page | "What's the runway plan after this round?" |
| RR5 | CRM ingestion and data-contract ownership not described | unknown | n/a | `[grounded]` posting | "Is the data-contract work greenfield, and which sources does CRM ingestion cover?" |

The employer is attributable to the company's own site, so this is not the standing "employer not established" entry. RR1 keeps the decision at `conditional_go`, pending a check that the company is what it says it is.

**Application plan (as far as evidence allows)**

- **Lead with:** dbt at about 180 models on Snowflake, Airflow orchestration, and the Great Expectations suite. Those are the three stack items the posting names.
- **Address BigQuery directly:** something like "I've run dbt at scale on Snowflake; I expect a short ramp on BigQuery-specific operations." Don't write "BigQuery experience."
- **Don't claim:** data contracts or CRM ingestion, unless you confirm you've done them.
- **Resume edits:** none finalized. Any wording change needs your approval before it goes out.
- **Interview rehearsal:** mock-interview can take this from here.

**Evidence status**

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | yes | Queries: "Pellucid Learning online tutoring K-12 Denver" (no results); "Pellucid Learning" Series C funding (returned the About page). Fetched the careers page: live and matches the posting. |
| 2. Role-family sweep | yes | Query: "Datawright 2026 Data Engineering Pay Report". Result: `datawright.example/2026-data-engineering-pay-report`. Figures match your copy. |
| 3. Hiring manager footprint | n/a | No name given. |

Upgrade menu:

- **Your location and base floor:** settles R9 and R10, moving the gates from unconfirmed to met or failed.
- **Any CRM-ingestion or data-contract work, even partial:** settles R7 and R8.
- **Any BigQuery exposure:** a sandbox project or course would move R6 toward direct.
- **References or work samples:** would raise R1–R6 from medium confidence.
- **Hiring manager's name:** would let me check their public footprint for positioning.
- **Deeper research (L2):** funding and leadership churn, recent news, and public candidate reports, using up to 5 more searches and 2 more fetches. Say the word if you want it.

I can also prepare the full dossier file (`tuesday-dossier.md`) from this assessment, if you'd like it for later.

Questions (answer any, skip any; silence is an answer):

1. R9 and R10: Are you open to remote US only, Denver only, or both? And what's your base floor?
2. R7 and R8: Have you built or used a CRM ingestion feed or data contracts, even partially?
3. R6: Any BigQuery exposure at all, such as a sandbox, a course, or a side project?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.