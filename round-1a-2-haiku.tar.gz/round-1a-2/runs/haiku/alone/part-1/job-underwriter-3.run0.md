**No, not on these terms.** The pay and the location each fail one of your two hard constraints, and the posting says the location is non-negotiable. Status: `no_go`.

The evidence is strong on paper, but the two ledgers answer different questions and they don't offset each other. You fit the job's experience requirements. The posting itself fails your constraints.

**Decision snapshot**

**Status: `no_go`.** Your two constraints fail on the posting's own terms: base pay ($70–85k against your $150k floor) and location (Austin five days a week, "no exceptions", against remote-only). The only path is the employer changing both terms, and the posting rules that out.

**Fit ledger.**

- `hard_gate` — hard_gate_fail: R1 (base pay at least $150k), R2 (remote-only, Portland)
- `must_have` — direct: R3 (8+ years growth leadership), R4 (paid acquisition), R5 (lifecycle/CRM)
- `important` — unclear: R6 (SEO/content), R7 (brand, PR, partnerships, sales ops), R8 (team of one, no bench), R9 (thrive on ambiguity, evolving metrics)

R1 — pay fails: JD $70–85k is $65k–$80k below your floor; R2 — location fails: "no exceptions"; R3, R4, R5 — `medium`, from your account, not yet verified.

- **Hard gates:** failed: R1 (base pay at least $150k), R2 (remote-only, Portland); no gate rows met.
- **Severe red flags:** RR4 (`severity: high`), RR5 (`severity: high`).
- **Opportunity ledger.** The mandate is heavy and the terms are unclear: RR1 (seven functions for one person), RR2 (evenings and weekends), RR3 (success metrics undefined) are risk signals; RR6 (employer not verified) is unresolved. RR7 (profitable since day one, clear reporting line) is a positive signal.
- **What would change this:** both R1 and R2 would have to differ, meaning base at or above $150k and a remote or flexible location. The posting currently rules out both.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Novaline, e-commerce enablement, Series A, "profitable since day one" | `[grounded]` posting (not verified; see RR6) |
| Mandate | All revenue growth end to end: paid, SEO/content, lifecycle, brand, PR, partnerships, sales ops | `[grounded]` posting |
| Reporting | CEO, with a dotted line to the board | `[grounded]` posting |
| Team | "A team of one to start" | `[grounded]` posting |
| Compensation | $70–85k base plus equity | `[grounded]` posting |
| Market calibration | Not run. The role-family search was refused, so no band is available. The gap to your floor stands regardless | — |
| Unknowns | Actual success metrics, budget, what "when it matters" means in practice, whether the Austin rule has any exceptions | — |
| Contradictions | "Team of one" alongside "8+ years required" and seven functions | `[inferred]` from the posting's own text |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Base pay at least $150k (your floor; JD's pay line) | hard_gate | hard_gate_fail | high | hard_gate | Your constraint is specific and stated by you; the posting's $70–85k fails it | `[grounded]` JD pay line; your stated floor | None; only employer changing pay resolves it |
| R2 | Remote-only, Portland (your constraint; JD's on-site line) | hard_gate | hard_gate_fail | high | hard_gate | The posting says Austin five days a week, "no exceptions" | `[grounded]` JD line; your stated constraint | None; only employer changing terms resolves it |
| R3 | 8+ years growth leadership | must_have | direct | medium | none | Nine years, growth lead then Head of Growth at two B2C subscription companies; intake prose, so capped at `medium` | `[grounded]` your account | Artifact to raise to `high` (see upgrade menu) |
| R4 | Paid acquisition ownership | must_have | direct | medium | none | Owned paid; scaled one company $8M→$40M ARR with a budget you controlled | `[grounded]` your account | Same |
| R5 | Lifecycle/CRM | must_have | direct | medium | none | Owned lifecycle; deep in Braze and GA4 | `[grounded]` your account | Same |
| R6 | SEO/content | important | unclear | low | discovery | Nothing in your material either way | — | Gap G1 |
| R7 | Brand, PR, partnerships, sales ops | important | unclear | low | discovery | Nothing in your material either way | — | Gap G2 |
| R8 | Running growth as a team of one, "no bench" | important | unclear | low | transferability | You have built and managed teams of 3–7, not solo scope | `[inferred]` from your account | Gap G3 |
| R9 | Thriving on ambiguity; metrics that evolve | important | unclear | low | discovery | No evidence either way | — | RR3 |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | SEO/content (R6) | discovery | Not in your material | An explicit responsibility | Any content or organic programme you owned or shaped | A content plan or organic-traffic dashboard | `[grounded]` absent from your account |
| G2 | Brand, PR, partnerships, sales ops (R7) | discovery | Not in your material | Four functions outside your listed scope | Partnerships, PR, or sales-enablement work | A partner deal or PR outcome | `[grounded]` absent from your account |
| G3 | Solo scope (R8) | transferability | Team leadership, not solo | Shapes the first 90 days | Any period running growth with no team | A one-quarter plan with no reports | `[inferred]` from your account |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Responsibility without resources | risk_signal | medium | "Own all revenue growth end to end … You will be a team of one to start" | One person may be accountable for seven functions with no team or budget | `[inferred]` from the scope list against "team of one" | What budget and headcount are committed to this role in year one? | unresolved |
| RR2 | Always-on expectation | risk_signal | medium | "evenings and weekends when it matters is just who we are" | Off-hours work may be the norm, not the exception | `[grounded]` posting text | What does "when it matters" mean in a typical month? | unresolved |
| RR3 | Undefined success | risk_signal | medium | "success metrics will evolve as we learn" | Accountability with no stated definition of success | `[grounded]` posting text | What three numbers define success at six and twelve months, and who sets them? | unresolved |
| RR4 | Pay below your floor | red_flag | high | "$70–85k base plus meaningful equity upside" | Stated pay is roughly half your floor; equity does not change the base gate | `[grounded]` JD, against your stated floor; market band not verified (see RR6) | Is the $70–85k base final, and what is budgeted for this post? | unresolved |
| RR5 | Location rule | red_flag | high | "On-site in our Austin office 5 days a week — no exceptions" | The posting rules out your location | `[grounded]` JD text | Is any remote arrangement possible for a candidate outside Austin? | unresolved |
| RR6 | Employer not verified | risk_signal | medium | "Novaline (e-commerce enablement startup, Series A…)" | The employer's existence and the posting's liveness are unverified; this is a standing entry, not a finding that the employer is fake | `[generic]` pattern for early-stage employers; search refused, so unverified | Can you point me at the role on Novaline's own careers site, and who would I interview with? | unresolved |
| RR7 | Clear reporting and profitability | positive_signal | — | "profitable since day one"; "Report to the CEO with a dotted line to the board" | Clear authority line and a financially stable base | `[grounded]` posting text, unverified | What is the current team size and the year-one plan? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Don't apply on the posted terms | R1 and R2 fail your constraints | `[grounded]` JD | pending your approval |
| A2 | If you want to test it, ask the recruiter in writing whether base and location can move | Only a written change could reopen R1 and R2 | `[generic]` pattern | pending your approval |

**Evidence status**

Verified: your two constraints as you stated them (R1, R2). Your experience claims (R3–R5) stay at `medium` until you have an artifact. Unverified: the employer, the live posting, and the market pay band.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Three searches were refused (permission not granted), so Novaline's existence and the posting's status are unverified. Would have moved role reality's organization row and RR6 |
| 2. Role-family sweep | unavailable | Shared with target 1's refusals. Would have calibrated RR4 against a market band |
| 3. Hiring manager's public footprint | n/a | No name was given |

Dossier offer: I can write this up as `tuesday-dossier.md` if you want to keep it.

**Upgrade menu**

- Permission to run web searches, or the posting's link or the company's careers page pasted in: verifies the employer (RR6) and calibrates pay against the market (RR4). Pasted links are read without charge.
- A written reply from the recruiter on base pay or location: the only thing that could move R1 or R2 out of "fails" and change the decision.
- An artifact for R3–R5, such as a dashboard or a launch plan: raises those rows from `medium` to `high`. It matters only if the gates change.

Two questions, both tagged to their rows. Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

1. **R1 and R2:** Has Novaline said anything in writing, from the recruiter or the hiring team, that moves the $70–85k base or the Austin-five-days requirement?
2. **RR6:** Can you point me at the role on Novaline's own careers site, and who would I be interviewing with?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.