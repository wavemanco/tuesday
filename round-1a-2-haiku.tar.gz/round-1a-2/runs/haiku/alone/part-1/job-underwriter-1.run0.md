**Yes, apply, with conditions. Status: `conditional_go`.** You fit the analytics core of this role, and the gaps sit in its clinical and health-data parts. The employer is not yet verified, so confirm the live posting before you invest in the loop.

**Fit ledger.**

- `must_have` — direct: R1, R2, R3, R4, R6 · adjacent: R5 (metrics layer)
- `important` — direct: R9 · adjacent: R7 (partner with PMs) · unclear: R10 (mentor two junior analysts) · absent: R8 (partner with clinicians)
- `preferred` — adjacent: R11 (healthcare data, HIPAA)

R1–R4 and R6 are stated, specific and within your range, all at `medium` because nothing inspectable backs them yet. R5 is inferred from governed dashboards, not from owning a metrics layer.

**Opportunity ledger.** The scope is explicit, and the posting names outcomes and responsibilities (RR3 is not a risk). Two entries carry the weight: the employer is not established from attributable sources (RR1, standing entry), and the salary is withheld (RR2). RR3 is an unknown about whether the warehouse holds identifiable health data.

- **Hard gates:** none stated; candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the posting is live on Harborlight's own careers page (RR1); (2) the health-data and clinician scope holds up in interviews (RR3, R8, R11), and you describe it as adjacent, never as healthcare experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people, Series C | `[grounded]` JD header |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B test design and analysis, self-serve Looker dashboards, partnering with PMs and clinicians, mentoring two junior analysts | `[grounded]` JD |
| First-year outcomes | Not stated | — |
| Working pattern | Not stated | — |
| Scope read | A senior IC-plus-mentor role, with a defined analytics remit | `[inferred]` from the responsibility list |
| Market calibration | Not run: role-family sweep unavailable (see Evidence status) | — |
| Unknowns | Salary; location and work arrangement; reporting line; whether the warehouse holds PHI; how much clinician work is direct | — |
| Contradictions | None found within the JD; the posting was not checked against the company's own site | `[grounded]` JD only |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at one consumer-subscription company | `[grounded]` user-stated | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on a Snowflake warehouse; no query sample yet | `[grounded]` user-stated | sample query (upgrade menu) |
| R3 | Experiment design at scale | must_have | direct | medium | none | Designed and ran the program: 30+ tests a year, including the pricing test behind an 11% retention lift | `[grounded]` user-stated | sanitized readout (upgrade menu) |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the company's Looker instance from scratch; 40+ governed dashboards | `[grounded]` user-stated | dashboard screenshot (upgrade menu) |
| R5 | Define and maintain the metrics layer | must_have | adjacent | medium | transferability | Governed dashboards imply shared definitions; owning a metrics layer end to end is not claimed | `[inferred]` from R4 | metric dictionary sample — limit: not claimed as owned |
| R6 | Written communication to non-technical stakeholders | must_have | direct | medium | none | Writes the monthly exec metrics memo and presents it to the VP Product | `[grounded]` user-stated | memo excerpt, sanitized |
| R7 | Partner with product managers | important | adjacent | medium | transferability | Works with product leadership through the VP Product; day-to-day PM partnership not stated | `[inferred]` | G3 not asked; confirm in interview |
| R8 | Partner with clinicians | important | absent | none | discovery | No clinical or care-team stakeholders in the background | `[grounded]` silence | G2 |
| R9 | Turn analysis into roadmap decisions | important | direct | medium | none | The pricing test drove a product decision | `[grounded]` user-stated | test readout |
| R10 | Mentor two junior analysts | important | unclear | low | discovery | Not stated either way | `[grounded]` silence | G1 |
| R11 | Healthcare data experience (HIPAA) | preferred | adjacent | medium | transferability | Consumer PII under GDPR/CCPA; built the warehouse consent-state model. No PHI and no HIPAA controls | `[inferred]` | limit named: no PHI exposure |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring (R10, important) | discovery | Nothing on mentoring or managing people | Two named mentoring duties; an unclear one is a likely interview probe | Onboarding a new analyst on your Looker or SQL standards; reviewing a colleague's test analysis; running a learning group | A mentoring plan, feedback example, or onboarding doc | `[grounded]` silence; `[generic]` that this probe is common |
| G2 | Clinician partnership (R8, important) | discovery | No clinical or care-team work on record | Clinicians are named in the role; absent evidence on first pass is premature to call a capability gap | Analysis for an ops or customer-care team that had to act on results; any health-adjacent project, even informal | A stakeholder example or project brief | `[grounded]` silence |
| G3 | Health data and HIPAA (R11, preferred) | transferability | Consent and PII work carries over; PHI and HIPAA controls are not in it | Preferred, not a gate, but it is the likeliest objection | Consent-state modelling, data-subject request handling, access controls on sensitive fields | A sanitized consent-model summary | `[inferred]` bridge; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The posting may be stale or aggregated, or the employer may be too new for a footprint. This is unverified, not evidence of a fake | `[generic]` pattern for companies this size; `[grounded]` JD only | "Can you point me at this role on your own careers site, and who would I be interviewing with?" | unresolved |
| RR2 | Base salary withheld | unknown | — | Salary not stated in the JD | The figure may sit below the role-family band, or the company may not publish salaries | `[inferred]` from the posting's silence | "What base salary range is budgeted for this role?" | unresolved |
| RR3 | Health-data and HIPAA ownership unstated | unknown | — | "healthcare data experience (HIPAA) a plus" | The warehouse may hold PHI, and analytics may share compliance work | `[inferred]` from the JD's HIPAA reference | "Does the analytics warehouse hold identifiable health information, and who owns the HIPAA controls?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the Looker build and the experimentation program as outcomes, using only the stated facts | see R3, R4 | `[grounded]` user-stated | pending your approval |
| E2 | Describe the consent work as GDPR/CCPA consent modelling. Do not claim healthcare or HIPAA experience | see R11 | `[grounded]` user-stated; reframing audit: no added facts | pending your approval |
| A1 | Before the loop, get the live posting link, the salary range, the work arrangement, and whether the warehouse holds PHI | see RR1, RR2, RR3 | `[grounded]` register | pending your approval |
| W1 | A sanitized readout of one experiment, including the 11% result, as a work sample | see R3 | `[grounded]` user-stated | pending your approval |

## Evidence status

Verified: none yet. Your background is user-stated in this engagement; nothing is backed by an artifact.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Both search calls were refused permission in this session. It would have checked whether Harborlight exists as described and whether the posting is live (RR1) |
| 2. Role-family sweep | unavailable | Same refusal. It would have set the market band for salary and scope against this seniority (RR2, market calibration) |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Dossier offer

If you want this carried into later sessions, I can save it as a `tuesday-dossier.md` file.

## Upgrade menu

- Permission to use web search: the employer check (RR1) and the salary and scope sweep (RR2) both run. Both calls were refused this session.
- The live posting link from Harborlight's careers page → RR1 closes or stays open.
- A published or budgeted salary → RR2 closes, set against the band once a sweep runs.
- A sanitized experiment readout or the metrics memo → R3 and R6 move toward `high`.
- A sample metric dictionary or semantic-layer doc → R5 moves toward `direct`.
- Any health-data or clinician-facing work, even informal → R8 and R11 move.

## Questions

G1 — Have you mentored or managed junior analysts before? If so, what did you do, and how did they grow?

G2 — Have you worked with clinical or care-team stakeholders, or with data that held health information, even informally?

RR1 — Do you have a link to the live posting on Harborlight's own careers site?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.