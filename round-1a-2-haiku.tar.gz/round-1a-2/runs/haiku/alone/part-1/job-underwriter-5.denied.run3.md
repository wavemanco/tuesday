**Worth applying to, on conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R10 (location and work authorization for remote-US or Denver; your constraints weren't given)
- `must_have`: direct: R1, R2, R3, R4, R5, R6
- `important`: unclear: R7 (app and CRM ingestion), R8 (data contracts); adjacent: R9 (BigQuery)

The six must-haves are direct on your CV. The open items are ingestion, contracts, and BigQuery.

**Opportunity ledger.** Sound on the page, but under-specified. The posting gives no team size, no hiring manager, and no ownership boundaries for contracts or ingestion. Pay is disclosed and sits inside the market band. No severe red flags were found.

- **Hard gates:** none failed; unconfirmed: R10 (remote-US or Denver eligibility); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Confirm the posting is live on the company's own careers page, or through the recruiter's email domain. The employer is not verified (RR1).
  2. Confirm your location and work authorization against the remote-US/Denver terms (R10).
  3. Describe BigQuery as adjacent, never as experience you have. Confirm the stack with the recruiter before the loop (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C of $52M, February 2026 | `[grounded]` your about-page text. Not verified externally (see RR1) |
| Mandate | Build and run reporting pipelines: app and CRM ingestion, a dbt-modelled BigQuery warehouse, and data contracts for analysts | `[grounded]` JD |
| Scope read | Senior, with pipeline ownership and no stated direct reports. That matches the pay-report norm for the title | `[generic]` Datawright 2026 report, as you relayed it |
| Market calibration | Base median $151,000; IQR $139,000–$163,500 | `[generic]` Datawright 2026 report. Not checked against a live source |
| Compensation | $148,000–$166,000 plus equity. Midpoint $157,000, inside the IQR, above the median | `[grounded]` JD; comparison `[generic]` |
| Seniority fit | "Senior" typically means 5–8 years. You have 6 | `[generic]` pay report |
| Unknowns | Team size, hiring manager, contract ownership, whether this role owns ingestion, and BigQuery usage | — |
| Contradictions | None found in what you supplied. Public-web checks were refused, so none were run | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years data engineering | must_have | direct | high | none | Six years at a B2B payroll company, per your background | `[grounded]` your statement | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated. No artifact is attached, so CV-only | `[grounded]` your statement | optional: a code sample |
| R3 | dbt | must_have | direct | medium | none | A 180-model dbt project, built by you | `[grounded]` your statement | upgrade menu: a sanitized project structure |
| R4 | Cloud warehouse | must_have | direct | medium | none | Snowflake is a cloud warehouse. This meets the wording as written | `[grounded]` your statement | none |
| R5 | Orchestration (Airflow or similar) | must_have | direct | medium | none | Airflow, used for orchestration | `[grounded]` your statement | none |
| R6 | Data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite | `[grounded]` your statement | upgrade menu: a suite excerpt would raise this to high |
| R7 | Ingestion from app and CRM | important | unclear | low | discovery | Not in your background. The JD names it as a responsibility, not as a requirement | `[inferred]` from the JD's responsibilities | G1 |
| R8 | Data contracts that analysts depend on | important | unclear | low | discovery | dbt tests and GE checks are related, but you didn't describe contracts with consumers | `[inferred]` adjacency | G1 |
| R9 | BigQuery warehouse | important | adjacent | medium | transferability | Snowflake and dbt carry over directly. Limit: no BigQuery experience. Strengthener: a BigQuery sandbox project or a dbt-on-BigQuery test | `[grounded]` your statement; `[inferred]` transfer | G2 |
| R10 | Remote US or Denver | hard_gate | unclear | — | hard_gate | Your location and authorization weren't given | — | Question 2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion and data contracts (R7, R8) | discovery | Your background covers the warehouse and tests, not source ingestion or consumer contracts | Both are named in the JD's first sentence, so they will come up in the loop | Pipelines pulling from a product database, a CRM, or a billing system; any agreement on schema or freshness with downstream users | A pipeline diagram, a schema-change note, or a contract doc | `[grounded]` JD; `[inferred]` that these are probed |
| G2 | BigQuery (R9) | transferability | Snowflake and dbt carry over. No BigQuery exposure is stated | A hiring manager will probe platform-specific cost, partitioning, and IAM | Any BigQuery use, including a sandbox, or any work you have done on another platform's cost model | A sandbox project, a course, or a short migration note | `[inferred]` from the JD's platform; `[generic]` that this is a common probe |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified | risk_signal | medium | The employer details come from pages you pasted. The public-web checks were refused | The posting may be stale, or may not be the company's own | `[grounded]` the search refusal | Can you send the live posting URL, or the recruiter's email domain? | unresolved |
| RR2 | No hiring manager or team size named | unknown | — | (absent from the JD) | The team may be small, which would raise the ownership load | `[inferred]` from the JD's silence | Who is the hiring manager, and how many engineers are on the data team? | unresolved |
| RR3 | Ownership of contracts and ingestion undefined | unknown | — | "the data contracts our analysts depend on" | Contracts may sit with analysts, not the data team, which changes the scope | `[inferred]` | Who writes and approves the data contracts? | unresolved |
| RR4 | K-12 tutoring is a school-budget-dependent market | risk_signal | low | "live online tutoring for K-12 schools" | Revenue may track school budgets, which can make reporting-driven hiring volatile | `[generic]` sector pattern, not checked | How has revenue trended since the last round? | unresolved |
| RR5 | Pay disclosed and in band | positive_signal | — | "$148,000–$166,000 plus equity" | The range is in line with the market and transparent | `[grounded]` JD; `[generic]` band | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the live posting and the recruiter's domain before investing time | RR1 | `[grounded]` RR1 | pending your approval |
| A2 | Ask the recruiter about BigQuery use, team size, and contract ownership | R9, RR2, RR3 | `[grounded]` register | pending your approval |
| A3 | Apply, leading with dbt, Airflow, and GE. Describe BigQuery as adjacent, not as experience | R3, R5, R6, R9 | `[grounded]` evidence map | pending your approval |
| A4 | If true, surface any ingestion or contract work as a bullet, with its scope stated | R7, R8 | `[grounded]` CV gap | pending your approval |
| A5 | Build a small BigQuery sandbox project before the loop, and keep it to what you actually built | R9 | `[generic]` common hiring-loop probe | pending your approval |

Nothing above is a claim to send. Any CV or outreach wording needs your approval first.

## Evidence status

Verified: none yet. Your CV claims are your statements, not checked artifacts.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Would have confirmed the posting and the company facts (RR1). The search was refused by the permission prompt |
| 2. Role-family sweep | unavailable | Would have checked the pay-report band against live data. The search was refused by the permission prompt |
| 3. Hiring manager's public footprint | n/a | No name was given |

The pay-report figures are the ones you relayed. They are not independently checked.

## Upgrade menu

- The live posting URL or the recruiter's email domain → RR1 closes, and the decision can move to `go` if the other conditions hold.
- Your location and work authorization → R10 closes.
- A BigQuery sandbox or course → R9 moves from adjacent toward direct.
- A sanitized Great Expectations suite excerpt → R6 rises to high.
- A pipeline diagram showing source ingestion → R7 closes or is confirmed.
- The hiring manager's name → RR2 closes, and the application can lead with the story that fits that reader.
- Live research on the company and the market (up to 5 searches and 2 fetches, if you approve them) → verifies the company facts and the pay band.

I can also write this to `tuesday-dossier.md` if you want a file for the application, or you can take this as it is.

**Questions:**

1. **G1.** Have you built ingestion from a product database or a CRM into a warehouse, and did you own any contract with the analysts who consume the data? What was the scope and who used it?
   Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
2. **R10.** Where are you based, and are you authorized to work in the US? The role is remote-US or Denver.
   Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
3. **G2.** Have you used BigQuery at all, including a sandbox or a side project, or worked on another platform's cost model?
   Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.