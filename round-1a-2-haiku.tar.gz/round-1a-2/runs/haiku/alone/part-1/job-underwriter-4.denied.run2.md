**Yes, apply, on four conditions. Status: `conditional_go`.** The core of the JD matches your five years of motor pricing work closely. The open items are the pet-insurance domain, whether the role manages people, decision rights, and whether Brindlemoor exists as described. I couldn't check that last one: every web search was refused, so I worked from your message and the JD alone.

**Fit ledger.**

- `hard_gate` — unclear: H1 (UK remote location, right to work)
- `must_have` — direct: R1, R2, R3, R4, R5, R6, R7; adjacent: R8 (Pet-insurance product)
- `important` — unclear: R10 (People management)
- `preferred` — direct: R9

R8 — a credible bridge, its limit named; R10 — open until you know whether the role manages people; R1, R2, R3, R4, R5, R6, R7 — direct on your own account, awaiting an artifact.

**Opportunity ledger.** The mandate is defined and the requirements are specific (RR6). Decision rights (RR2), product maturity (RR3), pay (RR4) and line management (RR5) are unstated, and the employer is not established from here (RR1).

- **Hard gates:** none failed; unconfirmed: H1 (UK remote location, right to work); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) RR1: the posting and employer confirmed on Brindlemoor's own careers page; (2) RR5: no line management in year one, or the gap named openly; (3) RR2: decision rights concrete; (4) R8: the pet bridge framed as adjacent, never as pet expertise.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech with a pet-insurance product | `[grounded]` JD header and your message; existence not established (search refused) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` as you gave it; footprint not checked |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | A senior individual-contributor analytics role; the JD names no direct reports | `[inferred]` from the absence of any team language |
| Market calibration | Not run. Pay and scope norms for this seniority are unchecked | `[generic]` none — role-family sweep refused |
| Unknowns | Decision rights, team size, whether the pet model is new, pay, contract basis, line management | — |
| Contradictions | None within the JD. Not checked against a careers page | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Pricing or actuarial analytics, 4+ years | must_have | direct | medium | none | Five years, two as senior analyst, at a UK motor insurer. Confirmed by you; no artifact | `[grounded]` your statement | none |
| R2 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both. No artifact | `[grounded]` your statement | none |
| R3 | GLM experience | must_have | direct | medium | none | Built and maintained the GLM rating model for the young-driver book. Motor, not pet | `[grounded]` your statement | none |
| R4 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your statement | none |
| R5 | Build and monitor rating models | must_have | direct | medium | none | Same GLM work: built, maintained, monitored | `[grounded]` your statement | none |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your statement | none |
| R7 | Turn results into recommendations for underwriting and product | must_have | direct | medium | presentation | Underwriting recommendations are evidenced. Product-facing recommendations are not stated | `[grounded]` your statement | E1 (pending approval) |
| R8 | Pet-insurance product and its risk drivers (implied by "our pet-insurance product") | must_have | adjacent | medium | transferability | Same GLM and price-test mechanics carry over. No pet work; limit named in G1 | `[inferred]` from R3 and R6 against the product line | G1 |
| R9 | Insurance experience (a plus) | preferred | direct | medium | none | Five years at a motor insurer | `[grounded]` your statement | none |
| R10 | People management (not in the JD; implied by "Senior" and "own") | important | unclear | none | discovery | You have never managed anyone. Whether the role does is not stated | `[inferred]` from the title; `[grounded]` your statement | G2 |
| H1 | UK-based, with right to work, for a fully remote UK role | hard_gate | unclear | none | hard_gate | Your location and right to work were not in your message | `[grounded]` JD; your status not given | question below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product (R8, must_have) | transferability | Motor pricing carries over directly. Nothing touches pet claims, vet-cost inflation, or pet policy structure | The likeliest objection from the hiring side | Any non-motor product, a pet-adjacent pricing discussion, or a rating review where a new product's data was thin | A one-page note showing what transfers and what you would need to learn | `[inferred]` bridge from R3 and R6; `[generic]` that pet cost drivers differ from motor |
| G2 | People management (R10, important) | discovery | Your CV shows no management, and the JD doesn't say whether the role has any | If the role line-manages, this is the largest gap in the file | Leading a workstream, mentoring analysts, or running a review with others' sign-off | The team structure, from the posting or the recruiter | `[inferred]` from the title and "own" |

The queue holds no questions. Their questions are in the closing block.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved (search refused, not failed) |
| RR2 | Decision rights unstated | unknown | — | "Own pricing analytics ... turn the results into recommendations for underwriting and product" | Recommendations language suggests underwriting or product may hold sign-off, so ownership may be narrower than "own" implies | `[inferred]` from recommendations language against silence on authority | Which pricing decisions does this role make itself, and which need underwriting or product sign-off? | unresolved |
| RR3 | Pet model maturity unstated | unknown | — | "build and monitor rating models" | The pet rating model may be new, with thin claims history to calibrate | `[generic]` pattern for new product lines | Is the pet rating model being built new, and how much claims history exists to calibrate it? | unresolved |
| RR4 | Pay not stated | unknown | — | (none: the JD as given has no pay) | Pay may sit below the role-family band, or may simply not be published | `[grounded]` absence from the JD as pasted; `[inferred]` on what the absence suggests | What is the budgeted base salary for this post? | unresolved |
| RR5 | Line management possibly expected | unknown | — | "Senior Pricing Analyst" with "own" | A senior title can carry people management the JD doesn't list | `[inferred]` from title against the JD's silence | Does this role line-manage anyone, now or within its first year? | unresolved |
| RR6 | Requirements describe a defined mandate | positive_signal | — | "build and monitor rating models; design and read price tests" | The scope is concrete and measurable, and it mirrors your evidence closely | `[grounded]` JD | What does success look like for this role in its first year? | noted |

No `severity: high` entries. No payment or deposit requests appear in the material.

## Application plan

Every row is proposed. Nothing reaches your CV, outreach or application text until you approve it.

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Put the 14 price tests and the quarterly underwriting review into outcome bullets, using only outcomes you can evidence | see R6, R4, R7 | `[grounded]` your statement | pending your approval |
| W1 | A one-page bridge note: what carries from motor GLM work to pet, and what you would need to learn | see R8, G1 | `[inferred]` from R8; `[generic]` on pet cost drivers | pending your approval |
| Q1 | Ask RR1–RR5 verbatim in the interview loop; the register doubles as interview prep | see the register | `[grounded]` register | pending your approval |
| A1 | Confirm the posting on Brindlemoor's own careers page before you invest application effort | see RR1 | `[generic]` pattern | pending your approval |

## Evidence status

Verified: none yet. Every claim about you comes from your message and is not yet backed by an artifact.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Four searches for Brindlemoor and its posting were refused by the tool's permission check. Would have confirmed the employer, the live posting, and the pet product's stage. Feeds RR1 |
| 2. Role-family sweep | unavailable | Refused with the rest. Would have set the market band for senior pricing analysts in UK insurance, which bears on RR4 |
| 3. Hiring manager's public footprint | unavailable | A name was given, so the target is not `n/a`. Refused with the rest. Would have shaped which story to lead with for a Director of Pricing |

The four refused calls count toward the L1 budget, so one search remains. Without research, the remaining checks rest on what the JD says.

Dossier offer: When this settles, I can write the assessment up as a `tuesday-dossier.md` file for later use, if you want one.

## Upgrade menu

- Search permission for the three L1 targets → RR1 closes (employer and live posting); RR4 gets a pay band; the positioning for Odile Varga gets sharper. This would draw on the one remaining search and the two fetches.
- The live posting URL → RR1 closes directly.
- Brindlemoor's own product page or pet-insurance pricing material → R8 may move to adjacent-with-evidence.
- Any pet-related exposure, even a pet-adjacent pricing talk → R8 may move to direct.
- The budgeted salary → RR4 closes, set against the band.
- Your location and right-to-work status → H1 closes.

## Questions

RR5 — Does this role line-manage anyone, now or within its first year?

RR1 — Can you share the live posting link, or the URL of the role on Brindlemoor's own careers page?

H1 — Are you based in the UK with the right to work for a fully remote UK role, and is there a pay floor below which you wouldn't take it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.