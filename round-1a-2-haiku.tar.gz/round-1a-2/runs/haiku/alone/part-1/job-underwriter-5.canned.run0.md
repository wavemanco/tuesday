**Yes, worth applying to, on two conditions: `conditional_go`.** On your stated experience you meet all five must-haves, and the employer checks out as real and live. The gaps are BigQuery, which you can learn, and two responsibilities your background doesn't mention. Your location and pay floor were not given, so those checks are open.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3, R4, R5, R6, R7
- `important` — adjacent: R8 (a cloud warehouse, BigQuery); unclear: R9 (Ingestion from our app and CRM), R10 (Data contracts our analysts depend on)

R3, R4, R5, R6 and R7 — all five must-haves met on your stated experience; R8 — a credible bridge from Snowflake, BigQuery untested; R9 and R10 — absent from your background, so open until you answer.

**Opportunity ledger.** The employer is verified and the posted pay sits inside the market band, both positive (RR1, RR2). The reporting line, equity and contract type are unstated (RR3, RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 and R2 checked against your own location and pay floor; (2) R8 closed by a BigQuery sample or a credible plan before the technical round; (3) RR3 answered: who the role reports to, and whether these pipelines are yours end to end.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` about-page search snippet (not fetched in full); matches your pasted text |
| Mandate | Build and run the reporting pipelines: app and CRM ingestion, a dbt warehouse in BigQuery, data contracts for analysts | `[grounded]` JD, matches the careers page fetched |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD and careers page |
| Scope read | One domain (reporting pipelines), no direct reports stated: the usual Senior shape | `[inferred]` from the JD's single-domain wording |
| Market calibration | Senior base at Series B–D companies: median $151,000, IQR $139,000–$163,500. Posted band midpoint $157,000 sits inside the IQR. This is the market, not this employer's offer | `[generic]` Datawright 2026 report, supplied by your recruiter and not independently checked; `[grounded]` JD for the posted band |
| Unknowns | Reporting line; hiring manager; equity size; employment type; whether data contracts are net-new | — |
| Contradictions | None between the JD and the careers page | `[grounded]` careers page fetched |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | Your location constraint wasn't given, so the check is unknown, not met | `[grounded]` JD | Q1 |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Posted band is known; your pay floor isn't | `[grounded]` JD | Q1 |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company; prose intake is self-report, so medium is the ceiling | `[grounded]` your background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Both used daily; self-report | `[grounded]` your background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, a cloud warehouse | `[grounded]` your background | none |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow named directly | `[grounded]` your background | none |
| R7 | Experience with data quality testing | must_have | direct | medium | none | Set up a Great Expectations suite | `[grounded]` your background | none |
| R8 | Cloud warehouse, in practice BigQuery (named in the JD's responsibilities) | important | adjacent | medium | transferability | Snowflake modelling transfers; BigQuery-specific work (partitioning, cost, IAM) is untested | `[inferred]` from Snowflake work against the JD's named BigQuery | G1 |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | Your background doesn't mention app or CRM ingestion | `[grounded]` JD; silence in your background | Q2 |
| R10 | Data contracts our analysts depend on | important | unclear | low | discovery | Not in your background | `[grounded]` JD; silence in your background | Q2 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R8, important) | transferability | Snowflake and dbt at scale; no BigQuery | BigQuery is named in the responsibilities, so the first technical round may probe it | Any cloud-warehouse cost, partitioning or access-control work | A small dbt project on BigQuery, or a sanitized note comparing it with Snowflake | `[inferred]` bridge from your Snowflake work; `[generic]` that BigQuery is the likeliest probe |
| G2 | App and CRM ingestion; data contracts (R9, R10, important) | discovery | Nothing in your background | Two of the five responsibilities | Any app-event or CRM feed you've loaded; any schema agreement with a downstream team | A sanitized source-to-model contract, or an ingestion design doc | `[grounded]` JD; `[generic]` that these are commonly probed in interviews |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting verified | positive_signal | — | "Accepting applications" (careers page) | Live posting from an established employer | `[grounded]` careers page fetched; about page via search | Who is the hiring manager, and is this team hiring to grow or to replace? | noted |
| RR2 | Posted base inside the market band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is market-normal for Senior; equity is the open part | `[generic]` Datawright 2026 (supplied, not verified); `[grounded]` JD | Is the base band final, and how does equity compare at this level? | noted |
| RR3 | Reporting line and ownership not stated | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Ownership may be one domain with no direct reports, the usual Senior scope | `[inferred]` from the JD's single-domain wording; `[generic]` Senior norm | Who would I report to, and do I own these pipelines end to end or share them? | unresolved |
| RR4 | Equity size and employment type unstated | unknown | — | "plus equity" | Equity could be material to total pay; contract type unknown | `[grounded]` JD silence | What does the equity package look like, and is this a permanent full-time role? | unresolved |

Severe red flags: none. The employer-not-established entry does not apply, since the employer and posting are attributable.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm your location and pay floor against R1 and R2 before applying | Both hard gates are unchecked | `[grounded]` JD; Q1 | pending your approval |
| A2 | Write the BigQuery gap plainly: "dbt on Snowflake, about 180 models; new to BigQuery" | Honest framing for R8 | `[grounded]` your background | pending your approval |
| A3 | Build a small BigQuery dbt sample before the technical round | Gives R8 an inspectable artifact | `[generic]` common way to bridge a named tool | pending your approval |
| A4 | Ask RR3 and RR4 in the first screen | The unknowns decide the offer | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Unverified leads: none.

Research tier: L1 — searches 1 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Fetched "Senior Data Engineer — Pellucid Learning careers" (pellucidlearning.com/careers/senior-data-engineer): live, "Accepting applications", text matches the JD you pasted. Searched "Pellucid Learning live online tutoring K-12 Denver Series C", which returned "About Pellucid Learning" (pellucidlearning.com/about) with the company facts as you gave them; that page was not fetched. Moved: employer established, posting live, no standing entry triggered |
| 2. Role-family sweep | skipped | The Datawright 2026 pay report figures are already in hand and fix the market band, the Senior scope norm and the 5–8 year definition. No search sent |
| 3. Hiring manager's public footprint | n/a | No name given, so there was no query to form |

## Upgrade menu

- A small BigQuery dbt project or sanitized comparison → R8 gets an inspectable artifact; the BigQuery objection loses force.
- A sanitized example of app or CRM ingestion, or a data-contract doc → R9 and R10 move off `unclear`.
- Your location limits and pay floor → R1 and R2 are checked; the snapshot's "checks unknown" clears.
- The hiring manager's name → RR3's scope read sharpens, and the people-research target can run.
- Deeper research on Pellucid Learning (funding and leadership changes, hiring patterns, candidate and employee reports): up to 5 more searches and 2 more fetches. Say the word and it runs.

I can also write this assessment up as `tuesday-dossier.md` to keep on record.

**Q1 [R1, R2]:** Is remote-US or the Denver office workable for you, and is a $148,000 base at or above your floor?

**Q2 [R9, R10]:** Have you built ingestion from an app database or CRM, or set up data contracts with analyst consumers? If so, what did you build?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.