**Yes, worth applying, on conditions: `conditional_go`.** Your direct fit covers the core stack the posting names (R2, R3, R4, R6, R7, R10). The open items are BigQuery (R5), ingestion and data contracts (R8, R9), your location against the remote-US-or-Denver gate (R1), and whether the employer checks out (RR1).

## Decision snapshot

**Status: `conditional_go`.** Apply once the posting is confirmed live and the location gate is cleared. If you are outside the US and the role is US-only, this becomes `no_go`.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote US or Denver location)
- `must_have` — direct: R2, R3, R4, R6, R7, R10
- `important` — adjacent: R5 (BigQuery warehouse); unclear: R8 (ingestion from app and CRM), R9 (data contracts analysts depend on)

R5 is adjacent (dbt and SQL carry over; BigQuery itself is new). R8 and R9 are unclear because the CV is silent on them, not because they are absent.

**Opportunity ledger.** Sound on pay and location: the stated range $148k–$166k sits inside the market IQR and straddles the median (RR3), and the posting offers remote-or-Denver (RR5). Open items are employer verification (RR1), team and scope (RR2), and equity (RR4). No red flags.

- **Hard gates:** none failed; unconfirmed: R1 (Remote US or Denver location); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) R1 — your location and US work eligibility confirmed; (2) RR1 — the live posting confirmed on the company's own careers page; (3) R8 and R9 — ingestion and contracts answered honestly in the first conversation; (4) R5 — BigQuery stated as adjacent, never as experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 states; founded 2016, Denver; 264 employees; Series C, $52M, February 2026 | `[grounded]` pasted About page, not independently checked |
| Mandate | Build and run the pipelines behind reporting: ingestion from the app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts analysts depend on | `[grounded]` JD |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Compensation | $148,000–$166,000 base plus equity; equity unquantified | `[grounded]` JD |
| Scope read | Owns the reporting data path end to end: sources, warehouse, and contracts. Broader than the one-domain scope typical for the title | `[inferred]` from the JD's three-part mandate against the typical scope |
| Market calibration | Senior Data Engineer at Series B–D: base median $151,000, IQR $139,000–$163,500, 5–8 years typical. The posted range sits inside the IQR, and its midpoint ($157,000) is above the median | `[generic]` Datawright 2026 pay report as pasted; `[grounded]` JD for the posted range |
| Unknowns | Team size; hiring manager (none named); equity grant; US-location eligibility; employment type | — |
| Contradictions | None between the JD and the About page as pasted | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | low | hard_gate | Your location and work eligibility were not given, so the gate cannot be checked | `[grounded]` JD; candidate input absent | Q1 below |
| R2 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated but without an artifact | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, stated; no code sample yet | `[grounded]` your background | none |
| R4 | dbt and a cloud warehouse | must_have | direct | medium | none | dbt project of about 180 models on Snowflake, a cloud warehouse; the requirement as written is met | `[grounded]` your background | none |
| R5 | BigQuery warehouse (named in responsibilities) | important | adjacent | medium | transferability | dbt and SQL carry over; BigQuery itself never used. Limit: BigQuery-specific cost and partitioning decisions not exercised | `[grounded]` background states no BigQuery; `[inferred]` adjacency | G2 |
| R6 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration; ownership stated | `[grounded]` your background | none |
| R7 | Data quality testing | must_have | direct | medium | none | Set up the Great Expectations suite, stated | `[grounded]` your background | none |
| R8 | Ingestion from app and CRM (responsibility) | important | unclear | low | discovery | CV is silent on which source systems were ingested | `[grounded]` CV silence | G1 |
| R9 | Data contracts analysts depend on (responsibility) | important | unclear | low | discovery | CV is silent on contracts with downstream consumers | `[grounded]` CV silence | G1 |
| R10 | Build and run pipelines | must_have | direct | medium | none | Built and ran production pipelines at a B2B company, stated | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Ingestion from app and CRM; data contracts (R8, R9, important) | discovery | The CV shows orchestration and dbt modelling, not which sources were ingested or whether downstream teams relied on agreed schemas | These are the first two things the posting names; a real gap here changes how the role reads | Pulling from a CRM API or vendor export into a warehouse; handling schema changes from an upstream application database; a schema or freshness agreement downstream teams depended on, even informal | A pipeline diagram, a contract or schema doc, a schema-change incident note | `[grounded]` CV silence; `[inferred]` that this matters to scope |
| G2 | BigQuery (R5, important) | transferability | Snowflake and dbt at about 180 models; BigQuery never used | The posting names BigQuery in its first sentence, so an interviewer will probe it | Cloud-warehouse cost and partitioning decisions on Snowflake; any GCP work in earlier roles | A small BigQuery dbt project would strengthen the bridge; it counts as practice, not as experience | `[grounded]` background; `[generic]` that interviewers probe the named platform |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified | unknown | — | "Pellucid Learning runs live online tutoring for K-12 schools in 31 US states" | The posting may be live and accurate; this run could not confirm it. Web search was refused, so this is unchecked, not failed | `[grounded]` the pasted About page is the only source | Can you point me to this role on your careers page, and who would I be interviewing with? | unresolved |
| RR2 | Scope with no team or lead named | unknown | — | "Build and run the pipelines behind our tutoring platform's reporting" | Could be a solo platform role with no peers, or a lead role without the title | `[inferred]` from the three-part mandate against the silence on team size | How many data engineers work on this today, and who makes the warehouse design calls? | unresolved |
| RR3 | Pay stated and in market range | positive_signal | — | "Salary $148,000–$166,000 plus equity" | Pay is at market for the seniority; the midpoint sits above the median | `[grounded]` JD range; `[generic]` band from the pasted pay report | none needed | noted |
| RR4 | Equity unquantified | unknown | — | "plus equity" | Equity may be meaningful or token; the posting does not say | `[inferred]` from the posting's silence on grant size | What equity grant does this level receive, and on what vesting schedule? | unresolved |
| RR5 | Location flexibility | positive_signal | — | "Remote (US) or our Denver office" | Lowers the cost of applying from anywhere in the US | `[grounded]` JD | Is the remote role fully remote in the US, or does it expect periodic Denver presence? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Lead with the 180-model dbt project on Snowflake, Airflow ownership, and the Great Expectations suite | Matches R4, R6, R7 with what you have actually done | `[grounded]` background | proposed; needs your approval before use in any CV or outreach |
| A2 | Describe BigQuery as adjacent: "dbt and Snowflake; new to BigQuery" | Keeps R5 honest and avoids a claim the interviewer can test | `[grounded]` background states no BigQuery | proposed; needs your approval |
| A3 | Confirm the posting is live via the careers page before investing effort | Closes RR1 | `[grounded]` RR1 | proposed |
| A4 | Prepare an honest answer on source ingestion and contracts; if you lack them, name the closest real example and say so | Closes G1 | `[inferred]` from the posting's first sentence | proposed |
| A5 | Ask the recruiter whether this is a platform team and who the hiring manager is | Closes RR2 | `[inferred]` from RR2 | proposed |

No CV language is proposed yet. The reframing audit runs before any wording is used.

## Evidence status

Verified: none yet.

Unverified leads: the About page's figures (31 states, 264 employees, $52M Series C in February 2026) are pasted and unchecked.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent (Pellucid Learning company profile; Pellucid Learning data engineer careers). Both were refused by the session's search permission, so no result came back. Would have moved RR1 (employer existence and whether the posting is live) |
| 2. Role-family sweep | skipped | The pasted Datawright 2026 report already gives the median and IQR for this title and stage, which fixes the market calibration |
| 3. Hiring manager's public footprint | n/a | No name was given, so there is no query to form |

## Upgrade menu

- Your location and US work eligibility → R1 closes; if you are outside the US, the status becomes `no_go`.
- The live posting link or the careers page → RR1 closes.
- Answers on ingestion and contracts → R8 and R9 move up or down, and the decision may simplify.
- A BigQuery sandbox project or any real GCP work → R5 could move from adjacent toward direct. A sandbox counts as practice, not experience.
- The hiring manager's name or team size → RR2 closes, and the application plan can be tuned to that reader.
- Search access, if you grant it → the company-existence check runs at L1.
- A deeper diligence pass on Pellucid (funding, leadership changes, public reviews) would add up to 5 more searches and 2 more fetches. Say the word and it runs.

I can write this up as a `tuesday-dossier.md` so the analysis carries into later sessions, if you want it.

Three questions:

1. (R1) Where are you based, and do you need sponsorship to work for a US employer?
2. (G1) Have you ingested from a CRM or application database into a warehouse, or owned data contracts with downstream teams? If so, what did you build and who relied on it?
3. (G2) Have you used BigQuery in any form, such as a side project, a course, or a sandbox?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.