**Decision: `conditional_go`.** Worth applying, but only if the employer checks out and the forecast and billing parts of the role are scoped the way the posting implies.

**Fit ledger (candidate side)**
- `hard_gate`: unconfirmed: R1 (Bristol, two days a week in office). Your location and constraints weren't given, so checks against them are unknown.
- `must_have`: direct: R2, R3, R4, R5; adjacent: R6 (forecast ownership), R7 (finance-facing billing or revenue data).
- `important`: adjacent: R8 (owning billing data).

Your pipeline and renewal reporting, Salesforce admin, and SQL/Excel work match the posting closely. The two real gaps are forecast ownership and billing data, and the posting asks for both as requirements.

**Opportunity ledger (role side).** The posting is clear about scope: CRM and billing data, pipeline and renewal reporting, and a quarterly forecast run with the CFO. It is less clear about who owns the forecast model and where billing data sits (RR2, RR3). The salary is stated (£61,500–£67,000 plus share options) but I haven't checked it against market. The posting is hosted on a job aggregator (tallyboard.example), not Quillfield's own site, so the employer is unverified (RR1). No severe red flags found.

**Hard gates:** none failed; unconfirmed: R1 (Bristol, two days a week in office); candidate constraints not given — checks against them unknown.

**Conditions for go**
1. Quillfield is confirmed through its own careers site or a recruiter email from its domain (RR1).
2. The forecast is clearly scoped: you would own the pipeline-to-forecast process, with the CFO owning the model or sign-off, or you're comfortable with the gap (RR2).
3. Billing data scope is confirmed (RR3).
4. Bristol two days a week is workable for you.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Provenance |
|---|---|---|---|---|---|---|
| R1 | Bristol, hybrid 2 days/week | hard_gate | unclear | none | location not given | `[grounded]` JD; your location unknown |
| R2 | 4+ years RevOps/sales ops at B2B software company | must_have | direct | medium | payments vs software company type | `[grounded]` your background |
| R3 | HubSpot or Salesforce admin | must_have | direct | high | none | `[grounded]` Salesforce certified |
| R4 | Strong SQL and spreadsheet modelling | must_have | direct | medium | "modelling" not stated | `[grounded]` SQL weekly, Excel daily |
| R5 | Build pipeline and renewal reporting | must_have | direct | high | none | `[grounded]` rebuilt dashboards |
| R6 | Experience owning a forecast | must_have | adjacent | low | capability | `[inferred]` you run monthly pipeline review, never owned the forecast |
| R7 | Experience working with finance on billing or revenue data | must_have | adjacent | low | discovery | `[inferred]` revenue data via pipeline work, no billing data |
| R8 | Own CRM and billing data | important | adjacent | medium | capability | `[grounded]` CRM direct, billing absent |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question |
|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from its own site | risk_signal | medium | "Revenue Operations Lead, Quillfield" on tallyboard.example | The posting may be aggregated or stale, or the role may sit elsewhere | `[generic]` pattern for aggregator postings | Can you point me at this role on Quillfield's own careers site, and who would I be interviewing with? |
| RR2 | Forecast ownership unclear | unknown | — | "run the quarterly revenue forecast with the CFO" | The role may own the process but not the model | `[inferred]` from the scope wording | Who owns the forecast model, and what would this role own versus the CFO? |
| RR3 | Billing data scope unclear | unknown | — | "you will own our CRM and billing data" | The role may hold billing data as a reporting consumer, not as its system owner | `[inferred]` from the scope wording | Which billing systems does this role own, and who maintains the billing data today? |
| RR4 | Salary stated, not calibrated | unknown | — | "£61,500–£67,000 plus share options" | Not yet checked against the role-family band | `[generic]` no market search run this pass | Is the base fixed for this level, and how do the share options vest? |
| RR5 | Clear named responsibilities | positive_signal | — | "build the pipeline and renewal reporting" | Scope is defined | `[grounded]` JD | — |

**Application plan (proposed, pending your approval)**
- Lead with pipeline and renewal reporting and the Salesforce admin work. These are direct matches (R3, R5).
- Describe the monthly pipeline review as input to forecasting. Don't say you have owned a forecast or worked on billing data (R6, R7). That would overstate the record.
- Ask RR1–RR3 in the first recruiter call, before you invest in a full application.

**Evidence status**

Research tier: L0 — no searches; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Not run in this pass. Would confirm Quillfield exists and the role is live (RR1) |
| 2. Role-family sweep | unavailable | Not run in this pass. Would set the £61.5–67k band against market (RR4) |
| 3. Hiring manager's public footprint | unavailable | Not run in this pass. Tamsin Achebe's public background would inform positioning |

Verified: none yet. Claims used above come from the posting and your background as you stated it. Nothing has been checked externally.

**Upgrade menu**
- Running the research tier (L1): checks on Quillfield's own site, a salary band for this seniority, and Tamsin Achebe's public background. This would resolve RR1 and RR4 and sharpen positioning.
- An example of forecast input you produced (even a pipeline-to-forecast reconciliation) would move R6 from `low` toward `medium`.
- Any informal billing or invoicing data work, even reconciliations, would move R7 and R8.
- Your location and any non-negotiables would let the Bristol gate be checked.

If you want me to run the L1 research, say so and I'll do it.

**Questions**
1. (RR1) Can you point me at this role on Quillfield's own careers site, and who would I be interviewing with?
2. (RR2) Who owns the forecast model at Quillfield, and what would this role own versus the CFO?
3. (Hard gate R1) Where are you based, and can you do Bristol two days a week? Let me know if you'd rather skip this one.

Response modes: answer in text, paste a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.