**Decision: conditional go.** Apply. Your stack matches almost every requirement, and the one real gap (BigQuery) is a tool you can learn, not a missing skill. The condition is that you can speak to ingestion from a production app or CRM and to data contracts, since your background doesn't show either.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

**Decision snapshot**
- Fit: 5 requirements met, 1 transferable gap (BigQuery), 1 unknown (ingestion and data contracts).
- Hard gates: location (Remote US or Denver) is unknown for you. Your pay floor is also unknown. Neither is confirmed against the posting.
- Opportunity: no failed attribution. The employer exists as described and the posting is live.

**Role reality**
- Organization: Pellucid Learning, live online tutoring for K-12 schools in 31 states, founded 2016, Denver, 264 employees, Series C ($52M, Feb 2026). `[grounded]` from the company's about page (search snippet, not fetched).
- Posting: live on its careers page, text matches what you pasted. `[grounded]`
- Scope: owns pipelines for reporting, ingestion from app and CRM, a dbt warehouse, and data contracts. This reads as ownership of one domain with no direct reports. `[inferred]` from the posting wording.
- Market calibration: the posted range of $148k–$166k has a midpoint of $157k. The Datawright 2026 median for Senior Data Engineer at Series B–D is $151k, with an IQR of $139k–$163.5k. The posted range sits inside the band, a little above median. `[generic]` for the band; the posted figure is `[grounded]`.
- Equity: unquantified. The posting doesn't say what it's worth.
- Hiring manager: not named in the posting.

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap |
|---|---|---|---|---|---|
| 1 | 5+ years data engineering | must-have | meets | medium | none |
| 2 | Strong SQL and Python | must-have | meets | medium | none |
| 3 | dbt and a cloud warehouse | must-have | meets | medium | none (Snowflake, ~180 models) |
| 4 | Airflow or similar | must-have | meets | medium | none |
| 5 | Data quality testing | must-have | meets | medium | none (Great Expectations suite) |
| 6 | BigQuery (implied by the stack) | preferred | gap | — | transferability |
| 7 | App and CRM ingestion; data contracts | must-have | unknown | — | discovery |

Confidence is `medium` throughout because the evidence is your CV, which is a lead rather than verified proof. Row 6 is a gap because the posting names BigQuery explicitly. Row 7 is unknown because your background doesn't mention either ingestion work or contracts.

**Gap recovery queue**
- Row 6 (BigQuery): dbt and SQL skills carry over, and the warehouse concepts are close. What closes it is a short BigQuery project or a stated transfer story, not a new certification.
- Row 7 (ingestion and contracts): if you've built CRM or app-source ingestion, or defined schema contracts with analysts, that closes it. Naming those projects is enough.

**Opportunity risk register**
- Posting withholds the hiring manager. Low severity; normal for this type of listing.
- Equity is unquantified. Ask for detail before you accept any offer, not before you apply.
- Scope may be broad ("build and run" plus contracts plus ingestion). Confirm in the first conversation that it's one domain, not a whole platform.
- No red flags found in L1 research. Funding runway, leadership churn and recent news were not checked (that's L2).

**Application plan**
- Lead with the dbt-on-Snowflake build and the data-quality work, since those match the posting directly.
- Address BigQuery as a transfer, not a claim. Don't say you have used it.
- Prepare one specific example of ingestion or data contracts before the first call, if you have one.
- The resume edits are pending your approval. I haven't drafted any text for you to send.

**Evidence status**

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | yes | Fetched the careers page; the about page was confirmed from a search snippet. Query: "Pellucid Learning online tutoring K-12 Denver Series C". |
| 2. Role-family pay sweep | yes | Query: "senior data engineer salary 2026 US median dbt Airflow BigQuery". The Datawright snippet matched the figures your recruiter sent; the page itself wasn't fetched. |
| 3. Hiring manager footprint | n/a | No hiring manager named. |

**Dossier offer:** I can write this up as a `tuesday-dossier.md` file for later use if you want it.

**Upgrade menu**
- Your home location against the Remote-US-or-Denver requirement would settle the hard-gate row.
- Your pay floor would show whether the posted range clears it.
- A link to a BigQuery project, or any ingestion or contracts work, would move rows 6 and 7 from gap to evidence.
- Deeper company research (funding, leadership churn, recent news) is available: up to 5 more searches and 2 more fetches. Say if you want it.

**Questions**
1. Where are you based? That decides whether the Remote-US option works for you or whether Denver is the only realistic route.
2. Have you built ingestion from a production app or CRM, or defined data contracts analysts relied on? Even a single project counts.
3. What is your pay floor, and how much does the equity matter to you?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.