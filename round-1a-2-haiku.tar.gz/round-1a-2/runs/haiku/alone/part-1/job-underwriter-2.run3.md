**Decision snapshot**

Applying is not a waste of time, but only if two things check out: the posting is real, and the "3+ years product management" must-have is not a literal screen. Your title gap is real, and it is the first thing a recruiter will check. `conditional_go`

- **Fit ledger.**
  - `must_have`: direct: R3, R5 · adjacent: R1b (roadmap ownership), R2 (shipped API or platform products), R4 (stakeholder management), R6 (specs and squad delivery) · absent: R1a (3+ years PM experience)
  - `important`: adjacent: R9 (launch coordination) · unclear: R7 (agile delivery), R8 (adoption metrics)

  R5 — partner discovery, direct and your strongest bridge; R3 (`medium`) — technical fluency, CV-stated; R2 (`medium`) — integration-level, not product-level; R1a (`none`) — no PM years in the material.
- **Opportunity ledger.** The scope is concrete (RR5), but decision rights (RR3), pay (RR4) and the experience screen (RR2) are unstated, and the employer is not yet established (RR1, a standing entry that caps the decision at `conditional_go`).
- **Hard gates:** `none stated`; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** (1) RR1 clears: the employer exists and the posting is live on its own careers page. (2) RR2 comes back flexible, or platform-ownership work counts toward it: the status holds. If it is literal and you have no PM years, the case weakens toward `no_go`. (3) RR3 and RR4 come back concrete. (4) Your answer to G1 shows you decided what shipped, not only what was requested.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics-tech, ~150 people, Series B | `[grounded]` your JD header; not verified (searches refused, see Evidence status) |
| Mandate | Own the roadmap of the partner-facing API platform; partner discovery; specs; drive two engineering squads; define and track adoption metrics; coordinate launches | `[grounded]` JD |
| Scope read | Owning a platform with two squads is a substantial product remit, and the 3-year line suggests a mid-level PM | `[inferred]` from the must-have years line against the scope |
| Market calibration | Not run; no compensation or title band is available | — |
| Unknowns | Decision rights, pay, location, contract type, reporting line, whether the 3-year line is literal | — |
| Contradictions | None visible in the JD text | `[grounded]` JD text only; not checked against the careers page |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1a | 3+ years PM experience | must_have | absent | none | capability | No PM title or PM-owned work in the CV; this is your own statement | `[grounded]` CV | Closure path: G1 |
| R1b | Own a product roadmap | must_have | adjacent | low | transferability | Ran quarterly roadmap-input sessions; no evidence you set priorities or scope | `[grounded]` CV | Q G1 |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST API integrations went live with clients; you did not own the platform's product decisions. Limit: integration, not product | `[grounded]` CV; `[inferred]` on the limit | Bridge story, G2 |
| R3 | Technical fluency with API docs and schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI, integration architecture stated; no artifact | `[grounded]` CV | none |
| R4 | Stakeholder management: engineering, sales, customers | must_have | adjacent | medium | transferability | Coordinated your engineers, client engineers and PMs; sales coordination not in the material | `[grounded]` CV | Confirm sales exposure |
| R5 | Partner discovery | must_have | direct | medium | presentation | Scoping workshops and requirements gathering are discovery; the CV files them under implementation | `[grounded]` CV | E1 |
| R6 | Write specs and drive squad delivery | must_have | adjacent | medium | transferability | Requirements documents and UAT for client builds; no stated squad or sprint delivery | `[grounded]` CV | Q G3 |
| R7 | Agile delivery | important | unclear | none | discovery | Not stated in the material | `[grounded]` CV silence | Q G3 |
| R8 | Define and track adoption metrics | important | unclear | none | discovery | Not stated; go-live work is not metrics. An earlier conversation mentioned a triage tool, unverified | `[grounded]` CV silence; `[inferred]` from the lead | Q G2 |
| R9 | Coordinate launches with sales and support | important | adjacent | medium | transferability | Go-live and UAT coordination with clients; support and sales not stated | `[grounded]` CV | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Titled PM years (R1a) | capability | No PM title; roadmap-input work only | The literal screen will reject on this alone | Any feature or product where you set scope and sequencing, even informally | A roadmap, a prioritization doc, a launch plan you wrote | `[grounded]` CV; `[generic]` that screens read titles literally |
| G2 | Shipped product (R2), metrics (R8) | transferability / discovery | Integrations shipped; no metrics recorded | Positions the bridge as product work | A tool or rollout you specified and measured adoption of | A spec, adoption numbers, a launch note | `[inferred]` bridge from the integration record |
| G3 | Agile and squad delivery (R6, R7) | discovery | Requirements docs and UAT; no sprint work stated | Two squads are the job's core mechanism | Sprint planning, backlog ownership, release scope decisions | A backlog or a sprint review | `[grounded]` CV silence |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies this size | Can you point me at this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Literal 3-year screen | unknown | — | "3+ years product management experience (must-have)" | The line may be a hard screen, or may accept platform ownership without a PM title | `[inferred]` from the must-have label | Is the 3-year product management requirement a hard screen, and would platform-ownership work count toward it? | unresolved |
| RR3 | Decision rights | unknown | — | "Own the roadmap for our partner-facing API platform" | Roadmap ownership may come with input but not final say over scope | `[inferred]` from silence on decision rights | Which roadmap decisions does this role make alone, and which go to engineering or executive leads? | unresolved |
| RR4 | Pay withheld | unknown | — | JD states no pay | The band may sit at or below the role's expectation, or pay may simply be unpublished | `[grounded]` silence in the JD; band not calibrated | What base range is budgeted for this role? | unresolved |
| RR5 | Concrete scope | positive_signal | — | "two engineering squads"; "define and track adoption metrics" | Resourcing and metrics are named, so the mandate is real | `[grounded]` JD | How are adoption metrics defined today, and who owns them? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Reframe the CV around integration-to-product work: "Led 30+ end-to-end REST API client integrations, from scoping workshops and requirements documents through UAT and go-live" | Shows R5 and R2 without claiming a PM title | `[grounded]` CV wording | pending your approval |
| E2 | Add a roadmap-input example with the outcome you influenced | Closes R1b if specific | `[grounded]` R1b | pending G1 answer |
| E3 | Verify the posting on the company's careers site before tailoring anything | RR1 caps the whole decision | `[generic]` pattern | to do |
| E4 | Ask the recruiter RR2 and RR4 before investing in the loop | Decides whether the application is worth the time | `[grounded]` RR2, RR4 | to do |
| E5 | If RR2 is literal, widen the target to PM-adjacent roles that accept integration-led experience | A literal screen on this posting is a poor use of effort | `[generic]` role-family pattern | pending decision |

**Evidence status**

Verified: none yet. Your CV claims are self-report at `medium` at most. The earlier-conversation triage tool is a lead only; it is not evidence and I have not used it.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Search permission was refused in this session, so all three calls failed. Would have moved RR1 and the contradictions row in role reality |
| 2. Role-family sweep | unavailable | Same refusal. Would have moved the market calibration and RR4's band |
| 3. Hiring manager's public footprint | n/a | No name was given, so no query could be formed |

**Dossier offer:** Want me to save this as `tuesday-dossier.md` for later use?

**Upgrade menu**
- Granting search permission lets L1 run: it can verify Quartzline and the posting (RR1) and calibrate the pay band (RR4).
- A hiring manager's name would let me read their public background for positioning.
- A roadmap, prioritization doc or launch plan from your current work would raise R1b and R2 to `medium` or higher.

**Questions**

G1 — When your client-feedback sessions fed the product roadmap, did you ever decide what shipped or in what order? Give one example and what changed.

G2 — An earlier conversation, which I can't verify, mentioned an internal request-triage tool that support adopted. Did you build it? What did it do, who specified it, and how did you measure whether people used it?

G3 — Have you worked in sprints or with a squad? If so, what did you own in planning or the backlog?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.