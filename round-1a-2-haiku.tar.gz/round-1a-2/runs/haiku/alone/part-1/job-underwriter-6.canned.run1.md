# Quillfield, Revenue Operations Lead: `conditional_go`

Worth applying to, on three conditions. You match the tooling and years directly. The two must-haves you've never done, owning a forecast and working on billing data, are real, and the interview will probe them.

**Fit ledger.**

- `hard_gate`: unclear: R1 (hybrid, two days a week in the office)
- `must_have`: direct: R2a (4+ years in RevOps or sales ops), R3 (HubSpot or Salesforce admin), R4 (SQL and spreadsheet modelling); adjacent: R2b (B2B software company), R5 (owning a forecast), R6 (working with finance on billing or revenue data)
- `important`: direct: R8 (pipeline and renewal reporting); absent: R7 (CRM and billing data ownership)

R2b — a payments company, not software; R5 — pipeline review is a forecast input, not the forecast itself; R6 — revenue reporting, but no billing data and no finance sign-off; R7 — billing data never touched.

**Opportunity ledger.** Pay is stated and sits near the market median (RR3). Two entries need answers: the forecast is shared with the CFO and nobody says who signs it off (RR1), and the hiring manager already holds the Head of Revenue Operations title, so this role's place beside them is unclear (RR2). The employer's own careers page didn't resolve (RR5).

- **Hard gates:** none failed; unconfirmed: R1 (hybrid, two days a week in the office); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) confirm the posting on Quillfield's own site and that Bristol hybrid works for you (R1, RR5); (2) get a clear answer on forecast sign-off and reporting line (RR1, RR2); (3) describe the forecast and billing work as adjacent, never as owned.

Rationale, both ledgers: on fit, you're strong on the core tools and years, and the forecast and billing gaps are genuine. On the opportunity, the role is sound but has unclear scope and reporting lines.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, invoicing and payments software for UK builders' merchants; Bristol; founded 2018; 96 staff; £11M Series A, April 2025 | `[grounded]` quillfield.co.uk/about |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in the Bristol office | `[grounded]` JD |
| Pay | £61,500–£67,000 plus share options | `[grounded]` JD |
| Market calibration | UK revenue operations lead, B2B software (Ledgerline 2026 pay guide, n=438): median £64,200, IQR £57,800–£70,400. The posted range sits around the median. This is one pay survey, not a range across employers | `[generic]` |
| Scope read | Three functions for one lead: data ownership, reporting, and the quarterly forecast | `[inferred]` from the listed responsibilities |
| Hiring manager | Tamsin Achebe, listed as Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years. This role may sit beside or under that seat | `[grounded]` public profile; `[inferred]` on the seat |
| Unknowns | Reporting line; forecast sign-off; size of the billing-data scope; right-to-work (not stated); your location and constraints | — |
| Contradictions | None between the JD and the employer's site, though the careers page was not found | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Bristol | hard_gate | unclear | low | discovery | Your location isn't in hand | `[grounded]` JD | Q1 |
| R2a | 4+ years in RevOps or sales ops | must_have | direct | high | none | Five years, two as RevOps lead | `[grounded]` your background | none |
| R2b | B2B software company | must_have | adjacent | medium | transferability | B2B payments; same buyers and renewal cycles, not a software product | `[inferred]` | see G1 |
| R3 | HubSpot or Salesforce admin | must_have | direct | high | none | Salesforce admin certified | `[grounded]` your background | none |
| R4 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; modelling is inferred from the pipeline work, not shown | `[grounded]` background, partly `[inferred]` | none |
| R5 | Experience owning a forecast | must_have | adjacent | low | capability | You ran the monthly pipeline review; finance owned the forecast | `[grounded]` background | G1 |
| R6 | Working with finance on billing or revenue data | must_have | adjacent | medium | capability | Renewal dashboards are revenue data; no billing or finance work stated | `[grounded]` background | G2 |
| R7 | Own CRM and billing data | important | absent | high | capability | No billing data | `[grounded]` background | G2 |
| R8 | Pipeline and renewal reporting | important | direct | high | none | You rebuilt both dashboards | `[grounded]` background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Owning a forecast (R5); B2B software (R2b) | capability / transferability | Pipeline review is one forecast input. No forecast of your own is on record | A stage-weighted forecast you produced, even informally, and how it compared with actuals. For R2b: a note on what software renewal cycles share with payments | `[inferred]` |
| G2 | Billing data and finance work (R6, R7) | capability | Revenue reporting without billing data | Any reconciliation or billing-revenue reporting you did with finance, described with a figure | `[grounded]` background |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Forecast ownership shared with the CFO; sign-off unstated | risk_signal | medium | "run the quarterly revenue forecast with the CFO" | You could carry the forecast's accountability without deciding its numbers | `[inferred]` from the JD's wording | Who signs off the quarterly forecast number, and what is this role's part in it? | unresolved |
| RR2 | Hiring manager already holds a Head-level RevOps title | unknown | — | Head of Revenue Operations (public profile) | This role may be a second RevOps seat with narrower decision rights | `[inferred]` from the title comparison | Which of the three areas does this role own outright, and which stay with the Head of Revenue Operations? | unresolved |
| RR3 | Pay stated and near the median | positive_signal | — | "£61,500–£67,000 plus share options" | Pay is in line with the market; transparency is a good sign | `[grounded]` JD, `[generic]` band | Is £61.5k–£67k the approved budget for this post? | noted |
| RR4 | Three functions in one lead role | risk_signal | medium | "own our CRM and billing data, build the pipeline … run the quarterly revenue forecast" | A bundled role whose year-one priority is unclear | `[generic]` pattern for bundled RevOps roles | Is there analyst or finance support for the forecast and billing data in year one? | unresolved |
| RR5 | Employer's careers page didn't resolve; posting from an aggregator | risk_signal | medium | Tallyboard posting; quillfield.co.uk/careers returned no page | The posting may be stale, or aggregated from an out-of-date listing | `[generic]` pattern for aggregator postings | Can you point me at this role on Quillfield's own careers site? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead with the Salesforce admin certification and the pipeline and renewal dashboards | R3, R8 are your direct matches | `[grounded]` background | pending your approval |
| E2 | Describe the monthly pipeline review exactly as it was; say finance owned the forecast | Avoids overclaiming R5 | `[grounded]` background | pending your approval |
| E3 | Don't claim billing-data work; mention only revenue reporting you can evidence | Keeps R6 and R7 honest | `[grounded]` background | pending your approval |
| W1 | Ask the recruiter to confirm the role on Quillfield's careers site, and ask about reporting line and forecast sign-off before the first interview | RR1, RR2, RR5 | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol", which returned quillfield.co.uk/about (employer exists as described, 96 staff, Bristol). Fetched quillfield.co.uk/careers, which returned no page, so the posting is not confirmed on the employer's site. Moved RR5 |
| 2. Role-family sweep | yes | Searched "revenue operations lead salary UK B2B software forecast billing", which returned the Ledgerline 2026 UK Revenue Operations Pay Guide (median £64,200). Moved the market calibration line |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", which returned the public profile (Head of Revenue Operations at Quillfield; previously Corvane Payments). Moved RR2 and the scope read |

## Upgrade menu

- A forecast you produced, even anonymised, or a stage-weighted pipeline number and its accuracy → G1, R5 moves up.
- Any billing or revenue reconciliation work with finance, with a figure → R6 and R7 move up.
- Your home location → R1 closes.
- The recruiter's answer on reporting line and forecast sign-off → RR1 and RR2 close, and the decision may simplify to `go` or `no_go`.
- Deeper research on Quillfield (funding, leadership changes, staff reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

If you'd like, I can save this as `tuesday-dossier.md` to take into interviews.

**Questions**

1. (R1) Where are you based, and can you be in the Bristol office two days a week?
2. (G1, RR1) Have you ever produced a forecast, even informally, such as a stage-weighted number you gave the sales director?

Answer in text, paste a voice transcript, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.