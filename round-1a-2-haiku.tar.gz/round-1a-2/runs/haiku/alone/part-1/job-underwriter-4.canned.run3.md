**Yes, worth applying to, once the posting checks out. Status: `conditional_go`.** Verify the employer before you spend application effort on it.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Fully remote, UK)
- `must_have` — direct: R2, R3, R4, R5, R6, R7
- `important` — direct: R8 · adjacent: R9 (Pet-insurance product knowledge)
- `preferred` — direct: R10 (Insurance experience)

R4 — the GLM is motor, so the technique carries over but the book does not; R9 — a credible bridge from motor rating, with its limit named; R8 — the underwriting side is evidenced, the product side is not.

**Opportunity ledger.** The role is specific and its scope is concrete (RR4); the hiring manager has published on the monitoring work the role describes (RR5). Against that, the employer could not be found in public sources (RR1), the salary is withheld (RR2), and the JD does not say whether the role line-manages anyone (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found.
- **Conditions for go:** (1) Brindlemoor and the live posting verify on its own careers site (RR1); (2) the remote-UK terms match your location and right to work (R1); (3) pet insurance is framed as an adjacent bridge with its limit named, never as expertise (R9).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` JD; existence not established (RR1) |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Scope read | A full-cycle pricing analyst remit; no people, budget or decision rights are stated | `[inferred]` from the responsibilities against the JD's silence on them |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing; previously head of pricing analytics at Calloway Re for six years; spoke at the 2025 Insurance Pricing Forum on monitoring rating models in small books | `[grounded]` public profile snippet (not fetched) |
| Market calibration | A senior pricing analyst across UK insurers and insurtechs: median base £58,400, interquartile range £52,100–£64,900 (2026 survey, n=612). The JD withholds salary, so this is what to expect, not this employer's offer | `[generic]` role-family sweep; `[grounded]` JD for the withheld salary |
| Unknowns | Employer existence; salary; line management; whether product-side recommendations are part of the role | — |
| Contradictions | None found within the JD; the employer itself could not be checked against any public source | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based (location and right to work) | hard_gate | unclear | none | hard_gate | Your location and right-to-work status are not in your background. Your UK motor history suggests a fit but does not settle it | `[inferred]` from your UK employer history; `[grounded]` JD | Q1 |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, stated; not yet probed | `[grounded]` your background (self-report) | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, stated; no artifact seen | `[grounded]` your background | none |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM for a motor young-driver book. The technique is direct; the book is motor, and must be described as motor | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Design and read price tests | must_have | direct | medium | none | Ran 14 price tests last year with the underwriting team | `[grounded]` your background | none |
| R7 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained one GLM; the monitoring you ran is not yet described | `[grounded]` your background | Describe the monitoring you ran, in interview |
| R8 | Turn results into recommendations for underwriting and product | important | direct | medium | discovery | Underwriting recommendations are evidenced through the quarterly review and the tests. Product-side recommendations are not in your background | `[grounded]` your background; `[inferred]` that the product half is the unevidenced one | G1 |
| R9 | Pet-insurance product knowledge (implied by "our pet-insurance product") | important | adjacent | medium | transferability | Motor rating carries over: the same GLM and test discipline. Limit: no pet product, pet claims or pet pricing exercised by you | `[inferred]` adjacency from motor rating work; limit from your stated background | G2 |
| R10 | Insurance experience ("a plus") | preferred | direct | medium | none | Five years at a UK motor insurer | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Product-side recommendations (R8, important) | discovery | Underwriting recommendations are evidenced; no product-side decision appears in your background | The JD names product as a recipient of your recommendations; this is the half interviewers will test | A pricing or cover change you shaped with a product team; a feature or eligibility decision you argued for | A product brief, a decision note, a test readout shared with product | `[grounded]` JD; `[inferred]` that this is the gap |
| G2 | Pet-insurance product (R9, important) | transferability | Motor rating carries over; no pet exposure in your background | The posting is for a pet product, so the bridge decides how strong the fit reads | Any pet, companion-animal or pet-health cost analysis, even outside your job | A pet-data sample, a cost-driver analysis, a pricing exercise | `[inferred]` bridge derived from motor rating work; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Brindlemoor (insurtech)" | The entity may be too new or small to have a footprint, the posting may be stale or aggregated, or it may not represent a real hiring employer | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Salary withheld | unknown | — | (no salary in the posting) | The budget may sit below the market band, or the salary may simply go unpublished | `[inferred]` from the posting's silence, against the `[generic]` band in role reality | What salary is budgeted for this role? | unresolved |
| RR3 | Line management not stated | unknown | — | "Own pricing analytics" (no reports mentioned) | The role may carry direct reports the posting does not mention. You have never managed anyone, so this changes what the title expects | `[inferred]` from the JD's silence on reports | Does this role line-manage anyone now, or is that planned in the first year? | unresolved |
| RR4 | Responsibilities specific and measurable | positive_signal | — | "build and monitor rating models, design and read price tests, and turn the results into recommendations" | The scope is concrete and matches your record | `[grounded]` JD | Across those three duties, which takes most of a typical quarter? | noted |
| RR5 | Hiring manager publishes on monitoring | positive_signal | — | Talk, 2025 Insurance Pricing Forum: "Small Books, Loud Errors" | The monitoring part of the role may be a real priority for the hiring manager | `[inferred]` from the talk's topic against the JD's "build and monitor" | In a small book, which monitoring signals made you act, and how fast? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find the live posting on Brindlemoor's own careers site before applying | RR1 | `[grounded]` RR1 | your next step |
| A2 | Ask RR2 and RR3 in the first conversation, verbatim | The register doubles as interview preparation | `[grounded]` register | pending your approval |
| A3 | Lead with the price tests (R6) and the underwriting presentation (R5); describe the GLM as motor (R4) | Those are the direct evidence | `[grounded]` rows R4–R6 | pending your approval |
| A4 | Describe pet insurance as an adjacent bridge with its limit named. Do not claim pet expertise or a product-side track record | R8, R9 | `[grounded]` rows; reframing audit on kind and scope | pending your approval |

## Evidence status

Verified: none yet. Every claim above is your own statement, not yet probed.

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Brindlemoor insurtech pet insurance": no results. The employer is not established from attributable sources (RR1). No careers page reached |
| 2. Role-family sweep | yes | Searched "Senior Pricing Analyst pet insurance UK salary GLM", which returned "Pricewell 2026 UK Pricing and Actuarial Analytics Pay Survey" (pricewell.example). Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Odile Varga Director of Pricing Brindlemoor", which returned a public profile (linkedin.example/in/odile-varga). Read from the snippet only; it moved the role-reality hiring-manager row and RR5 |

## Upgrade menu

- A live posting link or Brindlemoor's careers page → RR1 closes; the `conditional_go` cap lifts, and the status becomes `go` or `no_go`.
- The budgeted salary → RR2 closes against the band in role reality.
- The team's structure, reports and monitoring duties → RR3 and R7 close.
- A pet-data or cost-driver artifact from your work, if any → R9 moves up from `adjacent`.
- A deeper research pass on Brindlemoor (funding, leadership changes, past postings; up to 5 more searches and 2 more fetches). Say the word and it runs.

I can write this assessment up as `tuesday-dossier.md` whenever you want it kept.

1. **R1** — Where are you based, and do you have the right to work in the UK without sponsorship?
2. **G2** — Have you worked on any pet, companion-animal or pet-health cost data, even a side project or a pricing exercise outside your job?
3. **G1** — Have you ever shaped a pricing or cover change together with a product team? What did you decide, and what did they own?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.