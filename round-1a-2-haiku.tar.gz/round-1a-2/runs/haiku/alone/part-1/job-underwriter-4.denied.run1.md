**Snapshot: conditional go. Apply, once you've checked two things: that Brindlemoor is a real, live employer, and that the pay is in your range.**

**Hard gates:** Fully remote UK. Your CV doesn't state your location, so confirm you're based in the UK and eligible to work there. This is the only hard gate, and nothing in your background suggests it fails.

**Fit ledger (CV-stated, not yet verified):**

| # | Requirement | Priority | Fit | Evidence | Confidence |
|---|---|---|---|---|---|
| 1 | 4+ years pricing or actuarial analytics | Must | Strong | 5 years, last 2 senior | High |
| 2 | GLM experience | Must | Strong | Built and maintained a young-driver GLM | High |
| 3 | Strong SQL and Python | Must | Strong | Daily use; no work samples yet | Medium-high |
| 4 | Presenting to underwriting or actuarial leads | Must | Strong | Quarterly pricing review to head of underwriting | High |
| 5 | Designing and reading price tests | Core scope | Strong | 14 tests with underwriting last year | Medium-high (scale and design rigor unstated) |
| 6 | Insurance experience | Plus | Strong | UK motor insurer | High |
| 7 | Pet insurance domain | Not required, but implied by "pet-insurance product" | Gap | None | n/a |
| 8 | Managing people | Not stated in the JD | Unknown | None | n/a |

**The real gap is domain, not method.** Pet insurance has different risk drivers from motor: breed and species mix, vet-cost inflation, and typically different policy structures. [generic] This is learnable, and the GLM, testing and underwriting-facing work transfers directly. Your gap is domain knowledge, which you can show by learning it, not a missing skill set. Don't claim pet experience you don't have.

**Management is not a gap.** The JD asks for ownership of analytics, not direct reports. Confirm this before you apply, but don't raise it unprompted.

**Opportunity side:** The JD is coherent and the scope is clear. Compensation is not stated, which is itself worth asking about. I haven't verified that Brindlemoor exists as described, its funding stage, or whether the posting is live. That's why this is conditional.

**Application plan:**
- Lead with GLM build-and-maintain ownership and the 14 price tests. These are your strongest matches for the JD's core scope.
- Frame the pet gap as transferable method plus a concrete plan to learn the domain. Don't write it as a weakness or as experience.
- Don't draft CV wording yet. Any wording you want to use would need your approval first.

**Research:** Research tier: L0 — no searches. I haven't checked the company, the market pay band, or the hiring manager's public profile. I can run a company and role check if you want it.

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | No research consent yet (L0) |
| 2. Role-family pay and scope sweep | skipped | No research consent yet (L0) |
| 3. Hiring manager public footprint | skipped | No research consent yet (L0) |

**Upgrade menu:** Each item below would raise a row or close a flag:
- Live posting link or the company's careers page: verifies the employer and resolves the conditional.
- Pay range, if stated: closes the unstated-compensation check.
- A pet-domain learning step, such as a course or a read-through of pet-insurance pricing: moves the domain gap from "none" to "in progress".
- SQL or Python work sample, if you can share one: raises row 3 from medium-high to high.

I can also build a fuller dossier file with this assessment if you want it for later. Say the word and I'll produce it.

**Questions:**
1. Does the JD mean the role has direct reports, or is it an individual contributor role?
2. Is there a stated or expected salary range, and what is your floor?
3. Where are you based, and are you eligible to work in the UK?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.