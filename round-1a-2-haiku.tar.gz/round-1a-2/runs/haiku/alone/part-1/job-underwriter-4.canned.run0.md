**Decision: conditional_go.** Apply, but confirm the posting is live and the employer is real before you spend time on it. On fit, you match most of this role. The main gap is pet-specific domain knowledge, which is closable.

Research tier: L0, no searches, no fetches. I worked only from what you gave me, so company facts and market pay are not verified.

## Decision snapshot

- **Fit ledger:** Requirements you meet on your stated evidence: 4+ years pricing analytics, SQL and Python, GLM experience, presenting to underwriting leads. Partial: insurance experience (motor, not pet). Unknown: pet-insurance rating drivers, and whether the role wants people management (the JD doesn't say).
- **Hard gates:** None stated in the JD. Remote UK is probably fine, but confirm it. Compensation is not stated, so it can't be checked against your floor.
- **Opportunity side:** Unverified. Company stage, size, funding and the live posting are all unchecked.

## Role reality

- **Scope:** "Own pricing analytics" for one product, with build, monitor, test and recommend all in one role. That reads as a broad, senior individual-contributor scope. Reporting to a Director of Pricing is a reasonable seniority signal. `[inferred]`
- **Unknowns:** Team size, data maturity for pet pricing (claims history, lifetime vs annual cover), and whether you'd own the model end-to-end or inherit one.
- **Compensation:** Not stated. The posting withholds it, which is worth a question.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 4+ years pricing or actuarial analytics | Must-have | Fit | Medium (CV-only) | None | 5 years UK motor pricing analytics |
| 2 | Strong SQL and Python | Must-have | Fit | Medium (CV-only) | None | Daily use, stated |
| 3 | GLM experience | Must-have | Fit | Medium (CV-only) | None | Built and maintained the young-driver GLM |
| 4 | Designing and reading price tests | Must-have (in scope) | Fit | Medium (CV-only) | None | 14 tests run last year with underwriting |
| 5 | Presenting to underwriting or actuarial leads | Must-have | Fit | Medium (CV-only) | None | Quarterly pricing review to head of underwriting |
| 6 | Insurance experience | Preferred | Partial | Medium | Transferability | Motor, not pet |
| 7 | Pet-insurance rating drivers and claims behaviour | Implied | Unknown | Low | Capability | No stated experience |
| 8 | People management | Not in JD | Unknown | n/a | Not required | Never managed anyone; JD doesn't ask for it |

Confidence reflects that every claim is from your CV. Nothing is verified yet.

## Opportunity risk register

| Class | Severity | Item |
|---|---|---|
| Unverified employer | Medium | Can't confirm Brindlemoor exists as described or that this posting is live. This is why the decision is conditional. |
| Domain gap | Medium | Pet pricing is different from motor: breed, species and vet-cost inflation drive it, and lifetime-cover mechanics differ. Expect ramp-up. `[generic]` |
| Scope ambiguity | Low | "Own" plus "monitor" could mean one-person function with thin data. |
| Compensation | Unknown | Not stated. Can't compare to your floor. |

## Application plan

- **Positioning, as your evidence supports it:** Lead with the GLM build and maintenance, the 14 tests, and the underwriting presentations. These map directly to "build and monitor rating models", "design and read price tests" and "turn results into recommendations." Name the pet gap yourself and frame it as a transfer from motor, not as experience you lack.
- **Wording to avoid:** Don't claim pet-insurance knowledge, and don't say "led" or "owned" for test outcomes unless you can show your decision rights.
- **Before applying:** Get the live posting link and the recruiter's email domain.

## Evidence status

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| Company site and careers page | skipped | L0; research not yet consented |
| Role-family pay and scope sweep | skipped | L0; research not yet consented |
| Hiring manager public footprint (Odile Varga) | skipped | L0; research not yet consented |

## Dossier offer

I can write this assessment to a `tuesday-dossier.md` file you can keep and bring back later, if that would help.

## Upgrade menu

- **Live posting link and recruiter email domain** unlocks employer verification, which is the main reason the decision is conditional.
- **L1 research (up to 5 searches, 2 fetches)** checks the company's existence and stage, the role-family pay band against your floor, and any public footprint of the hiring manager.
- **Compensation range or your floor** lets me check the offer against your expectations.
- **Any non-motor or adjacent pricing work** (home, travel, health, claims inflation) would raise the domain-gap row.

## Questions

1. Does the JD's "own" mean you'd be the only pricing analyst on pet, or will you have a team? (Relates to scope ambiguity.)
2. Do you have any exposure to non-motor pricing or claims-inflation work that would transfer to pet? (Relates to the domain gap.)
3. What's your compensation floor, and are there any location or schedule constraints I should treat as hard gates?

Response mode: answer these inline, or say "skip" to any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.