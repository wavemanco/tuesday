## Decision snapshot

**Decision: `no_go` on the posting as written.** Both of your hard constraints fail, and the posting says they won't move.

**Candidate fit (your ledger):** Strong on experience and core channels. Paid, lifecycle, experimentation, team leadership, and SQL/GA4/Braze are all supported by your CV. Five requirements (SEO/content, brand, PR, partnerships, sales ops) have no evidence yet. Fit is based on CV claims only, so confidence is medium at best.

**Opportunity quality (separate ledger):** Weak. The pay sits well below your floor, the role is on-site in Austin with "no exceptions," and the title, scope and pay don't line up.

**Hard gates (2 failed):**
- **Location:** On-site Austin 5 days a week, "no exceptions." Your requirement: remote-only from Portland. **Fails.**
- **Compensation:** $70–85k base. Your floor: $150k base. **Fails.**

Research tier: L0, no searches run. Everything about Novaline is unverified.

## Role reality

- **Title and scope:** "Head of Growth" owning all revenue growth, with "a team of one to start" and no direct reports. [grounded] Reads as a senior title on an individual-contributor scope. [inferred]
- **Seniority vs. pay:** An 8+ year requirement paired with $70–85k base. [grounded] Posted pay is below typical for a Head-level role. [generic]
- **Culture signals:** "Evenings and weekends when it matters is just who we are" and "players who don't need a bench." [grounded] These suggest sustained overload. [inferred]
- **Company:** "Series A, profitable since day one" is an unverified claim. [grounded as stated in the posting; unverified]

**Market calibration:** The title, seniority and pay mismatch is a common pattern in under-leveled postings. [generic]

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | 8+ years growth leadership | Must | Meets | Medium | None | CV: 9 years in growth |
| 2 | Own revenue growth end to end | Must | Meets | Medium | None | CV: ARR $8M→$40M over 3 years with a budget you controlled |
| 3 | Paid acquisition | Must | Meets | Medium | None | CV: owned paid |
| 4 | Lifecycle / CRM | Must | Meets | Medium | None | CV: owned lifecycle; Braze |
| 5 | SEO / content | Must | Not evidenced | Low | Discovery | Nothing in the inventory |
| 6 | Brand | Must | Not evidenced | Low | Discovery | Nothing in the inventory |
| 7 | PR | Must | Not evidenced | Low | Discovery | Nothing in the inventory |
| 8 | Partnerships | Must | Not evidenced | Low | Discovery | Nothing in the inventory |
| 9 | Sales ops | Must | Not evidenced | Low | Discovery | Nothing in the inventory |
| 10 | Experimentation / analytics | Implied | Meets | Medium | None | CV: owned experimentation; SQL, GA4 |
| 11 | Team-of-one vs. your team leadership | Scope | Mismatch | — | Transferability | You managed 3–7; posting has no reports |
| 12 | On-site Austin, 5 days | Hard gate | **Fails** | — | Hard gate | You: remote-only, Portland |
| 13 | $70–85k base | Hard gate | **Fails** | — | Hard gate | Your floor: $150k base |

Rows 5–9 are "not evidenced," not "missing." Your CV is silent on them, so they may be discovery gaps (you have done it and didn't list it). They are not confirmed capability gaps.

## Opportunity risk register

| Class | Severity | Risk |
|---|---|---|
| Hard gate | High | On-site 5 days, "no exceptions," vs. remote-only. [grounded] |
| Hard gate | High | $70–85k is $65k–$80k below your $150k floor (47–57% of it). [grounded] |
| Scope/title | Medium | Head title, 8+ years, team of one, and sub-$85k pay together suggest an under-leveled or inflated title. [inferred] |
| Culture | Medium | Evenings and weekends as the default. [inferred from wording] |
| Unverified employer | Medium | Company stage and profitability are unchecked. Standing entry: attribution not yet tested. Resolves with the live posting link, the company careers page, or the recruiter's email domain. |

## Application plan

**Don't apply as written.** Both constraints are stated as fixed, so there is no tailoring that changes the outcome. The only thing that would reopen this is a written change to both the location and pay terms, and the posting already rules that out.

No resume edits are proposed, so no approval is needed.

## Evidence status

Research tier: L0, no searches.

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Novaline's official site and careers page | skipped | Research not consented to; not run |
| 2 | Role-family sweep (scope, title, pay for this seniority) | skipped | Research not consented to; not run |
| 3 | Hiring manager's public footprint | n/a | No hiring manager named |

## Dossier offer

If you want, I can save this assessment as `tuesday-dossier.md` for later reference.

## Upgrade menu

- **Live posting link or careers page:** Confirms the role exists as described and closes the unverified-employer risk.
- **Evidence for SEO/content, brand, PR, partnerships, sales ops:** Moves rows 5–9 from "not evidenced" to a confirmed fit or a real gap.
- **L1 research consent:** Checks Novaline's stage and replaces the generic pay band with a checked one. It cannot change the two failed gates.
- **Recruiter's answer on terms:** Only a written change to both location and pay would reopen this.

## Questions

1. Where did this posting come from: a live careers page, a recruiter's email, or a job board? The link or email domain is what I'd need to confirm that Novaline exists as described.
2. Have you done any of SEO/content, brand, PR, partnerships or sales ops, even as part of a broader role? A line on each would settle rows 5–9.
3. Do you still want the L1 company check? It would confirm whether Novaline is real, but it can't change the two failed gates.

Reply with any mix of answers, or "skip" to any question.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.