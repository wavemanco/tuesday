**Decision: conditional_go.** Apply, but expect the 3+ years of PM experience requirement to screen you out unless you can show product ownership in some form.

**Hard gates:** None are stated in the posting. Location, pay, and work authorization are absent, so they're unknown against your constraints. Years of experience isn't a hard gate under this framework, so the must-have sits in the fit ledger.

**Fit ledger**

| Priority | Fit | Requirement |
|---|---|---|
| Must-have | Gap | 3+ years PM experience |
| Stated requirement | Partial | Shipped API or platform products |
| Stated requirement | Strong | Technical fluency with API docs and schemas |
| Stated requirement | Strong | Stakeholder management across engineering, sales, and customers |
| Stated requirement | Partial | Partner discovery |
| Stated requirement | Partial | Writing specs and driving squad delivery |
| Stated requirement | Partial | Launch coordination with sales and support |
| Stated requirement | Not evidenced | Defining and tracking adoption metrics |
| Stated requirement | Not evidenced | Agile delivery |
| Implied | Not evidenced | Owning a roadmap (you have gathered input, not set priorities) |

**Role reality**
- Quartzline's posting gives a B2B logistics-tech company, about 150 people, Series B. That is the posting's own claim [grounded], and I have not checked it.
- One PM owns the roadmap for a partner-facing API platform and works with two engineering squads. That reads as a senior individual-contributor role with no stated PM team [inferred].
- Pay and location are missing from the posting. Its absence is worth a question to the recruiter.

**Evidence map** (confidence is for the claim as written; none of it is verified)
- **Technical fluency, high.** Postman, SQL, OpenAPI, and integration architecture across 30+ REST integrations. A work sample would confirm this.
- **Stakeholder management, medium-high.** You coordinated your engineers, the clients' engineers, and product managers, and ran UAT and go-live. Sales coordination isn't explicit.
- **Discovery, medium.** Scoping workshops and quarterly roadmap-input sessions are real discovery work under a different name. Present them as discovery.
- **Shipped API products, medium.** You shipped integrations of a product you didn't own. The requirement asks for ownership.
- **PM experience, high (gap).** You have no PM title and no product-ownership record in what you've given me.
- **Triage tool, unverified.** The note from a prior conversation is a lead, not evidence. Don't use it in anything you send until you confirm it.

**Gap recovery queue**
- **PM experience (must-have).** Transferability gap: adjacent roles, no title. Closes with a product-shaped artifact (a spec, a discovery synthesis) or evidence of owning a backlog or roadmap.
- **Shipped products.** Presentation gap. Closes if the triage tool is real and has adoption numbers, or if you can show a feature you shaped from start to finish.
- **Adoption metrics and agile delivery.** Capability gaps. Closes with any metric you tracked or any sprint or backlog work, even informal.

**Risk register**
- **Must-have mismatch, high.** The posting asks for 3+ years of PM experience and you have none. Screens may reject you before anyone reads the rest.
- **Unverified employer, medium.** Nothing has been checked against the live posting or Quartzline's site. This is why the decision is conditional.
- **Compensation and location unknown, medium.** Neither is stated, so you can't yet test them against your floor.

**Application plan**
1. Lead with the discovery-to-roadmap story: 30+ client integrations turned into product input. Use only what's verified.
2. Write one product-shaped work sample from your playbook or a past integration, such as a spec or discovery synthesis. Proposed text only; nothing gets sent without your approval.
3. Confirm the triage tool. If it's real and has adoption numbers, it's your strongest shipped-product evidence.
4. Ask the recruiter whether they'd consider a PM with a strong solutions-engineering background. That's a fair question for a 150-person company.

Proposed resume wording is pending your approval. Avoid calling roadmap-input sessions "product management" or the playbook a "product."

**Evidence status**

Research tier: L0 — no searches

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | No research consented yet |
| 2. Role-family sweep (scope, title, pay) | skipped | No research consented yet |
| 3. Hiring manager footprint | n/a | No name given |

**Dossier offer:** If you want, I can save this assessment as `tuesday-dossier.md` so it carries into later sessions.

**Upgrade menu**
- Confirmation of the triage tool, with who used it and any adoption numbers. Unlocks the shipped-product row.
- A live link to the posting or Quartzline's careers page. Unlocks employer verification.
- Your location and pay floor. Unlocks the hard-gate check.
- Any sprint, backlog, or roadmap artifact. Unlocks the agile and ownership rows.
- Consent to run L1 research: up to 5 searches and 2 page fetches on Quartzline's site, careers page, and the role-family pay band.

**Questions**
1. Did you build the request-triage tool? If so, who used it, roughly how many requests did it handle, and what changed in turnaround or volume?
2. Have you ever run sprints, owned a backlog, or prioritized engineering work in Jira or a similar tool, even informally for a squad?
3. Do you want me to run L1 research on Quartzline? It would use up to 5 searches and 2 page fetches.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.