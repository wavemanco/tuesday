**Status: `hold_pending_answers`.** Your fit on the must-haves is strong, but I can't call the decision yet. Two hard gates are unchecked, and the employer is unverified.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R7 (orchestration with Airflow or similar), R8 (experience with data quality testing)
- `important` — adjacent: R6 (BigQuery warehouse); unclear: R9 (data contracts analysts depend on), R10 (ingestion from our app and CRM)

R6 — a real limit, since you've never used BigQuery; R9, R10 — no evidence yet, both worth one question; R1, R2 — the gates, waiting on your answers.

**Opportunity ledger.** Mixed. The stated pay band (RR5) sits at or above the market median and is a positive signal. Against that, the role bundles three areas into one senior post with no team named (RR2), and the employer is unverified (RR1).

- **Hard gates:** none failed; unconfirmed: R1 (Remote (US) or our Denver office), R2 (Salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Waiting on:** (1) your location and whether remote-US or Denver works (R1); (2) your lowest acceptable base (R2); (3) a link to the live posting on the company's own careers page (RR1)
- **What would change this:** once those clear, the likely status is `conditional_go`, on three conditions: the scope in RR2 is confirmed as yours to own, the team in RR3 is named, and BigQuery is stated as a limit in every application.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online tutoring for K-12 schools in 31 US states; founded 2016, Denver; 264 employees; Series C ($52M, February 2026) | `[grounded]` the company's about page as you pasted it; not externally verified (RR1) |
| Mandate | Build and run ingestion from the app and CRM, a dbt-modelled BigQuery warehouse, and the data contracts analysts rely on | `[grounded]` JD |
| Scope read | Three areas under one post, wider than one domain's pipelines | `[inferred]` from the JD's responsibilities set against the typical scope in the pasted report |
| Market calibration | Senior data engineers at Series B–D companies: base median $151,000, interquartile range $139,000–$163,500; "Senior" typically 5–8 years | `[generic]` the pasted Datawright 2026 report, US, n=2,310; a pattern, not this employer's offer |
| Pay position | The posted $148,000 floor sits just under the median; the $166,000 top sits above the upper quartile | `[inferred]` comparing the `[grounded]` JD band with the `[generic]` report band |
| Working pattern | Remote (US) or the Denver office | `[grounded]` JD |
| Unknowns | Team size, reporting line, hiring manager, contract type, equity terms, whether a BigQuery migration is in progress | — |
| Contradictions | None between the JD and the about page as pasted | `[grounded]` both pasted texts |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or our Denver office | hard_gate | unclear | none | hard_gate | No candidate location in the material, so the gate is not established | `[grounded]` JD; no candidate statement | Ask (Q1) |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | No candidate floor given, so the gate is not established | `[grounded]` JD; no candidate statement | Ask (Q2) |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at one payroll company, stated in your intake; unprobed, so capped at medium | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use, stated in your intake; no artifact inspected | `[grounded]` your stated background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake, a cloud warehouse; the JD's requirement is met as written | `[grounded]` your stated background | none |
| R6 | BigQuery warehouse (responsibility) | important | adjacent | medium | transferability | Warehouse and dbt work on Snowflake carries over; BigQuery itself never used. Limit: no BigQuery work to point to | `[inferred]` transfer from Snowflake work; `[generic]` that BigQuery-specific habits such as cost and partitioning are what interviewers probe | State the limit (A3) |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow for orchestration at your payroll company, stated | `[grounded]` your stated background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | You set up a Great Expectations suite; what it covered is unprobed | `[grounded]` your stated background | none |
| R9 | Data contracts analysts depend on (responsibility) | important | unclear | none | discovery | Nothing in the material about contracts | `[grounded]` absence in your intake | Ask (Q3) |
| R10 | Ingestion from the app and CRM (responsibility) | important | unclear | none | discovery | Nothing in the material about ingestion sources | `[grounded]` absence in your intake | Ask (Q3) |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery (R6) | transferability | Snowflake and dbt work; no BigQuery | The posting names BigQuery; the limit must be stated, not hidden | Any warehouse migration, cost tuning, or partitioning work you have done, even off the job | A sanitized dbt project note or query plan from any warehouse | `[inferred]` transfer; `[generic]` what BigQuery probes look like |
| G2 | Data contracts and ingestion (R9, R10) | discovery | Your intake mentions the Great Expectations suite, not contracts or source ingestion | Both are named responsibilities, and both are likely interview probes | Schema agreements with downstream analysts, source connectors or CDC into a warehouse, breaking-change handling | A schema doc, a contract, or a data-flow diagram | `[grounded]` absence in your intake; `[inferred]` that these are the likely probes |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not verified; the live-posting check was refused | risk_signal | medium | "Senior Data Engineer — Pellucid Learning" | The posting may be stale or aggregated, or the employer may be too small to have a footprint | `[generic]` pattern for employers of this size, not a claim about this one | Can you point me to this role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Three areas bundled into one senior post | risk_signal | medium | "Build and run the pipelines … ingestion from our app and CRM, a dbt-modelled warehouse in BigQuery, and the data contracts" | This may be the company's whole data function rather than one domain's pipelines | `[inferred]` from the JD's scope against `[generic]` typical scope in the pasted report | Who else works on these pipelines today, and which of these three areas would I own end to end? | unresolved |
| RR3 | Team, reporting line and hiring manager unnamed | unknown | — | "Remote (US) or our Denver office" (no manager named anywhere) | Reporting structure and team size are unknown | `[grounded]` absence in the posting | Who would I report to, and how many data engineers work on this team? | unresolved |
| RR4 | Equity and contract type unstated | unknown | — | "plus equity" | Equity terms and whether the role is permanent are unknown | `[grounded]` absence in the posting | What is the equity grant, and is this role permanent? | unresolved |
| RR5 | Stated pay band | positive_signal | — | "Salary $148,000–$166,000 plus equity" | The band is stated openly and sits at or above the market median | `[inferred]` comparing `[grounded]` JD with `[generic]` report | Is this band for the full seniority range, and where does a six-year hire usually land? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Tell me your location and lowest acceptable base | Gates R1 and R2 decide whether this is `no_go` | `[grounded]` rows R1, R2 | awaiting your answer |
| A2 | Find the live posting on the company's careers site before applying | Confirms RR1; a referral-only or aggregated posting changes the approach | `[generic]` employer check | your action |
| A3 | Say the BigQuery limit in one sentence, e.g. "Warehouse and dbt work on Snowflake; I haven't run BigQuery in production yet" | Stating the limit is what keeps R6 honest in interviews | `[grounded]` R6 | pending your approval |
| A4 | Ask RR2 and RR3 verbatim in the first recruiter call | Settles scope and team before investing in the loop | `[grounded]` register | pending your approval |

## Evidence status

Verified: none yet. Every claim above is your intake statement, unverified. Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent (one open, one limited to pellucidlearning.com); both were refused at the permission prompt. Would have moved the organization row and RR1 |
| 2. Role-family sweep | skipped | The pasted Datawright report already fixes the band, the median and the typical scope, which is what the market calibration reads |
| 3. Hiring manager's public footprint | n/a | No name given; the posting names none |

## Upgrade menu

- Permission to web search: the employer check (target 1, RR1) moves to verified or not established. A deeper pass on the company is also available on consent, once: up to 5 more searches and 2 more fetches, covering funding, leadership changes and public employee reports.
- A sanitized dbt model or Airflow DAG → R5 and R7 move to `high`.
- A sanitized Great Expectations suite → R8 moves to `high`.
- A name for the hiring manager → RR3 narrows, and the application plan leads with the story that reader will care about.
- Your location and pay floor → R1 and R2 leave the hold.

I can also write this up as `tuesday-dossier.md` if you want it on file.

1. For R1, are you based in the US, and would remote or the Denver office work for you?
2. For R2, what is the lowest base salary you would accept for this role?
3. For R9 and R10, have you built ingestion from a product app or a CRM, or a data contract that analysts relied on? Tell me one, what broke, and who was affected.

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.