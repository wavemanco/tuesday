**Yes, worth applying to, on conditions. Status: `conditional_go`.** Your analysis of the role is strong on the ops, CRM and reporting requirements. The one must-have you can't yet claim is owning the forecast, and the posting is the only place this employer's details come from until you check it.

**Fit ledger.**

- `hard_gate`: unclear: R1 (Bristol hybrid, two office days a week), R2 (£61,500–£67,000 plus share options)
- `must_have`: direct: R3, R5, R6 · adjacent: R4 (B2B software company), R7 (owning a forecast) · unclear: R8 (finance work on billing or revenue data)
- `important`: direct: R9

R7 — the forecast gap, bridged by your pipeline review with the limit named; R8 — unclear, one question away.

**Opportunity ledger.** The employer is real and the scope and pay are stated, which reads well. Two things are open: the role isn't listed on Quillfield's own site as far as I can find (RR1), and the forecast's decision rights are split with the CFO (RR3).

- **Hard gates:** none failed; unconfirmed: R1 (Bristol hybrid, two office days a week), R2 (£61,500–£67,000 plus share options); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the role is confirmed live on Quillfield's own careers page or by a Quillfield contact (RR1); (2) location and pay floor check out (R1, R2); (3) you can show a forecast-adjacent artifact or a credible account of what you did with pipeline-to-forecast, and not claim forecast ownership (R7, RR3).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quillfield, Bristol. Invoicing and payments software for UK builders' merchants; founded 2018, 96 staff, £11M Series A (April 2025) | `[grounded]` company About page, read from search snippet, not fetched |
| Mandate | Own CRM and billing data; build pipeline and renewal reporting; run the quarterly revenue forecast with the CFO | `[grounded]` JD |
| Working pattern | Hybrid, two days a week in the office | `[grounded]` JD |
| Pay | £61,500–£67,000 plus share options | `[grounded]` JD |
| Market calibration | UK revenue operations lead, B2B software: median £64,200, IQR £57,800–£70,400 (n=438). The stated range sits inside the IQR | `[generic]` Ledgerline 2026 UK Revenue Operations Pay Guide (one vendor survey) |
| Hiring manager | Tamsin Achebe, listed as Head of Revenue Operations at Quillfield; previously sales operations manager at Corvane Payments for four years | `[grounded]` public LinkedIn listing, read from search snippet |
| Unknowns | Contract type; reporting line; team size; share option terms | — |
| Contradictions | The posting is on tallyboard.example; no matching role on quillfield.co.uk/careers (the page doesn't exist) | `[grounded]` fetch and search |

A Head of Revenue Operations as hiring manager suggests this role may sit close to her team, or may report to her. That's an inference from her title and isn't stated in the posting.

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Bristol hybrid, two office days a week | hard_gate | unclear | low | hard_gate | Your location and commute limits aren't given | `[grounded]` JD | Q3 |
| R2 | Salary £61,500–£67,000 plus share options | hard_gate | unclear | low | hard_gate | Your floor isn't given; the figure sits inside the market IQR | `[grounded]` JD; `[generic]` pay guide | Q3 |
| R3 | 4+ years in RevOps, sales ops or analytics | must_have | direct | high | none | Five years in sales operations, the last two running revenue operations | candidate-stated | none |
| R4 | B2B software company | must_have | adjacent | medium | transferability | B2B payments company, close to Quillfield's invoicing-and-payments product; limit: not an invoicing or billing product | candidate-stated; `[grounded]` Quillfield About snippet | framing only |
| R5 | HubSpot or Salesforce administration | must_have | direct | high | none | Salesforce admin certified (verifiable on request) | candidate-stated | none |
| R6 | Strong SQL and spreadsheet modelling | must_have | direct | medium | none | SQL weekly, Excel daily; forecast-style modelling not yet shown | candidate-stated | artifact would raise to high |
| R7 | Experience owning a forecast | must_have | adjacent | medium | transferability | Run the monthly pipeline review with the sales director, the input a forecast is built on. Limit: never owned the company forecast; finance did it | candidate-stated | G1 |
| R8 | Working with finance on billing or revenue data | must_have | unclear | low | discovery | Never worked on billing data; finance-facing revenue work not stated | candidate-stated | Q1 |
| R9 | Build pipeline and renewal reporting | important | direct | medium | none | Rebuilt the pipeline and renewal dashboards | candidate-stated | dashboard screenshot would raise to high |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Forecast ownership (R7, must_have) | transferability | Pipeline review with the sales director; no forecast ownership | The JD makes the forecast a core duty with the CFO. A stronger bridge narrows the most likely objection | Any pipeline-to-actuals check, stage-weighting review, or commit call you contributed to, even if finance owned the number | A pipeline-vs-actuals view, a review deck, or a note on forecast accuracy | `[inferred]` bridge from your pipeline review; `[generic]` that this is the likeliest objection |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Posting not confirmed on the employer's own site | risk_signal | low | "Revenue Operations Lead, Quillfield" (job board) | The posting may be stale, aggregated or not yet live on the employer's site. The employer itself is real, so severity stays low | `[inferred]` from the careers page missing and the job-board host | Is this role live on Quillfield's careers page, and who would I interview with? | unresolved |
| RR2 | Reporting line not stated | unknown | — | Hiring manager is Head of Revenue Operations (public listing) | The role may report into her team, or be a new layer above it | `[inferred]` from her title against the posting's silence | Who does this role report to, and what does the team look like? | unresolved |
| RR3 | Forecast ownership split with the CFO | risk_signal | medium | "run the quarterly revenue forecast with the CFO" | Decision rights over the forecast may sit with the CFO, so this role may own its mechanics without its numbers | `[inferred]` from "with the CFO" against silence on authority | Which parts of the forecast does this role own alone, and which sit with the CFO? | unresolved |
| RR4 | Contract type and share option terms not stated | unknown | — | "plus share options" | Contract basis and equity terms are unknown | — | Is this permanent, and what are the share option terms? | unresolved |
| PS1 | Stated pay sits inside the market IQR | positive_signal | — | "£61,500–£67,000" | The pay is credible for the role, not a low outlier | `[generic]` pay guide | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Confirm the role is live on Quillfield's careers page, or through a recruiter email from a Quillfield domain | RR1 | `[grounded]` careers page missing | pending your approval |
| A2 | Check your location and pay floor against R1 and R2 | Hard gates | `[grounded]` JD | pending your approval |
| E1 | Frame forecasting honestly: "I run the monthly pipeline review with the sales director, the input a forecast is built on. I haven't owned the company forecast" | R7 | candidate-stated | pending your approval; run through the reframing audit before use |
| W1 | Prepare to show the pipeline-to-forecast link, and nothing beyond it | R7, RR3 | `[inferred]` | pending your approval |

## Evidence status

Verified: none. Everything rests on what you've told me, plus the public pages above. Your Salesforce certification is verifiable on request.

Research tier: L1 — searches 4 of 5, fetches 1 of 2; user links read 1

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Quillfield invoicing software company Bristol" (quillfield.co.uk/about, snippet read, not fetched) and "Quillfield careers Revenue Operations Lead" (no results); fetched quillfield.co.uk/careers (no page). Moved: the employer is confirmed to exist; the role on its own site is not confirmed (RR1) |
| 2. Role-family sweep | yes | Searched "Revenue Operations Lead salary UK B2B software", returning "Ledgerline 2026 UK Revenue Operations Pay Guide" (ledgerline.example/2026-uk-revenue-operations-pay-guide). Moved: market calibration `[generic]` and PS1 |
| 3. Hiring manager's public footprint | yes | Searched "Tamsin Achebe Quillfield", returning a public LinkedIn listing (linkedin.example/in/tamsin-achebe). Moved: RR2 and the positioning in E1 |

I can save this as a `tuesday-dossier.md` file if you want to keep it.

## Upgrade menu

- A Quillfield careers page listing, or a recruiter email from a Quillfield domain → RR1 closes; the conditional for go clears.
- Your location limits and pay floor → R1 and R2 move from unclear.
- A pipeline-vs-actuals view or forecast-accuracy note → R7 moves toward direct.
- A finance reconciliation or invoicing data example → R8 moves from unclear.
- A deeper research pass on Quillfield (leadership changes, funding, interview reports; up to 5 more searches and 2 more fetches) — say the word and it runs.

## Questions

**Q3 (R1, R2)** — Can you do two office days a week in Bristol, and is £61,500–£67,000 plus share options workable for you?

**Q1 (R8)** — Have you ever worked with finance on revenue figures, reconciliation or invoicing data, even if not billing data itself?

**G1 (R7)** — Have you ever contributed a number to a forecast (a commit call, a pipeline-to-actuals check, a stage-weighting review), even without owning it?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.