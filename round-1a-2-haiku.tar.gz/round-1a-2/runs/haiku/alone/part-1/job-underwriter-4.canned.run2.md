**Should you go for it? Yes, apply, on conditions.** You match the core of the role on paper. The open questions are about the employer and the job itself, not about whether you can do the work.

Research tier: L0, no searches. I haven't checked Brindlemoor, Odile Varga or the live posting, so the employer is unverified.

## Decision snapshot

**Worth applying to, on the conditions below. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: R11
- `must_have`: direct: R1–R6 · adjacent: R7
- `important`: adjacent: R8 · unclear: R9
- `preferred`: direct: R10

- **Hard gates:** none failed; unconfirmed: R11 (fully remote, UK-based). Your location and constraints weren't given, so checks against them are unknown.
- **Severe red flags:** none found in the posting as pasted.
- **Conditions for go:** (1) the posting is live and the employer is as described (not yet checked, RR2); (2) the management expectation is clear before you invest in the loop (RR1); (3) pet insurance is framed as transfer, never as domain expertise (G1).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, insurtech, pet-insurance product | `[grounded]` JD |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Reporting line | Director of Pricing (Odile Varga) | `[grounded]` your brief |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Scope read | Standard senior analyst scope for this title. It's a full-remit analyst role, not a stated leadership role | `[inferred]` from the mandate against the title |
| Market calibration | Not run (L0). Salary and contract basis are not stated in the JD | — |
| Unknowns | Whether the role line-manages; data scale and product age; salary; contract basis | — |
| Contradictions | None found between the JD and your brief | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | 5 years at a UK motor insurer, last 2 as senior analyst | `[grounded]` your CV |
| R2 | Build and monitor rating models | must_have | direct | medium | none | Built and maintained the young-driver GLM | `[grounded]` your CV |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use. "Strong" is your claim, not yet tested | `[grounded]` your CV |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model | `[grounded]` your CV |
| R5 | Design and read price tests | must_have | direct | medium | none | 14 price tests run with underwriting last year | `[grounded]` your CV |
| R6 | Present to underwriting or actuarial leads | must_have | direct | medium | none | Quarterly pricing review to the head of underwriting. Actuarial audience not evidenced, but the JD says "or" | `[grounded]` your CV |
| R7 | Turn results into recommendations for underwriting and product | must_have | adjacent | medium | transferability | Underwriting recommendations are evidenced. Product recommendations are not | `[inferred]` from the price-test and review work |
| R8 | Pet-insurance product (implied by "our pet-insurance product") | important | adjacent | medium | capability | Motor pricing method transfers. Pet market drivers (breed, species, vet-fee inflation, claim patterns) do not | `[generic]` for pet-market drivers; `[inferred]` on transfer |
| R9 | Leading people (implied by "Senior" and "own"; not stated) | important | unclear | low | discovery | No evidence either way. You have never managed anyone | `[inferred]` from the title and mandate |
| R10 | Insurance experience ("a plus") | preferred | direct | medium | none | Motor insurer, 5 years | `[grounded]` your CV |
| R11 | Fully remote, UK-based | hard_gate | unclear | low | discovery | Your location and right to work aren't in the brief | — |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance domain (R8) | capability | Motor GLM and price-test work; no pet exposure | The JD names the product, so the objection is likely | Any claims-cost, breed or species analysis; vet-cost trend work; any non-motor rating | Sanitized model documentation, or a short note on a non-motor project | `[generic]` for the likely objection; `[inferred]` on transfer |
| G2 | Product-side recommendations (R7) | transferability | Underwriting-facing recommendations only | The JD explicitly says "underwriting and product" | Any price-test result that changed a product decision, proposition or launch | A short before-and-after note on one test | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Management expectation unstated | unknown | — | "Senior Pricing Analyst… Own pricing analytics" | The role may include leading others, which you have never done | `[inferred]` from the title and the silence on line management | Does this role line-manage anyone, now or within 12 months? | unresolved |
| RR2 | Employer and posting unverified | risk_signal | medium | — | The posting or company may not match the description | `[generic]` (no check run) | Can you send the live posting link or the company's careers page? | unresolved |
| RR3 | Data scale and product age unknown | unknown | — | "insurtech… pet-insurance product" | A newer pet book may have too little claims history for a full GLM | `[inferred]` from "insurtech" and the product focus | How many policies and claims does the pet book have, and how long has it been live? | unresolved |
| RR4 | Salary and contract basis unstated | unknown | — | — | The package may be below your expectations, or fixed-term | `[grounded]` absence in the JD | What is the salary band and contract type? | unresolved |
| RR5 | Strong overlap on the core work | positive_signal | — | "build and monitor rating models, design and read price tests" | The role's core matches your track record closely | `[grounded]` JD against your CV | — | noted |

## Application plan

- **Lead with** the GLM build-and-maintain work, the 14 price tests, and the underwriting review. These match the must-haves directly.
- **Frame pet insurance as transfer:** "applies a motor GLM and price-test method to a new product." Don't write "pet-insurance experience."
- **Don't claim** people management or product ownership. Say what you did, not what you'd like to be seen doing.
- **Resume edits** are proposed only, pending your approval.

## Evidence status

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | skipped | No research consent yet; available at L1 |
| 2 | Role-family sweep (scope, title, pay) | skipped | No research consent yet; available at L1 |
| 3 | Hiring manager's public footprint | skipped | No research consent yet; available at L1 |

## Dossier offer

If you want, I can save this as a `tuesday-dossier.md` file you can carry into later stages.

## Upgrade menu

- **Live posting link or careers page** → resolves RR2 and turns the employer from unverified to checked.
- **Research at L1** (up to 5 searches and 2 page fetches): checks the company, runs a role-family pay sweep, and looks at the hiring manager's public footprint. It can move RR2 and RR4 from unknown to grounded.
- **Research at L2** (a further 5 searches and 2 fetches on top of L1): funding, leadership churn, recent news. Offered once; I won't re-offer if you decline.
- **Sanitized model documentation or a non-motor project note** → moves G1 from capability to transferable, and R8 toward `high`.
- **One before-and-after price-test note with a product outcome** → moves G2, and R7 toward `direct`.

## Questions

1. **(RR1)** Does this role line-manage anyone, now or within 12 months?
2. **(RR3)** How many pet policies and claims does the book have, and how long has the product been live?
3. **(RR2)** Can you send the live posting link? And would you like me to run L1 research on Brindlemoor, Odile Varga's public footprint, and the pay band? Answer in text, paste the link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.