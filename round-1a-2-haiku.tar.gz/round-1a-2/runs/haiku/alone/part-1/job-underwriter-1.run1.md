**Decision: `conditional_go`.** Worth applying, on the conditions below. Your experience covers most of the must-haves. The gaps are mentoring, the clinical side of the role, and HIPAA. Harborlight itself is unverified, because my web searches were refused.

## Decision snapshot

**Worth applying to, conditionally. Status: `conditional_go`.**

**Fit ledger.**
- `hard_gate`: unconfirmed: R1 (your location, work authorization, salary floor and start date, none of which you've given me)
- `must_have`: direct: R2 (5+ years), R3 (SQL), R4 (experiment design), R5 (Looker), R6 (written communication) · adjacent: R7 (metrics layer)
- `important`: unclear: R9 (mentoring two junior analysts) · adjacent: R8 (clinician partnership)
- `preferred`: adjacent: R10 (healthcare data and HIPAA)

**Opportunity ledger.** The role is clearly scoped: you'd own product analytics for one care-navigation app, with two defined outcomes of mentoring and metrics ownership (RR4). Three things are open: the employer is unverified (RR1), the salary is withheld (RR2), and the clinical setting may slow experimentation (RR3). I found no severe red flags.

- **Hard gates:** none failed; unconfirmed: R1 (candidate constraints not given — checks against them unknown)
- **Severe red flags:** none found
- **Conditions for go:**
  1. Confirm Harborlight exists as described and the posting is live (RR1).
  2. Confirm your own hard constraints against the role's location, authorization and pay (R1).
  3. Present the HIPAA bridge as adjacent, never as healthcare experience.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, digital-health scale-up, ~400 people, Series C | `[grounded]` your JD text; not verified externally |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B tests, Looker, stakeholder partnership | `[grounded]` JD |
| Team | Mentor two junior analysts | `[grounded]` JD |
| Scope read | A senior IC role with a lead-by-influence element, not a people-management role | `[inferred]` from "mentor" against the absence of direct-report language |
| Market calibration | Not established: web research was refused, and I won't supply a salary band from memory | — |
| Unknowns | Compensation, location, contract basis, whether the company is as described | — |
| Contradictions | None found, because no external source was checked | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Candidate constraints: location, work authorization, salary floor, start date | hard_gate | unclear | none | hard_gate | Nothing given, so nothing to grade | — | Q2 below |
| R2 | 5+ years product analytics | must_have | direct | medium | none | Six years stated, consumer subscription; no artifact yet | `[grounded]` your statement | none |
| R3 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, stated; a query sample would raise it | `[grounded]` your statement | offer: anonymized query sample |
| R4 | Experiment design at scale | must_have | direct | medium | none | 30+ tests a year, with an 11% retention lift from a pricing test; the lift needs its readout to be credible | `[grounded]` your statement | offer: the pricing test's design doc or readout |
| R5 | Looker or similar BI | must_have | direct | medium | none | Built the instance from scratch, 40+ governed dashboards | `[grounded]` your statement | offer: anonymized dashboard screenshot |
| R6 | Written communication with non-technical stakeholders | must_have | direct | medium | none | Monthly metrics memo read by the exec team; presents to the VP Product monthly | `[grounded]` your statement | offer: a redacted memo |
| R7 | Define and maintain the metrics layer | must_have | adjacent | medium | discovery | Governed dashboards and consent-state modeling suggest metric-definition work, but I can't tell if you owned the definitions | `[inferred]` from the dashboard and warehouse work | Q3 below |
| R8 | Partner with clinicians | important | adjacent | low | transferability | You partnered with PMs and executives, not clinicians | `[inferred]` from stakeholder work | see G3 |
| R9 | Mentor two junior analysts | important | unclear | low | discovery | Not stated in your message | — | Q1 below |
| R10 | Healthcare data / HIPAA | preferred | adjacent | medium | transferability | You handled GDPR and CCPA consumer PII and built a consent-state model; HIPAA is a different regime (PHI, business associate agreements, minimum-necessary rules), so this is a bridge, not experience | `[inferred]` from the consent and PII work | see G4 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Mentoring (R9) | discovery | Nothing stated | It's an explicit responsibility of the role | Informal coaching of analysts, onboarding, reviewing others' SQL or analyses | Any example you can describe | `[inferred]` |
| G2 | Metrics ownership (R7) | discovery | Governed dashboards, not stated metric definitions | Defining and maintaining the metrics layer is the first responsibility in the JD | A metric dictionary, a semantic layer, or a definition process you ran | Metric definitions or a glossary you wrote | `[inferred]` |
| G3 | Clinician partnership (R8) | transferability | Stakeholder work with product and executives | The JD names clinicians as partners, and that's a different audience | Work with ops, customer support, or any domain experts | A specific example of translating analysis for a non-product audience | `[inferred]` |
| G4 | HIPAA and healthcare data (R10) | transferability | PII handling under GDPR and CCPA, plus a consent-state model | HIPAA is preferred, so the gap is a preference, not a bar | Consent modeling and PII governance, presented as transferable | Any HIPAA training or exposure, however small | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer unverified | unknown | — | "Harborlight Health (digital-health scale-up, ~400 people, Series C)" | The company may exist as described, or the posting may be stale or not from the company. Web research was refused, so this is unchecked, not negative | `[generic]` standing entry for postings of this kind | Can you send the live posting link or the careers-page URL? | unresolved; caps the decision at `conditional_go` |
| RR2 | Salary withheld | unknown | — | JD gives no compensation | The figure may sit below your floor, or may just be unpublished | `[inferred]` from the absent figure | What is your salary floor, and does the posting state a range anywhere else? | unresolved |
| RR3 | Clinical setting may slow experimentation | risk_signal | medium | "care-navigation app", "partner with … clinicians" | Clinical safety review and outcome measures that take longer than retention can limit the test cadence you're used to | `[inferred]` from the clinical setting; not checked against the company | How are experiments reviewed and how are clinical outcomes measured? | unresolved |
| RR4 | Clear scope with mentoring and metrics ownership | positive_signal | — | "mentor two junior analysts"; "define and maintain the metrics layer" | The role is defined enough to plan against | `[grounded]` JD | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the live posting and the employer before investing time | see RR1 | `[grounded]` RR1 | pending your approval |
| P2 | Lead with the 11% pricing-test result and the program, and say how you'd bring the same method to clinical outcomes | see R4, RR3 | `[grounded]` R4 | pending your approval |
| P3 | Describe HIPAA as adjacent: consent modeling and PII governance under other regimes | see R10 | `[inferred]` from R10 | pending your approval |
| P4 | Prepare one mentoring story, even an informal one, before the first interview | see G1 | `[inferred]` from R9 | pending your approval |

## Evidence status

Verified: none yet. Every claim rests on your message, which is a lead until an artifact backs it.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for Harborlight's company page and careers posting were refused (search permission not granted). Would have checked RR1 |
| 2. Role-family sweep | unavailable | A search for senior product analyst pay and scope was refused. Would have calibrated the market line and RR2 |
| 3. Hiring manager's public footprint | n/a | No name given |

## Upgrade menu

- Live posting link or careers-page URL → RR1 closes, and the `conditional_go` condition lifts if it checks out.
- Permission to run web search → the employer check and the role-family salary band become possible; I'd rerun the L1 targets.
- Your constraints (location, work authorization, salary floor, start date) → R1 becomes a real check.
- A query sample, a dashboard screenshot, or the pricing test's readout → R3, R5 and R4 move from `medium` to `high`.
- A redacted monthly memo → R6 moves to `high`.
- Any HIPAA training or exposure → R10 may move from `adjacent`.

If you want, I can write this up as `tuesday-dossier.md` to carry into prep.

1. What informal or formal mentoring have you done with junior analysts, and for how long? (R9, G1)
2. What are your hard constraints: location or time zone, work authorization, salary floor, and earliest start date? (R1, RR2)
3. Did you own the metric definitions, such as a metric dictionary or semantic layer, or only the logic inside the dashboards? (R7, G2)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.