**Yes, apply, but verify Brindlemoor and the live posting first: `conditional_go`.** R2, R3, R4 and R5, which are every must-have row, are direct at medium confidence. The gap is pet-insurance context (R8), which the JD doesn't list as a must-have. The employer check didn't run because web search was refused, so the employer is unverified.

**Fit ledger**

- `hard_gate`: unconfirmed: R1 (Fully remote, UK-based)
- `must_have`: direct: R2, R3, R4, R5
- `important`: direct: R6, R7 · adjacent: R8 (Pet-insurance product pricing)
- `preferred`: direct: R9 (Insurance experience)

R2–R5 are the must-haves, all direct. R8 is the one row below direct, and it is transferability, not a capability gap.

- **Hard gates:** none failed; unconfirmed: R1 (Fully remote, UK-based); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** The scope is concrete (RR4). Three items are unknown: whether the employer is real and the posting live (RR1, standing entry), whether the role manages people (RR2), and pay (RR3, not stated in the JD).
- **Conditions for go:** (1) RR1 verifies: the live posting is on Brindlemoor's own careers site; (2) R1 confirmed: you can work in the UK without sponsorship; (3) R8 is framed honestly as motor-to-pet transfer, never as pet experience.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Brindlemoor, an insurtech; pet-insurance product | `[grounded]` JD header |
| Mandate | Own pricing analytics: build and monitor rating models, design and read price tests, turn results into recommendations for underwriting and product | `[grounded]` JD |
| Working pattern | Fully remote, UK | `[grounded]` JD |
| Hiring manager | Odile Varga, Director of Pricing | `[grounded]` as you gave it; not checked |
| Scope read | A senior analyst role with ownership of the pricing function's analytics. Whether it includes leadership is not stated | `[inferred]` from the title and the verbs |
| Market calibration | Not established. The role-family search was refused, so there is no band | — |
| Unknowns | Employer existence, live posting, pay, line management, who approves rating-model changes | — |
| Contradictions | None visible in the JD text you gave. The careers page wasn't checked | `[grounded]` absence |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Fully remote, UK-based | hard_gate | unclear | none | hard_gate | No location or right-to-work claim from you yet; the gate is surfaced, not worked around | `[grounded]` JD term | Question 1 below |
| R2 | 4+ years pricing or actuarial analytics | must_have | direct | medium | none | Five years in pricing analytics, last two senior; stated, not inspected | `[grounded]` your background | none |
| R3 | Strong SQL and Python | must_have | direct | medium | none | Daily use stated; no code inspected | `[grounded]` your background | Offer a sanitized query or model-code sample |
| R4 | GLM experience | must_have | direct | medium | none | Built and maintained a GLM rating model for the young-driver book (motor) | `[grounded]` your background | none |
| R5 | Presenting to underwriting or actuarial leads | must_have | direct | medium | none | Presents the quarterly pricing review to the head of underwriting | `[grounded]` your background | none |
| R6 | Design and read price tests | important | direct | medium | none | Ran 14 price tests last year with underwriting | `[grounded]` your background | none |
| R7 | Build and monitor rating models | important | direct | medium | none | Maintained the rating model; "monitor" is implied, not stated | `[grounded]` maintain; `[inferred]` monitor | none |
| R8 | Pet-insurance product pricing (inferred from "our pet-insurance product") | important | adjacent | medium | transferability | Rating, GLM and test design carry over. Limit: no pet claims, vet-cost trends or lifetime-cover dynamics exercised | `[inferred]` from the JD's product name against your motor background; `[generic]` that pet loss drivers differ from motor | G1 |
| R9 | Insurance experience | preferred | direct | medium | none | UK motor insurer, five years | `[grounded]` your background | none |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Pet-insurance product pricing (R8, important) | transferability | Motor pricing only | A senior pricing role on a pet product will be probed on the transfer | Any non-motor product you priced (home, travel, a new-product launch) | A sanitized note on what changed when you moved between lines | `[inferred]` bridge from your motor work; `[generic]` that pet loss drivers differ |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and live posting not verified | risk_signal | medium | "Senior Pricing Analyst — Brindlemoor (insurtech)" | The employer may be too new or small for a footprint, the posting may be stale, or it may not be a live hire. The check was refused, so this is not evidence of a problem | `[generic]` pattern for companies of this size, not a claim about this one | Can you point me at the role on your own careers site, and who would I be interviewing with? | unresolved |
| RR2 | Line management not stated | unknown | — | "Senior Pricing Analyst" | The title may carry a people-management expectation, and you have not managed anyone | `[inferred]` from the title against the JD's silence | Does this role line-manage anyone now, or is it expected to within a year? | unresolved |
| RR3 | Pay not stated | unknown | — | No pay term in the JD text you gave | Pay may be withheld until application. No band can be checked here | `[grounded]` absence in the JD text | What is the budgeted base salary for this role? | unresolved |
| RR4 | Concrete, measurable scope | positive_signal | — | "build and monitor rating models, design and read price tests" | The deliverables are specific and match pricing work, which reads as a real analytics mandate | `[grounded]` JD text | Who signs off rating-model changes before they go live, and how often do price tests run? | noted |

**Application plan**

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead your CV with the GLM rating model and the 14 price tests | see R4, R6 | `[grounded]` your background | pending your approval |
| E2 | In the cover note, say pet is new and bridge from motor. Don't claim pet experience | see R8 | `[inferred]` from the R8 limit | pending your approval |
| A1 | Verify Brindlemoor and the live posting before spending application effort | see RR1 | `[generic]` standing entry | pending your approval |
| A2 | Ask RR2 and RR3 verbatim at the first call | see RR2, RR3 | `[grounded]` register | pending your approval |

**Evidence status**

Verified: none yet. Everything above is your own statement, not yet checked.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searched "Brindlemoor insurtech pet insurance" and "Brindlemoor Senior Pricing Analyst careers"; both refused, as web search permission was not granted. Would have moved RR1 |
| 2. Role-family sweep | unavailable | Searched "senior pricing analyst UK insurance salary GLM"; refused. Would have set the market calibration line and RR3's band |
| 3. Hiring manager's public footprint | unavailable | Searched "Odile Varga Director of Pricing insurance"; refused. Would have moved the scope read and positioning |

**Upgrade menu**

- A link to the live posting or Brindlemoor's careers-page URL: clears or confirms RR1, the largest open item in the decision.
- Your location and right-to-work status: moves R1 from unclear to direct or hard_gate_fail.
- Web search permission, then a rerun of the three targets (up to 5 searches and 2 fetches): a market pay band for RR3, Odile's public footprint, and Brindlemoor's presence.
- One sanitized pricing artifact, such as a rating-model summary or a test readout: raises R3 and R4 from medium to high.
- A product you priced outside motor: narrows R8's limit.

I can write this up as a `tuesday-dossier.md` you can keep and reuse.

Questions:

1. R1: Are you based in the UK, and can you work here without sponsorship?
2. RR2: Would you take this role if it came with managing a small team later, given you haven't managed anyone yet?
3. RR1: Can you paste the live posting link or the Brindlemoor careers-page URL?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.