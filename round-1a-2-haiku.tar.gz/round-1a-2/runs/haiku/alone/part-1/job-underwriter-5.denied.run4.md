**Yes, it's worth applying, provided the location and pay checks clear: `conditional_go`.** The stack matches well. The gaps are BigQuery, app and CRM ingestion, and data contracts. Two hard gates (location and pay floor) are unchecked because you haven't told me your constraints.

**Fit ledger.**

- `hard_gate` — unclear: R1 (remote in the US, or the Denver office), R2 (salary $148,000–$166,000 plus equity)
- `must_have` — direct: R3 (5+ years data engineering), R4 (strong SQL and Python), R5 (dbt and a cloud warehouse), R7 (orchestration with Airflow or similar), R8 (experience with data quality testing)
- `important` — adjacent: R6 (dbt-modelled warehouse in BigQuery), R10 (data contracts our analysts depend on); unclear: R9 (ingestion from our app and CRM)

R6 — Snowflake and dbt carry over, BigQuery not used; R10 — Great Expectations is adjacent, contracts not yet described; R9 — no app or CRM ingestion in the material.

**Opportunity ledger.** Pay sits inside the market band (RR2, positive). Scope may be wider than one domain (RR1, medium risk). Equity size, the hiring manager and whether the posting is live are unknown (RR3, RR4, RR5).

- **Hard gates:** none failed; unconfirmed: R1 (remote in the US, or the Denver office), R2 (salary $148,000–$166,000 plus equity); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **What would change this:** for `conditional_go`, the conditions are (1) R1: you're US-based and can work remote or from Denver; (2) R2: $148,000 meets your floor; (3) RR5: the posting is confirmed live on Pellucid's own careers page.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Pellucid Learning: live online K-12 tutoring in 31 states, founded 2016, Denver, 264 staff, Series C ($52M, Feb 2026) | `[grounded]` the About text you pasted; not verified (see RR5) |
| Mandate | Build and run reporting pipelines: ingestion from the app and CRM, a dbt warehouse on BigQuery, and data contracts for analysts | `[grounded]` JD |
| Level | Senior, 5+ years | `[grounded]` JD; `[generic]` the report's typical 5–8 years for "senior" |
| Working pattern | Remote (US) or Denver office | `[grounded]` JD |
| Pay | $148,000–$166,000 plus equity; the posted midpoint is $157,000 | `[grounded]` JD |
| Market calibration | The report's Senior Data Engineer base median is $151,000 (IQR $139,000–$163,500) at Series B–D companies. The posted range sits around that median, and Pellucid's Series C is inside the report's stage band. | `[grounded]` the report as you sent it; `[generic]` as a pattern for this title, not this employer's offer |
| Scope read | Three areas (ingestion, warehouse modelling, contracts) for one role is wider than the report's typical one-domain ownership | `[inferred]` from the JD's responsibilities, against `[generic]` the report's one-domain norm |
| Unknowns | Hiring manager, equity size and vesting, team size, whether the role is the sole owner | — |
| Contradictions | None between the JD and the About text | `[grounded]` both as pasted |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Remote (US) or Denver office | hard_gate | unclear | none | hard_gate | Your location is not in the material, so the gate is not established | `[grounded]` JD; no candidate statement | Q1 below |
| R2 | Salary $148,000–$166,000 plus equity | hard_gate | unclear | none | hard_gate | Your pay floor is not in the material | `[grounded]` JD; no candidate statement | Q2 below |
| R3 | 5+ years data engineering | must_have | direct | medium | none | Six years at a B2B payroll company, stated in intake; no artifact to inspect | `[grounded]` your stated background | none |
| R4 | Strong SQL and Python | must_have | direct | medium | none | Daily use of both, stated in intake | `[grounded]` your stated background | none |
| R5 | dbt and a cloud warehouse | must_have | direct | medium | none | About 180 dbt models on Snowflake; Snowflake meets "a cloud warehouse" as written | `[grounded]` your stated background | none |
| R6 | dbt-modelled warehouse in BigQuery | important | adjacent | low | transferability | Snowflake and dbt carry over; no BigQuery use. Lower band taken because the carry-over is a judgement | `[grounded]` "never used BigQuery"; `[inferred]` that dbt and SQL transfer | G1 below |
| R7 | Orchestration with Airflow or similar | must_have | direct | medium | none | Airflow used for orchestration, stated in intake | `[grounded]` your stated background | none |
| R8 | Experience with data quality testing | must_have | direct | medium | none | Set up a Great Expectations test suite, stated in intake | `[grounded]` your stated background | none |
| R9 | Ingestion from our app and CRM | important | unclear | low | discovery | Material says data engineering at a payroll company, not which sources were ingested | `[grounded]` absence in intake | Q3 below |
| R10 | Data contracts our analysts depend on | important | adjacent | low | transferability | Great Expectations validates data; agreed producer-consumer contracts are not described | `[inferred]` adjacency from the test suite | G2 below |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | BigQuery specifics (R6, important) | transferability | Snowflake and dbt work; no BigQuery use | The posting names BigQuery as the warehouse. The limit is platform-specific: partitioning, clustering, cost model, datasets and IAM | Dbt models on any warehouse; cost or performance work on Snowflake that transfers | A small dbt project on BigQuery, if you build one; otherwise, say you haven't used it | `[grounded]` intake; `[inferred]` the transfer |
| G2 | Ingestion and data contracts (R9, R10) | discovery | Ingestion sources and contract ownership not described | These are two of the three named responsibilities, and nothing in the material settles them | Pipelines ingesting an app database or a CRM; schema or freshness agreements with consumers | A sanitized ingestion DAG or contract document, only what your employer allows you to share | `[grounded]` absence in intake; `[inferred]` the adjacency |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Three responsibility areas for one senior role | risk_signal | medium | "Build and run the pipelines behind our tutoring platform's reporting" | The role may own the whole reporting data stack, not one domain | `[inferred]` from the three responsibilities; `[generic]` the report's one-domain norm | Which parts of the reporting pipeline does this role own end to end, and who else works on them? | unresolved |
| RR2 | Pay sits inside the market band | positive_signal | — | "$148,000–$166,000 plus equity" | The range is in line with the title and stage | `[grounded]` JD and report as sent; `[generic]` the band | Is the salary range final? | noted |
| RR3 | Equity size withheld | unknown | — | "plus equity" | Equity may be meaningful or token; the posting doesn't say | `[grounded]` JD silence | What equity comes with the role, and on what vesting terms? | unresolved |
| RR4 | No hiring manager named | unknown | — | Posting names no hiring manager | The reporting line is unknown | `[grounded]` JD silence | Who would I report to, and who is the hiring manager? | unresolved |
| RR5 | Posting and employer not verified this session | unknown | — | "Senior Data Engineer, Pellucid Learning" | The posting may be live on the careers page, or the copy may be stale | `[grounded]` search was declined, so nothing was checked | Is this role open on your careers page now, and is the Denver/remote setup as posted? | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead the application with your own matching facts: six years of data engineering, a dbt project of about 180 models on Snowflake, Airflow, a Great Expectations test suite | R3, R5, R7, R8 | `[grounded]` your intake, no new wording | pending your approval |
| P2 | When BigQuery comes up, say plainly that you haven't used it, and name the Snowflake dbt work as what carries over | R6 | `[grounded]` intake; `[inferred]` the carry-over | pending your approval |
| P3 | Ask the recruiter for the hiring manager's name and confirm the posting is live on pellucidlearning.com | RR4, RR5 | `[grounded]` posting silence | pending your approval |

## Evidence status

Verified: none yet.

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were sent ("Pellucid Learning live online tutoring K-12 Denver" and "Pellucid Learning senior data engineer job"); both were refused, so the entity and the live posting are unchecked. This would have moved RR5 and the employer's footprint |
| 2. Role-family sweep | skipped | The Datawright report you sent already covers Senior Data Engineer pay and scope at Series B–D companies, so no search was needed |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

Dossier offer: I can write this up as `tuesday-dossier.md` for later interview prep whenever you want.

Upgrade menu:

- Search permission (declined here): with it, I can check that the company exists as described and that the posting is live, using up to 5 searches and 2 page fetches. This moves RR5.
- A link to the live posting, or the careers-page text pasted here, also closes RR5 without search.
- The equity grant size and vesting terms close RR3.
- The hiring manager's name closes RR4 and tells us which story to lead with for that reader.
- A sanitized ingestion DAG or data-contract document from your payroll work, only what your employer lets you share, would move R9 and R10 from `low`.

Questions:

R1 — Are you based in the US, and could you work fully remote or from the Denver office?

R2 — Is $148,000, the bottom of the posted range, at or above your floor?

G2 (R9, R10) — Have you built ingestion from an application database and a CRM, and agreed a data contract with analysts? What did you own, and which sources were involved?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.