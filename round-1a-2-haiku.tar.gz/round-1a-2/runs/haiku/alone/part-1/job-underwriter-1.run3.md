## Decision snapshot

**Worth applying to, on three conditions. Status: `conditional_go`.**

**Fit ledger.**

- `hard_gate`: unclear: H1 (location, work authorization and contract basis are not stated, and your constraints were not given)
- `must_have`: direct: R1, R2, R3, R4, R6 · adjacent: R5
- `important`: adjacent: R7 · unclear: R8
- `preferred`: adjacent: R9

**Opportunity ledger.** Sound on its stated scope, but under-specified. The posting withholds pay and location, does not name the employer's live posting in what you gave me, and says nothing about mentoring. The healthcare context is the largest real gap. One entry runs the other way: the duties are concrete and map closely onto a program you built (RR5).

- **Hard gates:** none failed; unconfirmed: H1. Candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the employer and posting are confirmed live and as described (RR1); (2) location, contract type and pay are stated (H1, RR2); (3) mentoring scope is confirmed before you claim it (R8, RR4).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Harborlight Health, a digital-health scale-up of about 400 people, Series C | `[grounded]` your description of the JD; not checked (RR1) |
| Mandate | Own product analytics for the care-navigation app: metrics layer, A/B testing, self-serve Looker, PM and clinician partnership, two junior analysts | `[grounded]` JD |
| Scope read | Five duties plus mentoring, a senior IC scope with people leadership attached | `[inferred]` from the duty count |
| Market calibration | Not run: research was unavailable (see Evidence status) | — |
| Unknowns | Pay, location, contract type, data access (PHI or not), decision rights on metrics definitions, mentoring scope | — |
| Contradictions | None between the JD and your description of it | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | 5+ years product analytics | must_have | direct | medium | none | Six years at one company, stated by you; consistent across inputs, no artifact | `[grounded]` your statement | none |
| R2 | Expert SQL | must_have | direct | medium | none | Daily SQL on Snowflake, stated; no query sample yet | `[grounded]` your statement | optional: a sanitized query sample |
| R3 | Experiment design at scale | must_have | direct | medium | none | 30+ A/B tests a year and a program you designed; the 11% retention lift is a result you report, not yet a method you have shown | `[grounded]` your statement | P1 |
| R4 | Looker or similar BI | must_have | direct | medium | none | Built the instance and 40+ governed dashboards from scratch | `[grounded]` your statement | none |
| R5 | Define and maintain a metrics layer | must_have | adjacent | medium | discovery | Governed dashboards and a monthly metrics memo suggest metric definition work, but you have not stated owning a metric definitions layer | `[inferred]` from the dashboard and memo work | G3 |
| R6 | Written communication with non-technical stakeholders | must_have | direct | medium | none | You write the monthly memo the exec team reads and present it to the VP Product | `[grounded]` your statement | a sanitized memo would raise to high |
| R7 | Partner with PMs and clinicians on roadmap decisions | important | adjacent | low | transferability | Exec and VP Product partnership is shown; clinician partnership is absent | `[inferred]` | G4 |
| R8 | Mentor two junior analysts | important | unclear | low | discovery | Not mentioned in your inputs; the CV is silent | `[grounded]` silence | G2 |
| R9 | Healthcare data and HIPAA | preferred | adjacent | medium | transferability | No healthcare work. GDPR/CCPA consumer PII handling and a consent-state model are the nearest transfer | `[inferred]` | G1 |
| H1 | Location, work authorization and contract basis | hard_gate | unclear | unknown | hard_gate | The JD states none of these, and your constraints were not given | `[grounded]` JD silence | Q1 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Healthcare data and HIPAA (R9, preferred) | transferability | Consumer PII under GDPR/CCPA and a consent-state model in the warehouse; no PHI | The JD lists HIPAA as a plus, so it does not block, but it is the most visible absence | Any work on sensitive-category data, access controls, or de-identification | A short description of how the consent model handled sensitive categories | `[inferred]` |
| G2 | Mentoring (R8, important) | discovery | Nothing in your inputs | An explicit duty of the role | Onboarding or reviewing another analyst's work, even informally | One example of a mentoring or review responsibility | `[grounded]` silence |
| G3 | Metrics layer ownership (R5, must_have) | discovery | Governed dashboards and a metrics memo; no statement of owning metric definitions | The duty is first on the JD; the evidence is probably there but unstated | A metric definitions doc, a semantic-layer standard, or a KPI tree you owned | A metric definition you wrote, sanitized | `[inferred]` |
| G4 | Clinician and PM partnership (R7, important) | transferability | Exec and VP Product partnership; no clinician-facing work | Clinicians are named in the JD as stakeholders | A roadmap decision you traced to an analysis, with PM sign-off | One example of a PM-led decision you influenced | `[inferred]` |

## Opportunity risk register

**Standing entry:** Employer existence and posting not verified. Research was unavailable, so the company facts (size, stage, product) are your description, not checked.

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer and posting unverified | unknown | — | JD header | The company and posting match the JD, but nothing here confirms it | `[grounded]` no research ran | Is there a live posting or careers page link? | unresolved |
| RR2 | Pay and location withheld | unknown | — | JD silence | Pay may sit below your band, or the posting simply omits it; remote terms are unknown | `[inferred]` from the silence | What is the pay range and the location or remote policy? | unresolved |
| RR3 | Role likely touches PHI; you have no healthcare experience | risk_signal | medium | "healthcare data experience (HIPAA) a plus" | Warehouse data includes PHI, so the role needs HIPAA-aware handling you have not practiced | `[inferred]` from the JD's HIPAA line | Does this role access PHI directly, and what is the data-access model? | unresolved |
| RR4 | Mentoring scope unknown | unknown | — | "mentor two junior analysts" | Mentoring may be a formal people-management remit, which would change the level of the role | `[inferred]` | Is mentoring a formal reporting line, or an informal duty? | unresolved |
| RR5 | Duties map onto a program you built | positive_signal | — | "define and maintain the metrics layer… design and analyze A/B tests" | The role's scope is defined and matches your strongest area | `[inferred]` from JD against your inputs | — | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Lead with the experimentation program. State the 11% lift as the measured result of one pricing test, with its interval and design, not as a general claim about your work | Keeps R3 strong without overclaiming | `[grounded]` your statement; the framing is `[inferred]` | pending your approval |
| P2 | Prepare one sanitized metrics memo sample with no confidential figures | A work sample would raise R6 to high | `[inferred]` | pending your approval |
| P3 | Describe healthcare as an adjacent transfer: consent-state and PII work under GDPR/CCPA. Do not use the words HIPAA or healthcare experience | Honest transfer; the claim you can defend | `[grounded]` your statement; the wording is `[inferred]` | pending your approval |
| P4 | Confirm the posting is live before investing time | RR1 | `[grounded]` RR1 | pending your approval |
| P5 | Do not claim mentoring or clinician partnership until you have one concrete example each | R7, R8 | `[grounded]` gap rows G2, G4 | pending your approval |

Nothing above is approved for use. No CV or outreach wording is drafted yet.

## Evidence status

Verified: none yet. Every candidate claim in the map rests on your statement in this engagement. No artifact has been checked.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches were refused because the search tool was not granted permission. This leaves RR1 open and the contradictions row unchecked |
| 2. Role-family sweep | unavailable | The same refusal. Would have set the market calibration line against pay and scope norms for this seniority |
| 3. Hiring manager's public footprint | n/a | No name was given, so there was no query to form |

## Upgrade menu

- A live posting or careers page link → RR1 closes, and the contradictions row gets checked.
- Permission for the search tool → targets 1 and 2 run at L1, which fills the market calibration line and checks the employer.
- Pay, location and contract type → H1 and RR2 close, and the decision may move to `go` or `no_go`.
- One mentoring example → R8 moves from unclear to direct or adjacent.
- A sanitized metrics memo → R6 moves to high confidence.
- A deeper research pass on Harborlight Health (funding, leadership changes, public candidate reports; up to 5 more searches and 2 more fetches). Say the word and it runs.

## Questions

1. **H1 / RR2:** What are the pay range, the location or remote policy, and the contract type? Tell me your own non-negotiables on each, and I can check them against the role.
2. **R8 / RR4:** Have you mentored or formally reviewed the work of other analysts? And is this role a formal people-management position?
3. **RR3 / G1:** Does this role work with PHI directly, or does it use de-identified or aggregate data?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.