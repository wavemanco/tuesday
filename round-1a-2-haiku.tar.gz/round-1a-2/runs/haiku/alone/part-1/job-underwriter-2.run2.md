**Not a waste of time, but not worth a cold application to this JD as written.** The must-have is three years of product management, and you don't hold that by title. Whether you can credibly claim it depends on whether you've owned product decisions in practice. That is the answer that would change this. `hold_pending_answers`

**Fit ledger.**

- `must_have`: direct: R3, R4a · adjacent: R1, R2, R6 · unclear: R4b, R5
- `important`: direct: R8 · adjacent: R7, R10 · unclear: R9

R1 (`low`) — PM-shaped work without PM ownership; R2 (`medium`) — shipped integrations, not a shipped product; R9 (`low`) — no adoption metrics on the CV.

- **Hard gates:** none failed; the JD states no hard gates; candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** The role is concrete: a defined partner-facing platform, two squads, named responsibilities. RR1 (pay not in the JD text) and RR2 (employer unchecked) are open. RR3 is a risk signal: a 3+ year must-have on a platform role can mean you'd be the first PM on it, with no peer to learn from `[inferred]`.

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Quartzline, B2B logistics tech, ~150 people, Series B | `[grounded]` JD header; not verified (search denied) |
| Mandate | Own the partner API roadmap; partner discovery; specs; two squads; adoption metrics; launch with sales and support | `[grounded]` JD |
| Implied must-have | Roadmap ownership is a responsibility, so I've treated it as must-have | `[inferred]` from the JD's "own the roadmap" |
| Scope read | Ordinary for a PM on one platform surface, but with two squads it's a full-time owner | `[inferred]` from the squad count |
| Market calibration | Not run: web search was denied this session | — |
| Unknowns | Pay, contract type, location, whether this is the first PM on the platform, how adoption is measured | — |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| R1 | 3+ years PM experience | must_have | adjacent | low | transferability | Roadmap-input sessions, requirements docs, coordinating PMs. No PM title, and no evidence you owned prioritization or launch decisions | `[grounded]` CV; `[inferred]` the ownership read |
| R2 | Shipped API or platform products | must_have | adjacent | medium | transferability | 30+ REST integrations delivered end to end. You shipped the client's implementation, not a product you owned | `[grounded]` CV |
| R3 | Technical fluency: API docs, schemas | must_have | direct | medium | none | Postman, SQL, OpenAPI, integration architecture | `[grounded]` CV |
| R4a | Stakeholders: engineering and customers | must_have | direct | medium | none | Coordinated vendor engineers, client engineers and PMs; UAT and go-live | `[grounded]` CV |
| R4b | Stakeholders: sales | must_have | unclear | low | discovery | Sales isn't mentioned | — |
| R5 | Agile delivery | must_have | unclear | low | discovery | No sprint or agile experience stated | — |
| R6 | Own the roadmap | must_have | adjacent | low | transferability | Quarterly roadmap-input sessions feeding product; no ownership of the roadmap itself | `[grounded]` CV |
| R7 | Discovery with integration partners | important | adjacent | medium | transferability | Scoping workshops and client feedback sessions; not product-agenda discovery | `[grounded]` CV |
| R8 | Write specs | important | direct | medium | none | Requirements documents and integration architecture | `[grounded]` CV |
| R9 | Define and track adoption metrics | important | unclear | low | discovery | Nothing stated. A prior note may be relevant (see G1) | — |
| R10 | Launch coordination with sales and support | important | adjacent | medium | transferability | Go-live coordination with clients; not sales or support launches | `[grounded]` CV |

**Gap recovery queue**

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | PM ownership and adoption metrics (R1, R6, R9) | discovery | No stated product decision you owned, judged on a metric | This is the must-have. Its answer moves the decision | A prioritization call you made and defended; a feature or internal tool you chose to build; a metric you were held to | A roadmap doc, decision memo, or dashboard you used | `[grounded]` CV silence; `[inferred]` that this moves the status |

**Opportunity risk register**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer unchecked | risk_signal | medium | "Quartzline (B2B logistics-tech, ~150 people, Series B)" | Employer may be real but unverified here; search was denied, so this is unchecked, not established | `[generic]` pattern for early-stage employers | Can you point me to this role on Quartzline's own careers page, and who would I be interviewing with? | unresolved |
| RR2 | Compensation absent | unknown | — | (no pay in JD text) | Pay may sit below your expectation for this scope | `[inferred]` from the JD's silence | What is the base range budgeted for this role? | unresolved |
| RR3 | First PM on the platform? | risk_signal | low | "Own the roadmap for our partner-facing API platform" | With no PM peers to learn from, the 3+ year bar may be a hiring-manager wish, not a team norm | `[inferred]` from the scope against a 3+ year must-have | Who else currently owns product decisions for this platform, and who would I report to? | unresolved |

**Application plan** (every row needs your approval)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Describe the roadmap-input work truthfully, e.g. "Ran quarterly client roadmap-input sessions and synthesized feedback into product planning." Don't write "owned the roadmap." | R6 | `[grounded]` CV; reframing audit applied | pending your approval |
| P2 | If the triage tool is real, document its adoption: users, volume, time saved | R9, R2 | Lead only, unconfirmed | pending your confirmation |
| P3 | Verify the posting on Quartzline's own careers page before investing effort | RR1 | `[generic]` | pending your approval |
| P4 | Ask RR3 in the first recruiter contact | RR3 | Register | pending your approval |
| P5 | Widen the search to technical or solutions PM roles and API-platform roles at API-first companies, where implementation experience is valued | R1 gap | `[generic]` pattern, not checked against a market | pending your approval |

**Evidence status.** Verified: none yet. Unverified lead: a note from an earlier conversation says you built an internal request-triage tool that support agents adopted. I have not counted it as evidence. If it's real, it's the strongest PM-like claim you have, because it's a product you built and people used.

**Research tier:** L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Web search was denied in this session (3 searches refused). Quartzline's existence and the live posting are unchecked; RR1 stays open |
| 2. Role-family sweep | unavailable | Same denial. The market calibration line and the "3+ years" norm are unchecked |
| 3. Hiring manager's public footprint | n/a | No name given |

You are weighing an opportunity, so the dossier offer: I can write this analysis to `tuesday-dossier.md` so it's kept with the open questions.

**Upgrade menu**

- Your answer to G1 → R1 and R6 move toward `direct` or stay `adjacent`. This decides between `go`, a conditional go, or a pass.
- Confirming the triage tool, with adoption numbers → R9 moves off `unclear`, and R2 gets its first shipped-product evidence.
- Granting web search → targets 1 and 2 run (up to 5 searches and 2 fetches): the employer check and what "3+ years" PM roles at this scope pay and require.
- Your hard constraints (pay floor, location, contract type) → the hard-gate checks run.

**Questions**

G1 — Have you ever owned a product decision end to end: chosen what got built, been judged on a metric, and seen what happened? If so, what was it?

R9 — Did you build an internal request-triage tool that support agents adopted? If so, what did it do, and how do you know people used it?

Constraints — The JD doesn't state pay, location or contract type. Do you have hard constraints I should check this role against?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip. Web search for targets 1 and 2 is available if you grant permission.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.