**Worth applying to, on three conditions. Status: `conditional_go`.** Both gates you have to clear are met, and most of the essential duties match your evidence. The gaps are your first caseload and the records and leg-ulcer work the CV doesn't show.

**Fit ledger.**

- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5, R7, R9 · adjacent: R6, R10, R12 · unclear: R4
- `important`: unclear: R8, R11, R13
- `preferred`: absent: R14

R12 — your home-visit work is a bridge, and its limit is that you've never held a caseload; R4 — nothing in the CV shows records, so it stays unconfirmed.

**Opportunity ledger.** The employer checks out as a real, established provider (RR3). The posting itself is not yet confirmed live (RR2), and caseload support is undefined (RR1).

- **Hard gates:** none failed (R1 `direct`, R2 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the post is confirmed open through the named contact (RR2); (2) you can show or describe clear written records (R4); (3) RR1 comes back with a realistic caseload and supervision picture, and your caseload gap is described as adjacent, not as experience you have.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health CIC: adult community nursing, therapy and rehab in Calderdale under an NHS contract; founded 2015; 410 staff across four locality hubs | `[grounded]` calderbrookhealth.example/about (search snippet) |
| Role | Band 5 community staff nurse; housebound adults at home; a small personal caseload with senior nurse support | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage, stated | `[grounded]` advert |
| Pay calibration | Survey median £34,300, interquartile range £32,400–£36,600. The advert's range sits around that median, so it reads as normal for the band, not a mismatch. Self-reported survey, n=1,240, 2026 | `[generic]` Wardround 2026 community nursing pay guide |
| Unknowns | Caseload size; how senior support works day to day; on-call; whether the post is still open | — |
| Contradictions | None found between the advert and the employer's About page | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | Your CV states it, with registration active and revalidation due March 2028 | `[grounded]` CV | none |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Full UK licence, category B, as stated | `[grounded]` CV | none |
| R3 | At least one year post-registration | must_have | direct | medium | none | Five years as a staff nurse | `[grounded]` CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV is silent on documentation; the advert's EPR wording isn't matched | `[grounded]` CV silence | G1 |
| R5 | Wound care (pressure ulcers, surgical wounds) | must_have | direct | medium | none | Named in the CV | `[grounded]` CV | none |
| R6 | Leg-ulcer care | must_have | adjacent | medium | transferability | General wound care carries over; no leg-ulcer or compression work is named. Limit: venous-specific assessment and compression | `[inferred]` from R5 | G2 |
| R7 | Catheter care | must_have | direct | medium | none | Named in the CV | `[grounded]` CV | none |
| R8 | Continence care | important | unclear | low | discovery | Only catheter care is named | `[grounded]` CV silence | ask in G2 block |
| R9 | Insulin administration | must_have | direct | medium | none | Named in the CV | `[grounded]` CV | none |
| R10 | Care planning | must_have | adjacent | medium | transferability | Discharge-to-assess visits planned first-week care at home; the CV doesn't say whether you owned the plan. Limit: longer-term planning for a caseload | `[inferred]` from the discharge-team role | G3 |
| R11 | End-of-life visits | important | unclear | low | discovery | The CV is silent on palliative or end-of-life visits | `[grounded]` CV silence | ask in G2 block |
| R12 | Holding your own caseload | must_have | adjacent | medium | transferability | Home visits in the discharge team carry over; you have never managed a caseload yourself | `[grounded]` CV for the visits; `[inferred]` for the adjacency | G3 |
| R13 | Electronic patient record | important | unclear | low | discovery | The CV doesn't name a record system | `[grounded]` CV silence | ask in G1 |
| R14 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No Doppler work; preferred, so a minor gap | `[grounded]` CV | closure path in the risk register |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Written records and EPR (R4, R13) | discovery | No documentation or record-system detail on the CV | An essential requirement; if it's proven, it is the strongest answer to the advert | Handover and discharge notes; any electronic record system you've used; audit or complaint learning on documentation | An anonymised record entry, or a description of the system | `[grounded]` CV silence; `[inferred]` that this is the essential item to close |
| G2 | Leg-ulcer, continence, end-of-life (R6, R8, R11) | discovery | Wound and catheter care are named; leg ulcers, continence and palliative work are not | Leg ulcers appear in the core duties and in the desirable list; end-of-life visits are a named duty | Compression or venous care; continence or bladder work; end-of-life or palliative discharge planning | Training records or a supervised-practice log | `[grounded]` CV silence; `[generic]` that district nursing teams weight these heavily |
| G3 | Caseload and care planning (R10, R12) | transferability | Home visits and discharge planning are real; you've never owned a caseload | The biggest role change: this is a caseload-holding job | Planning first-week care for patients you visited; prioritising visits; handing over to a GP or senior nurse | A sanitised care plan | `[grounded]` CV; `[inferred]` adjacency |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload size and senior support not stated | unknown | — | "a small caseload of your own, supported by a senior community nurse" | The caseload could be large, or the support could be remote | `[inferred]` from the advert's silence on caseload size | What is the typical caseload for a new Band 5, and how is senior support arranged day to day? | unresolved |
| RR2 | The posting's live status is unconfirmed | unknown | — | "Community Staff Nurse, Band 5" | The advert may be stale, or it may be listed in a different place | `[grounded]` careers page not found at the guessed address | Is this post still open, and where should I apply? | unresolved |
| RR3 | Established employer with a stated NHS contract | positive_signal | — | "Calderbrook Community Health CIC" | Stable, real employer | `[grounded]` About page | — | noted |
| RR4 | Named contact for an informal chat | positive_signal | — | "contact Rhiannon Mabbott, Community Nursing Team Lead" | The employer is open to pre-application questions | `[grounded]` advert | Can I ask about caseload size and supervision in an informal chat? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| E1 | Lead the CV with the home-visit work: wound care, catheter care, insulin administration, each with the patient group | Your strongest match to the duties, all already on the CV | `[grounded]` CV | pending your approval |
| E2 | Describe the caseload gap as adjacent: home visits and discharge planning, with no caseload claimed | Keeps the claim within what you can defend in interview | `[grounded]` R12 | pending your approval |
| A1 | Contact Rhiannon Mabbott for the informal chat and ask RR1 and RR2 | Resolves the conditions before you invest in the application | `[grounded]` RR1, RR2, RR4 | pending your approval |

Nothing in E1 or E2 adds a fact; both reorder or describe what the CV already says. Please approve before anything goes out.

## Evidence status

Verified: R1, R2, R3, R5, R7, R9 (from the CV, not yet user-confirmed text). Unverified leads: none. Rejected inferences: none.

Research tier: L1 — searches 2 of 5, fetches 1 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax community staff nurse", which returned the About page (calderbrookhealth.example/about). Fetched a guessed careers address, which returned no page, so the posting's live status is still unconfirmed (RR2). Confirmed the employer as established |
| 2. Role-family sweep | yes | Searched "Agenda for Change Band 5 pay scale 2026/27 England", which returned "Wardround 2026 UK Community Nursing Pay Guide" (wardround.example/2026-uk-community-nursing-pay-guide). Set the pay calibration in role reality |
| 3. Hiring manager's public footprint | n/a | No name was given beyond the contact, so there was no query to form |

## Upgrade menu

- An anonymised record entry, or a description of the record system you've used → R4 and R13 move up.
- Any leg-ulcer, compression or continence work → R6 and R8 move up.
- Any end-of-life or palliative visits → R11 moves up.
- The contact's answer on caseload size and supervision → RR1 closes.
- A deeper pass on Calderbrook (up to 5 more searches and 2 more fetches) would check their careers page and any staffing reports. Say the word and it runs.

If you want to keep this analysis, I can write it up as a `tuesday-dossier.md` file.

1. Did you ever write a record or handover that someone else acted on without asking you anything? How was it recorded, and was it electronic? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip. (G1)
2. Have you done any leg-ulcer compression, venous assessment or continence work, even under supervision? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip. (G2)
3. On your discharge visits, did you ever plan care for a patient over several visits, or hand over to someone who then took the plan on? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip. (G3)

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.