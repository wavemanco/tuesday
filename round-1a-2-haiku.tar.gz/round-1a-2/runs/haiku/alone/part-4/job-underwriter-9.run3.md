**Yes, asking for bank details, a PPS number and a passport check is normal onboarding for a payroll job, once a written offer is in place.** Enter them only in the employer's own portal, at the address on its own website, not through a link in the offer email. I could not verify Marrowgate Housing from here, so check that first. Status: `conditional_go`.

**Decision snapshot**
- **Status:** `conditional_go`. Apply once the employer checks out and the open terms are confirmed.
- **Fit ledger:**
  - `direct`: R1 (3 years' fortnightly payroll, `high`), R3 (Excel, `high`), R4 (certificate, `high`), R6 (starters and leavers, `high`), R7 (payroll-to-ledger reconciliation, `high`).
  - `adjacent`: R2 (Irish PAYE/PRSI/USC, `medium`; the hotel role's Irish scope isn't stated), R5 (240 monthly against 90 fortnightly, `medium`).
  - `absent`: R8 (pension changes; you've never done them, `low`).
  - `unclear`: R9 (staff queries; not shown in your background).
  - Gate rows H1 and H2 are `unclear` (see below).
- **Opportunity ledger:** The posted pay band matches the offer (RR-none). The scope is concrete: monthly cycle, reconciliation, reporting to a named Finance Manager. The offer is thin, and the employer is unverified (RR1).
- **Hard gates:** none failed (no gate row met yet); unconfirmed: H1 (hybrid, two days a week in Limerick), H2 (€40,000 against your pay floor); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** RR1 clears (you find the employer and the portal on its own site); the written contract arrives; H1 and H2 confirm.

**Role reality**
- **Role:** Permanent Payroll Administrator, €40,000, hybrid with two office days in Limerick, reporting to Declan Garvagh, Finance Manager.
- **Scope:** Monthly payroll for 240 staff, starters and leavers, pension changes, monthly payroll-to-GL reconciliation, staff queries. `[grounded]` from the posting.
- **Pay:** €40,000 sits inside the posted €38,000–€42,000 band `[grounded]`. I could not check market pay for this role, because web search was refused. No market band is given.
- **Contradictions and unknowns:** The offer has no written contract, start date, notice terms, pension scheme details or probation. The posting wants Irish PAYE/PRSI/USC; your background doesn't say whether the hotel payroll was Irish.

**Evidence map**

| # | Priority | Fit | Confidence | Requirement | Evidence |
|---|---|---|---|---|---|
| R1 | must_have | direct | high | 2+ years running payroll | 3 years fortnightly payroll, 90 staff |
| R2 | must_have | adjacent | medium | Working knowledge of Irish PAYE/PRSI/USC | Payroll Technician certificate 2024 `[inferred]`; Irish scope of hotel payroll not stated |
| R3 | must_have | direct | high | Strong Excel | Daily use: pivots, XLOOKUP |
| R4 | must_have | direct | high | Payroll qualification or working towards one | Payroll Technician certificate, 2024 |
| R5 | important | adjacent | medium | Monthly payroll for 240 staff | Fortnightly for 90; monthly cycle is new `[inferred]` |
| R6 | important | direct | high | Process starters and leavers | 3 years |
| R7 | important | direct | high | Monthly payroll-to-GL reconciliation | Done at the hotel group |
| R8 | important | absent | low | Process pension changes | Never done; your manager handled them |
| R9 | preferred | unclear | low | Answer staff payroll queries | Not shown in your background |
| H1 | hard_gate | unclear | — | Hybrid, two days a week in Limerick | Your location not given |
| H2 | hard_gate | unclear | — | €40,000 against your pay floor | Floor not given |

**Gap recovery queue**
- **R2:** Confirm whether the hotel group ran Irish PAYE/PRSI/USC payroll and whether you handled it. The certificate covers the theory; the question is hands-on use.
- **R5:** Scale and cycle change. Closed by a question about how you've handled larger volumes or a monthly cycle.
- **R8:** No pension experience. Closed by learning on the job, and by knowing who administers the scheme and what training they give.
- **R9:** Not shown. Closed by describing how queries reached you at the hotel group.
- **H1, H2:** Need your location and pay floor.

**Opportunity risk register**

**RR1 (standing entry: employer not established)**
- **Class / severity:** `risk_signal` / `medium`.
- **Source quote:** "Marrowgate Housing, a housing association in Limerick"; offer from people@marrowgatehousing.ie.
- **Hypothesis:** I could not confirm the employer from here, because search was refused. The offer's domain is company-style, but that isn't verified. `[generic]` pattern for employers of this kind, not a claim about this one.
- **Verification question (to the employer):** "Can you confirm the company's registered name, and the onboarding portal address as it appears on your website?"
- **Decision rule:** Verify the employer and the portal on its own site before accepting or sending any data.
- **Status:** unresolved.

**Onboarding data requests: no entry.** The offer is a written offer naming role and pay, follows in-person interviews, and comes from a company-style domain. That makes it routine onboarding. The one check: enter bank, PPS and passport details only in the portal at the address on the company's website. That check depends on RR1 clearing.

**RR2 — Offer terms missing**
- **Class / severity:** `unknown` / `low`.
- **Source quote:** the offer gives the role, pay and location but no contract, start date or notice terms.
- **Hypothesis:** The terms will come later. `[inferred]` from the offer's text. Irish law requires a written statement of core terms `[generic]`, so ask for it now.
- **Verification question:** "Could you send the written contract, pension scheme details and start date before I accept?"
- **Decision rule:** Accept only after the contract matches the offer.
- **Status:** unresolved.

**Application plan**
1. Find the company independently: type its website address yourself, or use a search engine, not the link in the email. Check that the address matches the offer's domain, that the role is listed, and that a phone number and named contacts are on the site. If you find an approved housing body register online (the Approved Housing Bodies Regulatory Authority keeps one `[generic]`), check whether Marrowgate appears.
2. Reply to the offer asking for the written contract, start date, notice terms and pension scheme details. Ask for these before you accept.
3. Before entering any data, check the portal address against the company's website, and confirm it uses the same domain. Ask what the passport check records and how the copy is stored. A check of original documents on day one is normal `[generic]`.
4. In interview and onboarding talk, lead with the three years' fortnightly payroll for 90 staff, the reconciliation, the certificate and Excel. On pensions, say plainly that you haven't administered them, and that you learn quickly with a scheme provider. Do not claim pension experience.

**Evidence status**

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company's official site and careers page | unavailable | All 3 web searches were refused by permission; no result came back |
| 2 | Role-family sweep (pay and scope for this title) | unavailable | Same refusal |
| 3 | Hiring manager's public footprint (Declan Garvagh) | unavailable | Same refusal; name was given, no call succeeded |

**Dossier offer:** I can save this assessment as `tuesday-dossier.md` so you can pick it up later.

**Upgrade menu**
- **Allow web search:** I would check the employer's own site, the portal address, the role listing, and the Limerick pay band. This would close RR1 and the market calibration.
- **Your location and pay floor:** Closes H1 and H2.
- **Written contract and pension details from the employer:** Closes RR2, and gives a better view of R8.

**Questions**
1. (H1) Where do you live relative to the Limerick office, and can you do two office days a week?
2. (H2) What is your pay floor, and what notice do you need to give?
3. (R2) Did the hotel group's payroll run under Irish PAYE/PRSI/USC, and did you handle those yourself?

Answer in text, or say skip for any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.