**Decision snapshot:** `conditional_go`. It's worth taking the call, but verify the company first. Nothing in the posting or the WhatsApp message is a scam marker: no fees, no payment, no requests for ID or bank details. Research tier: L0, no searches run. I haven't checked Fernquay online, so the legitimacy read below rests on what you pasted.

**Hard gates:** None failed. Galway-based hybrid fits your location. Your salary floor isn't stated, so the €52k–€60k band is unchecked against it.

**Fit, by requirement** (confidence is from what you've told me, not verified):
- **3+ years product design:** Meets. Four years at a travel-booking company. `[grounded]`, high confidence.
- **Strong Figma:** Meets. You use it daily. `[grounded]`, high confidence.
- **Ran your own user research:** Meets. You ran monthly usability sessions with customers. This is the closest match to "research calls with school owners." `[grounded]`, high confidence.
- **Works directly with engineers:** Meets. You worked in a squad of four engineers. `[grounded]`, high confidence.
- **Own the booking flow end to end:** Partial. You redesigned checkout, which is one flow inside a larger product. Owning a whole flow is a scope stretch, not a gap you can't close. `[inferred]`, medium confidence.
- **First and only designer:** Gap. You've never been the only designer anywhere. This is the real gap to plan for. It's a capability and experience gap, not a skill gap. `[grounded]`.
- **Sea-kayak and surf-school booking domain:** Transferable. Booking UX carries over from travel, but the customers are small operators, not travellers. `[inferred]`.

**Role reality** (from the posting only):
- Six people, two engineers, a CTO, and a co-founder you'd work with most. Early-stage, so "first designer" means you'd set up design practice as well as design the screens. `[grounded]`
- Equity of 0.5–1% is plausible for an early hire at a company this size. `[generic]`
- €52k–€60k for a mid-to-senior product designer in Galway is in a reasonable range. I haven't checked it against current market data. `[generic]`
- The posting asks for "one messy real project," which suggests they'll want to see your real work rather than a polished deck. `[grounded]`

**Legitimacy checks, in order:**
1. **Confirm the company exists.** Search the Companies Registration Office (CRO) register for "Fernquay" and check the registered directors against Ronan Kehoe and Saoirse. Check that the company has a real website. This is the check that matters most.
2. **Check the calendar invite's sender domain.** It should be a Fernquay address, not a Gmail or similar. Ronan said the invite was emailed, so compare that address against the domain on their website.
3. **Find the posting on their site or a job board.** A live posting that matches the WhatsApp message is good evidence. If you can't find it anywhere except the message, treat that as a warning.
4. **Hold back anything sensitive.** Don't send ID, bank details, or a paid "test" until 1–3 are done. A design task you do for free is normal at this stage, but a paid or unusually open-ended one is not.

**The WhatsApp contact** is slightly unusual for a formal application but common for small Irish startups. It is not a red flag by itself. The check is whether the people and the company match up.

**Preparing for the call:** Lead with the checkout redesign and the monthly customer research. For the "only designer" question, be direct: you've never been the sole designer, here's how you'd handle that. Lean on the squad experience and ask how they make design decisions today. Don't claim you "owned" checkout unless you did.

**Upgrade menu** (what would move this call):
- The CRO record and company website (would verify the employer, moving the decision to `go` if they check out).
- The live posting link (would confirm the role is real and current).
- Your salary floor (would test the €52k–€60k band against your needs).
- If you want, I can run up to 5 web searches and 2 page fetches on Fernquay and the role's market rate. That's research tier L1 and would add grounded company facts in place of the `[generic]` labels above.

**Questions:**
1. Can you send the job post link, or say where you found the posting?
2. What's the lowest salary you'd accept?
3. Does the calendar invite come from a Fernquay email address?

I can also turn this into a `tuesday-dossier.md` file you could reuse for later applications. Say the word and I'll produce it.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.