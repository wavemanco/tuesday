**Decision snapshot:** `conditional_go`. Apply, or take the call, after you've verified the company. The fit is strong on the requirements the posting lists. The real gap is that this would be your first design role with no other designer, and your users would be school owners rather than travellers.

**Hard gates:** Location is met: hybrid with two office days in Galway, and you live there. Pay is unknown against your floor, because you haven't told me one. The posting states €52–60k plus 0.5–1% equity. Schedule and other non-negotiables are unknown.

**Research tier:** L1, searches 2 of 5, fetches 0 of 2. Both web searches were refused by the permission prompt in this session, so nothing about Fernquay has been checked online.

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Web search permission was denied |
| 2 | Role-family sweep (pay, scope, title) | unavailable | Same |
| 3 | Ronan Kehoe's public footprint | unavailable | Same |

I also worked from the skill's rules and the posting, not the skill's reference files, so the analysis is lighter than the full method calls for.

**Is it legit?** I can't confirm it. The posting and the WhatsApp message are internally consistent: Galway, six people, Ronan as co-founder, a CTO called Saoirse, and a call with both of them. A founder reaching out on WhatsApp is not unusual for a small Irish startup [generic]. The scam signals I'd look for are absent so far: no fee, no bank or ID request, no paid "test", no pressure to move off-channel. Before you give anything away, check three things:

- The calendar invite's sender domain matches the company's website. Find the website yourself, not via a link in the message.
- An Irish company should appear in the Companies Registration Office register (cro.ie). Search for "Fernquay". Nothing there, or a different trading name, is a reason to hold.
- The posting is live on the company's own careers page or a job board you recognise.

**Role reality [grounded, from the posting]:** You would be the first designer, owning the booking flow end to end, running discovery with school owners, and shipping with two engineers. You'd work most closely with Ronan. The posting says they value a messy real project over a polished deck.

**Evidence map**

| Requirement | Fit | Basis |
|---|---|---|
| 3+ years product design | Met | Four years at a Dublin travel-booking company [grounded] |
| Strong Figma | Met | Daily use [grounded] |
| Has run own user research | Met | Monthly usability sessions with customers [grounded] |
| Works directly with engineers | Met | Four-engineer squad [grounded] |
| Owns a booking flow end to end | Partly met | You redesigned checkout, but you were one designer in a larger team |
| Works as the only designer | Gap | Never done it [grounded] |
| Research with school owners (B2B) | Transferable | Your research was with consumers, not business customers [inferred] |

**Risk register**

- **Solo role.** Nobody to review your work, set standards, or push back on your decisions. This is the main risk. Ask who makes product decisions and how success is measured.
- **Customer shift.** Travellers buying a trip versus business owners running a school are different users. Your method transfers; your intuitions about users may not.
- **Pay.** €52–60k is grounded from the posting. Whether it's fair for Galway is [generic] and I can't calibrate it without research. Ask whether it's gross and what your floor is.
- **Equity.** 0.5–1% with no vesting or share-class detail stated. Ask for the vesting schedule and option terms in writing.
- **Unverified employer.** See above. This is why the decision is conditional.

**Application plan**

1. Verify the company first, using the three checks above.
2. On the call, ask who else the company has hired or spoken to, and what happened to the last designer, if there was one.
3. Lead with the checkout redesign and the monthly usability sessions. Frame them as work you owned, but don't claim you led a team you didn't lead.
4. Prepare one short story about making a call without a design peer to check it with. Don't overstate it.

**Upgrade menu.** Each item would move the assessment:
- Web search access: checks Fernquay's existence, team, and funding. This is the most valuable input.
- The posting link, or the company's careers page: confirms the role is live and matches the email.
- Your salary floor and any non-negotiables: closes the hard-gate checks.
- The checkout case study: lets me judge the portfolio claims directly.

**Questions**

1. Did you apply through a form or job board? If so, which one? That tells us whether the WhatsApp contact makes sense.
2. What's your minimum acceptable salary, and are there other must-haves, such as remote days or start date?
3. Can you send the posting link or the company's website, so I can check the domain against the invite?

Response mode: answer these in any order, or skip any. Each one changes the decision.

Call prep for the 45-minute call is a separate job for the mock-interview skill.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.