**Job 1 (Duinvaart) is worth your time, on conditions. Job 2 (Kroonhaven) is not worth it as posted.**

Research tier: L1 — searches 3 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Searches for Duinvaart and Kroonhaven were refused by the tool permission, so I could not confirm either employer exists as described or that the postings are live. |
| 2. Role-family sweep | unavailable | The salary and role-scope search was refused. Market calibration for pay is missing for both roles. |
| 3. Hiring manager's public footprint | n/a | No name was given. |

I'm working from your background as you stated it. Nothing is verified yet.

## Job 1: Operations Analyst, Duinvaart Cold Chain, Rotterdam

**Decision: `conditional_go`.** Apply once the Rotterdam schedule and the temperature-compliance scope are confirmed.

**Fit ledger.**
- `hard_gate`: unconfirmed: A9 (hybrid, three days a week in the Rotterdam office). Candidate constraints not given, so checks against them are unknown.
- `must_have`: direct: A1, A2, A3, A4. Your on-time dashboard and SQL work match the core of the role.
- `important`: direct: A6, A7. Adjacent: A5 (temperature compliance).
- `preferred`: adjacent: A8 (Dutch).

**Opportunity ledger.** The posting is clear and scoped like your current job, with no red flags. Three things are unknown: who acts on a temperature excursion, how the Dutch requirement plays out day to day, and pay (not stated). Verification of the employer is still outstanding (see Evidence status).

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| A1 | 2+ years logistics or ops analysis | must_have | direct | medium | none | Four years as an ops analyst at a parcel carrier | `[grounded]` your background |
| A2 | Strong SQL | must_have | direct | medium | none | Daily use | `[grounded]` your background |
| A3 | Power BI or Tableau | must_have | direct | medium | none | Daily Power BI use | `[grounded]` your background |
| A4 | Track on-time delivery | must_have | direct | medium | none | You built the on-time dashboard depot managers use | `[grounded]` your background |
| A5 | Track temperature compliance, refrigerated fleet | important | adjacent | low | transferability | Monitoring KPIs transfers. You have no cold-chain or temperature data. Limit: not exercised on temperature | `[inferred]` from your background |
| A6 | Weekly dashboards | important | direct | medium | none | Weekly reporting cadence | `[grounded]` your background |
| A7 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your background |
| A8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent. Limit: daily depot work may need more | `[grounded]` your statement |
| A9 | Hybrid, 3 days a week in Rotterdam | hard_gate | unclear | unknown | hard_gate | Your location and schedule constraints were not given | — |

**Opportunity risk register.**

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RA1 | Temperature-compliance ownership unclear | unknown | — | "track … temperature compliance across our refrigerated fleet" | The role may monitor compliance without authority over the response | `[inferred]` from the posting's silence on authority | When a reefer excursion happens, who acts on it, and is the role's report the trigger? | unresolved |
| RA2 | Dutch use in daily work | risk_signal | low | "Dutch a plus" beside "work with depot managers" | Depot conversations may run in Dutch | `[generic]` pattern for Dutch regional logistics | What language do depot managers use day to day, and what level is needed? | unresolved |
| RA3 | Hybrid schedule | unknown | — | "three days a week in our Rotterdam office" | Commute and attendance may be fixed | `[grounded]` posting | Is the three-day office attendance fixed or negotiable? | unresolved |
| RA4 | Pay not stated | unknown | — | (none stated) | Pay is unknown; no market band was available | `[generic]` no sweep run | What is the salary range for this role? | unresolved |

**Application plan** (every row needs your approval before anything is sent).
- P1: Lead with the on-time delivery dashboard and the route-performance review. Source: A4, A7 (`[grounded]`). Pending your approval.
- P2: Do not claim cold-chain or temperature experience. Describe the monitoring work as it was. Source: A5 (`[inferred]`). Pending your approval.
- P3: State Dutch as "conversational Dutch", the level you have. Source: A8 (`[grounded]`). Pending your approval.
- P4: Confirm the employer and the posting on Duinvaart's own careers page before investing effort. Research could not do this here.

## Job 2: Supply Planner, Kroonhaven Foods, Utrecht

**Decision: `no_go`** for this posting as written. Two must-haves are absent with no realistic closure in the time you have: 3+ years of FMCG planning, and SAP IBP or a similar planning system. You have never worked in planning, so this role would be a stretch on the core of the job. Your analytical skills are relevant, but they do not stand in for planning ownership.

**Fit ledger.**
- `hard_gate`: unconfirmed: B7 (on-site in Utrecht). Candidate constraints not given.
- `must_have`: absent: B1 (3+ years planning), B3 (SAP IBP or similar). unclear: B2 (advanced Excel). adjacent: B4 (fluent Dutch), B5 (13-week plan and capacity balance).
- `important`: adjacent: B6 (weekly S&OP meeting).

**Opportunity ledger.** The posting is coherent and has no red flags. The issue is entirely on the fit side.

**Evidence map.**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| B1 | 3+ years supply or demand planning, FMCG | must_have | absent | high | capability | You have never worked in planning. Your self-statement is specific | `[grounded]` your statement |
| B2 | Advanced Excel | must_have | unclear | low | discovery | Not in your background | — |
| B3 | SAP IBP or similar planning system | must_have | absent | high | capability | No planning-system experience | `[grounded]` your statement |
| B4 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational. Limit: not fluent | `[grounded]` your statement |
| B5 | 13-week plan, balance capacity against forecast | must_have | adjacent | low | transferability | Performance measurement transfers. Production-capacity allocation does not | `[inferred]` from your background |
| B6 | Run weekly S&OP | important | adjacent | medium | transferability | You ran a weekly review of route performance. Different content, same cadence | `[grounded]` your background |
| B7 | On-site in Utrecht | hard_gate | unclear | unknown | hard_gate | Your location constraint was not given | — |

**Opportunity risk register.** No entries of concern. The posting is coherent. Pay is not stated; the market sweep did not run.

**Application plan.** None, since the decision is `no_go`. If you want to move toward planning later, the closure path is a junior or analyst planning role with a lower experience bar, not this posting.

## Evidence status

Verified: none yet. All claims above come from your background as you stated it.

Unverified: the existence and live status of both postings, and both employers.

## Upgrade menu

- A sanitized screenshot of the on-time dashboard, with identifying details removed, would move A2–A4 from `medium` toward `high`.
- The posting links and each company's own careers page would let research verify the employers. Without them, the employer check stays open.
- A salary range from the recruiter, or a role-family pay check, would close RA4.
- Any record of temperature or cold-chain data would move A5 from adjacent to direct.

If you want, I can write this into a `tuesday-dossier.md` so the register carries into interview prep.

**Questions**

- A9 — Can you work three days a week in the Rotterdam office from where you live? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- A8 — In your current job, how much of your daily work with depot managers is in Dutch? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.
- A5 — Has any of your work touched temperature or cold-chain data, such as sensor logs, reefer alerts or food-safety records? Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.