**Decision: conditional_go.** Accept only after you've verified the employer and the onboarding request through a channel you chose yourself, not one from the offer email. The role fits your core experience well. Two gaps are real, and neither is a reason to walk away.

**Hard gates:** Pay is met: €40,000 sits inside the posted €38–42k band `[grounded]`. Your Limerick commute and notice period are unknown, since neither is in what you gave me. Those are the only hard-gate checks still open.

**Your direct question:** Asking for bank details and a PPS number after you accept is normal in Ireland. Payroll needs the first to pay you and the second to report to Revenue. Employers also have a legal duty to check right to work before you start, so asking for a passport is normal too. What's less usual is a scan through an online portal before your first day. The usual practice is to view the original passport in person and, if at all, keep a copy on file. The sequence you describe (in-person interviews, then an offer, then onboarding after acceptance) is the normal order. The request itself isn't the red flag. The channel is: a link in an email asking you to enter sensitive data is exactly how phishing works. Verify before you act `[inferred]`.

**Evidence map** (`[grounded]` = your account; no outside research run)

| # | Priority | Requirement | Your evidence | Fit | Confidence | Gap type |
|---|---|---|---|---|---|---|
| 1 | Must | 2+ years running payroll | 3 years fortnightly payroll, 90 staff | Met | Medium (self-stated) | None |
| 2 | Must | Working knowledge of PAYE, PRSI, USC | Payroll Technician cert (2024); hotel payroll work | Likely met | Medium | Discovery: not stated explicitly on your CV |
| 3 | Must | Strong Excel | Daily use: pivots, XLOOKUP | Met | Medium–high | None |
| 4 | Must | Payroll qualification or working towards | Payroll Technician cert, 2024 | Met | High (certificate) | None |
| 5 | Must | Starters and leavers | Covered in hotel role | Met | Medium | None |
| 6 | Must | Monthly payroll-to-GL reconciliation | Done monthly at hotel group | Met | Medium–high | None |
| 7 | Must | Monthly payroll for 240 staff | Fortnightly for 90 | Partial | Medium | Transferability: scale and cycle |
| 8 | Must | Process pension changes | Not done; your manager handled these | Not evidenced | n/a | Capability |
| 9 | Preferred | Answer staff payroll queries | Not stated | Unknown | Low | Discovery |
| 10 | Context | Housing association sector | Hotel group only | Unknown | Low | Transferability |

**Gap recovery queue** (no questions here; the questions are below)
- **Pension changes (row 8):** Closes with any exposure: sending joiner or opt-out forms, checking contribution changes, or liaising with the pension provider. Without it, expect this to come up at interview. Short provider-led training would narrow it.
- **Scale and monthly cycle (row 7):** Closes with a sentence in your CV describing how you handled volume and deadlines.
- **Staff queries and sector (rows 9, 10):** Close with a line on what you handled, plus any interest in housing.

**Opportunity risk register**
- **R1, employer identity (medium):** You've met people in person, which is strong evidence. It isn't verification of the legal entity or the posting. Resolve: search the Companies Registration Office for the legal name, check the company's own website and careers page, and check that the regulator for Irish approved housing bodies lists it (AHBRA, if I recall correctly).
- **R2, onboarding channel (medium):** A portal link plus a pre-start passport scan. Resolve: go to the portal only through the company's website, or ask your interviewer to confirm the link in writing. Ask why the scan is needed before day one, and ask for their data-protection notice.
- **R3, pay (low):** €40k is within the posted band.
- **R4, commute and notice (unknown):** Not yet assessed.

**Application plan (acceptance)**
1. Don't click the portal link yet. Check the company's own website for the People team's phone number and email, and confirm the offer with them directly.
2. Confirm in writing that the right-to-work check can be done with the original passport on day one, without a prior scan. If they still want a scan, ask how it's stored and who sees it.
3. Never send your PPS number or bank details by ordinary email. Use the verified portal only.
4. Ask Declan Garvagh, or whoever interviewed you, to confirm the start date and the pension scheme details before you give notice.
5. Be honest in interview about the pension gap. Describe the hotel's process and what you'd learn, without claiming hands-on experience.

**Evidence status**
Research tier: L0 — no searches. You haven't consented to research, so I haven't checked the company or the pay band online.

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | skipped | No research consent |
| 2. Role-family pay and scope sweep | skipped | No research consent |
| 3. Declan Garvagh public footprint | skipped | No research consent |

I'd also note that I haven't seen the posting live, so I can't confirm it matches the offer beyond the €38–42k band and the two-day hybrid pattern.

**Dossier offer:** If you'd like, I can save this assessment as a `tuesday-dossier.md` file so it carries into interview prep later.

**Upgrade menu**
- A link to the live posting, or the company's careers page: confirms the role is live and matches the offer (closes part of R1).
- Permission to run public searches (L1): checks the Companies Registration Office, the company website and the pay band for this kind of role (closes R1 and firms up the pay band).
- Any detail of pension exposure at the hotel group, even indirect: moves row 8 from "not evidenced" to a partial match.

**Questions**
1. Did you have any involvement in pension changes at the hotel group, even indirectly, such as sending forms or checking contribution figures?
2. Is a commute to Limerick for two office days a week workable, and what is your notice period?
3. Who did you interview with, and do you have the People team's phone number from the company's own website so you can verify the offer?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.