The web tools are loaded, so I'll run the L1 research now: the company's footprint, a salary sweep for the role, and the co-founder's public professional footprint.
**Yes, it's worth the call, and the company checks out. Status: `conditional_go`.** Your craft fits the posting. The real question is whether you can be the only designer, and the call is where to test that.

**Fit ledger.**

- `hard_gate` — direct: R1
- `must_have` — direct: R2, R3, R4, R5 · adjacent: R6
- `important` — adjacent: R7

R6 — the one real gap, since you have never been the only designer; R7 — booking-domain transfer, with new customers; R3 (`medium`) — stated, not yet shown in a portfolio.

**Opportunity ledger.** The employer is established and the salary sits inside the market band (RR4, RR3). The open unknowns are scope and decision rights (RR1) and what the equity is worth (RR2).

- **Hard gates:** none failed (R1 `direct`); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) RR1 — the solo scope and decision rights are concrete in the call; (2) RR2 — you understand what 0.5–1% means; (3) you present the checkout work as adjacent to solo ownership, not as proof you've done it.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Fernquay: six people in Galway, founded 2023, customer-funded, makes Kelproster booking software for sea-kayak, surf and sailing schools in Ireland and Scotland | `[grounded]` fernquay.example/about |
| Role | First designer: own the booking flow, run research with school owners, ship with two engineers | `[grounded]` JD |
| Pay and location | €52,000–€60,000 plus 0.5–1% equity; hybrid, two days a week in Galway | `[grounded]` careers page and JD agree |
| Market calibration | Tillerby 2026 Ireland survey (n=520): product designers with 3–5 years, median €57,000, IQR €51,500–€62,000. The posting's range sits inside that IQR. This is Ireland-wide, not Galway-specific | `[generic]` salary sweep |
| Co-founders | Ronan Kehoe: co-founder and CEO per public LinkedIn; previously product lead at a Galway travel-software company for five years. Saoirse Doyle: co-founder per the About page; the message calls her CTO | `[grounded]` LinkedIn snippet and About page |
| Unknowns | Solo scope, decision rights, research budget, equity value, design tooling | — |
| Contradictions | None between the JD and the careers page. Minor: the About page says Saoirse is a co-founder, the message says CTO; both can be true | `[grounded]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Hybrid, two days a week in Galway | hard_gate | direct | high | none | You moved back to Galway last year | `[grounded]` your background, JD | none |
| R2 | 3+ years product design | must_have | direct | high | none | Four years at a Dublin travel-booking company | `[grounded]` your background | none |
| R3 | Strong Figma | must_have | direct | medium | none | "Figma daily" is your claim; no portfolio reviewed yet | `[grounded]` self-stated | offer a portfolio link to raise to high |
| R4 | Has run own user research | must_have | direct | medium | none | Monthly usability sessions with customers. Caveat: those customers were travel shoppers, not school owners (B2B) | `[grounded]` your background | name the difference yourself |
| R5 | Works directly with engineers | must_have | direct | high | none | Squad of four engineers | `[grounded]` your background | none |
| R6 | Owns a flow end to end, as the only designer | must_have | adjacent | medium | transferability | You redesigned the checkout flow inside a squad, not alone. Never been the only designer anywhere | `[grounded]` your background; `[inferred]` the transfer | see gap G1 |
| R7 | Sea-kayak and surf-school booking domain | important | adjacent | medium | transferability | Checkout and booking logic transfer. School-owner customers and activity-booking rules are new | `[inferred]` from checkout work | see gap G2 |

## Gap recovery queue

| # | Gap (req) | Type | What I see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Solo ownership (R6, must_have) | transferability | Checkout redesign inside a squad of four; no solo design decisions on record | This is the objection the company is most likely to raise | Any time you set direction on a feature without a lead designer signing off; anything you scoped and shipped with engineers | A short note on one decision you made alone, with its outcome | `[inferred]` bridge; `[generic]` that this is the likeliest objection |
| G2 | Booking domain (R7, important) | transferability | Travel booking, not activity schools | Less critical, since the flow patterns transfer | Any work on multi-step booking with capacity or scheduling rules | One line on the closest rule-heavy booking problem you solved | `[inferred]` |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Solo scope with no stated design resources | unknown | — | "our first designer … own the booking flow end to end" | The role may carry the flow without a design lead, a research budget, or final say on direction | `[inferred]` from the JD's scope against its silence on resources | Who makes the final call on design direction, and what research budget and tools are committed to this role? | unresolved |
| RR2 | Equity value unstated | unknown | — | "0.5–1% equity" | The equity may be worth little at this stage, or simply unexplained | `[generic]` pattern for early-stage equity offers | What is the total share count and the latest valuation behind 0.5% and 1%? | unresolved |
| RR3 | Salary inside market band | positive_signal | — | "€52,000–€60,000" | The range is realistic for 3–5 years' experience | `[grounded]` JD against `[generic]` Tillerby IQR | Is the range flexible, and where would an offer for your experience land? | noted |
| RR4 | Established employer, live posting | positive_signal | — | "Six people, based in Galway" | The company is small but real, with a live posting and named co-founders | `[grounded]` About page, careers page, LinkedIn | How is the company funded, and how long is its runway? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Check the calendar invite comes from a fernquay.example address, the same domain as the careers page's jobs@ address | Confirms the contact is the company's own | `[grounded]` careers page | your check |
| A2 | Lead the call with the checkout redesign and the usability sessions. Say "redesigned the checkout flow", not "owned the booking flow" | Accurate to what you did; the wording matters | `[grounded]` your background | pending your approval |
| A3 | Ask RR1 and RR2 directly on the call | These decide the conditions | `[grounded]` register | pending your approval |
| A4 | Share a short note on one solo decision, for G1 | Turns the gap into a discussable answer | `[inferred]` G1 | pending your approval |

Rehearsing the 45-minute call itself is the job of the mock-interview skill, not this one.

## Evidence status

Verified: none beyond the checkout case study the company has already seen. Your claims about Figma and research are stated, not shown.

Research tier: L1 — searches 4 of 5, fetches 2 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Fernquay Galway booking software sea kayak surf schools" and "Fernquay careers Product Designer Galway"; fetched fernquay.example/careers/product-designer and fernquay.example/about. Confirmed the posting is live and matches the JD; confirmed the employer exists as described |
| 2. Role-family sweep | yes | Searched "Product Designer salary Ireland 3 years experience Galway", which returned the Tillerby 2026 Ireland Design Salary Report. Market calibration `[generic]` |
| 3. Hiring manager's public footprint | yes | Searched "Ronan Kehoe co-founder Galway software", which returned a public LinkedIn profile. Confirmed the role and prior role only; nothing personal used |

## Upgrade menu

- A portfolio link or one shown project → R3 to `high`.
- A short note on a solo decision → R6 can move from `adjacent` toward `direct`.
- The company's answers on scope and equity → RR1 and RR2 close, and the decision can move to `go` or `no_go`.
- Your non-negotiables (pay floor, contract type, start date) → the hard-gate line can be checked, not left as unknown.

I can save this assessment as `tuesday-dossier.md` if you want to carry it into your call prep.

## Questions

1. **[R1 / candidate constraints]** Do you have a pay floor, contract type, or start-date limit I should check this role against?
2. **[R3]** Do you have a portfolio link or a shared project that shows your Figma work?
3. **[R6 / G1]** Can you think of one design decision you made alone, even in a small way, and what happened? If not, that is useful to know too.

Response mode: answer in text, paste a link, or say skip for any of these.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.