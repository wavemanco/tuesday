**Short answer: worth taking the call, but verify the recruiter first.** I'd call it a conditional go. The role fits you well, and the company checks out only partly.

**Is it legit?**

- The search results describe a company that matches the posting: Fernquay, booking software for sea-kayak, surf and sailing schools, six people in Galway, founded 2023 by Ronan Kehoe and Saoirse Doyle. Its careers page lists the same role, salary, hybrid terms and application route.
- Ronan's LinkedIn lists him as co-founder and CEO, previously product lead at a Galway travel-software company for five years. That's consistent with what he wrote to you.
- **Caveat:** every company page I found is on `fernquay.example`. That's a reserved placeholder domain, not a real company domain, so I can't confirm these are the company's real pages. I also found no funding, reviews or news. Small companies often have little online presence, so thin results alone aren't alarming. But I haven't verified the employer.
- The WhatsApp message itself isn't a red flag. It refers to a calendar invite by email, which is normal for a recruiter who has already been in touch. Before you join:
  - Check that the invite comes from a Fernquay email domain that matches the address on the careers page (`jobs@…`).
  - Don't use any video link sent through WhatsApp. Use the one in the email invite, and only after the domain check.
  - If the domain doesn't match, reply through the application channel and ask Ronan to confirm.

**Fit**

- **Strong:** 4 years of product design (the 3+ requirement), Figma daily, a checkout redesign, monthly customer usability sessions (research), and a squad of four engineers. Those cover the posting's specific asks well.
- **Real gap: being the only designer.** You've never owned design alone, so "first designer" means no design critique partner and making calls on your own. That's a judgment gap, not a skills gap, and you can address it directly in the call.
- **Location and schedule:** you live in Galway, so the two office days work.
- **Pay:** €52–60k is what the posting states. I did not check this against market rates, so treat it as unbenchmarked. The equity (0.5–1%) needs questions: is it options or shares, what's the strike price, what's the vesting schedule, and what happens if you leave?

**Research tier:** L1 — searches 3 of 5, fetches 1 of 2. I didn't check the careers page directly; I relied on the search snippet.

**Before the call**

- Confirm the invite's sender domain (above).
- Bring the checkout case study and be ready to talk through it in detail. Ronan said they "loved" it, and the posting says they'd rather see one messy real project than a polished deck, so a real case is a better fit than a presentation.
- Be upfront that you've never been the only designer. Have a concrete answer to "how would you get critique and make calls on your own?"
- Ask about the equity terms and what "run research calls with school owners" looks like in practice (how many, how often).

Would you like me to draft a short reply to Ronan that confirms the time and asks the equity questions?

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.