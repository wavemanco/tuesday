## Decision snapshot

**Decision: no_go.** Do not send anything to @VellowayHiring. Do not send your IBAN, PPS number, or passport photo, and do not pay the €349 or lodge the cheque.

- **Opportunity ledger:** The hiring process shows the signs of an advance-fee and cheque-overpayment scam. The posting itself is ordinary, but the messages are not. Nothing you've been asked to do is a normal part of hiring.
- **Candidate fit ledger:** Your background matches the duties well. That does not change the decision, because the risk comes from the employer's conduct, not from the fit.
- **Hard gates:** Pay floor (€30,000/yr) is not met on the posting's own figures unless you work about 22+ hours a week at the top rate, and commission is unstated. Unverified.
- **Employer:** Not verified. No check was run (see Evidence status).

## Role reality

- **Stated role** [grounded]: Remote Order Processing Coordinator, 15–30 hrs/week, "up to" €26/hr plus commission per order, "no experience needed", training provided.
- **Pay arithmetic** [grounded, from the posting]: €26 × 15 h × 52 wks ≈ €20,280. €26 × 30 h × 52 wks ≈ €40,560. Reaching €30,000 at full rate needs about 22 hours/week, before any commission.
- **Process** [grounded]: Telegram only, no calls or video, "passed screening" before any interview, and a request for banking and ID data before the interview.
- **Market calibration** [generic]: Remote roles that pay real wages do not normally ask new hires to fund their own equipment, or to deposit a cheque and forward part of it.

## Evidence map (fit)

| # | Priority | Fit | Requirement | Evidence | Confidence |
|---|---|---|---|---|---|
| 1 | must | likely met | Attention to detail | ~60 Zendesk tickets/day, 3 years, self-reported | medium |
| 2 | must | likely met | Spreadsheets | Keep team's weekly Excel tracker, self-reported | medium |
| 3 | must | unverified | Written English | Not tested; no writing sample provided | low |
| 4 | must | unknown | Quiet workspace | Not asked yet | none |
| 5 | hard_gate | unmet on stated terms | Pay ≥ €30,000/yr | Max base ≈ €20k at 15 h, ≈ €40k at 30 h; commission unknown | — |
| 6 | hard_gate | unknown | Schedule 15–30 h/wk | Compatible with your stated hours? Not asked | none |

Fit status and confidence are shown for each row. There is no overall fit score.

## Opportunity risk register

| Risk | Class | Severity |
|---|---|---|
| €349 "equipment" payment by bank transfer before any work | Advance-fee fraud signal | Critical |
| Lodge a €2,850 cheque, keep €350, forward the rest to a third party. Cheques that bounce are charged back to the depositor, so you would owe the money | Overpayment / money-mule scheme | Critical |
| IBAN, PPS number and passport photo requested before any interview | Identity theft risk | Critical |
| Whole process on Telegram; "passed" the screening and the chat before any real interview | Process red flag | High |
| Contact is an email at `postmail.example`, not a company domain | Attribution gap | High |
| Employer not verified (standing entry) | Failed attribution — cannot confirm the company exists as described | High; a go would at most become conditional, and the evidence here points to no_go |
| Pay "up to" €26/hr with commission unstated; floor not met on stated terms | Hard-gate mismatch | Medium |

## Application plan

Don't apply through this channel. Your evidence is strong for real remote coordinator, support, or operations roles, so search those through the jobs site's verified postings, the company's own careers page, or recognised job boards. Your Zendesk and Excel experience and the two onboarding you did are the lead points. Ask for pay in the posting, and don't accept any role that asks you to pay, deposit money, or send ID before a verified interview.

## Evidence status

Research tier: L0 — no searches. I have not checked whether Velloway Logistics exists.

| Target | Status | Reason |
|---|---|---|
| 1. Company's official site and careers page | skipped | Not run; no consent yet. The decision does not depend on it |
| 2. Role-family sweep (pay and scope norms) | skipped | Not run; no consent yet |
| 3. Hiring manager's public footprint | n/a | No name given |

Note: I worked from the skill's core structure and did not open its reference files, so the formatting may not match its templates exactly. The decision rests on the posting and messages you provided.

## Dossier offer

If you want, I can save this assessment as a `tuesday-dossier.md` file for your records.

## Upgrade menu

- **Live posting link or company careers page** — would confirm whether the role exists and matches the message. Given the messages, this is unlikely to change the decision.
- **Company registration number (Irish CRO) and a website domain** — would let the employer be checked directly.
- **A writing sample in English** — would move row 3 from unverified to verified.
- **Your quiet-workspace and schedule answers** — would close rows 4 and 6.

## Questions

1. Have you sent anything to @VellowayHiring or the email address yet, even the IBAN or a photo? If you have, tell me what and I'll help you with next steps for the bank and identity risk.
2. Do you want me to run a light L1 check on Velloway Logistics (company site and careers page, plus a sweep of typical pay for this role)? It costs up to 3 searches and 2 page fetches, and it would close the attribution gap, though the decision is no_go either way.

Response modes: answer each question, or reply "skip" to either.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.