**Decision: `conditional_go`.** Take the call, once the company checks out. I can't establish whether Fernquay is legitimate from here. Every web search was refused, so nothing about the company, Ronan Kehoe or Saoirse is verified. That is not a finding that it's fake.

**Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Salary €52,000–€60,000); candidate constraints not given. Checks against your pay floor and contract needs are unknown.
**Severe red flags:** none found. The messages so far ask you for no money, bank details or ID.

**Fit ledger.**
- `hard_gate`: direct: R1 · unclear: R2
- `must_have`: direct: R3, R4, R5, R8 · adjacent: R6, R7
- `preferred`: direct: R9

R6 (`medium`): adjacent, research with school owners instead of travel customers. R7 (`medium`): adjacent, the solo ownership is unproven.

**Opportunity ledger.** The employer is not established (RR1), and the solo mandate has no design peer (RR2). Pay and equity are unscoped (RR3). The scope and the named people are concrete (RR4, positive).

**Role reality**

| Element | What it is | Provenance |
|---|---|---|
| Organization | Six people in Galway, booking software for sea-kayak and surf schools | `[grounded]` posting's own description, unverified |
| Mandate | First designer: booking flow end to end, school-owner research, shipping with two engineers | `[grounded]` posting |
| Stage | Video call with Ronan and Saoirse (CTO) arranged by WhatsApp, invite by email | `[grounded]` message |
| Market calibration | Not run. The salary search was refused, so there is no band to set the €52–60k against | — |
| Unknowns | Pay floor, equity vesting and dilution, contract type, who signs off design decisions | — |
| Contradictions | None between the posting and the message | `[grounded]` |

**Evidence map**

| # | Requirement | Priority | Fit | Confidence | Gap | Provenance / next action |
|---|---|---|---|---|---|---|
| R1 | Hybrid, two days in Galway | hard_gate | direct | high | none | `[grounded]` you moved back to Galway; your own statement |
| R2 | Salary €52,000–€60,000 | hard_gate | unclear | low | hard_gate | Your floor not given; Q1 |
| R3 | 3+ years product design | must_have | direct | medium | none | `[grounded]` 4 years, self-reported |
| R4 | Strong Figma | must_have | direct | medium | none | `[grounded]` daily use, self-reported; attach a file to raise to high |
| R5 | Run your own user research | must_have | direct | medium | none | `[grounded]` monthly usability sessions |
| R6 | Research calls with school owners | must_have | adjacent | medium | transferability | `[inferred]` customer research carries over; the segment differs; G2 |
| R7 | Own booking flow end to end, first designer | must_have | adjacent | medium | transferability | `[grounded]` checkout redesign in a squad; never the only designer; G1 |
| R8 | Ship with engineers | must_have | direct | medium | none | `[grounded]` squad of four engineers |
| R9 | One messy real project | preferred | direct | medium | none | `[grounded]` checkout case study, which Ronan has seen |

**Gap recovery queue**
- **G1 (R7, transferability).** Adjacent: you owned the checkout redesign inside a squad. Limit: no solo design decisions and no end-to-end ownership with no peer. Strengthener: the checkout case study, with what you decided and who signed off.
- **G2 (R6, transferability).** Adjacent: customer usability work. Limit: B2B small-business owners are a different segment. Strengthener: any session notes or research plan.

**Opportunity risk register**

| # | Signal | Class | Severity | Verification question | Provenance |
|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "Can you point me at this role on your own careers page, and which registered company would employ me?" | `[generic]` pattern for companies this size, not a claim about this one |
| RR2 | Solo design mandate, no design peer named | risk_signal | medium | "Which design decisions are mine alone, and who reviews my work?" | `[inferred]` from "first designer" against silence on design review |
| RR3 | Pay and equity unscoped | unknown | — | "What is the salary band, and what are the equity vesting and dilution terms?" | `[grounded]` posting figures; no band calibrated |
| RR4 | Concrete scope, named co-founder and CTO | positive_signal | — | "What would a good first six months look like?" | `[grounded]` posting and message |

No `severity: high` entries, so no severe red flags. RR1 is why the decision is capped at `conditional_go`.

**Application plan** (all proposed; nothing is sent)

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| A1 | Find Fernquay yourself on the Companies Registration Office public search and on its own website, not through the WhatsApp contact | RR1 | `[generic]` standard practice | your action |
| A2 | Check the invite's sender address matches the company's domain | RR1 | `[grounded]` invite is by email | your action |
| A3 | Keep WhatsApp to confirming the time; use the emailed invite for the call | Routine scheduling; no signal | `[generic]` | your action |
| A4 | Ask the RR2 and RR3 questions on the call | Register doubles as interview prep | `[grounded]` register | pending your approval |
| A5 | Lead with the checkout redesign and state the limit: never the only designer | G1 | `[grounded]` CV | pending your approval |

Share no ID, bank or tax details until a written offer arrives through the company's own portal.

**Evidence status.** Verified: none yet. Everything above is your own account, self-reported.

Research tier: L1 — searches 4 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Every search was refused. Would confirm the company exists, its stage, and that the role is live |
| 2. Role-family sweep | unavailable | Every search was refused. Would set the €52–60k and the role's scope against a band |
| 3. Hiring manager's public footprint | unavailable | Every search was refused. Would verify Ronan Kehoe's role and history |

To re-run research, grant web search permission and I'll spend the rest of the L1 budget. The refused calls count against it.

I can write this up as `tuesday-dossier.md` if you want a file to carry into the call.

**Upgrade menu**
- A checkout case study link or a Figma file: R4 and R7 move toward `high`.
- The company's careers-page URL or the invite's sender address: RR1 can clear.
- Web search permission: the three targets above, and an independent check of Ronan and Saoirse.

**Questions**
- **R2:** Is €52,000 your floor, and would you take the call at that figure?
- **R7:** Name one project where you made product decisions with no other designer to check them. What did you own, and who signed off?
- **R6:** In the usability sessions, were participants business owners or end customers?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

For preparing the call itself, `mock-interview` is the right skill.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.