## Decision snapshot

Yes, asking for bank details, a PPS number and a passport check after a written offer is routine. But verify the sender and the portal before you send anything. Status: `conditional_go` (RR1, RR2).

The web search was refused in this session, so I could not check Marrowgate Housing or its email domain from here. The rest of this assessment rests on your material and the offer text.

**Fit ledger.**

- `hard_gate` — unclear: R1 (Limerick hybrid, two days a week), R2 (salary €38k–€42k)
- `must_have` — direct: R3 (2+ years running payroll), R5 (monthly payroll-to-ledger reconciliation), R6 (payroll qualification), R10 (strong Excel); unclear: R4 (Irish PAYE, PRSI and USC)
- `important` — direct: R7 (starters and leavers); absent: R8 (pension changes); unclear: R9 (answering payroll queries)

R4 — not in your background, so it is an open question; R8 — an adjacent base with the pension side untested; R1 and R2 — waiting on your own constraints.

**Opportunity ledger.** Sound on what the material shows: two in-person interviews, a named reporting line and a written offer with pay and start terms (RR3, positive). Open items are the unverified sender and portal (RR1, RR2) and a single-person payroll scope with no stated support (RR4).

- **Hard gates:** none failed; unconfirmed: R1 (Limerick hybrid, two days a week), R2 (salary €38k–€42k); candidate constraints not given — checks against them unknown
- **Severe red flags:** none found
- **Conditions for go:** (1) the offer and portal confirmed through Marrowgate's own contact details (RR1, RR2); (2) your location and pay floor checked against R1 and R2; (3) the Irish statutory payroll question (R4) answered before you accept.

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Marrowgate Housing, a housing association in Limerick; not verified from here | `[grounded]` job ad; search refused |
| Mandate | Monthly payroll for 240 staff, starters and leavers, pension changes, payroll-to-GL reconciliation, staff queries | `[grounded]` job ad |
| Working pattern | Hybrid, two days a week in the Limerick office | `[grounded]` job ad and offer |
| Pay | Posted €38k–€42k; offered €40,000 | `[grounded]` job ad and offer |
| Reporting line | Declan Garvagh, Finance Manager | `[grounded]` offer |
| Scope read | Reads as one person running the full cycle for 240 staff; whether there is a team or backup is not stated | `[inferred]` from the responsibility list against its silence on support (RR4) |
| Market calibration | Not run; the salary search was refused, so there is no band to set €40,000 against | — |
| Unknowns | Payroll system; in-house or outsourced pension administration; payroll team or backup; Irish statutory experience expected; your floor and location | — |
| Contradictions | None between the job ad and the offer | `[grounded]` both documents |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Limerick office, two days a week (hybrid) | hard_gate | unclear | none | hard_gate | No location or commute stated; the term is set by the job ad | `[grounded]` job ad | Q1 |
| R2 | Salary within €38k–€42k | hard_gate | unclear | none | hard_gate | Offer sits in the posted band; your floor is not given, so the gate is not settled | `[grounded]` job ad and offer | Q1 |
| R3 | 2+ years running payroll | must_have | direct | medium | none | Three years of fortnightly payroll for 90 staff; self-reported, nothing inspected. Fortnightly and 90 staff is not the monthly 240 | `[grounded]` your background | none |
| R4 | Working knowledge of Irish PAYE, PRSI and USC | must_have | unclear | low | discovery | Not stated in your background; the certificate may cover it, but nothing confirms live use | `[grounded]` absence in your background | Q2 |
| R5 | Monthly payroll-to-GL reconciliation | must_have | direct | medium | none | Three years of monthly payroll-to-ledger reconciliation; self-reported | `[grounded]` your background | none |
| R6 | Payroll qualification or working towards one | must_have | direct | medium | none | Payroll Technician certificate, 2024; issuer and content not inspected | `[grounded]` your background | none |
| R7 | Process starters and leavers | important | direct | medium | none | Done in the hotel-group role; self-reported | `[grounded]` your background | none |
| R8 | Process pension changes | important | absent | medium | transferability | You did not handle pension changes; your manager did. Adjacent: starters and leavers run through the same payroll, but the pension side is untested | `[grounded]` your statement; `[inferred]` adjacency from R7 | Q3 |
| R9 | Answer staff payroll queries | important | unclear | low | discovery | Not in your background | `[grounded]` absence | Raise in interview; no question spent this turn |
| R10 | Strong Excel | must_have | direct | medium | none | Daily use, pivot tables, XLOOKUP; self-reported, no workbook inspected | `[grounded]` your background | none |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Irish statutory payroll (R4, must_have) | discovery | Not stated in your background | A must-have; resolving it could move the decision | Running PAYE, PRSI and USC lines on a live payroll; Revenue's real-time (RTI) submissions; year-end returns | An anonymised payslip showing the USC and PRSI lines, or an RTI or year-end checklist | `[grounded]` absence; `[generic]` that Irish payroll roles usually test these lines |
| G2 | Pension changes (R8, important) | transferability | You ran the payroll inputs; your manager ran the pension changes | Interviews for this role will probably ask about it | Pension enrolment or opt-in data in a payroll run; contribution-rate changes entered into payroll; reconciling deductions to the provider | Any pension-change form or provider reconciliation you worked on, even if signed off by your manager | `[grounded]` your statement; `[generic]` on interview focus |
| G3 | Staff payroll queries (R9, important) | discovery | Not stated | Part of the job, not a gate | Answering pay queries; resolving a payslip dispute | None needed; an example in the interview | `[grounded]` absence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Request for bank, PPS and passport after offer, via portal | unknown | — | "add your bank details ... your PPS number ... a scan of your passport" | Routine after a written offer: pay needs bank details, PAYE reporting needs the PPS number, and right-to-work is checked against ID. Enter nothing until the portal is confirmed through the employer's own contact details | `[generic]` what these details are for in Irish payroll; `[grounded]` the offer's wording | "Can you confirm this offer and the onboarding portal address, and what is kept from my passport and for how long?" | unresolved |
| RR2 | Employer and email domain not verified | risk_signal | medium | "people@marrowgatehousing.ie" | The offer is credible on its face (in-person interviews, named manager, pay, start terms), but the search was refused, so the domain and company are unchecked. Not a failed check; this is the standing employer-not-verified entry, capping the decision at `conditional_go` | `[generic]` pattern for companies of this size, not a claim about this one | "Which address and switchboard should I use to confirm this offer with your people team?" | unresolved |
| RR3 | In-person process with a named reporting line | positive_signal | — | "reporting to Declan Garvagh, Finance Manager" | Two in-person interviews and a named manager are the normal shape of a real hire | `[grounded]` your account and the offer | "Who handles pension administration day to day, and who else is on the payroll team?" | noted |
| RR4 | Single-run payroll scope, 240 staff, monthly | unknown | — | "Run the monthly payroll for our 240 staff" | Whether there is a payroll team, a system, or a backup person is not stated | `[inferred]` from the responsibility list against its silence on support | "What system does payroll run on, and who covers it when the main payroll person is away?" | unresolved |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find Marrowgate's own website and switchboard yourself (not the email or its links), and ask the people team to confirm the offer and portal address | RR1, RR2 | `[generic]` the standard check; `[grounded]` the offer's route | your call |
| P2 | Enter bank, PPS and passport details only in the portal at the address confirmed in P1 | RR1 | `[generic]` routine onboarding practice | your call |
| P3 | Ask what is kept from your passport, for how long, and who can see it | RR1 | `[generic]` data-minimisation practice under GDPR | your call |
| P4 | Accept within the five working days only after P1; if P1 takes longer, ask the people team in writing for a few extra days | Offer deadline | `[grounded]` the offer | your call |
| P5 | Before accepting, answer the Irish statutory question for yourself (G1) and note what you would learn in week one | R4 | `[grounded]` R4 | your call |

## Evidence status

Verified: none yet. Your background is self-report at `medium`; no artifact has been inspected.

Research tier: L1 — searches 3 of 5, fetches 0 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches for the company and its careers page were refused, so the company and the offer's domain stay unchecked. Would have moved RR1 and RR2 |
| 2. Role-family sweep | unavailable | One salary search for Payroll Administrator in Limerick was refused. Would have set the market line against the €40,000 offer and R2 |
| 3. Hiring manager's public footprint | unavailable | A name was given (Declan Garvagh); no query was sent after the search tool was refused. Would have moved the scope read in role reality |

## Dossier offer

If you want, I can write this up as a `tuesday-dossier.md` to keep and reread before you reply to the offer.

## Upgrade menu

- Your location and your pay floor → R1 and R2 move from `unclear` to `direct` or `hard_gate_fail`, and the decision can go to `go` or `no_go`.
- An anonymised payslip or a summary of your RTI submissions from your current role → R4 moves from `discovery` toward `direct`.
- Your own check of Marrowgate's website and switchboard, or search working later → RR1 and RR2 close; targets 1 and 2 can be rerun.
- Declan Garvagh's public professional profile, if search works later → the scope read in role reality and which story to lead with in interview.

## Questions

R1, R2 — Is Limerick with two office days a week workable for you, and is €40,000 at or above the lowest figure you would accept?

R4 — Have you run Irish PAYE, PRSI and USC yourself on a live payroll, including Revenue's real-time submissions and year-end returns?

R8 — When staff joined or changed pension contributions in your payroll, what did you actually process, even if your manager set up the scheme?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.