**Decision: conditional_go.** Apply, but confirm the company exists as described before you share anything beyond your CV and portfolio. Your background fits most of the role. The main gaps are being the only designer and running research with school owners. I ran no web searches, so the company checks below are yours to do.

**Fit ledger**
- **Meets:** 3+ years of product design; strong Figma; running your own user research; working directly with engineers.
- **Partial:** owning the booking flow end to end. You redesigned checkout, which is one step in a booking flow, not the whole flow.
- **Gaps:** never having been the only designer (capability); research with small business owners rather than travel customers (transferability).
- **Hard gates:** none failed. Galway hybrid fits your move back. Pay floor is unknown to me, so that gate is open.

**Evidence map**

| Requirement | Your evidence | Fit | Gap type |
|---|---|---|---|
| 3+ years product design | 4 years, Dublin travel-booking | Meets | — |
| Strong Figma | Daily use | Meets (self-stated; portfolio would verify) | — |
| Own user research | Monthly customer usability sessions | Meets | Transferability: consumers, not school owners |
| Work directly with engineers | Squad of four engineers | Meets | — |
| Own booking flow end to end | Checkout redesign | Partial | Presentation: don't stretch checkout into the whole flow |
| First designer, no peers | None stated | Gap | Capability |

**Posting observations** `[grounded]` unless marked
- **Employer unverified.** You couldn't find much online, and I haven't checked either. Until it's confirmed, this stays a conditional go.
- **Equity, 0.5–1%.** Ordinary for an early hire at a six-person company `[generic]`. It's worth little without vesting terms, option type and strike price, so ask for those.
- **Salary, €52,000–€60,000.** I can't calibrate it against the market without research `[generic, unverified]`.
- **WhatsApp outreach.** Informal, but not alarming `[inferred]`. Named co-founder and CTO, a specific role, and a stated process are all positives. The message asks for nothing sensitive. The real check is whether the calendar invite comes from a company email domain that matches the company's website.
- **"A messy real project over a polished deck."** Ask what that means in practice. Take-home work should have a time limit.

**Application plan**
- Lead with the checkout redesign and your monthly research sessions. Describe your actual role in each, not "owned the booking product."
- Answer the first-designer question directly. If you've ever had to make calls without a design peer, say so. If not, say how you'd set up feedback and review.
- For the call, ask what the research budget looks like, how you'd reach school owners, and what "ship" means for a team of six.

**Checks before the call** (free, and they take about 20 minutes)
1. Search the Companies Registration Office (CRO) for Fernquay. Check the registration date and whether Ronan Kehoe is listed as a director.
2. Confirm the calendar invite's sender domain matches the company website.
3. Find the live posting on the company's own site or a job board.
4. Look up Ronan Kehoe on LinkedIn, and find Saoirse, the CTO, and check they're listed at Fernquay.
5. Share nothing sensitive before an offer: no PPS number, ID or bank details. Pay for nothing and install no unfamiliar software.

**Upgrade menu**
- A web search (L1) could confirm the company's existence and the live posting, and check the salary and equity against Irish market norms.
- A portfolio link would let me verify the checkout work and the research sessions, which would raise your confidence in the fit ratings.
- A dossier (`tuesday-dossier.md`) can hold this assessment for later reference, and it would be ready for interview prep if you proceed. Say the word and I'll write it.

**Questions**
1. Can you send the job-board or careers-page link, and the sender domain of Ronan's invite?
2. What's your salary floor, and how much would equity change your decision?
3. Have you ever had product decision-making authority, or been the person who picked what got built? That's the crux of the "first designer" question.

Reply with answers, say "skip" to any question, or ask for a deeper check.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.