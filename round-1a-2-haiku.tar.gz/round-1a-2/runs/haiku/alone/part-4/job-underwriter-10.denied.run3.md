**Decision: conditional go.** Take the video call, but confirm Fernquay is a real company before you share documents, accept any offer, or pay for anything. Nothing I found is a hard-gate failure, and the posting reads as specific and plausible. The company itself is unverified.

**Research tier: L1, but web search was refused in this session.** I sent three searches (company, company registration, Ronan Kehoe) and the permission prompt was declined, so nothing about Fernquay is externally confirmed. Everything below rests on the posting and your message (`[grounded]`), plus my reasoning (`[inferred]`).

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Search not permitted; no fetch attempted |
| 2 | Role-family sweep (scope, title, pay for this seniority) | unavailable | Search not permitted |
| 3 | Hiring manager's public footprint (Ronan Kehoe) | unavailable | Search not permitted |

**Legitimacy**

- **Posting: plausible, not proven.** It names a niche, a city, a team size, a salary range, and a specific first-designer scope. Specificity isn't verification.
- **The WhatsApp message is the odd part, but not alarming by itself.** Small Irish startups often use WhatsApp informally. What matters is the next step: the invite must come from a company email address.
- **Unverified:** that Fernquay is registered, that Ronan and Saoirse hold the roles claimed, and that the video link goes where it says.
- **Red flags to watch for:** anyone asking you to pay for equipment or software, to send bank or ID documents before an offer, or to sign anything before you've spoken with both of them.
- **Equity** at 0.5–1% for a first hire at a six-person company is within the range I'd expect `[generic]`, but I can't check current figures from here. Ask for the option terms in writing.

**Fit: strong on the stated requirements**

- **3+ years product design:** you have 4 `[grounded]`.
- **Strong Figma:** daily use `[grounded]`.
- **Own user research:** monthly customer usability sessions `[grounded]`. The gap is audience: they want research calls with business owners, not consumers. That's a transferable gap, not a failure.
- **Works directly with engineers:** a four-engineer squad `[grounded]`.
- **Booking-flow experience:** you redesigned a checkout flow at a travel-booking company `[grounded]`. That is close to their core problem.
- **Location:** you're already in Galway, so the two-day office requirement is met `[grounded]`.
- **The real gap is capability, not a hard gate:** you've never been the only designer. This role means building process alone and having no design peer to check your work. Plan a concrete answer for that.

**Application plan (for the call)**

- Lead with the checkout redesign and what changed for customers, with numbers if you have them.
- Be ready to explain how you'd run research with school owners: who you'd recruit, how you'd pay them for time, and how you'd turn findings into shipped work.
- Have an answer for working without a design peer: how you'd get feedback, and how you'd set up critique with engineers.
- Ask them: runway and funding, what "first year" looks like, who decides on design, and the equity terms (options or shares, vesting, cap table, strike price).

**Verify before the call or any offer (about 15 minutes):**

1. Search the Companies Registration Office (cro.ie) for "Fernquay". A real Irish company has a registration number and officers.
2. Check the company's own website. If it has none, that's worth noting.
3. Confirm the calendar invite came from a company email domain that matches the website. A Gmail address is a warning sign.
4. Look up Ronan and Saoirse on LinkedIn. Their names, roles, and the company should match across sources.
5. Check where you saw the posting. If it's a job board, the listing should show the company name and link back to it.

If all five hold, move to `go`. If the company isn't on the registry or the invite comes from an unrelated domain, don't continue.

**Questions for you**

1. Where did you find and apply for the posting (a job board, their website, or a direct email)?
2. Can you share the company website or careers URL, and the email domain the invite came from? Both would let me check the employer directly.
3. Do you want me to run the web checks? That needs you to grant web search permission. Without it, steps 1 to 4 above are yours to do.

I can also put the verification steps and the call prep into a short document if that helps. This is the point where a tuesday-dossier.md would be useful, so say if you want one.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.