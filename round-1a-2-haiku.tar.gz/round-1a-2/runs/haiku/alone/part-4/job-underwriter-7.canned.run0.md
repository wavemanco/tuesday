**Yes, it's worth applying for, with conditions.** Decision: `conditional_go`. Apply, and confirm the conditions below in the first conversation or at the informal chat.

## Decision snapshot

**Fit ledger.**
- `hard_gate`: direct: R1, R2
- `must_have`: direct: R3, R5a, R6, R8 · adjacent: R5b (leg-ulcer care) · unclear: R4 (clear, timely written records), R7 (continence care), R9 (care planning)
- `important`: adjacent: R11 (holding a small caseload) · unclear: R10 (end-of-life visits), R12 (electronic patient record)
- `preferred`: absent: R13 (Doppler assessment)

Your registration, licence and post-registration experience meet the essential terms, and your wound, catheter and insulin work is direct. The fit gaps are in the places your CV is silent or only adjacent: caseload ownership, leg-ulcer care, continence, care planning, end-of-life work and records. R13 is the one clear absence, and it is desirable rather than essential.

**Opportunity ledger.** The role reads as sound and well defined: pay and mileage are stated, pool cars are provided, and a senior community nurse supports the caseload (RR3, positive). The open questions are how a first-year caseload is sized and supported (RR1) and whether the post is still live, since I could not confirm the posting itself (RR2). I found no severe red flags.

- **Hard gates:** none failed; none unconfirmed; met: R1 `direct`, R2 `direct`. Both rest on your statement and the CV. Neither has been inspected yet.
- **Severe red flags:** none found.
- **Conditions for go:**
  1. Check your NMC registration on the NMC register and confirm your licence details (R1, R2).
  2. Get concrete answers on caseload size and senior support (RR1), and whether continence, end-of-life work and care planning are expected in the first year (R7, R9, R10).
  3. Describe leg-ulcer care as wound care you have done, not as leg-ulcer experience (R5b).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Calderbrook Community Health, a community interest company running adult community nursing across Calderdale under an NHS contract; about 410 staff in four locality hubs | `[grounded]` calderbrookhealth.example/about (search result) |
| Team lead | Rhiannon Mabbott leads the Halifax district nursing team; eleven years as a district nurse; spoke on leg-ulcer clinics and Doppler training for new community staff | `[grounded]` communitynursingforum.example/speakers/rhiannon-mabbott (search result) |
| Role | Band 5 community staff nurse with a small caseload of your own, supported by a senior community nurse | `[grounded]` advert |
| Pay | £31,050–£37,800 plus mileage, stated | `[grounded]` advert |
| Pay calibration | Wardround 2026 places a community staff nurse Band 5 median at £34,300, interquartile range £32,400–£36,600. The advert's range covers that interquartile range, with its floor below it and its ceiling above it. Not a mismatch | `[generic]` wardround.example/2026-uk-community-nursing-pay-guide, n=1,240 |
| Mileage and cars | 61% of respondents in that survey were paid mileage; 24% had a pool or lease car. The advert's terms are in line | `[generic]` same survey |
| Working pattern | Home visits across a caseload, all recorded on an electronic patient record | `[grounded]` advert |
| Scope read | Caseload work in homes, with senior support: a normal scope for a first community post | `[inferred]` from the advert's duties against the Band 5 title |
| Unknowns | Caseload size in months 1–6; the senior nurse's role; whether continence, end-of-life and care planning are expected from the start; whether the post is still open | — |
| Contradictions | None found between the advert and the sources I could read | `[inferred]` |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Current NMC registration as an Adult Nurse | hard_gate | direct | medium | none | You state active registration (revalidation due March 2028). Specific and confirmed, but the register has not been checked. | `[grounded]` your CV | Check the NMC register yourself |
| R2 | Full UK driving licence | hard_gate | direct | medium | none | Full licence, category B. Stated, not inspected. | `[grounded]` your CV | Confirm the licence details |
| R3 | At least one year's post-registration experience | must_have | direct | medium | none | Five years as a staff nurse on an acute medical ward. Stated in the CV, with no document attached. | `[grounded]` your CV | none |
| R4 | Clear, timely written records | must_have | unclear | low | discovery | The CV says nothing about records. Your secondment visits would have involved documentation, but the standard is unknown. | `[grounded]` CV silence | Ask: how you document home visits, and whether anyone checks timeliness (closing question Q3) |
| R5a | Wound care | must_have | direct | medium | none | Pressure ulcers and surgical wounds, stated. | `[grounded]` your CV | none |
| R5b | Leg-ulcer care | must_have | adjacent | medium | transferability | Wound care carries over; no leg-ulcer work is named. Limit: no leg-ulcer assessment or dressing regime is evidenced. Do not present it as leg-ulcer experience. | `[inferred]` from R5a | See G2 |
| R6 | Catheter and continence care | must_have | direct | medium | none | Catheter care is stated. Continence care is not, so R7 carries it. | `[grounded]` your CV | none |
| R7 | Continence care | must_have | unclear | low | discovery | Not in the CV. Catheter care may be a starting point. | `[grounded]` CV silence | See G4 and closing question Q2 |
| R8 | Insulin administration | must_have | direct | medium | none | Stated in the CV. | `[grounded]` your CV | none |
| R9 | Care planning | must_have | unclear | low | discovery | Not in the CV. Discharge visits may have involved planning, but that is not stated. | `[grounded]` CV silence | See G4 |
| R10 | End-of-life visits | important | unclear | low | discovery | Not in the CV. Your discharge-to-assess work is about the first week after discharge, not end of life. | `[grounded]` CV silence | See G4 and closing question Q2 |
| R11 | Holding a small caseload of your own | important | adjacent | medium | transferability | You visited patients at home in their first week after discharge, but you say you have never held your own caseload. Limit: no ongoing responsibility for a patient list. | `[grounded]` your CV; `[inferred]` that the advert's caseload means a named patient list | See G1 and closing question Q1 |
| R12 | Electronic patient record | important | unclear | low | discovery | The CV does not name any patient record system. | `[grounded]` CV silence | Ask at the informal chat which system the team uses |
| R13 | Doppler assessment for leg ulcers | preferred | absent | none | capability | No direct or adjacent evidence. The team lead's forum talk covers Doppler training for new community staff, so the team may train you. | `[grounded]` CV silence; `[inferred]` that training may be offered, from the speaker page | See G3 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Caseload ownership (R11, important) | transferability | Home visits in your first post-discharge week; no ongoing patient list | This is the objection most likely to come up first. A clear account of follow-up work narrows it | Follow-up calls or visits where you kept a patient's plan on track; work with a senior nurse on a patient's home care | A caseload description or a sanitised care plan excerpt | `[inferred]` that the advert's caseload means a named patient list |
| G2 | Leg-ulcer care (R5b, must_have) | transferability | Pressure ulcer and surgical wound work | Leg-ulcer care is in the essential duties, so it needs a bridge that does not overclaim | Dressing and assessment of chronic wounds; wound-plan reviews; compression or offloading decisions you helped make | Wound-care documentation or a training record | `[inferred]` from R5a |
| G3 | Doppler assessment (R13, preferred) | capability | No Doppler evidence | Desirable, not essential. Training may close it | Any vascular or pulse assessment training; ankle-brachial work | A training certificate, or confirmation the employer trains this | `[generic]` that employers often train for desirable skills; `[grounded]` the forum talk |
| G4 | Continence, care planning, end-of-life (R7, R9, R10) | discovery | Not in the CV | These are core duties for the role. Even brief experience would shift the picture | Catheter-related continence decisions; discharge care plans you wrote or contributed to; supporting a patient or family near the end of life | A care plan excerpt (anonymised) or a ward or discharge note | `[grounded]` CV silence |
| G5 | Records and EPR (R4, R12) | discovery | No record or system detail | Written records are essential to the role | Any electronic record system you use; how you keep timeliness | A sample of an anonymised entry | `[grounded]` CV silence |

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Caseload size and senior support not described | unknown | — | "You will hold a small caseload of your own, supported by a senior community nurse." | The first-year caseload may be built up gradually, with the senior nurse taking a review role | `[inferred]` from the advert's duties against its silence on size | How big is a new community staff nurse's caseload in the first months, and what does senior support look like day to day? | unresolved |
| RR2 | Posting not confirmed live | unknown | — | "For an informal chat about the role, contact Rhiannon Mabbott." | Adverts are sometimes left up after a post is filled, or re-posted | `[generic]` pattern for job adverts; the careers page address I tried returned no page | Is this post still open, and where is it listed on your careers page? | unresolved |
| RR3 | Pay within sector band | positive_signal | — | "£31,050–£37,800 a year plus mileage" | The range is in line with the sector's pay for this band | `[generic]` Wardround 2026 survey; `[grounded]` advert | Is the point of entry fixed for Band 5, or does it depend on experience? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Check your NMC registration on the register and confirm your licence details before you apply | Lifts R1 and R2 from stated to checked | `[grounded]` your statement | your action |
| P2 | Ask Rhiannon Mabbott at the informal chat: caseload size and senior support in the first months; whether continence, end-of-life and care planning are expected from the start; which electronic record system the team uses; whether the team trains for Doppler | Answers RR1, R7, R9, R10, R12, R13 | `[inferred]` from the advert and the team lead's talk | pending your approval (contacting her) |
| P3 | Confirm the post is still open before you spend effort on the application | RR2 | `[generic]` pattern | your action |
| P4 | Frame the CV around discharge-to-assess home visits, wound care, catheter care and insulin administration. Do not describe the discharge visits as a caseload, and do not claim leg-ulcer or Doppler experience | Keeps the claims to what you can defend at interview (R5b, R11, R13) | `[grounded]` your CV sentences; the reframing audit applies | pending your approval |

## Evidence status

Verified: none yet. Every claim in the map rests on your CV or your statement in this conversation, both of which are self-report, and I have not inspected any document. The employer and team-lead facts come from public web pages I found.

Research tier: L1 — searches 3 of 5, fetches 1 of 2; user links read 0

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | yes | Searched "Calderbrook Community Health CIC Halifax" and a careers query; fetched calderbrookhealth.example/careers, which returned no page. The about page (calderbrookhealth.example/about) confirmed the employer exists as described. The posting itself is not confirmed: RR2 |
| 2. Role-family sweep | yes | Searched the Band 5 salary query; read Wardround 2026 (wardround.example/2026-uk-community-nursing-pay-guide). Moved the market calibration line |
| 3. Hiring contact's public footprint | yes | Searched the team lead's name with the careers query; read her conference speaker page (communitynursingforum.example/speakers/rhiannon-mabbott). Moved the scope read and the chat questions in P2 |

## Upgrade menu

- A link to the live posting, or the careers page address that lists it → RR2 closes, and the decision can move to `go` if RR1 also resolves.
- Your NMC register screenshot and licence check (both yours to do) → R1 and R2 move from medium to inspected.
- A short, anonymised example of a care plan, a discharge note or a record entry → R4, R7, R9 and R10 move from `unclear` if they show what you did.
- A training record for wound assessment, vascular or Doppler work → R5b and R13 strengthen.
- Deeper research on Calderbrook (its NHS contract terms, staff and leadership changes, recent news; up to 5 more searches and 2 more fetches) → available once, on your word.

I can write this up as a `tuesday-dossier.md` file for later use if you want it.

1. **G1 (caseload ownership):** In your secondment, did you ever follow a patient through after discharge with your name on the care plan, and how many did you have at once?
2. **G4 (continence, end-of-life):** Have you given continence care, or cared for someone at end of life, even on the ward or in discharge visits? What did that involve?
3. **G5 (records):** How do you document a home visit now, and does anyone check your entries for timeliness?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.