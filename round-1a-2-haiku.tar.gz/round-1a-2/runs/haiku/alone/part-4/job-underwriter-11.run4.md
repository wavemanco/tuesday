## Decision snapshot

**Duinvaart: worth your time, once one question is answered. Status: `hold_pending_answers`. Kroonhaven: not worth it now. Status: `no_go`.**

### Duinvaart Cold Chain, Operations Analyst, Rotterdam

**Fit ledger.**

- `hard_gate`: unclear: D8 (hybrid, three days a week in the Rotterdam office)
- `must_have`: direct: D1, D2, D3
- `important`: direct: D4a, D5 · adjacent: D4b (temperature compliance), D6 (route changes with depot managers)
- `preferred`: adjacent: D7 (Dutch a plus)

D1, D2 and D3 are the core asks and read as direct. D4b is a credible bridge with its limit named. D8 waits on your answer.

- **Hard gates:** none failed; unconfirmed: D8 (hybrid, three days a week in Rotterdam office); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** The posting is specific, with stated scope and tools (O1, positive). Pay is withheld (O2) and the employer is unverified (O3).

### Kroonhaven Foods, Supply Planner, Utrecht

**Fit ledger.**

- `hard_gate`: unclear: K8 (on-site in Utrecht)
- `must_have`: adjacent: K3 (run the weekly S&OP meeting) · unclear: K5 (advanced Excel) · absent: K1 (own the 13-week supply plan), K2 (3+ years of planning in FMCG), K4 (balance capacity against forecast), K6 (SAP IBP or similar), K7 (fluent Dutch)

No — K2 (3+ years planning), K6 (SAP IBP) and K7 (fluent Dutch) are absent, and none has a realistic closure inside an application cycle · `no_go`.

- **Hard gates:** none failed; unconfirmed: K8 (on-site in Utrecht); candidate constraints not given, so checks against them are unknown.
- **Severe red flags:** none found.
- **Opportunity ledger:** The scope is concrete (K-O3, positive). Pay is withheld (K-O2) and the employer is unverified (K-O1).

## Role reality

Provenance: the posting text is `[grounded]`; anything about the market or about how these roles usually run is `[generic]`. Market calibration is not available: the salary search was refused (see Evidence status), so no band is given for either title.

| Element | Duinvaart | Kroonhaven |
|---|---|---|
| Organization | Duinvaart Cold Chain, refrigerated fleet, Rotterdam `[grounded]` JD | Kroonhaven Foods, chilled ready meals, Utrecht `[grounded]` JD |
| Mandate | On-time delivery and temperature compliance, weekly Power BI dashboards, route changes with depot managers `[grounded]` | 13-week supply plan, production capacity against forecast, weekly S&OP `[grounded]` |
| Working pattern | Hybrid, three days a week in the office `[grounded]` | On-site in Utrecht `[grounded]` |
| Scope read | Ordinary for the title `[inferred]` from the stated tasks | Planning ownership at a single-range level, a planning-career step `[inferred]` from the stated tasks |
| Salary | Not stated; withheld (O2) | Not stated; withheld (K-O2) |
| Unknowns | Salary; whether route changes are decided by this role; temperature-monitoring tools | Salary; whether the role owns the forecast or only consumes it; planning system in use |
| Contradictions | None visible in the posting | None visible in the posting |

## Evidence map

Every fit call and confidence band rests on what you told me, which is self-report. Confidence is `medium` for specific claims with no artifact behind them. `high` needs something inspectable.

**Duinvaart**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| D1 | 2+ years in logistics or operations analysis | must_have | direct | medium | none | Four years as operations analyst at a parcel carrier, your statement | `[grounded]` your intake statement | none |
| D2 | Strong SQL | must_have | direct | medium | none | SQL daily, your statement | `[grounded]` your intake statement | none |
| D3 | Power BI or Tableau | must_have | direct | medium | none | Power BI daily, including the on-time delivery dashboard depot managers use | `[grounded]` your intake statement | A sanitised screenshot would raise to high |
| D4a | Track on-time delivery | important | direct | medium | none | Your on-time dashboard and weekly route review are the same work | `[grounded]` your intake statement | none |
| D4b | Track temperature compliance, refrigerated fleet | important | adjacent | low | transferability | Nothing on temperature monitoring. The method of tracking a threshold KPI and acting on it carries over; the subject does not | `[inferred]` from D4a's method against the silence on temperature | Q2 below |
| D5 | Build weekly dashboards in Power BI | important | direct | medium | none | Same tool and cadence you already run | `[grounded]` your intake statement | none |
| D6 | Work with depot managers on route changes | important | adjacent | medium | transferability | You ran the route-performance review with depot managers. Route-change decisions are not stated as yours | `[grounded]` your intake statement; `[inferred]` on the decision boundary | Ask in the screen whether the role decides route changes alone |
| D7 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational Dutch, not fluent. Preferred, so a minor risk | `[grounded]` your intake statement | none |
| D8 | Hybrid, three days a week in Rotterdam office | hard_gate | unclear | none | hard_gate | Your constraint was not given, so the gate cannot be checked. Confidence is none because there is no statement to grade | `[grounded]` the posting | Q1 below |

**Kroonhaven**

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| K1 | Own the 13-week supply plan | must_have | absent | none | capability | You have never worked in planning | `[grounded]` your intake statement | Closure path: a planning role first; not realistic this cycle |
| K2 | 3+ years supply or demand planning in FMCG | must_have | absent | none | capability | No planning years. Length of experience, so graded on fit, not treated as a gate | `[grounded]` your intake statement | As K1 |
| K3 | Run the weekly S&OP meeting | must_have | adjacent | medium | transferability | You ran a weekly performance review. That is a review cadence, not a planning meeting; you did not own the plan | `[grounded]` your intake statement; `[inferred]` on the overlap | Limit named: review of delivery performance, not supply decisions |
| K4 | Balance production capacity against forecast | must_have | absent | none | capability | Nothing in your background on capacity or forecast | `[grounded]` your intake statement | As K1 |
| K5 | Advanced Excel | must_have | unclear | none | discovery | Your background is silent on Excel. You use SQL and Power BI | `[grounded]` the silence in your background | Q2 below is for Duinvaart; this one is not asked, as K's decision is `no_go` on other rows |
| K6 | SAP IBP or a similar planning system | must_have | absent | none | capability | No planning-system experience stated | `[grounded]` your intake statement | As K1 |
| K7 | Fluent Dutch | must_have | absent | medium | capability | Conversational, not fluent. Fluency in weeks is not a realistic closure | `[grounded]` your intake statement | As K1 |
| K8 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | Your constraint was not given | `[grounded]` the posting | Confirm your location constraint |

## Gap recovery queue

| # | Gap (req) | Type | What I see | What would close it | Provenance |
|---|---|---|---|---|---|
| G1 | Temperature compliance (D4b) | transferability | Threshold-KPI tracking carries over; temperature monitoring does not appear in your background | Any cold-chain, refrigerated or temperature-alert work, even a single project | `[inferred]` the bridge from D4a; `[generic]` that cold-chain employers screen for this |
| G2 | Excel (K5) | discovery | Silent in your background | A line on your Excel level, or one example | `[grounded]` the silence |

The queue has no questions. The questions for D8 and G1 sit in the closing block, tagged by row.

## Opportunity risk register

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| O1 | Concrete scope and named tools | positive_signal | — | "Track on-time delivery and temperature compliance … build weekly dashboards in Power BI" | The role is defined and measurable | `[grounded]` JD | What does success look like at twelve months? | noted |
| O2 | Salary withheld | unknown | — | Not stated | The figure may sit outside the band you expect, or simply not be published | `[inferred]` from the omission | What is the budgeted salary for this role? | unresolved |
| O3 | Employer and posting unverified | unknown | — | "Duinvaart Cold Chain, Rotterdam" | The posting may be stale, or the employer may be too small to have a footprint | `[generic]` pattern for small employers, not a claim about this one | Is this role open on your careers page, and who would I interview with? | unresolved |
| K-O1 | Employer and posting unverified | unknown | — | "Kroonhaven Foods, Utrecht" | As O3 | `[generic]` pattern | As O3, addressed to Kroonhaven | unresolved |
| K-O2 | Salary withheld | unknown | — | Not stated | As O2 | `[inferred]` from the omission | As O2 | unresolved |
| K-O3 | Clear scope with a named process | positive_signal | — | "run the weekly S&OP meeting" | The role's remit is specified | `[grounded]` JD | Which of the 13-week plan decisions does this role make alone? | noted |

None of the unverified-employer entries is a risk signal about fraud. I could not check either company (see Evidence status), and that is the whole of it. Checking the posting on each employer's own careers page is one visit.

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Confirm the Duinvaart posting on Duinvaart's own careers page before you apply | O3 | `[grounded]` the unverified entry | Your action |
| P2 | CV line: "Worked daily in SQL and Power BI on the on-time delivery dashboard used by depot managers" | D3, D4a. Wording stays true to what you told me; confirm it fits your role | `[grounded]` intake statement | pending your approval |
| P3 | Ask O2 and O3's questions at first contact | Pay and employer are the open unknowns | `[grounded]` register | your call |
| P4 | Do not apply to Kroonhaven now | K1, K2, K4, K6 and K7 are absent | `[grounded]` the map | recommendation |

On P4, a `[generic]` observation: planning-adjacent roles often take people from ops analysis, but this one asks for planning years. Your interview preparation for Duinvaart can run through mock-interview once you decide to apply.

## Evidence status

Verified: none yet. Your intake statements are leads, not verified claims.

Research tier: L1 — searches 4 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page (both employers) | unavailable | Both company searches were refused by the tool's permission setting, so neither site or posting is checked. Would have moved O3 and K-O1 |
| 2. Role-family sweep (salary and scope, both titles) | unavailable | The salary searches were refused. Would have moved market calibration for both roles |
| 3. Hiring manager's public footprint | n/a | No name was given |

## Upgrade menu

- Your schedule and location limits (Rotterdam three days a week; on-site Utrecht) → D8 and K8 close; the Duinvaart decision moves to `go` or `no_go`.
- A sanitised screenshot or description of the on-time dashboard → D3 rises to `high`.
- Any cold-chain or temperature-alert work → D4b rises from adjacent toward direct.
- A line on your Excel level → K5 closes.
- Search access, or the two posting links → the employer check, and a market band for both salaries.
- A dossier emitted with this analysis: I can write `tuesday-dossier.md` if you want it kept; say so.

## Questions

Duinvaart needs one answer before it can be decided, and Kroonhaven's K5 is not asked because Kroonhaven's decision does not depend on it.

- D8 — Can you work three days a week in the Rotterdam office, and do you have a Utrecht on-site constraint for Kroonhaven?
- G1 — Have you done any cold-chain, refrigerated or temperature-alert work, even on a single project?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.