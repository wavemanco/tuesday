**Yes to Duinvaart, with conditions (`conditional_go`). No to Kroonhaven (`no_go`).** Your core background matches Duinvaart's main duties closely. Kroonhaven's must-haves are the planning experience you say you don't have.

Two sets of decisions below, one per role, and the comparison sits in the table. Each role's fit and opportunity are scored separately.

| Role | Status | Fit ledger | Opportunity ledger | Hard gates |
|---|---|---|---|---|
| Operations Analyst, Duinvaart (Rotterdam) | `conditional_go` | Must-haves D1–D4 `direct`; D5 `adjacent` | Sound and specific (RR4); no pay stated (RR2); employer not yet verified (RR1) | none failed; D7 unconfirmed |
| Supply Planner, Kroonhaven (Utrecht) | `no_go` | Must-haves K1, K3 `absent`; K2 `unclear`; K4, K5 `adjacent` | Coherent scope (RR2); employer not yet verified (RR1) | none failed; K7 unconfirmed |

## Operations Analyst, Duinvaart: `conditional_go`

- **Fit ledger.** `must_have`: direct D1, D2, D3, D4; adjacent D5. `important`: direct D6. `preferred`: adjacent D8. `hard_gate`: unclear D7.
- **Opportunity ledger.** The scope is concrete and the decision partner is named (RR4). The unknowns are pay (RR2) and where temperature data comes from (RR3). The employer is unverified (RR1).
- **Hard gates:** none failed; unconfirmed: D7 (Hybrid, three days a week in Rotterdam office); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** (1) you confirm the Rotterdam commute works (D7); (2) the posting appears on Duinvaart's own careers site (RR1); (3) your bridge on temperature compliance holds up in interview (D5).

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| D1 | 2+ years logistics/ops analysis | must_have | direct | medium | none | Four years as an ops analyst at a parcel carrier | `[grounded]` your statement, not inspected |
| D2 | Strong SQL | must_have | direct | medium | none | Daily use | `[grounded]` your statement |
| D3 | Power BI or Tableau | must_have | direct | medium | none | Daily use; you built the depot on-time dashboard. A sanitized screenshot would raise this to `high` | `[grounded]` your statement |
| D4 | Track on-time delivery | must_have | direct | medium | none | Same dashboard work | `[grounded]` your statement |
| D5 | Track temperature compliance, refrigerated fleet | must_have | adjacent | medium | transferability | Tracking, thresholds and exception reporting carry over. No cold-chain or temperature data in your record; that is the limit | `[inferred]` method transfers; domain does not |
| D6 | Work with depot managers on route changes | important | direct | medium | none | You ran the weekly route-performance review | `[grounded]` your statement |
| D7 | Hybrid, three days a week in Rotterdam | hard_gate | unclear | none | hard_gate | You haven't stated whether this works | — |
| D8 | Dutch a plus | preferred | adjacent | medium | transferability | Conversational, not fluent. Limit: not enough for a meeting in Dutch | `[grounded]` your statement |

**Register.**

| # | Signal | Class | Severity | Hypothesis and provenance | Verification question | Status |
|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified (web search refused, see tier line) | unknown | — | The posting may be live and standard; nothing was checked. `[generic]` pattern | "Can you point me at this role on Duinvaart's own careers site, and who would I interview with?" | unresolved |
| RR2 | No pay stated | unknown | — | Pay may sit below your floor, or be negotiable. `[inferred]` from the posting's silence | "What salary is budgeted for this role?" | unresolved |
| RR3 | Source of temperature data not described | unknown | — | The role may own thresholds, or only report on them. `[inferred]` from the posting's silence | "Where does temperature data come from, and who sets the compliance thresholds?" | unresolved |
| RR4 | Concrete scope with a named decision partner | positive_signal | — | Route changes are made with depot managers. `[inferred]` from the scope line | "Which route changes does this role approve alone?" | noted |

**Application plan** (all proposed, pending your approval):
- Apply once the posting verifies. Lead with the depot on-time dashboard. Any CV wording needs your approval, and I'll use only the figures you can give me.
- Prepare a short bridge answer for temperature compliance: your method carries over, the cold-chain domain doesn't, and here is how you'd close that. `[generic]` interviewers usually probe this gap.

## Supply Planner, Kroonhaven: `no_go`

Capability gaps sit across several must-haves (K1, K2, K3), and the closure time is years, not a course. A scoped-down target role is the realistic route.

- **Fit ledger.** `must_have`: absent K1 (3+ years planning in FMCG), absent K3 (SAP IBP or similar), unclear K2 (advanced Excel), adjacent K4 (fluent Dutch: conversational, not fluent), adjacent K5 (owning the 13-week plan: weekly review is the nearest structure). `important`: absent K6 (balancing production capacity against forecast). `hard_gate`: unclear K7 (on-site Utrecht).
- **Opportunity ledger.** The scope is clear (RR2), and the employer is unverified (RR1). The posting's problem is your fit, not its quality.
- **Hard gates:** none failed; unconfirmed: K7 (On-site in Utrecht); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **What would change this:** you'd need planning experience you don't have. The posting's 3+ year bar can only be changed by the employer.

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance |
|---|---|---|---|---|---|---|---|
| K1 | 3+ years supply/demand planning in FMCG | must_have | absent | medium | capability | You said you've never worked in planning. Time closes this, not a course | `[grounded]` your statement |
| K2 | Advanced Excel | must_have | unclear | low | discovery | Not in your record; SQL and Power BI overlap but don't cover planning models | — |
| K3 | SAP IBP or similar planning system | must_have | absent | medium | capability | No planning-system exposure stated | `[grounded]` your statement |
| K4 | Fluent Dutch | must_have | adjacent | medium | transferability | Conversational. Limit: not fluent, and the S&OP meeting may run in Dutch. Not a gate by the suite's definition, but the posting makes it a must-have | `[grounded]` your statement |
| K5 | Own the 13-week supply plan | must_have | adjacent | medium | transferability | Your weekly route review is a recurring plan-versus-actual cadence. Limit: no supply side or capacity work | `[inferred]` bridge from your review |
| K6 | Balance production capacity against forecast | important | absent | none | capability | No production or capacity work | — |
| K7 | On-site in Utrecht | hard_gate | unclear | none | hard_gate | You haven't stated whether this works | — |

**Register.**

| # | Signal | Class | Severity | Hypothesis and provenance | Verification question | Status |
|---|---|---|---|---|---|---|
| RR1 | Employer and posting not verified | unknown | — | As RR1 for Duinvaart. `[generic]` pattern | "Can you point me at this role on Kroonhaven's careers site?" | unresolved |
| RR2 | Scope and cadence stated | positive_signal | — | Clear accountability for a 13-week plan with a weekly forum. `[inferred]` from the posting | "What capacity decisions does this role make alone?" | noted |

**Application plan:** don't apply to this posting. If you want planning-adjacent work, look for demand-analyst or S&OP-analyst titles with lower planning-year bars. `[generic]` — I did not search for these.

## Research

Research tier: L1 — searches 2 of 5, fetches 0 of 2

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | Two searches (Duinvaart Cold Chain Rotterdam; Kroonhaven Foods Utrecht chilled ready meals) were refused at the permission prompt, so nothing came back. Would have checked RR1 for both roles |
| 2. Role-family sweep | unavailable | Not sent after the refusal. Would have set the market band behind RR2 and the scope norm for both titles |
| 3. Hiring manager's footprint | n/a | No name given |

I didn't retry the refused searches.

## Evidence status

Verified: your background as you stated it (four years at a parcel carrier; daily SQL and Power BI; the depot on-time dashboard; the route-performance review; conversational Dutch). This is your own statement, not inspected. Unverified leads: none. Rejected inferences: none.

Dossier offer: I can write this up as `tuesday-dossier.md` so you can return to it, if you want.

## Upgrade menu

- Approve web search and I'll check both postings are live, Duinvaart's pay context, and the role-family norms for both titles.
- A sanitized screenshot or description of the on-time dashboard would raise D3 to `high`.
- An Excel model you've built would move K2 from `unclear`.
- A recording or certificate of your Dutch would firm up D8 and K4.

## Questions

**Q1 (D7, K7):** Could you commute to Rotterdam three days a week, and to Utrecht every day? Is either a hard limit?

**Q2 (D8, K4):** Could you run a 30-minute meeting in Dutch at normal speed?

**Q3 (RR2):** What's your pay floor?

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.