**Decision: conditional_go.** Apply, but first confirm the posting is live and ask Rhiannon Mabbott about caseload support and Doppler training.

**Decision snapshot**
- **Fit:** Strong on every essential you can evidence from the CV. Gaps sit in caseload ownership (role-defining, not a listed essential), Doppler (desirable), and end-of-life and EPR, which the CV doesn't mention.
- **Hard gates:** NMC registration as Adult Nurse: met as stated (you verify on the NMC register; I did not check your PIN). Full UK licence: met. Post-registration experience of at least one year: met (five years). Location (Halifax): met. Pay band £31,050–£37,800: within range.
- **Opportunity:** Entity exists as described (see Evidence status). The posting itself could not be confirmed live.
- **Condition:** Verify the live posting before applying.

**Role reality**
- Band 5 community staff nurse, district nursing, housebound adults at home. Caseload-holding is stated as part of the job. `[grounded]`
- Pay: the posting's own figure is £31,050–£37,800 plus mileage. `[grounded]` A 2026 UK survey of Band 5 community staff nurses reports a median of £34,300 (IQR £32,400–£36,600), with 61% paid mileage. `[generic]` The advertised range sits around that median.
- Company: Calderbrook Community Health is a CIC running adult community nursing under an NHS contract in Calderdale, founded 2015, with 410 staff across four hubs. `[grounded]`, from its About page in search results.
- Scope read: discharge-to-assess visits in your current role are the closest match to this work. `[inferred]`

**Evidence map**

| # | Priority | Requirement | Fit | Confidence | Gap | Evidence |
|---|---|---|---|---|---|---|
| 1 | Essential | Current NMC registration, Adult | Meets | High (CV) | None | Registered Adult nurse, revalidation March 2028 |
| 2 | Essential | Full UK driving licence | Meets | High (CV) | None | Full licence, category B |
| 3 | Essential | ≥1 year post-registration | Meets | High (CV) | None | Five years as staff nurse |
| 4 | Essential | Clear, timely written records | Partly evidenced | Medium | Presentation | Not described in CV; discharge-to-assess documentation is the likely evidence |
| 5 | Stated duty | Wound and leg-ulcer care | Meets (wounds) | High | Leg ulcers not named | Pressure and surgical wounds |
| 6 | Stated duty | Catheter and continence care | Partly | Medium | Continence not named | Catheter care only |
| 7 | Stated duty | Insulin administration and care planning | Partly | Medium | Care planning not named | Insulin administration; care planning not stated |
| 8 | Stated duty | End-of-life visits | Not evidenced | Low | Discovery | Not in CV |
| 9 | Stated duty | Electronic patient record | Not evidenced | Low | Discovery | Which system is not stated |
| 10 | Stated duty | Own caseload, supported by senior nurse | Not met | High | Capability | You have never held a caseload |
| 11 | Desirable | Doppler assessment for leg ulcers | Not met | High | Capability (trainable) | Never done |

**Gap recovery queue** (questions are asked below)
- **Row 10, caseload:** Gap is real and the CV says so. Closes by asking whether caseload onboarding and senior supervision are offered. Don't describe discharge-to-assess visits as caseload ownership.
- **Row 11, Doppler:** Desirable, not essential. Closes if the employer offers training.
- **Row 8, end-of-life:** Closes if you did end-of-life or palliative home visits in your current role.
- **Row 9, EPR:** Closes once you name the system you've used.

**Opportunity risk register**
- **Severity: medium.** Standing entry: the posting could not be confirmed live. The careers page link returned no page. Resolves with the live posting link, or the employer's vacancy page.
- **Severity: low.** Rhiannon Mabbott's role is corroborated by a public forum profile, which describes her leading the Halifax district nursing team. `[grounded]`
- **Severity: low.** The posting says Band 5 with a caseload, and you have no caseload experience. This is a fit gap, not a red flag, but expect to be asked about it.

**Application plan (as far as evidence allows)**
1. Verify the live posting, and check your NMC registration on the register.
2. Ask Rhiannon for an informal chat. Ask about caseload onboarding, senior supervision, Doppler training, and the EPR system.
3. Tailor the CV to lead with discharge-to-assess home visits, wound care, catheter care, and insulin administration. `resume_edits_pending_approval`: nothing is final until you approve it.
4. Do not claim caseload experience or any Doppler exposure.

**Evidence status**

Research tier: L1 — searches 3 of 5, fetches 1 of 2

| Target | Status | Reason |
|---|---|---|
| 1. Company site and careers page | yes | Entity confirmed via search of "Calderbrook Community Health CIC Halifax" (About page). Careers page fetch returned no page, so the posting is not confirmed live. |
| 2. Role-family sweep | yes | Search "Band 5 community staff nurse district nursing Halifax salary" (Wardround 2026 pay guide). |
| 3. Hiring manager footprint | yes | Search "Rhiannon Mabbott Community Nursing Team Lead" (forum speaker profile). |

No L2 targets were run.

**Dossier offer:** If you want, I can save this assessment as `tuesday-dossier.md` for later use.

**Upgrade menu**
- A link to the live posting or the Calderbrook vacancy page: would move the posting risk from medium to resolved.
- Your EPR experience and any end-of-life or continence visits: would close rows 8 to 9 and firm up row 6.
- L2 research (up to 5 more searches and 2 more fetches): would check company funding, leadership changes, and public candidate reports.

**Questions**
1. (Row 8) In your discharge-to-assess role, did you do end-of-life or palliative home visits?
2. (Row 9) Which electronic patient record system have you used?
3. (Posting) Can you share the live posting link or the Calderbrook vacancy page?

Response mode: answer each question in turn, or reply "skip" to any of them.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.