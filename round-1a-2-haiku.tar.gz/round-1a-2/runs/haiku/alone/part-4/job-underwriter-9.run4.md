**Decision snapshot — conditional go, pending verification of the employer.** Nothing goes into the onboarding portal until the company checks out.

- **Fit (per requirement, not a score):** Most must-haves are met on your own account. Irish PAYE/PRSI/USC is the one must-have I can't confirm from what you've given me. Pension changes, the 240-staff scale and the housing sector are gaps.
- **Hard gates:** Hybrid Limerick attendance is **unknown**, because I don't know where you live. Pay at €40,000 is inside the advertised €38,000–€42,000 band.
- **Opportunity:** I could not verify that Marrowgate Housing exists as described. My search permission was denied, so this is L0: provided documents only. Everything below about the company is unverified.

**Your question: is it normal to be asked for bank details, PPS and passport?**

Asking for these *after you accept* is normal in Ireland `[generic]`. Employers need bank details for salary, your PPS number for Revenue and payroll, and a right-to-work check, and the passport scan is a standard way to do that. Asking for them *before* any offer, or by email, or to a personal account, would be a red flag. This offer does none of those things on its face.

Ways to check before you send anything:

1. **Check the domain.** Confirm `marrowgatehousing.ie` is the domain on the company's own website, and that the offer came from it. Compare it to the address on the posting, not to anything in the email. Look for lookalikes such as an extra hyphen or a different TLD.
2. **Check the portal link.** Before you enter anything, the link should go to a page on that same company domain, or to a named payroll provider the company tells you about in writing. Do not use a link that leads to a shortener, a login page on an unfamiliar domain, or a page that asks for a card or a fee.
3. **Check the company is real.** Look for it on the company's own site and on the Companies Registration Office register. Housing associations are usually registered with the Approved Housing Bodies Regulatory Authority (AHBRA), which you can search `[generic]`. Ask the People Team for the registered name, and check it matches.
4. **Ask who handles your data.** Ask whether the portal is run by the company or a third party, and where the data is held. That is a fair question at this stage.
5. **Send only through the portal.** Do not send the passport or PPS by email. Bring the original passport on day one as the offer says.
6. **Never pay anything.** A genuine employer will never ask you for money to start or to "process" the job.

If the domain, the register entry and the portal all check out, the request is normal. If any one of them doesn't, stop and don't submit.

**Role reality** `[grounded]` from the posting and offer: permanent post, €40,000, hybrid two days a week in Limerick, reporting to Declan Garvagh, Finance Manager, 240 staff. The duties are the full monthly cycle, starters, leavers, pension changes, GL reconciliation and staff queries. Market calibration: the €38k–€42k band is `[generic]`, not a claim about this employer.

**Evidence map**

| # | Priority | Requirement | Fit | Gap | Evidence (your account) | Confidence |
|---|---|---|---|---|---|---|
| 1 | Must | 2+ years running payroll | Met | — | 3 years fortnightly payroll, 90 staff | Stated, CV-only |
| 2 | Must | Irish PAYE, PRSI, USC | Unknown | Jurisdiction not stated | Hotel payroll, country not given | Unconfirmed |
| 3 | Must | Strong Excel | Met | — | Daily use; pivots; XLOOKUP | Stated |
| 4 | Must | Payroll qualification or working towards | Met | — | Payroll Technician cert, 2024 | Documentary (certificate) |
| 5 | Must | Starters and leavers | Met | — | Done in role | Stated |
| 6 | Preferred | Monthly payroll-to-GL reconciliation | Met | — | Done monthly in role | Stated |
| 7 | Preferred | Pension changes | Gap | Never done yourself | Manager handled them | — |
| 8 | Implied | Scale of 240 staff | Partial | 90 → 240 | Current scale | — |
| 9 | Implied | Housing sector | Gap | Discovery | None stated | — |
| 10 | Hard gate | Hybrid Limerick | Unknown | Your location | Not given | Unconfirmed |

**Gap recovery queue** (no questions here; the questions are below)
- Row 2: Irish PAYE/PRSI/USC. Closed by confirming the hotel payroll ran under Irish rules, or by naming the Irish payroll qualification you studied.
- Row 7: Pension changes. Closed by describing any pension admin you have seen, or by a short plan to learn the scheme's process. Present it as untried, not as experience.
- Row 8: Scale. Closed by describing what your 90-staff process would look like at 240.
- Row 9: Housing sector. Transferable; close by showing how your payroll controls carry over.

**Opportunity risk register**
- **Unverified employer** (red flag, severity high, until checked). Resolve with the live posting link, the company's careers page, the registered name, and the domain check above.
- **Sensitive data request** (severity medium). Normal at the stage described, but only acceptable through the verified portal.
- **Hard gate unknown** (Limerick attendance). Resolve by confirming your commute.

**Application plan**
1. Verify the employer using the six checks above.
2. If verified, confirm your location and Irish payroll experience before accepting.
3. Accept within the five working days, by reply to the verified address.
4. Submit the portal details only after step 1.
5. Use the pension and scale gaps as honest learning points in conversation. Do not claim pension experience you don't have.

**Evidence status**

Research tier: L0 — no searches

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company site and careers page | unavailable | Web search permission was not granted in this session |
| 2 | Role-family sweep | unavailable | Same |
| 3 | Hiring manager's public footprint | unavailable | Same, and no further name given |

**Dossier offer:** If you want, I can write up this assessment as a `tuesday-dossier.md` file to keep with your application.

**Upgrade menu**
- A link to the live posting or the company's careers page. Unlocks the verification of the employer.
- Your home location and commute to Limerick. Closes the hard-gate row.
- Whether your hotel payroll was Irish. Closes the must-have row on PAYE, PRSI and USC.
- Search access, if you grant permission. Would let me check the company register and AHBRA listing directly.

**Questions**
1. Where do you live, and how would you commute to the Limerick office two days a week? *(Row 10)*
2. Was your hotel payroll run under Irish PAYE, PRSI and USC rules? *(Row 2)*
3. Do you have a link to the live posting or the company's careers page? *(Employer verification)*

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.