## Decision snapshot

**Decision: `no_go`.** Don't send your IBAN, PPS number or passport photo, don't pay the €349, and don't deposit any cheque they send.

- **Candidate fit:** Strong on paper for a genuine customer-service or operations role: three years on Zendesk at about 60 tickets a day, two new starters trained, and a team tracker kept in Excel [grounded, from your description]. That fit is real, but it doesn't make this offer safer.
- **Opportunity:** The process is built to collect identity documents and move money. The red flags below are decisive whatever the research shows.
- **Hard gates:** Pay is a mismatch, not a clean fail. The posting says "up to €26/hr plus commission". At the top rate with no commission, reaching €30,000 takes about 22 hours a week, every week of the year [inferred from the posting's rate].

## Opportunity red flags

Each point is from the messages you pasted, with the reason it matters.

1. **Identity documents before any interview.** They asked for your IBAN, PPS number and passport photo before the "chat interview". Payroll setup happens after a signed offer through a verifiable process, not in a chat [generic].
2. **Paying for your own equipment.** A €349 payment to an unnamed "equipment partner", refunded "with your first wages", is a standard way to take money from applicants [generic].
3. **The cheque arrangement.** They send €2,850, you keep €350, and you transfer €2,500 onward. This is the classic overpayment scam. The cheque is typically returned as fraudulent days or weeks later. By then the €2,500 you sent is gone, and the bank can hold you responsible for the shortfall.
4. **No verifiable employer.** Hiring runs entirely on Telegram, with no calls, no video and no company domain. The contact address is a generic mail address, not a company one.
5. **The "interview" and offer.** The job was declared yours in one message, after a chat, with no contract and no role details.

**Failed attribution:** Research was not run, so I could not confirm that Velloway Logistics exists as described. This is a standing entry in the risk register. It does not change the decision: even if a real company is behind this, the requested payments and cheque handling are the scam itself. Anyone impersonating a real firm would use the same steps.

## Evidence status

Research tier: L0, no searches; user links read 0.

| # | Target | Status | Reason |
|---|---|---|---|
| 1 | Company official site and careers page | n/a | L0 chosen; the decision rests on the posting and messages, not on the employer's existence |
| 2 | Role-family pay and scope sweep | n/a | L0 chosen; pay mismatch is calculated from the posting's own rate |
| 3 | Hiring manager public footprint | n/a | No name given |

## Role reality

- **Stated pay:** "Up to €26/hr plus commission", 15–30 hours a week [grounded]. At 15–30 hours over 52 weeks, base pay is about €20,000–€40,000 [inferred]. Commission is unstated, so the posting does not commit to €30,000.
- **Stated scope:** Order processing, spreadsheets, written English [grounded]. This is ordinary admin and is the kind of role that gets used as cover for scams.

## What to do now

1. **Send nothing.** Don't reply with the IBAN, PPS number or passport photo, don't pay the €349, and don't lodge any cheque they send.
2. **If you've already sent anything,** call your bank now, using the number on your card or in the app. Report the transfer and ask whether it can be recalled. Keep every message.
3. **Report it.** Report the scam to the Gardaí (your local station or the Garda online reporting). Report the Telegram account to Telegram, and the listing to the jobs site.
4. **If you sent a passport photo,** tell your bank and watch your accounts for unusual activity. Consider contacting the Passport Office about the document.
5. **For real roles,** your background fits Zendesk-based customer support and operations coordinator jobs. Check each employer on its own website, and apply only through a company's own careers page or a known job board.

## Gap recovery queue

- **Employer existence:** Would be closed by a live posting on the company's own careers page, not one that exists only on Telegram or the jobs site.
- **Pay gap:** Would be closed by a stated salary range with commission terms in writing.

Neither gap can reopen this offer on its own. The cheque mechanics and up-front payments would also have to disappear.

## Upgrade menu

- **What would change the answer:** A verified employer with a live posting on its own site, a written contract, and no up-front payments, cheques or requests for identity documents before a signed offer.
- **Optional check:** A light research pass to test whether the company exists. It can't clear the red flags above.

## Questions

1. Have you sent anything to them yet: your IBAN, PPS number, passport photo, a payment, or a cheque deposit? The answer decides which of the steps above are urgent.
2. Do you want me to write a `tuesday-dossier.md` for this posting, so the warning signs are saved for later?

Reply with an answer to each, or "skip".

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.