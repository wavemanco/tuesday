**Yes, take the call, after two quick checks: `conditional_go`.** Nothing in the messages asks you for money, bank details, ID or a deposit, and a video interview is a normal next step. I could not confirm that Fernquay exists as described, though: the web searches were refused in this session, so that check is still open.

- **Hard gates:** none failed (R1 `direct`); unconfirmed: R2 (Pay €52–60k against your minimum); candidate constraints not given — checks against them unknown.
- **Severe red flags:** none found.
- **Conditions for go:** (1) the company checks out on its own website and the Irish CRO register (P1, P2); (2) the calendar invite comes from the company's own email domain (P3); (3) the €52,000 base clears your minimum (R2); (4) on the call, the booking-flow decision rights and design support are concrete (RR2).

**Fit ledger.**

- `hard_gate` — direct: R1 · unclear: R2 (Pay €52–60k against your minimum)
- `must_have` — direct: R3, R4, R5, R6 · adjacent: R7 (Own the booking flow end to end)
- `important` — adjacent: R9 (Research calls with school owners) · unclear: R8 (Work as the only designer)

R7 — a credible bridge, its limit named; R8 — no evidence either way; R2 (`low`) — waiting on your minimum.

**Opportunity ledger.** Scope and terms are stated plainly (RR5), but the company itself is thinly evidenced: RR1 (employer not established from attributable sources), RR2 (a bundled role with decision rights unstated), RR3 (pay and equity unchecked) and RR4 (stage and runway unknown).

## Role reality

| Element | What it is | Provenance |
|---|---|---|
| Organization | Six people in Galway, booking software for sea-kayak and surf schools; co-founder Ronan Kehoe, CTO Saoirse | `[grounded]` posting and WhatsApp message |
| Mandate | First product designer: own the booking flow end to end, run research with school owners, ship with two engineers | `[grounded]` posting |
| Working pattern | Hybrid, two days a week at the Galway office | `[grounded]` posting |
| Pay | €52,000–€60,000 plus 0.5–1% equity | `[grounded]` posting |
| Market calibration | Not established. The role-family sweep did not run (search refused), so I have no salary band to set €52k against | — |
| Unknowns | Stage, funding, number of paying schools, design budget, whether a product manager exists, your pay floor | — |
| Contradictions | None in the material you supplied | — |

## Evidence map

| # | Requirement | Priority | Fit | Confidence | Gap | Reasoning | Provenance | Next action |
|---|---|---|---|---|---|---|---|---|
| R1 | Galway-based, two days on site | hard_gate | direct | medium | none | You moved back to Galway last year | `[grounded]` your statement | none |
| R2 | Pay €52–60k against your minimum | hard_gate | unclear | low | hard_gate | Your floor was not given | `[grounded]` posting | Q3 |
| R3 | 3+ years of product design | must_have | direct | medium | none | Four years as a product designer | `[grounded]` your CV | Portfolio would raise this |
| R4 | Strong Figma | must_have | direct | medium | none | Daily use, stated | `[grounded]` your CV | Figma link would raise this |
| R5 | You have run your own user research | must_have | direct | medium | none | Monthly customer usability sessions. The audience was travellers, not school owners, so the method transfers and the audience does not | `[grounded]` your CV; audience gap `[inferred]` | Lead with this |
| R6 | Work directly with engineers | must_have | direct | medium | none | Four-engineer squad | `[grounded]` your CV | none |
| R7 | Own the booking flow end to end | must_have | adjacent | medium | transferability | You redesigned checkout, one stage of the flow, inside a squad. End-to-end ownership is not evidenced | `[inferred]` from your checkout work | G1 |
| R8 | Work as the only designer | important | unclear | low | discovery | Never done it; no evidence either way | `[grounded]` your statement | G2 |
| R9 | Research calls with school owners (small B2B operators) | important | adjacent | medium | transferability | Method direct; the buyer is a different kind of customer | `[inferred]` | Covered by R5 |

## Gap recovery queue

| # | Gap (req) | Type | What I currently see | Why it matters | Experience that may count | Useful evidence | Provenance |
|---|---|---|---|---|---|---|---|
| G1 | Own the booking flow end to end (R7, must_have) | transferability | You led checkout redesign in a squad; who did research, decided and shipped is not stated | End-to-end ownership is the core of the role; the bridge is real but has a named limit | Booking or checkout work you led from research to launch; a flow you scoped, not just designed | Your checkout case study with its research and decision log | `[inferred]` bridge; `[generic]` that this is the likeliest objection |
| G2 | Work as the only designer (R8, important) | discovery | No record of working without a design peer to check your work | "First designer" means no one to review your decisions | Setting your own research plan or critique without a peer; shaping design practice across engineers | A short note on how you worked when no peer reviewed your decisions | `[grounded]` your statement |

## Opportunity risk register

The WhatsApp message asks for no money, bank, ID or deposit, and it schedules a video interview. Scheduling by chat for an interview held elsewhere is not a signal, so it raises no entry.

| # | Signal | Class | Severity | Source quote | Hypothesis | Provenance | Verification question | Status |
|---|---|---|---|---|---|---|---|---|
| RR1 | Employer not established from attributable sources | risk_signal | medium | "We are six people in Galway making booking software" | The company may be too new or small to have a footprint, the posting may be stale, or it may not be a real hiring employer. This run could not check, so this is not evidence the company is absent | `[generic]` pattern for companies this size | Where is this role listed on your own careers page, and which company is the employer of record? | unresolved |
| RR2 | Bundled role with decision rights unstated | risk_signal | medium | "own the booking flow end to end, run research calls … ship alongside our two engineers" | One title may cover product design, research and product management, with ownership of the flow in name only | `[inferred]` from the posting's scope against its silence on decision rights | Which booking-flow decisions does this role make alone, and who signs off on them? | unresolved |
| RR3 | Pay and equity unchecked | unknown | — | "€52,000–€60,000 plus 0.5–1% equity" | The band may be low for this scope; equity at this stage is hard to value | `[generic]` band not searched this run | How was the €52,000–€60,000 band set for this scope, and what does 0.5–1% equal in shares? | unresolved |
| RR4 | Stage, funding and customers unknown | unknown | — | "six people" | Runway and the number of paying schools set how long the role lasts | `[generic]` | How many schools pay for the product today, and how many months of runway does the company have? | unresolved |
| RR5 | Scope, people and terms stated plainly | positive_signal | — | "we would rather see one messy real project than a polished deck" | Named leaders, a concrete product and stated terms are the opposite of an evasive posting | `[grounded]` posting and message | Who are the two engineers, and what do they need from design day to day? | noted |

## Application plan

| # | Action | Why | Provenance | Status |
|---|---|---|---|---|
| P1 | Find Fernquay's own website yourself and confirm the role is listed there | RR1 | `[generic]` check method | you do this |
| P2 | Search the Irish CRO register (cro.ie) for the company and check whether Ronan Kehoe is listed as a director | RR1 | `[generic]` public check | you do this |
| P3 | Check the sender's domain on the calendar invite matches the domain on P1; do not reply with personal or bank details over WhatsApp | RR1, process | `[generic]` | you do this |
| P4 | Set your minimum base before the call | R2 | `[grounded]` | you do this |
| P5 | Take the 45-minute call. Put RR2 and RR3 to the interviewers as written. Lead with the checkout case study, and say plainly that you have never been the only designer and how you would work when you are | R7, R8, RR2 | `[grounded]` register; the framing is your own truthful limit | pending your approval |

## Evidence status

Verified: none yet. Your CV claims are your own account and have not been checked.

Research tier: L1 — searches 2 of 5, fetches 0 of 2; the host refused every search. No user links read.

| Target | Status | What it moved, or would have |
|---|---|---|
| 1. Official site and careers page | unavailable | The search for Fernquay was refused, so there is no result. It would have moved RR1 and whether the posting is live |
| 2. Role-family sweep | unavailable | No search was sent once the host refused searches. It would have set the market band for RR3 and R2 |
| 3. Hiring manager's public footprint | unavailable | The search for Ronan Kehoe was refused. It would have informed how to position the call |

## Upgrade menu

If you want this kept, I can write the assessment to `tuesday-dossier.md`.

- Your check of the company's own website and the CRO register → RR1 closes or escalates, and can move the decision to `go` or `no_go`.
- The invite's sender address and the careers-page link → confirms the call and that the posting is live.
- Your minimum base salary → R2 resolves.
- A portfolio link or Figma file for the checkout work, or a project you led alone → R3, R4 and R7 confidence rises.
- A deeper pass on Fernquay (funding, leadership, past hiring; up to 5 more searches and 2 more fetches) — offered once; say the word and it runs.

1. When you have worked without another designer to check your decisions, how did you get feedback and decide what shipped? (G2)
2. On the checkout redesign, which parts did you own from research to launch, and which did the squad share? (G1)
3. What is your minimum base salary? (R2)

Answer in text, paste a voice transcript, attach a document, drop a link, or say skip.

**Watch-out:** A summary line here can contradict the evidence table — before you act on a count, an "only" or an all-clear, check it against the table's rows.